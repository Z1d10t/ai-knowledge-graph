# Lead-Free Perovskite Materials for Solar Cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nano-Micro Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 354 |
| 作者 | Ming-Hao Wang, Wei Wang, Ben Ma, W. Shen, Lihui Liu, K. Cao, Shu-Fen Chen, Wei Huang |
| DOI | 10.1007/s40820-020-00578-z |
| 源文件 | 044_Wang_2021_Lead-Free-Perovskite-Materials-for-Solar-Cells.pdf |

---
ISSN 2311-6706 e-ISSN 2150-5551 CN 31-2103/TB 

https://doi.org/10.1007/s40820-020-00578-z 

## **<mark>REVIEW</mark>** 



# **Lead‑Free Perovskite Materials for Solar Cells** 

###### **Cite as** 

> Nano-Micro Lett. Minghao Wang<sup>1</sup> , Wei Wang<sup>1</sup> , Ben Ma<sup>1</sup> , Wei Shen<sup>1</sup> , Lihui Liu<sup>1</sup> , Kun Cao<sup>1</sup> , 

> (2021) 13:62 Shufen Chen<sup>1,2*</sup> , Wei Huang<sup>1,2*</sup> 

Received: 19 August 2020 Accepted: 4 December 2020 Published online: 25 January 2021 © The Author(s) 2021 

#### **HIGHLIGHTS** 

- The toxicity issue of lead-based halide perovskites hinders theirs large-scale commercial applications in solar cells. 

- A variety of non- or low-toxic perovskite materials have been used for development of environmentally friendly lead-free perovskite solar cells, some of which show excellent optoelectronic properties and device performances. 

- At present, more new lead-free perovskite materials with tunable optical and electrical properties are urgently required to design highly efficient and stable lead-free perovskite solar cells. 

**ABSTRACT** The toxicity issue of lead hinders large-scale commercial production and photovoltaic field application of lead halide perovskites. Some novel non- or low-toxic perovskite materials have been explored for development of environmentally friendly lead-free perovskite solar cells (PSCs). This review studies the substitution of equivalent/ heterovalent metals for Pb based on first-principles calculation, summarizes the theoretical basis of lead-free perovskites, and screens out some promising lead-free candidates with suitable bandgap, optical, and electrical properties. Then, it reports notable achievements for the experimental studies of lead-free perovskites to date, including the crystal structure and material bandgap for all of lead-free materials and photovoltaic performance and stability for corresponding devices. The review finally discusses challenges facing the successful development and commercialization of lead-free PSCs and predicts the prospect of lead-free PSCs in the future. 

**KEYWORDS** Solar cells; Perovskite; Lead-free; First-principles calculation; Photovoltaic 



<!-- Start of picture text -->
AB(II)X3<br>A2B(II)X4 A2 B(IV)X6<br>        Enviomently Friendly<br>Lead-free Perovskite Materials<br>AB(Ch, X)3 A2B(I)B(III)X6<br>A3 B(III)2X9<br><!-- End of picture text -->

> * Shufen Chen, iamsfchen@njupt.edu.cn; Wei Huang, wei-huang@njtech.edu.cn; iamdirector@fudan.edu.cn 

> 1 Key Laboratory for Organic Electronics and Information Displays & Jiangsu Key Laboratory for Biosensors, Institute of Advanced Materials (IAM), Jiangsu National Synergetic Innovation Center for Advanced Materials (SICAM), Nanjing University of Posts & Telecommunications (NUPT), 9 Wenyuan Road, Nanjing 210023, People’s Republic of China 

> 2 Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE) and Xi’an Institute of Biomedical Materials & Engineering, Northwestern Polytechnical University, 127 West Youyi Road, Xi’an 710072, People’s Republic of China 

1 3 

**62** Page 2 of 36 

Nano-Micro Lett. (2021) 13:62 

### **1 Introduction** 

As a major driving force of the world today, traditional fossil fuels have been essential from the first industrial revolution. Although previous industrial revolutions have brought human society into an unprecedented boom era, they have simultaneously caused tremendous energy and resource consumption and aggravated the contradiction between human and nature, making us have to pay a huge environmental price and ecological cost. With the fast development of world’s economy and social productive forces, the requirement of energy has also been growing rapidly and the traditional fossil energy has been incapable of meeting our demands. So entering the twenty-first century, humanity has been facing unprecedented challenges of global crises of energy and resource, environment, ecology, and climate change. All of these issues have initiated the fourth industrial revolution, namely the green industrial revolution. At this time, solar energy as the initial source of all energy inevitably becomes new support for human and social development due to its advantages of pollution-free, renewability, huge energy, and so on. Optoelectronic conversion as one of the major utilizations of solar energy has been widely researched in the past several decades, and solar cells belong to the most important type of optoelectronic converters. The development of low-cost, high-efficiency solar cells has become a central issue in recent years. And perovskite solar cells (PSCs), as a promising class of solar cells family, have attracted intensive attention in the past decade due to high absorption coefficient, excellent bipolar charge mobility, long carrier diffusion length, low exciton binding energy, low trap state density, and tunable bandgap. 

The power conversion efficiency (PCE) of PSCs based on lead (Pb) perovskites has been dramatically improved from the initial 3.8% to recently certified value of 25.2% [1–24]. However, there exist unavoidable shortcomings in these Pb-based high-efficiency PSCs (e.g.,  MAPbI3,  FAPbI3, Cs0.05FA0.85MA0.10Pb(I0.97Br0.03)3), that is, the element lead is toxic to the environment and organisms and difficult to discharge from the body. Research indicates that the contamination of lead ions to soil and water sources is permanent and generates a very serious negative impact on human, animal, and plant survival [25–34]. The human’s nervous, digestive and blood systems eventually show functional disorders in the case of lead poisoning since lead can enter 

human’s body, bind with enzyme and finally store in soft tissues and bones such as spleen, kidney, liver, and brain through blood circulation. Generally, most people show lead toxic symptoms when lead intake reaches about 0.5 mg/day [25–27]. Therefore, to guarantee human’s safe and pollutionfree natural environment it is necessary to develop some non- or low-toxic metal ions to replace lead as perovskite absorbers of PSCs [28–34]. 

Generally, metal halide perovskites have a universal chemical formula of  ABX3, where A is an organic cation, B is a metal cation and X is a halogen anion [35–55]. Here, the organic cation usually includes methylammonium (MA), formamidinium (FA), Cs, or their mixture, and the halogen anion consists of Cl, Br, I or their mixture. For B, previous work has showed that less toxic ions like  Sn<sup>2+</sup> ,  Bi<sup>3+</sup> ,  Ge<sup>2+</sup> , Sb<sup>3+</sup> ,  Mn<sup>2+</sup> , and  Cu<sup>2+</sup> could be used as an alternative ion to Pb<sup>2+</sup> in perovskites to constitute a new lead-free perovskite structure [56–63]. The introduction of these metal cations not only increases the diversity of perovskite species, but also enhances environmentally friendly features of PSCs. 

This review mainly focuses on various lead-free perovskite materials and related solar cell applications by summarizing recent work about theoretical bases and experimental studies of those lead-free perovskites. Specifically, it summarizes the replacement of Pb with other possible isovalent and heterovalent elements proposed recently. Herein, the isovalent elements consisting of Sn (II), Ge (II) and divalent transition metals (e.g., Cu, Fe, Zn), and the heterovalent elements containing Bi(III), Sb (III), Sn (IV), Ti (IV) and double cations of Ag(I)Bi(III) are summarized. The crystal structure and bandgap for all of lead-free materials and their corresponding photovoltaic performance and stability are included. And by comparing various types of lead-free perovskite materials, we finally predict development prospects of lead-free perovskite materials in the future. 

### **2  Theoretical Bases of Lead‑Free Hybrid Perovskites** 

First-principles calculation based on density functional theory (DFT) is a modeling method for simulating the electronic structures of many-body systems from atomicscale quantum mechanics. This method has been used as an important tool for the study of lead-free perovskites [64, 65]. Electronic structures of various lead-free perovskites 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 3 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

were calculated by researchers to simulate their electron/ hole effective masses, theoretical absorption spectra, carrier mobilities, bandgaps, and other properties related to their potential solar cell applications by first-principles calculations in order to find the optimal  MAPbI3 substitute [67–70]. Generally speaking, there exist a variety of options of exchange–correlation functions in DFT calculations, which will qualitatively affect the result of DFT calculations. In the past research work, researchers often chose local density approximation (LDA) and generalized gradient approximation (GGA) functionals. Although their functions are relatively simple, the calculation results are generally more reliable. But this does not mean that there are no problems. LDA and GGA exhibit serendipitous cancellations between their exchange–correlation parts, which lead to unphysical electron self-interactions. This result further causes the local (LDA) and semilocal (GGA) functions to essentially underestimate the bandgaps of solids by 30–100% [67, 68]. To solve such problems, methods/functions including the many-body perturbation (GW) approximation [65], timedependent DFT (TDDFT) [66], PBE0, HSE03, and HSE06 hybrid functionals [64–70], and more recent delta selfconsistent-field method have been developed and applied to recent theoretical calculations of lead-free perovskites. It is worth emphasizing that in the presence of heavy atoms, spin–orbit coupling (SOC) must be included in the calculation to achieve a more accurate prediction of the electronic structure. 

So far, researchers have already had a certain understanding of the lead-free perovskite system after several years of targeted research. The core of research on lead-free perovskite materials is the replacement of Pb element. Researchers have screened out a series of elements that could replace Pb through theoretical calculations (Fig. 1). 

Filip et al. considered stability and desired bandgap as two concurrent prerequisites for suitable candidates of lead-free perovskites [66]. They used randomly displaced structures (atom positions and lattice parameters) to investigate the stability of possible lead-free perovskites. Making the stability and desired calculated bandgap as two concurrent conditions, the crystal structure retains the perovskite geometry after relaxation of the shaken configurations, and the relativistic bandgap is smaller than 2.0 eV. Finally, they identified 10 compounds out of 248 candidates for possible solar cell applications with high-throughput screening, as shown in Fig. 1. After calculation,  AMgI3 exhibited as a promising 

candidate with tunable bandgap between 0.9 and 1.7 eV (1.7 eV for  CsMgI3, 1.5 eV for  CH3NH3MgI3 and 0.9 eV for CH(NH2)2MgI3) and low electron effective mass, which is caused by exceptionally dispersive conduction bands [66]. Therefore, Filip et al. deduced that the substitution of Pb by Mg was theoretically feasible to reduce the toxicity of metal halide perovskites without losing solar cell efficiency substantially. In subsequent research work, the researchers have also proved that Cu, Ag, Bi and Sb can also replace Pb to form perovskites (Fig. 1) [62–66]. 

In addition, it is possible to use valence state replacement to select suitable non-toxic elements by using the first-principles calculation [59, 64–75]. Usually, as shown in Fig. 2, we can replace the Pb element with either homovalent elements such as Sn, Ge, and Cu, or heterovalent elements such as Sb and Bi. To maintain the charge neutrality, the heterovalent replacement can be divided into three subcategories: cation splitting, mixed valence anion and ordered vacancy. Cation splitting is to form a double perovskite structure with a chemical formula of  A2B(I)B(III)X3 by splitting Pb into a combination of monovalent and trivalent cations. Introducing mixed valence anions is the case with a single valence cation but two valence anions, whose general chemical formula is AB(Ch, X)3, where Ch represents a chalcogen element and X represents a halogen element. The perovskite can maintain electrical neutrality via forming ordered vacancies. Such substitutions can also be divided into two types: the B(III) compounds with a formula of  A3 □ B(III)X9 and the B(IV) compounds with a formula of  A2 □ B(IV)X6. Here, the sign of □ indicates vacancies. However, the formation of vacancies cuts the original 3D perovskite structure into a low dimension crystal structure, thereby reducing the electronic dimension and then affecting the optoelectronic performance [67]. 

Researchers have conducted a lot of theoretical studies on the Pb replacement with various elements, e.g., Sn, Ge, and Bi [57–62]. These theoretical studies reveal the advantages and disadvantages of different lead-free perovskite materials. In the substitution of homovalent elements, take Snbased perovskite  MASnI3 as an example. In the process of studying the optoelectronic properties of  MASnI3 using the GW + SOC method, the researchers found that compared with  MAPbI3,  MASnI3 showed a stronger _s_ - _p_ antibond coupling near the maximum value of the valence band (VBM) [68]. This phenomenon is due to the fact that the Sn 5s lone pair is shallower and more active than the Pb 6s lone pair. 

1 3 

**62** Page 4 of 36 

Nano-Micro Lett. (2021) 13:62 

|**H**|||||||||||||||||**He**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Li**|**Be**|||||||||||**B**|**C**|**N**|**O**|**F**|**Ne**|
|**Na**|**Mg**|||||||||||**Al**|**Si**|**P**|**S**|**Cl**|**Ar**|
|**K**|**Ca**|**Sc**|**Ti**|**V**|**Cr**|**Mn**|**Fe**|**Co**|**Ni**|**Cu**|**Zn**|**Ga**|**Ge**|**As**|**Se**|**Br**|**Kr**|
|**Rb**|**Sr**|**Y**|**Zr**|**Nb**|**Mo**|**Tc**|**Ru**|**Rh**|**Pd**|**Ag**|**Cd**|**In**|**Sn**|**Sb**|**Te**|**I**|**Xe**|
|**Cs**|**Ba**||**Hf**|**Ta**|**W**|**Re**|**Os**|**Ir**|**Pt**|**Au**<br>**Au**|**Hg**<br>**Hg**|**Tl**<br>**Tl**|**Pb**<br>**Pb**|**Bi**<br>**Bi**|**Po**<br>**Po**|**At**<br>**At**|**Rn**<br>**Rn**|
|**Fr**<br>**Fr**|**Ra**<br>**Ra**||**Rf**<br>**Rf**|**Db**<br>**Db**|**Sg**<br>**Sg**|**Bh**<br>**Bh**|**Hs**<br>**Hs**|**Mt**<br>**Mt**|**Ds**<br>**Ds**|**Rg**<br>**Rg**|**Cn**<br>**Cn**|**Unt**|**Fl**<br>**Fl**|**Uup**|**Lv**<br>**Lv**|**Uns**|**Uuo**|



**Fig. 1** Potential elements to substitute Pb. The orange shading on the periodic table marks the screened elements by Filip et al. that can replace Pb. The green shading of the VA group heterovalent elements and the blue shading of transition metal elements have also been calculated or proved to substitute Pb. (Color figure online) 

In addition, because of much weaker SOC, the Sn 5p orbital is shallower and less dispersive than the Pb 6p orbitals. As a result, compared to  MAPbI3, the bandgap of  MASnI3 is reduced. Unfortunately, defect calculations indicated that the high-energy Sn  5s<sup>2</sup> state makes the Sn-I bond easy to break, forming high-density Sn vacancies, resulting in an excessively high defect density (> 10<sup>17</sup> cm<sup>−3</sup> ) in the Sn-based perovskite [68]. Similar to Sn-based perovskite, theoretical calculations by Ming et al. indicated that the Ge vacancy in Ge-based perovskite is the dominant defect with shallow transition levels and rather low formation enthalpy, which yields high-density holes, particularly at Ge-poor synthesis conditions [33]. At the same time, Sun et al. pointed out that the stability of  MAGeI3 is better than that of  MASnI3 based on the calculation of the formation energy of the compound. In addition, they calculated the electronic structure and improved bandgap results through the hybrid function HSE06 and the spin–orbit coupling [36]. The calculated band structure showed that the bottom of the conduction band and the top of the valence band are very dispersed, which corresponds to low electron/hole effective masses. These results mean that the replacement of Pb in perovskite by Ge is possible. 

In the theoretical study of heterovalent replacement, using  Cs3Bi2I9 as an example, the calculations using hybrid Heyd–Scuseria–Ernzerhof (HSE) functional with SOC indicated that  Cs3Bi2I9 exhibits an indirect bandgap of 2.10 eV from the Γ point to the K point [40, 51]. Moreover, the defect calculations by Ghosh et al. indicated that most of the defects in  Cs3Bi2I9 that have low formation energies generate deep level states in the bandgap, which act as recombination 

centers [51]. Fortunately, this type of perovskite material has been calculated to own excellent thermodynamic stability. 

In addition, the chalcogen–halogen hybrid perovskite AB(Ch, X)3 was systematically studied by Sun et al. with Ab initio molecular dynamics, GGA functions and DFT-D3 van der Waals scheme [52]. According to relevant calculations, they predicted that  MABiSI2 and  MABiSeI2 have the best bandgap (1.3–1.4 eV) for solar energy collection materials. However, in later studies, Hong et al. combined DFT calculations and solid-state reactions to prove that all proposed AB(Ch, X)3 perovskites are thermodynamically unstable [34]. Although this result is disappointing, it also reminds us that stability analysis is equally important in the theoretical calculation of the discovery of new lead-free perovskites. 

Recently, the theoretical calculation has proved the 0D electronic dimension and larger bandgap of double perovskite  A2B(I)B(III)X6 with the use of alkali metal B(I) cation [28, 29]. Actually, transition metal B(III) cations with multiple oxidation states and/or partially occupying d or f orbitals are not ideal for the design of photovoltaic absorbers because they may introduce deeper defect states and localized bandedges. Finally, regarding the screening of X anions, it is known that iodides and bromides have the potential of obtaining narrower bandgaps, but they are thermodynamically unstable, while fluorides and chlorides are relatively stable but usually have larger bandgaps [75–78]. The above theoretical research work undoubtedly played a guiding role in the application of new-type lead-free perovskite materials in perovskite solar cells, resulting in a rapid development of this field. 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 5 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
Advantage:       Electronically-3D<br>Higher efficiency<br>AB(II)X3 Disadvantage:  Poor stability<br>Advantage: Stable<br>A2B(II)X4 Disadvantage:  Deep defects<br>Low absorption coefficient<br>A<br>Pb Advantage:       Stable<br>X<br>A3 B(III)2X9 Disadvantage:  Large bandgap<br>Deep defects<br>APbX3<br>Advantage:<br>Advantage:       Electronically-3D<br>Small carrier effective masses<br>High optical absorption coefficient<br>AB(Ch, X)3 Disadvantage:  Thermodynamic instability<br>Excellent defect tolerance<br>High electronic dimensionality<br>Disadvantage: Advantage: Stable<br>Long-term instability<br>Suitable bandgap<br>Toxicity<br>A2 B(IV)X6 Disadvantage: Deep defects<br>Large hole effective mass<br>Advantage: Stable<br>Rich chemistry<br>A2B(I)B(III)X6 Disadvantage:  Difficult to synthesize<br>Nonideal bandgap<br>Isovalent Elements<br>Lead Replacement by<br>Lead Replacement by Heterovalent Elements<br><!-- End of picture text -->

**Fig. 2** Schematic illustration of the approaches and consequences of potential Pb replacement 

- **3  Experimental Investigation of Various Types of Lead‑Free Hybrid Perovskites** 

##### **3.1  Lead Replacement by Isovalent Elements** 

##### **_3.1.1  Sn‑based Perovskite_** 

As a chemical element of Pb’s family (IVA group),  Sn<sup>2+</sup> possesses a homologous lone-pair s orbital and similar radius (1.35 Å) to  Pb<sup>2+</sup> (1.49 Å); therefore, Sn-based perovskites show superior optoelectronic properties similar with Pb [68, 69]. In addition, they also exhibit narrower optical bandgaps (1.2–1.4 eV) and higher carrier mobilities than the Pbbased counterparts. Moreover, due to intrinsic low toxicity of Sn, the Sn-based perovskite absorbers have become the important candidate for lead-free perovskites and gradually turned into the research hotspot in high-performance leadfree PSCs [68–70]. As a result, the Sn-based perovskites 

are more suitable for efficient single-junction solar cell applications. However,  Sn<sup>2+</sup> is unstable and easily oxidized to  Sn<sup>4+</sup> . The formation of  Sn<sup>4+</sup> leads to p-type self-doping in Sn-based perovskites, which will generate numerous Sn vacancies with large background carrier density and rapid recombination of charge carriers [14], leading to serious performance degradation and poor reproducibility of PSCs using Sn-based perovskites as absorbers [26–30]. 

##### **_3.1.1.1 3D Sn‑based Perovskite_** 

##### (1) MASn(I,Br)3 

The first  MASnIBr2 perovskite solar cell was realized with a PCE of 5.7% in 2014 [70], whose PCE was then quickly refreshed to 6.4% by Zhao in the same year [71]. In 2015, Umari et al. investigated the optoelectronic properties of MASnI3 with a more advanced many-body perturbation 

1 3 

**62** Page 6 of 36 

Nano-Micro Lett. (2021) 13:62 

theory involved with SOC [68]. They found  MASnI3 exhibited a higher charge mobility of  10<sup>2</sup> –10<sup>3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> [68, 69], a smaller direct bandgap of 1.1 eV at the Γ point and a higher absorption coefficient of 1.82 × 10<sup>4</sup> cm<sup>−1</sup> in the visible region than  MAPbI3, whose mobility, bandgap and absorption coefficient of the latter are 10–10<sup>2</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , 1.5 eV and 1.80 × 10<sup>4</sup> cm<sup>−1</sup> , respectively [56, 70]. These pretty results encouraged researchers to pay more attention to Sn-based perovskites. Interestingly, Sn-based perovskite materials exhibit n-type semiconductor characteristics when the internal  Sn<sup>2+</sup> content ratio is high, and p-type semiconductor characteristics when the  Sn<sup>4+</sup> content ratio is high. Until now plenty of efforts have been dedicated to development of high-performance and air-stable Sn-based perovskite solar cells [33, 34]. Poor homogeneity and low coverage are critical issues to be solved in Sn-based perovskites, which usually lead to direct contact between the hole-transporting layer (HTL) and the electron-transporting layer (ETL), thus generating low PCEs [70, 72]. Here, film formation methods suitable for Pb-based perovskites tend to become inefficient for Sn-based cases due to a faster crystallization rate of Snbased perovskites [73, 74]; for instance, one-step method with common solvent of _N_ , _N_ -dimethylformamide (DMF) or _γ_ -butyrolactone (GBL) hardly realized smooth Sn-based perovskite films on flat substrates. Hao et al. studied the effect of solvent on the crystallization of  MASnI3 perovskite film and found that adding dimethyl sulfoxide (DMSO) retarded the perovskite crystallization via the formation of a stable intermediate adduct  SnI2·3DMSO (Fig. 3a), the film formation speed of which was eventually controlled by the evaporation rate of DMSO. As the scanning electron microscopy (SEM) images shown in Fig. 3a–d, the morphologies of MASnI3 films with DMSO showed the highest coverage and pinhole–free property on mesoporous  TiO2 [74]. Moreover, _N_ -methyl-2-pyrrolidone (NMP) was also investigated as a solvent to further understand the effect of the intermediate phase on the tin perovskite formation process. As a result, a high-quality, pinhole-free  CH3NH3SnI3 films are achieved using NMP as solvents [73, 74]. 

Multi-step film formation method was another efficient approach to achieve high-quality Sn-based perovskite films [19, 56, 75, 76]. Schlettwein et al. reported an approach combined thermal evaporation with solution process to fabricate  MASnI3 perovskite films [56, 76]. The  SnI2 layers prepared by vapor thermal deposition could be converted to  MASnI3 by sequentially spin coating MAI solution. 

The as-acquired sizes of  MASnI3 grains were over 200 nm (Fig. 3i–n) [75]. Moreover, the film morphologies were highly dependent on MAI concentrations. With the increasing concentration of MAI, larger and more uniform  MASnI3 crystals were obtained (Fig. 3i–n). After 10-min thermal annealing, high-quality and dense films were achieved with significantly improved stability. The films remained stable after exposure to air for 90 min under both dark and light conditions. 

In addition to the above approaches, Qi et al. invented a method to improve the quality of MASn(I, Br)3-based perovskite film. They used co-evaporation and sequential evaporation methods to fabricate  MASnBr3 perovskite films with SnBr2 and MABr as precursors [77]. For co-evaporation, they used a 4:1 MABr/SnBr2 deposition ratio (0.4:0.1 Å s<sup>−1</sup> ) to simultaneously evaporate the two materials, and finally produced a perovskite film with a thickness of about 400 nm. However, solar cells based on this film only showed a low PCE of 0.35% (Fig. 4a). Such a low PCE was resulted from the oxidation of  Sn<sup>2+</sup> which restrained the generation of excitons, the carriers diffusion, and the final charge extraction. As a melioration, Qi et al. then employed sequential deposition method to decrease oxidation (Fig. 4b, c) and realized a relatively high PCE of 1.12% because oxidation can be significantly avoided by the top MABr layer [77]. The specific operation is first to deposit a 100-nm film of  SnBr2, and then to precipitate a following 400-nm film of MABr (Fig. 4d). The as-deposited sample was transferred from the vacuum system to a  N2 glovebox for post-annealing so as to convert the two-layer sample to  MASnBr3 perovskite. Therefore, sequential evaporation approach could be an efficient approach for fabricating high-quality Sn-based perovskites. 

##### (2) CsSn(I,Br)3 

In 1974, Fisher et al. first synthesized and characterized allinorganic  CsSnX3 compounds [78]. It was not until 2012, Shum et al. reported the application of  CsSnI3 in perovskite solar cell [79]. A black thin film of  CsSnI3 with a bandgap of 1.3 eV was fabricated by alternate depositions of SnCl2 and CsI on a glass substrate followed by a thermal annealing process. The  CsSnI3 perovskite solar cell exhibited a PCE of 0.9%. Then in 2014, Mathews et al. reported a CsSnI3 PSC incorporated with  SnF2 to reduce Sn vacancies and obtain a high photocurrent output [71]. The best PCE of 2.02% as well as a short-circuit current density ( _J_ sc) of 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 7 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 



**Fig. 3** SEM images for  MASnI3 layer on mesoporous  TiO2 layer by using **a** DMF, **b** NMP, **c** GBL, and **d** DMSO solvents. Reproduced with permission from Ref. [74]. SEM images for  FASnI3 films obtained from different antisolvent processes: **e** No dripping, **f** CB, **g** TL and **h** DE. Reproduced with permission from Ref. [96]. SEM images of **i** vapor deposited 100 nm  SnI2, non-annealing  MASnI3 films with **j** 6, **k** 10, **l** 20 and **m** 40 mg mL<sup>−1</sup> MAI precursor solution spin coated and **n** MASnI3 films with 20 mg mL<sup>−1</sup> MAI precursor solution spin coated followed by annealing at 80 °C for 10 min. Reproduced with permission from Ref. [75] 

22.70 mA cm<sup>−2</sup> , an open-circuit voltage ( _V_ oc) of 0.24 V and a fill factor (FF) of 0.37 was achieved with 20 mol %  SnF2 (Fig. 4e). Moreover, the devices displayed less hysteresis than those counterparts without  SnF2 (Fig. 4f). The incident photon-to-current conversion efficiency (IPCE) data clearly indicated that the onset was extended to 950 nm, which corresponded to 1.3 eV of bandgap (Fig. 4g). In 2015, a detailed study on  CsSnX3 was done by Sabba et al. [80]. Their studies revealed that the  CsSnX3 materials were semiconductors with a strong tendency to self-doping because the oxidation of  Sn<sup>2+</sup> to  Sn<sup>4+</sup> would generate hole carriers. 

It is worth mentioning that  CsSnI3 as a 3D p-type orthorhombic perovskite possesses a bandgap of 1.3 eV [81], a low exciton binding energy of 18 × 10<sup>−3</sup> eV [82], and a high optical absorption coefficient of  10<sup>4</sup> cm<sup>−1</sup> (comparable to  MAPbI3) [83]. Therefore, it has the potential to be as 

a light absorber for lead-free PSCs. The biggest obstacle that hinders rapid development of  CsSnI3 perovskite solar cell is the instability of  CsSnI3 and the black phase  CsSnI3 could be easily converted to yellow phase  CsSnI3 in atmosphere due to its oxidization [69, 84]. It was reported that the excessive  SnI2 contributed to the improvements of efficiency and stability of  CsSnI3-based PSCs [85]. The  CsSnI3 films with low defect density and high surface coverage were prepared in a Sn-rich environment or at high temperature. The PCE of the device with a configuration of ITO/CuI/CsSnI3/ fullerene/bathocuproine (BCP)/Al increased from 0.75 to 1.5% in the condition of 10 mol % excessive  SnI2, and _V_ oc and FF remained good within 20 min under light stability. Although _J_ sc quickly deteriorated by 10% in the first 50 min, _J_ sc’s decline rate slowed significantly. The excess of  SnI2 located at the  CsSnI3/CuI interface formed an interfacial 

1 3 

**62** Page 8 of 36 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
(a) 2.5 MASnBr3 spiro-OMeTAD (b) Sn 3 d Sn1 = 486.7 eV (c) Br 3 d Br1 = 68.6 eV<br>C60<br>2.0 Sn2 = 487.5 eV<br>P3HT Br2 = 69.3 eVBr3 = 68.1 eV<br>1.5 60 min<br>1.0 60 min<br>0.5 As-received<br>0.0 As-received<br>−0.5<br>0.0 0.2 0.4 0.6 495 490 485 71 70 69 68 67<br>Voltage (V) Binding energy (eV) Binding energy (eV)<br>(d) HTL<br>MABr (400 nm)<br>Annealing<br>MASnBr3 (200-300 nm)<br>SnBr2 (100 nm)<br>TiO2 (c.l.) TiO2 (c.l.)<br>HTL spin casting<br>FTO Glass FTO Glass<br>(e) 25 CsSnI3+5 mol% SnF2 (f) 25 CsSnI3 (g) 80 CsSnI3 20<br>20 CsSnICsSnI33+10 mol% SnF+20 mol% SnF22 20 70<br>CsSnI3+40 mol% SnF2 60 15<br>15 15 50<br>40 10<br>10 10<br>30<br>5 5 20 5<br>10<br>0 0 0 0<br>0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.0 0.1 0.2 400 500 600 700 800 900 1000<br>Vtloage( V) Vtloage( V) Wavelength( nm)<br>Intensity (a.u.) Intensity (a.u.)<br>−2Capacity density (mA cm)<br>IPCE (%)<br>−2current (mA cm)<br>Integrated solar photo<br>−2Current density (mA cm) −2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 4  a** _J_ – _V_ curves of co-evaporated  MASnBr3 films with different hole transport materials. **b** Sn 3d and **c** Br 3d XPS results of  MASnBr3 films as-deposited and after 1 h stored in air. **d** Fabrication of sequential method for  MASnBr3 films. Reproduced with permission from Ref. [77]. **e** _J_ – _V_ curves of  CsSnI3-based PSCs incorporated with different ratios of  SnF2. **f** _J_ – _V_ curves of 20 mol %  SnF2-doped  CsSnI3 devices showing no hysteresis. **g** IPCE spectrum for 20 mol %  SnF2-doped  CsSnI3 devices. Reproduced with permission from Ref. [71] 

dipole which acted as a hole-transporting layer from  CsSnI3 to CuI owing to a favorable vacuum level shift. 

After that, some additives have been introduced into precursors to further improve film quality of CsSn(I,Br)3 perovskites, which have significantly promoted the performances of CsSn(I,Br)3 perovskite solar cells [86–90]. Marshall et al. systematically investigated  CsSnI3 perovskite films with different Sn halide additives, such as  SnF2,  SnCl2, SnI2, and  SnBr2 [90]. The films adding  SnCl2 additive had the highest pinhole density and the HTL-free devices with 10 mol %  SnCl2 achieved the highest FF and PCE. Such results were mainly attributed to the formation of ultrathin hole-selective layer of  SnCl2 at the ITO/CsSnI3 interface. 

On this basis, doping Br into  CsSnI3 was also proposed. It is noteworthy that the Br-doped  CsSnI3−xBrx perovskites showed a much higher FF compared to  CsSnI3 due to the appearance of the negligible overlayer of  CsSnI3−xBrx [80]. The crystal structure was thus changed from orthorhombic  (CsSnI3) to cubic  (CsSnBr3) with the increase in Br component. The onset of optical bandgap edge was also altered from 1.27 eV  (CsSnI3) to 1.37, 1.65, and 1.75 eV for  CsSnI2Br,  CsSnIBr2 and  CsSnBr3, respectively (Fig. 5). Notably,  CsSnI2Br,  CsSnIBr2 and  CsSnBr3 were suitable for solar cell applications due to their excellent thermal and air stabilities (Table 1) [80]. 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 9 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

##### (3) FASn(I,Br)3 

Compared to  MA<sup>+</sup> and  Cs<sup>+</sup> ,  FA<sup>+</sup> is another extensively investigated organic cation with a relatively larger ionic radius.  FASnI3 is a 3D perovskite with a bandgap of 1.41 eV, which is slightly wider than  MASnI3 (1.30 eV) and CsSnI3 (1.30 eV) [37] but narrower than Pb-based perovskites (~ 1.5 eV) [69]. Moreover, the bandgaps of  FASnX3 can be tuned with different halides, e.g., 1.68 and 2.4 eV for  FASnI2Br and  FASnBr3 [78, 91]. The  FASnI3 material exhibits a threshold charge-carrier density of 8 × 10<sup>17</sup> cm<sup>−3</sup> and a charge-carrier mobility of 22 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> [92]. In addition,  FASnI3 has a similar thermal stability but a lower conductivity with respect to  MASnI3 [93]. 

Synthesis and characterization of cubic  FASnI3 perovskite were first investigated in 1997 [94]. Until now, most highperformance Sn-based PSCs are mainly based on  FASnI3 materials [95–97] because of their better air stability. This is because the trap density of  FASnI3 (n-type semiconductor) is as low as ~ 10<sup>11</sup> cm<sup>−3</sup> , preventing water and oxygen from entering into the  FASnI3 crystal, which has been experimentally proved by Wang et al. [98]. Therefore, the air stability of the  FASnI3 crystal is higher than  MASnI3 one. 

After the first successful incorporation of  SnF2 into CsSnI3, Mathews group further verified similar effect of  SnF2 additive on performance enhancements of FASnI3-based solar cells.  SnF2 additive played a similar role in preventing oxidation of  Sn<sup>2+</sup> to  Sn<sup>4+</sup> and reducing background carrier density, and the  FASnI3 PSC with 20% SnF2 finally achieved a PCE of 2.1% [99]. 

However, it has been proven that a higher amount of  SnF2 induced severe phase separation in the  FASnI3 perovskites 

films and thus led to performance degradation of solar cells. To solve this issue, Seok et al. introduced pyrazine into DMF/DMSO mixed precursor solution to fabricate highquality  FASnI3 films with high coverage and smooth surface [87]. Since the N atoms in pyrazine can accept lone pairs electrons, pyrazine doping can remarkably restrict the phase separation and effectively reduce Sn vacancies [84], with which a dense, smooth, and pinhole-free  FASnI3 perovskite layer and a pretty good PCE of 4.8% were achieved with high reproducibility. Furthermore, the encapsulated solar cells exhibited good long-term stability, remaining 98% of the initial PCE for over 10-day storage under ambient condition. It is worth mentioning that, in addition to  SnF2 and pyrazine, hydrazine vapor, hydrazine iodide [69], and Sn powder [100] have also been used as antioxidants in Sn-based perovskites in later work. The application of these antioxidants has a similar effect with  SnF2, that is, to improve the stability and efficiency of Sn-based PSCs by reducing Sn vacancies and background carriers in Sn perovskites. 

In addition, some other special materials have also been served as additives to improve the film quality of perovskites and hinder the oxidation of  Sn<sup>2+</sup> . For instance, Chen et al. used the bidentate ligand 8-hydroxyquinoline (8HQ) as an additive in the perovskite [101]. The N and O atoms in the 8HQ can simultaneously coordinate with  Sn<sup>2+</sup> and greatly inhibit the oxidation of  Sn<sup>2+</sup> . Meantime, the formation of complex also improved the quality of  FASnI3 film and reduced defect state-induced non-radiative recombination. Recently, ammonium hypophosphite was introduced into the  FASnI3 perovskite precursor by Yan et al. to suppress the oxidation of  Sn<sup>2+</sup> and assist the growth of perovskite grains, resulting in improved perovskite film 



<!-- Start of picture text -->
−3.39  −3.28 −3.24 −3.19 −3.13<br>−3.50 −3.70 −3.90 −3.50 −4.17  −3.96 −3.78<br>−4.50 −4.50  −4.20 −4.50<br>1.30 1.37 1.65 1.75<br>−4.58 −4.61 −4.84 −4.88 −5.26 −5.20 −5.20 −5.18 −4.99 −5.40<br>1.30 1.56 1.75 2.15 PPN PTAA PEDOT PT TPE NiO<br>2.00 2.00 1.40 −5.47 −5.52 −5.53 −5.54<br>−5.70 −5.90 −5.90<br>1.70<br>−6.20<br>3.50 2.80 3.10 3.50<br>−7.00 −7.30 −7.30 −7.00<br>3CsSnBr<br>3CsSnI 12CsSnIBr 12CsSnIBr<br>3MASnBr<br>ICBA PCBM 3MASnI 12MASnIBr<br>3FASnI 21MASnIBr<br>BCP 60C 2TiO ZnS<br>2SnO<br><!-- End of picture text -->

**Fig. 5** Energy diagram of common Sn-based perovskites, ETLs and HTLs. Unit: eV 

1 3 

**62** Page 10 of 36 

Nano-Micro Lett. (2021) 13:62 

**Table 1** Photovoltaic parameters of PSCs based on various Sn-based perovskite absorbers. In the table, c-TiO2 and m-TiO2 represent compact and mesoporous  TiO2 layer, respectively 

|Preparation process|Absorber|Device architecture|_V_oc(V)|_J_sc(mA cm|<sup>−2</sup>) FF (%)|PCE (%|) References|
|---|---|---|---|---|---|---|---|
|One-step|MASnI3|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.68|16.30|48|5.23|[70]|
|One-step|MASnI2Br|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.77|14.38|50|5.48|[70]|
|One-step|MASnIBr2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.82|12.30|57|5.73|[70]|
|One-step|MASnBr3|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.88|8.26|59|4.27|[70]|
|One-step|MASnI3|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.716|15.18|50.07|5.44|[135]|
|One-step|MASnI3|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.88|16.8|42|6.4|[82]|
|One-step|MASnI3|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.79|13.40|52|5.49|[124]|
|One-step|CsSnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.201|27.67|29|1.66|[91]|
|One-step|CsSnI2Br + 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.289|15.06|38|1.67|[91]|
|One-step|CsSnIBr2+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.311|11.57|43|1.56|[91]|
|One-step|CsSnI2.9Br0.1+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.222|24.16|33|1.76|[91]|
|One-step|FASnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.238|24.45|36|2.10|[99]|
|One-step|CsSnBr3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.42|9.1|57|2.17|[89]|
|One-step|MASnIBr2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.69|15.9|49|5.36|[134]|
|One-step|MASnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.25|26.1|30|1.94|[137]|
|One-step|{en}FASnI3+ 15%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.48|22.54|65.96|7.14|[81]|
|One-step|{en}FASnI3+ 15%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.46|22.54|69.74|7.23|[138]|
|One-step|{PN}FASnI3+ 15%  SnF2|c-TiO2/m-TiO2/perovskite/<br>TPE/Au|0.44|22.15|60.67|5.85|[109]|
|One-step|{TN}FASnI3+ 15%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.40|22.72|61.04|5.53|[109]|
|One-step|{en}MASnI3+ 15%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.43|24.28|63.72|6.63|[108]|
|One-step|MASnBr3|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.307|1.22|36.8|0.14|[139]|
|One-step|CsSnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/_m_-<br>MTDATA/Au|0.24|22.70|37|2.02|[88]|
|One-step|MASnCl3|c-TiO2/perovskite/CuSCN/Ag|0.576|12.89|55|3.41|[140]|
|One-step|CsSnI3|NiO/perovskite/PCBM/Al|0.52|10.21|62.5|3.31|[141]|
|One-step|CsSnI3|c-TiO2/perovskite/spiro-MeO-<br>TAD/Au|0.48|8.11|19.8|0.77|[141]|
|One-step|HEA0.4FA0.6SnI3|c-TiO2/m-TiO2/perovskite/<br>Al2O3/C|0.37|18.52|56.2|3.9|[118]|
|One-step|GA0.2FA0.78SnI3+ 1%  EDAI2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.61|21.2|72|9.6|[119]|



© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 11 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

**Table 1** (continued) 

|Preparation process|Absorber|Device architecture|_V_oc(V)|_J_sc(mA cm<sup>−</sup>|<sup>2</sup>) FF (%)|PCE (%|) References|
|---|---|---|---|---|---|---|---|
|One-step|FASnI3|PEDOT:PSS/perovskite/<br>PCBM/BCP/Ag|0.49|22.24|65.19|7.15|[101]|
|One-step|FASnI3|SnO2/perovskite/PCBM/BCP/<br>Ag|0.55|19.39|68.82|7.34|[102]|
|One-step|FASnI3|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.63|21.6|74.7|10.17|[103]|
|One-step|FASnI3|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.628|22.25|74.2|10.37|[104]|
|One-step|PEAxFA1−xSnI3+ NH4SCN|PEDOT:PSS/perovskite/<br>ICBA/BCP/Ag|0.94|17.4|75|12.4|[135]|
|One-step|FASnI3+ 5% PHCl|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.76|23.5|64|11.4|[136]|
|Hot-casting|BA2MA3Sn4I13+ 100%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.229|24.1|45.7|2.53|[120]|
|Hot-casting|MASnI3+ 20%  SnF2/hydrazine|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.378|19.92|51.73|3.89|[142]|
|Hot-casting|CsSnI3+ 20%  SnF2/hydrazine|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.170|30.75|34.88|1.83|[142]|
|Hot-casting|CsSnBr3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.367|13.96|59.36|3.04|[142]|
|Hot-casting|MASnI3|PEDOT/perovskite/PCBM/Al|0.595|17.8|29.8|3.2|[143]|
|Vapor-assisted|MASnI3|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.273|17.36|39.1|1.86|[143]|
|Vapor-assisted|MASnI3−xBrx|c-TiO2/m-TiO2/perovskite/<br>PTAA/Au|0.452|5.02|48.3|1.10|[139]|
|Solvent-engineering|FASnI3+ 10%  SnF2+ pyrazine|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.32|23.7|63|4.8|[71]|
|Solvent-engineering|FASnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.38|23.09|60.01|5.27|[97]|
|Solvent-engineering|MASnI3+ 20%  SnF2|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.232|26.0|38.6|2.33|[134]|
|Solvent-engineering|FASnI3+ 10%  SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.47|22.07|60.67|6.22|[96]|
|Solvent-engineering|FASnI3+ 20% PEAI + 10%<br>SnF2|NiO/perovskite/PCBM/Al|0.59|14.44|69|5.94|[127]|
|Solvent-engineering|(FA)0.75(MA)0.25SnI3+ 10%<br>SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.61|21.2|62.7|8.12|[80]|
|Solvent-engineering|(FA)0.5(MA)0.5SnI3+ 10%<br>SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.53|21.3|52.4|5.92|[80]|
|Solvent-engineering|(FA)0.25(MA)0.75SnI3+ 10%<br>SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.48|20.7|45.2|4.49|[80]|
|Solvent-engineering|FASnI3+ 10%  SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.48|21.3|64.6|6.60|[80]|
|Solvent-engineering|MASnI3+ 10%  SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.46|21.4|42.7|4.29|[80]|
|Solvent-engineering|0.92FASnI3+ 0.08PEAI + 10%<br>SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.525|24.1|71|9.0|[144]|
|Solvent-engineering|FASnI2Br|PEDOT:PSS/perovskite/C60/<br>Ca/Al|0.467|6.82|54|1.72|[89]|
|Solvent-engineering|MA0.9Cs0.1SnI3|PEDOT:PSS/perovskite/<br>PCBM/Bis-C60/Ag|0.20|4.53|36.4|0.33|[114]|
|Solvent-engineering|FA0.8Cs0.2SnI3|PEDOT:PSS/perovskite/<br>PCBM/Bis-C60/Ag|0.24|16.05|35.8|1.38|[114]|



1 3 

**62** Page 12 of 36 

Nano-Micro Lett. (2021) 13:62 

**Table 1** (continued) 

|Preparation process|Absorber|Device architecture|_V_oc(V)|_J_sc(mA cm<sup>−2</sup>|) FF (%)|PCE (%|) References|
|---|---|---|---|---|---|---|---|
|Solvent-engineering|FASnI3|PEDOT:PSS/perovskite/<br>PCBM/Bis-C60/Ag|0.04|11.73|23.4|0.11|[114]|
|Solvent-engineering|PEA2SnI4|NiOx/perovskite/PCBM/BCP/<br>Ag|0.61|22.0|70.1|9.41|[123]|
|Solvent-engineering|(BA0.5PEA0.5)2FA3Sn4I13|PEDOT:PSS/perovskite/C60/<br>LiF/Al|0.60|21.82|66.73|8.82|[126]|
|Solvent-engineering|AVA2FAn−1SnnI3n+1|PEDOT:PSS/perovskite/<br>PCBM/BCP/Ag|0.61|21.0|68|8.71|[128]|
|Solvent-engineering|(4AMP)(FA)3Sn4I13|c-TiO2/ZrO2/perovskite/C|0.64|14.9|44.3|4.42|[131]|
|Quantum rods|CsSnI3|c-TiO2/perovskite/spiro-MeO-<br>TAD/Au|0.86|23.2|65|12.96|[145]|
|Quantum rods|CsSnBr3|c-TiO2/perovskite/spiro-MeO-<br>TAD/Au|0.85|21.23|58|10.46|[145]|
|Quantum rods|CsSnCl3|c-TiO2/perovskite/spiro-MeO-<br>TAD/Au|0.87|19.82|56|9.66|[145]|
|Sequential deposition|FASnI3+ 10%  SnF2+ TMA|SnO2/C60/perovskite/spiro-<br>MeOTAD/Ag|0.31|21.65|64.7|4.34|[83]|
|Sequential deposition|FASnI3+ 10%  SnF2+ TMA|PEDOT:PSS/perovskite/C60/<br>Bis-C60/Ag|0.47|22.45|0.68|7.09|[83]|
|Sequential deposition|FASnI3|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.33|17.78|67.9|3.98|[146]|
|Thermal evaporation|MASnBr3|c-TiO2/perovskite/P3HT/Au|0.498|4.27|49.1|1.12|[77]|
|Thermal evaporation|CsSnBr3+ 2.5%  SnF2|MoO3/perovskite/C60/BCP/Ag|0.40|2.4|55|0.55|[147]|
|Thermal evaporation|(PEA, FA)  SnI3|LiF/PEDOT:PSS/perovskite/<br>C60/BCP/Ag|0.47|20.07|74|6.98|[148]|
|Thermal evaporation|MASnI3|PEDOT:PSS/TPD/perovskite/<br>C60/BCP/Ag|0.377|12.1|36.6|1.7|[149]|
|Thermal evaporation|CsSnI3|ITO/perovskite/Au/Ti|0.42|4.80|22|0.88|[87]|
|Direct dropping|MASnIBr1.8Cl0.2+ 20%  SnF2|c-TiO2/m-TiO2/m-Al2O3/<br>perovskite/C|0.38|13.99|57.3|3.11|[150]|
|Hot-dropping|CsSnIBr2+ 60%  SnF2+ H3PO2|c-TiO2/m-TiO2/m-Al2O3/<br>perovskite/C|0.31|17.4|56|3.2|[151]|
|Solvent-engineering|FASnI3+ PEABr + 10%  SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Cu|0.45|24.87|63|7.05|[152]|
|Solvent-engineering|FASnI3+ 2.5%  N2H5Cl + 10%<br>SnF2|PEDOT:PSS/perovskite/<br>PCBM/BCP/Ag|0.455|17.64|67.3|5.40|[153]|
|Solvent-engineering|FASnI3+ 12%  SnF2|PEDOT:PSS(PEG)/perovskite/<br>PCBM/BCP/Ag|0.455|17.64|67.3|5.40|[153]|
|Solvent-engineering|MASnI3+ 20%  SnF2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.45|11.82|40|2.14|[154]|
|Solvent-engineering|FASnI3+ 1%  EDAI2|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.583|21.3|0.72|8.9|[155]|
|Solvent-engineering|FASnI3|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.638|21.95|0.725|10.16|[156]|



quality and reduced defect density, and the final device showed a PCE of 7.3% [102]. More importantly, about 50% of their original PCE was maintained after the 500 h storage in air. Soon after, Han et al. employed a π-conjugated Lewis base molecule 2-cyano-3-[5-[4-(diphenylamino) 

phenyl]-2-thienyl]-propenoic acid (CDTA) with high electron density to systematically control the crystallization rate of  FASnI3 perovskite [103]. They obtained a compact and uniform perovskite film with greatly increased carrier lifetime via forming stable intermediate phase with 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 13 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

the Sn-I frameworks. Meanwhile, the introduction of the π-conjugated system also retarded the permeation of moisture into perovskite crystal, which significantly suppressed the film degradation in air [103]. The perovskite solar cell prepared on this basis achieved a PCE of 10.1% and maintained over 90% of its initial value after 1000 h light soaking in air. Another work is Han et al. introduced a liquid formic acid as a reducing solvent in the  FASnI3 perovskite precursor solution to product the  FASnI3 perovskite film with high crystallinity, low  Sn<sup>4+</sup> content, reduced background doping, and low electronic trap density. As a result, the lead-free tin halide PSC achieved 10.37% efficiency [104]. 

In addition to additives, the use of antisolvents also greatly promoted the film quality of  FASnI3 perovskites. Typical antisolvents include chlorobenzene (CB) [105], toluene (TL) [106], diethyl ether (DE) [107], and other aprotic nonpolar solvents. Here, it is noteworthy that the antisolvents should be miscible with DMSO solvent, but insoluble for perovskites. Liao et al. used such a solvent-engineering method to fabricate  FASnI3 perovskites and tuned the film morphologies with different antisolvents (Fig. 3e–h) [96]. They obtained high-quality, uniform and fully covered FASnI3 perovskite thin films. Among these antisolvents, dripping with diethyl ether onto  FASnI3 produced the best FASnI3 thin films with high uniformity and full coverage. With improved film quality and proper structure design, the champion  FASnI3 device achieved a PCE of 6.22% with _V_ oc of 0.465 V, _J_ sc of 22.07 mA cm<sup>−2</sup> , and FF of 60.67%. Furthermore, such device exhibited a weak _J_ – _V_ hysteresis behavior [96]. 

Recently, a new type of “hollow” perovskites has been prepared. Chen et al. reported a successful incorporation of medium size cations ethylenediammonium (en) into the 3D  FASnI3 perovskite structure and they denoted it as {en} FASnI3 [91, 108]. Typically, change of A-site cation only results in a small bandgap alteration due to structural distortion, but for {en}FASnI3, its bandgap can be tuned in a wide range of 1.3–1.9 eV via simply increasing the en amount [108]. Actually, adding en could improve film morphology, reduce background carrier density and increase carrier lifetime, all of which contribute to the resultant PCE and stability of Sn-based solar cells [70]. Based on this viewpoint, the {en}FASnI3 device achieved a 7.14% PCE with higher _V_ oc and FF. Similar results were also observed in MASnI3 and  CsSnI3 solar cells [108]. Recently, Kanatzidis et al. also reported two other diammonium cations of 

propylenediammonium (PN) and trimethylenediammonium (TN) forming new hollow perovskites of {TN}FASnI3 and {PN}FASnI3 [109]. TN and PN with slightly larger size than en also improved device performances. The  FASnI3 absorbers mixed with 10% PN and 10% TN achieved enhanced PCEs of 5.85% and 5.53%, respectively [109]. 

##### (4) Mixed A Cations Sn-Based Perovskites 

Metal halide perovskites with mixed cations have been widely used in Pb-based PSCs, part of which achieved record efficiencies and good stability due to cation mixturetriggered film morphology improvement and water and oxygen resistance increase as well as inhibition of carrier recombination within devices [20, 22, 110–113]. In this case, it is also a powerful strategy to develop highly efficient, stable Sn-based PSCs with mixed A cations perovskites. Liu et al. first synthesized Sn-based perovskites with mixed cations of MA and Cs and applied  MA0.9Cs0.1SnI3 to PSCs [114]. The PCE was low (0.33%) since the device was fabricated without any optimization. Later, Zhao et al. reported 3D Sn-based perovskites with mixed cations of MA and FA (Fig. 6d). Notably, the optical property exhibited an obvious alteration with the ratio of mixed cations (Fig. 6a–c, e–f). Among them, (FA)0.75(MA)0.25SnI3 perovskite solar cell with 10 mol %  SnF2 generated a maximum PCE of 8.12% and an average value of 7.48% ± 0.52% [88]. 

**_3.1.1.2 Low‑Dimensional Sn‑Based Perovskite_** As an alternative, reduced-dimensional (quasi-2D) perovskites have been widely investigated recently since they have showed superior enduring stability outperforming their 3D counterparts [115–117]. The existence of insulating organic spacer cations, e.g., PN [89], 2-hydroxyethylammonium (HEA) [118], guanidinium (GA) [119], butylammonium (BA) [120], polyethylenimine cation [121], cyclopropylammonium [122], and phenylethylammonium (PEA) on quasi2D perovskites, restrains self-doping effect and suppresses ion migration [115, 121], thus contributing to ameliorated moisture, oxygen, and thermal stability. However, the emergence of these insulating long-chain organic cations also leads to the anisotropy characteristics of the crystal, which significantly reduces device performance. That means the resulting quasi-2D PSCs with enhanced stability are at the expense of declining performance due to blocked charge transportation of these insulating organic spacers along vertical direction [95, 120, 123]. The highly vertically oriented perovskite films are considered as a prerequisite to address 

1 3 

**62** Page 14 of 36 

Nano-Micro Lett. (2021) 13:62 

the low-efficiency issue in quasi-2D PSCs since in this situation these inorganic slabs are aligned in perpendicular to the substrates [124, 125]. Various methods of forming highly vertically oriented films have been developed in Pb-based quasi-2D perovskites, but unfortunately, most of which are unsuitable for Sn-based counterparts due to different properties between Pb- and Sn-based perovskites [123, 124]. In the published cases of Sn-based PSCs, Kanatzidis et al. reported 2D Ruddlesden–Popper (RP) perovskites (CH3(CH2)3NH3)2(CH3NH3)n−1SnnI3n+1 with perpendicular orientation by using _N,N_ -dimethylformamide as solvent [120]. For _n_ = 4, perpendicularly oriented 2D perovskites were fabricated whether the substrates were heated or not, while for _n_ = 3, only hot substrates of 120 centigrade were able to intensify perpendicular growth of 2D films. Huang et al. introduced mixed _n_ -butylamine and PEA organic cations into 2D RP Sn perovskite to control the crystallization process and formed highly vertically oriented [(BA 0.5<sup>PEA</sup> 0.5<sup>)</sup> 2<sup>FA</sup> 3<sup>Sn</sup> 4<sup>I</sup> 13<sup>] 2D RP perovskites [126]. Benefitting</sup> from it, the PCE of the 2D Sn-based PSC was improved to 8.82%. Liao et al. reported low-dimensional Sn-based perovskites by using FA and PEA mixed cations (Fig. 7a), and they adjusted the orientation of the perovskite domains by altering the PEA/FA ratios [127]. A highly oriented per- 

ovskite film perpendicular to the substrate was realized by adding 20% PEA. As a result, the  FASnI3 perovskite solar cells with 20% PEA achieved a maximum PCE of 5.94% with enhanced stability [127]. Recently, Yuan et al. used the bifunctional cation 5-ammoniumvaleric acid (5-AVA) as the spacer to fabricate  AVA2FA _n_ −1Sn _n_ I3 _n_ +1 ( 〈 _n_ 〉 = 5) quasi-2D Sn-based perovskite, and by introducing appropriate amount of ammonium chloride  (NH4Cl) additive, they obtained highly vertically oriented quasi-2D perovskite films which eventually enhanced the transportation of charge carriers between electrodes [128]. Actually, the Cl doping can also improve the electrical conductivity of perovskite film, as demonstrated by Li et al. [129]. 

In recent work, Padture et al. first reported the synthesis and photovoltaic performance of low-dimensional Dion–Jacobson Sn(II)-based halide perovskites (4AMP) (FA)n−1SnnI3n+1, but the PSC based on this perovskite only achieved an efficiency of 2.15% [130]. Compared with the Sn-based perovskite of the RP layered with a van der Waals gap between the adjacent unit cells, the unique structure of DJ layered Sn-based perovskites allows the inorganic stacks to be more uniform and closer, rendering better alignment and less displacement of perovskites [131]. Moreover, the 



<!-- Start of picture text -->
(a) (b) 2.5 (c)<br>(FA)x(MA)1-xSnI3 (FA)x(MA)1-xSnI3 1.0 (FA)x(MA)1-xSnI3<br>x = 1.00 2.0 x = 0.00 0.8 x = 0.00<br>x = 0.75 x = 0.25 x = 0.25<br>1.5 x = 0.50 0.6 x = 0.50<br>x = 0.50 x = 0.75 x = 0.75<br>1.0 x = 1.00 0.4 x = 1.00<br>x = 0.25<br>0.5 0.2<br>x = 0.00<br>0.0 0.0<br>13.5 14.0 14.5 27.5 28.0 28.5 29.0 400 600 800 1000 800 900 1000 1100 1200<br>2θ (°) Wavelength (nm) Wavelength (nm)<br>(d) c (e) (f) FASnI3 1:0.5 1:5<br>b a<br>1:1<br>1:0.5<br>1:0.25 FASnI3<br>1:0.1<br>Sn 1:0.1<br>I 1:0.25<br>NC FASnI3 1:0.51:1<br>H<br>10 20 30 40 50 60 400 600 800 1000<br>(FA)x(MA)1-xSnI3<br>2θ (°) Wavelength (nm)<br>Absorption<br>Normalized intensity Normalized intensity<br>Intensity (a.u.)<br>Absorbance (a.u.)<br><!-- End of picture text -->

**Fig. 6  a** XRD patterns of one-step deposited (FA)x(MA)1−xSnI3 (x = 0.00, 0.25, 0.50, 0.75, and 1.00) films on ITO/poly(3,4ethylenedioxythiophene)-poly(styrenesulfonate) (PEDOT:PSS) substrates. **b** Absorption spectra and **c** normalized PL spectra of the different perovskite films on quartz substrates. **d** A 2 × 2 × 2 supercell of (FA)2Sn2I6 depicting a model of the hollow perovskite with two  SnI2 vacancies [(FA)16Sn14I44]. **e** XRD patterns and **f** optical absorption of the {en}FASnI3 perovskite crystals with various molar ratios of FA to {en}. Reproduced with permission from Ref. [88] 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 15 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

shortened interlayer distance might reduce the barrier of charge transfer, which will benefit the charge transport of derived quasi-2D perovskite devices. It is particularly worth mentioning that the growth of the DJ phase perovskite layer can be controlled by selecting different diammonium organic cations as the intermediate spacer layer so that the growth direction is perpendicular to the substrate, which facilitates the transfer and collection of charge through the electrode [124, 132]. These characteristics will make DJ Sn-based perovskites to be a promising class of materials for photovoltaic applications. 

Kanatzidis et al. reported some hexagonal polytypes and low-dimensional structures of hybrid Sn iodide perovskites, which employed various small cations such as trimethylammonium  (TMA<sup>+</sup> ), imidazolium  (IM<sup>+</sup> ), guanidinium  (GA<sup>+</sup> ), ethylammonium  (EA<sup>+</sup> ), acetamidinium (ACA<sup>+</sup> ), and isopropylamine  (IPA<sup>+</sup> ) (Fig. 7b–e) [133]. Due to the moderate size of these cations, a variety of new  ASnX3 polytypes were formed by combinations of corner-sharing octahedra (perovskite) and face-sharing octahedra (perovskitoid), which have the potential for lead-free solar cells [134]. Finally, we summarize the current research results of Sn-based perovskite solar cells in Table 1 [70, 71, 80–83, 87–89, 96, 97, 101–104, 118–120, 124, 133–156]. 

To further improve the efficiency of tin-based perovskite, device structure manipulation was also conducted by Ning et al., who used indene-C60 bisadduct as the ETL to fabricate solar cells based on  PEAxFA1−xSnI3 perovskite, yielding a high efficiency of 12.4% [135]. In addition to efficiency, the stability issue of tin-based PSCs also restrained their applications. Mathews et al. encapsulated  FASnI3 PSCs and realized more stable PSCs with over 80% of its initial PCE being maintained after 1-month storage in a  N2 environment, which is much better than the unencapsulated counterparts that fully decomposed within two weeks [71]. In addition, Kanatzidis et al. studied the encapsulated 2D (BA)2(MA)3Sn4I13 PSCs and their test results showed that the encapsulated device retained more than 90% of its initial performance after 1 month and dropped only to ~ 50% after 4 months in a glove box full of  N2 [120]. This encouraging stability is closely related to the intrinsically stable 2D perovskite structure as well as the encapsulation that sufficiently blocked the invasion of water and oxygen. Other researchers have also proposed in their respective work that it is possible to package Sn-based solar cells to improve stability [71, 103, 104, 120, 136, 155, 156]. 

In summary, there is still a large room for efficiency and stability enhancements of Sn-based perovskites. Future works should focus on optimization of perovskite composition and selection of effective additives to fabricate stable and high-quality perovskite film with less  Sn<sup>2+</sup> oxidation. Besides, reasonable choice of hole/electron transport materials is very critical for enhancing device performance and stability of the Sn-based PSCs. Protecting of solar cells with industrial encapsulation techniques will also be a viable approach to improve the long-term stability of the Sn-based PSCs and push it to the commercial market. 

##### **_3.1.2  Ge‑based Perovskite_** 

Previous reports have shown that metal ions owning external _ns_<sup>2</sup> electronic structure with low ionization energy can enhance light absorption efficiency and carrier diffusion length of  ABX3 structure.  Ge<sup>2+</sup> has similar outer  ns<sup>2</sup> electronic structure  (4s<sup>2</sup> ) to  Sn<sup>2+</sup> (5s<sup>2</sup> ) and  Pb<sup>2+</sup> (6s<sup>2</sup> ), but smaller ionic radii than  Sn<sup>2+</sup> and  Pb<sup>2+</sup> [64]. Ge-based perovskites containing  MAGeI3,  CsGeI3 and  FAGeI3 have also been demonstrated to be stable at temperature of up to 150 °C. According to these data, Mathews et al. considered that Ge could replace Pb as a new type of lead-free perovskite material [64]. Actually, the bandgaps of the Ge-based perovskites can be adjusted close to the conventional lead halide perovskite of 1.5 eV via altering A-site cations. 

Kanatzidis et al. synthesized a series of  AGeI3 perovskite compounds and characterized their structural, electronic and optical properties in 2015 [61]. The bandgaps of the Ge-based perovskites increase with the increased radius of the A cation. For instance,  CsGeI3 has an optical bandgap of 1.63 eV, whereas other  AGeI3 perovskites universally exhibit wide bandgap values of ≥ 2.0 eV. These  AGeI3 perovskites are rhombohedral crystal structures at room temperature [60]. Kanatzidis et al. [61] used the pyramidal  [GeI3]<sup>−</sup> building block to synthesize a series of Ge-based perovskites and adjusted their A-site cations. The experimental results showed that  CsGeI3,  MAGeI3, FAGeI3 and  CH3C(NH2)2GeI3 were 3D perovskite structures with direct bandgaps of 1.6, 1.9, 2.2, and 2.5 eV, respectively, while C(NH2)3GeI3,  (CH3)2C(H)NH3GeI3, and  (CH3)3NHGeI3 were 1D infinite chain structures separately with indirect bandgaps of 2.7, 2.5, and 2.8 eV, among which  CsGeI3 exhibited the highest optical absorption coefficient (Fig. 8a) and showed much more application potential in photovoltaic field. 

1 3 

**62** Page 16 of 36 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
(a) FA + b ··· ···<br>···<br>Sn 2+ +I − ··· ···<br>PEA + (101) ···<br>n=9<br>PEAI % 0% 20% 40% 80% 100%<br>3D 2D<br>(b) Corner-Sharing Perovskite (c) Face-Sharing Polytype<br>(100) view (110) view (111) view 3C 2H<br>- -  - - - - - -<br>c h<br>3D - - - - - - - -<br>3D c 1D h<br>- - - - - - - -<br>c<br>3D<br>(d) Dimensionally Reduced Perovskites (e) Hexagonal Perovskite Polytypes<br>6H 4H 9R<br>h h<br>2D<br>h<br>c h<br>2D c 3D 3D<br>c<br>c ---------<br>3D<br>1D<br>1D<br>(100 ) view (110 ) view<br><!-- End of picture text -->

**Fig. 7  a** Schematic structures of mixed FA/PEA Sn perovskites with PEAI/FAI doping ratios of 0, 20, 40, 60, 80, and 100%. Reproduced with permission from Ref. [127]. **b** Three alternative views of the archetypal 3D perovskite structure viewed along the (100), (110), and (111) cleavage planes. **c** “Perovskitoid” face-sharing building block of the 1D structures obtained for t > 1 representing the archetypal hexagonal polytype. **d** Perovskite structures obtained through dimensional reduction featuring corner-sharing 2D sheets and 1D chains through the (100) and (110) cleavage planes, respectively. **e** Hexagonal perovskite polytypes obtained from a linear combination of the corner-sharing 3D perovskite along the (111) cleavage plane and the 1D face-sharing polytype. The “h” and “c” symbols indicate hexagonal and cubic layers, respectively, and serve in identifying the layer sequence that characterizes the polytype. Reproduced with permission from Ref. [135] 

The photoluminescence (PL) measurements of  CsGeI3 single crystals exhibited two peaks at 0.82 μm (1.51 eV) and 1.15 μm (1.08 eV), which were respectively assigned to the interband transition at α. k = (π/a) (111) and the energy band change (Fig. 9a). The energy bands of the Ge-based perovskites with different A cations are shown in Fig. 9b. Fourier transform infrared spectroscopy showed that the transparent range of  CsGeI3 can be extended from ~ 2 to > 12 μm. The short-wave cutoff is mainly limited by the energy band, and 

the longest infrared transparency wavelength may originate from the phonon absorption of crystal lattice, and a specific rhombohedral crystal structure can be generated at room temperature [157]. Mathews et al. used hypophosphorous acid to improve the solubility of Ge perovskite precursor in organic solvent and prepared Ge-based perovskite films [60]. According to the SEM images (Fig. 9d–f), the films of  MAGeI3 and  CsGeI3 exhibited nearly full-coverage morphology, but the  FAGeI3 film showed a poor quality. Based 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 17 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

on these films, they then fabricated devices on mesoporous TiO2 structures.  MAGeI3 and  CsGeI3 solar cells showed _J_ scs of 4.0 and 5.7 mA cm<sup>−2</sup> and PCEs of 0.11 and 0.2%, respectively, as shown in Fig. 9c. In contrast,  FAGeI3 solar cell with poor film morphology displayed no photocurrent. 

Kopacic et al. [158] demonstrated that chemical composition engineering of  MAGeI3 significantly improved performances of solar cells and simultaneously enhanced their stability. By introducing bromide anion to partially replace idiode, the PCE based on  MAGeI2.7Br0.3 was increased up to 0.57%. 

Generally, Ge-based perovskites exhibit obviously different energy structures from the Pb-based ones and thus suitable ETL and HTL should be optimized to improve charge extraction efficiency in the device. More importantly, stabilization of  Ge<sup>2+</sup> in Ge-based perovskite is also a pretty challenging task to be solved. Otherwise, the stability issue and extremely low PCE will limit broader photovoltaic applications of this kind of perovskites. 

##### **_3.1.3  Transition Metal Halide Perovskite_** 

Divalent transition metal cations (e.g.,  Cu<sup>2+</sup> ,  Fe<sup>2+</sup> ,  Zn<sup>2+</sup> ) have also been considered as the candidates of Pb-free perovskites, which can be synthesized via a variety of routes to tune photovoltaic properties [63, 159]. Because of small ionic radii for transition metal ions (e.g., 0.73 nm for Cu(II) and 0.78 nm for Fe(II)) that far deviated from tolerance factor of 1, 3D structure (e.g.,  K2NiF4) cannot be maintained and it turns into stable 2D layered structure along < 100 > , < 110 > and < 111 > orientations [160]. 

Cu<sup>2+</sup> is a promising Pb-free perovskite in consideration of its good stability, earth abundance, low-cost and sufficient absorption in near-infrared region. Currently, some Cu-based perovskites have been developed for solar cell applications [63, 161, 162]. Cortecchia et al. first used the 2D crystal structure of  MA2CuClxBr4−x (Fig. 10a) as a light absorbing layer to fabricate solar cell [63]. They mixed MABr, MACl,  CuCl2 and  CuBr2 in DMSO as the precursor 



<!-- Start of picture text -->
(a) 3.5<br>3.0<br>2.5<br>2.0<br>1.5 Direct bandgap<br>Indirect bandgap<br>1.0<br>2.00<br>(b) CH3NH3PbI3 CH3NH3BiSeI2 (c) 2.0 1.90<br>1.68<br>1.59 1.58<br>1.5 1.38 1.29 1.44<br>1.24<br>Pb Bi 1.0<br>C I Se<br>N<br>0.5<br>0.0<br>MAPbI3MAGeI3FAGeI3CsGeI(CH)33NHGeI3 C(NH3 CH)2GeI3C(NH3 (CH3 )2)C(H)NH3GeI2 3 GeI3 3<br>Bandgap (eV)<br>Bandgap (eV)<br>CHSClNHBi332 CHSBrNHBi332 CHSINHBi323 CHSeClNHBi233 CHSeBrNHBi323 CHSeINHBi323 CHTeClNHBi323 CHBiTeBrNH332 CHNHBiTeI323<br><!-- End of picture text -->

**Fig. 8  a** Bandgaps of various Ge-based perovskite materials compared with  MAPbI3. **b** Atomic structures of  MAPbI3 and  MABiSeI2. **c** Calculated bandgaps of  CH3NH3BiXY2 compounds (with X = S, Se, Te and Y = Cl, Br, or I) using the Heyd–Scuseria–Ernzerhof functional with spin– orbit coupling. The dashed line marks the optimal bandgap for single-junction solar cell according to the Shockley–Queisser theory. Reproduced with permission from Ref. [52] 

1 3 

**62** Page 18 of 36 

Nano-Micro Lett. (2021) 13:62 

solution and tuned the bandgaps of  MA2CuClxBr4−x from 2.48 to 1.80 eV via changing the Br content (Fig. 10b). Cubased perovskites exhibited a narrow bandgap with low conduction band compared to other non-transition metal perovskite compounds, whose conduction band is derived from the unoccupied Cu 3d orbitals hybridized with Br/ Cl p orbitals. The  MA2CuClxBr4−x layer was fabricated on the FTO/mesoporous  TiO2 substrate by spin coating process. A PCE of 0.017% was obtained with extremely low _J_ sc of 216 µA  cm<sup>−2</sup> and _V_ oc of 0.256 V (Fig. 10c). In addition, they also prepared planar heterojunction cells based on  MA2CuClxBr4−x, but the PCE was far less than 0.017%. The higher PCE for mesoporous structure solar cell arises from improved charge extraction and vertical charge transport along with the destruction of the 2D structure of  MA2CuClxBr4−x perovskite by mesoporous  TiO2. The solar cells with  MA2CuClxBr4−x as the light absorber showed better stability due to the essential role of  Cl<sup>−</sup> , but unfortunately, the low absorption coefficient and heavymass hole limited their device performances. Subsequent works showed that  (C6H5CH2NH3)2CuBr4, (ρ-FC6H5C2H4NH3)2CuBr4 and  (CH3(CH2)3NH3)2CuBr4 based solar cells 

had slightly higher PCEs of 0.2%, 0.51%, and 0.63% [161, 162]. 

On the whole, Cu-based perovskites are relatively stable compared to other transition metal perovskite materials despite of the universially low conversion efficiency. How to reduce their wide optical bandgap and improve their charge transfer rate is the bottleneck problems limiting the further development of this type of perovskites. We believe that Cu-based perovskites will be an important part of lead-free perovskite solar cells once overcoming these problems. 

##### **3.2  Lead Replacement by Heterovalent Elements** 

##### **_3.2.1  A3B2X9 Perovskite_** 

Bi-based perovskites represent a successful example in lead-free perovskite materials family with low toxicity, air stability, and a fair degree of tunability. Abulikemu et al. successfully fabricated  (CH3NH3)3Bi2I9 powders, millimeter-scale single crystals and thin films with solvent-based crystallization methods (Fig. 11a, b) [163]. Compared with Pb-based counterpart,  (CH3NH3)3Bi2I9 perovskite has better 



<!-- Start of picture text -->
Wavelength (nm)<br>1000 900 800 700 600 500<br>(a) (b) −3.20 −3.20 (c) 10<br>−4.2 −3.45 8<br>6<br>CsSnI3 −4.9FTO CsGeI3 MAGeI3 FAGeI 3 OMeTADSpiro- 42 CsGeIMAGeI33<br>TiO2 0<br>CsGeI3 MAGeI3 FAGeI3 −5.10 −5.20 −5.50 −5.22 −5.1Au −2−4 0.0 Applied voltage (V)0.1 0.2 0.3 0.4<br>−6<br>1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6<br>Energy (eV)<br>(d) CsGeI3 (e) MAGeI3 (f) FAGeI3<br>1 µm 1 µm 1 µm<br>Absorption<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 9  a** Tauc plot for  CsSnI3,  CsGeI3,  MAGeI3, and  FAGeI3 showing optical bandgaps of 1.29, 1.63, 2.0, and 2.35 eV, respectively. **b** Energy level pattern for the PSCs with  CsGeI3,  MAGeI3, and  FAGeI3 absorbers. **c** Comparison of _J_ – _V_ curves of  CsGeI3 and  MAGeI3 solar cells. **d‑f** SEM images for  CsGeI3,  MAGeI3, and  FAGeI3 films both deposited on the compact  TiO2/mesoporous  TiO2 substrates. Reproduced with permission from Ref. [60] 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 19 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

stability. In response to the rapid crystallization of perovskites during film formation, the researchers proposed two thin film annealing methods to improve the film-forming quality. One was an antisolvent assisted crystallization route, which dropped antisolvent of chlorobenzene during the spin coating process of precursors and then annealed at 70 °C for 10 min to form perovskite film. The other method was denominated saturated vapor crystallization. The perovskite film was fabricated without dropping chlorobenzene during the spin coating process, and then annealed in a closed Petri dish at 60 °C overnight to slow the solvent evaporation, which generated a highly oriented single-crystal film (Fig. 11b, c). Solar cell devices were fabricated based on these thin films, achieving an efficiency of 0.11%, an FF of 31.80%, an average _J_ sc of 491.89 μA  cm<sup>−2</sup> and a _V_ oc of 0.7216 V (Fig. 11d, e). However, the external quantum efficiency (EQE) spectrum demonstrated that the device produced photocurrent merely at a short wavelength, with most part of the visible spectrum missed (e.g., above 500 nm) [163]. The explanation given by the researchers was that the depletion of EQE in the  (CH3NH3)3Bi2I9 film was attributed to its inhomogeneity and discontinuity between crystallites in terms of high recombination of photogenerated charges, so the high-quality perovskite film is a prerequisite to achieve a high efficiency. 

Buonassisi et al. used solution-processing and vaporassisted techniques to synthesize pure phase  (CH3NH3)3Bi2I9 perovskite (Fig. 12a) [164]. They found that the crystal structure of the pure phase  (CH3NH3)3Bi2I9 was composed 

of alternate  MA<sup>+</sup> and  Bi2I93− groups (Fig. 13b). The perovskite films prepared by this method were densely packed with high coverage and also showed excellent stability (Fig. 12c, d). The vapor processed films also got a longer PL decay time [164]. 

Very recently, Zhang et al. made a breakthrough in experimental method of fabricating high-quality  (CH3NH3)3Bi2I9 film [165]. They employed a novel solvent-free high–low vacuum deposition (HLVD) procedure to obtain smooth, compact and pinhole-free polygonal crystal  (CH3NH3)3Bi2I9 film and then fabricated heterojunction solar cells. The HLVD approach proposed here is a two-step alternate vacuum deposition of  BiI3 and MAI under high- and lowvacuum, which can be further transformed to the resultant (CH3NH3)3Bi2I9 perovskite. With the approximate 300 nm (CH3NH3)3Bi2I9 film as the light absorption layer to construct the planar heterojunction PSCs, they not only achieved a high PCE of 1.64% and a high EQE close to 60%, but also obtained a good stability during the measurement of 15 weeks, demonstrating the potential of  (CH3NH3)3Bi2I9 for highly efficient and stable solar cells. 

In subsequent research, Ran et al. synthesized a smooth, uniform and pinhole-free  (CH3NH3)3Bi2I9 thin film with a novel two-step evaporation spin coating film fabrication strategy (Fig. 13a, b) [166]. They further optimized film formation conditions by comparing the integrated current from the IPCE measurements and formed compact (CH3NH3)3Bi2I9 thin films. By taking advantage of the optimized compact thin film, they manufactured inverted 



<!-- Start of picture text -->
c<br>(a) b (b) 6 (c) 250<br>MA2CuCl2Br2 light<br>a 5 MA2CuCl2Br2 dark<br>200<br>4<br>3.80 eV 150<br>3 MA2CuCl0.5Br3.5 light<br>MA2CuCl0.5Br3.5 dark<br>2 100<br>0.92 eV<br>1<br>50<br>0<br>Cu 2.436<br>BrCl 2.9212.272 2.2722.921 −1 0<br>N 2.436<br>C −2 −50<br>Z Г Y T Z 0.0 0.1 0.2 0.3 0.4 0.5<br>MA2CuCl2Br2<br>Voltage (V)<br>9.6 Å<br>Energy (eV)<br>−2Current density (µA cm)<br><!-- End of picture text -->

**Fig. 10  a** Crystal structure of  MA2CuCl2Br2, showing the alternation of organic and inorganic layers and the Cu-X bond lengths in the inorganic framework. **b** Electronic band structure of  MA2CuClBr3 investigated by DFT simulation. **c** _J_ – _V_ curve of solar cells sensitized with MA2CuCl2Br2 (red) and  MA2CuCl0.5Br3.5 (brown) under 1 sun of light illumination. The red and brown dashed lines represent dark current. Reproduced with permission from Ref. [63] 

1 3 

**62** Page 20 of 36 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
(a) I(1) I(1) I(1) (b) I II<br>c Bi<br>b C(2) C(2)<br>a I(2) I(2)<br>N(2) I(2) N(2)<br>1000 µm 5000  µ m<br>C(2) Bi C(2)<br>III IV<br>I(1)<br>I(1) I(1)<br>Bi<br>I<br>N (CH3NH3)3Bi2I9 C(1) 0.5 µm GBL/DMSO GBL<br>C N(1)<br>400 20 500<br>(c) calc. powderpowder (d) GBL/DMSO-SVCGBL/DMSO-ASAC (e) (CH3NH3)3Bi2I9<br>thin film SVCthin film ASAC 300 EQE 15 400<br>300<br>200 10<br>200<br>JSC = 491.89 µA cm −2<br>100 5<br>100 VOC = 721.588 mV<br>FF = 31.80%<br>η = 0.11%<br>0 0 0<br>10 20 30 40 50 60 70 80 400 500 600 700 800 900 1000 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8<br>2θ Wavelength (nm) Voltage (V)<br>Counts SPS (mV) EQE (%)<br>−2)Current density (A cm<br><!-- End of picture text -->

**Fig. 11  a** A representation of the layered structure of  (CH3NH3)3Bi2I9, characterized by isolated  [Bi2I9]<sup>3−</sup> anions and two crystallographic inequivalent  CH3NH3+ cations. **b** Small single-crystal powder grown from  Bi2O3 and  CH3NH3I in concentrated HI (I–III). And  (CH3NH3)3Bi2I9 thin films deposited by the antisolvent assisted crystallization method (ASAC) using GBL/DMSO and GBL as solvents and chlorobenzene as antisolvent (IV). **c** Diffraction patterns of  (CH3NH3)3Bi2I9 thin films, powder and simulated powder from single-crystal XRD measurements. **d** EQE of a typical FTO/TiO2/(CH3NH3)3Bi2I9/spiro-MeOTAD/Au device. **e** _J_ – _V_ scanning of the best-forming device. Reproduced with permission from Ref. [163] 

planar heterojunction photovoltaic device with a PCE of 0.39% and a high _V_ oc of 0.83 V, which exhibited the lowest loss-in-potential to date in  (CH3NH3)3Bi2I9-based solar cells (Fig. 13c–e). However, there still existed a slight hysteresis effect in the _J_ – _V_ curves [166]. This work certificates that the film morphology engineering is crucial for improving the optoelectronic performance of Bi-based hybrid perovskites solar cells. 

Additionally, Park et al. confirmed more efficient solar cells with MA cations replaced by Cs cations in Bi-based perovskite [59]. On the basis of that research, Johansson et al. introduced a bismuth halide as the light absorber with the chemical composition of  Cs3Bi2I9 in their solar cells [167]. The morphology of the  Cs3Bi2I9 sample showed hexagonal flakes with size up to 2 μm, which were vertically organized and penetrated into  TiO2. The  TiO2 can be seen in the gaps between the large flakes due to the unique perovskite morphology and stacking mode. The best-performing device based on  Cs3Bi2I9 showed a _J_ sc 

2.2 mA cm<sup>−2</sup> , but lower _V_ oc and FF values generated a PCE of 0.4% [167]. 

Although researchers have got some successful examples of Bi-based perovskites, the performances of their perovskite solar cells are still universally low due to the intrinsic large bandgaps, large carrier effective masses, large exciton binding energies, more internal defects and defect intolerance. Design of new Bi-based lead-free perovskite materials avoiding above issues on the basis of theoretical calculation is critical for further development of high-performance solar cells. In addition, accurate control of formation rate with facile process technologies (e.g., moisture assisted growth, vacuum deposition, hot spin coating, and so forth) to improve the film quality of Bi-based perovskite allows for an improved performance of Bi-based lead-free perovskite devices. Here, we summarize the current research results of Bi-based PSCs in Table 2 [59, 161, 163–170]. 

Sb is in the same element group as Bi with low toxicity although it is a heavy metal [171, 172]. Halide perovskites 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 21 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
(a) Bil3 in DMF 20 °C 100 °C 20 °C<br>Bil3 Bil3 MBI<br>Spin Anneal + MAI<br>Substrate Substrate Substrate Substrate<br>10 s 0.5 hr 20 s<br>(b) 21.7 Å (c) (d)<br>(CH3NH3)3Bi2I9 Day 5 Day 13 Day 26<br>c 21.7 Å<br>b CH3NH3 + Bi3+ I− c 2 µm (CH3NH3)3Bi2I9<br>a<br>Fig. 12  a  Schematic diagram of  (CH3NH3)3Bi2I9 solution-assisted process. 3NH3)3Bi2I9 solution-assisted process. NH3)3Bi2I9 solution-assisted process. 3)3Bi2I9 solution-assisted process. )3Bi2I9 solution-assisted process. 3Bi2I9 solution-assisted process. Bi2I9 solution-assisted process. 2I9 solution-assisted process. I9 solution-assisted process. 9 solution-assisted process.  solution-assisted process.  b  Crystal structure and (001) view of  (CH3NH3)3Bi2I9. 3NH3)3Bi2I9. NH3)3Bi2I9. 3)3Bi2I9. )3Bi2I9. 3Bi2I9. Bi2I9. 2I9. I9. 9. .  c  SEM image<br>of  (CH3NH3)3Bi2I9 thin film. 3NH3)3Bi2I9 thin film. NH3)3Bi2I9 thin film. 3)3Bi2I9 thin film. )3Bi2I9 thin film. 3Bi2I9 thin film. Bi2I9 thin film. 2I9 thin film. I9 thin film. 9 thin film.  thin film.  d  Stability measurement of  (CH3NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]3NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]3)3Bi2I9 in air. Reproduced with permission from Ref. [164])3Bi2I9 in air. Reproduced with permission from Ref. [164]3Bi2I9 in air. Reproduced with permission from Ref. [164]Bi2I9 in air. Reproduced with permission from Ref. [164]2I9 in air. Reproduced with permission from Ref. [164]I9 in air. Reproduced with permission from Ref. [164]9 in air. Reproduced with permission from Ref. [164] in air. Reproduced with permission from Ref. [164]164]]<br>(a) (b) (CH3NH3)3Bi2I9<br>ITO glass<br>PEDOT:PSS<br>MAI drop 120 °C<br>& spin coat annealing<br>BiI3 powder<br>1 µm<br>MA3Bi2I9<br>(d) 1.6 (CH3NH3)3Bi2I9 (e) 25 1.4<br>(c)<br>20 1.2<br>C60/BCP/Ag 1.2 VJSCOC = 1.39 mA cm = 0.83 V −2 1.0<br>MA3Bi2I9 FF = 0.34 15<br>PCE = 0.39% IPCE 0.8<br>PEDOT:PSSITO 400 nm 0.8 JVFF = 0.33PCE = 0.36%SCOC = 1.34 mA cm = 0.81 V −2 10 Integrated current 0.6<br>0.4 0.4<br>5<br>0.2<br>0.0<br>0 0.0<br>0.0 0.2 0.4 0.6 0.8 300 400 500 600 700<br>Voltage (V) Wavelength (nm)<br>8.6 Å<br>14.9 Å<br>IPCE (%)<br>−2Current density (mA cm)<br>−2)Integrated photo current (mA cm<br><!-- End of picture text -->

**Fig. 12  a** Schematic diagram of  (CH3NH3)3Bi2I9 solution-assisted process. 3NH3)3Bi2I9 solution-assisted process. NH3)3Bi2I9 solution-assisted process. 3)3Bi2I9 solution-assisted process. )3Bi2I9 solution-assisted process. 3Bi2I9 solution-assisted process. Bi2I9 solution-assisted process. 2I9 solution-assisted process. I9 solution-assisted process. 9 solution-assisted process.  solution-assisted process. **b** Crystal structure and (001) view of  (CH3NH3)3Bi2I9. 3NH3)3Bi2I9. NH3)3Bi2I9. 3)3Bi2I9. )3Bi2I9. 3Bi2I9. Bi2I9. 2I9. I9. 9. . **c** SEM image of  (CH3NH3)3Bi2I9 thin film. 3NH3)3Bi2I9 thin film. NH3)3Bi2I9 thin film. 3)3Bi2I9 thin film. )3Bi2I9 thin film. 3Bi2I9 thin film. Bi2I9 thin film. 2I9 thin film. I9 thin film. 9 thin film.  thin film. **d** Stability measurement of  (CH3NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]3NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]NH3)3Bi2I9 in air. Reproduced with permission from Ref. [164]3)3Bi2I9 in air. Reproduced with permission from Ref. [164])3Bi2I9 in air. Reproduced with permission from Ref. [164]3Bi2I9 in air. Reproduced with permission from Ref. [164]Bi2I9 in air. Reproduced with permission from Ref. [164]2I9 in air. Reproduced with permission from Ref. [164]I9 in air. Reproduced with permission from Ref. [164]9 in air. Reproduced with permission from Ref. [164] in air. Reproduced with permission from Ref. [164]164]] 

**Fig. 13  a** Fabrication procedure and **b** SEM image of  (CH3NH3)3Bi2I9 film. **c** Cross-sectional SEM image of  (CH3NH3)3Bi2I9-based solar cells. **d** Forward and backward scanning and **e** IPCE spectra of the best-forming device. Reproduced with permission from Ref. [166] 

based on group-VA cations of  Sb<sup>3+</sup> are promising candidates due to the same lone-pair _ns_<sup>2</sup> state as  Pb<sup>2+</sup> . Through a joint experimental and theoretical study, researchers found that a 0D structure was formed in Sb-based perovskite, which was similar to Bi, but with lower exciton binding energies. Mitzi et al. reported a highly oriented Sb-based perovskite thin film by a two-step deposition approach. Large grain (> 1 μm) and continuous thin films of the lead-free perovskite  Cs3Sb2I9 

were achieved by annealing the evaporated CsI in  SbI3 vapor at 300 °C for 10 min, and the 〈 111 〉 -stacked layered perovskite structure was convinced by the X-ray diffraction (XRD) patterns [62]. The layered inorganic  Cs3Sb2I9 has a bandgap of 2.05 eV, measured by ultraviolet photoelectron spectroscopy, inverse photoemission spectroscopy and X-ray photoelectron spectroscopy (XPS), which showed similar absorption as high as  CH3NH3PbI3. The DFT calculations 

1 3 

**62** Page 22 of 36 

Nano-Micro Lett. (2021) 13:62 

indicated  Cs3Sb2I9 has a nearly direct bandgap in consideration of less than 0.02 eV difference between the direct and indirect bandgaps. Then Mitzi et al. prepared PSCs with the  Cs3Sb2I9 material, which produced a low PCE of less than < 1%, a significant hysteresis effect, and an enhanced air stability compared to  CH3NH3PbI3 counterpart [62]. 

Kirchartz et al. presented solution-treated trivalent antimony perovskite  (CH3NH3)3Sb2I9 and fabricated a planar heterojunction solar cell with this compound (Fig. 14a–c), yielding a PCE of ~ 0.5%, a decent FF of 55%, a _V_ oc of 0.89 V and a low photocurrent density of 1.0 mA cm<sup>−2</sup> [173]. They determined a peak absorption coefficient (α) of ~ 10<sup>5</sup> cm<sup>−1</sup> and an optical bandgap of 2.14 eV for amorphous  (CH3NH3)3Sb2I9 films by photothermal deflection spectroscopy. The PL was observed at 1.58 eV, and the Urbach tail energy of this amorphous composite was 62 × 10<sup>−3</sup> eV, demonstrating a substantial amount of energetic disorder [173]. The wide optical bandgap and energetic disorder may be the source of low photocurrent densities. In a word, this type of 0D dimer-phase trivalent antimony perovskite suffers from intrinsic problems including a 

low-symmetry induced indirect bandgap, strong quantumconfinement effect caused oversized gap values, and inferior hopping-like carrier transport, thus it is unfavorable for photovoltaic applications with extremely low PCEs of less than 0.5% obtained [62, 173]. 

The 2D layered phase can partially circumvent the abovementioned problems and is expected to show a direct bandgap, smaller optical bandgap and good in-layer carrier transport properties. Recently, with the introduction of small-size Rb<sup>+</sup> and  NH4+ as the A-site cations, 2D layered phases of Rb3Sb2I9 [174] and  (NH4)3Sb2I9 [175] have been realized using low-temperature solution processing. Zhou et al. performed comprehensive chemical composition engineering of the precursor solutions by incorporating MACl into the mixture of  SbI3 and MAI, and successfully realized a phase transformation from the 0D dimer phase to the 2D layered one [176]. As displayed in Fig. 14d–j, the presence of the 2D layered phase was demonstrated by X-ray diffraction measurements, optical absorbance spectroscopy, and direct comparison of the experimental data with theoretical calculations. With high-quality films of the 2D layered 

**Table 2** Photovoltaic parameters of PSCs based on various Bi-based perovskite absorbers 

|Preparation process|Absorber|Device architecture|_V_oc(V)|_J_sc(mA cm<sup>−2</sup>)|FF (%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|One-step spin coating|Cs3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>P3HT/Ag|0.31|0.34|38|0.40|[165]|
|One-step spin coating|(CH3NH3)3Bi2I9|c-TiO2/perovskite/spiro/Au|0.72|0.49|31.8|0.11|[161]|
|One-step spin coating|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.68|0.38|88|0.22|[166]|
|One-step spin coating|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Ag|0.68|0.52|33|0.12|[59]|
|One-step spin coating|Cs3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Ag|0.85|2.15|60|1.09|[59]|
|One-step spin coating|(CH3NH3)3Bi2I9Clx|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Ag|0.04|0.18|38|0.03|[59]|
|One-step spin coating|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>P3HT/Au|0.35|1.157|46.4|0.19|[167]|
|One-step spin coating|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>PIF8-TAA/Au|0.85|1.22|73|0.71|[168]|
|Two-step evaporation spin<br>coating|(CH3NH3)3Bi2I9|PEDOT:PSS/perovskite/C60/<br>BCP/Ag|0.83|1.39|37|0.39|[164]|
|Two-step thermal evaporation|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>spiro-MeOTAD/Au|0.83|3.00|79|1.64|[163]|
|Vapor-assisted solution process|(CH3NH3)3Bi2I9|c-TiO2/m-TiO2/perovskite/<br>P3HT/Au|1.01|4.02|78|3.17|[169]|
|One-step spin coating|Cs3Bi2I9|c-TiO2/perovskite/spiro-MeO-<br>TAD/Au|0.79|4.45|50.34|1.77|[170]|
|One-step spin coating|Cs3Bi2I9|c-TiO2/perovskite/CuI/Au|0.86|5.78|64.38|3.20|[170]|
|One-step spin coating|Cs3Bi2I9|c-TiO2/perovskite/PTAA/Au|0.83|4.82|57.49|2.30|[170]|



© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 23 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

MA3Sb2ClXI9−X perovskites as light absorbers, they fabricated solar cells with PCEs of over 2% [176]. 

So far, the Sb-based perovskites, similar to bismuth ones, still show a limited efficiency. But they own a bright application prospect once their nearly direct bandgap can be adjusted to a suitable value (e.g., doping) that matches with solar spectra. In addition, Sb-based perovskites can form a more stable 2D layered phase, which are better for carrier transport and display improved optoelectronic properties compared with the 0D Bi-based counterparts. 

##### **_3.2.2  Chalcogen–Halogen Hybrid Perovskite_** 

In 2015, Sun et al. proposed the anion-split approach based on first-principles calculation, where dual anions (e.g., halogen and chalcogen anions) were introduced while Pb was replaced by heterovalent non-toxic elements in order to keep the 3D perovskite structure and the charge neutrality (Fig. 8b, c) [52]. Figure 8b shows the atomic structure of MABiSeI2, which maintained the  MAPbI3 tetragonal structure with a freely rotating  MA<sup>+</sup> ion according to ab initio molecular dynamics (AIMD) simulations. 

Taking Bi as the core element of the B position, Shockley et al. examined a series of  MABiChX2 (Ch = S, Se, Te; X = I, Br, Cl) compounds and found that  CH3NH3BiSeI2 and CH3NH3BiSI2 exhibited improved optical absorption and reduced bandgaps (1.3–1.4 eV) over  CH3NH3PbI3, which were proved to be the optimal value for solar cell absorbers according to the Shockley–Queisser theory (Fig. 8c) [177]. These results suggested that the 3D AB(Ch, X)3 perovskites represented by  MABiSI2 could be promising candidates of photovoltaic absorbers once they were successfully synthesized. Unfortunately, the subsequent feasibility assessment of the proposed 3D AB(Ch, X)3 perovskites by Hong et al. via DFT calculations and solid-state reactions indicated that all of the as-proposed AB(Ch, X)3 perovskites are thermodynamically unstable [34], and they tend to decompose into ternary and/or binary phases or form nonperovskite phases. Recently, the work of Li et al. has proved the instability of chalcogen–halogen hybrid perovskite through experimental and computational analysis, and they found that AB(Ch, X)3 would be decomposed into a mixture of binary and ternary compounds  (Sb2S3 and  MA3Sb2I9) soon after being synthesized [178]. Upon inspection, the target perovskites are impossible to be successfully synthesized as designed. 

Finally, the researcher had to draw a conclusion that it may be a huge challenge to synthesize the proposed AB(Ch, X)3 perovskites due to their thermodynamic instability, which means there is still a long way for AB(Ch, X)3 perovskites to go for further applications in perovskite photovoltaic devices. 

##### **_3.2.3  0D Perovskite Derivative  A2BX6_** 

Previous analysis indicated that it is feasible to replace Pb of lead halide perovskites with tetravalent B(IV) substitutes. To accommodate the heterovalent substitute, the chemical formula needs to turn into  A2BX6, which is derived from its  ABX3 perovskite structure by removing half of B-site cations. Because of the large charge difference between them, the  A2BX6 perovskite variant is sometimes referred to as the  A2B □ X6-type vacant ordered double perovskite [86, 179–181]. The B-site vacancies (denoted as □ ) and the remaining B-site cations generally adopt a rock salt arrangement in the  A2BX6 perovskite structure. Due to the absence of connectivity between the  [BX6] octahedra, the A2BX6 perovskite variants are actually 0D nonperovskites despite researchers still would like to call them perovskites. The optoelectronic properties of the  A2BX6-type perovskite materials are rather different from those of 3D  ABX3 (B = Pb, Sn, and Ge) perovskites due to the isolated  [BX6] octahedra in  A2BX6 compounds. Among the  A2BX6 compounds [182–185],  A2SnI6 (A = Cs, MA) [182, 183] and Cs2TiBr6 [181, 182] have been investigated for photovoltaic applications. These  A2BX6 compounds show intrinsic n-type conductivity. Compared to 3D  CsSnI3 with better defect tolerance, the  A2BX6-type materials with I vacancies and Sn interstitial defects have deeper levels in their bandgaps owing to the strong covalent nature of the  [SnI6] octahedron, seriously impacting optoelectronic performances of devices. 

The vacancy-ordered  A2M(IV)X6 double perovskites was found to have suitable direct bandgaps. In 2016, Cao et al. found the spontaneous oxidative conversion of unstable  CsSnI3 to air-stable  Cs2SnI6 in air [183]. The  Cs2SnI6 perovskite was adopted as the light absorber layer of leadfree perovskite solar cell for the first time due to its small bandgap of 1.48 eV and high absorption coefficient, showing a PCE of about 1% with a _V_ oc of 0.51 V and a _J_ sc of 5.41 mA cm<sup>−2</sup> after optimizing the perovskite film thickness. 

1 3 

**62** Page 24 of 36 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
(a) 0.0<br>(b) (c)<br>12 (CH3NH3)3Sb2I9<br>Cs/CH3NH3 sweep-up (down): JSC  = 1.1 mA cm −2<br>I −0.4 VOC  = 885(896) mV<br>Sb JSC  = 1.0 mA cm −2 8<br>FF  = 52(55)% up<br>η  = 0.46(0.49)% down<br>−0.8 4 JSC  = 0.1 mA cm −2<br>PEDOT/PCBM<br>0<br>(CH3NH3)3Sb2I9 0.0 0.2 0.4 0.6 0.8 1.0 400 500 600 700<br>Voltage  V (V) Wavelength  λ  (nm)<br>(d) Dimer Layer (e) Au<br>Cl addition<br>A3Sb2I9 A3Sb2ClxI9-x<br>Cl I Sb A<br>(g) 3.0 (h)<br>(f) 1-1.5-0 SbI3-MAI-MACl SbI3-MAI-MACl<br>Dimer (simulated) 2.5 1-1.5-0 1-1.5-0<br>1-0-1.5 1-0-1.5<br>2.0 1-0.5-1.5 1-0.5-1.5<br>1-1-1.2 1-1-1.2<br>1.5<br>1-0-1.5 1.0<br>Layer (simulated)<br>0.5 ~2.17 eV<br>~2.44 eV<br>0.0<br>450 500 550 600 650 2.0 2.2 2.4 2.6 2.8<br>Wavelength (nm) hv  (eV)<br>1-0.5-1.5 )i( 2 )j( 5 4<br>4<br>0 3<br>SbI3-MAI-MACl<br>−2 1-1.5-01-0-1.5 3 2<br>1-1-1.2 1-0.5-1.5 2<br>−4 1-1-1.2 1 light on Vmpp = 0.54 V 1<br>−6 0.0 0.2 0.4 0.6 0.8 00 60 120 180 240 300 3600<br>Voltage (V)<br>10 20 30 40 50 60 Time (s)<br>2θ (°)<br>spiro-OMeTAD<br>MA3Sb2ClxI9-x<br>c-TiO2/m-TiO2<br>FTO<br>−2Current density  (mA cm) J Quantum efficiency  EQE  (%)<br>2(ahv) (a.u.)<br>Absorbance (a.u.)<br>Intensity (a.u.)<br>PCE (%)<br>−2Current density (mA cm) −2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 14  a** Crystal structure of  (CH3NH3)3Sb2I9 (space group  P63/ _mmc_ ). **b** Illuminated _J_ – _V_ curves of  (CH3NH3)3Sb2I9 solar cell measured with forward and backward scanning with a rate of 0.1 V s<sup>−1</sup> . **c** EQE measurement of the  (CH3NH3)3Sb2I9 solar cell compared to the reference device of ITO/PEDOT/PCBM/ZnO-NP/Al. Reproduced with permission from Ref. [173] **d** Schematic plot of the Cl doping-induced transformation from the 0D dimer phase of  A3Sb2I9 to the 2D layered phase of  A3Sb2ClXI9−X. **e** Schematic structure of the as-fabricated PSC. **f** XRD patterns of the films deposited from precursors containing  SbI3, MAI, and MACl with molar ratios of 1:1.5:0, 1:0:1.5, 1:0.5:1.5, and 1:1:1.2. **g** Measured UV–vis absorbance spectra of the four types of films. **h** Tauc plots of the absorption coefficients for evaluating the bandgap values of the pureiodine perovskites  MA3Sb2I9 and Cl-containing mixed-halide perovskites  MA3Sb2ClXI9−X. **i** _J_ – _V_ curves for the devices fabricated with the four kinds of perovskite films. **j** Steady-state photocurrent output for the device based on 1-1-1.2 film at the maximum power point (red circle). Maximum power point voltage  Vmpp is equal to 0.54 V. Reproduced with permission from Ref. [176] 

Soon after, Cao et al. synthesized  Cs2SnI6 powder with a modified solution process and fabricated mesoporous solar cells [183]. They achieved a PCE of 0.96% by carefully 

controlling ZnO nanorod length and pore size. Chang et al. reported a new material  Cs2SnI6−xBrx with mixed halides which provided desired bandgaps of ~ 1.3 to ~ 2.9 eV suitable 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 25 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

for solar cells via simple tune of Br component. They applied this perovskite material as light absorbing layer to PSCs and achieved an optimal conversion efficiency of 2.1% as x = 2 [184]. Recently,  Cs2TiBr6 thin films were prepared through a facile low-temperature vapor-based method and then incorporated into planar heterojunction PSCs [185]. Subsequently, Chen et al. also demonstrated that the  Cs2TiBr6 thin film has a suitable bandgap of 1.8 eV, a long and balanced carrier diffusion length, and an appropriate energy level, with which solar cells produced an efficiency of up to 3.3% [186]. 

##### **_3.2.4  Double Perovskite  A2B(I)B(III)X6_** 

Lead-free halide double perovskites materials were known as “elpasolites” many years ago, whose name was from the mineral  K2NaAlF6. In 2016, Giustino et al. counted the elements belonging to halide elpasolites [27]. As shown in Fig. 15, it can be clearly seen that 7 elements can occupy the A-site, and 8 elements including  NH3+ can occupy the B(I) site and 34 elements can occupy the B(III) site, while 5 elements containing the cyanide  CN<sup>−</sup> are able to occupy the X site. Although many of these compounds are available, it requires to satisfy some prerequisites for photovoltaic 

applications, such as suitable bandgap, high carrier mobility, low defect state and good thermodynamic stability. Through the element selection of B(I) site and B(III) site in the double perovskite, the bandgap can be well adjusted and thus exhibits excellent optoelectronic properties. For example, Cs2NaBiI6 has a direct bandgap of 1.66 eV. Through element adjustment,  Cs2AgInBr6 with a direct bandgap of 1.50 eV and  Cs2InSbCl6 and  Cs2InBiCl6 with a direct bandgap of about 1.0 eV can be obtained. At present, the researchers have discovered the double perovskite material  Cs2AgBiBr6 possesses with a suitable bandgap of 1.95 eV, which can be used as light absorber in solar cells. To date,  Cs2AgBiBr6 is the most commonly used photovoltaic material in leadfree halide double perovskite-based solar cells [187–190]. Bein et al. fabricated  Cs2AgBiBr6 films with a spin coating method and incorporated them into solar cells for the first time in 2017 [187]. After optimizing synthesis conditions, the  Cs2AgBiBr6-based solar cells without encapsulation showed a PCE of 2.43%, a _V_ oc of exceeding 1 V and excellent stability in air. The fly in the ointment is that the device has a serious hysteresis effect. 

In 2018, Xiao et al. prepared a transparent solution of Cs2AgBiBr6 in DMSO and fabricated the  Cs2AgBiBr6 film using spin coating technique by low-pressure-assisted 



<!-- Start of picture text -->
(a) (b)<br>A2B(I)B(III)X6<br>A B(I) B(III) X<br>K    Rb Li  Na Al   Sc  Ti  F  Cl<br>V   Cr  Mn<br>Ag  Sc K   Rb Br  I<br>Fe  Co  Ni<br>TINH4+ TI  Ag Au Cu  Ga  YIn   Sb  Au   CN -<br>+<br>CH3NH3 + Tl   Bi   Ce<br>NH4<br>Pr  Nd  Sm<br>Eu Gd  Tb<br>Dy  Ho Tm<br>Yb  Lu  Er<br>3D A2B(I)B(III)X6 Halide Double Perovskites Pu Am  Bk<br>La<br><!-- End of picture text -->

**Fig. 15** Crystal structure of double perovskite  A2B(I)B(III)X6 ( **a** ) and the elements/functional groups that can form double perovskite  A2B(I) B(III)X6 ( **b** ) 

1 3 

**62** Page 26 of 36 

Nano-Micro Lett. (2021) 13:62 



<!-- Start of picture text -->
IPA Drop<br>(a)<br>120<br>nm<br>Substrate<br>0<br>RMS = 5.46 nm<br>Dissolved<br>In DMSO Spin Coat<br>164<br>Cs2AgBiBr6<br>Powder<br>nm<br>Substrate<br>0<br>RMS = 24.20 nm<br>(b)<br>Cs2AgBiBr6<br>Two-step<br>Annealing in Air<br>AgBr BiBr3 CsBr<br>(c) 2.0 (d) 2.0 (e)<br>40 1.8 1.2<br>1.5 1.6 1.0<br>1.4<br>30<br>EQE 1.2 0.8<br>P3HT<br>1.0 Cs2AgBiBr6 20 Integrated J 1.0 0.6 w/o encapsulations<br>c-TiO2 0.8 Stored in dry box (7% RH 25 °C)<br>FTO 0.6 0.4 tested in open air (42% RH)<br>0.5 500 nm 10 0.4 0.2<br>0.2<br>0.0 0 0.0 0.0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 300 350 400 450 500 550 600 0 50 100 150 200 250<br>Voltage (V) Wavelength (nm) Time (h)<br>EQE (%)<br>Normalized PCE<br>−2)Integrated J (mA cm<br>−2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 16  a** Schematic illustration of the spin coating process of  Cs2AgBiBr4 with and without antisolvent dropping program, and the morphology of the as-prepared film. Reproduced with permission from Ref. [189] **b** Scheme of sequential vapor deposition process. **c** _J_ – _V_ curve of the optimized solar cell. Inset: Cross-sectional SEM image of the device. **d** EQE spectrum and the integrated current density with AM 1.5G photon flux. **e** Evaluation of long-term stability of the solar cells stored in dry box. Reproduced with permission from Ref. [191] 

solution processing under ambient conditions [188]. Differently from the conventional annealing method, the spincoated film was quickly moved to a low-pressure chamber pumped to 20 Pa, where the transparent film gradually turned to light yellow. A smooth morphology was obtained 

compared with the rough films prepared by conventional annealing methods. Finally, planar heterojunction solar cells were manufactured with optimized  Cs2AgBiBr6 films and P3HT hole transport layer, and a PCE of 1.44% was achieved. 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 27 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

**Table 3** Photovoltaic parameters of PSCs based on double perovskite  A2B(I)B(III)X6 absorbers 

|Absorber|Method for preparing perovskite<br>film|Device architecture|_V_oc(V)|_J_sc(mA cm<sup>−2</sup>)|FF (%)|PCE (%)|References|
|---|---|---|---|---|---|---|---|
|Cs2AgBiBr6|Spin coating|c-TiO2/m-TiO2/perovskite/spiro-<br>MeOTAD/Au|0.98|3.93|63|2.43|[187]|
|Cs2AgBiBr6|Low-pressure-assisted solution pro-<br>cessing under ambient conditions|SnO2/Cs2AgBiBr6/P3HT/Au|1.04|1.78|78|1.44|[188]|
|Cs2AgBiBr6|Antisolvent dropping technology<br>and post-annealing process|Cu-NiO/Cs2AgBiBr6/C60/BCP/Ag|1.00|3.23|68.4|2.21|[189]|
|Cs2AgBiBr6|Sequential vapor deposition<br>method|c-TiO2/perovskite/P3HT/Au|–|–|–|1.37|[191]|
|Cs2AgBiBr6|Spin coating deposition and<br>annealing at high temperature|c-TiO2/m-TiO2/perovskite/PTAA/<br>Au|1.02|1.84|67|1.26|[190]|
|Cs2AgBiBr6|Spin coating deposition and<br>annealing at high temperature|c-TiO2/m-TiO2/perovskite/PCP-<br>DTBT/Au|0.71|1.67|57|0.68|[190]|
|Cs2AgBiBr6|Spin coating deposition and<br>annealing at high temperature|c-TiO2/m-TiO2/perovskite/spiro-<br>MeOTAD/Au|0.64|2.45|57|0.90|[190]|
|Cs2NaBiI6|Spin coating|c-TiO2/m-TiO2/perovskite/spiro-<br>MeOTAD/Au|0.47|1.99|44|0.42|[194]|



In a subsequent work, Wu et al. used antisolvent dropping method and post-annealing process to realize high-quality Cs2AgBiBr6 films with ultra-smooth morphology, microsized grains, and high crystallinity (Fig. 16a). Then they fabricated inverted planar heterojunction solar cells with the as-prepared  Cs2AgBiBr6 films and got a high PCE of 2.23% [189]. It should be noted that the _J_ – _V_ hysteresis was clearly showed in the above-mentioned two works, which was closely related with the large amount of defects in Cs2AgBiBr6 films. Grancini et al. precisely controlled the perovskite deposition parameters to obtain a highly uniform and compact  Cs2AgBiBr6 film, and modified the device interfaces with small molecular/polymeric hole-transporting materials to eliminate the hysteresis effect [190]. 

Recently, Liu et al. successfully prepared double perovskite  Cs2AgBiBr6 thin films through a sequential vapor deposition procedure (Fig. 16b) [191]. The as-fabricated thin films with pure double perovskite phase showed large grain sizes, uniform and smooth surface morphology along with a PL lifetime of 117 ns, indicative of a significant potential in photovoltaic applications. The solar cells with planar device structure obtained an optimal PCE of 1.37%, which maintained 90% of the initial efficiency after 240 h storage under ambient condition (Fig. 16c–e). In addition to  Cs2AgBiBr6, Cs2NaBiI6 has also been used as a light absorbing layer for PSCs and the device showed a good stability despite of a low efficiency of only 0.42% [192]. Relevant results for most 

types of double PSCs based on various device architectures are summarized in Table 3 [187–192]. 

At the initial design stage of lead-free halide double perovskite materials, researchers specifically emphasized the need to ensure the thermodynamic stability of the material [186–188]. Therefore, the halide double perovskite materials used in solar cells show excellent stability, which will be an outstanding advantage in practical application. In addition, the optical bandgap and other optoelectronic properties of the double perovskites can be optimized through the use of both B(I) and B(III) elements [186–194]. Thus, these characteristics make the halide double perovskite a good candidate for high-performance, stable and environmentally friendly solar cells. 

### **4  Conclusion and Prospect** 

In this review, we focused our attention on environmentally friendly lead-free perovskite materials and combed the related progress on theoretical and experimental works. Herein, all of lead-free perovskites consisting of Sn (II), Cu (II), Bi(III), Sb (III), Sn (IV), Ti (IV), and Ag(I)Bi(III) were introduced from the isovalent and heterovalent elements replacement perspectives. We summarized the material preparation, device performance and stability of each lead-free perovskite materials and presented their possible issues and potential development prospects. For Sn-based 

1 3 

**62** Page 28 of 36 

Nano-Micro Lett. (2021) 13:62 

perovskites, this type of material has a relatively high absorption coefficient (close to 1.80 × 10<sup>4</sup> cm<sup>−1</sup> ), but the easy oxidation of  Sn<sup>2+</sup> to  Sn<sup>4+</sup> is also considered to be the main problem limiting the development of Sn-based PSCs. Similar to Sn-based perovskites, Ge-based perovskites also face the trouble of being easily decomposed by oxidation. In addition, compared with  Sn<sup>2+</sup> , Bi and Sb are very stable when they are in the +3 valence state in the atmosphere. However, the efficiency of Bi- and Sb-based PSCs is still very low. Further optimization of their bandgaps as well as film morphology, manufacture methods and device structures are feasible solutions to further improve device performance. The transition metal perovskites represented by Cu-based perovskites also need to reduce their wide optical bandgap and improve their charge transporting properties to develop more efficient PSCs. Besides, the application of AB(Ch, X)3 perovskites for PSCs is facing great challenges due to the thermodynamic instability. In addition to the above-mentioned materials, the halide double perovskite has attracted people’s attention because of its excellent stability and bandgap tunability. 

In summary, we have reviewed the past experimental work and comprehensively understood the development and application prospects of current lead-free perovskite materials. Lead-free perovskites enable to avoid a high content of the toxic, polluting and bioaccumulative lead hazards and are more conducive to commercial production and application. At the same time, theoretical simulations have made important contributions to comprehending the fundamental physics behind the efficiency, stability, and carrier transport properties of lead-free PSCs. Using scientific theoretical calculations and reasonable solar cell preparation methods, we believe that the research on lead-free PSCs will soon have a clear breakthrough. Here, we are looking forward to the further development of lead-free perovskite materials and PSCs. Finally, we expect that the performance as well as the stability of lead-free perovskites, especially 2D layered perovskites, can be continuously improved to meet the needs of commercial development. In spite of slower development of lead-free perovskites than lead ones, we believe that the efficiency based on lead-free perovskite materials can break through 15% after further in-depth study, and we should keep warm toward this research. 

**Acknowledgements** The authors acknowledge financial support from the National Key Research and Development Program of 

China (Grant No. 2017YFB0404501), the National Major Fundamental Research Program of China (Grant No. 91833306), the National Natural Science Foundation of China (Grant Nos. 62074083, 62005131, 61705111 and 61704091), the Science Fund for Distinguished Young Scholars of Jiangsu Province of China (Grant No. BK20160039), the Natural Science Foundation of Jiangsu Province (Grant Nos. BM2012010 and BK20170899), the Priority Academic Program Development of Jiangsu Higher Education Institutions (Grant No. YX030003), the Jiangsu National Synergetic Innovation Center for Advanced Materials, the Synergetic Innovation Center for Organic Electronics and Information Displays, the National Postdoctoral Program for Innovative Talents (Grant No. BX201700122), and the Open Foundation from Jilin University (Grant Nos. IOSKL2017KF04 and IOSKL2018KF01). 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creat iveco mmons .org/licen ses/by/4.0/. 

### **References** 

1. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. **131** (17), 6050–6051 (2009). https :// doi.org/10.1021/ja809 598r 

2. M.M. Lee, J. Teuscher, T. Miyasaka, T.N. Murakami, H.J. Snaith, Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science **338** (6107), 643–647 (2012). https ://doi.org/10.1126/scien ce.12286 04 

3. G. Xing, N. Mathews, S. Sun, S.S. Lim, Y.M. Lam et al., Long-range balanced electron- and hole-transport lengths in organic-inorganic  CH3NH3PbI3. Science **342** (6156), 344–347 (2013). https ://doi.org/10.1126/scien ce.12431 67 

4. S.D. Stranks, G.E. Eperon, G. Grancini, C. Menelaou, M.J.P. Alcocer et al., Electron-hole diffusion lengths exceeding 1 micrometer in an organometal trihalide perovskite absorber. Science **342** (6156), 341–344 (2013). https ://doi.org/10.1126/ scien ce.12439 82 

5. P. Docampo, J.M. Ball, M. Darwich, G.E. Eperon, H.J. Snaith, Efficient organometal trihalide perovskite planarheterojunction solar cells on flexible polymer substrates. Nat. Commun. **4** , 2761–2766 (2013). https ://doi.org/10.1038/ ncomm s3761 

6. J.H. Heo, S.H. Im, J.H. Noh, T.N. Mandal, C.-S. Lim et al., Efficient inorganic–organic hybrid heterojunction solar 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 29 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

   - cells containing perovskite compound and polymeric hole conductors. Nat. Photon. **7** (6), 486–491 (2013). https ://doi. org/10.1038/nphot on.2013.80 

7. J. Burschka, N. Pellet, S.-J. Moon, R. Humphry-Baker, P. Gao et al., Sequential deposition as a route to high-performance perovskite-sensitized solar cells. Nature **499** (7458), 316–319 (2013). https ://doi.org/10.1038/natur e1234 0 

8. P. Gao, M. Grätzel, M.K. Nazeeruddin, Organohalide lead perovskites for photovoltaic applications. Energy Environ. Sci. **7** (8), 2448–2463 (2014). https ://doi.org/10.1039/c4ee0 0942h 

9. O. Malinkiewicz, A. Yella, Y.H. Lee, G.M. Espallargas, M. Graetzel et al., Perovskite solar cells employing organic charge-transport layers. Nat. Photon. **8** (2), 128–132 (2013). https ://doi.org/10.1038/nphot on.2013.341 

10. W. Chen, Y. Wu, Y. Yue, J. Liu, W. Zhang et al., Efficient and stable large-area perovskite solar cells with inorganic charge extraction layers. Science **350** (6263), 944–948 (2015). https ://doi.org/10.1126/scien ce.aad10 15 

11. M. Sessolo, H.J. Bolink, Solar cells@ Perovskite solar cells join the major league. Science **350** (6263), 917 (2015). https ://doi.org/10.1126/scien ce.aad58 91 

12. J. Xu, A. Buin, A.H. Ip, W. Li, O. Voznyy et al., Perovskite-fullerene hybrid materials suppress hysteresis in planar diodes. Nat. Commun. **6** , 7081 (2015). https ://doi. org/10.1038/ncomm s8081 

13. M.A. Green, K. Emery, Y. Hishikawa, W. Warta, E.D. Dunlop, Solar cell efficiency tables (version 46). Prog. Photovolt: Res. Appl. **23** (7), 805–812 (2015). https ://doi.org/10.1002/ pip.2637 

14. Z. Xiao, Q. Dong, C. Bi, Y. Shao, Y. Yuan et al., Solvent annealing of perovskite-induced crystal growth for photovoltaic-device efficiency enhancement. Adv. Mater. **26** (37), 6503–6509 (2014). https ://doi.org/10.1002/adma.20140 1685 

15. A. Mei, X. Li, L. Liu, Z. Ku, T. Liu et al., A hole-conductorfree, fully printable mesoscopic perovskite solar cell with high stability. Science **345** (6194), 295–298 (2014). https :// doi.org/10.1126/scien ce.12547 63 

16. D. Liu, T.L. Kelly, Perovskite solar cells with a planar heterojunction structure prepared using room-temperature solution processing techniques. Nat. Photon. **8** (2), 133–138 (2013). https ://doi.org/10.1038/nphot on.2013.342 

17. C. Bi, Q. Wang, Y. Shao, Y. Yuan, Z. Xiao et al., Non-wetting surface-driven high-aspect-ratio crystalline grain growth for efficient hybrid perovskite solar cells. Nat. Commun. **6** , 7747 (2015). https ://doi.org/10.1038/ncomm s8747 

18. D.P. McMeekin, G. Sadoughi, W. Rehman, G.E. Eperon, M. Saliba et al., A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. Science **351** (6269), 151–155 (2016). https ://doi.org/10.1126/scien ce.aad58 45 

19. Y. Chen, T. Chen, L. Dai, Layer-by-layer growth of CH3NH3PbI(3−x)Clx for highly efficient planar heterojunction perovskite solar cells. Adv. Mater. **27** (6), 1053–1059 (2015). https ://doi.org/10.1002/adma.20140 4147 

20. W.S. Yang, J.H. Noh, N.J. Jeon, Y.C. Kim, S. Ryu et al., High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science **348** (6420), 1234– 1237 (2015). https ://doi.org/10.1126/scien ce.aaa92 72 

21. J. Wang, Y. Liu, X. Chen, C. Chen, P. Chen et al., Functional metal oxides in perovskite solar cells. ChemPhysChem **20** (20), 2580–2586 (2019). https ://doi.org/10.1002/ cphc.20190 0447 

22. D. Bi, W. Tress, M.I. Dar, P. Gao, J. Luo et al., Efficient luminescent solar cells based on tailored mixed-cation perovskites. Sci. Adv. **2** (1), e1501170 (2016). https ://doi. org/10.1126/sciad v.15011 70 

23. K. Meng, S. Gao, L. Wu, G. Wang, X. Liu et al., Two-dimensional organic-inorganic hybrid perovskite photonic films. Nano Lett. **16** (7), 4166–4173 (2016). https ://doi.org/10.1021/ acs.nanol ett.6b010 46 

24. N.J. Jeon, H. Na, E.H. Jung, T.-Y. Yang, Y.G. Lee et al., A fluorene-terminated hole-transporting material for highly efficient and stable perovskite solar cells. Nat. Energy **3** (8), 682–689 (2018). https ://doi.org/10.1038/s4156 0-018-0200-6 

25. B. Hailegnaw, S. Kirmayer, E. Edri, G. Hodes, D. Cahen, Rain on methylammonium lead iodide based perovskites: Possible environmental effects of perovskite solar cells. J. Phys. Chem. Lett. **6** (9), 1543–1547 (2015). https ://doi. org/10.1021/acs.jpcle tt.5b005 04 

26. R. Wang, J. Wang, S. Tan, Y. Duan, Z.-K. Wang et al., Opportunities and challenges of lead-free perovskite optoelectronic devices. Trends in Chem. **1** (4), 368–379 (2019). https ://doi. org/10.1016/j.trech m.2019.04.004 

27. F. Giustino, H.J. Snaith, Toward lead-free perovskite solar cells. ACS Energy Lett. **1** (6), 1233–1240 (2016). https ://doi. org/10.1021/acsen ergyl ett.6b004 99 

28. Z. Shi, J. Guo, Y. Chen, Q. Li, Y. Pan et al., Lead-free organic-inorganic hybrid perovskites for photovoltaic applications: recent advances and perspectives. Adv. Mater. **29** (16), 1605005 (2017). https ://doi.org/10.1002/adma.20160 5005 

29. S. Yang, W. Fu, Z. Zhang, H. Chen, C.-Z. Li, Recent advances in perovskite solar cells: efficiency, stability and lead-free perovskite. J. Mater. Chem. A **5** (23), 11462–11482 (2017). https ://doi.org/10.1039/c7ta0 0366h 

30. P. Xu, S. Chen, H.-J. Xiang, X.-G. Gong, S.-H. Wei, Influence of defects and synthesis conditions on the photovoltaic performance of perovskite semiconductor  CsSnI3. Chem. Mater. **26** (2), 6068–6073 (2014). https ://doi.org/10.1021/cm503 122j 

31. S.F. Hoefler, G. Trimmel, T. Rath, Progress on lead-free metal halide perovskites for photovoltaic applications: a review. Monatsh. Chem. **148** (5), 795–826 (2017). https :// doi.org/10.1007/s0070 6-017-1933-9 

32. M. Lyu, J.-H. Yun, P. Chen, M. Hao, L. Wang, Addressing toxicity of lead: progress and applications of low-toxic metal halide perovskites and their derivatives. Adv. Energy Mater. **7** (15), 1602512–1602537 (2017). https ://doi.org/10.1002/ aenm.20160 2512 

33. W. Ming, H. Shi, M.-H. Du, Large dielectric constant, high acceptor density, and deep electron traps in perovskite solar 

1 3 

**62** Page 30 of 36 

Nano-Micro Lett. (2021) 13:62 

cell material  CsGeI3. J. Mater. Chem. A **4** (13), 13852–13875 (2016). https ://doi.org/10.1039/C6TA0 4685A 

34. F. Hong, B. Saparov, W. Meng, Z. Xiao, D.B. Mitzi et al., Viability of lead-free perovskites with mixed chalcogen and halogen anions for photovoltaic applications. J. Phys. Chem. C **120** (12), 6435–6441 (2016). https ://doi.org/10.1021/acs. jpcc.6b009 20 

35. G.E. Eperon, S.D. Stranks, C. Menelaou, M.B. Johnston, L.M. Herz et al., Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. Energy Environ. Sci. **7** (3), 982–989 (2014). https ://doi. org/10.1039/c3ee4 3822h 

36. P. Sun, Q. Li, L. Yang, Z. Li, Theoretical insights into a potential lead-free hybrid perovskite: substituting  Pb<sup>2+</sup> with  Ge<sup>2+</sup> . Nanoscale **8** (3), 1503–1513 (2016). https ://doi. org/10.1039/c5nr0 5337d 

37. Y. Zhao, K. Zhu, Organic-inorganic hybrid lead halide perovskites for optoelectronic and electronic applications. Chem. Soc. Rev. **45** (3), 655–689 (2016). https ://doi.org/10.1039/ c4cs0 0458b 

38. N. Pellet, P. Gao, G. Gregori, T.-Y. Yang, M.K. Nazeeruddin et al., Mixed-organic-cation perovskite photovoltaics for enhanced solar-light harvesting. Angew. Chem. Int. Ed. **53** (12), 3151–3157 (2014). https ://doi.org/10.1002/ anie.20130 9361 

39. N.H. Tiep, Z. Ku, H.J. Fan, Recent advances in improving the stability of perovskite solar cells. Adv. Energy Mater. **6** (3), 1501420–1501456 (2016). https ://doi.org/10.1002/ aenm.20150 1420 

40. Y. Zhang, J. Yin, M.R. Parida, G.H. Ahmed, J. Pan et al., Direct-indirect nature of the bandgap in lead-free perovskite nanocrystals. J. Phys. Chem. Lett. **8** (1), 3173–3188 (2017). https ://doi.org/10.1021/acs.jpcle tt.7b013 81 

41. N.J. Jeon, J.H. Noh, W.S. Yang, Y.C. Kim, S. Ryu et al., Compositional engineering of perovskite materials for highperformance solar cells. Nature **517** (7535), 476–480 (2015). https ://doi.org/10.1038/natur e1413 3 

42. D.E. Starr, G. Sadoughi, E. Handick, R.G. Wilks, J.H. Alsmeier et al., Direct observation of an inhomogeneous chlorine distribution in  CH3NH3PbI3−xClx layers: surface depletion and interface enrichment. Energy Environ. Sci. **8** (5), 1609–1615 (2015). https ://doi.org/10.1039/c5ee0 0403a 

43. S. Dharani, H.A. Dewib, R.R. Prabhakarb, T. Baikieb, C. Shic et al., Incorporation of Cl in sequentially deposited lead halide perovskite films for highly efficient mesoporous solar cells. Nanoscale **6** (22), 13854–13860 (2014). https ://doi. org/10.1039/C4NR0 4007D 

44. W. Zhang, M. Saliba, D.T. Moore, S.K. Pathak, M.T. Hörantner et al., Ultrasmooth organic-inorganic perovskite thin-film formation and crystallization for efficient planar heterojunction solar cells. Nat. Commun. **6** , 6142–6151 (2015). https :// doi.org/10.1038/ncomm s7142 

45. J. Qing, H.-T. Chandran, Y.-H. Cheng, X.-K. Liu, H.-W. Li et al., Chlorine incorporation for enhanced performance of planar perovskite solar cell based on lead acetate precursor. 

ACS Appl. Mater. Interfaces. **7** (41), 23110–23116 (2015). https ://doi.org/10.1021/acsam i.5b068 19 

46. X. Lu, Y. Wang, C.C. Stoumpos, Q. Hu, X. Guo et al., Enhanced structural stability and photo responsiveness of CH3NH3SnI3 perovskite via pressure-induced amorphization and recrystallization. Adv. Mater. **28** (39), 8663–8668 (2016). https ://doi.org/10.1002/adma.20160 0771 

47. M. Jiang, J. Wu, F. Lan, Q. Tao, D. Gao et al., Enhancing the performance of planar organo-lead halide perovskite solar cells by using a mixed halide source. J. Mater. Chem. A **3** (3), 963–967 (2015). https ://doi.org/10.1039/c4ta0 5373g 

48. L. Huang, Z. Hu, G. Yue, J. Liu, X. Cui et al., CH3NH3PbI3−xClx films with coverage approaching 100% and with highly oriented crystal domains for reproducible and efficient planar heterojunction perovskite solar cells. Phys. Chem. Chem. Phys. **17** (34), 22015–22022 (2015). https ://doi. org/10.1039/c5cp0 3934g 

49. T.G. Kim, S.W. Seo, H. Kwon, J. Hahn, J.W. Kim, Influence of halide precursor type and its composition on the electronic properties of vacuum deposited perovskite films. Phys. Chem. Chem. Phys. **17** (37), 24342–24348 (2015). https ://doi.org/10.1039/c5cp0 4207k 

50. J. Albero, A.M. Asiri, H. Garcia, Influence of the composition of hybrid perovskites on their performance in solar cells. J. Mater. Chem. A **4** (12), 4353–4364 (2016). https :// doi.org/10.1039/c6ta0 0334f 

51. B. Ghosh, S. Chakraborty, H. Wei, C. Guet, S. Li et al., Poor photovoltaic performance of  Cs3Bi2I9: an insight through first-principles calculations. J. Phys. Chem. C **121** (32), 17062–17081 (2017). https ://doi.org/10.1021/acs.jpcc.7b035 01 

52. Y. Sun, J. Shi, J. Lian, W. Gao, M.L. Agiorgousis et al., Discovering lead-free perovskite solar materials with a splitanion approach. Nanoscale **8** (12), 6284–6290 (2016). https ://doi.org/10.1039/c5nr0 4310g 

53. G.E. Eperon, C.E. Beck, H.J. Snaith, Cation exchange for thin film lead iodide perovskite interconversion. Mater. Horiz. **3** (1), 63–71 (2016). https ://doi.org/10.1039/c5mh0 0170f 

54. J.H. Heo, S.H. Im, Highly reproducible, efficient hysteresisless  CH3NH3PbI3−xClx planar hybrid solar cells without requiring heat-treatment. Nanoscale **8** (5), 2554–2560 (2016). https ://doi.org/10.1039/c5nr0 8458j 

55. T.M. Brenner, D.A. Egger, L. Kronik, G. Hodes, D. Cahen, Hybrid organic–inorganic perovskites: low-cost semiconductors with intriguing charge-transport properties. Nat. Rev. Mater. **1** , 15007–15023 (2015). https ://doi.org/10.1038/natre vmats .2015.7 

56. N.K. Noel, S.D. Stranks, A. Abate, C. Wehrenfennig, S. Guarnera et al., Lead-free organic-inorganic tin halide perovskites for photovoltaic applications. Energy Environ. Sci. **7** (9), 3061–3068 (2014). https ://doi.org/10.1039/c4ee0 1076k 

57. N. Leblanc, N. Mercier, L. Zorina, S. Simonov, P. AubanSenzier et al., Large spontaneous polarization and clear hysteresis loop of a room-temperature hybrid ferroelectric based on mixed-halide  BiI3Cl2 polar chains and methylviologen 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 31 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

   - dication. J. Am. Chem. Soc. **133** (38), 14924–14927 (2011). https ://doi.org/10.1021/ja206 171s 

58. W. Bi, N. Leblanc, N. Mercier, P. Auban-Senzier, C. Pasquier, Thermally induced Bi(III) lone pair stereoactivity: ferroelectric phase transition and semiconducting properties of (MV)BiBr 5(MV = methylviologen). Chem. Mater. **21** (18), 4099–4101 (2009). https ://doi.org/10.1021/cm901 6003 

59. B.-W. Park, B. Philippe, X. Zhang, H. Rensmo, G. Boschloo et al., Bismuth based hybrid perovskites  A3Bi2I9 (a: methylammonium or cesium) for solar cell application. Adv. Mater. **27** (43), 6806–6813 (2015). https ://doi.org/10.1002/ adma.20150 1978 

60. T. Krishnamoorthy, H. Ding, C. Yan, W.L. Leong, T. Baikie et al., Lead-free germanium iodide perovskite materials for photovoltaic applications. J. Mater. Chem. A **3** (47), 23829– 23832 (2015). https ://doi.org/10.1039/c5ta0 5741h 

61. C.C. Stoumpos, L. Frazer, D.J. Clark, Y.S. Kim, S.H. Rhim et al., Hybrid germanium iodide perovskite semiconductors: active lone pairs, structural distortions, direct and indirect energy gaps, and strong nonlinear optical properties. J. Am. Chem. Soc. **137** (21), 6804–6819 (2015). https ://doi. org/10.1021/jacs.5b010 25 

62. B. Saparov, F. Hong, J.-P. Sun, H.-S. Duan, W. Meng et al., Thin-film preparation and characterization of  Cs3Sb2I9: a lead-free layered perovskite semiconductor. Chem. Mater. **27** (16), 5622–5632 (2015). https ://doi.org/10.1021/acs. chemm ater.5b019 89 

63. D. Cortecchia, H.A. Dewi, J. Yin, A. Bruno, S. Chen et al., Lead-free MA2CuClxBr 4–x hybrid perovskites. Inorg. Chem. **55** (3), 1044–1052 (2016). https ://doi.org/10.1021/ acs.inorg chem.5b018 96 

64. G. Giorgi, J.-I. Fujisawa, H. Segawa, K. Yamashita, Small photocarrier effective masses featuring ambipolar transport in methylammonium lead iodide perovskite: a density functional analysis. J. Phys. Chem. Lett. **4** (24), 4213–4216 (2013). https ://doi.org/10.1021/jz402 3865 

65. J. Feng, B. Xiao, Crystal structures, optical properties, and effective mass tensors of  CH3NH3PbX3 (X = I and Br) phases predicted from HSE06. J. Phys. Chem. Lett. **5** (7), 1278–1282 (2014). https ://doi.org/10.1021/jz500 480m 

66. M.R. Filip, F. Giustino, Computational screening of homovalent lead substitution in organic-inorganic halide perovskites. J. Phys. Chem. C **120** (1), 166–173 (2015). https ://doi. org/10.1021/acs.jpcc.5b118 45 

67. Z. Xiao, Z. Song, Y. Yan, From lead halide perovskites to lead-free metal halide perovskites and perovskite derivatives. Adv. Mater. **31** (47), 1803792–1803813 (2019). https ://doi. org/10.1002/adma.20180 3792 

68. P. Umari, E. Mosconi, F. De Angelis, Relativistic GW calculations on  CH3NH3PbI3 and  CH3NH3SnI3 perovskites for solar cell applications. Sci. Rep. **4** , 4467–4473 (2014). https ://doi.org/10.1038/srep0 4467 

69. F. Li, C. Zhang, J.H. Huang, H. Fan, H. Wang et al., A cationexchange approach for the fabrication of efficient methylammonium tin iodide perovskite solar cells. Angew. Chem. 

   - Int. Ed. **58** (20), 6688–6692 (2019). https ://doi.org/10.1002/ anie.20190 2418 

70. F. Hao, C.C. Stoumpos, D.H. Cao, R.P.H. Chang, M.G. Kanatzidis, Lead-free solid-state organic-inorganic halide perovskite solar cells. Nat. Photon. **8** (6), 489–494 (2014). https ://doi.org/10.1038/nphot on.2014.82 

71. M.H. Kumar, S. Dharani, W.L. Leong, P.P. Boix, R.R. Prabhakar et al., Lead-free halide perovskite solar cells with high photocurrents realized through vacancy modulation. Adv. Mater. **26** (41), 7122–7127 (2014). https ://doi.org/10.1002/ adma.20140 1991 

72. J.H. Noh, S.H. Im, J.H. Heo, T.N. Mandal, S.I. Seok, Chemical management for colorful, efficient, and stable inorganicorganic hybrid nanostructured solar cells. Nano Lett. **13** (4), 1764–1769 (2013). https ://doi.org/10.1021/nl400 349b 

73. T. Yokoyama, D.H. Cao, C.C. Stoumpos, T.B. Song, Y. Sato et al., Overcoming short-circuit in lead-free  CH3NH3SnI3 perovskite solar cells via kinetically controlled gas-solid reaction film fabrication process. J. Phys. Chem. Lett. **7** (5), 776–782 (2016). https ://doi.org/10.1021/acs.jpcle tt.6b001 18 

74. F. Hao, C.C. Stoumpos, P. Guo, N. Zhou, T.J. Marks et al., Solvent-mediated crystallization of  CH3NH3SnI3 films for heterojunction depleted perovskite solar cells. J. Am. Chem. Soc. **137** (35), 11445–11452 (2015). https ://doi.org/10.1021/ jacs.5b066 58 

75. M. Weiss, J. Horn, C. Richter, D. Schlettwein, Preparation and characterization of methylammonium tin iodide layers as photovoltaic absorbers. Phys. Status Solidi A **213** (4), 975–981 (2016). https ://doi.org/10.1002/pssa.20153 2594 

76. S. Chen, A. Walsh, X.G. Gong, S.-H. Wei, Classification of lattice defects in the kesterite  Cu2ZnSnS4 and  Cu2ZnSnSe4 earth-abundant solar cell absorbers. Adv. Mater. **25** (11), 1522–1539 (2013). https ://doi.org/10.1002/adma.20120 3146 

77. M.C. Jung, S.R. Raga, Y. Qi, Properties and solar cell applications of Pb-free perovskite films formed by vapor deposition. RSC Adv. **6** (4), 2819–2825 (2016). https ://doi.org/10.1039/ c5ra2 1291j 

78. D.E. Scaife, P.F. Weller, W.G. Fisher, Crystal preparation and properties of cesium tin(ii) trihalides. J. Solid State Chem. **9** (3), 308–314 (1974). https ://doi.org/10.1016/00224596(74)90088 -7 

79. Z. Chen, J.J. Wang, Y. Ren, C. Yu, K. Shum, Schottky solar cells based on  CsSnI3 thin-films. Appl. Phys. Lett. **101** (9), 093901–093904 (2012). https ://doi.org/10.1063/1.47488 88 

80. D. Sabba, H.K. Mulmudi, R.R. Prabhakar, T. Krishnamoorthy, T. Baikie et al., Impact of anionic Br- substitution on open circuit voltage in lead free perovskite  (CsSnI3−xBrx) solar cells. J. Phys. Chem. C **119** (4), 1763–1767 (2015). https ://doi.org/10.1021/jp512 6624 

81. Y. Zhou, H.F. Garces, B.S. Senturk, A.L. Ortiz, N.P. Padture, Roomtemperature “one-pot” solution synthesis of nanoscale CsSnI3 orthorhombic perovskite thin films andparticles. Mater. Lett. **110** , 127–129 (2013). https ://doi.org/10.1016/j. matle t.2013.08.011 

82. S. Dharani, H.K. Mulmudi, N. Yantara, P.T. Thu-Trang, N.G. Park et al., High efficiency electrospun  TiO2 nanofiber based 

1 3 

**62** Page 32 of 36 

Nano-Micro Lett. (2021) 13:62 

hybrid organic-inorganic perovskite solar cell. Nanoscale **6** (3), 1675–1679 (2014). https ://doi.org/10.1039/c3nr0 4857h 

83. K. Shum, Z. Chen, J. Qureshi, C. Yu, J.J. Wang et al., Synthesis and characterization of  CsSNi3 thin films. Appl. Phys. Lett. **96** (22), 221903 (2010). https ://doi.org/10.1063/1.34425 11 

84. I. Chung, J.H. Song, J. Im, J. Androulakis, C.D. Malliakas et al.,  CsSnI3: semiconductor or metal? High electrical conductivity and strong near-infrared photoluminescence from a single material. High hole mobility and phase-transitions. J. Am. Chem. Soc. **134** (20), 8579–8587 (2012). https ://doi. org/10.1021/ja301 539s 

85. K.P. Marshall, R.I. Walton, R.A. Hatton, Tin perovskite/ fullerene planar layer photovoltaics: improving the efficiency and stability of lead-free devices. J. Mater. Chem. A **3** (21), 11631–11640 (2015). https ://doi.org/10.1039/c5ta0 2950c 

86. L. Liang, P. Gao, Lead-free hybrid perovskite absorbers for viable application: can we eat the cake and have it too? Adv. Sci. **5** (2), 1700331–1700364 (2018). https ://doi.org/10.1002/ advs.20170 0331 

87. S.J. Lee, S.S. Shin, Y.C. Kim, D. Kim, T.K. Ahn et al., Fabrication of efficient formamidinium tin iodide perovskite solar cells through  SnF2-pyrazine complex. J. Am. Chem. Soc. **138** (12), 3974–3977 (2016). https ://doi.org/10.1021/ jacs.6b001 42 

88. Z. Zhao, F. Gu, Y. Li, W. Sun, S. Ye et al., Mixed-organiccation tin iodide for lead-free perovskite solar cells with an efficiency of 8.12. Adv. Sci. **4** (11), 1700204–1700210 (2017). https ://doi.org/10.1002/advs.20170 0204 

89. W. Ke, C.C. Stoumpos, M. Zhu, L. Mao, I. Spanopoulos et al., Enhanced photovoltaic performance and stability with a new type of hollow 3D perovskite {en}FASnI3. Sci. Adv. **3** (8), e1701293–e1701301 (2017). https ://doi.org/10.1126/sciad v.17012 93 

90. K.P. Marshall, M. Walker, R.I. Walton, R.A. Hatton, Enhanced stability and efficiency in hole-transport-layer-free CsSnI3 perovskite photovoltaics. Nat. Energy **1** (12), 16178– 16186 (2016). https ://doi.org/10.1038/nener gy.2016.178 

91. M. Zhang, M. Lyu, J.H. Yun, M. Noori, X. Zhou et al., Low-temperature processed solar cells with formamidinium tin halide perovskite/fullerene heterojunctions. Nano Res. **9** (6), 1570–1577 (2016). https ://doi.org/10.1007/s1227 4-016-1051-8 

92. R.L. Milot, G.E. Eperon, T. Green, H.J. Snaith, M.B. Johnston et al., Radiative monomolecular recombination boosts amplified spontaneous emission in HC(NH2)2SnI3 perovskite films. J. Phys. Chem. Lett. **7** (20), 4178–4184 (2016). https :// doi.org/10.1021/acs.jpcle tt.6b020 30 

93. Y. Dang, Y. Zhou, X. Liu, D. Ju, S. Xia, H. Xia, X. Tao, Formation of hybrid perovskite tin iodide single crystals by top-seeded solution growth. Angew. Chem. Int. Ed. **55** (10), 3447–3450 (2016). https ://doi.org/10.1002/anie.20151 1792 

94. D.B. Mitzi, K. Liang, Synthesis, resistivity, and thermal properties of the cubic perovskite  NH2CH5NH2SnI3 and related systems. J. Solid State Chem. **134** (2), 376–381 (1997). https ://doi.org/10.1006/jssc.1997.7593 

95. Z. Zhu, C.C. Chueh, N. Li, C. Mao, A.K.-Y. Jen, Realizing efficient lead-free formamidinium tin triiodide perovskite solar cells via a sequential deposition route. Adv. Mater. **30** (6), 1703800–1703808 (2018). https ://doi.org/10.1002/ adma.20170 3800 

96. W. Liao, D. Zhao, Y. Yu, C.R. Grice, C. Wang et al., Leadfree inverted planar formamidinium tin triiodide perovskite solar cells achieving power conversion efficiencies up to 622. Adv. Mater. **28** (42), 9333–9340 (2016). https ://doi. org/10.1002/adma.20160 2992 

97. W. Ke, C.C. Stoumpos, J.L. Logsdon, M.R. Wasielewski, Y. Yan et al.,  Tio2-zns cascade electron transport layer for efficient formamidinium tin iodide perovskite solar cells. J. Am. Chem. Soc. **138** (45), 14998–15003 (2016). https ://doi. org/10.1021/jacs.6b087 90 

98. F. Wang, J. Ma, F. Xie, L. Li, J. Chen et al., Organic cationdependent degradation mechanism of organotin halide perovskites. Adv. Funct. Mater. **26** (20), 3417–3423 (2016). https ://doi.org/10.1002/adfm.20150 5127 

99. T.M. Koh, T. Krishnamoorthy, N. Yantara, C. Shi, W.L. Leong et al., Formamidinium tin-based perovskite with low Eg for photovoltaic applications. J. Mater. Chem. A **3** (29), 14996–15000 (2015). https ://doi.org/10.1039/c5ta0 0190k 

100. F. Gu, S. Ye, Z. Zhao, H. Rao, Z. Liu et al., Improving performance of lead-free formamidinium tin triiodide perovskite solar cells by tin source purification. Sol. RRL **2** (10), 1870217 (2018). https ://doi.org/10.1002/solr.20187 0217 

101. Z. Lin, C. Liu, G. Liu, J. Yang, X. Duan et al., Efficient inverted tin-based perovskite solar cells via bidentate coordination effect of 8-Hydroxyquinoline. Chem. Commun. **56** (28), 4007–4010 (2020). https ://doi.org/10.1039/d0cc0 1106a 

102. J. Cao, Q. Tai, P. You, G. Tang, T. Wang et al., Enhanced performance of tin-based perovskite solar cells induced by an ammonium hypophosphite additive. J. Mater. Chem. A **7** (46), 26580–26585 (2019). https ://doi.org/10.1039/c9ta0 8679j 

103. T. Wu, X. Liu, X. He, Y. Wang, X. Meng et al., Efficient and stable tin-based perovskite solar cells by introducing π-conjugated lewis base. Sci. China Chem. **63** (1), 107–115 (2019). https ://doi.org/10.1007/s1142 6-019-9653-8 

104. X. Meng, T. Wu, X. Liu, X. He, T. Noda et al., Highly reproducible and efficient  FASnI3 perovskite solar cells fabricated with volatilizable reducing solvent. J. Phys. Chem. Lett. **11** (8), 2965–2971 (2020). https ://doi.org/10.1021/acs.jpcle tt.0c009 23 

105. M. Saliba, T. Matsui, K. Domanski, J.-Y. Seo, A. Ummadisingu et al., Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science **354** (6309), 206–209 (2016). https ://doi.org/10.1126/scien ce.aah55 57 

106. N.J. Jeon, J.H. Noh, Y.C. Kim, W.S. Yang, S. Ryu et al., Solvent engineering for high-performance inorganic-organic hybrid perovskite solar cells. Nat. Mater. **13** (9), 897–903 (2014). https ://doi.org/10.1038/nmat4 014 

107. N. Ahn, D.-Y. Son, I.-H. Jang, S.M. Kang, M. Choi et al., Highly reproducible perovskite solar cells with average 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 33 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

   - efficiency of 18.3% and best efficiency of 19.7% fabricated via lewis base adduct of lead(ii) iodide. J. Am. Chem. Soc. **137** (27), 8696–8699 (2015). https ://doi.org/10.1021/ jacs.5b049 30 

108. W. Ke, C.C. Stoumpos, I. Spanopoulos, L. Mao, M. Chen et al., Efficient lead-free solar cells based on hollow {en} MASnI3 perovskites. J. Am. Chem. Soc. **139** (41), 14800– 14806 (2017). https ://doi.org/10.1021/jacs.7b090 18 

109. W. Ke, C.C. Stoumpos, I. Spanopoulos, M. Chen, M.R. Wasielewski et al., Diammonium cations in the  FASnI3 perovskite structure lead to lower dark currents and more efficient solar cells. ACS Energy Lett. **3** (7), 1470–1476 (2018). https ://doi.org/10.1021/acsen ergyl ett.8b006 87 

110. X. Li, D. Bi, C. Yi, J.D. Décoppet, J. Luo et al., A vacuum flash-assisted solution process for high-efficiency large-area perovskite solar cells. Science **353** , 58–62 (2016). https ://doi. org/10.1126/scien ce.aaf80 60 

111. F. Xu, T. Zhang, G. Li, Y. Zhao, Mixed cation hybrid lead halide perovskites with enhanced performance and stability. J. Mater. Chem. A **5** (23), 11450–11461 (2017). https ://doi. org/10.1039/c7ta0 0042a 

112. H. Tan, A. Jain, O. Voznyy, X. Lan, F.P.G. Arquer et al., Efficient and stable solution-processed planar perovskite solar cells via contact passivation. Science **355** (6326), 722–726 (2017). https ://doi.org/10.1126/scien ce.aai90 81 

113. W.S. Yang, B.-W. Park, E.H. Jung, N.J. Jeon, Y.C. Kim et al., Iodide management in formamidinium-lead-halide-based perovskite layers for efficient solar cells. Science **356** (6345), 1376–1379 (2017). https ://doi.org/10.1126/scien ce.aan23 01 

114. X. Liu, Z. Yang, C.C. Chueh, A. Rajagopal, S.T. Williams et al., Improved efficiency and stability of Pb-Sn binary perovskite solar cells by cs substitution. J. Mater. Chem. A **4** (46), 17939–17945 (2016). https ://doi.org/10.1039/c6ta0 7712a 

115. I.C. Smith, E.T. Hoke, D. Solis-Ibarra, M.D. McGehee, H.I. Karunadasa, A layered hybrid perovskite solar-cell absorber with enhanced moisture stability. Angew. Chem. Int. Ed. **53** (42), 11232–11235 (2014). https ://doi.org/10.1002/ anie.20140 6466 

116. W. Peng, J. Yin, K.T. Ho, O. Ouellette, M. De Bastiani et al., Ultralow self-doping in two-dimensional hybrid perovskite single crystals. Nano Lett. **17** (8), 4759–4767 (2017). https :// doi.org/10.1021/acs.nanol ett.7b014 75 

117. Y. Lin, Y. Bai, Y. Fang, Q. Wang, Y. Deng et al., Suppressed ion migration in low-dimensional perovskites. ACS Energy Lett. **2** (7), 1571–1572 (2017). https ://doi.org/10.1021/acsen ergyl ett.7b004 42 

118. C.-M. Tsai, Y.-P. Lin, M.K. Pola, S. Narra, E. Jokar et al., Control of crystal structures and optical properties with hybrid formamidinium and 2-hydroxyethylammonium cations for mesoscopic carbon-electrode tin-based perovskite solar cells. ACS Energy Lett. **3** (9), 2077–2085 (2018). https ://doi.org/10.1021/acsen ergyl ett.8b010 46 

119. E. Jokar, C.H. Chien, C.M. Tsai, A. Fathi, E.W. Diau, Robust tin-based perovskite solar cells with hybrid organic cations to attain efficiency approaching 10%. Adv. Mater. **31** (2), e1804835 (2019). https ://doi.org/10.1002/adma.20180 4835 

120. D.H. Cao, C.C. Stoumpos, T. Yokoyama, J.L. Logsdon, T.-B. Song et al., Thin films and solar cells based on semiconducting two-dimensional ruddlesden-popper (CH3(CH2)3NH3)2(CH3NH3)n−1SnnI3n+1 perovskites. ACS Energy Lett. **2** (5), 982–990 (2017). https ://doi.org/10.1021/ acsen ergyl ett.7b002 02 

121. K. Yao, X. Wang, Y. Xu, F. Li, L. Zhou, Multilayered perovskite materials based on polymeric-ammonium cations for stable large-area solar cell. Chem. Mater. **28** (9), 3131–3138 (2016). https ://doi.org/10.1021/acs.chemm ater.6b007 11 

122. C. Ma, C. Leng, Y. Ji, X. Wei, K. Sun et al., 2D/3D perovskite hybrids as moisture-tolerant and efficient light absorbers for solar cells. Nanoscale **8** (43), 18309–18314 (2016). https :// doi.org/10.1039/c6nr0 4741f 

123. F. Wang, X. Jiang, H. Chen, Y. Shang, H. Liu et al., 2D-quasi2D-3D hierarchy structure for tin perovskite solar cells with enhanced efficiency and stability. Joule **2** (12), 2732–2743 (2018). https ://doi.org/10.1016/j.joule .2018.09.012 

124. X. Zhang, G. Wu, W. Fu, M. Qin, W. Yang et al., Orientation regulation of phenylethylammonium cation based 2D perovskite solar cell with efficiency higher than 11%. Adv. Energy Mater. **8** (14), 1702498 (2018). https ://doi.org/10.1002/ aenm.20170 2498 

125. A.Z. Chen, M. Shiu, J.H. Ma, M.R. Alpert, D. Zhang et al., Origin of vertical orientation in two-dimensional metal halide perovskites and its effect on photovoltaic performance. Nat. Commun. **9** (1), 1336 (2018). https ://doi.org/10.1038/s4146 7-018-03757 -0 

126. J. Qiu, Y. Xia, Y. Zheng, W. Hui, H. Gu et al., 2D intermediate suppression for efficient ruddlesden-popper (RP) phase lead-free perovskite solar cells. ACS Energy Lett. **4** (7), 1513– 1520 (2019). https ://doi.org/10.1021/acsen ergyl ett.9b009 54 

127. Y. Liao, H. Liu, W. Zhou, D. Yang, Y. Shang et al., Highly oriented low-dimensional tin halide perovskites with enhanced stability and photovoltaic performance. J. Am. Chem. Soc. **139** (19), 6693–6699 (2017). https ://doi. org/10.1021/jacs.7b018 15 

128. H. Xu, Y. Jiang, T. He, S. Li, H. Wang et al., Orientation regulation of tin-based reduced-dimensional perovskites for highly efficient and stable photovoltaics. Adv. Funct. Mater. **29** (47), 1807696 (2019). https ://doi.org/10.1002/adfm.20180 7696 

129. J. Wang, H. Shen, W. Li, S. Wang, J. Li et al., The role of chloride incorporation in lead-free 2D perovskite (BA)2SnI4: morphology, photoluminescence, phase transition, and charge transport. Adv. Sci. **6** (5), 1802019 (2019). https ://doi. org/10.1002/advs.20180 2019 

130. M. Chen, M.G. Ju, M.Y. Hu, Z.H. Dai, Y. Hu et al., Lead-free dion-jacobson tin halide perovskites for photovoltaics. ACS Energy Lett. **4** (1), 276–277 (2019). https ://doi.org/10.1021/ acsen ergyl ett.8b020 51 

131. B.E. Cohen, Y. Li, Q. Meng, L. Etgar, Dion-jacobson twodimensional perovskite solar cells based on benzene dimethanammonium cation. Nano Lett. **19** (4), 2588–2597 (2019). https ://doi.org/10.1021/acs.nanol ett.9b003 87 

1 3 

**62** Page 34 of 36 

Nano-Micro Lett. (2021) 13:62 

132. C. Ma, D. Shen, T.W. Ng, M.F. Lo, C.S. Lee, 2D perovskites with short interlayer distance for high-performance solar cell application. Adv. Mater. **30** (22), 1800710–1800715 (2018). https ://doi.org/10.1002/adma.20180 0710 

133. C.C. Stoumpos, L. Mao, C.D. Malliakas, M.G. Kanatzidis, Structure-bandgap relationships in hexagonal polytypes and low-dimensional structures of hybrid tin iodide perovskites. Inorg. Chem. **56** (1), 56–73 (2017). https ://doi.org/10.1021/ acs.inorg chem.6b027 64 

134. G. Kieslich, S. Sun, A.K. Cheetham, Solid-state principles applied to organic-inorganic perovskites: new tricks for an old dog. Chem. Sci. **5** (12), 4712–4715 (2014). https ://doi. org/10.1039/c4sc0 2211d 

135. X. Jiang, F. Wang, Q. Wei, H. Li, Y. Shang et al., Ultra-high open-circuit voltage of tin perovskite solar cells via an electron transporting layer design. Nat. Commun. **11** (1), 1245– 1251 (2020). https ://doi.org/10.1038/s4146 7-020-15078 -2 

136. C. Wang, F. Gu, Z. Zhao, H. Rao, Y. Qiu et al., Self-repairing tin-based perovskite solar cells with a breakthrough efficiency over 11. Adv. Mater. **32** (31), e1907623–e1907631 (2020). https ://doi.org/10.1002/adma.20190 7623 

137. F. Hao, C.C. Stoumpos, R.P.H. Chang, M.G. Kanatzidis, Anomalous bandgap behavior in mixed Sn and Pb perovskites enables broadening of absorption spectrum in solar cells. J. Am. Chem. Soc. **136** (22), 8094–8099 (2014). https ://doi. org/10.1021/ja503 3259 

138. H.D. Kim, Y. Miyamoto, H. Kubota, T. Yamanari, H. Ohkita, Open-circuit voltage loss in  CH3NH3SnI3 perovskite solar cells. Chem. Lett. **46** , 253–256 (2017). https ://doi. org/10.1246/cl.16099 4 

139. T. Handa, T. Yamada, H. Kubota, S. Ise, Y. Miyamoto et al., Photocarrier recombination and injection dynamics in longterm stable lead-free  CH3NH3SnI3 perovskite thin films and solar cells. J. Phys. Chem. C **121** (30), 16158–16165 (2017). https ://doi.org/10.1021/acs.jpcc.7b061 99 

140. W. Ke, P. Priyanka, S. Vegiraju, C.C. Stoumpos, I. Spanopoulos et al., Dopant-free tetrakis-triphenylamine hole transporting material for efficient tin-based perovskite solar cells. J. Am. Chem. Soc. **140** (1), 388–393 (2018). https ://doi. org/10.1021/jacs.7b108 98 

141. T. Yokoyama, T.-B. Song, D.H. Cao, C.C. Stoumpos, S. Aramaki et al., The origin of lower hole carrier concentration in methylammonium tin halide films grown by a vapor-assisted solution process. ACS Energy Lett. **2** (1), 22–28 (2016). https ://doi.org/10.1021/acsen ergyl ett.6b005 13 

142. S.A. Moyez, S. Roy, Thermal engineering of lead-free nanostructured  CH3NH3SnCl3 perovskite material for thin-film solar cell. J. Nanopart. Res. **20** (1), 5–17 (2017). https ://doi. org/10.1007/s1105 1-017-4108-z 

143. N. Wang, Y. Zhou, M.-G. Ju, H.F. Garces, T. Ding et al., Heterojunction-depleted lead-free perovskite solar cells with coarse-grained b-γ-CsSnI3 thin films. Adv. Energy Mater. **6** (24), 1601130–1601139 (2016). https ://doi.org/10.1002/ aenm.20160 1130 

144. T.B. Song, T. Yokoyama, C.C. Stoumpos, J. Logsdon, D.H. Cao et al., Importance of reducing vapor atmosphere in the 

   - fabrication of tin-based perovskite solar cells. J. Am. Chem. Soc. **139** (2), 836–842 (2017). https ://doi.org/10.1021/ jacs.6b107 34 

145. B. Zhao, M. Abdi-Jalebi, M. Tabachnyk, H. Glass, V.S. Kamboj et al., High open-circuit voltages in tin-rich lowbandgap perovskite-based planar heterojunction photovoltaics. Adv. Mater. **29** (2), 1604744–1604751 (2017). https ://doi. org/10.1002/adma.20160 4744 

146. S. Shao, J. Liu, G. Portale, H.-H. Fang, G.R. Blake et al., Highly reproducible Sn-based hybrid perovskite solar cells with 9% efficiency. Adv. Energy Mater. **8** (4), 1702019– 1702028 (2018). https ://doi.org/10.1002/aenm.20170 2019 

147. L.-J. Chen, C.-R. Lee, Y.-J. Chuang, Z.-H. Wu, C. Chen, Synthesis and optical properties of lead-free cesium tin halide perovskite quantum rods with high-performance solar cell application. J. Phys. Chem. Lett. **7** (24), 5028–5035 (2016). https ://doi.org/10.1021/acs.jpcle tt.6b023 44 

148. J. Xi, Z. Wu, B. Jiao, H. Dong, C. Ran et al., Multichannel interdiffusion driven  FASnI3 film formation using aqueous hybrid salt/polymer solutions toward flexible lead-free perovskite solar cells. Adv. Mater. **29** (23), 1606964–1606970 (2017). https ://doi.org/10.1002/adma.20160 6964 

149. D. Moghe, L. Wang, C.J. Traverse, A. Redoute, M. Sponseller et al., All vapor-deposited lead-free doped CsSnBr 3 planar solar cells. Nano Energy **28** , 469–474 (2016). https :// doi.org/10.1016/j.nanoe n.2016.09.009 

150. C. Ran, J. Xi, W. Gao, F. Yuan, T. Lei et al., Bilateral interface engineering toward efficient 2D-3D bulk heterojunction tin halide lead-free perovskite solar cells. ACS Energy Lett. **3** (3), 713–721 (2018). https ://doi.org/10.1021/acsen ergyl ett.8b000 85 

151. Y. Yu, D. Zhao, C.R. Grice, W. Meng, C. Wang et al., Thermally evaporated methylammonium tin triiodide thin films for lead-free perovskite solar cell fabrication. RSC Adv. **6** (93), 90248–90254 (2016). https ://doi.org/10.1039/c6ra1 9476a 

152. C.-M. Tsai, N. Mohanta, C.-Y. Wang, Y.-P. Lin, Y.-W. Yang et al., Formation of stable tin perovskites co-crystallized with three halides for carbon-based mesoscopic lead-free perovskite solar cells. Angew. Chem. Int. Ed. **56** (44), 13819–13823 (2017). https ://doi.org/10.1002/anie.20170 7037 

153. W. Li, J. Li, J. Li, J. Fan, Y. Maib et al., Addictive-assisted construction of all-inorganic CsSnIBr 2 mesoscopic perovskite solar cells with superior thermal stability up to 473 K. J. Mater. Chem. A **4** , 17104–17110 (2016). https ://doi. org/10.1039/c6ta0 8332c 

154. K. Chen, P. Wu, W. Yang, R. Su, D. Luo et al., Lowdimensional perovskite interlayer for highly efficient leadfree formamidinium tin iodide perovskite solar cells. Nano Energy **49** , 411–418 (2018). https ://doi.org/10.1016/j.nanoe n.2018.05.006 

155. E. Jokar, C.-H. Chien, A. Fathi, M. Rameez, C.-Y. Hao et al., Slow surface passivation and crystal relaxation with additives to improve device performance and durability for tinbased perovskite solar cells. Energy Environ. Sci. **11** (9), 1–12 (2018). https ://doi.org/10.1039/C8EE0 0956B 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

Page 35 of 36 **62** 

Nano-Micro Lett. (2021) 13:62 

156. X.Y. Meng, Y.B. Wang, J.B. Lin, X. Liu, X. He et al., Surface-controlled oriented growth of  FASnI3 crystals for efficient lead-free perovskite solar cells. Joule **4** , 902–912 (2020). https ://doi.org/10.1016/j.joule .2020.03.007 

157. L.-C. Tang, C.-S. Chang, J.Y. Huang, Electronic structure and optical properties of rhombohedral  CsGeI3 crystal. J. Phys.: Condens. Matter **12** (43), 9129–9143 (2000). https :// doi.org/10.1088/0953-8984/12/43/303 

158. I. Kopacic, B. Friesenbichler, S.F. Hoefler, B. Kunert, H. Plank et al., Enhanced performance of germanium halide perovskite solar cells through compositional engineering. ACS Appl. Energy Mater. **1** (2), 343–347 (2018). https ://doi. org/10.1021/acsae m.8b000 07 

159. M.F. Mostafa, R.D. Willett, Magnetic properties of ferrous chloride complexes with two-dimensional structures. Phys. Rev. B **4** (7), 2213–2215 (1971). https ://doi.org/10.1103/ PhysR evB.4.2213 

160. S.N. Ruddlesden, P. Popper, New compounds of the  K2NiF4 type. Acta Cryst. **10** (8), 538–539 (1957). https ://doi. org/10.1107/S0365 110X5 70019 29 

161. X.-P. Cui, K.-J. Jiang, J.-H. Huang, Q.-Q. Zhang, M.-J. Su et al., Cupric bromide hybrid perovskite heterojunction solar cells. Synth. Met. **209** , 247–250 (2015). https ://doi. org/10.1016/j.synth met.2015.07.013 

162. X. Li, B. Li, J. Chang, B. Ding, S. Zheng et al., (C6H5CH2NH3)2CuBr 4: a lead-free, highly stable twodimensional perovskite for solar cell applications. ACS Appl. Energy Mater. **1** (6), 2709–2716 (2018). https ://doi. org/10.1021/acsae m.8b003 72 

163. M. Abulikemu, S. Ould-Chikh, X. Miao, E. Alarousu, B. Murali et al., Optoelectronic and photovoltaic properties of the air-stable organohalide semiconductor  (CH3NH3)3Bi2I9. J. Mater. Chem. A **4** (32), 12504–12515 (2016). https ://doi. org/10.1039/c6ta0 4657f 

164. R.L.Z. Hoye, R.E. Brandt, A. Osherov, V. Stevanović, S.D. Stranks et al., Methylammonium bismuth iodide as a leadfree, stable hybrid organic-inorganic solar absorber. Chem. Eur. J. **22** (8), 2605–2610 (2016). https ://doi.org/10.1002/ chem.20150 5055 

165. Z. Zhang, X. Li, X. Xia, Z. Wang, Z. Huang et al., High-quality  (CH3NH3)3Bi2I9 film-based solar cells: pushing efficiency up to 1.64. J. Phys. Chem. Lett. **8** (17), 4300–4307 (2017). https ://doi.org/10.1021/acs.jpcle tt.7b019 52 

166. C. Ran, Z. Wu, J. Xi, F. Yuan, H. Dong et al., Construction of compact methylammonium bismuth iodide film promoting lead-free inverted planar heterojunction organohalide solar cells with open-circuit voltage over 0.8 V. J. Phys. Chem. Lett. **8** (2), 394–400 (2017). https ://doi.org/10.1021/acs.jpcle tt.6b025 78 

167. M.B. Johansson, H. Zhu, E.M. Johansson, Extended photoconversion spectrum in low-toxic bismuth halide perovskite solar cells. J. Phys. Chem. Lett. **7** (17), 3467–3471 (2016). https ://doi.org/10.1021/acs.jpcle tt.6b014 52 

168. A.K. Baranwal, H. Masutani, H. Sugita, H. Kanda, S. Kanaya et al., Lead-free perovskite solar cells using Sb and Bi-based A3B2X9 and  A3BX6 crystals with normal and inverse cell 

structures. Nano Converg. **4** (1), 26–39 (2017). https ://doi. org/10.1186/s4058 0-017-0120-3 

169. M. Lyu, J.-H. Yun, M. Cai, Y. Jiao, P.V. Bernhardt et al., Organic-inorganic bismuth (III)-based material: a lead-free, air-stable and solution-processable light-absorber beyond organolead perovskites. Nano Res. **9** (3), 692–702 (2016). https ://doi.org/10.1007/s1227 4-015-0948-y 

170. S.S. Shin, O.P.C. Baena, O.C. Kurchin, O. Polizzotti, O.J. Yoo et al., Solvent-engineering method to deposit compact bismuth-based thin films: mechanism and application to photovoltaics. Chem. Mater. **30** (2), 336–343 (2018). https ://doi. org/10.1021/acs.chemm ater.7b032 27 

171. S.M. Jain, D. Phuyal, M.L. Davies, M. Li, B. Philippe et al., An effective approach of vapour assisted morphological tailoring for reducing metal defect sites in leadfree,  (CH3NH3)3Bi2I9 bismuth-based perovskite solar cells for improved performance and long-term stability. Nano Energy **49** , 614–624 (2018). https ://doi.org/10.1016/j.nanoe n.2018.05.003 

172. F. Bai, Y. Hu, Y. Hu, T. Qiu, X. Miao et al., Lead-free, airstable ultrathin  Cs3Bi2I9 perovskite nanosheets for solar cells. Sol. Energy Mater. Sol. Cells **184** , 15–21 (2018). https ://doi. org/10.1016/j.solma t.2018.04.032 

173. J.-C. Hebig, I. Kühn, J. Flohre, T. Kirchartz, Optoelectronic properties of  (CH3NH3)3Sb2I9 thin films for photovoltaic applications. ACS Energy Lett. **1** (1), 309–314 (2016). https ://doi.org/10.1021/acsen ergyl ett.6b001 70 

174. P.C. Harikesh, H.K. Mulmudi, B. Ghosh, T.W. Goh, Y.T. Teng et al., Rb as an alternative cation for templating inorganic lead-free perovskites for solution processed photovoltaics. Chem. Mater. **28** (20), 7496–7504 (2016). https ://doi. org/10.1021/acs.chemm ater.6b033 10 

175. C. Zuo, L. Ding, Lead-free perovskite materials (NH4)3Sb2IxBr 9–x. Angew. Chem. Int. Ed. **56** (23), 6528– 6532 (2017). https ://doi.org/10.1002/anie.20170 2265 

176. F. Jiang, D. Yang, Y. Jiang, T. Liu, X. Zhao et al., Chlorineincorporation-induced formation of the layered phase for antimony-based lead-free perovskite solar cells. J. Am. Chem. Soc. **140** (3), 1019–1027 (2018). https ://doi.org/10.1021/ jacs.7b107 39 

177. W. Shockley, H.J. Queisser, Detailed balance limit of efficiency of p-n junction solar cells. J. Appl. Phys. **32** (3), 510– 519 (1961). https ://doi.org/10.1063/1.17360 34 

178. T. Li, X. Wang, Y. Yan, D.B. Mitzi, Phase stability and electronic structure of prospective sb-based mixed sulfide and iodide 3D perovskite  (CH3NH3)SbSI2. J. Phys. Chem. Lett. **9** (14), 3829–3833 (2018). https ://doi.org/10.1021/acs.jpcle tt.8b016 41 

179. A. Antonio, Perovskite solar cells go lead free. Joule **1** (4), 659–664 (2017). https ://doi.org/10.1016/j.joule .2017.09.007 

180. Y. Cai, W. Xie, H. Ding, Y. Chen, T. Krishnamoorthy et al., Computational study of halide perovskite-derived  A2BX6 inorganic compounds: chemical trends in electronic structure and structural stability. Chem. Mater. **29** (18), 7740 (2017). https ://doi.org/10.1021/acs.chemm ater.7b020 13 

1 3 

**62** Page 36 of 36 

Nano-Micro Lett. (2021) 13:62 

181. A.E. Maughan, J.A. Kurzman, J.R. Neilson, Hybrid inorganic-organic materials with an optoelectronically active aromatic cation:  (C7H7)2SnI6 and  C7H7PbI3. Inorg. Chem. **54** (1), 370–378 (2015). https ://doi.org/10.1021/ic502 5795 

182. M.M. Elsenety, A. Kaltzoglou, M. Antoniadou, I. Koutselas, A.G. Kontos et al., Synthesis, characterization and use of highly stable trimethyl sulfonium tin(IV) halide defect perovskites in dye sensitized solar cells. Polyhedron **150** , 83–91 (2018). https ://doi.org/10.1016/j.poly.2018.05.001 

183. X. Qiu, Y. Jiang, H. Zhang, Z. Qiu, S. Yuan et al., Lead-free mesoscopic  Cs2SnI6 perovskite solar cells using different nanostructured ZnO nanorods as electron transport layers. Phys. Status Solid. RRL **10** (8), 587–591 (2016). https ://doi. org/10.1002/pssr.20160 0166 

184. B. Lee, A. Krenselewski, S. Il-Baik, D. Seidman, R.P.H. Chang, Solution processing of air-stable molecular semiconducting iodosalts,  Cs2SnI6−xBrx, for potential solar cell applications. Sustain. Energy Fuels **1** (4), 710–724 (2017). https ://doi.org/10.1039/c7se0 0100b 

185. A.E. Maughan, A.M. Ganose, M.M. Bordelon, E.M. Miller, D.O. Scanlon et al., Defect tolerance to intolerance in the vacancy-ordered double perovskite semiconductors  Cs2SnI6 and  Cs2TeI6. J. Am. Chem. Soc. **138** (27), 8453–8464 (2016). https ://doi.org/10.1021/jacs.6b032 07 

186. M. Chen, M.-G. Ju, A.D. Carl, Y. Zong, R.L. Grimm et al., Cesium titanium(IV) bromide thin films based stable leadfree perovskite solar cells. Joule **2** (3), 558–570 (2018). https ://doi.org/10.1016/j.joule .2018.01.009 

187. E. Greul, M.L. Petrus, A. Binek, P. Docampo, T. Bein, Highly stable, phase pure Cs2AgBiBr 6 double perovskite thin films for optoelectronic applications. J. Mater. Chem. A **5** (37), 19972–19981 (2017). https ://doi.org/10.1039/c7ta0 6816f 

188. C. Wu, Q. Zhang, Y. Liu, W. Luo, X. Guo et al., The dawn of lead-free perovskite solar cell: highly stable double perovskite Cs2AgBiBr 6 film. Adv. Sci. **5** (3), 1700759–1700766 (2018). https ://doi.org/10.1002/advs.20170 0759 

189. W. Gao, C. Ran, J. Xi, B. Jiao, W. Zhang et al., High-quality Cs2AgBiBr 6 double perovskite film for lead-free inverted planar heterojunction solar cells with 2@2% efficiency. ChemPhysChem **19** (14), 1696–1700 (2018). https ://doi. org/10.1002/cphc.20180 0346 

190. M. Pantaler, K.T. Cho, V. Queloz, I.G. Benito, C. Fettkenhauer et al., Hysteresis-free lead-free double perovskite solar cells by interface engineering. ACS Energy Lett. **3** , 1781– 1786 (2018). https ://doi.org/10.1021/acsen ergyl ett.8b008 71 

191. M. Wang, P. Zeng, S. Bai, J. Gu, F. Li et al., High quality sequential-vapor-deposited Cs2AgBiBr 6 thin films for lead-free perovskite solar cells. Sol. RRL. **2** (12), 1800217– 1800222 (2018). https ://doi.org/10.1002/solr.20180 0217 

192. P. Li, W. Gao, C. Ran, H. Dong, X. Hou et al., Post-treatment engineering of vacuum-deposited  Cs2NaBiI6 double perovskite film for enhanced photovoltaic performance. Phys. Status Solidi A **216** (23), 1900567–1900574 (2019). https ://doi. org/10.1002/pssa.20190 0567 

193. H. Wang, Y. Zhao, Z. Wang, Y. Liu, Z. Zhao et al., Hermetic seal for perovskite solar cells: an improved plasma enhanced atomic layer deposition encapsulation. Nano Energy **69** , 104375–104383 (2020). https ://doi.org/10.1016/j.nanoe n.2019.10437 5 

194. C. Chen, T.H. Han, S. Tan, J. Xue, Y. Zhao et al., Efficient flexible inorganic perovskite light-emitting diodes fabricated with CsPbBr 3 emitters prepared via low-temperature in situ dynamic thermal crystallization. Nano Lett. **20** (6), 4673– 4680 (2020). https ://doi.org/10.1021/acs.nanol ett.0c015 50 

© The authors 

https://doi.org/10.1007/s40820-020-00578-z 

