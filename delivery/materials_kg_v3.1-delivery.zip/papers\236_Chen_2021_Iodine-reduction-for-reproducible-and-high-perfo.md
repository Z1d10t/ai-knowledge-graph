# Iodine reduction for reproducible and high-performance perovskite solar cells and modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 268 |
| 作者 | Shangshang Chen, Xun Xiao, Hangyu Gu, Jin-Song Huang |
| DOI | 10.1126/sciadv.abe8130 |
| 源文件 | 027_Chen_2021_Iodine-reduction-for-reproducible-and-high-perfo.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **M A T E RIALS SCIENC E** 

# **Iodine reduction for reproducible and high-performance perovskite solar cells and modules** 

### **Shangshang Chen, Xun Xiao, Hangyu Gu, Jinsong Huang*** 

**Perovskite-based electronic materials and devices such as perovskite solar cells (PSCs) have notoriously bad reproducibility, which greatly impedes both fundamental understanding of their intrinsic properties and real-world applications. Here, we report that organic iodide perovskite precursors can be oxidized to I2 even for carefully sealed precursor powders or solutions, which markedly deteriorates the performance and reproducibility of PSCs. Adding benzylhydrazine hydrochloride (BHC) as a reductant into degraded precursor solutions can effectively reduce the detrimental I2 back to I**<sup>**−**</sup> **, accompanied by a substantial reduction of I3−-induced charge traps in the films. BHC residuals in perovskite films further stabilize the PSCs under operation conditions. BHC improves the stabilized efficiency of the blade-coated p-i-n structure PSCs to a record value of 23.2% (22.62 ± 0.40% certified by National Renewable Energy Laboratory), and the high-efficiency devices have a very high yield. A stabilized aperture efficiency of 18.2% is also achieved on a 35.8-cm**<sup>**2**</sup> **mini-module.** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

#### **INTRODUCTION** 

Metal halide perovskite photovoltaics has progressed rapidly in the past decade and is regarded a promising solar technology that can compete with inorganic photovoltaics ( _1_ – _3_ ). Compared to conventional inorganic counterparts, one of the key advantages of perovskite solar technology is its solution processability that ensures highthrough and low-cost manufacturing using techniques such as blade coating ( _4_ ), slot-die coating ( _5_ ), or roll-to-roll coating ( _6_ ). Despite high efficiencies have been certified using small area cells, the poor reproducibility of solution-processed perovskite solar cells (PSCs) has stood out to be one notorious hurdle that shadows the prospectus of their scaling up and commercialization ( _7_ ). It has been broadly complained by the community that device performances achieved by different research laboratories are difficult to be reproduced, sometimes even by the same personal from time to time. The performances of perovskite devices have been shown to be very sensitive to the compositions and states of the precursor solutions including stoichiometric ratio of organic halide to lead salt ( _8_ ), colloidal size ( _9_ ), storing conditions ( _10_ , _11_ ), aging duration ( _12_ ), etc. It is commonly observed that fresh precursor solutions can realize PSCs with decent power conversion efficiencies (PCEs), but after storage for a few days, the aged solutions are no longer able to reproduce efficient PSCs. Consequently, the photovoltaic performance and the reproducibility of perovskite devices are deteriorated because of the degradation of perovskite precursor solutions. Compared to the extensive research attention devoted to improving the stability of perovskite solar devices in the past decade ( _13_ , _14_ ), the stability of perovskite precursor solutions has not received enough attention given its importance. Preventing the degradation of perovskite precursor solutions is equally important compared to postfabrication device encapsulation, because large-area perovskite modules are generally manufactured in air and perovskite precursor inks are generally prepared in large quantity and stored for days or months. In addition, the degradation of the precursor materials would also negatively affect the understanding of intrinsic properties of perovskites, 

Department of Applied Physical Sciences, University of North Carolina, Chapel Hill, NC 27599, USA. *Corresponding author. Email: jhuang@unc.edu 

because the formed single crystals or polycrystalline thin films from degraded perovskite inks inevitably cause extrinsic response from the materials and may dominate. One example is that a huge variation of carrier mobility and carrier recombination lifetime has been reported for perovskite single crystals even measured by the same methods ( _15_ ). Recently, the stability issue of perovskite precursor solutions started to draw increasing attentions from the perovskite photovoltaic community. An addition of sulfur into the perovskite precursor solution was shown to stabilize methyl ammonium cations and thus enhanced the stability of both precursor solutions and solar cells ( _16_ ). 

Among the precursor materials used in preparing perovskite precursor solutions, organic halide salts, such as methylammonium iodide (MAI) and formamidinium iodide (FAI), typically suffer from much poorer stability compared to metal halides. One of the most outstanding instability issues is that I<sup>−</sup> ions are readily oxidized into I2 during the storage of perovskite precursor solutions. The oxidation of I<sup>−</sup> has been commonly observed in other I<sup>−</sup> -containing solutions like HI in which hypophosphorous acid is typically added as stabilizer. Such an instability issue has been observed to significantly deteriorate the photovoltaic performance of perovskite devices ( _17_ ). A common practice is to use most fresh organic halides to prepare precursor solutions that are not economically feasible in manufacturing. One alternative way was reported to add hypophosphorous acid into precursor solutions to reduce I2 ( _8_ ). However, hypophosphorous acid is typically dissolved in water, which makes it not applicable to the perovskite compositions sensitive to water. In addition, heating hypophosphorous acid will release highly toxic phosphine, which may make it not suitable for mass production. 

Here, we report a low-cost benzylhydrazine hydrochloride (BHC) reductant that can effectively reduce I2 back to I<sup>−</sup> in aged precursor solutions and thus restore the pristine perovskite precursor solutions (Fig. 1A). In addition, the BHC residual in perovskite solid films can reduce the I2 generated during light soaking that induces the shallow charge traps and accelerates the decomposition of perovskite materials. Because of these dual effects, the blade-coated p-i-n PSCs processed from the BHC-added aged precursor solution achieved a record stabilized PCE of 23.2% [certified efficiency of 22.62 ± 0.40% by National Renewable Energy Laboratory (NREL)] and an excellent 

**1 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Degradation of perovskite precursor solutions and materials.** ( **A** ) Scheme showing that I2/I3− was generated during the aging of perovskite precursor solution that can be reduced back to I<sup>−</sup> after adding BHC. ( **B** ) Photographs of the precursor solutions and materials: pristine 1.37 M MAI:FAI (7:3) in 2-ME before (1) and after (2) aged in air for 2 days; fresh FAI power (3) and the FAI after stored in air for 5 months (4). ( **C** ) Ultraviolet (UV)–visible absorption spectra of the fresh and aged 1.37 M MAI:FAI (7:3) before and after adding BHC. Inset shows the chemical reaction between benzylhydrazine and I2. a.u., arbitrary units. Photo credit: Shangshang Chen, University of North Carolina Chapel Hill. 

operational stability with almost zero degradation after operation for 1000 hours at maximum power point (MPP) using a perovskite composition that does not contain cesium. This work provides a simple and effective strategy to restore and stabilize the perovskite precursor solutions toward efficient and reproducible perovskite materials and devices. 

#### **RESULTS** 

To verify the oxidation of I<sup>−</sup> to I2 during the aging of the precursor solutions, we first prepared a 1.37 M MAI:FAI (molar ratio of 7:3) mixed 2-methoxyethanol (2-ME) solution, which has the same ratio and concentration of MAI and FAI with that of the perovskite precursor solution (1.37 M MA0.7FA0.3PbI3 in 2-ME) for device fabrication. We excluded lead iodide (PbI2) in this study, because the absorption spectrum of PbI2 overlaps to a great degree with that of I2 in these solutions. After aged in air for 2 days, the color of the solution turned into light yellow (Fig. 1B), and an absorption peak at 365 nm emerged in the absorption spectrum of the solution (Fig. 1C) that can be ascribed to I3− (the combination of I2 and I<sup>−</sup> ions). Individual FAI or MAI solution was also found to decompose to I2, and FAI showed a faster decomposition, as shown by the photo of the solutions (fig. S1). We also found that even the white solid FAI powder turned into yellow color, an indication of its oxidization to I2, after it was stored in the dark in air for 5 months (Fig. 1B). This degradation is much faster than the previously observed reaction of FA<sup>+</sup> with oxygen under illumination ( _11_ ). When 3.6 mM BHC was added into the aged MAI:FAI solution, the color of the solution became transparent, and the absorption peak of 

I3− completely disappeared, demonstrating the effectiveness of BHC in reducing I2/I3−. In addition to organic halide solutions, we also added BHC into the perovskite precursor solutions as the stabilizer and then extracted the generated I2/I3− by toluene after aging the precursor solutions. The ultraviolet-visible (UV-vis) absorption measurement of the toluene extractions shows that the addition of BHC effectively inhibited the generation of I2/I3− (fig. S2). 

We investigated the performance change of perovskite films/ devices caused by precursor solution aging and the addition of BHC into the solution. Here, we fabricated perovskite films and devices from three types of MA0.7FA0.3PbI3 precursor solutions: freshly prepared perovskite precursor solution, the precursor solution that had been aged for 2 months in a N2-filled glovebox with an O2 level of ~20 parts per million (ppm), and the identical aged solution with the addition of 0.26% BHC (molar ratio with respect to lead in perovskites) before coating. This is the optimal amount of BHC in perovskite solution that yields the highest device efficiency. Note that the amount of I2/I3− in the aged precursor solution is between 10−5 and 10<sup>−4</sup> M estimated from its absorbance (fig. S3) and absorption coefficient, which is much lower than that of BHC (3.6 mM) added into the precursor solution. The perovskite precursor powders that did not show notable degradation were chosen for this study to prepare fresh solution. These three solutions are denoted as “fresh, aged, and aged + BHC” hereinafter, respectively. The perovskite films were deposited onto glass substrates with a room temperature blade coating process in air as we reported previously ( _4_ ). The addition of BHC did not have notable impacts on the film grain size and distribution, as shown by the scanning electron microscopy (SEM) images in fig. S4. The x-ray diffraction (XRD) patterns from three different batches of samples (Fig. 2A) all show reduced XRD peak intensity for the resultant perovskite films from the aged solution, an indication of decreased crystallinity. The XRD (110) peak intensity increased by 23% after the addition of BHC into the aged precursor solution. A similar trend was also observed in the steady state photoluminescence (PL) measurements on the films. The PL intensity decreased for the film made from aged precursor solution compared to that made from the fresh solution, and the addition of BHC into aged precursor solution enhanced the PL intensity by 32%, resulting in a film with a PL intensity even higher than that of the film from the fresh solution (Fig. 2B). PSCs were then fabricated with a p-i-n planar heterojunction configuration of glass/indium tin oxide (ITO)/poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA)/ perovskites/C60/bathocuproine (BCP)/copper (Cu). As shown in Fig. 2C and Table 1, the device processed from the fresh precursor solution delivered a decent PCE of 21.8%, along with an open-circuit voltage ( _V_ OC) of 1.14 V, a short-circuit current density ( _J_ SC) of 23.8 mA cm<sup>−2</sup> , and a fill factor ( _FF_ ) of 0.805. After the precursor solution was aged for 2 months, we found that the PCE of the resulting devices was markedly reduced to 19.2%, with especially a deteriorated _J_ SC from 23.8 to 21.4 mA cm<sup>−2</sup> . In notable contrast, after adding BHC into the aged precursor solution, a PCE of 23.4% was realized with a restored _J_ SC and a high _V_ OC of 1.17 V. The champion solar cell was further held at a fixed bias of 1.04 V, or MPP, and a stabilized power output for >400 s was recorded as depicted in Fig. 2D. The current density was stabilized at 22.3 mA cm<sup>−2</sup> , thus corresponding to a stabilized PCE of 23.2%. Our champion devices were then shipped to NREL for certification, and a stabilized PCE of 22.62 ± 0.40% was certified (fig. S5). The voltage deficit in this case was minimized to 0.33 V calculated from the external quantum 

**2 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 2. Characterization of perovskite films and devices.** ( **A** to **C** ) XRD patterns (A), PL spectra (B), and _J-V_ characteristics (C) of the perovskite films or solar devices processed from different precursor solutions (red, fresh precursor solution; orange, 2-month aged precursor solution; blue, 2-month aged precursor solution with BHC). ( **D** ) Stabilized power output of the champion PSC at a fixed bias of 1.04 V. ( **E** to **G** ) External quantum efficiency (EQE) curves (E), trap density of states (tDOS) spectra (F), and statistical analysis on the PCEs (G) of the three types of devices processed from different precursor solutions. The PCEs in (G) are based on 191, 121, and 244 devices processed from “fresh,” “aged,” and “aged + BHC” precursor solutions, respectively. 

efficiency spectrum onset of 825 nm (Fig. 2E). The improved device efficiencies were mainly contributed by benzylhydrazine groups instead of chloride anions, which is confirmed by that adding methylammonium chloride (MACl) into the aged precursor solution did not cause such a notable efficiency enhancement (fig. S6). This is a little different from the performance enhancement by adding MACl into fresh precursor reported previously ( _9_ ). A reduced trap density in the “aged + BHC” device was also discovered by the thermal admittance spectroscopy measurement results shown in Fig. 2F ( _18_ ). The aged + BHC device exhibited a much lower trap density of states (tDOS) in shallow trap depth region (0.30 to 0.40 eV). This trap peak with depth from 0.20 to 0.35 eV was confirmed by another study to be a signature of the formation of I3−, which forms by the combination of I2 and I<sup>−</sup> ions. The reduced trap density is thus a direct evidence for the reduction of the detrimental I2 in the aged precursor solution. It is interesting to find that the aged + BHC 

**Table 1. Photovoltaic parameters of the PSCs processed from different precursor solutions.** 

|**Precursor**<br>**solutions**|**_V_OC [V]**|**_J_SC [mA cm**<sup>**−2**</sup>**]**|**_FF_**|**PCE [%]**|
|---|---|---|---|---|
|Fresh|1.14|23.8|0.805|21.8|
|Aged for<br>2 months|1.12|21.4|0.800|19.2|
|Fresh + BHC|1.17|24.0|0.829|23.3|
|Aged for<br>2 months +<br>BHC|1.17|23.9|0.836|23.4|



device had even less I2 than the devices made from fresh solution. This indicates that even the fresh solution has already degraded, which manifests the importance of reducing I2 in perovskite precursor solutions. 

In addition to BHC, we also tried other strong reducing agents including propylhydrazine hydrochloride (PHC) and (2-thienylmethyl)hydrazine hydrochloride (THC) with similar molecular structures. Likewise, the additions of PHC and THC restored the aged precursor solutions and improved the device efficiencies to 22.6 and 23.0% (fig. S7 and table S1), respectively, demonstrating the universality of organic hydrazine halides in reducing I2 in perovskite precursor solutions. Nevertheless, BHC is much cheaper than PHC and THC (table S2), thus making it more attractive in the scalable manufacturing of perovskite modules. We also tested the reproducibility of fabricating three types of devices with their PCEs statistically analyzed in Fig. 2G. Obviously, the PSCs fabricated from aged + BHC precursor solution showed much better reproducibility than those of the other two groups of PSCs. More than 80% aged + BHC devices (244 in total) had PCEs over 22.0%, and more than half of them achieved PCEs over 22.5%. The fresh solution with the addition of BHC was further used to blade coat PSCs, and it shows that the resulting devices were able to realize the highest PCE of 23.3% with a _V_ OC of 1.17 V, a _J_ SC of 24.0 mA cm<sup>−2</sup> , and a _FF_ of 0.829 (fig. S8). This performance is almost identical to those from the aged + BHC solution, indicating that the “fresh” solution actually also had some degree of degradation already, despite all precautious attentions paid to protect them. All these results demonstrate the effectiveness of BHC in restoring precursor solutions and reducing film defects, accounting for the suppressed charge recombination and thus enhanced device efficiency. Besides, we found that the blade-coated PSCs were able to tolerate a higher amount of BHC up to 1.6% (molar ratio with respect to Pb), at which the PSCs still delivered a decent PCE of 21.8% (fig. S9 and table S3). Such a wide processing window of adding BHC is highly desirable for large-scale fabrication of efficient and reproducible perovskite solar devices. 

Subsequently, we performed long-term stability tests of encapsulated perovskite devices under a plasma lamp with light intensity equivalent to AM 1.5G (fig. S10) in air (relative humidity ~60 ± 10%). No UV filters were used during the tests. All devices were connected to an MPP tracker that enabled the devices to keep working under MPP conditions during light soaking. The temperature of the devices was measured to be ~65°C due to the heating effect of light illumination. The operational stability of the PSCs prepared from different precursor solutions was compared in Fig. 3A. Both devices 

**3 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. Stability of PSCs and films.** ( **A** ) Operational stability test results of the encapsulated PSCs processed from different precursor solutions under one sun equivalent illumination in air (neither cooling nor UV filters were used in this test). ( **B** ) Absorption spectra of the toluene in which MA0.7FA0.3PbI3 films with and without BHC were immersed under 1 sun illumination for 8 hours. Inset shows a picture of the vials in which two films (15 mm by 15 mm) were immersed into 5 ml of toluene. Photo credit: Shangshang Chen, University of North Carolina Chapel Hill. 



**Fig. 4. Photovoltaic performance of the perovskite mini-modules.** ( **A** ) _J-V_ characteristics of the champion perovskite mini-module with an aperture area of 35.8 cm<sup>2</sup> . Inset shows a picture of the champion mini-module. ( **B** ) Stabilized power output of the champion mini-module at a fixed bias of 9.8 V. Photo credit: Shangshang Chen, University of North Carolina Chapel Hill. 

prepared from fresh and aged precursor solutions exhibited poor operational stability, especially the device based on aged precursor solution that lost >60% of its initial efficiency after 400-hour light soaking. In notable contrast, the PSC fabricated from the aged + BHC precursor solution showed excellent operational stability with almost no degradation after 1000-hour MPP tracking. The significantly enhanced device stability can be attributed to, on the one hand, that the reducing of I2 in the precursor solutions decreased the trap density that have been reported to initialize the degradation of perovskites ( _19_ , _20_ ). On the other hand, since the amount of BHC added into the precursor solution is higher than that of I2/I3−, the residual BHC can work as a sacrificing agent to further reduce the generated I2 inside the perovskite films during light soaking. Accelerated formation of I2 for iodide perovskites under illumination has been observed previously ( _17_ , _21_ ), which was also shown to hasten the degradation of PSCs ( _22_ ). To confirm such a role of BHC, we further immersed two perovskite films with and without BHC into toluene to extract the I2 generated in the films during light soaking process. After continuous light soaking for 8 hours at one sun light intensity, the absorption spectra (Fig. 3B) of two toluene solutions show that the amount of I2 (located at ~500 nm) generated from the films is greatly reduced with the addition of BHC. This proves the effects of the BHC residual in reducing I2 and thus stabilizing the perovskite films under 

illumination. It is also worth mentioning that I2 was still observed in the toluene from the perovskite film with BHC, which might be caused by that part of I2 was directly extracted by toluene without reacting with BHC, since BHC is not soluble in toluene. However, the generated I2 generated in encapsulated devices is trapped and thus has higher possibility to be reduced by the residual BHC. 

Last, the BHC incorporated solution was evaluated for module fabrication and performance. Here, we fabricated large-area perovskite modules following the same blade coating procedures as the PSCs. As shown in Fig. 4A, the perovskite mini-modules delivered the highest PCE of 18.5% from _J-V_ scanning (aperture area of 35.8 cm<sup>2</sup> ), with a _V_ OC of 11.7 V (10 subcells, therefore each subcell gave a _V_ OC of 1.17 V), a short circuit current _I_ SC of 73.20 mA, and a _FF_ of 0.773. The champion mini-module was then held at a bias of 9.8 V for >400 s, and the current was stabilized at 66.2 mA, thus corresponding to a stabilized PCE of 18.2% (Fig. 4B). Such a PCE is among the highest for the perovskite modules reported to date. 

#### **DISCUSSION** 

In summary, we report that I<sup>−</sup> ions were observed to be oxidized to I2 during the storage of perovskite precursor solutions, which deteriorated the quality of the perovskite films and the performance of 

**4 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

resulting PSCs. The addition of BHC, on the one hand, can effectively reduce detrimental I2 and restore the precursor solutions. On the other hand, the remaining BHC can further stabilize the PSCs. As a result, the highest stabilized PCE of 23.2% was achieved in the blade-coated PSCs, which is a record efficiency for p-i-n PSCs processed from any methods. This work demonstrates the importance of stabilizing precursor solutions and provides an effective strategy to improve the performance and reproducibility of perovskite solar devices. 

[SYLGARD 184 silicone elastomer; 10:1 (w/w)] was dropped onto the silicon wafer and let rest for 0.5 hours to allow the PDMS to fill the cavities. After cured on a hot plate kept at 150°C for 15 min, the PDMS layer was peeled off silicon wafer with caution and then mounted onto the surface of module substrate with adhesive tapes. The active areas of solar cells and modules are 8 mm<sup>2</sup> (4 mm by 2 mm determined by a metal shadow mask) and 35.8 cm<sup>2</sup> (5.5 cm by 0.65 cm by 10 subcells), respectively. 

### **Device characterization** 

#### **MATERIALS AND METHODS** 

### **Materials** 

BHC, PHC, THC, PTAA (average _M_ n, 7000 to 10,000), BCP, lead iodide (PbI2, 99.999% trace metals), dimethyl sulfoxide (DMSO), _L_ --phosphatidylcholine (LP), 2-ME, and toluene were purchased from Sigma-Aldrich and used without further purification. C60 was purchased from Nano-C Inc. MAI, FAI, 4-fluoro-phenylammonium iodide (p-F-PEAI) and n-dodecylammonium iodide were purchased from GreatCell Solar. Methylammonium chloride (MACl) was purchased from Xi’an Polymer Light Technology Corp. 

### **Device fabrication** 

Patterned ITO glass substrates (1.5 cm by 1.5 cm for solar cells and 13.0 cm by 8.5 cm for solar modules) were first cleaned by ultrasonication with soap, deionized water, and isopropyl alcohol, and then UV ozone was treated for 15 min before use. All perovskite solar devices were prepared by blade coating at room temperature inside a fume hood with a relative humidity of 45 ± 5%. The hole-transporting PTAA layer with a concentration of 3.3 mg ml<sup>−1</sup> dissolved in toluene was bladecoated onto ITO glass substrates at a speed of 20 mm s<sup>−1</sup> . The gap between blade coater and ITO substrates was 150 m. The perovskite precursor solutions (2.5 M MAPbI3 and 1.67 M FAPbI3) were prepared separately by dissolving corresponding organic halides and lead iodide in 2-ME and stored in a N2-filled glovebox with an O2 level ~ 20 ppm. Before blade coating, the MAPbI3 and FAPbI3 precursor solutions were mixed and diluted to a 1.37 M MA0.7FA0.3PbI3 solution, and different amounts of BHC, n-dodecylammonium iodide (0.83 mg ml<sup>−1</sup> ), LP (0.27 mg ml<sup>−1</sup> ), 0.14% (v/v) MAH2PO2, p-F-PEAI (1.40 mg ml<sup>−1</sup> ), and 2.8% (v/v) DMSO were added into the precursor solution as additives. Subsequently, the precursor solution was blade-coated onto the PTAA-covered ITO glass substrates with a gap of 250 m at a movement speed of 20 mm s<sup>−1</sup> . The N2 knife worked at 20 psi during blade coating. After that, the perovskite films were annealed at 120°C for 5 min in air. The solar cells were completed by thermally evaporating C60 (30 nm, 0.2 Å s<sup>−1</sup> ), BCP (6 nm, 0.1 Å s<sup>−1</sup> ), and 100-nm copper (1 Å s<sup>−1</sup> ). The devices for stability tests were coated with an octylammonium sulfate solution (annealed at 100°C for 10 min) before evaporating electron-transporting layers and metal electrodes ( _23_ ). For mini-modules, laser scribing was performed twice before and after electrode deposition to complete the module fabrication. The fabricated modules have 10 subcells, and each subcell has a width of 6.5 mm. The total scribing line width was 0.4 to 0.6 mm, giving a geometry filling factor of 90 to 94%. A polydimethylsiloxane (PDMS) layer was applied to the surface of glass substrate as antireflection coating. The PDMS antireflection layer was prepared by a soft lithography method, and a textured silicon wafer with pyramid size of ~10 m was used as a template (fig. S11). First, the PDMS prepolymer/curing agent mixture 

The _J-V_ characteristics of solar cells were performed using a Xenon lamp–based solar simulator (Oriel Sol3A, Class AAA Solar Simulator), and the power of the simulated light was calibrated to 100 mW cm<sup>−2</sup> by a silicon reference cell (Newport 91150 V-KG5). All devices were measured using a Keithley 2400 source meter with a backward scan rate of 0.1 V s<sup>−1</sup> in air at room temperature, and the delay time was 10 ms. There was no preconditioning before measurement. A metal mask with an aperture (7.3 mm<sup>2</sup> ) aligned with the device area was used for measurements. SEM images were taken on FEI Helios 600 Nanolab Dual Beam System operating at 5 kV. The XRD patterns were obtained with a Rigaku sixth generation MiniFlex x-ray diffractometer. UV-vis absorption spectra were obtained with a Thermo Scientific Evolution 201 Spectrophotometer. Because the reaction product (Benzenemethanediazon ium) between BHC and I2 has absorption between 300 and 400 nm under acidic condition, a tiny amount of methylamine solution (40 weight % in water) was added into the solution to obviate the interference before measuring the UV-vis absorption spectra. The PL measurement was conducted on a PicoQuant MT100 FLIM System at room temperature with an excitation wavelength of 640 nm. The PL intensity was recorded by a hybrid PMT detector. The tDOS of solar cells were derived from the frequency-dependent capacitance (C-f) and voltagedependent capacitance (C-V), which were obtained from the thermal admittance spectroscopy measurement performed with an LCR meter (Agilent E4980A). **Device encapsulation and stability tests** A thin layer of CYTOP was blade-coated onto the back of the PSCs for operational stability tests. After dried at 60°C in air for 10 min, the PSCs were then encapsulated by cover glass sealed by epoxy encapsulant on the back. A plasma lamp with a light intensity equivalent to AM 1.5G without any ultraviolet filter worked as solar simulator in air (relative humidity, ∼60 ± 10%). The temperature of the solar ∼60 ± 10%). The temperature of the solar 60 ± 10%). The temperature of the solar 

A thin layer of CYTOP was blade-coated onto the back of the PSCs for operational stability tests. After dried at 60°C in air for 10 min, the PSCs were then encapsulated by cover glass sealed by epoxy encapsulant on the back. A plasma lamp with a light intensity equivalent to AM 1.5G without any ultraviolet filter worked as solar simulator in air (relative humidity, ∼60 ± 10%). The temperature of the solar ∼60 ± 10%). The temperature of the solar 60 ± 10%). The temperature of the solar cells was measured to be ~65°C due to the heating effects of the lamp. The solar cells were connected to an EnliteTech LS-6100 MPP tracker that automatically tracked the MPPs after each _J-V_ sweeping so that the solar cells always worked at MPP conditions during the stability tests. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/10/eabe8130/DC1 

### **REFERENCES AND NOTES** 

1. M. A. Green, A. Ho-Baillie, H. J. Snaith, The emergence of perovskite solar cells. _Nat. Photonics_ **8** , 506–514 (2014). 

2. J.-P. Correa-Baena, M. Saliba, T. Buonassisi, M. Grätzel, A. Abate, W. Tress, A. Hagfeldt, Promises and challenges of perovskite solar cells. _Science_ **358** , 739–744 (2017). 

3. Y. Rong, Y. Hu, A. Mei, H. Tan, M. I. Saidaminov, S. I. Seok, M. D. McGehee, E. H. Sargent, H. Han, Challenges for commercializing perovskite solar cells. _Science_ **361** , eaat8235 (2018). 

**5 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 

## SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

4. Y. Deng, C. H. Van Brackle, X. Dai, J. Zhao, B. Chen, J. Huang, Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. _Sci. Adv._ **5** , eaax7537 (2019). 

5. R. Patidar, D. Burkitt, K. Hooper, D. Richards, T. Watson, Slot-die coating of perovskite solar cells: An overview. _Mater. Today Commun._ **22** , 100808 (2020). 

6. B. Dou, J. B. Whitaker, K. Bruening, D. T. Moore, L. M. Wheeler, J. Ryter, N. J. Breslin, J. J. Berry, S. M. Garner, F. S. Barnes, S. E. Shaheen, C. J. Tassone, K. Zhu, M. F. A. M. van Hest, Roll-to-roll printing of perovskite solar cells. _ACS Energy Lett._ **3** , 2558–2565 (2018). 

7. M. Saliba, J. P. Correa-Baena, C. M. Wolff, M. Stolterfoht, N. Phung, S. Albrecht, D. Neher, A. Abate, How to make over 20% efficient perovskite solar cells in regular (n–i–p) and inverted (p–i–n) architectures. _Chem. Mater._ **30** , 4193–4201 (2018). 

8. W. Zhang, S. Pathak, N. Sakai, T. Stergiopoulos, P. K. Nayak, N. K. Noel, A. A. Haghighirad, V. M. Burlakov, D. W. deQuilettes, A. Sadhanala, W. Li, L. Wang, D. S. Ginger, R. H. Friend, H. J. Snaith, Enhanced optoelectronic quality of perovskite thin films with hypophosphorous acid for planar heterojunction solar cells. _Nat. Commun._ **6** , 10030 (2015). 

9. K. Yan, M. Long, T. Zhang, Z. Wei, H. Chen, S. Yang, J. Xu, Hybrid halide perovskite solar cell precursors: Colloidal chemistry and coordination engineering behind device processing for high efficiency. _J. Am. Chem. Soc._ **137** , 4460–4468 (2015). 

10. B. Dou, L. M. Wheeler, J. A. Christians, D. T. Moore, S. P. Harvey, J. J. Berry, F. S. Barnes, S. E. Shaheen, M. F. A. M. van Hest, Degradation of highly alloyed metal halide perovskite precursor inks: Mechanism and storage solutions. _ACS Energy Lett._ **3** , 979–985 (2018). 

11. H. Wei, S. Chen, J. Zhao, Z. Yu, J. Huang, Is formamidinium always more stable than methylammonium? _Chem. Mater._ **32** , 2501–2507 (2020). 

12. G. S. Shin, Y. Zhang, N.-G. Park, Stability of precursor solution for perovskite solar cell: Mixture (FAI + PbI2) versus synthetic FAPbI3 Crystal. _ACS Appl. Mater. Interfaces_ **12** , 15167–15174 (2020). 

13. J. A. Christians, S. N. Habisreutinger, J. J. Berry, J. M. Luther, Stability in perovskite photovoltaics: A paradigm for newfangled technologies. _ACS Energy Lett._ **3** , 2136–2143 (2018). 

14. T. Leijtens, G. E. Eperon, N. K. Noel, S. N. Habisreutinger, A. Petrozza, H. J. Snaith, Stability of metal halide perovskite solar cells. _Adv. Energy Mater._ **5** , 1500963 (2015). 

15. L. M. Herz, Charge-carrier mobilities in metal halide perovskites: Fundamental mechanisms and limits. _ACS Energy Lett._ **2** , 1539–1548 (2017). 

16. H. Min, G. Kim, M. J. Paik, S. Lee, W. S. Yang, M. Jung, S. I. Seok, Stabilization of precursor solution and perovskite layer by addition of sulfur. _Adv. Energy Mater._ **9** , 1803476 (2019). 

17. L. Wang, H. Zhou, J. Hu, B. Huang, M. Sun, B. Dong, G. Zheng, Y. Huang, Y. Chen, L. Li, Z. Xu, N. Li, Z. Liu, Q. Chen, L. D. Sun, C. H. Yan, A Eu<sup>3+</sup> -Eu<sup>2+</sup> ion redox shuttle imparts operational durability to Pb-I perovskite solar cells. _Science_ **363** , 265–270 (2019). 

18. Y. Shao, Z. Xiao, C. Bi, Y. Yuan, J. Huang, Origin and elimination of photocurrent hysteresis by fullerene passivation in CH3NH3PbI3 planar heterojunction solar cells. _Nat. Commun._ **5** , 5784–5790 (2014). 

19. S. P. Dunfield, L. Bliss, F. Zhang, J. M. Luther, K. Zhu, M. F. A. M. Hest, M. O. Reese, J. J. Berry, From defects to degradation: A mechanistic understanding of degradation in perovskite solar cell devices and modules. _Adv. Energy Mater._ **10** , 1904054 (2020). 

20. F. Wang, S. Bai, W. Tress, A. Hagfeldt, F. Gao, Defects engineering for high-performance perovskite solar cells. _npj Flexible Electron._ **2** , 22 (2018). 

21. G. Y. Kim, A. Senocrate, T. Y. Yang, G. Gregori, M. Grätzel, J. Maier, Large tunable photoeffect on ion conduction in halide perovskites and implications for photodecomposition. _Nat. Mater._ **17** , 445–449 (2018). 

22. S. Wang, Y. Jiang, E. J. Juarez-Perez, L. K. Ono, Y. Qi, Accelerated degradation of methylammonium lead iodide perovskites induced by exposure to iodine vapour. _Nat. Energy_ **2** , 16195 (2017). 

23. S. Yang, S. Chen, E. Mosconi, Y. Fang, X. Xiao, C. Wang, Y. Zhou, Z. Yu, J. Zhao, Y. Gao, F. de Angelis, J. Huang, Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473–478 (2019). 

##### **Acknowledgments** 

**Funding:** The material and characterization research is supported by the Center for Hybrid Organic Inorganic Semi-conductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the U.S. Department of Energy. The demonstration of modules and related stability studies were supported by Office of Naval Research under award N6833520C0390. **Author contributions:** S.C. conceived the idea. S.C. fabricated and characterized the perovskite films and devices. X.X. prepared PDMS antireflection layers. H.G. performed laser scribing of perovskite mini-modules. S.C. and J.H. wrote the manuscript, and all authors commented on the manuscript. **Competing interests:** J.H. and S.C. are inventors on a provisional patent application related to this work filed by UNC-Chapel Hill (no. 63/131,959, filed 30 December 2020). J.H. has disclosed a significant financial interest in Perotech Inc. The other authors declare that they have no competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the corresponding author. 

Submitted 16 September 2020 Accepted 19 January 2021 Published 3 March 2021 10.1126/sciadv.abe8130 

**Citation:** S. Chen, X. Xiao, H. Gu, J. Huang, Iodine reduction for reproducible and high-performance perovskite solar cells and modules. _Sci. Adv._ **7** , eabe8130 (2021). 

**6 of 6** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabe8130     3 March 2021 



## **Iodine reduction for reproducible and high-performance perovskite solar cells and modules** 

Shangshang Chen, Xun Xiao, Hangyu Gu, and Jinsong Huang 

_Sci. Adv._ **7** (10), eabe8130.  DOI: 10.1126/sciadv.abe8130 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abe8130 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

