# Strain-Enhanced Mobility of Monolayer MoS2.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nano letters (Print) |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 168 |
| 作者 | I. Datye, A. Daus, R. Grady, Kevin A. Brenner, S. Vaziri, E. Pop |
| DOI | 10.1021/acs.nanolett.2c01707 |
| 源文件 | 086_Datye_2022_Strain-Enhanced-Mobility-of-Monolayer-MoS2.pdf |

---
Published in Nano Letters (2022), DOI: 10.1021/acs.nanolett.2c01707 

1 

# **Strain-Enhanced Mobility of Monolayer MoS2** 

Isha M. Datye,<sup>1</sup> Alwin Daus,<sup>1,2</sup> Ryan W. Grady,<sup>1</sup> Kevin Brenner,<sup>1,3</sup> Sam Vaziri,<sup>1</sup> and Eric Pop<sup>1,4,5,*</sup> 

> 1 _Department of Electrical Engineering, Stanford University, Stanford, CA 94305, USA_ 

> 2 _Present address: Chair for Electronic Devices, RWTH Aachen University, Aachen, 52074, Germany_ 

> 3 _Present address: Department of Electrical and Computer Engineering, Southern Methodist University, Dallas, TX 75275, USA_ 

> 4 _Department of Materials Science & Engineering, Stanford University, Stanford, CA 94305, USA_ 

> 5 _Precourt Institute for Energy, Stanford University, Stanford, CA 94305, USA_ 

### **ABSTRACT:** 

Strain engineering is an important method for tuning the properties of semiconductors and has been used to improve the mobility of silicon transistors for several decades. Recently, theoretical studies have predicted that strain can also improve the mobility of two-dimensional (2D) semiconductors, e.g. by reducing intervalley scattering or lowering effective masses. Here, we experimentally show strainenhanced electron mobility in monolayer MoS2 transistors with uniaxial tensile strain, on flexible substrates. The on-state current and mobility are nearly doubled with tensile strain up to 0.7%, and devices return to their initial state after release of strain. We also show a gate-voltage-dependent gauge factor up to 200 for monolayer MoS2, which is higher than previous values reported for sub-1 nm thin piezoresistive films. These results demonstrate the importance of strain engineering 2D semiconductors for performance enhancements in integrated circuits, or for applications such as flexible strain sensors. 

**KEYWORDS:** _2D materials, MoS2, transistors, strain engineering, strain sensors, mobility_ 

Transition metal dichalcogenides (TMDs), a class of two-dimensional (2D) layered materials, have gained interest for electronic and optoelectronic devices due to their atomically thin nature and pristine interfaces that, in theory, lack dangling bonds.<sup>1</sup> Molybdenum disulfide (MoS2) is a promising TMD because it can be synthesized in single layers,<sup>2-3</sup> it is relatively air-stable,<sup>4</sup> and its band gap is nearly twice that of silicon, which is advantageous for low-power transistors.<sup>1</sup> However, other electrical properties, including on-state current, mobility, and contact resistance of MoS2 and other TMD devices must be improved for them to compete with or complement existing technologies based on silicon. Several techniques have been used to experimentally improve TMD-based transistors, such as contact engineering,<sup>5-6</sup> channel doping,<sup>7-9</sup> defect healing,<sup>10</sup> and interface engineering,<sup>11</sup> while strain engineering has been theoretically predicted as an additional method to improve electrical performance.<sup>12-15</sup> 

2 

Strain engineering was shown to improve the mobility of silicon metal oxide semiconductor fieldeffect transistors (MOSFETs) in the 1990s<sup>16-17</sup> and then commercialized with the 90 nm technology node.<sup>18-20</sup> In practice, electron mobility in nMOS silicon FETs is increased by uniaxial tensile strain from silicon nitride encapsulation layers.<sup>19-20</sup> In contrast, higher hole mobility in pMOS silicon FETs is achieved by uniaxial compressive strain imparted by selective growth of SiGe at the source and drain regions.<sup>19-20</sup> Reduced electron effective mass and scattering due to band splitting in the conduction band, and reduced hole effective mass due to band warping in the valence band lead to enhanced mobility with strain in silicon.<sup>16,19-21</sup> Experimental and theoretical studies have shown that strain can also modify the band structure and phonon dispersion of 2D semiconductors based on TMDs.<sup>12-13,22-24</sup> However, most strained TMD studies to date have focused on optical measurements (e.g. photoluminescence mapping of optical band gap changes with strain<sup>24-26</sup> ), and less attention has been paid to strain effects on electron and hole mobility, despite the enhancement predicted theoretically.<sup>12-15</sup> 

In this work, we study the effect of uniaxial tensile strain on the electrical performance of monolayer MoS2 transistors fabricated on flexible substrates. We find the mobility and on-state current are nearly doubled with ~0.7% applied strain, reverting to their initial values when the strain is removed. This represents the largest enhancement in TMD mobility with externally applied strain to date, revealing that strain engineering could be just as important as defect- and contact-engineering for enhancing the electrical performance of 2D transistors based on TMDs. We also show these devices can be used as strain sensors because they have voltage-dependent gauge factors up to ~200, larger than most conventional strain sensors based on bulk materials and most 2D-based strain sensors. 

We fabricate MoS2 transistors with local back-gates on free-standing polyethylene naphthalate (PEN), a flexible and transparent plastic substrate, as shown in **Figure 1** . The MoS2 is grown by chemical vapor deposition (CVD) on separate SiO2/Si substrates,<sup>2</sup> then transferred<sup>27</sup> onto the Al2O3 backgate dielectric on PEN. We note that monolayer MoS2 is also a flexible material and can withstand strains up to ~11%.<sup>28</sup> Detailed steps regarding the fabrication of these transistors are given in Supporting Information Section 1. We apply strain to our MoS2 transistors using a two-point bending apparatus, by controlling the distance between the two ends of the substrate, as shown in **Figure 2a** . The strain can be estimated as 𝜀= 𝜏/(2𝑅), where 𝜏 = 125 μm is the thickness of the PEN and _R_ is the radius of curvature of the bent substrate (see **Figure 2b** ).<sup>29</sup> The strain applied to the MoS2 is confirmed by Raman and photoluminescence (PL) spectroscopy, by monitoring the position of the in-plane E’ peak at ~384 cm<sup>-1</sup> and the A exciton peak at ~1.8 eV, respectively. We note that we can only monitor _relative_ changes in MoS2 strain with bending, i.e. we cannot be sure if the transistor has built-in tensile 

3 

or compressive strain from the transfer and fabrication process, because the Al2O3 gate dielectric can cause peak shifts in the MoS2 Raman spectra.<sup>30</sup> Thus, all strain measurements below are reported relative to the as-fabricated devices in their flat, unbent state. 



**Figure 1.** (a) Schematic of back-gated (BG) monolayer (1L) MoS2 transistor on a polyethylene naphthalate (PEN) flexible substrate, with Au source and drain contacts, and an Al2O3 gate dielectric ~20 nm thick. (b) Top-view optical image of 1L MoS2 device with length _L_ ≈ 8 μm and width _W_ ≈ 20 μm. A few small triangular bilayer regions are visible, but these do not bridge the transistor channel and we do not expect them to significantly affect the electrical performance of the monolayer MoS2.<sup>31</sup> (c) Picture of sample (on a cleanroom wipe) taken after fabrication was completed, with the green region within the white box corresponding to the transferred MoS2 film. 

**Figure 2c** shows the Raman spectra of the MoS2 device from **Figure 1b** without applied strain (blue) and with ~0.7% tensile strain (red). We perform Raman measurements on four locations across the device channel with similar results, but only include one representative spectrum at each strain level here for clarity. The E’ peak clearly redshifts with ~0.7% applied tensile strain, and the average positions of the E’ peaks without and with applied strain are 384.6 ± 0.3 cm<sup>-1</sup> and 383.0 ± 0.2 cm<sup>-1</sup> , respectively. This corresponds to a peak shift of ~2.3 ± 0.2 cm<sup>-1</sup> /% strain, which is comparable to that of other studies.<sup>22,32-33</sup> The cyan curve, representing the measurement after strain is released, matches very well with the initial 0% (blue) curve, indicating that the effects of strain are reversible. Figure S2 of Supporting Information Section 2 includes Raman peak position data for all devices measured and a short discussion of the smaller A1’ peak shifts. 

**Figure 2d** displays the PL spectra of the MoS2 device from **Figure 1b** at 0% (blue), 0.4% (magenta), 0.6% (red), and back to 0% strain (cyan). As expected, the A exciton redshifts with tensile strain because of a decrease in the direct, optical band gap at the K point (see **Figure 2e** ).<sup>24,26,34</sup> The A exciton peak positions at 0%, 0.4%, 0.6%, and back to 0% strain are 1.810 ± 0.006 eV, 1.790 ± 0.004 eV, 1.772 ± 0.004 eV, and 1.811 ± 0.005 eV, respectively, averaged over four measurements in the device channel. Therefore, the shift of the A exciton peak is ~63 ± 10 meV/% strain. This is similar to that of other experimental studies demonstrating PL of MoS2 with strain.<sup>24,26,34</sup> The PL peak position data for all devices measured are included in Supporting Information Figure S3b. 

4 

Next, we perform electrical measurements of our devices as a function of strain. Our set-up enables direct probing of transistors under strain (see **Figure 2a** ) inside a vacuum probe station at ~2 × 10<sup>-5</sup> torr pressure. **Figure 3a** displays drain current vs. gate voltage ( _I_ D- _V_ GS) measurements of the MoS2 transistor shown in **Figure 1b** with applied tensile strain from 0% to 0.7%, and back to 0%. The onstate current rises with increasing strain and then returns to the initial (unstrained) level after strain release (cyan curve in **Figure 3a** ). Thus, strain does not have a permanent effect on the device characteristics. The gate leakage currents remain low (<1.2 nA) across all _V_ GS and strain levels (see Supporting Information Figure S4). The drain current vs. drain voltage ( _I_ D- _V_ DS) measurements of the device at 0% (solid lines) and 0.7% strain (dotted lines) are displayed in **Figure 3b** at several _V_ GS values. As before, we observe _I_ D increasing with strain; for example, at _V_ GS = 7 V and _V_ DS = 5 V, the current doubles from ~6 μA/μm to ~12 μA/μm at 0.7% strain. 



**Figure 2.** (a) Composite image of bending apparatus for applying tensile strain to the flexible substrates, illustrating the three probes (source, gate, drain) used for electrical measurements. (b) Image of bent substrate which is used to estimate the applied strain 𝜀= 𝜏/(2𝑅), where _τ_ is the thickness of the substrate and _R_ is the radius of curvature. (c) Raman spectra of the device from Figure 1b at different applied strains. The data (symbols) are fit to a superposition of Lorentzian and Gaussian peaks (solid curves). (d) Photoluminescence (PL) spectra of the same device, with the solid line fit to the data as the sum of two Lorentzians, for the A (at ~1.8 eV) and B exciton (at ~2.0 eV).<sup>35-36</sup> The A and B excitons are illustrated in the Figure S3a schematic. The line at ~1.96 eV is due to a Raman notch filter present in the optical path of the measurement setup. All Raman and PL measurements were taken in air, with laser wavelength 532 nm. (e) Simplified band structure of monolayer MoS2, not to scale. With uniaxial tensile strain, the direct gap at the _K_ point decreases and the energy separation between _K_ and _Q_ conduction band valleys increases.<sup>12-13,24,26</sup> The valence band at the Γ point also rises, leading to a narrowing of the K-Γ indirect gap<sup>15,26</sup> and the decreased PL intensity observed with strain in Figure 2d. 

5 

We estimate the field-effect mobility from the _I_ D vs. _V_ GS curves in the linear operation regime, as _μ_ FE = (∂ _I_ D/∂ _V_ GS) _L_ /( _WC_ ox _V_ DS), where _C_ ox ≈ 312 nF/cm<sup>2</sup> is the capacitance per unit area of the gate oxide, extracted from capacitance-voltage measurements of Au-Al2O3-Au structures on the same sample as the MoS2 transistors, with and without strain (see Supporting Information Section 4). We note the threshold voltage ( _V_ T) also changes with strain (see **Figure 3a** and Supporting Information Figure S11), suggesting that the electron density increases with the decreasing band gap under tensile strain.<sup>33,37</sup> To account for shifts in _V_ T, we estimate _μ_ FE at the same carrier density _n_ ≈ 1.1 × 10<sup>13</sup> cm<sup>-2</sup> , where 𝑛= (𝐶��/𝑞)(𝑉�� −𝑉� −𝑉��/2). We estimate _V_ T using the linear extrapolation method, which uses the voltage intercept of a line fit to the _I_ D vs. _V_ GS data near the maximum transconductance _g_ m = ∂ _I_ D/∂ _V_ GS.<sup>38</sup> The transistor has _μ_ FE ≈ 5.3 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> with 0% applied strain and _μ_ FE ≈ 10.8 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> with 0.7% applied tensile strain. Therefore, we achieve a ~2× improvement in _μ_ FE at 0.7% tensile strain for this device, which is essentially the same as the increase in drive current observed in **Figure 3b** . 



<!-- Start of picture text -->
(a) (b)<br>ε = 0%, released Solid lines: 0% strain<br>0.7% Dotted lines: 0.7% strain<br>0.6%<br>0.4% W  = 20 µm V GS = 7 V<br>0% L  = 8 µm<br>3 V<br>V DS = 1 V 1 V<br>(c) (d)<br>n  ~ 1.1×10 13 cm -2 V GS = 7 V<br>V DS = 1 V V DS = 1 V<br>Strain  Strain<br>released released<br><!-- End of picture text -->

**Figure 3.** (a) Transfer characteristics ( _I_ D vs. _V_ GS) of the device from **Figure 1b** ( _W_ = 20 μm, _L_ = 8 μm) at _V_ DS = 1 V and different levels of applied tensile strain. Solid lines correspond to data plotted on a log scale (left _<u>y</u>_ -axis), and dashed lines correspond to the same data plotted on a linear scale (right _y_ -axis). (b) Output voltage characteristics ( _I_ D vs. _V_ DS) of the same device at 0% (solid) and 0.7% (dotted) applied tensile strain, for _V_ GS = 1 V (green), 3V (magenta), and 7 V (dark blue). (c) Field-effect mobility ( _μ_ FE) normalized to the initial (unstrained) values for 8 devices as a function of applied strain, with the box plots showing the median across devices (red points), first and third quartiles (blue box), and maximum and minimum (top and bottom horizontal lines, respectively). The cyan box plot corresponds to the measurement after strain is released. (d) _I_ D normalized to the initial (unstrained) values at different levels of strain, with the box plots again showing the distribution of values across all devices. _I_ D values were extracted with applied voltages _V_ GS = 7 V and _V_ DS = 1 V. The cyan box plot again shows the measurement after strain is released. 

6 

We measure 7 other transistors with lengths from _L_ = 2 μm to 15 μm on the same substrate and perform electrical measurements with applied strain. To account for _V_ T variation, we extract _μ_ FE at the same carrier density ( _n_ ~ 1.1 × 10<sup>13</sup> cm<sup>-2</sup> ) and _I_ D at the same _V_ GS = 7 V and _V_ DS = 1 V, plotting the data for all devices in **Figure 3c-d** . These show _μ_ FE and _I_ D normalized to their initial values without applied strain, with the data from all devices summarized by box plots. (Supporting Information Figure S6 shows the magnitudes of _μ_ FE and _I_ D for each device, without normalizing them.) On average, _μ_ FE increases by a factor of 1.85 ± 0.23, and _I_ D increases by a factor of 1.76 ± 0.18 with 0.7% applied tensile strain, compared to the initial values without applied strain. For the _I_ D comparison, we note that the threshold voltage variation is at most δ _V_ T ≈ 1 V, which is significantly smaller than the overdrive voltage _V_ GS – _V_ T ≈ 8 V. Therefore, the ~12.5% variation in electron density with δ _V_ T cannot account for the nearly 2× increase in _I_ D, which must come directly from the tensile strain applied. 

Supporting Information Section 5 displays additional strain-dependent data as a function of channel length and at lower carrier density, with results largely consistent with the data presented in **Figure 3** . We also explored strain levels in excess of 0.7%, however we generally observed a degradation of electrical device performance in such cases (see Supporting Information Section 6). We attribute this degradation to either worsened adhesion of the contact metal to the MoS2 or to cracking of the metal lines. Gate dielectric damage could be ruled out because gate leakage currents remained the same at higher strain levels; “slippage” of the MoS2 along the substrate was also ruled out because we observed the expected shift of the E’ Raman peak at higher strain levels (Supporting Information Figure S12). In future work, higher strains could be achievable with metals that are more ductile and with gate oxides like HfO2, which has a lower Young’s modulus than Al2O3.<sup>39-40</sup> 

The improvements in current and mobility of our devices are expected to result from changes in the band structure with strain, as illustrated in **Figure 2d-e** . The direct band gap of monolayer MoS2 at the K-point decreases with tensile strain, seen as a redshift of the A exciton in **Figure 2d** . The nextlowest valley in the conduction band is at the Q-point (approximately halfway along the Τ line between the Γ and K points<sup>41-43</sup> ), and the energy separation between the Q and K valleys (Δ _E_ QK) has been predicted to increase when tensile strain is applied to MoS2 (see **Figure 2e** ), resulting in less electron intervalley scattering and therefore improved mobility.<sup>12-14,41</sup> (Δ _E_ QK for monolayer MoS2 encased in quartz and WS2 was experimentally estimated to be ~110 meV,<sup>44</sup> and theoretical predictions are in the ~50-270 meV range for unstrained monolayer MoS2, depending on the simulation approach used.<sup>12-</sup> 14,41,45-46 Monolayer TMDs such as WS2, WSe2, MoSe2, and MoTe2 have smaller Δ _E_ QK, thus one may expect a larger mobility improvement with strain in transistors based on these materials.<sup>13,46-47</sup> ) 

7 

Tensile strain is also expected to change the curvatures of the conduction band valleys, leading to decreased electron effective mass.<sup>14-15,48-49</sup> This is similar to the reduced electron effective mass with strain in silicon nMOS transistors, which leads to increased mobility.<sup>20-21</sup> Applying tensile strain to 2D transistors has also been suggested to lower Schottky barriers at the source and drain contacts,<sup>33,50-51</sup> potentially leading to lower contact resistance. However, because our devices have relatively long channels and our improvements in _μ_ FE and _I_ D do not depend on channel length (see Supporting Information Figure S7), we expect the contribution of contact resistance in our measurements to be relatively small.<sup>52</sup> Thus, we believe that the electrical performance improvements observed here are mostly related to electronic transport in the MoS2 channel, i.e. lower intervalley scattering and effective mass. 

We also consider the interaction of strain with defects in our MoS2 channels. Electron transport in our MoS2 channels is likely to occur in part by band-like transport, which is limited by scattering with phonons (e.g. intervalley<sup>12-13,41</sup> ), defects, or impurities – and in part by hopping-like transport between defect trap states.<sup>53</sup> When strain is applied, the former benefits from lowering of the phononassisted intervalley scattering rate.<sup>12-13,41</sup> On the other hand, tensile strain could also influence the hopping-like transport, as suggested by recent results which saw improvements in carrier lifetime with tensile strain, due to weaker trapping of charge carriers.<sup>54</sup> In other words, tensile strain is expected to benefit the electron mobility for both “pristine”, phonon-limited MoS2 samples, and for lower-quality, “defective” MoS2 samples. 

The large change in resistance with strain of our MoS2 transistors indicates that these devices could be useful for strain sensors. The figure of merit used to characterize strain sensors is the gauge factor (GF), defined as (∆𝑅𝑅⁄ �)⁄∆𝜀, where Δ𝑅= |𝑅� −𝑅�| is the change in resistance between 𝜀 and 0% strain, and 𝑅� is the initial resistance with 0% applied strain.<sup>55</sup> Metals are often used in commercial strain gauges due to their ease of fabrication, but they typically have relatively low GF < 50.<sup>56</sup> Silicon strain sensors have GF ~ 30-50 for polysilicon<sup>57-58</sup> and up to 200 for single-crystal silicon.<sup>59</sup> 2D materials like MoS2 and other TMDs are predicted to have large GFs because, similar to silicon and germanium,<sup>60</sup> they are piezoresistive. In addition, they can withstand much higher strains than conventional bulk materials, making them attractive for flexible electronics.<sup>28</sup> 

**Figure 4a** shows the resistance ( _R_ = _V_ DS/ _I_ D) vs. _V_ GS curves for the device in **Figure 1b** from 0% to 0.7% applied tensile strain. **Figure 4b** illustrates Δ _R_ / _R_ 0 vs. strain for several _V_ GS = -4.4 V, 0 V, 3 V, and 7 V. We find the largest change in resistance at _V_ GS = -4.4 V, which corresponds to the subthreshold region of the transistor (see **Figure 3a** ). Fitting a dashed line to the Δ _R_ / _R_ 0 vs. strain at this _V_ GS yields 

8 

an average GF ≈ 150. **Figure 4c** shows the calculated GF as a function of _V_ GS for each strain level in **Figure 4a** . We observe a peak in GF at all strain levels around _V_ GS = -4.4 V, with the maximum GF reaching ~200 for 0.4% tensile strain in this device. (We performed similar measurements on 7 other devices with channel lengths between 2 and 15 μm, and found an average maximum GF = 200 ± 45.) The GF displays a stronger gate dependence below and near threshold ( _V_ GS < 0) where current is limited by hopping-like transport between defect trap states,<sup>53</sup> recently shown to more weakly trap carriers when tensile strain is applied.<sup>54</sup> The GF is nearly constant in the linear transistor regime ( _V_ GS > 0, also see Figure 3a) where the band-like transport and mobility dominate. 



<!-- Start of picture text -->
(a) (b)<br>ε = 0.7% VGS = -4.4 V<br>0.6%<br>0.4%<br>0% 0 V<br>7 V<br>3 V<br>VDS = 1 V<br>(c) (d)<br>ε = 0.4% This<br>work<br>Exf MoS2 c-Si<br>BP<br>CVD<br>0.6% MoS2 PtSe2<br>Poly-Si<br>0.7%<br>InSe<br>Metal<br>m)<br>-<br> (M R<br><!-- End of picture text -->

**Figure 4.** (a) Resistance ( _R_ ) vs. _V_ GS curves of the device in **Figure 1b** at _V_ DS = 1 V at different levels of applied strain (ε). (b) ∆ _R_ / _R_ 0 vs. strain at different gate voltages for the curves in (a). (c) Gauge factor (GF = ∆𝑅𝑅⁄ �⁄∆𝜀) vs. _V_ GS for the different levels of strain. ∆𝜀 is always calculated with respect to 0% strain. The GF below approximately -5 V is uncertain when the measurable _I_ D minimum is reached (see Figure 3a), suggesting that the peak GF obtained could be higher at lower voltages. (d) GF vs. thickness for our best devices (shown as the blue square with error bars) in addition to various materials found in literature, including CVD-grown MoS2, exfoliated MoS2, indium selenide (InSe), platinum selenide (PtSe2), black phosphorus (BP), polycrystalline Si (poly-Si), crystalline Si (c-Si), and thin metal films. We note that the c-Si values are for bulk Si with thicknesses likely greater than 1 μm. 

**Figure 4d** compares the best GF values obtained in this work to those found in literature for MoS2, other 2D materials, silicon, and metals (of various thicknesses). Our GF for monolayer CVD-grown MoS2 is higher than the best GFs for monolayer and trilayer exfoliated MoS2,<sup>61</sup> CVD-grown MoS2,<sup>62-</sup> 64 other 2D materials (BP, InSe, and PtSe2),65-67 polysilicon,57-58 and thin metal films.56 Comparable or slightly higher GFs have been found for bulk crystalline silicon<sup>59,68</sup> and bilayer exfoliated MoS2,<sup>33,61</sup> 

9 

respectively. However, CVD-grown MoS2 is easier to integrate and more promising than bulk silicon or exfoliated MoS2 for large-area flexible and transparent sensors. We note that **Figure 4d** only displays GF calculated as (∆𝑅𝑅⁄ �)⁄∆𝜀, though some studies calculate GF as (∆𝐼𝐼⁄ �)⁄∆𝜀, where _I_ is current, which artificially yields much larger GF. For example, using the latter definition with current instead of resistance, the maximum GF achieved by our devices would be ~5000 instead of ~200. 

In summary, we studied the mobility enhancement of CVD-grown monolayer MoS2 transistors with tensile strain, by bending devices on flexible PEN substrates. We found a two-fold increase of mobility and current with tensile strain up to 0.7%, and a gauge factor (GF) up to ~200, which is the highest reported to date for sub-1 nm thin piezoresistive films. The improvements are attributed to changes in the band structure, including lower electron-phonon intervalley scattering and lower electron effective mass with tensile strain. These results achieve the largest mobility improvements of MoS2 transistors with strain to date, pointing the way for performance enhancements in integrated 2D electronics, and for the use of this material in strain sensors on flexible substrates. For electronics on rigid substrates (i.e. integrated with silicon), strain could be induced with nitride or metal layers, or by growth on substrates with different thermal coefficients of expansion or lattice constants.<sup>69-75</sup> Some approaches would have the additional advantage of inducing biaxial strain in the 2D material, which is expected to have a larger effect on the electrical properties than uniaxial strain.<sup>12,23,76-77</sup> 

### **ASSOCIATED CONTENT** 

### **Supporting Information.** 

The following file is available free of charge on the ACS Publications website. Device fabrication and MoS2 transfer process; Raman and photoluminescence (PL) spectroscopy of devices with strain; current-voltage characteristics of MoS2 transistors with strain; _C_ - _V_ characteristics of Au-Al2O3Au with strain; mobility ( _μ_ FE) and drain current ( _I_ D) as a function of strain; and degradation of devices at high levels of strain. 

### **AUTHOR INFORMATION** 

### **Corresponding Author** 

*E-mail: <u>epop@stanford.edu</u> 

### **Present Addresses** 

RWTH Aachen University (A.D.), Southern Methodist University (K.B.). 

### **Author Contributions** 

The manuscript was written through contributions of all authors. All authors have given approval to 

10 

the final version of the manuscript. 

### **Notes** 

The authors declare no competing financial interest. 

### **ACKNOWLEDGMENTS** 

This work was performed in part at the Stanford Nanofabrication Facility (SNF) and the Stanford Nano Shared Facilities (SNSF) which receive funding from the National Science Foundation (NSF) as part of the NNCI award 1542152. This work was also supported by the NSF EFRI 2-DARE grant 1542883. I.M.D. acknowledges support from the NDSEG and ARCS Fellowships. A.D. has been in part supported by the Swiss National Science Foundation’s Early Postdoc.Mobility fellowship (grant: P2EZP2_181619) and in part by Beijing Institute of Collaborative Innovation (BICI). 

### **REFERENCES** 

(1)  Das, S.; Sebastian, A.; Pop, E.; McClellan, C. J.; Franklin, A. D.; Grasser, T.; Knobloch, T.; Illarionov, Y.; Penumatcha, A. V.; Appenzeller, J.; Chen, Z.; Zhu, W.; Asselberghs, I.; Li, L.-J.; Avci, U. E.; Bhat, N.; Anthopoulos, T. D.; Singh, R. Transistors based on two-dimensional materials for future integrated circuits. _Nature Electronics_ **2021,** _4_ , 786-799. 

(2)  Smithe, K. K. H.; English, C. D.; Suryavanshi, S. V.; Pop, E. Intrinsic electrical transport and performance projections of synthetic monolayer MoS2 devices. _2D Materials_ **2017,** _4_ , 011009. (3)  Cun, H.; Macha, M.; Kim, H.; Liu, K.; Zhao, Y.; LaGrange, T.; Kis, A.; Radenovic, A. Waferscale MOCVD growth of monolayer MoS2 on sapphire and SiO2. _Nano Research_ **2019,** _12_ , 2646. (4)  Mirabelli, G.; McGeough, C.; Schmidt, M.; McCarthy, E. K.; Monaghan, S.; Povey, I. M.; McCarthy, M.; Gity, F.; Nagle, R.; Hughes, G.; Cafolla, A.; Hurley, P. K.; Duffy, R. Air sensitivity of MoS2, MoSe2, MoTe2, HfS2, and HfSe2. _Journal of Applied Physics_ **2016,** _120_ , 125102. 

(5)  Das, S.; Chen, H.-Y.; Penumatcha, A. V.; Appenzeller, J. High Performance Multilayer MoS2 Transistors with Scandium Contacts. _Nano Letters_ **2013,** _13_ , 100-105. 

(6)  English, C. D.; Shine, G.; Dorgan, V. E.; Saraswat, K. C.; Pop, E. Improved Contacts to MoS2 Transistors by Ultra-High Vacuum Metal Deposition. _Nano Letters_ **2016,** _16_ , 3824-3830. 

(7)  Yang, L.; Majumdar, K.; Liu, H.; Du, Y.; Wu, H.; Hatzistergos, M.; Hung, P. Y.; Tieckelmann, R.; Tsai, W.; Hobbs, C.; Ye, P. D. Chloride Molecular Doping Technique on 2D Materials: WS2 and MoS2. _Nano Letters_ **2014,** _14_ , 6275-6280. 

(8)  Zhao, Y.; Xu, K.; Pan, F.; Zhou, C.; Zhou, F.; Chai, Y. Doping, Contact and Interface Engineering of Two-Dimensional Layered Transition Metal Dichalcogenides Transistors. _Advanced Functional Materials_ **2017,** _27_ , 1603484. 

(9)  McClellan, C. J.; Yalon, E.; Smithe, K. K. H.; Suryavanshi, S. V.; Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **2021,** _15_ , 1587-1596. 

(10)  Yu, Z.; Pan, Y.; Shen, Y.; Wang, Z.; Ong, Z.-Y.; Xu, T.; Xin, R.; Pan, L.; Wang, B.; Sun, L.; Wang, J.; Zhang, G.; Zhang, Y. W.; Shi, Y.; Wang, X. Towards intrinsic charge transport in 

11 

monolayer molybdenum disulfide by defect and interface engineering. _Nature Communications_ **2014,** _5_ , 5290. 

(11)  Yu, Z.; Ong, Z.-Y.; Pan, Y.; Cui, Y.; Xin, R.; Shi, Y.; Wang, B.; Wu, Y.; Chen, T.; Zhang, Y.-W.; Zhang, G.; Wang, X. Realization of Room-Temperature Phonon-Limited Carrier Transport in Monolayer MoS2 by Dielectric and Carrier Screening. _Advanced Materials_ **2016,** _28_ , 547-552. (12)  Hosseini, M.; Elahi, M.; Pourfath, M.; Esseni, D. Strain induced mobility modulation in single-layer MoS2. _Journal of Physics D: Applied Physics_ **2015,** _48_ , 375104. 

(13)  Hosseini, M.; Elahi, M.; Pourfath, M.; Esseni, D. Strain-Induced Modulation of Electron Mobility in Single-Layer Transition Metal Dichalcogenides MX2 (M = Mo, W; X = S, Se). _IEEE Transactions on Electron Devices_ **2015,** _62_ , 3192-3198. 

(14)  Harada, N.; Sato, S.; Yokoyama, N. Computational study on electrical properties of transition metal dichalcogenide field-effect transistors with strained channel. _Journal of Applied Physics_ **2014,** _115_ , 034505. 

(15)  Shi, H.; Pan, H.; Zhang, Y.-W.; Yakobson, B. I. Quasiparticle band structures and optical properties of strained monolayer MoS2 and WS2. _Physical Review B_ **2013,** _87_ , 155304. 

(16)  Takagi, S. i.; Hoyt, J. L.; Welser, J. J.; Gibbons, J. F. Comparative study of phonon‐limited mobility of two‐dimensional electrons in strained and unstrained Si metal–oxide–semiconductor field‐effect transistors. _Journal of Applied Physics_ **1996,** _80_ , 1567-1577. 

(17)  Welser; Hoyt; Gibbons NMOS and PMOS transistors fabricated in strained silicon/relaxed silicon-germanium structures. _1992 International Technical Digest on Electron Devices Meeting_ , 13-16 Dec. 1992, **1992.** 10.1109/IEDM.1992.307527. 

(18)  Thompson, S.; Anand, N.; Armstrong, M.; Auth, C.; Arcot, B.; Alavi, M.; Bai, P.; Bielefeld, J.; Bigwood, R.; Brandenburg, J.; Buehler, M.; Cea, S.; Chikarmane, V.; Choi, C.; Frankovic, R.; Ghani, T.; Glass, G.; Han, W.; Hoffmann, T.; Hussein, M.; Jacob, P.; Jain, A.; Jan, C.; Joshi, S.; Kenyon, C.; Klaus, J.; Klopcic, S.; Luce, J.; Ma, Z.; Mcintyre, B.; Mistry, K.; Murthy, A.; Nguyen, P.; Pearson, H.; Sandford, T.; Schweinfurth, R.; Shaheed, R.; Sivakumar, S.; Taylor, M.; Tufts, B.; Wallace, C.; Wang, P.; Weber, C.; Bohr, M. A 90 nm logic technology featuring 50 nm strained silicon channel transistors, 7 layers of Cu interconnects, low κ ILD, and 1 μm<sup>2</sup> SRAM cell. _International Electron Devices Meeting (IEDM) Technical Digest_ , 8-11 Dec. 2002, **2002.** 

(19)  Mistry, K.; Armstrong, M.; Auth, C.; Cea, S.; Coan, T.; Ghani, T.; Hoffmann, T.; Murthy, A.; Sandford, J.; Shaheed, R.; Zawadzki, K.; Zhang, K.; Thompson, S.; Bohr, M. Delaying forever: Uniaxial strained silicon transistors in a 90nm CMOS technology. _Symposium on VLSI Technology_ , **2004.** 

(20)  Thompson, S. E.; Armstrong, M.; Auth, C.; Cea, S.; Chau, R.; Glass, G.; Hoffman, T.; Klaus, J.; Zhiyong, M.; Mcintyre, B.; Murthy, A.; Obradovic, B.; Shifren, L.; Sivakumar, S.; Tyagi, S.; Ghani, T.; Mistry, K.; Bohr, M.; El-Mansy, Y. A logic nanotechnology featuring strained-silicon. _IEEE Electron Device Letters_ **2004,** _25_ , 191-193. 

(21)  Mohta, N.; Thompson, S. E. Mobility enhancement: The next vector to extend Moore's law. _IEEE Circuits Devices Mag._ **2005,** _21_ , 18-23. 

(22)  Rice, C.; Young, R. J.; Zan, R.; Bangert, U.; Wolverson, D.; Georgiou, T.; Jalil, R.; Novoselov, K. S. Raman-scattering measurements and first-principles calculations of straininduced phonon shifts in monolayer MoS2. _Physical Review B_ **2013,** _87_ , 081307. 

(23)  Chang, C.-H.; Fan, X.; Lin, S.-H.; Kuo, J.-L. Orbital analysis of electronic structure and phonon dispersion in MoS2, MoSe2, WS2, and WSe2 monolayers under strain. _Physical Review B_ **2013,** _88_ , 195420. 

12 

(24)  He, K.; Poole, C.; Mak, K. F.; Shan, J. Experimental Demonstration of Continuous Electronic Structure Tuning via Strain in Atomically Thin MoS2. _Nano Letters_ **2013,** _13_ , 2931-2936. 

(25)  Aslan, O. B.; Datye, I. M.; Mleczko, M. J.; Sze Cheung, K.; Krylyuk, S.; Bruma, A.; Kalish, I.; Davydov, A. V.; Pop, E.; Heinz, T. F. Probing the Optical Properties and Strain-Tuning of Ultrathin Mo1–xWxTe2. _Nano Letters_ **2018,** _18_ , 2485-2491. 

(26)  Conley, H. J.; Wang, B.; Ziegler, J. I.; Haglund, R. F.; Pantelides, S. T.; Bolotin, K. I. Bandgap Engineering of Strained Monolayer and Bilayer MoS2. _Nano Letters_ **2013,** _13_ , 36263630. 

(27)  Vaziri, S.; Yalon, E.; Munoz Rojo, M.; Suryavanshi, S. V.; Zhang, H.; McClellan, C. J.; Bailey, C. S.; Smithe, K. K. H.; Gabourie, A. J.; Chen, V.; Deshmukh, S.; Bendersky, L.; Davydov, A. V.; Pop, E. Ultrahigh thermal isolation across heterogeneously layered two-dimensional materials. _Sci Adv_ **2019,** _5_ , eaax1325. 

(28)  Bertolazzi, S.; Brivio, J.; Kis, A. Stretching and Breaking of Ultrathin MoS2. _ACS Nano_ **2011,** _5_ , 9703-9709. 

(29)  Mohiuddin, T. M. G.; Lombardo, A.; Nair, R. R.; Bonetti, A.; Savini, G.; Jalil, R.; Bonini, N.; Basko, D. M.; Galiotis, C.; Marzari, N.; Novoselov, K. S.; Geim, A. K.; Ferrari, A. C. Uniaxial strain in graphene by Raman spectroscopy: G peak splitting, Gruneisen parameters, and sample orientation. _Physical Review B_ **2009,** _79_ , 205433. 

(30)  Schauble, K.; Zakhidov, D.; Yalon, E.; Deshmukh, S.; Grady, R. W.; Cooley, K. A.; McClellan, C. J.; Vaziri, S.; Passarello, D.; Mohney, S. E.; Toney, M. F.; Sood, A. K.; Salleo, A.; Pop, E. Uncovering the Effects of Metal Contacts on Monolayer MoS2. _ACS Nano_ **2020,** _14_ , 14798–14808. 

(31)  Smithe, K. K. H.; Suryavanshi, S. V.; Muñoz Rojo, M.; Tedjarati, A. D.; Pop, E. Low Variability in Synthetic Monolayer MoS2 Devices. _ACS Nano_ **2017,** _11_ , 8456-8463. 

(32)  Christopher, J. W.; Vutukuru, M.; Lloyd, D.; Bunch, J. S.; Goldberg, B. B.; Bishop, D. J.; Swan, A. K. Monolayer MoS2 Strained to 1.3% With a Microelectromechanical System. _Journal of Microelectromechanical Systems_ **2019,** _28_ , 254-263. 

(33)  John, A. P.; Thenapparambil, A.; Thalakulam, M. Strain-engineering the Schottky barrier and electrical transport on MoS2. _Nanotechnology_ **2020,** _31_ , 275703. 

(34)  Zhu, C. R.; Wang, G.; Liu, B. L.; Marie, X.; Qiao, X. F.; Zhang, X.; Wu, X. X.; Fan, H.; Tan, P. H.; Amand, T.; Urbaszek, B. Strain tuning of optical emission energy and polarization in monolayer and bilayer MoS2. _Physical Review B_ **2013,** _88_ , 121301. 

(35)  Beal, A. R.; Knights, J. C.; Liang, W. Y. Transmission spectra of some transition metal dichalcogenides. II. Group VIA: trigonal prismatic coordination. _Journal of Physics C: Solid State Physics_ **1972,** _5_ , 3540-3551. 

(36)  Wilson, J. A.; Yoffe, A. D. The transition metal dichalcogenides discussion and interpretation of the observed optical, electrical and structural properties. _Advances in Physics_ **1969,** _18_ , 193335. 

(37)  Ji-Song, L.; Thompson, S. E.; Fossum, J. G. Comparison of threshold-voltage shifts for uniaxial and biaxial tensile-stressed n-MOSFETs. _IEEE Electron Device Letters_ **2004,** _25_ , 731733. 

(38)  Dobrescu, L.; Petrov, M.; Dobrescu, D.; Ravariu, C. Threshold voltage extraction methods for MOS transistors. _2000 International Semiconductor Conference_ , 10-14 Oct. 2000, **2000.** 10.1109/SMICND.2000.890257. 

13 

(39)  Chang, H.-Y.; Yang, S.; Lee, J.; Tao, L.; Hwang, W.-S.; Jena, D.; Lu, N.; Akinwande, D. High-Performance, Highly Bendable MoS2 Transistors with High-κ Dielectrics for Flexible LowPower Systems. _ACS Nano_ **2013,** _7_ , 5446-5452. 

(40)  Münzenrieder, N.; Petti, L.; Zysset, C.; Görk, D.; Büthe, L.; Salvatore, G. A.; Tröster, G. Investigation of gate material ductility enables flexible a-IGZO TFTs bendable to a radius of 1.7 mm. _2013 Proceedings of the European Solid-State Device Research Conference (ESSDERC)_ , 1620 Sept. 2013, **2013.** 10.1109/ESSDERC.2013.6818893. 

(41)  Ferry, D. K. Electron transport in some transition metal di-chalcogenides: MoS2 and WS2. _Semiconductor Science and Technology_ **2017,** _32_ , 085003. 

(42)  Herring, C. Character tables for two space groups. _Journal of the Franklin Institute_ **1942,** _233_ , 525-543. 

(43)  Ribeiro-Soares, J.; Almeida, R. M.; Barros, E. B.; Araujo, P. T.; Dresselhaus, M. S.; Cançado, L. G.; Jorio, A. Group theory analysis of phonons in two-dimensional transition metal dichalcogenides. _Physical Review B_ **2014,** _90_ , 115438. 

(44)  Hill, H. M.; Rigosi, A. F.; Rim, K. T.; Flynn, G. W.; Heinz, T. F. Band Alignment in MoS2/WS2 Transition Metal Dichalcogenide Heterostructures Probed by Scanning Tunneling Microscopy and Spectroscopy. _Nano Letters_ **2016,** _16_ , 4831-4837. 

(45)  Gaddemane, G.; Gopalan, S.; Van de Put, M. L.; Fischetti, M. V. Limitations of ab initio methods to predict the electronic-transport properties of two-dimensional semiconductors: the computational example of 2H-phase transition metal dichalcogenides. _Journal of Computational Electronics_ **2021,** _20_ , 49-59. 

(46)  Jin, Z.; Li, X.; Mullen, J. T.; Kim, K. W. Intrinsic transport properties of electrons and holes in monolayer transition-metal dichalcogenides. _Physical Review B_ **2014,** _90_ , 045422. 

(47)  Aslan, O. B.; Deng, M.; Heinz, T. F. Strain tuning of excitons in monolayer WSe2. _Physical Review B_ **2018,** _98_ , 115308. 

(48)  Yue, Q.; Kang, J.; Shao, Z.; Zhang, X.; Chang, S.; Wang, G.; Qin, S.; Li, J. Mechanical and electronic properties of monolayer MoS2 under elastic strain. _Physics Letters A_ **2012,** _376_ , 11661170. 

(49)  Yun, W. S.; Han, S. W.; Hong, S. C.; Kim, I. G.; Lee, J. D. Thickness and strain effects on electronic structures of transition metal dichalcogenides: 2H-MX2 semiconductors (M = Mo, W; X = S, Se, Te). _Physical Review B_ **2012,** _85_ , 033305. 

(50)  Quereda, J.; Palacios, J. J.; Agräit, N.; Castellanos-Gomez, A.; Rubio-Bollinger, G. Strain engineering of Schottky barriers in single- and few-layer MoS2 vertical devices. _2D Materials_ **2017,** _4_ , 021006. 

(51)  Shen, T.; Penumatcha, A. V.; Appenzeller, J. Strain Engineering for Transition Metal Dichalcogenides Based Field Effect Transistors. _ACS Nano_ **2016,** _10_ , 4712-4718. 

(52)  Kumar, A.; Schauble, K.; Neilson, K. M.; Tang, A.; Ramesh, P.; Wong, H. S. P.; Pop, E.; Saraswat, K. Sub-200 Ω•um Alloyed Contacts to Synthetic Monolayer MoS2. _2021 IEEE International Electron Devices Meeting (IEDM)_ , 11-16 Dec. 2021, **2021.** 10.1109/IEDM19574.2021.9720609. 

(53)  Zhu, W.; Low, T.; Lee, Y.-H.; Wang, H.; Farmer, D. B.; Kong, J.; Xia, F.; Avouris, P. Electronic transport and device prospects of monolayer molybdenum disulphide grown by chemical vapour deposition. _Nature Communications_ **2014,** _5_ , 3087. 

14 

(54)  Hong, H.; Cheng, Y.; Wu, C.; Huang, C.; Liu, C.; Yu, W.; Zhou, X.; Ma, C.; Wang, J.; Zhang, Z.; Zhao, Y.; Xiong, J.; Liu, K. Modulation of carrier lifetime in MoS2 monolayer by uniaxial strain. _Chinese Physics B_ **2020,** _29_ , 077201. 

(55)  Beckwith, T. G.; Marangoni, R. D.; Lienhard, J. H., _Mechanical Measurements_ . International Edition ed.; Pearson Education, Limited: 2008. 

(56)  Li, C.; Hesketh, P. J.; Maclay, G. J. Thin gold film strain gauges. _Journal of Vacuum Science & Technology A_ **1994,** _12_ , 813-819. 

(57)  French, P. J.; Evans, A. G. R. Piezoresistance in polysilicon and its applications to strain gauges. _Solid-State Electronics_ **1989,** _32_ , 1-10. 

(58)  Kim, Y.; Kim, Y.; Lee, C.; Kwon, S. Thin Polysilicon Gauge for Strain Measurement of Structural Elements. _IEEE Sensors Journal_ **2010,** _10_ , 1320-1327. 

(59)  Beeby, S., _MEMS Mechanical Sensors_ . Artech House: 2004. 

(60)  Smith, C. S. Piezoresistance Effect in Germanium and Silicon. _Physical Review_ **1954,** _94_ , 42-49. 

(61)  Manzeli, S.; Allain, A.; Ghadimi, A.; Kis, A. Piezoresistivity and Strain-induced Band Gap Tuning in Atomically Thin MoS2. _Nano Letters_ **2015,** _15_ , 5330-5335. 

(62)  Park, M.; Park, Y. J.; Chen, X.; Park, Y.-K.; Kim, M.-S.; Ahn, J.-H. MoS2-Based Tactile Sensor for Electronic Skin Applications. _Advanced Materials_ **2016,** _28_ , 2556-2562. 

(63)  Zhu, M.; Li, J.; Inomata, N.; Toda, M.; Ono, T. Vanadium-doped molybdenum disulfide film-based strain sensors with high gauge factor. _Applied Physics Express_ **2019,** _12_ , 015003. 

(64)  Zhu, M.; Sakamoto, K.; Li, J.; Inomata, N.; Toda, M.; Ono, T. Piezoresistive strain sensor based on monolayer molybdenum disulfide continuous film deposited by chemical vapor deposition. _Journal of Micromechanics and Microengineering_ **2019,** _29_ , 055002. 

(65)  Chen, L.; Liang, D.; Yu, Z.; Li, S.; Feng, X.; Li, B.; Li, Y.; Zhang, Y.; Ang, K. Ultrasensitive Flexible Strain Sensor based on Two-Dimensional InSe for Human Motion Surveillance. _2019 IEEE International Electron Devices Meeting (IEDM)_ , 7-11 Dec. 2019, **2019.** 10.1109/IEDM19573.2019.8993476. 

(66)  Wagner, S.; Yim, C.; McEvoy, N.; Kataria, S.; Yokaribas, V.; Kuc, A.; Pindl, S.; Fritzen, C.P.; Heine, T.; Duesberg, G. S.; Lemme, M. C. Highly Sensitive Electromechanical Piezoresistive Pressure Sensors Based on Large-Area Layered PtSe2 Films. _Nano Letters_ **2018,** _18_ , 3738-3745. (67)  Zhang, Z.; Li, L.; Horng, J.; Wang, N. Z.; Yang, F.; Yu, Y.; Zhang, Y.; Chen, G.; Watanabe, K.; Taniguchi, T.; Chen, X. H.; Wang, F.; Zhang, Y. Strain-Modulated Bandgap and PiezoResistive Effect in Black Phosphorus Field-Effect Transistors. _Nano Letters_ **2017,** _17_ , 6097-6103. (68)  Won, S. M.; Kim, H.; Lu, N.; Kim, D.; Solar, C. D.; Duenas, T.; Ameen, A.; Rogers, J. A. Piezoresistive Strain Sensors and Multiplexed Arrays Using Assemblies of Single-Crystalline Silicon Nanoribbons on Plastic Substrates. _IEEE Transactions on Electron Devices_ **2011,** _58_ , 4074-4078. 

(69)  Wan, W.; Chen, L.; Zhan, L.; Zhu, Z.; Zhou, Y.; Shih, T.; Guo, S.; Kang, J.; Huang, H.; Cai, W. Syntheses and bandgap alterations of MoS2 induced by stresses in graphene-platinum substrates. _Carbon_ **2018,** _131_ , 26-30. 

(70)  Ahn, G. H.; Amani, M.; Rasool, H.; Lien, D.-H.; Mastandrea, J. P.; Ager Iii, J. W.; Dubey, M.; Chrzan, D. C.; Minor, A. M.; Javey, A. Strain-engineered growth of two-dimensional materials. _Nature Communications_ **2017,** _8_ , 608. 

15 

(71)  Chae, W. H.; Cain, J. D.; Hanson, E. D.; Murthy, A. A.; Dravid, V. P. Substrate-induced strain and charge doping in CVD-grown monolayer MoS2. _Applied Physics Letters_ **2017,** _111_ , 143106. 

(72)  Chai, Y.; Su, S.; Yan, D.; Ozkan, M.; Lake, R.; Ozkan, C. S. Strain Gated Bilayer Molybdenum Disulfide Field Effect Transistor with Edge Contacts. _Scientific Reports_ **2017,** _7_ , 41593. 

(73)  Chen, P.; Xu, W.; Gao, Y.; Warner, J. H.; Castell, M. R. Epitaxial Growth of Monolayer MoS2 on SrTiO3 Single Crystal Substrates for Applications in Nanoelectronics. _ACS Applied Nano Materials_ **2018,** _1_ , 6976-6988. 

(74)  Peña, T.; Chowdhury, S. A.; Azizimanesh, A.; Sewaket, A.; Askari, H.; Wu, S. M. Strain engineering 2D MoS2 with thin film stress capping layers. _2D Materials_ **2021,** _8_ , 045001. 

(75)  Chen, Y.; Deng, W.; Chen, X.; Wu, Y.; Shi, J.; Zheng, J.; Chu, F.; Liu, B.; An, B.; You, C.; Jiao, L.; Liu, X.; Zhang, Y. Carrier mobility tuning of MoS2 by strain engineering in CVD growth process. _Nano Research_ **2021,** _14_ , 2314-2320. 

(76)  Ghorbani-Asl, M.; Borini, S.; Kuc, A.; Heine, T. Strain-dependent modulation of conductivity in single-layer transition-metal dichalcogenides. _Physical Review B_ **2013,** _87_ , 235434. 

(77)  Johari, P.; Shenoy, V. B. Tuning the Electronic Properties of Semiconducting Transition Metal Dichalcogenides by Applying Mechanical Strains. _ACS Nano_ **2012,** _6_ , 5449-5456. 

16 

### **Table of Contents Figure** 



1 

## **<u>Supporting Information</u>** 

# **Strain-Enhanced Mobility of Monolayer MoS2** 

Isha M. Datye,<sup>1</sup> Alwin Daus,<sup>1,2</sup> Ryan W. Grady,<sup>1</sup> Kevin Brenner,<sup>1,3</sup> Sam Vaziri,<sup>1</sup> and Eric Pop<sup>1,4,5,*</sup> 

> 1 _Department of Electrical Engineering, Stanford University, Stanford, CA 94305, USA_ 

> 2 _Present address: Chair for Electronic Devices, RWTH Aachen University, Aachen, 52074, Germany_ 

> 3 _Present address: Department of Electrical and Computer Engineering, Southern Methodist University, Dallas, TX 75275, USA_ 

> 4 _Department of Materials Science & Engineering, Stanford University, Stanford, CA 94305, USA_ 

> 5 _Precourt Institute for Energy, Stanford University, Stanford, CA 94305, USA_ 

*Corresponding Author: epop@stanford.edu 

## **1. Device fabrication and MoS2 transfer process** 

### **1.1 Fabrication of monolayer (1L) MoS2 transistors** 

The steps for fabricating our MoS2 transistors on polyethylene naphthalate (PEN) substrates are described below. We include a schematic for each step of the process in Figure S1. 

First, we pattern Cu (28 nm)/Au (5 nm) back-gates (BG) by optical lithography directly on the PEN (125 μm thick), and deposit them using electron-beam (e-beam) evaporation. We use Cu in contact with PEN because of its higher ductility than Au,<sup>1</sup> and we use a thin Au layer to encapsulate the Cu and limit its oxidation. We then deposit ~20 nm aluminum oxide (Al2O3) using atomic layer deposition (ALD) in a Savannah S200 from Cambridge Nanotech, with trimethyl aluminum (TMA) and H2O as precursors for 200 cycles. We perform ALD at 130°C, which is within the thermal limitations of our PEN substrates. 

The MoS2 is grown by chemical vapor deposition (CVD) on separate SiO2/Si substrates<sup>2</sup> (chips of approx. 1.5×2 cm) and transferred onto the Al2O3, as detailed in Section 1.2. Next, we pattern and e-beam evaporate Au (55 nm) to form the source and drain contacts to the transistors. The channel length of our transistors ranges from 2 to 15 μm, which is within the limits of optical lithography on PEN substrates. We also define and evaporate Ti (3 nm)/Cu (30 nm)/Au (5 nm) pads connected to the Au contacts for device probing. We note that before metal deposition of the pads, we etch the MoS2 underneath this region to improve the adhesion of the metal to the PEN substrate. The MoS2 is etched using O2 plasma with 100 sccm O2 at 150 mTorr at a power of 50 W for 45 seconds. Finally, the MoS2 channel is patterned and etched into a rectangle to define the width of the transistor channel using the same etch conditions. We note that the fabrication processes outlined here do not damage the MoS2 film or leave photoresist residue.<sup>3</sup> 

2 



<!-- Start of picture text -->
2. Deposit Al2O3 by ALD<br>1. Pattern and evaporate local<br>at 130°C, 200 cycles<br>metal back-gates (BG)<br>Al 2 O 3<br>Cu/Au BG Cu/Au BG<br>PEN PEN<br>3. Transfer MoS2 using<br>PMMA/polystyrene and<br>H2O + NaOH<br>5. Etch MoS2 with O2<br>plasma to define channel<br>Al 2 O 3<br>Cu/Au BG<br>Au Au 4. Pattern and evaporate Au  PEN<br>source and drain contacts<br>Al 2 O 3<br>Cu/Au BG<br>PEN<br>Au Au<br>Al 2 O 3<br>Cu/Au BG<br>PEN<br><!-- End of picture text -->

**Figure S1.** Summary of steps used to fabricate our MoS2 transistors on flexible PEN substrates. 

### **1.2 MoS2 transfer process** 

We describe the steps used to transfer MoS2 onto PEN substrates as follows.<sup>4</sup> 

1. Place thin strips of tape (Nitto Denko RevAlpha series thermal release tape or Kapton) on all four edges of the chip with MoS2 grown by CVD on SiO2/Si. 

2. Spin-coat 2% PMMA at 2500 rpm for 1 minute, and then bake for 45 seconds at 135°C. 

3. Spin-coat polystyrene (PS) dissolved in toluene (PS/toluene 3 g/20 mL) at 2000 rpm for 1 minute, and then bake for 5 minutes at 85°C. 

4. Remove the tape very carefully from edges of the chip. 

5. Place MoS2 sample with polymer support layers in a beaker of water. Agitate sample in water to cause delamination of MoS2/polymer stack from growth substrate. Use tweezers to poke edges of the polymer stack to initiate delamination from substrate. 

6. If MoS2/polymer stack does not delaminate in water, place sample in a beaker of 1M NaOH for a few minutes to etch SiO2 and promote delamination from the substrate. After the MoS2/polymer stack begins to delaminate from the SiO2/Si substrate, return the chip to a fresh beaker of water. Return to step 5 until the entire film has delaminated from the substrate. 

7. After the MoS2/polymer film has delaminated from the growth substrate, it will float on the water. Use the PEN to pick up the floating sample. 

8. Carefully blow a N2 gun perpendicular to the sample to remove water trapped between the MoS2 and PEN. 

9. Place the sample on a hot plate at 55°C for 5 minutes, then increase the temperature to 85°C and heat the sample for 5 minutes, and finally increase the temperature to 135°C. This gradual increase in temperature minimizes damage (e.g. bubbles and holes) to the MoS2 film after the transfer. When the temperature reaches 135°C, remove the sample from the hot plate. 

10. Place the obtained polymer/MoS2/PEN stack in toluene for 12 hours to dissolve the PMMA and PS polymers. Rinse the sample in acetone and IPA after removing it from toluene. 

3 

## **2. Raman and photoluminescence (PL) spectroscopy of devices with strain** 

We use Raman and photoluminescence (PL) spectroscopy to confirm that the MoS2 is under tensile strain, in addition to the visual inspections shown in Figure 2b of the main text. 

Figure S2a-b below illustrates the E’ (in-plane) and A1’ (out-of-plane) Raman peak positions for 10 devices, respectively. The data are presented as box plots for 0%, 0.7%, and back to 0% applied tensile strain. For each transistor, we averaged the Raman peak positions over ~5 spots across the channel. The average E’ peak positions across all 10 devices after device fabrication, with 0.7% strain, and after the strain is released are ~384.6 ± 0.1 cm<sup>-1</sup> , ~382.8 ± 0.4 cm<sup>-1</sup> , and ~384.6 ± 0.2 cm<sup>-1</sup> , respectively. This marks a 2.5 ± 0.5 cm<sup>-1</sup> /% strain shifting rate of the E’ peak. 

As expected, the shift of the A1’ Raman peak (at ~403 cm<sup>-1</sup> ) is lower (1.0 ± 0.3 cm<sup>-1</sup> /% strain) than that of the E’ peak. This shift may be partially due to altered substrate interactions rather than purely a direct strain effect on the out-of-plane vibrations.<sup>5</sup> 

We note that some studies report peak splitting of the degenerate E’ Raman mode with tensile strain due to breaking the symmetry of the crystal.<sup>6-7</sup> Our MoS2 E’ peak did not exhibit such behavior, likely because the MoS2 did not experience large enough strains. 



<!-- Start of picture text -->
(a) (b)<br>E’ Raman mode A1’ Raman mode<br><!-- End of picture text -->

**Figure S2.** Box plots showing (a) E’ and (b) A1’ Raman peak positions. The figures include data averaged from ~5 spots across the channels of all devices and show Raman peak positions before applying strain, with 0.7% strain, and after the strain returns to 0%. 

We also perform PL spectroscopy on our samples to study the change in the optical band gap as a function of strain, with the A and B excitons schematically illustrated in Figure S3a. Figure S3b shows the position of the A exciton peak at 0%, 0.4%, 0.6%, and back to 0% strain. Each box plot represents data from 7 transistors, and for each transistor we averaged the peak position over 3 spots in the channel region. The average A exciton peak positions at 0% strain, 0.4% strain, 0.6% strain, and back to 0% strain are 1.813 ± 0.004 eV, 1.793 ± 0.005 eV, 1.773 ± 0.005 eV, and 1.814 ± 0.005 eV, respectively. We also point out that the PL peak intensity decreases slightly with increasing tensile strain (see Figures 2d-e in the main text), due to a narrowing of the indirect optical gap of monolayer MoS2 between the Γ (valence) and K (conduction) points.<sup>6,8</sup> 

4 



<!-- Start of picture text -->
(a) (b)<br>A exciton<br>E G,optical<br>A exciton<br>B exciton<br>k<br>K<br><!-- End of picture text -->

**Figure S3.** (a) Schematic band diagram of monolayer MoS2 showing the optical band gap ( _E_ G,optical) and the A and B excitons at the K point, without strain applied.<sup>9-10</sup> (b) Box plots showing the A exciton peak position from photoluminescence measurements as a function of strain, including after the strain is released. Each box plot includes data from 3 spots across the channels of 7 devices. 

We note that CVD-grown MoS2 typically attains some built-in tensile strain during the growth process, due to the larger thermal coefficient of expansion (TCE) of MoS2 compared to the underlying SiO2.<sup>11</sup> Transferring the MoS2 to another substrate should release this built-in strain, so we expect that the MoS2 is either unstrained or slightly compressively strained upon transfer to the PEN. However, the Raman and PL peak positions of unstrained MoS2 are difficult to determine because these peaks are affected by many factors in addition to strain, such as doping and substrate interactions.<sup>5,11-13</sup> Our MoS2 is transferred onto Al2O3, which is known to cause peak shifts in the Raman and PL spectra of MoS2.<sup>14</sup> Therefore, we are unable to conclude whether our devices initially have any built-in tensile or compressive strain from the transfer and fabrication processes. 

## **3. Current-voltage characteristics of MoS2 transistors with strain** 

We perform electrical measurements with a Keithley 4200-SCS using Keithley Interactive Test Environment (KITE) software. Figure S4 shows the same _I_ D- _V_ GS curves from Figure 3a of the main text but here includes the reverse sweep (dashed lines) in addition to the forward sweep (solid lines). The difference between the forward and reverse voltage sweep measurements points to hysteresis in the device, likely arising from electrostatic screening by H2O and O2 adsorbates trapped at the MoS2-Al2O3 interface during the transfer process.<sup>15</sup> The gate current ( _I_ G) at different strain levels is depicted by the dotted lines and does not exceed 1.2 nA during any of the measurements, indicating that the leakage current through the gate dielectric remains low during all strain-dependent measurements. 

The _I_ D- _V_ DS measurements shown in Figure 3b of the main text include forward and backward voltage sweeps with no observable hysteresis, which also suggests that the traps are located at the MoS2-Al2O3 interface or within the Al2O3, and are mainly affected by sweeping the gate voltage. 

5 



<!-- Start of picture text -->
ε = 0%, released V DS = 1 V<br>0.7%<br>0.6% I D<br>0.4%<br>0%<br>I G<br><!-- End of picture text -->

**Figure S4.** Measured _I_ D- _V_ GS curves showing forward (solid) and backward (dashed lines) sweeps at different strain levels, for the same device shown in Figure 3a of the main text, with _W_ = 20 μm, _L_ = 8 μm, and _V_ DS = 1 V. The gate current ( _I_ G) at different levels of strain is depicted by the dotted lines and does not exceed 1.2 nA for all measurements. 

## **4.** **_C-V_ characteristics of Au-Al2O3-Au capacitors with strain** 

We characterize the capacitance of the Al2O3 gate oxide using metal-oxide-metal structures (see Figure S5a for a top-view schematic) to enable more accurate estimation of field-effect mobility ( _μ_ FE). We verify that the capacitance does not change with strain, as shown in Figure S5b. We measure an oxide capacitance _C_ ox ≈ 312 nF/cm<sup>2</sup> , which we use in our calculation of _μ_ FE. With ellipsometry, we estimate an Al2O3 thickness _t_ ox ~ 20 nm, which gives a relative dielectric constant _ϵ_ ox ~ 7 for our Al2O3, based on the equation 𝐶𝑜𝑥 = 𝜖𝑜𝑥𝜖𝑜/𝑡𝑜𝑥, where _C_ ox is normalized by the area of the Au electrode overlap and _ϵ_ o = 8.85×10<sup>-14</sup> F/cm. The equivalent oxide thickness (𝐸𝑂𝑇= 𝜖𝑆𝑖𝑂2𝑡𝑜𝑥/𝜖𝑜𝑥) of our Al2O3 film is ~11 nm. The alternating current (AC) frequency and voltage bias during the measurements are 20 kHz and 30 mV, respectively. 



<!-- Start of picture text -->
(a) (b)<br>ε = 0%<br>Au<br>0.7%<br>bottom<br>electrode<br>Au top<br>ALD Al2O3<br>electrode<br><!-- End of picture text -->

**Figure S5.** (a) Schematic of Au-Al2O3-Au structure for capacitance-voltage measurements. (b) Capacitance-voltage measurements of an Au-Al2O3-Au test structure with and without 0.7% tensile strain. The capacitance is normalized by the area of the top and bottom Au electrode overlap. 

## **5. Mobility (** **_μ_ FE) and drain current (** **_I_ D) as a function of tensile strain** 

Figure S6a-b shows the magnitudes of _μ_ FE and _I_ D as a function of strain, with each color corresponding to a different device. The data for 8 devices shown here correspond to the same data 

6 

represented in box plots in Figure 3c-d of the main text. All values of _μ_ FE are extracted at the same carrier density _n_ ~ 1.1×10<sup>13</sup> cm<sup>-2</sup> and _V_ DS = 1 V, and all values of _I_ D are extracted at _V_ GS = 7 V and _V_ DS = 1 V. The data points on the right side of each plot show _μ_ FE and _I_ D after the strain is released back to 0%. We note that the unstrained mobilities are lower than in some other MoS2 studies,<sup>2,16</sup> which we attribute to growth variations and partial degradation of the MoS2 after transfer to the flexible substrates. We also perform strain-dependent electrical measurements on a different set of monolayer MoS2 transistors with higher initial mobilities, which is discussed in Section 6. 



<!-- Start of picture text -->
(a) (b)<br>n  ~ 1.1×10 13 cm -2 V GS = 7 V<br>V DS = 1 V V DS = 1 V<br> (a) Mobility ( μ FE) and (b) drain current () and (b) drain current ( I D) for 8 different devices at 0%, 0.4%, 0.6%, 0.7%, and back to ) for 8 different devices at 0%, 0.4%, 0.6%, 0.7%, and back to<br>0% strain. Channel lengths of these devices are  L  = 2 to 15 μm, also see Figure S7.<br>(a) (b)<br>n  ~ 1.1×10 13 cm -2 V GS = 7 V<br>V DS = 1 V V DS = 1 V<br>released released<br><!-- End of picture text -->

**Figure S6.** (a) Mobility ( _μ_ FE) and (b) drain current () and (b) drain current ( _I_ D) for 8 different devices at 0%, 0.4%, 0.6%, 0.7%, and back to ) for 8 different devices at 0%, 0.4%, 0.6%, 0.7%, and back to 0% strain. Channel lengths of these devices are _L_ = 2 to 15 μm, also see Figure S7. 

**Figure S7.** (a) Normalized _μ_ FE and (b) normalized _I_ D at 0.7% tensile strain as a function of channel length. The mobility and current are normalized to their unstrained values (subscript “0”). 

We plot normalized _μ_ FE and _I_ D at 0.7% strain as a function of _L_ = 2 to 15 μm (see Figure S7a-b). There is no noticeable trend of mobility or current improvement with strain for different channel lengths, indicating that contact effects do not play a significant role across this range of channel lengths. Some theoretical studies have also predicted a directional (armchair vs. zigzag) dependence of <mark>MoS</mark> 2 <mark>m</mark> obility on strain.<sup>17</sup> <mark>However, the theoretical predictions are virtually indistinguishable at the lower strains applied in our work (<1%) and they are below our measurement sensitivity. In other words, we cannot conclude whether the variability observed in Figure S7 is due to applying strain along different crystallographic directions or (more likely) due to device and fabrication non-uniformity.</mark> 

7 

Figure S8a-b shows absolute and normalized _μ_ FE as a function of strain at a lower carrier density ( _n_ ~ 4.8×10<sup>12</sup> cm<sup>-2</sup> ). The absolute and normalized _μ_ FE at lower _n_ are slightly lower than those at higher _n_ (see Figure S6a and Figure 3c in the main text), but the overall trends are similar. 



<!-- Start of picture text -->
(a) (b)<br>n  ~ 4.8×10 12 cm -2 n  ~ 4.8×10 12 cm -2<br>V DS = 1 V V DS = 1 V<br>Strain<br>released<br>released<br><!-- End of picture text -->

**Figure S8.** (a) Mobility ( _μ_ FE) and (b) normalized mobility ( _μ_ FE/ _μ_ FE,0) for the same 8 devices as in Figure S6-S7, at 0%, 0.4%, 0.6%, 0.7%, and back to 0% tensile strain at a lower carrier density _n_ ~ 4.8×10<sup>12</sup> cm<sup>-2</sup> . The _μ_ FE in (b) is normalized to the initial (unstrained) values, with the box plots showing the median across devices (red circles), first and third quartiles (blue box), and maximum and minimum (top and bottom lines, respectively). The red “+” symbols represent outliers in the data. The cyan box plot corresponds to the measurement after strain is released. 

## **6. Degradation of devices at high levels of strain** 

At strain greater than 0.7%, we observe a degradation of mobility and current in all devices. Figure S9a depicts this decrease in mobility at 0.8% strain during the 1<sup>st</sup> measurement of a second set of devices. When the strain returns to 0%, the mobility decreases further. However, the 2<sup>nd</sup> measurement (Figure S9b) shows an increase in mobility when strain is again applied to the devices, though it is lower than the improvement in mobility observed in Figure S6. These results demonstrate that there is a “break-in” of the device when the strain exceeds 0.7%, resulting in a degradation in performance. 



<!-- Start of picture text -->
(a) 1 st Measurement (b) 2 nd Measurement<br>n  ~ 8.2×10 12 cm -2<br>V DS = 1 V released released<br><!-- End of picture text -->

**Figure S9.** Field-effect mobility _μ_ FE as a function of larger tensile strain for devices on a different sample. Each color corresponds to a different device. (a) First measurement of devices at 0%, 0.8%, and back to 0% strain, showing a degradation in mobility. (b) Second measurement after device “break-in” at 0%, 0.8%, and back to 0% strain, this time showing an improvement in mobility at 0.8% strain, but lower mobility overall. 

8 



<!-- Start of picture text -->
(a) 1 st Measurement (b) 2 nd Measurement<br>n  ~ 8.2×10 12 cm -2<br>V DS = 1 V released released<br><!-- End of picture text -->

**Figure S10.** Current _I_ D as a function of larger tensile strain for the same devices shown in Figure S9. Each color corresponds to a different device. (a) First measurement of devices at 0%, 0.8%, and back to 0% strain, showing a degradation in current. (b) Second measurement after device “break-in” at 0%, 0.8%, and back to 0% strain, this time showing an improvement in current at 0.8% strain. 

Figure S10a-b shows the same trends of current _I_ D at higher strain, i.e. an initial decrease in current with strain during the first measurement and subsequently an increase in current with strain during the second measurement. Once the strain is released the second time, _I_ D and _μ_ FE return to the same levels as before the second measurement. We point out that the device measurements displayed in Figure S9 and Figure S10 have higher initial unstrained mobilities and drive currents than the device measurements shown in Figure S6, but we were unable to further improve the mobility with strain because of device break-in and degraded electrical performance at 0.8% strain. 



<!-- Start of picture text -->
ε = 0.3%<br>0%<br>W = 20 µm<br>L = 2 µm<br>V DS = 1 V<br><!-- End of picture text -->

**Figure S11** . _I_ D- _V_ GS measurements at 0% and 0.3% strain for a transistor with _W_ = 20 μm and _L_ = 2 μm on a different sample. The mobility increases from ~25 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> at 0% strain to ~34 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> at 0.3% strain at _n_ ~ 7×10<sup>12</sup> cm<sup>-2</sup> . 

We also perform strain-dependent electrical measurements on a third set of monolayer MoS2 transistors with higher initial mobilities (~15 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> to 35 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> ). Transfer characteristics from one of these transistors are included in Figure S11. The mobility and current of these devices improve with ~0.3% strain, but the devices degrade at higher levels of strain (not shown). The mobility of the device in Figure S11 increases from ~25 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> with 0% strain to ~34 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> with 0.3% strain at _n_ ~ 7×10<sup>12</sup> cm<sup>-2</sup> . 

9 

We attribute the degradation in electrical performance at higher strains to cracking in the metal or Al2O3 gate dielectric, or worsened adhesion of the contact metal to the MoS2. When strain greater than 1% is applied to the MoS2 devices, we observe obvious cracks in the metal or Al2O3 layers (see Figure S12). Although we did not observe such cracks in the devices measured in Figures S9S11, this could still be the source of device degradation. Raman measurements (see Figure S13) showing the expected shift in the E’ peak prove that the MoS2 remains strained at 0.8%, and that the MoS2 is not “slipping” against the substrate. 



<!-- Start of picture text -->
(a) (b)<br><!-- End of picture text -->

**Figure S12.** (a) Optical image of a device after >1% strain was applied. (b) Zoomed-in region showing fine cracks in the metal gate and/or the Al2O3 gate insulator under the MoS2 channel. Small arrows point to the fine cracks. 



<!-- Start of picture text -->
ε = 0% A1’<br>0.8%<br>E’<br><!-- End of picture text -->

**Figure S13.** Raman spectra at 0% and 0.8% tensile strain for one of the devices that degraded electrically at 0.8% strain. The data are depicted as symbols, and the fits using a superposition of Lorentzian and Gaussian peaks are displayed as solid curves. The redshift in the E’ peak shows that the MoS2 is still strained (even after the electrical degradation of the transistor) and does not slip against the substrate. 

## **7. Supplementary References:** 

(1)  Münzenrieder, N.; Petti, L.; Zysset, C.; Görk, D.; Büthe, L.; Salvatore, G. A.; Tröster, G. Investigation of gate material ductility enables flexible a-IGZO TFTs bendable to a radius of 1.7 mm. _2013 Proceedings of the European Solid-State Device Research Conference (ESSDERC)_ , 1620 Sept. 2013, **2013.** 10.1109/ESSDERC.2013.6818893. 

10 

(2)  Smithe, K. K. H.; English, C. D.; Suryavanshi, S. V.; Pop, E. Intrinsic electrical transport and performance projections of synthetic monolayer MoS2 devices. _2D Materials_ **2017,** _4_ , 011009. (3)  Smithe, K. K. H.; Suryavanshi, S. V.; Muñoz Rojo, M.; Tedjarati, A. D.; Pop, E. Low Variability in Synthetic Monolayer MoS2 Devices. _ACS Nano_ **2017,** _11_ , 8456-8463. 

(4)  Vaziri, S.; Yalon, E.; Munoz Rojo, M.; Suryavanshi, S. V.; Zhang, H.; McClellan, C. J.; Bailey, C. S.; Smithe, K. K. H.; Gabourie, A. J.; Chen, V.; Deshmukh, S.; Bendersky, L.; Davydov, A. V.; Pop, E. Ultrahigh thermal isolation across heterogeneously layered two-dimensional materials. _Sci Adv_ **2019,** _5_ , eaax1325. 

(5)  Buscema, M.; Steele, G. A.; van der Zant, H. S. J.; Castellanos-Gomez, A. The effect of the substrate on the Raman and photoluminescence emission of single-layer MoS2. _Nano Research_ **2014,** _7_ , 561-571. 

(6)  Conley, H. J.; Wang, B.; Ziegler, J. I.; Haglund, R. F.; Pantelides, S. T.; Bolotin, K. I. Bandgap Engineering of Strained Monolayer and Bilayer MoS2. _Nano Letters_ **2013,** _13_ , 3626-3630. 

(7)  Wang, Y.; Cong, C.; Qiu, C.; Yu, T. Raman Spectroscopy Study of Lattice Vibration and Crystallographic Orientation of Monolayer MoS2 under Uniaxial Strain. _Small_ **2013,** _9_ , 28572861. 

(8)  Shi, H.; Pan, H.; Zhang, Y.-W.; Yakobson, B. I. Quasiparticle band structures and optical properties of strained monolayer MoS2 and WS2. _Physical Review B_ **2013,** _87_ , 155304. 

(9)  Goswami, T.; Rani, R.; Hazra, K. S.; Ghosh, H. N. Ultrafast Carrier Dynamics of the Exciton and Trion in MoS2 Monolayers Followed by Dissociation Dynamics in Au@MoS2 2D Heterointerfaces. _The Journal of Physical Chemistry Letters_ **2019,** _10_ , 3057-3063. 

(10)  Mak, K. F.; Lee, C.; Hone, J.; Shan, J.; Heinz, T. F. Atomically Thin MoS2: A New DirectGap Semiconductor. _Physical Review Letters_ **2010,** _105_ , 136805. 

(11)  Liu, Z.; Amani, M.; Najmaei, S.; Xu, Q.; Zou, X.; Zhou, W.; Yu, T.; Qiu, C.; Birdwell, A. G.; Crowne, F. J.; Vajtai, R.; Yakobson, B. I.; Xia, Z.; Dubey, M.; Ajayan, P. M.; Lou, J. Strain and structure heterogeneity in MoS2 atomic layers grown by chemical vapour deposition. _Nature Communications_ **2014,** _5_ , 5246. 

(12)  Cai, L.; McClellan, C. J.; Koh, A. L.; Li, H.; Yalon, E.; Pop, E.; Zheng, X. Rapid Flame Synthesis of Atomically Thin MoO3 down to Monolayer Thickness for Effective Hole Doping of WSe2. _Nano Letters_ **2017,** _17_ , 3854-3861. 

(13)  Zhao, Y.; Xu, K.; Pan, F.; Zhou, C.; Zhou, F.; Chai, Y. Doping, Contact and Interface Engineering of Two-Dimensional Layered Transition Metal Dichalcogenides Transistors. _Advanced Functional Materials_ **2017,** _27_ , 1603484. 

(14)  Schauble, K.; Zakhidov, D.; Yalon, E.; Deshmukh, S.; Grady, R. W.; Cooley, K. A.; McClellan, C. J.; Vaziri, S.; Passarello, D.; Mohney, S. E.; Toney, M. F.; Sood, A. K.; Salleo, A.; Pop, E. Uncovering the Effects of Metal Contacts on Monolayer MoS2. _ACS Nano_ **2020,** _14_ , 14798–14808. 

(15)  Datye, I. M.; Gabourie, A. J.; English, C. D.; Smithe, K. K. H.; McClellan, C. J.; Wang, N. C.; Pop, E. Reduction of hysteresis in MoS2 transistors using pulsed voltage measurements. _2D Materials_ **2019,** _6_ , 011004. 

(16)  English, C. D.; Shine, G.; Dorgan, V. E.; Saraswat, K. C.; Pop, E. Improved Contacts to MoS2 Transistors by Ultra-High Vacuum Metal Deposition. _Nano Letters_ **2016,** _16_ , 3824-3830. (17)  Hosseini, M.; Elahi, M.; Pourfath, M.; Esseni, D. Strain induced mobility modulation in single-layer MoS2. _Journal of Physics D: Applied Physics_ **2015,** _48_ , 375104. 

