# Highly enhanced ferroelectricity in HfO2-based ferroelectric thin film by light ion bombardment

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 191 |
| 作者 | Seunghun Kang, Woo-Sung Jang, A. Morozovska, Owoong Kwon, Yeongrok Jin, Young-Hoon Kim, H. Bae, Chen-Xi Wang et al. |
| DOI | 10.1126/science.abk3195 |
| 源文件 | 045_Kang_2022_Highly-enhanced-ferroelectricity-in-HfO2-based-f.pdf |

---
Submitted Manuscript: Confidential Template revised February 2021 

# **Title: Highly enhanced ferroelectricity in HfO2-based ferroelectric thin film by light ion bombardment** 

5 

**Authors:** Seunghun Kang<sup>1</sup> †, Woo-Sung Jang<sup>2</sup> †, Anna N. Morozovska<sup>3</sup> †, Owoong Kwon<sup>1</sup> , Yeongrok Jin<sup>4</sup> , Young-Hoon Kim<sup>2</sup> , Hagyoul Bae<sup>5</sup> , Chenxi Wang<sup>1</sup> , Sang-Hyeok Yang<sup>2</sup> , Alex Belianinov<sup>6,7</sup> , Steven Randolph<sup>6</sup> , Eugene A. Eliseev<sup>8</sup> , Liam Collins<sup>6</sup> , Yeehyun Park<sup>1</sup> , Sanghyun Jo<sup>5</sup> , Min-Hyoung Jung<sup>2</sup> , Kyoung-June Go<sup>9</sup> , Hae Won Cho<sup>1</sup> , Si-Young Choi<sup>9</sup> , Jae Hyuck Jang<sup>10</sup> , Sunkook Kim<sup>1</sup> , Hu Young Jeong<sup>11</sup> , Jaekwang Lee<sup>4</sup> , Olga S. Ovchinnikova<sup>6</sup> , Jinseong Heo<sup>5</sup> *, Sergei V. Kalinin<sup>6</sup> *, Young-Min Kim<sup>2</sup> *, and Yunseok Kim<sup>1</sup> * 

## **Affiliations:** 

10 

1School of Advanced Materials and Engineering, Sungkyunkwan University (SKKU), Suwon 16419, Republic of Korea. 

2Department of Energy Science, Sungkyunkwan University (SKKU), Suwon 16419, Republic of Korea. 

15 

3Institute of Physics, National Academy of Sciences of Ukraine, 46, Prospekt. Nauky, 03028 Kyiv, Ukraine. 

4Department of Physics, Pusan National University, Busan 46241, Republic of Korea. 

5Samsung Advanced Institute of Technology, Suwon 16678, Republic of Korea. 

6Center for Nanophase Materials Sciences, Oak Ridge National Laboratory, Oak Ridge, TN 37831, United States. 

20 

7Sandia National Laboratories, Albuquerque, TN 87123, United States. 

8Institute for Problems of Materials Science, National Academy of Sciences of Ukraine, Krjijanovskogo 3, 03142 Kyiv, Ukraine. 

9Department of Materials Science and Engineering, Pohang University of Science and Technology (POSTECH), Pohang 37673, Republic of Korea. 

25 

10Center for Scientific Instrumentation, Korea Basic Science Institute (KBSI), Daejeon 34133, Republic of Korea. 

11Graduate School of Semiconductor Materials and Devices Engineering, UNIST, Ulsan 44919, Republic of Korea. 

†These authors contributed equally to this work. 

30 

35 

**Abstract:** Continuous advancement in non-volatile and morphotropic beyond-Moore electronic devices requires integration of ferroelectric and semiconductor materials, and the direction has been aggressively pursued for more than 40 years. Emergence of the HfO2 based ferroelectrics that are compatible with atomic layer deposition have opened new and promising venue of research. However, the origins of ferroelectricity and pathways to control it in HfO2 are still mysterious. Here, we demonstrate that local He implantation can locally activate ferroelectricity in these materials. The possible competing mechanisms including He ion-induced molar volume changes, vacancy redistribution, vacancy generation, and activation of vacancy mobility are 

1 

Submitted Manuscript: Confidential Template revised February 2021 

5 

analyzed. These findings both reveal the origins of ferroelectricity in this system and open pathway for nanoengineered binary ferroelectrics. 

**One-Sentence Summary:** A new technology using ion bombardment enables enhancement of polarization in HfO2-based ferroelectrics. 

2 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

25 

15 

20 

30 

35 

40 

45 

Progress towards ultra-dense oxide electronics and applications including the non-volatile memories and beyond-Moore devices necessitates the introduction of new device paradigms and development of novel strategies utilizing the wealth of functionalities of complex materials at extremely reduced dimensions. These include a wide range of emergent properties, such as magnetoelectricity, ferroelectricity, flexoelectricity, and electrochromicity that emerge due to the intrinsic competition (or cooperation) of charge, spin orbital and lattice degrees of freedom ( _1_ ). Among these, the special role required for the switching, logical, and memory devices is ferroelectricity, which refers to a material property of spontaneous electrical polarization that is reversible when an electric field is applied. Ferroelectricity has been studied for the application of next-generation electronic devices, such as ferroelectric field-effect transistors ( _2, 3_ ) and nonvolatile memories, ( _4, 5_ ) for over 40 years owing to their remarkable physical properties, including a fast-switching speed and long-term stability ( _6_ ). However, despite these superior properties, ferroelectrics have practical limitations owing to scaling effects ( _7, 8_ ) and a low compatibility with complementary metal oxide semiconductor (CMOS) processes ( _9_ ). In particular, the ferroelectricity of conventional perovskite ferroelectrics significantly drops at thicknesses below 50 nm, limiting their application in ultra-large-scale integrated electronics ( _7_ ). Secondly, integration between classical ferroelectrics and Si and other semiconductors is limited by intrinsically high oxygen chemical potential in the former, leading to formation of parasitic SiOx layers and degradation during classical processing. Hence, despite much effort, the goal of ferroelectric-semiconductor integration remained elusive. 

The discovery of HfO2-based ferroelectrics with a fluorite structure in 2011 ( _10_ ), e.g. Hf0.5Zr0.5O2 (HZO), broke the traditional paradigm and offers a promise of non-volatile and morphotropic beyond-Moore electronic devices ( _10-13_ ). Unlike conventional ferroelectrics, HfO2-based ferroelectrics maintain robust ferroelectricity ( _14_ ), which would be viable even down to a fundamental barrier restricted by a unit cell dimension, and are highly compatible with the existing CMOS processes ( _15_ ). However, the nature of ferroelectricity in these materials remains poorly understood due to the complexity arisen from undefined structural and chemical factors. This in turn has hindered keeping the pace towards the rapid development of facile controllability and large-scale uniformity. From phenomenological perspective, HfO2-based ferroelectrics demand a wake-up process to vitalize ferroelectricity by electric field cycling ( _1620_ ), suggesting the non-conventional nature of ferroelectric responses. Furthermore, the deposition conditions, such as doping, oxygen partial pressure and annealing conditions ( _21-24_ ), and engineering-perspective post-surface treatments such as plasma treatment ( _25, 26_ ) were found to have a strong effect on the resulting ferroelectricity. 

Ferroelectricity in HfO2-based ferroelectrics can originate from multiple mechanisms such as intrinsic ferroelectricity ( _27_ ), electret-like responses associated with charge trapping at internal interfaces and intrinsic electrostriction ( _28_ ). Moreover, recent studies have illustrated significant role of oxygen vacancies ( _29_ ). In particular, the role of oxygen vacancies in HfO2based ferroelectrics has gained significant attention because the vacancies stabilize the metastable ferroelectric orthorhombic ( _Pca_ 21) phase over the entire polycrystalline HZO thin film, resulting in a significant enhancement of ferroelectricity ( _23, 30_ ). Further, oxygen vacancy redistribution has been suggested as one of the possible mechanisms for enhancement of the ferroelectricity driven by the wake-up effect ( _16-19_ ). However, despite these findings, the consistent nature of ferroelectricity in HfO2-based ferroelectrics, detailed mechanisms behind it, and hence, the knowledge-driven ways of controlling it, are elusive. 

3 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

35 

Here, we propose a new strategy for highly enhanced and precisely controlled ferroelectricity in HfO2-based ferroelectric thin films by point defect engineering via a light ion bombardment. From the perspective of fundamental knowledge, we also report the possible competing mechanisms including molar volume changes, vacancy distribution, number of vacancies, and vacancy mobility, and provide the evidence towards the vacancy generation as the dominant mechanism behind the emergence of ferroelectric behavior in these materials. 

To quantitatively evaluate the effective enhancement of ferroelectricity after ion beam treatment, we explore the remnant polarization states and the hysteretic behavior via piezoresponse force microscopy (PFM) combined with various advanced techniques, such as the band excitation (BE) method and laser Doppler vibrometer (LDV). To understand the origin of the enhanced ferroelectricity, we examined the atomic structure-chemistry relationship in the polycrystalline HZO thin films before and after the light ion treatment based on scanning transmission electron microscopy (STEM) combined with energy dispersive X-ray spectroscopy (EDX) and electron energy loss spectroscopy (EELS). We revealed that oxygen vacancies are homogeneously distributed over the optimally treated HZO thin film without the intervention of structural defects, which eventually leads to a global phase transition to the ferroelectric orthorhombic phase while the non-treated or un-optimized thin films present a mixture of nonferroelectric and ferroelectric phases. This intriguing result implies a strong coupling of the oxygen vacancy and the resulting ferroic behavior of the HZO thin film. Thermodynamical interpretation can elucidate the phenomenological observation as possible competing mechanisms including molar volume changes, vacancy distribution, number of vacancies, and vacancy mobility. The method proposed to modulate the density of the point defects could be a new breakthrough for the practical application of ferroelectrics to next-generation memory devices via enhanced ferroelectricity. 

## **Piezoresponse dependent light ion bombardment** 

We chose He ion bombardment as a strategy to explore the emergence of ferroelectricity in these materials, where He ions can get trapped by the lattice leading to the increase of molar volume as well as generate oxygen vacancies. To investigate the enhancement of the ferroelectricity in the HZO thin film by light ion bombardment, we performed ion bombardment on the HZO thin film as a function of the He ion dose using a focused beam He ion microscopy (Fig. 1A). To observe the change in the electric polarization as a function of defect density, we bombarded the thin film with various He ion doses, as shown in Fig. 1B. Figures 1C and 1D present the changes in the local polarization associated with the He ion dose using resonance PFM (R-PFM), which was measured with an AC voltage of a single frequency near the contact resonance (Fig. 1C and 1D) ( _55_ ). 

40 

The regions with He ion doses below 10<sup>16</sup> ions/cm<sup>2</sup> do not demonstrate significant changes in the R-PFM amplitude, which represents the magnitude of the piezoresponse signal that in turn is related to polarization. Instead, these regions apparently present a slight decrease in the piezoresponse. This reduction may be resulted from the defect formation by ion bombardment. However, this reduction may be also associated with carbon contamination at the surface because carbon deposition can be easily induced by the surface adsorbates of hydrocarbon molecules during ion bombardment ( _31-33_ ) and, furthermore, the atomic force microscopy (AFM) measurements can be sensitive to carbon contamination. However, the regions with He ion doses above 10<sup>16</sup> ions/cm<sup>2</sup> present an increase in the R-PFM amplitude with 

45 

4 

Submitted Manuscript: Confidential Template revised February 2021 

10 

5 

15 

20 

25 

30 

35 

40 

45 

an increase in the He ion dose. In particular, the R-PFM amplitude in the region with the He ion dose of 10<sup>17</sup> ions/cm<sup>2</sup> increased by approximately two times compared with the pristine region, indicating significant enhancement of ferroelectricity. Meanwhile, the central part of the region with the He ion dose of 10<sup>18</sup> ions/cm<sup>2</sup> presents a rapid decrease in the R-PFM amplitude and the milled surface (Fig. S1) because an excessive He ion dose can lead to a crystallographic collapse via material sputtering. 

Since R-PFM can be affected by other contributions, such as a resonance shift or nonferroelectric contributions ( _34-37_ ), we measured BE-PFM and LDV-PFM as shown in Figs. 1F and 1G in addition to R-PFM (Fig. 1E). Because BE-PFM can track the resonance frequency, it allows minimizing the error from the resonance shift ( _38_ ), which can be associated with carbon contamination. Similar to the R-PFM results, BE-PFM amplitude also indicates an increase in the piezoresponse after ion bombardment. In addition, we confirmed little change of mechanical properties in the ion bombarded HZO thin film through BE-PFM (Fig. S2). Meanwhile, recent studies have reported that non-ferroelectric factors, such as the electrostatic effect, can be attributed to the PFM signal ( _34, 35_ ). The difference in the surface potential according to the ion bombardment may affect the PFM signal due to electrostatic effects ( _39_ ). 

Therefore, we conducted LDV-PFM measurements in the same region (Fig. 1G) to evaluate the PFM signal, excluding the long-range electrostatic effect because LDV-PFM is less sensitive to the electrostatic effect ( _39, 40_ ). From the result of the LDV-PFM, a higher PFM amplitude was observed in the region with a He ion dose of 10<sup>17</sup> ions/cm<sup>2</sup> . Furthermore, as shown in the ion dose of 10<sup>17</sup> ions/cm<sup>2</sup> of Fig. S3, although the surface potential in the ion bombarded region relaxed to the same value as that in the pristine region after a sufficient time elapsed, the R-PFM amplitude still exhibits a strong response in the ion bombarded region, indicating that the highly increased PFM signal is primarily originated from the highly enhanced polarization by the ion bombardment. In addition, to verify the reproducibility of the thin films deposited by another method, R-PFM images were measured after ion bombardment on the HZO thin film deposited by the atomic layer deposition (Fig. S4). We observed that light ion bombardment continues to enhance the polarization in the HZO thin film, regardless of the deposition method used. Overall, the R-PFM results indicate that ion bombardment can be used to control the polarization by controlling the He ion dose. 

The effective _d33_ was measured to explore the change in the polarization of HZO after ion bombardment, which may indicate the out-of-plane piezoelectric constant of spontaneous polarization, through an alternating-current voltage ( _Vac_ ) amplitude sweep in the HZO thin film. Figure 1H illustrates the variation of the effective _d33_ obtained from the mapping result of the _Vac_ amplitude sweep, i.e., the BE-PFM amplitude according to _Vac_ , after ion bombardment. The measured regions correspond to the regions of 5×10<sup>14</sup> –10<sup>17</sup> ions/cm<sup>2</sup> in Figs. 1I and 1J. The regions of 5×10<sup>17</sup> –10<sup>18</sup> ions/cm<sup>2</sup> were excluded because of significant topographic variations, including beam damage, as presented in Fig. S1. The regions with He ion doses of 5×10<sup>16</sup> –10<sup>17</sup> ions/cm<sup>2</sup> clearly present a higher effective _d33_ compared to that of the other regions (Fig. 1H and 1I), although the difference according to the He ion dose was not observed owing to the equipment background noise below 0.3 _Vac_ . The effective _d33_ results were averaged for a quantitative comparison as a function of the He ion dose (Fig. 1J). The regions with He ion doses below 10<sup>16</sup> ions/cm<sup>2</sup> present a slight decrease in the effective _d33_ . As previously indicated, this decrease may be due to the defect formation by ion bombardment or the carbon contamination at the surface of the HZO thin film after ion bombardment ( _31-33_ ). Meanwhile, when the He ion dose is increased to 5×10<sup>16</sup> ions/cm<sup>2</sup> or more, the effective _d33_ is significantly increased 

5 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

compared to that of the pristine region. In particular, the effective _d33_ value of the 10<sup>17</sup> ions/cm<sup>2</sup> region increased by 99% compared to that of the pristine region. Therefore, the PFM results indicate that light ion bombardment can enhance the polarization of HZO; furthermore, it can be used to locally control these enhancements. However, considering the applicability of ferroelectrics to next-generation electronic devices, the switching characteristics of the polarization rather than a spontaneous polarization are more important. 

## **Influence of light ion bombardment on polarization switching** 

25 

30 

35 

40 

To observe the changes in the polarization switching characteristics owing to He ion bombardment, PFM hysteresis loops based on the first-order reversal-curve (FORC) method were performed ( _41_ ). Figure 2A presents the polarization switching behavior depending on the maximum direct-current voltages ( _Vdc,max_ ) as a function of the He ion dose. While the coercive voltages related to the polarization switching were in a similar range regardless of the ion bombardment and He ion dose, the piezoresponse indicating the intensity and direction of polarization was significantly increased at He ion doses above 10<sup>16</sup> ions/cm<sup>2</sup> . These results can be more clearly observed through the remnant piezoresponse in Figs. 2B and 2C. As shown in Fig. 2B, the positive remnant piezoresponse increases more steeply in the He ion doses of 5×10<sup>16</sup> and 10<sup>17</sup> ions/cm<sup>2</sup> than that of other doses with an increasing _Vdc,max_ as the polarization direction shifts downwards in the HZO thin film, except for the result at 1 _Vdc,max_ where switching does not occur. In the region with a He ion dose of 10<sup>17</sup> ions/cm<sup>2</sup> , the positive remnant piezoresponse at 8 _Vdc,max_ was increased by approximately 42% compared to that with the pristine region. Notably, in the present case, the ion bombardment does not significantly affect leakage current as shown in Fig. S5. We further note that the piezoresponse was slightly decreased at He ion doses below 10<sup>16</sup> ions/cm<sup>2</sup> , indicating that the slight decrease in both R-PFM amplitude and remnant piezoresponse may be resulted from the defect formation by ion bombardment as well rather than the carbon contamination. 

As shown in Fig. 2D, the PFM hysteresis loops obtained by the FORC method were wellfitted by the generalized Preisach model, the details of which can be found in the Supplementary Materials. This analysis suggests that He ion bombardment yields broader distribution of coercive fields than the internal bias fields for the average result, suggesting the non-uniform nature of the material. However, the distributions of the Preisach density for the He ion dose of 5×10<sup>16</sup> –10<sup>17</sup> ions/cm<sup>2</sup> are clearly distinguished from the other doses by the more narrow distribution of the coercive voltages and higher Preisach density than the coercive fields, as shown in Fig. 2E, indicating more uniform and strengthened polarization switching responses. In addition, because of the increasing defect density, the interaction between charged defects and the spontaneous polarization is enhanced, leading to an extended distribution of internal bias voltages for the He ion dose of 5×10<sup>16</sup> –10<sup>17</sup> ions/cm<sup>2</sup> . Apparently, there is a threshold value for the He ion dose to induce strengthened polarization switching and strong interactions. The ratio of the coercive voltage width to the internal bias voltage width and the irreversible amplitude both present an abrupt increment between the He ion doses of 10<sup>16</sup> and 5×10<sup>16</sup> ions/cm<sup>2</sup> , as shown in Fig. 2F. 

Overall, these results indicate the possibility of using light ion bombardment to highly enhance the ferroelectric polarization in HZO through defect engineering. Furthermore, as shown in Figs. S6 and S7, an increase in the number of defects can occur owing to light ion bombardment. Presumably, the enhanced ferroelectricity of the HZO thin film could be ascribed 

45 

6 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

to the increased defect density inside the HZO thin film by the post-treatment of the He ion bombardment. Regardless, because the enhancement of ferroelectric polarization through defect engineering can be associated with several mechanisms, such as domain depinning and phase transition to the ferroelectric phase ( _16_ ), we explored the origin of the ferroelectric polarization enhancement. 

## **Mechanism of highly enhanced ferroelectricity based on defect engineering** 

To determine the dominant defect formed and the cause of the enhanced ferroelectricity in the treated HZO thin film, we performed a chemical analysis on the HZO samples with different He ion doses of 5×10<sup>15</sup> and 10<sup>17</sup> ions/cm<sup>2</sup> , respectively, and compared those with the case of the pristine HZO thin film. The pristine HZO and the two HZO thin films with different He ion doses are denoted with respect to He ion dose as follows: pristine (P-HZO), 5×10<sup>15</sup> ions/cm<sup>2</sup> (LHZO), and 10<sup>17</sup> ions/cm<sup>2</sup> (H-HZO), respectively. Figure 3A presents the EDX elemental maps of Hf (red), Zr (yellow), O (green), and Si (cyan) for the three HZO samples of P-HZO, L-HZO, and H-HZO, respectively. The annular dark field (ADF) STEM images and the corresponding EDX maps confirm that the thicknesses of the HZO thin films are approximately 10 nm but appear to thicken with an increasing dose of He ions, which indicates the increase of molar volume. Comparing the high-resolution high-angle (HA)ADF STEM images of the three HZO samples (Fig. 3B), we observed layer thickening and structural disorder (seen as the increased fuzzy contrast in the image) in the H-HZO sample. This characteristic volume change is also evinced at the atomic scale in the comparison of planar spacings of the orthorhombic phase observed in the three HZO samples (Fig. S8 in the Supplementary Materials). The EDX maps of the three samples revealed that Hf and Zr are sufficiently mixed without elemental segregation, and the contrast of oxygen is thicker than those of Hf and Zr, extending into the Si substrate. This result indicates that a portion of oxygen in the HZO thin film was consumed to form a thin SiO **2** bottom layer on the Si substrate due to the interface reaction during the growth. Thus, the bottom part of the HZO layer would be oxygen-deficient as compared to the upper part. 

30 

35 

40 

45 

To clarify the structural transition of the HZO thin films to the ferroelectric orthorhombic phase by He ion bombardment, atomic-scale HAADF STEM images were obtained for the three HZO samples and compared with the simulated counterparts (Fig. 3C). Because the signal contrast in the HAADF imaging mode is approximately scaled to the atomic number squared ( _Z_<sup>_~2_</sup> ), heavy Hf atoms ( _Z_ = 72) appear as bright dots, whereas light oxygen atoms ( _Z_ = 8) are hardly observed ( _42_ ). Owing to the polycrystalline nature of the grown HZO thin films, the atomic structures of the thin films were only observed for nano-grains aligned along an arbitrary crystal zone axis. Hence, we conducted multiple STEM observations for each sample to determine the polymorphic phase distribution over the film of investigation. As a result, the P- HZO and L-HZO thin films present a mixture of monoclinic and orthorhombic phases, maintaining the monoclinic structure as the dominant phase. The two atomic structures identified as orthorhombic and monoclinic phases observed in both HZO thin films are given in Figs. S9A and S9B. In contrast, the nano-grains in the H-HZO thin film were identified as the ferroelectric orthorhombic ( _Pca_ 21) phase in all the observations (Fig. S9C). An extra dataset confirming this behavior is provided in Fig. S10 in the Supplementary Materials. In Fig. 3C, the HAADF STEM images of the P- and L-HZO samples show the [001]-oriented monoclinic structure, while that of the H-HZO represents the [110]-oriented orthorhombic structure. Position-averaged convergent beam electron diffraction (PACBED) analysis ( _43_ ) was complementarily performed on the regions of STEM observations to confirm those structures. Consistently, the experimental 

7 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

35 

40 

45 

PACBED patterns show a good match with the simulated PACBED patterns that were derived from the structures identified by the STEM observations (Fig. 3D). Considering the multiple structural observations, we can conclude that the He ion bombardment into the pristine HZO thin film readily induces a homogeneous distribution of the ferroelectric orthorhombic phase over the film. These results suggest that atomic defects such as oxygen vacancies and the structural disorder that were induced by He ion bombardment could play an important role in the favorable structural transition to the ferroelectric orthorhombic phase, thus resulting in the notable enhancement of ferroelectricity. 

To trace the distribution of oxygen vacancies inside the HZO thin films, we conducted an EELS spectrum imaging (SI) analysis of the O _K_ edge for each HZO film as shown in Fig. S11. From the EELS SI datasets, we extracted the averaged O _K_ spectra for the three HZO thin films (see insets in Fig. 3E). The O _K_ energy loss near edge structure (ELNES) of HZO presents a notable doublet peak shape denoted as _a_ (peaked at ~534 eV) and _b_ (peaked at ~538 eV) with an energy difference ( _ΔEB-A_ ) of ~4 eV, which is attributed to the O _2p_ orbital hybridized with the Hf (or Zr) 𝑑𝑒𝑔 and 𝑑𝑡2𝑔 orbitals, respectively ( _44_ ). This characteristic peak splitting of the O _K_ ELNES commonly appears in the HfO2 polymorphs of monoclinic, tetragonal, and cubic phases with slight differences in the energy shift and peak broadening ( _44_ ). Characteristically, the peak sharpness and intensity of peak _a_ relative to peak _b_ varies with the crystallinity and content of the oxygen vacancies in the HfO2 film. Poor crystallinity causes a broadening of the double peak structure and also a decrease in the relative intensity of peak _a_ , which should be considered when HZO thin films are grown at different annealing temperatures ( _45_ ). Since the HZO samples were grown under the same thermal processing conditions, the most probable origin of the change in the O _K_ ELNES can be the formation of the oxygen vacancies and/or the occurrence of structural disorder due to the He ion bombardment. The notable reduction of the _a_ / _b_ ratio from 0.60 to 0.43 in O _K_ edges (Figs. 3E and S11C) implies that the vacancy defects and structural disorder are increased as the dose of He ion bombardment was increased to the optimal value of 10<sup>17</sup> ions/cm<sup>2</sup> (H-HZO). Due to the fact that monoclinic and orthorhombic HZO structures have seven-fold coordinate metal ions, a similar broad doublet peak structure of the O _K_ edges is observed (Fig. S12A). However, cubic and tetragonal HfO2 structures with six-fold coordinate metal ions would present significantly sharper double-peaked O _K_ ELNES owing to the higher crystal field symmetry ( _45_ ). Previous studies reported that the formation of oxygen vacancies reduces the first peak ( _a_ ) intensity of the O _K_ doublet edge when other factors are held constant ( _45, 46_ ). Our DFT-based O _K_ edge simulations for the influence of oxygen vacancies represent the same tendency (see Supplementary Text for the effect of oxygen vacancy on the phase stability and Fig. S12B, C). 

Therefore, we examined the change in the relative intensity of peak _a_ in the O _K_ ELNES to detect the oxygen vacancies inside the HZO thin films and mapped the _a_ / _b_ ratios corresponding to the entire film region by non-linear least squares (NLLS) fitting analysis (Fig. 3E). The resulting _a_ / _b_ ratio maps show that the oxygen vacancy content is gradually increased from P-HZO to H-HZO. Notably, the entire H-HZO thin film is revealed to be populated by oxygen vacancies, whereas the distribution of the oxygen vacancies is localized and non-uniform in the other two HZO samples (P-HZO and L-HZO); these results are similar to those previously obtained for a conventional HfO2 sample ( _47_ ). The statistical histograms of the measured _a_ / _b_ ratios for the three HZO samples clearly indicate the varying population behavior of oxygen vacancies from the P- and L-HZO to the H-HZO thin films (Fig. S11C). The Gaussian curve fits of the _a_ / _b_ distributions for the three HZO samples demonstrate that the H-HZO thin film is 

8 

Submitted Manuscript: Confidential Template revised February 2021 

10 

15 

20 

25 

35 

5 

highly oxygen-deficient compared with the other two HZO samples. It is worth noting that the _a_ / _b_ ratio can be also decreased to some extent as the crystallinity becomes poor ( _45_ ). Given the increase of structural disorder by the He ion bombardment, it is also expected that the _a_ / _b_ ratio would be complementarily further reduced, making quantification of the vacancy content by EELS difficult. 

Theoretical calculations predicted that the injection of oxygen vacancies and substitutional doping into the HfO2 thin film can promote a phase transition from the monoclinic ( _P_ 21/ _c_ ) to the ferroelectric orthorhombic ( _Pca_ 21) phase ( _48, 49_ ). However, this doping was presumably insufficient to stabilize the metastable ferroelectric phase over the predominant monoclinic phase ( _50, 51_ ). Experimental work demonstrated that the role of oxygen vacancy is more significant in stabilizing the ferroelectric phase, prompting significant efforts for developing a facile route to control the concentration of the oxygen vacancy in the hafnia film ( _23, 30_ ). Based on the STEM-EELS results, we confirmed that He ion bombardment into the HZO thin film efficiently triggers the formation of oxygen vacancy and increases its density and distribution with an increasing He ion dose before causing structural damage (≥ ~10<sup>18</sup> ions/cm<sup>2</sup> ). Thus, to explore why the ferroelectric orthorhombic phase is stabilized as the oxygen vacancies are gradually introduced, we surveyed the change of total energy difference between the monoclinic and orthorhombic phases up to the vacancy content of 25% (see Supplementary Text for the effect of oxygen vacancy on the phase stability and Fig. S12D). Surprisingly, we found that a threshold concentration (>20%) of oxygen vacancy is required to fully stabilize the ferroelectric orthorhombic phase. Annular bright-field STEM imaging confirmed that the oxygen-deficient ferroelectric orthorhombic structure is stably sustained (Fig. S12E). We note that slight reduction of both R-PFM amplitude and remnant piezoresponse at He ion doses below 10<sup>16</sup> ions/cm<sup>2</sup> may be also associated with the threshold concentration. 

Nevertheless, since there can be multiple mechanisms, we further analyze the possible thermodynamic mechanisms, including direct change of molar volume, emergence of ferroelectricity, vacancy formation, and vacancy redistribution. The free energy contribution 𝐺𝑃𝐸 describing the ferroelectric order-disorder type transition can be expressed using the macroscopic polarization vector components ( _28_ ): 

30 

40 



<!-- Start of picture text -->
𝐺𝑃𝐸 = 𝑁𝑑<br>― 𝐽 𝑝 2 ― 𝐽𝑛𝑙 𝑝 4 + 𝑘𝐵𝑇 ∑ 3 𝑖=1 (1 + 𝑝𝑖)ln(1 + 𝑝𝑖) + (1 ― 𝑝𝑖)ln(1 ― 𝑝𝑖) ― 𝑑∙𝑝𝑖 𝐸 𝑒 𝑖 + 𝐸𝑑𝑖 +<br>2 4 2 2<br>𝛿𝑖𝑗𝑘𝑙 ∂𝑝𝑖 ∂𝑝𝑗<br>2 𝑃 2 𝑑∂𝑥𝑘∂𝑥𝑙 ,     (1)<br><!-- End of picture text -->

𝑃𝑖 where the polarization components are normalized as 𝑝𝑖 = 𝑃𝑑 ~~,~~ 𝑃𝑑≅𝑁𝑑𝑑; 𝑑 is the concentrationindependent average value of an elementary dipole moment; the concentration 𝑁𝑑 can be related with the average concentration ⟨𝛿𝑁𝑑(𝑟)⟩ of different vacancies and/or other defects; 𝐽 is the effective interaction constant that is negative for the considered case of improper ferroelectricity; 𝐽𝑛𝑙 is the effective nonlinearity coefficient; __ is the positive gradient coefficient determined by the correlation between the dipole moments and by the contribution of the spatial gradients induced by the surface as well as by the inhomogeneities inherent to the film; and 𝑘𝐵 is the Boltzmann constant. We consider that the film surfaces are defect-blocking, and so all O, Hf and Zr vacancies inside the film are time-independent. Because of this, the average concentration of the vacancies is also time-independent and equal to the average value calculated in the initial moment of time. Inserting elastic fields, created by different defects, into the (Hf,Zr)O2 Gibbs potential and its subsequent expansion on the polarization powers leads to renormalization of the 

9 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

20 

25 

30 

coefficient __ by the electrostriction coupling with the Vegard expansion tensor, and depolarization field effect (see ( _28_ ) and Supplementary Materials). Then, a local polar state can 𝑃3 emerge for an out-of-plane polarization component 𝑝≡ 𝑃𝑑 when the average concentration of defects 〈𝑁𝑑〉 is high enough, and the positive terms proportional to<sup>Λℎ𝜀</sup> 0 and 𝛿𝜆ℎ are small enough where  is the effective screening length produced by the exposed free surface and/or imperfect bottom electrode; ℎ is the (Hf,Zr)O2 film thickness; and 𝜀0 is the universal dielectric constant. 

Typical dependences of the spontaneous out-of-plane polarization 𝑝 on the film thickness and vacancy concentration 𝑁𝑑𝑜 is shown in Figs. 4C-D. Figure 4C shows that the _p_ value increases rapidly when 𝑁𝑑𝑜 increases from 0.5𝑁0 to 2𝑁0, where 𝑁0≅10<sup>25</sup> m<sup>-3</sup> . From Fig.  4D, the _p_ value appears, rapidly increases and then saturates with increasing 𝑁𝑑𝑜. The ferroelectricity appearance is a typical size-induced effect because the second (positive) and third (negative) terms in Eq. S10 are thickness-dependent. In particular, the third term increases with ℎ increase 1 ℎ𝑑 as ℎ ~~,~~ because 〈𝑁𝑑〉= 𝑁𝑑0 ℎ 1 ― exp ― ℎ<sup>ℎ</sup> 𝑑 in accordance with Eq. S9. Small second and high third terms are required for the negative ⟨⟨𝛼<sup>𝑅</sup> 33<sup>⟩⟩. Making Λ < 0.1nm, that corresponds to a high</sup> screening degree by e.g., either conducting electrodes or ambient free carriers, and using small gradient coefficient, 𝛿≤10<sup>―10</sup> C<sup>-2</sup> m<sup>3</sup> J, the positive terms appearing small than the negative one. Thus, the third term explains the size effect shown in Figs. 4C-D. Assuming that the polar state occurs at 𝑁𝑑𝑜≅(10<sup>25</sup> – 10<sup>26</sup> ) m<sup>-3</sup> , we need to minimize exposure to He, 𝑁𝐻𝑒≅10<sup>14</sup> ions/cm<sup>2</sup> can create such a defect concentration over the already available defect “background”. This analysis suggests that the emergence of the ferroelectricity in He ion bombarded hafnia can be driven by a synergy of several factors. In accordance with Eq. S10, emergence of ferroelectricity via renormalization of ⟨⟨𝛼<sup>𝑅</sup> 33<sup>⟩⟩ requires a dominant third term. This in turn requires high negative</sup> values of electrostriction coupling and large product 〈𝑊<sup>𝑑</sup> 33<sup>〉〈</sup> 𝑁𝑑〉. Of these, the electrostriction coefficient 𝑞33 is of the same order for most ferroics. Hence, the product of the defect concentration and Vegard expansion coefficient 〈𝑊<sup>𝑑</sup> 33<sup>〉 emerges as a preponderant factor</sup> controlling ferroelectiricty in this material. 

35 

Finally, although the STEM and theoretical results showed the mechanism of polarization enhancement based on defect redistribution and phase transition as one of possible mechanisms, electrical measurements are still necessary because non-ferroelectric factors such as electrostatic effects might contribute to the obtained PFM signal in Figs. 1 and 2. Thus, we directly observed the remnant polarization charge of the electrode sample through an AFM-based positive-upnegative-down, i.e. AFM-PUND, method ( _52, 53_ ). As shown in Figs. 4A-B, the remnant polarization charge density clearly increased after the ion bombardment at the dose condition of 10<sup>17</sup> ions/cm<sup>2</sup> . 

## **Conclusions** 

40 

We demonstrated the high enhancement of ferroelectricity in HZO thin films based on defect engineering via He ion bombardment. Our PFM results indicate that the He ion bombardment highly enhanced the ferroelectricity in the HZO thin film. In particular, the resonance PFM results indicate that the amplitude of piezoresponse in the ion-bombarded region of 10<sup>17</sup> ions/cm<sup>2</sup> increased approximately two fold compared with that in the pristine region. This implies that the fine modulation of light ion bombardment can significantly enhance the polarization of HZO. 

10 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 

Furthermore, the STEM and EELS results present that the high enhancement of ferroelectricity by ion bombardment can be caused by a homogeneous distribution of oxygen vacancies and a phase transition to the ferroelectric phase. Furthermore, the theoretical calculations for thermodynamic mechanism allow us to fully explore possible mechanisms for the enhancement of the polarization by ion bombardment. These results, regarding the variation of ferroelectricity through defect engineering based on ion bombardment, suggest additional possibilities for ferroelectricity enhancement in HfO2-based ferroelectrics including HZO. Thus, He ion bombardment can be a facile technique for stabilizing the ferroelectric orthorhombic phase. Furthermore, this study suggests that highly enhanced ferroelectricity can be selectively obtained by controlling light ion bombardment with a high spatial resolution. Ultimately, this approach can be directly applied to a semiconductor process without structural modification and, thus, can increase its applicability in next-generation electronic devices, such as ultra-scaled ferroelectricsbased transistors and memories. 

## **References and Notes** 

1. M. Coll _et al._ , Towards Oxide Electronics: a Roadmap. _Appl. Surf. Sci._ **482** , 1-93 (2019). 2. S. Mathews, R. Ramesh, T. Venkatesan, J. Benedetto, Ferroelectric field effect transistor based on epitaxial perovskite heterostructures. _Science_ **276** , 238-240 (1997). 

20 

3. M. W. Si _et al._ , A ferroelectric semiconductor field-effect transistor. _Nat. Electron._ **2** , 580586 (2019). 

4. C. H. Ahn _et al._ , Local, nonvolatile electronic writing of epitaxial Pb(Zr0.52Ti0.48)O3/SrRuO3 heterostructures. _Science_ **276** , 1100-1103 (1997). 

5. J. Hoffman _et al._ , Ferroelectric Field Effect Transistors for Memory Applications. _Adv. Mater._ **22** , 2957-2961 (2010). 

25 

6. J. F. Scott, Applications of modern ferroelectrics. _Science_ **315** , 954-959 (2007). 

7. J. F. Ihlefeld _et al._ , Scaling Effects in Perovskite Ferroelectrics: Fundamental Limits and Process-Structure-Property Relations. _J. Am. Ceram. Soc._ **99** , 2537-2557 (2016). 

8. J. Junquera, P. Ghosez, Critical thickness for ferroelectricity in perovskite ultrathin films. _Nature_ **422** , 506-509 (2003). 

30 

9. F. Ambriz-Vargas _et al._ , A Complementary Metal Oxide Semiconductor ProcessCompatible Ferroelectric Tunnel Junction. _ACS Appl. Mater. Interfaces_ **9** , 13262-13268 (2017). 

10. T. S. Boescke, J. Muller, D. Brauhaus, U. Schroder, U. Bottger, Ferroelectricity in hafnium oxide thin films. _Appl. Phys. Lett._ **99** , 102903 (2011). 

35 

11. M. H. Park _et al._ , Ferroelectricity and Antiferroelectricity of Doped Thin HfO2-Based Films. _Adv. Mater._ **27** , 1811-1831 (2015). 

12. U. Schroeder _et al._ , Recent progress for obtaining the ferroelectric phase in hafnium oxide based films: impact of oxygen and zirconium. _Jpn. J. Appl. Phys._ **58** , SL0801 (2019). 

40 

13. C. Wang, H. Qiao, Y. Kim, Perspective on the switching behavior of HfO2-based ferroelectrics. _J. Appl. Phys._ **129** , 010902 (2021). 

14. Y. F. Wei _et al._ , A rhombohedral ferroelectric phase in epitaxially strained Hf0.5Zr0.5O2 thin films. _Nat. Mater._ **17** , 1095-1100 (2018). 

15. S. S. Cheema _et al._ , Enhanced ferroelectricity in ultrathin films grown directly on silicon. _Nature_ **580** , 478-482 (2020). 

45 

16. M. Pesic _et al._ , Physical Mechanisms behind the Field-Cycling Behavior of HfO2-Based Ferroelectric Capacitors. _Adv. Funct. Mater._ **26** , 4601-4612 (2016). 

11 

Submitted Manuscript: Confidential Template revised February 2021 

17. T. Y. Lee _et al._ , Ferroelectric Polarization-Switching Dynamics and Wake-Up Effect in SiDoped HfO2. _ACS Appl. Mater. Interfaces_ **11** , 3142-3149 (2019). 

5 

18. A. Chouprik _et al._ , Wake-Up in a Hf0.5Zr0.5O2 Film: A Cycle-by-Cycle Emergence of the Remnant Polarization via the Domain Depinning and the Vanishing of the Anomalous Polarization Switching. _ACS Appl. Electron. Mater._ **1** , 275-287 (2019). 

19. H. J. Kim _et al._ , A study on the wake-up effect of ferroelectric Hf0.5Zr0.5O2 films by pulseswitching measurement. _Nanoscale_ **8** , 1383-1389 (2016). 

20. P. Buragohain _et al._ , Fluid Imprint and Inertial Switching in Ferroelectric La:HfO2 Capacitors. _ACS Appl. Mater. Interfaces_ **11** , 35115-35121 (2019). 

10 

21. H. Yang _et al._ , Facile Ferroelectric Phase Transition Driven by Si Doping in HfO2. _Inorg. Chem._ **59** , 5993-5999 (2020). 

22. L. Xu _et al._ , Kinetic pathway of the ferroelectric phase formation in doped HfO2 films. _J. Appl. Phys._ **122** , 124104 (2017). 

15 

23. A. Pal _et al._ , Enhancing ferroelectricity in dopant-free hafnium oxide. _Appl. Phys. Lett._ **110** , 022903 (2017). 

24. M. H. Park _et al._ , Understanding the formation of the metastable ferroelectric phase in hafnia-zirconia solid solution thin films. _Nanoscale_ **10** , 716-725 (2018). 

25. J. Hur _et al._ , Exploring argon plasma effect on ferroelectric Hf0.5Zr0.5O2 thin film atomic layer deposition. _J. Mater. Res._ , **36** , 1206-1213 (2021). 

20 

26. K. Y. Chen, P. H. Chen, R. W. Kao, Y. X. Lin, Y. H. Wu, Impact of Plasma Treatment on Reliability Performance for HfZrOx-Based Metal-Ferroelectric-Metal Capacitors. _IEEE Electron. Device Lett._ **39** , 87-90 (2018). 

27. S. E. Reyes-Lillo, K. F. Garrity, K. M. Rabe, Antiferroelectricity in thin-film ZrO2 from first principles. _Phys. Rev. B_ **90** , 140103 (2014). 

25 

28. M. D. Glinchuk _et al._ , Possible electrochemical origin of ferroelectricity in HfO2 thin films. _J. Alloy. Compd._ **830** , 153628 (2020). 

29. P. Nukala _et al._ , Reversible oxygen migration and phase transitions in hafnia-based ferroelectric devices. _Science_ **372** , 630-635 (2021). 

30 

30. M. Hoffmann _et al._ , Stabilizing the ferroelectric phase in doped hafnium oxide. _J. Appl. Phys._ **118** , 072006 (2015). 

31. G. S. Was _et al._ , Resolution of the carbon contamination problem in ion irradiation experiments. _Nucl. Instrum. Meth. B_ **412** , 58-65 (2017). 

32. M. J. F. Healy, Minimising carbon contamination during ion beam analysis. _Nucl. Instrum. Meth. B_ **129** , 130-136 (1997). 

35 

33. D. Seol _et al._ , Selective patterning of out-of-plane piezoelectricity in MoTe2 via focused ion beam _Nano Energy_ **79** , 105451 (2021). 

34. D. Seol, B. Kim, Y. Kim, Non-piezoelectric effects in piezoresponse force microscopy. _Curr. Appl. Phys._ **17** , 661-674 (2017). 

40 

35. N. Balke _et al._ , Quantification of surface displacements and electromechanical phenomena via dynamic atomic force microscopy. _Nanotechnology_ **27** , 425707 (2016). 

36. Q. N. Chen, Y. Ou, F. Y. Ma, J. Y. Li, Mechanisms of electromechanical coupling in strain based scanning probe microscopy. _Appl. Phys. Lett._ **104** , 242907 (2014). 

37. D. O. Alikin _et al._ , Local Electromechanical Response in Doped Ceria: Rigorous Analysis of the Phase and Amplitude. _IEEE Trans. Dielectr. Electr. Insul._ **27** , 1478-1485 (2020). 

45 

38. S. Jesse, S. V. Kalinin, Band excitation in scanning probe microscopy: sines of change. _J. Phys. D Appl. Phys._ **44** , 464006 (2011). 

39. L. Collins, Y. T. Liu, O. S. Ovchinnikova, R. Proksch, Quantitative Electromechanical Atomic Force Microscopy. _ACS Nano_ **13** , 8055-8066 (2019). 

12 

Submitted Manuscript: Confidential Template revised February 2021 

40. A. Labuda, R. Proksch, Quantitative measurements of electromechanical response with a combined optical beam and interferometric atomic force microscope. _Appl. Phys. Lett._ **106** , 253103 (2015). 

5 

   41. Y. Kim _et al._ , First-Order Reversal Curve Probing of Spatially Resolved Polarization Switching Dynamics in Ferroelectric Nanocapacitors. _ACS Nano_ **6** , 491-500 (2012). 

   42. S. J. Pennycook _et al._ , Material structure, properties, and dynamics through scanning transmission electron microscopy. _J. Anal. Sci. Technol._ **9** , 11 (2018). 

   43. J. M. LeBeau, S. D. Findlay, L. J. Allen, S. Stemmer, Position averaged convergent beam electron diffraction: Theory and applications. _Ultramicroscopy_ **110** , 118-125 (2010). 

- 10 

   44. T. Mizoguchi, M. Saitoh, Y. Ikuhara, First-principles calculation of oxygen K-electron energy loss near edge structure of HfO2. _J. Phys. Condens. Mat._ **21** , 104212 (2009). 

   45. G. D. Wilk, D. A. Muller, Correlation of annealing effects on local electronic structure and macroscopic electrical properties for HfO2 deposited by atomic layer deposition. _Appl. Phys. Lett._ **83** , 3984-3986 (2003). 

- 15 

   46. S. Stemmer, Z. Q. Chen, W. J. Zhu, T. P. Ma, Electron energy-loss spectroscopy study of thin film hafnium aluminates for novel gate dielectrics. _J. Microsc._ **210** , 74-79 (2003). 

   47. C. Li _et al._ , Dynamic observation of oxygen vacancies in hafnia layer by in situ transmission electron microscopy. _Nano Res._ **8** , 3571-3579 (2015). 

- 20 

48. Y. Zhou _et al._ , The effects of oxygen vacancies on ferroelectric phase transition of HfO2based thin film from first-principle. _Comput. Mater. Sci._ **167** , 143-150 (2019). 

49. H. J. Lee _et al._ , Scale-free ferroelectricity induced by flat phonon bands in HfO2. _Science_ **369** , 1343-1347 (2020). 

25 

   50. R. Batra, T. D. Huan, J. L. Jones, G. Rossetti, R. Ramprasad, Factors Favoring Ferroelectricity in Hafnia: A First-Principles Computational Study. _J. Phys. Chem. C_ **121** , 4139-4145 (2017). 

   51. C. Kunneth, R. Materlik, M. Falkowski, A. Kersch, Impact of Four-Valent Doping on the Crystallographic Phase Formation for Ferroelectric HfO2 from First-Principles: Implications for Ferroelectric Memory and Energy-Related Applications. _ACS Appl. Nano Mater._ **1** , 254-264 (2018). 

- 30 

   52. O. Kwon _et al._ , Quantitative Local Probing of Polarization with Application on HfO2Based Thin Films. _Small Methods_ **5** , 2100781 (2021). 

   53. O. Kwon _et al._ , Direct Probing of Polarization Charge at Nanoscale Level. _Adv. Mater._ **30** , 1703675 (2018). 

- 35 

54. O. Kwon, D. Seol, H. Qiao, Y. Kim, Recent Progress in the Nanoscale Evaluation of Piezoelectric and Ferroelectric Properties via Scanning Probe Microscopy. _Adv. Sci._ **7** , 1901391 (2020). 

55. See the Supplementary Materials. 

## **Acknowledgments:** 

- 40 **Funding:** This work was supported by the National Research Foundation of Korea (NRF) grants funded by the Korean government (MSIT) (No. 2021R1A2C2009642; No. 

45 

- 2020R1F1A1072355; No. 2020R1A2C1006207) in Korea. This work was also supported by the Samsung Advanced Institute of Technology, SEC, in Korea. A portion of the work, including He ion exposure, AFM measurements, and data analysis, was conducted at the Center for Nanophase Materials Sciences, which is a DOE Office of Science User Facility (CNMS2018-219; CNMS2021-B-00917). S.-Y.C. acknowledges the support of the Global 

13 

Submitted Manuscript: Confidential Template revised February 2021 

Frontier Hybrid Interface Materials of the National Research Foundation of Korea (NRF) funded by the Ministry of Science and ICT (2013M3A6B1078872). J.L acknowledges the support of the Korea Basic Science Institute (National research Facilities and Equipment Center) grant funded by the Ministry of Education (No. 2021R1A6C101A429). 

5 

## **Author contributions:** 

Conceptualization: YK 

Data Curation: SK, WSJ, ANM, YK 

Formal Analysis: SK, WSJ, ANM, CW, EAE 

10 

Funding acquisition: SYC, JL, SVK, YMK, YK 

Investigation: SK, WSJ, ANM, OK, YJ, YHK, HB, CW, SHY, EAE, YP, KJG, SYC, JHJ, JL, YK 

Methodology: JH, SVK, YMK, YK 

Project administration: SVK, YMK, YK 

15 

Resources: AB, SR, LC, SJ, MHJ, HWC, SK, HYJ, OSO 

Supervision: JH, SVK, YMK, YK 

Validation: SK, WSJ, ANM, SVK, YMK, YK 

Writing – original draft: SK, WSJ, CW, ANM, SVK, YMK, YK 

Writing – review & editing: SK, WSJ, ANM, AB, LC, OSO, JH, SVK, YMK, YK 

20 

**Competing interests:** Authors declare that they have no competing interests. 

**Data and materials availability:** All data needed to evaluate the conclusions in the paper are available in the main text or the Supplementary Materials. The theoretical calculations for thermodynamic mechanisms were performed and visualized in Mathematica 12.2 ®Wolfram Research software. Mathematica notebook is available per reasonable request. 

25 

## **Supplementary Materials** 

Materials and Methods Supplementary Text Figs. S1 to S13 References ( _55_ – _85_ ) 

30 

14 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 

15 



**Fig. 1. Design of experiments and spontaneous polarization properties.** ( **A** ) Schematic representation of ion bombardment process. ( **B** ) Scheme for dose of He ion bombardment; inserted texts indicate the He ion doses (ions/cm<sup>2</sup> ). ( **C** ) R-PFM amplitude image of HZO thin film after ion bombardment; green-dotted box in (B) indicates the measurement position of (C). ( **D** ) R-PFM amplitudes as a function of He ion dose extracted from (C) except for the central part of 10<sup>18</sup> ions/cm<sup>2</sup> . ( **E** ) R-PFM, ( **F** ) BE-PFM, and ( **G** ) LDV-PFM amplitude images for 10<sup>17</sup> ions/cm<sup>2</sup> corresponding to the orange dotted box of (C). The PFM image is rotated 90° counterclockwise to align according to (B) and (C). ( **H** ) Spatial map of effective _d33_ after ion bombardment in (B); the orange and blue dashed boxes serve as visual guides corresponding to the positions with the He ion dose of 5×10<sup>14</sup> –5×10<sup>15</sup> and 10<sup>16</sup> –10<sup>17</sup> ions/cm<sup>2</sup> , respectively. ( **I** ) BE-PFM amplitude versus _Vac_ depending on the He ion dose; BE-PFM amplitude was calibrated via the force–distance curvebased static calibration method ( _54_ ). ( **J** ) Effective _d33_ as a function of He ion dose; the green line and area indicate the mean and standard deviation of the effective _d33_ in the pristine region, respectively. The effective _d33_ results of (H) and (J) were extracted using least-squares linear fitting, except for the noise floor region. 

15 

Submitted Manuscript: Confidential Template revised February 2021 

5 



**Fig. 2. Switchable polarization properties.** ( **A** ) FORC-PFM hysteresis loop depending on the He ion dose. ( **B** ) Positive and ( **C** ) negative remnant piezoresponse versus _Vdc,max_ depending on the He ion dose. ( **D** ) Average piezoresponse hysteresis loop and the fitting result by the Preisach model. ( **E** ) Distribution of Preisach density depending on the He ion dose. ( **F** ) Dependence of the irreversible amplitude and the ratio of the interaction and coercivity widths extracted by the Preisach model on the He ion dose. 

16 

Submitted Manuscript: Confidential Template revised February 2021 



5 

10 

15 

20 

**Fig. 3. Chemical and structural analysis of crystal phases and defects.** ( **A** ) STEM-EDX chemical maps of the constituent elements, Hf, Zr, O, and Si in the HZO samples with different He ion dose conditions: P-HZO, L-HZO, and H-HZO, respectively. For elemental mapping, characteristic X-ray peaks of Hf _L_ (7.898 keV), Zr _K_ (15.744 keV), O _K_ (0.525 keV), and Si _K_ (1.739 keV) were selected. Note, the weak Si contrast shown in the HZO thin film is attributed to the peak overlap of Si _K_ and Hf _M_ (1.644 keV) peaks. Scale bars are 10 nm. ( **B** ) Representative HAADF images of the three HZO samples. One of the nanograins in the three samples was aligned to a crystal zone-axis for atomic resolution imaging. ( **C** ) (left) Enlarged atomic structure images for the regions marked by white boxes in (B); (right) Simulated HAADF images corresponding to the experimental images. The Hf/Zr lattice models used for the HAADF image simulations were overlaid on each image for comparison. The aligned nanograins in the three HZO samples were identified to be [001]-oriented monoclinic and [110]-oriented orthorhombic structures, respectively. ( **D** ) Comparison between the experimental and the simulated PACBED patterns obtained from each nanograin in the three HZO samples. The simulated PACBED patterns were calculated from the three identified atomic structures. ( **E** ) Maps of _a_ / _b_ ratio in O _K_ EELS for the three HZO samples. The maps were reconstructed by NLLS fitting process for the obtained EELS SI datasets. Insets represent O _K_ EELS spectra averaged over the HZO film regions, respectively. Note that the outside regions shaded with dark gray in each HZO sample were not considered for the evaluation of the _a_ / _b_ ratio because those regions are unrelated to the HZO film. The color scale bar on the rightmost side indicates the range of the measured _a_ / _b_ ratio in O _K_ edge. 

17 

Submitted Manuscript: Confidential Template revised February 2021 

5 

10 



**Fig. 4. Polarization charge after ion bombardment.** Normalized polarization 𝑃(𝐸) on the electric field _E_ calculated for ( **A** ) normalized spontaneous polarization 𝑝 vs. relative film thickness ℎℎ𝑑 calculated for different 𝑁𝑑𝑜 = (2, 1.5, 1, 0.5)  𝑁0 (black, red, blue, and green curves, respectively). **(B)** Normalized spontaneous polarization 𝑝 vs. vacancy concentration 𝑁𝑑𝑜 calculated for different film thicknesses ℎ= (2, 5, 10, 20) ℎ𝑑 (black, red, blue and green curves, respectively). Parameters: 𝑇= 300 K,<sup><u>𝐽</u></sup> = ―10 𝐾, 𝑞33〈𝑊<sup>𝑑</sup> 33<sup>〉𝑁</sup> 0<sup>= ―5 ∙106 mJ/C2 corresponds</sup> 𝑘𝐵 to e.g., 𝑁0≅10<sup>25</sup> m<sup>-3</sup> at 〈𝑊<sup>𝑑</sup> 33<sup>〉≅― 10―29 m-3 and 𝑞</sup> 33<sup>= 5 ∙1010 mJ/C2. (</sup><sup>**C**) Topographic image</sup> of HZO thin film with top electrodes. Red and blue circles indicate the points where P-V curve measurements by AFM-PUND were performed for the pristine and bombarded regions, respectively. The slightly larger height with rectangular shape indicates the region bombarded with 10<sup>17</sup> ions/cm<sup>2</sup> . ( **D** ) P-V curves of the pristine (red) and bombarded (blue) regions. Note that, in the case of the pristine region, P-V curve measurements were performed before He ion bombardment. 

18 

