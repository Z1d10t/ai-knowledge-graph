# Photoluminescent Nanoparticles for Chemical and Biological Analysis and Imaging.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Chemical Reviews |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 299 |
| 作者 | W. R. Algar, M. Massey, Kelly Rees, Rehan Higgins, Katherine D. Krause, Ghinwa H. Darwish, W. J. Peveler, Zhujun Xiao et al. |
| DOI | 10.1021/acs.chemrev.0c01176 |
| 源文件 | 004_Algar_2021_Photoluminescent-Nanoparticles-for-Chemical-and.pdf |

---


<mark>Algar, W. R. et al. (2021) Photoluminescent nanoparticles for chemical and biological analysis and imaging.</mark> _<mark>Chemical Reviews</mark>_ <mark>, 121(15), pp. 9243-9358.</mark> 

<mark>(doi: 10.1021/acs.chemrev.0c01176)</mark> 

This is the Author Accepted Manuscript. 

There may be differences between this version and the published version. You are advised to consult the publisher’s version if you wish to cite from it. 

<u>https://eprints.gla.ac.uk/247215/</u> 

Deposited on: 27 July 2021 

Enlighten – Research publications by members of the University of Glasgow <u>http://eprints.gla.ac.uk</u> 

# **Photoluminescent Nanoparticles for Chemical and Biological Analysis and Imaging** 

_W. Russ Algar,_<sup>_1_</sup> _* Melissa Massey,_<sup>_1_</sup> _Kelly Rees,_<sup>_1_</sup> _Rehan Higgins,_<sup>_1_</sup> _Katherine D. Krause,_<sup>_1_</sup> _Ghinwa H. Darwish,_<sup>_1_</sup> _William J. Peveler,_<sup>_2_</sup> _Zhujun Xiao,_<sup>_1_</sup> _Hsin-Yun Tsai,_<sup>_1_</sup> _Rupsa Gupta,_<sup>_1_</sup> _Kelsi Lix,_<sup>_1_</sup> _Michael V. Tran,_<sup>_1_</sup> _Hyungki Kim_<sup>_1_</sup> 

- 1Department of Chemistry, University of British Columbia, 2036 Main Mall, Vancouver, BC, V6T 1Z1, Canada 

- 2 Division of Biomedical Engineering, School of Engineering, University of Glasgow, Glasgow, G12 8LT, U.K. 

- *Corresponding author: algar@chem.ubc.ca 

1 

# **Abstract** 

Research related to the development and application of luminescent nanoparticles (LNPs) for chemical and biological analysis and imaging is flourishing. Novel materials and new applications continue to be reported after two decades of research. This review provides a comprehensive and heuristic overview of this field. It is targeted to both newcomers and experts who are interested in a critical assessment of LNP materials, their properties, strengths and weaknesses, and prospective applications. Numerous LNP materials are cataloged by fundamental descriptions of their chemical identities and physical morphology, quantitative photoluminescence (PL) properties, PL mechanisms, and surface chemistry. These materials include various semiconductor quantum dots, carbon nanotubes, graphene derivatives, carbon dots, nanodiamonds, luminescent metal nanoclusters, lanthanide-doped upconversion nanoparticles and downshifting nanoparticles, triplet-triplet annhilation nanoparticles, persistent luminescence nanoparticles, conjugated polymer nanoparticles and semiconducting polymer dots, multi-nanoparticle assemblies, and doped and labeled nanoparticles, including but not limited to those based on polymers and silica. As an exercise in the critical assessment of LNP properties, these materials are ranked by several application-related, functional criteria. Additional sections highlight recent examples of advances in chemical and biological analysis, point-of-care diagnostics, and cellular, tissue, and _in vivo_ imaging and theranostics.  These examples are drawn for the recent literature, and organized by both LNP material and the particular properties that are leveraged to an advantage. A perspective is then offered on what comes next for the field. 

**Keywords:** assay, bioanalysis, energy transfer, fluorescence, imaging, nanoparticle, point-ofcare diagnostics, photoluminescence, sensors, smartphone, theranostics 

2 

# **Table of Contents** 

1. Introduction 

2. Catalog of Materials 

   - 2.1 Fluorescent Dyes and Proteins 

2.1.1 PL Properties and Mechanism 

   - 2.1.2 Labeling 

- 2.2 Transition Metal Complexes 

   - 2.2.1 PL Properties and Mechanism 

   - 2.2.2 Labeling 

- 2.3 Luminescent Lanthanide Complexes 

2.3.1 PL Properties and Mechanism 

- 2.4 Quantum Dots 

2.4.1 II-VI QDs 

2.4.1.1 PL Properties and Mechanism 

2.4.1.2 Surface Chemistry and Functionalization 

- 2.4.2 IV-VI QDs 

2.4.2.1 PL Properties and Mechanism 

2.4.2.2 Surface Chemistry and Functionalization 

- 2.4.3 III-V QDs 

2.4.3.1 PL Properties and Mechanism 

2.4.3.2 Surface Chemistry and Functionalization 

   - 2.4.4 I-III-VI and I-VI QDs 

      - 2.4.4.1 PL Properties and Mechanism 

      - 2.4.4.2 Surface Chemistry and Functionalization 

   - 2.4.5 IV QDs 

      - 2.4.5.1 PL Properties and Mechanism 

      - 2.4.5.2 Surface Chemistry and Functionalization 

- 2.5 Nanoscale Colloidal Carbon Allotropes 

   - 2.5.1 Carbon Nanotubes 

      - 2.5.1.1 PL Properties and Mechanism 

3 

      - 2.5.1.2 Surface Chemistry and Functionalization 

   - 2.5.2 Graphene-Derived Materials 

      - 2.5.2.1 PL Properties and Mechanism 

      - 2.5.2.2 Surface Chemistry and Functionalization 

   - 2.5.3 Carbon Dots 

      - 2.5.3.1 PL Properties and Mechanism 

      - 2.5.3.2 Surface Chemistry and Functionalization 

   - 2.5.4 Nanodiamonds 

      - 2.5.4.1 PL Properties and Mechanism 

      - 2.5.4.2 Surface Chemistry and Functionalization 

- 2.6 Metal Nanoclusters 

   - 2.6.1 PL Properties and Mechanism 

   - 2.6.2 Surface Chemistry and Functionalization 

- 2.7 Lanthanide-doped Upconversion and Downshifting Nanoparticles 

   - 2.7.1 PL Mechanism 

   - 2.7.2 PL Properties 

   - 2.7.3 Surface Chemistry and Functionalization 

- 2.8 Persistent Luminescence Nanoparticles 

   - 2.8.1 PL Properties and Mechanism 

   - 2.8.2 Surface Chemistry and Functionalization 

- 2.9 Conjugated Polymer Nanoparticles 

   - 2.9.1 PL Properties and Mechanism 

   - 2.9.2 Surface Chemistry and Functionalization 

- 2.10 Doped and Labeled Nanoparticles 

- 2.11 Lipid Nanoparticles 

- 2.12 Virus-like Nanoparticles 

- 2.13 Synthetic Polymer Nanoparticles 

   - 2.13.1 Crosslinked Polymer Nanoparticles 

   - 2.13.2 Dendrimers 

   - 2.13.3 Disordered Aggregate Polymer Nanoparticles 

   - 2.13.4 Assemblies of Amphiphiles 

4 

      - 2.13.5 DNA Nanostructures 

   - 2.14 Triplet-Triplet Annihilation Upconversion Nanoparticles 

      - 2.14.1 PL Properties and Mechanism 

   - 2.15 Dye-Doped Silica Nanoparticles 

      - 2.15.1 PL Properties and Mechanism 

      - 2.15.2 Surface Chemistry and Functionalization 

   - 2.16 Labeled Iron Oxide Nanoparticles 

   - 2.17 Labeled Metal Nanoparticles 

   - 2.18 Multi-Nanoparticle Assemblies 

      - 2.18.1 Plasmonic Nanoparticle-LNP Assemblies 

      - 2.18.2 Magnetic Nanoparticle-LNP Assemblies 

3. Power Rankings 

   - 3.1 Intrinsic Brightness and Maximum PL Intensity 

   - 3.2 Optical Access and Low Background 

   - 3.3 Multicolor Measurements 

   - 3.4 Plug-and-Play Compatibility 

   - 3.5 Photobleaching 

   - 3.6 Blinking and Photoswitching 

   - 3.7 Size 

   - 3.8 Cargo Capacity 

   - 3.9 Labeling 

   - 3.10 Surface Chemistry and Functionalization 

   - 3.11 Non-Ranked Factors 

      - 3.11.1 Robustness 

      - 3.11.2 Rational Design 

      - 3.11.3 Biocompatibility and Toxicological Risk 

      - 3.11.4 Photodamage and Phototoxicity 

3.11.5 Suitability for FRET 

- 3.11.5.1 Size 

- 3.11.5.2 Absorption and Emission Spectra 

3.11.5.3 Absorption and Emission Efficiencies 

5 

3.11.5.4 Excited-state Lifetime 

   - 3.12 Overall Power Rankings 

4. Chemical Analysis and Bioanalysis 

   - 4.1 CdX QDs 

      - 4.1.1 Leveraging Brightness 

      - 4.1.2 Leveraging Spectral Properties 

      - 4.1.3 Harnessing Inorganic Reactivity 

      - 4.1.4 Harnessing Ligand Reactivity 

      - 4.1.5 Leveraging Surface Area: Molecular Imprinting 

      - 4.1.6 Leveraging Surface Area: Building FRET Networks 

      - 4.1.7 Harnessing Surface Chemistry: Regulating Enzyme Activity 

      - 4.1.8 Harnessing Surface Chemistry: Sensor Arrays 

   - 4.2 Other QD Materials 

      - 4.2.1 Leveraging Photoinduced Electron Transfer Capability 

      - 4.2.2 Utilizing Energy Transfer Capability 

      - 4.2.3 Leveraging Robust PL 

      - 4.2.4 Harnessing Inorganic Reactivity 

   - 4.3 SWCNTs 

   - 4.4 CDs and GQDs 

      - 4.4.1 Harnessing PL Quenching Mechanisms 

      - 4.4.2 Leveraging Multiple Origins of PL 

      - 4.4.3 Utilizing PL Lifetime Sensitivity 

      - 4.4.4 Leveraging Catalytic Activity 

   - 4.5 Metal NCs 

      - 4.5.1 Leveraging PL 

      - 4.5.2 Utilizing PET Capability 

      - 4.5.3 Leveraging Reactivity 

      - 4.5.4 Leveraging Surface Sensitivity 

      - 4.5.5 Leveraging Aggregation Induced Emission 

   - 4.6 UCNPs 

      - 4.6.1 Leveraging Upconversion PL 

6 

      - 4.6.2 Leveraging Multiple Narrow Emission Bands 

      - 4.6.3 Leveraging Non-Bleaching and Non-Blinking PLs 

      - 4.6.4 Utilizing Energy Transfer Capability 

      - 4.6.5 Leveraging Anti-Stokes PL 

      - 4.6.6 Harnessing Upconversion: Photochemistry 

   - 4.7 CPNs and Pdots 

      - 4.7.1 Leveraging Brightness: Single Particle Counting Assay 

      - 4.7.2 Leveraging Polymer Chemistry: Metal Chelation 

   - 4.8 Doped and Labeled NPs 

      - 4.8.1 Harnessing Loading Capacity 

      - 4.8.2 Harnessing Structural Changes 

      - 4.8.3 Leveraging Multivalency 

      - 4.8.4 Utilizing Metal-Enhanced Fluorescence 

   - 4.9 Multi-NP Assemblies 

      - 4.9.1 Leveraging Brightness 

      - 4.9.2 Utilizing Multifunctionality 

      - 4.9.3 Harnessing Differences in PL Properties 

5. Toward Point-of-Care Diagnostics 

   - 5.1 Lateral Flow Immunochromatographic Assays 

      - 5.1.1 Leveraging Brightness 

      - 5.1.2 Leveraging Persistent Luminescence 

      - 5.1.3 Utilizing Multicolor PL 

      - 5.1.4 Utilizing Energy Transfer Capability 

      - 5.1.5 Leveraging Multifunctionality 

   - 5.2 Smartphone-based Assays 

      - 5.2.1 Leveraging Brightness 

      - 5.2.2 Utilizing Spectrally Narrow PL 

      - 5.2.3 Harnessing Multifunctionality: Bright and Magnetic LNPs 

      - 5.2.4 Leveraging Upconversion PL 

      - 5.2.5 Leveraging Long PL Lifetime 

      - 5.2.6 Utilizing Surface Sensitivity 

7 

- 5.2.7 Harnessing Reactivity 

5.2.8 Harnessing Different PL Sensitivities 

6. Cellular, Tissue, and in Vivo Imaging and Theranostics 

   - 6.1 CdX QDs 

      - 6.1.1 Utilizing QDs as a Traceable Proxy 

      - 6.1.2 Utilizing Energy Transfer Capability 

      - 6.1.3 Utilizing PET Capability 

      - 6.1.4 Leveraging Multivalency 

      - 6.1.5 Leveraging Nanoparticle Effects 

   - 6.2 Other QD Materials 

      - 6.2.1 Harnessing Surface Chemistry 

      - 6.2.2 Leveraging NIR PL Emission 

      - 6.2.3 Leveraging Long PL Lifetime 

      - 6.2.4 Utilizing Spectrally Narrow PL Emission 

   - 6.3 SWCNTs 

      - 6.3.1 Leveraging NIR Emission 

      - 6.3.2 Leveraging Resistance to Photobleaching 

      - 6.3.3 Harnessing Surface Sensitivity 

   - 6.4 CDs and GQDs 

      - 6.4.1 Utilizing Blinking: Super-Resolution Imaging 

      - 6.4.2 Leveraging Surface Chemistry 

      - 6.4.3 Harnessing Surface Sensitivity 

   - 6.5 Nanodiamonds 

      - 6.5.1 Leveraging Non-Blinking and Non-Bleaching PL 

      - 6.5.2 Harnessing Defect Chemistry 

   - 6.6 Au NCs 

      - 6.6.1 Harnessing Reactivity 

      - 6.6.2 Leveraging Size and NIR Emission 

      - 6.6.3 Leveraging Size and Surface Area 

      - 6.6.4 Utilizing Energy Transfer 

   - 6.7 UCNPs and DLnNPs 

8 

      - 6.7.1 Utilizing Energy Transfer 

      - 6.7.2 Harnessing Upconversion: Spatiotemporal Control 

      - 6.7.3 Leveraging Downshifting 

   - 6.8 TTA-NPs 

   - 6.9 pLNPs 

   - 6.10 Pdots and CPNs 

      - 6.10.1 Leveraging Size and Surface Chemistry 

      - 6.10.2 Leveraging Brightness 

      - 6.10.3 Leveraging Energy Transfer: Photoswitching 

      - 6.10.4 Leveraging Polymer Chemistry 

      - 6.10.5 Utilizing Blinking: Super-resolution Imaging 

      - 6.10.6 Harnessing Reactivity 

   - 6.11 Doped and Labeled NPs 

      - 6.11.1 Leveraging Small Size 

      - 6.11.2 Leveraging Surface Chemistry 

      - 6.11.3 Leveraging Protein Engineering 

      - 6.11.4 Utilizing Cargo Capacity 

   - 6.12 Multi-NP Assemblies 

      - 6.12.1 Harnessing Different PL Sensitivities 

      - 6.12.2 Utilizing PL and Magnetism 

      - 6.12.3 Leveraging Upconversion PL: Photosensitization 

      - 6.12.4 Pairing PL with other Contrast Mechanisms 

7. Perspective 

Acknowledgements 

Author Contributions 

Author Biographies 

References 

9 

# **1. Introduction** 

The International Union of Pure and Applied Chemistry (IUPAC) defines _luminescence_ as the spontaneous emission of radiation from an electronically or vibrationally excited species.<sup>1</sup> In turn, _photoluminescence_ (PL) is luminescence from direct photoexcitation of that species.<sup>2</sup> Fluorescence is the best known and most analytically useful example of PL. Features and advantages of fluorescence measurements include, but are not necessarily limited to, optical selectivity via excitation and emission wavelengths, high sensitivity (potentially to the level of single molecule detection), multiplexing through multicolor or multiwavelength measurements, multiparametric measurements ( _e.g._ intensity, lifetime, anisotropy), up to three-dimensional spatial resolution, temporal resolution, and non-destructive and non-contact measurements.<sup>3–5</sup> Few other techniques, if any, can match this capability and versatility. The scope of analytical applications of fluorescence includes assays, imaging, chemical and biological sensing, other more specialized applications, and fundamental characterization of materials and samples. 

To date, organic synthetic fluorescent dyes and engineered fluorescent proteins (FPs) have been the workhorses of both analytical and biological fluorescence measurements, with large and still growing libraries of both materials. Dyes and FPs are often selected on the basis of excitation and emission wavelengths, and by the availability of reactive derivatives for labeling and bioconjugation. As these materials already span the visible and near-infrared (NIR) spectrum many times over, it is often not color that motivates new additions to these libraries. Rather, new additions are frequently motivated by tailoring particular properties; for example, one or more enhanced photophysical properties ( _e.g._ quantum yield, photoswitching behavior, photobleaching rate), designed sensitivity of photophysical properties to an analyte or environmental condition of interest ( _e.g._ pH, viscosity, temperature), or physical characteristics such as size, solubility, binding properties or other intermolecular interactions. Nevertheless, the tailorability of dyes and FPs through molecular design and protein engineering is finite. Some disadvantages cannot be overcome and some desired properties cannot be accessed. In this respect, one recourse is technical optimization, such as through the use of more sophisticated instruments and measurement techniques. Another recourse is the use of an alternative luminescent material. 

10 

Luminescent nanoparticles (LNPs) are a diverse set of alternative luminescent materials, spanning carbonaceous, organic, biological, and inorganic materials. The physical and photophysical properties of these materials, and their PL mechanisms, are equally diverse. As such, each LNP has advantages and disadvantages versus dyes, FPs, and other LNPs. There are some applications where an LNP is well used as a substitute for a dye or FP, others where an LNP is best used to complement or enhance the parallel use of a dye or FP, and others where the use of a dye or FP will be functionally superior to the use of an LNP. In general, use of an LNP should be motivated by one or more advantages derived from its photophysical properties, its size or surface area, or its composition. Good matchmaking between the LNP and the application is essential for obtaining favorable outcomes. 

Here, we review the use of LNPs for chemical and biological analysis. For this purpose, we define an LNP as a material that exhibits PL as a discrete entity with sub-micron (and preferably sub100-nm) dimensionality and potential for stable colloidal dispersion. Materials that fall under this definition include semiconductor quantum dots, single-walled carbon nanotubes, graphenederived materials, carbon dots, nanodiamonds, metal nanoclusters, lanthanide-doped upconversion and downshifting nanoparticles, persistent luminescence nanoparticles, a variety of doped and labeled nanoparticles ( _e.g._ dye-doped silica nanoparticles, triplet-triplet annihilation nanoparticles), and discrete supra- or super-particle assemblies of LNPs. Figure 1 depicts the use of these materials for analysis and imaging, since 1996, as the number of indexed publications per year. Doped and labeled nanoparticles (NPs) and multi-NP assemblies are not included because the PL properties of these materials are not intrinsic and rather come from the luminescent materials selected for labeling, doping, or assembling. The relative numbers of publications are approximately reflective of the research activity and growth of interest in each type of LNP material. 

11 



**Figure 1.** Approximate number of indexed publications per year that leverage the PL properties of various LNPs for (bio)analytical and imaging applications. Abbreviations: QDs, semiconductor quantum dots; SWCNTs, single-walled carbon nanotubes; CDs, carbon dots; GQDs, graphene quantum dots; NDs, nanodiamonds; UCNPs, lanthanide-doped upconversion nanoparticles; metal NCs, metal nanoclusters; CPNs/Pdots, conjugated polymer NPs/semiconducting polymer dots; pLNPs, persistent luminescence nanoparticles; TTA-UCNPs, triplet-triplet annihilation upconversion nanoparticles. Source: Web of Science database; see SI for details of the search. 

This review begins with a catalog of LNP materials, addressing their morphology, structure, and composition, PL properties and mechanism, and, in brief, their surface chemistry. Note that the chemistries used for the functionalization and bioconjugation of the LNPs are underemphasized for reasons of scope (the focus here is PL properties). Poor functionalization and ineffective bioconjugation can render the advantageous photophysical properties of LNPs moot, for example, because of prohibitive colloidal instability or non-specific binding, or little or no biological activity. More information on the functionalization and bioconjugation of NPs can be found in several detailed reviews.<sup>6–8</sup> The catalog section is followed by what we call a “Power Rankings” 

12 

section where we discuss and evaluate the LNPs with respect to various functional criteria for their use in applications. 

Following the Power Rankings section, we present a selection of recent examples of analytical and imaging applications of LNPs (up to and including 2019). These examples are grouped into three sections. The first section largely covers _in vitro_ assays and sensors. The second section continues this topic in the specific context of point-of-care (POC) or point-of-need diagnostics, especially with respect to lateral flow immunochromatographic assays and smartphone-based assays and devices. The third section covers cellular, tissue, and _in vivo_ imaging, as well as some theranostic applications. Given the scope of LNP materials and wide range of applications of each, we were unable to cover all recent work in this vibrant and far-reaching field. Our goal was to present examples of applications that illustrate how one or more of the PL properties of the various LNPs were used to an advantage. Omissions of notable work were unavoidable and we convey our apologies and respect to these authors. Throughout the text, interested readers are encouraged to further explore the literature via referrals to other review articles that focus on specific LNP materials or a more-narrow scope of applications. 

The review concludes with a perspective on remaining challenges and future directions for the analytical applications of LNPs. 

# **2. Catalog of Materials** 

This section is a catalog of photoluminescent materials. For each LNP material, we summarize (as applicable) the physicochemical identity of the material, its PL properties and mechanism, and its surface chemistry. For comparison, we also do the same for organic fluorescent dyes, FPs, luminescent transition metal complexes, and luminescent lanthanide complexes. The discussion of each material is far from exhaustive. Review articles have been cited wherever possible and readers are encouraged to refer to these resources for much more detailed information. Although it would arguably be preferable to cite as much original work as possible, the aspiration of this section is to be a “one-stop shop” for utilitarian information about a wide range of materials. It is targeted to 

13 

novices, non-experts, and any researcher seeking out the best material for a particular application. We anticipate that readers will identify and become knowledgeable about the material(s) matched to their application by first reading this review. Further reading of material-specific reviews and subsequent digging into original work will help readers become experts in particular materials. Again, our apologies and respect to authors whose important original work we have not cited directly. 

For quick reference, Table 1 summarizes several important PL properties for the LNPs discussed in this section. For PL properties with wide ranges of values tabulated, the most likely reasons are variation in the property as a function of NP size, wavelength, and/or composition. It should also be noted values in Table 1 are intended to reflect typical values for good-quality materials. The corresponding values for low-quality materials may fall outside of the reported ranges of values, as may values for rarely-achieved, best-in-class materials. As much as this review will highlight research effort toward applications of LNPs, there is similar research effort toward continually improving upon the PL properties of these materials, such that values in this table may eventually be out of date. 

**2.1 Fluorescent Dyes and Proteins.** Most fluorescent dyes are organic molecules, typically < 2 kDa in molecular weight and < 2 nm in size, that are rich in double bonds, fused rings, and heteroatoms. Common examples, some of which are shown in Figure 2A,<sup>9–13</sup> include the families of fluorescein and rhodamine dyes (both xanthenes), coumarins, cyanines, boron-dipyrromethenes (BODIPYs), naphthalene derivatives, and squaraines.<sup>14–18</sup> Each dye has a well-defined molecular structure that is obtained via standard organic synthetic methodology. 

14 



**Figure 2.** Examples of photoluminescent molecules: **(A)** fluorescent dyes, **(B)** luminescent TMCs, and **(C)** LLCs. The name of each dye is shown with its parent structure in parentheses. The colors of the structures indicate their approximate emission color and, to a first approximation, the emitting component(s). R groups are common points for attachment of a reactive linker for labeling biomolecules. The dyes and LLCs are commercially available or from ref. 9. The TMCs are from refs. 10–13. Abbreviations: bphen, bathophenanthroline; bpy, 2,2’-bipyridine; bpybz, 1,3-bis(2-pyridyl)benzene; DIGP, tetrakis-(diisopropylguanidine) phthalocyanine; phen, phenanthroline; TBP, trisbipyridine. 

15 

**Table 1.** PL properties of selected molecular materials and LNPs.<sup>_a_</sup> 

|**Material**<sup>**_b_**</sup>|**Size**<br>**(nm)**<sup>**_c_**</sup>|**Exc.**<br>**Range**<sup>**_d_**</sup>|**ε**<sup>**_e_**</sup><br>**(Μ**<sup>**–1**</sup>**cm**<sup>**–1**</sup>**)**|**Exc. FWHM (nm)**|**TPA**<sup>**_f_**</sup><br>**(GM)**|**Em. Range**<sup>**_d_**</sup>|**Em. Bands**|**Em. FWHM**<br>**(nm)**|**PL QY**|**τ (s)**<sup>**_g_**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|
|Organic<br>Dyes|< 2|UV–NIR-II|10<sup>4</sup>–10<sup>5</sup>|30–70 (vis)<br>50–150 (NIR)|≤ 10<sup>2</sup>|vis-NIR-II|single (tailed)|25–50 (vis)<br>40–150 (NIR)|0.05–0.9<br>(vis–NIR-I)<br>≤ 0.01 (NIR-II)|10<sup>–10</sup>–10<sup>–8</sup>|
|FPs|4–12|UV–vis|10<sup>4</sup>–10<sup>5</sup>|30–70|≤ 10<sup>2</sup>|vis-NIR|single (tailed)|25–80|0.1–0.9|10<sup>–10</sup>–10<sup>–9</sup>|
|LLCs|< 2|UV|10<sup>4</sup>|30–70|≤ 10<sup>2</sup>|UV-NIR-II|multiple|15–30 (vis)<br>50–100 (NIR)|0.1–0.6 (vis)<br>≤ 0.1 (NIR)|10<sup>–6</sup>–10<sup>–3</sup>|
|TMCs|< 2|UV-vis|10<sup>3</sup>–10<sup>5</sup>|multiple bands<br>(each 20–100)|≤ 10<sup>3</sup>|vis–NIR-I|single|100–200|0.05–0.9|10<sup>–7</sup>–10<sup>–5</sup>|
|CdX QDs|2–10|UV-vis|10<sup>5</sup>–10<sup>7</sup>|<br>broad|10<sup>3</sup>–10<sup>4</sup>|vis–NIR-I|single|25–75|0.1-0.8|10<sup>–8</sup>|
|PbX QDs|2–10<br>|vis-NIR-II|10<sup>5</sup>–10<sup>7</sup>|broad|10<sup>4</sup>|NIR-II|single|100–250|≤ 0.3|10<sup>–7</sup>–10<sup>–6</sup>|
|InP QDs|2–10|UV-vis|10<sup>5</sup>–10<sup>7</sup>|broad|10<sup>2</sup>–10<sup>3</sup>|vis-NIR|single|35–100|≤ 0.6|10<sup>–9</sup>–10<sup>–7</sup>|
|CIS QDs|2–10|vis–NIR-I|10<sup>5</sup>–10<sup>7</sup>|broad|10<sup>2</sup>–10<sup>3</sup>|vis–NIR-II|single|100–200 nm|≤ 0.6|10<sup>–7</sup>|
|AgX QDs|1–10|vis–NIR-I|10<sup>5</sup>–10<sup>7</sup>|broad|10<sup>2</sup>–10<sup>3</sup>*|vis–NIR|single|75–300|≤ 0.3|10<sup>–8</sup>–10<sup>–7</sup>|
|Si QD|2–10|UV-vis|10<sup>4</sup>–10<sup>5</sup>|broad<br>|nr|vis–NIR-I|single|100–200|≤ 0.7|10<sup>-6</sup>–10<sup>–5</sup>|
|||||two bands per|||||||
|SWCNTs|10<sup>2</sup>–10<sup>3</sup>|vis-NIR|10<sup>6</sup>–10<sup>8</sup>|<br>chirality<br>(each 25–35 nm)|10<sup>3</sup>–10<sup>4</sup>|NIR|single (per<br>chirality)|25–50|0.001–0.01|10<sup>–11</sup>–10<sup>–10</sup>|
|GQDs|< 20|UV|10<sup>5</sup>–10<sup>6</sup>*|<br>50–broad|10<sup>2</sup>–10<sup>4</sup>|vis|single|50–125|0.05–0.5|10<sup>–9</sup>–10<sup>–8</sup>|
|CDs|1–10|UV|10<sup>5</sup>–10<sup>6</sup>*|50–100|10<sup>2</sup>–10<sup>4</sup>|vis|single|75–150|0.05–0.9|10<sup>–9</sup>–10<sup>–8</sup>|
|NDs (NV)|4–10<sup>2</sup>|vis|10<sup>3</sup>–10<sup>6</sup>*|100–150|< 10<sup>3</sup>|Red/NIR-I|single|100–150|0.05–0.8|10<sup>–9</sup>–10<sup>–8</sup><br>|
|Metal NCs|< 3|UV-NIR|10<sup>4</sup>–10<sup>5</sup>|broad|10<sup>3</sup>–10<sup>5</sup>|vis–NIR-I|single|75–150 nm|0.01–0.2|10<sup>–9</sup>–10<sup>–6</sup>|
|UCNPs and<br>DLnNPs|10<sup>1</sup>–10<sup>2</sup>|NIR-I|10<sup>4</sup>–10<sup>7</sup>*|< 50|nr|UV-NIR-II|multiple|15–30 (vis)<br>50–100 (NIR-I/II)|≤ 0.1|10<sup>–4</sup>–10<sup>–2</sup>|
|pLNPs<sup>_h_</sup>|5–10<sup>2</sup>|UV–vis|nr|50–150|nr|vis-NIR-I|single|<br>50–100|nr|1–10<sup>5</sup>|
|CPNs/Pdots|4–100<br>|UV–NIR-I|10<sup>6</sup>–10<sup>9</sup><br>|broad|10<sup>3</sup>–10<sup>5</sup>|vis–NIR-II|single (tailed)|40–200|0.05–0.6|10<sup>–10</sup><br>|
|TTA-NPs<br>**Notes:**|10<sup>1</sup>–10<sup>2</sup>|G–NIR-I|10<sup>5</sup>–10<sup>7</sup>*|20–50|nr|B–O|single (tailed)|25–100|≤0.3|10<sup>–6</sup>–10<sup>–5</sup>|



> _a_ The asterisk (*) beside a value refers to limited data available. These values arise from either (i) very few measurements in the literature that are consistent with expectations based on size and composition, or (ii) predications based on the size, composition, and/or dopant properties, or from limited data available. 

> _b_ Abbreviations: FPs, fluorescent proteins; LLCs, luminescent lanthanide complexes; TMCs, transition metal complexes; QDs, quantum dots; SWCNTs, single-walled carbon nanotubes; GQDs, graphene quantum dots; CDs, carbon dots; NDs (NV), nanodiamonds with NV defects; UCNPs, lanthanide-based upconversion nanoparticles; DLnNPs, downshifting lanthanide-based nanoparticles; pLNPs, persistent luminescence nanoparticles; CPNs, conjugated polymer nanoparticles; Pdots, semiconducting polymer dots; TTANPs, triplet-triplet annihilation upconversion nanoparticles. 

> _c_ Size refers to largest dimension if the material is not quasi-spherical. 

> _d_ Spectral ranges: UV (200–400 nm), visible (400–650 nm), NIR-I (650–950 nm), the NIR-II (1000–1800 nm). The colors of the visible spectrum (red, orange, yellow, green, blue, violet) are indicated by letters (R, O, Y, G, B, V). 

> _e_ Molar absorption coefficient 

> _f_ Two-photon absorption cross-section 

> _g_ Typical PL emission lifetime 

> _h_ This entry refers to pLNPs not based on lanthanide ions 

16 

The two main varieties of FPs are phycobiliproteins<sup>19,20</sup> and members of the green fluorescent protein (GFP) family.<sup>21,22</sup> The former are photosynthetic pigments from cyanobacteria and the latter are derived from marine coelenterates ( _e.g. Aqueoria vitoria_ sea jelly or _Discosoma_ sea anemone). Phycobiliproteins are either trimeric or hexameric proteins, where each monomer unit (15–20 kDa) has two subunits, each of which has a phycobilin fluorophore (an acyclic tetrapyrrole).<sup>19,20</sup> Thus, there is a minimum of six (trimers) or twelve (hexamers) fluorophores per phycobiliprotein, which are ≥ 100 kDa and can have a maximum dimension up to ~12 nm. The GFP-family proteins are ~27 kDa and fold into β-barrels (2.4 nm diameter, 4.2 nm length) with an α-helix running down their central axis. At the center of the protein, interrupting the central α- helix, is a fluorophore ( _e.g._ 4-(p-hydroxybenzylidene)-5-imidazolinone for GFP).<sup>21,22</sup> This fluorophore is the product of an autocatalytic reaction between three amino acid residues, two of which are always tyrosine and glycine.<sup>21,22</sup> 

# _2.1.1 PL Properties and Mechanism_ 

Organic fluorescent dyes and FPs both emit via the conventional fluorescence mechanism, with absorbance and PL reflecting singlet-singlet transitions between the highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO), inclusive of their manifolds of vibrational states. 

Organic fluorescent dyes have absorption and PL emission spectra that are usually approximate mirror images of one another, with their peaks separated by typical Stokes shifts of 15–30 nm.<sup>3,23,24</sup> The spectra are asymmetric, often with defined shoulders, with full-width-at-half-maximum (FWHM) values of 20–50 nm, although FWHM values are not always inclusive of shoulders. Typically, molar absorption coefficients are 10<sup>4</sup> –10<sup>5</sup> M<sup>–1</sup> cm<sup>–1</sup> , two-photon absorption coefficients are ≤ 10<sup>2</sup> GM, PL quantum yields (QYs) vary from a few percent to > 0.9, and PL emission decays are generally monoexponential with lifetimes of 1–10 ns.<sup>3,23,24</sup> Spectral features and their positions, PL QYs, and PL lifetimes are sometimes sensitive to conditions such as viscosity, pH, ionic strength, solvent ( _i.e._ polarity), and changes in local environment induced by attachment to a (bio)macromolecule or an interface. For a given parent structure ( _e.g._ rhodamine, indocyanine, or BODIPY), fluorescence properties are modified through changes in rigidity, substituents, and the number of conjugated double bonds.<sup>25</sup> As an example of the latter, Cy3, Cy5, and Cy7 have 

17 

polymethine bridges with 2, 3, and 4 double bonds joining indole rings and peak emission wavelengths of approximately _ca._ 565, 665, and 775 nm, respectively. Cy3.5, Cy5.5, and Cy7.5 fuse additional benzene rings to the original indole rings of Cy3, Cy5, and Cy7 to obtain peak emission wavelengths of _ca._ 590, 690, and 805 nm, respectively. These general structural concepts apply to other dye families as well. Overall, dyes are readily designed with PL emission in the ultraviolet (UV), visible, or near-infrared (NIR) regions. 

The GFP family of proteins, having a molecular fluorophore at their center, have absorption and PL emission spectra analogous to those of organic fluorescent dyes. PL emission colors for various FPs span the visible spectrum and, in a few cases, push into the NIR. Molar absorption coefficients and PL QYs range between 10<sup>4</sup> –10<sup>5</sup> M<sup>–1</sup> cm<sup>–1</sup> and 0.1–0.9, respectively, and lifetimes are on the order of nanoseconds.<sup>22</sup> PL properties vary between different FPs because of different molecular structures for their central fluorophore, different environments around their central fluorophore, or both. Ensconced within the protein barrel, PL emission is relatively insensitive to the solution environment, except for pH and denaturants or other conditions that unfold the protein. 

Allophycocyanin (trimeric), and B-phycoerythrin and R-phycoerythrin (hexameric) are three common phycobiliproteins that have molar absorption coefficients of ~10<sup>6</sup> M<sup>–1</sup> cm<sup>–1</sup> , PL QYs of ~0.70 or higher, and lifetimes on the order of nanoseconds.<sup>24</sup> The PL emission spectra have FWHM of 20–30 nm, absorption spectra have FWHM 45–60 nm, and both spectra are asymmetric with shoulders. 

Single fluorescent dyes and single FPs blink ( _i.e._ fluctuate between bright and dark states) and both materials photobleach ( _i.e._ irreversible loss of PL after many cycles of excitation and emission). Dyes and GFP-family FPs have also been designed to photoactivate ( _i.e_ convert from dark to bright state), photoswitch ( _i.e._ between dark and bright states), and photoconvert ( _i.e._ from one color to another).<sup>18,22,26,27</sup> It is also possible to design fluorescent dyes that activate in response to analytes ( _e.g._ ions, proteins, DNA),<sup>17,28,29</sup> activate upon aggregation (aggregation-induced emission),<sup>30</sup> and preferentially stain certain cellular organelles.<sup>31</sup> 

18 

# _2.1.2 Labeling_ 

Fluorescent dye derivatives with reactive group-terminated linker arms are widely available. These linkers are placed at sites that have minimal impact on PL properties. Common reactive groups include, but are not limited to, amines, hydrazides, and other nucleophiles; active esters ( _e.g._ succinimidyl esters); isothiocyanates; maleimides; and clickable functional groups ( _e.g._ alkynes, cycloalkynes, azides, tetrazines).<sup>24</sup> Enzymatic methods are also useful for labeling biomolecules with dyes. For labeling proteins, examples include the halotag<sup>32</sup> and SNAP-tag systems,<sup>33</sup> among others.<sup>34,35</sup> These systems employ a fusion of the protein of interest and the halotag protein (a modified haloalkane dehalogenase) or O<sup>6</sup> -alkylguanine-DNA alkyltransferase, which spontaneously form covalent bonds with chloroalkane and O<sup>6</sup> -benzylguanine tags, respectively, that are incorporated into the structure of dyes. Fluorescent dye derivatives of nucleobases are also readily incorporated into nucleic acids by various polymerase enzymes.<sup>36</sup> 

GFP-family FPs are used to directly label proteins of interest through genetic encoding of fusion proteins produced _in situ_ by a cultured cell or organism.<sup>37</sup> The FP expression level depends on the efficiencies of transcription and translation, the stability of the mRNA and the FP, and the rates of protein folding, chromophore maturation, and FP turnover.<sup>22</sup> Folding is necessary for GFP-family FPs to become fluorescent, often necessitating a linker of suitable length between the FP and fused protein. Maturation of the fluorophore requires a time period that can range from minutes to days.<sup>22</sup> Dimerization and oligomerization of FPs can be a challenge, and significant effort has been put into designing FPs that favor monomeric states. 

In contrast to GFP-family FPs, phycobiliproteins are not yet practical to genetically encode, in part because of the need to add the chromophoric phycobilin cofactor to the expressed apoprotein.<sup>25</sup> Phycobiliproteins are thus conjugated to biomacromolecules through crosslinking chemistries. 

**2.2 Transition Metal Complexes.** Luminescent transition metal complexes (TMCs) have been extensively studied as an alternative to small-molecule organic dyes.<sup>38,39</sup> The TMCs with the most optimal luminescent properties for PL measurements are most commonly complexes of _d_<sup>6</sup> , _d_<sup>8</sup> or _d_<sup>10</sup> metals. Common metals centers include Ru(II), Rh(III), Re(I), Ir(III), Pt(II), Au(I) or Zn(II).<sup>40–</sup> 

19 

44 Ligands are selected for stable complex formation, generally featuring polydentate carboxyls or nitrogen bearing aromatic heterocycles, and also influence PL properties through metal-to-ligand or ligand-to-metal charge transfer pathways. Common examples are bipyridyl or phenanthroline ligands. Biologically inspired ligands, such as porphyrins and chlorins, are also harnessed.<sup>45</sup> Examples of strutures are shown in Figure 2B. 

# _2.2.1 PL Properties and Mechanism_ 

TMC PL most commonly orignates from electronic transitions on the metal center that transfer to the ligands to relax (metal-to-ligand charge transfer, MLCT) or _vice versa_ (ligand-to-metal charge transfer, LMCT).<sup>46</sup> More complex pathways are also invoked in certain situations; for example, ligand-to-ligand, metal-metal-to-ligand, and metal-to-ligand-ligand charge transfer (LLCT, MMLCT and MLLCT respectively).<sup>41,46</sup> These complex energy transfer pathways give multiple absorption bands (typical molar absorption coefficients of 10<sup>3</sup> –10<sup>5</sup> M<sup>–1</sup> cm<sup>–1</sup> for fully allowed charge transfers) and may provide separations of more than 100 nm between PL excitation and emission wavelengths (usually UV and blue excitation in this case).<sup>44</sup> Of note, the use of heavy _d_ - elements encourages spin-orbit coupling leading to relatively facile intersystem crossing during MLCT processes, and production of long-lived phosphorescence (100 ns to tens of microseconds).<sup>44,47</sup> Depending on the ligands and metal center, this PL may be found in the visible or NIR regions of the spectrum, with typically broad FWHMs of 100–200 nm.<sup>48</sup> 

The access to the triplet state is associated with an increase in non-radiative relaxation routes via ligand vibration. Typical values for PL QYs in solution range from a few percent to 20%, but can be as high as 50%.<sup>47</sup> ~~(I~~ n an immobilized and low-oxygen environment, some aggregated Pt and Au complexes have been reported as achieving a PL QY in excess of 0.9.<sup>39</sup> ~~)~~ As PL properties are strongly dependent on the ligand environment, the exchange of ligands and resulting changes in PL properties is a useful basis for chemical and biological measurements. 

PL excited by two-photon absorption (TPA) is possible for TMCs with appropriate ligand sets with typtical TPA cross-sections of 10<sup>1</sup> –10<sup>3</sup> GM.<sup>49</sup> 

20 

# _2.2.2 Labeling_ 

The labeling methods associated with TMCs are largely analogous to those of fluorescent dyes, although TMCs offer some advantages. There is a degree of modularity in their construction, enabling the design of systems where one metal ligand is easily swapped out and replaced by another to give different conjugation options without substantially changing the synthetic route or PL properties. Similar to dyes, some TMCs selectively bind to DNA or proteins.<sup>46,50</sup> 

**2.3 Luminescent Lanthanide Complexes.** Luminescent lanthanide complexes (LLCs), which include both chelates and cryptates, comprise a trivalent lanthanide ion and coordinating organic ligands.<sup>51–55</sup> Most trivalent lanthanide ions are luminescent, but not bright enough to be practically useful without complexation by an organic ligand (or inclusion in a solid-state host matrix; _vide infra_ ). Examples of coordinating ligands are those based on aminocarboxylic acids, hydroxypyridine, 8-hydroxyquinoline, and 2-hydroxyisophthalamide, among several others.<sup>51–55</sup> Examples of structures are shown in Figure 2C. LLCs are small (< 2 nm) and are used with labeling strategies that are analogous to those for organic fluorescent dyes. Labeling chemistries are also analogous to those for organic dyes, with reactive groups found at the end of linker arms attached to the organic ligands. However, it should be noted that the synthesis of bright and reactive LLCs suitable for aqueous biological labeling is not trivial, accounting, at least in part, for their much more limited availability compared to organic dyes. 

# _2.3.1 PL Properties and Mechanism_ 

Trivalent lanthanide ions have partially filled 4 _f_ orbtials and PL arises from 4 _f_ -4 _f_ transitions, which, though parity forbidden (Laporte selection rule), are weakly allowed because of coupling to vibrational states and orbital mixing.<sup>52,54</sup> Direct excitation of lanthanide ion PL is impractical because the molar absorption coefficients for 4 _f_ -4 _f_ transitions are very small (< 10 M<sup>–1</sup> cm<sup>–1</sup> ). PL from lanthanide ions is thus obtained indirectly via antennae sensitization, where an organic ligand absorbs excitation light, transitions to a donor state, and transfers energy to the lanthanide ion, which then emits.<sup>51–55</sup> The most common ligand donor state is a triplet state, but others are possible, 

21 

and Dexter, dipole-dipole ( _i.e._ Förster), and dipole-multipole mechanisms of energy transfer are variously suggested.<sup>52–55</sup> 

LLCs exhibit narrow emission bands (FWHM 15–30 nm in the visible region, 50–100 nm in the NIR) that can be either fluorescence or phosphorescence.<sup>52,54</sup> This narrowness arises from the minimal environment-induced perturbations of the 4 _f_ orbitals with shielding by the filled 5 _s_ and 5 _p_ orbitals. Depending on the lanthanide ion, PL emission can be in the UV (Gd<sup>3+</sup> ), visible (Pr<sup>3+</sup> , Sm<sup>3+</sup> , Eu<sup>3+</sup> , Tb<sup>3+</sup> , Dy<sup>3+</sup> , Tm<sup>3+</sup> ), and NIR (Pr<sup>3+</sup> , Nd<sup>3+</sup> , Ho<sup>3+</sup> , Er<sup>3+</sup> , Yb<sup>3+</sup> ), often with multiple emission lines. 

To date, Tb<sup>3+</sup> and Eu<sup>3+</sup> complexes have been the most widely utilized, with predominantly green and red emission, respectively. Tb<sup>3+</sup> has its main emission bands at _ca._ 485, 540, 585, and 620 nm (and longer wavelengths), and Eu<sup>3+</sup> has its main emission bands at _ca._ 590, 610, and 690 nm, where the relative intensities of emission bands and wavelengths may vary between complexes and can strongly depend on the environment (especially for Eu-based LLCs). For good complexes of Tb<sup>3+</sup> and Eu<sup>3+</sup> , which put the lanthanide ion in a rigid environment (no high energy vibrations) protected from solvent, PL emission lifetimes range from hundreds of microseconds to millseconds and observed QYs are 0.1–0.6 (in water). Observed QYs are considerably lower for complexes of NIRemitting lanthanide ions ( _e.g._ fractions of a percent up to 0.13 in water, but higher in organic solvents), with shorter PL lifetimes.<sup>53,56,57</sup> Note that the observed QY is the product of the efficiency of ligand conversion to the donor state ( _e.g._ efficiency of intersystem crossing), the efficiency of energy transfer from ligand to lanthanide ion, and the actual emission QY of the lanthanide ion. Molar absorption absorption coefficients (for complexes) are on the order of 10<sup>4</sup> M<sup>–1</sup> cm<sup>–1</sup> and centered in the UV,<sup>54,55,58,59</sup> resulting in large spectral separation between excitation and emission.<sup>51</sup> 

**2.4 Quantum Dots.** Colloidal quantum dots (QDs) are approximately spherical semiconductor nanocrystals, typically 1–10 nm in diameter, and made up of hundreds to thousands of atoms.<sup>60–62</sup> One of the defining features of QDs is size-dependent electronic structure and PL emission from a phenomenon called _quantum confinement_ ( _vide infra_ ).<sup>60,63</sup> For the purpose of this review, we 

22 

subdivide QD materials into cadmium chalcogenides (group II-VI semiconductors), lead chalcogenides (group IV-VI semiconductors), non-heavy metal compounds (group III-VI, I-IIIVI, and I-VI semiconductors), and silicon (group IV semiconductor). 

**2.4.1 II-VI QDs.** CdS nanocrystals were the first colloidal semiconductor material in which quantum confinement was observed.<sup>64,65</sup> To date, cadmium chalcogenide semiconductors remain the most widely used QD materials and still set the bar for PL properties. This standing has arisen from an unrivaled combination of advantageous PL properties ( _vide infra_ ), PL excitation and emission at wavelengths analogous to conventional fluorescent dyes,<sup>63</sup> well-established synthetic procedures for relatively monodisperse CdS, CdSe, and CdTe nanocrystals,<sup>66</sup> including their alloyed and core/shell analogs,<sup>67,68</sup> and early commercialization. Figure 3A shows transmission electron microscope (TEM) images of CdSe QDs.<sup>69</sup> 

High-quality cadmium chalcogenide (CdX) QDs are synthesized via hot injection of cadmium and chalcogenide precursors ( _e.g._ dimethyl cadmium,<sup>66</sup> cadmium oxide/acetate,<sup>70,71</sup> trioctylphosphine selenide/telluride,<sup>66,71</sup> bis(trimethylsilyl) sulfide/selenide/telluride<sup>66</sup> ). Hydrophobic ligands ( _e.g._ alkyl phosphines, alkyl amines, fatty acids) and coordinating ( _e.g._ trioctylphosphine oxide) and non-coordinating solvents ( _e.g._ octadecene) are common reagents in these syntheses.<sup>72</sup> The aqueous syntheses of good-quality CdTe QDs has also been reported, where PL QYs are competitive with those obtained from hot injection syntheses, although the nanocrystals are usually (but not always) less monodisperse, giving broader emission FWHMs.<sup>73–75</sup> Similarly effective aqueous syntheses of CdS and CdSe QDs remain elusive, as the resulting QDs are generally poor quality with low PL QYs, poor monodispersity, and large emission FWHMs.<sup>76–78</sup> 

Most PL-based applications of QDs use a core/shell architecture, such as CdSe/ZnS, rather than a core-only nanocrystal ( _e.g._ CdSe). Figure 3B illustrates the core/shell structure pictorially.<sup>61</sup> The shell is an epitaxial layer of another semiconductor that passivates the core nanocrystal, protects it from the surrounding environment (and _vice versa_ ), and generally enhances its QY.<sup>61,67,69,79</sup> ZnS is the most common shell material for CdX QDs because of its bandgap energy ( _vide infra_ ) and its structural properties. Ideal shell materials are structurally similar to the core nanocrystal in order 

23 

to minimize lattice strain, which can introduce surface defects that degrade PL efficiency and counteract the benefits of the shell. For example, the lattice strain associated with the lattice mismatch between the wurtzite crystal structures for CdSe and ZnS is sufficiently large to be detrimental to the PL properties of CdSe/ZnS QDs if there is more than a few atomic layers of shell.<sup>61</sup> Architectures that help address this limitation include gradient shells ( _e.g._ CdSe/Cd _x_ Zn1– _x_ S),<sup>80</sup> multiple shells ( _e.g._ CdSe/CdS/ZnS),<sup>81</sup> and gradient interfaces between core and shell ( _e.g._ CdSe/CdxSexZn1-xS1-x/ZnS, where _x_ varies radially),<sup>82</sup> enabling the growth of thicker shells. Shells are grown via chemistry similar to that used for core synthesis, albeit with technical differences that promote epitaxial shell growth on the existing core nanocrystals rather than nucleation and growth of new nanocrystals. 

# _2.4.1.1 PL Properties and Mechanism_ 

High-quality CdX QDs exhibit narrow and symmetric (approximately Gaussian) PL emission spectra with typical FWHMs between 25–40 nm.<sup>63</sup> The peak PL wavelength is continuously tunable over a range of _ca._ 200–300 nm as a function of nanocrystal size, or over a range of _ca._ 300–400 nm as a function of both size and composition ( _e.g._ ternary semiconductors). Absorption is spectrally broad, with a first exciton peak at a wavelength _ca._ 15–30 nm shorter than the PL emission peak,<sup>61,83</sup> and increases (with potential observation of second and third exciton peaks) as wavelength decreases into the UV region. Figure 3C shows absorption and PL emission spectra for several sizes of CdSe QDs,<sup>69</sup> and Figure 3D shows the approximate PL emission ranges for CdS, CdSe, and CdTe QDs (among other materials).<sup>62</sup> CdX QDs also exhibit high brightness from competitive QYs (0.1–0.9), large molar absorption coefficients (10<sup>5</sup> –10<sup>7</sup> M<sup>–1</sup> cm<sup>–1</sup> ), and large TPA cross-sections (10<sup>3</sup> –10<sup>4</sup> GM).<sup>61,63</sup> PL lifetimes tend to be multiexponential and average between 10–50 ns. QDs are also highly resistant to photobleaching but have a propensity for blinking. 

The origin of the advantageous PL properties of CdX QDs is quantum confinement, which can be approximated as a particle-in-a-(spherical)-box model. As the size of a semiconductor crystal decreases, fewer of the wavefunctions that describe the electronic states of the bulk material satisfy the size constraints of the nanocrystal.<sup>63</sup> The resultant decrease in the density of states near the conduction and valence band edges yields discrete quantum-confined energy levels.<sup>61,63</sup> As shown in Figure 3E,<sup>84</sup> this effect increases as the nanocrystal size decreases and yields progressive 

24 

increases in the bandgap energy relative to the bulk material. PL arises from exciton recombination across the bandgap, so PL emission shifts to shorter wavelengths as the nanocrystal size decreases.<sup>61,63,69</sup> In turn, the spectrally broad absorption arises from excitation to states away from the band edges. The main contribution to the PL FWHM of an ensemble of QDs is often heterogeneous broadening from non-zero size polydispersity of the QD nanocrystals ( _e.g._ single CdSe linewidths have been measured to be _ca._ 30–80% of that of the ensemble,<sup>85–87</sup> or around 15– 20 nm). 

Quantum confinement effects typically become significant as the crystal diameter approaches and becomes smaller than the exciton Bohr radius ( _i.e._ the electron-hole pair is forced closer together than its preferred distance).<sup>61,63,69</sup> Size-tuning of QD PL is thus based on changing the magnitude of quantum confinement. The range of this tuning is determined by the bulk bandgap energy (2.4, 1.8, and 1.5 eV for CdS, CdSe, and CdTe, respectively)<sup>69,88,89</sup> and exciton Bohr radius (~3, ~5, and ~7 nm),<sup>69,90,91</sup> which are both set by the nanocrystal material. 

Within certain limits, alloyed or ternary semiconductors provide the opportunity to decouple, bandgap energy from core nanocrystal size. For example, CdSe1– _x_ S _x_ nanocrystals can have the same bandgap energy as CdSe QDs, but at a larger size (and, consequently, larger molar absorption coefficient). Conversely, ZnxCd1– _x_ Se nanocrystals will have the same bandgap energy at a smaller size.<sup>92</sup> In both cases, the bandgap increases as the mole fraction _x_ increases. A compositional series of CdSe1– _x_ S _x_ /ZnS QDs has been referred to as “brightness equalized” QDs because of the similar molar absorption coefficients (and QYs) between QDs with different PL emission wavelengths.<sup>93</sup> For comparison, a size series of CdSe/ZnS QDs exhibits an increase in molar absorption coefficient of an order of magnitude or more as PL shifts from green to red.<sup>94,95</sup> 

There are two features of real QDs that deviate from an ideal particle-in-a-box model: a finite potential energy well, which allows some leakage of the exciton wavefunction from the core nanocrystal; and the potential for trap states, energetically within the bandgap and localized at defects, particularly at the surface of the nanocrystal. Both of these properties promote nonradiative relaxation mechanisms and decrease PL QY. Trap states may also yield dim and spectrally broad bandgap PL at wavelengths longer than the desired band edge PL. The addition 

25 

of a shell around the core nanocrystal enhances its PL efficiency by passivating its surface and, if the shell material has a larger bandgap energy than the core material ( _e.g._ ~3.7 eV for ZnS),  better confinement of the exciton.<sup>61,66,69,79</sup> Shell thickness and coverage largely determine the extent to which the PL properties of the core are decoupled from the local environment of the QD, and thus the degree to which ligands or other surface functionalization affect the PL QY. As a physical barrier, the shell also improves resistance to photobleaching and oxidative damage,<sup>61,66–69</sup> and can reduce or suppress blinking, as in the case of “giant shell” CdSe/ZnS QDs.<sup>96</sup> 

Although less common, additional tuning of PL properties ( _e.g._ emission wavelength, lifetime) is possible through bandgap engineering between the core and shell, wherein the materials of each are selected to achieve certain alignments of the band edge states. The most common configuration is a Type I heterostructure ( _e.g._ CdSe/ZnS QDs), where a semiconductor shell has a larger bandgap energy than the core, and an alignment of its band edge states that bound those of the core. The electron and hole wavefunctions of the exciton are thus both preferentially confined to the core. Type II heterostructures have the band edge states of the shell offset in the same energetic direction as the core. The electron and hole wavefunctions of the exciton are preferentially separated between the core and shell, such that radiative recombination occurs across the core-shell interface, resulting in red-shifted PL emission and longer PL lifetimes. Quasi-Type II heterostructures have one band edge state aligned between the core and shell, with the others offset, and increase PL lifetime without a significant change in PL emission wavelength. Several reviews address these concepts in more detail.<sup>61,69,97</sup> 

# _2.4.1.2 Surface Chemistry and Functionalization_ 

The preferred methods for CdX QD synthesis yield materials coated with hydrophobic ligands and further functionalization is necessary for stable aqueous dispersion.<sup>61</sup> The two general methods are encapsulation with amphiphilic polymers (or other amphiphiles) and exchange of the hydrophobic ligands with either small-molecule ligands or ligand-decorated polymers that are bifunctional, having both QD-binding groups ( _e.g._ thiols, imidazoles) and hydrophilic groups ( _e.g._ carboxyl, sulfobetaine, PEG).<sup>61,63,79</sup> These strategies are illustrated in Figure 3B. Silica coating of QDs is also possible but less common.<sup>98–102</sup> The final hydrodynamic size and passivation of the QD differs between strategies, with encapsulation typically retaining higher QYs and small-molecule ligands 

26 

offering smaller size.<sup>61</sup> Ligands have evolved since first use<sup>98,103</sup> for more robust binding to QDs,<sup>104</sup> superior colloidal stability across broad ranges of conditions ( _e.g._ pH, ionic strength),<sup>105,106</sup> minimization of size and non-specific protein adsorption,<sup>105,106</sup> and greater scope of conjugation reactions.<sup>62,104,107</sup> Other reviews offer a more detailed discussion of the surface coatings used to disperse QDs in aqueous media.<sup>63,108–110</sup> 

Strategies for the (bio)conjugation of QDs target either functional groups associated with ligand and polymer coatings ( _e.g._ carboxyl, amine, clickable groups), or the inorganic surface of the QD itself.<sup>61–63,107,111</sup> The latter is applicable with ligands and ligand-like polymer coatings that permit, for example, thiol-terminated or polyhistidine-tagged biomolecules to access and bind to the ZnS shell of a core/shell QD.<sup>61–63,107,111</sup> 

27 



**Figure 3.** CdSe QDs. **(A)** Left: TEM image of an individual CdSe QD. Scale bar is 5 nm. Reproduced from ref.<sup>69</sup> Copyright 2010 American Chemical Society. Right: TEM image of many QDs. Scale bar is 50 nm. **(B)** Two common surface chemistries for QDs: (i) and (ii) depict encapsulation of hydrophobic surfactants with amphiphilic polymers, and (iii)–(v) depict exchange with dithiol ligands. Adapted with permission from ref.<sup>61</sup> Copyright 2012 SAGE Publishing. **(C)** Absorbance and PL emission spectra of CdSe QDs as a function of nanocrystal size. Reproduced from ref.<sup>69</sup> Copyright 2010 American Chemical Society. **(D)** Accessible PL emission wavelengths and energies as a function of QD composition. Reproduced from ref.<sup>62</sup> Copyright 2017 American Chemical Society. **(E)** Cartoon representation of the effect of nanocrystal size and quantum confinement on the bandgap energy of QDs (VB, valence band; CB, conduction band). Reproduced from ref.<sup>84</sup> Copyright 2014 American Chemical Society. 

**2.4.2 IV-VI QDs.** Lead chalcogenide QDs ( _i.e._ PbX, X = S, Se, Te) are narrow bandgap semiconductors that offer NIR emission, tunable via nanocrystal size,<sup>112,113</sup> analogous to cadmium chalcogenide QDs. The synthesis of PbX QDs is typically via hot injection of lead and chalcogen precursors, with methods similar to those used for CdX QDs. Variations of the reaction temperature, the Pb:X ratio, and the synthetic ligands are useful for tuning nanocrystal size, shape, and optical properties.<sup>112,114,115</sup> 

Although the greatest interest in PbX materials is for optoelectronic devices,<sup>97,115,116</sup> the NIR emission is also of potential interest for biological imaging.<sup>112,113</sup> Unfortunately, the cores tend to 

28 

oxidize quickly, so modifications must be made to enhance their stability.<sup>97,116,117</sup> One strategy is to add an inorganic shell of another material ( _e.g._ CdX), either via epitaxial growth or cation exchange, which concurrently enhances the PL properties of the QDs.<sup>112,116</sup> Figure 4A illustrates growth of a CdS shell around a PbS QD.<sup>118</sup> Additional non-epitaxial coatings ( _e.g._ silica, amphiphilic polymer) further passivate the QDs.<sup>117</sup> Figure 4B shows a TEM image of PbS QDs.<sup>119</sup> 

# _2.4.2.1 PL Properties and Mechanism_ 

Analogous to CdX QDs, the origin of PL from PbX QDs is quantum confinement. Aside from the shift of absorption and PL emission into the NIR region, the absorption and PL emission profiles are similar to those of CdX ( _vide supra_ ). Figures 3C and 3D show PL emission and absorption spectra for different sizes of PbS QDs.<sup>120,121</sup> Typical emission ranges are 900–2000 nm and 1000– 2000 nm for PbS and PbSe QDs, respectively (bulk bandgap of 0.4 and 0.3 eV, and exciton Bohr radii of ~20 and ~50 nm).<sup>97,112,119,122,123</sup> Emission in the range 1150–1610 nm has been reported for PbTe QDs, but longer wavelength emission is also expected (bulk bandgap of 0.3 eV and exciton Bohr radius of  ~150 nm).<sup>112,113,119,124,125</sup> PL FWHM are typically 100–200 nm for PbS<sup>116,126–128</sup> and 50–200 nm for PbSe.<sup>116,122</sup> In energy units, these FWHMs are similar to those for CdX QDs. 

PL lifetimes are typically > 1 µs for PbS QDs,<sup>112,127,129–131</sup> and on the order of hundreds of nanoseconds to a few microseconds for PbSe QDs.<sup>119,129,131–135</sup> Hydrophobic PbX QDs have QYs up to ~0.8, depending on the material and synthesis method.<sup>112,116,117,119,120</sup> Transfer of the QDs to water often leads to a large decrease in QY; however, aqueous QDs with QYs of up to 0.3 have been produced.<sup>126</sup> 

# _2.4.2.2 Surface Chemistry and Functionalization_ 

As with CdX QDs, the preferred routes for synthesis of PbX QDs (and core/shell analogs) yield materials with hydrophobic surface chemistry. Hydrophilic functionalization is likewise accomplished via ligand exchange, encapsulation with amphiphiles, or silica coating. Though much less developed, potential conjugation strategies are analogous to those for CdX QDs, targeting either functional groups on these coatings or utilizing direct binding to the inorganic shell. 

29 



**Figure 4.** PbS QDs. **(A)** Illustration of the formation of a CdS shell around a PbS nanocrystal and subsequent ligand exchange for transfer in water. Reproduced with permission from ref.<sup>118</sup> Copyright 2014 Royal Society of Chemistry. **(B)** TEM image PbS QDs. The scale bar is 10 nm. Adapted with permission from ref.<sup>119</sup> Copyright 2012 Royal Society of Chemistry. **(C)** PL emission spectra of PbS QDs of different sizes. Reproduced from ref.<sup>121</sup> Copyright 2014 American Chemical Society. **(D)** Absorbance spectra of PbS QDs of different sizes. Adapted from ref.<sup>120</sup> Copyright 2011 American Chemical Society. Note that the spectra in panels C and D are not for the same batches of materials. 

**2.4.3 III-V QDs.** Type III-V QDs include InP, InAs, GaP, and GaAs QDs. Of these materials, InP QDs have been the most frequently studied since their first colloidal synthesis<sup>136</sup> and have been of the most interest for chemical and biological analysis and imaging. InP QDs are a potential alternative to CdX QDs, with the putative benefit of being heavy metal-free.<sup>137–142</sup> There has also been some interest in InAs core/shell QDs for biological applications,<sup>143,144</sup> although we limit the current discussion to InP QDs. 

As with CdX and PbX, the preferred method for synthesis of InP QDs is hot injection of indium and phosphorous precursors. Initial methods used coordinating alkyl phosphines ( _e.g._ trioctylphosphine oxide) as solvents. More recently, non-coordinating solvents ( _e.g._ octadecene) with fatty acids ( _e.g._ stearic acid), and sometimes alkyl amines ( _e.g._ hexadecylamine), have been 

30 

used to obtain better control over the size distribution of the QDs.<sup>145</sup> InP cores oxidize easily without a shell of another semiconductor material ( _e.g._ ZnS). Figure 5A shows a TEM image of InP/ZnS QDs.<sup>146</sup> 

# _2.4.3.1 PL Properties and Mechanism_ 

The size-dependent, band edge PL emission from quantum confinement in InP QDs spans the visible to NIR region of the spectrum. This range is broader than that of CdX materials because InP has a larger exciton Bohr radius (~10 nm, with a bulk bandgap of 1.35 eV).<sup>147</sup> 

The absorption and PL spectra of InP QDs are qualitatively similar to those for CdX QDs, but absorption peaks are less well-defined and PL FWHMs are typically > 35 nm. Figure 5B shows absorption spectra for different sizes of InP QD, and Figure 5C shows the absorption and PL emission spectra for an InP QDs before and after growth of a ZnS shell.<sup>142</sup> Relative to CdX QDs, the broader PL FWHM for InP QDs has been attributed to a wider size distribution inherent to the synthesis of InP QDs, a steeper correlation between bandgap energy and nanocrystal size, and efficient radiative relaxation from the conduction band edge to structural defect-related states.<sup>138,148,149</sup> Similar to CdX QDs, weak, broad, and generally undesired NIR emission can also arise from defect state-associated exciton recombination within the bandgap, albeit that recent work has looked at enhancing and harnessing this emission for bioimaging.<sup>150</sup> 

The PL QY of InP cores is generally low (< 0.01) compared to CdX QDs because of less effective passivation of surface defects.<sup>137–139,142,145,147,148,151–153</sup> One method for enhancing PL is photoassisted etching of the surface with hydrofluoric acid, which can increase the PL QY to 0.3– 0.4.<sup>139,145</sup> An alternative method is surface passivation with an epitaxial shell of larger bandgap material, such as ZnSe or ZnS, to form a Type I heterostructure.<sup>137–141,145,147,148,151,152,154,155</sup> The resulting materials can have PL QYs greater than 0.5, with one recent example achieving a QY of 0.6 after transfer into aqueous media.<sup>145,152</sup> 

# _2.4.3.2 Surface Chemistry and Functionalization_ 

Analogous to CdX and PbX QDs, as-synthesized InP QDs (and core/shell analogs) are coated with hydrophobic ligands. For dispersion in aqueous media, InP/ZnS QDs are functionalized through 

31 

ligand exchange with bifunctional small-molecule ligands ( _e.g._ thiol binding groups, carboxylate or PEG hydrophilic groups)<sup>140,146,152,153,155–157</sup> or encapsulation by amphiphilic polymers or lipids.<sup>141,150,158</sup> Conjugation strategies target distal functional groups on these coatings, and, in principle, utilize direct binding to a ZnS shell. 



**Figure 5.** InP QDs. **(A)** TEM image of InP/ZnS QDs. The scale bar is 20 nm. The inset shows a highresolution TEM image of an individual InP QD. The scale bar is 2 nm. Reproduced from ref.<sup>146</sup> <mark>Published by The Royal Society of Chemistry (licensed under a Creative Commons Attribution 3.0 Unported License).</mark> **(B)** Absorption spectra of different sizes of InP QDs (measured at different growth times). **(C)** Absorption and PL emission spectra of 2.3 nm diameter InP QDs before (dashed black line, green line) and after growth of a ZnS shell (red line, blue line). Panels B and C are adapted from ref.<sup>142</sup> Copyright 2008 American Chemical Society. 

**2.4.4 I-III-VI and I-VI QDs.** Similar to InP QDs, I-III-VI and I-VI semiconductor QD materials are of interest as alternatives to CdX and PbX. 

Examples of I-III-VI semiconductor QDs include CuInS2 (CIS), CuInSe2 (CISe), and AgInS2 (AIS) QDs, amongst which CIS QDs are the most studied. As with CdX QDs, ternary I-III-VI semiconductor QDs are typically synthesized via hot injection of precusors, although some aqueous synthetic methods have been developed.<sup>139,145,159,160</sup> Alternative methods utilize the thermal decomposition of single source precursors.<sup>159–164</sup> Alloying or doping with other elements ( _e.g._ Zn) to modify electronic and optical properties, or add other functionality ( _e.g._ magnetic properties), is also possible.<sup>162,164–167</sup> Figure 6A shows a TEM image of CIS QDs.<sup>168</sup> 

32 

Ag2S, Ag2Se, and Ag2Te QDs are the most prominent examples of I-VI semiconductor QDs, with Ag2S and Ag2Se QDs being of greatest interest for biological applications.<sup>169</sup> Figure 7A shows TEM images of various sizes of Ag2S QD.<sup>170</sup> As QDs, these materials are still nascent. Current synthetic methods, whether organic or aqueous phase, still require optimization for good control of size, obtaining high PL QYs, and routine and effective epitaxial shelling ( _e.g._ with ZnS).<sup>112,171</sup> 

# _2.4.4.1 PL Properties and Mechanism_ 

Good quality I-III-VI semiconductor QDs exhibit PL that arises from quantum confinement and is size- and composition-tunable across the visible-NIR range.<sup>138,139,160,162–165,172,173</sup> Figure 6B shows absorption and PL emission spectra for different compositions of CIS/ZnS QDs synthesized via an aqueous method.<sup>174</sup> Figure 6C illustrates the concept of tuning CIS QD bandgap energy through both size and composition.<sup>172</sup> (The concept is applicable to other alloyed QD materials as well.) 

CIS QDs have good molar absorption coefficients (~10<sup>5</sup> –10<sup>6</sup> M<sup>–1</sup> cm<sup>–1</sup> ),<sup>175</sup> broad but mostly featureless absorption spectra ( _i.e._ shoulder rather than sharp excitonic peak), broad PL emission with FWHMs of ~100 nm, spectral distances of > 100 nm between the absorption shoulder and peak PL emission, and PL lifetimes on the order of 10<sup>2</sup> ns.<sup>137,138,159,160,163,165,172,173,176</sup> The featureless absorption and broad PL emission may be due to intrinsic electronic properties of CIS and/or inhomogeneity in nanocrystal size, shape, or composition. Tailing of PL emission at longer wavelengths is often observed, which may be associated with intraband states of CIS.<sup>138,160</sup> The difference in PL properties between I-III-VI semiconductor QDs and CdX QDs suggests potential for a different mechanism of PL emission. The PL mechanism is still a topic of active research, but it is widely accepted that intrinsic defects associated with the more complex QD structure (resulting from the non-stoichiometry of the crystal structure) are involved in generating PL with the involvement of intragap states.<sup>159,160,162,164,172,176</sup> Similar to other non-cadmium QD materials, CIS QDs exhibit QYs that are low (< 0.1) without any surface passivation, but increase significantly (> 0.5) with a ZnS shell.<sup>137,165,173</sup> Interestingly, the addition of a ZnS shell has been found to blue-shift the PL emission, likely from an alloying or cation exchange process.<sup>137,138,159,160,165,172,173</sup> (For comparison, epixtaxial growth of a shell red-shifts the PL of many Type I heterostructure QD materials ( _e.g._ CdX/ZnS) because leakage of the exciton wavefunction into the shell decreases quantum confinement.) 

33 

As I-VI materials, Ag2S and Ag2Se, and Ag2Te QDs exhibit size-tunable PL emission between ~500–1200 nm (bulk bandgaps of ~1 eV for Ag2S and ~0.2 eV for Ag2Se).<sup>112,113,169,171</sup> However, due to the very small Bohr radius of Ag2S (2.2 nm), it has been shown that QDs larger than 4–5 nm no longer have strongly size-tunable emission.<sup>112,137,170,171,177</sup> Ag2X QDs have PL emission with FWHM of 75–300 nm, relatively low PL QYs (< 0.3), broad but largely featureless absorption spectra, and PL lifetimes on the order of 10<sup>1</sup> –10<sup>2</sup> ns.<sup>112,113,177,178</sup> Figure 7B shows absorption and PL emission spectra, as well as photographs, of Ag2X QDs of different sizes.<sup>170</sup> 

# _2.4.4.2 Surface Chemistry and Functionalization_ 

As with other QD materials, ligand exchange or encapsulation methods are used to render I-III-VI semiconductor QDs dispersible in water,<sup>138,160,164,172</sup> and the functional groups on the coatings are targets for (bio)conjugation reactions. Examples of conjugation are limited to date, but it is anticipated that methods will be similar to those for other semiconductor QD materials. 



**Figure 6.** CIS QDs. **(A)** TEM images of CIS QDs. The scale bar is 50 nm. Adapted from ref.<sup>168</sup> Copyright 2009 American Chemical Society. **(B)** UV-vis absorption and PL emission spectra for CIS QDs synthesized with different Cu/In ratios. Reproduced from ref.<sup>174</sup> Copyright 2013 American Chemical Society. **(C)** Illustration of the compositional strategy for tuning the bandgap energy of CIS QDs. Reproduced from ref.<sup>172</sup> Copyright 2012 American Chemical Society. 

34 



**Figure 7.** Ag2S QDs. **(A)** TEM images of different sizes of Ag2S QDs. The scale bar is 20 nm. Corresponding **(B)** absorption spectra and **(C)** PL emission spectra for the same batches of Ag2S QDs. Figure adapted from ref.<sup>170</sup> Copyright 2014 American Chemical Society. 

**2.4.5 IV QDs.** Silicon QDs are more often called silicon nanocrystals (Si NCs), often with good reason ( _vide infra_ ). These materials comprise a crystalline silicon core with a layer of functionalization on its surface, and have typical dimensions of 1.5–10 nm.<sup>179–182</sup> Figure 8A shows TEM images of three sizes of Si QDs.<sup>183</sup> Germanium nanocrystals (Ge NCs) are, in many ways, analogous materials to Si NCs,<sup>182,184</sup> but are less developed and applied, so we limit this section to Si NCs. 

Common methods for the synthesis of Si NCs include the reduction of silicon halides ( _e.g._ SiCl4), reduction of metal silicides ( _e.g._ MgSi), and the thermal decomposition of organosilanes and silicon oxides ( _e.g._ silsesquioxane).<sup>179–183</sup> The resulting Si NCs are typically hydride-, halide-, or oxide- terminated, where the latter tend to be further etched to hydride-terminated Si NCs. Hydride- and halide-terminated NCs are sensitive to oxygen and moisture, such that surface passivation and stabilization is required to preserve the structure and properties of the materials.<sup>180–</sup> 182 In contrast to the aforementioned varieties of QDs, the growth of a shell of inorganic semiconductor ( _e.g._ CdS)<sup>185</sup> around Si NCs has been, to date, largely ineffective, impractical, and uncommon. Instead, the surface is covalently modified with organic molecules. For hydrideterminated Si NCs, the preferred surface-passivation reactions are hydrosilylation, as illustrated in Figure 8B,<sup>183</sup> whereas for halide-terminated Si NCs, the preferred reactions are those with Grignard and alkyl lithium reagents, yielding Si-C bonds in all cases.<sup>180,181,186</sup> Other reactions that 

35 

introduce Si-O and Si-N bonds ( _e.g._ reaction of amines with halide-terminated Si NC) are also possible; however, these reactions often modify PL properties.<sup>180,181</sup> 

# _2.4.5.1 PL Properties and Mechanism_ 

Some Si NCs are aptly described as “Si QDs” because PL emission arises from quantum confinement. These materials tend to be ~5 nm or less in diameter, as the exciton Bohr radius for Si is _ca._ 4.5 nm.<sup>179,180,182</sup> Larger Si NCs have weak quantum confinement and thus exhibit NIR PL, or visible PL by other mechanisms ( _e.g._ defect states). As an interesting aside, germanium has an exciton Bohr radius of 24.5 nm,<sup>182</sup> and, in principle, would afford one of the largest size-ranges of QDs among materials noted in this review. 

Analogous to other materials, PL from quantum confinement shifts to shorter wavelengths as nanocrystal size decreases. For Si QDs, the practical size-tuning range has, to date, been from green/yellow to NIR PL emission ( _ca._ 500–1000 nm). FWHMs for ensemble PL spectra are 100– 200 nm and QYs are as high as 0.7.<sup>179–181</sup> Figure 8C shows PL emisison spectra for three sizes of Si QDs.<sup>183</sup> As silicon is an indirect bandgap material (electronic transitions must be phononassisted), the exciton is slower to recombine than in direct bandgap materials ( _e.g._ CdSe) and PL lifetimes are on the order of microseconds. These quantum-confined PL properties are most frequently obtained with Si NCs synthesized at higher temperatures (> 160 ºC).<sup>180</sup> Another consequence of the indirect bandgap is weaker light absorption by Si NCs compared to direct bandgap QD materials, where estimates of molar extinction coefficients are 10<sup>4</sup> –10<sup>5</sup> M<sup>–1</sup> cm<sup>–1</sup> . 187,188 Absorption spectra are relatively featureless but likewise increase in intensity from the bandgap energy toward the UV. 

In other cases, Si NCs exhibit PL emission from surface or other defect states. This PL generally ranges from the UV through blue/green, has lifetimes on the order of 1–10 ns, and QYs of 0.1– 0.3.<sup>180</sup> Lower temperature syntheses (< 160 ºC) more frequently produce Si NCs with such PL characteristics, as do certain surface modifications, particularly those that yield Si-N and Si-O bonds.<sup>180</sup> The PL mechanism and properties ( _e.g._ QYs, lifetimes) of Si NCs can have a nonmonotonic relationship with surface area-to-volume ratio, and thus Si NC size, because of the competing effects of quantum confinement and the magnitude of influence from surface states.<sup>186</sup> 

36 

The latter includes both radiative and non-radiative relaxation pathways associated with surface states. 

# _2.4.5.2 Surface Chemistry and Functionalization_ 

The selection of surface chemistry for Si NCs is, on one hand, driven by the need to passivate the nanocrystal surface and retain the desired PL properties. On the other hand, it is driven by requirements for colloidal stability and downstream (bio)conjugation reactions. The most common functionalization strategies use bifunctional reagents or mixtures of bifunctional reagents with hydride-terminated Si NCs.<sup>189–191</sup> One functionality is an alkene or alkyne group for hydrosilylation, and the other (usually distal) functionality is either polar ( _e.g._ PEG) or suitable for further functionalization or conjugation reactions ( _e.g._ alkene, carboxyl, amine). There are indications that the density of the distal functional group can affect PL properties.<sup>192–194</sup> 

# **2.5 Nanoscale Colloidal Carbon Allotropes.** There are several photoluminescent nanomaterials 

based on carbon. For the purpose of this review, we divide nanoscale colloidal carbon allotrope materials into carbon nanotubes (CNTs), graphene-derived materials, carbon (quantum) dots, and nanodiamonds. We acknowledge that CNTs are conceptually derived from graphene, but make the distinction because, in practice, CNTs are not obtained experimentally from graphene or graphite. Readers should note that there is variation in the nomenclature and classification of colloidal carbon allotropes across the literature. CNTs and nanodiamonds notwithstanding, the variation in nomenclature and categorization arises, in large part, from challenging structural characterization of some carbon materials, inherently heterogeneous samples of materials, and evidence for PL from multiple mechanistic origins ( _vide infra_ ).<sup>195,196</sup> The heterogeneity of many preparations of nanoscale colloidal carbon allotrope materials also mean that their apparent properties and behaviour may have strong dependences on the specific synthetic approaches, purification methods, and the material sub-populations present. 

37 



**Figure 8.** Si QDs. **(A)** TEM images of three sizes of Si QDs. **(B)** Functionalization of hydride-terminated Si QDs with dodecane via hydrosilylation methods. **(C)** PL emission spectra for the three sizes of Si QD from panel A. Panels reproduced from ref.<sup>183</sup> Copyright 2017 American Chemical Society. 

**2.5.1 Carbon Nanotubes.** Single-walled carbon nanotubes (SWCNTs) are quasi-one-dimensional materials that conceptually arise from rolling up a section of a graphene sheet into a tube. SWCNTs typically have diameters between 0.4–2 nm (but potentially up to 7 nm) and a very broad range of lengths (nanometers to micrometers).<sup>197,198</sup> As shown in Figure 9A,<sup>199</sup> the direction in which the graphene is rolled up determines the chirality of the SWCNT and is indicated by either two vectors ( _n_ , _m_ ) that lie in the plane of its hexagonal lattice, or, equivalently, the combination of roll-up angle (0–30º) and nanotube diameter.<sup>195,197,198,200</sup> This chirality determines whether a SWCNT is metallic ( _n_ – _m =_ 0), semi-metallic ( _n_ – _m_ = 3 _p_ , where _p_ is an integer), or semiconducting ( _n_ – _m_ ≠ 3 _p_ ).<sup>197</sup> Multi-walled carbon nanotubes (MWCNTs) are collections of concentrically nested 

38 

SWCNTs, with inter-wall spacing of approximately 0.34 nm (similar to the graphite interplane distance), and diameters from a few nanometers up to many tens of nanometers depending on the number of concentric tubes.<sup>195</sup> Figure 9B shows an example of a TEM image of a SWCNT.<sup>201</sup> 

SWCNTs can be prepared by a variety of methods, including arc discharge with a graphite electrode and powdered carbon precursor, laser ablation of a powdered mixture of graphite and a catalytic metal, chemical vapor deposition (CVD) with suitable catalysts, and other less common methods. Relative to one another, these general methods have advantages and disadvantages with respect to technical requirements and scalability, quality and purity of the CNTs obtained, and level of control over nanotube diameter, length, and chirality. Other reviews address the synthesis of SWCNTs in more detail, and highlight the push toward controlled synthesis of SWCNTs of defined chirality.<sup>198,202–206</sup> Many current analytical applications use SWCNTs synthesized by the high-pressure carbon monoxide (HiPCO) method, and, to a lesser degree, the cobalt and molybdenum catalysis (CoMoCat) method. Purification of SWCNTs and isolation or enrichment of specific chiralities are ongoing areas of development and utilize separation methods such as ultracentrifugation, electrophoresis, size-exclusion chromatography, polymer-assisted isolation, and aqueous two-phase extraction, as reviewed elsewhere.<sup>207</sup> 

# _2.5.1.1 PL Properties and Mechanism_ 

Only semiconducting SWCNTs are photoluminescent, and only when isolated from one another.<sup>195,197</sup> Figure 9C shows PL excitation-emission matrices for selected chiralities of SWCNT.<sup>208</sup> PL tends to be quenched in bundles of SWCNTs, and non-photoluminescent metallic and semi-metallic SWCNTs will quench PL from semiconducting SWCNTs within the same MWCNT.<sup>195</sup> The electronic density of states for CNTs features sharp peaks called van Hove singularities, and transitions between these singularities on opposite sides of the Fermi level largely determine the PL properties of CNTs.<sup>197</sup> The intrinsic PL of semiconducting SWCNTs is excitonic in origin, arising from recombination of the exciton between the band edge singularities, with some dependence on the diameter of the nanotube.<sup>195,197</sup> 

Light absorption by SWCNTs arises from multiple transitions between van Hove singularities across the bandgap (denoted S11, S22, S33, see Figure 9D; crossovers such as S12 are forbidden).<sup>200</sup> 

39 

