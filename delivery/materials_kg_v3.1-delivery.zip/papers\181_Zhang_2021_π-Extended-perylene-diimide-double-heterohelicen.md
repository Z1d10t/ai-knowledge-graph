# π-Extended perylene diimide double-heterohelicenes as ambipolar organic semiconductors for broadband circularly polarized light detection

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 170 |
| 作者 | Li Zhang, Inho Song, Jaeyong Ahn, Myeonggeun Han, M. Linares, M. Surin, Hui-Jun Zhang, J. Oh et al. |
| DOI | 10.1038/s41467-020-20390-y |
| 源文件 | 081_Zhang_2021_π-Extended-perylene-diimide-double-heterohelicen.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-020-20390-y **OPEN** 

# π-Extended perylene diimide doubleheterohelicenes as ambipolar organic semiconductors for broadband circularly polarized light detection 

Li Zhang<sup>1,6</sup> , Inho Song<sup>2,6</sup> , Jaeyong Ahn<sup>2</sup> , Myeonggeun Han<sup>3</sup> , Mathieu Linares 4, Mathieu Surin 5, Hui-Jun Zhang 1, Joon Hak Oh 2✉ & Jianbin Lin 1✉ 

Despite great challenges, the development of new molecular structures with multiple and even conflicting characteristics are eagerly pursued for exploring advanced applications. To develop high-performance chiral organic semiconducting molecules, a distorted π-system is required for strong coupling with circularly polarized light (CPL), whereas planar π-stacking systems are necessary for high charge-carrier mobility. To address this dilemma, in this work, we introduce a skeleton merging approach through distortion of a perylene diimide (PDI) core with four fused heteroaromatics to form an ortho-π-extended PDI double-[7]heterohelicene. PDI double helicene inherits a high dissymmetry factor from the helicene skeleton, and the extended π-planar system concurrently maintains a high level of charge transport properties. In addition, ortho-π-extension of the PDI skeleton brings about near-infrared (NIR) light absorption and ambipolar charge transport abilities, endowing the corresponding organic phototransistors with high photoresponsivity of 450 and 120 mA W<sup>−1</sup> in p- and n-type modes respectively, along with a high external quantum efficiency (89%) under NIR light irradiations. Remarkably, these multiple characteristics enable high-performance broadband CPL detections up to NIR spectral region with chiral organic semiconductors. 

> 1 Department of Chemistry, College of Chemistry and Chemical Engineering, MOE Key Laboratory of Spectrochemical Analysis and Instrumentation, Xiamen University, Xiamen 361005, China.<sup>2</sup> School of Chemical and Biological Engineering, Institute of Chemical Processes, Seoul National University, 1 Gwanak-ro, Gwanak-gu, Seoul 08826, Korea.<sup>3</sup> Department of Chemical Engineering, Pohang University of Science and Technology (POSTECH), Gyeongbuk, Pohang 37673, Korea.<sup>4</sup> Laboratory of Organic Electronics and Scientific Visualization Group, ITN, Campus Norrköping; Swedish e-Science Research Centre (SeRC), Linköping University, Linköping SE-581 83, Sweden.<sup>5</sup> Laboratory for Chemistry of Novel Materials, Centre of Innovation and Research in Materials and Polymers (CIRMAP), University of Mons – UMONS, 20 Place du Parc, Mons B-7000, Belgium.<sup>6</sup> These authors contributed equally: Li Zhang, Inho Song. ✉email: joonhoh@snu.ac.kr; jb.lin@xmu.edu.cn 

1 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 

he bright future of organic semiconducting materials hinges upon the rational design at the molecular and supraTmolecular levels, which can be directly reflected by their diverse optoelectronic properties and morphologies<sup>1,2</sup> . A driving role in this setting falls on multiple and sometimes conflicting requirements that have to be fulfilled simultaneously on molecular designs. In recent years, distinctive chiroptical properties arising from interactions of chiral chromophores with electromagnetic fields have led to a growing recognition that active chiral components would provide additional functions in optoelectronic devices<sup>3,4</sup> . However, the search for chiral organic semiconductors is still at a very early stage, because principles for design of chiral chromophores with highly-efficient absorption of circularly polarized light (CPL) have been in conflict with the requirements for improved charge transport properties. 

As a typical example of chiral π-systems, helicenes have a large chiral pitch matching a specific handedness of CPL, which can largely enhance the light–matter interactions<sup>5</sup> . As a result, helicenes exhibits excellent chiroptical performances, such as high circularly polarized absorption and luminescence values<sup>6–16</sup> . Unfortunately, the exploration of their electronic properties has been held back on account of the weak electron delocalization in small π-planes and the loose molecular packing in solid state caused by the strongly distorted screw-shaped aromatic rings. In 2013, Campbell and co-workers<sup>17</sup> reported the first CPL detection by a chiral organic semiconductor phototransistor employing chiral helicene as an active layer. A specific photoresponse to CPL was achieved albeit at the expense of rather low charge-carrier mobility (~10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) and photoresponsivity (quantum efficiency ~ 0.1%). Notably, due to the disturbed π-conjugation, helicenes generally show chiroptical properties in only UV and near blue part of the visible light spectrum (<400 nm), which prevents advanced applications based on near-infrared (NIR) light absorption. In contrast, as an important class of organic dyes, perylene diimides (PDIs) have received great attention for applications as organic optoelectronics due to their unique features such as high charge-carrier mobilities, favorable electron affinities, air stability, and facile molecular design<sup>18–20</sup> . Recently, even several PDI-based helical ribbons<sup>21,22</sup> and other twisted structures<sup>23,24</sup> with high chargecarrier mobilities were reported. In 2017, we employed a supramolecular assembly of PDIs possessing chiral side groups for chiroptical sensing<sup>25</sup> . This system exhibited a broad UV–vis absorption range (<~600 nm) and high photoresponsivity, but very poor CPL selectivity owing to the chirality in the side chains that provides only weak perturbations to the electronic transitions of the main chromophores. 

Herein, we introduce a skeleton merging approach to combine both helicene and PDI to afford ortho-π-extended PDI double-[7] heterohelicenes, which encompass the high chiroptical and electronic properties from both parent skeletons and offer new properties such as NIR light absorption and ambipolar chargecarrier transport properties (Fig. 1a). The corresponding organic phototransistor exhibits comparable external quantum efficiency (EQE) among thin-film-based organic CPL detectors reported to date<sup>17,26,27</sup> . Especially, its photoresponsivity is even superior to the reported chiral NIR light detectors based on silicon and chiral plasmonic-patterned electrodes<sup>28</sup> . The ortho-π-extended PDI double-heterohelicene allows CPL detection using chiral organic semiconductors at NIR spectral region for the first time, together with excellent thermal stability. This broadband CPL detection could provide unprecedented opportunities in optoelectronics, by introducing a new functionality to various prospective applications, including motion detection, remote sensing, health monitoring, photoplethysmogram sensor, spectrometric analysis, and night vision. 

### Results 

Design and synthesis. Twisting of the PDI core engendered by steric repulsion between the encumbered bay-substituents leads to the occurrence of atrop-enantiomers (P- and M-enantiomers). However, despite significant distortion in these bay-substituted<sup>29</sup> and ortho-fused<sup>30,31</sup> PDI systems, a fast interconversion process between the P- and M-enantiomers prevents the isolation of enantiopure derivatives for further applications. As the activation parameters for conformational chiral systems are influenced by the size of the substituents, we speculated that annulation of four indole/benzothiophene rings to perylene skeleton with heteroatom at ortho-position should lead to conformationally stable double-[7]heterohelicene 3a (X = NH) and 3b (X = S) with overlapping terminal aromatic rings (Fig. 1a). The rigidity of the π-skeleton can be further enhanced via the hydrogen bonds<sup>32</sup> and chalcogen bonds<sup>33</sup> . The incorporation of heteroatoms in helicenes would offer the possibility to tune their band gap. Additionally, the donor (heteroaromatics)–acceptor (PDI) fused architecture might show ambipolar charge transport properties, which would improve the performance of electronic circuits. 

We began our studies by evaluating the isomerization process from P-/M-enantiomers to the meso-conformer through a proposed transition state by DFT calculations (using 6–31 + G (d) basis set with the ωB97Xd<sup>34</sup> functional to include dispersion corrections). The P-/M-enantiomers of 3a, 3b bearing methyl substituents at imide positions are more stable than their mesoforms by 12.6 and 13.1 kcal mol<sup>−1</sup> , respectively (Fig. 1b and Supplementary Fig. 1). Accordingly, the isomerization barriers were estimated to be 62.9 and 65.2 kcal mol<sup>−1</sup> , respectively, which are notably high enough for further separation by chiral highperformance liquid chromatography (HPLC). 

Encouraged by this result, we have synthesized 3a on the basis of ortho-mono-indole fused PDI 3a′ with a twist angle of 24°, which were prepared using a mild and regioselective Rh(III)catalyzed method (Supplementary Fig. 2)<sup>35</sup> . Before this work, we have noticed that two related compounds have already been synthesized by Wang and co-workers<sup>36</sup> with tetrabromotetrachloro-perylene-3,4:9,10-tetracarboxylic acid dianhydride (Br4Cl4PTCDA). However, the harsh reaction conditions and tedious synthetic procedures involving Br4Cl4-PTCDA constrained further explorations of their chiral properties. As depicted in Fig. 1c, in our case, through nucleophilic aromatic substitution reactions of 1, intermediate 2a was produced in 81% yield. After optimizing palladium-catalyzed intramolecular C–H activation conditions, tetraindole-fused PDI 3a could be obtained with a 51% yield when 2a was treated with Pd(OAc)2 catalyst. Due to its twisted structure, 3a displays enhanced solubility in common organic solvents, such as dichloromethane (DCM), chloroform, and tetrahydrofuran. In NMR measurements, the aromatic protons assigned to the indole of 3a are significantly shifted upfield compared to 3a′, reflecting the π-overlap at the terminal rings of 3a. 

Photophysical property characterization. By using chiral HPLC, the two enantiomers of 3a could be completely separated (47% 3a-P, 50% 3a-M). Their optophysical properties were studied by absorption and CD spectroscopy (Fig. 2). Compared to 1, the substantial red shifts (~100 nm, Supplementary Fig. 4) of 3a′ indicate an effective expansion of the π systems even with one fused heteroaromatic ring. The introduction of four fused rings induced a further bathochromic shift to NIR with a maximum of 3a at 737 nm (Fig. 2a). The enantiomers were subsequently characterized by CD spectroscopy, which displays a perfect mirror image of the enantiomers (Fig. 2b). It is noteworthy that the CD signal reaches the NIR region (~780 nm). High 

2 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 



<!-- Start of picture text -->
a R b<br>O N O<br>X X<br>62.9 62.9<br>[7]heterohelicene TS TS<br>merge<br>chiral skeleton<br>O O<br>X X<br>N N<br>O N O<br>O O R<br>semiconducting skeleton PDI :  n-type ortho- double-[7]heterohelicene  -extended-PDI III  12.6 3a- meso<br>X = NH ( 3a ), S ( 3b ) 0.0 0.0<br>c 3a- P 3a- M<br>R<br>R R R<br>O N O O N O O N O O N O<br>I I HN HN HN HN HN HN<br>2-bromoaniline Pd(OAc) 2, P t Bu3 HBF4<br>t BuOK Br Br Cs 2CO3,DMF<br>Br Br<br>120  o C, 24 h 150  o C, 24 h<br>I I NH NH NH NH NH NH<br>O N O R = hexylheptyl O N O O N O O N O<br>R<br>R R R<br>1 2a 3a- P 3a- M<br>(kcal/mol)∆G<br><!-- End of picture text -->

Fig. 1 Molecule design and synthesis. a Schematic representation of the skeleton merging approach. b Potential energy surface of the isomerization process between 3a-P/M and 3a-meso conformations, calculated by DFT calculations at the ωB97Xd/6–31+G(d) level (hexylheptyl groups have been replaced by methyl groups to simplify the calculations, carbon = black, hydrogen = white, nitrogen = blue, oxygen = red). c Synthesis of tetraindole-fused PDIs 3a. 



Fig. 2 Photophysical property characterization. a Absorption and b CD spectrum/dissymmetry factor (gabs) of 3a (10 μM in chloroform, solid line: CD, dashed line: gabs). 

dissymmetry in the PDI double helicene is as expected, and the gabs factor of 3a (628 nm: 0.014) is higher than that for a classical hexahelicene (0.009)<sup>16</sup> . More importantly, 3a still shows high gabs factor even above a wavelength of 700 nm, which enables its application in advanced chiroptical devices. Excitonic couplet at about 309 nm for 3a can be attributed to the excitonic interaction of the two twisted π-extended naphthalene imide units of the PDI core. For a more reliable configurational assignment of the enantiomers, TD-DFT calculations were performed to calculate the CD spectra. The signs of the calculated CD bands clearly point to the assignment of (+/−) signals at low energy for 3a-P 

enantiomer, and (−/+) signals for 3a-M enantiomer (Supplementary Fig. 6). Note that the first band at low energy can be attributed to the deformation of the PDI core of the molecule from a planar conformation with a twist of +33.6° and −33.6° for the P and M conformers, respectively (Supplementary Fig. 7). In addition, the diphenyl ether solution of 3a-P was heated at different temperatures and the isomerization was not observed even heated up to 523 K for 2 h (Supplementary Fig. 8), suggesting the remarkable conformational stability of 3a-P/M as predicted by the DFT calculation. From cyclic voltammetry measurements of 3a in DCM solutions (Supplementary Table 1), the corresponding HOMO/LUMO energy levels are estimated as −5.31/−3.75 eV. Based on the HOMO/LUMO energy levels, and the small band gap (1.56 eV), 3a should favor balanced ambipolar charge injection and CPL detection in the NIR range (see below). 

Morphological and chiroptical study of thin films. To elucidate molecular packing characteristics in terms of morphology in the aggregated solid films, we investigated the morphologies of 3a-P thin films fabricated by a thermal evaporation process. Forty-nmthick PDI derivatives thin films were thermally evaporated onto n-octadecyltrimethoxysilane (OTS)-modified SiO2/Si substrates under high vacuum (~10<sup>−6</sup> Torr) at different substrate temperatures (Ts). Scanning electron microscope (SEM) analysis on the 3a-P solid films displayed dense granular crystalline domains, when the 3a-P molecules were solidified at an optimized Ts of 140 °C (Supplementary Fig. 9a). However, SEM measurement could not distinguish the morphology of 3a-P solid films prepared at a Ts of room temperature (RT), because of their very smooth and small domains (Supplementary Fig. 9b). To further investigate the grains at the nanoscale, atomic force microscopy (AFM) analysis was conducted. Figure 3a presents the height images (2 × 2 µm<sup>2</sup> scan) of the 3a-P thin films prepared at 

3 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 





Fig. 3 Morphological chiroptical study of thin film. a AFM topography images of 3a-P films deposited at a substrate temperature of RT (top) and 140 °C (bottom). b Thickness normalized ellipticity of 3a thin films deposited at 140 °C. c Thickness normalized ellipticity values at 635 nm for 3a-P/M thin films prepared at different substrate temperature conditions. Error bars mean standard deviations. d Thickness normalized ellipticity of 3a-P/M thin films deposited at 140 °C after sample flipping (back side) and sample rotation. Solid and dotted lines mean 3a-P and 3a-M, respectively. e Estimated gabs value of 3a-P/M thin films evaporated at 140 °C. Circles and triangles mean gabs values at 740 and 635 nm, respectively. 

different Ts. AFM analysis revealed that the optimally evaporated thin films at 140 °C consisted of dense granular grains, which are large (~100 nm) and well-connected each other (Fig. 3a, bottom), as shown in the aforementioned SEM results. However, the grain size decreased as the 3a-P molecules were solidified on the substrate at RT condition (Fig. 3a, top, 80 °C in Supplementary Fig. 10b). Although they showed dense, granular morphology similar to those prepared at higher Ts, the films displayed smaller domains of 10–30 nm. The much larger domains in solid films prepared at the optimal Ts originated from the efficient diffusion of chiral molecules on the substrate and a dominant aggregation process, which plays a key role in determining the electrical properties such as a field-effect mobility of organic thin-film transistors. In addition, we also observed that too high substrate temperature process (i.e., above 200 °C) causes an island-type aggregation, leading to absence of continuity in the channel and therefore very limited charge transport (Supplementary Fig. 10d). 

CD spectroscopy was used to further investigate the chiroptical properties of the thin films of 3a (Fig. 3b). Interestingly, we observed similar CD spectra to the monomer state in solution, with slightly red-shifted sharp peaks. These similar properties indicate that the thin films showed the molecular chirality rather than supramolecular chirality with the intermolecular exciton coupling in the aggregated state. Indeed, we confirmed the aggregated thin films retained the vibrational progression of monomer state from UV–vis measurement (Supplementary Fig. 11), which is a typical phenomenon found in loosely packed PDI molecules with a weak intermolecular interaction in solid state<sup>37</sup> . 

In addition, we confirmed the temperature-dependent CD behaviors of the evaporated thin films on the substrate (Fig. 3c). Unlike the morphological trend (grain size), the ellipticity was 

almost constant irrespective of the substrate temperature, except the island-type thin films prepared at a very high temperature (200 °C). To study the molecular packing and crystallinity in aggregated state, the 3a thin films were investigated using the outof-plane X-ray diffraction (XRD; Supplementary Fig. 12). 3a thin films did not exhibit any diffraction peaks except the peaks from SiO2 as substrate regardless of the chiral composition of organic molecules or evaporated conditions, leading to the absence of anisotropic orientation. AFM and XRD analyses both revealed almost no preferred orientation of 3a molecules in thin films. Unlike strong intermolecular orientation of PDI semiconductors using π–π stacking<sup>38–42</sup> , 3a thin films exhibited completely circular or spherical grains, not rod type ones, which indicates their weak intermolecular interactions in the aggregated states, related to loosely, isotropic molecular packing. 

Furthermore, we tried to measure CD spectra by considering the azimuthal sample rotation and sample flipping for the investigation on the origin of the CD effect in our solid system and the precise estimation of dissymmetry g-factor for thin films in the conventional CD measurements. Indeed, the strong linear dichroism/birefringence and their synergistic effect can strongly affect CD results. In aggregated solid state, the preferential molecular ordering and anisotropic crystalline nature generate the cross term between the linear dichroism and birefringence, leading to significant contribution to the CD signal<sup>43</sup> . First, we checked that thin films of 3a do not have any locally anisotropic and linearly birefringent domains by observing microscope images with crossed linear polarizers (Supplementary Fig. 13). We noticed that there are no birefringent domains on a black background. In addition, we observed the CD spectra of the evaporated thin films by rotating the azimuthal angle of the mounted sample around the optical axis of the incident light to 

4 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 

remove artificial CD based on the macroscopic anisotropic effect of the sample. Figure 3d and Supplementary Fig. 14 display almost negligible difference in the CD spectra, which indicates the absence of macroscopic structural ordering or any preferential orientation in parallel to the glass surface, in line with the XRD results. In addition, we tested the CD spectra by flipping the sample by 180° with respect to the vertical axis<sup>43</sup> . We confirmed that there is no change of CD spectra in the entire spectral range, indicating that the chirality in the thin film originates from the intrinsic chirality of the helical molecules, and not a product of linear dichroism and birefringence<sup>44,45</sup> . Based on the recorded ellipticity of thin films, we estimated the gabs value depending on the film thickness (Fig. 3e). We observed the almost identical, thickness-independent dissymmetry factors, indicative of intrinsic chiroptical properties in aggregated solid systems. They exhibited relatively lower gabs values than those in the solution state, which is indicative of no amplification of chirality via supramolecular chirality<sup>27,46,47</sup> . 

Device fabrication and electrical performance. To further investigate the electrical properties of PDI double helicenes as chiral organic semiconductors, thin-film-based organic fieldeffect transistors (OFETs) were fabricated and their electrical behaviors were examined. The experimental details of the OFET fabrication and measurements are given in the Supplementary Information. Due to their unstable air stability, we tested the transfer and output characteristics in the vacuum chamber. The transfer and output characteristics are shown in Fig. 4 and OFET characteristics are summarized in Supplementary Table 2. 

Each enantiomer exhibited almost identical electrical properties regardless of the chirality of molecules (P or M). Interestingly, 3aP/M films prepared at an optimized Ts of 140 °C displayed ambipolar field-effect behaviors with typical V-shaped transfer curves. They exhibited high charge-carrier mobility with average hole and electron mobility of 2.1 × 10<sup>−3</sup> and 1.7 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively (3b′ and 3b were also synthesized. 3b-P/M films at an optimized Ts of 140 °C exhibited normal n-type OFET characteristics with an average electron mobility of 2.5 × 10<sup>−5</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , for details see Supplementary Figs. 2, 3 and 15 and Table 2). The charge-carrier mobility was calculated using the slope from a plot of the square root of drain current against gate voltage in the transfer curve at the region marked by red solid line, because they showed non-linearity at high gate voltage (VG) region, which was confirmed by the characteristics of other organic TFTs<sup>48–50</sup> . However, they showed no kink at the low VG region, leading to the ideal operation with biasindependent charge-carrier mobilities. In addition, they showed good bias stability and relatively small charge traps at the organic semiconductor–dielectric interface in transfer characteristics with a hysteresis test. The well-balanced hole and electron mobilities makes 3a very attractive to be applied in complementary circuits. The comparison of chiroptical and electrical performance of 3a with those of previously reported helical organic semiconductors is summarized in Supplementary Table 3. Remarkably, our ortho-π-extended PDIs substantially extends the chiroptically responsive wavelength up to the NIR region (~780 nm) and exhibits the moderate charge-carrier mobilities with well-balanced ambipolarity in thin-film-type OFETs, in comparison with previously reported helical organic semiconductors<sup>17,31,51–56</sup> . In addition to 3a-P/M, 3a-rac was also thermally deposited on the OTS modified substrate at a Ts of 140 °C to investigate the impact of chiral compositions on the electrical properties. Although the organic thin films were fabricated in identical conditions, 3a-rac films did not show any field-effect characteristics (Supplementary Fig. 16) due to the island-type film growth (Supplementary Fig. 17). 



Fig. 4 Electrical performances. a Transfer characteristics of OFETs based on 3a-P films deposited at a Ts of 140 °C in p-type (left) and n-type (right) modes. b Output characteristics of OFETs based on 3a-P films deposited at a Ts of 140 °C in p-type (left) and n-type (right) modes. Solid red lines indicate the region for mobility estimation. 

NIR light responsivity. Design of NIR photodetector with both high quantum yield and excellent charge transport is challenging due to low dissociation efficiencies of the photogenerated excitons and a high dark current<sup>57,58</sup> . Notably, our novel approach using double helicene structure through ortho-π-extension engineering in large PDI core induces significantly red-shifted absorption capability up to NIR region and narrow band gaps. To investigate their spectral photoresponse, we measured the photocurrent of phototransistor devices as the exposed light wavelength changed from NIR to UV range. They showed photocurrent up to NIR region due to their extended π-conjugation (Supplementary Fig. 18). To further explore the photoresponsivity of the enantiopure transistors at the NIR region, the responses of 3a-P to NIR light irradiations were studied (considering their CD spectra, photocurrent, and available laser, λ of 730 nm was selected). Significant current enhancements and threshold voltage (VT) shifts were observed in both p- and n-type operating transfer curves when an external NIR light was illuminated on 3a-P-based OFETs (Fig. 5a). The photocurrent enhancement and sizeable VT shift should be attributed to the generation of photoexcited charge carriers and elimination of trap sites<sup>59,60</sup> . Thus, the photocurrent and VT shift became greater with increased NIR light intensity, as shown in Fig. 5b. More importantly, the slope of photocurrent and VT shift was steeper in p-type mode, indicating improved photosensing responsivity. The higher responsivity is likely originating from the enhanced electrical mobility, which could lead to easier exciton dissociation, exciton separation, and charge transport<sup>59,61</sup> . 

The NIR detection ability was quantified by the photoresponsivity (R), photocurrent/dark current ratio (P), EQE, and detectivity (D*) parameters from the transfer characteristics in Fig. 5a. The R and D* values, the most important factors for photodetectors, increased with the gate field due to the efficient 

5 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 



Fig. 5 Optoelectronic performances in the dark and under NIR light irradiations. a Transfer curves of 3a-P-based OFETs in the dark and under light irradiations (λ = 730 nm) in p-type (left) and n-type (right) modes. b Quantitative analysis results of the photocurrent and VT change of 3a-P-based OFETs under the NIR light irradiations. c R and D* of 3a-P-based OFETs under the NIR light irradiations in p-type (left) and n-type (right) modes. d Maximum R, P, EQE, and D* values of 3a-P-based OFETs under the NIR light irradiations (λ = 730 nm, 540 μW cm<sup>−2</sup> ). 

exciton separation within the dielectric layer (Fig. 5c). Especially, R values reached to 450 and 120 mA W<sup>−1</sup> at VG of −80 V and 100 V in p- and n-type modes, respectively, which are even superior to the reported chiral NIR light detectors based on silicon and chiral plasmonic-patterned electrodes (1.5 mA W<sup>−1</sup> )<sup>28</sup> . The maximum D* values of 3a-P-based OFETs, evaluated from the shot noise under dark conditions<sup>60</sup> were estimated to be 2.1 × 10<sup>10</sup> Jones and 5.9 × 10<sup>9</sup> Jones, in p- and n-type operations, respectively. The maximum photoresponsive parameters under the NIR light irradiations (λ = 730 nm, 540 μW cm<sup>−2</sup> ) are shown in Supplementary Table 4 and Fig. 5d. The maximum P of 2.5 was observed under 540 μW cm<sup>−2</sup> NIR light illumination. In addition, EQE values, the ratio of the number of photogenerated carriers circulating in the circuit to the number of photons absorbed in the device, reached almost 89%, which is comparable to organic thinfilm-based CPL detectors reported to date<sup>17,26,27</sup> . 

Selective detection of CPL. The manipulation of NIR polarization has scarcely been explored because the conventional organic chiral semiconductors have been limited to CPL detection in UV–vis spectral region. Finally, we tested the selectivity of 3aP/M-based OFETs for polarization of illuminated CPL by recording the real-time photocurrent signal in both p-type and n- type modes, respectively (p-type: VD = −80 V, VG = −40 V and n-type: VD = 80 V, VG = 40 V). Interestingly, 3a-P/M-based OFETs showed distinct real-time photocurrent signal under the irradiation of CPL with different polarization (λ = 635 nm, 1400 μW cm<sup>−2</sup> , Fig. 6a). 3a-P-based OFETs exhibited higher photocurrent under the left-handed CPL (LCPL) illumination, while 3a-M-based OFETs exhibited higher photocurrent under the right-handed CPL (RCPL), agreeing very well with the results of CD spectra. To investigate the CPL polarization selectivity quantitatively, we defined a dissymmetry factor of responsivity, 

gR, for photodetectors as follows: 



<!-- Start of picture text -->
gR ¼ 2ðRLCPL � RRCPLÞ=ðRLCPL þ RRCPLÞ; ð1Þ<br><!-- End of picture text -->

where RLCPL and RRCPL are the responsivities under the illumination of LCPL and RCPL, respectively. Figure 6b shows the gR values estimated from four different devices in real-time CPL detections (λ = 635 nm). The dissymmetry factors were estimated to be −0.054 and +0.057 on average depending on the helicity of the organic molecules. The CPL detection abilities were different from the FET operation mode. In n-type operation, the gR value was estimated to +0.029 in 3a-P-based OFETs. The more sensitive CPL detection ability may originate from the increased exciton dissociation and separation and faster charge transport in the p-type operation (Fig. 6c). The relatively larger gR compared to gabs may originate from the synergetic effect of the enhanced photocurrent difference from photomultiplication phenomena by the applied gate bias and the spin-dependent carrier transport/ collection effect due to the optical selection rules<sup>62,63</sup> . In addition, we tested NIR CPL detection in real time (λ = 730 nm, 1400 μW cm<sup>−2</sup> , Fig. 6d, e). 3a-P/M-based OFETs also exhibited distinct and clear real-time photocurrent change with gR of +0.010 and –0.009, respectively. These dissymmetry factors are relatively smaller than those under the red CPL illumination, which also match CD spectra. As a further control experiment for CPL detection, we tested 3a-rac thin films deposited at room temperature. We tested the CPL detection in identical light exposure condition to enantiomeric devices. We recorded the current under the exposure of different handedness of CPL (635 nm). The results showed almost identical photocurrent regardless of the handedness of circular polarization within several times of exposure cycles in two devices (Supplementary Fig. 19). For practical electronic application, we also investigated the thermal stability of 3a-P/M-based OFETs. The CD intensity and gR value 

6 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 







Fig. 6 Selective CPL detection properties. a Real-time current signal of 3a-P/M-based OFETs under CPL irradiations (λ = 635 nm) in p-type mode (the recorded current was plotted as absolute value). b Quantitative analysis results of gR of four 3a-P/M-based OFET devices under CPL irradiations (λ = 635 nm) in p-type mode. c Quantitative analysis results of gR of four 3a-P-based OFET devices under CPL irradiations (λ = 635 nm). d Real-time current signal of 3a-P/M-based OFETs under CPL irradiations (λ = 730 nm) in p-type mode (the recorded current was plotted as absolute value). e Quantitative analysis results of gR of four 3a-P/M-based OFET devices under CPL irradiations (λ = 730 nm) in p-type mode. f Relative CD intensity and gR value of 3a-M-based OFETs under CPL irradiations (λ = 635 nm) in p-type mode after thermal annealing. 

under the CPL illumination keep constant even after annealing at 250 °C for 10 min (Fig. 6f). After 300 °C annealing, CD intensity sharply decreased and the OFET devices became dysfunctional because of the thermal evaporation of many domains in thin films, but was not induced by the isomerization process. These stable and unique NIR light detection should make the helical semiconductors extremely valuable in the high-performance diverse chiroptical applications. 

### Discussion 

In conclusion, we demonstrated a skeleton merging approach for the design of PDI double-heterohelicenes as chiral organic semiconductors for broadband CPL detections. The resulting tetraindole-fused PDI 3a offered a long-desired, simultaneous achievement of electrical and optical properties with large circularly polarization selectivity. The ortho-π-extended PDI double helicene with high photoresponsivity and detectivity enabled CPL detection at NIR spectral region for the first time among chiral organic semiconductors, together with ambipolar charge transport and excellent thermal stability up to ~250 °C. Furthermore, the high-performance NIR-responsive, ambipolar chiral organic semiconductors with intrinsically high gabs developed in this study could be utilized for the fabrication of integrated CPL detectors and complementary logic circuits without auxiliary optical elements. Thus, the skeleton merging approach provides opportunities for the design of custom-made molecules to pursue sophisticated multiple characteristics in order to meet the demands of miniaturization trends in the coming “Internet of Things (IoT)” era. 

using the standard Schlenk method.<sup>1</sup> H and<sup>13</sup> C NMR spectra were recorded at 400 or 500 MHz in CDCl3 as solvent. High-resolution mass spectra were obtained on an FT-MS instrument using ESI or APCI technique. Absorption spectra were recorded on a Thermo Scientific Evolution 300 UV/Vis spectrophotometer. CD spectra of solutions were recorded with a JASCO J-1500 spectropolarimeter. Absorption and CD spectra of thin films were recorded with a JASCO V-770 and a JASCO-815 150-L with an equipment for solid samples, respectively. For transmission spectroscopy, we thermally deposited thin films on transparent quartz plates. Cyclic voltammetry measurements were performed on a Bio-Logic-Science Instrument EC-LAB SP-200. The gabs values are typically defined by the following equation: 



<!-- Start of picture text -->
Θ<br>gabs ¼ 33000*Abs : ð2Þ<br><!-- End of picture text -->

DFT calculations were performed using the Gaussian 09 software package. The geometries and frequencies calculations have been obtained with the ωB97Xd functional in combination with the 6–31+G(d) basis set. Alkyl chains at imide position have been truncated to methyl groups to simplify the calculations. For calculations of CD spectra, the first 20 states were calculated for the [7]-heterohelicenes molecules and the first 40 states for the PDI double-heterohelicenes. A Gaussian broadening of 0.2 eV was used. 

OFET fabrication. OFETs based on 3a and 3b were fabricated using heavily doped silicon wafers covered with a 300-nm-thick SiO2 layer (Ci = 11.5 nF cm<sup>−2</sup> ). Wafers were cleaned with a piranha solution for 30 min, followed by UV-ozone treatment. The wafer surface was treated with an OTS self-assembled monolayer. The OTS solution (3 mM in trichloroethylene) was spin-coated onto the wafers at 1500 r.p.m. for 30 s, and the samples then kept overnight in a vacuum desiccator with a separate vial containing NH4OH. The wafers were then washed with toluene, acetone, and isopropyl alcohol and dried under nitrogen. To fabricate thin films, PDI derivatives were deposited (40 nm) onto OTS-treated wafers in a thermal evaporator at different substrate temperatures. The chamber was under high vacuum (<5.0 × 10<sup>−6</sup> torr), and the deposition rate was maintained at 0.2 Å s<sup>−1</sup> . Gold electrodes (40 nm) were thermally evaporated and patterned using shadow masks. The source/drain patterns had a channel length (L) of 50 μm and a channel width (W) of 1000 μm (W/L = 20). 

### Methods 

All commercial reagents were used without further purification unless otherwise indicated. All oxygen-sensitive reactions were performed under argon atmosphere 

Optoelectronic measurements. Current–voltage characteristics of OFETs were measured inside a vacuum chamber, using a Keithley 4200-SCS semiconductor parametric analyzer. To investigate photocurrent of phototransistor devices, laser 

7 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 

instrument (CNI laser, maximum power of 5 mW) was used to generate monochromatic light. For testing the spectral photoresponse, monochromatic light was produced using a 300 W Xenon lamp and Oriel Cornerstone 130 monochromator with dual gratings. In all, 280 μm slits were used for bandwidth of 3.7 nm. The CPL illumination was generated through a linear polarizer and a quarter-wave plate (Thorlabs). To confirm the quality of circular polarization of the light, we tested the intensity independence of the light passing through the quartz as the degree between the transmission axis of the linear polarizer and the fast axis of the quarter-wave plate changed. Also, we rotated the degree to avoid elliptical polarization by confirming that the intensity of light splits into two orthogonal linear polarization state using beam splitter (Thorlabs). All corrections were conducted by placing the Si photodetector in the same position with the samples. 

Estimation of optoelectrical properties. In order to investigate photosensitivity for OFETs, photoresponsivity (R) and photocurrent/dark current ratio (P) were calculated from transfer characteristics coupled with light irradiation. The R and P values are typically defined by the following equations: 



<!-- Start of picture text -->
R ¼ Iph ¼ Ilight � Idark ; ð3Þ<br>Pinc Pinc<br>P ¼ Ilight � Idark ; ð4Þ<br>Idark<br><!-- End of picture text -->

where Iph is the photocurrent, Pinc the incident illumination power on the channel of the device, Ilight the drain current under illumination, and Idark the drain current in the dark, respectively. In addition, the EQE (η) of OPTs was calculated, which can be defined as the ratio of number of photogenerated carriers that practically enhances the drain current to the number of photons incident onto the OPT channel area, using the following Eq. (5): 



<!-- Start of picture text -->
η ¼ �Ilight � Idark�hc ; ð5Þ<br>ePintAλpeak<br><!-- End of picture text -->

where h is the plank constant, c the speed of light, e the fundamental unit of charge, Pint the incident power density, A the area of the transistor channel, and λpeak the peak wavelength of the incident light, respectively. 

Detectivity usually describes the smallest detectable signal, which allows comparisons of phototransistor devices with different configurations and areas. D* was evaluated within this study using the following Eqs. (6) and (7): **f** 



<!-- Start of picture text -->
f<br>pA<br>D * ¼ ð6Þ<br>NEP ;<br>f f i f f<br>NEP ¼ qI f n f i  f 2 f i f : ð7Þ<br>R p Δf<br><!-- End of picture text -->

In these equations, A is the phototransistor active area, NEP the noise equivalent power,<sup>�</sup> In<sup>2themeasurednoisecurrent,andΔfthebandwidth.Ifthe</sup> major limit to detectivity is shot noise from the drain current under dark conditions, D* can be simplified as 



<!-- Start of picture text -->
D * ¼ f f i  f f i  f f i  f f i  f R f i  f f i  f f i  f f i  f f i  f f i  f f i  f f i  f : ð8Þ<br>p ð2e � Idark=AÞ<br><!-- End of picture text -->

### Data availability 

The data supporting the findings of this study are included within the Article and its Supplementary Information files, and are also available from the authors upon reasonable request. 

Received: 24 June 2020; Accepted: 27 November 2020; 



### References 

1. Beaujuge, P. M. & Fréchet, J. M. J. Molecular design and ordering effects in π- functional materials for transistor and solar cell applications. J. Am. Chem. Soc. 133, 20009–20029 (2011). 

2. Henson, Z. B., Mullen, K. & Bazan, G. C. Design strategies for organic semiconductors beyond the molecular formula. Nat. Chem. 4, 699–704 (2012). 

3. Brandt, J. R., Salerno, F. & Fuchter, M. J. The added value of small-molecule chirality in technological applications. Nat. Rev. Chem. 1, 0045 (2017). 

4. Pop, F., Zigon, N. & Avarvari, N. Main-group-based electro- and photoactive chiral materials. Chem. Rev. 119, 8435–8478 (2019). 

5. Passaseo, A., Esposito, M., Cuscunà, M. & Tasco, V. Materials and 3D designs of helix nanostructures for chirality at optical frequencies. Adv. Opt. Mater. 5, 1601079 (2017). 

6. Shen, Y. & Chen, C.-F. Helicenes: synthesis and applications. Chem. Rev. 112, 1463–1535 (2011). 

7. Li, C. Q., Yang, Y. & Miao, Q. Recent progress in chemistry of multiple helicenes. Chem. Asian J. 13, 884–894 (2018). 

8. Fujikawa, T., Segawa, Y. & Itami, K. Synthesis, structures, and properties of π- extended double helicene: a combination of planar and nonplanar π-systems. J. Am. Chem. Soc. 137, 7763–7768 (2015). 

9. Wang, X.-Y. et al. Synthesis, structure, and chiroptical properties of a double [7]heterohelicene. J. Am. Chem. Soc. 138, 12783–12786 (2016). 

10. Schuster, N. J. et al. Electron delocalization in perylene diimide helicenes. Angew. Chem. Int. Ed. 55, 13519–13523 (2016). 

11. Hu, Y. et al. Benzo-fused double [7]carbohelicene: synthesis, structures, and physicochemical properties. Angew. Chem. Int. Ed. 56, 3374–3378 (2017). 

12. Kato, K., Segawa, Y., Scott, L. T. & Itami, K. A quintuple [6]helicene with a corannulene core as a C5-symmetric propeller-shaped π-system. Angew. Chem. Int. Ed. 57, 1337–1341 (2018). 

13. Zhu, Y. et al. Synthesis and characterization of hexapole [7]helicene, a circularly twisted chiral nanographene. J. Am. Chem. Soc. 140, 4222–4226 (2018). 

14. Hu, Y. et al. π-extended pyrene-fused double [7]carbohelicene as a chiral polycyclic aromatic hydrocarbon. J. Am. Chem. Soc. 141, 12797–12803 (2019). 

15. Schuster, N. J. et al. The structural origins of intense circular dichroism in a waggling helicene nanoribbon. J. Am. Chem. Soc. 142, 7066–7074 (2020). 

16. Liu, B., Bockmann, M., Jiang, W., Doltsinis, N. L. & Wang, Z. Perylene diimide-embedded double [8]helicenes. J. Am. Chem. Soc. 142, 7092–7099 (2020). 

17. Yang, Y., da Costa, R. C., Fuchter, M. J. & Campbell, A. J. Circularly polarized light detection by a chiral organic semiconductor transistor. Nat. Photonics 7, 634–638 (2013). 

18. Jiang, W., Li, Y. & Wang, Z. Tailor-made rylene arrays for high performance n-channel semiconductors. Acc. Chem. Res. 47, 3135–3147 (2014). 

19. Würthner, F. et al. Perylene bisimide dye assemblies as archetype functional supramolecular materials. Chem. Rev. 116, 962–1052 (2016). 

20. Nowak-Krol, A. & Würthner, F. Progress in the synthesis of perylene bisimide dyes. Org. Chem. Front. 6, 1272–1318 (2019). 

21. Zhong, Y. et al. Helical ribbons for molecular electronics. J. Am. Chem. Soc. 136, 8122–8130 (2014). 

22. Zhong, Y. et al. Helical nanoribbons for ultra-narrowband photodetectors. J. Am. Chem. Soc. 139, 5644–5647 (2017). 

23. Chen, Z., Debije, M. G., Debaerdemaeker, T., Osswald, P. & Würthner, F. Tetrachloro-substituted perylene bisimide dyes as promising n-type organic semiconductors: studies on structural, electrochemical and charge transport properties. ChemPhysChem 5, 137–140 (2004). 

24. Gsänger, M. et al. Hydrogen-bonded octachloroperylene diimide with a twisted core: an n-channel organic semiconductor. Angew. Chem. Int. Ed. 49, 740–743 (2010). 

25. Shang, X. et al. Supramolecular nanostructures of chiral perylene diimides with amplified chirality for high-performance chiroptical sensing. Adv. Mater. 29, 1605828 (2017). 

26. Kim, N. Y. et al. Chiroptical-conjugated polymer/chiral small molecule hybrid thin films for circularly polarized light-detecting heterojunction devices. Adv. Funct. Mater. 29, 1808668 (2019). 

27. Schulz, M. et al. Chiral excitonic organic photodiodes for direct detection of circular polarized light. Adv. Funct. Mater. 29, 1900684 (2019). 

28. Li, W. et al. Circularly polarized light detection with hot electrons in chiral plasmonic metamaterials. Nat. Commun. 6, 8379 (2015). 

29. Osswald, P. & Würthner, F. Effects of bay substituents on the racemization barriers of perylene bisimides: resolution of atropo-enantiomers. J. Am. Chem. Soc. 129, 14319–14326 (2007). 

30. Wu, J. et al. Selective ortho-π-extension of perylene diimides for rylene dyes. Org. Lett. 20, 6117–6120 (2018). 

31. Zeng, C. et al. Electron-transporting bis(heterotetracenes) with tunable helical packing. Angew. Chem. Int. Ed. 57, 10933–10937 (2018). 

32. Suraru, S.-L., Burschka, C. & Würthner, F. Diindole-annulated naphthalene diimides: synthesis and optical and electronic properties of syn- and antiisomers. J. Org. Chem. 79, 128–139 (2014). 

33. Su, F. et al. Trisulfur radical anion-triggered stitching thienannulation: rapid access to largely π-extended thienoacenes. Chem. Sci. 11, 1503–1509 (2020). 

34. Chai, J. D. & Head-Gordon, M. Long-range corrected hybrid density functionals with damped atom-atom dispersion corrections. Phys. Chem. Chem. Phys. 10, 6615–6620 (2008). 

35. Wu, J. et al. Direct synthesis of large-scale ortho-iodinated perylene diimides: key precursors for functional dyes. Org. Lett. 19, 5438–5441 (2017). 

36. Yue, W., Jiang, W., Böckmann, M., Doltsinis, N. L. & Wang, Z. Regioselective functionalization of core-persubstituted perylene diimides. Chem. Eur. J. 20, 5209–5213 (2014). 

37. Yu, Z. et al. Self-assembled microdisk lasers of perylenediimides. J. Am. Chem. Soc. 137, 15105–15111 (2015). 

8 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-020-20390-y 

38. Wen, Y. et al. Improvements in stability and performance of N,N’-dialkyl perylene diimide-based n-type thin-film transistors. Adv. Mater. 21, 1631–1635 (2009). 

39. Datar, A., Balakrishnan, K. & Zang, L. One-dimensional self-assembly of a water soluble perylene diimide molecule by pH triggered hydrogelation. Chem. Commun. 49, 6894–6896 (2013). 

40. Hartnett, P. E. et al. Slip-stacked perylenediimides as an alternative strategy for high efficiency nonfullerene acceptors in organic photovoltaics. J. Am. Chem. Soc. 136, 16345–16356 (2014). 

41. Zhang, F. et al. Self-assembly, optical and electrical properties of perylene diimide dyes bearing unsymmetrical substituents at bay position. Sci. Rep. 8, 8208 (2018). 

42. Su, F. et al. Discrete π-stacks from self-assembled perylenediimide analogues. Angew. Chem. Int. Ed. 58, 15273–15277 (2019). 

43. Albano, G., Lissia, M., Pescitelli, G., Aronica, L. A. & Di Bari, L. Chiroptical response inversion upon sample flipping in thin films of a chiral benzo[1,2b:4,5-b’]dithiophene-based oligothiophene. Mater. Chem. Front. 1, 2047–2056 (2017). 

44. Snatzke, G. Circular dichroism and absolute conformation: application of qualitative MO theory to chiroptical phenomena. Angew. Chem. Int. Ed. Engl. 18, 363–377 (1979). 

45. Berova, N., Bari, L. D. & Pescitelli, G. Application of Electronic circular dichroism in configurational and conformational analysis of organic compounds. Chem. Soc. Rev. 36, 914–931 (2007). 

46. Schulz, M. et al. Giant intrinsic circular dichroism of prolinol-derived squaraine thin films. Nat. Commun. 9, 2413 (2018). 

47. Hoeben, F. J. M., Jonkheijm, P., Meijer, E. W. & Schenning, A. About supramolecular assemblies of pi-conjugated systems. Chem. Rev. 105, 1491–1546 (2005). 

48. Salleo, A., Chabinyc, M. L., Yang, M. S. & Street, R. A. Polymer thin-film transistors with chemically modified dielectric interfaces. Appl. Phys. Lett. 81, 4383–4385 (2002). 

49. Lee, W. H., Choi, H. H., Kim, D. H. & Cho, K. 25th Anniversary Article: Microstructure dependent bias stability of organic transistors. Adv. Mater. 26, 1660–1680 (2014). 

50. McCulloch, I., Salleo, A. & Chabinyc, M. Avoid the kinks when measuring mobility. Science 352, 1521–1522 (2016). 

51. Kim, C. et al. Synthesis, characterization, and transistor response of tetrathia- 

   - [7]-helicene precursors and derivatives. Org. Electron. 10, 1511–1520 (2009). 

52. Di Maria, F. et al. Chemical strategy to induce oligothiophene self-assembly into fibers with tunable shape and function. J. Am. Chem. Soc. 133, 8654–8661 (2011). 

53. Hatakeyama, T., Hashimoto, S., Oba, T. & Nakamura, M. Azaboradibenzo[6] helicene: carrier Inversion induced by helical homochirality. J. Am. Chem. Soc. 134, 19600–19603 (2012). 

54. Di Maria, F. et al. Polymorphism in crystalline microfibers of achiral octithiophene: the effect on charge transport, supramolecular chirality and optical properties. Adv. Funct. Mater. 24, 4943–4951 (2014). 

   - donor–acceptor conjugated polymers. ACS Appl. Mater. Interfaces 10, 32444–32453 (2018). 

62. Odenthal, P. et al. Spin-polarized exciton quantum beating in hybrid organic–inorganic perovskites. Nat. Phys. 13, 894–899 (2017). 

63. Long, G. et al. Spin control in reduced-dimensional chiral perovskites. Nat. Photon. 12, 528–533 (2018). 

### Acknowledgements 

We are grateful for financial support from the Natural Science Foundation of China (No. 21772165, 21772162), Samsung Research Funding Center of Samsung Electronics (SRFC-MA1602-51), Natural Science Foundation of Fujian Province of China (2018J01014), Fundamental Research Funds for the Central Universities (No. 20720180031), and the Foundation for Innovative Research Groups of the National Natural Science Foundation of China (Grant No. 21521004), the National Research Foundation of Korea (NRF) grant (No. 2020R1A2B5B03094499), Nano Material Technology Development Program (No. 2017M3A7B8063825) funded through the NRF by the Ministry of Science and ICT (MSIT), Korea. Research in Mons was supported by the Fund for Scientific Research (F.R.S.-FNRS) under the grants No. 4532.16 and 30650939. M.L. thanks the Swedish e-Science Research Center (SeRC) for funding and the Swedish National Infrastructure for Computing (SNIC) for providing computer resources. 

### Author contributions 

H.-J.Z., J.H.O., and J.L. devised the project. L.Z. synthesized the compounds and carried out the solution studies. I.S., J.A., and M.H. performed device measurements. M.L. and M.S. performed the DFT calculations and simulations of CD spectra. J.L. and I.S. co-wrote the manuscript. All authors discussed the results and edited the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information is available for this paper at https://doi.org/10.1038/s41467020-20390-y. 

Correspondence and requests for materials should be addressed to J.H.O. or J.L. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

55. Eakins, G. L. et al. Functional organic semiconductors assembled via natural aggregating peptides. Adv. Funct. Mater. 25, 5640–5649 (2015). 

56. Yang, Y. et al. Emergent properties of an organic semiconductor driven by its molecular chirality. ACS Nano 11, 8329–8338 (2017). 

57. Gong, X. et al. High-detectivity polymer photodetectors with spectral response from 300 nm to 1450 nm. Science 325, 1665–1667 (2009). 

58. Wang, C., Zhang, X. & Hu, W. Organic photodiodes and phototransistors toward infrared detection: materials, devices, and applications. Chem. Soc. Rev. 49, 653–670 (2020). 

59. El Gemayel, M. et al. Tuning the photoresponse in organic field-effect transistors. J. Am. Chem. Soc. 134, 2429–2433 (2012). 

60. Song, I. et al. High-performance visible-blind UV phototransistors based on n- type naphthalene diimide nanomaterials. ACS Appl. Mater. Interfaces 10, 11826–11836 (2018). 

61. Samanta, S. K., Song, I., Yoo, J. H. & Oh, J. H. Organic n-channel transistors based on [1]Benzothieno[3,2-b]benzothiophene–rylene diimide 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

9 

NATURE COMMUNICATIONS | (2021) 12:142 | https://doi.org/10.1038/s41467-020-20390-y | www.nature.com/naturecommunications 

