# Lead-chelating hole-transport layers for efficient and stable perovskite minimodules

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 305 |
| 作者 | Cheng-Bin Fei, Neng-Xu Li, Meng-Ru Wang, Xiao-Ming Wang, Hangyu Gu, Bo Chen, Zhao Zhang, Zhen-Yi Ni et al. |
| DOI | 10.1126/science.ade9463 |
| 源文件 | 062_Fei_2023_Lead-chelating-hole-transport-layers-for-efficie.pdf |

---
# Lead-chelating hole-transport layers for efficient and stable perovskite minimodules 

Chengbin Fei<sup>1</sup> , Nengxu Li<sup>1</sup> , Mengru Wang<sup>1</sup> , Xiaoming Wang<sup>2</sup> , Hangyu Gu<sup>1</sup> , Bo Chen<sup>3</sup> , Zhao Zhang<sup>3</sup> , Zhenyi Ni<sup>1</sup> , Haoyang Jiao<sup>1</sup> , Wenzhan Xu<sup>1</sup> , Zhifang Shi<sup>1</sup> , Yanfa Yan<sup>2</sup> , Jinsong Huang<sup>1,4</sup> * 

The defective bottom interfaces of perovskites and hole-transport layers (HTLs) limit the performance of p-i-n structure perovskite solar cells. We report that the addition of lead chelation molecules into HTLs can strongly interact with lead(II) ion (Pb<sup>2+</sup> ), resulting in a reduced amorphous region in perovskites near HTLs and a passivated perovskite bottom surface. The minimodule with an aperture area of 26.9 square centimeters has a power conversion efficiency (PCE) of 21.8% (stabilized at 21.1%) that is certified by the National Renewable Energy Laboratory (NREL), which corresponds to a minimal small-cell efficiency of 24.6% (stabilized 24.1%) throughout the module area. Small-area cells and large-area minimodules with lead chelation molecules in HTLs had a light soaking stability of 3010 and 2130 hours, respectively, at an efficienc <mark>y</mark> loss of 10% from the initial value under 1-sun illumination and o <mark>p</mark> en-circuit volta <mark>g</mark> e conditions. 

comes from the top-to-down crystallization process of perovskites during solution coating (20). The evaporation of initially trapped DMSO may generate amorphous regions and voids on the scale of tens of nanometers at the bottom of perovskite films during film formation (6). Although the initially formed voids could be eliminated by introducing solid-state carbohydrazide to partially replace DMSO in perovskite precursor solutions, new voids formed at the bottom interfaces along grain boundaries during long-term device operation, indicating the presence of non-negligible amorphous perovskite in perovskite films even after annealing (21). Amorphous regions near the bottom interface have been also observed by high-resolution tunneling electron microscopy studies (22, 23). The nonuniform distribution of the amorphous regions, caused by evaporation of DMSO, may cause nonuniform device performance, and thus it strongly affects the module efficiency and reproducibility, which is not reflected by champion small-cell PCEs. Perovskite modules need to be fabricated to evaluate their impact. 

he power conversion efficiency (PCE) of small-area n-i-p structure, single-junction perovskite solar cells has reached the parity of monocrystalline silicon solar T cells (>25%) (1–4). However, the certified perovskite module PCE is still much lower, at about 19% (5–7), because of the low PCE of p-i-n structure perovskite solar cells and large losses after transferring the small cells to modules, which is mainly induced by the nonuniformity of perovskites or charge-transport layers. Several strategies, such as improving the crystallization process and passivating surface defects, have been applied to further improve the efficiency of p-i-n structure devices (8–12). For example, a certified stabilized PCE >24% was reported for small-area p-i-n structure devices when a surface treatment was used to enhance charge extraction (13). In contrast to top surfaces, the perovskite–hole-transport layer (HTL) interface has received much less attention. Nonradiative recombination of interface carriers caused by defects at buried interfaces may limit the efficiency of p-i-n structure perovskite solar cells (14). A notable smaller photoluminescence (PL) quantum yield was observed for perovskites near HTLs (15). 

We report a method to effectively reduce the amorphous region at the bottom of perovskite films by embedding lead chelation molecules (LCMs), including a broadly applied electron transport material of bathocuproine (BCP), into HTLs. BCP competed with DMSO to interact with lead ions through strong chelation, which reduces the DMSO residue and thus the amorphous region in perovskites near the HTLs. BCP also passivated perovskites and improved the PCE, reproducibility, and stability of the perovskite cells and minimodules. 

In contrast to top surfaces, the bottom perovskite-HTL interface is much more difficult to control. Attempts have been made to mix defect passivation species with HTLs (16–19), given that many passivation molecules may be washed away during perovskite coating because of their high solubility in perovskite precursor solvents, such as 2-methoxyethanol (2-ME), dimethylformamide (DMF), and dimethyl sulfoxide (DMSO). The other challenge 

## Strong interaction of LCMs with perovskites 

> 1Department of Applied Physical Sciences, University of North Carolina at Chapel Hill, Chapel Hill, NC 27599, USA. 

> 2Department of Physics and Astronomy, University of Toledo, Toledo, OH 43606, USA.<sup>3</sup> Perotech, Inc., Chapel Hill, NC 27516, USA.<sup>4</sup> Department of Chemistry, University of North Carolina at Chapel Hill, Chapel Hill, NC 27599, USA. *Corresponding author. Email: jhuang@unc.edu 

We passivated the bottom perovskite-HTL interface by blending passivation species into HTLs. We used LCMs, which are used in water purification or as drugs to treat lead poisoning (24), because these molecules should 

interact strongly with Pb<sup>2+</sup> in perovskites at their interface with HTLs (Fig. 1A). The molecular structures of several selected LCMs are shown in figs. S1 and S2, including BCP, p-toluenesulfonic anhydride (TSA), L-ascorbic acid (VC), meso-2,3-dimercaptosuccinic acid (MDSA), and ethylenediaminetetraacetic acid (EDTA), all of which can provide two or more lone-pair electrons to chelate with Pb<sup>2+</sup> on perovskite surfaces. The chelation of LCMs with Pb<sup>2+</sup> led to the precipitation of Pb<sup>2+</sup> after addition to the perovskite precursor solution. We selected BCP for demonstration because of its low solubility of <0.2 mg ml<sup>−1</sup> in 2-ME, the main solvent in our perovskite inks for a fast-blading process. When BCP was mixed with formamidinium lead iodide (FAPbI3) solution, pale yellow precipitates showed up even at a very low BCP concentration of <0.05 mg ml<sup>−1</sup> (Fig. 1B), indicating that the reaction products have an even lower solubility than BCP. The same precipitation phenomenon was observed when TSA was blended with FAPbI3 (fig. S3). 

The x-ray diffraction (XRD) pattern of the pale yellow precipitates (Fig. 1C and fig. S4) revealed diffraction peaks of multiple compounds, including PbI2•BCP and some solvated phases. The diffraction peak at 11.06° was assigned to PbI2•BCP because this peak was observed from the precipitates of the PbI2 and BCP mixture solution (fig. S5). However, all of the solvated phases, such as PbI2•DMSO, disappeared after removing DMSO by annealing the precipitates at 100°C, after which the powder color changed from yellow to pale yellow. The presence of PbI2•BCP in the annealed powder indicated that the interaction of BCP with Pb<sup>2+</sup> was stronger than that of DMSO with Pb<sup>2+</sup> . 

Fourier-transform infrared spectroscopy (FTIR) measurements were conducted to study how BCP interacts with perovskite precursors (Fig. 1, D and E). The C=N stretch in BCP at 1622 cm<sup>−1</sup> could be distinguished readily from that of FAPbI3 at 1720 cm<sup>−1</sup> (25). After mixing with FAPbI3, the C=N stretching peak from BCP shifted to a smaller wavenumber of ~1606 cm<sup>−1</sup> , which agreed with the shifting of electron density toward Pb<sup>2+</sup> and was indicative of the strong interaction of BCP with Pb<sup>2+</sup> . The same FTIR shift was observed when all of the other LCMs were mixed with FAPbI3 (fig. S6), supporting the Pb<sup>2+</sup> chelation effect of these molecules. The phenanthroline group in BCP has two pyridine rings. We note that the C=N FTIR peak completely shifted, rather than splitting into two peaks. This result indicated that the N atom in both pyridine groups of BCP interacted with Pb<sup>2+</sup> , resulting in the chelation of BCP with Pb<sup>2+</sup> . X-ray photoelectron spectroscopy (XPS) also confirmed the interaction of BCP with Pb<sup>2+</sup> , because there was a shift in the Pb 4f peak after the 

perovskite film was covered by a spin-coated thin layer of BCP (Fig. 1F). The decrease in Pb<sup>2+</sup> binding energy was consistent with the chelation of BCP with Pb<sup>2+</sup> that resulted from the sharing of electrons from N (in BCP) with Pb<sup>2+</sup> . 

The chelation effect provides a more robust interaction with perovskites than the single pyridine group. We calculated the binding energies of a BCP and a DMSO molecule on PbI2-terminated and formamidinium iodide (FAI)–terminated (100) FAPbI3 perovskite surfaces. During the PbI2 termination, the two N atoms of BCP bond to a single Pb atom of FAPbI3 (Fig. 1G), whereas for DMSO, only a single O–Pb bond forms (Fig. 1H). The binding energy of BCP with FAPbI3 is 1.71 eV and 0.84 eV for DMSO. For the FAI termination, hydrogen bonding occurs between the two N atoms of BCP and one H atom of FA (Fig. 1I). The binding energy of BCP with FAPbI3 is 1.41 eV. For DMSO, hydrogen bonding occurs between the O atom of DMSO and two H atoms of FA<sup>+</sup> (Fig. 1J), resulting in a smaller binding energy of 0.57 eV. On both surfaces with PbI2 and FAI termination, the binding energy is two to three times greater for BCP than for DMSO. 

## Defect passivation of the bottom interface by LCMs 

We introduced LCMs to the poly[bis(4phenyl)(2,4,6-trimethylphenyl)amine] (PTAA) layer by mixing them in toluene at different ratios for BCP and TSA or by blade-coating them onto the PTAA layers for insoluble LCMs, including VC, MDSA, and EDTA (see supplementary methods for details). The perovskite composition of FA0.9Cs0.1PbI3 was used for device fabrication because of its reported high operational stability (5, 26–28). Both the HTL and perovskite layers were coated in ambient conditions by using nitrogen knife-assisted blading (29). 

We conducted steady-state PL and PL lifetime measurements to understand how LCMs blended in PTAA affect the perovskiteHTL interfaces. Several prior studies showed that the embedded perovskite-HTL interface could be even more defective than the top perovskite surface depending on the processing conditions (15). When we sandwiched a perovskite film with PTAA to keep the charge extraction condition the same at both sides and compared the PL intensity of the top surface with that of the bottom surface, we also observed a ~ 40% weaker PL from the bottom side (fig. S7), indicating that bottom interface indeed has more defects. When we examined the bottom interface by bringing incident excitation light in from the indium tin oxide (ITO) side (Fig. 2A), BCP notably enhanced the steady-state PL intensity by 1.7 times (Fig. 2B). The PL lifetime at the bottom of the perovskite 



Fig. 1. Chelation of lead ions by BCP. (A) Illustration of the chelation of the LCMs (in the HTL) with Pb<sup>2+</sup> ions at the bottom side of the perovskite films. (B) Photo of the BCP solution (in 2-ME, ~0.1 mg ml<sup>−1</sup> ), FAPbI3 solution (in 2-ME and DMSO, 1M), and a mixture of the BCP solution and the FAPbI3 solution (volume: volume = 1:1 mixture). (C) XRD pattern of the precipitates that form in the mixture of the BCP and FAPbI3 solutions. The insets are photos of the dried precipitates before (bottom) and after (top) annealing. a.u., arbitrary units. (D and E) FTIR of the BCP powder, the FAPbI3 powder, and the dried powder from the BCP-FAPbI3 mixture (D). A zoomed-in view of the FTIR results is shown in (E). (F) XPS spectra of Pb 4f from the perovskite films with and without spun BCP on the top surface. (G to J) DFT modeling of the interaction of the BCP and PbI2 termination (G), the DMSO and PbI2 termination (H), the BCP and FAI termination (I), and the DMSO and FAI termination (J). [Photo credits: The authors] 

skites to exclude the impact of perovskite crystallinity. We measured the PL spectra and PL lifetime changes with light incident from the air side (Fig. 2D). BCP enhanced the PL intensity by 1.2 times and improved the PL lifetime to 1.43 ms (Fig. 2, E and F), which confirmed the passivation effect of BCP on perovskites and indicated that the 

films also increased from 195 to 452 ns (Fig. 2C), so preembedded BCP in PTAA reduced the nonradiative recombination defects at the bottom interface of perovskites. However, the improved PL lifetime may also be caused by the HTL creating a more-crystalline perovskite layer (30). To verify the passivation function of BCP, we spun a BCP layer on top of perov- 



Fig. 2. Functionality of BCP in reducing defects in perovskites. (A and D) Measurement geometry. (B and C) Steady state PL and time-resolved PL (TRPL) decay of control and target perovskite films, respectively. (E and F) Steady-state PL and TRPL decay of perovskite samples with and without BCP coated on the top surface, respectively. (G and H) FLIM of perovskite layers on PTAA with and without BCP, respectively. (I) Structure of a Pb-Pb dimer on the PbI2-terminated (100) surface. (J) Structure of BCP binding to a Pb-Pb dimer on the surface. (K) Calculated DOS of the PbI2 termination without and with BCP binding. The dashed vertical lines indicate the valence band maximum and conduction band minimum. 

(DFT) calculation. We found that perfect PbI2and FAI-terminated surfaces do not form deep gap states. Pb-Pb dimers could form on the surface with an extra I vacancy, which can be easily formed through the loss of iodide. The Pb-Pb dimer induces gap states through Pb 5p–Pb 5p bonding. The deep gap states could be eliminated by BCP but not by DMSO, as revealed by studies of the PbI2-terminated (100) surface. The Pb-Pb dimer that formed when two iodide vacancies were present created deep gap states (Fig. 2I). When a BCP molecule interacted with the Pb-Pb dimer, the two N atoms bonded to one Pb atom of the dimer, breaking the dimer structure (Fig. 2J), because the Pb-N bond formation partly saturated the Pb coordination. As shown in Fig. 2K, the gap states were eliminated after 

BCP addition also modified the morphology of the perovskite close to this interface. 

We evaluated the uniformity of the passivated perovskite-HTL interface using fluorescence lifetime imaging microscopy (FLIM). Hereafter, we refer to the pure PTAA and BCP: PTAA HTLs as control and target, respectively. The crystal grains were distinguished in PL mapping and had apparent sizes of 1 to 2 mm (Fig. 2, G and H). The PL intensity and lifetime were relatively uniform in both the control and target films over a measurement area of 40 mm by 40 mm, but compared with the control film, the target film showed a PL that was 1.5 times stronger and a PL lifetime that was 1.1 times longer. 

We further compared the passivation effects of BCP and DMSO by density function theory 

breaking the Pb-Pb dimer. However, DMSO could not break Pb-Pb dimers because it formed only one Pb–O bond. The Pb-Pb dimer remained after DMSO molecule binding, leaving gap states (fig. S8, A and B). 

## Reducing amorphous regions in perovskites by LCMs 

To find out which defects were reduced by the introduction of BCP to PTAA, we measured the trap density change of the devices using thermal admittance spectroscopy and drivelevel capacitance profiling (DLCP). The trap density of state (tDOS) profiles in Fig. 3A showed three distinct trap bands for both the control and target devices, which resembled those reported for iodide perovskites. These trap bands were assigned to negatively charged iodine interstitials (Ii–) and positively charged iodine interstitials (Ii+), respectively (31). The density of Ii– did not exhibit obvious changes in the perovskites, whereas the Ii+ density was reduced by the introduction of BCP into PTAA. DLCP measurements gave consistent results in that the Ii– density did not change throughout the devices, whereas the Ii+ density was notably reduced (fig. S9). 

We plotted the change in Ii+ density (DIiþ<sup>¼</sup> jIi<sup>þ</sup> ;target<sup>�I</sup> i<sup>þ</sup> ;control<sup>j)inducedbyBCPinperov-</sup> skites across the device from C60 to the HTL side. As shown in Fig. 3B, BCP mainly reduced the Ii+ density in perovskites near the HTL. Our recent study of another perovskite with the same composition showed a similar reduction in the Ii+ density with unchanged Ii– density upon thermal annealing of the films in the dark for several hundreds of hours (21). Because the reduction in the Ii+ density was accompanied by a reduction of the amorphous region and the appearance of associated voids at the bottom interface near PTAA, we hypothesize that the amorphous phase at the bottom of the perovskite films may be rich in Ii+, which were reduced by the BCP:PTAA HTL. 

To verify this hypothesis, we conducted scanning electron microscope (SEM) measurements to examine the voids caused by the recrystallization of the amorphous region in the control perovskite devices using PTAA as the HTL. The devices were encapsulated to avoid the impact of moisture and oxygen and soaked under room lighting for ~1000 hours to allow recrystallization to occur. The fresh and soaked perovskite films were peeled off from the ITO/PTAA substrate to expose the bottom surfaces, which were then subjected to SEM study. As shown in Fig. 3, C to F, the average grain size of these perovskite films was 1 to 2 mm, which agreed with the PL mapping result. For the fresh samples with or without BCP, there was no notable morphology difference at the bottom of the perovskite films. After aging, many shallow voids appeared 

around the grain boundaries at the bottom of the aged control samples, resembling the result of thermal annealing of such films (21). 

By contrast, the bottom morphology of the aged target sample was nearly indistinguishable from that of the fresh target samples, indicating that BCP notably reduced the formation of an amorphous phase at the bottom of the perovskite films. We conducted grazing-incident XRD (GIXRD) pattern measurements to directly examine the crystallinity of perovskites near the HTL using peeled-off fresh samples. As shown by the GIXRD patterns in Fig. 3G and fig. S10, the peak of the (100) plane is not only 60% stronger but also 8% sharper, confirming the improved crystallinity of the perovskite bottom layer induced by BCP. The reduced amorphous regions should contribute to the reduction in Ii+ density at the bottom of the perovskite films (Fig. 3A). 

We studied why BCP could reduce the amorphous regions. Prior studies showed that the trapped solvent DMSO may also cause the amorphous phase in the perovskite bottom and grain boundaries (6). We measured the trapped DMSO content in perovskite films after film annealing using hydrogen nuclear magnetic resonance (<sup>1</sup> H-NMR) spectroscopy. Perovskite films fabricated on different HTLs were scraped off from the substrates and dissolved in deuterium oxide. The content of DMSO in the perovskite film was determined by the ratio of the integral area of the characteristic peak of<sup>1</sup> H in DMSO to that of FA<sup>+</sup> . As shown in Fig. 3H and fig. S11, the peaks at 7.71 parts per million (ppm) and 2.63 ppm were assigned to –CH in FA<sup>+</sup> and –CH3 in DMSO, respectively (32, 33). The DMSO/ FA<sup>+</sup> atomic ratio in the control sample was 0.13% but was 0.08% in the target sample (table S1). 

Thus, BCP in PTAA did reduce the amount of trapped DMSO, in that BCP competed with DMSO to coordinate with Pb<sup>2+</sup> at the bottom region during the film formation process, so BCP:PTAA reduced the amount of DMSO bounded to Pb<sup>2+</sup> (Fig. 1C). The decrease in trapped DMSO resulted in perovskites that were less amorphous. The reduction of defective amorphous perovskite by BCP thus improved device efficiency and stability. The trapping of DMSO can be very nonuniform, particularly for large-area perovskite films coated in a production line, depending on the local vapor pressure, which could differ substantially from location to location. Reduced trapping of DMSO explained the better uniformity of perovskite films and thus would be expected to enhance perovskite module efficiency. 

## Enhancing the performance of perovskite solar cells by LCMs 

To evaluate how the LCMs affect perovskite solar cell performance, perovskite solar cells 



Fig. 3. Influence of BCP on perovskite crystallization. (A) tDOS of perovskite solar cells prepared on PTAA with (target) and without (control) BCP. I, II, and III represent trap bands. Ew, demarcation energy. (B) Changes in the trap density of trap band II in the perovskite devices induced by BCP. SEM images of the bottom side of the perovskite films that were peeled off from the ITO/glass substrates. (C to F) SEM images of the control films [(C) and (D)] and target films [(E) and (F)]. (C) and (E) are fresh films, and (D) and (F) are films aged 1000 hours. Scale bars are 2 mm. (G) GIXRD patterns of the fresh control and target perovskite films measured from the bottom side. (H)<sup>1</sup> H-NMR of DMSO residual in the control and target perovskite films. 

were fabricated with the structure ITO/HTL/ perovskite/C60/BCP/copper (Cu) (Fig. 4A). As shown in fig. S12, incorporating LCMs either into or onto HTLs improved the stability of all of the devices during an accelerated lightinduced degradation test (200 mW cm<sup>−2</sup> , at open-circuit and ambient conditions, 59° to 65°C). Of all of the LCMs tested, BCP and TSA resulted in a higher PCE with an improved open-circuit voltage (VOC) and fill factor (FF) (fig. S13). The higher PCEs could be explained by the better mixing of BCP and TSA with PTAA, because the benzene group in BCP or TSA should induce a p-p interaction with PTAA (34), facilitating carrier transfer from perov- 

skites to PTAA. Another reason is that BCP and TSA are much less soluble in the solvents of perovskites. 

We chose BCP for the PCE optimization. BCP has been broadly used as an electron transport material in p-i-n structure perovskite solar cells (35), and its hole-blocking property has been reported often (36–38). Thus, its loading ratio in PTAA needed to be optimized for optimal hole collection. Perovskites have a sufficiently long carrier diffusion length, such that photogenerated charges can still be efficiently extracted even if some local contacts are blocked, which has been demonstrated by nanocontact perovskite solar cells or those 



Fig. 4. Small-area perovskite device performance. (A) Schematic of the structure of the perovskite solar cells. (B) J-V curves of the p-i-n structure small devices with and without BCP in PTAA HTLs. The active area of the small devices is 0.08 cm<sup>2</sup> . (C) Device performance parameter values for the small devices based on PTAA with 0 to 10 wt % BCP in PTAA. Each of the symbols (squares, circles, diamonds, hexagons, and pentagons) represent one sample. The box outlines represent the data variation. (D) Light soaking stability of the control and target small devices under illumination from light source LS2 with an intensity of 100 mW cm<sup>−2</sup> . Data were collected from 18 to 20 devices for each group. 

1.17 V, and a FF of 0.825, resulting in a PCE of 24.6% (Fig. 4B). The average PCE increased to 24.1%, and the photocurrent hysteresis was not obvious in either type of device. The observed small variation in the PCE of small-area devices (0.08 cm<sup>2</sup> ) agreed with the uniform distribution of BCP in PTAA and uniform passivation. The average PCE of the control devices is ~22.0%, which is consistent with what was reported previously using the same CsI- or FAI-rich perovskite composition (5). Considering that BCP has other functional groups besides phenanthroline, we evaluated two other molecules with these functional groups and confirmed that chelation phenanthroline groups dominate the device efficiency enhancement (figs. S14 and S15). 

with noncontinuous insulating interfacial layers (19, 39–42). The control devices with a 0.08-cm<sup>2</sup> working area had a short-circuit current density (JSC) of 25.2 mA cm<sup>−2</sup> , a VOC of 1.13 V, a FF of 0.80, and a PCE of 22.7% (Fig. 4B), consistent with our previous results (5). As shown in Fig. 4C, a BCP of ~2 wt % in PTAA was needed to increase the FF of the perovskite devices. WhentheBCPloadinginPTAAexceeded 2wt%, the device FF was markedly reduced, which was likely caused by a reduction in hole collection. The same variation trend of JSC with that of FF also occurred with varied BCP loading ratios. By contrast, the device VOC monotonically increased from 1.13 to 1.17 V when the BCP loading ratio was increased from 0 to 2 wt %. VOC saturated with a further increased BCP ratio because hole extraction was not needed under open-circuit conditions. 

The preembedded BCP in PTAA also greatly improved the device stability. We used three different light sources for stability measurements based on the device area and lifetime of 

The champion target devices with optimal BCP showed a JSC of 25.5 mA cm<sup>−2</sup> , a VOC of 

the light sources (fig. S16). The light intensity of all of the light sources was controlled to be 1 sun, as determined by a silicon solar cell that is used for solar-simulator light-intensity calibration (see fig. S17). The xenon light source with a 400-nm long-pass filter (LS1) and the white light-emitting diode (LED) light source (LS2) had more deep-blue or deep–ultraviolet (UV) light, and the light-emitting plasma light source with a 450-nm long-pass filter (LS3) had a stronger infrared component. Deep-UV light was filtered to simulate the final PV modules that have a UV absorber such as a ZnO coating (43, 44). We also evaluated whether the spectra of these light sources affected solar-cell stability. Our study shows that UV light in the solar spectrum did accelerate perovskite device degradation, but filtering UV light of the solar spectrum made perovskites as stable as those measured under a white LED light source (fig. S18). The degradation of these devices was similar (fig. S19), and when the deep-UV light was filtered, only minor spectral differences in the stability of the perovskite solar cells were evident for the three light sources. The small-area device stability was tested by soaking the devices at open-circuit conditions with light source LS2. The devices were heated to between 55° and 61°C by illumination during the stability testing, and no additional temperature control was applied. 

Typical J-V curves of the devices after light soaking for different durations are shown in fig. S20, and average PCEs over time for the control and target devices are shown in Fig. 4D. For the control devices, the PCE decreased to 90% of its initial efficiency (T90 lifetime) after light soaking for 1890 hours. By contrast, the T90 lifetime of the target devices under light soaking increased to 3010 hours. Previous studies concluded that light-soaking stability measured at VOC conditions is an even harsher stability test than the maximum power point (MPP) stability test because accumulated photogenerated excess charges accelerate perovskite degradation by enhancing ion migration (45). To verify this for this perovskite composition, we tested the same batch of control devices under the MPP and VOC conditions and found a much longer T90 lifetime during MPP testing (fig. S21). The thermal stability of the devices was also evaluated at high temperatures according to the International Electrotechnical Commission (IEC) 61215 standard. The PCE loss of both the control and target devices was <1% of the initial efficiency (T99) after ~1000 hours of testing in the dark at 85°C (fig. S22). 

## Efficiency and stability of perovskite minimodules 

Our prior study showed that nonuniform photocurrents from different subcells would 



Fig. 5. Perovskite minimodule performance. (A) Photo of an encapsulated minimodule. [Photo credit: The authors] (B) J-V curves of the control and target minimodules that have eight subcells connected in series. Each subcell is 6 mm wide and 55 mm long. (C) Certification of stabilized photovoltaic performance for a minimodule by NREL using their asymptotic Pmax scan protocol. The aperture area of this module is 26.9 cm<sup>2</sup> . (D) The calculated aperture efficiency 

of minimodules with different subcell widths based on small-cell efficiencies of 24.1% (orange) and 24.6% (green). The maximum attainable efficiencies for a subcell width of 6 mm are 21.1 and 21.8%. (E) Light-soaking stability of the control and target minimodules under illumination from light source LS2 with an intensity of 100 mW cm<sup>−2</sup> . Efficiency data were collected from five or six minimodules (aperture area of ~26.4 cm<sup>2</sup> ) for each group. 

notably reduce the FF of resultant modules (46). BCP:PTAA improved the uniformity of perovskite films, as evidenced by the small variation in device performance from batch to batch, which should also improve the module performance. We thus upscaled the 0.08 cm<sup>2</sup> small-area devices to minimodules with aperture areas of 20 to 30 cm<sup>2</sup> , as defined by the photomask shown in fig. S23. The minimodules had a subcell width of 6.0 mm and a dead-area width of 320 mm (fig. S24), resulting in a geometry filling factor of 94.7% (Fig. 5A). As shown by the photocurrent curves in Fig. 5B, the addition of BCP enhanced the FF and VOC of the minimodules. Several minimodules were sent to the National Renewable Energy Laboratory (NREL) for PCE certification. The certified champion aperture PCE of the perovskite minimodules reached 21.8%, with an aperture area of 26.9 cm<sup>2</sup> from J-V scanning (fig. S25). The stable power output measurement method (which measures the stabilized photocurrent near the MPP) gave a stabilized PCE of 21.1% (Fig. 5C and fig. S26). 

Using a recently established model (46), we calculated the minimal small-cell PCE that is needed to yield a module PCE of 21.8% (or a 

stabilized PCE of 21.1%) by assuming that the perovskite device is perfectly uniform throughout the minimodules. As shown in Fig. 5D, with more details in fig. S27, the minimal small-area cell PCE needs to be 24.6% (stabilized PCE of 24.1%). This efficiency is near the measured average PCE of small cells, indicating that the perovskite films were very uniform. The minimodules with a BCP:PTAA HTL had a VOC of 1.17 V, which is the same as that of small-area cells. The photocurrent density from each 6-mm-wide subcell in the minimodule was 23.6 mA cm<sup>−2</sup> , which is near the calculated value (fig. S27A). Notably, the minimodule with this large area had a large FF of 0.803, which was also the highest FF reported for perovskite minimodules. The calculation result provided in fig. S27B also shows that the FF of 0.803 has already reached the theoretical upper limit based on the attainable small-area device performance, indicating that there is negligible PCE loss caused by the nonuniformity of device performance. 

The minimodule stability was evaluated by light soaking with five or six minimodules in ambient conditions at VOC conditions under light source LS2 with a light intensity of 1 sun. 

The minimodule temperature was measured as between 56° and 62°C and was kept constant during the testing process. Instead of using a higher testing temperature, the actual module operation temperature was used to keep the underlying photochemistry the same as it would be under real operation conditions. Typical J-V curves of the control and target minimodules after light soaking for different durations are shown in fig. S28. The average T90 lifetime of the minimodules with a BCP: PTAA HTL reached ~2130 hours, whereas the control minimodules only had a T90 lifetime of ~1380 hours (Fig. 5E). 

## Discussion 

The introduction of LCMs into PTAA HTLs improved the efficiency, stability, and reproducibility of the p-i-n structure perovskite solar cells. Because of the strong interaction between the phenanthroline group in BCP and Pb<sup>2+</sup> and the low solubility of BCP•PbI2 in 2-ME, BCP stayed at the bottom of the perovskite layer during solution coating. With a reduced trap density at the bottom of the perovskite layer and charge recombination at the PTAA-perovskite interface, the average 

PCE of the devices with BCP increased to 24.1%. With BCP in the PTAA layer, the amorphous layer and DMSO residue in the perovskite layer were decreased, leading to the reduced void formation around the grain boundaries during light soaking. BCP in PTAA also increased the T90 lifetime from ~1890 to ~3010 hours. The champion minimodules with an aperture area of 26.9 cm<sup>2</sup> showed a certified PCE of 21.8% (stabilized at 21.1%). 

### REFERENCES AND NOTES 

1. M. Kim et al., Science 375, 302–306 (2022). 

2. Y. Zhao et al., Science 377, 531–534 (2022). 

3. T. Wang et al., Science 377, 1227–1232 (2022). 

4. H. Min et al., Nature 598, 444–450 (2021). 

5. Y. Deng et al., Nat. Energy 6, 633–641 (2021). 

6. S. Chen et al., Science 373, 902–907 (2021). 

7. T. Bu et al., Science 372, 1327–1332 (2021). 

8. Q. Cao et al., Sci. Adv. 7, eabg0633 (2021). 

9. Z. Li et al., Science 376, 416–420 (2022). 

10. X. Li et al., Science 375, 434–437 (2022). 

11. S. Bai et al., Nature 571, 245–250 (2019). 

12. S. Tan et al., Nature 605, 268–273 (2022). 

13. Q. Jiang et al., Nature 611, 278–283 (2022). 

14. X. Zuo et al., Chem. Eng. J. 431, 133209 (2022). 

15. G. Yang et al., Nat. Photonics 16, 588–594 (2022). 

16. Y. Yang et al., Org. Electron. 86, 105873 (2020). 

17. B. L. Watson, N. Rolston, K. A. Bush, L. Taleghani, 

- R. H. Dauskardt, J. Mater. Chem. A 5, 19267–19279 (2017). 

18. S. Ye et al., J. Am. Chem. Soc. 139, 7504–7512 (2017). 

19. J. Peng et al., Energy Environ. Sci. 10, 1792–1800 (2017). 

20. S. Chen et al., Sci. Adv. 7, eabb2412 (2021). 

21. M. Wang, C. Fei, M. A. Uddin, J. Huang, Sci. Adv. 8, eabo5977 (2022). 

22. S. Yang et al., Science 365, 473–478 (2019). 

23. Z. Ni et al., Science 367, 1352–1358 (2020). 

24. J. J. Chisolm Jr., J. Pediatr. 73, 1–38 (1968). 

25. V. C. A. Taylor et al., J. Phys. Chem. Lett. 9, 895–901 (2018). 

26. J. Chen, N.-G. Park, Adv. Mater. 31, e1803019 (2019). 

27. N. Li et al., Joule 4, 1743–1758 (2020). 

28. Y.-H. Lin et al., Science 369, 96–102 (2020). 

29. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

30. C. Bi et al., Nat. Commun. 6, 7747 (2015). 

31. Z. Ni et al., Nat. Energy 7, 65–73 (2022). 

32. T. Zhu, D. Zheng, M.-N. Rager, T. Pauporté, Sol. RRL 4, 2000348 (2020). 

33. T. A. S. Doherty et al., Science 374, 1598–1605 (2021). 

34. C.-H. Kuan et al., Chem. Eng. J. 450, 138037 (2022). 

35. Q. Wang et al., Energy Environ. Sci. 7, 2359–2365 (2014). 

36. R. Tomova, P. Petrova, R. Stoycheva-Topalova, Phys. Status Solidi. C 7, 992–995 (2010). 

37. J. Lee et al., Phys. Chem. Chem. Phys. 18, 5444–5452 (2016). 

38. H. Gao et al., J. Phys. Chem. A 112, 9097–9103 (2008). 

39. J. Peng et al., Science 371, 390–395 (2021). 

40. S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, Science 362, 449–453 (2018). 

41. Q. Wang, Q. Dong, T. Li, A. Gruverman, J. Huang, Adv. Mater. 28, 6734–6739 (2016). 

42. W. Peng et al., Science 379, 683–690 (2023). 

43. A. Becheri, M. Dürr, P. Lo Nostro, P. Baglioni, J. Nanopart. Res. 10, 679–689 (2008). 

44. Y. Li et al., Nat. Commun. 12, 5419 (2021). 

45. Y. Lin et al., Nat. Commun. 9, 4981 (2018). 

46. X. Dai et al., PRX Energy 1, 013004 (2022). 

### ACKNOWLEDGMENTS 

Funding: This material is based upon work supported by the US Department of Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under Solar Energy Technologies Office award no. DE-EE0009520. The research at Perotech, Inc., is supported by the Office of Naval Research under award no. N6833522C0122. The 

work at the University of Toledo was supported by the Center for Hybrid Organic Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science, within the US Department of Energy. DFT calculations used resources of the National Energy Research Scientific Computing Center (NERSC), a US Department of Energy Office of Science User Facility located at Lawrence Berkeley National Laboratory, operated under contract no. DEAC02-05CH11231 using NERSC award BES-ERCAP0023945. The views expressed herein do not necessarily represent the views of the US Department of Energy or the United States government. Author contributions: C.F. and J.H. conceived the idea. C.F. fabricated and characterized perovskite films and devices. M.W. performed the GIXRD measurement and acquired the SEM images. N.L. evaluated several LCMs. X.W. and Y.Y. carried out the DFT calculations. H.G. carried out partial module encapsulation. Z.Z., B.C., and W.X. optimized the laser scribing process. Z.N. carried out the tDOS and DLCP analyses. H.J. carried out the MPP tracker (MPPT) analysis of light stability. Z.S. carried out the PL mapping of the samples. C.F. and J.H. wrote the manuscript, and all authors commented on the manuscript. Competing interests: C.F. and J.H. are authors of a provisional patent based on this manuscript. J.H. has disclosed a financial interest with Perotech, Inc. Data and materials availability: All data are available in the main text or the supplementary materials. License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/science-licensesjournal-article-reuse 

### SUPPLEMENTARY MATERIALS 

science.org/doi/10.1126/science.ade9463 Materials and Methods Figs. S1 to S28 Table S1 References 

Submitted 18 September 2022; resubmitted 9 March 2023 Accepted 27 April 2023 10.1126/science.ade9463 

