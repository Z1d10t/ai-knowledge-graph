# Co-deposition of hole-selective contact and absorber for improving the processability of perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 295 |
| 作者 | Xiao-Peng Zheng, Zhen Li, Yi Zhang, Min Chen, Tuo Liu, C. Xiao, Dan-Peng Gao, Jay B. Patel et al. |
| DOI | 10.1038/s41560-023-01227-6 |
| 源文件 | 065_Zheng_2023_Co-deposition-of-hole-selective-contact-and-abso.pdf |

---
Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **nature energy** 

**Article** 

https://doi.org/10.1038/s41560-023-01227-6 

# **Co-deposition of hole-selective contact and absorber for improving the processability of perovskite solar cells** 

|Received: 31 October 2022<br>Accepted: 7 February 2023|**Xiaopeng Zheng**<br>**1,9, Zhen Li2,9, Yi Zhang**<br>**3,9, Min Chen1,9, Tuo Liu4,**<br>**1**<br>**Chuanxiao Xiao**<sup>**1**</sup>**,Danpeng Gao**<sup>**2**</sup>**, JayB. Patel**<br>**1,5, Darius Kuciauskas**<br>**,**<br>**Artiom Magomedov**<sup>**5,6**</sup>**, RebeccaA. Scheidt**<sup>**1**</sup>**,Xiaoming Wang**<sup>**7**</sup>**,**|
|---|---|
|Published online: xx xx xxxx|**StevenP. Harvey**<br>**1, Zhenghong Dai8, Chunlei Zhang2, Daniel Morales5,**|
|Check for updates|**8**<br>**Henry Pruett**<sup>**4**</sup>**, BrianM. Wieliczka**<sup>**1**</sup>**,AhmadR. Kirmani**<sup>**1**</sup>**,NitinP. Padture**<br>**,**<br>**3**<br>**KennethR. Graham**<br>**4, Yanfa Yan**<br>**7, Mohammad Khaja Nazeeruddin**<br>**,**|
||<br> <br>**1**<br>**MichaelD. McGehee**<br>**1,5, Zonglong Zhu**<br>**2**<br>**& JosephM. Luther**|



Simplifying the manufacturing processes of renewable energy technologies is crucial to lowering the barriers to commercialization. In this context, to improve the manufacturability of perovskite solar cells (PSCs), we have developed a one-step solution-coating procedure in which the hole-selective contact and perovskite light absorber spontaneously form, resulting in efcient inverted PSCs. We observed that phosphonic or carboxylic acids, incorporated into perovskite precursor solutions, self-assemble on the indium tin oxide substrate during perovskite flm processing. They form a robust self-assembled monolayer as an excellent hole-selective contact while the perovskite crystallizes. Our approach solves wettability issues and simplifes device fabrication, advancing the manufact urability of PSCs. Our PSC devices with positive–intrinsic–negative geometry show a power conversion efciency of 24.5% and retain >90% of their initial efciency after 1,200 h of operating at the maximum power point under continuous illumination. The approach shows good generality as it is compatible with diferent self-assembled monolayer molecular systems, perovskites, solvents and processing methods. 

<mark>Q1</mark> Perovskite solar cells (PSCs) have m .attained outstanding power conversion efficiency (PCE) approaching 26% due to the advances in compositional engineering<sup>1</sup> , solvent engineering<sup>2,3</sup> , phase stabilization<sup>4,5</sup> , contact and interface engineering<sup>6–10</sup> , and defect passivation<sup>11–17</sup> . These 

efficient PSCs are usually fabricated in multiple steps during which charge-carrier transport layers, perovskite absorber, interfacial treatment layers and electrodes are sequentially deposited. Reducing the number of device processing steps without sacrificing device efficiency 

> 1National Renewable Energy Laboratory, Golden, CO, USA. 2Department of Chemistry and Hong Kong Institute for Clean Energy, City University of Hong Kong, Hong Kong, Hong Kong.<sup>3</sup> Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Sion, Switzerland. 4Department of Chemistry, University of Kentucky, Lexington, KY, USA. 5Department of Chemical and Biological Engineering, and Materials Science and Engineering, University of Colorado, Boulder, CO, USA.<sup>6</sup> Department of Organic Chemistry, Kaunas University of Technology, Kaunas, Lithuania. 

> 7Department of Physics and Astronomy, and Wright Center for Photovoltaics Innovation and Commercialization, University of Toledo, Toledo, OH, USA. 

> 8School of Engineering, Brown University, Providence, RI, USA. 9These authors contributed equally: Xiaopeng Zheng, Zhen Li, Yi Zhang, Min Chen. e-mail: zonglzhu@cityu.edu.hk; joey.luther@nrel.gov 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 

would be advantageous to reduce the complexity of the process as well as the manufacturing costs, which will enhance the manufactur-ability of PSCs. **m.m.m.m.m.m.m.m.m.m.** 

<mark>Q2 Q3</mark> **.m.m.m..m.m..m..** <mark>Q4 Q5</mark> ability of PSCs. **m.m.m.m.m.m.m.m.m.m.** In the inverted configuration, the use of p-type additives, such as <mark>Q6 Q7</mark> 2,3,5,6-tetrafluoro-7,7,8,8-tetracyanoquinodimethane, fluorinated <mark>Q8 Q9 Q10</mark> (tetraarylbenzo[1,2-and CuSCN, in the perovskite precursor solution has been explored _b_ :4,5- _b_ ′]dipyrrol-1,5-diyl)dialkanesulfonate m .salts to remove the hole transport layer (HTL) deposition step by modifying the energetic alignment at the indium tin oxide (ITO)/perovskite interface<sup>18–21</sup> . This strategy has achieved PSCs with 20.2% PCE<sup>18</sup> . However, despite this effort, the concept of HTL-free devices has not <mark>Q11</mark> proliferated and their PCEs lag significantly m .behind those of regularly structured devices. 

Recently, some of the most promising inverted PSCs were fabricated with a self-assembled monolayer (SAM) formed of a carbazolecontaining phosphonic acid (PA), such as [2-(9 _H_ -carbazol-9-yl)ethyl] phosphonic acid (2PACz), [2-(3,6-dimethoxy-9 _H_ -carbazol-9-yl)ethyl] phosphonic acid (MeO-2PACZ) and [4-(3,6-dimethyl-9 _H_ -carbazol-9-yl) butyl]phosphonic acid (Me-4PACz), as hole-selective contact due to their ability to conformally coat rough surfaces and high hole extraction selectivity with low interface electron trap density<sup>22–27</sup> . 

Here we report the spontaneous formation of both the SAM hole-selective contact and the absorber in a single step for the fab- <mark>Q12</mark> rication of efficient inverted PSCs. .We introduced various molecules m directly into the perovskite precursor solution and the molecules self-assembled as a SAM on the ITO substrate during perovskite film processing, forming an excellent hole-selective contact. The devices were completed by passivating the top surface and applying contacts, resulting in cells with a PCE of 24.5% with >1,200 h of stable operation under illumination. The approach is compatible with different molecules, perovskite compositions, solvent systems and coating methods. 

### **Dynamic process of perovskite film and SAM formation** 

<mark>Q13</mark> We first demonstrated the procedure by introducing 0–2 mg ml.m<sup>−1</sup> Me-4PACz, a carbazole-containing PA, into a perovskite precursor solution in 4:1 _N_ , _N_ -dimethylformamide (DMF)–dimethylsulfoxide (DMSO) to prepare 1.56 eV bandgap Cs0.05(FA0.92MA0.08)0.95Pb(I0.92Br0.08)3 (FA, formamidinium; MA, methylammonium)<sup>13</sup> . Throughout this manuscript, we will refer to perovskite films containing Me-4PACz in the precursor as ‘target’ perovskites and to films without the PA as ‘neat’ perovskite. The target perovskite films were directly deposited onto ITO-coated glass substrate without the processing of an HTL. In parallel, we also prepared neat perovskite films on glass/ITO, glass/ITO/2PACz and glass/ITO/ Me-4PACz substrates. Compared with the perovskite films prepared on glass/ITO/2PACZ, perovskite films processed on glass/ITO/Me-4PACz showed very poor coverage due to poor wetting, which may be an effect of the methyl substitutions (Supplementary Figs. 1 and 2)<sup>28</sup> . The target perovskite film with Me-4PACz included in the precursor achieved full coverage on glass/ITO substrate, comparable to that of the neat perovskite precursor deposited directly onto the glass/ITO substrate. No change in the bandgap was observed after introducing Me-4PACz (Supplementary Fig. 3). Scanning electron microscopy (SEM) images of the films show that the average grain size of a perovskite film with Me-4PACz (0.5 mg ml<sup>−1</sup> ) is slightly larger than that of a neat perovskite film (Supplementary Fig. 4). Increasing the additive concentration to 2 mg ml<sup>−1</sup> resulted in reduced grain size, indicating that there is an optimal concentration of the additive molecules for ideal crystallization. Dark current mapping by conductive atomic force microscopy (C-AFM) revealed that the perovskite films prepared with the optimal Me-4PACz concentration had a lower dark current than neat films or films with a high concentration of Me-4PACz (Supplementary Fig. 5). 

We fabricated inverted c (BCP, bathocuproine). The passivation <mark>Q14</mark> agent was a 2:1 (wt/wt) mixture m .of 4-trifluorophenylethylammonium iodide (CF3-PEAI) and methylammonium iodide (MAI)<sup>29,30</sup> , and the Cs0. 

05<sup>(FA</sup> 0.98<sup>MA</sup> 0.02<sup>)</sup> 0.95<sup>Pb(I</sup> 0.98<sup>Br</sup> 0.02<sup>)</sup> 3<sup>perovskite films (bandgap</sup><sup>_E_</sup> G<sup>≈ 1.55 eV)</sup> had a thickness of about 800 nm (Fig. 1a). Figure 1b shows the forward and reverse current density–voltage ( _J_ – _V_ ) characteristics of a champion target 1.55 eV PSC with 24.5% PCE (confirmed by the stabilized power output (SPO)). The Me-4PACz concentration-dependent _J_ – _V_ curves demonstrate that the optimal concentration for 1.55 eV devices is 0.25 mg ml<sup>−1</sup> (Supplementary Fig. 6). At higher Me-4PACz concentration, the performance drops dramatically, mainly because of reduced shunt resistance. The PCEs of devices with lower Me-4PACz concentrations m .are slightly lower, mainly due to the loss of open-circuit <mark>Q15</mark> voltage ( _V_ OC), which we expect to be the result of direct contact between the perovskite and ITO. 

To gain an understanding of how and where the Me-4PACz SAM forms, we used a simplified device stack without surface passivation treatment, with the structure glass/ITO/perovskite (1.56 eV)/LiF/C60/ BCP/Ag, for optical and structural characterization unless otherwise noted. The thickness of the perovskite films was about 650 nm (Supplementary Fig. 7). The Me-4PACz concentration-dependent _J–V_ curves demonstrate that the PCEs of the 1.56 eV PSCs are highest when the concentration is between 0.25 and 1 mg ml<sup>−1</sup> (Supplementary Fig. 8), and the devices deliver a PCE of 22.6% (Supplementary Fig. 9). 

We then characterized these devices by depth profiling using time-of-flight secondary ion mass spectrometry (TOF-SIMS; Fig. 1c–e). For the target perovskite film, a pronounced phosphorous (P) signal from Me-4PACz was observed at both the ITO/perovskite and perovskite/electron transport layer (ETL) interfaces (Fig. that the Me-4PACz molecules diffuse to the top and bottom interface1d), which indicatesm . <mark>Q16</mark> during perovskite film processing. We then removed the target perovskite film by dissolving it in DMF, yielding an optically clear substrate. We then redeposited a neat perovskite film and performed TOF-SIMS again. We still observed a P signal of similar magnitude at the ITO/perovskite interface for this new film deposited without the Me-4PACz additive (Fig. 1e). This observation was confirmed by X-ray photoelectron spectroscopy (XPS; Supplementary Fig. 10), which showed the presence of P on the ITO surface after the target perovskite film had been washed off. The TOF-SIMS and XPS results suggest that Me-4PACz SAMs form on the ITO during perovskite film processing through strong bonding interactions between the PA and ITO. 

To investigate the dynamics of SAM formation, we washed off the intermediate-phase perovskite film containing Me-4PACz while still partially wet using DMF. We then redeposited a neat perovskite film onto the substrate (Fig. 2a). The resulting device showed a PCE of only 18.4% (Fig. 2b). The cell showed an inferior performance to the target device ( _V_ OC of 1.08 V versus 1.14 V and fill factor .m (FF) of 78.9% <mark>Q17</mark> versus 83.3%), indicative of SAM-free regions leading to direct contact between the ITO and perovskite. We conclude that the SAM is loosely packed and incomplete before perovskite crystallization. 

We also fabricated neat PSCs on substrates in which the target perovskite film had been washed off after full crystallization. The resulting device showed a much higher PCE (21.7% with a _V_ OC of 1.12 V) than the neat devices fabricated on ITO substrate with the intermediate-phase film containing Me-4PACz washed off. This demonstrates that a denser and robust SAM formed on the ITO substrate during the perovskite film crystallization process. Perovskite films have been shown to follow a top-to-bottom downward crystallization process initialized by the evaporation of residual solvent from the top surface of ‘wet’ films<sup>31</sup> . We surmise that during film formation the Me-4PACz is pushed downwards and concentrated on the ITO surface where the phosphonic acid headgroups bind strongly to the ITO substrate spontaneously forming a robust SAM<sup>32</sup> . Meanwhile, residual Me-4PACz remains on the perovskite top surface. Me-4PACz is too large to be incorporated into the perovskite lattice and we do not see a substantial P signal throughout the film, but cannot rule out a very small amount at grain boundaries. The 1.55 eV PSCs also showed a similar SAM formation process (Supplementary Fig. 11). 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 



<!-- Start of picture text -->
a c 105<br>C<br>104  Pb  In  Ag<br>(CF3-PEAI + MAI)/C60/BCP/Ag  103  LiF/C 60 /BCP<br>102  Neat perovskite<br>Perovskite  10100 1  P  Glass/ITO<br>0  200  400  600<br>Apparent depth (nm)<br>ITO  d<br>Glass  1 µm  105  C<br>104  Pb  Ag<br>103  In  LiF/C 60 /BCP<br>b 25  102  P Me-4PACz  Target perovskite<br>101<br>20  Forward scan Reverse scan  100  Glass/ITO<br>0  200  400  600  Target perovskite<br>25  24.5%  25  Apparent depth (nm)  washed o”<br>15  e<br>105  C<br>10  20  SPO @ 1.04 V  20  104  Pb  In<br>103  Ag<br>5  15  15  102  LiF/C 60 /BCP<br>0  20  40  60  80  100  P<br>Time (s)  101  Redeposited neat<br>Me-4PACz  perovskite<br>0  100<br>0  0.2  0.4  0.6  0.8  1.0  1.2  0  200  400  600  800  Glass/ITO<br>Voltage (V)  Apparent depth (nm)<br>f<br>I  Downward<br>crystallization<br>Pb<br>C<br>N<br>O<br>S<br>P<br>Cs/MA/FA<br>DMF<br>Spin coating  Annealing<br>DMSO<br>Void<br>Me-4PACz<br>Perovskite precursor  Glass/ITO<br>Intensity (counts)<br>Intensity (counts)<br>–2 )<br> (mA cm J SPO (%)<br>–2) Current density (mA cm<br>Intensity (counts)<br><!-- End of picture text -->

**Fig. 1 | Perovskite thin-film preparation and characterization. a** , Crosssectional SEM image of a target 1.55 eV PSC. **b** , _J_ – _V_ curves of the champion target 1.55 eV PSC. The inset shows the SPO. **c** – **e** , TOF-SIMS profiles of 1.56 eV PSCs along with device stack diagrams showing the layers of the devices: PSC with neat perovskite (c), PSC with target perovskite (d) and PSC in which the target 

perovskite film has been washed off and a neat perovskite film redeposited in the finished device. Simplified device stacks without surface passivation treatment were used. The grey and light-blue shading in **c** – **e** mark the ETL/perovskite and perovskite/ITO interfaces, respectively. **f** , Illustration of SAM formation and the perovskite crystallization process. 

Figure 1f shows a schematic illustration of the dynamics of SAM formation. Some Me-4PACz molecules bind to the ITO surface through covalent bonds/chemisorption and form a loosely packed SAM during application of the perovskite precursor solution, but a denser and robust SAM forms during the crystallization of the perovskite film. 

We also performed in situ real-time photoluminescence (PL) experiments to monitor the perovskite crystallization process (Supplementary Fig. 12). The results show that the neat and target films form similarly, and that the target film has a higher PL intensity during crystallization, indicating fewer defects in the target perovskite film. 

### **Characterization of perovskite films and interfaces** 

Given the ability to simultaneously form a SAM and perovskite layer and then for only the perovskite layer to be removed with DMF, we further examined the electronic structure of the ITO substrates and perovskite films by ultraviolet photoelectron spectroscopy (UPS). We washed off the perovskite films and compared the work function ( _Φ_ ) of the ITO substrates. We observed a significant change in the value of _Φ_ from 4.33 eV (identical to that of bare ITO) for the ITO substrates after rinsing away the neat perovskite to 4.94 eV for the ITO substrates 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 



<!-- Start of picture text -->
a b 25<br>DMF<br>(i) Wash o…<br>20<br>Intermediate-phase/<br>ITO  perovskite film 15<br>Target<br>Glass<br>10  Redeposited neat perovskite film on substrate with:<br>Neat perovskite film washed o…<br>(ii) Redeposit  5  Target intermediate-phase film washed o…<br>neat perovskite<br>Target perovskite film washed o…<br>Neat perovskite  0<br>film<br>–5<br>0  0.2  0.4  0.6  0.8  1.0  1.2<br>Voltage (V)<br>c d e f<br>Neat  Neat  Neat  Neat<br>Target  Target  Target  Target<br>ITO  ITO  Perovskite  Perovskite<br>0.65 eV  1.34 eV  1.08 eV<br>6.5  6.0  5.5  5.0  4.5  3  2  1  0  6.5  6.0  5.5  5.0  4.5  4  3  2  1  0  –1<br>Binding energy (eV)  Binding energy (eV)  Binding energy (eV)  Binding energy (eV)<br>g h<br>0  E vac  1<br>–1  On glass<br>–2<br>Work function<br>–3<br>CB  CB<br>–4  Neat<br>0.5 mg ml–1<br>–5  E F 0.1  2 mg ml–1<br>–6<br>ITO  HOMO  VB  VB<br>ITO/SAM  Perovskite Perovskite  0  200  400  600  800  1,000<br>(control)  (target)  Time (ns)<br>–2) Current density (mA cm<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br>Energy (eV)  PL intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Characterization of SAM formation, energetic alignment and carrier lifetime. a** , Schematic illustration of the washing off of the intermediate-phase or perovskite film and redeposition of a neat perovskite film. **b** , _J_ – _V_ characteristics of neat PSCs fabricated on substrates with the intermediate-phase or perovskite film washed off. **c** ,d, UPS spectra (10.2 eV excitation) of the secondary electron cut-off ( **c** ) and valence band ( **d** ) regions of the ITO and ITO/SAM substrates after washing off the neat and target perovskite films, respectively. The red dashed vertical line in **d** indicates the value of the HOMO with respect to _E_ F, determined 

by the intercept to the background<sup>13</sup> . **e** ,f, UPS spectra of the secondary electron cut-off ( **e** ) and valence band ( **f** ) regions of the neat and target perovskite films, respectively. The red dashed vertical lines in **f** indicate the values of the VBM with respect to _E_ F, calculated by Gaussian fits according to a previous report<sup>35</sup> . **g** conduction band; VB, valence band. , Energy-level diagram extracted from the UPS data. **h** m . , TRPL of perovskite films with different _E_ vac, vacuum level; CB, <mark>Q18</mark> concentrations of Me-4PACz on glass substrates. 

from which the target perovskite had been removed (Fig. 2c). Density functional theory (DFT) calculations show that the electric dipole moment of Me-4PACz increases the work function of the ITO surface (Supplementary Figs. 13 and 14). We also detected a clear signature from the Me-4PACz SAM on ITO with a highest-occupied molecular orbital (HOMO) of 5.59 eV for the ITO substrate after rinsing away the target perovskite (Fig. 2d). The _Φ_ of the top of the perovskite film also increases from 4.54 eV (neat) to 4.66 eV (target; Fig. 2e), and the valence band maximum (VBM) changes from 5.88 eV (neat) to 5.74 eV (target; Fig. 2f), revealing that the target perovskite film is less n-type than the 

neat film (Fig. 2g). The VBM of the modified perovskite aligns well with the HOMO of Me-4PACz on the ITO substrate after the target perovskite has been washed away. Therefore, Me-4PACz likely promotes extraction of the photogenerated holes at the perovskite/ITO interface while also serving to increase the selectivity of the contact. 

We next used cross-sectional Kelvin probe force microscopy (KPFM) to probe the charge-carrier extraction barriers at the bottom interface (ITO/perovskite)<sup>33,34</sup> . The first derivative of the potential difference (measured between the probe and cross-section surface of the sample) shows the electric-field distribution relative to the 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 



<!-- Start of picture text -->
a b<br>1.25<br>25<br>1.20  20<br>1.55 eV PSC with and without passivation<br>15  Without passivation<br>1.15<br>With passivation<br>10<br>V OC = 1.13 V  V OC = 1.19 V<br>1.10  FF = 82.90%  FF = 83.07%<br>5  J SC = 24.74 mA cm–2  J SC = 24.78 mA cm–2<br>PCE = 23.18%  PCE = 24.50%<br>1.05  0<br>0  0.2  0.4  0.6  0.8  1.0  1.2<br>Voltage (V)<br>c<br>1.0<br>0.8  One- Sun continuous illumination<br>MPP tracking<br>Unencapsulated device<br>0.6  N2 atmosphere, 40–45 °C<br>0.4<br>Target washed o› and redeposited neat<br>Target<br>0.2  Target and surface passivation<br>0<br>0  200  400  600  800  1,000  1,200<br>Time (h)<br>ITO/SAM/neat  ITO/tarIgTeOt /SAM/neat/LiF/C ITO/target/LiF/C<br>60  60<br>QFLS (eV)<br>–2 ) Current density (mA cm<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 3 | Device photovoltaic characteristics and stability. a** , Calculated QFLS of glass/ITO/Me-4PACz/neat perovskite, glass/ITO/target perovskite, glass/ ITO/Me-4PACz/neat perovskite/LiF/C60 and glass/ITO/target perovskite/LiF/C60 stacks. **b** , _J_ – _V_ curves of target 1.55 eV PSCs with and without surface passivation. **c** , Operational stability of a neat 1.55 eV PSC fabricated on the substrate with the 

target perovskite washed off (initial PCE = 21.80%) and target 1.55 eV PSCs with (initial PCE = 24.48%) and without (initial PCE = 23.28%) surface passivation. The normalized PCE is shown as a function of time under the following conditions: one-Sun continuous illumination, MPP tracking, unencapsulated, N2 atmosphere and operating cell temperature of ~40–45 °C. 

metallurgical interfaces. Previously we found that the main junction is located at the perovskite/ETL interface with a potential barrier at the HTL/perovskite interface<sup>33</sup> . Here, we observed a significant potential barrier at the ITO/perovskite interface induced by a mismatch of the energetic alignment on the ITO/perovskite (neat) interface (Supplementary Fig. 15). The potential barrier at the ITO/perovskite interface is remarkably reduced for the target perovskite film, which could facilitate hole extraction at the ITO/perovskite interface. To gain an understanding of the impact of SAMs on charge-carrier separation and transport at the top interface (perovskite/ETL), we analysed the direction of the interface dipole induced by Me-4PACz (Supplementary Fig. 16). PAs have also been shown to anchor to the perovskite film surface with the alkyl tail pointing upwards<sup>35</sup> . The molecular dipole induced by Me-4PACz on the top surface would thus have the same polarity as below the perovskite and could promote electron extrac- <mark>Q19</mark> tion to the ETL. Thus, contrary to a conventional HTL m .(such as PTAA and spiro-OMeTAD), SAMs can be present on both sides of the perovskite absorber provided that the dipole is pointing in the same direction to promote charge-carrier extraction at both interfaces (Supplementary Fig. 16). 

We then performed time-resolved photoluminescence (TRPL) experiments on perovskite films on glass and glass/ITO/PTAA substrates. TRPL of the perovskite films on glass substrates showed that the perovskite film with 0.5 mg ml<sup>−1</sup> Me-4PACz has the longest average lifetime ( _τ_ ave) of 520.5 ns compared with 305.0 ns for the neat 

perovskite film (Fig. 2h and Supplementary Table 1), which suggests that the presence of Me-4PACz reduces surface non-radiative recombination. We also measured the TRPL of perovskite films with and without Me-4PACz on glass/ITO/PTAA substrates and fitted the results with a biexponential decay equation. If we assume that lifetime _τ_ 1 is dominated by charge extraction m .to the transport layers and lifetime <mark>Q20</mark> _τ_ 2 is dominated by interface recombination, attributed to fast and slow decay in the literature, respectively<sup>36</sup> , the target perovskite film on ITO/PTAA shows shorter _τ_ 1, indicating faster hole extraction, and longer _τ_ 2, indicating reduced interface recombination (Supplementary Fig. 17 and Supplementary Table 2). Tan and co-workers reported that 2PACz efficiently passivates deep traps in perovskite because of the chemical bonding between Pb and O of the phosphoryl group of 2PACz (ref.<sup>37</sup> ). Another PA additive, 2-aminoethylphosphonic acid, has been demonstrated to passivate positively charged defects (such as iodine vacancies and lead−iodine anti-sites) and therefore improve device efficiency and durability<sup>38</sup> . 

### **Photovoltaic performance and stability** 

We tested this approach on the wide-bandgap perovskite Cs0.05FA0.8 MA0.15Pb(I0.75Br0.25)3 ( _E_ G ≈ 1.68 eV), which is commonly used in perovskite–silicon tandem solar cells<sup>25</sup> , to demonstrate the generality of this concept. The target device showed a PCE of 20.3% with a _V_ OC of 1.14 V from the reverse scan (Supplementary Fig.18). Using a quasi-Fermi level splitting (QFLS) approach, we found that after covering the perovskite 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 



<!-- Start of picture text -->
a b<br>ITO/Me-4PACz/neat perovskite  ITO/target perovskite<br>c d<br>25<br>80<br>20  Forward scan Reverse scan<br>75<br>25<br>15  20<br>70<br>15<br>SPO @ 1.0 V<br>10  10<br>65<br>5<br>5  0<br>0  20  40  60  80 100  60<br>Time (s)<br>0<br>0  0.2  0.4  0.6  0.8  1.0  1.2<br>Voltage (V)<br>2PACzMeO-2PACzMe-2PACzMeO-4PACzMe-4PACzMe-6PACz<br>SPO (%)  Fill factor (%)<br>–2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 4 | Blade coating of PSCs and evaluation of different PAs. a** , **b** , Photographic images of a blade-coated neat 1.55 eV perovskite film on an <mark>Q24</mark> ITO/Me-4PACz SAM (( **b** ). **c** , _J_ – _V_ curves of the champion 1-cm **a** ) and a blade-coated target 1.55 eV perovskite film on ITO<sup>2</sup> blade-coated target 1.55 eV PSC m .with surface passivation. The insets show the SPO (left) and a photographic image of a 1-cm<sup>2</sup> blade-coated target device (right). **d** , Comparison of the FF values of spin- 

coated 1.56 eV PSCs fabricated with different PAs in the perovskite precursor. The box plots in **d** show the median and 25–75% box limits with 1.5 interquartile range whiskers. The mean values are connected by a line to show the trend. For this analysis, 18, 18, 18, 18, 18 and 12 samples were measured for the PSCs prepared with 2PACz, MeO-2PACz, Me-2PACz, MeO-4PACz, Me-4PACz and Me-6PACz, respectively. 

with C60, consistent with previous reports<sup>37</sup> , both ITO/Me-4PACz/neat perovskite and ITO/target perovskite stacks showed room for possible improvement of the voltage by 65–80 mV (Fig. 3a). We ascribed this to incomplete passivation of defect states on the perovskite surface. To confirm this hypothesis, we thereafter passivated the perovskite surface using a mixture of CF3-PEAI and MAI to further improve the device efficiency<sup>29,30</sup> . XPS confirmed the coexistence of Me-4PACz and CF3-PEAI on the perovskite surface (Supplementary Fig. 19). The PCE of the 1.68 eV PSCs improved to 21.6% with a _V_ OC of 1.19 V after surface passivation (Supplementary Fig. 20). We also applied this approach to a 1.8 eV perovskite composition (Cs0.15FA0.85Pb(I0.6Br0.4)3), which is commonly used as a front cell for all-perovskite tandems<sup>39</sup> , and the target 1.8 eV devices showed a PCE of 18.6% with a high _V_ OC of 1.29 V (Supplementary Fig. 21). 

<mark>Q21</mark> 

A PCE of 24.5% with a high _V_ OC of 1.19 V was also achieved m .for 1.55 eV PSCs with surface passivation, along with a short-circuit current density ( _J_ SC) of 24.78 mA cm<sup>−2</sup> and FF of 83.1% from the reverse scan (Figs. 1b and 3b). The 24.5% PCE represents a significant improvement over the previous highest reported PCEs for HTL-free PSCs, and within one <mark>Q22</mark> percentage point of the highest PCE for inverted PSCs (SupplementaryTable 3). The narrow distribution of PCEs for 44 tested devices m .confirms good reproducibility (Supplementary Fig. 22 and Supplementary Table 4). The external quantum efficiency (EQE) was integrated against the solar spectrum to estimate a _J_ SC of 24.6 mA cm<sup>−2</sup> , in agreement with the _J_ – _V_ measurement (Supplementary Fig. 23). 

We evaluated the operating stability using maximum power point (MPP) tracking of unencapsulated 1.55 eV devices under continuous illumination (Fig. 3c). The neat device fabricated on the substrate with the target perovskite washed off, with Me-4PACz only on the bottom interface, retained 82% of the initial PCE after 1,200 h of continuous operation. The target devices with and without surface passivation, with Me-4PACz on both the bottom and top interface, retained 91% and 85% of the initial PCE, respectively. 

### **Blade coating of PSCs and evaluation of different PAs** 

Encouraged by the high device performance, we further evaluated the film uniformity and upscaling capability by fabricating PSCs by blade coating. Due to the severe wetting issues incurred on trying to process perovskites directly onto the Me-4PACz SAM, almost no perovskite remained on the ITO/Me-4PACz substrate (Fig. 4a). By contrast, the blade-coated target perovskite film with Me-4PACz included in the precursor solution achieved full coverage on a glass/ITO substrate (Fig. 4b). A 1-cm<sup>2</sup> blade-coated target device achieved a PCE of 22.5% from the reverse scan, with a _V_ OC of 1.16 V, a _J_ SC of 23.88 mA cm<sup>−2</sup> and an FF of 81.23%. (Fig. tion of PCEs for 20 blade-coated devices confirms good reproducibility4c). The SPO efficiency was 22.1%. The narrow distribu-m . <mark>Q23</mark> (Supplementary Fig. 24) and the approach overcomes the manufacturing challenge of poor wetting of perovskite inks on a SAM-coated surface. 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 



<!-- Start of picture text -->
a b e<br>25  25<br>20  Layer by layer  20  Layer by layer<br>One step  One step<br>O O<br>15  O O 15<br>10  10  Br S Br<br>N<br>N<br>5  EADR03  5  Br-2EPT<br>O OH O P OHOH<br>0  0<br>0  0.2  0.4  0.6  0.8  1.0  0  0.2  0.4  0.6  0.8  1.0<br>Voltage (V)  Voltage (V)<br>Generality<br>c d<br>25  25<br>20  ACN–2ME  20  EtOH–DMA<br>FA0.98MA0.02Pb(I0.98Br0.02)3<br>15  FA0.98MA0.02Pb(I0.98Br0.02)3  15  EtOH<br>ACN  DMA<br>2ME  MACl<br>10  Me-4PACz  10  PMACl<br>Me-4PACz<br>5  5<br>Blade-coated  Spin-coated<br>0  0<br>0  0.2  0.4  0.6  0.8  1.0  1.2  0  0.2  0.4  0.6  0.8  1.0  1.2<br>Voltage (V)  Voltage (V)<br>Fig. 5 | Evaluation of different SAM molecular systems and solvents. a ,  J – V  precursor with Me-4PACz dissolved in ACN–2ME (left) and a perovskite film with<br>curves of target 1.55 eV PSCs and PSCs fabricated by the ‘layer-by-layer’ method dimensions of 1.5 cm × 1.5 cm prepared by blade coating of the precursor solution<br>using EADR03 as the SAM molecule. The inset shows the structure of EADR03. b ,  J – V  curves of target 1.55 eV PSCs and PSCs fabricated by the ‘layer-by-layer’ (right). EtOH–DMA as solvent.  d ,  J – V  curve of a spin-coated target FAm .The insets show a photographic image of the perovskite0.98MA0.02Pb(I0.98Br0.02)3 PSC using Q26<br>method using Br-2EPT as the SAM molecule. The inset shows the structure of precursor with Me-4PACz dissolved in EtOH–DMA (left) and a perovskite film<br>Br-2EPT.  c ,  J – V  curve of a blade-coated target FA0.98MA0.02Pb(I0.98Br0.02)3 PSC using0.98MA0.02Pb(I0.98Br0.02)3 PSC usingMA0.02Pb(I0.98Br0.02)3 PSC using0.02Pb(I0.98Br0.02)3 PSC usingPb(I0.98Br0.02)3 PSC using0.98Br0.02)3 PSC usingBr0.02)3 PSC using0.02)3 PSC using)3 PSC using3 PSC using PSC using with dimensions of 1.5 cm × 1.5 cm prepared by spin coating of the precursor<br>ACN–2ME as solvent. The insets show a photographic image of the perovskite solution (right).  e , Summary of the generality of the approach.<br>Molecular<br>Composition<br>Solvent<br>Processing<br>Cs0.15FA0.85Pb(I0.6Br0.4)3<br>Cs0.05FAFA0.80.98MA0.15MA0.02Pb(IPb(I0.750.98Br0.25Br0.02)3  )3<br>Carboxylic acid (EADR03)<br>Phosphonic acid (Me-4PACz, Br-2EPT and so on) Cs0.05(FA0.92MA0.08)0.95Pb(I0.92Br0.08)3<br>Cs0.05(FA0.98MA0.02)0.95Pb(I0.98Br0.02)3<br>Spin coating<br>DMF – DMSOACN – 2ME<br>Blade coating<br>EtOH (green solvent) – DMA<br>–2) Current density (mA cm –2 ) Current density (mA cm<br>–2) Current density (mA cm –2 ) Current density (mA cm<br><!-- End of picture text -->

**Fig. 5 | Evaluation of different SAM molecular systems and solvents. a** , _J_ – _V_ curves of target 1.55 eV PSCs and PSCs fabricated by the ‘layer-by-layer’ method using EADR03 as the SAM molecule. The inset shows the structure of EADR03. **b** , _J_ – _V_ curves of target 1.55 eV PSCs and PSCs fabricated by the ‘layer-by-layer’ method using Br-2EPT as the SAM molecule. The inset shows the structure of Br-2EPT. **c** , _J_ – _V_ curve of a blade-coated target FA0.98MA0.02Pb(I0.98Br0.02)3 PSC using0.98MA0.02Pb(I0.98Br0.02)3 PSC usingMA0.02Pb(I0.98Br0.02)3 PSC using0.02Pb(I0.98Br0.02)3 PSC usingPb(I0.98Br0.02)3 PSC using0.98Br0.02)3 PSC usingBr0.02)3 PSC using0.02)3 PSC using)3 PSC using3 PSC using PSC using ACN–2ME as solvent. The insets show a photographic image of the perovskite 

To understand why Me-4PACz enables the spontaneous formation of a robust SAM during perovskite film processing, we compared the photovoltaic (PV) parameters of 1.56 eV PSCs fabricated with different PAs (2PACz, MeO-2PACz, [2-(3,6-dimethyl-9 _H_ -carbazol-9-yl)ethyl] phosphonic acid (Me-2PACz), [4-(3,6-dimethoxy-9 _H_ -carbazol-9-yl) butyl]phosphonic acid (MeO-4PACz), Me-4PACz and [6-(3,6-dimet hyl-9 _H_ -carbazol-9-yl)hexyl]phosphonic acid (Me-6PACz)) incorporated in the perovskite precursor solution (Fig. 4d and Supplementary Figs. 25 and 26). The devices with smaller PA (2PACz) showed low PV parameters ( _J_ SC = 21.5–22.5 mA cm<sup>−2</sup> , _V_ OC = 0.9–1.06 V, FF = 60–65% and PCE = 11.5–14.5%). For larger SAM molecules, incorporating two methyl or methoxy groups, we observed improved device performance, with FF values of ~75% for MeO-2PACZ and ~78% for Me-2PACz, due to better coverage of the SAM on ITO, corresponding to better hole extraction. The FF further improved to ~79% and ~80% for the devices prepared with PAs with longer alkyl spacers, MeO-4PACz and Me-4PACz, respectively. These results indicate that the larger Me-4PACz molecules are more effi- <mark>Q25</mark> ciently pushed towards the ITO/perovskite interface m .and the stronger lateral van der Waals interactions help to organize the molecules into a high-grafting-density<sup>40</sup> and well-ordered SAM<sup>40,41</sup> . Further increasing the alkyl spacer length to six in Me-6PACz reduced the FF and PCE due to the detrimental impact of a long spacer on charge extraction<sup>23,42</sup> . 

### **The generality of the approach** 

We have demonstrated the generality of the approach above in terms of various perovskite compositions, SAM chemistry and processing methods (both the solvent system used and the coating procedure). We also investigated different SAM molecular systems and solvents. PSCs fabricated with a carboxylic acid SAM molecule (4-[3,6-bis(2,4-dimethoxyphenyl)-9 _H_ -carbazol-9-yl]benzoic acid (EADR03))<sup>43–45</sup> or a phosphonic acid SAM molecule with a phenothiazine 

electron-rich group ([2-(3,7-dibromo-10 _H_ -phenothiazin-10-yl)ethyl] phosphonic acid (Br-2EPT))<sup>46</sup> incorporated into the perovskite precursor delivered similar PCEs to the devices fabricated by the ‘layer-by-layer’ deposition method, demonstrating the generality of the approach in terms of SAM molecular system (Fig. 5a,b). 

Acetonitrile (ACN) mixed with 2-methoxyethanol (2ME) is a solvent system widely used in the scalable blade coating of PSCs<sup>47,48</sup> . Due to the limited solubility of CsI in this solvent, we used a Cs-free perovskite composition (FA0.98MA0.02Pb(I0.98Br0.02)3). The insets in Fig. 5c show a photographic image of the perovskite precursor with Me-4PACz dissolved in a ACN–2ME and a perovskite film prepared by blade coating of the precursor. The target PSCs with Me-4PACz fabricated by blade coating using ACN–2ME as solvent showed a PCE of 22.1% from the reverse scan (Fig. 5c). 

Yun et al. demonstrated a greener solvent system based on ethanol that yields high performance without the need for DMF or ACN, which may impede the sustainability aspects of PSCs<sup>49,50</sup> . We further explored the EtOH-based green solvent as we try to improve both PSC manufacturability and sustainability. EtOH and isopropanol are solvents commonly used for the deposition of SAM layers by the spin-coating and dipping methods<sup>22</sup> . Following the previous report<sup>50</sup> , we were able to dissolve a perovskite precursor in an EtOH-based solvent. Again we used a Cs-free perovskite composition (FA0.98MA0.02Pb(I0.98Br0.02)3) due to the limited solubility of CsI in the solvent. The insets in Fig. 5d show a photographic image of the perovskite precursor with Me-4PACz dissolved in a mixed solvent of EtOH and dimethylacetamide (DMA), and a perovskite film prepared by spin coating of the precursor. The target PSCs with Me-4PACz fabricated by spin coating using an EtOH-based green solvent showed a PCE of 21.6% from the reverse scan (Fig. 5d). 

We summarize the generality of the approach in Fig. 5e. The approach is compatible with different SAM molecular systems 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

**Article** 

https://doi.org/10.1038/s41560-023-01227-6 

(carbazole- and phenothiazine-based with a phosphonic or carboxylic acid headgroup), perovskite compositions, solvents (DMF–DMSO, ACN–2ME and an ethanol-based green solvent) and processing methods (spin coating and scalable blade coating). Further fine optimization of the approach for each condition using different SAM molecular systems, perovskites, solvents and processing methods will enable higher device performance to be achieved. 

### **Conclusion** 

We have demonstrated that the incorporation of SAM molecules directly into the perovskite precursor enables the spontaneous deposition of both the hole-selective SAM and the perovskite layer. Our approach emphasizes the synergetic roles of molecular size, dipole direction, dipole strength, energetic alignment and defect passivation of the perovskite by PAs. Incorporating SAM molecules into several different types of perovskite precursor solves the critical wetting issue encountered when processing perovskite onto SAMs, while simplifying the manufacturability and retaining high efficiency following proper defect passivation. The approach is versatile as it allows for the use of different SAM molecules, perovskites, solvents and coating methods to improve PSC manufacturability and sustainability. 

### **Methods** 

#### **Materials** 

Formamidinium iodide (FAI), MAI and methylammonium bromide were purchased from Greatcell Solar. CF3-PEAI was purchased from Xi’an Polymer Light Technology. Lead iodide (ultra dry, 99.999%) was purchased from Alfa Aesar. Lead bromide (99.999%), caesium iodide (99.999%), lithium fluoride (≥99.98%), anhydrous DMF, anhydrous DMSO and anhydrous chlorobenzene (CB) were purchased from Sigma-Aldrich. 2PACz and Me-4PACz were purchased from Tokyo Chemical Industry-America. MeO-2PACz, Me-2PACz, MeO-4PACz, Me-4PACz, Me-6PACz, EADR03, Br-2EPT, C60 and BCP were purchased from Luminescence Technology. All chemicals were used as received without further purification. 

#### **Device fabrication** 

The patterned glass/ITO substrates were sequentially cleaned with acetone and isopropanol (IPA) under ultrasonication, dried with nitrogen and then treated with UV/ozone for 15 min. In a typical procedure, the perovskite precursor solution (1.7 M Cs0.05(FA0.98M A0.02)0.95Pb(I0.98Br0.02)3 for 1.55 eV cells, 1.4 M Cs0.05(FA0.92MA0.08)0.95P b(I0.92Br0.08)3 for 1.56 eV cells or 1.5 M Cs0.05FA0.8MA0.15Pb(I0.75Br0.25)3 for 1.68 eV cells) was dissolved in DMF–DMSO (4:1, v/v) in a nitrogen glove box. For the target devices, Me-4PACz was added to the perovskite precursor. A 2 mg ml<sup>−1</sup> Me-4PACz stock solution was prepared by adding 2 mg Me-4PACz powder to 1 ml perovskite precursor solution. We then mixed the 2 mg ml<sup>−1</sup> stock solution with neat perovskite precursor (1:3 or 1:7, v/v) to achieve 0.5 or 0.25 mg ml<sup>−1</sup> Me-4PACz perovskite precursor. The hole-selective contact and perovskite absorber were cast in a single coating step in a nitrogen glove box. The perovskite precursor containing Me-4PACz was spin-coated onto UV/ozone-treated glass/ITO substrates at 2,000 r.p.m. for 2 s and 4,000 r.p.m. for 20 s, and then 150 µl CB was dropped onto the spinning substrate 5 s before the end of the spin-coating process. Subsequently, the sample was annealed at 100 °C for 30 min. For the devices with surface passivation treatment, a mixture of CF3-PEAI (2 mg ml<sup>−1</sup> ) and MAI (1 mg ml<sup>−1</sup> ) was dissolved in IPA–DMF (150:1, v/v), spun onto the as-prepared perovskite films at 5,000 r.p.m. for 30 s and then annealed at 100 °C for 10 min. The devices with surface treatment were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stack. For the devices without surface passivation treatment, we sequentially deposited LiF (1 nm), C60 (25 nm), BCP (6 nm) and silver (100 nm) to complete the device. 

For the fabrication of 1.80 eV PSCs, 1.2 M perovskite precursor. m <mark>Q27</mark> solution was prepared by mixing CsI, CsBr, FAI, formamidinium bromide, PbI2 and PbBr2 in stoichiometric amounts consistent with the chemical formula of Cs0.15FA0.85Pb(I0.6Br0.4)3. Then 8–10 mol% excess PbI2 was added. Me-4PACz was added to the perovskite precursor at a concentration of 0.25 mg ml<sup>−1</sup> . The hole-selective contact and perovskite absorber were cast in a single coating step in a nitrogen glove box. In a typical procedure, the perovskite precursor containing Me-4PACz was spin-coated onto UV/ozone-treated glass/ITO substrates at 1,000 r.p.m. for 5 s and 5,000 r.p.m. for 30 s, and then 200 µl CB was dropped onto the spinning substrate 20 s before the end of the spin-coating process. The substrates were immediately transferred to a hotplate and annealed at 100 °C for 20 min. The surface passivation treatment procedure was performed according to the method described above. The devices were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stacks. 

For the blade coating of 1.55 eV cells, a 0.9 M perovskite precursor solution of Cs0.05(FA0.98MA0.02)0.95Pb(I0.98Br0.02)3 was used. For the target devices, Me-4PACz was added to the perovskite precursor. Then the perovskite precursor solution was blade-coated onto UV/ozone-treated glass/ITO substrates (the blading speed was 10 mm s<sup>−1</sup> and the distance between the blade coater and substrate was 100 µm) at room temperature in ambient air with a relative humidity of ~40%. Next, the as-prepared perovskite substrate was pretreated in a vacuum (<20 Pa) for 5 min, then transferred to a hotplate and annealed at 100 °C for 60 min. The surface passivation treatment procedure was performed according to the method described above. The 1-cm<sup>2</sup> devices were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stacks. 

For the devices fabricated by the conventional ‘layer-by-layer’ method using EADR03 or Br-2EPT as the SAM, these molecules were dissolved in IPA at a concentration of 0.25 mg ml<sup>−1</sup> . The EADR03 solution was heated to 60 °C to increase its solubility. The as-prepared solution was spin-coated onto UV/ozone-treated ITO substrates at 4,000 r.p.m. for 30 s and then annealed at 100 °C for 10 min. The substrates were then washed with IPA by spin coating at 4,000 r.p.m. for 30 s, followed by annealing at 100 °C for 5 min. The 1.7 M Cs0.05(FA0.98MA0.02)0.95Pb(I0. 98<sup>Br</sup> 0.02<sup>)</sup> 3<sup>perovskite precursor solution dissolved in DMF–DMSO (4:1,</sup> v/v) was spin-coated onto the as-prepared substrates at 1,000 r.p.m. for 10 s and 5,000 r.p.m. for 40 s, and then 200 µl CB was dropped onto the spinning substrate 10 s before the end of the spin-coating process. The substrates were immediately transferred to a hotplate and annealed at 100 °C for 30 min. For the devices prepared by the one-step coating process, EADR03 or Br-2EPT was added to the perovskite precursor at a concentration of 0.25 mg ml<sup>−1</sup> . In a typical procedure, the perovskite precursor containing EADR03 or Br-2EPT was spin-coated onto UV/ozone-treated glass/ITO substrates at 1,000 r.p.m. for 10 s and 5,000 r.p.m. for 40 s, and then 200 µl CB was dropped onto the spinning substrate 10 s before the end of the spin-coating process. The substrates were immediately transferred to a hotplate and annealed at 100 °C for 60 min. The devices were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stacks. 

For the PSCs fabricated using EtOH-based solvent, a 1.55 M FA0.9 8<sup>MA</sup> 0.02<sup>Pb(I</sup> 0.98<sup>Br</sup> 0.02<sup>)</sup> 3<sup>perovskite precursor solution was prepared by</sup> mixing FAI, PbBr2, PbI2 and PbBr2, with the addition of 30 mol% MACl and 20 mol% PMACl, in EtOH–DMA (2:1, v/v) and heated at 60 °C for 1 h. Me-4PACz was then added to the perovskite precursor at a concentration of 0.25 mg ml<sup>−1</sup> . The hole-selective contact and perovskite absorber were cast in a single coating step in a nitrogen glove box. In a typical procedure, the perovskite precursor containing Me-4PACz was spin-coated onto UV/ozone-treated glass/ITO substrates at 5,000 r.p.m. for 30 s under a gentle flow of nitrogen. m .The coated films were annealed <mark>Q28</mark> at 100 °C for 20 min. The surface passivation treatment procedure was performed according to the method described above. The devices 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 

were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stacks. 

For the PSCs fabricated using ACN–2ME as solvent, a 1 M FA0.98MA0 .02<sup>Pb(I</sup> 0.98<sup>Br</sup> 0.02<sup>)</sup> 3<sup>perovskite precursor solution was prepared by mixing</sup> <mark>Q29</mark> FAI, PbBr2, PbI2, PbBr2 in ACN–2ME (3:2, v/v). m .The perovskite precursor solution needed to be heated to 60 °C for 1 h. Me-4PACz was then added to the perovskite precursor at a concentration of 0.25 mg ml<sup>−1</sup> . Next, the perovskite precursor solution was blade-coated onto the UV/ozone-treated substrate (the blading speed was 10 mm s<sup>−1</sup> and the distance between the blade coater and substrate was 100 µm) at room temperature in ambient air with a relative humidity of ~40%. Next, the as-prepared perovskite substrate was pretreated in a vacuum (<20 Pa) for 5 min, then transferred to a hotplate at 100 °C for 20 min. The surface passivation treatment procedure was performed according to the method described above. The devices were completed by sequentially thermally evaporating C60 (25 nm), BCP (6 nm) and silver (100 nm) onto the stacks. 

Renewable Energy Laboratory (NREL) PV Performance Characterization Team, and the spectral mismatch factor was minimized to 0.9923. The device area was 0.122 cm<sup>2</sup> and was masked with a metal aperture to define an active area of 0.0585 cm<sup>2</sup> . The scan rate was 0.34 V s<sup>−1</sup> . The SPO of the devices was measured by monitoring the photocurrentdensity output with the biased voltage set near the MPP. EQE meas-m. <mark>Q32</mark> urements were conducted using a Newport Oriel IQE200 instrument. The devices made at City University of Hong Kong were studied using an Enlitech SS-F5 solar simulator (calibrated to 100 mW cm<sup>−2</sup> using a silicon reference cell) for _J_ – _V_ measurements and an Enlitech QE-R system for EQE measurements. The long-term operational stability was tested by applying the PSCs under a one-Sun-equivalent light-emitting diode lamp in a N2-filled glove box (with the contents of O2 and H2O <10 ppm). The device operating temperature was measured to be ~40–45 °C. The PSCs were biased at the MPP voltage and the power output was tracked using a multipotentiostat (CHI1040C, CH Instruments). During the MPP test, the12 h to determine the proper loads for the MPP. _J_ – _V_ curves of the devices were obtained everym . <mark>Q33</mark> 

#### **Material characterization** 

- SEM images were collected using a Hitachi 4800 scanning electron microscope. The absorption spectra were recorded using a Shimadzu UV-3600 spectrophotometer. An ION-TOF TOF-SIMS V spectrometer was used for depth profiling of the perovskite films in accord with our previous report<sup>51</sup> . Depth profiling was completed with a 30 keV Bi3+ primary ion beam (0.8 pA pulsed current) rastered over an area 

- <mark>Q30</mark> of 50 µm × 50 µm and a 1 kV oxygen ion sputter beam (7 nA sputtercurrent) rastered over an area of 150 µm × 150 µm. Photoelectron.m spectroscopy measurements were conducted using a PHI 5600 UHV system with an 11-inch-diameter hemispherical electron energy ana- 

- <mark>Q31</mark> lyser and a multichannel detector. m .The excitation source for UPS was an Excitech H Lyman-α lamp (E-LUXTM121) with an excitation energy of 10.2 eV. All UPS measurements were conducted with a sample bias of −5 V and a pass energy of 5 eV. XPS spectra were recorded with an Al Kα X-ray excitation source (1,486.6 eV) and a pass energy of 30 eV. TRPL measurements were performed using an NKT supercontinuum laser (SuperK EXU-6-PP) for excitation and a Hamamatsu C-10910-04 streak camera for detection (the fluence was 1.04 µW mm<sup>−2</sup> at 0.305 MHz and the wavelength was 532 nm). 

PL emission spectra were recorded using an excitation wavelength of 632.8 nm (HeNe laser). A Princeton Instruments HRS300 spectrograph equipped with a Si CCD (charge-coupled device; Pixis F100) and InGaAs (PyLoN IR) detector was used. The spectral response of the spectrometer system and detectors was corrected using calibration sources (IntelliCal for visible and infrared ranges, Princeton Instruments) placed at the sample position. The size of the excitation beam was determined using a CCD camera. Data were measured in absolute photon numbers using Spectralon reflectance standards (LabSphere) and assuming that one-Sun-equivalent fluence for a 1.68 eV bandgap is about 1.43 × 10<sup>17</sup> photons cm<sup>−2</sup> s<sup>−1</sup> . The QFLS was determined from the spectral fit to the high-energy side of the absolute PL emission spectrum<sup>52</sup> . 

KPFM and C-AFM measurements were performed inside an Ar-filled glove box. The devices were cleaved from the film side to expose the cross section for KPFM measurements, the front side of the device wasgrounded and a biasvoltage wasapplied from theback contact of the devices. KPFM measurements were performed with varying bias voltage from −1 V to +1 V on the same area. The C-AFM images were collected on a Veeco Nanoscope IIIA instrument running in tapping mode. 

#### **Device characterization** 

Simulated AM1.5G irradiation (100 mW cm<sup>−2</sup> ) was produced using an Oriel Sol3A Class AAA solar simulator in a nitrogen glove box for _J_ – _V_ measurements. The intensity of the solar simulator was calibrated with a KG5-filtered Si reference solar cell that was certified by the National 

#### **Computation** 

DFT calculations were performed using the code from the Vienna Ab m. <mark>Q34</mark> initio Simulation Package with projector augmented-wave potentials<sup>53–55</sup> . A kinetic energy cut-off of 500 eV was used to expand the wave functions. The Brillouin zone was sampled with Γ-centred 2 × 2 × 1 _k_ -mesh. The atomic coordinates were relaxed using the Perdew– Burke-Ernzerhof functional with a force tolerance of 0.01 eV Å<sup>−1</sup> (ref.<sup>56</sup> ). To model ITO, we used the In2O3 crystal structure with one-third of the In atoms replaced by Sn. The (222) surface was adopted with O termin ation (passivated with H). **m.** <mark>Q35 Q36</mark> 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data generated or analysed during this study are included in the published article and its Supplementary Information. 

### **References** 

1. Jeon, N. J. et al. Compositional engineering of perovskite materials for high-performance solar cells. _Nature_ **517** , 476–480 (2015). 

2. Jeon, N. J. et al. Solvent engineering for high-performance inorganic–organic hybrid perovskite solar cells. _Nat. Mater._ **13** , 897–903 (2014). 

3. Zhang, H. et al. A universal co-solvent dilution strategy enables facile and cost-efective fabrication of perovskite photovoltaics. _Nat. Commun._ **13** , 89 (2022). 

4. Min, H. et al. Eficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

5. Swarnkar, A. et al. Quantum dot-induced phase stabilization of α-CsPbI3 perovskite for high-eficiency photovoltaics. _Science_ **354** , 92–95 (2016). 

6. Kim, M. et al. Conformal quantum dot–SnO2 layers as electron transporters for eficient perovskite solar cells. _Science_ **375** , 302–306 (2022). 

7. Peng, J. et al. Centimetre-scale perovskite solar cells with fill factors of more than 86 per cent. _Nature_ **601** , 573–578 (2022). 

8. Chen, S. et al. Stabilizing perovskite–substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902–907 (2021). 

9. Li, X. et al. Constructing heterojunctions by surface sulfidation for eficient inverted perovskite solar cells. _Science_ **375** , 434–437 (2022). 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

**Article** 

https://doi.org/10.1038/s41560-023-01227-6 

10. Zhang, F. et al. Metastable Dion–Jacobson 2D structure enables eficient and stable perovskite solar cells. _Science_ **375** , 71–76 (2022). 

11. Luo, D. et al. Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. _Science_ **360** , 1442–1446 (2018). 

12. Jiang, Q. et al. Surface passivation of perovskite film for eficient solar cells. _Nat. Photon._ **13** , 460–466 (2019). 

13. Zheng, X. et al. Managing grains and interfaces via ligand anchoring enables 22.3%-eficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131–140 (2020). 

14. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381–385 (2021). 

15. Wang, R. et al. Constructive molecular configurations for surface-defect passivation of perovskite photovoltaics. _Science_ **366** , 1509–1513 (2019). 

16. Wang, L. et al. A Eu<sup>3+</sup> –Eu<sup>2+</sup> ion redox shuttle imparts operational durability to Pb–I perovskite solar cells. _Science_ **363** , 265–270 (2019). 

17. Bai, S. et al. Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ **571** , 245–250 (2019). 

18. Wu, W.-Q. et al. Molecular doping enabled scalable blading of eficient hole-transport-layer-free perovskite solar cells. _Nat. Commun._ **9** , 1625 (2018). 

19. Zhou, Z. et al. Organic/inorganic hybrid p-type semiconductor doping afords hole transporting layer free thin-film perovskite solar cells with high stability. _ACS Appl. Mater. Interfaces_ **11** , 22603–22611 (2019). 

20. Ye, S. et al. A strategy to simplify the preparation process of perovskite solar cells by co-deposition of a hole-conductor and a perovskite layer. _Adv. Mater._ **28** , 9648–9654 (2016). 

21. Zhou, Z. & Pang, S. Highly eficient inverted hole-transport-layer-free perovskite solar cells. _J. Mater. Chem. A_ **8** , 503–512 (2020). 

22. Al-Ashouri, A. et al. Conformal monolayer contacts with lossless interfaces for perovskite single junction and monolithic tandem solar cells. _Energy Environ. Sci._ **12** , 3356–3369 (2019). 

23. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% eficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

24. Levine, I. et al. Charge transfer rates and electron trapping at buried interfaces of perovskite solar cells. _Joule_ **5** , 2915–2933 (2021). 

25. Liu, J. et al. 28.2%-eficient, outdoor-stable perovskite/silicon tandem solar cell. _Joule_ **5** , 3169–3186 (2021). 

26. Jiang, Q. et al. Surface reaction for eficient and stable inverted perovskite solar cells. _Nature_ **611** , 278–283 (2022). 

27. Li, G. et al. Structure and performance evolution of perovskite solar cells under extreme temperatures. _Adv. Energy Mater._ **12** , 2202887 (2022). 

28. Cassella, E. J. et al. Gas-assisted spray coating of perovskite solar cells incorporating sprayed self-assembled monolayers. _Adv. Sci._ **9** , e2104848 (2022). 

29. Shi, W. & Ye, H. Eficient and stable perovskite solar cells with a superhydrophobic two-dimensional capping layer. _J. Phys. Chem. Lett._ **12** , 4052–4058 (2021). 

30. Chen, H. et al. Quantum-size-tuned heterostructures enable eficient and stable inverted perovskite solar cells. _Nat. Photon._ **16** , 352–358 (2022). 

31. Chen, S. et al. Crystallization in one-step solution deposition of perovskite films: upward or downward? _Sci. Adv._ **7** , eabb2412 (2021). 

32. Hotchkiss, P. J. et al. The modification of indium tin oxide with phosphonic acids: mechanism of binding, tuning of 

   - surface properties, and potential for use in organic electronic applications. _Acc. Chem. Res._ **45** , 337–346 (2012). 

33. Xiao, C. et al. Junction quality of SnO2-based perovskite solar cells investigated by nanometer-scale electrical potential profiling. _ACS Appl. Mater. Interfaces_ **9** , 38373–38380 (2017). 

34. Jiang, C.-S. et al. Carrier separation and transport in perovskite solar cells studied by nanometre-scale profiling of electrical potential. _Nat. Commun._ **6** , 8397 (2015). 

35. Park, S. M., Abtahi, A., Boehm, A. M. & Graham, K. R. Surface ligands for methylammonium lead iodide films: surface coverage, energetics, and photovoltaic performance. _ACS Energy Lett._ **5** , 799–806 (2020). 

36. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-eficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

37. Li, L. et al. Flexible all-perovskite tandem solar cells approaching 25% eficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708–717 (2022). 

38. Zhao, Y. et al. Molecular interaction regulates the performance and longevity of defect passivation for metal halide perovskite solar cells. _J. Am. Chem. Soc._ **142** , 20071–20079 (2020). 

39. Zheng, X., Alsalloum, A. Y., Hou, Y., Sargent, E. H. & Bakr, O. M. All-perovskite tandem solar cells: a roadmap to uniting high eficiency with high stability. _Acc. Mater. Res._ **1** , 63–76 (2020). 

40. Kim, M., Schmitt, S. K., Choi, J. W., Krutty, J. D. & Gopalan, P. From self-assembled monolayers to coatings: advances in the synthesis and nanobio applications of polymer brushes. _Polymers_ **7** , 1346–1378 (2015). 

41. Cheng, H. & Hu, Y. Influence of chain ordering on frictional properties of self-assembled monolayers (SAMs) in nano-lubrication. _Adv. Colloid Interface Sci._ **171** – **172** , 53–65 (2012). 

42. Pathak, A. et al. Disorder-derived, strong tunneling attenuation in bis-phosphonate monolayers. _J. Phys. Condens. Matter_ **28** , 094008 (2016). 

43. Aktas, E. et al. Understanding the perovskite/self-assembled selective contact interface for ultra-stable and highly eficient p–i–n perovskite solar cells. _Energy Environ. Sci._ **14** , 3976–3985 (2021). 

44. Aktas, E. et al. Role of terminal group position in triphenylamine-based self-assembled hole-selective molecules in perovskite solar cells. _ACS Appl. Mater. Interfaces_ **14** , 17461–17469 (2022). 

45. Aktas, E., Jiménez-López, J., Azizi, K., Torres, T. & Palomares, E. Self-assembled Zn phthalocyanine as a robust p-type selective contact in perovskite solar cells. _Nanoscale Horiz._ **5** , 1415–1419 (2020). 

46. Ullah, A. et al. Novel phenothiazine-based self-assembled monolayer as a hole selective contact for highly eficient and stable p-i-n perovskite solar cells. _Adv. Energy Mater._ **12** , 2103175 (2022). 

47. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly eficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

48. Deng, Y. et al. Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. _Sci. Adv._ **5** , eaax7537 (2019). 

49. Vidal, R. et al. Assessing health and environmental impacts of solvents for producing perovskite solar cells. _Nat. Sustain._ **4** , 277–285 (2021). 

50. Yun, H.-S. et al. Ethanol-based green-solution processing of α-formamidinium lead triiodide perovskite layers. _Nat. Energy_ **7** , 828–834 (2022). 

51. Zhao, Q. et al. High eficiency perovskite quantum dot solar cells with charge separating heterostructure. _Nat. Commun._ **10** , 2842 (2019). 

Nature Energy 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. **Article** https://doi.org/10.1038/s41560-023-01227-6 

- <mark>Q37</mark> 52. Unold, T. & Gütay, L. in _Advanced Characterization Techniques for_ m . _Thin Film Solar Cells_ 151–175 (Wiley-VCH, 2011). 

   53. Kresse, G. & Furthmüller, J. Eficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

   54. Kresse, G. & Furthmüller, J. Eficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

   55. Blöchl, P. E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953–17979 (1994). 

   56. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

### **Acknowledgements** 

This work was authored in part by the National Renewable Energy Laboratory, operated by Alliance for Sustainable Energy, for the US Department of Energy (DOE) under contract no. DE-AC3608GO28308. This work was primarily supported as part of the Center for Hybrid Organic-Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Ofice of Basic Energy Sciences, Ofice of Science within the US DOE. The scalable manufacturing work carried out at the NREL was supported by the US DOE’s Ofice of Energy Eficiency and Renewable Energy (EERE) under the Solar Energy Technologies Ofice (SETO) Advanced Perovskite Cells and Modules programme of the National Center for Photovoltaics. The work at City University of Hong Kong was supported by the Innovation and Technology Fund (GHP/102/20GD, Hong Kong). The work at École Polytechnique Fédérale de Lausanne (EPFL) was supported by an NPRP grant (NPRP11S-1231-170150) from the Qatar National Research Fund (a member of the Qatar Foundation) and the Valais Energy Demonstrators Fund. T.L., H.P. and K.R.G. acknowledge funding from the National Science Foundation under award nos. OIA-1929131 (T.L. and K.R.G) and 2102257 (H.P. and K.R.G). The work at Brown University was supported by the Ofice of Naval Research (grant no. N00014-20-1-2574) and the US DOE’s EERE through SETO award no. DE-0009511. The views expressed in the article do not necessarily represent the views of the US DOE or the US Government. 

### **Author contributions** 

X.Z. and J.M.L. conceived the idea and designed the experiments. J.M.L. and Z.Z. supervised the project. X.Z. and Z.L. fabricated the devices and conducted the characterizations. Y.Z., D.G. and C.Z. 

participated in device fabrication. M.C., J.B.P., D.K., R.A.S., D.M. and B.M.W. performed optical spectroscopy and analysis. T.L. and H.P. carried out XPS and UPS measurements. C.X. conducted and analysed the KPFM and C-AFM measurements. S.P.H. performed TOF-SIMS measurements. Z.L., Z.D. and N.P.P. contributed to the device MPP stability test. X.W. and Y.Y. performed and interpreted the DFT calculations. A.M., A.R.K., N.P.P., K.R.G., Y.Y., M.K.N. and M.D.M. contributed to the analysis and provided advice. X.Z. and J.M.L. wrote the initial draft and all authors contributed to the final manuscript. 

### **Competing interests** 

X.Z. and J.M.L. are inventors on a pending provisional patent (US application no. 63/363,327, by Alliance for Sustainable Energy) related to the one-step solution method co-deposition of hole-selective contact and absorber for perovskite solar cells as discussed in this manuscript. M.D.M is an advisor to Swift Solar. All other authors have no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560-023-01227-6. 

**Correspondence and requests for materials** should be addressed to Zonglong Zhu or Joseph M. Luther. 

**Peer review information** _Nature Energy_ thanks Antonio Abate, Emilio Palomares and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional afiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

Nature Energy 

