# Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 2294 |
| 作者 | Jaeki Jeong, Minjin Kim, Jongdeuk Seo, Hai-Zhou Lu, Paramvir Ahlawat, Aditya Mishra, Ying-Guo Yang, M. Hope et al. |
| DOI | 10.1038/s41586-021-03406-5 |
| 源文件 | 001_Jeong_2021_Pseudo-halide-anion-engineering-for-α-FAPbI3-per.pdf |

---
Article 

# **Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells** 

|https://doi.org/10.1038/s41586-021-03406-5<br>Received: 25 September 2020|**Jaeki Jeong**<sup>**1,2,3,11**</sup>**, Minjin Kim**<sup>**4,11**</sup>**, Jongdeuk Seo**<sup>**1,11**</sup>**, Haizhou Lu**<sup>**2,3,11**</sup>**, Paramvir Ahlawat**<sup>**5**</sup>**,**<br>**Aditya Mishra**<sup>**6**</sup>**, Yingguo Yang**<sup>**7**</sup>**, Michael A. Hope**<sup>**6**</sup>**, Felix T. Eickemeyer**<sup>**2**</sup>**, Maengsuk Kim**<sup>**1**</sup>**,**<br>**Yung Jin Yoon**<sup>**1**</sup>**, In Woo Choi**<sup>**4**</sup>**, Barbara Primera Darwich**<sup>**8**</sup>**, Seung Ju Choi**<sup>**4**</sup>**, Yimhyun Jo**<sup>**4**</sup>**,**|
|---|---|
|Accepted: 1 March 2021<br>Published online: 5 April 2021|**Jun Hee Lee**<sup>**1**</sup>**, Bright Walker**<sup>**9**</sup>**, Shaik M. Zakeeruddin**<sup>**2**</sup>**, Lyndon Emsley**<sup>**6**</sup>**, Ursula Rothlisberger**<sup>**5**</sup>**,**<br>**Anders Hagfeldt**<sup>**3,10** ✉</sup>**, Dong Suk Kim**<sup>**4** ✉</sup>**, Michael Grätzel**<sup>**2** ✉</sup>**& Jin Young Kim**<sup>**1** ✉</sup>|
|Check for updates|Metal halide perovskites of the general formula ABX3—where A is a monovalent cation<br>such as caesium, methylammonium or formamidinium; B is divalent lead, tin or<br>germanium; and X is a halide anion—have shown great potential as light harvesters for<br>thin-film photovoltaics<sup>1–5</sup>. Among a large number of compositions investigated, the<br>cubic α-phase of formamidinium lead triiodide (FAPbI3) has emerged as the most<br>promising semiconductor for highly efficient and stable perovskite solar cells<sup>6–9</sup>, and<br>maximizing the performance of this material in such devices is of vital importance for the<br>perovskite research community. Here we introduce an anion engineering concept that<br>uses the pseudo-halide anion formate (HCOO<sup>−</sup>) to suppress anion-vacancy defects that<br>are present at grain boundaries and at the surface of the perovskite films and to augment<br>the crystallinity of the films. The resulting solar cell devices attain a power conversion<br>efficiency of 25.6 per cent (certified 25.2 per cent), have long-term operational stability<br>(450 hours) and show intense electroluminescence with external quantum efficiencies of<br>more than 10 per cent. Our findings provide a direct route to eliminate the most<br>abundant and deleterious lattice defects present in metal halide perovskites, providing a<br>facile access to solution-processable films with improved optoelectronic performance.|



Perovskite solar cells (PSCs) have attracted much attention since their first demonstration in 2009<sup>1–5</sup> . The rapid expansion of research into PSCs has been driven by their low-cost solution processing and attractive optoelectronic properties, including a tunable bandgap<sup>6</sup> , high absorption coefficient<sup>10</sup> , low recombination rate<sup>11</sup> and high mobility of charge carriers<sup>12</sup> . Within a decade, the power conversion efficiency (PCE) of single-junction PSCs progressed from 3% to a certified value of 25.5%<sup>13</sup> , the highest value obtained for thin-film photovoltaics. Moreover, through the use of additive and interface engineering strategies, the long-term operational stability of PSCs now exceeds 1,000 hours in full sunlight<sup>14,15</sup> . PSCs therefore show great promise for deployment as the next generation of photovoltaics. 

Compositional engineering plays a key part in achieving highly efficient and stable PSCs. In particular, mixtures of methylammonium lead triiodide (MAPbI3) with formamidinium lead triiodide (FAPbI3) have been extensively studied<sup>5,7</sup> . Compared to MAPbI3, FAPbI3 is thermally more stable and has a bandgap closer to the Shockley–Queisser limit<sup>6</sup> , rendering FAPbI3 the most attractive perovskite layer for single-junction PSCs. 

Unfortunately, thin FAPbI3 films undergo a phase transition from the black α-phase to a photoinactive yellow δ-phase below a temperature of 150 °C. Previous approaches to overcome this problem have included mixing FAPbI3 with a combination of methylammonium (MA<sup>+</sup> ), caesium (Cs<sup>+</sup> ) and bromide (Br<sup>−</sup> ) ions; however, this comes at the cost of blue-shifted absorbance and phase segregation under operational conditions<sup>7–9,16</sup> . 

Nevertheless, α-FAPbI3 has recently emerged as the candidate of choice for highly efficient and stable PSCs<sup>9,17,18</sup> . We have previously prepared α-FAPbI3 by spin-coating a precursor solution of FAPbI3 mixed with excess methylammonium chloride (MACl), and achieved a certified efficiency of 23.48% for the resulting mesoporous FAPbI3 PSC<sup>17</sup> . By fully exploiting the absorption spectrum of FAPbI3 together with proper light management, a certified efficiency of 23.73% was reported<sup>18</sup> —approaching the theoretical maximum—with a short-circuit current density ( _J_ sc) of 26.7 mA cm<sup>−2</sup> . However, the open-circuit voltage ( _V_ oc) of around 1.15 V for FAPbI3 PSCs still lags behind the radiative limit<sup>9,18</sup> , which suggests that more work is needed to further reduce the density of defects in the FAPbI3 perovskite films to suppress the non-radiative recombination of charge carriers. 

> 1Department of Energy Engineering, School of Energy and Chemical Engineering, Ulsan National Institute of Science and Technology (UNIST), Ulsan, Republic of Korea. 2Laboratory of Photonics and Interfaces, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland.<sup>3</sup> Laboratory of Photomolecular Science, Institute of Chemical Sciences Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland.<sup>4</sup> Korea Institute of Energy Research (KIER), Ulsan, Republic of Korea. 5Laboratory of Computational Chemistry and Biochemistry, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland. 6Laboratory of Magnetic Resonance, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland. 7Shanghai Synchrotron Radiation Facility (SSRF), Zhangjiang Lab, Shanghai Advanced Research Institute, Chinese Academy of Sciences, Shanghai, P. R. China.<sup>8</sup> Laboratory for Molecular Engineering of Optoelectronic Nanomaterials, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland.<sup>9</sup> Department of Chemistry and Research Institute of Basic Sciences, Kyung Hee University, Seoul, Republic of Korea.<sup>10</sup> Present address: Department of Chemistry, Ångström Laboratory, Uppsala University, Uppsala, Sweden.<sup>11</sup> These authors contributed equally: Jaeki Jeong, Minjin Kim, Jongdeuk Seo, Haizhou Lu.<sup>✉</sup> e-mail: anders.hagfeldt@uu.se; kimds@kier.re.kr; michael.graetzel@epfl.ch; jykim@unist.ac.kr 

Nature | Vol 592 | 15 April 2021 | **381** 

## Article 



<!-- Start of picture text -->
a 2.5 c e 25 800<br>Reference Reference<br>2% Fo-FAPbI3 700<br>2.0 4% Fo-FAPbI3 20 FTO 600<br>1.5 15 500<br>Cross-sectional SEM 400<br>1.0 10 300<br>(100)δ 200<br>0.5 5<br>100<br>0.0 Top-view SEM 0<br>600 700 800 900 –5 0 5 10 15 20<br>Wavelength (nm) q xy (nm –1 )<br>b d f 25 800<br>1.00.8 2% Fo-FAPbI3 (210)α 700<br>20<br>0.6 (200)α 600<br>0.4 Cross-sectional SEM 15 (111)(110)αα 500400<br>10 (100)α 300<br>0.2 Reference (001)PbI2 200<br>2% Fo-FAPbI3 5 100<br>4% Fo-FAPbI3 Top-view SEM<br>0<br>0 500 1,000 1,500 2,000 –5 0 5 10 15 20<br>Time (ns) q xy (nm –1 )<br>–1 (nm) q z<br>Absorbance (a.u.) PL intensity (a.u.)<br>–1 (nm) q z<br>Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Characterization of the FAPbI3 films. a** , UV–vis absorption and photoluminescence (PL) spectra of the FAPbI3 films. **b** , Time-resolved photoluminescence of the FAPbI3 films. **c** , **d** , SEM images of the reference 

FAPbI3 ( **c** ) and 2% Fo-FAPbI3 ( **d** ) films. The insets show cross-sectional SEM images. Scale bar, 2 μm. **e** , **f** , Two-dimensional grazing-incidence XRD patterns of the reference ( **e** ) and 2% Fo-FAPbI3 ( **f** ) films. 

Bromide, chloride (Cl<sup>−</sup> ) and thiocyanate (SCN<sup>−</sup> ) anions have commonly been used to improve the crystallinity and stability of perovskite films<sup>8,9,11,17–22</sup> . Another pseudo-halide anion, formate (HCOO<sup>−</sup> ), has also been investigated in connection with MAPbI3 PSCs<sup>23–26</sup> . Two studies<sup>23,24</sup> reported that MAHCOO improves the quality of MAPbI3 films by controlling the growth of the perovskite crystals, while others<sup>25,26</sup> reported that formic acid accelerates the crystallization of perovskites based on MA cations. Previous work has therefore mainly dealt with the effect of formate on the morphology, nucleation and growth of MAPbI3. There has also been a recent report of a highly fluorescent methylammonium lead bromide and formate mixture in water<sup>27</sup> . However, a fundamental understanding of the effects of formate on perovskite films has yet to be achieved. 

Here we uncover the key role of HCOO<sup>−</sup> anions in removing halide vacancies, which are the predominant lattice defects in FAPbI3 perovskite films. This enables the PCE of the PSC to exceed 25%, combined with a high operational stability and external quantum efficiency (EQE) of electroluminescence (EQEEL) that exceeds 10%. Iodide vacancies are also the principal cause of the unwanted ionic conductivity of metal halide perovskites, which has deleterious effect on their operational stability. We provide insight into the mode of formate intervention. Formate is small enough to fit into the iodide vacancy<sup>22</sup> , thereby eliminating a prevalent and notorious defect in the metal halide perovskite that accelerates the non-radiative recombination of photogenerated charge carriers, in turn decreasing both the fill factor and the _V_ oc of a solar cell. We generated FAPbI3 perovskite films with improved crystallinity and larger grain size by introducing 2% formamidine formate (FAHCOO) into the precursor solution. The defect passivation and the improved crystallinity are essential to attain the levels of efficiency and stability that are demonstrated by our FAPbI3-based PSCs. 

### **Characterization of the perovskite films** 

The reference FAPbI3 film, hereafter denoted ‘reference’, was prepared as previously reported using a precursor solution containing a mixture of FAPbI3 powder with 35 mol% additional MACl<sup>17</sup> . For the formate-doped FAPbI3 (Fo-FAPbI3) film, _x_ mol% ( _x_ ≤ 4) FAHCOO was added to the reference precursor solution (for experimental details, see Supplementary Information). At a later stage in this work, we quantify the amount of MA 

in the resulting perovskite material to be 5%, but for simplicity we refer to this sample as FAPbI3. Figure 1a shows the ultraviolet–visible (UV–vis) absorption and photoluminescence spectra of the FAPbI3 perovskite films ( _x_ = 0, 2 and 4). The absorption threshold and photoluminescence peak position were identical for all films; however, there was an obvious decrease in absorbance for the 4% Fo-FAPbI3 film. We derived a bandgap of 1.53 eV for the films using the Tauc plot (Extended Data Fig. 1a). Fig. 1b shows the time-resolved photoluminescence of the FAPbI3 perovskite films. The 2% Fo-FAPbI3 perovskite film showed a slower photoluminescence decay than the reference, which indicates a reduced non-radiative recombination rate due to a reduction in trap-mediated bulk or surface recombination. By contrast, the 4% Fo-FAPbI3 perovskite film showed a faster photoluminescence decay than the reference. A full photoluminescence decay up to 4 μs is shown in Extended Data Fig. 1b. A quantitative analysis of the time-resolved photoluminescence is presented in Supplementary Note 1. 

Scanning electron microscopy (SEM) measurements were performed to investigate the morphology of the perovskite film. Compared to the reference film (Fig. 1c), the 2% Fo-FAPbI3 film (Fig. 1d) had a slightly larger grain size of up to 2 μm (Extended Data Fig. 1c). The insets of Fig. 1c, d show the cross-sectional SEM images of the corresponding perovskite films. Both the reference and 2% Fo-FAPbI3 films showed monolithic grains from the top to the bottom. Extended Data Fig. 1d, e shows the irregular grain size of the 4% Fo-FAPbI3 films. Atomic force microscopy measurements (Extended Data Fig. 1f, g) revealed a surface roughness of 41.66 nm and 57.47 nm for the reference and 2% Fo-FAPbI3 films, respectively. The slightly increased surface roughness of the 2% Fo-FAPbI3 film is probably due to the slightly increased grain size. X-ray diffraction (XRD) measurements (Extended Data Fig. 1h) showed identical peak positions at around 13.95° and 27.85° for both the reference and the Fo-FAPbI3 perovskite films, corresponding to the α-phase of FAPbI3. However, the XRD pattern of the 4% Fo-FAPbI3 film showed additional peaks, which are assigned to fluorine-doped tin oxide (FTO) substrates and different orientations of α-FAPbI3. The broader and lower-intensity diffraction peaks—resulting in a higher relative noise level—indicate a poor crystallinity, which is consistent with the poor optical measurements of the 4% Fo-FAPbI3 film described above. Synchrotron-based two-dimensional grazing-incidence XRD measurements were also obtained for the FAPbI3 films at a relative 

**382** | Nature | Vol 592 | 15 April 2021 



<!-- Start of picture text -->
a b<br>(1) (1)<br>FAHCOO<br>δ α-FAPbI3<br>(2)<br>(2) δ-FAPbI3<br>α-FAPbI3 +<br>5% FABr (3)<br>α-FAPbI3<br>(3)<br>5% FAHCOOα-FAPbI3 + (4) ×8 5% FAHCOOα-FAPbI3 +<br>3,000 2,000 1,000 0 –1,000 200 180 160 140 120 100 80<br>207Pb chemical shift (ppm) 13C chemical shift (ppm)<br>c d<br>HCOO –<br>Cl –<br>Pb 2+<br>Br –<br>I –<br>FA +<br>I –<br>HCOO –<br>BF4–<br>0.0 0.5 1.0 1.5 2.0 2.5 3.0<br>Binding affinity towards<br>iodide vacancy site (eV)<br><!-- End of picture text -->

**Fig. 2 | Solid-state NMR spectra and molecular dynamics simulations. a** ,<sup>207</sup> Pb solid-state NMR spectra (recorded at 298 K and a magic-angle spinning (MAS) rate of 15 kHz) of α-FAPbI3 (1), α-FAPbI3 + 5% FABr (2) and α-FAPbI3 + 5% FAHCOO (3). In (1), a small amount of the δ-phase can be seen, but this is distinct from the shoulder seen in (2), and is not seen in (3). **b** ,<sup>13</sup> C solid-state NMR spectra (recorded at 100 K and 12 kHz MAS) of FAHCOO (1), δ-FAPbI3 (2), α-FAPbI3 (3) and α-FAPbI3 + 5% FAHCOO (4) (the top trace in (4) is an eightfold magnification). **c** , Calculated structure illustrating the passivation of an I<sup>−</sup> vacancy at the FAPbI3 surface by a HCOO<sup>−</sup> anion. All chemical species are shown in ball-and-stick representation. Pb<sup>2+</sup> , yellow; I<sup>−</sup> , pink; oxygen atoms, red; carbon, green; nitrogen, blue; hydrogen, white. **d** , The relative interaction strengths of different anions with the I<sup>−</sup> vacancy at the surface. 

humidity of around 100% at 30 °C in air. Figure 1e clearly shows the presence of the δ-phase in the reference, whereas this phase was absent in the 2% Fo-FAPbI3 film (Fig. 1f). This provides strong evidence that FAHCOO stabilizes the α-phase of FAPbI3 against humidity. In addition, the full-width at half-maximum of the α-phase peak was decreased for the 2% Fo-FAPbI3 film, which is hereafter denoted as ‘target’. The integrated one-dimensional diffraction intensity is shown in Extended Data Fig. 1i. We infer from these data that including 2% FAHCOO in the synthesis of the FAPbI3 films strongly enhances their crystallinity. 

We obtained solid-state nuclear magnetic resonance (NMR) spectroscopy measurements in order to elucidate the molecular mechanisms that lead to the improvements afforded by the HCOO<sup>−</sup> anions. We prepared the samples by mixing formamidinium iodide and PbI2 powders with 5 mol% excess FAHCOO using a mechano-synthesis method. Experimental details are provided in Methods. The<sup>207</sup> Pb spectrum is sensitive to the nature of the anions that are coordinated to Pb<sup>2+</sup> in the perovskite crystal<sup>28</sup> . Figure 2a shows the<sup>207</sup> Pb NMR spectrum of α-FAPbI3, in which the<sup>207</sup> Pb resonance appears at 1,543 ppm. The addition of 5% FABr results in a notable shoulder on the low-frequency side of the resonance, as shown in Fig. 2a (2). This shoulder corresponds to 207Pb in a [PbBrI5] site, which resonates at lower frequency than in a [PbI6] site, because<sup>207</sup> Pb in a [PbBr6] site in FAPbBr3 resonates at 510 ppm<sup>28</sup> . However, the<sup>207</sup> Pb resonance of α-FAPbI3 remained the same even when 5% FAHCOO was added during the synthesis, which is strong evidence that HCOO<sup>−</sup> does not substitute for iodide anions in the α-FAPbI3 lattice. This is also supported by the density functional theory (DFT) calculations of the formation energy (Supplementary Note 2). 

To explore the local environment of the HCOO<sup>−</sup> anions in the Fo-FAPbI3 perovskite,<sup>1</sup> H–<sup>13</sup> C cross-polarization experiments<sup>29</sup> were performed at 100 K. Figure 2b (1) shows<sup>13</sup> C resonance signals at 167.8 ppm and 158.5 ppm for the HCOO<sup>−</sup> and FA<sup>+</sup> environments in FAHCOO, respectively. Figure 2b, (2) and (3) show the δ-FAPbI3 and α-FAPbI3 and<sup>13</sup> C resonances 

at 157.6 ppm and 153.4 ppm, respectively. Upon mixing 5 mol% FAHCOO with FAPbI3, the<sup>13</sup> C signal of α-FAPbI3 remained unchanged at 153.4 ppm (Fig. 2b (4)); this further corroborates the lack of substitution of iodide by HCOO<sup>−</sup> inside the FAPbI3 lattice, which would broaden the<sup>13</sup> C resonance of FAPbI3. The HCOO<sup>−</sup> peak, however, exhibited considerable broadening—indicative of a distribution of local environments—in contrast to the well-defined environment in crystalline FAHCOO. This is consistent with interaction of the HCOO<sup>−</sup> anion with undercoordinated Pb<sup>2+</sup> to passivate iodide vacancies that are present at the surface or the grain boundaries of the perovskite, as predicted by molecular dynamics simulations (see below). For the spin-coated target thin films, the formate<sup>13</sup> C signal is less intense, appearing as a shoulder on the α-FAPbI3 peak (Extended Data Fig. 2a, b). This is due to a combination of the lower initial formate concentration and—because the exposed area is greater—the potentially greater evaporation of formate during annealing in the thin films compared to that in the powders; however, it should be noted that cross-polarization spectra are not quantitative. The presence of FAHCOO in the α-FAPbI3 films is also supported by the time-of-flight secondary-ion mass spectrometry measurements (Extended Data Fig. 2c, d). We further quantified the composition of the spin-coated target films using directly detected 13C NMR at 100 K (Extended Data Fig. 2e). Integration of the FA+ and MA+ resonances in the quantitative<sup>13</sup> C spectrum yields a concentration of MA<sup>+</sup> in the final film of 5.1% (Supplementary Note 3). 

### **Molecular dynamics simulations** 

To explore in more detail the unique role of HCOO<sup>−</sup> anions, we performed ab initio molecular dynamics simulations of a homogeneous mixture of different ions in the precursor solution (see Extended Data Fig. 3a, b and Supplementary Note 4)—comprising Pb<sup>2+</sup> , I<sup>−</sup> , HCOO<sup>−</sup> and FA<sup>+</sup> —and found that HCOO<sup>−</sup> anions coordinate strongly with Pb<sup>2+</sup> cations (Supplementary Video 1). This strong coordination might help to slow the growth process, resulting in larger stacked grains of the perovskite film; this is validated by the in situ images of the perovskite films without annealing (Supplementary Fig. 1). Compared to the reference film, the target film showed a slower colour change from brown to black. We also performed molecular dynamics simulations to understand the surface passivation effects of HCOO<sup>−</sup> anions. Extended Data Fig. 3c shows a super cell of a α-FAPbI3 perovskite slab, in which surface iodides are replaced by formate anions. We found that HCOO<sup>−</sup> anions can form a hydrogen-bonded network with FA<sup>+</sup> ions (Extended Data Fig. 3d, Supplementary Video 2), in agreement with the hydrogen bonding that is observed in FAHCOO crystal structures<sup>30</sup> . In addition, HCOO<sup>−</sup> anions can also form a bonding network on the Pb<sup>2+</sup> ion-terminated surface, owing to their strong affinity towards lead (Extended Data Fig. 3e, Supplementary Video 3). Figure 2c shows a calculated structure that illustrates an HCOO<sup>−</sup> anion passivating an I<sup>−</sup> vacancy at the FAPbI3 surface. I<sup>−</sup> vacancy defects are the most deleterious defects for halide perovskites. They act as electron traps—inducing the non-radiative recombination of charge carriers—and are responsible for the ionic conductivity of perovskites that causes operational instability. We estimated the relative binding affinities of different anions to I<sup>−</sup> vacancies at the surface (Extended Data Fig. 4).The energies shown in Fig. 2d reveal that HCOO<sup>−</sup> has the highest binding energy to I<sup>−</sup> vacant sites in comparison with Cl<sup>−</sup> , Br<sup>−</sup> , I<sup>−</sup> and BF4−. Furthermore, we also calculated the bonding energies of FA<sup>+</sup> cations at the interface with HCOO<sup>−</sup> anions and with other anions (Extended Data Fig. 5, Supplementary Note 5). We found that FA<sup>+</sup> cations at the interface form stronger bonds with HCOO<sup>−</sup> than with the other anions. We therefore conclude that the HCOO<sup>−</sup> anion acts by eliminating anion-vacancy defects. 

### **Photovoltaic performance of the PSCs** 

We further explored the photovoltaic performance of the PSCs. FAPbI3 PSCs were fabricated using a configuration as illustrated in Fig. 3a. 

Nature | Vol 592 | 15 April 2021 | **383** 

## Article 



<!-- Start of picture text -->
a b 28 c 12<br>Au 24 10 TargetReference<br>Spiro-OMeTAD 20 8<br>Perovskite OAI 16<br>6<br>12 Target (reverse)<br>m-TiO2 8 Target (forward)Reference (reverse) 4<br>FTO c-TiO2 4 Reference (forward) 2<br>Glass 0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 22 23 24 25 26<br>Voltage (V) Efficiency (%)<br>d 100 30 e 15 f 1.25<br>Target Target<br>80 25 12 Reference 1.20 Reference<br>60 TargetReference 20 9 10.1% 1.15 1.18  k B T / q<br>15 1.10<br>40 10 6 1.05 1.52  k B T / q<br>20 5 3 2.2% 1.00<br>0 0 0 0.95<br>300 400 500 600 700 800 900 0.01 0.1 1 10 100 10 100<br>Wavelength (nm) Current density (mA cm –2 ) Light intensity (mW cm –2 )<br>Counts<br>–2Current density (mA cm)<br>EQE (%) EQE (%)EL  (V) V oc<br>–2 (mA cm)Integrated  J sc<br><!-- End of picture text -->

**Fig. 3 | Characterization of the photovoltaic performance of the FAPbI3 PSCs. a** , The configuration of a typical FAPbI3 PSC device. Spiro-OMeTAD, 2,2′,7,7′-tetrakis( _N_ , _N_ -di- _p_ -methoxyphenylamine)9,9′-spirobifluorene. **b** , _J_ – _V_ curves of the reference and target PSCs under both reverse and forward voltage scans. **c** , The distribution of the PCEs of the reference and target PSCs. **d** , EQE and the integrated _J_ sc of the reference and target PSCs. **e** , EQEEL measurements of the reference and target PSCs under current densities from 0.01 mA cm<sup>−2</sup> to 100 mA cm<sup>−2</sup> . **f** , The relationship between the measured _V_ oc and light intensity for the reference and target PSCs. 

illumination), respectively. Treatment with formate therefore results in a fivefold reduction in the non-radiative recombination rate. The _V_ oc of 1.21 V that we obtained for the target cell (Extended Data Fig. 6a) is 96% of the Shockley–Queisser limit of 1.25 V<sup>32,33</sup> —to our knowledge, this is the highest value yet obtained. To further confirm the role of formate, we also measured the performance of devices fabricated using formamidinium acetate as an additive (Extended Data Fig. 6b); however, this additive had a negative effect on performance. For the devices fabricated without MACl additives or passivation layers, those that contained formate still showed an advantage (Extended Data Fig. 6c, d). 

Figure 3b shows current density ( _J_ )–voltage ( _V_ ) curves of the reference and target PSCs under both forward and reverse scans. The reference cell had a maximum PCE of 23.92% with a _J_ sc of 25.72 mA cm<sup>−2</sup> , a _V_ oc of 1.153 V and a fill factor of 80.69%. The target PSC had a maximum PCE of 25.59% with a _J_ sc of 26.35 mA cm<sup>−2</sup> , a _V_ oc of 1.189 V and a fill factor of 81.7%. The detailed parameters are summarized in Extended Data Table 1. A statistical distribution of the measured PCE of the reference and target PSCs are shown in Fig. 3c. To verify the efficiency, we sent one of our best target PSCs to an accredited photovoltaic test laboratory (Newport, USA) for certification. Supplementary Fig. 2 represents a certified quasi-steady-state efficiency of 25.21%, with a _V_ oc of 1.174 V, a _J_ sc of 26.25 mA cm<sup>−2</sup> and a fill factor of 81.8%. 

Supplementary Fig. 3 shows a linear relationship (with a slope of approximately 0.95) between _J_ sc and light intensity for both the reference and target PSCs—indicating good charge transport and negligible bimolecular recombination—and Fig. 3f shows a linear relationship between _V_ oc and the logarithm of light intensity. We fitted the data points with a slope of _η_ id _k_ B _T_ / _q_ , where _η_ id is the ideality factor, _k_ B is the Boltzmann constant, _T_ is temperature and _q_ is the electron charge. The reference cell had an _η_ id of 1.52, whereas that of the target cell was 1.18—lower than the previously reported value<sup>33</sup> of 1.27. A summary of the detailed photovoltaic parameters can be found in Extended Data Table 2. The reduction in _η_ id, as well as the space-charge-limited current measurements (Supplementary Fig. 4), further support our findings of a reduction in trap-assisted recombination<sup>34,35</sup> . Because the fill factor 

EQE measurements (Fig. 3d) were performed to verify the measured _J_ sc. The EQE of the target cell was higher than that of the reference cell over the whole visible-light absorption region. By integrating the EQE over the AM 1.5G standard spectrum, the projected _J_ sc of the reference and target PSCs are 25.75 mA cm<sup>−2</sup> and 26.35 mA cm<sup>−2</sup> , respectively, which well match the measured _J_ sc under the solar simulator. Figure 3e shows the EQEEL of the PSCs. It is known that the photovoltage of a solar cell is directly related to the ability to extract its internal luminescence<sup>31</sup> . EQEEL values have previously been successfully used to predict the _V_ oc of PSCs<sup>32</sup> . In this case, the EQEEL of the reference cell was 2.2%, whereas that of the target cell was 10.1% for injection current densities of 25.5 mA cm<sup>−2</sup> and 26.5 mA cm<sup>−2</sup> (corresponding to the _J_ sc measured under 1 sun 



<!-- Start of picture text -->
a b<br>1.0 1.0<br>0.8 0.8<br>0.6 0.6<br>0.4 20% relative humidity 0.4 60 °C<br>Target, PCEinitial = 25.73% Target, PCEinitial = 25.15%<br>0.2 Reference, PCEinitial = 23.86% 0.2 Reference, PCEinitial = 23.75%<br>0.0 0.0<br>0 200 400 600 800 1,000 0 200 400 600 800 1,000<br>Time (h) Time (h)<br>c d<br>25 1.0<br>0.8<br>20<br>0.6<br>15 MPP MPP<br>(Xenon lamp, 100 mW cm –2 ) 0.4 (LED lamp, 100 mW cm –2 )<br>10 Target, PCEinitial = 24.74% 0.2 Target, PCEinitial = 23.49%<br>Reference, PCEinitial = 23.57% Reference, PCEinitial = 21.82%<br>5 0.0<br>0 2 4 6 8 10 12 0 100 200 300 400<br>Time (h) Time (h)<br>Normalized PCE Normalized PCE<br>PCE (%)<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4 | Stability of the FAPbI3 PSCs. a** , The shelf-life stability of the reference and target PSCs. **b** , The heat stability of the reference and target PSCs. **c** , The operational stability of the reference and target PSCs, showing high performance. **d** , The long-term operational stability of the reference and target PSCs. 

**384** | Nature | Vol 592 | 15 April 2021 

critically depends<sup>36</sup> on _η_ id, the reduction in _η_ id that we observe here also contributes to the increase in fill factor measured for the target PSCs. 

### **Shelf-life and operational stability of the PSCs** 

To assess the stability of our PSCs, we measured first their shelf life by storing the unencapsulated devices in the dark at 25 °C and 20% relative humidity. Figure 4a shows that the PCE of the reference cell decreased by about 35% after 1,000 h aging, whereas the target cell showed a degradation of only 10% over this time. A heat-stability test was also performed by annealing the unencapsulated PSC devices at 60 °C under 20% relative humidity. Figure 4b shows that the target cell retained around 80% of its initial efficiency after 1,000 h aging, whereas the reference cell retained only about 40%. 

We further investigated the operational stability of the PSCs by aging the unencapsulated devices under a nitrogen atmosphere, using maximum power point (MPP) tracking under a simulated 1-sun illumination. Figure 4c shows the PCE of the PSCs under continuous light soaking using a xenon lamp. The PCE of the target cell remained above 24% after 10-h MPP tracking, whereas that of the reference cell decreased to 22.8%. Figure 4d shows the long-term operational stability of the PSCs. The PCE of the reference cell decreased by about 30%, whereas the target cell only lost around 15% of its initial efficiency. Note that during this experiment the temperature of the PSCs was measured to be around 35 °C, as we did not cool the cells during illumination. Compared to the target PSC, the reference cell showed a considerable decrease in _J_ sc and fill factor over the 450-h MPP tracking test (Extended Data Fig. 7), which suggests that reference perovskite layer is less stable. We attribute the decline in fill factor to a de-doping of the hole conductor due to Li<sup>+</sup> ion migration under illumination<sup>37</sup> . 

The improvement in thermal and operational stability of the target cell compared with the reference cell is ascribed to the better crystallinity of the perovskite film and a reduced concentration of halide defects, because NMR experiments show that formate is not incorporated into the bulk of the perovskite. It is known that crystallinity is crucial for the stability of the perovskites, because the main degradation process starts from defects near the grain boundaries. The high crystallinity and large grain size of the formate-containing perovskite films—as validated by SEM and XRD measurements—will contribute to their greater stability and performance. Our simulations and calculations suggest that formate anions have the highest binding affinity among all halides and pseudo halides for iodide vacancy sites, and are therefore the best candidates to eliminate the most abundant and deleterious lattice defects present in halide perovskite films. This results in a marked reduction of trap-mediated non-radiative recombination, which we validated by EQEEL, time-resolved photoluminescence, _n_ id, and SCLC measurements. A low level of halide vacancies is beneficial for the stability of solar cells, because halide vacancies can lead to degradation as a result of photoinduced iodine loss, especially under light illumination. 

Overall, we demonstrate α-FAPbI3-based PSCs with a PCE of 25.6% (certified 25.2%) and high stability, achieved through solution processing by introducing 2% formamidinium formate into the FAPbI3 perovskite precursor solution. Our molecular dynamics simulations, together with solid-state NMR spectroscopy analysis and in-depth optoelectronic device characterization, provide an understanding of the role of HCOO<sup>−</sup> anions as passivating agents for FAPbI3 perovskites. Our findings pave the way for facile access to high-performance PSCs approaching their theoretical efficiency limit. 

1. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc_ . **131** , 6050–6051 (2009). 

2. Grätzel, M. The light and shade of perovskite solar cells. _Nat. Mater_ . **13** , 838–842 (2014). 3. Park, N.-G. et al. Towards stable and commercially available perovskite solar cells. _Nat. Energy_ **1** , 16152 (2016). 

4. Correa-Baena, J. P. et al. Promises and challenges of perovskite solar cells. _Science_ **358** , 739–744 (2017). 

5. Lu, H., Krishna, A., Zakeeruddin, S. M., Grätzel, M. & Hagfeldt, A. Compositional and interface engineering of organic-inorganic lead halide perovskite solar cells. _iScience_ **23** , 101359 (2020). 

6. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci_ . **7** , 982–988 (2014). 

7. Pellet, N. et al. Mixed-organic-cation perovskite photovoltaics for enhanced solar-light harvesting. _Angew. Chem. Int. Ed_ . **53** , 3151–3157 (2014). 

8. Jeon, N. J. et al. Compositional engineering of perovskite materials for high-performance solar cells. _Nature_ **517** , 476–480 (2015). 

9. Lu, H. et al. Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. _Science_ **370** , eabb8985 (2020). 

10. De Wolf, S. et al. Organometallic halide perovskites: sharp optical absorption edge and its relation to photovoltaic performance. _J. Phys. Chem. Lett_ . **5** , 1035–1039 (2014). 

11. Stranks, S. D. et al. Electron-hole diffusion lengths exceeding 1 micrometer in an organometal trihalide perovskite absorber. _Science_ **342** , 341–344 (2013). 

12. Herz, L. M. et al. Charge-carrier mobilities in metal halide perovskites: fundamental mechanisms and limits. _ACS Energy Lett_ . **2** , 1539–1548 (2017). 

13. NREL. _Best Research-Cell Efficiency Chart_ https://www.nrel.gov/pv/cell-efficiency.html (accessed 17 March 2021). 

14. Zheng, X. et al. Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131–140 (2020). 

15. Liu, Z. et al. A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. _Nat. Energy_ **5** , 596–604 (2020). 

16. Saliba, M. et al. Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. _Energy Environ. Sci_ . **9** , 1989–1997 (2016). 

17. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ **3** , 2179–2192 (2019). 

18. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

19. Yang, S. et al. Thiocyanate assisted performance enhancement of formamidinium based planar perovskite solar cells through a single one-step solution process. _J. Mater. Chem. A_ **4** , 9430–9436 (2016). 

20. Kim, D. H. et al. Bimolecular additives improve wide-band-gap perovskites for efficient tandem solar cells with CIGS. _Joule_ **3** , 1734–1745 (2019). 

21. Kim, D. et al. Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. _Science_ **368** , 155–160 (2020). 

22. Walker, B., Kim, G. H. & Kim, J. Y. Pseudohalides in lead-based perovskite semiconductors. _Adv. Mater_ . **31** , 1807029 (2019). 

23. Moore, D. T. et al. Direct crystallization route to methylammonium lead iodide perovskite from an ionic liquid. _Chem. Mater_ . **27** , 3197–3199 (2015). 

24. Seo, J. et al. Ionic liquid control crystal growth to enhance planar perovskite solar cells efficiency. _Adv. Energy Mater_ . **6** , 1600767 (2016). 

25. Nayak, P. K. et al. Mechanism for rapid growth of organic–inorganic halide perovskite crystals. _Nat. Commun_ . **7** , 13303 (2016). 

26. Meng, L. et al. Improved perovskite solar cell efficiency by tuning the colloidal size and free ion concentration in precursor solution using formic acid additive. _J. Energy Chem_ . **41** , 43–51 (2020). 

27. Khan, Y. et al. Waterproof perovskites: high fluorescence quantum yield and stability from a methylammonium lead bromide/formate mixture in water. _J. Mater. Chem. C_ **8** , 5873– 5881 (2020). 

28. Askar, A. M. et al. Composition-tunable formamidinium lead mixed halide perovskites via solvent-free mechanochemical synthesis: decoding the Pb environments using solid-state NMR spectroscopy. _J. Phys. Chem. Lett_ . **9** , 2671–2677 (2018). 

29. Kubicki, D. J. et al. Cation dynamics in mixed-cation (MA) _x_ (FA)1− _x_ PbI3 hybrid perovskites from solid-state NMR. _J. Am. Chem. Soc_ . **139** , 10055–10061 (2017). 

30. Zhou, Z. et al. Synthesis, microwave spectra, X-ray structure, and high-level theoretical calculations for formamidinium formate. _J. Chem. Phys_ . **150** , 094305 (2019). 

31. Ross, R. et al. Some thermodynamics of photochemical systems. _J. Chem. Phys_ . **46** , 4590–4593 (1967). 

32. Tress, W. et al. Predicting the open-circuit voltage of CH3NH3PbI3 perovskite solar cells using electroluminescence and photovoltaic quantum efficiency spectra: the role of radiative and non-radiative recombination. _Adv. Energy Mater_ . **5** , 1400812 (2015). 

33. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460–466 (2019). 

34. Yang, D. et al. Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. _Energy Environ. Sci_ . **9** , 3071–3078 (2016). 

35. Kuik, M., Koster, L. J., Wetzelaer, G. A. & Blom, P. W. Trap-assisted recombination in disordered organic semiconductors. _Phys. Rev. Lett_ . **107** , 256805 (2011). 

36. Green, M. Accuracy of analytical expressions for solar cell fill factors. _Solar Cells_ **7** , 337– 340 (1982). 

### **Online content** 

Any methods, additional references, Nature Research reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-021-03406-5. 

37. Wang, Y. et al. Stabilizing heterostructures of soft perovskite semiconductors. _Science_ **365** , 687–691 (2019). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2021 

Nature | Vol 592 | 15 April 2021 | **385** 

## Article **Methods** 

#### **Materials** 

Formamidine acetate salt (99%), hydroiodic acid (HI, 57 wt% in water), titanium diisopropoxide bis(acetylacetonate), 2-propanol (anhydrous, 99.5%), chlorobenzene (anhydrous, 99.8%), _N_ , _N_ -dimethylformamide (DMF, anhydrous 99.8%,), dimethyl sulfoxide (DMSO, >99.5%), 2-methoxyethanol (anhydrous, 99.8%) and formic acid were procured from Sigma-Aldrich and used as received. Methylamine hydrochloride (MACl, 98%) was procured from Acros Organics. Fluorine-doped tin oxide on glass (FTO glass, 7 Ω sq<sup>–1</sup> ) was obtained from Asahi. Ethanol (absolute, 99.9%) was procured from Changshu Yangyuan Chemicals. Diethyl ether (extra pure grade) was procured from Duksan. TiO2 paste (SC-HT040) was procured from ShareChem. Lead iodide (PbI2, 99.999%) was purchased from TCI. 

#### **Materials synthesis** 

Formamidinium iodide (FAI) was synthesized as reported elsewhere<sup>8</sup> . In brief, 25 g formamidine acetate was directly mixed with 50 ml hydroiodic acid in a 500 ml round-bottomed flask with vigorous stirring. A light-yellow powder was obtained by evaporating the solvent at 80 °C for 1 h in a vacuum evaporator. The resulting powder was then dissolved in ethanol and precipitated using diethyl ether. This procedure was repeated three times until white powder was obtained, and the white powder was recrystallized from ethanol and diethyl ether in a refrigerator. After recrystallization, the resulting powders were collected and dried at 60 °C for 24 h. As reported previously<sup>18</sup> , black FAPbI3 powder was synthesized by mixing the synthesized FAI (0.8 M) with PbI2 (1:1 molar ratio) in 30 ml of 2-methoxyethanol with stirring. The yellow mixed solution was heated with a stirring bar at 120 °C and then recrystallized using the retrograde method. The resulting powder was filtered using a glass filter and baked at 150 °C for 30 min. Formamidine formate (FAHCOO) was synthesized by dissolving formamidine acetate in an excess of formic acid. The resulting solution was dried at 80 °C by rotary evaporation to remove most of the formic acid and acetic acid. A wet formamidine formate powder was obtained. This wet powder was recrystallized with a small amount of ethanol. A transparent, plate-like crystal was formed after the recrystallization, which was consecutively dried in vacuum for 10 h to obtain the final formamidine formate. Bulk perovskite samples for solid-state NMR are prepared by grinding the reactant (FAI and PbI2 with FABr or FAHCOO as appropriate) in an electric ball (Retsch Ball Mill MM-200) for 30 min at 25 Hz, before annealing at 150 °C for 15 min. 

#### **Substrate preparation** 

Asahi FTO glass (1.8 mm, 7 Ω sq<sup>–1</sup> ) was used as the substrate for the devices. The substrates were cleaned using the RCA-2 (H2O2-HCl-H2O) procedure for 15 min to remove metal-ion impurities. Then, the substrates were cleaned sequentially with acetone, ethanol and isopropyl alcohol (IPA) in an ultrasonic system for 15 min. To deposit the compact TiO2 (c-TiO2) layer, 60 ml of a titanium diisopropoxide bis(acetylacetonate)/ethanol (1:10 volume ratio) solution was applied using the spray-pyrolysis method. Prior to the spraying process, the FTO substrates were placed on a hot plate and the temperature was increased to 450 °C rapidly. After the spray pyrolysis step, the substrates were stored at 450 °C for 1 h and then slowly cooled to room temperature. On top of the c-TiO2 layer, a mesoporous TiO2 (m-TiO2) layer was deposited by spin-coating a TiO2 paste dispersed in ethanol/terpineol (78:22 w/w). The TiO2 nanoparticles have a diameter of approximately 50 nm and were purchased from ShareChem. The FTO/c-TiO2 substrates prepared with m-TiO2 were heated at 500 °C on a hot plate for 1 h to remove organic compounds first, and then slowly cooled to 200 °C. 

#### **Device fabrication** 

For the fabrication of the perovskite layer, the whole process was carried out at controlled room temperature (25 °C) and humidity (20% relative 

humidity). The reference perovskite precursor solution was prepared by mixing 1,139 mg FAPbI3 and 35 mol% MACl in a mixture of DMF and DMSO (4:1). For the Fo-FAPbI3 perovskite film, extra FAHCOO was added to the reference solution in the range of 1–4 mol%. For each sample, 70 μl of the solution was spread over the m-TiO2 layer at 6,000 rpm for 50 s with 0.1 s ramping. During the spin-coating, 1 ml diethyl ether was dripped after spinning for 10 s. The perovskite film was then dried on a hot plate at 150 °C for 10 min immediately. See Supplementary Video 4 for details of the fabrication of perovskite films. After cooling the perovskite film on the bench, 15 mM of octylammonium iodide dissolved in IPA was spin-coated on top of the perovskite film at 3,000 rpm for 30 s. The hole-transport layer was deposited by spin-coating a Spiro-OMeTAD (Lumtech) solution at 4,000 rpm for 30 s. Details of the Spiro-OMeTAD solution was reported in the previous study<sup>18</sup> . Finally, a gold electrode was deposited on top of the Spiro-OMeTAD layer using a thermal evaporation system. The back and front contacts were formed with 100-nm-thick Au films deposited under a pressure of 10<sup>−6</sup> Torr. 

#### **Characterization of the solar cells** 

The solar cells without encapsulation were measured with a solar simulator (McScience, K3000 Lab solar cell _I-V_ measurement system, Class AAA) in a room with relative humidity below 25% at 25 °C. An anti-reflecting coating layer was used for the devices. The light intensity was calibrated to AM 1.5G (100 mW cm<sup>−2</sup> ) using a Si-reference cell certified by the National Renewable Energy Laboratory before performing measurements. No light soaking was applied before the potential _I_ – _V_ scans. All _J–V_ curves were measured using a reverse scan (from 1.25 V to 0 V) and a forward scan (from 0 V to 1.25 V) under a constant scan speed of 100 mV s<sup>−1</sup> . The stabilized power output was measured at the maximum power point using a xenon lamp light source. A non-reflective mask with an aperture area of 0.0804 cm<sup>2</sup> was used to cover the active area of the device to avoid the artefacts produced by the scattered light (the mask area is determined using a microscope). EQE measurements were obtained using a QEX7 system (PV Measurements). For the EQEEL measurements, different bias voltages or currents were applied to the PSCs with a BioLogic SP300 potentiostat. The emitted photon flux from the PSCs was recorded using a calibrated, large-area (1 cm<sup>2</sup> ) Si photodiode (Hamamatsu S1227-1010BQ). All measurements were performed in the ambient environment (40% relative humidity, 24 °C). 

#### **Characterization of the device stability** 

For the stability tests, all PSCs were used without encapsulation. The shelf-life stability was assessed by measuring the photovoltaic performance of PSCs every tens of hours. The thermal stability test was performed by ageing the solar cells on a hot plate at 60 °C at 20% relative humidity. The performance of the devices was periodically measured after cooling the devices to room temperature. The operational stability was performed with a BioLogic potentiostat under an LED or a lamp that was adjusted to AM 1.5G (100 mW cm<sup>−2</sup> ). The PSCs were masked and placed inside a homemade sample holder purged with continuous N2 flow. The devices were aged with a maximum point power tracking routine under continuous illumination. The temperature-control system was not activated during the measurements. _J_ – _V_ curves with reverse voltage scans were recorded every 30 min during the whole operational test. 

#### **Characterization of the perovskite film** 

UV–vis absorption spectra of the perovskite films were recorded on a UV-1800 (Shimadzu) spectrophotometer. The SEM images of the perovskite films were taken with a field-emission scanning electron microscope (FE-SEM, S-4800, Hitachi). XRD patterns of the perovskite films were performed using a D8 Advance (Bruker) diffractometer equipped with Cu K _α_ radiation ( _λ_ = 0.1542 nm) as the X-ray source. Steady-state photoluminescence and time-resolved photoluminescence measurements of the perovskite films were conducted using a 

PicoQuant FluoTime 300 (PicoQuant GmbH) equipped with a PDL 820 laser pulse driver. A pulsed laser diode ( _λ_ = 375 nm, pulse full-width at half-maximum <70 ps, repetition rate 200 kHz–40 MHz) was used to excite the perovskite sample. Surface roughness was assessed using a Cypher S atomic force microscope from Asylum Research under ambient conditions (24 °C, 50% relative humidity). An Olympus AC240-TS tip was used, and the system was operated under tapping mode. Two-dimensional grazing-incidence XRD of the perovskite films was performed at the BL14B1 beamline of the Shanghai Synchrotron Radiation Facility (SSRF) using X-rays with a wavelength of 0.6887 Å. Two-dimensional grazing-incidence XRD patterns were acquired by a MarCCD mounted vertically at a distance of around 632 mm from the sample with grazing-incidence angles of 0.4° and an exposure time of 30 s. For the time-of-flight secondary-ion mass spectrometry (TOF-SIMS) measurements, the reference and 2% Fo-FAPbI3 films were coated on a glass substrate using anti-solvent methods. The samples were analysed by TOF-SIMS using a hybrid IONTOF TOF-SIMS instrument. Depth profiling was accomplished with a three-lens 25-keV BiMn primary ion gun and a Bi3+ primary ion-beam cluster (1 pA pulsed beam current). Measurements used a caesium-ion beam for sputtering with an energy of 500 eV (sputtering current 1–23 nA). Profiling was completed with a 100 × 100 μm<sup>2</sup> primary-beam area and a 300 × 300 μm<sup>2</sup> sputter-beam raster. Non-interlaced mode was used to limit beam damage from the primary ion-beam (1 frame, 2 s sputter, 2 s pause). 

#### **Solid-state NMR measurements** 

Low-temperature (100 K)<sup>1</sup> H–<sup>13</sup> C cross-polarization and directly detected<sup>13</sup> C (125.8 MHz) NMR spectra, and room-temperature<sup>207</sup> Pb (104.7 MHz) NMR spectra were recorded on a Bruker Avance III 11.7 T spectrometer equipped with a 3.2-mm low-temperature CPMAS probe.<sup>207</sup> Pb and<sup>13</sup> C spectra were referenced to Pb(NO3)2 at –3,492 ppm and the CH2 resonance of solid adamantane at 38.48 ppm, respectively, at room temperature. Room temperature<sup>207</sup> Pb spectra were recorded with a Hahn echo and an effective recycle delay of 17 ms. The low-temperature<sup>1</sup> H–<sup>13</sup> C cross-polarization spectra of δ-FAPbI3 and α-FAPbI3 were recorded with 1 ms contact time, recycle delays of 1.5 s and 4 s, respectively, and 12 kHz MAS. The low-temperature<sup>1</sup> H–<sup>13</sup> C spectra of FAHCOO and Fo-FAPbI3 were recorded with 2 ms contact time, 10 s recycle delay and 12 kHz MAS. The quantitative, directly detected<sup>13</sup> C experiment on a scraped 2% Fo-FAPbI3 film was performed with a single pulse experiment, 12 kHz MAS and a 10 s recycle delay, which is more than 5 times the longitudinal relaxation time of<sup>13</sup> C (1 s). All<sup>13</sup> C spectra were acquired with 100 kHz<sup>1</sup> H decoupling. The low-temperature<sup>1</sup> H–<sup>13</sup> C cross-polarization spectrum of scraped 2% Fo-FAPbI3 thin-film was measured with 2 ms contact time, 4 s recycle delay and 12 kHz MAS. NMR characterization was performed with 5% Fo-FAPbI3, because the greater amount of formate in the sample provides higher sensitivity compared to 2% Fo-FAPbI3. MACl was not included in the mechanosynthesized samples for NMR spectroscopy, because this would lead to broadening of the<sup>13</sup> C and<sup>207</sup> Pb resonances of FAPbI3 (ref.<sup>29</sup> ), owing to different local 

environments with slightly different chemical shifts that arise from MA<sup>+</sup> substitution of nearest-neighbour—and more distant—A-site cations. This broadening would obscure the small changes in the<sup>207</sup> Pb and<sup>13</sup> C resonances that arise from the incorporation of formate. However, given that the incorporation of MA<sup>+</sup> ions has a minimal effect on the lattice structure, these findings also apply to the MA<sup>+</sup> -doped composition studied here. 

### **Data availability** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

### **Code availability** 

The code used for this study is available from the corresponding author upon reasonable request. 

**Acknowledgements** We thank W. R. Tress for discussions, and the staff at beamlines BL17B1, BL14B1, BL11B, BL08U and BL01B1 of the SSRF for providing the beamline, and the Swiss National Supercomputing Centre (CSCS) and EPFL computing center (SCITAS) for their support. This research was supported by the Technology Development Program to Solve Climate Changes of the National Research Foundation (NRF) funded by the Ministry of Science, ICT & Future Planning (2020M1A2A2080746). This work was also supported by ‘The Research Project Funded by U-K Brand’ (1.200030.01) of Ulsan National Institute of Science & Technology (UNIST). D.S.K. acknowledges the Development Program of the Korea Institute of Energy Research (KIER) (C0-2401 and C0-2402). L.E. acknowledges support from the Swiss National Science Foundation, grant number 200020_178860. U.R. acknowledges funding from the Swiss National Science Foundation via individual grant number 200020_185092 and the NCCR MUST. A.H. acknowledges the Swiss National Science Foundation, project ‘Fundamental studies of dye-sensitized and perovskite solar cells’, project number 200020_185041. M.G. acknowledges financial support from the European Union’s Horizon 2020 research and innovation programme under grant agreement number 881603, and the King Abdulaziz City for Science and Technology (KACST). 

**Author contributions** J.J., B.W. and J.Y.K. conceived the project. J.J., Minjin Kim and H.L. prepared the samples, performed the relevant photovoltaic measurements, analysed the data and wrote the manuscript. J.S. synthesised the FAHCOO material. Minjin Kim and D.S.K. certified the efficiency of the PSCs. Y.J.Y. carried out photoluminescence and UV–vis absorption spectroscopy. S.J.C. and I.W.C. performed the time-resolved photoluminescence, SEM and XRD measurements. Y.J. and H.L. collected the light-intensity-dependent _J_ – _V_ data. P.A. and U.R. designed and performed all the DFT calculations and molecular dynamics simulations. Maengsuk Kim and J.H.L contributed to the DFT calculations. A.M., M.A.H. and L.E. conducted the solid-state NMR measurements and analysis. B.P.D. performed the atomic force microscopy measurements. H.L. conducted the long-term operational stability measurements, EQEEL measurements and analysed the data. Y.Y. performed the two-dimensional grazing-incidence XRD measurements. F.T.E contributed to the analysis of the time-resolved photoluminescence data. S.M.Z. coordinated the project. A.H. and M.G. proposed experiments and M.G. wrote the final version of the manuscript. A.H., D.S.K., M.G. and J.Y.K. directed the work. All authors analysed the data and contributed to the discussions. 

**Competing interests** The authors declare no competing interests. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-021-03406-5. **Correspondence and requests for materials** should be addressed to A.H., D.S.K., M.G. or J.Y.K. **Peer review information** _Nature_ thanks the anonymous reviewers for their contribution to the peer review of this work. **Reprints and permissions information** is available at http://www.nature.com/reprints. 

## Article 



**Extended Data Fig. 1 | Characterization of the perovskite films with and without FAFo. a** , The Tauc plot of the 2% Fo-FAPbI3 perovskite film. **b** , A full photoluminescence decay of the reference, 2% Fo-FAPbI3 and 4% Fo-FAPbI3 perovskite films. **c** , The distribution of the grain sizes of the reference and 2% Fo-FAPbI3 films. The box + whisker plots show the distribution of the grain sizes for both reference and 2% Fo-FAPbI3 perovskite films. The distribution is based on 22 data points each. **d** , **e** , The top-view SEM image ( **d** ) and the cross-sectional 

SEM image ( **e** ) of the 4% Fo-FAPbI3 perovskite film. **f** , **g** , AFM images of the reference ( **f** ) and the 2% Fo-FAPbI3 ( **g** ) perovskite films. **h** , The XRD patterns of the reference, 2% Fo-FAPbI3 and 4% Fo-FAPbI3 perovskite films. Peaks labelled with an asterisk are assigned to the FTO substrates, which can be seen for the 4% sample owing to the lower intensity of the perovskite reflections. **i** , Integrated one-dimensional grazing-incidence XRD pattern of the reference and 2% Fo-FAPbI3 films. 



**Extended Data Fig. 2 | The composition of the Fo-FAPbI3 perovskite film.** peak. A minor signal arising from the PTFE that is used to seal the rotor is also **a** , **b** ,<sup>1</sup> H–<sup>13</sup> C cross-polarization spectra of mechanosynthesized FAPbI3 with 5% visible. **c** , **d** , TOF-SIMS measurements of the reference ( **c** ) and the 2% Fo-FAPbI3 FAHCOO ( **a** ) and a scraped thin film of 2% Fo-FAPbI3 ( **b** ), recorded at 12 kHz MAS ( **d** ) films. **e** , Quantitative, directly detected<sup>13</sup> C solid-state NMR measurement and 100 K. In **b** the formate signal can be seen as a minor shoulder on the FAPbI3 of 2% Fo-FAPbI3 scraped thin film at 12 kHz MAS and 100 K. 

Article 



**Extended Data Fig. 3 | Ab initio molecular dynamics simulations. a** , Molecular dynamics snapshot showing the coordination of Pb<sup>2+</sup> ions with HCOO<sup>−</sup> anions in the perovskite precursor solution. As a guide to the eye, we highlight only Pb<sup>2+</sup> and HCOO<sup>−</sup> ions; the remaining ions and solvent molecules are shown as transparent. **b** , The radial distribution function _g_ ( _r_ ) between the oxygen atoms of HCOO<sup>−</sup> and Pb<sup>2+</sup> over the full ab initio molecular dynamics trajectory of around 11 ps. **c** , Initial configuration of FAPbI3 with surface iodide 

replaced by HCOO<sup>−</sup> anions. **d** , The top view of surface atoms on the FA<sup>+</sup> -terminated side. **e** , The top view of the surface atoms on the Pb<sup>2+</sup> -terminated side. Pb<sup>2+</sup> –HCOO<sup>−</sup> and FA<sup>+</sup> –HCOO<sup>−</sup> bonding and hydrogen-bonding networks are illustrated with magenta dashed lines. All ions are shown in ball-and-stick representation. Pb<sup>2+</sup> ions, yellow; iodide, light pink; oxygen, red; carbon, light blue; nitrogen, dark blue; sulfur, light yellow; hydrogen, white. 



**Extended Data Fig. 4 | DFT-relaxed slabs of FAPbI3 with different anions adsorbed at an iodide-vacancy site on the surface. a** , Structure of a pure FAPbI3 slab with a Pb–I terminated surface on the top and an FA–I terminated surface on the bottom side. **b** – **e** , Front view of the Cl<sup>−</sup> ( **b** ), Br<sup>−</sup> ( **c** ), BF4− ( **d** ) and HCOO<sup>−</sup> ( **e** ) passivated surface. **f** , An illustration of iodide-vacancy passivation by HCOO<sup>−</sup> . **g** , **h** , DFT-relaxed FAPbI3 slab with HCOO<sup>−</sup> adsorbed at the 

iodide-vacancy site on the Pb–I ( **g** ) and the FA–I ( **h** ) terminated surface. All chemical species are shown in ball-and-stick representation. Pb<sup>2+</sup> , grey; iodide, violet; oxygen, red; carbon, dark brown; nitrogen, light blue; bromide, red-brown; chloride, light green; boron atoms, dark green; fluoride, yellow; hydrogen atoms, white. 

## Article 



**Extended Data Fig. 5 | Bonding between formamidinium and different anions on the surface of FAPbI3. a** , Structure of a pure FAPbI3 slab with FA–I termination on the top and Pb–I termination on the bottom side. **b** , **c** , The front view ( **b** ) and the side view ( **c** ) of the HCOO<sup>−</sup> passivated surface. **d** – **f** , Cl<sup>−</sup> ( **d** ), Br<sup>−</sup> ( **e** ) and BF4− ( **f** ) passivated surface. All chemical species are shown in 

ball-and-stick representation. Pb<sup>2+</sup> , grey; iodide, violet; oxygen, red; carbon, dark brown; nitrogen, light blue; bromide, red-brown; chloride, light green; boron atoms, dark green; fluoride, yellow; hydrogen, white. **g** , Relative desorption strength of FA<sup>+</sup> cations on different passivated surfaces. 



**Extended Data Fig. 6 | Photovoltaic performance of the PSCs under different conditions. a** , _J–V_ curve of the target PSC measured without a metal mask. **b** , _J–V_ curves of the reference PSC and the PSC with 2% formamidinium 

acetate. **c** , _J–V_ curves of the reference and 2% Fo-FAPbI3 PSCs without the MACl additive. **d** , _J–V_ curves of the reference and the 2% Fo-FAPbI3 PSCs without using octylammonium iodide passivation. FF, fill factor. 

Article 



**Extended Data Fig. 7 |** **_J–V_ metrics of the reference and target PSCs during the operational stability test. a** – **c** , The change in _J_ sc ( **a** ), _V_ oc ( **b** ) and fill factor ( **c** ) of the reference and target cells over the 450-h MPP tracking measurement. 

**Extended Data Table 1 | Detailed** **_J–V_ parameters of the reference and target PSCs under both reverse and forward voltage** 

**scans** 



Article 

**Extended Data Table 2 | Detailed** **_J–V_ parameters of the reference and target PSCs under different light intensities** 



