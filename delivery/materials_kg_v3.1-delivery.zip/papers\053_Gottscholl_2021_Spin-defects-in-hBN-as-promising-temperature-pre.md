# Spin defects in hBN as promising temperature, pressure and magnetic field quantum sensors

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 325 |
| 作者 | Andreas Gottscholl, Matthias Diez, V. Soltamov, C. Kasper, Dominik Krauße, A. Sperlich, M. Kianinia, C. Bradac et al. |
| DOI | 10.1038/s41467-021-24725-1 |
| 源文件 | 053_Gottscholl_2021_Spin-defects-in-hBN-as-promising-temperature-pre.pdf |

---
# **Sub-nanoscale Temperature, Magnetic Field and Pressure sensing with Spin Centers in 2D hexagonal Boron Nitride** 

Andreas Gottscholl<sup>1</sup> , Matthias Diez<sup>1</sup> , Victor Soltamov<sup>1,2</sup> , Christian Kasper<sup>1</sup> , Andreas Sperlich<sup>1</sup> , Mehran Kianinia<sup>3, 4</sup> , Carlo Bradac<sup>5</sup> , Igor Aharonovich<sup>3, 4</sup> , Vladimir Dyakonov<sup>1,</sup> * 

1 Experimental Physics 6 and Würzburg-Dresden Cluster of Excellence ct.qmat, Julius Maximilian University of Würzburg, 97074 Würzburg, Germany 

2 Ioffe Institute, St. Petersburg 194021, Russia 

3 School of Mathematics and Physical Sciences, University of Technology Sydney, Ultimo, NSW 2007, Australia 

4.Centre of Excellence for Transformative Meta-Optical Systems, University of Technology Sydney, Ultimo, NSW 2007, Australia 

5 Department of Physics & Astronomy, Trent University, 1600 West Bank Dr., Peterborough 28 ON, K9J 0G2, Canada 

**Spin defects in solid-state materials are strong candidate systems for quantum information technology and sensing applications. Here we explore in details the recently discovered negatively charged boron vacancies (** 𝐕𝐁# **) in hexagonal boron nitride (hBN) and demonstrate their use as atomic scale sensors for temperature, magnetic fields and externally applied pressure. These applications are possible due to the high-spin triplet ground state and bright spin-dependent photoluminescence (PL) of the** 𝐕𝐁# **. Specifically, we find that the frequency shift in optically detected magnetic resonance (ODMR) measurements is not only sensitive to static magnetic fields, but also to temperature and pressure changes which we relate to crystal lattice parameters. Our work is important for the future use of spinrich hBN layers as intrinsic sensors in heterostructures of functionalized 2D materials.** 

Spin defects in three-dimensional (3D) wide band-gap semiconductors have extensively been utilized in both fundamental and practical realizations in quantum science. The most prominent systems are the nitrogenvacancy (NV) center in diamond<sup>1</sup> and various types of spin defects in silicon carbide (SiC) (divacancy and silicon vacancy)<sup>2,3</sup> . These systems reveal optically detected magnetic resonance (ODMR), which allows for polarization, manipulation and optical readout of their spin state and consequent mapping of external stimuli (magnetic/electric field, temperature, pressure, etc.) onto it<sup>4-6</sup> . A variety of reports have demonstrated outstanding nanoscale sensing applications of NV-centers (particularly NV<sup>-</sup> ) in physics and biology including detection of individual surface spins<sup>7</sup> and nanothermometry in living cells<sup>8,9</sup> . However, NV-centers in diamond and spin centers in SiC possess intrinsic limitations. The three-dimensional nature of the material makes it challenging to position the spin-defects close as to the sample surface, and thus, to the object/quantity to be sensed. Furthermore, the proximity to the surface deteriorates their spin coherence properties and hinder their sensitivity as nano-sensors<sup>10</sup> . 

A remedy to these limitations may be provided by recently discovered defects in layered materials. One of the most prominent stackable 2D materials is hexagonal boron nitride (hBN) which hosts a large variety of atomlike defects including single photon emitters<sup>11-14</sup> . Spin carrying defects have been theoretically predicted and experimentally confirmed in hBN<sup>15-19</sup> . Currently, the most understood defect is the negatively-charged boron vacancy center (V%#)20, which can be readily created by neutron irradiation, ion implantation or femtosecond laser pulses<sup>21,22</sup> . Due to its spin-optical and properties, the V%# center is proving to be a promising candidate system for quantum information and nanoscale quantum sensing applications and has thus expanded the already large suite of unique features displayed by 2D materials<sup>13</sup> . 

The recently identified VB<sup>–</sup> in hBN displays a photoluminescence (PL) emission band around 850 nm and has been found to be an electronic spin-triplet (S=1) system with a ground state zero-field splitting (ZFS) 𝐷'(/ℎ≅ 3.5 GHz between its spin sublevels 𝑚( = 0 and 𝑚( = ±1<sup>16</sup> . Here, we study the effect of external stimuli on the defect’s properties and demonstrate its suitability for sensing temperature, pressure (as lattice compression) and magnetic fields. Notably, our experiments show that the resolution and range of operation of the hBN V%# center is competitive or exceeding those of similar defect-based sensors<sup>23</sup> . 

The results presented in this work were obtained on single-crystal hBN. The V%# centers were generated in the sample via neutron irradiation (≈2.3´10<sup>18</sup> n·cm<sup>−2</sup> ), as described elsewhere<sup>16,20</sup> . The hBN single crystalline sample consists of a stack of a few thousand mono layers. The distance between two adjacent layers is 𝑐≅ 6.6 Å, while the in-plane distance between two identical atoms is 𝚊≅2.5 Å (Fig. 1a). As shown by temperature dependent X-ray data<sup>24</sup> , the hBN lattice undergoes highly anisotropic thermal expansion with 𝑐 and 𝚊 changing in opposite directions, i.e., while 𝑐 decreases with cooling, 𝚊 increases, as schematically shown in Fig. 1b. This crystallographic feature can be used to monitor local temperature variations optically, via ODMR, since the temperature-driven compression/expansion of the lattice parameters 𝚊 and 𝑐 causes a direct change in the ZFS parameter 𝐷'( of the triplet ground state Spin-Hamiltonian<sup>25</sup> . Figure 1c shows continuous wave (cw) 

1 

ODMR measurements for three different temperatures, with (dark blue) or without (cyan) an external magnetic field 𝑩 applied. At room temperature and in the absence of the external magnetic field, the ODMR spectrum of the V%# shows two resonances (𝜈@, 𝜈B) centered symmetrically around 𝜈C, which corresponds to the ZFS parameter 𝐷'(/ℎ= 𝜈C = 3.48 GHz with the splitting due to the non-zero off-axial ZFS parameter 𝐸'(/ℎ≅ 50 MHz. When applying an external static magnetic field 𝑩, 𝜈@ and 𝜈B split further following: 



<!-- Start of picture text -->
𝜈@,B = 𝐷'(/ℎ± (1/ℎ)J𝐸'(B + (𝑔𝜇N𝐵)B.  (1)<br><!-- End of picture text -->

Here, h is Planck’s constant, g is the Landé factor and 𝜇𝐵 is the Bohr magneton. The separation of the two resonances 𝜈@ and 𝜈B can clearly be seen in Fig. 1c (dark blue traces). The visible substructure in both ODMR peaks is due to hyperfine coupling of the electron S=1 spin system (negatively charged boron vacancy) with three equivalent nearest nitrogen atoms, each possessing nuclear spin 𝐼= 1 for the most abundant<sup>14</sup> N isotope (99.63%). In total, seven hyperfine peaks can be resolved, whose relative separations are temperature and magnetic field independent. A closer look at Fig. 1c reveals that cooling down the sample results in a shift of the ODMR peaks to higher frequencies. Thus, the dependencies of the ODMR spectrum on temperature and magnetic fields can provide a basis for the use of the V%# center as a thermometer and magnetometer at the sub-nanoscale. 



**_Figure 1. a)_** _Schematic of the hexagonal boron nitride (hBN) crystal, its hexagonal structure with alternating boron (red) and nitrogen (blue) atoms and the lattice constants_ 𝚊 _and_ 𝑐 _._ **_b)_** _Lattice contraction and expansion due to temperature variation, according to crystallographic data_<sup>_24_</sup> _._ **_c)_** _cw ODMR spectra measured with (dark blue) and without (cyan) external magnetic field at different temperatures T = 295 K, 160 K and 10 K. Lowering of the temperature causes the resonances_ 𝜈C, 𝜈@ _and_ 𝜈B _to shift to larger microwave frequencies indicating an increase of the zero-field splitting_ 𝐷'( _._ 

## **Temperature Sensing** 

The observed shift of the resonances to higher frequency values (Fig. 1c) is independent of the applied magnetic field and is solely due to a reduction of the ZFS parameter 𝐷'(. Over the temperature range 295 – 10 K, 𝐷'( undergoes a variation ∆𝐷'( ≅195 MHz. This is a relatively large change compared to analogous spin systems in 3D materials (≈30-fold). For instance, the NV<sup>-</sup> center in diamond exhibits a shift ∆𝐷'( ≅7 MHz<sup>25</sup> , while the 𝐷'( of VSi in SiC is almost constant over the same range. Only more complex spin defects such as Frenkel defects (VSi-Sii) in SiC display a comparably strong effect (∆𝐷'( ≅300 MHz)<sup>5</sup> . 

To quantify this temperature-induced shift of the ground state triplet energy-levels we combine temperatureand magnetic field-dependent ODMR measurements. Figure 2 summarizes the shift of 𝐷'( in the ODMR spectrum as a function of temperature both, in the presence (a) and absence (b) of an external magnetic field. In Fig. 2a, an external magnetic field of 8.5 mT is applied. A monotonic, nearly linear increase of the resonance frequencies associated to a change in the zero-field splitting parameter 𝐷'( can be observed for temperatures down to 50 K. Zero-field ODMR (Fig. 2b) shows the same behavior. From Figs. 2a, b we now extract the ZFS values 𝐷'(/ℎ and plot them against temperature (Fig. 2c). Both temperature dependencies, represented by dark blue and cyan diamonds, match perfectly and thus confirm that the temperature scaling of 𝐷'( is indeed independent of the magnetic field. 

2 



**_Figure 2._** _Temperature dependence of the ODMR spectrum of_ V%# _._ **_a)_** _,_ **_b)_** _Color maps represent the peak positions of the normalized ODMR spectrum for different temperatures in an external magnetic field of (a)_ 𝑩= 8.5 mT _and (b)_ 𝑩= 0 mT _._ **_c)_** _ZFS parameter_ 𝐷'(/ℎ _obtained from a) (blue diamonds) and b) (cyan diamonds) vs. temperature. The monotonic increase while lowering the sample temperature is unaffected by the magnetic field. The data can be fitted using Eq. (2) describing the temperature-dependent change of the lattice parameters a (grey dotted line_<sup>_24_</sup> _) and c (black dotted line_<sup>_24_</sup> _) that are also plotted in (c). The fits are shown as solid lines (blue for 8.5 mT and cyan for 0 mT) on top of the diamonds and reproduce the temperature dependence perfectly._ 

The temperature dependency can be explained by considering the change in the delocalization of the spindefect wave function delocalization due to temperature-induced structural deformations of the crystal lattice. This is consistent with e.g. the case of the NV<sup>-</sup> center in diamond<sup>25,26</sup> . The latter shows a linear behavior for the shift of the ZFS associated to the relative change of the lattice constant 𝜂 is observed<sup>26</sup> : ∆𝐷'((𝜂)/ℎ= 𝜃 𝜂(𝑇), where 𝜃 is the proportionality factor, explicitly written as 𝑑𝐷/𝑑𝜂 and 𝜂(𝑇) is the relative change of the lattice parameter. Applying the same concept to hBN with its two lattice parameters 𝚊 and 𝑐 results in the equation: 

## 𝐷'((𝜂𝚊, 𝜂Z) = 𝐷'(,B[\] + ∆𝐷'(,𝚊 + ∆𝐷'(,Z = 𝐷'(,B[\] + 𝜃𝚊𝜂𝚊ℎ+ 𝜃Z𝜂Zℎ (2) 

Here, 𝐷'(/ℎ is the experimentally measured ZFS frequency. 𝐷'(,B[\]/ℎ = 3.48 GHz is the ZFS at T = 295 K that we choose as reference. ∆𝐷'(,𝚊 and ∆𝐷'(,Z are the frequency shifts induced by the relative changes in 𝚊 and 𝑐, 𝜂𝚊(𝑇) and 𝜂Z(𝑇) are relative changes of 𝚊 and 𝑐, respectively (see also Eqs. (6,7) below). The temperature-dependent lattice parameters 𝚊(𝑇) and 𝑐(𝑇) for hBN were determined in Ref. 24 and are plotted in Fig. 2c in addition to the ODMR data. The proportionality factors 𝜃𝚊 and 𝜃Z are the significant parameters that connect lattice deformation and ZFS and will be derived from the experimental data in the following. To do so, Eq. (2) is fitted to the experimentally measured ZFS 𝐷'(, as shown in Fig. 2c. The fit perfectly reproduces the experimental data, which highlights the remarkable linear response of the resonance frequency to changes of the lattice constants in this case due to temperature. 

Figure 3 shows the relationship between temperature-dependent lattice parameters and ZFS for a magnetic field of 𝑩 = 8.5 mT. By inserting the crystallographic data for the hBN lattice parameters<sup>24</sup> into Eq. (2), we obtain a surface with respective slopes 𝜃𝚊and 𝜃Z, as shown in Fig. 3d (grey). 

3 



**_Figure 3._** _Zero-field splitting dependence on the lattice parameters_ 𝚊 _and_ 𝑐 _. Eq. (2) is fitted (solid lines) to the experimental data displayed as diamonds._ **_a)_** _Change of ZFS_ ∆𝐷'(,𝚊 _caused by the temperature-dependent lattice parameter_ 𝚊 _._ **_b)_** _Change of ZFS_ ∆𝐷'(,Z _caused by temperature-dependent lattice parameter_ 𝑐 _._ **_c)_** _Comparison of lattice parameters in the temperature range 5 K – 350 K._ **_d)_** _Combined 3-dimensional representation of plots_ **_a-c)_** _. Fitting Eq. (2) to the 3-dimensional data set_ 𝐷'((𝚊,𝑐, 𝑇) _allows estimating the slopes_ 𝜃𝚊 _and_ 𝜃Z _(shown also Figs 3a, b). The ZFS reference temperature T = 295 K is marked by the red dot. The assignment of colors of fitting lines (blue for 8.5 mT and cyan for 0 mT) is the same as in Fig. 2._ 

We extract the values for 𝜃𝚊 of (−84 ± 15) GH𝑧 and (−78.2 ± 8.8) GH𝑧 or 𝜃Z of (−24.32 ± 0.59) GH𝑧 and (−24.6 ± 1.0) GH𝑧 at B = 0 mT and 8.5 mT, respectively. The out-of-plane 𝜃Z can be determined more precisely, since the relative change of lattice parameter 𝑐 is one order of magnitude larger. The values coincide within the experimental error and can be combined as: 



<!-- Start of picture text -->
𝜃𝚊 = (−81 ± 12) GH𝑧 (3)<br>𝜃Z = (−24.5 ± 0.8) GH𝑧 (4)<br><!-- End of picture text -->

Remarkably, the ratio 𝜃𝚊/𝜃Z ≈ 3.3, which means the influence of the lattice distortion on the ZFS in-plane is at least three times stronger than the influence of the interplanar distance on the same, indicating a localization of the V%#  spin density in the plane as predicted by the theory17. 

Finally, we propose a polynomial which allows a direct determination of 𝐷'( from the sample temperature 𝑇: 



<!-- Start of picture text -->
𝐷'((𝑇) = ℎ∑𝐴b b𝑇 b  (𝑘= 0,1,2,3)   (5)<br><!-- End of picture text -->

where T is the temperature, ℎ is Planck’s constant, 𝑘 is an integer, and the polynomial coefficients 𝐴b are summarized in Table 1 for different temperature ranges. To obtain the coefficients 𝐴b, the essential step is to determine the relative changes of the lattice parameters from the crystallographic data<sup>24</sup> by using the Equations (6) and (7): 



<!-- Start of picture text -->
𝚊(d)#𝚊(B[\ ])<br>𝜂𝚊(𝑇) = (6)<br>𝚊(B[\ ])<br>Z(d)#Z(B[\ ])<br>𝜂Z(𝑇) = (7)<br>Z(B[\ ])<br><!-- End of picture text -->

4 

|Temperature range (K)|𝐴C(GHz)|𝐴@(MHz K<sup>-1</sup>)|𝐴B(kHz K<sup>-2</sup>)|𝐴e(Hz K<sup>-3</sup>)|
|---|---|---|---|---|
|5-128|3.6367|0|-4.4308|11.468|
|128-189|3.6109|0.22839|-3.8805|5.522|
|189-350|3.6664|-0.55659|-0.2383|0|



**_Table 1._** _Calculated polynomial coefficients_ 𝐴b _for Eq. 5. The three different temperature regions arise from the sectionally defined polynomial for the temperature- dependent lattice parameters_ 𝚊 _and_ 𝑐<sup>24</sup> _. The exact procedure of calculation can be found in the Supporting Information._ 

## **Pressure Sensing** 

The observation that a temperature-induced change in the lattice parameters directly results in a shift of the ZFS 𝐷'( leads to the consideration of utilizing the V%# center also as a sensor, for externally applied in-plane or out-of-plane pressure. For a first-order estimation we assume an isothermal system without shear strain and derive the perspective sensitivity based on reported elastic moduli for hBN crystals<sup>27,28</sup> . In cartesian coordinates, the pressure vector σghi is given by the elastic moduli tensor 𝐶 multiplied with the relative change of the lattice parameters 𝜂ghi: 



<!-- Start of picture text -->
𝜎g 𝐶@@ 𝐶@B 𝐶@e 𝜂g<br>𝜎h 𝐶@B 𝐶@@ 𝐶@e 𝜂h (8)<br>k𝜎im = k𝐶@e 𝐶@e 𝐶eemk𝜂i m<br><!-- End of picture text -->

The reported elastic moduli for hBN are: 𝐶@@ = (811±12) GPa, 𝐶@B = (169±24) GPa, 𝐶@e = (0±3) GPa and 𝐶ee = (27±5) GPa<sup>27</sup> . The hBN lattice parameters 𝚊 and 𝑐 are oriented along the y- and z-direction, respectively. This simplifies Eq. (8) by incorporating 𝜂𝚊,Z and removing 𝐶@e , which is 0: 



<!-- Start of picture text -->
B @<br>𝜎g ⎛𝜂p qeB 𝐶@@ + e@ 𝐶@Br⎞<br>𝜎h (9)<br>k𝜎im = 𝜂p qe 𝐶@B + e 𝐶@@r<br>⎝ 𝜂Z𝐶ee ⎠<br><!-- End of picture text -->

This can be rewritten to obtain 𝜂𝚊,Z directly: 



<!-- Start of picture text -->
𝜂p = 𝜎g/u v w 𝐶 @@ + x w 𝐶 @By = 𝜎h/u v w 𝐶 @B + x w 𝐶 @@y (10)<br>𝜂Z = 𝜎i/𝐶ee (11)<br><!-- End of picture text -->

Substituting these relationships into Eq. (2) yields the ZFS as a function of the applied pressure: 



<!-- Start of picture text -->
z{|}~ z{|•~ z‚|ƒ~<br>𝐷'(u𝜎g, 𝜎h, 𝜎iy = 𝐷'(,B[\] + ∆𝐷'(,g + ∆𝐷'(,h + ∆𝐷'(,i = 𝐷'(,B[\] + + + (12)<br>u v w • xx € x w • xvy u v w • xv € x w • xxy •ww<br><!-- End of picture text -->

Based on our estimates for 𝜃𝚊,Z in Eqs. (3,4) and the reported elastic moduli<sup>27</sup> , we obtain the sensitivity to measure the ZFS shifts for each direction of the applied pressure: 



<!-- Start of picture text -->
„i<br>∆𝐷'(,g = 𝜎gℎ(−0.136 ± 0.028) …p (13)<br>„i<br>∆𝐷'(,h = 𝜎hℎ(−0.212 ± 0.052) …p (14)<br>„i<br>∆𝐷'(,i = 𝜎iℎ(−0.91 ± 0.20) …p (15)<br><!-- End of picture text -->

Consequently, we find that the ZFS shift ∆𝐷'(,ghi is directly associated with external compression of the hBN lattice and therefore V%# can be utilized as a pressure sensor. Remarkably, the out-of-plane sensitivity along the 𝑐-axis is much higher due to the small 𝐶ee coefficient. This makes this type of sensor particularly useful to measure vertical indentation in 2D heterostructures. 

## **Magnetic Field Sensing** 

As shown in Fig. 2a, the two resonant transitions 𝜈@,B are equally separated with respect to 𝜈C over the entire temperature range between 5 K and 350 K. It should be pointed out that the magnetic field sensing is based on the g-factor, which is independent of the lattice parameters. In Figure 4, we demonstrate the principle suitability of a V%# center in hBN for magnetic field sensing, where we show the resonant microwave transitions 

5 

𝜈@ and 𝜈B over a broad range (0 −3500 mT) and exemplarily simulated for two distant temperatures, T = 295 K (dark blue) and T = 5 K (light blue). For a magnetic field applied in the 𝑐-direction of the hBN lattice, the behavior can be described with Eq. (1). Due to the non-zero 𝐸'(, the Zeeman splitting term 𝑔µN𝐵 leads to a linear regime only for 𝐵> 3 𝑚𝑇, when the applied magnetic field is large enough to separate the two otherwise partially overlapping 𝜈@,B transitions. 



**_Figure 4._** _Experimental (diamonds) and simulated (dark and light blue traces) resonant frequencies of_ V%# _for different temperatures and magnetic fields._ **_a)_** _ODMR measurements (pink diamonds) at B < 20 mT._ **_b)_** _cw EPR measurement at T = 5 K and microwave frequency of 9.4 GHz (light green) and electron spin-echo measurements at T = 8 K and 94 GHz (dark green). Note the axes are shifted for better visibility and comparability._ 

To extend the magnetic field range of our measurements beyond the confocal ODMR setup limit of ≈20 mT, we applied cw electron paramagnetic resonance (cw EPR) and electron spin-echo detected (ESE) EPR. The advantage is that the cw EPR measurements are performed at a microwave frequency of 9.4 GHz (X-band) (light green diamonds) and the ESE EPR measurements at a microwave frequency of 94 GHz (W-band) (dark green diamonds) which allow extending the magnetic field range to 3500 mT. The multifrequency spin resonance approach enables us to determine the g-factor with extremely high accuracy as 𝑔= 2.0046 ± 0.0021. 

## **Discussion** 

As we mentioned, one of the crucial parameters for high-sensitivity sensing is the distance between the sensor and the object to be sensed. In this regard, sensors based on the hBN V%# center are particularly appealing as — based on the presented model of lattice constant variations — the required hardware ideally consists of only three hBN layers, with the intermediate one hosting a V%# center. This corresponds to a minimum distance of the defect to the surface in the sub-nanometer range of »0.33 nm. A further thickness reduction, e.g. to a single monolayer, would indeed eliminate the interlayer contribution 𝑐(𝑇), but make the sensing effect completely dependent on the interaction of the V%# wave function with the parameters of the adjacent material. For single layers, 𝐷'(,B[\] would differ from the theoretical calculation<sup>29</sup> , and a calibration would be required to determine the set of parameters (𝐷'(,B[\ ], 𝜃p, 𝜃Z) specific for the adjacent material. To substantiate this hypothesis, however, further measurements and calculations must be carried out. 

In the following, we benchmark the properties of the hereby proposed sensor based on V%# centers in hBN against other defect-based sensors in silicon carbide and diamond. For this purpose, the general sensitivity is derived, which includes the respective coupling coefficient Γd,|,N  representing the sensitivity of the ODMR frequency shift due to the corresponding external influence, and the general resolution in relative change of frequency in relation to acquisition time and noise level<sup>5</sup> . An overview of all calculated coupling coefficients and resolutions is summarized in Table 2. 

In order to facilitate comparison with other color centers in 3D materials, we consider a linear regime (50 – . 350 K) in our analysis. In this range, a proportionality between ∆𝐷'( and 𝑇 is given by the factor Γd = −623<sup>‰Šƒ</sup> ‹ This value is almost one order of magnitude larger than the corresponding factor for NV<sup>-</sup> centers in diamond (−74<sup>‰Šƒ</sup> ‹ )<sup>30</sup> . This remarkable (> 8-fold) difference is in particular due to the larger relative change of the lattice parameters as a function of temperature in hBN, while 𝜃 is of the same order of magnitude. For NV<sup>-</sup> centers, a value of 𝜃Œ• = −14.41 GHz is reported<sup>26</sup> , which is comparable to 𝜃Z ≈−24 GHz for V%# in hBN. Note that 𝜃p can be neglected here, since on the one hand the relative change of the lattice parameter _a_ is negligible and on the other hand it counteracts the effect due to the expansion of the in-plane distance while cooling the sample. The general resolution 𝛿dB[\] obtained at room temperature is approximately 3.82 <u>√</u><sup>‹</sup> Šƒ which is of the 

6 

same order of magnitude as defect-based temperature sensors in SiC (1 <u>√</u><sup>‹</sup> Šƒ ) using the same cw ODMR setup<sup>5</sup> . It should be noted, however, that at cryogenic temperatures the resolution of the V%# center is enhanced by a factor of ≈20 (𝛿d\C] = 0.19 <u>√</u><sup>‹</sup> Šƒ ), as both the ODMR contrast ΔPL/PL and the PL intensity increase, which significantly reduces the required measurement time. Despite the smaller coupling coefficient, a temperature sensor based on NV’s in diamond is still more sensitive (0.76 <u>√</u><sup>•‹</sup> Šƒ )<sup>31</sup> , mainly due to stronger PL emission, higher ODMR contrast and an optimized pulsed measurement protocol that exceeds the sensitivity of standard cw ODMR measurements performed here. Analogously, the magnetic field resolution of the V%# can be quantified at room temperature as 𝛿NB[\] = 85.1 <u>√</u><sup><u>‘</u></sup> Šƒ<sup>’</sup> (𝛿N\C] = 4.33 <u>√</u><sup><u>‘</u></sup> Šƒ<sup>’</sup> at T=50 K). This is comparable to VSi in SiC (10 <u>√</u><sup><u>‘</u></sup> Šƒ<sup>’</sup> )<sup>5</sup> but lower than for NVs in diamond (3 <u>√</u><sup>“’</sup> Šƒ )<sup>32</sup> . However, spin defects in 3D materials can lose their superior properties if they are close to the surface of the crystalline host<sup>10</sup> , which also leads to an inevitable limitation of the minimum achievable sensor-to-object distance. This can significantly hinder the effectiveness of the spin defects-based sensors in 3D materials, highlighting the potential advantages of the V%# center as a sub-nanometer scale sensor. 

||Coupl|ing coeffici|ent Γ|Reso<br>(2|lution𝛿<br>95 K)||Resolution𝛿<br>(50 K)|
|---|---|---|---|---|---|---|---|
||hBN|diamond|SiC|hBN|diamond|SiC|hBN|
|Magnetic Field B|𝑔µN = 28.|0 <sup>‰Šƒ</sup><br>‘’<br> (for𝑔|= 2.00)|85.1 <sup>”d</sup><br>√„i<br>|3 <sup>•d</sup><br>√„i<br>|10 <sup>”d</sup><br>√„i<br>|4.33 <sup>”d</sup><br>√„i<br>|
|Temperature T|−623<sup>b„i</sup><br>]<br>|−74 <sup>b„i</sup><br>]<br>|−1 .~~1~~<sup>–„i</sup><br>]<br>|3.82 <sup>]</sup><br>√„i<br>|0.76 <sup>—]</sup><br>√„i<br>|1 <sup>]</sup><br>√„i<br>|0.19 <sup>]</sup><br>√„i<br>|
|X Pressure𝜎g|−0.136 <sup>„i</sup><br>…p|||17.5 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i<br>|||0.891 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i|
|Y Pressure𝜎h|−0.212 <sup>„i</sup><br>…p<br>|||11.2 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i<br>|||0.572 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i<br>|
|Z Pressure𝜎i|−0.91 <sup>„i</sup><br>…p<br>|||2.62 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i<br>|||0.133 ⋅10<sup>™</sup> <sup>…p</sup><br>√„i<br>|



**_Table 2_** _. Three spin hosting systems in comparison: coupling coefficient_ Γ _and general resolution_ 𝛿 _at room (T = 295 K) and cryogenic (T = 50 K) temperatures. Also shown are the reference values for spin defects in diamond_<sup>_30-32_</sup> _and SiC_<sup>_5_</sup> _, respectively (see main text)._ 

## **Conclusion** 

In this work, we have analyzed the spin properties of V%# lattice defects in van der Waals hBN crystals in terms of their sensitivity to external perturbations and evaluated their advantages and disadvantages for possible applications as a nanoscale quantum sensor. The advantages include the simple intrinsic nature of the defect basically consisting of a missing boron atom, but also the potentially accessible very small distance between the sensor and the object to be sensed. In particular, we focused on the influence of temperature on the ground-state zero-field splitting, which can be directly measured by cw ODMR and is explained by the temperature-dependent lattice compression/expansion. Externally applied pressure can also induce lattice deformations and therefore be mapped onto the defect ODMR spectrum of the V−B . However, temperature and pressure measurements exclude each other and need to be performed isobar or isothermal, respectively. Nevertheless, V%# can be used for simultaneous magnetic field measurements with high sensitivity, due to the invariability of its g-factor with respect to temperature and pressure. By comparing three spin defect hosting solid systems, diamond, SiC and hBN, we showed that the V%# defect has comparable and, in some cases, even superior properties compared to 3D hosts. The coupling coefficient between zero-field splitting and temperature is eight times larger than the corresponding factor for NV centers in diamond. For completeness, a temperature sensor based on NV centers in diamond is still more sensitive, mainly due to stronger PL emission, higher ODMR contrast and an optimized pulsed measurement protocol that exceeds the sensitivity of cw ODMR measurements. The resolution of V%# to external magnetic fields is comparable to that of silicon vacancies in SiC, but lower than that of NV centers in diamond. However, we believe that the recent demonstration of coherent control of V%# spins in hBN together with the overcoming of inhomogeneous ODMR line broadening by multifrequency spectroscopy<sup>20</sup> will stimulate the development of advanced pulse protocols<sup>33</sup> and lead to a further increase in the resolution of this sensor. In addition, during preparation of our manuscript, a similar work on V%# in hBN was submitted34 reporting an ODMR contrast of almost 10% and its high temperature stability up to 600 K. Finally, the unique feature of hBN is its non-disturbing chemical and crystallographic compatibility with many different 2D materials, which gains a new fundamental functionality with the embedded spin centers and allows sensing in heterostructures with high sensitivity serving as a boundary itself. 

7 

## **Methods:** 

**ODMR:** The low-field ODMR measurements are performed with a lab-built confocal microscope setup. A 532nm laser (Cobolt Samba 100) is coupled into a 50-µm fiber and focused on the sample with a 10× objective (Olympus LMPLN10XIR), which excites an area on the sample with a diameter of about 10 μm. The photoluminescence is separated from the laser by a dichroic mirror and the remaining laser light is rejected by a 532-nm long pass filter. The photoluminescence is then coupled into a 600 µm fiber and directed onto an avalanche photodiode (Thorlabs APD440A). A 0.5-mm wide copper strip-line is used to apply microwaves to the hBN sample placed on top. Microwaves from a signal generator (Stanford Research Systems SG384) are amplified by a Mini Circuits ZVE-3W-83+ amplifier. Lock-in detection is used (Signal Recovery 7230) by on-off modulation of the microwaves. For an external magnetic field, a permanent magnet is placed below the sample. 

## **Acknowledgements** 

A.G, A.S. and V.D. acknowledge financial support from the DFG through the Würzburg-Dresden Cluster of Excellence on Complexity and Topology in Quantum Matter—ct.qmat (EXC 2147, project-id 39085490) and C.K through the DY18/13-1. I. A. and V.S. are grateful for the Alexander von Humboldt (AvH) Foundation for their generous support. The Australian Research council (via DP180100077, DP190101058 and CE200100010), the Asian Office of Aerospace Research and Development grant: FA9550-19-S-0003 are gratefully acknowledged. 

## **References:** 

1. Gruber, A., Dräbenstedt, A., Tietz, C., Fleury, L., Wrachtrup, J., von Borczyskowski, C. Scanning confocal optical microscopy and magnetic resonance on single defect centers. _Science,_ **276** , 2012 (1997) 

2. Koehl, W. F., Buckley, B. B., Heremans, F. J., Calusine, G. and Awschalom, D.D. Room temperature coherent control of defect spin qubits in silicon carbide. _Nature,_ **479** , 84-87 (2011) 

3. Riedel, D., Fuchs, F., Kraus, H., Väth, S., Sperlich, A., Dyakonov, V., Soltamova, A., Baranov, P., Ilyin, V., Astakhov, G. V. Resonant addressing and manipulation of silicon vacancy qubits in silicon carbide. _Phys. Rev. Lett._ **109** , 226402 (2012) 

4. Doherty, M.W., Struzhkin, V.V., Simpson, D.A., McGuinness, L.P., Meng, Y., Stacey, A., Karle, T.J., Hemley, R.J., Manson, N.B., Hollenberg, L.C. and Prawer, S. Electronic properties and metrology applications of the diamond NV− center under pressure. _Phys. Rev. Lett._ , **112** (4), 047601 (2014) 

5. Kraus, H., Soltamov, V.A., Fuchs, F., Simin, D., Sperlich, A., Baranov, P.G., Astakhov, G.V. and Dyakonov, V. Magnetic field and temperature sensing with atomic-scale spin defects in silicon carbide. _Sci. Rep._ , **4** , 5303 (2014) 

6. Dolde, F., Fedder, H., Doherty, M.W., Nöbauer, T., Rempp, F., Balasubramanian, G., Wolf, T., Reinhard, F., Hollenberg, L.C., Jelezko, F. and Wrachtrup, J. Electric-field sensing using single diamond spins. _Nat. Phys._ , **7** (6), 459-463 (2011) 

7. Grinolds, M.S., Warner, M., De Greve, K., Dovzhenko, Y., Thiel, L., Walsworth, R.L., Hong, S., Maletinsky, P. and Yacoby, A. Subnanometre resolution in three-dimensional magnetic resonance imaging of individual dark spins. 

8. Kucsko, G., Maurer, P.C., Yao, N.Y., Kubo, M, Noh, H.J., Lo, P.K., Park, H. and Lukin, M.D. Nanometre-scale thermometry in a living cell. _Nature_ , **500** (7460), 54-58 (2013) 

9. Schirhagl, R., Chang, K., Loretz, M. and Degen, C.L. Nitrogen-vacancy centers in diamond: nanoscale sensors for physics and biology. _Annu. Rev. Phys. Chem.,_ **65** , 83-105 (2014) 

10. Zhang, W., Zhang, J., Wang, J., Feng, F., Lin, S., Lou, L., Zhu, W. and Wang, G. Depth-dependent decoherence caused by surface and external spins for NV centers in diamond. _Phys. Rev. B_ , **96** (23), 235443 (2017) 

11. Shotan, Z., Jayakumar, H., Considine, C. R., Mackoit, M., Fedder, et al. Photoinduced modification of single-photon emitters in hexagonal boron nitride. _ACS Photonics_ , **3** (12), 2490-2496 (2016) 

12. Jungwirth, N. R., Calderon, B., Ji, Y., Spencer, M. G., Flatté, M. E., Fuchs, G. D. Temperature dependence of wavelength selectable zero-phonon emission from single defects in hexagonal boron nitride. _Nano letters_ , **16** (10), 6052-6057 (2016) 

13.  Caldwell, J.D., Aharonovich, I., Cassabois, G. et al. Photonics with hexagonal boron nitride. _Nat. Rev. Mater._ **4** , 552–567 (2019) 

14. Hoese, M., Reddy, P., Dietrich, A., Koch, M. K., Fehler, K. G., Doherty, M. W., Kubanek, A. Mechanical decoupling of quantum emitters in hexagonal boron nitride from low-energy phonon modes. _Science Advances_ , **6** (40), eaba6038 (2020) 

15. Abdi, M., Chou, J.-P., Gali, A. and Plenio, M. B. Color centers in hexagonal boron nitride monolayers: a group theory and ab initio analysis. _ACS Photonics_ **55** , 1967-1976 (2018) 

16. <mark>Gottscholl, A., Kianinia, M., Soltamov, V.</mark> _<mark>e</mark> t al._ <mark>Initialization and read-out of intrinsic spin defects in a van der Waals crystal at room temperature.</mark> _<mark>N</mark> at. Mater._ **19,** <mark>540–545 (2020)</mark> 

8 

17. Ivády, V., Barcza, G., Thiering, G., Li, S., Hamdi, H., Chou, J.P., Legeza, Ö. and Gali, A., Ab initio theory of the negatively charged boron vacancy qubit in hexagonal boron nitride. _npj Comp. Mat._ , **6** (1), 1-6 (2020) 

18. Mendelson, N., Chugh, D.,  Reimers, J. R., Cheng, T. S.,  Gottscholl, A. et al. Identifying carbon as the source of visible single-photon emission from hexagonal boron nitride. _Nat. Mater._ 1-8 (2020) 

19. Chejanovsky, N., Mukherjee, A., Kim, Y., Denisenko, A., Finkler, A., Taniguchi, T., Watanabe, K., Dasari, D.B.R., Smet, J.H. and Wrachtrup, J. Single spin resonance in a van der Waals embedded paramagnetic defect. _arXiv preprint arXiv:_ 1906.05903 (2019) 

20. Gottscholl, A., Diez, M., Soltamov, V., Kasper, C., Sperlich, A., Kianinia, M., Bradac, C., Aharonovich, I. and Dyakonov, V. Room Temperature Coherent Control of Spin Defects in hexagonal Boron Nitride. _Science Advances,_ in press, (2021). _arXiv preprint arXiv_ :2010.12513 (2020) 

21. Kianinia, M., White, S., Froch, J. E., Bradac, C., Aharonovich, I. Generation of spin defects in hexagonal boron nitride. _ACS Photonics_ , **7** (8), 2147-2152. (2020) 

22. Gao, X., Pandey, S., Kianinia, M., Ahn, J., Ju, P., Aharonovich, I., et al. Femtosecond Laser Writing of Spin Defects in Hexagonal Boron Nitride. _arXiv preprint arXiv_ :2012.03207 (2020) 

23. <mark>Bradac, C., Lim, S.F., Chang, H.C. and Aharonovich, I. Optical Nanoscale Thermometry: From Fundamental Mechanisms to Emerging Practical Applications.</mark> _<mark>A</mark> dv. Opt. Mater_ _<mark>.</mark>_ <mark>, 2000183 (2020)</mark> 

24. Paszkowicz, W., Pelka, J.B., Knapp, M., Szyszko, T., Podsiadlo, S. Lattice parameters and anisotropic thermal expansion of hexagonal boron nitride in the 10–297.5 K temperature range. _Appl. Phys. A_ , **75** (3), pp.431-435 (2002) 

25. Chen, X.D., Dong, C.H., Sun, F.W., Zou, C.L., Cui, J.M., Han, Z.F. and Guo, G.C. Temperature dependent energy level shifts of nitrogen-vacancy centers in diamond. _APL_ , **99** (16), 161903 (2011) 

26. Ivády, V., Simon, T., Maze, J.R., Abrikosov, I.A. and Gali, A. Pressure and temperature dependence of the zero-field splitting in the ground state of NV centers in diamond: A first-principles study. _Phys. Rev. B_ , **90** (23), 235205 (2014) 

27. Bosak, A., Serrano, J., Krisch, M., Watanabe, K., Taniguchi, T. and Kanda, H. Elasticity of hexagonal boron nitride: Inelastic x-ray scattering measurements. _Phys. Rev. B_ , **73** (4), 041402 (2006) 

28. Lynch, R.W. and Drickamer, H.G. Effect of high pressure on the lattice parameters of diamond, graphite, and hexagonal boron nitride. _J. Chem. Phys.,_ **44** (1), 181-184 (1966) 

29. Ivády, V., Barcza, G., Thiering, G., Li, S., Hamdi, H., Chou, J.P., Legeza, Ö. and Gali, A. Ab initio theory of the negatively charged boron vacancy qubit in hexagonal boron nitride. _npj Comput. Mater._ , **6** (1), 1-6 (2020) 

30. Acosta, V.M., Bauch, E., Ledbetter, M.P., Waxman, A., Bouchard, L.S. and Budker, D. Temperature dependence of the nitrogen-vacancy magnetic resonance in diamond. _PRL,_ **104** (7), 070801 (2010). 

31. Hayashi, K., Matsuzaki, Y., Taniguchi, T., Shimo-Oka, T., Nakamura, I., Onoda, S., Ohshima, T., Morishita, H., Fujiwara, M., Saito, S. and Mizuochi, N. Optimization of temperature sensitivity using the optically detected magnetic-resonance spectrum of a nitrogen-vacancy center ensemble. _Phys. Rev. Appl.,_ **10** (3), p.034009 (2018) 

32. Zhang, N., Yuan, H., Zhang, C., Xu, L., Zhang, J., Bian, G., Fan, P., Yuan, H. and Fang, J. Microwave field uniformity impact on DC magnetic sensing with NV ensembles in diamond. _IEEE Sensors Journal_ , **19** (2), pp.451-456 (2018) 

33. Soltamov, V.A., Kasper, C., Poshakinskiy, A.V., Anisimov, A.N., Mokhov, E.N., Sperlich, A., Tarasenko, S.A., Baranov, P.G., Astakhov, G.V. and Dyakonov, V. Excitation and coherent control of spin qudit modes in silicon carbide at room temperature. _Nat. Commun._ , **10** (1), 1-8 (2019) 

34. Liu, W., Li, Z. P., Yang, Y. Z., Yu, S., Meng, Y., Li, Z. C., Guo, G. C. et al. Temperature-dependent energy-level shifts of Spin Defects in hexagonal Boron Nitride. _arXiv preprint arXiv_ :2101.09920 (2021). 

9 

