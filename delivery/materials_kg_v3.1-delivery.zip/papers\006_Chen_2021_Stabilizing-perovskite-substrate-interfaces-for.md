# Stabilizing perovskite-substrate interfaces for high-performance perovskite modules

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 690 |
| 作者 | Shangshang Chen, Xuezeng Dai, Shuang Xu, Hao-Yang Jiao, Liang Zhao, Jin-Song Huang |
| DOI | 10.1126/science.abi6323 |
| 源文件 | 006_Chen_2021_Stabilizing-perovskite-substrate-interfaces-for.pdf |

---
# Stabilizing perovskite-substrate interfaces for high-performance perovskite modules 

Shangshang Chen, Xuezeng Dai, Shuang Xu, Haoyang Jiao, Liang Zhao, Jinsong Huang* 

The interfaces of perovskite solar cells (PSCs) are important in determining their efficiency and stability, but the morphology and stability of imbedded perovskite-substrate interfaces have received less attention than have top interfaces. We found that dimethyl sulfoxide (DMSO), which is a liquid additive broadly applied to enhance perovskite film morphology, was trapped during film formation and led to voids at perovskite-substrate interfaces that accelerated the film degradation under illumination. Partial replacement of DMSO with solid-state carbohydrazide reduces interfacial voids. A maximum stabilized power conversion efficiency (PCE) of 23.6% was realized for blade-coated p-type/intrinsic/n-type (p-i-n) structure PSCs with no efficiency loss after 550-hour operational stability tests at 60°C. The perovskite mini-modules showed certified PCEs of 19.3 and 19.2%, with aperture areas of 18.1 and 50.0 square centimeters <mark>,</mark> res <mark>p</mark> ectivel <mark>y</mark> . 

ertified power conversion efficiencies (PCEs) for perovskite solar cells (PSCs) have exceeded 25% for small-area singlejunction cells and 29% for perovskiteC silicon tandem cells (1–3). However, degradation caused by various stimuli remains a critical challenge for PSC commercialization (4, 5). Degradation of PSCs starts from the interfaces, including both perovskite-metal electrodes and perovskites-substrates, where defects enrich (6–9). However, most research efforts have focused on stabilizing perovskitemetal electrode interface through surface passivation (10) or post-fabrication treatment (11), whereas the imbedded perovskite-substrate interface has received less attention, in part because of difficulties in its study with morphology characterization methods such as scanning electron microscopy (SEM) or atomic force microscopy (AFM). Nevertheless, stabilizing the imbedded bottom interfaces is as important as that of top interface (12). Trap density profiling showed that the perovskite layers near the substrate side have an even higher defect concentration, particularly deep charge traps, than that of perovskite-metal electrode interfaces (6). High-resolution transmittance electron microscopy also revealed that perovskite at this interface contains amorphous regions or nanocrystals with large interface areas. Light is incident from the perovskitesubstrate interface and also makes it more vulnerable to degradation. 

these voids was related to the entrapped nonvolatile dimethyl sulfoxide (DMSO) near the bottom of perovskite films. We replaced DMSO partially with a solid-state leadcoordinating additive of carbohydrazide (CBH), which reduced the formation of interfacial voids, yielding blade-coated p-type/intrinsic/ n-type (p-i-n) structure PSCs with a highest stabilized PCE of 23.6% and a module efficiency of 19.2% (50.0 cm<sup>2</sup> ), certified by the National Renewable Energy Laboratory (NREL). In addition, the reduced interfacial voids and the CBH residuals in perovskite films stabilized the PSCs and improved the yield of highefficiency perovskite modules. 

The PSCs were fabricated with a p-i-n structure of glass/indium tin oxide (ITO)/poly[bis (4- phenyl)(2,4,6-trimethylphenyl)amine (PTAA)/ perovskite/fullerene (C60)/bathocuproine (BCP)/ copper (Cu). Both the PTAA hole-transporting layer (HTL) and perovskite films were prepared with a room-temperature blade-coating method that we had developed previously (13). A mixed solvent composing of volatile and nonvolatile solvents, such as volatile 2-methoxyethanol (2-ME) mixed with nonvolatile DMSO, has been widely adopted to coat large-area perovskite films (14–16). During the blade-coating of perovskite films, the majority fraction, 2-ME, quickly evaporated to leave the “wet” films under N2 blowing at room temperature. The small fraction of the nonvolatile DMSO retarded the crystallization to yield large grains as well as intimate contact with bottom substrates. 

In this work, we discovered a high density of voids at the perovskite-substrate interfaces of the bladed and spun perovskite films with a variety of compositions by peeling them off from the substrates. The perovskites around these voids underwent faster degradation under light illumination. The formation of 

In our previous study of blade-coating efficient methylammonium lead tri-iodide (MAPbI3) minimodules, the addition of 13% DMSO [molar ratio to lead (Pb)] optimized the formation of a crystalline intermediate phase with methylammonium iodide (MAI) and lead iodide (PbI2) (13), which then crystallized downward and converted into perovskite during thermal annealing (17). A dense and mirror-like MAPbI3 film was obtained and appeared visually to 

Department of Applied Physical Sciences, University of North Carolina, Chapel Hill, NC 27599, USA. *Corresponding author. Email: jhuang@unc.edu 

have intimate contact with the substrate. The morphology of the MAPbI3-substrate interface was investigated by first peeling off the bladecoated MAPbI3 films from the ITO glass substrates with an epoxy encapsulant (Fig. 1A, scheme). After exposing the perovskite bottom surfaces next to the PTAA HTL layer, we discovered by use of SEM voids in the perovskite surface with sizes of tens to hundreds of nanometers (Fig. 1B). These voids were not caused by the breakdown of perovskite grains during the peeling-off process; otherwise, residual particles would have been left on the ITO substrates, and none was seen in SEM, AFM, and x-ray photoelectron spectroscopy (XPS) characterizations on the corresponding ITO substrates after their peeling off (fig. S1). 

In addition to MAPbI3, other compositions, such as MAI-FAI (FAI, formamidinium iodide) mixed perovskites, showed similar amounts or even more voids at the perovskite-substrate interfaces. Replacing MAI partially or completely with FAI has been widely adopted in the perovskite photovoltaic community to enhance material stability and broaden the absorption spectrum (18, 19). We used MA0.6FA0.4PbI3 as the perovskite composition, which remained in the black phase at room temperature. To bladecoat high-quality FAI-containing perovskite films, the percentage of DMSO had to be much higher than that for MAPbI3. It proved much harder to form the FAI-PbI2-DMSO intermediate phase by using the same solvent system, and we had to add more DMSO to retard its crystallization. Previous reports found that pure FAPbI3 films spun from DMSO-containing precursor solutions had no notable FAI-containing intermediate phase (20). 

We studied the effect of DMSO on the perovskites near the HTL interface by changing the molar ratio of DMSO to Pb in MA0.6FA0.4PbI3 precursor solutions from 0 to 50%. Using the same peeling technique, the bottom interface morphology (Fig. 1B) at a lower amount of DMSO (<13%) was very poor. Insufficient DMSO was present, and rapid crystallization of the precursor solution rapidly created a porous film full of voids. Increasing the amount of DMSO to Pb from 13 to 25% reduced both the density and size of voids at the perovskite bottom interface. The PCEs of the corresponding PSCs increased from 19.0 to 21.5% (fig. S2 and table S1). Further increasing the amount of DMSO to 38% yielded a maximum PCE of 22.0% (hereafter denoted as the control device), despite the density of interfacial voids increasing and the reappearance of some large voids. The presence of the interfacial voids was also confirmed with cross-sectional SEM (fig. S3) and focused ion beam (FIB)–SEM (fig. S4A) characterizations. Increasing the amount of DMSO to 50% created a film with much larger interfacial voids and a PCE of 16.4%. 































Fig. 1. Investigate the morphology of perovskite-substrate interfaces by peeling off perovskite films from ITO glass substrates. (A) Schematic of peeling off perovskite films from ITO glass substrates with an epoxy encapsulant for SEM characterization. (Right) A peeled-off device from ITO glass substrate. (B) Top-view SEM images of the perovskite-substrate interfaces of the blade-coated perovskite films that were prepared from the precursor solutions with different amounts of DMSO and then peeled off from ITO glass substrates. Scale bars, 1 mm. (C) Schematic shows how the voids are formed at the perovskitesubstrate interfaces. (D) Top-view SEM images of the peeled-off perovskite-substrate interfaces of the light-soaked MA0.6FA0.4PbI3 films. Scale bars, 1 mm. 

We recently observed that the crystallization of perovskite films by using one-step solution deposition methods generally started at the film-air interface as the solvents evaporate from the film top surface, quickly forming a solid shell that temporarily traps “wet” films containing high–boiling point DMSO (17). The trapped DMSO solvent would eventually 

escape the films, particularly after further annealing, which left voids in the perovskite films near the perovskite-substrate interface because of the volume collapse (Fig. 1C). This phenomenon was more evident in the coated thick films that further delayed the escape of DMSO from the bottom side. We also examined perovskite films including MAPbI3, 

Cs0.05FA0.81MA0.14PbI3, and Cs0.4FA0.6PbI1.95Br1.05 spun from DMSO-containing precursor solutions. Voidswereobservedatalltheperovskite-substrate interfaces (fig. S5), showing this phenomenon to be a general issue, despite almost all reported record performance devices fabricated with a solution process by using DMSO solutions (2, 20, 21). 

















substrate. Scale bar, 1 mm. (D) XPS spectra of the (bottom) perovskite-substrate and (top) perovskite-air interfaces of an identical target MA0.6FA0.4PbI3 film. (E) PL maps of the (left) control and (right) target perovskite films on thin glass excited from the glass side with a 485-nm laser. 

Fig. 2. Characterization of perovskite films. (A) Chemical structures of DMSO and CBH. (B) FTIR spectra of DMSO, CBH, and the MA0.6FA0.4PbI3 films with the addition of DMSO and CBH. (C) Top-view SEM image of the perovskitesubstrate interface of the target perovskite film peeled off from ITO glass 

To investigate the evaporation rate of DMSO in perovskite films during thermal annealing, we scraped the perovskite films off glass substrates and dissolved them in deuterium oxide (D2O) and then performed proton nuclear magnetic resonance (<sup>1</sup> H NMR) characterization of the solutions to determine how much DMSO was trapped in each stage of annealing. By comparing the integrated area of DMSO<sup>1</sup> H NMR peak and those of MAI and FAI (fig. S6), we were able to quantify the relative amount of DMSO to MAI or FAI, and then that of Pb in the perovskite films. As shown in fig. S7, the evaporation of DMSO occurred in two stages: a rapid evaporation in the first few seconds and a slow process from 5 s to 1 min. The top solid shell also forms within a few seconds (17), and the slow evaporation of DMSO in the second stage should be caused by the hinderance from the perovskite top shell. Because nearly 90% of DMSO in the perovskite solution evaporated in the first 5 s, about 10% of DMSO, or ~2 mole % (mol %) relative to Pb, was trapped initially in the wet bottom layer. We estimate that it would cause a total void volume of 0.01 mm<sup>3</sup> per cubic micrometer of perovskites on the basis of the residual DMSO amount when the subsequent 

entrapped DMSO leaves the perovskite-substrate interface. This roughly agrees with the results (1% volume ratio to perovskites) obtained by analyzing the relative ratio between the regions of perovskite grains and voids in the top-view SEM image (fig. S8) and the void depth of ~100 nm. 

We examined the effect of the interfacial voids on the stability of the perovskite films. Encapsulated MA0.6FA0.4PbI3 control films were light-soaked under simulated 1-sun illumination at 60°C for different durations and then peeled off from ITO substrates for SEM characterization. Some small white regions started to appear around the voids after 4 hours of lightsoaking (Fig. 1D). These white regions are generally caused by a charging effect in electron-beam scanning, which is caused by less conductive decomposition products. After 8 hours, the white regions expanded, accompanied with the generation of more and larger ones, whereas the regions without voids showed barely any change. Thus, interfacial voids initialized film degradation at the perovskitesubstrate interface. 

Several perovskite degradation mechanisms could be triggered by interfacial voids. Photogenerated holes surrounding the voids could 

not be quickly extracted by the HTL, which would lead to charge accumulation that accelerates perovskite degradation by increasing ion migration (22). The surface of the voids would be similar to perovskite top surfaces that are generally defective, and lack of passivation coatings would make them degrade more quickly. Voids can act as a reservoir for decomposition products such as iodine vapor, which is generated in perovskite films during light-soaking (23, 24) and can accelerate decomposition (25–27). Recent studies also show that passivating the perovskite film surfaces can effectively shift the reaction balance for iodide interstitials and thus prevent the iodide generation under illumination (23). 

To address this issue, we replaced partial DMSO with a solid-state CBH additive (melting point 153°C, denoted as target films or PSCs) that can also coordinate with Pb cations by meansofitsC=Obond,similartoDMSO(Fig.2A). CBH barely evaporated during thermal annealing and thus remained within the perovskite films (figs. S9 and S10). It avoids the volume collapse during annealing and thus reduces void formation.Moreover,CBHcanreducethedetrimentalI2 generated in perovskite films. First, we confirmed 





<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->













Fig. 3. Photovoltaic performance of PSCs. (A) J-V curve of the champion target PSC. (Inset) The stabilized power output of the champion target PSC fixed at a bias of 1.04 V for 600 s. (B) The efficiency distribution of 65 target PSCs. (C) Operational stability test results of the encapsulated control and target PSCs processed under 1-sun equivalent illumination in air. Neither cooling nor UV filters were used in this test. (Inset) The top-view SEM images 

of the peeled-off perovskite-substrate interface of the light-soaked (left) control and (right) target PSCs after stability test. Scale bars, 1 mm. (D) UV-vis absorption spectra of the toluene solutions in which control and target MA0.6FA0.4PbI3 films were immersed under 1-sun illumination for 15 hours. (Inset) A picture of the vials in which each film (15 by 15 mm) was immersed into 5 ml of toluene. 

the shifted Fourier-transform infrared spectroscopy (FTIR) peak of C=O bond after introducing CBH into the MA0.6FA0.4PbI3 films (Fig. 2B). Such an interaction was found to slow down the rapid crystallization and enhance crystallization of perovskite films (figs. S11 and S12). 

Because of the nonvolatility of CBH, voids were dramatically reduced with the CBH additive (Fig. 2C and figs. S4B and S13). Some amount of DMSO (~25% to Pb) in the solution was needed to help the grain growth, but it was the entrapped 10% of DMSO that caused void formation. The quick top perovskite shell formation and later release of CBH molecules from the CBH-Pb coordinates should expel some CBH molecules toward HTL side because of the film-downward crystallization evidenced by the grazingincidence x-ray diffraction (GIXRD) results (fig. S14). XPS characterization of both perovskite-air and perovskite-HTL interfaces of the identical target perovskite films showed 

more CBH molecules at perovskite-HTL interface (Fig. 2D), whereas the control film only showed a single ammonium peak (fig. S15). In addition, we performed the photoluminescence (PL)mappingoftheperovskitefilmsexcitedfrom the thin cover glass side. The target perovskite film showed both more uniform PL emission (likely from fewer voids) and stronger PL emission (from passivation effects) than those of the control film (Fig. 2E). Both effects should reduce charge recombination and facilitate charge extraction. 

The current density-voltage (J-V) characteristics show that the target PSCs delivered a PCE of 23.8% (Fig. 3A), with an elevated opencircuit voltage (VOC) of 1.17 V, a short-circuit current density (JSC) of 24.1 mA cm<sup>−2</sup> , and a fill factor (FF) of 0.842. The optical bandgap of the target PSCs determined from the absorption onset of the external quantum efficiency (EQE) spectra is 1.49 eV (fig. S16), which gave a small 

VOC deficit of 0.32 V. The champion PSC showed a stabilized PCE of 23.6% (Fig. 3A, inset). The PSCs also showed good reproducibility (Fig. 3B), where 50 and 88% of PSCs can realize PCEs of more than 22.5 and 22.0%, respectively. 

We tested the long-term stability of encapsulated perovskite devices under a plasma lamp with a light intensity equivalent to AM (air mass coefficient) 1.5 G (global) in air at a relative humidity of ~40 ± 10%. No ultraviolet (UV) filter was used during the tests. All devices were connected to an automatic maximum power point (MPP) tracker so that the devices kept working under MPP conditions during light-soaking. The temperature of the devices was measured to be ~60°C (the heating effect of light). The operational stability of control and CBH-incorporated PSCs is compared in Fig. 3C. The CBH-incorporated PSC shows negligible efficiency loss after 550 hours of light-soaking, whereas the control one was 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->













112 minimodules. (Inset) The aperture efficiency distribution of 112 minimodules. (D) Long-term operational stability results of five perovskite minimodules under simulated 1-sun illumination at 50°C. The abrupt PCE change at ~400 hours was caused by the replacement of the peeling-off PDMS antireflection layers. 

Fig. 4. Photovoltaic performance of perovskite minimodules. (A) J-V characteristics of two perovskite minimodules with aperture areas of 17.9 and 50.1 cm<sup>2</sup> , respectively. (B) NREL certified stabilized current-voltage dots around the MPP point of the minimodules with aperture areas of 18.1 and 50.0 cm<sup>2</sup> . (C) Average efficiencies versus aperture areas of 

area of 3.6 cm<sup>2</sup> in the best minimodule has a JSC of 23.7 mA cm<sup>−2</sup> , VOC of 1.17 V, and an active area efficiency of 21.8%. 

the light-soaking back to I<sup>–</sup> . We immersed the target film into a vial filled with 5 ml of toluene and then illuminated it for 15 hours. The UV–visible (vis) absorption spectra of the toluene extractions show that the formation of iodine has been suppressed by the residual CBH (Fig. 3D). 

near zero-power output after ~200 hours of light-soaking. This good stability was realized without further post-treatments on the bladecoated perovskite films. 

We sent our most effective minimodules to NREL for certification, and a highest stabilized aperture efficiency of 19.3 and 19.2% were reached for the minimodules with the certified aperture areas of 18.1 and 50.0 cm<sup>2</sup> , respectively (Fig. 4B and figs. S19 and S20). Stabilizing photocurrent is needed to get the accurate efficiency for module measurement, and regular J-V scanning generally overestimates the module efficiency by 0.5 to 1% regardless of scanning rates. The aperture efficiencies of 112 minimodules were further analyzed statistically, and their distribution is shown in Fig. 4C, inset, with their detailed photovoltaic parameters listed in table S2. More than 50% of minimodules showed aperture PCEs of >19.0%, and 77% of them had efficiencies of >18.5%, 

After the stability tests, we peeled off the light-soaked devices from ITO glass substrates and performed SEM characterization of the perovskite-substrate interfaces. The control device showed substantial degradation at its perovskite-substrate interface accompanied with the merging of the voids, whereas the CBH device did not show notable morphology changes at the bottom interface (Fig. 3C). The enhanced operational stability we attributed not only to the reduction in interfacial voids that accumulate charges and decomposition products but also to CBH being an effective reductant (fig. S17). The CBH residuals in perovskite films could further reduce the detrimental iodine formed in perovskites during 

We evaluated the compatibility of the CBH additive with upscaling processes by fabricating perovskite minimodules with aperture areas from 10.7 to 60.8 cm<sup>2</sup> by means of blade-coating. The minimodules with 5 and 14 subcells showed high aperture efficiencies of 20.1% (VOC = 1.17 V; JSC = 21.8 mA cm<sup>−2</sup> ; and FF = 0.786 for each subcell) and 19.7% (VOC =1.15 V; JSC = 21.5 mA; FF = 0.798 for each subcell) with aperture areas of 17.9 and 50.1 cm<sup>2</sup> , respectively (Fig. 4A), derived from J-V scanning. The geometric fill factor (GFF) of the champion minimodules was 92% (fig. S18); thus, each subcell with an 

indicatingthegoodreproducibilityofthis method. We also plot efficiencies and aperture areas of the 112 minimodules in Fig. 4C. Module efficiencies were not sensitive to their aperture areas, and a high efficiency of (18.3 ± 0.48)% was maintained with increasing aperture areas to >60 cm<sup>2</sup> as a result of high film uniformity after introducing CBH. Furthermore, the long-term operational stability of the highly efficient perovskite minimodules was also tested with the statistical results (Fig. 4D). Five minimodules retained 85% of initial PCEs after 1000 hours of lightsoaking under simulated 1-sun illumination at 50°C. 

## REFERENCES AND NOTES 

1. NREL, Best Research-Cell Efficiency Chart (2021); www.nrel.gov/pv/cell-efficiency.html. 

2. J. J. Yoo et al., Nature 590, 587–593 (2021). 

3. A. Al-Ashouri et al., Science 370, 1300–1309 (2020). 

4. Y. Rong et al., Science 361, eaat8235 (2018). 

5. J.-P. Correa-Baena et al., Science 358, 739–744 (2017). 

6. Z. Ni et al., Science 367, 1352–1358 (2020). 

7. S. Yang et al., Science 365, 473–478 (2019). 

8. F. Wang, S. Bai, W. Tress, A. Hagfeldt, F. Gao, npj Flexible Electronics 2, 22 (2018). 

9. S. P. Dunfield et al., Adv. Energy Mater. 10, 1904054 (2020). 

10. B. Chen, P. N. Rudd, S. Yang, Y. Yuan, J. Huang, Chem. Soc. Rev. 48, 3842–3867 (2019). 

11. J. Xue, R. Wang, Y. Yang, Nat. Rev. Mater. 5, 809–827 (2020). 

12. X. Yang et al., Adv. Mater. 33, e2006435 (2021). 

13. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

14. D.-K. Lee, D.-N. Jeong, T. K. Ahn, N.-G. Park, ACS Energy Lett. 4, 2393–2401 (2019). 

15. J. Li et al., Adv. Energy Mater. 11, 2003460 (2021). 

16. K. H. Hendriks et al., J. Mater. Chem. A Mater. Energy Sustain. 5, 2346–2354 (2017). 

17. S. Chen et al., Sci. Adv. 7, eabb2412 (2021). 

18. S.-H. Turren-Cruz, A. Hagfeldt, M. Saliba, Science 362, 449–453 (2018). 

19. Y. Deng, Q. Dong, C. Bi, Y. Yuan, J. Huang, Adv. Energy Mater. 6, 1600372 (2016). 

20. M. Kim et al., Joule 3, 2179–2192 (2019). 

21. H. Min et al., Science 366, 749–753 (2019). 

22. Y. Lin et al., Nat. Commun. 9, 4981 (2018). 

23. S. G. Motti et al., Nat. Photonics 13, 532–539 (2019). 

24. N. Aristidou et al., Angew. Chem. Int. Ed. 54, 8208–8212 (2015). 

25. F. Fu et al., Energy Environ. Sci. 12, 3074–3088 (2019). 

26. S. Wang, Y. Jiang, E. J. Juarez-Perez, L. K. Ono, Y. Qi, Nat. Energy 2, 16195 (2016). 

27. S. Chen, X. Xiao, H. Gu, J. Huang, Sci. Adv. 7, eabe8130 (2021). 

## ACKNOWLEDGMENTS 

Funding: The material and characterization research was supported by the Center for Hybrid Organic Inorganic 

Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the US Department of Energy. The demonstration of modules and related stability studies were supported by Office of Naval Research (ONR) under award N6833520C0390. We thank the University of North Carolina’s Department of Chemistry NMR Core Laboratory for NMR spectrometers, and ONR award N00014-18-1-2239 for PL mapping. Author contributions: S.C. and J.H. conceived the idea. S.C. fabricated and characterized the perovskite films and devices. X.D. performed laser scribing. S.X. carried out PL measurement and prepared the film samples for GIXRD, FIB-SEM, and partial NMR characterizations. H.J. carried out FIB milling, and acquired the FIB-SEM images and partial NMR spectra. L.Z. performed GIXRD measurement. S.C. and J.H. wrote the manuscript, and all authors commented on the manuscript. Competing interests: J.H. has disclosed a financial interest with Perotech. J.H. and S.C. are inventors of an invention disclosure covering this work filed by University of North Carolina Chapel Hill. The other authors declared no competing interests. Data and materials availability: All data are available in the main text or the supplementary materials. 

## SUPPLEMENTARY MATERIALS 

science.sciencemag.org/content/373/6557/902/suppl/DC1 Materials and Methods Figs. S1 to S20 Tables S1 and S2 22 March 2021; accepted 7 July 2021 10.1126/science.abi6323 

