# Transfer of large-scale two-dimensional semiconductors: challenges and developments

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | 2D Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 199 |
| 作者 | A. Watson, Wen-Bo Lu, M. Guimarães, M. Stöhr |
| DOI | 10.1088/2053-1583/abf234 |
| 源文件 | 034_Watson_2021_Transfer-of-large-scale-two-dimensional-semicond.pdf |

---
# **Transfer of Large-Scale Two-Dimensional Semiconductors: Challenges and Developments** 

_Adam J. Watson, Wenbo Lu, Marcos H. D. Guimarães_ * _and Meike Stöhr_ * 

A. J. Watson, W. Lu, Prof. M. Guimaraes, Prof. M. A. Stöhr Zernike Institute for Advanced Materials (ZIAM) University of Groningen Nijenborgh 4, 9747 AG, The Netherlands Email: <u>m.h.guimaraes@rug.nl</u> and <u>m.a.stohr@rug.nl</u> 

Keywords: 2D materials, transition metal dichalcogenides, transfer techniques, chemical 

vapor deposition, Van der Waals materials, characterization techniques 

Abstract: Two-dimensional (2D) materials offer opportunities to explore both fundamental science and applications in the limit of atomic thickness. Beyond the prototypical case of graphene, other 2D materials have recently come to the fore. Of particular technological interest are 2D semiconductors, of which the family of materials known as the group-VI transition metal dichalcogenides (TMDs) has attracted much attention. The presence of a bandgap allows for the fabrication of high on-off ratio transistors and optoelectronic devices, as well as valley/spin polarized transport. The technique of chemical vapour deposition (CVD) has produced highquality and contiguous wafer-scale 2D films, however, they often need to be transferred to arbitrary substrates for further investigation. In this Review, the various transfer techniques developed for transferring 2D films will be outlined and compared, with particular emphasis given to CVD-grown TMDs. Each technique suffers undesirable process-related drawbacks such as bubbles, residue or wrinkles, which can degrade device performance by for instance reducing electron mobility. This Review aims to address these problems and provide a systematic overview of key methods to characterize and improve the quality of the transferred films and heterostructures. With the maturing technological status of CVD-grown 2D materials, a robust transfer toolbox is vital. 

1 

# **1. Introduction** 

Ever since the discovery and isolation of graphene by Geim and Novoselov in 2004<sup>[1]</sup> using the technique of mechanical exfoliation (the ‘Scotch tape’ method), the field of twodimensional (2D) materials has become one of the most intensively researched in condensed matter physics. 2D layered materials (2DLMs) offer opportunities to explore fundamental physics in the limit of atomic thickness, and have advantages over existing materials with regards to technological applications.<sup>[2]</sup> Graphene, the prototypical 2D material, has numerous interesting properties, including a high mobility, transparency, tensile strength, etc.<sup>[3]</sup> However, lacking a bandgap<sup>[4]</sup> , it is limited in its applications, for instance in optoelectronics and for conventional field-effect transistors (FETs).<sup>[5]</sup> Hence, other 2D materials have been investigated. Transition metal dichalcogenides (TMDs) are a class of materials with a rich catalogue of novel properties, many of which go beyond those of graphene. Their general formula is given as MX2, where M is a transition metal atom, and X is a chalcogen atom (usually S, Se or Te). The group-VIB TMDs (e.g. MoS2 and WSe2) represent the most extensively studied in the monolayer (ML) limit. The exciting technological potential has been realized in the demonstration of atomically thin FETs<sup>[6–9]</sup> , tunable photovoltaic or light emitting devices for optoelectronic applications<sup>[10–12]</sup> , as well as more exotic devices based on spin-valley coupling.<sup>[13]</sup> 

Initial research on 2D TMDs relied on mechanical exfoliation from a bulk crystal. However, this method yields unpredictable flake thickness and domain sizes, which are usually on the order of a few microns. Moreover, the method is relatively time consuming. To meet the demands placed upon TMDs with respect to their technological applications, two conditions must be met. Firstly, scalable production methods are required. High quality 2D TMDs, of wafer scale, are needed to produce integrated circuits (ICs), compatible with existing industrial fabrication methods. Recently, the technique of chemical vapor deposition (CVD) has been 

2 

used to successfully grow large area TMD films (up to centimeter scale) with high uniformity, in a cost effective manner.<sup>[14–18]</sup> Samples made using this method have shown properties on par with, or even surpassing, those of exfoliated films.<sup>[19]</sup> The second condition is flexibility over substrate choice. This remains a challenge for the CVD method, as the target substrates for TMD-based devices may not be able to withstand the high-temperature environment produced during the CVD growth process.<sup>[20]</sup> Furthermore, it is also desirable to fabricate heterostructures from individual TMD films, with customizable stacking order. This requires a systematic methodology for transferring large-scale TMD films from their growth substrate onto a target substrate, while maintaining the intrinsic structural and physicochemical properties that make 2D TMDs so appealing. Hence, any successful transfer method must allow for a uniform separation of the film from its growth substrate, and also maintain the structural integrity of the film during the transfer steps. 

Many transfer techniques were developed initially to transfer mechanically exfoliated flakes of graphene. One of the most common methods uses polymethyl methacrylate (PMMA) as a support layer to transfer the exfoliated flake to the desired target substrate.<sup>[21,22]</sup> Such a method has been successful at transferring exfoliated flakes to diverse substrates. However, modifications to this method are required for CVD-grown 2DLMs. Substrates used in CVD (such as SiO2/Si or mica) do not have a water-soluble layer commonly used in the standard PMMA method for exfoliated flakes, requiring other methods to remove the 2DLM from the growth substrate. Often this entails harsh chemical etchants such as KOH, which can damage the 2DLM. Furthermore, because of the size of the film being transferred (up to centimeter scale), maintaining the structural integrity of the film is of paramount importance to ensure a uniform transfer. Thus, mechanical supports take on a more critical role. Polymers, including PMMA, fulfil this role. However, the problems associated with using these materials, such as cracks, wrinkles or polymer residue, have led to a search for other materials to serve as supports, 

3 

and some methods forgo the use of any support entirely. **Figure 1** illustrates some of these 

problems. 



**Figure 1.** Schematic illustration of the transfer of a 2DLM onto an arbitrary substrate. The right image indicates the kinds of issues that are encountered from the transfer procedure, including cracks, residues from the supports, trapped bubbles, and wrinkles. 

The purpose of this Review is to provide an overview of the transfer methodologies currently used to transfer CVD-grown TMDs, and to offer a means to quantify and potentially solve their process-related drawbacks. Crucially, the Review is written with an eye to industrial applications. This will provide a grounding for fledgling researchers who are starting their work on CVD-grown 2D materials and the fabrication of van der Waals heterostructures. To this end, Section 2 will begin with a scheme to categorize the various transfer methods. The similarities and, perhaps more crucially, the differences between graphene and TMDs will be outlined. This is important as many of the transfer methods that work with graphene may not work identically with TMDs, owing to the different structural make-up of each material type. The various transfer techniques will be outlined, and the section will conclude with a critical comparison between each method. In Section 3, the process related drawbacks often encountered in transferring CVD TMDs will be discussed. Problems such as polymer residue, cracks or wrinkles (to name a few) are encountered routinely in CVD-based transfer. These often degrade 

4 

the properties of the film and fabricated devices. However, a comprehensive investigation has not yet been done on these problems, which need to be solved if TMDs are to be industrially applicable. To this end, an overview of the various problems with transfer will be given, as well as a description of the techniques to characterize them quantitatively. Finally, a conclusion will draw together the various threads of the Review to provide a commentary on the current state of transfer techniques for large area CVD-grown TMDs, and an outlook on future developments. 

# **2. Transfer methods for 2D TMDs** 

In this section, a categorization scheme for the transfer of 2D TMDs is introduced. Many of these techniques, originally developed for the deterministic transfer of exfoliated flakes, are now finding application for CVD-grown 2DLMs, with some modifications. These modifications are needed due to the larger size of CVD-grown 2DLMs. Issues relating to surface energetics, film quality and uniformity, and structural supports are more prominent, as the spatial variation of forces can lead to film breakage or other undesirable effects. In addition to the mechanical differences between exfoliated and CVD materials transfer, the transfer of large-scale 2DLMs is highly relevant for technological applications. It is therefore instructive to provide an overview of the various large-scale transfer techniques employed so far, including a discussion of their advantages and disadvantages, and also describe how they have been used for CVD-grown TMD 2DLMs. Traditionally, transfer techniques are classified into ‘wet’ and ‘dry’ categories. Dry transfer involves no direct contact of the 2DLM with water or chemicals during the main transfer step. Wet techniques involve the delamination of the 2D films from their original substrates using water, or chemicals in the liquid phase. Within these categories, a more convenient delineation can be made into methods that use supports (such as polymers), and those that do not. This is because many transfer methods use a mixture of wet and dry 

5 

techniques, resulting in some ambiguity when using the traditional classification. In contrast, supporting layers (or lack thereof) provide a clearer means of distinguishing between the various methods. Each of these methods will be described in detail below. A comparative overview of some of the key mechanical properties between TMDs and supports is given in 

**Table 1** . 

**Table 1.** Mechanical properties of TMDs and their supports. 

|Materials|Surface Energy<br>[mJ m<sup>-2</sup>]|Young’s Modulus<br>[Gpa]|TEC<br>[× 10<sup>-6</sup>K<sup>-1</sup>]|
|---|---|---|---|
|MoS2|35-48.3<sup>[23,24]</sup>|270<sup>[25]</sup>|7.6<sup>[26]</sup>|
|MoSe2|Unav.|177<sup>[27]</sup>|7.24<sup>[28]</sup>|
|WS2|39<sup>[24]</sup>|272<sup>[29]</sup>|10.3<sup>[30]</sup>|
|WSe2|Unav.|167<sup>[31]</sup>|14.5<sup>[32]</sup>|
|PMMA|41<sup>[33]</sup>|8 × 10<sup>-3 [34]</sup>|180<sup>[35]</sup>|
|PDMS|19.8<sup>[33]</sup>|3.6-8.7 × 10<sup>-4 [36]</sup>|906<sup>[35]</sup>|
|PVP|48-63<sup>[37]</sup>|0.12<sup>[38]</sup>|Unav.|
|PS|40.7<sup>[33]</sup>|3.5<sup>[39]</sup>|200<sup>[35]</sup>|
|PVA|36.5<sup>[33]</sup>|1.6 × 10<sup>-2 [40]</sup>|Unav.|
|CA|35.04<sup>[41]</sup>|2<sup>[42]</sup>|73<sup>[42]</sup>|
|Cu|1650<sup>[43]</sup>|100<sup>[44]</sup>|16.7<sup>[45]</sup>|



# **2.1 TMD transfer with a support layer** 

One of the first methods developed to transfer 2DLMs involved using a supporting layer on 

6 

top to better control the strain and forces during transfer. Polymers are the material of choice due to their flexibility, mechanical strength and ability to form a uniform contact with the 2DLM, but other supports (such as thin metallic films) have been used as well. The majority of TMD transfer techniques developed so far find their origins in those developed for graphene transfer<sup>[21,22,46–48]</sup> , but the underlying principles are similar. This is mainly a result of the fact that both materials are van der Waals (vdW) materials, meaning the surface energetics are similar. The surface energy of a material can be described by Young’s equation, written as 



<!-- Start of picture text -->
σsgsg = σslsl + σlg cos θ    lg cos θ     cos θ     (1)<br><!-- End of picture text -->

where _σsl_ is the interfacial tension between the liquid and solid, and 𝜃𝜃 is the contact angle between the liquid and solid,σsgsg = σslsl + σlg cos θ    lg cos θ     cos θ _σlg_ is the surface tension of the liquid, (1) _σsg_ is the surface free energy of the solid in units of J m<sup>-2</sup> . A schematic outlining the various terms is shown in **Figure 2** . In general, a hydrophobic surface will give a contact angle of ≥ 90°, resulting in a low surface energy, whereas a hydrophilic surface will give a contact angle of < 90°, giving a higher surface energy. 



**Figure 2.** A schematic diagram of the components of a 3-phase system relevant to determining 

the surface energy of a material. _σsg, σls_ and _σlg_ represent the surface tension (in J m<sup>-2</sup> ) of the solid-gas interface, the liquid-solid interface and the liquid-gas interface, respectively. As the angle θ approaches 90°, _σsg_ is lowered. 

7 

As illustrated by the equation (1), the proper choice of polymer support is affected by the surface energy of the polymer, the growth substrate and the destination substrate, ultimately determining the quality of the transferred film.<sup>[49]</sup> A lower surface energy corresponds to a lower adhesion force<sup>[50]</sup> , meaning that polymers with lower surface energy will be more easily removed with minimum damage or residues. On the other hand, the surface energy of the target substrate must be larger than that of the polymer, to ensure proper adhesion of the transferred film to the new substrate. Thus, care must be given to substrate and polymer choice. 

Both graphene and TMDs offer a unique combination of mechanical properties, such as a high in plane stiffness and strength, as well as a low bending modulus. But despite the _prima facie_ similarities between the two material types, there are some notable differences in their mechanical properties. For example, the Young’s modulus of MoS2 (130 N m<sup>-1</sup> )<sup>[51]</sup> is less than half that of graphene (340 N m<sup>-1</sup> )<sup>[52]</sup> . On the other hand, MoS2 has a bending modulus of 9.61 eV<sup>[53]</sup> , which is about 7 times larger than that of graphene (1.4 eV)<sup>[54]</sup> . This is due to the trilayer atomic structure of MoS2, resulting in more interaction terms in the bending energy calculation, which restricts the bending motion. This has implications for transfer, as it means TMDs do not buckle as readily under external compression, which is advantageous compared to graphene. One of the most striking differences, however, is in the thermal expansion coefficient (TEC) of both materials. For TMDs, the TEC is positive. MoS2, for instance, has a value of ~7.6 × 10<sup>-6</sup> K<sup>-1</sup> ,<sup>[26]</sup> and for WS2 it is ~10 × 10<sup>-6</sup> K<sup>-1</sup> .<sup>[30]</sup> For graphene, however, it is negative, with an average value of -3.75 × 10<sup>-6</sup> K<sup>-1</sup> .<sup>[55]</sup> Since the TEC of most polymers (and all metals) are positive, we would expect significant strain during any heating step, leading to wrinkles and cracks when using such supports for graphene transfer<sup>[56,57]</sup> , and much less so for TMDs. Below, we look at some of the main methods of transferring TMD films using mechanical supports. 

_2.1.1 Polymethyl methacrylate (PMMA)-assisted transfer_ 

First used as a support layer for the transfer of mechanically exfoliated flakes of 

8 

graphene<sup>[22,58]</sup> , the PMMA-assisted method was thereafter applied to CVD-grown graphene<sup>[59,60]</sup> , and then to CVD-grown MoS2 a few years later<sup>[61]</sup> . The standard procedure, for the case of CVD-grown MoS2 on a SiO2/Si substrate, is as follows<sup>[46]</sup> . (1) PMMA is spin-cast on top of MoS2 followed by baking at 100 °C for 10 min. (2) The PMMA/MoS2/SiO2/Si stack is then placed in a hot NaOH solution (100 °C for 30 min) to etch the SiO2 layer and detach the PMMA/MoS2 from the substrate. (3) The PMMA/MoS2 is rinsed with deionized (DI) water to remove remaining etchant and residues. (4) A target substrate is used to fish out the PMMA/MoS2 film and then dried on a hot plate (100 °C for 10 min). (5) Finally, the PMMA is removed with acetone and isopropyl alcohol (IPA), and rinsed with DI water and chloroform. Each step can be adjusted accordingly. For instance, instead of NaOH, another hot base solution of for example KOH can be used to etch the SiO2 layer.<sup>[62]</sup> 

The use of strong chemicals to etch the growth substrate means it cannot be reused, making the process relatively expensive, and perhaps prohibiting its use in industrial applications. Therefore, a different method was developed to detach the CVD-grown film from the growth substrate without wet etching processes, whilst keeping the PMMA support. Initially developed to delaminate graphene<sup>[63,64]</sup> , the so-called bubbling method uses bubble intercalation to weaken the adhesion between the 2D film and growth substrate. This method was used in a comparative study by Yun et al. in transferring centimeter scale monolayer CVD-grown WS2 on Au foil<sup>[65]</sup> . For the bubbling method, the WS2/Au assembly was immersed in a NaCl solution and used as a cathode. Hydrogen bubbles were produced between the WS2 film and Au surface according to the reaction 2H2O(l) + 2e<sup>-</sup> → H2(gas) + 2OH<sup>-</sup> (aq), separating the PMMA/WS2 layer from the Au foil and allowing it to be reused. The process is outlined in **Figure 3** (a). 

Another important development in the etching-free transfer process involves making use of a water-soluble sacrificial layer. Zhang et al _._ used a novel CVD method to grow MoS2 flakes on top of a crystalline layer of NaSx and NaCl, on a SiO2/Si substrate<sup>[66]</sup> . Precursors of both 

9 

NaCl and MoO3 in the ratio of 9:1, chosen due to their similar melting temperatures (795 °C and 801 °C respectively), are brought into the vapor phase. By exploiting the difference in dissociation energies of both the Na-O and Mo-O bonds, a layer of NaOx is formed first on the SiO2/Si substrate and then vulcanized by sulfur vapor to form NaSx, which is highly water soluble. Thereafter, MoS2 clusters form on top. The transfer step involves spin-casting PMMA on the MoS2 wafer, and then placing it in a container with a gradual addition of DI water. The NaCl/NaSx layer is dissolved and the PMMA/MoS2 layer is transferred to a new substrate. PMMA removal is carried out via an acetone treatment. 

Thermal release tape (TRT) provides another means by which TMD layers can be delaminated from their growth substrates, without the use of etchants or solvents.<sup>[16,67,68]</sup> Kang et al. made use of TRT and van der Waals stacking in vacuum to produce CVD-grown TMD heterostructures with clean interfaces.<sup>[16]</sup> PMMA was spin-cast first onto a monolayer TMD (called L0), and then TRT was used to peel it off the SiO2/Si substrate. The TRT/L0 stack was then pressed onto another TMD layer which was subsequently peeled off. The process was repeated until the desired number of layers was reached, after which the layers were placed onto a target substrate. The TRT was removed by applying heat and the PMMA, which was on the top layer only, was removed via acetone. In this method, although PMMA was used as a support in the initial step, the subsequent stacking of the monolayers was done via the van der Waals interaction. This process is outlined in Figure 3(b). 

The predominance of the PMMA-assisted method in the initial transfer of CVD-grown TMDs is largely a result of its use in transferring graphene films, where it serves as a robust supporting layer with good flexibility and adhesive contact.<sup>[69]</sup> A tried-and-tested methodology was developed which could simply be duplicated for use in transferring exfoliated films and, thereafter, larger-area TMD films for initial characterization. However, the harsh chemicals used to remove the PMMA, usually at elevated temperatures, results in damage to the TMD 

10 

layer. Moreover, the method invariably leaves a residue which is hard to remove with posttransfer cleaning procedures such as ultra-high vacuum annealing.<sup>[67,70]</sup> 



**Figure 3.** (a) Schematic illustrations of both the bubbling transfer and wet chemical etching techniques used in transferring WS2 from Au foil to a SiO2/Si substrate. For the bubbling method, the PMMA/WS2/Au assembly is immersed in a NaCl solution, where the Au foil acts as a negatively charged cathode. Hydrogen bubbles are generated between the WS2 film and Au foil, creating a pressure which delaminates the WS2 film. In the final step, the PMMA is removed. The advantage of this method compared to the wet-etching method is that the Au foil can be reused. Reproduced with permission.<sup>[65]</sup> Copyright 2015, American Chemical Society. (b) The TRT assisted stacking process, carried out in vacuum. (I) First the individual layer is grown on SiO2/Si substrates via CVD. (II) TRT is placed onto the PMMA-coated first layer (L0), and peeled off the growth substrate. (III) A stacking procedure is done in vacuum, in which L0 is used to pick up the next layer (L1), and the process can be repeated to achieve the desired number of layers in the stack. (IV) TRT is used to peel the completed stack off the last growth substrate. (V) The assembly is placed on a target substrate, and the TRT is released via heating.  Reproduced with permission.<sup>[16]</sup> Copyright 2017, Springer Nature. 

11 

# _2.1.2 Polydimethylsiloxane (PDMS)-assisted transfer_ 

Polydimethylsiloxane (PDMS) is a widely used organic polymer that has found application in the transfer of 2DLMs, due to its hydrophobicity, transparency, high flexibility and low surface energy.<sup>[71,72]</sup> In particular, the lower surface energy of PDMS (~19-21 mJ m<sup>-2</sup> )<sup>[73]</sup> compared to that of common target substrates such as SiO2/Si (57 mJ m<sup>-2</sup> )<sup>[74]</sup> means that TMD layers can be detached from their PDMS supports with relative ease.<sup>[75]</sup> This means that the final step of removing the polymer layer with wet chemicals is not necessary, in principle resulting in a cleaner transfer. The use of PDMS in the transfer of CVD-grown TMD layers has been done<sup>[19,29,76–81]</sup> , with notable variations in methodology. For instance, in order to increase the adhesion force between PDMS and the MoS2 film, Kang et al. used hydrophilic dimethyl sulfoxide (DMSO) molecules in a DI water solution that were vaporized onto the PDMS surface at 270 °C, in order to increase the surface energy and therefore the adhesion force.<sup>[79]</sup> This meant the PDMS mold could pick up the whole MoS2 film from the SiO2/Si substrate. When the PDMS/MoS2 was brought into contact with the target substrate at 70 °C, the standard adhesion force of PDMS was restored and the MoS2 could successfully detach from the polymer stamp. This method, shown schematically in **Figure 4** (a), is an all-dry transfer process involving no wet chemical or etching steps. This has obvious advantages in terms of both transfer speed and resulting film cleanliness. 

In an alternative method<sup>[19]</sup> , Jia et al. took advantage of the hydrophobic PDMS stamp and the hydrophilic SiO2/Si substrate to delaminate CVD MoS2 using DI water droplets. This is schematically illustrated in Figure 4(b). The MoS2/substrate was pressed onto the PDMS stamp attached to a glass slide. Water droplets injected at the edge of the stamp penetrated between the MoS2 and substrate, detaching the MoS2 film reliably. The PDMS stamp was subsequently removed by peeling. The advantage of this method over the DMSO-mediated method is the lack of a heating step, which can lead to structural damage. 

12 



**Figure 4.** (a) Schematic illustration of the all-dry transfer method utilizing a PDMS-support layer to transfer CVD-grown MoS2. A PDMS mold is brought into contact with the MoS2 film on a SiO2 substrate (left), and is then peeled away, removing strips of MoS2 (middle). Finally, the MoS2/PDMS strip assembly is brought into contact with a target substrate, allowing the MoS2 layers to adhere to the surface before removing the PDMS mold (right). Reproduced with permission.<sup>[79]</sup> Copyright 2017, Elsevier. (b) Schematic illustration of PDMS transfer using both water-delamination and dry transfer methods. MoS2 is grown using CVD (left). A PDMS stamp is brought into contact with the MoS2 film and a water droplet is introduced from the side (second from left), leading to water intercalation and separating the MoS2 film from the substrate (middle). The PDMS/MoS2 assembly is brought into contact with a substrate with prepatterned circular microtrench arrays (second from right), before the PDMS is removed by mechanical peeling leaving the film on the target substrate (right). Reproduced with permission.<sup>[19]</sup> Copyright 2016, Royal Society of Chemistry. 

A notable modification to the PDMS-supported transfer procedure is to introduce polyvinyl alcohol (PVA) in between the PDMS and TMD film. This intermediate layer was introduced due to the relatively poor adhesion between PDMS and 2D materials.<sup>[82]</sup> Rather than using PDMS as the direct contact polymer with the 2DLM, PVA is attached to the PDMS and is used 

13 

as the direct support. The PDMS serves as a secondary supporting layer for the PVA/2DLM assembly, and is attached to the glass slide. The PDMS/PVA procedure was carried out by Cao et al. to transfer a whole film of CVD-grown WSe2 onto a SiO2/Si substrate with pre-patterned electrodes.<sup>[83]</sup> With a larger PVA film, the authors predict that larger area films can be transferred. This scalability is appealing for applications. The use of PVA as a support has notable advantages, specifically in its water-solubility, as well as its good adhesion to 2DLMs. However, its use as a standalone support layer is hindered by its low viscoelastic properties<sup>[84]</sup> , meaning that it does not provide a strong enough support to enable a uniform transfer. Hence, a secondary supporting layer is required. This can introduce additional complexity to the transfer process. 

As mentioned above, the low surface energy of PDMS relative to various substrates can be problematic, particularly for detaching the film from growth substrates such as SiO2/Si. Modification to the PDMS surface energy<sup>[79]</sup> , or water intercalation<sup>[19]</sup> is required to assist the PDMS in delaminating the film. However, the low surface energy is an advantage in removing the PDMS from the TMD after it has been transferred. In addition, the presence of uncrosslinked oligomers (up to 5% depending on the curing time<sup>[85]</sup> ) can remain on the surface of the TMD after transfer, causing contamination.<sup>[86]</sup> Hence, further treatment to fully remove this residue is required. 

# _2.1.3 Polystyrene (PS)-assisted transfer_ 

The well-known hydrophobic polymer polystyrene (PS) has also found application in the transfer of CVD-grown TMD layers.<sup>[48,87–93]</sup> For instance, Gurarslan et al. made use of a surface energy-assisted process to delaminate MoS2.<sup>[92]</sup> A thin layer of PS was spin-cast onto an MoS2 monolayer grown on a sapphire substrate, which was chosen because the (0001) plane of c- sapphire is hexagonal, thus matching the lattice symmetry of many TMDs. Making use of the 

14 

different surface energies between film and substrate, the hydrophobic MoS2 layer is delaminated from its hydrophilic growth substrate. The procedure is illustrated in **Figure 5** . First, a layer of PS was spin-cast on the as-grown MoS2 film. A droplet of water was then added. The water intercalation was not automatic because of the strong film-substrate interaction, and required gently poking the side of the sample with a sharp object. Once started, the process was very fast, and the PS/MoS2 assembly could be removed and dried with a paper towel. After the 

PS/MoS2 stack was transferred to a SiO2/Si substrate, the PS was removed by toluene. 



**Figure 5** . Schematic illustration of the PS-assisted transfer of MoS2 on a sapphire substrate, with corresponding images of each step (a-h). The as-grown MoS2 film (a) covered in a spincoated layer of PS (b), after which a water droplet is added on top (c). By poking at the edge of the PS/MoS2 assembly, the water can intercalate between the MoS2 and sapphire substrate (d), eventually delaminating the PS/MoS2 assembly (e). The PS/MoS2 is lifted off and dried (f), and then placed onto the target SiO2/Si substrate (g). The PS is dissolved by baking as a final step (h). Reproduced with permission.<sup>[92]</sup> Copyright 2014, American Chemical Society. 

15 

Xu et al. used a similar method to delaminate CVD-grown WS2 from a sapphire substrate.<sup>[48]</sup> To improve the speed of delamination, the sample was pre-etched in NaOH solution for a number of minutes. Thereafter the sample was immersed in water to delaminate the PS/WS2 from the sapphire. It was found that etching for 5 minutes resulted in WS2 delamination within 30 seconds, whilst after 10 minutes of etching the delamination occurred instantaneously. However, for the latter case substantial damage to the sapphire substrate was incurred. Nevertheless, such a short etching time represents a substantial improvement over the commonly used etching times (typically 30-60 minutes) at elevated temperatures of up to 100 °C. The method represents an improvement over that described in ref<sup>[92]</sup> in two important respects. Firstly, the thickness of the PS film was made very thin (~100 nm), to avoid any residual stress obtained in thicker PS films that caused breaking of the MoS2 flakes observed in ref<sup>[92]</sup> . Secondly, a controlled delamination process was employed, in which the sample was lowered into the water at a delamination rate of 0.3 cm<sup>2</sup> s<sup>-1</sup> . Combined, a more uniform transfer of WS2 was achieved. 

PS has a number of advantages over the traditional PMMA-assisted method. For instance, PS has a larger Young’s modulus (3.5 GPa)<sup>[39]</sup> than PMMA (8 MPa)<sup>[34]</sup> . This means it provides a more robust support to the TMD films, preventing wrinkling. Furthermore, the aromatic structure of PS allows for a wider range of solvents, such as tetrahydrofuran (THF). It was further found that the solubility of PS in THF was greater than PMMA in acetone.<sup>[94]</sup> However, PS is more brittle than PMMA, hindering its use in larger scale transfer. To solve this issue, a thinner PS film can be made (as in ref<sup>[48]</sup> ). Alternatively, a modified form of PS can be used, in which the molecule 4,4’-diisopropylbiphenyl (DIPB) is mixed with PS to widen the distance between the polymer chains, making it softer and more mechanically flexible.<sup>[94,95]</sup> 

16 

# _2.1.4 Other polymer-assisted transfer_ 

In addition to the above, other less common polymer supports have been used for transferring TMD layers, and ultimately expand the repertoire of supports for transferring CVDgrown TMDs. For this reason, they deserve to be highlighted in this review. Citing the wellknown problems of using PMMA-based transfer methodologies, specifically polymer residues which degrade performance (see for example refs<sup>[22,70,96-98]</sup> ), Zhang et al. used cellulose acetate (CA) as a support layer to transfer CVD-grown TMDs onto a SiO2/Si substrate.<sup>[99]</sup> To avoid the problems associated with using the conventional hot NaOH etching method to detach the film (such as cracks or wrinkles from bubbles), the authors used a combination of NH4F and HF (known as buffered oxide etch, or BOE) which works at room temperature. A schematic illustration of the transfer procedure is shown in **Figure 6** (a). Firstly, a layer of CA was spincoated onto the as-grown TMD film. A BOE etch for a few minutes without heating removed the SiO2 layer and detached the TMD film, which was then transferred after DI rinsing to a SiO2/Si target substrate. The CA was removed via IPA and acetone baths. Among the advantages of using CA is that it can be easily dissolved in acetone, which should in principle lead to less residues. Furthermore, CA is inexpensive, non-toxic and biodegradable<sup>[100]</sup> , making it a suitable environmentally-friendly support. 

An alternative, scalable transfer method was used to transfer wafer-scale CVD-grown TMD films (~6 inches), making use of the roll-to-roll production method that was developed for graphene transfer.<sup>[101,102]</sup> Yang et al. adopted this method to transfer CVD-grown MoS2 on a glass substrate using an ethylene vinyl acetate/polyethylene terephthalate (EVA/PET) plastic support.<sup>[103]</sup> The method is outlined in Figure 6(b). Firstly, an EVA/PET film was attached to the MoS2/glass assembly via a hot lamination method using a lamination machine. The EVA/PET/MoS2/glass assembly was then immersed in DI water for about 5 minutes to delaminate the MoS2 from the glass substrate followed by a drying step using N2. The novelty 

17 

of this particular method is that the polymer support also serves as the transferred substrate, thus requiring no polymer-removal step and paving the way for large-scale batch production of flexible electronic components. 



**Figure 6.** (a) Schematic illustration of the cellulose acetate (CA)-assisted transfer of CVDgrown TMD films. TMD films are grown on a SiO2/Si substrate, followed by spin casting a layer of CA. The CA/TMD assembly is then placed on the surface of BOE to etch the SiO2 layer and detach the TMD, and is then transferred to a target substrate and rinsed in acetone and IPA. Reproduced with permission.<sup>[99]</sup> Copyright 2019, American Chemical Society. (b) The green transfer method to transfer large-scale CVD-grown MoS2 films on glass to an ethylene vinyl acetate/polyethylene terephthalate (PET/EVA) target, using the roll-to-roll production method. The MoS2/glass is attached to the PET/EVA via a hot lamination method (left image). The MoS2 is delaminated from the glass substrate via immersion into DI water (middle image). The transferred MoS2 on EVA/PET is shown in the right image. Reproduced with permission.<sup>[103]</sup> Copyright 2018, Springer Nature. 

In addition to its use with PDMS as described above in Section 2.1.2, Lu et al. used PVA in conjunction with polyvinylpyrrolidone (PVP) to form a water-soluble bilayer as a 

18 

support.<sup>[104]</sup> PVP was used as the direct contact with the 2DLM, given its good adhesion and wetting properties. To improve the wettability, _N_ -vinylpyrrolidone (NVP) was added to the PVP solution to match the surface energies of MoS2 and WS2. The PVA top layer serves as a structural support to reinforce the more flexible PVP. Notably, we see PVA being used again (see Section 2.1.2) in a bilayer polymer supporting structure, the difference being that here the bilayer is entirely water-soluble. 

# _2.1.5 Metal-assisted transfer_ 

Despite the efforts to minimize the problem of polymer residues, it remains an enduring issue in using polymer supports for transfer. To this end, other supports have been investigated which do not have such drawbacks. Metal supports have been shown to be suitable substitutes, given their larger adhesion energy compared to polymers, making TMDs less prone to tearing. Lin et al. outlined a method by which TRT was used to transfer CVD-grown MoS2 from a SiO2/Si substrate to a target<sup>[44]</sup> , which is shown schematically in **Figure 7** . A Cu thin film (~60 nm thick) was first coated on the MoS2, to provide both a robust mechanical support and to separate the MoS2 and the glue from the TRT. The TRT was placed on top and then peeled to remove the Cu/MoS2 assembly from the substrate. The MoS2 film was then transferred to a target substrate, and the TRT was released by heating to 120 °C. The Cu film was removed by etching. 

Although the above method solved the polymer residue issue, it still led to cracks and holes in the transferred film. This was due predominantly to the mechanical strain incurred from peeling with TRT. Another method, utilizing a Cu support layer but without TRT, was developed by Lai et al. to avoid this.<sup>[105]</sup> In this method, they relied on water intercalation to delaminate the MoS2 from its growth substrate. Use was made of a PDMS/PMMA layer on top of the Cu film on MoS2 to help remove it after immersion in water. The buoyancy force supplied 

19 

by the water was key in preventing damage to the thin PDMS/PMMA/Cu/MoS2 assembly during peeling, as was the rigid Cu film support. 

In general metal supports are more robust, but they share a similar drawback with polymer supports in that they require removal via chemical etching in the last transfer step, which can damage the TMD films. In addition, electron beam evaporation, although a softer metal deposition method than sputtering, can also damage the film. The process is also relatively expensive due to the used metal, restricting its use in industrial applications. 



**Figure 7.** Illustration of the Cu-assisted transfer process. MoS2 on SiO2/Si is coated with a thin layer of Cu, and then TRT is placed on top. The TRT/Cu/MoS2 assembly is peeled off the growth substrate, and placed on the target substrate. TRT is removed via heating, and the Cu is removed via etching, leaving the MoS2 on the target substrate. Reproduced with permission.<sup>[44]</sup> Copyright 2015, Springer Nature. 

20 

# **2.2 Transfer without a supporting layer** 

Supporting layers, either polymer or otherwise, were introduced primarily to avoid damage to the 2DLM from the harsh etching solution used to detach it from the substrate, and to provide structural support in moving the film to the target substrate. Furthermore, in order to fully take advantage of the myriad exotic functionalities of 2D TMDs, it is necessary to be able to transfer them from their growth substrates to a variety of target substrates, in order to realize specific functionalities (e.g. flexible supports). Therefore, generic strategies that are not limited to specific substrates depending on the support are necessary moving forward. In this context, Xia et al., adapting a method used to transfer CVD-grown graphene<sup>[106]</sup> ,  employed a direct transfer method to transfer MoSe2 flakes to a TEM grid.<sup>[107]</sup> The procedure is outlined in **Figure 8** (a). A MoSe2 film was grown using CVD on SiO2/Si and mica substrates. These were attached to a TEM grid and then immersed in a 1% HF solution to etch the substrate, leaving the MoSe2 film on the TEM grid. The fact that this technique removed the need of a support resulted in a faster and more convenient transfer, and did not require any post transfer chemical treatment. Nevertheless, despite the advantages of the aforementioned method, an etchant is still required to detach the 2DLM from the growth substrate, thereby limiting its industrial application as the growth substrate cannot be reused. To improve this, an all-water based transfer procedure for TMDs was developed, which did not use any harsh chemicals in any of the steps.<sup>[68,108,109]</sup> Kim et al. made use of such a method using centimeter-scale MoS2 on SiO2/Si as a representative case.<sup>[108]</sup> The steps are outlined in Figure 8(b). Instead of a chemical etchant, the MoS2/SiO2/Si assembly was immersed in water, which resulted in immediate delamination due to the difference between the hydrophobic MoS2 and hydrophilic SiO2 layer. The MoS2 layer was subsequently scooped out of the water bath onto an arbitrary substrate. The growth substrate, having not been etched, could be recycled for another growth phase. 

21 



**Figure 8.** (a) An unsupported, direct transfer method using an aqueous solution. The MoSe2 film on its growth substrate was placed in a container, with the MoSe2 side contacting a TEM grid. The container was filled with 1% HF solution, resulting in delamination of the MoSe2 film from its substrate. The MoSe2, which remains on the TEM grid, floats to the surface of the solution, and can then be fished out and dried. Reproduced with permission.<sup>[107]</sup> Copyright 2014, Royal Society of Chemistry. (b) A schematic illustration of an all water-assisted transfer. The CVD-grown TMD can be immersed in water, resulting in immediate delamination from the growth substrate, and then fished out onto a target substrate. The growth substrate can be reused, as no chemicals are used to etch the surface. Reproduced with permission.<sup>[108]</sup> Copyright 2019, Springer Nature. 

# **2.3 Discussion** 

The transfer methods of large-scale CVD-grown 2D TMDs have undergone significant development since their adoption from those used for graphene. The use of polymer supports became predominant owing to their flexibility and mechanical stability. However, from the 

22 

above considerations it is clear that there is significant variation between polymers, and that the choice of polymer will invariably come with a need to adapt the transfer procedure to suit the polymer. Alternative (e.g. metal) supports exist, providing some advantages over polymers, and there are now methodologies which forgo the use of any support. There now exists a landscape of transfer methods for researchers to choose from, and this can be somewhat bewildering at first glance. It is the purpose of this review to give some clarity in this regard. 

It is clear that the PMMA-assisted method, although the most extensively used, suffers from significant drawbacks. These include the use of harsh chemicals (such as KOH or HF) to etch the growth substrate, as well as the dissolution of the polymer after transfer, using hot acetone. These processes degrade the quality of the transferred TMD films. For example, the carrier mobility of CVD-grown monolayer MoS2 can be reduced from ~8 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> for the as-grown film<sup>[110]</sup> , to 0.8 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> for the PMMA-transferred one.<sup>[46]</sup> PDMS represents an improvement, in that it does not require removal via chemicals. However, delamination via mechanical peeling can result in an imperfect lift off, particularly given the poor adhesive properties of PDMS. This problem is often compounded by the strong film-substrate interactions that are introduced in the high-temperature growth process in CVD.<sup>[104]</sup> Water intercalation can assist in the delamination process, however it requires a hydrophilic layer under the as-grown TMD films (in contrast to the hydrophobic TMD), which is not common in the CVD growth-process. Substrates such as sapphire or SiO2/Si (with the SiO2 layer thickness greater than 300 nm<sup>[111]</sup> ) have the necessary hydrophilic qualities. In the surface-energy assisted transfer described in ref<sup>[92]</sup> , PS was used as a support. It was argued that, due to the greater hydrophobicity of PS, it can adhere more to the TMD layer than PMMA. Furthermore, the use of toluene to dissolve the PS layer resulted in a cleaner surface. Importantly, as mentioned above, PS is dissolved in THF to a greater degree than PMMA is in acetone.<sup>[94]</sup> This represents a potential solution to the problem of polymer residue, if the brittleness of PS can be addressed. 

23 

The addition of water-soluble polymers such as PVA or PVP represent an important modification to CVD transfer methods using supports, as they do not require any chemical solvents in the final transfer step. The entire process can be carried out using only water (see ref<sup>[104]</sup> ), making this an environmentally friendly method. Water-based delamination was also central to the development of a transfer process that did not use any support (see ref<sup>[108]</sup> ). The lack of support, however, can result in the wrinkling of the TMD film on the water surface. This process is not unlike how plastic kitchen film can wrinkle and fold without any supporting structure. It could be expected that the larger bending modulus of TMDs (and their associated resistance to crumpling) compared to graphene would be advantageous in transfers that use such support-free methods. Nevertheless, the water-assisted method requires a difference in surface energies between film and substrate, which again limits its use to specific substrates. 

From one extreme of having no support, a method using a more robust support was developed. This was done to avoid the problem of the polymer film being very soft (low Young’s modulus) compared to TMDs. For example, the Young’s modulus of PMMA is around 8 MPa<sup>[34]</sup> , much lower than that of MoS2 (270 GPa)<sup>[25]</sup> . As a result, the polymer can fold in a manner outlined in **Figure 9** . Once transferred to the target substrate, these folds remain and there is reduced contact between the TMD and the surface. By comparison, Cu has a Young’s modulus of 100 GPa<sup>[44]</sup> , much closer to that of MoS2 (and other TMDs), making for a much more robust support. The disadvantage of using metal supports, however, is that it still requires an etchant to remove the metal, damaging the TMD film. Furthermore, the use of e-beam evaporation to produce the thin metal support is relatively expensive, prohibiting such a method from being used in industrial applications. One way around this would be to use the metal foil growth substrate as the support as well. The problem is that the foils are quite thick (~100 µm<sup>[65]</sup> ), making them less flexible than polymer films and resulting in poor contact with the 2DLM if they are bent. Reducing the thickness may address this limitation. 

24 



**Figure 9.** Schematic illustration of the wrinkle formation process in standard PMMA transfers. The photograph shows a PMMA/MoS2 film floating on a KOH solution during transfer with TRT. Bubbles and wrinkles can both be seen. Reproduced with permission.<sup>[44]</sup> Copyright 2015, Springer Nature. 

In the light of the various technological applications of TMDs and their stacked combinations, thought should also be given to the applicability of these transfer methods, not only with respect to scalability, but also in terms of target substrates. For instance, the roll-toroll (R2R) method, described in Section 2.1.4, is scalable and suitable for flexible targets such as PET or EVA, but it is not applicable to inflexible SiO2/Si substrates and therefore of little use in the semiconductor industry.<sup>[112]</sup> By comparison, water-soluble supports such as PVA or PVP can be used to transfer TMD layers to various substrates, including Cu foil, SiO2/Si and quartz.<sup>[83]</sup> 

To summarize, it is apparent that despite the significant developments in transfer methods for CVD-grown TMDs, notable challenges remain. Hence, more research is required on improving these methods, with an emphasis on industrial applicability. The criteria that must be met are as follows: (i) Reduced contamination (e.g. polymer residue) and TMD film degradation (e.g. wrinkles and cracks), (ii) cost-effective methods that allow for scalability, and (iii) wide applicability in terms of target substrate (particularly Si wafers for CMOS integration). 

25 

# **3. The impact of transfer techniques on film quality** 

Using the different kinds of transfer methods mentioned above, various TMDs can be successfully transferred onto a wide range of different substrates. Given the potential for using 2D TMDs for novel technological applications, it is vital that the transferred films are of a high quality and fidelity, in order to preserve the material properties. To this end, the structural, chemical and electronic properties of transferred TMD films have been investigated.<sup>[29,44,47,76,92,99,113–115]</sup> This is important as many transfer methodologies suffer from process related weaknesses, such as trapped bubbles, polymer residues, cracks or wrinkles. These features can degrade device performance. For instance, inhomogeneous or uncontrollable strain is detrimental to photoluminescence (PL) and optical applications<sup>[48,116,117]</sup> , and cracks, wrinkles or polymer residue can strongly affect device resistivity and electron mobility<sup>[46,57,118]</sup> . It should be noted, however, that the various effects will be of differing importance depending on the application. For example, polymer residue does not have a large influence over the photoluminescence signal of 2D TMDs.<sup>[119]</sup> Thus, for optical applications such issues can usually be ignored. In the ideal case, a perfect transfer entails the functional continuity of the 2D film before and after transfer, with the only difference being the substrate. In practice this does not occur and, depending on the method used, modifications to the film results. In this section, the drawbacks associated with transferring CVD-grown TMD films will be outlined and described in detail. Furthermore, characterization techniques that can be used to quantify these drawbacks and methods to improve the film quality post-transfer will be given. 

# **3.1 Issues encountered in transferring 2D semiconductors** 

# _3.1.1 Wrinkles and cracks_ 

Wrinkles in 2D materials are to a certain extent unavoidable, as predicted by the MerminWagner theorem.<sup>[120]</sup> Ultimately, long-wavelength fluctuations destroy the long range order of 

26 

2D crystals. Once the size in one dimension exceeds a critical value (of the order of nanometers for van der Waals materials), the material will wrinkle due to thermal fluctuations.<sup>[121]</sup> Substrates can strongly suppress this effect, meaning that these natural wrinkles of 2DLMs can be mitigated by coupling them to supports. In addition to this ‘built-in’ wrinkling, other wrinkled structures can form randomly during the CVD growth and transfer processes, in a manner which is unavoidable.<sup>[56]</sup> Cracking can also occur when applied stresses, such as those that occur during transfer, break the chemical bonds of the material. As mentioned in Section 2, 2D TMDs are more resistant to cracking than graphene due to their trilayer atomic structure. They have a higher fracture toughness<sup>[122]</sup> , and during the CVD growth process they do not suffer from the stresses that occur due to having a negative TEC, as graphene does. Indeed, most materials, including TMDs and common CVD-growth substrates, have a positive TEC. Nevertheless, cracks and wrinkles still occur, either from the growth or transfer procedures. Although cracks in transferred films are undesirable, particularly for applications, this is not so obvious for the case of wrinkles. Indeed, wrinkle engineering can be used to tune the electronic properties of 2D materials, such as planar mobility.<sup>[123]</sup> For the case of WS2, wrinkles greatly enhanced the intensity of the photoluminescence signal, via the tuning of the bandgap<sup>[124]</sup> , which would find application in efficient photodetectors. On the other hand, both wrinkles and cracks can cause carrier scattering via flexural phonons<sup>[57]</sup> , resulting in a lower mobility, as well as short circuiting, which damages device integration.<sup>[118]</sup> In such situations it is important to understand the origins of these structural modifications, and how to reduce them. Here we limit the discussion to the transfer process. 

Wrinkles and cracks can come from various steps during transfer. For example, during the etching process to remove the growth substrate, some of the wrinkles formed from the surface topology of the growth substrate can be removed via the large surface energy of the etchant.<sup>[56]</sup> At the same time, the etchant may induce the formation of new wrinkles via capillary forces. A 

27 

soft support layer (i.e. one with a low Young’s modulus compared to the 2DLM) cannot prevent deformation of the film after it is detached from its growth substrate, for thicknesses in the order of hundreds of microns. These wrinkles remain when transferred onto the target substrate, reducing the direct contact area of the film with the surface. The evaporation of the solvent used to remove the polymer can also induce excess wrinkling.<sup>[125]</sup> In addition, methods that rely on mechanical peeling to remove the polymer layer induce a lateral strain in the 2D film when the polymer/TMD assembly is pressed onto the target substrate. When the polymer is peeled off, this can damage the TMD layer.<sup>[126]</sup> 

Gurarslan et al. compared the surface-energy-assisted method using a PS support, to that of a conventional PMMA-assisted one, for transferring CVD-grown MoS2 (see Section 2.1.3).<sup>[92]</sup> The PMMA/MoS2 assembly on sapphire was immersed in hot (90 °C) NaOH solution for 4 hours during the transfer process. Holes and cracks were observed in the transferred MoS2 film using the conventional PMMA support, as shown in **Figure 10** (a). By comparison, the surfaceenergy-assisted PS-support method produced no observable cracks or wrinkles. The reasons for this are two-fold. Firstly, the use of hot chemical etchants produces bubbles that can be trapped between the film and support layer, inducing mechanical strain and causing folding or even cracking. The use of water at room-temperature can help to alleviate these effects. Secondly, PS provides a more robust support than PMMA due to its larger Young’s modulus, hence limiting wrinkle formation. 

Bubbling in a solution<sup>[65]</sup> and/or by the capillary force induced when transferring the film out of the solution or water bath<sup>[108]</sup> (the wedging transfer method) can also result in wrinkles and cracks. For instance, Figures 10(b) and (c) show the optical images of transferred monolayer WS2 from Au foil onto SiO2/Si wafer by a PMMA-based wet-etching method, and the bubbling transfer method as described in Section 2.1.1, respectively.<sup>[65]</sup> It can be seen that the coverage of WS2 via the wet-etching transfer is higher than that from the bubble transfer 

28 

(see also Figure S11 of the Supplementary in ref<sup>[65]</sup> ). This indicates the extra mechanical stress on the TMD film by the intercalated bubbles. Figure 10(d) shows an atomic force microscopy (AFM) image of the same transferred WS2 film on the SiO2/Si substrate via the bubble method (as shown in Figure 3(a)). Wrinkles can be clearly observed. Similarly, Figure 10(e) shows an AFM image of monolayer MoS2 transferred from Au foil to SiO2/Si via wet-etching of the supporting PMMA layer (in addition to an Au etchant, KI/I2).<sup>[127]</sup> Cracks as well as wrinkles were observed. These findings indicate that wrinkles can occur at many stages of the transfer 

process, and their removal can be challenging. 



**Figure 10.** (a) Optical image of transferred MoS2 on SiO2/Si. The arrows indicate gaps in the film. (b-c) Optical images of transferred WS2 on SiO2/Si via wet-etching, PMMA-assisted and 

29 

bubbling transfer, respectively. Cracks and gaps are more clearly observed in the bubble method. (d) AFM image of the WS2 film transferred using the bubble method. Wrinkles are clearly observed. (e) AFM image of MoS2 transferred via the PMMA-assisted wet etching method, showing again significant wrinkling. (a) Reproduced with permission.<sup>[92]</sup> Copyright 2014, American Chemical Society. (b-d) Reproduced with permission.<sup>[65]</sup> Copyright 2015, American Chemical Society.  (e) Reproduced with permission.<sup>[127]</sup> Copyright 2015, John Wiley & Sons, Inc. 

# _3.1.2 Bubbles at the interface between TMD and substrate_ 

The transfer process consists of two main steps: (1) the removal of the 2D film from the growth substrate, and (2) the placing of the film onto the target substrate. The latter step is prone to trap contaminants at the interface formed between the TMD and the target substrate. However, due to the high diffusivity of contaminants on 2D van der Waals crystals (also termed the “self-cleansing” mechanism<sup>[128]</sup> ), these contaminants tend to aggregate into bubbles or blisters. This occurs because of the difference in adhesion energy between the TMD and the target substrate, and the TMD and contaminants. If the former is larger, then it is energetically favorable for the two materials to have the largest possible interface. This has the effect of pushing the contaminants away, leading to the aggregation. This is shown clearly in **Figure 11** , in which AFM images were taken of graphene transferred onto various 2D crystals. On substrates with a good adhesion to graphene, such as hexagonal boron nitride (h-BN), MoS2 and WS2 (Figure 11(a-c)), the contaminants are observed to aggregate into bubbles. On the other hand, on substrates with a poor adhesion to graphene, such as mica, bismuth strontium calcium copper oxide (BSCCO), and vanadium oxide (V2O5) (Figure 11d-f), the contamination is observed to spread uniformly over the interface. 

30 



**Figure 11.** AFM images of graphene on various substrates. In images (a-c), graphene is placed on top of van der Waals surfaces (h-BN, MoS2 and WS2). It can be seen that, due to the selfcleansing mechanism of 2D van der Waals materials, large areas of graphene/substrate interface become flat and contaminant free, with a surface roughness on the order of 0.1 nm. Contaminants are seen to aggregate into bubbles or blisters. In images (e-g), graphene is placed on hydrophilic oxide surfaces. It is observed that no large bubbles are present, with a surface roughness of a few nm. Reproduced with permission.<sup>[128]</sup> Copyright 2014, American Chemical Society. 

Trapped water or residue from chemical etchants are mainly found in wet transfer methods<sup>[68,76,129,130]</sup> , which can remain on a surface and thereafter become trapped between the transferred TMD film and that surface (for instance the supporting layer during transfer, or the target substrate). However, contaminants can also be introduced during all-dry transfers, including trapped air pockets.<sup>[68,131]</sup> It has been previously observed that bubbles formed during PMMA-assisted transfers contained amorphous hydrocarbons, as would be expected of PMMA contamination.<sup>[132]</sup> Little is known about contaminants introduced in other transfer methods. Hong et al. transferred monolayer MoS2 flakes from soda-lime glass onto HOPG (highly oriented pyrolytic graphite) by a water-assisted method (without support), and an all-dry TRT- 

31 

assisted method.<sup>[68]</sup> **Figure 12** (a-b) shows scanning electron microscopy (SEM) images of the wet-transferred sample, where clear bubbles are observed. These are attributed by the authors to trapped water at the interface of MoS2 and HOPG. The scanning tunneling microscope (STM) image in Figure 12(c) indicates some surface inhomogeneity. The reduction in the number and size of the bubbles from the dry-transferred sample, shown in the SEM images in Figure 12(d, e), confirms the origin of the bubbles in the wet-transferred case. Nevertheless, even in the all-dry case bubbles can be seen, which were attributed primarily to trapped air. 



**Figure 12.** A comparison between an all-water assisted wet method (a-c) and TRT-assisted all- 

dry method (d-f) to transfer MoS2 from soda-lime glass to HOPG. (a,b) SEM images of an MoS2 flake on HOPG after the water-assisted transfer process. Numerous bubbles and wrinkles can be observed. (c) STM image of the same flake as in (a), showing the rhombic unit cell of the Moiré lattice, with randomly distributed bright spots. (d,e) SEM images of an MoS2 flake on HOPG transferred using the all-dry TRT-assisted method. A few air bubbles can be observed. (f) STM image showing the same Moiré lattice, without the inhomogeneous distribution of bright spots. Reproduced with permission.<sup>[68]</sup> Copyright 2018, John Wiley & Sons, Inc. 

32 

The issue of bubbles/blisters is particularly pertinent to TMD-heterostructures. A common fabrication route for such heterostructures involves targeted pick-up and release. These stacking methods are known to introduce contaminants and prevent the formation of pristine interfaces, which can affect interlayer interactions (such as charge and energy transfer).<sup>[133,134]</sup> For instance, Yang et al. observed bubbles when fabricating graphene/TMD heterostructures using a van der Waals pick-up method.<sup>[134]</sup> The method is shown schematically in **Figure 13** (a). An exfoliated flake of h-BN was picked up by a PDMS-based support, and was then brought into contact with a CVD-grown WSe2 layer on SiO2/Si. In the final step (not shown) the polymer/hBN/TMD assembly was brought into contact with graphene, completing the heterostructure. It was found that bubbles were mainly introduced in this step. From the AFM image in Figure 13(b) it can be seen that the bubbles form randomly, and the PL mapping in Figure 13(c) of the same area as in Figure 13(b) indicates red dots where the PL signal is not quenched. In this respect, PL serves as a helpful tool for characterizing bubbles, as the PL signal is quenched 

when graphene is brought into intimate contact with the TMD. 



**Figure 13.** (a) Procedure for transferring CVD-grown WSe2 using an h-BN flake, with a PDMS-based all-polymer support. Firstly, a PDMS/PPC (polypropylene carbonate) stamp is lowered towards an h-BN flake (with the sample kept at 60 °C). The h-BN is detached from the substrate, and is then brought into contact with a CVD-WSe2 film. The PDMS/PPC/h-BN/WSe2 

33 

assembly is then peeled from the substrate, and is ready to align onto a pre-exfoliated graphene flake. (b) AFM topography image of the resulting h-BN/TMD/graphene stack, showing bright protrusions corresponding to the bubbles, imaged in (c) using PL mapping. Reproduced with permission.<sup>[134]</sup> Copyright 2017, American Physical Society. 

As mentioned before, the existence of bubbles precludes a pristine interface, which is instrumental for emerging phenomena in van der Waals heterostructures, such as proximity effects and interlayer excitons. The self-cleansing mechanism of 2DLMs can lead to bubblefree regions over which devices can be constructed, however at larger scales this is not possible due to the layer size. Thus, solutions must be found to reduce interface bubbles. In theory, the presence of bubbles can be removed by controlling the angle at which the 2DLM is brought into contact with the target substrate, as well as the merging time. With a slower merging time at an angle other than normal incidence, bubbles have a greater chance of escape. This process is analogous to how a plastic screen protector adheres to a phone screen. Nevertheless, it is difficult to entirely remove such defects. It is therefore a matter of future research to address these issues. 

# _3.1.3 Residues from support layer_ 

Almost all transfer methods require a support to successfully transfer the TMD film as a continuous piece, maintaining uniformity. Section 2 outlined two types of supporting layers that have been used, namely polymer and metal. Polymer supports are used more frequently, in particular PMMA (and to a lesser extent PDMS). These supports tend to leave residues on the surface of the 2DLM after they have been removed. For instance, due to the strong dipole interactions between PMMA and graphene, a thin layer of PMMA remains on the surface after transfer and removal of the polymer.<sup>[97,135–138]</sup> **Figure 14** shows CVD-grown MoS2 flakes 

34 

transferred from a SiO2/Si substrate to a target substrate using a PMMA-assisted transfer method. Figure 14(a) and (b) shows optical images of the as-grown and transferred MoS2 flakes, respectively. Large residues can be seen in the latter image, on both the substrate and TMD, and these are confirmed by the AFM image in Figure 14(c). Such residue is known to degrade the intrinsic properties of 2DLMs. For example, it can decrease the mobility of graphene by more than 50% due to carrier scattering<sup>[139,140]</sup> , and decreases its thermal conductivity by 70% because of phonon scattering<sup>[141]</sup> . Furthermore, such residue has been observed to cause weak p-type doping in transferred graphene, which can shift the threshold voltage for back-gated graphene FETs.<sup>[142]</sup> Research on the effects of PMMA residues on transferred TMDs is comparatively rarer. 



**Figure 14.** (a, b) Optical microscopy images of monolayer MoS2 before and after transfer by PMMA-assisted transfer method on the SiO2/Si. PMMA residuals are notable on the surface of transferred MoS2 flakes. (c) AFM image of transferred MoS2, the residues are clear on top of the MoS2 flakes. Reproduced with permission.<sup>[44]</sup> Copyright 2015, Springer Nature. 

A number of different methods have been employed to reduce or remove the residue. Annealing in different atmospheric conditions or in vacuum is the most common way<sup>[143-145]</sup> , although the process is not completely effective<sup>[97]</sup> . Moreover, high temperature annealing may induce defects in TMDs, such as metal or chalcogen vacancies.<sup>[146,147]</sup> Annealing graphene samples in oxidative atmospheres to remove PMMA residues has been reported<sup>[148]</sup> , but 

35 

extending this method to TMDs is likely not a good idea because it may lead to oxidation. Laser cleaning and electrostatic-force cleaning of PMMA residues on graphene has been reported to have some success, although such methods have not yet been reported for TMD transfer.<sup>[140,149]</sup> Plasma cleaning has also been used<sup>[150]</sup> , although care must be taken. For instance, O2 plasma can lead to significant doping of TMDs.<sup>[151]</sup> 

In addition to these global treatment methods, more local methods have been tried to remove PMMA residue. These include the use of contact mode AFM, where the residue is swept away by the tip to clean a small area of the film surface. For example, Liang et al _._<sup>[152]</sup> fabricated MoS2 and WSe2 FETs by electron beam (e-beam) lithography (using PMMA as e-beam resist) and investigated the impact of post-lithography PMMA residue on the electrical characteristics of the two FETs. Using an AFM tip, they managed to lower the height topography of the surface, and found that the charge carrier density and source-drain current increased by 4.5 × 10<sup>12</sup> cm<sup>-2</sup> and 247%, respectively. It should be noted that such methods are clearly not scalable, and are thus not suitable long-term solutions to the residue problem. 

Polymer residues are also found in PDMS-assisted transfer methods. PDMS, as mentioned in Section 2.1.2, contains many uncrosslinked oligomers which can remain on the surface after the polymer layer is detached after transfer, causing contamination.<sup>[29,86,115]</sup> On the one hand, such contamination reduces the surface cleanliness, affecting the properties of TMD heterostructures.<sup>[29,76]</sup> On the other hand, the transferred PDMS oligomers could be used as a protective layer for selected areas to survive from chemical etching.<sup>[153]</sup> Moreover, a patterned PDMS stamp can selectively pattern a target substrate with transferred PDMS oligomers to fabricate transistor devices.<sup>[154]</sup> To date, the influence of PDMS residues on the physicochemical properties of transferred TMDs has not been extensively researched. A possible reason would be that PDMS residues do not affect the overall PL quantum yield, and thus has been overlooked.<sup>[115]</sup> Various methods have been employed to remove PDMS residue, 

36 

some of which overlap with those for PMMA. Annealing at 400 °C under ultra-high vacuum (UHV) conditions for 1 hour has been reported to completely remove PDMS residues on MoS2<sup>[115]</sup> , however such high temperatures can introduce defects. Dissolving the PDMS residues in organic solvents, such as acetone or hexane, has been shown to be effective.<sup>[155]</sup> Usually, the PDMS swells when it is in organic solvents and the amount of extracted PDMS oligomers increases as the swelling ratio increases.<sup>[156]</sup> However, the solvent molecules might be adsorbed on the transferred TMD surface and perhaps lead to chemical doping. Preemptive treatment methods have also been investigated, for instance by pre-cleaning the PDMS by ultraviolet/ozone (UV/O3).<sup>[115,157]</sup> Jain et al _._ employed such a step for MoS2 flakes exfoliated on PDMS and transferred onto h-BN on a SiO2/Si substrate.<sup>[115]</sup> They found that the amount of 

PDMS residue was significantly reduced, as shown in **Figure 15** . 



**Figure 15.** (a) AFM image of transferred MoS2 on h-BN, displaying a considerable number of bubbles and wrinkles. (b) AFM image of the same area in (a), showing that the bubbles were efficiently removed by vacuum annealing at 200 °C for 3 hours. (c) AFM image of the redoutlined area in (b). (d) Height profile along the red-dashed line in (c), exhibiting a clear 

37 

monolayer MoS2 step of 7.2 Å. Inset: AFM phase map recorded together with the topography in (b) revealing a clear phase contrast between MoS2 and h-BN. Reproduced with permission.<sup>[115]</sup> Copyright 2018, IOP Publishing. 

# **3.2 Characterization techniques for determining transferred film quality** 

Given the numerous issues relating to the quality of transferred CVD-grown TMDs, and the need to resolve them for future applications, a robust set of characterization tools are required to benchmark the transferred films, at various length scales ranging from the atomic to the macroscopic. Here an overview of the main techniques is presented, as well as less common techniques that may also find utility in such inquiries. 

# _3.2.1 Raman spectroscopy_ 

One of the most common and readily accessible methods for obtaining structural and chemical information of materials is that of Raman spectroscopy. As a relatively cheap and non-destructive technique, it has played an important role in the characterization of graphitic materials. As a result, it has been readily adopted to study the quality of transferred TMD films. A typical Raman spectrum for TMD films can yield information on the number of layers<sup>[19,44,92,158,159]</sup> , indicate the charge doping<sup>[44,68,130]</sup> , strain<sup>[160]</sup> and defect density<sup>[161,162]</sup> . The Raman spectra of 2D TMDs draw some comparisons to graphene, with both similarities and notable differences. Semiconducting TMDs, like MoS2 and WSe2, often appear in the 2H phase. The 1T or 1T’ phase is a meta-stable phase resulting in (semi)metallic behavior and only stable for a selected number of TMDs. The 2H phase belongs to the P63/ _mmc_ nonsymmorphic space group (D<sup>4</sup> _6h_ ), with an inversion symmetry between the two adjacent monolayers (shown in **Figure 16** (a)). This symmetry is shared by Bernal stacked graphite.<sup>[162]</sup> However, in the monolayer limit 2H-TMDs lose their inversion symmetry, reducing the space group to the 

38 

symmorphic _P_ 6<sup>�</sup> _m_ 2 (D<sup>1</sup> _3h_ ).<sup>[163]</sup> Graphene has only one first-order (doubly degenerate) Raman active mode belonging to the irreducible representation E2g. This mode gives rise to the socalled G band (1580 cm<sup>-1</sup> ). In contrast, monolayer 2H-TMDs have three Raman active modes corresponding to the A1’, E’ and E’’ irreducible representations. These are shown in Figure 16(a). A1’ corresponds to the chalcogen atoms vibrating in the out of plane direction, with the upper chalcogen atom moving in anti-phase with the lower one. The metal atom remains stationary. The E’ and E’’ modes correspond to in-plane atomic vibrations. For the E’ modes, the metal atom moves in anti-phase with the two chalcogen atoms. It is somewhat comparable to the E2g mode in graphene. In a standard Raman backscattering configuration, the E’’ mode is silent and thus a typical Raman spectrum of monolayer 2H-TMDs displays only 2 first-order Raman modes (A1’ and E’)<sup>[164]</sup> , although it should be noted that this spectrum is strongly dependent on the excitation wavelength of the light. A resonant excitation leads to a diverse number of second-order peaks due to strong electron-phonon coupling.<sup>[165]</sup> 

In addition to the Raman active modes in pristine 2H-TMDs, there also exist defectactivated modes which can be useful for determining transferred film quality. Prominent defectinduced Raman bands were found in the spectrum of MoS2 and WS2 films at ~223 and 178 cm<sup>-</sup> 1, respectively.[166] They originate from phonons at the M-point of the longitudinal acoustic (LA) branch of the Brillouin zones of each material. For MoS2, the intensity of this LA(M) peak was found to be proportional to the average distance between defects.<sup>[161]</sup> The underlying mechanism could involve a so-called double-resonance (DR) Raman process involving 1 phonon and a defect. This process involves the same phonon branch as another second-order Raman process, the 2LA(M) band in MoS2 and WS2, which involves the scattering by two phonons, in contrast to the one phonon plus a defect in the LA(M) band. The 2LA(M) and the defect-induced LA(M) bands are analogous to the transverse optical (TO) modes of graphene involving phonons at the K-point – 2TO(K) and TO(K). These two bands are also called the G’ 

39 

and D bands (or 2D and D bands, respectively), with the latter being associated with defects in graphene. 

Raman spectroscopy can be used to determine the number of layers of transferred MoS2 films. The E<sup>1</sup> 2g and A1g are sensitive to layer thickness, and in general the Raman shift of the former will decrease and that of the latter will increase with increasing layer number.<sup>[167]</sup> An example is shown in Figure 16(b), showing Raman spectra of the CVD-grown MoSafter transfer, of both monolayer and trilayer samples. The change in wavenumber (found to be ∼20 cm<sup>-1</sup> and 23.2 cm<sup>-1</sup> , respectively.<sup>[92]</sup> Strain is another factor that influences the 2 before and Δ𝑘𝑘) was Raman spectra of TMD films. It was found that the change in wavenumber per percent of strain for uniaxially strained monolayer MoS2 was -2.1 cm<sup>-1</sup> for the E<sup>1</sup> 2g (E’) mode and -0.4 cm<sup>-1</sup> for the A1g (A1’) mode, in good agreement with theoretical predictions.<sup>[168]</sup> Such a redshift was observed in the E<sup>1</sup> 2g peak for CVD-grown MoS2 after transfer with PMMA (~2 cm<sup>-1</sup> )<sup>[44]</sup> , as shown in Figure 16(c). Little change was observed for the A1g peak, in accordance with the low value reported in ref<sup>[169]</sup> . The authors ascribed the change in the E<sup>1</sup> 2g mode to wrinkle-induced strain after the transfer. By contrast, no change in the E<sup>1</sup> 2g mode is observed for the TRTassisted transfer. However, a blueshift of the A1g mode was observed, which is generally associated with p-doping of the MoS2 from charged impurities<sup>[168]</sup> introduced at the interface between the MoS2 and the target substrate during transfer. Such behavior was not observed in the PMMA-assisted transfer due to the strain dominating the peak shifts.<sup>[170]</sup> Other than impurities, different substrates<sup>[47]</sup> , substrate-borne moisture<sup>[171]</sup> and vacancy defects (such as sulfur)<sup>[68]</sup> can also lead to doping and thus change the A1g peak. 

Raman spectroscopy is also a good way to study the interlayer coupling in van der Waals stacked bilayer TMDs, such as MoS2/WS2<sup>[29,76,129]</sup> and MoS2/WSe2<sup>[130]</sup> . For instance, it was found that in MoS2/WS2 heterostructures the E’ and A1’ modes of each layer contributed to the Raman signal independently at the same frequencies as the individual monolayers (both before 

40 

