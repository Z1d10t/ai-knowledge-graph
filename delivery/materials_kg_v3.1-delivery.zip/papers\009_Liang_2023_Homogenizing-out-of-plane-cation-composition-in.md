# Homogenizing out-of-plane cation composition in perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 653 |
| 作者 | Zheng Liang, Yong Zhang, Hui-Fen Xu, Wenjing Chen, Bo-Yuan Liu, Jiyao Zhang, Hui Zhang, Zi-Han Wang et al. |
| DOI | 10.1038/s41586-023-06784-0 |
| 源文件 | 009_Liang_2023_Homogenizing-out-of-plane-cation-composition-in.pdf |

---
Article 

# **Homogenizing out-of-plane cation composition in perovskite solar cells** 

|https://doi.org/10.1038/s41586-023-06784-0<br>Received: 1 January 2023<br>Accepted: 25 October 2023<br>Published online: 1 November 2023|**Zheng Liang**<sup>**1,2,15**</sup>**, Yong Zhang**<sup>**3,4,15**</sup>**, Huifen Xu**<sup>**1,2,15**</sup>**, Wenjing Chen**<sup>**2,5**</sup>**, Boyuan Liu**<sup>**1,2**</sup>**, Jiyao Zhang**<sup>**3,4**</sup>**,**<br>**Hui Zhang**<sup>**1,2**</sup>**, Zihan Wang**<sup>**1,2**</sup>**, Dong-Ho Kang**<sup>**6,7**</sup>**, Jianrong Zeng**<sup>**8**</sup>**, Xingyu Gao**<sup>**8**</sup>**, Qisheng Wang**<sup>**8**</sup>**,**<br>**Huijie Hu**<sup>**1,2**</sup>**, Hongmin Zhou**<sup>**2,9**</sup>**, Xiangbin Cai**<sup>**10**</sup>**, Xingyou Tian**<sup>**1**</sup>**, Peter Reiss**<sup>**11**</sup>**, Baomin Xu**<sup>**3,4**</sup>**,**<br>**Thomas Kirchartz**<sup>**12,13**</sup>**, Zhengguo Xiao**<sup>**2,5**</sup>**, Songyuan Dai**<sup>**14** ✉</sup>**, Nam-Gyu Park**<sup>**6,7** ✉</sup>**, Jiajiu Ye**<sup>**1,12** ✉</sup>**&**<br>**Xu Pan**<sup>**1** ✉</sup>|
|---|---|
|Open access||
|Check for updates|Perovskite solar cells with the formula FA1−_x_Cs_x_PbI3, where FA is formamidinium,<br>provide an attractive option for integrating high efficiency, durable stability and<br>compatibility with scaled-up fabrication. Despite the incorporation of Cs cations,<br>which could potentially enable a perfect perovskite lattice<sup>1,2</sup>, the compositional<br>inhomogeneity caused by A-site cation segregation is likely to be detrimental to the<br>photovoltaic performance of the solar cells<sup>3,4</sup>. Here we visualized the out-of-plane<br>compositional inhomogeneity along the vertical direction across perovskite films and<br>identified the underlying reasons for the inhomogeneity and its potential impact for<br>devices. We devised a strategy using 1-(phenylsulfonyl)pyrrole to homogenize the<br>distribution of cation composition in perovskite films. The resultant p–i–n devices<br>yielded a certified steady-state photon-to-electron conversion efficiency of 25.2% and<br>durable stability.|



There have been significant improvements in the efficiency of lead-halide perovskite solar cells (PSCs)<sup>5</sup> , largely due to the development of new passivation strategies<sup>6,7</sup> and the optimization of the perovskite composition<sup>8</sup> . Notably, the modulation of the A-site composition, specifically with FA-Cs alloyed perovskite, where FA is formamidinium, is emerging as a promising method for boosting efficiency<sup>9</sup> . However, there are growing concerns about the stability of Cs-containing perovskites due to the segregation of the cations, which could potentially accelerate the long-term degradation<sup>3,4,10,11</sup> . The distribution of these inhomogeneous phases within perovskites and their direct impact on efficiency are not yet fully understood. 

Herein, we visualize the spatially inhomogeneous phase distribution along the vertical direction across perovskite films and propose that device performance is limited by out-of-plane compositional inhomogeneity. Furthermore, we identified that unbalanced crystallization and phase transition between A-site components have a significant effect on the segregation of the FA and Cs phases. To address this issue, we devised a strategy using 1-(phenylsulfonyl) pyrrole (PSP) as an additive to retard the segregation of cations in FA-Cs perovskites. The PSP-treated devices have a p–i–n structure and yielded a champion photon-to-electron conversion efficiency 

(PCE) of 26.1% (certified reverse PCE of 25.8% and certified steady-state PCE of 25.2%). 

### **Out-of-plane cation inhomogeneity** 

The distribution of A-site cations within perovskite films critically affects the performance of the device<sup>12</sup> . Although Cs has been widely used as a cation dopant in perovskite formulations, there are still concerns about the inhomogeneous distribution of cations. Figure 1a is a schematic illustration of the out-of-plane cation inhomogeneity. It shows that Cs prefers to aggregate at the bottom of the perovskite film because crystallization has a significant impact on the compositional evolution within perovskite films. An organic molecule of PSP with a sulfone group<sup>13,14</sup> was designed as an additive to the precursor to address the cation inhomogeneity within perovskites, particularly for FA-Cs-containing perovskites (Fig. 1b, Supplementary Fig. 2 and Supplementary Note 1). 

We conducted time-of-flight secondary-ion mass spectroscopy (ToF-SIMS) to investigate the cation distribution (Supplementary Fig. 4). Figure 1c illustrates that in the reference film, for the Cs there is an increasing intensity gradient from the perovskite surface towards 

> 1Key Laboratory of Photovoltaic and Energy Conservation Material, Institute of Solid-State Physics (ISSP), Hefei Institutes of Physical Science (HIPS), Chinese Academy of Sciences, Hefei, People’s Republic of China.<sup>2</sup> University of Science and Technology of China (USTC), Hefei, People’s Republic of China.<sup>3</sup> Shenzhen Engineering Research and Development Center for Flexible Solar Cells, Southern University of Science and Technology (SUSTech), Shenzhen, People’s Republic of China.<sup>4</sup> Department of Materials Science and Engineering, Southern University of Science and Technology (SUSTech), Shenzhen, People’s Republic of China.<sup>5</sup> Hefei National Laboratory for Physical Sciences at the Microscale and Department of Physics, University of Science and Technology of China (USTC), Hefei, People’s Republic of China.<sup>6</sup> School of Chemical Engineering and Center for Antibonding Regulated Crystals, Sungkyunkwan University (SKKU), Suwon, Republic of Korea.<sup>7</sup> SKKU Institute of Energy Science & Technology (SIEST), Sungkyunkwan University, Suwon, Republic of Korea.<sup>8</sup> Shanghai Synchrotron Radiation Facility (SSRF), Shanghai Advanced Research Institute (SARI), and Shanghai Institute of Applied Physics, Chinese Academy of Sciences (CAS), Shanghai, People’s Republic of China.<sup>9</sup> Instruments Center for Physical Science (PIC), University of Science and Technology of China (USTC), Hefei, People’s Republic of China.<sup>10</sup> Department of Physics, The Hong Kong University of Science and Technology, Clear Water Bay, Kowloon, People’s Republic of China.<sup>11</sup> University Grenoble-Alpes, CEA, CNRS, INP, IRIG/SyMMES, STEP, Grenoble, France.<sup>12</sup> IEK5-Photovoltaics, Forschungszentrum Jülich, Jülich, Germany.<sup>13</sup> Faculty of Engineering and CENIDE, University of Duisburg-Essen, Duisburg, Germany.<sup>14</sup> State Key Laboratory of Alternate Electrical Power System with Renewable Energy Sources, North China Electric Power University (NCEPU), Beijing, People’s Republic of China.<sup>15</sup> These authors contributed equally: Zheng Liang, Yong Zhang, Huifen Xu.<sup>✉</sup> e-mail: sydai@ncepu.edu.cn; npark@skku.edu; yejj@issp.ac.cn; xpan@rntek.cas.cn 

Nature | Vol 624 | 21/28 December 2023 | **557** 

## Article 



<!-- Start of picture text -->
a Ag b<br>C60/BCP<br>FA-rich<br>surface<br>Perovskite<br>Nominal<br>PTAA<br>bulk<br>ITO<br>Cs-rich<br>bottom –5.0 e –2 0 5.0 e –2<br>PbI64– FA + Cs +<br>c d g<br>100<br>Cs + Ref. Ref.<br> PSP I<br> SO2–<br>5.0<br>C<br>Pb 4.0<br>10 3.0<br>Ref.<br>FA +  Ref.  PSP 2.0<br> PSP<br>1.0<br>Cs 0.8<br>1 0.4<br>0.1<br>500 1,000 1,500 2,000 0 500 1,000 27 28 29<br>Sputter time (s) Etching depth (nm) 2 �  (°)<br>e f h<br>Surface Bulk Bottom Surface Bulk Bottom<br>Ref. PSP PSP<br>5.0<br>d {200} ≈ 3.20 Å d {200} ≈ 3.15 Å d {200} ≈ 3.11 Å d {200} ≈ 3.13 Å d {200} ≈ 3.13 Å d {200} ≈ 3.13 Å 4.0<br>3.0<br>2.0<br>1.0<br>0.8<br>0.4<br>0.1<br>0 1 2 3 0 1 2 3 27 28 29<br>Distance (nm) Distance (nm) 2 �  (°)<br>Intensity (a.u.)<br>Intensity (counts)<br>Atomic percentage (%)<br>Grazing incidence angle (°)<br>Intensity (a.u.)<br>Grazing incidence angle (°)<br>Normalized Normalized<br>intensity (a.u.) intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Spatial vertical segregation of the FA and Cs phases. a** , Illustration of inhomogeneous phase distribution caused by out-of-plane FA and Cs segregation. **b** , Electrostatic potential image and molecular structure of PSP. **c** , Distribution of cations obtained from ToF-SIMS spectra for the reference (Ref.; blue) and PSP (red) devices. **d** , Atomic percentage profile of the reference (solid lines) and the PSP (dashed lines) extracted from depth-dependent XPS measurements. **e** , **f** , High-angle annular dark-field TEM images for the reference sample ( **e** ) and the PSP-treated sample ( **f** ). Scale bars, 200 nm. The crosssectional samples were prepared with a stack configuration of ITO/PTAA/ 

perovskite/PTAA/Cu. The second row underneath each image shows highresolution TEM images collected from the corresponding boxes. Scale, 7.3 × 7.3 nm. The third row shows the variation of calculated intensity over 3 nm. The calculated interplanar spacing for each lattice is given in the corresponding images. **g** , **h** , Enlarged GIXRD spectra collected from the bottom of the reference perovskite film ( **g** ) and the PSP-treated perovskite film ( **h** ). Structural information with a spatially vertical resolution could be obtained by varying the incident angle of the X-ray beam. In **g** , the red and blue shading represents the Cs-rich phase and FA-rich phase, respectively. a.u., arbitrary units. 

the bottom. The FA cations have the opposite trend. This observation confirms the out-of-plane cation inhomogeneity within the perovskite film. Notably, the addition of PSP resulted in a homogeneous cation distribution. Furthermore, as inferred from the characteristic fraction of SO2−, PSP molecules accumulate at the bottom of the perovskite film. To further survey the elemental variation within the perovskite film, we conducted depth-dependent X-ray photoelectron spectroscopy (XPS). The extracted atomic percentage depth profiles have a similar out-of-plane compositional gradient (Fig. 1d). 

The out-of-plane cation inhomogeneity could potentially influence the perovskite lattice, thereby altering the crystal structure. Hence, it is 

crucial to systematically investigate the structural variations induced by cation inhomogeneities. We visualized the out-of-plane A-site compositional inhomogeneity by studying the lattice heterogeneity of various perovskite phases. We collected cross-sectional transmission electron microscopy (TEM) images. Three regions across the perovskite films (denoted as surface, bulk and bottom) were selected to survey the interplanar spacing of the lattice ( _d_ ), which is a direct indication of phase heterogeneity. Vertical gradients for the cation distributions were directly observed by comparing the values of _d_ {200}. For the reference film, the three _d_ values were measured to be _d_ surface = 3.20 Å, _d_ bulk = 3.15 Å and _d_ bottom = 3.11 Å (Fig. 1e). The decreasing trend of the _d_ 

**558** | Nature | Vol 624 | 21/28 December 2023 

values correlates with the increasing internal lattice stress within the perovskite film. The decrease in _d_ bottom suggests that there is a significant lattice mismatch at the bottom of the film<sup>15</sup> . This could be ascribed to the relatively smaller Cs atoms accumulating at the bottom, thereby generating a Cs-rich perovskite phase. Importantly, the detected lattice contraction implies that cation inhomogeneity is a contributory factor to the lattice strain<sup>16,17</sup> . In contrast, as shown in Fig. 1f, negligible variation of the _d_ values was found in the PSP-treated film, which has _d_ surface = 3.13 Å, _d_ bulk = 3.13 Å and _d_ bottom = 3.13 Å. This finding indicates that PSP treatment provides a better out-of-plane lattice alignment and releases the lattice stress by inhibiting phase segregation. 

We employed the grazing incident X-ray diffraction (GIXRD) technique to detect the crystal structure from the exposed lower interface (Fig. 1g and Extended Data Fig. 1). For the reference film, the peaks are at around 28.1°, which are indexed for the (200) plane of perovskite. The split is significantly wider. Shoulder peaks emerge at around 28.4° when the incident angle was lower than 2°. These emergent shoulder peaks gradually weaken with an increase of the incident angle and ultimately vanish. The spectrum changes to stronger integrated peaks when the incident angle is larger than 3°. In contrast, the shoulder peaks are negligible after introducing the PSP (Fig. 1h). Moreover, a vertical misalignment of the peaks, which is an indication of the internal strain caused by lattice mismatch, is observed for the reference and PSP-1.2 films (Supplementary Figs. 5 and  6), which agrees well with the findings of the microscale TEM measurements. These results suggest that there is an out-of-plane inhomogeneous crystal structure within the reference perovskite film. The shoulder peaks may be associated with an undesired Cs-rich phase<sup>2</sup> in the buried region of the perovskite film. 

We presume, according to the coherence between 2 _θ_ and the lattice space, that the shoulder peaks can be attributed to a Cs-rich phase caused by Cs incorporation<sup>15,18,19</sup> . Considering the conventional X-ray diffraction (XRD) results (Supplementary Figs. 7 and  8), we may conclude that the spatially out-of-plane compositional inhomogeneity is generated by segregation of the FA and Cs phases in the perovskite films, even for Cs/(Cs + FA) ratios as low as 5%. The Cs-rich phase prefers to accumulate in the bottom region within perovskite films, thus leading to a gradient in the phase distribution from Cs-poor to Cs-rich from the surface to the bottom. 

Consequently, the results obtained allow us to conclude that in FA-Cs perovskite films, the different sizes of the cations of FA and Cs result in a spatially out-of-plane lattice mismatch. As shown in Fig. 1a, from top to bottom, there is a FA-rich phase, a phase in which the cations have nominal stoichiometry and a Cs-rich phase. 

### **Origin of the cation inhomogeneity** 

We performed in situ synchrotron radiation grazing incidence wide-angle X-ray scattering (GIWAXS) to investigate the two critical kinetics processes of crystallization and phase transition during perovskite formation. As demonstrated in Fig. 2a, signals for a **q** vector of around 0.8, 0.82 and 1.0 Å<sup>−1</sup> can be assigned to the δ-phase perovskite of 2H (100), 6H (101), and α-phase perovskite, respectively<sup>20</sup> . We defined two periods when analysing the kinetic processes. Period I was from after chlorobenzene dripping until the emergence of α-phase perovskite. The duration of this period is indicative of the crystallization rate. Period II was the duration it took for the α phase to become stable, which reflects the δ- to α-phase transition rate. From the in situ GIWAXS results, we found that the introduction of PSP accelerates both the crystallization and phase transition. Combined with the results from ‘Out-of-plane cation inhomogeneity’, this shows that PSP has effectively inhibited the segregation of the FA and Cs phases. A possible kinetical culprit for the phase segregation is the slow speeds of crystallization and phase transition. 

We further conducted density functional theory computations to thermodynamically investigate the barrier energy ( _E_ B) for perovskite 

crystallization and phase transition and subdivided the energy into the processes for the FA and Cs components. The difference between the barrier energies was defined as ∆ _E_ B = _E_ FAB − _E_ BCs. To evaluate more accurately the imbalance between the FA and Cs components, we cal-culated the mismatch factor period I, for the reference system, Δ _µ_ = _E_ FAB _EE_ −BFAB,I _E_ refCsB . As shown in Fig. 2b,c, during  = 101.6 meV. After the PSP was introduced, Δ _E_ B,IPSP = 35.3 meV. The corresponding _μ_ values were calculated to be _μ_ I,ref = 20.48% and _μ_ I,PSP = 5.34%. During period II, for the reference system, Δ _E_ B,IIref = 82 meV with _μ_ ref = 12.49%, whereas Δ _E_ B,IIPSP = −6 meV with _μ_ PSP = −1.79% for the PSP system (Supplementary Table 2). The lower _μ_ I and _μ_ II for the PSP system indicate that the differences in the crystallization and phase transition rates of the FA and Cs components were reduced. Such differences in the rates for cations were probably responsible for the tardiness observed by in situ GIWAXS. A possible reason for the cation inhomogeneity could be the soft base property of the Cs cations compared to the FA cations, which may lead to a much more intensive interaction with PbI3−, leading to Cs preferentially aggregating at the bottom. Additionally, the difference in the solubilities of Cs and FA components might partially also contribute to the cation inhomogeneity<sup>21</sup> . 

We collected adsorption spectra of the Pb LIII edge using extended X-ray absorption fine spectroscopy (EXAFS) to evaluate the interactions between PSP and perovskite. We selected five grazing incident angles to capture information at various depths within the perovskite film (Supplementary Fig. 12). As shown in Fig. 2d,e, peaks at radial distances of approximately 2.2 and 2.9 Å can be attributed to Pb–O and Pb–I coordination, respectively<sup>22</sup> . In the reference film, we observed a gradual downwards shift of around 0.03 Å for the Pb–I coordination with an increase in detection depth (Fig. 2d). This indicates that the lattice was compressed at the bottom of the perovskite<sup>23</sup> . In contrast, the peaks associated with Pb–I coordination remained relatively stable upon the incorporation of PSP, further reinforcing the existence of out-of-plane cation inhomogeneity. Notably, in the PSP film, peaks corresponding to Pb–O coordination migrated by a higher radial distance as the depth increased (Fig. 2e). This suggests the creation of a longer Pb–O coordination at the bottom of the film. By calculating of the Pb–O coordination ratio as (Pb–O)/ ((Pb–O) + (Pb–I)) (Fig. 2f), we concluded that Pb atoms at the bottom of the perovskite film tend to coordinate with additional oxygen atoms from PSP. Consequently, we hypothesize that PSP possibly interacts with the Pb atoms in perovskite through electrons donated by its two oxygen atoms. 

To precisely evaluate the interaction between PSP and PbI2, we synthesized (PbI2) _x_ (PSP)y complex crystals (Extended Data Fig. 2 and Supplementary Fig. 13), and performed Fourier transform infrared spectroscopy (FTIR) measurements. Peaks at around 1,328, 1,133 and 964 cm<sup>−1</sup> correspond to asymmetric stretching vibration ( _ν_ as) and symmetric stretching vibration ( _ν_ s) of the sulfone (O=S=O) and vibration ( _ν_ ) of the sulfoxide (S=O) group, respectively. Significant shifts in all three characteristic peaks indicate the coordination of PSP with PbI2 through the sulfone (O=S=O) group (Fig. 2g). The upward shifts of the _ν_ as and _ν_ s peaks imply that both oxygen atoms from PSP may serve as active sites. Additionally, nuclear magnetic resonance (NMR) spectra corroborated the coordination of the O=S=O group with PbI2. This was discerned through shifts in the carbon atoms adjacent to the O=S=O group (nos. 1, 2, 6, 11 and 14) to a higher field (Extended Data Fig. 3). These findings align with the decreased PbI2 signal observed by in situ GIWAXS tests and the peak shifts detected in XPS measurements (Supplementary Fig. 14). 

### **Optoelectronic properties** 

Besides retarding the phase segregation, PSP has a practical passivation effect. The steady-state and time-resolved photoluminescence were examined to optically evaluate changes in recombination caused by 

Nature | Vol 624 | 21/28 December 2023 | **559** 

## Article 



<!-- Start of picture text -->
CB dripping Crystallization Phase transition Crystallization Phase transition<br>a I II Ref. b c<br>α phase 101.6  82 meV 35.3  6 meV<br>1.0 meV meV<br>δ-6H (101)<br>0.8<br>δ-2H (100) Ref. PSP<br>FA FA<br>Cs Cs<br>I II PSP-1.2 Mixture δ phase α phase Mixture δ phase α phase<br>Reaction coordinate Reaction coordinate<br>1.0 d e<br>1.0 Ref. 1.0 PSP<br>GI angle GI angle<br>0.8 0.50° 0.8 0.50°<br>0.8<br>0.35° 0.35°<br>0.6 0.27° 0.6 0.27°<br>0.22° 0.22°<br>0.4 0.19° 0.4 0.19°<br>I II PSP-2.4<br>0.2 0.2<br>1.0<br>0 0<br>1 2 3 4 1 2 3 4<br>Radial distance (Å) Radial distance (Å)<br>0.8<br>f g PSP  PSP (PbI2)<br>36<br>Ref.<br>II PSP<br>PSP-4.8<br>33<br>1.0 � as (O=S=O) � (S=O)<br>� s (O=S=O)<br>30<br>0.8<br>27<br>0 100 200 300 400 0 500 1,000 1,500 1,400 1,300 1,200 1,100 1,000 900<br>Time (s) Penetration depth (nm) Wavenumber (cm –1 )<br> (Å–1) q<br>Free energy (eV) Free energy (eV)<br> (Å–1) q<br>)| (Å–3|() R χ )| (Å–3|() R χ<br> (Å–1) q<br> (Å–1) q<br>Transmittance (a.u.)<br>Coordination ratio (%)(Pb-O)<br><!-- End of picture text -->

**Fig. 2 | Revealing the origin of the segregation of the FA and Cs phases. a** , In situ GIWAXS pattern revealing processes of crystallization and phase transition. The  colour bars range from 0 to 1. **b** , **c** , Schematics of computation results for free energy evolution in the reference system ( **b** ) and PSP system ( **c** ) during crystallization and the phase transition. The blue and red rectangles represent the relevant FAPbI3 phases and CsPbI3 phases, respectively. The blue 

and red solid lines indicate the free energy evolution of FAPbI3 and CsPbI3, respectively. **d** , **e** , Plots of Fourier-transformed _R_ space results of EXAFS measurements of the reference films ( **d** ) and PSP films ( **e** ). The dashed lines at 2.9 Å and 2.2 Å correspond to the Pb–I and Pb–O coordination, respectively. **f** , Pb–O coordination ratios calculated from the EXAFS measurements. **g** , FTIR spectra of PSP and the PSP(PbI2) complex. CB, chlorobenzene. 

the out-of-plane lattice mismatch. In Fig. 3a, a significantly stronger photoluminescence peak was observed for the PSP film relative to that of the reference film. Moreover, the carrier lifetime of the PSP-treated film was extended to 1,876.6 ns compared with 491.7 ns for the reference (Fig. 3b and Supplementary Table 3). We used thermal admittance spectroscopy to characterize the trap density of the perovskite films. Supplementary Fig. 17 depicts that the trap density of states decreased after PSP introduction at shallow and deep energetic levels. Shallow traps could be attributed to a homogeneous phase distribution, which may inhibit the formation of vacancies. Further, a released spatial lattice mismatch is beneficial for stabilizing octahedral frameworks, which in turn positively reduces the metal-related deep defects<sup>24,25</sup> . We further modelled the lattice and calculated the defect formation energy using FA0.95Cs0.05PbI3 perovskite (Fig. 3c and Supplementary Fig. 19). Figure 3d shows that the defect formation energy of a series of defects was increased after PSP introduction, especially for the Pb and I vacancies, which should result in lower defect densities and longer carrier lifetimes in experiments. 

Efficient carrier diffusion and extraction are affected by the vertical band alignment of different phases within a perovskite film, which correlates with the out-of-plane compositional inhomogeneity. Depth-profile ultraviolet-photoelectron spectroscopy was carried out 

to evaluate the internal band alignment (Extended Data Fig. 4). Figure 3e shows that the out-of-plane compositional inhomogeneity may lead to quasi-type I band alignment at the contact region of the Cs-rich phase with a thickness of a few hundreds of nanometres. The conduction-band minimum and valence-band maximum are downwards and upwards twisted, respectively. This band alignment adversely affects carrier transport for solar cells through electrical doping<sup>26</sup> whether in a p–i–n or n–i–p configuration (Extended Data Fig. 5). In this case, the inherent disequilibrium of electron–hole extraction would be seriously aggravated<sup>27,28</sup> . Ultimately, it would worsen the device efficiency, especially the fill factor<sup>29–31</sup> . After PSP introduction, the band diagram had a favourable flattened alignment, mitigating energy losses of charge carriers within perovskite films (Fig. 3f). The findings from transient adsorption measurements align with the conclusion obtained from energy band alignment (Extended Data Fig. 6). Moreover, we tested the built-in electrical field ( _V_ bi) in a p–i–n device. The improved _V_ bi was beneficial for carrier diffusion as well (Supplementary Fig. 20). 

### **Device performance** 

We fabricated devices with a p–i–n stack of indium tin oxide (ITO)/ poly(triaryl)amine (PTAA)/FA0.95Cs0.05PbI3/C60/bathocuproine (BCP)/ 

**560** | Nature | Vol 624 | 21/28 December 2023 



<!-- Start of picture text -->
a b<br>Ref.  Ref.<br>PSP  PSP<br>650 750 850 950 0 1,000 2,000 3,000 4,000<br>Wavelength (nm) Time (ns)<br>c d<br> Ref.<br> PSP<br>V Pb<br>V I<br>V FA<br>V Cs<br>0 1 2 3 4 5<br>Formation energy (eV)<br>e HTL Perovskite ETL f HTL Perovskite ETL<br>–<br>– – – – –<br>4.23 eV 4.28 eV 4.27 eV 4.30 eV 4.33 eV 4.33 eV<br>Cs-rich Nominal FA-rich Bottom Bulk Surface<br>� F � F<br>Energy<br>barrier 5.80 eV 5.79 eV 5.82 eV 5.85 eV 5.85 eV<br>5.95 eV + + + + +<br>+ � Carrier extraction equilibrium<br>PL intensity (a.u.)<br>PL intensity (normalized)<br>Energy (eV) Energy (eV)<br><!-- End of picture text -->

**Fig. 3 | Optoelectronic properties. a** , Steady-state photoluminescence (PL) spectra of perovskite films with and without PSP treatment deposited onto quartz glass substrates. **b** , Time-resolved PL spectra of perovskite films deposited onto quartz glass substrates. The solid lines are fitted using the dual exponential fitting method. **c** , Constructed lattice model of FA0.95Cs0.05PbI3 perovskite. The (100) plane of the lattice was exposed so that it could adsorb a PSP molecule for the density functional theory computation. **d** , Statistics for 

the defect formation energy for various types of defect in the reference and PSP systems. **e** , **f** , Schematics for the band alignment within the reference perovskite film ( **e** ) and the PSP perovskite film ( **f** ). The values of the conductionband minimum, valence-band maximum and Fermi level ( _E_ F) were extracted from the depth-profile ultraviolet-photoelectron spectrum. The schematics were finally obtained by combining data from three depth regions with a manually aligned _E_ F. HTL, hole-transport layer; ETL, electron-transport layer. 

Ag. The bandgap of this perovskite recipe was determined to be 1.51 eV by the Tauc plot method (Supplementary Figs. 21) and by using the derivative of the external quantum efficiency (EQE) of the solar cell (Extended Data Fig. 7). The champion device yielded a notable PCE of up to 26.09%/25.16% (reverse/forward scan direction) whereas the reference cell had PCEs of 24.62%/23.48% (Fig. 4a). The corresponding steady-state power output efficiencies were 25.15% and 23.72%, respectively. An unencapsulated device achieved certified PCEs of 25.8% and 25.2% for the reverse scan and for the steady-state output, as certified by an independent organization (Supplementary Fig. 22). The fill factor of the champion device exceeded 85%, which is nearly 95% of the theoretical limit (89.5%). We attributed the remarkable fill factor improvement to the improved charge carrier extraction, which is supported by the efficiency improvement in the n–i–p configuration as well (Supplementary Fig. 23). The open-circuit voltage ( _V_ OC) improved from 1.145 to 1.164 V, which is consistent with the reduced trap density. The short-circuit current density ( _J_ SC) over 26 mA cm<sup>−2</sup> 

was consistent with the integrated _J_ SC extracted from the incident photon-to-electron conversion efficiency (IPCE) (Fig. 4b). The reproducibility was evaluated using a batch of devices comprising 16 individuals for each set-up (Supplementary Fig. 25). We further tested the solar cells in a light-emitting diode (LED) mode. The LED EQEEL improved from 7.1% to 9.7% (Fig. 4c), so that the emission peaks were around 820 nm (Supplementary Fig. 26). We fabricated devices with an upscaled area of 1 cm<sup>2</sup> , and the efficiency improved from 21.78% to 23.64% (Fig. 4d). This improvement was mainly associated with the enhanced fill factor. Further devices with typical efficient perovskite formulas were fabricated to assess the universality of the PSP strategy (Supplementary Figs. 27–29), although some perovskite formulas still require further evaluation. 

Device reliability was evaluated following the procedure specified in the ISOS protocols<sup>32</sup> . An unencapsulated PSP-treated device retained 92% of its initial PCE after 2,500 h of continuous tracking at the maximum power point in a nitrogen atmosphere. By contrast, 

Nature | Vol 624 | 21/28 December 2023 | **561** 

## Article 



<!-- Start of picture text -->
a b 100 28<br>25.98<br>25<br>24<br>At 1.04 V 80<br>26 At 1.02 V<br>20 20<br>24<br>22 60<br>15 0 200 400 600 800 1,000 16<br>Time (s)<br>12<br>40<br>10<br>V OC J SC FF PCE 8<br>5 (V) (mA cm –2 ) (%) (%) 20<br>Ref. 1.145 26.23 81.96 24.61 4<br>PSP 1.164 26.14 85.74 26.09<br>0 0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 800 900<br>Voltage (V) Wavelength (nm)<br>c 12 d<br>Ref. 1.0 cm 2<br>PSP 25<br>10<br>20<br>8<br>15<br>6<br>10<br>4<br>V OC J SC FF PCE<br>2 5 (V) (mA cm –2 ) (%) (%)<br>Ref. 1.144 24.89 76.50 21.78<br>PSP 1.149 25.03 82.19 23.64<br>0 0<br>10 –2 10 –1 10 0 10 1 10 2 0 0.2 0.4 0.6 0.8 1.0 1.2<br>Current density (mA cm –2 ) Voltage (V)<br>e<br>1.0<br>0.9<br>0.8<br>ISOS L-1I protocol<br>0.7 Ref.(champ.)<br>PSP(champ.) Nitrogen, RT, without encapsulation<br>0.6<br>0 500 1,000 1,500 2,000 2,500<br>Time (h)<br>f<br>1.0<br>0.9<br>0.8<br>ISOS D-3 protocol<br>0.7 Ref.(average)<br>PSP(average) Encapsulated device at 85 °C and 85% RH in dark<br>0.6<br>0 100 200 300<br>Time (h)<br>PCE (%)<br>IPCE (%)<br>–2 (mA cm)Integrated  J sc<br>–2Current density (mA cm)<br>EQE (%)EL<br>–2Current density (mA cm)<br>Efficiency (normalized)<br>Efficiency (normalized)<br><!-- End of picture text -->

**Fig. 4 | Device performance and stability. a** , _J–V_ curves of champion p–i–n PSCs at laboratory scale. The active area was around 0.073 cm<sup>2</sup> . The inset shows the detailed photovoltaic parameters from the reverse scan and the steady-state power output. **b** , IPCE plots for the PSP solar cells. The solid red line is the integrated _J_ SC. **c** , EQE curves measured for the reference and PSP solar cells in LED mode. The inset is a photograph showing the PSCs working in LED mode. **d** , _J–V_ curves of scaled-up PSCs with and without PSP. The inset is a photograph showing the scaled-up PSCs with 1 cm<sup>2</sup> active area. **e** , Normalized evolution of the PCE for unencapsulated reference and PSP devices under continuous 

tracking at the maximum power point following the ISOS L-1I protocol. The initial PCEs of the reference and PSP devices were 25.40% and 23.54%, respectively. RT, room temperature. **f** , Results of damp-heat reliability tests of the encapsulated devices tested at 85 °C and 85% relative humidity (RH) following the ISOS D-3 protocol. A device stack based on ITO/PTAA/perovskite/C60/Au was used in the damp-heat tests. The solid lines represent the average PCE for six individual devices. The initial average PCEs of the reference and PSP devices were 19.2% and 21.8%. The error bars denote the standard deviation. champ., champion; FF, fill factor. 

the PCE of the reference device dropped to around 80% of its initial value under the same conditions (Fig. 4e). Damp-heat experiments were conducted using encapsulated devices in an ageing box with 85 °C and 85% relative humidity. The PSP-treated device exhibited almost 90% efficiency after over 300 h on average, compared with around 80% for the initial PCE of the reference (Fig. 4f). Regarding 

the temperature cycling reliability, the encapsulated PSP-treated device retained 93% of its initial PCE after 300 cycles, compared to 67% for the reference (Extended Data Fig. 8). Overall, these findings provide an in-depth understanding of phase segregation and suggest a promising strategy for accelerating commercialization of perovskite photovoltaics. 

**562** | Nature | Vol 624 | 21/28 December 2023 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-023-06784-0. 

1. Li, Z. et al. Stabilizing perovskite structures by tuning tolerance factor: formation of formamidinium and cesium lead iodide solid-state alloys. _Chem. Mater._ **28** , 284–292 (2015). 

2. Yi, C. et al. Entropic stabilization of mixed A-cation ABX3 metal halide perovskites for high performance perovskite solar cells. _Energy Environ. Sci._ **9** , 656–662 (2016). 

3. Li, N. et al. Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under operational stressors. _Joule_ **4** , 1743–1758 (2020). 

4. Bai, Y. et al. Initializing film homogeneity to retard phase segregation for stable perovskite solar cells. _Science_ **378** , eabn3148 (2022). 

5. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

6. Jiang, Q. et al. Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278–283 (2022). 

7. Zhao, Y. et al. Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 531–534 (2022). 

8. Kim, G. et al. Impact of strain relaxation on performance of α-formamidinium lead iodide perovskite solar cells. _Science_ **370** , 108–112 (2020). 

9. Bu, T. et al. Lead halide-templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ **372** , eabh1035 (2021). 

10. Liu, L. et al. A-site phase segregation in mixed cation perovskite. _Mater. Rep., Energy_ **1** , 100064 (2021). 

11. Correa-Baena, J.-P. et al. Homogenized halides and alkali cation segregation in alloyed organic–inorganic perovskites. _Science_ **363** , eaah5065 (2019). 

12. Lee, J. W. et al. Rethinking the A cation in halide perovskites. _Science_ **375** , eabj1186 (2022). 

13. Jeon, N. J. et al. Solvent engineering for high-performance inorganic–organic hybrid perovskite solar cells. _Nat. Mater._ **13** , 897–903 (2014). 

14. Ren, Y. et al. A bi-functional additive for linking PI2 and decreasing defects in organo-halide perovskites. _J. Alloys Compd._ **758** , 171–176 (2018). 

15. Kim, H.-S. & Park, N.-G. Importance of tailoring lattice strain in halide perovskite crystals. _NPG Asia Mater._ **12** , 78 (2020). 

16. Turren-Cruz, S.-H. et al. Methylammonium-free high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , eaat3583 (2018). 

17. Zhu, C. et al. Strain engineering in perovskite solar cells and its impacts on carrier dynamics. _Nat. Commun._ **10** , 815 (2019). 

18. Kubicki, D. J. et al. Phase segregation in Cs-, Rb- and K-doped mixed-cation (MA) _x_ (FA)1− _x_ PbI3 hybrid perovskites from solid-state NMR. _J. Am. Chem. Soc._ **139** , 14173–14180 (2017). 

19. Chen, L. et al. Toward long-term stability: single-crystal alloys of cesium-containing mixed cation and mixed halide perovskite. _J. Am. Chem. Soc._ **141** , 1665–1671 (2019). 

20. Proppe, A. H. et al. Multication perovskite 2D/3D interfaces form via progressive dimensional reduction. _Nat. Commun._ **12** , 3472 (2021). 

21. Zheng, Y. et al. Downward homogenized crystallization for inverted wide‐bandgap mixed‐ halide perovskite solar cells with 21% efficiency and suppressed photo‐induced halide segregation. _Adv. Funct. Mater._ **32** , 2200431 (2022). 

22. Kang, D.-H. et al. Extended X-ray absorption fine structure (EXAFS) of FAPbI3 for understanding local structure–stability relation in perovskite solar cells. _J. Energy Chem._ **67** , 549–554 (2022). 

23. Park, J. et al. Controlled growth of perovskite layers with volatile alkylammonium chlorides. _Nature_ **616** , 724–730 (2023). 

24. Zhou, Y., Poli, I., Meggiolaro, D., De Angelis, F. & Petrozza, A. Defect activity in metal halide perovskites with wide and narrow bandgap. _Nat. Rev. Mater._ **6** , 986–1002 (2021). 

25. Shao, Y. et al. Origin and elimination of photocurrent hysteresis by fullerene passivation in CH3NH3PbI3 planar heterojunction solar cells. _Nat. Commun._ **5** , 5784 (2014). 

26. Euvrard, J. et al. Electrical doping in halide perovskites. _Nat. Rev. Mater._ **6** , 531–549 (2021). 27. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci_ **7** , 982–988 (2014). 

28. Herz, L. M. Charge-carrier mobilities in metal halide perovskites: fundamental mechanisms and limits. _ACS Energy Lett._ **2** , 1539–1548 (2017). 

29. Peng, J. et al. Centimetre-scale perovskite solar cells with fill factors of more than 86 per cent. _Nature_ **601** , 573–578 (2022). 

30. Ding, Y. et al. Single-crystalline TiO2 nanoparticles for stable and efficient perovskite modules. _Nat. Nanotechnol._ **17** , 598–605 (2022). 

31. Cao, Q. et al. Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. _Sci. Adv._ **7** , eabg0633 (2021). 

32. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2023 

Nature | Vol 624 | 21/28 December 2023 | **563** 

## Article **Methods** 

#### **Materials** 

Lead iodide (PbI2, 99.999%), lead bromide (PbBr2, 99.999%), caesium iodide (CsI, 99.999%), bis(trifluoromethane)sulfonimide lithium salt (Li-TFSI, 99.95%) and 4-tert-butylpyridine were purchased from Sigma Aldrich. Formamidinium iodide, methylammonium (MA) bromide and methylammonium chloride (MACl) were synthesized in house by reacting equal molar amounts of formamidine (FA) acetate and methylamine alcohol solution with the corresponding halogen acid<sup>33</sup> . PSP was synthesized in a laboratory according to the method mentioned in the Supplementary Information. PTAA, 2,2′,7,7′-tetrakis[N,N-di (4-methoxyphenyl)amino]-9,9′-spirobifluorene (spiro-OMeTAD) and BCP were purchased from Lumtec. Tin (IV) oxide (SnO2, 15% in H2O colloidal dispersion) was purchased from Alfa Aesar. Fullerene (C60) was purchased from Nano-C. All solvents used in the experiments, including _N_ , _N_ -dimethylformamide (99.8%), dimethyl sulfoxide (anhydrous, 99.9%), chlorobenzene (anhydrous, 99.8%), acetonitrile (99.9%) and isopropyl alcohol (anhydrous, 99.8%), were purchased from Sigma Aldrich. All chemicals were used as received without any further purification. 

#### **Perovskite precursor solution** 

The perovskite precursor solution was prepared by dissolving FAPbI3 (1.71 M) powder and CsPbI3 powder (0.09 M) in a mixture of the solvents dimethylformamide and dimethyl sulfoxide (8:1 v/v). 0.5% MAPbBr3 powder, 7.2% PbI2 and 30% MACl with molar ratio were added to increase the crystallinity<sup>34</sup> . For a solution with PSP agents, PSP powder was directly added into the perovskite precursor solution with different concentrations. PSP at 1.2, 2.4 and 4.8 mg ml<sup>−1</sup> was added to perovskite precursors for comparison (denoted as PSP-1.2, PSP-2.4 and PSP-4.8, respectively). The obtained precursor was vigorously shaken at room temperature for over 3 h. Finally, the perovskite precursor solutions were filtered through 0.22 μm polytetrafluoroethylene filters before use. 

#### **Device fabrication** 

The devices with the p–i–n configuration were fabricated as follows. Prepatterned ITO-coated glass substrates (7 Ω per square) were cleaned by sequential ultrasonication in detergent, deionized water, acetone and isopropanol each for 15 min, respectively. The cleaned substrates were dried under a flow of clean N2 and further dried in a 60 °C oven overnight. Before depositing the hole transport layer, the substrates were exposed to oxygen plasma cleaner for 5 min and then transferred into an N2 glovebox immediately for rest deposition progress. PTAA solution (2.5 mg ml<sup>−1</sup> dissolved in chlorobenzene) was spin-coated onto the substrate at 6,000 rpm for 30 s, then annealed at 100 °C for 15 min. The perovskite layer was deposited by one-step spin-coating of the filtered precursor solution at 1,000 rpm for 10 s and 4,000 rpm for 40 s. Then 200 μl of chlorobenzene was quickly dropped onto the centre of the spinning substrate at 15 s before the end. The film was immediately annealed at 100 °C for 30 min. After cooling down to room temperature, 100 μl of phenethylammonium iodide or _n_ -octylammonium iodide solution (5 mg ml<sup>−1</sup> ) was dynamically coated onto the perovskite films at 3,000 rpm for 30 s, followed by annealing at 100 °C for 5 min. The device fabrication was accomplished after sequential thermal evaporation of C60 (30 nm, 0.1 Å s<sup>−1</sup> ), BCP (7 nm, 0.1 Å s<sup>−1</sup> ) and Ag (100 nm, 0.2 Å s<sup>−1</sup> ) in a high-vacuum chamber (7 × 10<sup>−5</sup> Pa). Note that all procedures for device fabrication were conducted in a nitrogen glovebox (O2 and H2O less than 0.1 ppm). 

The devices with the n–i–p configuration were fabricated as follows. After the same pretreatment of the ITO substrates, SnO2 in a colloidal dispersion (diluted by 1:4 v/v with deionized H2O) was spin-coated onto the substrates at 3,000 rpm for 30 s, and sequentially annealed at 180 °C for 50 min in air (35% relative humidity). The procedures for perovskite film deposition were the same as those for the p–i–n devices. A solution of hole transport material was prepared 30 min before use 

by mixing spiro-OMeTAD (91 mg) and 4-tert-butylpyridine (36 μl) in chlorobenzene (1 ml). Li-TFSI (23 μl, 520 mg ml<sup>−1</sup> in acetonitrile) was doped to improve its conductivity. 50 μl of the solution of hole transport material was dynamically spin-coated onto the perovskite films at 3,000 rpm for 30 s in a nitrogen-filled glovebox. Finally, gold electrodes (100 nm, 0.2 Å s<sup>−1</sup> ) were deposited through thermal evaporation. 

#### **Photovoltaic performance characterization** 

The _J–V_ measurements were carried out with a xenon lamp-based solar simulator (Enlitech SS-F5-3A, Class AAA) and a source meter (Keithley 2400). The simulated AM 1.5G irradiation (100 mW cm<sup>−2</sup> ) was calibrated by a standard silicon cell (traced to NREL, SRC-2020). The solar cells were measured with a metal mask with an area of 7.485 mm<sup>2</sup> to accurately define the active area. The voltage was applied from −0.2 to 1.3 V with a scanning rate of 0.2 V s<sup>−1</sup> , and the voltage step was 20 mV. All devices were measured immediately after fabrication in an N2 glovebox. The IPCE was measured in a.c. mode on the xenon lamp-based system (Newport TLS260-300X). The scan range was from 300 to 1,000 nm. The solar cells were measured in LED mode in N2 using a home-made motorized goniometer set-up consisting of a source meter unit (Keithley 2400), a calibrated Si photodiode (FDS-100-CAL, Thorlabs), a pico-ammeter (4140B, Agilent) and a calibrated fibre optic spectrophotometer (UVN-SR, StellarNet Inc.). The distance between the LED device and the photodetector was 59.5 mm. 

#### **Stability characterization** 

A home-made calibrated LED-based solar simulator with an intensity of 100 mW cm<sup>−2</sup> was used as an illumination source in the stability tests. The tracking of the maximum power point was performed in N2. A blower was used to ensure the device was at a constant temperature. A home-made system was used to acquire the continuous power evolution. Devices for the damp-heat test were encapsulated with epoxy. The Ag electrodes were replaced by Au, and BCP was removed from the device. The damp-heat tests and thermal cycling tests were conducted in a customized ageing box. The accuracies of the temperature and humidity were under ±1 °C and ±5%, respectively. The damp-heat tests were periodically performed during the _J–V_ scan after cooling down in N2 for around 30 min. The thermal cycling tests were carried out by repeatedly performing the _J–V_ characterization after the stages for stabilizing the temperature. 

#### **Cross-sectional microstructure characterization** 

Note that all measurements, unless otherwise specified, were conducted with a perovskite formulation of FA0.95Cs0.05PbI3. The samples were prepared with ITO/PTAA/perovskite/PTAA/Cu stacks, in which a higher concentration of PTAA solution (30 mg ml<sup>−1</sup> in chlorobenzene) and thermally evaporated copper (200 nm, 0.2 Å s<sup>−1</sup> ) were used. Thick layers of PTAA and copper on the perovskite films can protect the samples from milling damage<sup>35</sup> . The other procedures were the same as in device fabrication apart from the absence of surface passivation. Pt and carbon layers were deposited before thinning using focused ion beam (FIB) equipment (ThermoFisher Helios 5 CX). A thick plate was extracted from the bulk sample at 30 kV and 3,000–30,000 pA, which was welded onto a Cu grid (omniprobe grid) by a probing system. The thick plate was first thinned at 30 kV and 50–1,000 pA and then at a lower current of 10–30 pA. Finally, the specimen was completed by thinning at a lower voltage of 1 kV and 30–50 pA after beam showering at 3 kV and 10–30 pA. The samples were immediately transferred to a TEM system (ThermoFisher Talos F200S). High-angle annular dark-field images across the full cross section of the samples and high-resolution TEM images were collected at an acceleration voltage of 200 kV. 

#### **Structure characterization** 

XRD and GIXRD data were acquired from a diffractometer (SmartLab, Rigaku) using Cu Kα ( _λ_ = 1.5406 Å) radiation. The tests were performed 

by scanning 2 _θ_ of 5°–45° with a scan rate of 3° min<sup>−1</sup> and 0.02° per step. The GIXRD tests detected signals from the bottom side of the perovskite films at grazing incident angles of 0.1°, 0.4°, 0.8°, 1°, 2°, 3°, 4° and 5°. The corresponding penetration depths for the perovskite material were calculated<sup>36</sup> as described in the Supplementary Information. 

#### **Depth profiling characterization** 

The depth profiles of perovskite deposited onto ITO substrates were recorded using a ToF-SIMS system (TOF-SIMS 5, ION-TOF) with a Bi<sup>3+</sup> primary beam (25 keV, 1 pA) and an oxygen sputter beam (1 keV, 45 nA). Note that an oxygen sputter gun can help in expelling pollution from the perovskite surface<sup>37</sup> . Samples were prepared with the full solar cell configuration for the depth-dependent photoelectron spectroscopy with an integrated etching system (ThermoFisher, ESCALAB Xi<sup>+</sup> ). 

#### **Synchrotron radiation characterization** 

Pb LIII-edge EXAFS data were collected on the BL13SSW beamline at the Shanghai Synchrotron Radiation Facility (SSRF) using the top-up mode operation with a ring current of 200 mA at 3.5 GeV. From the high-intensity X-ray photons of the multipole wiggler source, monochromatic X-ray beams could be obtained using a liquid-nitrogen-cooled double-crystal monochromator with a Si(111) crystal pair. For each grazing incident angle, X-ray absorption spectra were recorded in fluorescence mode using an N2/Ar mixed-gas-filled ionization chamber and passivated implanted planar silicon (Canberra Co.) for the incident and fluorescent X-ray photons, respectively. Higher-order harmonic contamination was eliminated by detuning to reduce the incident X-ray intensity by about 30%. The energy calibration was performed with a Pb foil reference using the Athena package<sup>38</sup> . Fourier-transformed radial distribution functions of k3-weighted Pb LIII-edge EXAFS spectra _k_<sup>3</sup> _χ_ ( _k_ ) were obtained in the _k_ range between 3.0 and 9.0 Å<sup>−1</sup> through a standard XAFS data-analysis process. In situ GIWAXS tests were performed at the beamlines BL14B1 and BL17B1 of SSRF. A two-dimensional detector (Rayonix MX300) was used to capture 360-frame spectra with 2 s intervals during spin-coating. Chlorobenzene dripping was automatically controlled in this experiment. 

#### **Other characterizations** 

The ultraviolet to visible absorption spectra were acquired with a spectrophotometer (Lambda 365, PerkinElmer). The photoluminescence and time-resolved photoluminescence were measured with a spectrofluorometer (Horiba Fluorolog-3 system). The excitation wavelength for the photoluminescence was 480 nm. The time-resolved photoluminescence was measured using a 532 nm laser nano-LED as an excitation source. All samples were deposited onto quartz glass. The morphology images were collected by a scanning electron microscope (Gemini SEM 500, Zeiss). The Mott–Schottky plots were measured with an applied bias range from −0.1 to 1.2 V. The built-in potential was deter2 mined using the equation area, _C_ the capacitance, _q_ the elementary charge, ( _CA_ ) = _qε_ r _ε_ 20 _N_ D ( _V_ bi − _V_ ) where _V_ bi the built-in poten- _A_ is the device tial, _V_ the applied voltage, _ε_ r the dielectric constant, _ε_ 0 the permittivity of free space and _N_ D the carrier density. The depletion width was calculated using _W_ = ( 2 _εN_ rD _ε_ 0 _V_ bi) 1/2. The capacitance–frequency curves were measured over a frequency range from 10<sup>1</sup> to 10<sup>6</sup> Hz using an electrochemical workstation (Zahner IM6ex). An a.c. amplitude voltage of 5 mV was used, and the d.c. bias was kept at 0 V to avoid the influence of the ferroelectric effect. The final trap density of states was calculated using tDOS( _Eω_ ) = − dd _ωC VqW_ bi _kω_ B _T_<sup>where</sup><sup>_ω_is the angular frequency,</sup><sup>_W_the</sup> depletion width, _k_ B the Boltzmann constant and _T_ temperature. _ω_ Here, _Eω_ = _k_ B _T_ ln( _ω_ 0 ) where _Ω_ 0 is the attempt-to-escape frequency at temperature _T_ . 

#### **Computational details** 

All the spin theoretical simulations in our work were carried out with the Vienna ab initio Simulation Package (VASP) v.5.4.4. The generalized 

gradient approximation with the Perdew–Burke–Emzerhof functional form was employed to evaluate the electron–electron exchange and correlation interactions. Projector augmented-wave methods were implanted to represent the core-electron (valence electron) interactions. The plane-wave basis function was set with a kinetic cutoff energy of 550 eV. The ground-state atomic geometries were optimized by relaxing the force below 0.02 eV/Å and the convergence criteria for energy was set with a value of 1.0 × 10<sup>−5</sup> eV per cell. The Brillouin zone was sampled using Monkhorst–Pack meshes of size 5 × 5 × 1 for the slab models. All slab models were modelled with a 20 Å vacuum layer. Gaussian smearing was employed for the stress/force relaxations. To better describe the interactions between molecules, van der Waal interactions were included with the zero damping DFT-D3 method of Grimme. The transition states during the reaction pathway were evaluated with the climbing-image nudged elastic band method. The convergence criteria for force were below 0.05 eV/Å. Only the gamma point was considered in this calculation. 

### **Data availability** 

The data that support the findings of this study are available from the corresponding author (X.P.) upon request. 

33. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ https://doi.org/10.1038/s41586-021-03406-5 (2021). 

34. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ **598** , 444–450 (2021). 

35. Zhang, Y. et al. Achieving reproducible and high-efficiency (>21%) perovskite solar cells with a presynthesized FAPbI3 powder. _ACS Energy Lett._ **5** , 360–366 (2019). 

36. Chateigner, D. Book review of _Thin Film Analysis by X-ray Scattering_ by M. Birkholz with contributions by P. F. Fewster and C. Genzel. _J. Appl. Crystallogr._ **39** , 925–926 (2006). 

37. Harvey, S. P. et al. Probing perovskite inhomogeneity beyond the surface: TOF-SIMS analysis of halide perovskite photovoltaic devices. _ACS Appl. Mater. Interfaces_ **10** , 28541–28552 (2018). 

38. Rehr, J. J. et al. Theoretical X-ray absorption fine structure standards. _J. Am. Chem. Soc_ . https://doi.org/10.1021/ja00014a001 (1991). 

**Acknowledgements** This work was financially supported by the National Key R&D Program of China (grant no. 2021YFB3800102), the National Natural Science Foundation of China (grant nos. 52272252, U22A20142, 52302324 and 62204108), the Director’s Fund of the Hefei Institutes of Physical Science (grant no. YZJJ-GGZX-2022-01) and the Science Funds of Distinguished Young Scholars of Anhui Province (grant no. 2108085J34). We acknowledge use of the beamlines BL13SSW, BL14B1, BL17B1 and BL10U2 at SSRF, China, for the synchrotron radiation experiments. We thank S. He, Z. Su and L. Cheng from SSRF for support with the synchrotron radiation experiments. N.-G.P. acknowledges financial support through grants from the National Research Foundation of Korea, which is funded by the Korean Ministry of Science and ICT under contract NRF-2021R1A3B1076723 (Research Leader Program). S.D. acknowledges support from the 111 project (B16016) and the Beijing Key Laboratory of Novel Thin-Film Solar Cells. 

**Author contributions** Z.L., J.Y. and X.P. conceived the idea. J.Y. and X.P. supervised the project and process. Z.L. and H.X. fabricated the perovskite devices, conducted the photovoltaic performance characterizations and analysed the experimental data described in this manuscript. Z.L., Y.Z. and H.X. wrote the manuscript. Y.Z. performed the structural characterizations, including those using GIXRD and TEM, with the assistance of J.Z. under the supervision of B.X. and N.-G.P. W.C. assessed performance in LED mode with photoluminescence, time-resolved photoluminescence and IPCE measurements under the supervision of Z.X. T.K. and P.R. analysed the results of the optoelectronic characterizations. B.L. conducted the in situ GIWAXS measurements with help from S.D. J.Z., X.G. and Q.W. assisted in the EXAFS and WAXS measurements. D.-H.K. assisted in the EXAFS measurements and analysis under the supervision of N.-G.P. H.Z. and Z.W. assisted in the synthesis of perovskite materials and PSP molecules. H.H. conducted the density functional theory computations. X.C. helped in the FIB-TEM measurements and analysis of the results. H.Z. conducted the SEM measurements. T.K., B.X., Z.X., S.D., N.-G.P., J.Y. and X.P. revised the manuscript. All authors discussed the results and commented on the manuscript. 

**Competing interests** A patent application related to the subject matter of this manuscript has been submitted (Application Nos. PCT/CN2022/143637 and 2022114089354) by the Hefei Institutes of Physical Science, Chinese Academy of Sciences. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-023-06784-0. **Correspondence and requests for materials** should be addressed to Songyuan Dai, Nam-Gyu Park, Jiajiu Ye or Xu Pan. 

**Peer review information** _Nature_ thanks Zhaoning Song and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at http://www.nature.com/reprints. 

Article 



**Extended Data Fig. 1 | Illustration of peel-off method to expose the bottom of perovskite films.** We prepared sample comprising ITO/PTAA/Perovskite/ Cu stacks for GIXRD measurements. PTAA (30 mg ml<sup>−1</sup> in CB) was deposited as sacrifice layer to further expose bottom interface, and Cu layer was evaporated to ensure the completeness of perovskite films. After fabrication, the samples were immersed in a tank filled with CB for 20 min in a nitrogen glovebox. Along with dissolving of PTAA layer, an entire perovskite film together with Cu would float in CB. A clean quartz substrate was used for flipping and carrying the obtained films. The samples should be immersed in CB again for another 5 min to clear potential PTAA residues. Finally, the samples were dried naturally in nitrogen and for further characterizations of bottom interface. It should be noted that, immersion in CB within 1 h would not affect perovskite structure. To ensure the reliability for these results, the controlled trial was conducted with perovskite films deposited on quartz glass. We tested conventional XRD measurements for the perovskite surface, which demonstrated identical results of 1 h immersed perovskite films. 



**Extended Data Fig. 2 | Analysis of synthesised (PbI2)x(PSP)y complex. a-b** , The potential crystal structure of (PbI2)x(PSP)y; **c** , The experimental XRD patterns of PSP, PbI2 and (PbI2)x(PSP)y and the complex simulations. 

## Article 



**Extended Data Fig. 3 | NMR results.**<sup>13</sup> C Chemical shift information of PSP and PSP(PbI2) complex obtained from NMR measurements. 



**Extended Data Fig. 4 | Band alignment analysis from ultraviolet** without and **(c)** with PSP introduction. The colour from the light to dark indicated **photoelectron spectroscopy (UPS) depth profile. a** , Schematic diagram of spectra recorded after etching 0 nm, 400 nm and 700 nm, respectively. method for depth profile UPS. **b-c** , UPS depth profiles of perovskite films **(b)** 

## Article 



**Extended Data Fig. 5 | Schematic diagram of band alignment extracted from UPS results.** The band structures of different depths have been combined through manually aligning the Fermi energy level, due to there were not actual contact junction of different detection region. **a-b** , Schematics of quasi-type I band alignment caused by FA-Cs phase segregation. In a solar cell with ( **a** ) p-i-n stacks, holes undergo extra energy loss at bottom region when it diffuses within 

the perovskite film, leading to charge carriers (holes) accumulate at this region. Ultimately break the carrier extraction equilibrium. The same situation would arise for the electrons in solar cells with ( **b** ) n-i-p configuration. **c-d** , Resultant flatten band alignment by PSP introduction in a device with ( **c** ) p-i-n configuration and ( **d** ) n-i-p configuration. 



**Extended Data Fig. 6 | Transient absorption (TA) spectra. a-b** , TA spectra of perovskite films of **(a)** the reference and **(b)** PSP film deposited on quartz glass. **c** , Time-resolved fitting curve at 780 nm. We utilized TA measurements to examine carrier dynamics. In the PSP film, an enhancement in absorption variation (ΔA) was observed, corroborating the reduction in Shockley-ReadHall (SRH) recombination due to the passivation of trap states. Time-resolved 

absorption at the ground-state bleach (GSB) of 780 nm revealed a decrease in the fast decay lifetime (τ1) and an increase in the slow decay lifetime (τ2). The five-fold reduction in τ1 suggests effective passivation, while the nearly threefold increase in τ2 implies a seamless carrier diffusion within the perovskite (Supplementary Table 4). This finding aligns with the conclusion obtained from energy band alignment. 

Article 



**Extended Data Fig. 7 | The plots of the first order derivative of EQE curve.** The bandgap was extracted from the first order derivative of EQE curve, which located at around 818 nm. 



**Extended Data Fig. 8 | Additional stability assessments. a** , PCE evolution curves of PSCs under thermal cycling stress. The temperature cycling reliability were tested between the −40 °C~60 °C with duration time of 2 h. The initial PCE of the reference and the PSP device is 25.27% and 24.09%, respectively. **b** , Stability test followed ISOS L-2I protocol that performing MPP tracking under continuous 

1 sun illumination at 65 °C in N2 atmosphere. The solid lines represent for the average efficiency evolution among the eight individual device, and the shadow region represent for the efficiency evolution range during the tests. The average initial PCE of the reference and PSP device is 25.47% and 24.26%, respectively. 

