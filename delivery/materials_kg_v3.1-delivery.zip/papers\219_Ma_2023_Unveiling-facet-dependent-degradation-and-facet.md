# Unveiling facet-dependent degradation and facet engineering for stable perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 352 |
| 作者 | Chun-Qing Ma, F. Eickemeyer, Sun-Ho Lee, Dong-Ho Kang, S. J. Kwon, M. Grätzel, Nam-Gyu Park |
| DOI | 10.1126/science.adf3349 |
| 源文件 | 016_Ma_2023_Unveiling-facet-dependent-degradation-and-facet.pdf |

---
RESEARCH 



within the FAPbI3 perovskite thin film. We have found direct evidence that the (100) facet, which is predominant in perovskite thin films, limits the overall stability of the perovskite and exhibits a fast phase transition to d-phase when exposed to moisture, whereas the (111) facet is much more stable to moisture-driven degradation. Based on the in situ characterization of an individual crystal with well-defined facets, ex situ measurements, and theoretical calculations, we show that a strong water adhesionafterhydroxylationwith anelongated Pb-I bond distance is responsible for the d-phase transition.Moreimportantly,theformed d-phase substantially deteriorates the optoelectronic properties of the (100) facet. Because the (111) facet exhibits a high barrier to the phase transition, a facet engineering strategy in which ligands assist the preferred growth of the (111) facet is provided. The (111)-dominated film shows exceptional stability against thermal stress and moisture without any surface passivation. 

#### SOLAR CELLS 

## Unveiling facet-dependent degradation and facet engineering for stable perovskite solar cells 

Chunqing Ma,<sup>1</sup> † Felix T. Eickemeyer,<sup>2</sup> † Sun-Ho Lee,<sup>1</sup> Dong-Ho Kang,<sup>1</sup> Seok Joon Kwon,<sup>3,4</sup> * Michael Grätzel,<sup>2,4</sup> * Nam-Gyu Park<sup>1,4</sup> * 

A myriad of studies and strategies have already been devoted to improving the stability of perovskite films; however, the role of the different perovskite crystal facets in stability is still unknown. Here, we reveal the underlying mechanisms of facet-dependent degradation of formamidinium lead iodide (FAPbI3) films. We show that the (100) facet is substantially more vulnerable to moisture-induced degradation than the (111) facet. With combined experimental and theoretical studies, the degradation mechanisms are revealed; a strong water adhesion following an elongated lead-iodine (Pb-I) bond distance is observed, which leads to a d-phase transition on the (100) facet. Through engineering, a higher surface fraction of the (111) facet can be achieved, and the (111)-dominated crystalline FAPbI3 films show exceptional stability against moisture. Our findings elucidate unknown facet-dependent degradation mechanisms and kinetics. 

# S 

tability is one of the most pressing issues that hinders the commercialization of perovskite solar cells (PSCs), despite efficiencies greater than 25% (1–3). The S degradation of hybrid perovskite thin films by moisture, thermal stress, and light is a complex process that involves changes in crystal structure, composition, film morphology, and optoelectronic properties (4–9). This is especially true for the most promising composition of formamidinium (FA)–based perovskite FAPbI3, which shows a thermodynamically stable photoactive a-phase only at temperatures greater than 150°C and can rapidly transition to photoinactive d-phase at room temperature (10–13). Although research on degradation has advanced considerably, a fundamental understanding of the role of the different crystal facets in the degradation process is missing (14, 15). 

ferent kinetics and that a thermodynamically unstable facet is prone to degradation and drives overall degradation. Despite the critical importance of the facets to the degradation process, no attempt, to our knowledge, has yet been made to understand the stability and degradation behaviors of perovskite facets. 

#### Specific degradation on the (100) facet 

To prepare perovskite thin films with welldefined (100) and (111) facets, piperidine additive was used (see methods) (22). X-ray diffraction (XRD) data in fig. S1 verify that the sample exhibits a high (100) peak and a low 

Here, we report direct observations of the degradation process of (100) and (111) facets 



It is the perovskite surface with its various facets that is exposed to the environment (moisture, oxygen, etc.), and these facets are likely to degrade first (16, 17). Thus, understanding the overall stability of the perovskite thin film begins with understanding the stability and degradation behavior of the perovskite facets (18). Different crystal facets have different atomic arrangements and coordination, which lead to different atomic potential landscapes and, subsequently, to different electronic, physical, and/or chemical properties (19–21). Therefore, it is expected that the various facets suffer degradation with dif- 













> 1School of Chemical Engineering and Center for Antibonding Regulated Crystals, Sungkyunkwan University, Suwon 16419, Republic of Korea.<sup>2</sup> Laboratory of Photonics and Interfaces, École Polytechnique Fédérale de Lausanne (EPFL), 1015 Lausanne, Switzerland.<sup>3</sup> School of Chemical Engineering, Sungkyunkwan University, Suwon 16419, Republic of Korea. 

> 4SKKU Institute of Energy Science and Technology (SIEST), Sungkyunkwan University, Suwon 16419, Republic of Korea. *Corresponding author. Email: sjoonkwon@skku.edu (S.J.K.); michael.graetzel@epfl.ch (M.G.); npark@skku.edu (N.-G.P.) †These authors contributed equally to this work. 

Fig. 1. Facet identification and facet-dependent degradation of FAPbI3 perovskite thin films. (A) SEM image of the perovskite thin film showing the well-defined (100) and (111) facets. The samples were prepared on the SnO2-coated FTO substrates. (B) Schematic model of the (100) and (111) facets on a perovskite cubic crystal (left) and atomic arrangements on the (100) and (111) facets (right). (C to E) AFM images of the as-prepared sample (C), the sample exposed to 30 to 40% RH for 72 hours (D), and the sample exposed to 30 to 40% RH for 200 hours (E). The (100) and (111) facets are marked on the images within a region of 3 mm by 3 mm. The yellow rectangles in (D) indicate the degraded parts on the (100) facet with protuberances. 

1 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 

RESEARCH | RESEARCH ARTICLE 



<!-- Start of picture text -->
A nm C 400 30 E 101<br>AFM (100) 100 As-prepared (100)<br>(100) 300 20<br>10-1<br>200 10 10-2<br>100 δ phase 10-3 V TFL=0.067 V<br>0<br>(111) -4<br>10<br>0<br>-10 10-5<br>0 50 100 150 200 0.01 0.1 1<br>Length (nm) Voltage (V)<br>B D<br>pA 400 30 F 0<br>pc-AFM (111) 10 Degraded (100)<br>(100) 300 20 10-1<br>200 10-2<br>10<br>10-3<br>100<br>(111) 0 10-4 V TFL=0.23 V<br>0<br>-10 10-5<br>0 50 100 150 200 0.01 0.1 1<br>Length (nm) Voltage (V)<br>G H I<br>As-prepared Degraded Degraded<br>(111)<br>(111) (111) (111)<br>(100) (100)<br>(111)<br>C)( tApnerru Height (nm) C)( tAnnerru<br>)( tApnerru )( tAnnerru<br>C Height (nm) C<br><!-- End of picture text -->

Fig. 2. Optoelectronic properties on the degraded (100) and (111) facets. (A and B) AFM (A) and pc-AFM (B) images of the degraded (aged 72 hours) (100) and (111) facets within a region of 1 mm by 1 mm. (C and D) Current and height profiles extracted from the degraded (100) and (111) facets, respectively. The line scans are marked in (A) and (B). The dashed circles mark the current and the height levels. 

(E and F) Current-voltage curves measured from undegraded (E) and degraded (F) (100) facets using the AFM tip as an electrode. (G) Confocal PL mapping of the as-prepared sample. The inset legend indicates PL intensity. (H and I) Confocal PL (H) and transmission mapping (I) of the degraded sample. The triangular (111) and lateral (100) facets are marked on the images. In (G) to (I), scale bars are 1 mm. 

(111) peak located at 14.0° and 24.4°, respectively (23). Scanning electron microscopy (SEM) imaging confirms the well-defined polyhedral shapes (Fig. 1A). Most of the grains have a triangular facet in the center, corresponding to the (111) facet (22), and the (100) facets are in the lateral directions of the crystal surface (24). This observation suggests that the perovskite crystal is enclosed by (100) facets, with (111) facets at the truncated corners. A schematic model of the (100) and (111) facets on a perovskite cubic crystal and atomic arrangements are shown in Fig. 1B. The metal cations (Pb) or organic cations (FA) are connected to I anions on the (100) facet with Pb-I or FA-I layer terminations. The (111) facet is terminated by 3/8 FA cation and 3/2 I anion, and the unsaturated bond of the I anions can be balanced by either FA or Pb cations at the corresponding crystallographic sites. With the well-defined facets on the individual crystal, the degradation process of the (100) and (111) 

facets was studied. Atomic force microscopy (AFM) was used to examine changes in surface morphology and electronic properties during the course of facet degradation (25). The AFM image of the as-prepared (undegraded) sample in Fig. 1C shows smooth (100) and (111) facets, as confirmed by the SEM image. The sample was then exposed to ambient air with a relative humidity (RH) of 30 to 40% for 72 hours, and the AFM image of the degraded sample is shown in Fig. 1D. Interestingly, the triangular (111) facet shows a different degradation behavior compared with that of the lateral (100) facet. In particular, the (100) facets appear to degrade and reveal newly formed crystals that could be identified as small protuberances (marked by yellow rectangles), whereas the (111) facets are nearly intact against degradation. Further exposure to ambient air for 200 hours breaks the (100) facets into small pieces of crystals, whereas little degradation is observed for the (111) facets (Fig. 1E). The SEM 

image of the degraded sample (aged 72 hours) in fig. S2 also indicates that small crystals are formed on the (100) facet after exposure to air for 72 hours, and XRD data demonstrate that the newly formed crystals are d-phase (fig. S3) (26). It was also observed that the (100) peak intensity is reduced after degradation, whereas the (111) peak in the film that was aged 72 hours exhibits a similar peak intensity to the as-prepared sample. To exclude the possibility that the selective (100) facet degradation could be caused by unevenly distributed methylammonium (MA) or bromine (Br) composition (27, 28), FAPbI3 thin films without MA and Br were prepared. As shown in AFM images of the perovskite thin films with and without MAPbBr3 additives (3 mol %; fig. S4), the crystal facet formation and distribution are not influenced by the small amount of MAPbBr3 additives. The stability of these two facets was examined in various atmospheres at room temperature for 72 hours, including 

2 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 

RESEARCH | RESEARCH ARTICLE 



Fig. 3. Mechanisms for facet-dependent degradation. (A) O 1s XPS spectra of the as-prepared (bottom) and degraded (top) samples. Open circles and lines represent the measured data and the fitted results, respectively. a.u., arbitrary units. (B) Fourier-transformed radial distribution function of Pb K-edge EXAFS spectra for the as-prepared (black) and degraded (red) samples. (C) D-W factor and Pb-I bond distance of the as-prepared and degraded samples from the fit result of the EXAFS 

spectra. (D) Time-dependent morphological evolution of a unit cell (cube) of the single cubic crystalline a-FAPbI3 [blue, (100) facets; red, (111) facets]. t, time; t, the characteristic time scale for the degradation kinetic constant for (111) facet. (E) Time dependence of the areal fraction of two different facets in the unit cell. t/t, the ratio of t to t. (F) Time-dependent Gibbs free energy DG for the a-FAPbI3 of the unit cell exposed to H2O together with time-dependent DG in vacuum for comparison. 

it is assumed that the combined effects from moisture, O2, and light can aggravate the degradation of the (100) facet, which needs further study. 

pure N2, N2 and O2 mixed gas, low-humidity air (30 to 40% RH), and high-humidity air (60 to 70% RH). An AFM image of the sample (fig. S5C) after exposure to the low-humidity air reveals the phase transition to d-phase on the (100) facet. The transition process to d-phase is observed to be accelerated under high-humidity air (60 to 70% RH; fig. S5D). No d-phases are detected in the samples that were exposed to pure N2 and the N2 and O2 mixed gas, as shown in fig. S5, A and B. These results suggest that the (100) facets are intrinsically unstable and can easily suffer phase transition to d-phase when exposed to moisture. It was reported that light and O2 can also influence the stability of the perovskite thin film by inducing carrier accumulation and triggering ion diffusion, which suggests different degradation processes (5, 29). Based on the fast degradation of the (100) facet when exposed to moisture, 

the d-phase that is consistent with the noticeable d-phase peak in XRD in fig. S3. To demonstrate the heterogeneity on the (100) facet, height and photocurrent values were extracted by line scan (marked by solid lines in Fig. 2, A and B). As shown in the height profile (Fig. 2C), the d-phase region on the (100) facet with a negligible photocurrent value is about 15 nm higher than the undegraded part, which shows a notable photocurrent value. The current profile exhibits a substantial reduction of the current from 300 to 0 pA on the d-phase region, which is ascribed to the photoinactive character of the d-phase. Conversely, photocurrent is continually generated on the (111) facet without changes in height (Fig. 2D), which indicates that the (111) facet is not affected by the degradationprocess. Toidentifyany changes in the electronic property before and after degradation of the (100) facet, position-specific 

#### Optoelectronic properties of the degraded facets 

It is essential to examine how the optoelectronic properties are affected by the phase transited d-phase on the (100) facet. We used photocurrent-AFM (pc-AFM) to study the optoelectronic properties of the (100) and (111) facets. Magnified AFM and pc-AFM images of the 72-hour-degraded sample in Fig. 2, A and B, show individual crystals with exposed (100) and (111) facets. A smooth surface and a uniform photocurrent are observed for the (111) facet, whereas the (100) facet exhibits high fluctuations in the current, where lowcurrent regions (dark regions) correspond to 

3 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 

RESEARCH | RESEARCH ARTICLE 



Fig. 4. (111) facet–dominated FAPbI3 perovskite thin film has better stability. (A and B) XRD pattern (A) and SEM image (B) of the FAPbI3 thin film prepared using CHA additive. A large triangular morphology of the (111) facet is distinct. (C) The areal ratio of the (111) facet calculated from five crystals of the control and (111)-dominated perovskite thin films. (D and E) XRD patterns (D) and PL spectra (E) of the control (bottom) and (111)-dominated (top) samples before (black dashed line) and after exposure to humidity for 1000 hours (red and green solid lines for the control and (111)-dominated samples, respectively). (F) Stability test of the unencapsulated devices for the (111)-dominated perovskite and the control sample stored under 30 to 40% RH in air atmosphere for 1938 hours. 



uted to the different surface compositions or stoichiometries. To elucidate in detail the facet-dependent degradation induced by moisture, x-ray photoelectron spectroscopy (XPS) measurements were conducted. All peaks were calibrated using the C 1s peak at 284.6 eV (fig. S8A). As shown in Fig. 3A, the O 1s spectrum of the as-prepared sample is deconvoluted into two peaks at binding energies of 532.7 and 531.5 eV, which correspond to molecularly adsorbed H2O (H2Oad) and –OH species attached to the perovskite surface via chemisorption, respectively (36). After degradation, the O 1s XPS spectrum shows a substantial increase in the peak intensity of both the H2Oad and –OH species. As shown in fig. S8B, the O/Pb ratio of the degraded sample is 0.8 and is much higher than that of the as-prepared sample (a ratio of 0.3). Concurrently, we observed peak shifts of ~0.8 and 0.4 eV to lower binding energies for the H2Oad and −OH species, respectively. The increased O/Pb ratio, together with the peak shift for the degraded sample, is indicative of a large amount of water absorption and enhanced interaction between the water molecules and the perovskite surface (37). In addition, a small peak observed at a binding 

This suggests that the bright (100) facet has less nonradiative loss and, therefore, low trap state density, which is consistent with previous reports (21). Thus, we can exclude the possibility that the degradation of the (100) facet could be mainly attributed to surface defects. Figure 2H shows a confocal PL image and an overlaid transmission image (Fig. 2I) of a degraded perovskite film. A dark region on the (100) facet appears on the confocal PL image, which corresponds to the bright region in the transmission image. This implies that the dark regions that appear are photoinactive d-phase associated with quenching centers, which is consistent with the pc-AFM results. 

dark current-voltage curves were measured by using an AFM tip as a nanoelectrode (30, 31). The current-voltage curves of the undegraded (100) parts and degraded (100) part are shown in Fig. 2, E and F, respectively. The trap state density of the undegraded and degraded (100) parts can be calculated from the trap-filled limit voltage VTFL (see details in methods). The trap state density of the degraded (100) part is estimated to be 2.25 × 10<sup>15</sup> cm<sup>−3</sup> , which is about three times greater than that of the undegraded (100) part (0.65 × 10<sup>15</sup> cm<sup>−3</sup> ) (32, 33). The deteriorated electronic property of the (100) facet after degradation is highly related to the formed d-phase, which can act as trap states (15). 

Mechanisms for facet-dependent degradation 

Next, we used confocal microscopy to differentiate the optoelectronic properties of the facets and to study the variations caused by the formed d-phase on the (100) facet (34, 35). Figure 2G shows a confocal photoluminescence (PL) image of the as-prepared perovskite film. PL heterogeneity on the individual crystal is observed with a dim triangular region and a bright lateral region, corresponding to the (111) and (100) facets, respectively. This is also confirmed by wide-field PL mapping in fig. S6. 

The surface compositions of the (100) and (111) facets were analyzed by energy dispersive x-ray (EDX) spectroscopy to investigate the degradation process of the different facets. As shown in fig. S7, the N/Pb and I/Pb ratios from the (100) and (111) facets show similar values, which indicates that the compositional difference between these two facets is negligible. Thus, we exclude the possibility that the specific (100) degradation can be attrib- 

4 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 

RESEARCH | RESEARCH ARTICLE 



than the (111) facet, which facilitates moistureinduced degradation of the (100) facet as compared with the (111) facet. Using the calculated interface energy of the different facets exposed to H2O, we then made a simple mathematical model to describe the morphological evolution of single cubic crystalline a-FAPbI3 driven by degradation dynamics. We used a simple cube model as the unit cell in which six (100) facets correspond to six faces of the cube with a unit length l at the initial state. Assuming a constant volume of the unit cell per the Wulff construction principle, the time dependences of areas of the facets were calculated (see details in methods) (44). As shown in Fig. 3D, the unit cell is continuously evolving into a truncated cube where the areal fraction of the (111) facet (red face) is continuously increasing, whereas that of the (100) facet (blue face) is decreasing. As is apparent from Fig. 3E, the relative fraction of the (111) facet increases with time, whereas the (100) facet decreases because of the instability caused by moisture attack. The morphological evolution also provides evidence that the (111) facet is the facet that is thermodynamically more stable when the a-FAPbI3 of the unit cell is exposed to H2O. The total Gibbs free energy DG of the surfaces exposed to H2O was also calculated. As shown in Fig. 3F, DG monotonically decreases with increasing time during the course of the H2O-driven degradation of the unit cell. These results support that the (111) facet is more stable than the (100) facet when under moisture attack, in terms of thermodynamics and degradation kinetics. 

energy of 529.5 eV for the degraded sample (Fig. 3A) is assigned to –O– species, which is probably due to the further interaction between the perovskite surface and the oxygen in the –OH species (38). As shown in fig. S8C, the N 1s XPS spectrum of the degraded sample shows an appearance of the –NH2 shoulder owing to the deprotonation process, and the Pb 4f XPS spectrum of the degraded sample shows a small shift toward low binding energy (fig. S8D) (39–41). This can be explained by the bonding between the lead iodide framework and the organic cations in the perovskite crystal having been weakened upon moisture attack. To further confirm the degradation products, the samples stored under humid N2 gas (N2 and H2O mixed gas, 30 to 40% RH) and dry O2 gas (N2 and O2 mixed gas) for 72 hours were measured by XRD, and the sample stored under humid N2 gas for 200 hours was also measured. As shown in fig. S9, d-phase appears on the sample that was degraded under humid N2 gas for 72 hours, which is enhanced for the longer exposure time of 200 hours. No d-phase is detected on the sample stored under dry O2 gas. These results confirm that the degradation product of the FAPbI3 thin film under moisture is d-phase. 

tals, the exposed-area percentages of the (111) facets from five crystals are roughly calculated to be 85 to 98%and 40 to 55% forthe (111)dominated and control samples, respectively (Fig. 4C). Thus, we conclude that the perovskite with CHA additive exhibits an enlarged (111) facet with a reduced (100) facet where moisture-induced phase transition can occur. This enlarged (111) facet might be due to the preferred absorption of the CHA additive, which can reduce the surface energy of the (111) facet. 





We examined the stability of the (100)- and (111)-dominated films by exposure to the 30 to 40% RH air atmosphere. After about 1000 hours, the bulk XRD pattern (Fig. 4D, top) of the degraded (111)-dominated film (green line) exhibits a negligible reduction of (100) and (111) peaks compared with the as-prepared film (black dashed line), consistent with the PL spectra that has only a slight peak shift (Fig. 4E, top). The slight PL peak shift might be due to the MA and FA phase segregation (45). However, the degraded control film that has relatively fewer (111) facets shows a substantial reduction in the (100) peak intensity to ~30% of that of the as-prepared film, with an enhanced d-phase peak after exposure. The degradation of the control film also leads to a substantially reduced PL intensity, as shown in Fig. 4E, which is ascribed to the formed d-phases on the (100) facet acting as nonradiative recombination centers. 

Extended x-ray absorption fine structure (EXAFS) was studied for the as-prepared and degraded samples to further understand local structural changes induced by the moisture (Fig. 3B and fig. S10) (42). Based on the Fouriertransformed spectra in Fig. 3B for the asprepared and degraded samples, the Pb-I bond distance and Debye-Waller (D-W) factor were extracted (see methods for the more detailed fitting process). As shown in Fig. 3C, the degraded sample shows a higher D-W factor of 0.0204 than the as-prepared sample (0.0173), indicating a high structural distortion of the corner-sharing PbI62− octahedra. A relatively longer Pb-I bond distance (3.150 Å) is also observed for the degraded sample, which implies that the Pb-I bond is weakened by interaction with water molecules (43). Based on the XPS and EXAFS data, we conclude that the water molecules are adsorbed on the perovskite surface by forming –OH species, which results in structural distortion with a weak Pb-I bond. These processes with distorted and weakened bonding can facilitate the d-phase transition at room temperature. 

To investigate the photovoltaic performance of PSCs, devices with the configuration of FTO/SnO2 (~20nm)/perovskite/spiro-MeOTAD (~300 nm)/Au (~80 nm) were prepared (FTO, fluorine-doped tin oxide; spiro-MeOTAD, 2,2′,7,7′tetrakis[N,N-di(4-methoxyphenyl)amino]-9,9′spirobifluorene). Figure S12 shows statistical data for the photovoltaic parameters based on 10 devices. For the best-performing devices measured with a mask area of 0.125 cm<sup>2</sup> , the control sample exhibits a power conversion efficiency (PCE) of 24.0% with a short-circuit current Jsc of 25.6 mA/cm<sup>2</sup> , an open-circuit voltage Voc of 1.12 V, and a fill factor FF of 0.84. The PCE for the (111)-dominated perovskite is 23.8% with a Jsc of 25.3 mA/cm<sup>2</sup> , a Voc of 1.15 V, and a FF of 0.82. The slightly lower Jsc for the (111)-dominated perovskite is due to a photocurrent generation capability that is a little lower than that of the (100) facet (22). It is anticipated that the performance of the (111)-dominated perovskite device can be further improved with surface passivation and optimization methods. In Fig. 4F, the humidity stability test of the devices without encapsulation reveals that the device with the (111)-dominated sample maintains 95% of initial PCE after ~2000 hours, which is notably better than the control device (87%). The average PCE degradation and standard errors (error bars) calculated from five devices are 

#### Facet engineering of the (111)-dominated thin film to protect against degradation 

Based on the degradation nature and dynamics of different facets, we provide a strategy to control the fraction of the (111) facet to reinforce the film against moisture. Exploring this possibility eventually achieves the (111)-dominated perovskite film through “facet engineering.” Cyclohexylamine (CHA) with a boiling point of 134°C is used as an additive to selectively induce (111) preferred growth. The XRD pattern of the perovskite with CHA additive in Fig. 4A confirms that the (111) phase dominates, with a relatively lower intensity (100) peak. The SEM image in Fig. 4B shows that the perovskite with CHA additive has a large triangular (111) facet with less lateral (100) facets on the individual crystal, whereas the control sample (shown in Fig. 1A) has a relatively smaller triangular (111) facet on the crystal surface with more lateral (100) structures. 

A theoretical calculation was carried out to understand the degradation kinetics of cubic crystalline a-FAPbI3 exposed to H2O. First, we calculated the interaction energy of water molecules with (100) and (111) facets (see methods for details). From the calculation, we found that the adhesion (or wetting energy) of H2O is 93.08 and 85.12 mN/m for the (100) and (111) facets, respectively. Thus, the (100) facet is energetically more favorable for H2O adhesion 

The large triangular (111) facet shown in the SEM image is consistent with the dominant (111) phase of the XRD pattern. Larger-area SEM images of the control and (111)-dominated films are shown in fig. S11. Based on the exposed (111) and (100) facet area on the crys- 

5 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 

RESEARCH | RESEARCH ARTICLE 



shown in fig. S13. Stability tests of the devices with encapsulation under 85% RH and 85°C were also conducted. As shown in fig. S14, the (111)-dominated sample maintains 85% of the initial PCE after 800 hours, whereas the PCE of the control device decreases to 75% of the initial value. The enhanced stability under high humidity and high temperature is highly related to the enlarged (111) facet on the perovskite surface. 





   36. S. Yamamoto et al., J. Phys. Condens. Matter 20, 184025 (2008). 

3. M. Kim et al., Science 375, 302–306 (2022). 

4. X. Zheng et al., ACS Energy Lett. 1, 1014–1020 (2016). 

5. W. Nie et al., Nat. Commun. 7, 11574 (2016). 

   37. F. Orlando et al., Top. Catal. 59, 591–604 (2016). 

   38. S. Yamanaka et al., J. Appl. Phys. 123, 165501 (2018). 

6. A. M. A. Leguy et al., Chem. Mater. 27, 3397–3407 (2015). 

   39. Q. Zhou et al., Adv. Energy Mater. 9, 1802595 (2019). 

7. H. Lu et al., Science 370, eabb8985 (2020). 

   40. J. Zhao et al., Sci. Rep. 6, 21976 (2016). 

8. S. Tan et al., Joule 4, 2426–2442 (2020). 

   41. Y.-H. Kye, C.-J. Yu, U.-G. Jong, Y. Chen, A. Walsh, J. Phys. Chem. Lett. 9, 2196–2201 (2018). 

9. D. P. McMeekin et al., Science 351, 151–155 (2016). 

10. T. A. S. Doherty et al., Science 374, 1598–1605 (2021). 

   42. D.-H. Kang, Y.-J. Park, Y.-S. Jeon, N.-G. Park, J. Energy Chem. 67, 549–554 (2022). 

11. T. Chen et al., Sci. Adv. 2, e1601650 (2016). 

12. J.-W. Lee, S. Tan, S. I. Seok, Y. Yang, N.-G. Park, Science 375, eabj1186 (2022). 

   43. C. Ma et al., ACS Appl. Mater. Interfaces 9, 14960–14966 (2017). 

13. G. E. Eperon et al., Energy Environ. Sci. 7, 982–988 (2014). 

   44. M. Laue, Z. Kristallogr. Cryst. Mater. 105, 124–133 (1943). 

   45. S. Chen et al., Adv. Energy Mater. 8, 1701543 (2018). 

14. X. Li et al., Science 375, 434–437 (2022). 

#### Discussion 

15. S. Macpherson et al., Nature 607, 294–300 (2022). 

16. J. Chun-Ren Ke et al., Chem. Commun. 53, 5231–5234 (2017). 

##### ACKNOWLEDGMENTS 

Moisture-induced degradation was found to depend on the crystal facet of the FAPbI3 film. The (100) facet is specifically unstable under moisture, whereas the (111) facet is notably stable. Experimental and theoretical studies revealed that the a- to d-phase transition is accelerated selectively on the (100) facet by moisture, whereas phase transition is considerably retarded on the (111) facet because of its thermodynamic stability against surface interaction with water molecules. A facet-engineered perovskite film with moisture-stable (111) facets was realized by controlling preferred growth using an organic ligand. Moisture and heat stability were substantially improved in the (111) facet–dominated perovskite thin film. Our findings describe distinct facet-dependent degradation, which provides an important insight into the design of stable PSCs using facet engineering. 

Funding: This work was supported by National Research Foundation of Korea (NRF) grants funded by the Korean government (MSIT) under contract NRF-2021R1A3B1076723 (Research Leader Program) (C.M., S.-H.L., and N.-G.P.). M.G. acknowledges financial research support from the Günes corporation. This work was partially supported by the Samsung Research Funding Center for Samsung Electronics under project number SRFC-MA2201-02 (S.J.K.). Author contributions: Conceptualization: N.-G.P., M.G., C.M.; Methodology: C.M., F.T.E., S.J.K., M.G., N.-G.P.; Investigation: C.M., F.T.E., S.-H.L., D.-H.K.; Funding acquisition: N.-G.P.; Supervision: N.-G.P., S.J.K., M.G.; Writing – original draft: C.M., N.-G.P.; Writing – review and editing: F.T.E., S.-H.L., D.-H.K., S.J.K., M.G., N.-G.P. Competing interests: The authors declare that they have no competing interests. Data and materials availability: All data are available in the manuscript or the supplementary materials. License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/science- 

17. A. Jamshaid et al., Energy Environ. Sci. 14, 4541–4554 (2021). 

18. C. Ma, M. Grätzel, N.-G. Park, ACS Energy Lett. 7, 3120–3128 (2022). 

19. D. Luo, X. Li, A. Dumont, H. Yu, Z. H. Lu, Adv. Mater. 33, e2006004 (2021). 

20. S. Y. Leblebici et al., Nat. Energy 1, 16093 (2016). 

21. S. Dong et al., Adv. Mater. 34, e2204342 (2022). 

22. C. Ma et al., Joule 6, 2626–2643 (2022). 

23. X. Zheng et al., Nat. Energy 5, 131–140 (2020). 

24. S. Sun, L. He, M. Yang, J. Cui, S. Liang, Adv. Funct. Mater. 32, 2106982 (2022). 

25. J. M. Howard, R. Lahoti, M. S. Leite, Adv. Energy Mater. 10, 1903161 (2019). 

26. S. Jiang et al., J. Am. Chem. Soc. 140, 13952–13957 (2018). 

27. N. J. Jeon et al., Nature 517, 476–480 (2015). 

28. J. W. Lee et al., Adv. Energy Mater. 5, 1501310 (2015). 

29. N. Aristidou et al., Nat. Commun. 8, 15218 (2017). 

30. R. Yang et al., J. Am. Chem. Soc. 128, 16532–16539 (2006). 

licenses-journal-article-reuse 

31. O. G. Reid, K. Munechika, D. S. Ginger, Nano Lett. 8, 1602–1609 (2008). 

##### SUPPLEMENTARY MATERIALS 

32. D. W. deQuilettes et al., Science 348, 683–686 (2015). 

science.org/doi/10.1126/science.adf3349 Materials and Methods Figs. S1 to S14 Submitted 14 October 2022; accepted 11 December 2022 10.1126/science.adf3349 

33. J.-W. Lee et al., Chem 3, 290–302 (2017). 

34. S. Sánchez et al., Energy Environ. Sci. 15, 3862–3876 (2022). 

##### REFERENCES AND NOTES 

1. H. Min et al., Nature 598, 444–450 (2021). 

   35. D. W. deQuilettes et al., ACS Nano 11, 11488–11496 (2017). 

2. Y. Rong et al., Science 361, eaat8235 (2018). 

6 of 6 

Ma et al., Science 379, 173–178 (2023) 13 January 2023 



### **Unveiling facet-dependent degradation and facet engineering for stable perovskite solar cells** 

Chunqing Ma, Felix T. Eickemeyer, Sun-Ho Lee, Dong-Ho Kang, Seok Joon Kwon, Michael Grätzel, and Nam-Gyu Park 

_Science_ **379** (6628), .  DOI: 10.1126/science.adf3349 

#### **Facet-stabilized films** 

The degradation of formamidinium–based lead iodide perovskite has been shown to depend on which crystal facets are exposed to the surface. C. Ma _et al_ . found that water adhesion was stronger on the (100) facet than on the (111) facet and made these materials more prone to moisture-induced degradation. The authors show how ligand-assisted perovskite film growth could be used create (111)-dominated films with high stability against moisture (up to 85% relative humidity) and thermal stress (85°C) without additional surface passivation. —PDS 

**View the article online** https://www.science.org/doi/10.1126/science.adf3349 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2023 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

