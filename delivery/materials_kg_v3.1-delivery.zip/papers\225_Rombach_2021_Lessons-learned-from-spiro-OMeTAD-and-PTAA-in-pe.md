# Lessons learned from spiro-OMeTAD and PTAA in perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Energy & Environmental Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 305 |
| 作者 | F. Rombach, S. Haque, Thomas J. Macdonald |
| DOI | 10.1039/d1ee02095a |
| 源文件 | 025_Rombach_2021_Lessons-learned-from-spiro-OMeTAD-and-PTAA-in-pe.pdf |

---
Energy & Environmental Science 



# <mark>R</mark> EVIEW 

Published on 25 August 2021 <u>Licensed under CC-BY 3.0</u> 



Cite this: _Energy Environ. Sci._ , 2021, 14, 5161 

# Lessons learned from spiro-OMeTAD and PTAA in perovskite solar cells 

Florine M. Rombach, Saif A. Haque * and Thomas J. Macdonald * 

Received 7th July 2021, Accepted 3rd August 2021 DOI: 10.1039/d1ee02095a rsc.li/ees 

Organic semiconductors have become essential parts of thin-film electronic devices, particularly as hole transport layers (HTLs) in perovskite solar cells (PSCs) where they represent one of the major bottlenecks to further enhancements in both device stability and efficiency. Small molecule 2,2<sup>0</sup> ,7,7<sup>0</sup> - tetrakis[N,N-di(4-methoxyphenyl)amino]-9,9<sup>0</sup> -spirobifluorene (spiro-OMeTAD) and polymer poly[bis(4phenyl)(2,4,6-trimethylphenyl)amine] (PTAA) are two of the first successful HTLs used in PSCs, and have remained at the forefront of developing high efficiency devices for almost a decade. Since their first application, many investigations into the properties of spiro-OMeTAD and PTAA have contributed to a growing understanding of the mechanisms that enable their success as HTLs. This review summarizes and discusses the key electronic and morphological properties, doping strategies and mechanisms, and degradation pathways of both spiro-OMeTAD and PTAA. A critical comparison between the two materials is provided, highlighting both the similarities which explain their enduring popularity as well as key differences in electrical and morphological properties. From this analysis emerges an improved understanding of the fundamental properties that enable the persistent success of HTL materials, which are found to include not only hole conductivity, band gap, and morphology, but also interactions with dopants, the perovskite, and environmental stressors. The knowledge about these properties, which are critically summarized in this review, is also applicable to the many other types of organic electronic devices now employing spiroOMeTAD and PTAA. A detailed examination of the properties of materials reveals a clear set of guiding principles for the development of future generation HTLs. Applying these design strategies to produce more advanced HTLs will be essential to further improve the stability, efficiency, and commercialization of PSCs. 

### Broader context 

Organic–inorganic lead halide perovskite solar cells (PSCs) are a class of third-generation photovoltaics that have attracted worldwide attention due to their facile solution processability, high efficiency, and low manufacturing costs. Hole transport layers (HTLs) in PSCs are critical to device functionality and represent a major bottleneck to further enhancing device stability and efficiency. Specifically, small molecule 2,2<sup>0</sup> ,7,7<sup>0</sup> -tetrakis[N,N-di(4-methoxyphenyl)amino]9,9<sup>0</sup> -spirobifluorene (spiro-OMeTAD) and polymer poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA) are two of the first successful HTLs used in PSCs and have remained as the most popular for developing high efficiency devices for over a decade. Investigations into the properties of spiro-OMeTAD and PTAA have contributed to a growing understanding of the mechanisms driving their success as HTLs and as a result, efficiencies of PSCs now routinely surpass 20%. While both HTLs typically use similar inorganic dopants to improve their functionality, several dissimilarities arising from differing physical and electronic properties affect their functionality and longevity in a PSC. Therefore, a detailed overview critically comparing the electronic properties, morphology, dopant and perovskite interactions, and stability of spiro-OMeTAD and PTAA is urgently needed. This will guide the future development of new and improved HTLs and is applicable for optoelectronic applications beyond PSCs. 

## 1. Introduction 

In current times of rapid population and economic growth, global energy demand is expected to double by 2050.<sup>1</sup> At the same time, the escalating impacts of global warming on both 

Department of Chemistry, Molecular Sciences Research Hub, Imperial College London, London W12 0BZ, UK. E-mail: s.a.haque@imperial.ac.uk, t.macdonald@imperial.ac.uk 

humanity and the world’s ecosystem call for an urgent reduction in emissions.<sup>2</sup> The amount of sunlight that reaches the earth every hour contains more energy than humanity consumes within one year.<sup>3</sup> This makes sunlight our most valuable renewable resource for energy production, which has prompted a worldwide research effort into photovoltaic (PV) energy conversion technologies. Over several decades, crystalline silicon (c-Si) solar cells have dominated the PV market, and although the price of producing electricity from c-Si declined by 76% between 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5161 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

2010–2018, the world is still producing over 70% of electricity by burning fossil fuels.<sup>3</sup> Further improvements in the efficiency of solar modules, which will reduce balance of system costs, are necessary to make the switch to solar power economically attractive. Whilst c-Si PV remains the cheapest way to produce solar electricity, they are approaching their theoretical maximum efficiency with only very minor improvements in the past few years,<sup>4</sup> and their fabrication is based on non-trivial, hightemperature processes.<sup>5</sup> 

In the last decade, perovskite solar cells (PSCs) have emerged as a new type of solar cell, whose fabrication is low-cost, solution processed, compatible with flexible materials and has the potential to achieve higher efficiencies than c-Si solar cells due to its more ideal band gap.<sup>6</sup> Additionally, the band gaps of perovskite materials are highly tuneable,<sup>7</sup> making them ideal candidates for multi-junction solar cells which promise significantly higher efficiencies.<sup>8</sup> The absorber layer of PSCs typically consists of an ABX3 crystal structure where A is an organic/inorganic cation such as methylammonium (MA), formamidinium (FA), or cesium 



Florine M. Rombach is a PhD candidate at the University of Oxford, working in the Photovoltaic and Optoelectronic Device group under Prof. Henry Snaith. She previously completed her MRes in Nanomaterials at Imperial College in London, and her BSc (majoring in Chemistry and Mathematics) at University College Utrecht in the Netherlands. She is interested in finding more efficient ways to create renewable energy, particularly through the investiga- 

Florine M. Rombach 

tion of the properties and stability of novel materials for photovoltaics. 

Saif A. Haque is a Professor of Chemistry at Imperial College London. He is a physical chemist with a particular interest in nanomaterials, molecular electronic materials, photochemistry and solar energy conversion. His research is currently addressing the functional characterization and development of solar cells (photovoltaics) based upon solution processable hybrid inorganic–organic semiconducting Saif A. Haque materials, inorganic metal chalcogenides and perovskites. Prior to becoming a professor, he was a Royal Society University Research Fellow at Imperial between 2005–2013. 

(Cs), B is a divalent cation such as lead (Pb) and/or tin (Sn), and X is typically one or more halide(s). The first PSC was constructed in 2009 by Kojima et al.,<sup>9</sup> who replaced the dye in a typical dye-sensitized solar cell (DSSC) architecture<sup>10</sup> with the perovskite absorber methylammonium lead iodide. Moving from a liquid electrolyte to a solid-state hole conductor later raised efficiencies from 3.8% to 9.7%, simultaneously resulting in greatly improved solar cell stability.<sup>5,11</sup> The demonstration that perovskite had a high absorption coefficient,<sup>12,13</sup> could independently conduct both electrons<sup>14</sup> and holes,<sup>15</sup> showed exceptionally long electron and hole diffusion lengths<sup>16,17</sup> as well as spontaneous exciton dissociation,<sup>18</sup> set the pace for the next decade of PSC research. This enabled the further exploration of both mesoporous<sup>19</sup> and planar<sup>20,21</sup> device architectures in both conventional n–i–p (Fig. 1a) and inverted p–i–n forms, as well as novel processing techniques enabling higher quality perovskite films.<sup>22–24</sup> In all architectures, charge carriers are selectively directed to their respective electrodes by charge transport layers (CTLs), where electrons move through an electron transport layer (ETL) and holes through a hole transport layer (HTL). 

Over the last decade, significant progress has been made in understanding and improving both the efficiency<sup>25–31</sup> and stability<sup>32–37</sup> of PSCs by tuning the properties of the perovskite absorber and/or CTLs. Over time, PSCs have become increasingly limited in both efficiency and stability by their CTLs.<sup>38</sup> A renewed focus on understanding and optimizing their functionality is hence essential to pushing the efficiency of PSCs from the current record of 25.6%<sup>39</sup> to the B31% thermodynamic efficiency limit,<sup>6</sup> whilst also developing sufficient stability for commercialization. 

The highest efficiencies in n–i–p PSCs are most often achieved using p-doped spiro-OMeTAD<sup>40,41</sup> (2,2<sup>0</sup> ,7,7<sup>0</sup> -tetrakis(N,N-p-dimethoxyphenylamino)-9,9<sup>0</sup> -spirobifluorene, Fig. 1b), which possesses a long-standing reputation as an effective solid-state HTL.<sup>42</sup> However, the more recently introduced<sup>43</sup> p-doped PTAA (poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine], Fig. 1c) has also become popular and been used to achieve record efficiencies.<sup>44</sup> 



Thomas J. Macdonald is an 1851 Research Fellow in the Department of Chemistry at Imperial College London. He was previously a Visiting Fellow at University College London, University of Queensland, and Flinders University. Before this, he was a Ramsay Memorial Fellow at University College London working on nanomaterials for solar energy conversion. He obtained his PhD at the University of South Australia in 2016 working in the research 

Thomas J. Macdonald 

group of Prof. Thomas Nann. He has a strong interest in renewable energy and extensive experience in the synthesis of functional nanomaterials and the fabrication of third-generation photovoltaics. 

5162 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 



Fig. 1 Introduction to spiro-OMeTAD and PTAA. (a) Architecture of a planar n–i–p PSC and its energy alignment. Chemical structures of (b) spiroOMeTAD and (c) PTAA. (d) HTLs used in high-efficiency solar cells over time. Reprinted with permission.<sup>59</sup> Copyright 2017, Wiley-VCH. 

Despite extensive attempts to develop more efficient and/or stable alternative HTL materials,<sup>45–47</sup> spiro-OMeTAD and PTAA remain the most popular HTLs for high-efficiency n–i–p PSCs (Fig. 1d).<sup>48</sup> This review provides an in-depth analysis and critical comparison of the development, key electronic and morphological properties, conventional and alternative doping schemes and mechanisms, and degradation pathways of both spiro-OMeTAD and PTAA. This knowledge is highly applicable to device fabrication and explains the root of various HTL-related device failures. 

Whilst this review focuses on applications of spiro-OMeTAD and PTAA as HTLs in PSCs, most of the properties discussed remain equally relevant for other electronic devices in which spiro-OMeTAD and PTAA are used as organic semiconductors. For example, they are also popular as HTLs in perovskite light emitting diodes (LED),<sup>49,50</sup> organic LEDs,<sup>51</sup> and dye sensitized solar cells (DSSC),<sup>52</sup> in which familiarity with the energetics, conductivity, doping, and stability of these materials remains equally important. Additionally, PTAA remains very widely used in organic field effect transistors (OFET),<sup>53</sup> and both materials have also been applied in photodetectors.<sup>54,55</sup> Researchers from any of these fields will find useful information about the intrinsic properties, doping schemes, behaviors under environmental stressing, and degradation pathways of spiro-OMeTAD and PTAA in this review. These are relevant to any electronic devices employing spiro-OMeTAD and PTAA as organic semiconductors. 

When looking specifically at the performance of spiro-OMeTAD and PTAA in PSCs, this review focuses on HTLs in n–i–p 

architectures as these still retain the highest efficiencies. Additionally, recent investigations have suggested that the properties of charge transfer at the perovskite/HTL interface are the major efficiency and stability-limiting factors in high-efficiency n–i–p PSCs.<sup>56–58</sup> Hence, this review focuses solely on the properties of HTLs in n–i–p architectures and does not cover the wetting or crystallographic growth of perovskite materials on top of them. 

This analysis reveals a range of fundamental properties that enable the persistent success of a HTL, which are found to include not only high hole mobility and good morphology, but also interactions with dopants, the perovskite, and environmental stressors. A detailed examination of both doping and degradation mechanisms reveals general rules for selecting optimal dopants and ensuring good stability, which apply even to materials beyond spiro-OMeTAD and PTAA (especially other organic HTLs). As the efficiencies of PSCs approach fundamental limits, optimization of hole transport layers will only become more important. Understanding the doping strategies, morphological and molecular adjustments that can be used to optimize device performance is essential for the development of the next generation of HTLs. 

## 2. Hole transport layers in perovskite solar cells 

The way charges are transferred to and through the CTLs in PSCs affects every important solar cell parameter and can 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5163 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

significantly limit power conversion efficiency (PCE). The choice and processing of the CTLs is central to PSC performance, as they strongly effect the energetic alignment,<sup>57,58,60</sup> charge transit time,<sup>61</sup> recombination kinetics,<sup>38,58,62</sup> and charge extraction efficiency<sup>63</sup> in the device. Their morphological, mechanical and chemical properties can strongly affect device stability, where their abundance and cost determine the commercialization of a PSC architecture. 

In high-efficiency n–i–p PSCs, open-circuit voltage (Voc) losses have been found to correspond very well to interfacial recombination currents at the perovskite/HTL interface, which depend strongly on the HTL used (Fig. 2a).<sup>57</sup> Gelmetti et al. demonstrated that recombination between holes in the HTL and electrons in the perovskite is the main recombination loss mechanism in these PSCs.<sup>58</sup> The magnitude of this interfacial recombination can be influenced by the electronic coupling between the HTL and the perovskite,<sup>64</sup> the number of trap states in the HTL as determined by its energetic disorder,<sup>38</sup> and the HTL conductivity, which when it is much lower than that of the perovskite can cause accumulation of high densities of holes at the interface.<sup>65</sup> Glowienka et al. suggested that the chemical interaction between the HTL and the perovskite creates a chemically altered ‘dead zone’ in the perovskite in which Shockley–Read–Hall recombination rates are very high.<sup>66</sup> However, some HTLs have also been shown to actively passivate defects at the perovskite interface.<sup>67</sup> 

Additionally, a large offset between the valence band (VB) of the perovskite and the highest occupied molecular orbital (HOMO) of the HTL decreases the Voc in PSCs due to hole transport losses.<sup>38</sup> Although the ideal offset remains a subject of discussion,<sup>62</sup> Westbrook et al. have suggested that only a small energy offset of 0.07 eV between the HTL HOMO and the perovskite VB is needed to drive charge separation at the interface.<sup>63</sup> The quasiFermi level of the perovskite must also be aligned with the Fermi level of the HTL, as an offset exponentially increases the hole density within the HTL, increasing the interfacial recombination rate.<sup>38,57</sup> The energetics of HTLs in n–i–p PSCs have also been shown to determine the distribution of internal electric potential 

in the cell, thought to be key to device performance as it can drive charges either towards or away from interfaces (Fig. 2b).<sup>60</sup> 

Fast charge transit through the HTL is also important to PSC efficiency, and the conductivity of hybrid perovskites is orders of magnitude larger than that of most commonly used HTLs.<sup>61,68</sup> Hence, decreasing the transit time of charges through the HTL, either by making it thinner or increasing its conductivity, significantly improves both the fill factor (FF) and Voc of the device by improving charge extraction<sup>65,69</sup> and reducing the likelihood of recombination events in the HTL.<sup>69</sup> In addition to this, parasitic absorption of light by HTLs can also reduce device efficiency by negatively impacting the short-circuit current density (Jsc).<sup>70</sup> 

Hence, the energetics, hole conductivity and morphology of the HTL all greatly influence overall device efficiency.<sup>71</sup> The HTL also plays a crucial role in the stability and lifetime of PSCs as it sits directly on top of the active perovskite layer, and can either slow down or accelerate degradation mechanisms.<sup>72</sup> Finally, the HTL should also be compatible with low-cost and solution processable manufacturing techniques. HTLs ideally require (a) high charge carrier mobilities and conductivities, (b) appropriate HOMO and quasi Fermi levels for efficient hole transfer from perovskite to HTL, (c) high LUMO for good electron blocking, (d) thermal, moisture, UV and chemical stability, (e) pinhole-free morphology and good morphological contact with the perovskite. Additionally, the HTLs should be made with (f) low-cost and abundant materials, (g) cheap, solution-based fabrication methods using solvents that do not disturb the perovskite layer, and (h) an easily reproducible synthesis. As a range of dopants or additives is normally used to improve both the hole conductivity in HTLs and their electronic alignment with the perovskite, these should also align with each of these properties. 

A wide range<sup>48</sup> of potential HTLs from organic small molecules<sup>45–47</sup> to polymers<sup>73,74</sup> to inorganic compounds<sup>75,76</sup> has been explored over the past decade, with the inclusion of various additives. However, the most popular hole transport materials for high efficiency PSCs remain spiro-OMeTAD and PTAA as demonstrated in Fig. 1a. They are both based on the 



Fig. 2 Impact of HTL energetics on PSCs. (a) Trend of quasi Fermi level splitting (QFLS) in a variety of HTLs and ETLs, illustrating impact of CTLs on PSC Voc. Reprinted with permission.<sup>57</sup> Copyright 2019, Royal Society of Chemistry. (b) Energy diagram of a PSC, illustrating band bending at CTL interfaces as well as impact of energetic offsets. Inset shows potential distribution throughout ETL/MAPI/HTL, with severe potential changes at the 4 Debye layers as described by the surface polarization model. Reprinted with permission.<sup>60</sup> Copyright 2019, Royal Society of Chemistry. 

5164 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

triarylamine moiety, which has been used in organic semiconductors since the late 1990’s and benefits from an exceptionally stable radical cation<sup>77</sup> and facile tuning of optical, electrical, and morphological properties.<sup>64</sup> The review examines how and to what extent spiro-OMeTAD and PTAA fulfill the requirements for ideal HTLs, and explains how this translates to their good functionality as HTL materials. However, it also reveals their limitations and makes recommendations for research practices around the design of future HTLs. 

## 3. Spiro-OMeTAD 

### 3.1 Pristine spiro-OMeTAD properties 

Spiro-OMeTAD was initially synthesized as a high conductivity, stably amorphous, small molecule HTL in the 1990’s<sup>42,78</sup> and first applied in PSCs in 2012 demonstrating an impressive efficiency of 9.7% and dramatically improved stability compared to liquid junction PSCs.<sup>11</sup> The use of spiro-OMeTAD proved to be critical to the evolution of solid-state heterojunction PSCs from DSSCs, and spiro-OMeTAD was the HTL of choice for many early PSC efficiency records.<sup>22,25,32,79</sup> The enduring popularity of spiroOMeTAD as a HTL in PSCs can be largely ascribed to its ease of processing, somewhat favorable HOMO-VB match with the most popular perovskite light absorbers, and good hole conductivity when doped. The use of an appropriate solvent, specifically chloroform,<sup>80</sup> enables a smooth, homogenous and pinhole-free layer of pristine spiro-OMeTAD to be deposited from solution, which is a morphology strongly correlated to overall device efficiency.<sup>81</sup> 

Schulz et al. investigated the band alignment of spiro-OMeTAD at the perovskite interface using direct spectroscopic methods, determining a HOMO of �5.0 eV � 0.1 eV and a LUMO of �1.5 eV.<sup>82</sup> The LUMO of spiro-OMeTAD is positioned more than 2 eV above the conduction band (CB) of a range of different perovskites, which indicates good electron blocking abilities. 

However, the offset between the spiro-OMeTAD HOMO and the perovskite VB, which lies between �5.2 eV and �5.9 eV for a wide range of photoactive perovskites,<sup>82,83</sup> lies on the order of 100s of meV, which is large enough to cause significant voltage losses.<sup>82</sup> 

Although hole mobility generally increases with crystallinity for organic semiconductors,<sup>84</sup> the amorphous spiro-OMeTAD phase is important for maintaining good contact at the HTL/ perovskite and HTL/electrode interfaces.<sup>85</sup> Poplavvsky and Nelson<sup>86</sup> determined the hole mobility in pristine spiro-OMeTAD to be 2 � 10<sup>�4</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> , but it is worth noting that this mobility is sometimes measured to be lower in other papers, down to a magnitude of 10<sup>�5</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> .<sup>87,88</sup> This variation is likely due to differences in solvent or spiro-OMeTAD purity<sup>89</sup> and film deposition techniques,<sup>86</sup> resulting in varying degrees of energetic disorder in the film,<sup>84</sup> but could also be caused by the use of different mobility measurement techniques and models.<sup>90</sup> Conductivity is a product of the hole mobility and hole density in the HTL. The intrinsic hole density in pristine spiro-OMeTAD has been cited as 8.67 � 10<sup>14</sup> cm<sup>�3 89</sup> and a range of values for its conductivity can be found in literature, ranging from 2.5 � 10<sup>�7</sup> S cm<sup>�1 88</sup> (derived from I–V characteristics) to B10<sup>�8</sup> S cm<sup>�1</sup> (derived from 4-point probe measurements).<sup>91</sup> These variations in conductivity measurements can be due to variations in the concentration of oxidized spiro-OMeTAD<sup>+</sup> in the pristine film caused by differing amounts of exposure to oxygen or light.<sup>92</sup> 

The hole conductivity of spiro-OMeTAD is smaller than that of perovskites by multiple orders of magnitude, which means that it limits charge transit times<sup>68</sup> (Fig. 3a) and particularly the FF in PSCs.<sup>61,68</sup> Multiple groups have found that using a thinner layer of spiro-OMeTAD (down to 180 nm) significantly improves the FF of PSCs (Fig. 3b), as holes have to traverse a shorter distance which means that the limited conductivity of spiro-OMeTAD impacts device performance less.<sup>93,94</sup> However, devices with spiro-OMeTAD layers this thin were found to be less reproducible due to a reduced uniformity of coverage on the relatively rough perovskite layer, which enabled occasional 



Fig. 3 Impact of spiro-OMeTAD thickness on PSC performance. (a) Transit time of charges through a PSC with different spiro-OMeTAD HTL thicknesses. Reprinted with permission.<sup>68</sup> Copyright 2017, American Chemical Society. (b) PSC parameters with different spiro-OMeTAD HTL thicknesses. Reprinted with permission.<sup>94</sup> Copyright 2015, American Chemical Society. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5165 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

direct contact between perovskite and Au. These contacts increase recombination and are detrimental to Voc (Fig. 3b). Spiro-OMeTAD hence has an optimal thickness around 200<sup>93,94</sup> –370 nm<sup>68</sup> depending on perovskite roughness. Additionally, a smooth HTL/Au interface was found to improve the current generation in PSCs by enhanced light reflection.<sup>94</sup> 

In addition to this, spiro-OMeTAD has been found to show very fast hole transfer on the sub-ps scale from perovskites (undoped)<sup>95</sup> and particularly low recombination rates (in its doped form) in DSSCs as compared to other HTLs.<sup>96</sup> This could be due to the relatively weak electronic coupling between spiroOMeTAD and the perovskite because of its bulky molecular structure.<sup>97</sup> 

### 3.2 Spiro-OMeTAD doping 

Spiro-OMeTAD is conventionally doped with multiple additives which enhance both its electronic and physical properties. Doping is a well-established strategy to improve the conductivity of semiconductors, where an impurity is added to the semiconductor in order to increase the concentration of majority charge carriers and improve conductivity.<sup>98</sup> Spiro-OMeTAD is p-doped by oxidation to spiro-OMeTAD<sup>+</sup> .<sup>99</sup> This also deepens its HOMO by 420 meV, potentially providing better energetic alignment at the spiro-OMeTAD/perovskite interface.<sup>100</sup> Although the oxidation of spiro-OMeTAD has been detected even without the addition of any p-dopants, this was at a rate too low to significantly affect conductivity.<sup>101</sup> The most commonly used additives are p-dopants lithium bistrifluoromethanesulfonimidate (LiTFSI) and FK209 (tris[2-(1H-pyrazol-1-yl)-4-tert-butylpyridine)cobalt(III) tris(bis(trifluoromethylsulfonyl)imide)], as well as 4-tertbutylpyridine (tBP) which mainly improves morphology (depicted in Fig. 4a).<sup>102</sup> 

The simultaneous use of LiTFSI and tBP in spiro-OMeTAD has been found to improve its conductivity by two orders of magnitude from 2.5 � 10<sup>�7</sup> S cm<sup>�1</sup> to 2 � 10<sup>�5</sup> S cm<sup>�1</sup> ,<sup>103</sup> and the addition of FK209 further improved conductivity causing a decrease in series resistance from 94.7 O to 65.8 O.<sup>79</sup> Since these additives are generally present in large concentrations (Table 1), dopants can have significant effects not only on conductivity but also on energetics, recombination, thin film morphology and stability within a PSC. 

LiTFSI. LiTFSI was introduced as a dopant in solid state dye sensitized solar cells by Snaith et al. in 2006.<sup>103</sup> It p-dopes spiroOMeTAD by increasing the concentration of oxidized spiroOMeTAD<sup>+</sup> , moving the Fermi level of the HTL closer to its HOMO.<sup>106</sup> In PSCs, the oxidation of spiro-OMeTAD by LiTFSI is suggested to proceed by two separate spectrum-dependent oxidation mechanisms, where spiro-OMeTAD is either oxidized directly by oxygen or by an intermediate oxidation of the perovskite depending on the wavelength of light that drives the reaction (Fig. 4b).<sup>101</sup> The product spiro-OMeTAD<sup>+</sup> TFSI<sup>�</sup> is weakly bound due to the highly delocalized charge on TFSI<sup>�</sup> , which means that the barrier to charge hopping is reduced, improving conductivity.<sup>107</sup> Hawash et al. also show that the concentration of spiro-OMeTAD<sup>+</sup> in a LiTFSI-doped film increased over time upon exposure to air.<sup>108</sup> Additionally, exposure to high humidity has been suggested to irreversibly distribute LiTFSI more evenly throughout the film resulting in a 

significant conductivity improvement.<sup>109</sup> 24 hours of aging LiTFSI-doped spiro-OMeTAD in ambient conditions increased both mobility and conductivity by more than 2 orders of magnitude, which was ascribed to irreversible LiTFSI redistribution by water vapour and reversible oxygen doping by extended oxygen exposure.<sup>109</sup> However, the mechanism by which these factors specifically increase mobility rather than hole concentration remains unclear. Although low concentrations of spiro-OMeTAD<sup>+</sup> may be created in PSCs by exposure to only light, oxygen or LiTFSI, all three factors are necessary to create significant concentrations of persistent spiro-OMeTAD<sup>+</sup> . Increases in device efficiency after lightsoaking treatments, in which devices are exposed to intense illumination for 15–30 min before testing, can also be attributed to an increase in spiro-OMeTAD<sup>+</sup> in the HTL.<sup>92,101</sup> To obtain high efficiency devices, it is customary to age doped spiroOMeTAD in a low humidity ambient environment overnight or even up to multiple weeks.<sup>105</sup> Cho et al. found that this aging improved Voc and FF in devices both by increasing conductivity and lowering the HOMO of spiro-OMeTAD, and by reducing recombination in the perovskite.<sup>110</sup> However, this was only observed in the presence of both oxygen and moisture. The necessity for light irradiation<sup>101</sup> and the effects of tBP de-doping<sup>111</sup> may suggest that it is unlikely that the concentration of spiroOMeTAD<sup>+</sup> is significantly increased in the dark. Hence, this phenomenon deserves further investigation. 

tBP. High boiling point (197 1C)<sup>81</sup> liquid tBP is mainly said to improve the morphology and uniformity of LiTFSI-doped spiro-OMeTAD films in PSCs.<sup>81,111,112</sup> It increases the polarity of the spiro-OMeTAD precursor which improves wetting on the perovskite.<sup>113</sup> Spiro-OMeTAD films doped with LiTFSI tend to form pinholes immediately after deposition (Fig. 4ci), which are detrimental to device stability as they allow the diffusion of degrading ions, water and oxygen into the perovskite.<sup>108</sup> tBP is thought to generate a semi-liquid environment in the deposited film which permits solid-state diffusion,<sup>111</sup> enabling it to fill pinholes which re-form when tBP is removed by evaporation as shown in Fig. 4c.<sup>112</sup> Wang et al. furthermore suggest that the addition of tBP to a liquid spiro-OMeTAD precursor in chlorobenzene removes the phase separation induced by the addition of LiTFSI, which is dissolved in acetonitrile, as shown in Fig. 4d.<sup>114</sup> This improved mixing translates to the deposited film, where the addition of tBP greatly improves the distribution of LiTFSI throughout the film as demonstrated in Fig. 4e.<sup>81</sup> This improvement was shown to be due to the formation of LiTFSI-tBP complexes.<sup>114</sup> In addition to this, there are indications that tBP improves the hole collection efficiency at the perovskite-HTL interface by p-doping the region of perovskite adjacent to the HTL, resulting in upward band bending as shown in Fig. 4f.<sup>115</sup> Noel et al. also showed that direct treatment with pyridine was able to passivate perovskite surfaces to reduce recombination,<sup>116</sup> which may indicate that tBP has a passivating effect. 

Co(III) complexes. Co(III) complexes are a more recently popularized but less well-understood class of p-dopants used in spiro-OMeTAD. Burschka et al.<sup>118</sup> and Noh et al.<sup>79</sup> simultaneously introduced FK209, which when used alongside LiTFSI and tBP, increased conductivity by B7� as compared to a LiTFSI- and 

5166 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 



Fig. 4 Effects of LiTFSI and tBP on spiro-OMeTAD. (a) Chemical structures of conventional spiro-OMeTAD dopants. Reprinted with permission.<sup>102</sup> Copyright 2019, Royal Society of Chemistry. (b) UV-vis absorption spectra in the 450–600 nm range of LiTFSI-doped spiro-OMeTAD in chlorobenzene with either 0.4 LiTFSI/spiro-OMeTAD molar ratio at various illumination times or 1 h illumination time with various molar ratios. Growing absorption peak corresponds to the oxidized spiro-OMeTAD<sup>+</sup> species. Reprinted with permission.<sup>101</sup> Copyright 2015, American Chemical Society. (c) Scanning electron microscopy (SEM) images of freshly prepared spiro-OMeTAD thin film (i) without tBP, showing pinholes, (ii) with tBP, showing no pinholes, (iii) with tBP after overnight vacuum treatment, showing re-formed voids and pinholes. Reprinted with permission.<sup>117</sup> Copyright 2016, American Chemical Society. (d) Photographs of spiro-OMeTAD solution doped with LiTFSI (i) without and (ii) with tBP. Reprinted with permission.<sup>117</sup> Copyright 2016, American Chemical Society. (e) Fourier transform infrared spectroscopy microscopy images mapping the LiTFSI signal intensity in spiro-LiTFSI and spiro-LiTFSI-tBP. Reprinted with permission.<sup>81</sup> Copyright 2016, American Chemical Society. (f) Diagram of perovskite region in a PSC with proposed n-doped region next to ETL and p-doped region next to tBP-containing HTL. Reprinted with permission.<sup>115</sup> Copyright 2017 Wiley. 

Table 1 Spiro-OMeTAD doping ratios in recent high-efficiency PSCs 

|Ref.|Spiro-OMeTAD :tBP : LiTFSI : FK209 (molar ratio)|
|---|---|
|26|1 : 3.3 : 0.53 : 0.098|
|41|1 : 3.5 : 0.53 : 0|
|40|1 : 1.8 : 0.28 : 0.017|
|104|1 : 3.7 : 0.57 : 0.034|
|105|1 : 3.30 : 0.50 : 0.03|



tBP-doped spiro-OMeTAD film.<sup>79</sup> Interestingly, FK209 was shown to oxidize spiro-OMeTAD significantly even under dark conditions, which LiTFSI does not. 

Alternative dopants. The remaining room for performance improvement, as well as the degrading properties of commonly 

used spiro-OMeTAD dopants, have prompted a search for alternative dopants and additives.<sup>102</sup> These have included a range of metal complexes (often containing the TSFI<sup>�</sup> ion),<sup>119–122</sup> pyridine derivatives,<sup>119,123</sup> and different Cu(II) complexes.<sup>120</sup> Particularly promising are dopants which are able to oxidize spiro-OMeTAD without any exposure to oxygen such as spiro-OMeTAD(TFSI)2,<sup>91</sup> Zn(TFSI)2,<sup>124</sup> and vanadic oxide (V2O5).<sup>125</sup> Oxygen has been shown to participate in perovskite degradation, and the ability to encapsulate devices that were never exposed to air directly in nitrogen makes encapsulation much more effective, especially for particularly air-sensitive tin-containing perovskites.<sup>126</sup> 

Despite the variety of alternative dopants and additives explored, LiTFSI, tBP and FK209 remain a favourite combination amongst high efficiency PSCs.<sup>40,41,104</sup> Since it has been 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5167 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

shown that additives are rarely straightforward modifiers, but rather interact strongly with multiple components of the spiroOMeTAD HTL and the PSC, a better understanding of the doping mechanisms outlined here can aid the design of intelligent doping schemes and more stable PSCs. 

### 3.3 Stability limitations of spiro-OMeTAD 

Thermal degradation. Whilst the electronic properties of doped spiro-OMeTAD enable high-efficiency devices in a research environment, its stability represents a major barrier. Although spiro-OMeTAD has a 245 1C melting point,<sup>85</sup> even pristine spiro-OMeTAD was shown to be vulnerable to crystallization upon thermal stressing at 100 1C, which disturbed contact at its interfaces.<sup>85</sup> Thermal stability is worsened by the addition of tBP, which was found to decrease the stability of the amorphous spiro-OMeTAD phase,<sup>85,111</sup> as well as by p-dopants, since oxidized spiro-OMeTAD<sup>+</sup> has a significantly lower glass transition temperature.<sup>127</sup> The performance of PSCs using doped spiro-OMeTAD HTLs has been shown to degrade rapidly at temperatures as low as 85 1C, whilst most perovskites and other PSC components have been shown to be thermally stable in this range.<sup>128</sup> Mesquita et al. observed that only part of this degradation was irreversible as shown in Fig. 5a.<sup>129</sup> As pristine spiro-OMeTAD was much less affected by thermal stressing, the permanent degradation was ascribed to dopant evaporation. tBP has directly been shown to evaporate from a doped spiroOMeTAD film at 85 1C,<sup>130</sup> causing device performance to rapidly degrade<sup>80,130</sup> through the formation of pinholes,<sup>112</sup> although this could be partially prevented by the presence of a metal electrode.<sup>131</sup> Additionally, the spontaneous degradation of spiro-OMeTAD<sup>+</sup> as well as the de-doping of spiro-OMeTAD<sup>+</sup> by tBP were shown to occur at much higher rates at high temperatures (100 1C).<sup>127</sup> 

Interface degradation & electrode migration. Lee et al. showed that adhesion at the spiro-OMeTAD/perovskite interface is poor. This is due to weak interactions as well as a hardening of the film by an accumulation of additives at this interface.<sup>132</sup> The addition of a very thin polyethylenimine (PEI) interlayer between the perovskite and spiro-OMeTAD was shown to improve adhesion as well as device stability.<sup>133</sup> Additionally, Wei et al. observed photodegradation of the chemical contact between spiro-OMeTAD and Au at the interface under continuous illumination.<sup>134</sup> 

Another stability problem is the migration of metal ions stemming from the electrode through the spiro-OMeTAD HTL into the perovskite, which for Au electrodes occurs at temperatures as low as 70 1C under illumination (Fig. 5b).<sup>135</sup> The presence of Au<sup>+</sup> inside the perovskite is suggested to degrade PSC performance by producing both shunts, which reduce FF, and inducing deep trap states, which reduce Jsc and Voc. Spiro-OMeTAD, which easily allows ionic diffusion, is found to be a very poor barrier for Au migration. This effect occurs even when PSCs are aged at room temperature.<sup>136</sup> In other architectures, a bilayer Cu–Ag electrode has been used to inhibit electrode diffusion and improve stability.<sup>137</sup> 

Li<sup>+</sup> diffusion. Unoxidized Li<sup>+</sup> ions in the spiro-OMeTAD layer stemming from LiTFSI doping have been shown to migrate all the way through the device into the perovskite layer (Fig. 5c). As Li<sup>+</sup> is small and has a high diffusion tendency, it can diffuse even faster than the intrinsic perovskite ions.<sup>138</sup> Interestingly, upon the application of varying LiTFSI concentrations, the variation in spiro-OMeTAD resistivity was significantly different from the variation in device series resistance. This suggests that LiTFSI affects not only the electrical properties of spiroOMeTAD but also those of other device components. This does not necessarily have to be a negative effect, as time-resolved photoluminescence measurements show that the accumulation of Li<sup>+</sup> in TiO2 actually facilitates electron injection in the ETL.<sup>138</sup> Dawson et al. showed that Li<sup>+</sup> ions can also participate in spontaneous and exothermic perovskite decomposition, producing LiPbX2 or LiX (where X is a halide),<sup>139</sup> but the extent of these processes and their effect on PSC performance remain unclear. 

tBP-assisted spiro-OMeTAD<sup>+</sup> and perovskite degradation. Kasparavicius et al. observed tBP to degrade the conductivity of spiro-OMeTAD,<sup>127</sup> which likely occurs as it decreased the concentration of spiro-OMeTAD<sup>+</sup> in both solutions and films over time and even faster at elevated temperatures.<sup>111,140</sup> It was suggested that tBP actively reduces spiro-OMeTAD<sup>+</sup> through the formation of an oxidized tBP<sup>+</sup> ion which is stabilized by TFSI<sup>�</sup> before reacting further with another molecule of spiroOMeTAD<sup>+</sup> .<sup>127</sup> This is problematic for PSC stability as it means that the concentration of spiro-OMeTAD<sup>+</sup> , and hence HTL conductivity, is highly dependent on temperature, illumination, aging, and tBP concentration. 

tBP has also been shown to degrade perovskites, which is proposed to occur by reaction with PbI2, a perovskite degradation product, to drive the perovskite decomposition reaction forward.<sup>123,141</sup> This degradation was shown to be a slow process contingent on the diffusion of tBP into the perovskite, although increasing the concentration of tBP in a spiro-OMeTAD HTL significantly increased the rate of perovskite degradation.<sup>141</sup> The inclusion of a montmorillonite buffer layer between the perovskite and spiro-OMeTAD films was shown to successfully delay perovskite corrosion, and even reduced charge recombination in the devices.<sup>141</sup> 

Moisture degradation. The hygroscopicity of LiTFSI is a wellknown stability concern for PSCs with doped spiro-OMeTAD HTLs.<sup>142,143</sup> The rate of degradation of a perovskite film with spiro-OMeTAD deposited on top was found to increase exponentially with higher LiTFSI concentrations, indicating that the hygroscopicity of LiTFSI is directly responsible for the acceleration of perovskite degradation.<sup>72</sup> However, Leijtens et al. showed that even when doped with an alternative nonhygroscopic dopant, spiro-OMeTAD incorporated in PSCs still allows a significant amount of moisture-related perovskite degradation during aging in humid ambient conditions at 85 1C.<sup>87</sup> SEM images revealed that spiro-OMeTAD cracks and breaks into individual pieces on top of a perovskite layer during high humidity degradation (Fig. 5d),<sup>72</sup> suggested to be due to the mechanical stress brought about by volume changes of the 

5168 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 



Fig. 5 Stability of spiro-OMeTAD and degradation of spiro-OMeTAD-based PSCs. (a) I–V curves of PSCs employing LiTFSI- and tBP-doped spiroOMeTAD operating at various temperatures. Reprinted with permission.<sup>129</sup> Copyright 2019, Wiley-VCH. (b) Time-of-flight secondary ion mass spectroscopy (ToF-SIMS) reconstructed maps of Au<sup>�</sup> ions traced using depth profiling after aging at 70 1C or 30 1C in nitrogen under illumination for 15 hours. Reprinted with permission.<sup>135</sup> Copyright 2016, American Chemical Society. (c) ToF-SIMS elemental depth profile of PSCs utilizing LiTFSI-doped spiro-OMeTAD, showing a broad distribution of Li over various layer. Reprinted with permission.<sup>138</sup> Copyright 2017, Royal Society of Chemistry. (d) SEM image of spiro-OMeTAD-coated MAPbI3 films after 24 h exposure to a high humidity (98 � 2% RH) environment. Reprinted with permission.<sup>72</sup> Copyright 2015, American Chemical Society. (e) Schematic depiction of the various degradation pathways in LiTFSI- and tBP-doped spiro-OMeTAD HTLs upon aging, as well as the interactions between these various mechanisms. Reprinted with permission.<sup>112</sup> Copyright 2016, American Chemical Society. (f) Evolution of current density and hysteresis index with spiro-OMeTAD<sup>+</sup> concentration. (g) Evolution of spiro-OMeTAD<sup>+</sup> concentration in spiroOMeTAD film on FTO under 1 sun illumination. Both reprinted with permission.<sup>92</sup> Copyright 2016, Elsevier. 

perovskite at the beginning of its degradation process, which spiro-OMeTAD cannot mechanically bear. 

LiTFSI and tBP co-degradation. Wang et al. proposed a full degradation mechanism for PSCs considering the effects of both LiTFSI and tBP in a spiro-OMeTAD HTL, shown in Fig. 5e.<sup>112</sup> In the first B200 hours of storage in the dark, tBP evaporates, causing the slow aggregation of LiTFSI which becomes hydrated 

over the next B300 hours. This leaves ‘bubbles’ of water in the HTL which eventually find their way into the perovskite, so that after 1000 hours device performance is severely degraded. This theory seems to be confirmed further by the observation that spiro-OMeTAD and FAPbI3 perovskite are stable under ambient thermal stressing on their own, but show signs of degradation when interfaced.<sup>144</sup> Devices using FK209 in conjunction with 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5169 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

LiTFSI and tBP were also found to be less stable than those just using LiTFSI and tBP, although it is not clear why.<sup>145</sup> 

Exceedingly high spiro-OMeTAD<sup>+</sup> concentration. Whilst a small concentration of spiro-OMeTAD<sup>+</sup> is highly beneficial for conductivity, Sanchez & Mas-Marza found that a spiro-OMeTAD<sup>+</sup> concentration beyond 4 mol% in the HTL increasingly decreases PSC efficiency in the form of Jsc reduction (Fig. 5f).<sup>92</sup> Performance degradation due to overoxidation of spiro-OMeTAD is problematic as the concentration of spiro-OMeTAD<sup>+</sup> continues to increase under full irradiation for more than 3 hours as shown in Fig. 5g, such that device performance quickly degrades under operating conditions.<sup>92</sup> Voc also decreases beyond a critical concentration of spiro-OMeTAD<sup>+</sup> , which was found to be at least partially associated with a higher charge recombination rate.<sup>101</sup> 

In summary, spiro-OMeTAD in its pristine form is already vulnerable to thermal degradation in the operational thermal range, and its commonly used dopants LiTFSI, tBP and FK209 and their byproducts can be hygroscopic,<sup>72</sup> cause morphological issues,<sup>81</sup> evaporate,<sup>129</sup> migrate through the PSC,<sup>138</sup> and/or participate in undesirable side reactions.<sup>111,127</sup> Spiro-OMeTAD was also found to be a very poor barrier for the migration of ions stemming from dopants, electrodes or other PSC components. Additionally, minor variations in dopant concentration<sup>59</sup> as well as environmental conditions such as illumination time and humidity can significantly affect the conductivity of spiro-OMeTAD, worsening reproducibility. As a result of these stability issues, PSCs that use spiro-OMeTAD as a HTL tend to have short lifetimes, especially when unencapsulated.<sup>48</sup> Despite these shortcomings, spiroOMeTAD has persisted throughout the years as a favorite HTL for high efficiency PSCs.<sup>25,26,32,40,41,104</sup> 

## 4. PTAA 

### 4.1 Pristine PTAA properties 

The other HTL regularly used in high efficiency PSCs is PTAA.<sup>59</sup> Until recent years, PTAA did not specifically refer to the trimethyl-substituted poly(bis(4-phenyl)(2,4,6-trimethylphenyl)amine but rather described a wide range of polytriphenylamines, a class of organic polymer semiconductors which was popularized in the group of J. Verez for applications in organic field-effect transistors 

(OFETs).<sup>146–148</sup> PTAA was first applied as a HTL in PSCs simultaneously by Heo et al.<sup>43</sup> and Noh et al.<sup>149</sup> in 2013 where it reached an efficiency of 12%, outperforming both a range of other semiconducting polymers and spiro-OMeTAD when all HTLs were doped with LiTFSI and tBP.<sup>43</sup> PTAA was found to interact more strongly with perovskite at the interface than other hole-conducting polymers, possibly improving hole transfer. PTAA has remained a popular HTL choice for PSCs, and has been used in many high-efficiency devices since its introduction.<sup>24,44,73,150</sup> 

The enduring popularity of PTAA as a HTL in PSCs stems, similarly to spiro-OMeTAD, from its thermally stable amorphous morphology, good solubility in a wide range of organic solvents, relatively good hole mobility and good energetic match with most perovskites. Pristine PTAA has repeatedly been found to be completely amorphous, with no glass transition or melting phase feature observed in DSC analysis up to 300 1C,<sup>151,152</sup> and is able to form especially smooth films.<sup>152</sup> 

Ko et al. measured the hole mobility of pristine PTAA films with Mw varying from 10–50 kDa to lie between 3–4 � 10<sup>�5</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ,<sup>152</sup> and observed a slight decrease in hole mobility with increasing Mw (Fig. 6a). This was ascribed to a higher degree of both positional disorder and energetic disorder in higher Mw PTAA, as impurities may be preferentially embedded in longer polymer chains.<sup>153</sup> One occasionally also sees hole mobilities around 10<sup>�3</sup> –10<sup>�2</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> cited for PTAA<sup>154</sup> when using OFET techniques, but these vary with layer thickness and contact used, and cannot determine general mobility as accurately as space-charge-limited current (SCLC) or ToF measurements. The conductivity of pristine PTAA was determined to be 5.98 � 10<sup>�7</sup> S cm<sup>�1</sup> .<sup>155</sup> Endres et al. showed that p-doped PTAA contains a significant number of sub-gap states below the LUMO, shown to belong to PTAA itself and not the dopant, which may act as traps and aid recombination in the HTL.<sup>156</sup> 

Various values have been measured for the HOMO of undoped PTAA, ranging from �4.91 eV<sup>27</sup> using ultraviolet photoelectron spectroscopy to �5.2 eV<sup>67</sup> using photoelectron spectroscopy in air (PESA), with the average value found in the literature determined to be �5.19 eV by Westbrook et al.<sup>63</sup> The offset between the HOMO of PTAA and the perovskite VB, which again generally lies between �5.2 eV and �5.9 eV<sup>82,83</sup> can hence be very small or can 



Fig. 6 Impact of PTAA thickness on PSC performance. (a) Hole mobilities determined using SCLC measurements of pristine PTAA films with different Mw ranging from 10–50 kDa, demonstrating decreasing mobility with increasing Mw. Reprinted with permission.<sup>152</sup> Copyright 2018, American Chemical Society. (b) Trend in PCE in p–i–n PSCs using various thicknesses of PTAA HTL.<sup>69</sup> (c) Trends in FF and Voc in p–i–n PSCs using various thicknesses of PTAA HTL. Both reprinted with permission.<sup>69</sup> Copyright 2017, Royal Society of Chemistry. 

5170 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

be on the order of 100s of meV, so the extent of voltage losses due to hole transport at the PTAA/perovskite interface would depend strongly on the perovskite used. 

Hole transfer from the perovskite to PTAA has been found to occur on a 10<sup>3</sup> ps timescale, which is relatively slow compared to other HTLs such as spiro-OMeTAD, for which hole transfer occurs 4 orders of magnitude faster.<sup>157</sup> However, Khadka et al. found PTAA to have low rates of interfacial recombination compared to other popular HTL materials, which was attributed partly to a better interface quality and passivation of defect states in the perovskite at the interface.<sup>67</sup> 

HTL thickness is an important parameter in PSCs, as the transit time of holes through the HTL affects both the speed of charge extraction and recombination in the device. When very thin (8 nm) layers of undoped PTAA are used in p–i–n PSCs, higher-order nonradiative recombination losses, which make up half of the total FF losses, were shown to be nearly eliminated.<sup>69</sup> However, PTAA HTLs in n–i–p architectures are normally somewhat thicker, ranging from 30–40 nm, which is still much thinner than spiro-OMeTAD HTLs.<sup>44,150</sup> As complete coverage of the perovskite by PTAA is necessary in order to 

Table 2 PTAA doping ratios in recent high-efficiency PSCs 



<!-- Start of picture text -->
Ref. PTAA monomer : tBP : LiTFSI (molar ratio)<br>24, 44 and 150 1 : 0.74 : 0.12<br>159 1 : 0.70 : 0.12<br>105 1 : 0.39 : 0.08<br><!-- End of picture text -->

avoid shunts created by contact between the perovskite and the electrode material (Fig. 6b), thinner PTAA HTLs result in worse performances. Even in devices with very thin PTAA layers, the FF is still shown to be limited by HTL thickness (Fig. 6c), indicating room for further conductivity improvements.<sup>69</sup> 

### 4.2 PTAA doping 

Similarly to spiro-OMeTAD, PTAA is conventionally p-doped in order to increase its conductivity, most often using LiTFSI and tBP. Endres et al. confirmed that PTAA can be successfully p-doped by observing a lowering of the Fermi level of PTAA towards the HOMO upon addition of a p-dopant.<sup>156</sup> Interestingly, the optimal concentrations of dopants for PTAA-based PSCs (shown in Table 2) are about 4 times lower than the conventional concentrations of LiTFSI and tBP added to spiroOMeTAD, which could indicate a higher doping efficiency or, less straightforwardly, a lower ideal concentration of holes in PTAA for optimal device performance. Co(III) complexes are not normally used to dope PTAA.<sup>158</sup> 

LiTFSI and tBP. Although the doping mechanisms and effects of LiTFSI and tBP in PTAA-based PSCs are still somewhat unexplored, in some ways they are likely to echo their effects in devices employing spiro-OMeTAD. Additionally, the tendency of Lewis acids to p-dope Lewis base polymers by forming complexes with them<sup>160</sup> suggests that LiTFSI may form chargetransfer complexes with the lone electron pair on the nitrogen in PTAA.<sup>161</sup> Indeed, Kim et al. observed a new UV-vis absorbance peak arising at 500 nm after doping PTAA with LiTFSI and 



Fig. 7 Effect of doping and Mw on PTAA-based PSCs. (a) Evolution of p-doped PTAA UV-vis absorption peak in LiTFSI- and tBP-doped PTAA films under illumination. Reprinted with permission.<sup>159</sup> Copyright 2018, Wiley-VCH. (b) Charge mobilities for LiTFSI- and tBP-doped PTAA films of various Mw ranging from 10 kDa to 50 kDa, showing an increase in mobility with Mw. (c) High resolution scanning electron microscopy (HR-SEM) images showing pinholes in a LiTFSI- and tBP-doped 10 kDa PTAA film, and a lack of pinholes in a 20 kDa film. Both reprinted with permission.<sup>152</sup> Copyright 2018, American Chemical Society. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5171 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

tBP (Fig. 7a), which they ascribed to the formation of oxidized PTAA<sup>+</sup> , but PTAA was shown to be oxidized only under illumination.<sup>159</sup> It seems likely that tBP performs a similar function in PTAA as it has been observed to have in spiroOMeTAD, where it forms complexes with LiTFSI to improve its distribution through the film and to avoid the negative effects of dopant aggregation on film morphology.<sup>81,112</sup> 

The conductivity of LiTFSI- and tBP-doped PTAA was determined to be 3.4 � 10<sup>�5</sup> S cm<sup>�1</sup> ,<sup>162</sup> around 2 orders of magnitude higher than the conductivity of pristine PTAA measured by other groups.<sup>155</sup> Interestingly, the mobility of various Mw PTAA (10–50 kDa) increased from B3–4 � 10<sup>�5</sup> a to B5–6 � 10<sup>�5</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> upon optimized doping with LiTFSI and tBP (Fig. 7a),<sup>152</sup> and the mobility of very high Mw doped PTAA (210 kDa) increased even more dramatically from 7.47 � 10<sup>�5</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> to 4.28 � 10<sup>�4</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> .<sup>27</sup> This may indicate that LiTFSI and tBP don’t only p-dope the polymer but also affect the positional and/or electronic disorder in the film.<sup>163</sup> Additionally, LiTFSI- and tBP-doping of PTAA has consistently been found to lower its HOMO,<sup>27,152,164</sup> which may reduce voltage losses. Interestingly, PESA measurements made by Watson et al. showed that the addition of LiTFSI to a pristine PTAA film greatly lowers its HOMO from �5.16 eV to �5.44 eV, but the subsequent addition of tBP increases the HOMO again to �5.17 eV.<sup>165</sup> The authors suggest that this may be due to the inhibition of p-doping by tBP. 

Effect of Mw on LiTFSI- and tBP-doped PTAA. Interestingly, LiTFSI- and tBP-doped PTAA films showed a significant increase in mobility (Fig. 7b) as well as device performance with increasing Mw.<sup>152,166</sup> This trend is opposite to the detrimental effect of increasing Mw on the mobility of undoped PTAA. Ko et al. argued 

that the addition of LiTFSI turns PTAA from an amorphous into a slightly paracrystalline film,<sup>152</sup> in which polymer chains can connect pi-stacked regions without loss of conjugation if they are long enough and can so greatly improve charge transport.<sup>163</sup> However, this claim was justified with HR-SEM images (Fig. 7c),<sup>152</sup> in which pi-stacking domains are not actually visible. Measurements on LiTFSI- and tBP-doped PTAA films of similar and higher Mw carried out by Nia et al. actually found no signal indicating any crystalline PTAA phases, in-plane order or indeed any effect on morphology.<sup>166</sup> Instead, Nia et al. attributed the efficiency improvements observed using high Mw doped PTAA mainly to its reduction of recombination at the perovskite interface and faster hole transfer when compared to lower Mw PTAA.<sup>166</sup> Electrochemical impedance spectroscopy measurements confirmed that higher Mw PTAA HTLs are better able to suppress charge recombination at the PTAA/perovskite interface.<sup>152</sup> Interestingly, this differs from other semiconducting polymer HTLs such as poly(3-hexylthiophene-2,5diyl) (P3HT), for which no such relationship between Mw and recombination is observed.<sup>167</sup> 

BCF. An alternative pathway to PTAA p-doping are Lewis acids, which may either form charge-transfer complexes with PTAA or completely ionize it. Tris-(pentafluorophenyl)borane (BCF, sometimes also referred to as TPFB), which was first applied to PTAA by Luo et al.,<sup>164</sup> p-dopes PTAA by forming a frustrated Lewis acid–base adduct<sup>155</sup> or by charge transfer to form free PTAA<sup>+</sup> and BCF<sup>�</sup> radicals as shown in Fig. 8a.<sup>164</sup> Usually 5–10% BCF is used, and when PTAA doped with 5 wt% BCF was compared to LiTFSI- and tBP-doped PTAA, hole mobility increased slightly from 4.28 � 10<sup>�4</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> to 5.72 � 10<sup>�4</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> and the HOMO was lowered from �5.14 eV to �5.2 eV.<sup>164</sup> Additionally, higher efficiency, faster charge extraction, 



Fig. 8 (a) Doping mechanism by adduct formation and charge transfer of BCF with PTAA. Reprinted with permission.<sup>155</sup> Copyright 2017, American Chemical Society. (b) Nyquist plots of PSCs employing either LiTFSI- and tBP-doped or BCF-doped (here labelled LAD) PTAA HTLs, measured at a bias of 0.8 V under simulated AM 1.5 illumination, demonstrating larger recombination resistance in BCF-doped devices. Reprinted with permission.<sup>164</sup> Copyright 2018, Royal Society of Chemistry. (c) J–V curves of PSCs utilizing PTAA HTLs doped with 8% BCF and exposed to various lengths of lightsoaking treatments, demonstrating optimal performance after 5 min of illumination. Reprinted with permission.<sup>155</sup> Copyright 2017, American Chemical Society. 

5172 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

higher recombination resistance (Fig. 8b) and better stability when stored was observed in devices. This could be due to faster charge extraction or a lower concentration of trap states inside the HTL, but BCF may also have a passivating effect on perovskite defects at the interface. It is interesting to note that on several occasions, BCF seems to be the dopant of choice when particularly high concentrations of PTAA of 30 mg ml<sup>�1</sup> are used (which will result in a relatively thick HTL).<sup>168,169</sup> Ye et al. showed that the performance of PSCs employing BCF-doped PTAA can be further enhanced through a 5 min light soaking treatment at 1 sun illumination (Fig. 8c), which can facilitate electron transfer to BCF and so irreversibly improve conductivity.<sup>155</sup> The concentration of holes in the film was found to continue increasing for light soaking treatments up to 30 min, but PSC performance began to deteriorate after 5 min, indicating that an overabundance of free holes in the film may increase the density of traps or scattering centres to the extent that these begin to dominate PSC performance. 

Other alternative PTAA dopants. PTAA has been doped by multiple groups with well-established p-dopant 2,3,5,6-tetrafluoro7,7,8,8-tetracyanoquinodimethane (F4-TCNQ),<sup>170</sup> which has an electron affinity of 5.2 eV that enables it to form charge-transfer complexes with PTAA.<sup>160</sup> The addition of 1 wt% F4-TCNQ to PTAA (in p–i–n PSCs) was shown to cause a significant drop in the resistance of the PTAA films, but higher concentrations increased resistance which is likely due to dopant aggregation.<sup>171</sup> 

Not all alternative dopants that have been added to PTAA function as p-dopants. Watson et al. used 1,3,5,7-tetrakis-(pformylphenyl)-adamantane (TPBA), a UV-activated crosslinker, as an additive to PTAA in addition to LiTFSI and tBP in order to promote better mechanical stability, fracture resistance, and adhesion to the perovskite.<sup>165</sup> It was able to increase fracture resistance by 221%, improving stability significantly whilst minimally affecting the electronic properties of the PTAA film. 

Alternative PTAA dopants have hence shown significant potential in replacing LiTFSI and tBP and so improving device stability, although more testing under full operational conditions is needed to confirm that they don’t introduce new destabilizing effects. It is not yet clear which properties of these Lewis acids, other than their electron affinity, makes them function well as stable dopants. It would be particularly interesting to investigate whether these dopants form more charge-transfer complexes or free radical ion pairs, and what effects this has on both mobility and ion migration-related stability issues. It is also interesting that the use of different PTAA dopants results in different charge transfer rates and recombination resistances in the device,<sup>164</sup> as it suggests that a dopant’s chemical structure may affect its propensity to act as a recombination center. 

### 4.3 Stability limitations of PTAA 

Thermal degradation. Pristine PTAA has a high thermal stability, with no melting phase feature observed in DSC analysis up to 300 1C<sup>152</sup> and no optically visible crystallization in films after thermal stressing.<sup>144</sup> Saliba et al. used PTAA in combination with a quadruple-cation perovskite to produce PSCs that are able to recover an impressive B90% of their original efficiency after 

500 hours of thermal stressing at 85 1C in nitrogen.<sup>32</sup> Mesquita et al. found that only 8.2% of the deterioration in device efficiency of encapsulated PSCs utilizing PTAA upon thermal stressing at 85 1C was irreversible (Fig. 9a),<sup>129</sup> which was attributed to the evaporation of dopants tBP and LiTFSI due to the observation of pinhole formation. Yang et al. furthermore proposed that when the thermal expansion coefficients of neighboring layers in PSCs are mismatched, thermal stressing can result in cracking.<sup>172</sup> Thermal stressing indeed resulted in cracks in the perovskite in PTAA-based PSCs, accompanied by a 60% efficiency loss. 

Moisture degradation. At 98% humidity, a layer of PTAA was shown to slow down the degradation of MAPbI3 significantly, and SEM images (Fig. 9b) revealed large pinholes and gaps but no cracking in the PTAA layer after moisture degradation.<sup>72</sup> Interestingly, PTAA doped with LiTFSI slowed down degradation even more than undoped PTAA – it was proposed that hydrophilic polymer HTLs may be able to ‘trap’ water in the HTL and slow its migration into the perovskite. Habisreutinger et al. found that when exposure to air is combined with thermal stressing at 80 1C, doped PTAA-covered perovskite degrades almost entirely within 24 hours, even faster than perovskite covered with spiro-OMeTAD.<sup>173</sup> Accordingly, PSCs employing PTAA as HTLs show a fast decrease in efficiency under increasing temperatures in air. However, Bi et al. reported that the addition of LiTFSI to PTAA in PSCs significantly increases the rate of degradation of entire devices when stored in a 50–60% humidity environment as shown in Fig. 9c.<sup>174</sup> Luo et al. observed perovskite degradation in aged devices upon storage in air employing LiTFSI and tBP doping but not in devices using alternative dopant BCF.<sup>164</sup> Additionally, SEM images of aged PTAA films doped with LiTFSI and tBP showed crystallization, aggregation and pinholes, whilst those doped with BCF remained smooth and homogenous. This indicates that much of the moisture instability of PTAA-based HTLs can be remedied through the use of alternative dopant schemes. 

Dopant effects & diffusion. As explored in previous sections, Li<sup>+</sup> ion and tBP migration are likely to negatively affect device stability in HTLs. Luo et al. use SIMS analysis to show that in PSCs using LiTFSI- and tBP-doped PTAA HTLs, Li<sup>+</sup> ions migrate through the cell to accumulate at the TiO2/perovskite interface as shown in Fig. 9d.<sup>164</sup> Li<sup>+</sup> can in this way affect the electrical properties of other PSC layers and possibly degrade the perovskite,<sup>139</sup> but may also facilitate electron injection in the ETL.<sup>138</sup> Additionally, it is likely that all of the processes that tBP has been suggested to participate in within spiro-OMeTAD, such as complexation with LiTFSI,<sup>114</sup> degradation of the perovskite,<sup>123,141</sup> and de-doping of oxidized HTL material,<sup>111,127</sup> can occur in a similar fashion in PTAA. However, the interaction strength between PTAA or PTAA<sup>+</sup> and tBP could affect the extent to which these processes take place. 

Au electrode migration. Migration of Au<sup>+</sup> from the electrode into the perovskite layer is detrimental to device efficiency as it can produce shunts between the perovskite and the electrode and because Au<sup>+</sup> ions act as deep traps, increasing recombination rates in the device.<sup>135</sup> Duong et al. found that after aging at elevated temperatures of 85 1C, Au does in fact migrate through 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5173 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 



Fig. 9 Stability of PTAA and degradation of PTAA-based PSCs. (a) J–V curves of a PSC utilizing a PTAA HTL operating at various temperatures, as well as at RT after thermal stressing (black dotted line). Reprinted with permission.<sup>129</sup> Copyright 2019, Wiley-VCH. (b) SEM image of PTAA coated MAPbI3 films after 24 h exposure to a high humidity (98 � 2% RH) environment. Reprinted with permission.<sup>72</sup> Copyright 2015, American Chemical Society. (c) Stability of PSCs during storage in an ambient atmosphere with 50–60% humidity employing PTAA HTLs with and without the addition of LiTFSI and tBP dopants. Reprinted with permission.<sup>174</sup> Copyright 2014, World Scientific. (d) SIMS depth profile showing distribution of Li throughout a PSC containing a LiTFSIand tBP-doped HTL. Reprinted with permission.<sup>164</sup> Copyright 2018 Royal Society of Chemistry. (e) ToF-SIMS analysis of a PSC using a fresh PTAA HTL, one that has been thermally aged, and one that has been thermally aged under illumination, demonstrating Au migration into the perovskite only in the device that had been thermally aged under illumination. Reprinted with permission.<sup>175</sup> Copyright 2018, The Institute of Electrical and Electronics Engineers. (f) Diagram illustrating the effect of Mw on crack formation in PTAA. Reprinted with permission.<sup>158</sup> Copyright 2017 American Chemical Society. 

PTAA HTLs into the perovskite (Fig. 9e), but only under light irradiation.<sup>175</sup> PSCs using PTAA HTLs and Au electrodes aged at 85 1C over 16 hours under illumination indeed show a significant deterioration in efficiency, but the replacement of Au with indium zinc oxide and a MoOx interlayer significantly improved the thermal stability of the device. 

Mechanical stability. The stability of PSCs can also be compromised when PTAA cohesion or adhesion to the perovskite fails, as good morphological contact is needed to ensure efficient charge transfer. Lee et al. found that a higher Mw 

results in a higher crack onset strain and better cohesion within PTAA, as the larger degree of entanglement enables the deflection of cracks as demonstrated in Fig. 9f.<sup>158</sup> They also found that cracks are more easily formed in PTAA in humid environments. Interestingly, it is possible that a larger Mw PTAA polymer would be better able to accommodate the mechanical stress provided by perovskite volume changes during its degradation as identified by Yang et al.,<sup>72</sup> and improved cell stability under humidity. Furthermore, Watson et al. found that the addition of LiTFSI also reduced the 

5174 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

adhesion of PTAA to the perovskite layer, and that this adhesion could be improved by the addition of the cross-linker TPBA.<sup>165</sup> 

Reproducibility. A well-known barrier to reproducibility in polymeric materials is batch-to-batch variability. PTAA can have significant variation in both polymer chain length distributions and trace metal impurity content between batches, which can significantly affect their electronic and to some extent also morphological properties.<sup>176</sup> Variations in these parameters are not usually completely reported by the producer and are costly to control precisely. 

In summary, although the amorphous morphology of PTAA is stable up to high temperatures, it is relatively vulnerable to allowing moisture ingress into the perovskite and somewhat prone to mechanical failure and delamination at interfaces. Additionally, the migration, evaporation and aggregation of LiTFSI and tBP causes many of the same stability issues as in spiro-OMeTAD, and PTAA is not shown to be a good barrier against ionic diffusion. Hence, the exploration of alternative dopant schemes as well as the use of larger Mw PTAA to improve mechanical stability will provide a pathway to better stability. 

## 5. Comparing spiro-OMeTAD & PTAA 

### 5.1 Energetics 

Measuring the HOMO, LUMO and QFLS of semiconducting materials is rarely straightforward, as exposure to oxygen, moisture or light can affect doping levels and chemical reactivity and hence change a material’s energetics in difficult to predict ways.<sup>38</sup> Especially at interfaces, chemical interaction between HTLs and neighbouring materials can generate interfacial dipoles or band bending,<sup>58</sup> significantly affecting charge transfer and recombination.<sup>38,60</sup> 

The difficulty of these interfacial measurements makes them rare, but the HOMO of both spiro-OMeTAD (undoped)<sup>82</sup> and PTAA (doped and undoped)<sup>156</sup> has been measured at an interface with a perovskite, although a different perovskite composition was used in both cases (Fig. 10a and b). Both HTLs showed similar HOMO offsets with the perovskite and 

were also suggested to show downward band bending towards the perovskite interface, potentially due to the formation of a surface dipole. This is interesting as downward band bending is theoretically detrimental to charge extraction and recombination kinetics as it directs holes back towards the perovskite interface. 

However, this band bending was suggested to be much smaller in doped PTAA, which clearly shows a more beneficial energetic alignment with the perovskite (Fig. 10bii) with only a very small VB-HOMO offset.<sup>156</sup> The band structure at the perovskite interface of doped spiro-OMeTAD has not been directly investigated, but tBP- and LiTFSI-doping of spiro-OMeTAD resulted in a 0.8 eV downwards shift of the Fermi level.<sup>106</sup> Although this seems to be beneficial for device functionality it is difficult to predict how this affects electronic alignment, as HTL doping may also affect the energetics of the perovskite at the interface. 

For PSCs, the alignment of the electronic band structure of HTLs with that of the perovskite absorber/emitter greatly influences device efficiency and specifically Voc. Offsets between the HTL HOMO and perovskite VB or between their Fermi levels, which should be minimized,<sup>38,62,63</sup> affect both charge transfer losses and recombination kinetics at the perovskite/HTL interface. Overall, it is suggested that both spiro-OMeTAD and PTAA incur extra Voc losses in PSCs through the energetic offsets between their HOMO and the perovskite VB. However, it is difficult to define either spiro-OMeTAD or PTAA as having ‘better electronic alignment’ with certain perovskites, as their energetics depend heavily on the perovskite used, on doping concentrations and environmental interactions.<sup>109</sup> It should hence become common practice to measure interfacial energetic alignments directly when tracking the impact of a novel HTL in a specific PSC architecture, but these measurements are currently not widely performed due to their difficulty. 

### 5.2 Mobility & conductivity 

The mobility and conductivity of organic semiconductors may vary with different deposition techniques, chemical purity levels, and exposure to light, oxygen and moisture – hence significant variations in measured values for the same material 



Fig. 10 Comparison of energetics at the HTL/perovskite interface between spiro-OMeTAD and PTAA. (a) Experimentally determined energy level diagram of spiro-OMeTAD deposited on MAPbI3. Reprinted with permission.<sup>82</sup> Copyright 2014, Royal Society of Chemistry. (b) Experimentally determined energy level diagram of (i) pristine and (ii) LiTFSI- and tBP-doped PTAA deposited on CsPbBr3, showing two possible scenarios which explain the vacuum level changes either with the presence of an interfacial or with band bending in the PTAA layer. Reprinted with permission.<sup>156</sup> Copyright 2017, AIP Publishing. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5175 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

Table 3 Mobility and conductivity values from literature for spiro-OMeTAD and PTAA films with various doping regimes 

|Material|Mobility (cm<sup>2 </sup>V<sup>�1 </sup>s<sup>�1</sup>)|Conductivity (S cm<sup>�1</sup>)|
|---|---|---|
|Spiro-OMeTAD (pristine)|2 �10<sup>�4 86</sup><br>B4.7 �10<sup>�5 109</sup>|B10<sup>�7</sup>–10<sup>�8 103</sup>|
|Spiro-OMeTAD (LiTFSI- and tBP-doped)<br>PTAA (pristine, high Mw)|4 �10<sup>�5 87</sup><br>1.5 �10<sup>�2 109 </sup>(aged 24 h in air)<br>B3–4 �10<sup>�5 152</sup><br>7.47 �10<sup>�5 164</sup>|2 �10<sup>�5 87,103</sup><br>B3.5 �10<sup>�5 101</sup><br>B10<sup>�9 109</sup><br>B10<sup>�5 109 </sup>(aged 24 h in air)<br>5.98 �10<sup>�7 155</sup>|
|PTAA (LiTFSI- and tBP-doped)|B5–6 �10<sup>�5 152</sup><br>4.28 �10<sup>�4 164</sup>|3.4 �10<sup>�5 162</sup>|
|PTAA (BCF doped)|5.72 �10<sup>�4 164</sup>|2.12 �10<sup>�5 155</sup>|



may be observed. Table 3 summarizes literature values for the mobility and conductivity of spiro-OMeTAD and PTAA with different doping regimes. Overall, pristine spiro-OMeTAD is suggested to have a slightly higher mobility, but similar conductivity to PTAA, and upon optimized doping conductivities continue to be very similar. The large improvements observed in both the mobility and conductivity of LiTFSI- and tBP-doped spiro-OMeTAD upon aging in air<sup>109</sup> are very interesting and further highlight the impact of environmental conditions on the functionality of spiro-OMeTAD and PTAA. 

When applied as HTLs in PSCs, the conductivity of both spiro-OMeTAD and PTAA directly limit the series resistance and FF of the device as they are orders of magnitude lower than the conductivity of perovskites.<sup>61</sup> Device efficiency can hence be improved by increasing either the mobility or the hole density in spiro-OMeTAD and PTAA, where mobility improvements are preferable as an increase in hole density can also increase the rate of non-radiative recombination in the HTL and especially at the perovskite/HTL interface.<sup>58,61</sup> 

Another strategy to decrease series resistance in PSCs is to reduce HTL thickness such that holes have to travel shorter distances, which also reduces their chance of recombination in the HTL. However, if a HTL is too thin this can allow contact between the perovskite and the electrode, which can cause shunts and increase recombination in the device.<sup>68,69,93,94</sup> This trend holds true for both spiro-OMeTAD and PTAA, although the optimal thickness for spiro-OMeTAD at B200<sup>93,94</sup> –370 nm<sup>68</sup> is much thicker than that for PTAA, which lies around 30–40 nm.<sup>44,150</sup> This suggests that the morphology of PTAA is more successful at preventing contact between the perovskite and electrode, potentially due to its polymeric nature. 

### 5.3 Doping mechanisms & effects 

When applied in n–i–p devices, spiro-OMeTAD and PTAA are conventionally doped with Li-TFSI, tBP, and other p-dopants, often at high molar ratios.<sup>114</sup> LiTFSI p-dopes the HTL by stabilizing radical cations created through the oxidation of the hole transport material,<sup>107</sup> which improves its conductivity<sup>103</sup> and can also affect mobility.<sup>89</sup> tBP is said to improve the morphology and distribution of other dopants through the HTL.<sup>81,112</sup> However, LiTFSI is hydrophilic and draws water into the device<sup>173</sup> which accelerates perovskite degradation, whilst tBP evaporates easily<sup>112</sup> and corrodes the perovskite.<sup>141</sup> Removing ionically doped HTLs 

from n–i–p PSCs has hence been shown to result in significant improvements in operating stability,<sup>104,177</sup> but at the cost of lower device efficiencies.<sup>102</sup> 

A direct comparison of the effects of most popular dopant LiTFSI on spiro-OMeTAD and PTAA is lacking. However, nonionic p-dopant BCF was shown to dope spiro-OMeTAD by ground-state integer charge transfer<sup>178</sup> whilst it dopes PTAA through the formation of charge-transfer complexes in the form of frustrated Lewis acid–base adducts.<sup>155</sup> These mechanisms do not generally apply to spiro-OMeTAD and PTAA doped with other dopants – for example, it has been suggested that spiro-OMeTAD forms charge-transfer complexes with p-dopant F4-TCNQ,<sup>179</sup> and that PTAA is oxidized by LiTFSI through integer charge transfer.<sup>159</sup> Whether organic semiconductors are doped by integer charge transfer or charge-transfer complex formation depends on the strength of the Coulomb interaction between the positive charge carrier on the semiconductor and the dopant anion, and hence doping mechanisms differ for each semiconductor-dopant pair.<sup>178</sup> 

Doping mechanisms in spiro-OMeTAD and PTAA are additionally complicated by the involvement of illumination as well as oxygen and moisture, which are often found to boost doping efficiency. It is well-established that exposure to both light and oxygen is necessary to build up a significant concentration of spiroOMeTAD<sup>+</sup> in LiTFSI-doped spiro-OMeTAD,<sup>101</sup> and although the doping mechanism of PTAA by LiTFSI is less clear, it is also suggested to require light exposure.<sup>159</sup> Although the doping mechanisms of PTAA are much less well-examined, for LiTFSIdoped spiro-OMeTAD multiple complex doping and de-doping mechanisms have been shown to exist. Hence, the large extent to which the conductivity of doped spiro-OMeTAD and PTAA is influenced by exposure to light, oxygen and moisture can be problematic for the reproducibility and stability of these materials. 

LiTFSI p-doping seems to increase the conductivity of both spiro-OMeTAD and PTAA by 2–3 orders of magnitude (Table 3), although this was not a direct comparison and different dopant concentrations were used. However, a direct comparison of BCF p-doping has been found to increase the conductivity of PTAA significantly more than that of spiro-OMeTAD, suggesting different doping interactions. It remains somewhat unclear what effects doping can have on mobility. Whilst Abate et al. argued that the ion pairs created by ionic p-dopants cannot improve mobility in terms of the screening of traps and reduction of electronic disorder,<sup>89</sup> Hawash et al. observe very 

5176 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

significant mobility improvements of more than 2 orders of magnitude when spiro-OMeTAD is doped with LiTFSI and tBP.<sup>109</sup> This could potentially be due to the rearrangement of spiro-OMeTAD into locally more crystalline regions facilitated by tBP, as proposed by Lamberti et al.<sup>111</sup> The mobility of PTAA has also been shown to be improved by about an order of magnitude by both LiTFSI and BCF doping.<sup>164</sup> It is possible that the influence of structural disorder on PTAA is somewhat different from its influence on spiro-OMeTAD. However, the general mechanism of whether and how dopants can affect mobility in these organic semiconductors remains unclear. 

### 5.4 Doped HTLs in PSCs 

Doping spiro-OMeTAD and PTAA to improve conductivity seems essential for PSC functionality when HTL thickness is on the order of tens-hundreds of nms. For applications in PSCs, the dopant concentrations generally used in both spiro-OMeTAD and PTAA are much higher than those in inorganic semiconductors. Especially since the moles of tBP added often approaches or exceeds the moles of the semiconductor. This means that dopants strongly affect material properties. Notably, the ideal molar concentration of LiTFSI and tBP is about 4 times higher in spiro-OMeTAD than it is in PTAA, and Bi et al. found that the effect of LiTFSI-doping of PTAA on PSC devices is much smaller and reaches an optimal point at a much lower concentration (Fig. 11a).<sup>174</sup> This suggests that the ideal compromise between conductivity and the adverse effects of dopants on morphology, recombination and possibly mobility is reached at lower LiTFSI concentrations in PTAA as compared to spiro-OMeTAD. This is perhaps partially because thinner layers of PTAA are generally 

used, which decreases the dependence of device efficiency on conductivity.<sup>69</sup> However, this drastic difference in dopant concentration seems specific to LiTFSI, as ideal dopant concentrations for both BCF (5%<sup>178</sup> for spiro-OMeTAD compared to 5%<sup>164</sup> or 8%<sup>155</sup> for PTAA) and F4-TCNQ (1.5%<sup>179</sup> for spiro-OMeTAD compared to 1%<sup>171</sup> for PTAA) are much more similar for spiro-OMeTAD and PTAA. 

Additionally, PSCs employing doped spiro-OMeTAD are conventionally aged in ambient or low humidity conditions for one or more days before electrode deposition in order to improve Voc and FF, whilst devices employing PTAA typically do not requiring aging.<sup>105</sup> Although there is evidence that the electronic quality of perovskites can improve with ambient storage,<sup>180</sup> Cho et al. describe this efficiency enhancement to also be due to improved conductivity and lower HOMO of spiro-OMeTAD after ambient storage.<sup>110</sup> It is possible that PTAA is not usually aged because similar processes do not occur in PTAA, or because PTAAbased PSCs are merely less sensitive to doping efficiency due to lower dopant concentrations and thicknesses. Therefore, PSCs employing PTAA offer the advantage of high efficiency without ageing, which is particularly useful if any of the underlying layers are particularly sensitive to ambient or low humidity conditions. 

### 5.5 Charge transfer & recombination dynamics at perovskite interfaces 

Spiro-OMeTAD and PTAA are extremely popular as HTLs for various types of perovskite-based electronic devices, so their charge transfer and recombination dynamics at the interface formed with perovskite materials are highly relevant. In studies 



Fig. 11 (a) Photovoltaic parameters of PSCs employing spiro-OMeTAD or PTAA HTLs doped with different concentrations of LiTFSI. Reprinted with permission.<sup>174</sup> Copyright 2014, World Scientific Publishing. (b) Atomic force microscopy images of spiro-OMeTAD and PTAA films, showing a significantly rougher surface for PTAA. (c) Plot of charge extraction (CE) against carrier lifetime, demonstrating same recombination mechanisms for each HTL, but slower recombination kinetics for higher Mw PTAA. Both reprinted with permission.<sup>166</sup> Copyright 2020, American Chemical Society. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5177 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

on PSCs, hole transfer from perovskite to HTL is found to occur 4 orders of magnitude faster for spiro-OMeTAD as compared to PTAA HTLs,<sup>157</sup> and although hole transfer is found to occur on a slightly faster timescale for high Mw PTAA, it is still significantly slower than spiro-OMeTAD.<sup>166</sup> As this comparatively slower hole transfer is common between PTAA and other polymeric HTLs, it has been ascribed to worse morphological contact between PTAA and the perovskite (Fig. 11b),<sup>166</sup> which requires charges to travel longer paths through the perovskite until they can be transferred.<sup>157</sup> 

When comparing the recombination kinetics in full devices employing spiro-OMeTAD and various Mw PTAA HTLs, Nia et al. showed that although the same type of recombination dominated regardless of the HTL used, the rate of recombination of devices employing spiro-OMeTAD HTLs lies between that of devices employing 10 kDa and 30 kDa PTAA HTLs, with the slowest recombination observed using 115 kDa PTAA (see Fig. 11c).<sup>166</sup> Interfacial recombination can be related to many different factors, from accumulation of charges at the interface to HTL/perovskite interactions to trap density in either the HTL or the perovskite. This makes it difficult to ascribe differences in recombination kinetics to specific molecular features of spiro-OMeTAD or PTAA. However, the direct measurement of interfacial recombination currents in full devices will be essential to understanding the effect of both new HTLs and new processing techniques on Voc in PSCs. Overall, holes seem to transfer to spiroOMeTAD faster, but high Mw PTAA HTLs seem to result in lower recombination in PSCs. 

### 5.6 Performance in PSCs 

Both spiro-OMeTAD and PTAA have proven essential to the development of PSCs, with the first four record efficiency devices employing either spiro-OMeTAD or PTAA HTLs.<sup>22,24,150,181</sup> Table 4 summarizes device data found in the literature in which PSCs employing spiro-OMeTAD and PTAA HTLs were directly compared. The most recent and highest efficiency devices fabricated by Nia et al.,<sup>166</sup> which are proposed to best reflect the dominant loss pathways in state-of-the-art PSCs, suggest that spiro-OMeTAD and very high Mw PTAA (both doped with LiTFSI and tBP) are able to produce similar device efficiencies. However, this very high Mw PTAA (B115 kDa) thus far is rarely used in PSCs, as Mw around B15–30 kDa are more common, which were shown to perform worse than spiro-OMeTAD in 

PSCs. This difference in efficiency, which seems to have become more pronounced as PSC architectures have become more advanced and other loss pathways have been eliminated, may explain why spiro-OMeTAD seems to have become more popular than PTAA in record efficiency devices in very recent years. 

Overall, this investigation into the efficiency of spiro-OMeTAD and PTAA as HTLs in PSCs demonstrates that although HTL conductivity and HOMO (measured in vacuum) are often treated as the only important parameters, many other HTL properties also strongly influence PSC efficiency. Energetic alignment and band bending as a result of interactions at the perovskite/HTL interface, charge transfer and recombination dynamics, interface morphology, and optimal HTL thickness all significantly affect device functionality. It hence remains difficult to pinpoint which exact molecular properties of spiro-OMeTAD and PTAA support or undermine their performance as HTLs, as all of these parameters can be affected by molecular structure in complex ways. However, this does emphasize the importance of carrying out energy level and recombination kinetics measurements on novel HTLs in complete devices in order to accurately understand their properties and performance. 

### 5.7 Stability 

Thermal stability. Although PTAA has a higher glass transition and melting temperature than spiro-OMeTAD, this should not necessarily be the parameter by which thermal stability of organic semiconductors in electronic devices should be measured, as both dopants and impurities can strongly affect glass transition temperatures.<sup>85</sup> Additionally, thermal degradation in the form of thermally activated ion migration from dopants<sup>138</sup> or the electrode,<sup>135</sup> or morphological degradation at the HTL/perovskite interface,<sup>144</sup> can also occur at temperatures far below the melting point. Kim et al. found that LiTFSI- and tBP-doped PTAA is more stably amorphous than doped spiro-OMeTAD upon thermal stressing at both 65 1C and 85 1C (Fig. 12a),<sup>144</sup> but pinhole formation was observed in both doped spiro-OMeTAD and PTAA films upon thermal stressing and ascribed to tBP evaporation.<sup>129</sup> This highlights the importance of the further development of alternative doping schemes or dopant-free HTLs for improved thermal stability. 

Moisture stability. As HTLs provide the main barrier between the perovskite layer and the environment, their response to moisture strongly affects PSC stability. Spiro-OMeTAD has been 

Table 4 Device parameters from literature directly comparing spiro-OMeTAD and PTAA HTLs 

|Authors|Material|Device architecture|PCE (%)|Voc|Jsc|FF|
|---|---|---|---|---|---|---|
|Heo et al.<sup>43</sup><br>|Spiro-OMeTAD|FTO/mp-TiO2/MAPbI3/spiro-OMeTAD (LiTFSI- and tBP-doped)/Au|8.4|0.855|16.7|58.8|
|Heo et al.<sup>43</sup><br>|PTAA|FTO/mp-TiO2/MAPbI3/PTAA (LiTFSI- and tBP-doped)/Au|12.0|0.997|16.5|72.7|
|Bi et al.<sup>174</sup><br>|Spiro-OMeTAD|FTO/bl-TiO2/mp-TiO2/MAPbI3/spiro-OMeTAD (LiTFSI- and tBP-doped)/Au|13.9|0.99|21.3|0.66|
|Bi et al.<sup>174</sup><br>|PTAA|FTO/bl-TiO2/mp-TiO2/MAPbI3/PTAA (LiTFSI- and tBP-doped)/Au|12.3|0.94|20.0|0.66|
|Nia et al.<sup>166</sup><br>|Spiro-OMeTAD|FTO/c-TiO2/mp-TiO2 (LiTFSI-doped)/FA1�x�yMAxCsy)Pb(I1�xBrx)3/<br>spiro-OMeTAD (LiTFSI- and tBP-doped)/Au|18.13|1.06|22.67|0.76|
|Nia et al.<sup>166</sup><br>|PTAA (10 kDa)|FTO/c-TiO2/mp-TiO2 (LiTFSI-doped)/FA1�x�yMAxCsy)Pb(I1�xBrx)3/<br>PTAA (LiTFSI- and tBP-doped)/Au|15.05|1.01|21.88|0.68|
|Nia et al.<sup>166</sup>|PTAA (115 kDa)|FTO/c-TiO2/mp-TiO2 (LiTFSI-doped)/FA1�x�yMAxCsy)Pb(I1�xBrx)3/<br>PTAA (LiTFSI- and tBP-doped)/Au|18.43|1.05|22.73|0.78|



5178 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 



Fig. 12 Comparison between the stability and effect on PSC degradation of spiro-OMeTAD and PTAA. (a) Optical microscope images of spiro-OMeTAD and PTAA thin films upon thermal stressing, showing crystallization in the spiro-OMeTAD film. Reprinted with permission.<sup>144</sup> Copyright 2017, Elsevier. (b) Diagram portraying the different effects high humidity environments have on spiro-OMeTAD and polymer HTLs and resulting impact on perovskite degradation. (c) Decrease in absorbance of MAPbI3 films indicating degradation over time in high humidity (98 � 2% RH) environments covered with different HTLs (i) without and (ii) with LiTFSI dopants. Both reprinted with permission.<sup>72</sup> Copyright 2015, American Chemical Society. (d) Color change of MAPbI3 films from black to yellow indicating degradation over time during thermal stressing at 80 1C in air covered with different HTLs. Reprinted with permission.<sup>173</sup> Copyright 2014, American Chemical Society. (e) Efficiency deterioration of PSCs employing different perovskite and spiro-OMeTAD or PTAA HTLs under operating conditions, demonstrating superior stability of PTAA-based PSCs. Reprinted with permission.<sup>144</sup> Copyright 2017, Elsevier. 

shown to crack upon exposure to high humidity environments, allowing water to directly degrade the perovskite, whilst PTAA only forms small holes, enabling better coverage and slower degradation of the perovskite as displayed in Fig. 12b.<sup>72</sup> This results in better moisture stability of perovskite films covered in PTAA as compared to those covered in spiro-OMeTAD (Fig. 12ci), especially when the HTLs are doped (Fig. 12cii).<sup>72</sup> The more pronounced effect of moisture on doped HTLs is likely due to the hygroscopicity of LiTFSI, present in a much higher concentration in spiro-OMeTAD. 

When their exposure to air is combined with thermal stressing at 80 1C, PTAA-covered perovskite degrades almost entirely within 24 hours, even faster than perovskite covered with spiro-OMeTAD (Fig. 12d).<sup>173</sup> Accordingly, PSCs employing PTAA as HTLs show a slightly faster decrease in efficiency under increasing temperatures in air than those using spiro-OMeTAD. It is interesting that the use of PTAA promotes the degradation of PSCs more than spiro-OMeTAD at high temperature in air, as it is both more thermally stable in nitrogen and more stable under high humidity conditions at room temperature as explained above. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5179 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

This suggests that the combination of heat and moisture may enable a unique degradation mechanism to occur in PTAA. Operational stability in PSCs. Under operation, PSCs are subjected to a combination of thermal, moisture, illumination, and electrical stresses which cause both reversible and irreversible device degradation. HTLs and their effect on PSC stability must hence ultimately be evaluated under complete operating conditions. Kim et al. showed that perovskite, spiro-OMeTAD and PTAA thin films are stable in isolation under thermal stressing and only degrade when interfaced,<sup>144</sup> suggesting that efficiency degradation can be mainly ascribed to deterioration of the perovskite/HTL interface as well as degradation reactions stemming specifically from contact of the perovskite with the HTL.<sup>111,127</sup> Under operating conditions at 85 1C, PSCs employing PTAA HTLs were shown to be significantly more stable than those with spiro-OMeTAD HTLs (Fig. 12e).<sup>144</sup> Mesquita et al. revealed that whilst both spiro-OMeTAD and PTAA showed significant losses in efficiency when operating under high temperatures (80 1C).<sup>129</sup> However, only 8.2% of this efficiency loss was irreversible after PTAA-based devices returned to room temperature post-thermal stressing, whilst in spiro-OMeTAD based devices 21.6% of efficiency was irreversibly lost. These irreversible efficiency losses was attributed to the evaporation of tBP and LiTFSI in both HTLs, and the higher stability of PTAA was hence ascribed to its lower dopant concentration.<sup>129</sup> However, the more stably amorphous morphology of PTAA, or a stronger interaction strength between PTAA and dopants which could reduce the rate of dopant evaporation, could also play a role. Finally, the thinner layer of PTAA used in these devices could also mean that a reduction in HTL conductivity due to dopant evaporation affects device efficiency less strongly. 

Overall, this research makes it clear that HTLs strongly affect PSC stability. Specifically, the mechanical qualities of spiroOMeTAD and PTAA turn out to be centrally important to protecting the perovskite under thermal and moisture stressing. Additionally, many of these stability problems could be linked to the presence of LiTFSI and tBP, which are generally caused by either the dopants themselves or by the byproducts of HTL oxidation, both of which can be hygroscopic,<sup>173</sup> cause morphological issues,<sup>81</sup> evaporate,<sup>129</sup> migrate through the PSC,<sup>138</sup> and/or participate in undesirable side reactions.<sup>111,127</sup> A significant portion of the instability of PSCs can hence be ascribed to the fact that spiro-OMeTAD and PTAA are most often doped in n–i–p devices. 

## 6. Directions for the next generation of HTLs 

### 6.1 Cost, abundance & reproducibility 

It should not be forgotten that the cost, natural abundance and reproducibility of HTLs are essential to their viability for commercialization. Unfortunately, both spiro-OMeTAD and PTAA are still prohibitively expensive, with spiro-OMeTAD carrying a usage cost of 23.96 $ per ml and PTAA carrying a usage cost of 19.80 $ per ml.<sup>182</sup> Spiro-OMeTAD requires a multistep synthesis process which utilizes costly materials such as 

Pd catalysts, particularly for the precursor containing the spiro core.<sup>183</sup> Similarly, the cost of PTAA is driven up by the degree of purification required after polymer synthesis.<sup>84</sup> Additionally, dopants such as LiTSFI can get quite expensive even when used in relatively small amounts. The synthetic cost of both materials unfortunately makes them much less favourable for commercial application, and no significantly cheaper synthetic routes have been discovered thus far. 

Additionally, both spiro-OMeTAD and PTAA suffer from reproducibility issues. The mobility of these layers can depend strongly on both purity and deposition process (see Sections 3.1 and 4.1), and it is especially difficult to control the batch-tobatch consistency of polymers such as PTAA. When the most popular doping scheme of LiTFSI and tBP is used, complex doping and de-doping processes exist that are strongly influenced by environmental factors such as illumination, humidity and oxygen exposure. Hence, HTL conductivity may vary significantly both between lab environments and within PSCs over time. Ideally, HTLs should also be synthesized and deposited by nontoxic, environmentally friendly processes. Currently the use of chlorobenzene in the deposition of spiro-OMeTAD has been cited as a major possible (eco)toxicity impact.<sup>184</sup> 

Even the most efficient HTL will ultimately not help bring PSCs towards commercialization if considerations of cost are ignored. This makes the discovery of alternative HTLs that can deliver the same functionality as doped spiro-OMeTAD and PTAA at a lower material cost essential for the successful commercialization of PSCs. Hence, the future development of materials should aim to produce a HTL that can be produced at low-cost with high purity, stable morphology and chemical composition, and ideally undoped or containing dopants that are insensitive to standard changes in environmental conditions. 

### 6.2 State of the art in novel HTLs 

Despite the enduring dominant popularity of spiro-OMeTAD and PTAA, significant progress has been made over the past few years in designing novel HTLs (for a thorough exploration of these, see detailed reviews by Urieta-Mora et al.<sup>185</sup> and Kim et al.<sup>186</sup> ). Many novel small molecule HTLs have been developed through gradual chemical tuning of existing HTLs. In PSCs, these new materials are often more stable than spiro-OMeTAD, but only occasionally result in better PCEs. A foremost example is TQ2, a quinoxaline-based molecule in which the conventional pi-spacer core is replaced with an acceptor group. When used in PSCs, TQ2 is able to produce slightly higher PCEs than spiroOMeTAD at a much lower synthetic cost.<sup>187</sup> Another popular alternative is 9-(2-ethylhexyl)-N,N,N,N-tetrakis(4-methoxyphenyl)9H-carbazole-2,7-diamine (also referred to as EH44), which is significantly more hydrophobic than spiro-OMeTAD and when doped with Li-free dopants, results in PSCs that retain 94% of their efficiency after 1000 hours continuous operation in ambient conditions.<sup>177</sup> 

Chemical modification of polymers has also been successfully used to synthesize alternative HTLs. Single fluorination of the PTAA side chain has been shown to downshift the HOMO of this HTL to create poly(bis(4-phenyl)(2-fluoro-4,6-dimethylphenyl)amine 

5180 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

(also referred to as 1F-PTAA), which was shown to significantly outperform PTAA in PSCs in terms of PCE.<sup>159</sup> Sidechain modification can be performed on any polymer to improve its suitability as a HTL – for example, Zhang et al. introduced diethylene glycol groups on the sidechain of carbazole- and benzothiadiazole-based copolymer to optimize its interactions at the perovskite interface for better hole transfer and mobility.<sup>188</sup> Older popular semiconducting polymers, such as the very high mobility P3HT, can also be used as HTLs in PSCs. However, P3HT shows high recombination rates at the perovskite interface, hence a passivation layer is required for it to function efficiently as a HTL.<sup>182</sup> 

The past few years have also seen the synthesis of entirely new classes of HTLs. Cross-linkable polymers were successfully employed as a dopant-free and particularly stable HTLs by Wang et al., but efficiencies don’t yet compete with spiroOMeTAD and PTAA.<sup>189</sup> Similarly, Hwang et al. were able to blend together a small molecule organic semiconductor and a conjugated polymer to create a stable HTL with strong adhesion at the perovskite interface, but this did not enable a competitive PCE.<sup>190</sup> Bilayer HTLs are another novel strategy in which materials with non-ideal HOMO, LUMO or interfacial interactions can complement each other. Particularly promising examples include NiOx/spiro-OMeTAD<sup>191</sup> and carbon nanotubes/spiro-OMeTAD,<sup>192</sup> but this strategy opens up far more opportunities for material exploration. Additionally, inorganic HTLs have long been proposed as a cheaper, more stable alternative to organic HTLs, but are difficult to deposit on top of perovskites as their solvent often degrades perovskites. However, some materials such as copper thiocyanate<sup>76</sup> and copper phthalocyanine<sup>193</sup> have been successfully used in PSCs with efficiencies exceeding 20% and good thermal stabilities through the development of new deposition methods. However, inorganic HTLs have overall only been moderately successful in PSCs despite their seemingly suitable properties as isolated materials such as good chemical stability, high conductivity, and suitable energetics. This may indicate some unfavourable interactions at the HTL/perovskite interface, which are potentially exacerbated by deposition challenges. 

In addition to this, a new type of HTL made from a monolayer of self-assembled molecules (SAMs) was very recently introduced in p–i–n PSCs by Magomedov et al.<sup>194</sup> This new HTL is unique in its ability to form a very thin (o2 nm) layer whilst still maintaining a uniform and complete barrier between the electrode and the perovskite, which enables very high (B80%) fill factors without doping. Additionally, the two sides of the SAM can be independently tuned to ensure both good surface coverage and a good energetic match with the perovskite. Although development has only just begun, perhaps it is this shift towards a new type of HTL that that will enable the next significant improvement in PSC efficiency. However, SAMs currently cannot be successfully deposited onto perovskites and hence are not suitable for n–i–p architectures. 

It is worth noting that none of these alternative HTLs have yet risen to the same level of popularity as spiro-OMeTAD and PTAA in n–i–p PSCs. This may partially be ascribed to the fact that groups working on PSCs may not always wish to spend lots 

of time optimizing the HTLs they use and hence prefer wellestablished options – however, it also suggests that results obtained with novel HTLs may not always be reproducible. 

### 6.3 Future HTL development 

It is clear that doped spiro-OMeTAD and PTAA cannot achieve the required stability or low enough cost for commercialization, especially with current doping schemes. We believe that the development of novel HTLs should be carried out along four areas of focus: (a) understanding and tuneability of interactions at the perovskite interface, (b) characterization within the full PSC device stack, (c) development of alternative dopants or dopant-free materials, and (d) focus on material cost. 

In order to further improve stability and efficiency, it will be critical to understand the environment created by chemical interaction between materials at the perovskite/HTL interface.<sup>195</sup> Considering the ongoing development of complex perovskite compositions with differing energetics, it is clear that any broadly successful HTL must also be tuneable to interact favourably with a range of different perovskite materials. Thus far, it is clear that molecular tuning of both small molecule and polymer HTL materials can be very successful at improving stability in PSCs, as well as adjusting energetics, hole mobility and morphology. However, it remains difficult to predict how these properties will affect how charges behave at the interface in terms of transfer kinetics and recombination, which critically affects PCE. 

Because of this, it is essential to characterize both the electronic properties and stability of any new materials within the full PSC device stack, where they have had the chance to interact with any neighbouring materials. Measurements on stand-alone thin films of organic semiconductors can be severely different to its actual properties within the device, as both interactions between the HTL and the perovskite and environmental factors can strongly influence fundamental HTL properties. Similarly, device stability measurements should ultimately be carried out at realistic operating conditions under elevated temperatures, humid environments, and at the maximum power point. 

Spiro-OMeTAD and PTAA measurements show that HTL doping can aid charge extraction in PSCs by improving energetic alignment with the perovskite, increasing mobility and conductivity in the HTL, and increasing the voltage drop through the perovskite layer, aiding charge extraction.<sup>61</sup> However, the increase in the concentration of holes in the HTL caused by doping may also increase recombination at the interface,<sup>58</sup> and the presence of dopant molecules may decrease mobility<sup>89</sup> or cause morphological problems.<sup>81</sup> Accordingly, alternative dopants often result in much better device stabilities,<sup>119,121,123,164</sup> and may in some cases provide a more facile path to developing more stable HTLs. This makes an understanding of doping mechanisms, effects and efficiencies centrally important to the further development of HTLs. The development of alternative dopants may go a long way in improving the stability of spiro-OMeTAD, PTAA and other existing HTLs. However, materials that are completely dopant-free are expected to have much better reproducibility and stability, so this should be the ultimate focus of novel HTL development. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5181 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

Finally, novel HTLs need to be significantly cheaper than spiro-OMeTAD and PTAA. Currently, novel small molecule HTLs are often produced by making small chemical modifications such as side chain replacements to spiro-OMeTAD. However, it is unlikely that small chemical modifications will significantly change the synthetic routes by which these molecules can be produced, and hence their production is expected to be similarly expensive. This may indicate that a stricter focus on cost is necessary within the field when judging new HTLs, and in fact candidates with lower synthetic costs<sup>187</sup> deserve more credit for fulfilling this requirement. 

## 7. Summary & outlook 

Over the past decade, research into how spiro-OMeTAD and PTAA function so well as HTLs has enabled a much deeper understanding of both the properties a HTL requires and the best ways to accurately measure these properties. Applying these lessons is critical to pushing PSCs towards their theoretical efficiency limits and better stabilities. So, which is the better HTL – spiro-OMeTAD or PTAA? Despite the seeming decrease in popularity of PTAA in record-efficiency n–i–p devices in recent years, direct device comparisons have given conflicting answers, so there is no straightforward choice. Both spiro-OMeTAD and PTAA have properties that inhibit their optimal functioning as HTLs, which include sub-optimal conductivity and significant recombination at the perovskite/HTL interface. Stability studies do indicate that PTAA has better thermal and mechanical stability, possibly due to the lower concentration of dopants generally used, leading to longer PSC lifetimes. However, both spiro-OMeTAD and PTAA suffer from a host of stability issues linked to dopant hydrophilicity, evaporation, migration, aggregation, and reactivity, making the development of alternative dopants a promising pathway to improving PSC stability. 

Additionally, despite their enduring popularity in research environments spiro-OMeTAD and PTAA remain prohibitively expensive for commercial PSCs. This, along with the potential for further efficiency and stability improvements, continues to motivate the search for new HTLs, which should be informed by the wealth of knowledge about spiro-OMeTAD and PTAA HTLs generated over the past decade. This review has revealed that these materials are successful not only due to their amorphous nature, energetics and conductivity, but the chemical interactions at the perovskite interface, the resulting charge transfer characteristics, and complex dopant interactions also play a significant role. Additionally, it highlights that material properties such as energy levels, conductivity, and stability should ideally be measured and compared within complete devices. It also shows that a significant amount of the stability problems associated with n–i–p PSCs can be traced back to the dopants used in spiro-OMeTAD and PTAA. Ultimately, the commercialization of PSCs will necessitate cheaper and more reproducible materials. 

All of this research is equally applicable to the many other contexts in which spiro-OMeTAD and PTAA are frequently used, 

including various types of LEDs, DSSCs, OFETs and even more novel applications in devices such as photodetectors. The deep understanding of the properties of these organic semiconductors that has been developed over the past decade, presented in this review, enables researchers to make predictions about how their will behave in a variety of electronic applications. 

The research examined in this review indicates that interfacial recombination at the HTL interface represents a bottleneck for further efficiency improvements in PSCs, and stability has long been established as a limiting factor on further PSC development. Within n–i–p PSCs, the HTL is uniquely positioned to address both of these problems. The development of new HTLs should be extended beyond its current focus on conductivity and HOMO improvements, and rather become more informed by an improved understanding of the various ways in which HTL interactions with the perovskite, dopants, and the environment affect device efficiency and stability. The great strides that have been made in understanding the fundamental properties of spiro-OMeTAD and PTAA over the past decade will be essential to developing the next generation of HTL materials. 

## Acronyms 

|BCF|Tris-(pentafluorophenyl)borane|
|---|---|
|CB|Conduction band<br>|
|Cs|Cesium|
|c-Si|Crystalline silicon|
|CTL|Charge transport layer|
|DSSC|Dye-sensitized solar cell|
|ETL|Electron transport layer|
|F4-TCNQ|2,3,5,6-Tetrafluoro-7,7,8,8-tetracyanoquinodi-<br>methane|
|FA|Formamidinium|
|FK209|Tris[2-(1H-pyrazol-1-yl)-(4-tert-butylpyridine)-<br>cobalt(III) tris(bis(trifluoromethylsulfonyl)imide)]|
|FF|Fill factor|
|HOMO|Highest occupied molecular orbital|
|HTL|Hole transport layer|
|Jsc|Short-circuit current density|
|LED|Light emitting diode|
|LiTFSI|Lithium bistrifluoromethanesulfonimidate|
|LUMO|Lowest unoccupied molecular orbital|
|MA|Methylammonium|
|OFET|Organic field-effect transistor|
|P3HT|Poly(3-hexylthiophene-2,5-diyl)|
|Pb|Lead|
|PCE|Power conversion efficiency|
|PESA|Photoelectron spectroscopy in air|
|PSC|Perovskite solar cell|
|PTAA|Poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine]|
|PV|Photovoltaic|
|QFLS|Quasi Fermi level splitting|
|SEM|Scanning electron microscopy|
|SIMS|Secondary ion mass spectrometry|



5182 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

|Sn|Tin|
|---|---|
|Spiro-OMeTAD|2,2<sup>0</sup>,7,7<sup>0</sup>-Tetrakis(N,N-p-dimethoxyphenyl-<br>amino)-9,9<sup>0</sup>-spirobifluorene|
|tBP|4-tert-Butylpyridine|
|ToF|Time-of-flight|
|TPBA|1,3,5,7-Tetrakis-(p-formylphenyl)-adamantane|
|VB|Valence band|
|Voc|Open-circuit voltage|



## Conflicts of interest 

There are no conflicts of interest to declare. 

## Acknowledgements 

S. A. H. acknowledges support from the EPSRC (grant numbers EP/R020574/1 and EP/R023581/1) and the UKRI Global Challenge Research Fund project SUNRISE (grant number EP/P032591/1). T. J. M. thanks the Royal Commission for the Exhibition of 1851 for their financial support through a Research Fellowship. 

## References 

- 1 European Union, World Energy Technology Outlook – 2050, 2012. 

- 2 IPCC, Global warming of 1.5 1C. An IPCC Special Report on the impacts of global warming of 1.5 1C above pre-industrial levels and related global greenhouse gas emission pathways, in the context of strengthening the global response to the threat of climate change, sustainable development, and efforts to eradicate poverty, ed. V. Masson-Delmotte, P. Zhai, H. O. Po¨rtner, D. Roberts, J. Skea, P.R. Shukla, A. Pirani, W., Moufouma-Okia, C. Pe´an, R. Pidcock, S. Connors, J. B. R. Matthews, Y. Chen, X. Zhou, M. I. Gomis, E. Lonnoy, T. Maycock, M. Tignor and T. Waterfield, 2018. 

- 3 C. F. Shih, T. Zhang, J. Li and C. Bai, Powering the Future with Liquid Sunshine, Joule, 2018, 2, 1925–1949. 

- 4 A. Polman, M. Knight, E. C. Garnett, B. Ehrler and W. C. Sinke, Photovoltaic materials: Present efficiencies and future challenges, Science, 2016, 352, aad4424. 

- 5 J. Yan and B. R. Saunders, Third-generation solar cells: a review and comparison of polymer:fullerene, hybrid polymer and perovskite solar cells, RSC Adv., 2014, 4, 43286–43314. 

- 6 W. E. I. Sha, X. Ren, L. Chen and W. C. H. Choy, The efficiency limit of CH3NH3PbI3 perovskite solar cells, Appl. Phys. Lett., 2015, 106, 221104. 

- 7 M. Saliba, J.-P. Correa-Baena, M. Gra¨tzel, A. Hagfeldt and A. Abate, Perovskite Solar Cells: From the Atomic Level to Film Quality and Device Performance, Angew. Chem., Int. Ed., 2018, 57, 2554–2569. 

- 8 A. D. Vos, Detailed balance limit of the efficiency of tandem solar cells, J. Phys. Appl. Phys., 1980, 13, 839–846. 

- 9 A. Kojima, K. Teshima, Y. Shirai and T. Miyasaka, Organometal Halide Perovskites as Visible-Light Sensitizers for Photovoltaic Cells, J. Am. Chem. Soc., 2009, 131, 6050–6051. 

- 10 B. O’Regan and M. Gratzel, A low-cost, high-efficiency solar cell based on dye-sensitized colloidal Ti02 films, Nature, 1991, 353, 737–740. 

- 11 H.-S. Kim, C.-R. Lee, J.-H. Im, K.-B. Lee, T. Moehl, A. Marchioro, S.-J. Moon, R. Humphry-Baker, J.-H. Yum, J. E. Moser, M. Gra¨tzel and N.-G. Park, Lead Iodide Perovskite Sensitized All-Solid-State Submicron Thin Film Mesoscopic Solar Cell with Efficiency Exceeding 9%, Sci. Rep., 2012, 2, 591. 

- 12 Q. Lin, A. Armin, R. C. R. Nagiri, P. L. Burn and P. Meredith, Electro-optics of perovskite solar cells, Nat. Photonics, 2015, 9, 106–112. 

- 13 N.-G. Park, Perovskite solar cells: an emerging photovoltaic technology, Mater. Today, 2015, 18, 65–72. 

- 14 M. M. Lee, J. Teuscher, T. Miyasaka, T. N. Murakami and H. J. Snaith, Efficient Hybrid Solar Cells Based on MesoSuperstructured Organometal Halide Perovskites, Science, 2012, 338, 643–647. 

- 15 L. Etgar, P. Gao, Z. Xue, Q. Peng, A. K. Chandiran, B. Liu, Md. K. Nazeeruddin and M. Gra¨tzel, Mesoscopic CH3NH3PbI3/TiO2 Heterojunction Solar Cells, J. Am. Chem. Soc., 2012, 134, 17396–17399. 

- 16 S. D. Stranks, G. E. Eperon, G. Grancini, C. Menelaou, M. J. P. Alcocer, T. Leijtens, L. M. Herz, A. Petrozza and H. J. Snaith, Electron-Hole Diffusion Lengths Exceeding 1 Micrometer in an Organometal Trihalide Perovskite Absorber, Science, 2013, 342, 341–344. 

- 17 G. Xing, N. Mathews, S. Sun, S. S. Lim, Y. M. Lam, M. Gratzel, S. Mhaisalkar and T. C. Sum, Long-Range Balanced Electronand Hole-Transport Lengths in Organic-Inorganic CH3NH3PbI3, Science, 2013, 342, 344–347. 

- 18 C. S. Ponseca, T. J. Savenije, M. Abdellah, K. Zheng, A. Yartsev, T. Pascher, T. Harlang, P. Chabera, T. Pullerits, A. Stepanov, J.-P. Wolf and V. Sundstro¨m, Organometal Halide Perovskite Solar Cell Materials Rationalized: Ultrafast Charge Generation, High and Microsecond-Long Balanced Mobilities, and Slow Recombination, J. Am. Chem. Soc., 2014, 136, 5189–5192. 

- 19 J. M. Ball, M. M. Lee, A. Hey and H. J. Snaith, Lowtemperature processed meso-superstructured to thin-film perovskite solar cells, Energy Environ. Sci., 2013, 6, 1739. 

- 20 M. Liu, M. B. Johnston and H. J. Snaith, Efficient planar heterojunction perovskite solar cells by vapour deposition, Nature, 2013, 501, 395–398. 

- 21 J.-Y. Jeng, Y.-F. Chiang, M.-H. Lee, S.-R. Peng, T.-F. Guo, P. Chen and T.-C. Wen, CH3NH3PbI3 Perovskite/Fullerene Planar-Heterojunction Hybrid Solar Cells, Adv. Mater., 2013, 25, 3727–3732. 

- 22 J. Burschka, N. Pellet, S.-J. Moon, R. Humphry-Baker, P. Gao, M. K. Nazeeruddin and M. Gra¨tzel, Sequential deposition as a route to high-performance perovskitesensitized solar cells, Nature, 2013, 499, 316–319. 

- 23 Z. Xiao, Q. Dong, C. Bi, Y. Shao, Y. Yuan and J. Huang, Solvent Annealing of Perovskite-Induced Crystal Growth for Photovoltaic-Device Efficiency Enhancement, Adv. Mater., 2014, 26, 6503–6509. 

- 24 N. J. Jeon, J. H. Noh, W. S. Yang, Y. C. Kim, S. Ryu, J. Seo and S. I. Seok, Compositional engineering of perovskite 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5183 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

materials for high-performance solar cells, Nature, 2015, 517, 476–480. 

- 25 M. Saliba, T. Matsui, J.-Y. Seo, K. Domanski, J.-P. CorreaBaena, M. K. Nazeeruddin, S. M. Zakeeruddin, W. Tress, A. Abate, A. Hagfeldt and M. Gra¨tzel, Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency, Energy Environ. Sci., 2016, 9, 1989–1997. 

- 26 M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J. M. Richter, M. Alsari, E. P. Booker, E. M. Hutter, A. J. Pearson, S. Lilliu, T. J. Savenije, H. Rensmo, G. Divitini, C. Ducati, R. H. Friend and S. D. Stranks, Maximizing and stabilizing luminescence from halide perovskites with potassium passivation, Nature, 2018, 555, 497–501. 

- 27 D. Luo, W. Yang, Z. Wang, A. Sadhanala, Q. Hu, R. Su, R. Shivanna, G. F. Trindade, J. F. Watts, Z. Xu, T. Liu, K. Chen, F. Ye, P. Wu, L. Zhao, J. Wu, Y. Tu, Y. Zhang, X. Yang, W. Zhang, R. H. Friend, Q. Gong, H. J. Snaith and R. Zhu, Enhanced photovoltage for inverted planar heterojunction perovskite solar cells, Science, 2018, 360, 1442–1446. 

- 28 M. Batmunkh, K. Vimalanathan, C. Wu, A. S. R. Bati, L. Yu, S. A. Tawfik, M. J. Ford, T. J. Macdonald, C. L. Raston, S. Priya, C. T. Gibson and J. G. Shapter, Efficient Production of Phosphorene Nanosheets via Shear Stress Mediated Exfoliation for Low-Temperature Perovskite Solar Cells, Small Methods, 2019, 3, 1800521. 

- 29 T. J. Macdonald, M. Batmunkh, C. Lin, J. Kim, D. D. Tune, F. Ambroz, X. Li, S. Xu, C. Sol, I. Papakonstantinou, M. A. McLachlan, I. P. Parkin, J. G. Shapter and J. R. Durrant, Origin of Performance Enhancement in TiO2 -Carbon Nanotube Composite Perovskite Solar Cells, Small Methods, 2019, 3, 1900164. 

- 30 C. Lin, J. Lee, J. Kim, T. J. Macdonald, J. Ngiam, B. Xu, M. Daboczi, W. Xu, S. Pont, B. Park, H. Kang, J. Kim, D. J. Payne, K. Lee, J. R. Durrant and M. A. McLachlan, Origin of Open-Circuit Voltage Enhancements in Planar Perovskite Solar Cells Induced by Addition of Bulky Organic Cations, Adv. Funct. Mater., 2020, 30, 1906763. 

- 31 A. S. R. Bati, M. Hao, T. J. Macdonald, M. Batmunkh, Y. Yamauchi, L. Wang and J. G. Shapter, 1D-2D Synergistic MXene-Nanotubes Hybrids for Efficient Perovskite Solar Cells, Small, 2021, 2101925. 

- 32 M. Saliba, T. Matsui, K. Domanski, J.-Y. Seo, A. Ummadisingu, S. M. Zakeeruddin, J.-P. Correa-Baena, W. R. Tress, A. Abate, A. Hagfeldt and M. Gratzel, Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance, Science, 2016, 354, 206–209. 

- 33 N. Aristidou, I. Sanchez-Molina, T. Chotchuangchutchaval, M. Brown, L. Martinez, T. Rath and S. A. Haque, The Role of Oxygen in the Degradation of Methylammonium Lead Trihalide Perovskite Photoactive Layers, Angew. Chem., Int. Ed., 2015, 54, 8208–8212. 

- 34 N. Aristidou, C. Eames, I. Sanchez-Molina, X. Bu, J. Kosco, M. S. Islam and S. A. Haque, Fast oxygen diffusion and iodide defects mediate oxygen-induced degradation of perovskite solar cells, Nat. Commun., 2017, 8, 15218. 

- 35 D. Bryant, N. Aristidou, S. Pont, I. Sanchez-Molina, T. Chotchunangatchaval, S. Wheeler, J. R. Durrant and S. A. Haque, Light and oxygen induced degradation limits the operational stability of methylammonium lead triiodide perovskite solar cells, Energy Environ. Sci., 2016, 9, 1655–1660. 

- 36 F. T. F. O’Mahony, Y. H. Lee, C. Jellett, S. Dmitrov, D. T. J. Bryant, J. R. Durrant, B. C. O’Regan, M. Graetzel, M. K. Nazeeruddin and S. A. Haque, Improved environmental stability of organic lead trihalide perovskite-based photoactive-layers in the presence of mesoporous TiO2, J. Mater. Chem. A, 2015, 3, 7219–7223. 

- 37 S. Pont, D. Bryant, C.-T. Lin, N. Aristidou, S. Wheeler, X. Ma, R. Godin, S. A. Haque and J. R. Durrant, Tuning CH3NH3 Pb(I1�xBrx)3 perovskite oxygen stability in thin films and solar cells, J. Mater. Chem. A, 2017, 5, 9553–9560. 

- 38 C. M. Wolff, P. Caprioglio, M. Stolterfoht and D. Neher, Nonradiative Recombination in Perovskite Solar Cells: The Role of Interfaces, Adv. Mater., 2019, 31, 1902762. 

- 39 J. Jeong, M. Kim, J. Seo, H. Lu, P. Ahlawat, A. Mishra, Y. Yang, M. A. Hope, F. T. Eickemeyer, M. Kim, Y. J. Yoon, I. W. Choi, B. P. Darwich, S. J. Choi, Y. Jo, J. H. Lee, B. Walker, S. M. Zakeeruddin, L. Emsley, U. Rothlisberger, A. Hagfeldt, D. S. Kim, M. Gra¨tzel and J. Y. Kim, Pseudohalide anion engineering for a-FAPbI3 perovskite solar cells, Nature, 2021, 592, 381–385. 

- 40 J. J. Yoo, S. Wieghold, M. C. Sponseller, M. R. Chua, S. N. Bertram, N. T. P. Hartono, J. S. Tresback, E. C. Hansen, J.-P. Correa-Baena, V. Bulovic´, T. Buonassisi, S. S. Shin and M. G. Bawendi, An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss, Energy Environ. Sci., 2019, 12, 2192–2199. 

- 41 Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin and J. You, Surface passivation of perovskite film for efficient solar cells, Nat. Photonics, 2019, 13, 460–466. 

- 42 U. Bach, D. Lupo, P. Comte, J. E. Moser, F. Weisso¨rtel, J. Salbeck, H. Spreitzer and M. Gra¨tzel, Solid-state dyesensitized mesoporous TiO2 solar cells with high photon-toelectron conversion efficiencies, Nature, 1998, 395, 583–585. 

- 43 J. H. Heo, S. H. Im, J. H. Noh, T. N. Mandal, C.-S. Lim, J. A. Chang, Y. H. Lee, H. Kim, A. Sarkar, Md. K. Nazeeruddin, M. Gra¨tzel and S. I. Seok, Efficient inorganic–organic hybrid heterojunction solar cells containing perovskite compound and polymeric hole conductors, Nat. Photonics, 2013, 7, 486–491. 

- 44 W. S. Yang, B.-W. Park, E. H. Jung, N. J. Jeon, Y. C. Kim, D. U. Lee, S. S. Shin, J. Seo, E. K. Kim, J. H. Noh and S. I. Seok, Iodide management in formamidinium-lead-halide–based perovskite layers for efficient solar cells, Science, 2017, 356, 1376–1379. 

- 45 H. Li, K. Fu, P. P. Boix, L. H. Wong, A. Hagfeldt, M. Gra¨tzel, S. G. Mhaisalkar and A. C. Grimsdale, Hole-Transporting Small Molecules Based on Thiophene Cores for High Efficiency Perovskite Solar Cells, ChemSusChem, 2014, 7, 3420–3425. 

- 46 Y. Liu, Q. Chen, H.-S. Duan, H. Zhou, Y. (Michael) Yang, H. Chen, S. Luo, T.-B. Song, L. Dou, Z. Hong and Y. Yang, 

5184 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

A dopant-free organic hole transport material for efficient planar heterojunction perovskite solar cells, J. Mater. Chem. A, 2015, 3, 11940–11947. 

- 47 M. Saliba, S. Orlandi, T. Matsui, S. Aghazada, M. Cavazzini, J.-P. Correa-Baena, P. Gao, R. Scopelliti, E. Mosconi, K.-H. Dahmen, F. De Angelis, A. Abate, A. Hagfeldt, G. Pozzi, M. Graetzel and M. K. Nazeeruddin, A molecularly engineered hole-transporting material for efficient perovskite solar cells, Nat. Energy, 2016, 1, 15017. 

- 48 Z. H. Bakr, Q. Wali, A. Fakharuddin, L. Schmidt-Mende, T. M. Brown and R. Jose, Advances in hole transport materials engineering for stable and efficient perovskite solar cells, Nano Energy, 2017, 34, 271–305. 

- 49 O. A. Jaramillo-Quintero, R. S. Sanchez, M. Rincon and I. Mora-Sero, Bright Visible-Infrared Light Emitting Diodes Based on Hybrid Halide Perovskite with Spiro-OMeTAD as a Hole-Injecting Layer, J. Phys. Chem. Lett., 2015, 6, 1883–1890. 

- 50 Y.-S. Liu, S. Guo, J. Feng, Y.-F. Liu, Y.-G. Bi, D. Yin, X.-L. Zhang and H.-B. Sun, Enhanced efficiency of all-inorganic perovskite light-emitting diodes by using F4-TCNQ-doped PTAA as a hole-transport layer, Opt. Lett., 2019, 44, 4817–4820. 

- 51 N. Zhang, G. Tian, X. Wu, W. Qin, M. Liu, Y. Li, H. Rui, L. Li, Y. Hua and S. Yin, Low driving voltage and enhanced performance of solution-processed blue flexible organic light-emitting diode with PTAA/AgNWs/PTAA composite hole injection layers, J. Phys. Appl. Phys., 2019, 52, 315102. 

- 52 C.-Y. Hsu, Y.-C. Chen, R. Y.-Y. Lin, K.-C. Ho and J. T. Lin, Solid-state dye-sensitized solar cells based on spirofluorene (spiro-OMeTAD) and arylamines as hole transporting materials, Phys. Chem. Chem. Phys., 2012, 14, 14099. 

- 53 J. Veres, S. Ogier, G. Lloyd and D. de Leeuw, Gate Insulators in Organic Field-Effect Transistors, Chem. Mater., 2004, 16, 4543–4555. 

- 54 J. Li, S. Yuan, G. Tang, G. Li, D. Liu, J. Li, X. Hu, Y. Liu, J. Li, Z. Yang, S. F. Liu, Z. Liu, F. Gao and F. Yan, High-Performance, Self-Powered Photodetectors Based on Perovskite and Graphene, ACS Appl. Mater. Interfaces, 2017, 9, 42779–42787. 

- 55 A. Bera, A. Das Mahapatra, S. Mondal and D. Basak, Sb2S3/ Spiro-OMeTAD Inorganic–Organic Hybrid p–n Junction Diode for High Performance Self-Powered Photodetector, ACS Appl. Mater. Interfaces, 2016, 8, 34506–34512. 

- 56 V. Sarritzu, N. Sestu, D. Marongiu, X. Chang, S. Masi, A. Rizzo, S. Colella, F. Quochi, M. Saba, A. Mura and G. Bongiovanni, Optical determination of Shockley-ReadHall and interface recombination currents in hybrid perovskites, Sci. Rep., 2017, 7, 44629. 

- 57 M. Stolterfoht, P. Caprioglio, C. Wolff, J. Ma´rquez Prieto, J. Nordmann, S. Zhang, D. Rothhardt, U. Ho¨rmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold and D. Neher, The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells, Energy Environ. Sci., 2019, 12, 2778–2788. 

- 58 I. Gelmetti, N. Montcada, A. Pe´rez-Rodrı´guez, E. Barrena, C. Ocal, I. Garcı´a-Benito, A. Molina-Ontoria, N. Martı´n, A. Vidal-Ferran and E. Palomares, Energy Alignment and Recombination in Perovskite Solar Cells: Weighted Influence on the Open Circuit Voltage, Energy Environ. Sci., 2019, 12, 1309–1316. 

- 59 Z. Hawash, L. K. Ono and Y. Qi, Recent Advances in SpiroMeOTAD Hole Transport Material and Its Applications in Organic-Inorganic Halide Perovskite Solar Cells, Adv. Mater. Interfaces, 2018, 5, 1700623. 

- 60 N. E. Courtier, J. M. Cave, J. M. Foster, A. B. Walker and G. Richardson, How transport layer properties affect perovskite solar cell performance: insights from a coupled charge transport/ion migration model, Energy Environ. Sci., 2019, 12, 396–409. 

- 61 V. M. Le Corre, M. Stolterfoht, L. Perdigo´n Toro, M. Feuerstein, C. Wolff, L. Gil-Escrig, H. J. Bolink, D. Neher and L. J. A. Koster, Charge Transport Layers Limiting the Efficiency of Perovskite Solar Cells: How To Optimize Conductivity, Doping, and Thickness, ACS Appl. Energy Mater., 2019, 2, 6280–6287. 

- 62 T. Kirchartz, High open-circuit voltages in lead-halide perovskite solar cells: experiment, theory and open questions, Philos. Trans. R. Soc., A, 2019, 377, 20180286. 

- 63 R. J. E. Westbrook, Dr I. Sanchez-Molina, Dr J. Manuel Marin-Beloqui, Dr H. Bronstein and Dr S. A. Haque, Effect of Interfacial Energetics on Charge Transfer from Lead Halide Perovskite to Organic Hole Conductors, J. Phys. Chem. C, 2018, 122, 1326–1332. 

- 64 J. Wang, K. Liu, L. Ma and X. Zhan, Triarylamine: Versatile Platform for Organic, Dye-Sensitized, and Perovskite Solar Cells, Chem. Rev., 2016, 116, 14675–14725. 

- 65 V. M. Le Corre, M. Stolterfoht, L. Perdigo´n Toro, M. Feuerstein, C. Wolff, L. Gil-Escrig, H. J. Bolink, D. Neher and L. J. A. Koster, Charge Transport Layers Limiting the Efficiency of Perovskite Solar Cells: How To Optimize Conductivity, Doping, and Thickness, ACS Appl. Energy Mater., 2019, 2, 6280–6287. 

- 66 D. Głowienka, D. Zhang, F. Di Giacomo, M. Najafi, S. Veenstra, J. Szmytkowski and Y. Galagan, Role of surface recombination in perovskite solar cells at the interface of HTL/CH3NH3PbI3, Nano Energy, 2020, 67, 104186. 

- 67 D. B. Khadka, Y. Shirai, M. Yanagida, J. W. Ryan and K. Miyano, Exploring the effects of interfacial carrier transport layers on device performance and optoelectronic properties of planar perovskite solar cells, J. Mater. Chem. C, 2017, 5, 8819–8827. 

- 68 I. Grill, M. F. Aygu¨ler, T. Bein, P. Docampo, N. F. Hartmann, M. Handloser and A. Hartschuh, Charge Transport Limitations in Perovskite Solar Cells: The Effect of Charge Extraction Layers, ACS Appl. Mater. Interfaces, 2017, 9, 37655–37661. 

- 69 M. Stolterfoht, C. M. Wolff, Y. Amir, A. Paulke, L. Perdigon, P. Caprioglio and D. Neher, Approaching the Fill Factor Shockley Queisser Limit in Stable, Dopant-Free Triple Cation Perovskite Solar Cells, Energy Environ. Sci., 2017, 10, 1530. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5185 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

- 70 Y. Da, Y. Xuan and Q. Li, Quantifying energy losses in planar perovskite solar cells, Sol. Energy Mater. Sol. Cells, 2018, 174, 206–213. 

- 71 N.-G. Park, M. Gra¨tzel, T. Miyasaka, K. Zhu and K. Emery, Towards stable and commercially available perovskite solar cells, Nat. Energy, 2016, 1, 16152. 

- 72 J. Yang, B. D. Siempelkamp, D. Liu and T. L. Kelly, Investigation of CH3NH3PbI3 Degradation Rates and Mechanisms in Controlled Humidity Environments Using in Situ Techniques, ACS Nano, 2015, 9, 1955–1963. 

- 73 S. Ryu, J. H. Noh, N. J. Jeon, Y. Chan Kim, W. S. Yang, J. Seo and S. I. Seok, Voltage output of efficient perovskite solar cells with high open-circuit voltage and fill factor, Energy Environ. Sci., 2014, 7, 2614–2618. 

- 74 J. H. Heo, D. H. Song and S. H. Im, Planar CH3NH3 PbBr3 Hybrid Solar Cells with 10.4% Power Conversion Efficiency, Fabricated by Controlled Crystallization in the Spin-Coating Process, Adv. Mater., 2014, 26, 8179–8183. 

- 75 J. A. Christians, R. C. M. Fung and P. V. Kamat, An Inorganic Hole Conductor for Organo-Lead Halide Perovskite Solar Cells. Improved Hole Conductivity with Copper Iodide, J. Am. Chem. Soc., 2014, 136, 758–764. 

- 76 N. Arora, M. I. Dar, A. Hinderhofer, N. Pellet, F. Schreiber, S. M. Zakeeruddin and M. Gra¨tzel, Perovskite solar cells with CuSCN hole extraction layers yield stabilized efficiencies greater than 20%, Science, 2017, 358, 768–771. 

- 77 F. E. Goodson, S. I. Hauck and J. F. Hartwig, PalladiumCatalyzed Synthesis of Pure, Regiodefined Polymeric Triarylamines, J. Am. Chem. Soc., 1999, 121, 7527–7539. 

- 78 J. Salbeck, N. Yu, J. Bauer, F. Weisso¨rtel and H. Bestgen, Low molecular organic glasses for blue electroluminescence, Synth. Met., 1997, 91, 209–215. 

- 79 J. H. Noh, N. J. Jeon, Y. C. Choi, Md. K. Nazeeruddin, M. Gra¨tzel and S. I. Seok, Nanostructured TiO2/CH3NH3PbI3 heterojunction solar cells employing spiro-OMeTAD/Cocomplex as hole-transporting material, J. Mater. Chem. A, 2013, 1, 11842. 

- 80 L. K. Ono, S. R. Raga, M. Remeika, A. J. Winchester, A. Gabe and Y. Qi, Pinhole-free hole transport layers significantly improve the stability of MAPbI 3 -based perovskite solar cells under operating conditions, J. Mater. Chem. A, 2015, 3, 15451–15456. 

- 81 E. J. Juarez-Perez, M. R. Leyden, S. Wang, L. K. Ono, Z. Hawash and Y. Qi, Role of the Dopants on the Morphological and Transport Properties of Spiro-MeOTAD Hole Transport Layer, Chem. Mater., 2016, 28, 5702–5709. 

- 82 P. Schulz, E. Edri, S. Kirmayer, G. Hodes, D. Cahen and A. Kahn, Interface energetics in organo-metal halide perovskite-based photovoltaic cells, Energy Environ. Sci., 2014, 7, 1377. 

- 83 T. Zhang, J. Wu, P. Zhang, W. Ahmad, Y. Wang, M. Alqahtani, H. Chen, C. Gao, Z. D. Chen, Z. Wang and S. Li, High Speed and Stable Solution-Processed Triple Cation Perovskite Photodetectors, Adv. Opt. Mater., 2018, 6, 1701341. 

- 84 V. Coropceanu, J. Cornil, D. A. da Silva Filho, Y. Olivier, R. Silbey and J.-L. Bre´das, Charge Transport in Organic Semiconductors, Chem. Rev., 2007, 107, 926–952. 

- 85 T. Malinauskas, D. Tomkute-Luksiene, R. Sens, M. Daskeviciene, R. Send, H. Wonneberger, V. Jankauskas, I. Bruder and V. Getautis, Enhancing Thermal Stability and Lifetime of Solid-State Dye-Sensitized Solar Cells via Molecular Engineering of the Hole-Transporting Material Spiro-OMeTAD, ACS Appl. Mater. Interfaces, 2015, 7, 11107–11116. 

- 86 D. Poplavskyy and J. Nelson, Nondispersive hole transport in amorphous films of methoxy-spirofluorene-arylamine organic compound, J. Appl. Phys., 2003, 93, 341–346. 

- 87 T. Leijtens, I.-K. Ding, T. Giovenzana, J. T. Bloking, M. D. McGehee and A. Sellinger, Hole Transport Materials with Low Glass Transition Temperatures and High Solubility for Application in Solid-State Dye-Sensitized Solar Cells, ACS Nano, 2012, 6, 1455–1462. 

- 88 H. J. Snaith and M. Gra¨tzel, Enhanced charge mobility in a molecular hole transporter via addition of redox inactive ionic dopant: Implication to dye-sensitized solar cells, Appl. Phys. Lett., 2006, 89, 262114. 

- 89 A. Abate, D. R. Staff, D. J. Hollman, H. J. Snaith and A. B. Walker, Influence of ionizing dopants on charge transport in organic semiconductors, Phys. Chem. Chem. Phys., 2014, 16, 1132–1138. 

- 90 J. A. Ro¨hr, X. Shi, S. A. Haque, T. Kirchartz and J. Nelson, Charge Transport in Spiro-OMeTAD Investigated through Space-Charge-Limited Current Measurements, Phys. Rev. Appl., 2018, 9, 044017. 

- 91 W. H. Nguyen, C. D. Bailie, E. L. Unger and M. D. McGehee, Enhancing the Hole-Conductivity of Spiro-OMeTAD without Oxygen or Lithium Salts by Using Spiro(TFSI) 2 in Perovskite and Dye-Sensitized Solar Cells, J. Am. Chem. Soc., 2014, 136, 10996–11001. 

- 92 R. S. Sanchez and E. Mas-Marza, Light-induced effects on Spiro-OMeTAD films and hybrid lead halide perovskite solar cells, Sol. Energy Mater. Sol. Cells, 2016, 158, 189–194. 

- 93 G.-W. Kim, D. V. Shinde and T. Park, Thickness of the hole transport layer in perovskite solar cells: performance versus reproducibility, RSC Adv., 2015, 5, 99356–99360. 

- 94 N. Marinova, W. Tress, R. Humphry-Baker, M. I. Dar, V. Bojinov, S. M. Zakeeruddin, M. K. Nazeeruddin and M. Gra¨tzel, Light Harvesting and Charge Recombination in CH3NH3PbI3 Perovskite Solar Cells Studied by Hole Transport Layer Thickness Variation, ACS Nano, 2015, 9, 4200–4209. 

- 95 C. S. Ponseca, E. M. Hutter, P. Piatkowski, B. Cohen, T. Pascher, A. Douhal, A. Yartsev, V. Sundstro¨m and T. J. Savenije, Mechanism of Charge Transfer and Recombination Dynamics in Organo Metal Halide Perovskites and Organic Electrodes, PCBM, and Spiro-OMeTAD: Role of Dark Carriers, J. Am. Chem. Soc., 2015, 137, 16043–16048. 

- 96 D. Bi, L. Yang, G. Boschloo, A. Hagfeldt and E. M. J. Johansson, Effect of Different Hole Transport Materials on Recombination in CH3NH3PbI3 Perovskite-Sensitized Mesoscopic Solar Cells, J. Phys. Chem. Lett., 2013, 4, 1532–1536. 

- 97 A. Torres and L. G. C. Rego, Surface Effects and Adsorption of Methoxy Anchors on Hybrid Lead Iodide Perovskites: Insights for Spiro-MeOTAD Attachment, J. Phys. Chem. C, 2014, 118, 26947–26954. 

5186 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

- 98 M. Pfeiffer, K. Leo, X. Zhou, J. S. Huang, M. Hofmann, A. Werner and J. Blochwitz-Nimoth, Doped organic semiconductors: Physics and application in light emitting diodes, Org. Electron., 2003, 4, 89–103. 

- 99 U. B. Cappel, T. Daeneke and U. Bach, Oxygen-Induced Doping of Spiro-MeOTAD in Solid-State Dye-Sensitized Solar Cells and Its Impact on Device Performance, Nano Lett., 2012, 12, 4925–4931. 

- 100 S. Fantacci, F. De Angelis, M. K. Nazeeruddin and M. Gra¨tzel, Electronic and Optical Properties of the Spiro-MeOTAD Hole Conductor in Its Neutral and Oxidized Forms: A DFT/TDDFT Investigation, J. Phys. Chem. C, 2011, 115, 23126–23133. 

- 101 S. Wang, W. Yuan and Y. S. Meng, Spectrum-Dependent Spiro-OMeTAD Oxidization Mechanism in Perovskite Solar Cells, ACS Appl. Mater. Interfaces, 2015, 7, 24791–24798. 

- 102 T. H. Schloemer, J. A. Christians, J. M. Luther and A. Sellinger, Doping strategies for small molecule organic hole-transport materials: impacts on perovskite solar cell performance and stability, Chem. Sci., 2019, 10, 1904–1935. 

- 103 H. J. Snaith and M. Gra¨tzel, Enhanced charge mobility in a molecular hole transporter via addition of redox inactive ionic dopant: Implication to dye-sensitized solar cells, Appl. Phys. Lett., 2006, 89, 262114. 

- 104 H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee and S. I. Seok, Efficient, stable solar cells by using inherent bandgap of a-phase formamidinium lead iodide, Science, 2019, 366, 749–753. 

- 105 M. Saliba, J.-P. Correa-Baena, C. M. Wolff, M. Stolterfoht, N. Phung, S. Albrecht, D. Neher and A. Abate, How to Make over 20% Efficient Perovskite Solar Cells in Regular (n–i–p) and Inverted (p–i–n) Architectures, Chem. Mater., 2018, 30, 4193–4201. 

- 106 R. Scho¨lin, M. H. Karlsson, S. K. Eriksson, H. Siegbahn, E. M. J. Johansson and H. Rensmo, Energy Level Shifts in Spiro-OMeTAD Molecular Thin Films When Adding Li-TFSI, J. Phys. Chem. C, 2012, 116, 26300–26305. 

- 107 A. Abate, T. Leijtens, S. Pathak, J. Teuscher, R. Avolio, M. E. Errico, J. Kirkpatrik, J. M. Ball, P. Docampo, I. McPherson and H. J. Snaith, Lithium salts as ‘‘redox active’’ p-type dopants for organic semiconductors and their impact in solid-state dye-sensitized solar cells, Phys. Chem. Chem. Phys., 2013, 15, 2572. 

- 108 Z. Hawash, L. K. Ono, S. R. Raga, M. V. Lee and Y. Qi, Air-Exposure Induced Dopant Redistribution and Energy Level Shifts in Spin-Coated Spiro-MeOTAD Films, Chem. Mater., 2015, 27, 562–569. 

- 109 Z. Hawash, L. K. Ono and Y. Qi, Moisture and Oxygen Enhance Conductivity of LiTFSI-Doped Spiro-MeOTAD Hole Transport Layer in Perovskite Solar Cells, Adv. Mater. Interfaces, 2016, 3, 1600117. 

- 110 Y. Cho, H. D. Kim, J. Zheng, J. Bing, Y. Li, M. Zhang, M. A. Green, A. Wakamiya, S. Huang, H. Ohkita and A. W. Y. Ho-Baillie, Elucidating Mechanisms behind Ambient Storage-Induced Efficiency Improvements in Perovskite Solar Cells, ACS Energy Lett., 2021, 6, 925–933. 

- 111 F. Lamberti, T. Gatti, E. Cescon, R. Sorrentino, A. Rizzo, E. Menna, G. Meneghesso, M. Meneghetti, A. Petrozza and L. Franco, Evidence of Spiro-OMeTAD De-doping by tertButylpyridine Additive in Hole-Transporting Layers for Perovskite Solar Cells, Chem, 2019, 5, 1806–1817. 

- 112 S. Wang, M. Sina, P. Parikh, T. Uekert, B. Shahbazian, A. Devaraj and Y. S. Meng, Role of 4- tert-Butylpyridine as a Hole Transport Layer Morphological Controller in Perovskite Solar Cells, Nano Lett., 2016, 16, 5594–5600. 

- 113 J. Kru¨ger, R. Plass, L. Cevey, M. Piccirelli, M. Gra¨tzel and U. Bach, High efficiency solid-state photovoltaic device due to inhibition of interface charge recombination, Appl. Phys. Lett., 2001, 79, 2085–2087. 

- 114 S. Wang, Z. Huang, X. Wang, Y. Li, M. Gu¨nther, S. Valenzuela, P. Parikh, A. Cabreros, W. Xiong and Y. S. Meng, Unveiling the Role of tBP–LiTFSI Complexes in Perovskite Solar Cells, J. Am. Chem. Soc., 2018, 140, 16720–16730. 

- 115 S. N. Habisreutinger, N. K. Noel, H. J. Snaith and R. J. Nicholas, Investigating the Role of 4-tert Butylpyridine in Perovskite Solar Cells, Adv. Energy Mater., 2017, 7, 1601079. 

- 116 N. K. Noel, A. Abate, S. D. Stranks, E. S. Parrott, V. M. Burlakov, A. Goriely and H. J. Snaith, Enhanced Photoluminescence and Solar Cell Performance via Lewis Base Passivation of Organic–Inorganic Lead Halide Perovskites, ACS Nano, 2014, 8, 9815–9821. 

- 117 S. Wang, M. Sina, P. Parikh, T. Uekert, B. Shahbazian, A. Devaraj and Y. S. Meng, Role of 4- tert-Butylpyridine as a Hole Transport Layer Morphological Controller in Perovskite Solar Cells, Nano Lett., 2016, 16, 5594–5600. 

- 118 J. Burschka, F. Kessler, M. K. Nazeeruddin and M. Gra¨tzel, Co(III) Complexes as p-Dopants in Solid-State DyeSensitized Solar Cells, Chem. Mater., 2013, 25, 2986–2990. 

- 119 L. Calio`, M. Salado, S. Kazim and S. Ahmad, A Generic Route of Hydrophobic Doping in Hole Transporting Material to Increase Longevity of Perovskite Solar Cells, Joule, 2018, 2, 1800–1815. 

- 120 J. Zhang, Q. Daniel, T. Zhang, X. Wen, B. Xu, L. Sun, U. Bach and Y.-B. Cheng, Chemical Dopant Engineering in Hole Transport Layers for Efficient Perovskite Solar Cells: Insight into the Interfacial Recombination, ACS Nano, 2018, 12, 10452–10462. 

- 121 T. Leijtens, T. Giovenzana, S. N. Habisreutinger, J. S. Tinkham, N. K. Noel, B. A. Kamino, G. Sadoughi, A. Sellinger and H. J. Snaith, Hydrophobic Organic Hole Transporters for Improved Moisture Resistance in Metal Halide Perovskite Solar Cells, ACS Appl. Mater. Interfaces, 2016, 8, 5981–5989. 

- 122 J. Zhang, T. Zhang, L. Jiang, U. Bach and Y.-B. Cheng, 4-tert-Butylpyridine Free Hole Transport Materials for Efficient Perovskite Solar Cells: A New Strategy to Enhance the Environmental and Thermal Stability, ACS Energy Lett., 2018, 3, 1677–1682. 

- 123 Y. Yue, N. Salim, Y. Wu, X. Yang, A. Islam, W. Chen, J. Liu, E. Bi, F. Xie, M. Cai and L. Han, Enhanced Stability of Perovskite Solar Cells through Corrosion-Free Pyridine Derivatives in Hole-Transporting Materials, Adv. Mater., 2016, 28, 10738–10743. 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5187 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

- 124 J.-Y. Seo, H.-S. Kim, S. Akin, M. Stojanovic, E. Simon, M. Fleischer, A. Hagfeldt, S. M. Zakeeruddin and M. Gra¨tzel, Novel p-dopant toward highly efficient and stable perovskite solar cells, Energy Environ. Sci., 2018, 11, 2985–2992. 

- 125 X. Wang, J. Wu, Y. Yang, X. Liu, Q. Guo, Z. Song, G. Li, Z. Lan and M. Huang, High performance and stable perovskite solar cells using vanadic oxide as a dopant for spiro-OMeTAD, J. Mater. Chem. A, 2019, 7, 13256–13264. 

- 126 L. Lanzetta, N. Aristidou and S. A. Haque, Stability of Lead and Tin Halide Perovskites: The Link between Defects and Degradation, J. Phys. Chem. Lett., 2020, 11, 574–585. 

- 127 E. Kasparavicius, A. Magomedov, T. Malinauskas and V. Getautis, Long-Term Stability of the Oxidized HoleTransporting Materials used in Perovskite Solar Cells, Chem. – Eur. J., 2018, 24, 9910–9918. 

- 128 X. Zhao, H.-S. Kim, J.-Y. Seo and N.-G. Park, Effect of Selective Contacts on the Thermal Stability of Perovskite Solar Cells, ACS Appl. Mater. Interfaces, 2017, 9, 7148–7153. 

- 129 I. Mesquita, L. Andrade and A. Mendes, Temperature Impact on Perovskite Solar Cells Under Operation, ChemSusChem, 2019, 12, 2186–2194. 

- 130 C. D. Bailie, E. L. Unger, S. M. Zakeeruddin, M. Gra¨tzel and M. D. McGehee, Melt-infiltration of spiro-OMeTAD and thermal instability of solid-state dye-sensitized solar cells, Phys. Chem. Chem. Phys., 2014, 16, 4864. 

- 131 A. K. Jena, Y. Numate, M. Ikegami and T. Miyasaka, Role of Spiro-OMeTAD in Performance Deterioration of Perovskite Solar Cells at High Temperature and Reuse of the Perovskite Films to Avoid Pb-waste, J. Mater. Chem. A, 2018, 6, 2219–2230. 

- 132 I. Lee, J. H. Yun, H. J. Son and T.-S. Kim, Accelerated Degradation Due to Weakened Adhesion from Li-TFSI Additives in Perovskite Solar Cells, ACS Appl. Mater. Interfaces, 2017, 9, 7029–7035. 

- 133 J. H. Yun, I. Lee, T.-S. Kim, M. J. Ko, J. Y. Kim and H. J. Son, Synergistic enhancement and mechanism study of mechanical and moisture stability of perovskite solar cells introducing polyethylene -imine into CH3NH3PbI3/HTM interface, J. Mater. Chem. A, 2015, 3, 22176–22182. 

- 134 D. Wei, T. Wang, J. Ji, M. Li, P. Cui, Y. Li, G. Li, J. M. Mbengue and D. Song, Photo-induced degradation of lead halide perovskite solar cells caused by the hole transport layer/metal electrode interface, J. Mater. Chem. A, 2016, 4, 1991–1998. 

- 135 K. Domanski, J.-P. Correa-Baena, N. Mine, M. K. Nazeeruddin, A. Abate, M. Saliba, W. Tress, A. Hagfeldt and M. Gra¨tzel, Not All That Glitters Is Gold: Metal-Migration-Induced Degradation in Perovskite Solar Cells, ACS Nano, 2016, 10, 6306–6314. 

- 136 S. Guarnera, A. Abate, W. Zhang, J. M. Foster, G. Richardson, A. Petrozza and H. J. Snaith, Improving the Long-Term Stability of Perovskite Solar Cells with a Porous Al 2 O 3 Buffer Layer, J. Phys. Chem. Lett., 2015, 6, 432–437. 

- 137 C.-T. Lin, J. Ngiam, B. Xu, Y.-H. Chang, T. Du, T. J. Macdonald, J. R. Durrant and M. A. McLachlan, Enhancing the operational stability of unencapsulated perovskite solar cells through Cu–Ag bilayer electrode incorporation, J. Mater. Chem. A, 2020, 8, 8684–8691. 

- 138 Z. Li, C. Xiao, Y. Yang, S. P. Harvey, D. H. Kim, J. A. Christians, M. Yang, P. Schulz, S. U. Nanayakkara, C.-S. Jiang, J. M. Luther, J. J. Berry, M. C. Beard, M. M. Al-Jassim and K. Zhu, Extrinsic ion migration in perovskite solar cells, Energy Environ. Sci., 2017, 10, 1234–1242. 

- 139 J. A. Dawson, A. J. Naylor, C. Eames, M. Roberts, W. Zhang, H. J. Snaith, P. G. Bruce and M. S. Islam, Mechanisms of Lithium Intercalation and Conversion Processes in Organic–Inorganic Halide Perovskites, ACS Energy Lett., 2017, 2, 1818–1824. 

- 140 W. H. Howie, J. E. Harris, J. R. Jennings and L. M. Peter, Solid-state dye-sensitized solar cells based on spiroMeOTAD, Sol. Energy Mater. Sol. Cells, 2007, 91, 424–426. 

- 141 W. Li, H. Dong, L. Wang, N. Li, X. Guo, J. Li and Y. Qiu, Montmorillonite as bifunctional buffer layer material for hybrid perovskite solar cells with protection from corrosion and retarding recombination, J. Mater. Chem. A, 2014, 2, 13587–13592. 

- 142 H. Sarvari, X. Wang, Y. Wang, P. Zhang, S. Li, V. P. Singh and Z. Chen, Photovoltaic Performance of Lead-Iodide Perovskite Solar Cells Fabricated Under Ambient Air Conditions With HTM Solution Excluding LiTFSI, IEEE J. Photovolt., 2018, 8, 1051–1057. 

- 143 Y. Zhang, A. Kirs, F. Ambroz, C. Lin, A. S. R. Bati, I. P. Parkin, J. G. Shapter, M. Batmunkh and T. J. Macdonald, Ambient Fabrication of Organic–Inorganic Hybrid Perovskite Solar Cells, Small Methods, 2021, 5, 2000744. 

- 144 J. Kim, N. Park, J. S. Yun, S. Huang, M. A. Green and A. W. Y. Ho-Baillie, An effective method of predicting perovskite solar cell lifetime–Case study on planar CH3NH3PbI3 and HC(NH 2) 2PbI3 perovskite solar cells and hole transfer materials of spiro-OMeTAD and PTAA, Sol. Energy Mater. Sol. Cells, 2017, 162, 41–46. 

- 145 Q. Wang, Influence of Cobalt Additive in spiro-OMeTAD on Charge Recombination and Carrier Density in Perovskite Solar Cells investigated by Impedance Spectroscopy, Phys. Chem. Chem. Phys., 2018, 20, 10114–10120. 

- 146 J. Veres, S. Ogier, S. Leeming, B. Brown and D. Cupertino, Air Stable, Amorphous Organic Films and their Applications to Solution Processable Flexible Electronics, MRS Proc., 2001, 708, BB8.7. 

- 147 J. Veres, S. D. Ogier, S. W. Leeming, D. C. Cupertino and S. Mohialdin, Khaffaf, Low-k Insulators as the Choice of Dielectrics in Organic Field-Effect Transistors, Adv. Funct. Mater., 2003, 13, 199–204. 

- 148 L. A. Majewski, M. Grell, S. D. Ogier and J. Veres, A novel gate insulator for flexible electronics, Org. Electron., 2003, 4, 27–32. 

- 149 J. H. Noh, S. H. Im, J. H. Heo, T. N. Mandal and S. I. Seok, Chemical Management for Colorful, Efficient, and Stable Inorganic–Organic Hybrid Nanostructured Solar Cells, Nano Lett., 2013, 13, 1764–1769. 

- 150 W. S. Yang, J. H. Noh, N. J. Jeon, Y. C. Kim, S. Ryu, J. Seo and S. I. Seok, High-performance photovoltaic perovskite layers fabricated through intramolecular exchange, Science, 2015, 348, 1234–1237. 

5188 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

- 151 B. Souharce, PhD thesis, Bergische Universita¨t Wuppertal, 2008. 

- 152 Y. Ko, Y. Kim, C. Lee, Y. Kim and Y. Jun, Investigation of Hole-Transporting Poly(triarylamine) on Aggregation and Charge Transport for Hysteresisless Scalable Planar Perovskite Solar Cells, ACS Appl. Mater. Interfaces, 2018, 10, 11633–11641. 

- 153 S. Barard, M. Heeney, L. Chen, M. Co¨lle, M. Shkunov, I. McCulloch, N. Stingelin, M. Philips and T. Kreouzis, Separate charge transport pathways determined by the time of flight method in bimodal polytriarylamine, J. Appl. Phys., 2009, 105, 013701. 

- 154 W. Zhang, J. Smith, R. Hamilton, M. Heeney, J. Kirkpatrick, K. Song, S. E. Watkins, T. Anthopoulos and I. McCulloch, Systematic Improvement in Charge Carrier Mobility of Air Stable Triarylamine Copolymers, J. Am. Chem. Soc., 2009, 131, 10814–10815. 

- 155 T. Ye, W. Chen, S. Jin, S. Hao, X. Zhang, H. Liu and D. He, Enhanced Efficiency of Planar Heterojunction Perovskite Solar Cells by a Light Soaking Treatment on Tris(pentafluorophenyl)borane-Doped Poly(triarylamine) Solution, ACS Appl. Mater. Interfaces, 2019, 11, 14004–14010. 

- 156 J. Endres, M. Kulbak, L. Zhao, B. P. Rand, D. Cahen, G. Hodes and A. Kahn, Electronic structure of the CsPbBr 3/ polytriarylamine (PTAA) system, J. Appl. Phys., 2017, 121, 035304. 

- 157 J. C. Brauer, Y. H. Lee, M. K. Nazeeruddin and N. Banerji, Charge Transfer Dynamics from Organometal Halide Perovskite to Polymeric Hole Transport Materials in Hybrid Solar Cells, J. Phys. Chem. Lett., 2015, 6, 3675–3681. 

- 158 I. Lee, N. Rolston, P.-L. Brunner and R. H. Dauskardt, HoleTransport Layer Molecular Weight and Doping Effects on Perovskite Solar Cell Efficiency and Mechanical Behavior, ACS Appl. Mater. Interfaces, 2019, 11, 23757–23764. 

- 159 Y. Kim, E. H. Jung, G. Kim, D. Kim, B. J. Kim and J. Seo, Sequentially Fluorinated PTAA Polymers for Enhancing VOC of High-Performance Perovskite Solar Cells, Adv. Energy Mater., 2018, 8, 1801668. 

- 160 P. Zalar, M. Kuik, Z. B. Henson, C. Woellner, Y. Zhang, A. Sharenko, G. C. Bazan and T.-Q. Nguyen, Increased Mobility Induced by Addition of a Lewis Acid to a Lewis Basic Conjugated Polymer, Adv. Mater., 2014, 26, 724–727. 

- 161 H. Me´ndez, G. Heimel, A. Opitz, K. Sauer, P. Barkowski, M. Oehzelt, J. Soeda, T. Okamoto, J. Takeya, J.-B. Arlin, J.-Y. Balandier, Y. Geerts, N. Koch and I. Salzmann, Doping of Organic Semiconductors: Impact of Dopant Strength and Electronic Coupling, Angew. Chem., Int. Ed., 2013, 52, 7751–7755. 

- 162 J. H. Heo, H. J. Han, D. Kim, T. K. Ahn and S. H. Im, Hysteresis-less inverted CH3NH3PbI3 planar perovskite hybrid solar cells with 18.1% power conversion efficiency, Energy Environ. Sci., 2015, 8, 1602–1608. 

- 163 R. Noriega, J. Rivnay, K. Vandewal, F. P. V. Koch, N. Stingelin, P. Smith, M. F. Toney and A. Salleo, A general relationship between disorder, aggregation and charge transport in conjugated polymers, Nat. Mater., 2013, 12, 1038–1044. 

- 164 J. Luo, J. Xia, H. Yang, L. Chen, Z. Wan, F. Han, H. A. Malik, X. Zhu and C. Jia, Toward high-efficiency, hysteresis-less, stable perovskite solar cells: unusual doping of a hole-transporting material using a fluorinecontaining hydrophobic Lewis acid, Energy Environ. Sci., 2018, 11, 2035–2045. 

- 165 B. L. Watson, N. Rolston, K. A. Bush, L. Taleghani and R. H. Dauskardt, Synthesis and use of a hyper-connecting cross-linking agent in the hole-transporting layer of perovskite solar cells, J. Mater. Chem. A, 2017, 5, 19267–19279. 

- 166 N. Y. Nia, M. Me´ndez, B. Paci, A. Generosi, A. Di Carlo and E. Palomares, Analysis of the Efficiency Losses in Hybrid Perovskite/PTAA Solar Cells with Different Molecular Weights: Morphology versus Kinetics, ACS Appl. Energy Mater., 2020, 3, 6853–6859. 

- 167 N. Y. Nia, M. Me´ndez, A. di Carlo and E. Palomares, Energetic disorder in perovskite/polymer solar cells and its relationship with the interfacial carrier losses, Philos. Trans. R. Soc., A, 2019, 377, 20180315. 

- 168 R. Wang, J. Xue, L. Meng, J.-W. Lee, Z. Zhao, P. Sun, L. Cai, T. Huang, Z. Wang, Z.-K. Wang, Y. Duan, J. L. Yang, S. Tan, Y. Yuan, Y. Huang and Y. Yang, Caffeine Improves the Performance and Thermal Stability of Perovskite Solar Cells, Joule, 2019, 3, 1464–1477. 

- 169 L. Meng, C. Sun, R. Wang, W. Huang, Z. Zhao, P. Sun, T. Huang, J. Xue, J.-W. Lee, C. Zhu, Y. Huang, Y. Li and Y. Yang, Tailored Phase Conversion under Conjugated Polymer Enables Thermally Stable Perovskite Solar Cells with Efficiency Exceeding 21%, J. Am. Chem. Soc., 2018, 140, 17255–17262. 

- 170 M. Maitrot, G. Guillaud, B. Boudjema, J. J. Andre´ and J. Simon, Molecular material-based junctions: Formation of a Schottky contact with metallophthalocyanine thin films doped by the cosublimation method, J. Appl. Phys., 1986, 60, 2396–2400. 

- 171 Q. Wang, C. Bi and J. Huang, Doped hole transport layer for efficiency enhancement in planar heterojunction organolead trihalide perovskite solar cells, Nano Energy, 2015, 15, 275–280. 

- 172 W. Yang, D. Zhong, M. Shi, S. Qu and H. Chen, Toward Highly Thermal Stable Perovskite Solar Cells by Rational Design of Interfacial Layer, iScience, 2019, 22, 534–543. 

- 173 S. N. Habisreutinger, T. Leijtens, G. E. Eperon, S. D. Stranks, R. J. Nicholas and H. J. Snaith, Carbon Nanotube/Polymer Composites as a Highly Stable Hole Collection Layer in Perovskite Solar Cells, Nano Lett., 2014, 14, 5561–5568. 

- 174 D. Bi, G. Boschloo and A. Hagfeldt, High-efficiency solidstate perovskite solar cell without lithium salt in the hole transport material, NANO, 2014, 09, 1440001. 

- 175 T. Duong, Y. Wu, H. Shen, J. Peng, N. Wu, T. White, K. Weber and K. Catchpole, in 2018 IEEE 7th World Conference on Photovoltaic Energy Conversion (WCPEC) (A Joint Conference of 45th IEEE PVSC, 28th PVSEC & 34th EU PVSEC), IEEE, Waikoloa Village, HI, 2018, pp. 3506–3508. 

- 176 H. K. H. Lee, Z. Li, I. Constantinou, F. So, S. W. Tsang and S. K. So, Batch-to-Batch Variation of Polymeric Photovoltaic 

_Energy Environ. Sci._ , 2021, 14, 5161–5190 | 5189 

This journal is © The Royal Society of Chemistry 2021 

Energy & Environmental Science 

Review 

   - Materials: its Origin and Impacts on Charge Carrier Transport and Device Performances, Adv. Energy Mater., 2014, 4, 1400768. 

- 177 J. A. Christians, P. Schulz, J. S. Tinkham, T. H. Schloemer, S. P. Harvey, B. J. Tremolet de Villers, A. Sellinger, J. J. Berry and J. M. Luther, Tailored interfaces of unencapsulated perovskite solar cells for 41000 hour operational stability, Nat. Energy, 2018, 3, 68–74. 

- 178 T. Ye, J. Wang, W. Chen, Y. Yang and D. He, Improved Performance and Reproducibility of Perovskite Solar Cells by Well-Soluble Tris(pentafluorophenyl)borane as a p-Type Dopant, ACS Appl. Mater. Interfaces, 2017, 9, 17923–17931. 

- 179 J. Luo, C. Jia, Z. Wan, F. Han, B. Zhao and R. Wang, The novel dopant for hole-transporting material opens a new processing route to efficiently reduce hysteresis and improve stability of planar perovskite solar cells, J. Power Sources, 2017, 342, 886–895. 

- 180 S. Moghadamzadeh, I. M. Hossain, M. Jakoby, B. Abdollahi Nejand, D. Rueda-Delgado, J. A. Schwenzer, S. Gharibzadeh, T. Abzieher, M. R. Khan, A. A. Haghighirad, I. A. Howard, B. S. Richards, U. Lemmer and U. W. Paetzold, Spontaneous enhancement of the stable power conversion efficiency in perovskite solar cells, J. Mater. Chem. A, 2020, 8, 670–682. 

- 181 N. J. Jeon, H. G. Lee, Y. C. Kim, J. Seo, J. H. Noh, J. Lee and S. I. Seok, o-Methoxy Substituents in Spiro-OMeTAD for Efficient Inorganic–Organic Hybrid Perovskite Solar Cells, J. Am. Chem. Soc., 2014, 136, 7837–7840. 

- 182 E. H. Jung, N. J. Jeon, E. Y. Park, C. S. Moon, T. J. Shin, T.-Y. Yang, J. H. Noh and J. Seo, Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene), Nature, 2019, 567, 511–515. 

- 183 J. Urieta-Mora, I. Garcı´a-Benito, A. Molina-Ontoria and N. Martı´n, Hole transporting materials for perovskite solar cells: a chemical approach, Chem. Soc. Rev., 2018, 47, 8541–8571. 

- 184 M. Monteiro Lunardi, A. Wing Yi Ho-Baillie, J. P. AlvarezGaitan, S. Moore and R. Corkish, A life cycle assessment of perovskite/silicon tandem solar cells: Perovskite/silicon tandem solar cell LCA, Prog. Photovoltaics, 2017, 25, 679–695. 

- 185 J. Urieta-Mora, I. Garcı´a-Benito, A. Molina-Ontoria and N. Martı´n, Hole transporting materials for perovskite solar cells: a chemical approach, Chem. Soc. Rev., 2018, 47, 8541–8571. 

- 186 G. Kim, H. Choi, M. Kim, J. Lee, S. Y. Son and T. Park, Hole Transport Materials in Conventional Structural (n–i–p) 

Perovskite Solar Cells: From Past to the Future, Adv. Energy Mater., 2020, 10, 1903403. 

- 187 H. Zhang, Y. Wu, W. Zhang, E. Li, C. Shen, H. Jiang, H. Tian and W.-H. Zhu, Low cost and stable quinoxalinebased hole-transporting materials with a D–A–D molecular configuration for efficient perovskite solar cells, Chem. Sci., 2018, 9, 5919–5928. 

- 188 L. Zhang, C. Liu, X. Wang, Y. Tian, A. K. Y. Jen and B. Xu, Side-Chain Engineering on Dopant-Free Hole-Transporting Polymers toward Highly Efficient Perovskite Solar Cells (20.19%), Adv. Funct. Mater., 2019, 29, 1904856. 

- 189 L. Wang, F. Zhang, T. Liu, W. Zhang, Y. Li, B. Cai, L. He, Y. Guo, X. Yang, B. Xu, J. M. Gardner, L. Kloo and L. Sun, A crosslinked polymer as dopant-free hole-transport material for efficient n–i–p type perovskite solar cells, J. Energy Chem., 2021, 55, 211–218. 

- 190 H. Hwang, S. Park, J. H. Heo, W. Kim, H. Ahn, T.-S. Kim, S. H. Im and H. J. Son, Enhancing performance and stability of perovskite solar cells using hole transport layer of small molecule and conjugated polymer blend, J. Power Sources, 2019, 418, 167–175. 

- 191 R. Li, P. Wang, B. Chen, X. Cui, Y. Ding, Y. Li, D. Zhang, Y. Zhao and X. Zhang, NiOx/Spiro Hole Transport Bilayers for Stable Perovskite Solar Cells with Efficiency Exceeding 21%, ACS Energy Lett., 2020, 5, 79–86. 

- 192 S. N. Habisreutinger, N. K. Noel, B. W. Larson, O. G. Reid and J. L. Blackburn, Rapid Charge-Transfer Cascade through SWCNT Composites Enabling Low-Voltage Losses for Perovskite Solar Cells, ACS Energy Lett., 2019, 4, 1872–1879. 

- 193 T. Duong, J. Peng, D. Walter, J. Xiang, H. Shen, D. Chugh, M. Lockrey, D. Zhong, J. Li, K. Weber, T. P. White and K. R. Catchpole, Perovskite Solar Cells Employing Copper Phthalocyanine Hole-Transport Material with an Efficiency over 20% and Excellent Thermal Stability, ACS Energy Lett., 2018, 3, 2441–2448. 

- 194 A. Magomedov, A. Al-Ashouri, E. Kasparavicˇius, S. Strazdaite, G. Niaura, M. Josˇt, T. Malinauskas, S. Albrecht and V. Getautis, Self-Assembled Hole Transporting Monolayer for Highly Efficient Perovskite Solar Cells, Adv. Energy Mater., 2018, 8, 1801892. 

- 195 R. J. E. Westbrook, T. J. Macdonald, W. Xu, L. Lanzetta, J. M. Marin-Beloqui, T. M. Clarke and S. A. Haque, Lewis Base Passivation Mediates Charge Transfer at Perovskite Heterojunctions, J. Am. Chem. Soc., 2021, 143, 12230–12243. 

5190 | _Energy Environ. Sci._ , 2021, 14, 5161–5190 

This journal is © The Royal Society of Chemistry 2021 

