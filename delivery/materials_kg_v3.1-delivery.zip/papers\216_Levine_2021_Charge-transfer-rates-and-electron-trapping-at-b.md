# Charge transfer rates and electron trapping at buried interfaces of perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 369 |
| 作者 | I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, Aida Drevilkauskaitė, V. Getautis, Dorothee Menzel et al. |
| DOI | 10.1016/j.joule.2021.07.016 |
| 源文件 | 016_Levine_2021_Charge-transfer-rates-and-electron-trapping-at-b.pdf |

---
**ll** OPEN ACCESS 



### Article 

# Charge transfer rates and electron trapping at buried interfaces of perovskite solar cells 



Igal Levine, Amran Al-Ashouri, Artem Musiienko, ..., Thomas Unold, Steve Albrecht, Thomas Dittrich 

igal.levine@helmholtz-berlin.de 

Highlights Loss mechanisms at buried interfaces identified by timeresolved surface photovoltage 

Hole transfer rates obtained for ITO/carbazole-based SAMs/ perovskite heterojunctions 

Lowest density of interface traps (2 3 10<sup>9</sup> cm<sup>�2</sup> ) found for the SAM ‘‘Me-4PACz’’ 

Correlation with the performance of related record perovskite solar cells shown 

Dominating loss mechanisms were identified at hole-selective buried interfaces engineered with carbazole-based self-assembled monolayers between a metal halide perovskite absorber and a conductive metal oxide. The analysis of surface photovoltage transients with a minimalistic kinetic model allowed for the extraction of interfacial electron trap densities and hole transfer rates and their correlation with open-circuit voltages and fill factors of the corresponding highefficiency solar cells is demonstrated. 

Levine et al., Joule 5, 2915–2933 November 17, 2021 ª 2021 The Author(s). Published by Elsevier Inc. https://doi.org/10.1016/j.joule.2021.07.016 



**ll** OPEN ACCESS 



##### Article 

## Charge transfer rates and electron trapping at buried interfaces of perovskite solar cells 

Igal Levine,<sup>1,7,</sup> * Amran Al-Ashouri,<sup>2</sup> Artem Musiienko,<sup>1</sup> Hannes Hempel,<sup>3</sup> Artiom Magomedov,<sup>4</sup> Aida Drevilkauskaite,<sup>4</sup> Vytautas Getautis,<sup>4</sup> Dorothee Menzel,<sup>2</sup> Karsten Hinrichs,<sup>5</sup> Thomas Unold,<sup>3</sup> Steve Albrecht,<sup>2,6</sup> and Thomas Dittrich<sup>1</sup> 

###### SUMMARY 

Identification of electronic processes at buried interfaces of chargeselective contacts is crucial for photovoltaic and photocatalysis research. Here, transient surface photovoltage (SPV) is used to study the passivation of different hole-selective carbazole-based SAMs. It is shown that transient SPV and transient photoluminescence provide complementary information on charge transfer kinetics and trapping/de-trapping mechanisms, and that trap-assisted non-radiative recombination losses originate from electron trapping at the SAM-modified ITO/perovskite interface. The hole transfer rates and the density of interface electron traps, obtained by fitting SPV transients with a minimalistic kinetic model, depended strongly on the SAM’s chemical structure, and densities of interface traps as low as 10<sup>9</sup> cm<sup>�2</sup> , on par with highly passivated c-Si surfaces, were reached for Me-4PACz, previously used in record perovskite/ silicon tandem solar cells. The extracted hole transfer rate constants and interface trap densities correlated well with the corresponding fill factors and open-circuit voltages of high-efficiency solar cells. 

###### INTRODUCTION 

The passivation of contacts is decisive for achieving high solar energy conversion efficiencies of solar cells. Interfacial recombination losses at buried interfaces disappear at ideally passivated contacts, i.e., recombination-active defect states are absent at charge-selective contacts, and minority charge carriers do not reach the corresponding ohmic contact where they recombine.<sup>1</sup> In conventional highefficiency solar cells such as those based on crystalline silicon (c-Si) and gallium arsenide absorbers,<sup>2</sup> charge-selective pn-homojunctions are practically free of interface defects. 

Solar cells based on halide perovskite (HaP) absorbers also bear the potential for very high efficiencies.<sup>2–4</sup> In solar cells with HaP absorbers, charge-selective contacts are realized by heterojunctions, which, on the one hand, allows careful tuning of the energy level alignment;<sup>5,6</sup> yet, on the other hand, could have an impact on the stability of the entire device.<sup>7</sup> Self-assembled monolayers (SAMs) are widely known for their unique ability to passivate the surface of semiconductors by chemical bonding to the surface, with the most prominent example being the widely studied c-Si.<sup>8</sup> Recently, it has been shown that SAMs containing a carbazole core can replace commonly used high-efficiency hole transport layers (HTL) such as poly-triarylamine (PTAA), boosting the efficiency of c-Si/HaP-based tandem solar cells to a record efficiency of above 29%<sup>3,9</sup> and of organic single junction solar cells (OSCs) to over 18%.<sup>10,11</sup> 

###### Context & scale 

The implementation of monolayers of small molecules (self-assembled monolayers, SAMs) at buried interfaces together with a deeper understanding of loss mechanisms bears tremendous opportunities for a further increase in the solar energy conversion efficiency of photovoltaic and photocatalytic devices. Carbazole-based SAMs (recently used in world record perovskite/silicon tandem solar cells) are fine-tuned by varying the size of molecules and by selecting specific functional groups. Separation of photogenerated charge carriers is a key for photovoltaic and photocatalytic solar energy conversion and can be directly investigated by surface photovoltage (SPV) techniques. The application of the timeresolved SPV together with kinetic modeling allows for the identification of dominating loss mechanisms as a function of the nature of SAMs at buried interfaces to the metal-halide perovskite absorber implemented in high-efficiency solar cells. 



Joule 5, 2915–2933, November 17, 2021 ª 2021 The Author(s). Published by Elsevier Inc. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/). 

2915 

Article 

OPEN ACCESS 

#### **ll** 

In particular, the SAM 2PACz ([2-(9H-carbazol-9-yl)ethyl]phosphonic acid) has expanded the choice of available hole-selective layers by a rare entry: It has been shown that it did not introduce any non-radiative recombination losses compared with films deposited on quartz glass, as measured by absolute photoluminescence (PL),<sup>3</sup> despite allowing for efficient hole extraction and thus high fill factors in perovskite solar cells. Usually, charge-selective layers induce a reduction of the PL quantum yield and PL decay time,<sup>12</sup> known as ‘‘quenching.’’<sup>13</sup> In addition, a recently presented SAM, Me-4PACz ([4-(3,6- dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid), led to a milestone combination of low ideality factor with high open-circuit voltage,<sup>9,14</sup> with the ideality factor being one of the parameters that presumably prevented perovskite solar cells from reaching the fill factors of mature solar cells technologies.<sup>15,16</sup> Additionally, SAMs can be considered as a model system since slight differences in their atomic structure change their functionalization without altering the perovskite bulk quality, morphology, and thickness, which might influence charge carrier kinetics, as confirmed by, e.g., grazing-incidence wide-angle X-ray scattering measurements.<sup>9</sup> 

This work is dedicated to a detailed analysis of the various charge carrier dynamics occurring in the perovskite/SAM-modified indium tin oxide (ITO) interface by utilizing steady-state and transient surface photovoltage (SPV).<sup>17</sup> Our detailed analysis allows to determine differences in the passivation quality, selectivity, and hole transfer rate depending on the structure of the SAM. This introduces a technique for quantifying charge extraction for which there is no standard as yet in the perovskite research field and might give guidelines for the design of ideal charge-selective contacts. 

Elucidating fundamental properties of buried interfaces in perovskite-based devices is still challenging.<sup>18</sup> Current-voltage (J-V) measurements are a major high-sensitivity method often used for the characterization of buried interfaces.<sup>19,20</sup> J-V measurements require two electrical contacts, which can hinder unambiguous interpretation of data, and the contribution of different interfaces cannot be separated. Hence, to-date, experimental analysis of recombination losses in a single buried interface remains a challenge.<sup>21</sup> The measurement of absolute PL spectra allows for the extraction of the quasi-Fermi-level splitting in a bulk semiconductor and its correlation with surface passivation, for example, in high-efficiency p-i-n perovskite solar cells.<sup>22</sup> However, the PL analysis does not directly give information about the passivation mechanism. Transient photoluminescence (tr-PL) can give information about the charge carrier recombination kinetics at a specific buried interface by using relatively advanced modeling of tr-PL decays for interpretation.<sup>23</sup> However, in most cases, quenching of PL signals by charge separation, such as charge transfer at chargeselective contacts, and by increased recombination rates cannot be unambiguously distinguished, and quite strong dependencies of PL transients on experimental conditions can make the analysis of PL transients even more complicated.<sup>24–27</sup> 

In contrast to J-V and PL measurements, SPV measurements track the change in the surface potential upon photoexcitation and give information about the direction of charge separation, i.e., a positive (negative) SPV signal suggests the preferred separation of holes (electrons) toward the sample’s surface.<sup>17</sup> For OSCs, intensitymodulated SPV microscopy has been shown to be a valuable tool to probe variations in carrier dynamics due to heterogeneity in the buried surface chemistry.<sup>28</sup> Thus, by performing tr-SPV measurements, one can track the charge carrier dynamics in a specific interface over a wide time domain, from the generation of e-h pairs to their separation in space and different e-h recombination paths. 

1Helmholtz-Zentrum Berlin fu¨ r Materialien und Energie GmbH, Kekulestraße 5, 12489 Berlin, Germany 

2Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin fu¨ r Materialien und Energie GmbH, Kekulestraße 5, 12489 Berlin, Germany 

3Department of Structure and Dynamics of Energy Materials, Helmholtz-Zentrum-Berlin fu¨ r Materialien und Energie GmbH, Hahn-Meitner Platz 1, 14109 Berlin, Germany 

4Department of Organic Chemistry, Kaunas University of Technology, Radvilenu pl. 19, Kaunas LT-50254, Lithuania 

5Leibniz-Institut fu¨ r Analytische Wissenschaften � ISAS�e.V., Schwarzschildstr. 8, 12489 Berlin, Germany 

6Faculty of Electrical Engineering and Computer Science, Technical University Berlin, Marchstraße 23, 10587 Berlin, Germany 

7Lead contact 

*Correspondence: igal.levine@helmholtz-berlin.de https://doi.org/10.1016/j.joule.2021.07.016 

2916 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 





Figure 1. Model diagram and the experimental system 

(A) Model diagram for describing the different process upon photoexcitation: the generation rate of e-h pairs upon light excitation is shown in green and denoted as G; the hole (electron) transfer rate from the perovskite to the ITO and back transfer of hole (electron) from the ITO to the perovskite is shown in red (blue) and denoted as Kh (Ke) and Khb (Keb), respectively; electron trapping/de-trapping processes at ITO/SAM interfacial traps (denoted as Nit) are shown in purple. FB,e denotes the barrier height for electron transfer from the conduction band of the perovskite to the ITO. (B) Schematic device stack and the SPV measurement setup, a mica sheet is used as a spacer between the sample‘s surface and the SPV probe, Rm denotes the measurement resistance. 

(C) The molecular structure of the different SAMs studied in this work. 

In practice, tr-PL and tr-SPV measurements are usually performed at rather different repetition rates of laser pulses for excitation (frep) due to the fact that charge separation results in strong and long-living SPV signals, whereas tr-PL signals are quickly quenched below the sensitivity limit. Supasai et al.<sup>29</sup> obtained by tr-SPV measurements at low frep (1 Hz) for HTL/HaP junctions, depending on the HTL, different carrier recombination kinetics as well as an indication for de-trapping of charge carriers in the ms timescale and longer. For deeper interpretation, direct correlation experiments between tr-PL and tr-SPV are required. For this purpose, in this work, several PL and SPV transients were measured under identical conditions at frep = 1 and 125 kHz. Furthermore, tr-SPV transients at different intensities were also measured at frep = 2 Hz in order to gain more information about relatively slow trapping and de-trapping processes. 

In general, molecules used for the formation of SAMs are characterized by their binding group(s) to a substrate, a molecular chain, and a functionalizing head group.<sup>30</sup> In this work, different molecules with a phosphonic acid (-PO(OH)2) binding group to ITO, a CnH2n chain (n = 2, 4, and 6), and different carbazole derivatives as head groups were used (see Figure 1C). The thickness of the SAM layers is of the order of 1 nm.<sup>31</sup> 

Joule 5, 2915–2933, November 17, 2021 2917 

#### **ll** 

OPEN ACCESS 

Article 

Different chain lengths and head groups have a strong influence on dipole moments and tunneling lengths for charge transfer. The resulting dipole moments affect the barrier heights between the energies of the HOMO (highest occupied molecular orbital) and the valence band edge of the HaP and of the LUMO (lowest unoccupied molecular orbital) and the conduction band edge of the HaP, whereas the tunneling length, determined by the insulating alkyl chain, affects the width of the barriers.<sup>32</sup> Figure 1A shows a schematic band diagram of an ITO/SAM/HaP junction with corresponding electron and hole transfer rate constants from the HaP into ITO (Ke and Kh, respectively) and back from ITO into the HaP (Keb and Khb, respectively). A larger Kh implies greater hole selectivity (Kh >> Ke), whereas a smaller density of interfacial electron traps, Nit, implies higher passivation quality of the ITO/SAM interface and minimized interfacial losses. A minimalistic kinetic model without considering limitations due to drift and diffusion was developed for the simulation of SPV transients under adequate conditions. The application of the model allowed for the extraction of the interfacial electron trap densities as well as the hole transfer rate constants for each SAM system. 

To begin, work functions and charge separation within SAMs are compared by measuring the spectra of the contact potential difference (CPD) at high sensitivity. Second, electron trapping at SAM-modified ITO/HaP interfaces is established by performing complementary tr-PL and tr-SPV measurements at high frep. Third, intensity-dependent trends in the kinetics of SPV transients at low frep are investigated in more detail for ITO/HaP and ITO/SAM/HaP systems. Fourth, a model based only on rate equations is introduced and applied to the simulation and fitting of SPV transients in order to extract values for transfer rate constants and densities of electron traps at SAM-modified ITO/HaP interfaces. Finally, the correlation between interfacial trap densities and the open-circuit voltages as well as between the hole transfer rate constants and the fill factors are demonstrated for corresponding high-efficiency solar cells based on HaP. 

###### RESULTS AND DISCUSSION 

Charge separation in the isolated ITO/SAM system 

Figure 2 shows the change in the steady-state CPD spectrum of a bare ITO surface, compared with the spectra of SAM-covered ITO using different SAMs—2PACz, MeO-2PACz (a variant that leads to lower open-circuit voltage, VOC), and Me4PACz. The CPD at the lowest photon energy corresponds to the value in the dark. The CPD spectrum was converted to the absolute work function (WF) using a freshly peeled highly oriented pyrolytic graphite (HOPG) reference sample (WFHOPG = 4.65 G 0.05 eV).<sup>33</sup> The values of the WF in the dark were 4.65 eV for the bare ITO and 4.93, 5.09, and 5.20 eV for MeO-2PACz, 2PACz, and Me-4PACz, respectively. The largest change in the WF was observed for 2PACz and Me4PACz, which can be attributed to the stronger dipole of the isolated molecules 2PACz and Me-4PACz (�1.7 D) compared with MeO-2PACz (�0.2 D), in accordance with previous reports.<sup>3,9</sup> 

As can be seen from Figure 2A, the WF of the bare ITO surface decreased from 4.65 to 4.60 eV under illumination (corresponds to a positive SPV) for photon energies larger than 3.0 eV, i.e., the band gap of ITO. The change of the SPV signals of bare ITO implies an upward band bending on the ITO surface, which is typical for an n-type semiconductor with a surface depletion layer, in accordance with previous reports in the literature.<sup>34,35</sup> Incidentally, an upward band bending is caused by the trapping of electrons at surface states. The positive SPV signals were strongly suppressed for the ITO covered with SAMs, suggesting strongly reduced surface 

2918 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 





Figure 2. Steady-state CPD measurements of the different ITO/SAM samples (A and B) Steady-state CPD measurements of the different ITO/SAM samples (A) and their derivative (the derivative of the ITO was scaled by 1/3) (B), the green and blue arrows denote the distinct transition energies observed in the derivative spectra for Me-4PACz and 2PACz, respectively. Illumination was performed with a quartz prism monochromator and a Xe lamp from the front (SAM) side (for a reference spectrum of the intensity of the Xe lamp as a function of wavelength, see Figure S1). 

band bending and therefore a strong reduction of electron trapping at surface states, i.e., within the experimental sensitivity of the CPD setup, all three different SAMs passivate defects at the ITO surface. Details in SPV spectra can be better resolved in the derivative spectra (Figure 2B). Based on the peaks of the derivative of the CPD signal, different light-induced transitions that lead to SPV signals associated with absorption, photogeneration, and charge separation in SAMs can be extracted.<sup>17,36</sup> Aside from the transitions related to the bare ITO substrate at 3.0, 3.7, 4.0, and 4.3 eV, distinct SPV peaks were observed for 2PACz and Me-4PACz at 3.60 and 3.45 eV in the minima, whereas the peak was several times higher for Me-4PACz (which was confirmed by repeating the measurements three times, as shown in Figure S5). Although it has been shown that the energy gap between the highest occupied and lowest unoccupied molecular orbitals (HOMO-LUMO gap) of the SAM deposited on the substrate can be sensitive to the ambiance and substrate, and need not be identical to that of the dissolved molecules in solution,<sup>37</sup> the energetic positions of the peaks are in good agreement with the HOMO-LUMO gaps extracted from the absorption spectra of 2PACz and Me-4PACz molecules dissolved in Tetrahydrofuran (3.54 and 3.44 eV, respectively<sup>9</sup> ). Importantly, a distinct SPV feature related to the HOMO-LUMO gap of MeO-2PACz (around 3.2 eV<sup>3</sup> ) was not observed. 

The sign of the SPV derivative depends on the charge carrier distribution in the sample after photoexcitation and charge separation. The sign of the derivative is negative (positive) if the density of electrons (holes) is higher closer to the surface. Thus, 

Joule 5, 2915–2933, November 17, 2021 2919 

Article 

OPEN ACCESS 

#### **ll** 

the negative sign of the 1<sup>st</sup> derivative at 3.60 and 3.45 eV indicates that holes photogenerated in 2PACz and Me-4PACz were injected into the ITO whereas photogenerated electrons preferentially remained in the SAMs (see Figure 1A). Therefore, the derivatives of the SPV spectra of 2PACz and Me-4PACz directly showed the ability for hole transfer across the ITO/SAM interface into ITO caused by the directed dipole across the SAM layers (�1.7 D).<sup>3,9</sup> This is not the case for MeO-2PACz since no distinct feature is observed at 3.2 eV and can be explained by a much lower dipole moment across the SAM layer (�0.2 D) due to (partial) compensation of the polarization charge in the phosphonic anchoring group by the two methoxy groups on top of the carbazole<sup>3,9</sup> (see also Figure 1C). Incidentally, incomplete coverage by MeO-2PACz molecules can be ruled out as a reason, as indicated by X-ray photoelectron spectroscopy (XPS) and infrared spectroscopic ellipsometry measurements (see section S3). Since the absorption coefficients of MeO-2PACz and 2PACz are rather similar,<sup>3</sup> it can be concluded that hole transfer from MeO-2PACz to the ITO is much less efficient than from 2PACz or Me-4PACz. 

###### Trapping of electrons photogenerated in the perovskite at the SAM-modified ITO/HaP interface 

Having established that the hole transfer efficiency is lower for MeO-2PACz compared with 2PACz and Me-4PACz, we now turn our attention to investigate by time-resolved measurements how this observed difference translates to the charge transfer kinetics in the perovskite layers deposited on the different SAMs. All timeresolved measurements shown hereinafter were performed using front excitation (illumination through the perovskite side). To verify that the illumination direction does not play a significant role in determining the shape of the transients, a comparison between front versus back illumination using different excitation wavelengths is shown in section S4. Usually, since the SAMs serve as an HTL, at first sight, it may seem that a shorter PL decay is an indication for a faster hole transfer or quenching of holes in the HaP absorber, an interpretation that is widely common in the literature.<sup>38–40</sup> However, a faster PL decay can also be caused by other processes such as electron trapping, as will be shown in the following by comparing PL and SPV transients measured under identical conditions. Figure 3 shows in (A) and (B) a comparison between tr-PL and tr-SPV for two different samples, ITO/MeO-2PACz/HaP and ITO/Me-4PACz/HaP, using a repetition rate of frep = 1 kHz. Figure 3A shows that the PL decay of the layer stack with Me-4PACz is significantly slower than when using MeO-2PACz as HTL. 

Figure 3B shows SPV transients for the same samples. The negative SPV transient in the entire time range for the ITO/Me-4PACz/HaP sample reveals that Me-4PACz serves as a selective layer for holes, which promotes hole injection to the ITO, resulting in an accumulation of electrons in the perovskite layer. The minimum in the SPV indicates that almost all holes are transferred into the ITO; the subsequent increase suggests that they slowly recombine with electrons across the interface. In the case of MeO-2PACz, a different transient is found: a positive maximum in SPV is observed at short timescales (t < 1 ms), which indicates electron trapping at the interface. The subsequent negative SPV signal indicates the transfer of holes to the ITO. The fact that the minimum in the SPV signal is reached at much shorter times for Me4PACz (t < 1 ms) than for MeO-2PACz (t � 8 ms) is strong evidence that the hole transfer rate to ITO is significantly higher for the Me-4PACz molecules. In addition, the negative SPV amplitude was nearly five times higher for ITO/Me-4PACz/HaP than for ITO/MeO-2PACz/HaP. Thus, an additional process occurred in ITO/MeO2PACz/HaP, shortly after the laser pulse, leading to a higher density of electrons in the MeO-2PACz-modified ITO/HaP interface compared with the surface of the 

2920 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 





Figure 3. tr-PL versus tr-SPV transients (A and B) tr-PL (normalized) (A) versus tr-SPV (B) for ITO/MeO-2PACz/HaP (red) and ITO/Me-4PACz/ HaP (green) using a 515 nm laser at a frequency of 1 kHz. (C) Normalized SPV (black, multiplied by �1 for the sake of comparison) and PL (blue) transients for ITO/Me-4PACz/HaP using a 515 nm laser, at a frequency of 125 kHz. The vertical dashed line highlights the rise time (see text) of the SPV transient and the dashed line on the PL transient is shown to illustrate the change from the fast initial decay to the mono-exponential decay at t > 300 ns. 

perovskite. This additional fast process (t < 1 ms), which is observed for ITO/MeO2PACz/HaP, can be explained by fast electron trapping close to the MeO-2PACzmodified ITO/HaP interface. Fast electron trapping also explains the faster PL decay observed for ITO/MeO-2PACz/HaP. Therefore, when tr-SPV and tr-PL are measured under the same conditions, both methods are complementary and enable to determine in a non-ambiguous way that the fast PL decay seen for ITO/MeO-2PACz/HaP is caused by fast electron trapping at the MeO-2PACz-modified ITO/HaP interface, rather than the common interpretation of faster hole transfer in ITO/MeO-2PACz/ HaP compared with ITO/Me-4PACz/HaP. 

For ITO/Me-4PACz/HaP, the PL decay is dominated by quenching, i.e., fast hole transfer from HaP into ITO, and by the recombination lifetime. As was shown recently, for samples with high decay times, the hole transfer time can be approximated from the PL decay by the initial differential decay time.<sup>23</sup> Thus, for the sake of comparison with the PL transient shown in Al-Ashouri et al.,<sup>9</sup> the PL transient was measured at a higher frequency (frep = 125 kHz, Figure 3C, blue). From the PL transient, by inspecting the early times when the PL decay changes to a single-exponential decay, the hole transfer time amounts to roughly 300 ns for ITO/Me-4PACz/ HaP, in excellent agreement with the value reported recently.<sup>9</sup> 

Figure 3C shows the normalized absolute SPV transient for ITO/Me-4PACz/HaP (frep = 125 kHz). The SPV signal reached its maximum at a time of 300 ns (rise time, marked by a dashed line). In the SPV measurement, this rise time corresponds 

Joule 5, 2915–2933, November 17, 2021 2921 

Article 

OPEN ACCESS 

#### **ll** 

directly to the transport time of photogenerated holes from the HaP absorber into the ITO and gives evidence that the interpretation of the PL decay was correct and agrees well with the hole extraction time that was found using the differential lifetime analysis<sup>22</sup> used in Al-Ashouri et al.<sup>9</sup> 

Thus, in the case of ITO/Me-4PACz/HaP, tr-SPV is found to be a direct and simple method to assess the hole transfer time, without the need for numerical modeling or complex analysis. In contrast, for ITO/MeO-2PACz/HaP, such a simple analysis cannot be made due to the overlap with the identified competing process of electron trapping at the MeO-2PACz-modified ITO/HaP interface at times shorter than about 1 ms. The observed correlation between PL and SPV decay suggests that at the time when the maximum SPV signal is reached, recombination of charge carriers via different recombination paths, as well as the rate of hole back transfer from the ITO to the HaP, overcomes the rate of hole transfer into the ITO. In order to understand and describe these systems more carefully and to extract the specific hole transfer rate constant from the tr-SPV transients, modeling with the help of a kinetic model is used, as shown later in the text. 

###### SPV transients over a wide time range 

Figure 4 shows SPV transients measured at frep = 2 Hz, on a logarithmic timescale up to 100 ms for ITO/HaP (A) and for ITO/SAM/HaP (SAM: MeO-2PACz, 2PACz, and Me-4PACz, (B)–(D), respectively), whereas the intensity of the laser pulses was varied between 0.03 and 46 mJ/cm<sup>2</sup> . For comparison, 0.03 mJ/cm<sup>2</sup> laser fluence generates approximately the same charge carrier density as under steady-state 1-sun conditions � 3 3 10<sup>15</sup> cm<sup>�3</sup> . Such intensity-dependent measurements can reveal the influence of traps on the charge carrier dynamics and the interplay between charge transfer, trapping, and de-trapping as a function of the charge carrier generation and thus the injection level. For the bare ITO substrate (Figure 4A), the sign of all SPV transients was positive over the whole-time range, i.e., electrons were preferentially separated toward the ITO/HaP interface. As expected for hole-selective ITO/SAM contacts (Figures 4B–D), the SPV transients were negative. Due to electron trapping at the ITO/ SAM contact, as mentioned before, small positive SPV signals appeared at very short times for MeO-2PACz for all intensities and 2PACz, although with very small signals. 

For the bare ITO contact, the maximum SPV signals reached values of only 1 mV for 0.03 mJ/cm<sup>2</sup> and 18 mV for 46 mJ/cm<sup>2</sup> within about 400 and 30 ns, respectively. For all intensities, the decays of the SPV transients can be approximated by a superposition of two processes, being more clearly separated for high intensities. At high intensities, the initial positive maxima in the SPV signals decreased within about 0.6 ms and increased again afterward within 2 ms before decreasing again, resulting in a second maximum. 

For the ITO/SAM contacts, for the low intensity of 0.03 mJ/cm<sup>2</sup> , the maximum negative SPV signals were reached within about 70 ms (MeO-2PACz), and 0.2 ms (Me-4PACz). For the ITO/MeO-2PACz contact and a laser intensity of 46 mJ/cm<sup>2</sup> , a first negative maximum of �46 mV was reached at about 0.8 ms and a second negative maximum of �48 mV was reached at 12 ms, whereas the process leading to the first negative maximum evolved like a shoulder at shorter times for the intermediate intensities. On the other side, shoulders appeared at longer times (range of about 10–100 ms) in the transients of ITO/2PACz/HaP and ITO/Me-4PACz/HaP. The highest SPV signals (�72 mV) were reached in the maximum intensity for ITO/Me-4PACz/ HaP (46 mJ/cm<sup>2</sup> ), meaning that hole separation is most efficient for pulsed excitation of this sample. Overall, the kinetics of charge separation varied over more than two 

2922 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 





Figure 4. SPV transients excited at frep = 2 Hz (A–D) SPV transients excited at frep = 2 Hz for ITO/HaP (A) and for ITO/SAM/HaP with MeO-2PACz (B); 2PACz (C) and Me-4PACz (D). The laser fluences were P = 46, 5, 0.43, and 0.03 mJ/cm<sup>2</sup> (black, red, blue, and green lines, respectively). The excitation wavelength was 600 nm. 

orders of magnitude, from 0.2 to 70 ms, depending on the SAM. We further note, that since the vertical diameters of the perovskite grains were larger than the thickness of the perovskite films deposited on the different SAM contacts (as shown in Figure S2), i.e., the influence of suitable different distributions of grain boundaries on the kinetics of charge separation could be neglected, the observed differences are mainly attributed to the different trapping/de-trapping processes occurring at the SAMmodified ITO/HaP interface. 

At times longer than about 1 ms, SPV signals were observed for all samples, where the highest signals at long times in relation to the negative maximum were measured for MeO-2PACz. A very slow relaxation of SPV signals can be related to very slow de-trapping processes, transport limitations due to low conductivity or potential barriers for back transfer of charge carriers.<sup>17</sup> 

The phenomena related to SPV transients over a wide time range on ITO/SAM/HaP are summarized in Figure 5. At very short times, small positive signals appeared, which are most pronounced for MeO-2PACz and which are related to the trapping of electrons in the SAM-modified ITO/HaP interface. Then, the SPV signals rose to a first negative maximum in the time range of 0.1–1 ms due to the transfer of holes to the ITO. It followed a decay (or shoulder) of the SPV signals within about 1 ms due to recombination of electrons and holes. A second local negative maximum (or shoulder) appeared within 1–50 ms, followed by a decay within about 0.5–1 ms and a decay within hundreds of ms. 

Since the dynamic processes that are usually associated with a timescale of tens of ms are de-trapping of charge carriers<sup>41,42</sup> and since the relative magnitude of this 

Joule 5, 2915–2933, November 17, 2021 2923 

**ll** OPEN ACCESS 

Article 





Figure 5. Summary of the different phenomena occurring in SPV transients over a wide time range 

Summary of the different phenomena occurring in SPV transients over a wide time range and corresponding assignment of dominating processes in the different time ranges. The processes include fast trapping of electrons near the ITO/SAM interface, followed by hole transfer to the ITO, radiative and non-radiative recombination of e-h pairs in the perovskite layer, release of trapped electrons from the ITO/SAM interface to the perovskite layer, and recombination of de-trapped and back-transferred charge carriers. 

feature increased with the decreasing intensity of the laser pulses, the second negative maximum (or shoulder) can be assigned to the release of electrons from occupied trap states at the SAM-modified ITO/HaP interface toward the perovskite layer. The magnitude of this additional feature differed substantially between the different SAMs. This is most notable in MeO-2PACz, where the second maximum is most pronounced (see Figure 4B), resulting in even higher SPV values compared with the initial SPV rise. The fact that for MeO-2PACz a clear signal of a trapping process occurred at the short times is in line with the fact that this sample also exhibited the largest increase in the retarded SPV signal between 1–50 ms, resulting from a release of the trapped electrons from the SAM-modified ITO/HaP interface to the bulk of the perovskite. Based on the comparison between the different SAMs shown in Figure 4, the extent of electron trapping at the ITO surface is largest for the bare ITO, followed by MeO-2PACz, 2PACz, and is nearly absent in Me-4PACz (no positive peak was observed at t < 0.1 ms). 

###### Interfacial trap densities and hole transfer rates 

The extraction of charge transfer rate constants and densities of traps at interfaces from SPV transients demands rather complex models, since the simultaneous change in the distribution of charge carriers both in time and space should be considered in simulations of SPV transients.<sup>43–45</sup> The application of ITO/SAM/HaP 

2924 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

##### Article 



systems and a relatively high value of frep allowed for a drastic simplification of the simulation model for SPV transients and even for the extraction of parameters by the fitting of measured SPV transients with simulated SPV transients. 

In our model, since the timescales of the carrier dynamics probed using tr-SPV range from several tens of ns to the ms-sec range, the influence of drift and diffusion on SPV transients is neglected, i.e., charge carriers are assumed to be homogeneously distributed in the HaP layer. This assumption is reasonable due to short transit times (of the order of 2–20 ns for a layer thickness (L) of 0.5 mm and diffusion constants of 0.1–1 cm<sup>2</sup> /s )<sup>9,46,47</sup> and due to the very low density of equilibrium charge carriers in HaP (the width of a space charge region would be much larger than the layer thickness).<sup>48</sup> The influence of very slow relaxation processes (t > 1 ms), observed for frep = 2 Hz, was eliminated by choosing frep = 1 kHz for the measurements. At this value of frep, trapping and de-trapping of electrons are practically not influenced by slow relaxation processes due to the much shorter time ranges involved (1–50 ms). Furthermore, the charge separation length for calculating the SPV was kept constant at half of the layer thickness.<sup>17</sup> This assumption is also reasonable since the SAM layer and the width of the surface space charge region at the ITO surface are much thinner than the thickness of the HaP layer and because the charge carriers are homogeneously distributed over the HaP layer. This allows to solve the model without considering boundary conditions, implying that in the model, the bulk cannot be distinguished from the respective interfaces. However, in the model it is needed to account for a positive experimental SPV signal due to trapped electrons in the SAM-modified ITO/HaP interface. Hence, in the calculation of the SPV signal (see Equation 7 further on), the density of the interfacial electron traps, Nit, is formally merged into the SAM layer (see Figure 1A), and these trapped electrons are not considered to reside in the HaP layer. Thus, whereas in the model the interfacial trap density is considered per volume (units of cm<sup>�3</sup> ), the interfacial trap density was converted to surface trap densities N<sup>~</sup> it where N<sup>~</sup> it is equal to Nit 3 L/2 (in units of cm<sup>�2</sup> ).<sup>49</sup> 

The kinetic model to describe the SPV transients applied here (see also Figure S10) contains 6 rate equations for the densities of holes (p) and electrons (n) in the HaP layer, of holes (pITO) and electrons (nITO) in the ITO layer, and electrons in bulk trap states (nt) and interfacial trap states (nit) (1–6) and one equation for the calculation of the SPV signals (7). For Equation 7, a net-charge balance was performed within the HaP layer, which, according to charge neutrality, is equal to the net charge outside the HaP layer, p-n-nt = nITO + nit � pITO, and the charge separation distance was assumed to be half the layer thickness, L/2. The band-to-band free carrier photogeneration is assumed by setting the initial condition n = p = 6.2 3 10<sup>14</sup> cm<sup>�3</sup> at t = 0 (for more details see section S6). The rate equations contain transfer and back transfer rate constants for holes and electrons (Kh, Ke, Khb, and Keb, see Figure 1A, respectively) and the parameters Cb, ni, Nit, Nt, vh, ve, sht, set, sith, site, sit, and tiD (radiative recombination constant, density of intrinsic charge carriers in HaP, density of interface traps per unit volume, density of traps in HaP, thermal velocity of holes, thermal velocity of electrons, capture cross sections for holes and electrons at traps in HaP and at interface traps, respectively, and electron lifetime at interface traps). The dielectric constant of vacuum and the relative dielectric constant are denoted by ε0 and εr, respectively. More details are given in section S6. 



<!-- Start of picture text -->
dp<br>dt = � Khp + KhbpITO � Cb �pn � ni 2 � � pshtvhnt � psithvhnit (Equation 1)<br><!-- End of picture text -->

Joule 5, 2915–2933, November 17, 2021 2925 

**ll** OPEN ACCESS 



Article 



<!-- Start of picture text -->
dn nit<br>dt = � Ken + KebnITO � Cb �np � ni 2 � � nsetveðNt � ntÞ � nsiteveðNit � nitÞ + tiD<br>(Equation 2)<br>dnt<br>dt = nsetveðNt � ntÞ � pshtvhnt (Equation 3)<br>dpITO<br>= Khp � KhbpITO (Equation 4)<br>dt<br>dnITO<br>= Ken � KebnITO (Equation 5)<br>dt<br>dnit nit<br>dt = nsitveðNit � nitÞ � psithvhnit � tiD (Equation 6)<br>L �p � n � nt� L<br>SPV = 2 , εr ε0 (Equation 7)<br><!-- End of picture text -->

Figure 6A illustrates simulated SPV transients with the effect of increasing N<sup>~</sup> it. For a given set of charge transfer parameters (Kh, Ke, Khb, and Keb) as indicated in the caption, when N<sup>~</sup> it increases from a low value of 2.5 3 10<sup>8</sup> up to 2 3 10<sup>12</sup> cm<sup>�2</sup> (corresponds to Nit values of 10<sup>13</sup> up to 10<sup>16</sup> cm<sup>�3</sup> ), a gradual increase in a positive SPV signal is observed in the timescale of 1 ns–10 ms. An increasing value of N<sup>~</sup> it leads to a larger density of electrons trapped at the SAM-modified ITO/HaP interface and results in an excess of holes in the HaP layer and therefore inducing a change from predominantly negative to predominantly positive SPV signals. 

Figure 6B illustrates simulated SPV transients and the effect of increasing hole transfer rate constant for a given N<sup>~</sup> it (see caption). It can be seen that as Kh gradually increases from 10<sup>3</sup> to 10<sup>7</sup> s<sup>�1</sup> , the SPV becomes more negative, and at some point (Kh > 10<sup>6</sup> s<sup>�1</sup> in the specific case shown in Figure 6B) the rate of hole transfer overcomes the rate of interfacial trapping of electrons at the SAM-modified ITO/HaP interface. Therefore, the positive SPV signal at the short times diminishes. The comparison of the experimental SPV transients shown in Figure 4 with the simulated transients in Figures 6A and 6B demonstrates that the characteristic features in the SPV transients can be very well reproduced by the model and therefore account for the interplay between trap passivation and hole transfer rate. Thus, the simulation results reveal the dual function of the SAMs as a selective contact: (1) passivation of the ITO surface to prevent trapping of electrons and (2) fast transfer of photogenerated holes into the ITO. 

The excellent reproduction of the characteristic features in the tr-SPV transients by our model simulations allows to fit measured SPV transients with a minimum number of fitting parameters and to extract transfer rate constants and trapping parameters. In the fits, the parameters N<sup>~</sup> it, Kh,Ke, Khb, and Keb were kept variable depending on the given interface, whereas the parameters of bulk HaP were kept constant, i.e., independent of the sample (the parameters of bulk HaP are given in the SI, table T2). Figure 6C shows the measured and fitted transients for the bare ITO/HaP and ITO/ MeO-2PACz/HaP, ITO/2PACz/HaP, and Me-4PACz/HaP samples. 

In order to investigate the influence of chain length on transfer rates, we have compared samples comprising nPACz molecules, with n being 2, 4, or 6 denoting the number of hydrocarbons in the (insulating) aliphatic chain. Figure 6D compares 

2926 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

##### Article 





Figure 6. Simulated and fitted tr-SPV curves (A) Simulated tr-SPV curves as a function of varying N<sup>~</sup> it (A) and Kh (B), all other parameters were kept constant as the values found for MeO-2PACz (see Table S3). (C) tr-SPV of the different SAM/perovskite samples including the fitting results shown in black. (D) Hole transfer rate constants for Me-4PACz compared with nPACz series extracted by fitting the tr-SPV measurements. All tr-SPV measurements were performed under frep = 1 kHz. For all simulations, the injection level was kept constant at 6.2 3 10<sup>14</sup> cm<sup>�3</sup> . 

measured and fitted SPV transients for ITO/nPACz/HaP (n = 2, 4, 6) and ITO/Me4PACz/HaP. The slope of the initial rise of the SPV transients decreases as the chain length increases, meaning that the hole transfer rates decrease with increasing chain length of nPACz (which was further confirmed using a laser repetition rate of 2 Hz and back illumination, as shown in Figure S9). The reduction of the hole transfer rates is caused by an increase in the width of the tunneling barrier with increasing aliphatic chain length. However, despite the fact that Me-4PACz and 4PACz have a similar chain length, Me-4PACz exhibits a much faster hole transfer, even faster than 2PACz. This difference could be related to the strong influence of the overall dipole, the specific functional group termination and/or differences in the morphology of the SAMs on the shape of the barrier. 

Figure 7 summarizes the fitting results for the different samples, yielding different values of interfacial trap densities and charge transfer rate constants —N<sup>~</sup> it, Kh,Ke, Khb, and Keb for each of the samples (for a list of values see Table S3). Figure 7 shows that bare ITO does not form a hole-selective contact with HaP (Ke was even larger than Kh). Therefore, the positive tr-SPV signal for ITO/HaP is a combination of preferential injection of electrons to the ITO and of electron trapping at the ITO/HaP interface. In contrast, for the ITO/SAM/HaP systems, the values of Kh were much larger than Ke, demonstrating the hole-selectivity of the different SAMs. When comparing the different SAMs, a clear trend of increasing Kh is seen, suggesting that the hole transfer rate is the highest for Me-4PACz, followed by the nPACz series where Kh is roughly 4–10 times lower, depending on the carbon-chain length, and 

Joule 5, 2915–2933, November 17, 2021 2927 

**ll** OPEN ACCESS 

Article 





Figure 7. Summary of the fitting results for the different ITO/SAM/HaP samples (A) Hole versus electron transfer rate constants (Kh versus Ke), the dashed line corresponds to Kh = Ke (lack of selectivity). 

(B) Kh versus interfacial trap density, N<sup>~</sup> it. the numbers 2, 4, and 6 denote the chain length in the nPACz series. 

even about 1–2 orders of magnitudes lower for MeO-2PACz. This trend is in line with the charge separation efficiency of the isolated ITO/SAM systems shown in Figure 2B and points to the crucial role of the SAM in the overall charge carrier dynamics of the ITO/SAM/HaP system. We note that the obtained range of Kh values for the SAMmodified contacts, 10<sup>5</sup> –10<sup>6</sup> s<sup>�1</sup> , is 2–3 orders of magnitudes lower than the Kh values reported by Hutter et al. for standard HTL such as Spiro-OMeTAD using timeresolved microwave conductivity (TRMC) measurements.<sup>50</sup> On the one hand, the lower Kh values for the SAM-modified contacts w.r.t. to the reported Kh values for Spiro-OMeTAD, and, on the other hand, the superior solar cell performance of HaP solar cells utilizing SAM-modified contacts as HTL suggest that a higher passivation quality of the SAM-modified ITO/HaP interface compared with significant losses due to non-radiative recombination in the ITO/Spiro-OMeTAD/HaP interfaces, overweighs the relatively slower hole extraction rates for the SAM-modified ITO/ HaP contacts. The highest value of interfacial electron trap states N<sup>~</sup> it (10<sup>11</sup> cm<sup>�2</sup> ) and the lowest value of hole transfer rate constants Kh (3.8 3 10<sup>4</sup> s<sup>�1</sup> ) were obtained for ITO/HaP. In contrast, the lowest value of N<sup>~</sup> it (� 2 3 10<sup>9</sup> cm<sup>�2</sup> ) and the highest value of Kh (4.7 3 10<sup>6</sup> s<sup>�1</sup> ) were obtained for ITO/Me-4PACz/HaP. Thus, for Me4PACz, the characteristic time until about 2/3 of the holes have been transferred into the ITO, i.e., 1/Kh, amounts to �213 ns, in excellent agreement with the SPV rise time of 300 ns extracted from Figure 3C. This shows that the application of 

2928 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 





Figure 8. Correlation plots for the different SAMs (A) Open-circuit voltage versus the density of interface traps. 

(B) Fill factor versus the hole transfer rate constant of the corresponding solar cells (the FF values were taken from Al-Ashouri et al.<sup>9</sup> ). Error bars indicate the standard deviation of values recorded from at least 5 solar cells. 

Me-4PACz molecules for the formation of a SAM led to a highly efficient passivation of interface traps with a density of surface states as low as at highly passivated c-Si surfaces.<sup>51</sup> 

The extracted Kh and N<sup>~</sup> it values can be used to compare the hole transfer rate with the trapping rate of electrons on the SAM-modified ITO/HaP interface �siteveNit. For N<sup>~</sup> it value of 4 3 10<sup>9</sup> cm<sup>�2</sup> (corresponds to Nit value of 1.6 3 10<sup>14</sup> cm<sup>�3</sup> in 2PACz) a trapping rate of 5 3 10<sup>4</sup> s<sup>�1</sup> is obtained. Therefore, in cases where Kh >> siteveNit, as is the case for 2PACz and Me-4PACz (Kh = 1.1–4.7 3 10<sup>6</sup> s<sup>�1</sup> ), negligible losses due to trap-assisted non-radiative interfacial recombination are expected, as discussed next. 

###### Correlation to device performance 

Larger values of N<sup>~</sup> it imply additional losses in the open-circuit voltage (VOC) due to trap-assisted non-radiative interfacial recombination. In Figure 8A, the values of VOC of solar cells, which also contain an electron-selective contact (an identical electronselective contact, C60, was used for all samples), are correlated with N<sup>~</sup> it for identically prepared samples but without the electron-selective contacts. For a bare ITO/HaP contact, the VOC is much lower than the SAM-modified ITO contacts, as one would expect from a value of N<sup>~</sup> it of about 10<sup>11</sup> cm<sup>�2</sup> . The reason is that ITO is more electron selective than hole selective, so that a photoinduced potential with the opposite sign additionally reduces VOC. For the ITO/MeO-2PACz/HaP stack, an interfacial trap density of N<sup>~</sup> it = 5 3 10<sup>10</sup> cm<sup>�2</sup> , improves the Voc over bare ITO stacks. Further reducing the interfacial trap density to a value of about N~ it = 4 3 10<sup>9</sup> cm<sup>�2</sup> , the VOC remained practically constant for 2PACz and Me4PACz at the highest level of 1.165 V on average, i.e., this high VOC is not limited by such low values of N<sup>~</sup> it anymore. 

The fill factor (FF) of solar cells depends sensitively on series resistances. High series resistance reduces the short-circuit current and the FF of the solar cell. Tunnel barriers at charge-selective contacts can introduce additional series resistance into solar cells. All the SAMs in this study contain an insulating aliphatic carbon chain, CnH2n, which poses a tunnel barrier for charge carrier transfer. The width of the tunnel barrier is determined by the chain length, n, and the resistance is expected to increase with increasing tunneling barrier width.<sup>52</sup> In general, the transport properties of the 

Joule 5, 2915–2933, November 17, 2021 2929 

Article 

OPEN ACCESS 

#### **ll** 

hole-selective tunnel barrier are merged in the value of Kh. In Figure 8B, the values of FF are correlated with Kh for identically prepared samples based on nPACz (n = 2, 4, and 6) and Me-4PACz, but without the electron-selective contacts. The value of the FF increased with increasing Kh and reached the highest value for the highest Kh. Thus, since the electron transfer rate is not the rate-limiting step in the solar cell operation, as demonstrated and discussed in section S5, the hole-transfer rate can significantly limit the FF. Therefore, the chain length of the molecules in the SAMs can control the hole transfer rate and also the FF due to the increased tunneling distance. However, due to the fact that the hole transfer rate of Me-4PACz is significantly faster than that of 2PACz and 4PACz, it is clear that the chemical structure of the molecular head group—here, the methyl group versus H, also plays an important role in charge transfer. This is not surprising since the dipole-related SPV signals were significantly larger for Me-4PACz than for 2PACz (Figure 2B), i.e., dipoles can strongly influence the shape of tunnel barriers. In addition, for other conjugated SAM systems, An et al. suggested that as the electronic cloud distribution of the HOMO of the SAM becomes more aggregated and continuous, the rate of hole transfer enhances.<sup>53</sup> Whether this conclusion also applies to the different SAMs studied here remains to be determined. It can be suggested that the enhanced hole transfer rate and FF for Me-4PACz could be related to the �0.1 eV increase in the WF observed for Me-4PACz (Figure 2A), leading to an increase in the barrier height for electron transfer to the ITO (FB,e in Figure 1A). A similar effect (which is sometimes referred to as ‘‘back surface field’’) was also suggested by Knesting et al. for OSCs<sup>54</sup> and can help suppress non-radiative recombination at the HTL contact and thus enhance the selectivity of Me-4PACz compared with the nPACz series.<sup>55</sup> However, it is also important to note that other factors aside from the WF of the SAM-modified ITO affect the hole transfer rate. Among them are the tunneling length (given mainly by the insulating chain length and the orientation of the SAMs with respect to the surface), the specific interaction between the SAM’s functional group and the first perovskite layer on top, and whether the dipole effect, observed on the bare SAM-modified ITO, remains the same after the deposition of the perovskite layer. 

###### Conclusion 

In this work, hole-selective contact systems for HaP films based on SAMs bound to ITO electrodes were studied by transient surface photovoltage (SPV). Transient SPV proved to be a powerful technique that provides new insights on the different loss mechanisms and charge transfer limitations in high-efficiency solar cell devices. Thanks to the fact that transient SPV requires only a bottom contact, it enabled to study and optimize specifically the ITO/SAM/HaP interface. Although the interpretation of transient SPV is often complex due to the different charge carrier dynamic processes that occur simultaneously, the combination of transient SPV and transient PL allowed to identify electron trapping in the ITO/HaP interface and to unambiguously determine the charge carrier separation and recombination processes over several orders of magnitudes in time. It was shown that electron traps at the ITO can be well passivated by carbazole-based SAMs with phosphonic acid anchoring groups and that the chain length of the molecules and the head groups can strongly influence the passivation and charge transfer kinetics. A minimalistic kinetic model based only on rate equations has been developed for the simulation of SPV transients. Values of parameters important for suitable limitations in solar cells, such as the density of interface traps ðN<sup>~</sup> it) and the hole transfer rate constant (Kh), were obtained by modeling measured SPV transients with excellent agreement between simulation and experiment. By applying our kinetic model, we find that the main loss mechanisms are insufficient hole selectivity and electron trapping at the SAM-modified ITO/HaP interface. The optimal 

2930 Joule 5, 2915–2933, November 17, 2021 

**ll** OPEN ACCESS 

Article 



SAM, based on Me-4PACz for the given experiments, not only provided the fastest hole transfer rate constant to the ITO (4.7 3 10<sup>6</sup> s<sup>�1</sup> ) but also the highest degree of passivation of the ITO, with a very low density of interfacial electron traps (� 2 3 10<sup>9</sup> cm<sup>�2</sup> ). The extracted quantities of interfacial trap densities and hole transfer rate constants correlated very well with the resulting VOC and the FF of corresponding solar cells and explain the remarkable performance of the Me-4PACz SAM, leading to the recent record photoconversion efficiency of perovskite/silicon tandem solar cells of 29.15%.<sup>9</sup> 

We suggest that our model can be applied to future transient SPV studies utilizing combinations of other absorbers and contact materials, in cases where spatial distribution of charge carriers in the absorber layer can be neglected due to fast diffusion of the charge carriers. We believe that our findings can stimulate further density functional theory analysis to predict the effect of the exact molecular structure of the different SAMs on the density of interfacial traps as well as the charge transfer rate from the absorber to the selective contact. In the future, transient SPV could be used as a powerful tool for the investigation of buried interfaces, which enables quantification of the passivation quality and charge extraction kinetics of different selective contacts for thin-film optoelectronic devices, enabling them to reach their maximum theoretical efficiency. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Igal Levine ( igal.levine@helmholtz-berlin.de). 

###### Materials availability 

This study did not generate new unique reagents. 

###### Data and code availability 

The data that support the findings of this study are available from the corresponding author upon reasonable request 

Full details of experimental procedures can be found in the supplemental information. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2021.07.016. 

###### ACKNOWLEDGMENTS 

I.L. thanks the PEROSEED project and the AiF project (ZIM-KK5085302DF0) for financial support. V.G., A.M., and A.D. acknowledge funding from the Research Council of Lithuania under grant agreement no. 01.2.2-LMT-K-718-03-0040 (SMARTMOLECULES). K.H. thanks Ilona Engler for her technical support and funding by the European Union through EFRE 1.8/13. The financial support by the Ministerium fu¨ r Innovation, Wissenschaft und Forschung des Landes NordrheinWestfalen, the Senatsverwaltung fu¨ r Wirtschaft, Technologie und Forschung des Landes Berlin, and the Bundesministerium fu¨ r Bildung und Forschung are also gratefully acknowledged. D.M., A.A.-A. and S.A. acknowledge funding by the Federal Ministry for Education and Research (BMBF) grant 03SF0540 within the project ‘‘Materialforschung fu¨ r die Energiewende’’; the HyPerCells Graduate School; the 

Joule 5, 2915–2933, November 17, 2021 2931 

**ll** OPEN ACCESS 

Article 



Helmholtz Association within the HySPRINT Innovation lab and the TAPAS project. H.H., T.U. and A.M. acknowledge financial support from the German Science Foundation (DFG) in the framework of the priority program SPP 2196. A.M. thanks Roman Grill for fruitful discussions. 

###### AUTHOR CONTRIBUTIONS 

I.L. and A.A.-A. initiated the research and planned the experiments with input from T.D.; A. Magomedov, A.D., and V.G. provided the SAMs; A.A.-A. prepared the perovskite and SAM layers; I.L., H.H., and T.D. performed the CPD, tr-SPV and tr-PL measurements; A. Musiienko developed the kinetic model and performed the simulations; D.M. performed and analyzed the XPS measurements; K.H. performed and analyzed the IRSE measurements; I.L. analyzed all data and took the lead in drafting the manuscript; I.L. and T.D. wrote the paper with input from the other authors. All authors contributed to the discussion of the results. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: May 17, 2021 Revised: June 28, 2021 Accepted: July 27, 2021 Published: August 18, 2021 

###### REFERENCES 

1. Dittrich, T. (2014). Materials Concepts for Solar Cells (Imperial College Press). 

2. Green, M.A., Dunlop, E.D., Hohl-Ebinger, J., Yoshita, M., Kopidakis, N., and Hao, X. (2020). Solar cell efficiency tables, (version 56). Prog. Photovoltaics Res. Appl. 28, 629–638. 

3. Al-Ashouri, A., Magomedov, A., Roß, M., Jo�st, M., Talaikis, M., Chistiakova, G., Bertram, T., Ma´rquez, J.A., Ko¨ hnen, E., Kasparavi�cius, E., et al. (2019). Conformal monolayer contacts with lossless interfaces for perovskite single junction and monolithic tandem solar cells. Energy Environ. Sci. 12, 3356–3369. 

4. Kim, J.Y., Lee, J.W., Jung, H.S., Shin, H., and Park, N.G. (2020). High-efficiency perovskite solar cells. Chem. Rev. 120, 7867–7918. 

5. Kegelmann, L., Wolff, C.M., Awino, C., Lang, F., Unger, E.L., Korte, L., Dittrich, T., Neher, D., Rech, B., and Albrecht, S. (2017). It takes two to tango-double-layer selective contacts in perovskite solar cells for improved device performance and reduced hysteresis. ACS Appl. Mater. Interfaces 9, 17245–17255. 

6. Fakharuddin, A., Schmidt-Mende, L., GarciaBelmonte, G., Jose, R., and Mora-Sero, I. (2017). Interfaces in perovskite solar cells. Adv. Energy Mater. 7, 1700623. 

7. Roose, B., Wang, Q., and Abate, A. (2018). The role of charge selective contacts in perovskite solar cell stability. Adv. Energy Mater. 9, 1803140. 

8. Har-Lavan, R., Yaffe, O., Joshi, P., Kazaz, R., Cohen, H., and Cahen, D. (2012). Ambient organic molecular passivation of Si yields nearideal, Schottky-Mott limited, junctions. AIP Adv. 2, 012164. 

9. Al-Ashouri, A., Ko¨ hnen, E., Li, B., Magomedov, A., Hempel, H., Caprioglio, P., Ma´rquez, J.A., Morales Vilches, A.B.M., Kasparavicius, E., Smith, J.A., et al. (2020). Monolithic perovskite/ silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300–1309. 

10. Lin, Y., Firdaus, Y., Isikgor, F.H., Nugraha, M.I., Yengel, E., Harrison, G.T., Hallani, R., El-Labban, A., Faber, H., Ma, C., et al. (2020). Self-assembled monolayer enables hole transport layer-free organic solar cells with 18% efficiency and improved operational stability. ACS Energy Lett. 5, 2935–2944. 

11. Lin, Y., Magomedov, A., Firdaus, Y., Kaltsas, D., El-Labban, A., Faber, H., Naphade, D.R., Yengel, E., Zheng, X., Yarali, E., et al. (2021). 18.4% organic solar cells using a high ionization energy self-assembled monolayer as hole extraction interlayer. ChemSusChem. https:// doi.org/10.1002/cssc.202100707. 

12. Stolterfoht, M., Caprioglio, P., Wolff, C.M., Ma´rquez, J.A., Nordmann, J., Zhang, S., Rothhardt, D., Ho¨ rmann, U., Amir, Y., Redinger, A., et al. (2019). The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. Energy Environ. Sci. 12, 2778–2788. 

13. Kim, J., Godin, R., Dimitrov, S.D., Du, T., Bryant, D., McLachlan, M.A., and Durrant, J.R. (2018). Excitation density dependent photoluminescence quenching and charge transfer efficiencies in hybrid perovskite/ organic semiconductor bilayers. Adv. Energy Mater. 8, 1802474. 

14. Caprioglio, P., Wolff, C.M., Sandberg, O.J., Armin, A., Rech, B., Albrecht, S., Neher, D., and Stolterfoht, M. (2020). On the origin of the ideality factor in perovskite solar cells. Adv. Energy Mater. 10, 2000502. 

15. Green, M.A., and Ho-Baillie, A.W.Y. (2019). Pushing to the limit: radiative efficiencies of recent mainstream and emerging solar cells. ACS Energy Lett. 4, 1639–1644. 

16. Guillemoles, J.F., Kirchartz, T., Cahen, D., and Rau, U. (2019). Guide for the perplexed to the Shockley–Queisser model for solar cells. Nat. Photonics 13, 501–505. 

17. Dittrich, T., and Fengler, S. (2020). Surface Photovoltage Analysis of Photoactive Materials (World scientific). 

18. Hutter, E.M., Kirchartz, T., Ehrler, B., Cahen, D., and Von Hauff, E. (2020). Pitfalls and prospects of optical spectroscopy to characterize perovskite-transport layer interfaces. Appl. Phys. Lett. 116, 100501. 

19. Yang, Z., Dou, J., and Wang, M. (2018). Interface Engineering in n-i-p Metal Halide perovskite Solar Cells. Sol. RRL 2, 1800177. 

20. Han, T.H., Tan, S., Xue, J., Meng, L., Lee, J.W., and Yang, Y. (2019). Interface and defect engineering for metal halide perovskite optoelectronic devices. Adv. Mater. 31, e1803515. 

21. Yang, X., Luo, D., Xiang, Y., Zhao, L., Anaya, M., Shen, Y., Wu, J., Yang, W., Chiang, Y.H., Tu, Y., et al. (2021). Buried interfaces in halide perovskite photovoltaics. Adv. Mater. 33, e2006435. 

2932 Joule 5, 2915–2933, November 17, 2021 

##### Article 

22. Stolterfoht, M., Wolff, C.M., Ma´rquez, J.A., Zhang, S., Hages, C.J., Rothhardt, D., Albrecht, S., Burn, P.L., Meredith, P., Unold, T., et al. (2018). Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. Nat. Energy 3, 847–854. 

23. Krogmeier, B., Staub, F., Grabowski, D., Rau, U., and Kirchartz, T. (2018). Quantitative analysis of the transient photoluminescence of CH 3 NH 3 PbI 3 /PC 61 BM heterojunctions by numerical simulations. Sustainable Energy Fuels 2, 1027–1034. 

24. Pea´n, E.V., Dimitrov, S., De Castro, C.S., and Davies, M.L. (2020). Interpreting time-resolved photoluminescence of perovskite materials. Phys. Chem. Chem. Phys. 22, 28345–28358. 

25. Kiligaridis, A., Frantsuzov, P.A., Yangui, A., Seth, S., Li, J., An, Q., Vaynzof, Y., and Scheblykin, I.G. (2021). Are Shockley-Read-Hall and ABC models valid for lead halide perovskites? arXiv. https://doi.org/10.1038/ s41467-021-23275-w. 

26. Kirchartz, T., Ma´rquez, J.A., Stolterfoht, M., and Unold, T. (2020). Photoluminescence-based characterization of halide perovskites for photovoltaics. Adv. Energy Mater. 10, 1904134. 

27. Kudriashova, L.G., Kiermasch, D., Rieder, P., Campbell, M., Tvingstedt, K., Baumann, A., Astakhov, G.V., and Dyakonov, V. (2017). Impact of interfaces and laser repetition rate on photocarrier dynamics in lead halide perovskites. J. Phys. Chem. Lett. 8, 4698–4703. 

28. Shao, G., Glaz, M.S., Ma, F., Ju, H., and Ginger, D.S. (2014). Intensity-modulated scanning Kelvin probe microscopy for probing recombination in organic photovoltaics. ACS Nano 8, 10799–10807. 

29. Ntia, T.S., Supasai, T., Tang, I., Amornkitbumrung, V., Yuan, J., Li, Y., Dittrich, T., and Rujisamphan, N. (2019). An analytical approach to CH 3 NH 3 PbI 3 Perovskite Solar Cells Based on Different Hole Transport Materials. Phys. Status Solidi 216, 1900087. 

30. Paniagua, S.A., Giordano, A.J., Smith, O.L., Barlow, S., Li, H., Armstrong, N.R., Pemberton, J.E., Bre´ das, J.L., Ginger, D., and Marder, S.R. (2016). Phosphonic acids for interfacial engineering of transparent conductive oxides. Chem. Rev. 116, 7117–7158. 

31. Magomedov, A., Al-Ashouri, A., Kasparavi�cius, E., Strazdaite, S., Niaura, G., Jo�st, M., Malinauskas, T., Albrecht, S., and Getautis, V. (2018). Self-assembled hole transporting monolayer for highly efficient perovskite solar cells. Adv. Energy Mater. 8, 1801892. 

32. Haj-Yahia, A.E., Yaffe, O., Bendikov, T., Cohen, H., Feldman, Y., Vilan, A., and Cahen, D. (2013). Substituent variation drives metal/monolayer/ semiconductor junctions from strongly rectifying to ohmic behavior. Adv. Mater. 25, 702–706. 

33. Sommerhalter, C., Matthes, T.W., Glatzel, T., Ja¨ger-Waldau, A., and Lux-Steiner, M.C. (1999). High-sensitivity quantitative Kelvin probe microscopy by noncontact ultra-high-vacuum 

atomic force microscopy. Appl. Phys. Lett. 75, 286–288. 

34. Li, L.S., Jia, Q.X., and Li, A.D.Q. (2002). Effects of organic self-assembled polymer and metal phthalocyanine multilayers on the surface photovoltaic properties of indium tin oxide and titanium oxide. Chem. Mater. 14, 1159–1165. 

35. Hu, J., Pan, J., Zhu, F., and Gong, H. (2004). Evidence of nitric-oxide-induced surface band bending of indium tin oxide. J. Appl. Phys. 95, 6273–6276. 

36. Kronik, L., and Shapira, Y. (2001). Surface photovoltage spectroscopy of semiconductor structures: at the crossroads of physics, chemistry and electrical engineering. Surf. Interface Anal. 31, 954–965. 

37. Dittrich, T., Macor, L., Gervaldo, M., Fungo, F., Otero, L., Lin, C.Y., Chi, L.C., Fang, F.C., Lii, S.W., Wong, K.T., et al. (2013). Charge separation in donoracceptor spiro compounds at metal and metal oxide surfaces investigated by surface photovoltage. J. Nanosci. Nanotechnol. 13, 5158–5163. 

38. Hou, Y., Chen, X., Yang, S., Li, C., Zhao, H., and Yang, H.G. (2017). A band-edge potential gradient heterostructure to enhance electron extraction efficiency of the electron transport layer in highperformance perovskite solar cells. Adv. Funct. Mater. 27, 1700878. 

39. Gu, P.Y., Wang, N., Wang, C., Zhou, Y., Long, G., Tian, M., Chen, W., Sun, X.W., Kanatzidis, M.G., and Zhang, Q. (2017). Pushing up the efficiency of planar perovskite solar cells to 18.2% with organic small molecules as the electron transport layer. J. Mater. Chem. A 5, 7339–7344. 

40. Kim, S.Y., Cho, S.J., Byeon, S.E., He, X., and Yoon, H.J. (2020). Self-assembled monolayers as interface engineering nanomaterials in perovskite solar cells. Adv. Energy Mater. 10, 2002606. 

41. Neukom, M., Zu¨ fle, S., Jenatsch, S., and Ruhstaller, B. (2018). Opto-electronic characterization of third-generation solar cells. Sci. Technol. Adv. Mater. 19, 291–316. 

42. Neukom, M.T., Schiller, A., Zu¨ fle, S., Knapp, E., A<sup>´</sup> vila, J., Pe´ rez-Del-Rey, D., Dreessen, C., Zanoni, K.P.S., Sessolo, M., Bolink, H.J., and Ruhstaller, B. (2019). Consistent device simulation model describing perovskite solar cells in steady-state, transient, and frequency domain. ACS Appl. Mater. Interfaces 11, 23320–23328. 

43. Mora-Sero´ , I., Dittrich, T., Garcia-Belmonte, G., and Bisquert, J. (2006). Determination of spatial charge separation of diffusing electrons by transient photovoltage measurements. J. Appl. Phys. 100, 103705. 

44. Dittrich, T., Mora-Sero´ , I., Garcı´aBelmonte, G., and Bisquert, J. (2006). Temperature dependent normal and anomalous electron diffusion in porous Ti 

#### **ll** OPEN ACCESS 

O2 studied by transient surface photovoltage. Phys. Rev. B 73, 045407. 

45. Fengler, S., Kriegel, H., Schieda, M., Gutzmann, H., Klassen, T., Wollgarten, M., and Dittrich, T. (2020). Charge transfer in c-Si(n++)/TiO2(ALD) at the amorphous/anatase transition: a transient surface photovoltage spectroscopy study. ACS Appl. Mater. Interfaces 12, 3140– 3149. 

46. Levine, I., Gupta, S., Bera, A., Ceratti, D., Hodes, G., Cahen, D., Guo, D., Savenije, T.J., A<sup>´</sup> vila, J., Bolink, H.J., et al. (2018). Can we use time-resolved measurements to get steadystate transport data for halide perovskites? J. Appl. Phys. 124, 103103. 

47. Kru¨ ckemeier, L., Krogmeier, B., Liu, Z., Rau, U., and Kirchartz, T. (2021). Understanding transient photoluminescence in halide perovskite layer stacks and solar cells. Adv. Energy Mater. 11, 2003489. 

48. Levine, I., Gupta, S., Brenner, T.M., Azulay, D., Millo, O., Hodes, G., Cahen, D., and Balberg, I. (2016). Mobility–lifetime products in MAPbI3 films. J. Phys. Chem. Lett. 7, 5219–5226. 

49. Wang, J., Fu, W., Jariwala, S., Sinha, I., Jen, A.K.-Y., and Ginger, D.S. (2019). Reducing surface recombination velocities at the electrical contacts will improve perovskite photovoltaics. ACS Energy Lett. 4, 222–227. 

50. Hutter, E.M., Hofman, J.-J., Petrus, M.L., Moes, M., Abello´ n, R.D., Docampo, P., and Savenije, T.J. (2017). Charge transfer from methylammonium lead iodide perovskite to organic transport materials: efficiencies, transfer rates, and interfacial recombination. Adv. Energy Mater. 7, 1602349. 

51. Liebhaber, M., Mews, M., Schulze, T.F., Korte, L., Rech, B., and Lips, K. (2015). Valence band offset in heterojunctions between crystalline silicon and amorphous silicon (sub)oxides (a-SiOx:H, 0 < x < 2). Appl. Phys. Lett. 106, 031601. 

52. Levine, I., Weber, S.M., Feldman, Y., Bendikov, T., Cohen, H., Cahen, D., and Vilan, A. (2012). Molecular length, monolayer density, and charge transport: lessons from Al-AlOx/alkylphosphonate/Hg junctions. Langmuir 28, 404–415. 

53. An, D., Liu, H., Wang, S., and Li, X. (2019). Modification of ITO anodes with selfassembled monolayers for enhancing hole injection in OLEDs. Appl. Phys. Lett. 114, 153301. 

54. Knesting, K.M., Ju, H., Schlenker, C.W., Giordano, A.J., Garcia, A., Smith, O.L., Olson, D.C., Marder, S.R., and Ginger, D.S. (2013). ITO interface modifiers can improve v OC in polymer solar cells and suppress surface recombination. J. Phys. Chem. Lett. 4, 4038– 4044. 

55. Chen, Q., Wang, C., Li, Y., and Chen, L. (2020). Interfacial dipole in organic and perovskite solar cells. J. Am. Chem. Soc. 142, 18281– 18292. 



Joule 5, 2915–2933, November 17, 2021 2933 

