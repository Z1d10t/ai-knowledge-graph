# Homogenized contact in all-perovskite tandems using tailored 2D perovskite

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 197 |
| 作者 | Yu-Rui Wang, Ren-Xing Lin, Chenshuaiyu Liu, Xiao-Yu Wang, Cullen Chosy, Yuki Haruta, A. D. Bui, Ming-Hui Li et al. |
| DOI | 10.1038/s41586-024-08158-6 |
| 源文件 | 063_Wang_2024_Homogenized-contact-in-all-perovskite-tandems-us.pdf |

---
Article 

# **Homogenized contact in all-perovskite tandems using tailored 2D perovskite** 

|https://doi.org/10.1038/s41586-024-08158-6<br>Received: 20 September 2023<br>Accepted: 4 October 2024|**Yurui Wang**<sup>**1,9**</sup>**, Renxing Lin**<sup>**1,9**</sup>**, Chenshuaiyu Liu**<sup>**1,9**</sup>**, Xiaoyu Wang**<sup>**2,9**</sup>**, Cullen Chosy**<sup>**3,4,9**</sup>**, Yuki Haruta**<sup>**5**</sup>**,**<br>**Anh Dinh Bui**<sup>**6**</sup>**, Minghui Li**<sup>**7**</sup>**, Hongfei Sun**<sup>**1**</sup>**, Xuntian Zheng**<sup>**1**</sup>**, Haowen Luo**<sup>**1**</sup>**, Pu Wu**<sup>**1**</sup>**, Han Gao**<sup>**1**</sup>**,**<br>**Wenjie Sun**<sup>**1**</sup>**, Yuefeng Nie**<sup>**1**</sup>**, Hesheng Zhu**<sup>**1**</sup>**, Kun Zhou**<sup>**2**</sup>**, Hieu T. Nguyen**<sup>**6**</sup>**, Xin Luo**<sup>**8**</sup>**, Ludong Li**<sup>**1**</sup>**,**<br>**Chuanxiao Xiao**<sup>**7**</sup>**, Makhsud I. Saidaminov**<sup>**5**</sup>**, Samuel D. Stranks**<sup>**3,4** ✉</sup>**, Lijun Zhang**<sup>**2** ✉</sup>**& Hairen Tan**<sup>**1,8** ✉</sup>|
|---|---|
|Published online: 14 October 2024||
|Check for updates|The fabrication of scalable all-perovskite tandem solar cells is considered an<br>attractive route to commercialize perovskite photovoltaic modules<sup>1</sup>. However,<br>the certified efficiency of 1-cm<sup>2</sup>-scale all-perovskite tandem solar cells lags behind<br>their small-area (approximately 0.05-cm<sup>2</sup>) counterparts<sup>2,3</sup>. This performance deficit<br>originates from inhomogeneity in wide-bandgap (WBG) perovskite solar cells (PSCs)<br>at a large scale. The inhomogeneity is known to be introduced at the bottom interface<br>and within the perovskite bulk itself<sup>4,5</sup>. Here we uncover another crucial source for<br>the inhomogeneity—the top interface formed during the deposition of the electron<br>transport layer (ETL; C60). Meanwhile, the poor ETL interface is also a notable<br>limitation of device performance. We address this issue by introducing a mixture of<br>4-fluorophenethylamine (F-PEA) and 4-trifluoromethyl-phenylammonium (CF3-PA)<br>to create a tailored 2D perovskite layer (TTDL), in which F-PEA forms a 2D perovskite at<br>the surface, reducing contact losses and inhomogeneity, and CF3-PA enhances charge<br>extraction and transport. As a result, we demonstrate a high open-circuit voltage (_V_oc)<br>of 1.35 V and an efficiency of 20.5% in 1.77-eV WBG PSCs at a square-centimetre scale.<br>By stacking with a narrow-bandgap (NBG) perovskite subcell, we report 1.05-cm<sup>2</sup><br>all-perovskite tandem cells delivering 28.5% (certified 28.2%) efficiency, the highest<br>reported so far. Our work showcases the importance of treating the top perovskite/<br>ETL contact for upscaling PSCs.|



Advances in NBG and WBG perovskites facilitated the development of tandem devices, including all-perovskite tandem solar cells, at small scale (about 0.05 cm<sup>2</sup> active area) with the best certified power conversion efficiency (PCE) of more than 28% (refs. 2,3,6–9). Nevertheless, all-perovskite tandems with an active area ≥1 cm<sup>2</sup> have only been reported at a certified PCE of 26.4% (ref. 4). There is still great room for improvement for the WBG PSCs, especially at the square-centimetre scale, which limits the performance of all-perovskite tandem solar cells. 

WBG PSCs suffer from large losses in the _V_ oc and the fill factor (FF) owing to high trap densities and inhomogeneity of the perovskite layer<sup>10,11</sup> . A well-known strategy to address these issues is to modify the bottom hole transport layer (HTL). This approach affects not only the defect density at the HTL/perovskite interface but also the nucleation and growth of the perovskite layer<sup>4,12,13</sup> . Zhao and colleagues treated the bottom HTL with a self-assembled monolayer (SAM) to suppress the _V_ oc loss and to improve the uniformity, leading to a record PCE at the time of 26.4% in 1-cm<sup>2</sup> all-perovskite tandem devices<sup>4</sup> . However, even these advanced WBG PSCs show _V_ oc losses 

exceeding 170 mV (for the bandgap of 1.77 eV, the Shockley–Queisser _V_ oc limit is 1.49 V)<sup>14</sup> . 

To further minimize losses in WBG PSCs, it is now important to also modify the top, perovskite/ETL interface. C60 and its derivatives are the ETL choice in nearly all efficient tandem devices owing to their high electron affinity and mobility, even though losses at the perovskite/C60 interface tend to increase with the bandgap of perovskite<sup>15,16</sup> . Therefore, it is necessary to develop interface layers as effective as fluoride in 1.68-eV perovskite<sup>17,18</sup> . Studies suggest that the trap states at the perovskite/C60 interface are introduced in the process of deposition of C60, rather than originating from the perovskite surface itself<sup>15,19,20</sup> . Warby et al. reported that the trap states increased substantially when the first few nanometres of C60 interfaced with perovskite<sup>21</sup> . A common strategy to treat the perovskite/C60 interface is to insert an insulating layer in between them. However, the use of patterned polymers (such as poly(methyl methacrylate) (PMMA)) requires complex photolithographic techniques, and the use of continuous insulating films deteriorates device performance<sup>21–23</sup> . Growing 2D perovskite at the 

> 1National Laboratory of Solid State Microstructures, College of Engineering and Applied Sciences, Frontiers Science Center for Critical Earth Material Cycling, Nanjing University, Nanjing, China.<sup>2</sup> State Key Laboratory of Integrated Optoelectronics, Key Laboratory of Automobile Materials of MOE, Key Laboratory of Material Simulation Methods & Software of MOE, School of Materials Science and Engineering, Jilin University, Changchun, China.<sup>3</sup> Department of Chemical Engineering and Biotechnology, University of Cambridge, Cambridge, UK.<sup>4</sup> Cavendish Laboratory, University of Cambridge, Cambridge, UK.<sup>5</sup> Department of Chemistry, University of Victoria, Victoria, British Columbia, Canada.<sup>6</sup> School of Engineering, The Australian National University, Canberra, Australian Capital Territory, Australia.<sup>7</sup> Ningbo Institute of Materials Technology and Engineering, Chinese Academy of Sciences, Ningbo City, China.<sup>8</sup> Research and Development Center, Renshine Solar (Suzhou) Co. Ltd., Suzhou, China.<sup>9</sup> These authors contributed equally: Yurui Wang, Renxing Lin, Chenshuaiyu Liu, Xiaoyu Wang, Cullen Chosy. ✉ e-mail: sds65@cam.ac.uk; lijun_zhang@jlu.edu.cn; hairentan@nju.edu.cn 

Nature | Vol 635 | 28 November 2024 | **867** 

## Article 

interface is another strategy<sup>24–26</sup> , but even a single 2D perovskite layer limits charge extraction because of reduced electrical conductivity and type I energy-level alignment<sup>27,28</sup> . 

Here we report that deposition of C60 introduces not only a high density of defects at the interface but also non-uniform electrostatic potential on the perovskite surface, resulting in inhomogeneous device performance. We address this issue by introducing a mixture of F-PEA and CF3-PA to create a TTDL at this interface. As a result, we demonstrate a PCE of more than 20% in 1.05-cm<sup>2</sup> 1.77-eV WBG PSCs. When integrated with a 1.25-eV NBG PSC, we achieve a record PCE of 28.5% (certified 28.2%) for a 1.05-cm<sup>2</sup> tandem, higher than even the record-certified PCE of 28.0% for small-area (0.05-cm<sup>2</sup> ) all-perovskite tandem solar cells reported so far<sup>3</sup> . 

### **Uniformity of WBG PSCs** 

In our previous study, we developed a molecular bridge NiO/SAM HTL, in which SAM was a mixture of 2PACz ([2-(9H-carbazol-9-yl)ethyl]phosphonic acid) and MeO-2PACz ([2-(9H-carbazol-9-yl)ethyl]phosphonic acid)<sup>13</sup> . This HTL provides sufficient wettability for the growth of high-quality perovskite films and effectively suppresses defects at the HTL/perovskite interface. We further found that using anisole as an antisolvent instead of commonly used chlorobenzene improves the crystallinity and uniformity of WBG perovskite films thanks to the well-controlled solvent volatilization (Supplementary Note 1, Supplementary Figs. 1–6 and Supplementary Table 1). Although these approaches improved the absolute performance of the WBG PSCs, the gap between the 1-cm<sup>2</sup> device and the 0.05-cm<sup>2</sup> devices remained large (Supplementary Fig. 6). We reasoned that inhomogeneity is still present in the device not only at the bottom interface and in the perovskite bulk but largely at the top perovskite/C60 interface. 

We performed a photoluminescence (PL) microscopy intensity images study of glass/ITO/NiO/SAM/perovskite before and after C60 deposition (Fig. 1a). After the deposition of C60, the PL intensity decreased and the standard deviation ( _σ_ ) of the PL intensity distribution increased from 3.7% to 5.2%, and this trend was observed in images measured in several regions (Supplementary Figs. 7 and 8). The overall loss in PL intensity can be attributed to increased interfacial non-radiative recombination and charge-carrier transfer to C60, so an increase in PL heterogeneity reflects an undesirable increase in the local variation of these properties. 

We further used the PL mapping to examine the effect of interface modifiers with various action mechanisms on the spatial uniformity of perovskite/C60 sandwiches (Fig. 1b). Specifically, we used PMMA as an insulating layer, as it is known to benefit the perovskite contact with C60 (ref. 21), F-PEA to construct surface 2D perovskite<sup>29,30</sup> , 1,2-ethane-diammonium (EDA) to reduce perovskite surface defects<sup>19,31</sup> and CF3-PA to anchor to perovskite grains and promote charge transfer<sup>3</sup> . The sample without an insertion layer is labelled as ‘control’. To visualize the uniformity, we normalized the images to steady-state PL intensity (Supplementary Fig. 9). EDA deteriorated the uniformity of the emission from the perovskite/C60 stack, whereas CF3-PA did not change it. By contrast, both PMMA and F-PEA greatly improved the uniformity of the PL maps, which we attribute to the reduced electrical conductivity of these insertion layers shielding the contact potential of the perovskite surface against C60. 

To investigate how the changes observed on the PL maps translate to device performance, we fabricated 1.05-cm<sup>2</sup> WBG PSCs and measured the external quantum efficiency (EQE) at eight positions of the active area (Fig. 1c). Consistent with the PL mapping studies, the control, CF3-PA and EDA devices showed a wide distribution of EQE spectra, whereas the F-PEA and PMMA devices showed completely overlapping spatial EQE, indicating improved uniformity. The PMMA, as expected from its insulating nature, led to marked EQE suppression and hence a low short-circuit current density ( _J_ sc) of 15.9 mA cm<sup>−2</sup> . Of all the insertion 

layers we studied, only CF3-PA devices achieved a _J_ sc increase compared with control devices. 

Therefore, we planned to combine two modifiers to complement each other: F-PEA, which, as we showed above, makes a uniform interface but suffers from charge-carrier transport; and CF3-PA, which, as we also showed above, enhances charge transport but suffers from non-uniformity. We called this strategy ‘tailored 2D perovskite layer’ (TTDL) (Fig. 1d). The details for TTDL surface treatment are discussed in Methods. The TTDL perovskite indeed exhibited the highest PL intensity, uniformity in PL maps (Fig. 1b) and _J_ sc in EQE profiles (Fig. 1c; 18.4 mA cm<sup>−2</sup> ). Compared with control samples (Fig. 1a), the standard deviation of the TTDL stack did not change substantially after C60 deposition (Fig. 1e). Kelvin probe force microscopy (KPFM) studies agree with our findings (Supplementary Figs. 10 and 11): when C60 is deposited on a control perovskite film, the contact potential broadens the electronic states on the surface of perovskite, expanding the surface heterogeneity<sup>19,21,32</sup> . However, this is not the case for TTDL perovskites, whose KPFM profiles largely remained intact after deposition of C60. A uniform surface potential distribution results in a high _V_ oc because minimizing potential fluctuations helps maintain the energy of carriers during their transport<sup>33</sup> . 

### **Mechanism and function of TTDL** 

We now discuss the mechanism of TTDL, analysing both molecules separately. We first investigated the treated perovskite surfaces using X-ray photoelectron spectroscopy (XPS; see Supplementary Fig. 12). _F_ 1S signals of 686.6 eV and 687.4 eV indicate that F-PEA and CF3-PA are present in the perovskite sample, respectively<sup>34</sup> . Scanning electron microscopy (SEM) images showed that both F-PEA and CF3-PA slightly increased the grain size but neither changed the thickness of perovskite films (Supplementary Figs. 13 and 14). Grazing-incidence wide-angle X-ray scattering (GI-WAXS) spectra indicated that the F-PEA film showed strong diffraction peaks (about 0.34°) from 2D structure with a composition of (F-PEA)2PbI4 (Fig. 2a). By contrast, there was no diffraction signal at small _q_ value for the CF3-PA film, indicating the absence of detectable 2D perovskites (Supplementary Fig. 15). The TTDL film showed only a weak diffraction deriving from 2D perovskite, although the same amount of F-PEA was used. We hence conclude that the introduction of CF3-PA disrupts the growth of this 2D perovskite. The weakened 2D perovskite signal in the TTDL sample was also observed in powder X-ray diffraction profiles (Supplementary Fig. 16). 

To investigate the spatial distribution of 2D perovskite, time-of-flight secondary-ion mass spectrometry (ToF-SIMS) measurement was conducted (Fig. 2b and Supplementary Fig. 17). The intensity of F-PEA<sup>+</sup> and CF3-PA<sup>+</sup> signals decreased substantially in the initial 40 s of sputtering, indicating that these cations preferentially aggregate towards the surface of the perovskite films. The F-PEA<sup>+</sup> signal in the TTDL film was not different from those in the F-PEA film, suggesting that the addition of CF3-PA did not change the vertical distribution of F-PEA<sup>+</sup> . Therefore, we attribute the reduced 2D perovskite X-ray diffraction peaks to the participation of CF3-PA<sup>+</sup> in the reaction of F-PEA<sup>+</sup> with the perovskite, leading to a more amorphous surface layer. 

We also studied the formation of 2D structures using twice the concentration of post-treatment solution (Supplementary Fig. 18). Post-treatment applied individually or sequentially resulted in different 2D perovskite structures. Suppression of diffraction peaks and shift to low diffraction angles are the most obvious only when CF3-PA and F-PEA are used together, which means that the interlayer spacing of 2D perovskite is extended. We carried out first-principles calculations to investigate the effect of CF3-PA on the structure of F-PEA-based 2D perovskites and found that the most stable structural configuration with the lowest adsorption energy occurs when the CF3-PA situates at the A -site (Supplementary Note 2). 

**868** | Nature | Vol 635 | 28 November 2024 



<!-- Start of picture text -->
a b 1.4 cm Normalized<br>Normalized intensity1.0 Normalized intensity1.0 Col intensity1.0<br>0.8 0.8<br>0.6 0.6 Insertion layer 0.8<br>0.4 0.4 PL mapping<br>Perovskite 0.2 Perovskite/C60 0.2 C 60 Control PMMA EDA 0.6<br>0 0<br>Control/C60 Control Perovskite 0.4<br>6<br>σ  = 3.7% NiO/SAM<br>4 σ  = 5.2% 0.2<br>Glass/ITO<br>2 0<br>0 F-PEA CF3-PA F-PEA and CF3-PA<br>0.4 0.5 0.6 0.7 0.8 0.9 1.0 (TTDL)<br>Normalized intensity<br>c 100<br>80<br>60<br>40<br>20 17.9–18.1 15.9 17.8–18.2 17.3 18.3–18.6 18.4<br>mA cm –2 mA cm –2 mA cm –2 mA cm –2 mA cm –2 mA cm –2<br>Control PMMA EDA F-PEA CF3-PA TTDL<br>0<br>400 500 600 700 400 500 600 700 400 500 600 700 400 500 600 700 400 500 600 700 400 500 600 700<br>Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>d e Normalized intensity Normalized intensity<br>1.0 1.0<br>0.8 0.8<br>Cu TTDL<br>ALD-SnO2 0.6 0.6<br>C60 NH3 NH3 0.4 0.4<br>Tailored 2D Cl Cl 0.2 0.2<br>perovskite layer TTDL TTDL/C60<br>+ 0 0<br>WBG perovskite TTDL/C60 TTDL<br>6<br>σ  = 3.5%<br>σ  = 3.4%<br>F CF3 4<br>NiO/SAM<br>F-PEA CF3-PA<br>ITO 2<br>Glass 1 : 1<br>0<br>0.4 0.5 0.6 0.7 0.8 0.9 1.0<br>Normalized intensity<br>4Count (10)<br>EQE (%)<br>4Count (10)<br><!-- End of picture text -->

**Fig. 1 | Uniformity of perovskite films and devices. a** , PL microscopy images and histograms of glass/ITO/NiO/SAM/perovskite with (dark grey) and without (light grey) C60. Each image has been normalized to its maximum intensity. The mapping area is 660 × 660 µm<sup>2</sup> . The repeated experment is shown in Supplementary Fig. 7. **b** , Schematic diagram and PL mapping images of stack of glass/ITO/NiO/SAM/perovskite/insertion layer/C60 with different insertion layers. The intensity in **b** is normalized to steady-state PL spectra (Supplementary Fig. 9). The imaged area is 1.4 × 1.4 cm<sup>2</sup> . The dashed box 

represents the active region of the 1.05-cm<sup>2</sup> device. **c** , EQE spectra of 1.05-cm<sup>2</sup> WBG PSCs with different insertion layers. Eight positions are selected in the active region of each device. **d** , Schematic diagram of the WBG device and the chemical structure of inserted molecules. **e** , PL microscopy images and pixel histograms of glass/ITO/NiO/SAM/perovskite/TTDL with (dark brown) and without (light brown) C60. Each image has been normalized to its maximum intensity. The mapping area is 660 × 660 µm<sup>2</sup> . The reapeated experment is shown in Supplementary Fig. 7. 

We then studied the photophysical properties of perovskite films coated with different insertion layers. Steady-state PL studies showed that both F-PEA and CF3-PA increased perovskite PL quenching compared with the untreated surface, indicating that a high defect concentration or potential charge transfer was introduced (Supplementary Fig. 19). We further used photoluminescence quantum yield (PLQY) measurements (Supplementary Fig. 20 and Supplementary Table 2), from which we calculated quasi-Fermi level splitting (QFLS) and quantified the source of _V_ oc losses (Fig. 2b). We observed that the 

F-PEA substantially reduced _V_ oc loss at the perovskite/C60 interface compared with the control device, whereas the CF3-PA alone had no notable effect. However, owing to energy-level mismatch resulting in a gradient of the quasi-Fermi level of majority charges, the mismatch between the device _V_ oc and QFLS in F-PEA remains large<sup>12,35</sup> . In TTDL devices, QFLS further increased and the difference between QFLS and _V_ oc reduced. 

Transient photoluminescence (TRPL) studies show that the insertion layers substantially increased the carrier lifetimes<sup>36,37</sup> (Fig. 2c). 

Nature | Vol 635 | 28 November 2024 | **869** 

## Article 



<!-- Start of picture text -->
a 2.0 2.0 2.0<br>Control F-PEA TTDL<br>1.5 1.5 1.5<br>1.0 1.0 1.0<br>2D  n  = 1 Weakened 2D  n  = 1<br>0.5 0.5 0.5<br>0 0 0<br>–1.0 –0.5 0 0.5 1.0 –1.0 –0.5 0 0.5 1.0 –1.0 –0.5 0 0.5 1.0<br>qy  (Å –1 ) qy  (Å –1 ) qy  (Å –1 )<br>b c d –3<br>1,600 PVK bulk loss Control<br>HTL/PVK interface loss –3.59<br>1,550 ETL/PVK interface loss Radiative F-PEA –3.83 –3.92<br>CF3-PA –4<br>Pin stack Device  V oc V oc limit<br>1,500 TTDL –4.66 –4.50<br>1,450 –5<br>1,400<br>–5.60<br>1,350 –6 –5.96<br>–6.27 –6.20<br>1,300 –6.43<br>Control F-PEA CF3-PA TTDL 0 50 100 150 200 250 300 –7 Control F-PEA CF3-PA TTDL C60<br>Time (ns)<br>e f g 0<br>3D-host 3D-Pbi 3D-VPb<br>2 3D-Ii 3D-VI C60<br>1 C60 LUMO –1<br>3D-PVK<br>0<br>PVK  VBM Host Ii Pbi VI VPb<br>0<br>2D-host 2D-VI 2D-CF3<br>2 2D-Ii 2D-VPb C60<br>2D-Pbi C60 LUMO<br>1 –1<br>2D-PVK<br>0<br>F-PEA TTDL –2 PVK 0VBM 2 4 Host Ii Pbi VI VPb CF3<br>Energy (eV)<br>Surface type<br>–1 (Å) qz –1 (Å) qz –1 (Å) qz<br>Intensity (a.u.)<br>PL intensity<br>Energy (eV)<br>QFLS, q (meV) V oc<br> (eV) E adsorb<br>–1–3–2 ÅDOS (states eV) 10<br> (eV) E adsorb<br><!-- End of picture text -->

**Fig. 2 | The formation mechanism and function of TTDL with enhanced uniformity. a** , GI-WAXS patterns of control, F-PEA and TTDL perovskite films. The colour scale shows intensity in arbitrary units from low (dark green) to high (light green). **b** , QFLS values extracted from the PL spectra for neat perovskite (PVK), HTL/perovskite and HTL/perovskite/insertion layer/ETL. **c** , The TRPL decay curves of the control, F-PEA, CF3-PA and TTDL perovskite films covered with C60. **d** , The band alignment of perovskite film treated by control, F-PEA, CF3-PA and TTDL. The data are derived from a combination of UPS and ultraviolet– visible light absorption in Supplementary Figs. 22 and 23. **e** , The calculated electron wavefunction distribution, that is, partial charge density integrated 

within the energy range of 0.3 eV above the CBM (isosurface = 0.0005 e Bohr<sup>−3</sup> ) of F-PEA-based 2D perovskite and a possible molecular arrangement in a portion of the TTDL. **f** , Calculated DOS of 3D perovskite/C60 and 2D perovskite/ C60 interfaces with different point defects. The energy of different cases was aligned by the vacuum energy level. The DOS of isolated C60 is given and its occupied molecular orbital is set to energy zero. Intrinsic defects in proximity to the interface including interstitial Pb (Pbi), interstitial I (Ii), Pb vacancy (VPb) and I vacancy (VI) are considered. The defect-free 2D perovskite surface with CF3-PA is calculated (2D-CF3). **g** , Adsorption energies of C60 on 3D and 2D perovskite surfaces with different point defects. 

We calculated the differential lifetime from TRPL traces measured under low excitation fluence to distinguish charge extraction and trap-assisted recombination (Supplementary Fig. 21). The PL decay at early time windows is dominated by the transfer of electrons from perovskite to C60 and at longer delay times by interfacial recombination<sup>36,38</sup> . We found that the CF3-PA substantially accelerated charge extraction at the perovskite/ C60 interface, as it showed a faster decay in early times. This indicates that CF3-PA alone is less effective than F-PEA in reducing non-radiative recombination but plays an essential role in electron extraction, consistent with the PLQY results. We plot the energy-level arrangement of perovskite films in Fig. 2d, derived from a combination of ultraviolet photoelectron spectroscopy (UPS) and ultraviolet–visible absorption 

(Supplementary Figs. 22 and 23). The F-PEA alone lifted the conduction band minimum (CBM) at the perovskite surface, which impedes the interfacial charge transport owing to the formation of 2D structures with an even wider bandgap (2.3 eV). The introduction of CF3-PA, acting to lower the CBM, reduces the energy-level mismatch between perovskite and C60, thereby enhancing electron extraction and transport. We further performed first-principles calculations to investigate the effect of introducing CF3-PA on the electron extraction properties of F-PEA-based 2D perovskites (Supplementary Note 2 and Supplementary Figs. 24–26). We found that the introduction of CF3-PA leads to a downward shift of CBM in 2D perovskites. The underlying mechanism is attributed to the direct contribution of CF3-PA to the band-tail states 

**870** | Nature | Vol 635 | 28 November 2024 



<!-- Start of picture text -->
a b<br>18.5 20<br>1.34<br>18.0<br>1.32<br>15<br>1.30 17.5<br>1.28 17.0<br>10<br>82.5 20 Control<br>80.0 19 5 F-PEA<br>CF3-PA<br>77.5 18 TTDL<br>75.0 17 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 1.4<br>Control F-PEA CF3-PA TTDL Control F-PEA CF3-PA TTDL Voltage (V)<br>c d 20 e 100<br>90<br>80<br>Non-radiative 15<br>recombination loss<br>60<br>85<br>10<br>Transport loss 40<br>80<br>S–Q limit 5 Reverse, PCE = 20.4% 20 EQE,  J sc = 18.6 mA cm –2<br>Forward, PCE = 20.5%<br>p-JV FF<br>75 Real-cell FF 0 0<br>Control F-PEA CF3-PA TTDL 0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 300 400 500 600 700 800<br>Voltage (V) Wavelength (nm)<br> (V) V oc<br>–2 (mA cm) J sc<br>–2)Current density (mA cm<br>FF (%) PCE (%)<br>FF (%) EQE (%)<br>–2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 3 | The performance of WBG PSCs. a** , Comparison of photovoltaic performance between control, F-PEA, CF3-PA and TTDL WBG solar cells processed in the same runs (1.05 cm<sup>2</sup> , 15 devices for each type). The box lines indicate the standard deviation and the centre represents the mean value. **b** , The _J_ – _V_ curves of champion 1.05-cm<sup>2</sup> control, F-PEA, CF3-PA and TTDL WBG solar cells. **c** , Schematic 

of FF loss mechanisms. The Shockley–Queisser (S–Q) limit is obtained from the radiative efficiency limit, pseudo- _J_ – _V_ (p-JV) FF are obtained from pseudo- _J_ – _V_ , whereas real-cell FF are obtained in Fig 2b. **d** , **e** , The _J_ – _V_ curve and EQE spectra of the champion TTDL WBG solar cell (aperture area, 1.05 cm<sup>2</sup> ). 

near the CBM, combined with its interaction with the greatly distorted Pb-I octahedral framework. This is anticipated to enhance charge extraction at the insertion layer interface between perovskite and C60, aligning well with the aforementioned experimental observations. 

Drawing on insights from first-principles calculations that investigate thermodynamically stable structures (Supplementary Fig. 24), we explored the insertion of CF3-PA into F-PEA-based 2D perovskite as a potential TTDL structure. The results reveal an optimized landscape for electron transport in the out-of-plane direction (Fig. 2e). This is evidenced by the marked electron charge density overlap between the interlayer molecules and the perovskite octahedra, which is absent in F-PEA-based 2D perovskites alone (Supplementary Fig. 26). This enhanced real-space charge connectivity is expected to improve electron transport along the out-of-plane direction, thereby facilitating more efficient electron extraction<sup>39</sup> . The calculated defect formation energy (Supplementary Fig. 27) suggests that F-PEA-based 2D perovskites play a substantial role in inhibiting defect formation at the interface, which is expected to further reduce the likelihood of electron–hole recombination at the perovskite/C60 interface. 

We subsequently conducted simulations of the perovskite/C60 interface to explore the impact of introducing the TTDL on the homogeneity of the interface. The calculated density of states (DOS) and the adsorption energies of C60 at both 3D and 2D perovskite/C60 interfaces are depicted in Fig. 2f,g. Various intrinsic defects commonly found in perovskite layers were taken into consideration (Supplementary Figs. 28 and 29). At the 3D perovskite/C60 interface, the highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO) of C60 are situated below the CBM and the valence band maximum (VBM) of the perovskite layer. The 2D perovskite/C60 interface leads to a notable downward shift of the VBM of the perovskite layer. These band-alignment results agree well with the experimental data 

(Fig. 2d). As expected, the C60-derived HOMO and LUMO states show negligible changes at both 2D and 3D perovskite/C60 interfaces. In the case of the 3D perovskite/C60 interface, various intrinsic defects result in a substantial variation in the perovskite VBM, spanning approximately 1.3 eV, as illustrated in Fig. 2f. The resultant diminishing energy difference between the perovskite VBM and the C60 LUMO is anticipated to increase the likelihood of electron–hole recombination at the interface. This possibility of recombination is expected to non-uniformly vary with the distribution of various defects. By contrast, for the 2D perovskite/C60 interface, different intrinsic defects result in a mild variation in the perovskite VBM (about 0.4 eV), attributed to the effective dielectric shielding of F-PEA. Such selective adsorption behaviour is expected to lead to decreased uniformity in C60 coverage in the presence of an uneven distribution of different defects. Conversely, the adsorption of C60 on 2D perovskite is predominantly governed by the electrostatic interaction between C60 and terminal F of F-PEA (Supplementary Fig. 29), leading to nearly unchanged adsorption energy under different defect conditions (Fig. 2g, lower panel). This may explain how the formed 2D perovskite layer enhances the uniformity of the perovskite/C60 interface. The above conclusions drawn from the DOS and adsorption-energy results at the 2D perovskite/C60 interface remain applicable with the introduction of CF3-PA. 

Figure 3a and Supplementary Table 3 compare the photovoltaic performance of the control, F-PEA and CF3-PA solar cells (15 devices each) with an active area of 1.05 cm<sup>2</sup> . Compared with control devices, PSCs with F-PEA showed an improved performance across _V_ oc, FF and PCE but a greatly decreased _J_ sc. As discussed above, the increase in _V_ oc is attributed to the formation of 2D perovskite, which reduces defects at the perovskite/C60 interface and effectively blocks holes, whereas the decrease in _J_ sc is because of poor electrical conductivity and suppression of electron transport caused by a shallow LUMO. CF3-PA devices 

Nature | Vol 635 | 28 November 2024 | **871** 

Article 

**Table 1 | Photovoltaic parameters of champion PSCs (aperture area, 1.05 cm**<sup>**2**</sup> **)** 

|**Device**|**Scan direction**|**_V_oc (V)**|**_J_sc (mA cm**<sup>**−2**</sup>**)**|**FF (%)**|**PCE (%)**|
|---|---|---|---|---|---|
|1.77 eV, single|Reverse|1.35|18.4|82.1|20.4|
||Forward|1.36|18.3|82.3|20.5|
|1.22 eV, single|Reverse|0.86|32.8|77.6|21.9|
||Forward|0.86|32.7|77.5|21.9|
|Tandem, in lab|Reverse|2.16|16.4|80.0|28.4|
||Forward|2.17|16.4|80.2|28.5|
|Tandem, certified|Reverse|2.16|16.5|80.3|28.5|
||Forward|2.16|16.6|79.5|28.5|
||Stabilized|–|–|–|28.2|



demonstrated greatly increased FF and _J_ sc owing to improved charge extraction and optimum energy-level arrangement. The _V_ oc of the devices improved by around 30–40 mV when switching from control to TTDL, in line with the QFLS results of Fig. 2d. The corresponding FF also increased on average from about 76.5% to about 78.5% when using the F-PEA and then to 79.5% when mixed with the CF3-PA, confirming that the TTDL did not lead to the formation of a barrier impeding electron extraction. Figure 3b and Supplementary Table 4 compare _J_ – _V_ curves of champion 1.05-cm<sup>2</sup> WBG PSCs: consistent with the trend seen in the statistical data, TTDL devices showed greatly improved _V_ oc and FF. EQE results extracted from the entire active area (1.05 cm<sup>2</sup> ) also showed stronger quantum efficiency across all visible light (Supplementary Fig. 30). The improvements in charge transport are further supported through pseudo- _J_ – _V_ curves from intensity-dependent QFLS measurements<sup>15</sup> , which show the hypothetical performance limit in the absence 

of transport losses (Fig. 3c, Supplementary Note 3, Supplementary Figs. 31 and 32 and Supplementary Table 5). The CF3-PA devices show the lowest difference between pseudo-FF and conventional FF values, indicating the lowest transport-induced losses in the full devices. Compared with F-PEA, TTDL further suppresses interfacial non-radiative recombination and slightly reduces transport losses. We also examined the homogeneity of the complete devices through electroluminescence (EL) mapping measurements (Supplementary Fig. 33), which also indicate higher intensity and spatial uniformity for the TTDL devices. We compared the two insertion layers using sequential deposition and neither sequence achieved performance comparable with TTDL devices, implementing the combined effect of the two molecules in TTDL (Supplementary Fig. 34). We performed the ISOS-L2 protocol (65 °C, AM 1.5G and roughly 20% to 30% relative humidity) for encapsulated WBG single-junction solar cells<sup>40</sup> . The device did not degrade during the measurement, demonstrating reliability under operating conditions, as shown in Supplementary Fig. 35. 

We fabricated more than 50 TTDL WBG PSCs with an area of 1.05 cm<sup>2</sup> . The devices exhibited an average PCE of 18.8 ± 0.7% and an average _V_ oc of 1.33 V (Supplementary Fig. 36). Mott–Schottky plot measurements suggested an improvement of roughly 40 mV in built-in potential ( _V_ bi) in TTDL devices (1.12 V versus 1.17 V, control versus TTDL; Supplementary Fig. 37), which agrees quantitatively with the measured increase in _V_ oc. Also, the TTDL devices had a longer lifetime in transient photovoltage measurement (Supplementary Fig. 38). The best TTDL device with an anti-reflection film showed a PCE of 20.4% ( _V_ oc = 1.35 V, _J_ sc = 18.4 mA cm<sup>−2</sup> and FF = 82.1%) under reverse scan (Fig. 3d and Table 1). Figure 3e presents the EQE spectra of the best TTDL device, with the integrated _J_ sc value of 18.6 mA cm<sup>−2</sup> , in good agreement with the _J_ – _V_ characteristics. Supplementary Fig. 39 shows that the stabilized PCE of the champion device was 20.3%. 



<!-- Start of picture text -->
a b c 100<br>1 –  R<br>16<br>80<br>12<br>60<br>NBG perovskite<br>8<br>40<br>RJ 16.6 mA cm –2 16.6 mA cm –2<br>4 20<br>WBG perovskite Reverse, PCE = 28.4%<br>Forward, PCE = 28.5%<br>0 0<br>0 0.4 0.8 1.2 1.6 2.0 400 600 800 1,000<br>Voltage (V) Wavelength (nm)<br>d e f<br>30<br>2,500 V oc from EL 60 Average PCE27.6 ± 0.9% 0.05-cm 2  scale<br>2,000 V oc of tandem device 22,175,196 50 28 1-cm 2  scale This work<br>40<br>26<br>V oc from EL Zhao et al.<br>1,500 30<br>1,351 864<br>V oc from EL 1,332 20 24 Tan et al.<br>1,000 875<br>10<br>22<br>500 0<br>WBG NBG Tandem 26 27 28 29 2019 2020 2021 2022 2023 2024<br>Devices PCE (%) Year<br>EQE (%)<br>–2Current density (mA cm)<br> (mV) V oc Count PCE (%)<br><!-- End of picture text -->

**Fig. 4 | The performance of monolithic all-perovskite tandem solar cells. a** , Cross-sectional SEM image of all-perovskite tandem solar cell. RJ, recombination junction. Scale bar, 1 µm. **b** , **c** , _J_ – _V_ and EQE curves of the champion tandem device with TTDL. The inset in **b** is a photo of the 1.05-cm<sup>2</sup> WBG device. The total absorption (1 − _R_ ) of the tandem device is shown in **c** . 

**d** , _V_ oc of single-junction WBG, NBG solar cells and tandem solar cells calculated by EQEEL. **e** , The PCE histogram of 220 TTDL devices, exhibiting an average PCE of 27.6 ± 0.9%. **f** , Summary of the reported PCEs of all-perovskite tandem solar cells. Solid symbols are certified values. 

**872** | Nature | Vol 635 | 28 November 2024 

### **All-perovskite tandem solar cells** 

We fabricated square-centimetre-scale monolithic all-perovskite tandem solar cells using the TTDL WBG and NBG sub-cells. The 1.05-cm<sup>2</sup> NBG sub-cells exhibited a PCE of 21.9% (with _V_ oc = 0.86 V, _J_ sc = 32.7 mA cm<sup>−2</sup> and FF = 77.5%; see Supplementary Fig. 40). The thicknesses of the WBG and NBG absorber layers for the front and back sub-cells were 400 and 1,100 nm, respectively (Fig. 4a and Supplementary Fig. 41). We used C60/ SnO2/Au/PEDOT:PSS as the recombination junction owing to its good optical and electrical properties. Figure 4b shows the _J_ – _V_ curves of the best-performing tandem devices measured from both reverse and forward scans, showing no notable hysteresis. The best tandem cell showed a PCE of 28.5% from the reverse scan (with _V_ oc = 2.17 V, _J_ sc = 16.4 mA cm<sup>−2</sup> and FF = 80.2%) and exhibited a stabilized PCE of 28.5% (Fig. 4b and Supplementary Fig. 42). The integrated _J_ sc values of the front and back sub-cells from EQE spectra were 16.6 and 16.6 mA cm<sup>−2</sup> (Fig. 4c), respectively, agreeing well with the _J_ sc value determined from the _J_ – _V_ measurements. Electroluminescence quantum yield (EQEEL) was further used to analyse the _V_ oc loss from single-junction devices to tandem devices<sup>41</sup> . The _V_ oc calculated by EQEEL measured in a single-junction WBG device and WBG sub-cell in a tandem device were 1.35 V and 1.33 V, respectively (Fig. 4d). Considering the small difference between the two, it can be concluded that minimal performance degradation occurs in the WBG sub-cell during the subsequent thermal processing of the tandem device fabrication (Supplementary Note 4, Supplementary Figs. 43–45 and Supplementary Table 6). It should be noted that both the PCE and the _J_ sc of the 1.05-cm<sup>2</sup> device are comparable with the previously reported small-area devices and are much higher than those of previously reported ones with similar areas<sup>3,4,19</sup> , thanks to the improved uniformity. 

We fabricated 220 all-perovskite tandem solar cells with an aperture area of 1.05 cm<sup>2</sup> ; the devices had an average PCE of 27.6 ± 0.9% (Fig. 4e and Supplementary Fig. 46), showing excellent reproducibility. We sent a tandem solar cell to an accredited independent photovoltaic calibration laboratory (Japan Electrical Safety and Environment Technology Laboratories, JET). The device delivered a certified stabilized PCE of 28.2% (Supplementary Fig. 47), which is comparable with that of the best small-area all-perovskite tandem solar cells (Fig. 4f and Supplementary Tables 7 and 8). At the same time, this is also the best demonstrated performance of thin-film solar cells with area >1 cm<sup>2</sup> (Supplementary Table 6). We also fabricated all-perovskite tandem devices using the blade-coating process. We deposited perovskite and TTDL by blade-coating in both WBG single-junction and tandem devices (Supplementary Fig. 48 and Supplementary Table 9). The improved performance validates the potential of TTDL in scaling all-perovskite tandem devices. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-024-08158-6. 

   8. Lee, M. M., Teuscher, J., Miyasaka, T., Murakami, T. N. & Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. _Science_ **338** , 643–647 (2012). 

   9. Burschka, J. et al. Sequential deposition as a route to high-performance perovskitesensitized solar cells. _Nature_ **499** , 316–319 (2013). 

   10. Mahesh, S. et al. Revealing the origin of voltage loss in mixed-halide perovskite solar cells. _Energy Environ. Sci._ **13** , 258–267 (2020). 

   11. Fu, F. et al. High-efficiency inverted semi-transparent planar perovskite solar cells in substrate configuration. _Nat. Energy_ **2** , 16190 (2017). 

   12. Stolterfoht, M. et al. The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. _Energy Environ. Sci._ **12** , 2778–2788 (2019). 

   13. Li, L. et al. Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708–717 (2022). 

   14. Rühle, S. Tabulated values of the Shockley–Queisser limit for single junction solar cells. _Sol. Energy_ **130** , 139–147 (2016). 

   15. Stolterfoht, M. et al. How to quantify the efficiency potential of neat perovskite films: perovskite semiconductors with an implied efficiency exceeding 28%. _Adv. Mater._ **32** , 2000080 (2020). 

   16. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

   17. Penã-Camargo, F. et al. Halide segregation versus interfacial recombination in bromide-rich wide-gap perovskite solar cells. _ACS Energy Lett._ **5** , 2728–2736 (2020). 

   18. Liu, J. et al. Efficient and stable perovskite-silicon tandem solar cells through contact displacement by MgF _x_ . _Science_ **377** , 302–306 (2022). 

   19. Chen, H. et al. Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676–681 (2023). 

   20. Yang, Z. et al. Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. _Nat. Commun._ **10** , 4498 (2019). 

   21. Warby, J. et al. Understanding performance limiting interfacial recombination in pin perovskite solar cells. _Adv. Energy Mater._ **12** , 2103567 (2022). 

   22. Kavadiya, S. et al. Investigation of the selectivity of carrier transport layers in wide‐ bandgap perovskite solar cells. _Sol. RRL_ **5** , 2100107 (2021). 

   23. Peng, J. et al. A universal double‐side passivation for high open‐circuit voltage in perovskite solar cells: role of carbonyl groups in poly(methyl methacrylate). _Adv. Energy Mater._ **8** , 1801208 (2018). 

   24. Cheng, B. et al. Extremely reduced dielectric confinement in two-dimensional hybrid perovskites with large polar organics. _Commun. Phys._ **1** , 80 (2018). 

   25. Li, P. et al. Dredging the charge‐carrier transfer pathway for efficient low‐dimensional Ruddlesden‐Popper perovskite solar cells. _Angew. Chem. Int. Ed._ **62** , 202217910 (2023). 

   26. Yusoff, A. R., bin, M. & Nazeeruddin, M. K. Low-dimensional perovskites: from synthesis to stability in perovskite solar cells. _Adv. Energy Mater._ **8** , 1702073 (2018). 

   27. Li, Z. et al. Hybrid perovskite‐organic flexible tandem solar cell enabling highly efficient electrocatalysis overall water splitting. _Adv. Energy Mater._ **10** , 2000361 (2020). 

   28. Shin, D. et al. The electronic properties of a 2D Ruddlesden‐Popper perovskite and its energy level alignment with a 3D perovskite enable interfacial energy transfer. _Adv. Funct. Mater._ **33** , 2208980 (2023). 

   29. Chen, H. et al. Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photon._ **16** , 352–358 (2022). 

   30. Luo, L. et al. Stabilization of 3D/2D perovskite heterostructures via inhibition of ion diffusion by cross-linked polymers for solar cells with improved performance. _Nat. Energy_ **8** , 294–303 (2023). 

   31. Hu, S. et al. Optimized carrier extraction at interfaces for 23.6% efficient tin–lead perovskite solar cells. _Energy Environ. Sci._ **15** , 2096–2107 (2022). 

   32. Baldo, M. A. & Forrest, S. R. Interface-limited injection in amorphous organic semiconductors. _Phys. Rev. B_ **64** , 85201 (2001). 

   33. Saidaminov, M. I. et al. Multi-cation perovskites prevent carrier reflection from grain surfaces. _Nat. Mater._ **19** , 412–418 (2020). 

   34. He, B. et al. Improving crystallinity and out‐of‐plane orientation in quasi‐2D Ruddlesden‐ Popper perovskite by fluorinated organic salt for light‐emitting diodes. _Small_ **19** , 2303255 (2023). 

   35. Onno, A., Chen, C., Koswatta, P., Boccard, M. & Holman, Z. C. Passivation, conductivity, and selectivity in solar cell contacts: concepts and simulations based on a unified partial-resistances framework. _J. Appl. Phys._ **126** , 183103 (2019). 

   36. Kirchartz, T. et al. Photoluminescence‐based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

   37. Krogmeier, B. et al. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain. Energy Fuels_ **2** , 1027–1034 (2018). 

   38. Krückemeier, L., Krogmeier, B., Liu, Z., Rau, U. & Kirchartz, T. Understanding transient photoluminescence in halide perovskite layer stacks and solar cells. _Adv. Energy Mater._ **11** , 2003489 (2021). 

   39. Ren, H. et al. Efficient and stable Ruddlesden–Popper perovskite solar cell with tailored interlayer molecular interaction. _Nat. Photon._ **14** , 154–163 (2020). 

1. Li, H. & Zhang, W. Perovskite tandem solar cells: from fundamentals to commercial deployment. _Chem. Rev._ **120** , 9835–9950 (2020). 

2. Green, M. A. et al. Solar cell efficiency tables (Version 60). _Prog. Photovolt. Res. Appl._ **30** , 687–701 (2022). 

3. Lin, R. et al. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. _Nature_ **620** , 994–1000 (2023). 

4. He, R. et al. Improving interface quality for 1-cm<sup>2</sup> all-perovskite tandem solar cells. _Nature_ **618** , 80–86 (2023). 

5. Gao, H. et al. Homogeneous crystallization and buried interface passivation for perovskite tandem solar modules. _Science_ **383** , 855–859 (2024). 

6. Kojima, A. et al. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

7. Kim, H.-S. et al. Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. _Sci. Rep._ **2** , 591 (2012). 

40. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

41. Rau, U. Reciprocity relation between photovoltaic quantum efficiency and electroluminescent emission of solar cells. _Phys. Rev. B_ **76** , 085303 (2007). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2024 

Nature | Vol 635 | 28 November 2024 | **873** 

## Article **Methods** 

#### **Materials** 

All materials were used as received without further purification. The organic halide salts (FAI, FABr, MAI, FAI, F-PEACl, CF3-PACl and GuaBF4) were purchased from Greatcell Solar Materials. EDAI2 and PMMA were purchased from Xi’an Polymer Light Technology. PEDOT:PSS aqueous solution (Al 4083) was purchased from Heraeus Clevios. 2PACz (>98.0%) and MeO-2PACz (>98.0%), PbI2 (99.99%), PbBr2 (99.99%), CsI (99.9%) and CsBr (99.9%) were purchased from Tokyo Chemical Industry. SnI2 (99.999%) was purchased from Alfa Aesar. SnF2 (99%), ITO nanocrystals, DMF (99.8% anhydrous), DMSO (99.9% anhydrous), ethyl acetate (99.8% anhydrous) and chlorobenzene (99.8% anhydrous) were purchased from Sigma-Aldrich. C60 was purchased from Nano-C. Tetrakis(dimethylamino) tin(IV) (99.9999%) was purchased from Ai Mou Yuan Scientific Equipment. ITO-glass has a square resistance of 20 ohm, purchased from SuZhou ShangYang Solar Technology. 

#### **Perovskite precursor solution** 

**WBG FA0.8Cs0.2Pb(I0.6Br0.4)3 perovskite.** The precursor solution (1.2 M) of WBG perovskite (approximately 1.77 eV) was prepared in mixed solvents of DMF and DMSO with a volume ratio of 4:1. The molar ratio of FAI/FABr/CsI/CsBr/PbI2/PbBr2 was 0.48:0.32:0.12:0.08:0.6:0.4. PbI2 and GuaBF4 were added to the precursor solution at optimized concentrations. 

**NBG FA0.7MA0.3Pb0.5Sn0.5I3 perovskite.** The precursor solution (2.0 M) of NBG perovskite (approximately 1.25 eV) was prepared in mixed solvents of DMF and DMSO with a volume ratio of 2:1. The molar ratios for FAI/MAI and PbI2/SnI2 were 0.7:0.3 and 0.5:0.5, respectively. The molar ratio of (FAI + MAI)/(PbI2 + SnI2) was 1:1. SnF2 (10 mol% relative to SnI2) was added in the precursor solution. The precursor solution was stirred at room temperature for 2 h. Tin powders (5 mg ml<sup>−1</sup> ) and formamidine sulfinic acid (0.3 mol%) were added in the precursor to reduce Sn<sup>4+</sup> in the precursor solution and to improve film uniformity. CF3-PACl was added to the precursor solution as additive at optimized concentrations. The precursor solution was filtered through a 0.22-µm PTFE membrane before making perovskite films. 

#### **Device fabrication** 

**The solution of insertion layer.** The F-PEACl and CF3-PACl molecules were separately dispersed in IPA at a concentration of 10 mg ml<sup>−1</sup> and stirred at room temperature for 2 h as a concentrated solution. The concentrated solution was mixed with IPA in a volume ratio of 1:9 for a single insertion layer solution. For the optimized mixed insertion layer solution, the volume ratio of concentrated solution of F-PEACl, CF3-PACl and IPA is 1:1:8. The EDAI2 molecules were separately dispersed in IPA at a concentration of 1 mg ml<sup>−1</sup> . The PMMA were separately dispersed in chlorobenzene at a concentration of 2 mg ml<sup>−1</sup> and stirred at room temperature for 2 h. 

**Single-junction WBG solar cells.** The pre-patterned ITO-glass substrates were sequentially cleaned using acetone and isopropanol. NiO was deposited by magnetron sputtering on ITO substrates first. Subsequently, the solutions of self-assembled molecule (2PACz:MeO-2PACz = 3:1, 1 mmol ml<sup>−1</sup> in IPA) were spin-coated on the NiO film at 4,000 r.p.m. for 20 s, followed by annealing at 100 °C for 1 min in air. After cooling, we transferred the substrates immediately to a nitrogen-filled glovebox for the deposition of perovskite films. The perovskite films were deposited with two-step spin-coating procedures: (1) 2,000 r.p.m. for 10 s with an acceleration of 200 r.p.m. s<sup>−1</sup> ; (2) 6,000 r.p.m. for 40 s with an acceleration of 2,000 r.p.m. s<sup>−1</sup> . Chlorobenzene (200 µl) or anisole (120 µl) were dropped on the spinning substrate during the second spin-coating step at 20 s before the end of 

the procedure, followed by annealing at 100 °C for 5 min and 85 °C for 15 min. All WBG devices use anisole as an antisolvent unless indicated otherwise. The 100-µl insertion layer solution was dropped onto the deposited perovskite film, spin-coated for 20 s at 4,000 r.p.m. and then annealed for 3 min on a 100 °C hotplate. After cooling down to room temperature, the substrates were transferred to the evaporation system and 20 nm C60 was deposited at the rates of 0.2 Å s<sup>−1</sup> . The substrates were transferred to the ALD system (Veeco Savannah S200) to deposit 20 nm SnO2 at a low temperature of 75 °C. Finally, 200 nm Cu was deposited by thermal evaporation as the back electrode. Usually, an anti-reflective film was used to reduce light reflection from the surface. 

**All-perovskite tandem solar cells.** The WBG solar cells were prepared as mentioned above. After ALD-SnO2 deposition, the substrates were transferred back to the thermal evaporation system to deposit an ultrathin layer of Au clusters (about 1 nm) on ALD-SnO2. PEDOT:PSS layers were spin cast in air on top of front cells and annealed in air at 120 °C for 20 min. After the substrates had cooled, we immediately transferred the substrates to a nitrogen-filled glovebox for the deposition of NBG perovskite films. The perovskite films were deposited with two-step spin-coating procedures: (1) 1,000 r.p.m. for 10 s with a ramp-up of 200 r.p.m. s<sup>−1</sup> ; (2) 4,000 r.p.m. for 40 s with a ramp-up of 1,000 r.p.m. s<sup>−1</sup> . Ethyl acetate (200 µl) was dropped on the spinning substrate during the second spin-coating step at 20 s before the end of the procedure. After cooling down to room temperature, the substrates were transferred to the evaporation system and 20 nm C60 was deposited at the rates of 0.2 Å s<sup>−1</sup> . The substrates were transferred to the ALD system (Veeco Savannah S200) to deposit 20 nm SnO2 at a low temperature of 75 °C. Finally, 200 nm Cu was deposited by thermal evaporation as the back electrode. Usually, an anti-reflective film was used to reduce light reflection from the surface. 

#### **Characterization of solar cells** 

For single-junction solar cells, the current density–voltage ( _J_ – _V_ ) characteristics were measured using a Keithley 2450 source meter under the illumination of the solar simulator (Enlitech, Class AAA) at the light intensity of 100 mW cm<sup>−2</sup> , as checked with NREL-calibrated reference solar cells (KG-5 and KG-0 reference cells were used for the measurements of WBG and NBG solar cells, respectively). Unless otherwise stated, the _J_ – _V_ curves were all measured in air with a scanning rate of 10 mV s<sup>−1</sup> (voltage steps of 20 mV and a delay time of 10 ms). The active area was determined by the aperture shade masks (0.05 cm<sup>2</sup> and 1.05 cm<sup>2</sup> ) placed in the glass side of the solar cells. EQE measurements were performed in ambient air using a QE system (Enlitech) with monochromatic light focused on the device pixel and a chopper frequency of 20 Hz. For tandem solar cells, the _J_ – _V_ characteristics were carried out under the illumination of a two-lamp high-spectral-match solar simulator (SAN-EI ELECTRIC, XHS-50S1). EQE measurements were performed in ambient air and the bias illumination from bright LEDs with emission peaks of 850 and 460 nm were used for the measurements of the front and back sub-cells, respectively. No bias voltage was applied during the EQE measurements of tandems. 

#### **Stability tests of solar cells** 

The operational stability tests were carried out under full AM 1.5G illumination (Class AAA, multicolour LED solar simulator, Guangzhou Crysco Equipment Co., Ltd.) with an intensity of 100 mW cm<sup>−2</sup> using a home-built LabVIEW-based MPP tracking system and a ‘perturb and observe’ method. The voltage of the maximum power is determined in the _J_ – _V_ measurement. The current density at a fixed bias voltage is tracked using a Keithley 2450 source meter. The data collection interval is 2 s. The solar cell is encapsulated in butyl rubber in a sandwich of two glasses and the electrodes are drawn out through a welding tape. No ultraviolet filter was applied during operation. 

#### **PL mapping and microscopy** 

The PL mapping for film on the square-centimetre scale was performed using a home-built system. The excitation light source is a Lumileds blue LED with a peak emission wavelength of 430 nm. The camera is a Princeton Instruments PIXIS 1024 camera with a Peltier-cooled (−70 °C) silicon CCD detector. The PL microscopy (660 × 660-µm<sup>2</sup> field of view) was captured using a wide-field microscope equipped with an IMA hyperspectral imaging system (Photon etc.), sCMOS camera and Olympus MPLFLN 5X Objective. The PL microscope uses a 405-nm laser with a spot area of 5 × 5 mm<sup>2</sup> . The spatial effects were calibrated using fluorescence microscope slides from Thorlabs. All PL mapping is normalized to the maximum intensity of the image itself. A digital handheld optical power and energy meter was used to measure the power density of both systems. The power density is adjusted to 100 mW cm<sup>−2</sup> . 

the intrinsic defects on the 3D perovskite surfaces, we constructed the 2 × 2 × 4 supercells of the cubic perovskite in the slab structures with a vacuum layer thickness of 15 Å along the out-of-plane direction. To simulate the defects on the 2D perovskite surfaces, we constructed a F-PEA2PbI4 Ruddlesden–Popper phase structure with a 15-Å vacuum layer. The larger supercell size of 5 × 5 × 1 was used to simulate the insertion of CF3-PA into F-PEA-based 2D perovskites, together with a 20-Å vacuum layer. Structure optimization (including lattice parameters and internal atomic positions) was performed until the energies converged to 10<sup>−4</sup> eV. A kinetic energy cut-off of 400 eV was used for wavefunction expansion. The 3 × 3 × 1 _k_ -point mesh was used for Brillouin zone integration of the 3D and 2D perovskite surfaces and the Γ only _k_ point was used for the larger supercells. To properly take into account the long-range van der Waals interaction that is non-negligible for hybrid perovskites involving organic molecules, the optB86b-vdW functional<sup>48</sup> was used. 

#### **Intensity-dependent QFLS and pseudo-** **_J_ –** **_V_** 

Absolute-intensity PL measurements were performed on a calibrated Zeiss wide-field microscope coupled to a spectrometer. All spectra were collected through a 20× objective (Nikon Plan Fluor ELWD 20x/0.45) under uniform epi-illumination from a 450-nm LED (Thorlabs M450LP2 with 500 nm shortpass filter). The LED excitation intensity was measured using a PTB-certified power meter (Thorlabs S120C) and controlled by modifying the driving current from a programmable power supply (Tenma). The collected PL signal was filtered with a dichroic mirror (Semrock 514 nm longpass, BLP01-514R-25) to remove the scattered excitation, then focused with an achromatic lens into an optical fibre. The PL signal from the fibre output was measured using an Ocean Optics Maya 2000 Pro spectrometer. All components were controlled through a Python program ensuring reproducible excitation intensities and sweep rates. PL spectra were measured at intensities from 0.015 Suns to 1.6 Suns, with increased sampling below 0.15 Suns to improve the accuracy of implied FF values. Samples were continuously illuminated over the variable intensity sweep, with spectrometer integration times beginning 100 µs after changing the intensity. Spectrometer integration times varied between 4 s and 10 µs for sufficient dynamic range to capture the PL signal under all excitation intensities. Note that the spectrometer CCD counts are corrected to achieve >99% linearity for accurate photometric calibration at different integration times. The system was calibrated by sequential measurement of a radiometrically calibrated halogen lamp and an LED at a known photon flux. Briefly, a certified halogen lamp (Ocean Optics) was coupled into the microscope objective through an integrating sphere (Thorlabs) to provide a known and isotropic spectrum over all collection angles of the objective. After establishing a spectral correction, a correction for absolute photon counts was made by measuring a uniform red LED beam (Thorlabs) reflected from a calibrated mirror (Semrock) at a known photon flux. See Supplementary Note 3 for details on the calculation of QFLS values and pseudo- _J_ – _V_ curves. 

#### **First-principles calculations** 

First-principles energetic and electronic-structure calculations were carried out within the framework of density functional theory using plane-wave pseudopotential method as implemented in the Vienna Ab initio Simulation Package<sup>42,43</sup> . The electron–ion interactions were described by using the projector augmented-wave pseudopotentials<sup>44</sup> . The 5 _s_ 5 _p_ 6 _s_ (Cs), 6 _s_<sup>2</sup> 6 _p_<sup>2</sup> (Pb), 2 _s_<sup>2</sup> 2 _p_<sup>5</sup> (F), 4 _s_<sup>2</sup> 4 _p_<sup>5</sup> (Br), 5 _s_<sup>2</sup> 5 _p_<sup>5</sup> (I), 2 _s_<sup>2</sup> 2 _p_<sup>2</sup> (C) and 2 _s_<sup>2</sup> 2 _p_<sup>3</sup> (N) were treated explicitly as valence electrons. We used the generalized gradient approximation formulated by Perdew, Burke and Ernzerhof as the exchange correlation functional<sup>45</sup> . The alloy of FA0.75Cs0.25Pb(I0.66Br0.33)3 perovskite was constructed to simulate the experimental 3D FA0.8Cs0.2Pb(I0.6Br0.4)3 perovskite sample. The alloy configurations were generated by the special quasi-random structure method<sup>46,47</sup> , which can produce the best approximated periodic ordered structure to mimic the actual disordered state. To simulate 

#### **Other characterizations** 

SEM images were obtained using a TESCAN microscope with an accelerating voltage of 2 kV. X-ray diffraction patterns were collected using a Bruker D8 Advance equipped with a NaI scintillation counter and using monochromatized copper Kα radiation ( _λ_ = 1.5406 Å). We carried out XPS analysis using the Thermo Scientific Al K-Alpha XPS system with energy steps of 0.1 eV. Steady-state PL and time-resolved PL were measured using an Edinburgh FLS980 system. The light was illuminated from the top surface of the perovskite film. For steady-state PL measurements, the excitation source was from a monochromated Xe lamp (peak wavelength at 520 nm with a line width of 2 nm). 

TRPL was measured using a Horiba Fluorolog-3 time-correlated single-photon counting system; the samples were excited using a pulsed laser with a wavelength of 485 nm (11.7 mW cm<sup>−2</sup> , 2 MHz, 5.83 nJ cm<sup>−2</sup> ). GI-WAXS measurement was performed by using a beam energy of 10 keV and a PILATUS detector at the BL17B1 beamline of the Shanghai Synchrotron Radiation Facility (SSRF). GI-WAXS patterns were acquired using an incident angle of 0.5° and the sample located about 330 mm away from the detector (PILATUS). Transient photovoltage decays were measured on a home-made system. A 540-nm green LED was used to modulate the _V_ oc with a constant light bias and the repetition rate was set to 2,000 Hz. The open-circuit voltage transient, induced by the light perturbation, was measured with a digital oscilloscope set to an input impedance of 1 MΩ. The charge recombination lifetime was fitted by a single exponential decay. The KPFM measurements were performed on a Bruker Dimension Icon AFM in an argon-filled glovebox. We used a Pt–Ir-coated PPP-EFM probe in tapping mode. A lock-in amplifier and signal filter were set up in the KPFM mode to achieve an electrical resolution of approximately 10 mV. The conductive substrate of the perovskite samples was connected to the sample stage. The scanning rate was set to 0.4 Hz to ensure image quality. During the measurements, the AC bias voltage was applied to the tip and the sample was grounded. Also, the AC bias produced an electric force on the cantilever, which is proportional to the potential difference between the conducting atomic force microscope tip and the sample. ToF-SIMS was performed using TOF-SIMS M5 from IONTOF GmbH. Samples were analysed in the dual-beam profiling mode. All profiles were performed in the non-interlaced mode. Spectral data were acquired in the high-mass-resolution mode. The primary ion for analysis was 30 keV Bi<sup>3+</sup> at 0.3 pA (with Bi liquid metal ion source). This ion beam was applied over a 100 × 100-µm<sup>2</sup> area at the centre of the sputter crater. The sputter ion was 10 keV Ar<sup>+</sup> at 120 nA (with Ar electron impact ion source). A 300 × 300-µm<sup>2</sup> sputter crater was used. 

### **Data availability** 

All data are available in the main text or the supplementary materials. Further data are available from the corresponding author on request. 

## Article 

42. Kresse, G. & Furthmüller, J. Efficient iterative schemes for _ab initio_ total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

43. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

44. Blöchl, P. E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953–17979 (1994). 

45. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

46. Van De Walle, A. et al. Efficient stochastic generation of special quasirandom structures. _Calphad_ **42** , 13–18 (2013). 

47. Wei, S. H., Ferreira, L. G., Bernard, J. E. & Zunger, A. Electronic properties of random alloys: special quasirandom structures. _Phys. Rev. B_ **42** , 9622–9649 (1990). 

48. Klimeš, J., Bowler, D. R. & Michaelides, A. Chemical accuracy for the van der Waals density functional. _J. Phys. Condens. Matter_ **22** , 022201 (2010). 

**Acknowledgements** This work was financially supported by the National Key R&D Program of China (2022YFB4200304), National Natural Science Foundation of China (T2325016, U21A2076, 61974063, 62125402, 62321166653, 62305150, 52302327), Natural Science Foundation of Jiangsu Province (BE2022021, BE2022026, BK20202008, BK20190315, BK20232022), Fundamental Research Funds for the Central Universities (0213/14380206, 0205/14380252), Frontiers Science Center for Critical Earth Material Cycling Fund (DLTD2109) and the ‘GeoX’ Interdisciplinary Research Funds for the Frontiers Science Center for Critical Earth Material Cycling, Nanjing University and Program for Innovative Talents and Entrepreneur in Jiangsu. C.C. acknowledges the support of a Marshall Scholarship, Winton Scholarship and the Cambridge Trust. Y.H., a Japan Society for the Promotion of Science (JSPS) Overseas Research Fellow, acknowledges the financial support from the JSPS. M.I.S. is grateful to Canada Research Chairs Program (CRC-2019-00297) for operational support. We acknowledge the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (HYPERION, grant agreement no. 756962) and the Engineering and 

Physical Sciences Research Council (EPSRC) (grant agreement no. EP/V027131/1). S.D.S. acknowledges the Royal Society and Tata Group (grant no. UF150033). Grazing-incidence wide-angle X-ray scattering experiments were carried out at beamline 02U2, Shanghai Synchrotron Radiation Facility (SSRF). Calculations were performed in part at the High Performance Computing Center of Jilin University. 

**Author contributions** H.T. conceived and directed the overall project. Y.W., R.L. and C.L. fabricated all the devices and conducted the characterization. A.D.B. and H.T.N. performed the photoluminescence and electroluminescence imaging characterization. H.S., X.Z., H.L., P.W., H.G., H.Z., X.L. and L.L. helped with the device fabrication and material characterization. W.S. and Y.N. performed the atomic force microscopy imaging characterization. C.C. performed the intensity-dependent quasi-Fermi level splitting measurements and pseudo- _J_ – _V_ analysis under the supervision of S.D.S. M.L. and C.X. performed the atomic Kelvin probe force microscopy imaging characterization. X.W., K.Z. and L.Z. performed the first-principles calculations. Y.W., X.W., Y.H., M.I.S., S.D.S., L.Z. and H.T. wrote the manuscript. All authors read and commented on the manuscript. 

**Competing interests** H.T. is the founder, chief scientific officer and chairman of Renshine Solar Co. Ltd., a company that is commercializing perovskite photovoltaics. S.D.S. is a co-founder of Swift Solar. The other authors declare no competing interests. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-024-08158-6. 

**Correspondence and requests for materials** should be addressed to Samuel D. Stranks, Lijun Zhang or Hairen Tan. 

**Peer review information** _Nature_ thanks the anonymous reviewers for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at http://www.nature.com/reprints. 

