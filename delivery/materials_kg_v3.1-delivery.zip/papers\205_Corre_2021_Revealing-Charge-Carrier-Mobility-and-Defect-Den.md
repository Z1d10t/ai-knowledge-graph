# Revealing Charge Carrier Mobility and Defect Densities in Metal Halide Perovskites via Space-Charge-Limited Current Measurements

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Energy Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 600 |
| 作者 | V. Le Corre, E. Duijnstee, Omar El Tambouli, J. Ball, H. Snaith, Jongchul Lim, L. Koster |
| DOI | 10.1021/acsenergylett.0c02599 |
| 源文件 | 005_Corre_2021_Revealing-Charge-Carrier-Mobility-and-Defect-Den.pdf |

---


http://pubs.acs.org/journal/aelccp 

### Revealing Charge Carrier Mobility and Defect Densities in Metal Halide Perovskites via Space-Charge-Limited Current Measurements 

Vincent M. Le Corre,* Elisabeth A. Duijnstee, Omar El Tambouli, James M. Ball, Henry J. Snaith, Jongchul Lim, and L. Jan Anton Koster* 

Cite This: ACS Energy Lett. 2021, 6, 1087−1094 Read Online 

ACCESS Metrics & More Article Recommendations *sı Supporting Information 

ABSTRACT: Space-charge-limited current (SCLC) measurements have been widely used to study the charge carrier mobility and trap density in semiconductors. However, their applicability to metal halide perovskites is not straightforward, due to the mixed ionic and electronic nature of these materials. Here, we discuss the pitfalls of SCLC for perovskite semiconductors, and especially the effect of mobile ions. We show, using driftdiffusion (DD) simulations, that the ions strongly affect the measurement and that the usual analysis and interpretation of SCLC need to be refined. We highlight that the trap density and mobility cannot be directly quantified using classical methods. We discuss the advantages of pulsed SCLC for obtaining reliable data with minimal influence of the ionic motion. We then show that fitting the pulsed SCLC with DD modeling is a reliable method for extracting mobility, trap, and ion densities simultaneously. As a proof of concept, we obtain a trap density of 1.3 × 10<sup>13</sup> cm<sup>−3</sup> , an ion density of 1.1 × 10<sup>13</sup> cm<sup>−3</sup> , and a mobility of 13 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for a MAPbBr3 single crystal. 

# O 

ne of the most common techniques for investigating the intrinsic transport properties as well as the trap O density of a semiconductor is the so-called spacecharge-limited current (SCLC) measurement. Due to the apparent simplicity of the measurement, it has been used extensively in the literature to study organic semiconductors and inorganic and hybrid organic−inorganic metal halide perovskites.<sup>1−13</sup> In fact, the measurement consists of measuring “only” a dark current−voltage (JV) characteristic of a single-carrier device, i.e., a device in which the contacts on both sides of a semiconductor are aligned with the conduction (valence) band in such a way that only electrons (holes) are injected. One of the main advantages of this technique versus other techniques such as charge carrier extraction by linearly increasing voltage, optical pump terahertz probe photoconductivity, and microwave conductivity, lies in the fact that the electron and hole mobility and trap density can be probed independently.<sup>14,15</sup> In addition, the device configuration is similar to that used in solar cells and other “sandwich structure” optoelectronic devices, where the vertical transport is probed, as opposed to the lateral transport that can be measured using field effect transistor measurements.<sup>15</sup> 

The widespread use of SCLC measurements in the field of organic semiconductors likely contributed to its rapid adoption by the perovskite community. As a result, a large number of 

very influential publications have used this technique to quantify the transport and trapping properties in both single crystals and thin films.<sup>4−13</sup> However, the analysis of SCLC measurement data is sometimes oversimplified because the assumptions required to extract reliable values are often overlooked and not fully met, which leads to an over- or underestimation of the extracted values. 

In this paper, we investigate the applicability of SCLC measurement for perovskites using drift-diffusion (DD) modeling. We show that the classical SCLC measurement procedure and analysis is not suitable to extract accurate values of the mobility and trap density of perovskites. Instead, pulsed SCLC measurements, as introduced by Duijnstee et al.,<sup>16,17</sup> need to be used. Using simulations, we show how we can correctly interpret and extract important parameters from pulsed SCLC. To the best of our knowledge, this is the first report of extraction of both the ion and trap density from 



Received: December 16, 2020 Accepted: February 23, 2021 Published: February 26, 2021 

© 2021 The Authors. Published by American Chemical Society 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

1087 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 



Figure 1. (a) Ideal device structure for SCLC measurement with symmetric ohmic contact and no injection barrier. (b) Simulated JV curve of an electron-only device with a 100 μm thick perovskite between two perfect electrodes as in panel a with various trap densities. The dashed lines correspond to the different tangents with slopes of 1, 2, and >2, and the red, blue, and magenta points correspond to construction of V1, Vinf, and V2, respectively. (c) Evolution of the slopes of the JV curves with voltage. (d) Evaluation of the accuracy of the trap density estimation depending on the voltage point taken as Vtfl. The parameters used in the simulations are listed in Table S1. 

SCLC measurements, in addition to accurately determining the charge carrier mobility. 

Typical Pitfalls of SCLC Analysis. Ideally, SCLC measurements consist of a dark JV curve measurement of a singlecarrier device with symmetric ohmic contacts on either side of a semiconductor, as depicted in Figure 1a. When the JV curve is plotted on a log−log scale, several regimes can be identified: 

Ä d log( _<u>J</u>_ <u>)</u> É first a low-voltage regime with a slope ÅÅÅÅÅÅÅÇ d log( _V_ ) ÑÑÑÑÑÑÑÖ<sup>of1,followed</sup> 

by a regime with a high slope (>2) due to trap filling (if any), and, finally, at high voltage, the so-called SCLC regime with a slope of 2. These three regimes are shown in panels b and c of Figure 1. Note that the space-charge effect also influences the trap-filled-limited (TFL) regime. 

Several pitfalls of SCLC measurements have already arisen from the simple characterization of these regimes, which have been reported in the literature. (i) The use of non-ohmic and/ or asymmetric contacts can lead to regimes with slopes of >2 and needs to be accounted for while performing the SCLC analysis; studies by Blakesley<sup>1</sup> and Röhr<sup>18</sup> present methods on how to account for asymmetric contact. (ii) The interpretation of the low-voltage regime varies depending on several factors such as diffusion and intrinsic, trap, or dopant densities.<sup>19−22</sup> (iii) The fitting and accuracy of the Mott−Gurney equation<sup>23,24</sup> were used for the quadratic regime at high voltages. (iv) Fitting the Mark−Helfrich equation is used for the interpretation of the TFL regime.<sup>19,25−27</sup> In addition to these issues, perovskite materials, good electronic and ionic conductors, bring some new challenges of their own as the contributions of electronic and ionic species influence the current. 

Before discussing the influence of ions on SCLC measurements, we first discuss the ideal case in which no ions are present as it is not always clear in the literature what values can be extracted and how. 

SCLC measurements are some of the most common approaches for extracting the mobility and trap density values of semiconductors and have been widely used in the perovskite literature.<sup>6−11,28</sup> As discussed in numerous papers,<sup>19,23,24</sup> the mobility value is typically extracted from the quadratic regime of the JV curve by fitting the Mott−Gurney equation: 



<!-- Start of picture text -->
9 ( V − V BI)2<br>J = 8 εμ L 3 (1)<br><!-- End of picture text -->

where J is the current density, V and VBI are the applied and built-in voltage, respectively, ε is the dielectric constant, L is the thickness, and μ is the mobility. While some slightly different formulas were proposed to account for the presence of trapping,<sup>19</sup> eq 1 remains the most commonly used formula in the literature. 

As previously mentioned, the trap density can be extracted from the plot of the JV curve on a log−log scale. The most common approach is to calculate the trap density from the socalled trap-filled-limit voltage:<sup>19</sup> 



<!-- Start of picture text -->
2<br>qn L t<br>V tfl =<br>2 ε (2)<br><!-- End of picture text -->

where q is the elementary charge and nt the trap density. Even though this formula can be easily derived under the assumption that the amount of traps is larger than the number of free charges, which point of the JV curve that should be chosen as Vtfl has not yet been clarified. Most reports choose the voltage of the crossing point between the low-voltage tangent with a slope of 1 and the trap-filled-limited regime tangent with a slope of >2, as shown in Figure 1b, which we call V1. However, others use the crossing point between the tangent space-charge-limited regime at high voltages and the trap-filled-limited regime, which we call V2.<sup>29</sup> Lastly, one may consider the inflection point (Vinf) as a viable option for the Vtfl value. 

1088 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 



Figure 2. (a) Forward and backward JV scan of a MAPbBr3 perovskite single crystal taken from ref 16 showing strong hysteresis. (b) Simulated JV curves for forward, backward, and steady-state scans demonstrating the influence of ion migration on the JV curve. The vertical line indicates the Vtfl as calculated from eq 2. (c) Cation density distribution calculated for steady-state conditions at different bias voltages where it can be seen that the cations slowly migrate toward the electrode (the anion distribution can be found in Figures S1−S3). (d) Effect of the injection barrier next to the injecting electrode that saturates the current at high voltages. The parameters used in the simulation are listed in Table S1. 

To assess which voltage (V1, V2, or Vinf) yields the most accurate estimate of the trap density, we simulated JV curves by varying the trap densities for a fixed thickness of 100 μm and extracted the values of V1, Vinf, and V2 and calculated the corresponding trap densities using eq 2. Figure 1d shows that using V1 to calculate Vtfl gives the worst estimation of trap density and can lead to errors of almost 1 order of magnitude in the estimated trap density. The error is largest when the trap density is low and the transition between the two regimes is shallow, i.e., when the slope of the TFL regime is low. As shown, V2 gives the most accurate value for the trap density and should be used instead. This is not so surprising as the transition from the TFL to the SCLC regime happens when all traps are filled and the free charge carrier density becomes larger than the number of traps (see Figures S1−S3). 

We also note that, for a given thickness, trap densities can be resolved by SCLC measurements only if the density of traps exceeds a certain threshold. In fact, the TFL regime appears only if nt > n at a low voltage. Hence, the minimum trap density leading to a TFL regime is given by the charge density ndiff at a low voltage (where the current is dominated by diffusion) in the absence of traps and dopants.<sup>21,22</sup> The minimum density of traps that is noticeable is thus given by 



<!-- Start of picture text -->
2 kT ε<br>n t,min = n diff = 4 π 2 2<br>q L (3)<br><!-- End of picture text -->

Assuming that the relative dielectric constant of perovskites is typically 25 and that the experiment is performed at 295 K, eq 3 implies that to resolve a trap density of 10<sup>11</sup> cm<sup>−3</sup> the thickness of the perovskite layer needs to be at least 100 μm. For a trap density of 10<sup>16</sup> cm<sup>−3</sup> , 400 nm is sufficient to resolve the TFL regime. Thus, to observe a TFL regime, high-quality perovskites require a very thick film in the SCLC experiment. However, because Vtfl is inversely proportional to L<sup>2</sup> , it is possible to encounter difficulties as we have to measure at high 

voltages to reach the quadratic SCLC regime if the perovskite thickness is increased. 

These important findings question the way SCLC measurements are reported in the literature. In the absence of a TFL regime, we should only note that the trap density is lower than nt,min, depending on the thickness of the measured sample, rather than claiming the absence of traps. 

Influence of Ions on SCLC Measurements: Classic SCLC Measurement. One of the peculiar properties inherent to perovskite materials is the fact that they are both electronic and ionic conductors. Typically, the halide anions are identified as being primarily responsible for the ionic motion in metal halide perovskites with a higher diffusion coefficient, a lower activation energy, and higher densities compared to those of other ionic species.<sup>30−32</sup> However, recent studies also suggest that the influence of A site cations such as Cs<sup>+</sup> , CH3NH3+, and (NH2)2CH<sup>+</sup> or even H<sup>+</sup> should not be neglected.<sup>33,34</sup> Overall, it is difficult to find one responsible for the ionic motion in perovskite as it largely depends on the system being studied. Nevertheless, it is clear that mobile ions are present in a large majority of metal halide perovskites and need to be accounted for. 

Like the issue of identifying the main source of mobile ions, investigating the nature and origin of the traps is also a big challenge, and while many reports use first-principles calculation to calculate the trap depth regardless of whether there are more acceptor or donor types, there is still a large spread in the obtained values and no consensus as to the nature of the traps.<sup>31,35</sup> It has been widely reported in the perovskite solar cell literature that the movement of ions can have a dramatic impact on the JV curves of perovskite solar cells and cause hysteresis.<sup>36−39</sup> Surprisingly, the influence of ions on the JV curves of SCLC measurements has been largely overlooked, and there are, to the best of our knowledge, few reports of the difference between forward (FW) and backward 

1089 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 



Figure 3. (a) Schematic representation of the construction of the pulsed SCLC JV curve from the measurement of the current during a voltage pulse. (b) Pulsed SCLC measurement JV curves with a small hysteresis for a 160 μm thick MAPbBr3 perovskite single crystal and the corresponding drift-diffusion fit. (c) Evolution of the pulsed SCLC JV curves depending on the ion density for a fixed trap density of 1 × 10<sup>13</sup> cm<sup>−3</sup> . (d) Input vs calculated net-charge density using eq 4. The black solid line is a guide to the eye corresponding to the input net charge, and the dashed line corresponds to the input trap density. The parameters used in the simulation are listed in Tables S1 and S2. 

(BW) scans for SCLC measurements. The FW (BW) scan is a measurement of a JV curve from low (high) to high (low) voltages. Recent exceptions are the papers by Duijnstee et al.<sup>16</sup> and Sajedi Alvar et al.<sup>40</sup> The JV curve from the SCLC measurement of a MAPbBr3 single crystal, taken from ref 16, is shown in Figure 2a and shows large hysteresis between the FW and BW scans. This indicates that the movement of the ions has a strong effect on the current and, hence, needs to be considered in the SCLC analysis when studying perovskites. 

To gain insight into how the ions affect the current, we simulated a 100 μm thick perovskite single crystal, including trapping and mobile ions, as shown in Figure 2b and Table S1. First, we simulated a steady-state (or stabilized) scan in which ions have time to redistribute at every voltage step followed by a simulation of the extreme cases of an infinitely fast FW and BW scan prebiased at 0 and 200 V, respectively. For these scans, the ion distributions throughout the device are calculated at the prebias (here the first applied voltage) and kept fixed for all of the other voltage steps. While there is no significant difference between the FW and steady-state scans, there is a dramatic hysteresis feature between the FW and BW sweeps. The fact that the steady-state and FW scans are similar is not so surprising as the cations mostly stay in the bulk at low voltages because the perovskite layer is so thick (see Figure 2c). Therefore, the current at low voltages is hardly affected, as depicted Figure 2b. Even though the cations will accumulate at the electrode at high voltages, as shown in Figure 2c, it still has a negligible effect as the electric field is high enough not to be affected. During the BW scan, the current is mostly affected at intermediate voltages as the ions are confined near the electrode, effectively dedoping the bulk of the perovskite. 

The vertical line in Figure 2b indicates the Vtfl as calculated from eq 2. We can note that V2 of the BW scan is much closer to Vtfl than that from the FW or steady-state scan. This tends 

to indicate that using a BW scan leads to a better estimate of the trap density. However, for this to be true the scan rate should be sufficiently high to ensure than ions do not have time to move throughout the JV measurement, which is difficult when scanning over a large voltage range. Additionally, we will later discuss other effects that may influence the BW scan, and can cause experimental difficulties. 

In summary, the ions have a strong influence on the SCLC JV curves but more importantly the values of trap density extracted from this measurement are largely dependent on the ions, making it impossible to extract reliable trap density values using Vtfl. 

While there is a clear effect of the ionic distribution on the simulated JV curves, we do not see such a drastic decrease and saturation in the current density in the BW scan compared to the FW scan as in the experiment depicted in Figure 2a. This effect could potentially be explained by the creation of an injection barrier next to the electrode when the applied bias is too strong. This barrier could originate from the degradation of the perovskite materials next to the electrode. Too many ions at the interface can result in the formation of a thin layer with a different bandgap. The simulation with a small injection (≈0.2−0.3 eV) barrier (see Figure 2d) in the layer next to the injecting electrode indeed shows a saturation of the current at high voltages and therefore makes this a probable scenario for explaining the shape of the hysteresis in the experimental JV curve. In addition, it has been shown in the literature that the reaction of the perovskite with the electrode or ionic migration could create different phases like PbI2 next to the electrode,<sup>41</sup> which could create such a barrier. Unfortunately, such a degradation complicates the use of the BW scan to gain a better estimate of the trap density. 

Pulsed SCLC Measurement. To tackle the problem of hysteresis and fixing the position of the ions within the 

1090 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

perovskite, Duijnstee et al. proposed a pulsed SCLC method for obtaining reliable JV curves with suppressed hysteresis.<sup>16</sup> This method consists of a short voltage pulse (20 ms) from 0 V to the wanted applied voltage (see Figure 3a) and measuring the current after the displacement pic and before the ions have the time to move significantly. In the Supporting Information, we show by simulating the pulsed measurement using transient drift diffusion that this approach is fully justified (for both single crystals and thin films) and that ions indeed do not move significantly and have little to no influence on the current at a such time scale and at such an electric field. 

Using this pulsed method presents several advantages; on one hand, it allows the measurement of hysteresis free curves where the ions are effectively fixed to their position at 0 V and do not move throughout the JV sweep, and on the other hand, it avoids unwanted degradation and phase changes next to the electrodes that saturate the current at high voltages. 

In the remainder of this paper, we will discuss the pulsed SCLC as this measurement is more reliable.<sup>16</sup> To simulate the pulsed SCLC, we first calculate the ion distribution at 0 V and then keep it fixed for the voltage sweep, making it equivalent to the infinitely fast scan described previously. Similar to the fast FW scan, the pulsed SCLC and the steady-state scan give similar JV curves, as shown in Figure 2b. This similarity arises from the fact that the injected electron density and the filling of the traps are not as much affected by the movement ions, and especially cations. Figures S1 and S2 show that the cations mostly remain within the bulk of the perovskite and that the electron injection is not different for the three methods, which lead to completely filled traps at the same voltage. However, the situation is different for a fast BW scan prebiased at 200 V. Figure S3 shows that in this case, the cations accumulate at the injecting electrode, which slows the injection of electrons, and thereby the filling of the traps. Hence, Vtfl shifts to higher voltages. 

Figure 3b shows the measured pulsed SCLC JV curves for a 160 μm thick MAPbBr3 single crystal. More details about the measurement can be found in ref 16. Figure S4 shows the measurement performed on three different crystals with different thicknesses. The absence of hysteresis for all three crystals implies that the ions are indeed fixed around their 0 V positions. Additionally, there is no sign of degradation in the BW scan, which confirms the hypothesis that the accumulation of ions at high voltages creates a barrier for the injection that limits the current. 

On top of the hysteresis, the ions significantly influence the actual shape of the JV curve. We show in Figure 3c that as the ion density approaches the trap density, here at 1 × 10<sup>13</sup> cm<sup>−3</sup> , the TFL regime disappears. In addition, V1, Vinf, and V2 are all affected by the ion density. This is due to the fact that ions are shielding the charge from the traps, and thereby reducing the net charge. If the ion and trap densities are within the same order of magnitude, eq 2 does not apply and needs to be rewritten in terms of net charges in the bulk such as 



<!-- Start of picture text -->
qn net L 2 q ( n t − n ion) L 2<br>V net = 2 ε = 2 ε (4)<br><!-- End of picture text -->

The derivation of eq 4 is provided in the Supporting Information. Similarly, eq 3 can be expressed in terms of the net charge in the bulk. Equivalently, this equation still holds when other types of charges, such as dopants, are added, as shown in Figure S5. One should also note that in eq 4 nt refers 

only to charged traps that are sufficiently deep within the bandgap; in our simulations for an electron-only device, only negatively charged traps (i.e., acceptor type) can be probed as shown in Figure S6. Realistically, if more than one type of trap is considered with both some donor and some acceptor, for example, nt would correspond to the net charge of all of the traps. 

This is a crucial point for the interpretation of SCLC measurement for perovskites as it shows that we measure Vnet and the net charge in the bulk of the perovskite, rather than the Vtfl and the trap density. This is well illustrated by Figure 3d, in which we show that as the ion density increases, i.e., the net charge decreases, the measured density deviates more from the actual trap density. This figure also shows that V1, which is the most commonly used point for Vtfl, not only can be 1 order of magnitude off in predicting the net charge but also underestimates the trap density by almost 2 orders of magnitude. Hence, previously reported trap density values from SCLC measurement showing a small slope for the TFL regime, probably indicating an ion density close to the trap density, cannot be trusted. 

Given the potential pitfalls of SCLC measurements when applying simplified equations such as the Mott−Gurney law or the expression for Vtfl, it appears to be more reasonable to fit drift-diffusion simulations to the measurement data. By doing so, we can relax a few assumptions and obtain values for trap and ion densities instead of only the net charge when using eq 4. If necessary, the built-in voltage can also be accounted for by fitting both positive and negative voltage JV curves, when different electrodes are used (which is not the case here). For this purpose, we use SIMsalabim, an open-source drift-diffusion simulation program, in the hope that it will enable researchers to fit their SCLC measurement to obtain more reliable values. More details about the simulation can be found in the Supporting Information and refs 39, 42, and 43, and the code is available on GitHub.<sup>44</sup> 

If we extract values from the 160 μm single-crystal JV curve using the “classical” method, i.e., taking the Vtfl as V1, from the FW scan in Figure 2a and from the pulsed measurement in Figure 3b, we obtain trap densities of ≈2 × 10<sup>11</sup> and ≈4.5 × 10<sup>12</sup> cm<sup>−3</sup> , respectively. However, when the pulsed JV curve is fitted using the drift-diffusion simulation, as shown in Figure 3a and Table S2, the simulation shows that trap and ion densities are indeed very similar, approximately 1.3 × 10<sup>13</sup> and 1.1 × 10<sup>13</sup> cm<sup>−3</sup> , respectively, giving a net charge in the bulk of 2 × 10<sup>12</sup> cm<sup>−3</sup> . The trap density was underestimated by 1−2 orders of magnitude when using the “classical” method. 

Even the values extracted by using the crossing points of the tangents from the pulsed measurement do not yield the correct values of either the net charge or the trap density. V1, Vinf, and V2 give values of 4.5 × 10<sup>12</sup> , 9.4 × 10<sup>12</sup> , and 1.2 × 10<sup>13</sup> cm<sup>−3</sup> , respectively. The TFL regime is not very pronounced, so the net charge is overestimated, as in Figure 3d when Vnet is small. Clearly, under such conditions, fitting a drift-diffusion simulation becomes necessary to extract a value for the trap density. It also allows for an estimation of the mobility value, which would not have been accessible using the “classical” method and fitting the Mott−Gurney law becaise the SCLC regime is not reached even at 200 V. Here, we find a mobility of approximately 13 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . 

We show that SCLC measurements have to be treated carefully when performed upon mixed ionic and electronic conductors, such as metal halide perovskites. We present some 

1091 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

of the common pitfalls for SCLC analysis and show that to obtain a reasonable estimate of the Vtfl and trap density, one needs to consider V2 rather than V1. 

We then present a detailed analysis of the effect of mobile ions on the interpretation of SCLC measurement. Both simulations and experiments suggest that performing pulsed SCLC measurement is necessary to minimize ion migration during the measurement. In this way, we obtain reliable and reproducible JV curves and avoid any degradation of the perovskite under large applied voltages. We show that even though we can extract the net charge in the perovskite bulk from the SCLC measurement, we cannot directly extract the trap density. This calls into question previous reports in the literature that may have underestimated the trap density by several orders of magnitude. 

Finally, we show how we can accurately reproduce pulsed SCLC experiments using drift-diffusion modeling, which enables us to quantify not only the net charge but also the actual mobility and trap and ion densities. We propose a wider use of drift-diffusion simulations to fit pulsed SCLC to extract meaningful values for the trap and ion densities, and mobility in the case of perovskites, and we provide an open-source solution to fit these measurements. We strongly encourage others to follow this approach and no longer perform analytical fits to JV data. 

## ■<sup>ASSOCIATEDCONTENT</sup> 

#### *sı Supporting Information 

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsenergylett.0c02599. 

Simulation parameters (Tables S1 and S2), charge carrier density profiles (Figures S1−S3), pulsed SCLC of single crystals of different thicknesses (Figure S4), effect of doping on pulsed SCLC (Figure S5), effect of defect type and trap depth on pulsed SCLC (Figure S6), simulated transient for pulsed SCLC (Figure S7), comparison between full transient and steady-state simulations of pulsed SCLC for a single-crystal-like perovskite (Figure S8), time evolution of the ionic distribution during the voltage pulse (Figures S9−S11), comparison between full transient and steady-state simulations of pulsed SCLC for a thin-film perovskite (Figure S12), illustration of the synthesis process of the perovskite single crystal (Figure S13), drift-diffusion model details, pulsed SCLC with ions really fixed during the voltage pulse, derivation of eq 4, and experimental procedures (PDF) 

## ■<sup>AUTHORINFORMATION</sup> 

##### Corresponding Authors 

- Vincent M. Le Corre − Zernike Institute for Advanced Materials, University of Groningen, 9747 AG Groningen, The Netherlands; orcid.org/0000-0001-6365-179X; Email: v.m.le.corre@rug.nl 

- L. Jan Anton Koster − Zernike Institute for Advanced Materials, University of Groningen, 9747 AG Groningen, The Netherlands; orcid.org/0000-0002-6558-5295; Email: l.j.a.koster@rug.nl 

##### Authors 

Elisabeth A. Duijnstee − Zernike Institute for Advanced Materials, University of Groningen, 9747 AG Groningen, The 

Netherlands; Clarendon Laboratory, University of Oxford, Oxford OX1 3PU, United Kingdom; orcid.org/00000002-7002-1523 

- Omar El Tambouli − Zernike Institute for Advanced Materials, University of Groningen, 9747 AG Groningen, The Netherlands 

- James M. Ball − Clarendon Laboratory, University of Oxford, Oxford OX1 3PU, United Kingdom; orcid.org/00000003-1730-5217 

- Henry J. Snaith − Clarendon Laboratory, University of Oxford, Oxford OX1 3PU, United Kingdom; orcid.org/ 0000-0001-8511-790X 

- Jongchul Lim − Clarendon Laboratory, University of Oxford, Oxford OX1 3PU, United Kingdom; orcid.org/00000001-8609-8747 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsenergylett.0c02599 

##### Author Contributions 

V.M.L.C. wrote the manuscript. V.M.L.C. and O.E.T. performed the numerical simulations. E.A.D. and J.L. fabricated the devices and performed the pulsed SCLC experiments. J.M.B. wrote the control software and assisted with the experimental setup and measurements. All authors discussed the results and reviewed the manuscript. J.L., H.J.S., and L.J.A.K. guided and supervised the overall project. 

Notes 

The authors declare the following competing financial interest(s): H.J.S. is co-founder and CSO of Oxford PV Ltd., a company commercializing perovskite PV technology. 

## ■<sup>ACKNOWLEDGMENTS</sup> 

The work by V.M.L.C. is supported by a grant from STW/ NWO (VIDI 13476). This is a publication by the FOM Focus Group “Next Generation Organic Photovoltaics”, participating in the Dutch Institute for Fundamental Energy Research (DIFFER). The work by E.A.D. was supported by the Engineering and Physical Sciences Research Council (EPSRC), Grants EP/M005143/1 and EP/P006329/1. E.A.D. thanks the EPSRC for funding via the Centre for Doctoral Training in New and Sustainable Photovoltaics. 

## ■<sup>REFERENCES</sup> 

(1) Blakesley, J. C.; Castro, F. A.; Kylberg, W.; Dibb, G. F.; Arantes, C.; Valaski, R.; Cremona, M.; Kim, J. S.; Kim, J. S. Towards reliable charge-mobility benchmark measurements for organic semiconductors. Org. Electron. 2014, 15, 1263−1272. 

(2) Zuo, G.; Linares, M.; Upreti, T.; Kemerink, M. General rule for the energy of water-induced traps in organic semiconductors. Nat. Mater. 2019, 18, 588−593. 

(3) Le Corre, V. M. V. V. M.; Chatri, A. A. R.; Doumon, N. Y. N.; Koster, L. J. A. Charge Carrier Extraction in Organic Solar Cells Governed by Steady-State Mobilities. Adv. Energy Mater. 2017, 7, 1701138. 

(4) Shi, D.; et al. Low trap-state density and long carrier diffusion in organolead trihalide perovskite single crystals. Science 2015, 347, 519−522. 

(5) Saidaminov, M. I.; Abdelhady, A. L.; Murali, B.; Alarousu, E.; Burlakov, V. M.; Peng, W.; Dursun, I.; Wang, L.; He, Y.; Maculan, G.; Goriely, A.; Wu, T.; Mohammed, O. F.; Bakr, O. M. High-quality bulk hybrid perovskite single crystals within minutes by inverse temperature crystallization. Nat. Commun. 2015, 6, 7586. 

(6) Liu, Y.; Sun, J.; Yang, Z.; Yang, D.; Ren, X.; Xu, H.; Yang, Z.; Liu, S. F. 20-mm-Large Single-Crystalline Formamidinium-Perovskite 

1092 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

Wafer for Mass Production of Integrated Photodetectors. Adv. Opt. Mater. 2016, 4, 1829−1837. 

(7) Zhumekenov, A. A.; Saidaminov, M. I.; Haque, M. A.; Alarousu, E.; Sarmah, S. P.; Murali, B.; Dursun, I.; Miao, X.-H.; Abdelhady, A. L.; Wu, T.; Mohammed, O. F.; Bakr, O. M. Formamidinium Lead Halide Perovskite Crystals with Unprecedented Long Carrier Dynamics and Diffusion Length. ACS Energy Lett. 2016, 1, 32−37. (8) Han, Q.; Bae, S.-H.; Sun, P.; Hsieh, Y.-T.; Yang, Y. M.; Rim, Y. S.; Zhao, H.; Chen, Q.; Shi, W.; Li, G.; Yang, Y. Single Crystal Formamidinium Lead Iodide (FAPbI3): Insight into the Structural, Optical, and Electrical Properties. Adv. Mater. 2016, 28, 2253−2258. (9) Zhang, F.; Yang, B.; Mao, X.; Yang, R.; Jiang, L.; Li, Y.; Xiong, J.; Yang, Y.; He, R.; Deng, W.; Han, K. Perovskite CH3NH3PbI3−xBrx Single Crystals with Charge-Carrier Lifetimes Exceeding 260 μs. ACS Appl. Mater. Interfaces 2017, 9, 14827−14832. 

(10) Murali, B.; Yengel, E.; Yang, C.; Peng, W.; Alarousu, E.; Bakr, O. M.; Mohammed, O. F. The Surface of Hybrid Perovskite Crystals: A Boon or Bane. ACS Energy Letters 2017, 2, 846−856. 

(11) Gu, Z.; Huang, Z.; Li, C.; Li, M.; Song, Y. A general printing approach for scalable growth of perovskite single-crystal films. Sci. Adv. 2018, 4, 2390. 

(12) Ju, D.; Dang, Y.; Zhu, Z.; Liu, H.; Chueh, C. C.; Li, X.; Wang, L.; Hu, X.; Jen, A. K.; Tao, X. Tunable Band Gap and Long Carrier Recombination Lifetime of Stable Mixed CH3NH3PbxSn1−xBr3 Single Crystals. Chem. Mater. 2018, 30, 1556−1565. 

(13) Chen, Z.; Dong, Q.; Liu, Y.; Bao, C.; Fang, Y.; Lin, Y.; Tang, S.; Wang, Q.; Xiao, X.; Bai, Y.; Deng, Y.; Huang, J. Thin single crystal perovskite solar cells to harvest below-bandgap light absorption. Nat. Commun. 2017, 8, 1890. 

(14) Herz, L. M. Charge-Carrier Mobilities in Metal Halide Perovskites: Fundamental Mechanisms and Limits. ACS Energy Letters 2017, 2, 1539−1548. 

(15) Peng, J.; Chen, Y.; Zheng, K.; Pullerits, T.; Liang, Z. Insights into charge carrier dynamics in organo-metal halide perovskites: From neat films to solar cells. Chem. Soc. Rev. 2017, 46, 5714−5729. 

(16) Duijnstee, E. A.; Ball, J. M.; Le Corre, V. M.; Koster, L. J. A.; Snaith, H. J.; Lim, J. Toward Understanding Space-Charge Limited Current Measurements on Metal Halide Perovskites. ACS Energy Letters 2020, 5, 376−384. 

(17) Duijnstee, E. A.; Le Corre, V. M.; Johnston, M. B.; Koster, L. J. A.; Lim, J.; Snaith, H. J. Understanding Dark Current-Voltage Characteristics in Metal-Halide Perovskite Single Crystals. Phys. Rev. Appl. 2021, 15, 014006. 

(18) Röhr, J. A. Direct Determination of Built-in Voltages in Asymmetric Single-Carrier Devices. Phys. Rev. Appl. 2019, 11, 054079. (19) Lampert, M. A.; Mark, P. Current injection in solids; Academic Press: New York, 1970. 

(20) Kirchartz, T. Influence of diffusion on space-charge-limited current measurements in organic semiconductors. Beilstein J. Nanotechnol. 2013, 4, 180−188. 

(21) Wetzelaer, G. A. H.; Blom, P. W. M. Ohmic current in organic metal-insulator-metal diodes revisited. Phys. Rev. B: Condens. Matter Mater. Phys. 2014, 89, 241201. 

(22) Röhr, J. A.; Kirchartz, T.; Nelson, J. On the correct interpretation of the low voltage regime in intrinsic single-carrier devices. J. Phys.: Condens. Matter 2017, 29, 205901. 

(23) Mott, N. F.; Gurney, R. W. Electronic Processes in Ionic Crystals; Oxford University Press, 1940. 

(24) Röhr, J. A.; Moia, D.; Haque, S. A.; Kirchartz, T.; Nelson, J. Exploring the validity and limitations of the Mott-Gurney law for charge-carrier mobility determination of semiconducting thin-films. J. Phys.: Condens. Matter 2018, 30, 105901. 

(25) Mark, P.; Helfrich, W. Space-charge-limited currents in organic crystals. J. Appl. Phys. 1962, 33, 205−215. 

(26) Fischer, J.; Tress, W.; Kleemann, H.; Widmer, J.; Leo, K.; Riede, M. Exploiting diffusion currents at Ohmic contacts for trap characterization in organic semiconductors. Org. Electron. 2014, 15, 2428−2432. 

(27) Röhr, J. A.; Shi, X.; Haque, S. A.; Kirchartz, T.; Nelson, J. Charge Transport in Spiro-OMeTAD Investigated through SpaceCharge-Limited Current Measurements. Phys. Rev. Appl. 2018, 9, 044017. 

(28) Chen, Y.-X.; Ge, Q.-Q.; Shi, Y.; Liu, J.; Xue, D.-J.; Ma, J.-Y.; Ding, J.; Yan, H.-J.; Hu, J.-S.; Wan, L.-J. General Space-Confined OnSubstrate Fabrication of Thickness-Adjustable Hybrid Perovskite Single-Crystalline Thin Films. J. Am. Chem. Soc. 2016, 138, 16196− 16199. 

(29) Cai, F.; Yang, L.; Yan, Y.; Zhang, J.; Qin, F.; Liu, D.; Cheng, Y.B.; Zhou, Y.; Wang, T. Eliminated hysteresis and stabilized power output over 20% in planar heterojunction perovskite solar cells by compositional and surface modifications to the low-temperatureprocessed TiO2 layer. J. Mater. Chem. A 2017, 5, 9402−9411. 

(30) Frost, J. M.; Walsh, A. What Is Moving in Hybrid Halide Perovskite Solar Cells? Acc. Chem. Res. 2016, 49, 528−535. 

(31) Futscher, M. H.; Lee, J. M.; McGovern, L.; Muscarella, L. A.; Wang, T.; Haider, M. I.; Fakharuddin, A.; Schmidt-Mende, L.; Ehrler, B. Quantification of ion migration in CH3NH3PbI3 perovskite solar cells by transient capacitance measurements. Mater. Horiz. 2019, 6, 1497−1503. 

(32) Zhou, Y.; Sternlicht, H.; Padture, N. P. Transmission Electron Microscopy of Halide Perovskite Materials and Devices. Joule 2019, 3, 641−661. 

(33) Pavlovetc, I. M.; Brennan, M. C.; Draguta, S.; Ruth, A.; Moot, T.; Christians, J. A.; Aleshire, K.; Harvey, S. P.; Toso, S.; Nanayakkara, S. U.; Messinger, J.; Luther, J. M.; Kuno, M. Suppressing cation migration in triple-cation lead halide perovskites. ACS Energy Letters 2020, 5, 2802−2810. 

(34) Ceratti, D. R.; Zohar, A.; Kozlov, R.; Dong, H.; Uraltsev, G.; Girshevitz, O.; Pinkas, I.; Avram, L.; Hodes, G.; Cahen, D. Eppur si Muove: Proton Diffusion in Halide Perovskite Single Crystals. Adv. Mater. 2020, 32, 2002467. 

(35) Jin, H.; Debroye, E.; Keshavarz, M.; Scheblykin, I. G.; Roeffaers, M. B.; Hofkens, J.; Steele, J. A. It’s a trap! on the nature of localised states and charge trapping in lead halide perovskites. Mater. Horiz. 2020, 7, 397−410. 

(36) Snaith, H. J.; Abate, A.; Ball, J. M.; Eperon, G. E.; Leijtens, T.; Noel, N. K.; Stranks, S. D.; Wang, J. T. W.; Wojciechowski, K.; Zhang, W. Anomalous hysteresis in perovskite solar cells. J. Phys. Chem. Lett. 2014, 5, 1511−1515. 

(37) Weber, S. A.; Hermes, I. M.; Turren-Cruz, S. H.; Gort, C.; Bergmann, V. W.; Gilson, L.; Hagfeldt, A.; Graetzel, M.; Tress, W.; Berger, R. How the formation of interfacial charge causes hysteresis in perovskite solar cells. Energy Environ. Sci. 2018, 11, 2404−2413. 

(38) Van Reenen, S.; Kemerink, M.; Snaith, H. J. Modeling Anomalous Hysteresis in Perovskite Solar Cells. J. Phys. Chem. Lett. 2015, 6, 3808−3814. 

(39) Sherkar, T. S.; Momblona, C.; Gil-Escrig, L.; Ávila, J.; Sessolo, M.; Bolink, H. J.; Koster, L. J. A. Recombination in Perovskite Solar Cells: Significance of Grain Boundaries, Interface Traps, and Defect Ions. ACS Energy Letters 2017, 2, 1214−1222. 

(40) Sajedi Alvar, M.; Blom, P. W.; Wetzelaer, G. J. A. Space-chargelimited electron and hole currents in hybrid organic-inorganic perovskites. Nat. Commun. 2020, 11, 4023. 

(41) Kerner, R. A.; Schulz, P.; Christians, J. A.; Dunfield, S. P.; Dou, B.; Zhao, L.; Teeter, G.; Berry, J. J.; Rand, B. P. Reactions at noble metal contacts with methylammonium lead triiodide perovskites: Role of underpotential deposition and electrochemistry. APL Mater. 2019, 7, 041103. 

(42) Koster, L. J. A.; Smits, E. C. P.; Mihailetchi, V. D.; Blom, P. W. M. Device model for the operation of polymer/fullerene bulk heterojunction solar cells. Phys. Rev. B: Condens. Matter Mater. Phys. 2005, 72, 85205. 

(43) Sherkar, T. S.; Momblona, C.; Gil-Escrig, L.; Bolink, H. J.; Koster, L. J. A. Improving Perovskite Solar Cells: Insights From a Validated Device Model. Adv. Energy Mater. 2017, 7, 1602432. 

1093 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

<u>ACS Energy Letters</u> 

<mark>http://pubs.acs.org/journal/aelccp</mark> 

<mark>Letter</mark> 

(44) Sherkar, T. S.; Le Corre, V. M.; Koopmans, M.; Wobben, F.; Koster, L. J. A. SIMsalabim GitHub repository. 2020 (https://github. com/kostergroup/SIMsalabim) (accessed December 2020). 

1094 

https://dx.doi.org/10.1021/acsenergylett.0c02599 ACS Energy Lett. 2021, 6, 1087−1094 

