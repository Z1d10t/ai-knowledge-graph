# Single-atom Pt-I3 sites on all-inorganic Cs2SnI6 perovskite for efficient photocatalytic hydrogen production

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 203 |
| 作者 | Peng Zhou, Hui Chen, Y. Chao, Qing-Hua Zhang, Weiyu Zhang, Fan Lv, Lin Gu, Qiang Zhao et al. |
| DOI | 10.1038/s41467-021-24702-8 |
| 源文件 | 027_Zhou_2021_Single-atom-Pt-I3-sites-on-all-inorganic-Cs2SnI6.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-021-24702-8 **OPEN** 

# Single-atom Pt-I3 sites on all-inorganic Cs2SnI6 perovskite for efficient photocatalytic hydrogen production 

Peng Zhou<sup>1,6</sup> , Hui Chen<sup>1,2,3,6</sup> , Yuguang Chao<sup>1,6</sup> , Qinghua Zhang<sup>4</sup> , Weiyu Zhang<sup>1</sup> , Fan Lv<sup>1</sup> , Lin Gu<sup>4</sup> , Qiang Zhao<sup>2</sup> , Ning Wang 2,3, Jinshu Wang2 & Shaojun Guo 1,5✉ 

Organic-inorganic lead halide perovskites are a new class of semiconductor materials with great potential in photocatalytic hydrogen production, however, their development is greatly plagued by their low photocatalytic activity, instability of organic component and lead toxicity in particular. Herein, we report an anti-dissolution environmentally friendly Cs2SnI6 perovskite anchored with a new class of atomically dispersed Pt-I3 species (PtSA/Cs2SnI6) for achieving the highly efficient photocatalytic hydrogen production in HI aqueous solution at room temperature. Particularly, we discover that Cs2SnI6 in PtSA/Cs2SnI6 has a greatly enhanced tolerance towards HI aqueous solution, which is very important for achieving excellent photocatalytic stability in perovskite-based HI splitting system. Remarkably, the PtSA/Cs2SnI6 catalyst shows a superb photocatalytic activity for hydrogen production with a record turnover frequency of 70.6 h<sup>−1</sup> per Pt, about 176.5 times greater than that of Pt nanoparticles supported Cs2SnI6 perovskite, along with superior cycling durability. Chargecarrier dynamics studies in combination with theory calculations reveal that the dramatically boosted photocatalytic performance on PtSA/Cs2SnI6 originates from both unique coordination structure and electronic property of Pt-I3 sites, and strong metal-support interaction effect that can not only greatly promote the charge separation and transfer, but also substantially reduce the energy barrier for hydrogen production. This work opens a new way for stimulating more research on perovskite composite materials for efficient hydrogen production. 

> 1 School of Materials Science and Engineering, Peking University, Beijing, P. R. China. 2 School of Materials and Energy, University of Electronic Science and Technology of China, Chengdu, P. R. China.<sup>3</sup> State Key Laboratory of Marine Resource Utilization in South China Sea, Hainan University, Haikou, P. R. China. 4 Institute of Physics, Chinese Academy of Sciences, Beijing, P. R. China. 5 The Beijing Innovation Center for Engineering Science and Advanced Technology, Peking University, Beijing, P. R. China.<sup>6</sup> These authors contributed equally: Peng Zhou, Hui Chen, Yuguang Chao.<sup>✉</sup> email: guosj@pku.edu.cn 

1 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 

plitting hydroiodic acid (HI) has significant research value in the field of energy science and technology<sup>1–5</sup> . The traditional Sdecomposition of HI at high temperature of 500 °C has been demonstrated to be an effective approach to produce hydrogen<sup>2,5</sup> , however, it is unsustainable, dangerous, and not cost-effective. Solar-driven splitting of HI, as a promising low-cost technique, has recently attracted more research interest because it can achieve the co-production of zero-emission hydrogen (H2) fuel and valueadded chemicals (I2/I3<sup>−</sup> ) only under light condition at room temperature (RT)<sup>6–8</sup> . The development of advanced photocatalysts is very necessary for achieving the high efficiency of photocatalytic HI splitting, however, unfortunately, the reported photocatalysts cannot stably work in HI solution with strong acid property, which poses a high demand on new material selection and photocatalyst design. Recently, the organic–inorganic lead halide perovskites (OLHPs), such as MAPbI3 (MA = CH3NH3), with the advantages of facile synthesis, low cost and superior optoelectronic characteristics<sup>9–13</sup> , have been proved to be a promising photocatalyst for hydrogen production. Nevertheless, the unstable organic component in those MAPbI3 photocatalytic materials easily suffers from the serious photo corrosion in HI solution<sup>14–25</sup> , which severely limit the applications of OLHPs in the photocatalytic HI splitting into hydrogen<sup>19,21</sup> . Besides, the lead toxicity of MAPbI3 also inhibits its practical application. In the seek for the lead-free perovskite materials, Sn-based perovskites have been demonstrated to have a narrower optical bandgap than that of the Pb-based perovskites<sup>26–30</sup> , indicating their larger light absorption range. Especially, all-inorganic Cs2SnI6 perovskite is more preferred material system in view of its good stability, superior conductivity, and appropriate energy band levels<sup>31–35</sup> . 

Apart from above obstacles, the reported OLHPs-based photocatalysts still suffer from a very low photocatalytic activity caused by the serious photogenerated electron–hole recombination<sup>15,17</sup> , restricting their further development. Decorating cocatalyst onto semiconductors to form the hetero-structured photocatalysts has been regarded as one of the simplest and most effective strategies for inhibiting the charge recombination, and hence improving the photocatalytic performance in the H2 evolution reaction<sup>36–40</sup> . Considering the fact that halide perovskites possess a large number of defects caused by its inherent property of low temperature crystallization<sup>41</sup> , they might be ideal scaffolds to anchor metal atoms and stabilize single atoms for achieving the greatly enhanced photocatalysis. However, developing new procedures for achieving highly efficient photocatalysts of halide perovskites anchored by a new class of metal single atoms for the hydrogen production, to the best of our knowledge, is still a great challenge in the field of photocatalysis. 

Herein, we demonstrate the first example on making a new class of single-atom Pt–I3 sites anchored on all-inorganic Cs2SnI6 perovskite (PtSA/Cs2SnI6) for efficient H2 evolution photocatalysis from HI splitting at RT via a facile and cost-effective strategy. Turnover frequency (TOF) of as-prepared PtSA/Cs2SnI6 catalyst exhibits 176.5-fold enhancements compared with Pt nanoparticle anchored on Cs2SnI6 (PtNP/Cs2SnI6) catalyst, outperforming all of reported Pt-loaded halide perovskites photocatalysts, along with excellent catalytic stability. Combining charge-carrier dynamics studies with theory calculations reveals that both unique coordination structure and electronic property of Pt–I3 sites and strong metal–support interaction (SMSI) effect are the main reasons in achieving the greatly enhanced photocatalytic performance in hydrogen production from HI aqueous solution. 

### Results 

Energy band structure of Cs2SnI6 and its stability in aqueous HI solution system. The synthetic procedure of PtSA/Cs2SnI6 is schematically illustrated in Fig. 1a. Briefly, the Cs2SnI6 was firstly 

synthesized by a one-pot hydrothermal treatment of cesium acetate and tin (II) acetate in presence of the excess hydriodic acid (HI) solution, followed by the impregnation of the platinum complex. Subsequently, the PtSA/Cs2SnI6 was obtained after activation at 160 °C for 1 h in H2/Ar atmosphere. Field-emission scanning electron microscopy image of the as-prepared Cs2SnI6 demonstrates that the Cs2SnI6 mainly adopts the octahedral morphology (Fig. 1b). Powder X-ray diffraction (PXRD) pattern (Fig. 1c) of the obtained Cs2SnI6 can be well indexed to the cubic Cs2SnI6 phase (JCPDS card NO. 51-0466), confirming the successful synthesis of Cs2SnI6. Furthermore, the as-synthesized Cs2SnI6 with a high yield of 93% exhibits the high-temperature stability with a decomposition temperature up to 350 °C in air atmosphere (Supplementary Fig. 1). Furthermore, Cs2SnI6 is insoluble in aqueous HI solution at RT, confirmed by the fact that the solubility of Cs2SnI6 was zero at 25 °C, and slightly increased to 10.0 × 10<sup>−6</sup> mol L<sup>−1</sup> as the temperature was improved to 100 °C, still far lower than that of reported MAPbI3 (0.645 mol L<sup>−1</sup> at 20 °C) (Fig. 1d)<sup>25</sup> . Moreover, there is no change in the color of aqueous HI solution with or without Cs2SnI6 powder, which further verifies the insolubility for Cs2SnI6 (inset of Fig. 1d). 

Furthermore, the stability of Cs2SnI6 in aqueous HI solution system was further investigated via PXRD (Fig. 1e). We find that the as-prepared Cs2SnI6 powder exhibits the excellent stability in aqueous HI solution system (decompose when HI concentration is <1.0 M), better than that of reported MAPbI3 (3.16 M)<sup>25</sup> . These results demonstrate that the Cs2SnI6-based aqueous HI splitting system is superior to the MAPbI3-based one, suggesting the great potential in photocatalytic HI splitting. The ultraviolet–visible (UV–vis) absorption spectrum and X-ray photoelectron spectroscopy (XPS) valence spectrum were employed to determine the energy band structure of as-prepared Cs2SnI6. As shown in Fig. 1f, the Cs2SnI6 powder has a broad optical absorption range, and its bandgap energy (Eg) is 1.22 eV, by calculating from the absorbance data on the basis of the Kubelka–Munk equation, less than that of reported MAPbI3 (1.53 eV) (Supplementary Fig. 2)<sup>25</sup> . The result indicates that Cs2SnI6 possesses a larger light absorption range and higher conductivity than MAPbI3. The valence band (VB) position of the Cs2SnI6 is −5.46 eV with respect to the vacuum level (corresponding to 0.96 eV versus the normal hydrogen electrode (NHE)), as obtained from XPS VB spectroscopy (Supplementary Fig. 3). Accordingly, the corresponding conduction band (CB) position of Cs2SnI6, obtained by coupling the VB positions and Eg, is calculated to be −4.24 eV with respect to the vacuum level (corresponding to −0.26 eV versus NHE). It should be noted that the calculated values of CB and VB are an approximation since the complicated electrolyte–perovskite interface effects were not considered herein. The suitable energy band levels of Cs2SnI6 (inset of Fig. 1g) provides new opportunity for straddling the redox potentials of HI to split HI into H2 and I3<sup>−</sup> . 

Structure characterization of PtSA/Cs2SnI6. The aberrationcorrected high-angle annular dark field-scanning transmission electron microscopy (HAADF-STEM) was performed to confirm the distribution and configuration of Pt single-atom in Cs2SnI6. No Pt clusters or large nanoparticles were observed in the lowmagnification HAADF-STEM image (Fig. 2a), further confirmed by PXRD analysis (Supplementary Fig. 4), in which there are no characteristic peaks of crystalline Pt species. The atomicresolution HAADF-STEM image (Fig. 2b) clearly depicts the individual dispersion of Pt atoms on the surface of as-prepared Cs2SnI6. The corresponding energy dispersive X-ray spectroscopy (EDS) mapping images confirm the uniform dispersion of Sn, I, and Pt atoms in PtSA/Cs2SnI6 (Fig. 2c), indicating that Pt atoms are uniformly distributed over Cs2SnI6. The Pt content on PtSA/ 

2 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 



Fig. 1 Energy band structure of Cs2SnI6 and its stability in aqueous HI solution system. a Schematic diagram of preparation process for the PtSA/Cs2SnI6 catalyst. b SEM image and c PXRD pattern of Cs2SnI6. d Solubility of Cs2SnI6 in aqueous HI solution at different temperature. The inset shows the photograph of the 6 M HI aqueous solution with and without Cs2SnI6 powder at 25 °C. e PXRD patterns of precipitates for Cs2SnI6 powder in aqueous HI solution with various concentrations. f UV–visible absorption spectrum of Cs2SnI6 powder. The inset is the photograph of the Cs2SnI6. g Schematic energy band diagram of the Cs2SnI6, charge generation and charge transfer process over the Cs2SnI6 under visible-light irradiation. 

Cs2SnI6 is determined to be 0.12 wt% by inductively coupled plasma-atomic emission spectrometry (ICP-AES). 

The oxidation state and coordination environment of the Pt species in PtSA/Cs2SnI6 were further investigated by X-ray absorption fine structure (XAFS) spectroscopy. Figure 2d depicts the normalized Pt L3-edge X-ray absorption near-edge structure (XANES) spectra of PtSA/Cs2SnI6, PtI2 and Pt foil. The white-line intensity of Pt L3-edge XANES of PtSA/Cs2SnI6 is higher than those of PtI2 and Pt foil, indicating that the oxidation state of Pt in PtSA/Cs2SnI6 is more than +2. The Fourier-transformed (FT) k<sup>3</sup> -weighted extended X-ray absorption fine structure (EXAFS) spectra (Fig. 2e) exhibits a prominent peak at ∼2.49 Å in PtSA/ Cs2SnI6, similar to that of the Pt–I bond in PtI2, and shorter than that of the Pt–Pt bond in Pt foil, implying that the Pt atoms are anchored onto the surface of PtSA/Cs2SnI6 by the Pt–I bond. According to the EXAFS fitting results (Fig. 2f, Supplementary Figs. 5, 6, and Table 1), one Pt atom in PtSA/Cs2SnI6 is coordinated with approximately three I atoms (labeled as Pt–I3). To further confirm the Pt single atoms in the PtSA/Cs2SnI6, the wavelet transform (WT) EXAFS of the PtSA/Cs2SnI6 and the reference systems (PtI2 and Pt foil) was performed (Fig. 2g, h and 

Supplementary Figs. 7, 8). The WT-EXAFS maximum is observed at 9.38 Å<sup>−1</sup> in Pt foil, assigned to the Pt–Pt bond. In contrast, the PtSA/Cs2SnI6 presents an intensity maximum value at 9.89 Å<sup>−1</sup> , similar to that of Pt–I bond in PtI2 (9.82 Å<sup>−1</sup> ), further indicating the atomic dispersion of Pt coordinated with I atoms on the surface of PtSA/Cs2SnI6. 

To further confirm the chemical state of Pt and chemical environment of Cs, Sn, and I in the catalysts, XPS measurements were conducted. As shown in Fig. 2i, the binding energy of Pt 4f in the high-resolution XPS spectrum of PtSA/Cs2SnI6 can be deconvoluted into two chemical states, assigned to Pt<sup>2+</sup> at 73.1 and 75.6 eV, and Pt<sup>4+</sup> at 75.1 and 77.5 eV, respectively, suggesting that Pt in the PtSA/Cs2SnI6 is Pt<sup>δ+</sup> (2 < δ < 4), in agreement with the aforementioned Pt L3-edge XANES results. Noticeably, a positive shift in the I 3d XPS spectra (Supplementary Fig. 9a) is observed upon Pt loading, implying the strong interaction between the Pt and I atoms in PtSA/Cs2SnI6. It means that those I species can serve as the anchor sites, and coordinate with the isolated Pt atoms. Moreover, the binding energy of Sn 3d in PtSA/Cs2SnI6 has an obviously positive shift, whereas that of Cs 3d was unchanged relative to that in pure Cs2SnI6 

3 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 



Fig. 2 Structure characterization of PtSA/Cs2SnI6. a Low-magnification and b high-magnification HAADF-STEM images, and c the corresponding STEMEDS elemental mapping of PtSA/Cs2SnI6. d Pt L3-edge XANES spectra and corresponding K<sup>3</sup> -weighted FT spectra at e R space and g k-space of PtSA/ Cs2SnI6, PbI2 and Pt foil. XANES f R space and h k-space fitting curves of PtSA/Cs2SnI6. i High-resolution XPS Pt 4f spectrum of PtSA/Cs2SnI6. 

(Supplementary Fig. 9b, c), implying that the electron transfer from Cs2SnI6 to PtSA depends on the Sn–I–Pt bonds rather than the Cs–I–Pt bonds. 

Superior photocatalytic activity and stability of PtSA/Cs2SnI6 catalyst. The activities of photocatalytic H2 evolution over PtSA/ Cs2SnI6, PtNP/Cs2SnI6, and Cs2SnI6 catalysts were evaluated in aqueous HI solution system under visible-light (λ ≥ 420 nm, 100 mW cm<sup>−2</sup> ) irradiation by a 300 W Xe lamp and a homemade double-layered Pyrex vessel. The results show that pristine Cs2SnI6 owns a poor photocatalytic performance with a H2 production rate of 25 μmol h<sup>−1</sup> g<sup>−1</sup> (Fig. 3a and Supplementary Fig. 10). We find that the photocatalytic performance of Cs2SnI6 can be dramatically increased by anchoring Pt single atoms onto the surface of Cs2SnI6, reaching its maximum upon Pt loading up to 0.12 wt% (Fig. 3a and Supplementary Fig. 11). Further increasing or decreasing the loading content of Pt on Cs2SnI6 surface leads to the decreased photocatalytic activities. This is because the excessive Pt species can reduce the light absorption of Cs2SnI6 due to the shading effect whereas the insufficient Pt species cannot provide the rich H2-releasing active sites. 

Considering that the interfacial contact can affect the charge transfer from Cs2SnI6 to PtNP, we also prepared the PtNP on Cs2SnI6 (noted as PtNPphoto/Cs2SnI6) by the direct photodeposition method, and studied its photocatalytic activity. The result shows that the rate of H2 evolution (101 μmol g<sup>−1</sup> h<sup>−1</sup> ) over the optimal PtNPphoto/Cs2SnI6 sample is only slightly better than that of PtNP/Cs2SnI6 (Supplementary Fig. 12), still much lower than that of PtSA/Cs2SnI6. The 0.12wt% PtSA/Cs2SnI6 shows the champion activity for the photocatalytic H2 production with a H2 production rate of 430 μmol h<sup>−1</sup> g<sup>−1</sup> , 17.2 and 5.8 times higher than pure Cs2SnI6 and optimized 3.88wt% PtNP/ Cs2SnI6 (Fig. 3a and Supplementary Figs. 13, 14), and also achieves a TOF of 70.6 h<sup>−1</sup> per Pt, 176.5 times higher than that of PtNP/Cs2SnI6 catalyst (0.4 h<sup>−1</sup> ) (Fig. 3b). Moreover, the TOF of PtSA/Cs2SnI6 catalyst is superior to all of the reported Pt-loaded halide perovskite photocatalysts (Fig. 3c and Supplementary Table 2). 

Furthermore, the photocatalytic activity of PtSA/Cs2SnI6 can be stable without obvious decrease over four cycles and even at a successive 180-h tracking (Fig. 3d and Supplementary Fig. 15). After stability test, the Pt species are still atomically dispersed 

4 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 



Fig. 3 Superior photocatalytic activity and stability of PtSA/Cs2SnI6 catalyst. a The rate of photocatalytic H2 evolution over PtSA/Cs2SnI6, PtNP/ Cs2SnI6, and Cs2SnI6 catalysts. b TOF of PtSA/Cs2SnI6 and PtNP/Cs2SnI6 catalysts. c TOF comparisons of PtSA/Cs2SnI6 catalyst and other reported Ptloaded halide perovskite photocatalysts. d Cyclic stability of the PtSA/Cs2SnI6 catalyst. 

on the surface of Cs2SnI6, confirmed by the diverse results of PXRD, HAADF-STEM, and STEM-EDS elemental mappings (Supplementary Fig. 16–18). In addition, the XPS spectrum of Pt 4f in PtSA/Cs2SnI6 after photocatalytic test reveals that the valence of Pt species has no obvious change (Supplementary Fig. 19), revealing the excellent chemical stability of PtSA on Cs2SnI6. 

Charge-carrier dynamics. Photoluminescence (PL) technique was employed to evaluate the effect of Pt single atoms on the kinetics of charge carriers transfer and recombination over the Cs2SnI6. As depicted in Fig. 4a, the PL quenching of PtSA/Cs2SnI6 is more efficient than those of PtNP/Cs2SnI6 and Cs2SnI6, indicating the enhanced extraction and reduced recombination of charge carriers. To quantify the charge-carrier dynamic, TRPL spectroscopy was performed (Fig. 4b). The average decay lifetime of PtSA/Cs2SnI6 is ca. 61 ns (inset of Fig. 4b), smaller than those of PtNP/Cs2SnI6 (ca. 98 ns) and Cs2SnI6 (ca. 109 ns), further confirming that the atomically dispersed Pt species can enhance the separation of charge carriers. Besides, the photocurrent response spectra reveal that the PtSA/Cs2SnI6 exhibits a significantly enhanced photocurrent than those of PtNP/Cs2SnI6 and Cs2SnI6 (Fig. 4c), indicating its more efficient separation and transfer of photogenerated electron–hole pairs. Similarly, the linear-sweep voltammogram curves demonstrate that PtSA/ Cs2SnI6 presents an overpotential of −0.38 V (versus RHE) at current density of 10 mA cm<sup>−2</sup> , much lower than those of PtNP/ Cs2SnI6 and Cs2SnI6 (Supplementary Fig. 20), implying its higher efficiency during the surface catalytic reaction. Furthermore, the PtSA/Cs2SnI6 displays the smallest semicircle in Nyquist plots obtained from the electrochemical impedance spectroscopy (Fig. 4d), also suggesting that the atomically dispersed Pt–I3 configuration makes a great contribution to improving the efficiency of charge separation and transfer over Cs2SnI6. 

Theoretical calculations. The photogenerated charge transfer on PtNP/Cs2SnI6 and PtSA/Cs2SnI6 was investigated by the DFT calculations. An extra electron was introduced to simulate the photogenerated electron in PtNP/Cs2SnI6 and PtSA/Cs2SnI6. The obtained charge density difference before and after photoexcitation reveals that the introduced photogenerated electrons tend to be distributed in the whole PtNP in PtNP-Cs2SnI6 (Fig. 5a), which undesirably decreases the electron density per Pt atom in PtNP. Instead, the electron in PtSA/Cs2SnI6 is only located between the PtSA and neighboring three I atoms (Fig. 5b), implying the high electron density on the Pt–I3 site. This is attributed to the SMSI effect<sup>42</sup> . Thus, the electron density per Pt atom in PtNP is further lower than that of PtSA, which is considered to lead to the lower HER activity of PtNP. To exclude the background charge effect, one donor hydrogen atom was introduced to calculate the charge density difference<sup>43</sup> . The obtained results also showed the localized distribution of electrons in the Pt–I3 region (Supplementary Fig. 21). This SMSI effect is beneficial to the photogenerated charge transfer between the photocatalyst and cocatalyst<sup>42</sup> , also confirmed by the calculated PDOS of PtNP and PtSA on Cs2SnI6 (Fig. 5c). The most 5d states of PtSA are below the Fermi level, indicating its electron-rich state. The integrated PDOS areas of uncaptured Pt 5d states above the Fermi level in PtNP and PtSA are calculated to be 1.19 and 0.71, respectively, which quantifies the different electron-saturation levels of PtNP and PtSA. This implies the relative electrondeficient property of PtNP. This means that the PtSA species owns a stronger ability for capturing electrons from the Cs2SnI6, leading to the higher hydrogen production activity of PtSA/ Cs2SnI6. Thus the different electronic properties of PtNP and PtSA on Cs2SnI6 lead to their different catalytic dynamics in the H2 evolution process, in which the PtSA owns a remarkably lower energy barrier (0.11 eV) than PtNP (0.92 eV) (Fig. 5d). This well explains the observably higher photocatalytic H2 production activity of PtSA/Cs2SnI6. 

5 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 



Fig. 4 Charge-carrier dynamics. a Steady-state PL spectra, b time-resolved transient PL decay, c photocurrent responses spectra, and d electrochemical impedance spectroscopy of Cs2SnI6, PtNP/Cs2SnI6, and PtSA/Cs2SnI6 catalysts. 

### Discussion 

In summary, we report a class of all-inorganic perovskite PtSA/ Cs2SnI6 single-atom photocatalyst for achieving highly efficient photocatalytic hydrogen production in aqueous HI solution. The HAADF-STEM, XAFS spectroscopy, and XPS spectroscopy results confirm the atomically dispersed Pt single atoms with the well-defined Pt–I3 structure on Cs2SnI6. By combining chargecarrier dynamics studies and DFT calculations, we discover that the unique coordination structure and electronic property of Pt–I3 species can contribute to the SMSI effect, boosting the photogenerated electron transfer from Cs2SnI6 to Pt single atoms, and simultaneously reducing the Gibbs free energy and accelerating the kinetics for the hydrogen production. Benefiting from these structural advantages, an outstanding TOF of 70.6 h<sup>−1</sup> per Pt was achieved over PtSA/Cs2SnI6 catalyst, 176.5-fold higher than that of PtNP/Cs2SnI6, setting a new TOF record reported for Pt-loaded halide perovskite photocatalysts, along with an excellent cycling stability. The achievements herein can significantly stimulate the exploitation of novel metal single atoms-perovskite hetero-structured photocatalysts systems and their further sustainable photocatalytic applications. 

to separate the EXAFS contribution from different coordination shells. The quantitative curve-fitting was performed by using the ARTEMIS module of IFEFFIT3 to obtain the elaborate structural parameters around Pt central atom in the as-synthesized catalysts. The functions of effective curved-wave backscattering amplitudes F(k) and phase shifts Φ(k) were calculated by the ab initio code FEFF8.0. Based on the fitting of reference samples of metal Pt bulk and PtI2 bulk, S0<sup>2</sup> (amplitude reduction factor) was fixed to the best-fit value of 0.70. The interatomic distance (R) and the Debye–Waller factor (σ<sup>2</sup> ) were allowed to change during the fitting analysis. The coordination of Pt–I was distinguished from Pt–Pt according to the bond length difference. 

Photocatalytic H2 evolution activity. The photocatalytic H2 evolution experiments in aqueous HI solution (containing 20 vol% H3PO2 as a stabilizer) were executed in a homemade double-layered Pyrex vessel. A 300 W Xe lamp with a visible-light illumination (λ ≥ 420 nm, 100 mW cm<sup>−2</sup> ) was employed as a light source for the photocatalytic reaction. In a typical photocatalytic H2 evolution procedure, 10 mg of as-synthesized photocatalyst was introduced into 10 mL aqueous HI solution containing 20 vol% H3PO2 with the constant stirring rate, and then degassed with Ar through the reactor for 30 min to completely remove the dissolved air before irradiation. The reaction temperature was preserved at 25 °C by a circulation cooling water. The amount of evolved H2 was detected every hour in a 6 h test by gas chromatography (GC-7890B, Agilent, America, TCD, with MS-5 Å molecular sieve column) with Ar as the carrier gas. The recycling photocatalytic experiment for the stability test of as-prepared photocatalyst was carried out every 6 h as a cycle. 

### Methods 

Synthesis of PtSA/Cs2SnI6. As-prepared Cs2SnI6 powder (0.10 g) was dispersed in 50 mL of chloroform containing different amount of Pt(acac)2. Then, the mixture was further ultrasonicated for 30 min and stirred for 12 h. Subsequently, the obtained precipitates were centrifugalized and washed for three times with isopropanol, and further dried in an oven 60 °C for 2 h. Finally, the PtSA/Cs2SnI6 was obtained by the treatment in a tube furnace at 160 °C for 1 h under a 5% H2/Ar atmosphere. The loading content of Pt on PtSA/Cs2SnI6 is determined by ICP-AES. 

XAFS characterization and data analysis. The Pt L3-edge XAFS spectra were performed at the 1W1B beamline of Beijing Synchrotron Radiation Facility (Beijing), operating at 2.5 GeV with a ring current of 250 mA. The X-ray beam was monochromatized by a Si (111) double crystal monochromator. The ATHENA module of the IFEFFIT software packages was used as the standard procedure to process the acquired EXAFS date. The k<sup>3</sup> -weighted χ (k) data of Pt K-edge in the k- space (2.0–12 Å<sup>−1</sup> ) were FT to real (R) space by a handing windows (dk = 1.0 Å<sup>−1</sup> ) 

Theoretical calculations. The photocatalytic property of PtSA/Cs2SnI6 was investigated by the Vienna Ab initio Simulation Package. The PAW pseudopotentials were used to describe the interaction between valence electrons and the ionic core. The energy profile for hydrogen production was calculated by the revised Perdew–Burke–Ernzerh functional of the generalized gradient approximation. The reported standard hydrogen electrode (SHE) model was used in the calculations of Gibbs free energy changes (ΔG) in hydrogen adsorption<sup>44</sup> . In this model, the chemical potential (µ(H<sup>+</sup> ) + µ(e<sup>−</sup> )) of a proton–electron pair was equal to half of the chemical potential (µ(H2)) of one gaseous hydrogen at U = 0 V versus SHE at pH = 0. The surface of Cs2SnI6 was simulated by its typical {111} facet, which was described by a 2 × 2 supercell with three Sn layers and six Cs–I layers (equal to three CsI–Sn–CsI layers). The PtSA was simulated by coordinating with three surface I atoms according to the above experimental results. The PtNP was described by a cluster containing 6 Pt atoms. The vacuum thickness was set to 16 Å. The larger supercells and higher vacuum thickness were tested, showing little effect on the calculation of hydrogen adsorption, as shown in Supplementary Table 3. A 

6 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 



Fig. 5 Charge density distribution and Gibbs energy calculations. The charge density difference maps between before and after photoexcitation: a PtNP/ Cs2SnI6 and b PtSA/Cs2SnI6. The isosurface of charge density is 0.001e Å<sup>−3</sup> . The insets stand for the top view. The yellow region represents the additional electron distribution. An excess electron was added into the models, which was used to describe the photogenerated electron. c The PDOS (5d states) of PtNP/Cs2SnI6 and PtSA/Cs2SnI6. The dashed line stands for the Fermi level. d The calculated energy profile for hydrogen production on PtNP/Cs2SnI6 and PtSA/Cs2SnI6. 

plane-wave basis with energy cutoff of 400 eV and an energy convergence threshold of 1.0 × 10<sup>−5</sup> eV were used to perform the geometry optimization at the gamma point. After geometry optimization, the projected density of states of PtNP/Cs2SnI6 and PtSA/Cs2SnI6 models is calculated with the energy convergence of 1.0 × 10<sup>−5</sup> eV and the Monkhorst–Pack k-point mesh of 2 × 1 × 1. To track the transfer of photogenerated electron between the Pt and photocatalyst, an extra electron with a compensating uniform background charge was used to simulate the photogenerated electron<sup>43</sup> . The energy convergence of 1.0 × 10<sup>−5</sup> eV and the Monkhorst–Pack k-point mesh of 2 × 1 × 1 were adopted to calculate the difference of charge density plots between PtNP/PtSA and Cs2SnI6. Besides, to exclude the background charge effect caused by the extra electron, the charge difference density maps between PtNP/PtSA and Cs2SnI6 was also calculated by inserting a donor hydrogen atom into the Cs2SnI6 bulk, which can provide one proton and one electron<sup>43</sup> . 

### Data availability 

All experimental data within the article and its Supplementary Information are available from the corresponding author upon reasonable request. 

Received: 15 February 2021; Accepted: 5 July 2021; 



4. Cerri, G. et al. Sulfur-iodine plant for large scale hydrogen production by nuclear power. Int. J. Hydrogen Energy 35, 4002–4014 (2010). 

5. Norman, J. H., Mysels, K. J., Sharp, R. & Williamson, D. Studies of the sulfuriodine thermochemical water-splitting cycle. Int. J. Hydrogen Energy 7, 545–556 (1982). 

6. Ardo, S., Park, S. H., Warren, E. L. & Lewis, N. S. Unassisted solar-driven photoelectrosynthetic HI splitting using membrane-embedded Si microwire arrays. Energ. Environ. Sci. 8, 1484–1492 (2015). 

7. Mubeen, S., Lee, J., Singh, N., Moskovits, M. & McFarland, E. W. Stabilizing inorganic photoelectrodes for efficient solar-to-chemical energy conversion. Energ. Environ. Sci. 6, 1633–1639 (2013). 

8. McKone, J. R., Potash, R. A., DiSalvo, F. J. & Abruna, H. D. Unassisted HI photoelectrolysis using n-WSe2 solar absorbers. Phys. Chem. Chem. Phys. 17, 13984–13991 (2015). 

9. Ponseca, C. S. et al. Organometal halide perovskite solar cell materials rationalized: ultrafast charge generation, high and microsecond-long balanced mobilities, and slow recombination. J. Am. Chem. Soc. 136, 5189–5192 (2014). 

10. Jeon, N. J. et al. Compositional engineering of perovskite materials for highperformance solar cells. Nature 517, 476–480 (2015). 

11. Dong, Q. F. et al. Electron-hole diffusion lengths >175 μm in solution-grown CH3NH3PbI3 single crystals. Science 347, 967–970 (2015). 

12. Stranks, S. D. et al. Electron-hole diffusion lengths exceeding 1 micrometer in an organometal trihalide perovskite absorber. Science 342, 341–344 (2013). 

13. Xing, G. C. et al. Long-range balanced electron- and hole-transport lengths in organic-inorganic CH3NH3PbI3. Science 342, 344–347 (2013). 

### References 

1. Onuki, K., Kubo, S., Terada, A., Sakaba, N. & Hino, R. Thermochemical watersplitting cycle using iodine and sulfur. Energ. Environ. Sci. 2, 491–497 (2009). 

2. Wang, L. J. et al. Catalytic performance of semi-coke on hydrogen iodide decomposition in sulfur-iodine thermochemical cycle for carbon dioxide-free hydrogen production. Energ. Convers. Manag. 173, 659–664 (2018). 

3. Beghi, G. E. Review of thermochemical hydrogen production. Int. J. Hydrogen Energy 6, 555–566 (1981). 

14. Wu, Y. Q. et al. Enhancing the photocatalytic hydrogen evolution activity of mixed-halide perovskite CH3NH3PbBr3-xIx achieved by bandgap funneling of charge carriers. ACS Catal. 8, 10349–10357 (2018). 

15. Zhao, Z. J. et al. Ni3C-Decorated MAPbI3 as visible-light photocatalyst for H2 evolution from HI splitting. ACS Catal. 9, 8144–8152 (2019). 

16. Wang, H. et al. Promoting photocatalytic H2 evolution on organic-inorganic hybrid perovskite nanocrystals by simultaneous dual-charge transportation modulation. ACS Energy Lett. 4, 40–47 (2019). 

7 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-24702-8 

17. Wang, X. M. et al. Dynamic interaction between methylammonium lead iodide and TiO2 nanocrystals leads to enhanced photocatalytic H2 evolution from HI splitting. ACS Energy Lett. 3, 1159–1164 (2018). 

18. Guo, Y. M. et al. Stable lead-free (CH3NH3)3Bi2I9 perovskite for photocatalytic hydrogen generation. ACS Sustain. Chem. Eng. 7, 15080–15085 (2019). 

19. Chen, G. Q. et al. Lead-free halide perovskite Cs3Bi2xSb2-2xI9(x ≈ 0.3) possessing the photocatalytic activity for hydrogen evolution comparable to that of (CH3NH3)PbI3. Adv. Mater. 32, 2001344 (2020). 

20. Wu, Y. et al. Composite of CH3NH3PbI3 with reduced graphene oxide as a highly efficient and stable visible-light photocatalyst for hydrogen evolution in aqueous HI solution. Adv. Mater. 30, 1704342 (2018). 

21. Wang, T., Yue, D., Li, X. & Zhao, Y. Lead-free double perovskite Cs2AgBiBr6/ RGO composite for efficient visible light photocatalytic H2 evolution. Appl. Catal. B: Environ. 268, 118399 (2020). 

22. Li, R. et al. Few-layer black phosphorus-on-MAPbI3 for superb visible-light photocatalytic hydrogen evolution from HI splitting. Appl. Catal. B-Environ. 259, 118075 (2019). 

23. Wang, F., Liu, X., Zhang, Z. & Min, S. A noble-metal-free MoS2 nanosheetcoupled MAPbI3 photocatalyst for efficient and stable visible-light-driven hydrogen evolution. Chem. Commun. 56, 3281–3284 (2020). 

24. Zhao, X. L. et al. Perovskite microcrystals with intercalated monolayer MoS2 nanosheets as advanced photocatalyst for solar-powered hydrogen generation. Matter 3, 935–949 (2020). 

25. Park, S. et al. Photocatalytic hydrogen generation from hydriodic acid using methylammonium lead iodide in dynamic equilibrium with aqueous solution. Nat. Energy 2, 16185 (2016). 

26. Liao, W. Q. et al. Lead-free inverted planar formamidinium tin triiodide perovskite solar cells achieving power conversion efficiencies up to 6.22%. Adv. Mater. 28, 9333–9340 (2016). 

27. Yang, B. et al. Lead-free, air-stable all-inorganic cesium bismuth halide perovskite nanocrystals. Angew. Chem. Int. Ed. 56, 12471–12475 (2017). 

28. Chen, M. et al. Cesium titanium(IV) bromide thin films based stable lead-free perovskite solar cells. Joule 2, 558–570 (2018). 

29. Jellicoe, T. C. et al. Synthesis and optical properties of lead-free cesium tin halide perovskite nanocrystals. J. Am. Chem. Soc. 138, 2941–2944 (2016). 

30. Hao, F., Stoumpos, C. C., Cao, D. H., Chang, R. P. H. & Kanatzidis, M. G. Lead-free solid-state organic-inorganic halide perovskite solar cells. Nat. Photonics 8, 489–494 (2014). 

31. Shin, H. et al. Surface state-mediated charge transfer of Cs2SnI6 and its application in dye-sensitized solar cells. Adv. Energy Mater. 9, 1803243 (2019). 

32. Kapil, G. et al. Investigation of interfacial charge transfer in solution processed Cs2SnI6 thin films. J. Phys. Chem. C. 121, 13092–13100 (2017). 

33. Lee, B. et al. Air-stable molecular semiconducting iodosalts for solar cell applications: Cs2SnI6 as a hole conductor. J. Am. Chem. Soc. 136, 15379–15385 (2014). 

34. Wang, X. D. et al. In situ construction of a Cs2SnI6 perovskite nanocrystal/ SnS2 nanosheet heterojunction with boosted interfacial charge transfer. J. Am. Chem. Soc. 141, 13434–13441 (2019). 

41. Chen, H. et al. Efficient bifacial passivation with crosslinked thioctic acid for high-performance methylammonium lead iodide perovskite solar cells. Adv. Mater. 32, 1905661 (2020). 

42. Zhou, P. et al. Strengthening reactive metal-support interaction to stabilize high-density Pt single atoms on electron-deficient g-C3N4 for boosting photocatalytic H2 production. Nano Energy 56, 127–137 (2019). 

43. Selcuk, S. & Selloni, A. Facet-dependent trapping and dynamics of excess electrons at anatase TiO2 surfaces and aqueous interfaces. Nat. Mater. 15, 1107–1112 (2016). 

44. Nørskov, J. K. et al. Origin of the overpotential for oxygen reduction at a fuelcell cathode. J. Phys. Chem. B 108, 17886–17892 (2004). 

### Acknowledgements 

The authors are grateful for the financial supports of this work from the National Natural Science Fund for Distinguished Young Scholars (52025133), the Tencent Foundation through the XPLORER PRIZE, the Beijing Natural Science Foundation (JQ18005), the National Natural Science Foundation of China (22002003), the Fund of the State Key Laboratory of Solidification Processing in NWPU (SKLSP202004), and the China Postdoctoral Science Foundation (2019TQ0001 and 2020M670020). The authors also thank TianHe-2 of LvLiang Cloud Computing Center of China for theoretical calculations. 

### Author contributions 

S.G. conceived the project. P.Z., H.C., and Y.C. designed and performed the experiments. P.Z. carried out the DFT calculations and analysis. P.Z., H.C., Y.C., and F.L. conducted the XAFS characterization and corresponding data analysis. Q. Zhang and L.G. assisted with taking HAADF-STEM images. Q. Zhao, N.W., J.W., W.Z., and S.G. conducted data analyses and discussions. P.Z., H.C., and S.G. co-wrote the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-24702-8. 

Correspondence and requests for materials should be addressed to S.G. 

Peer review information Nature Communications thanks Huajie Yin, Xu Zong, and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

35. Han, X. et al. Lead-free double perovskite Cs2SnX6: facile solution synthesis and excellent stability. Small 15, 1901650 (2019). 

36. Liu, Y. et al. 2H- and 1T- mixed phase few-layer MoS2 as a superior to Pt cocatalyst coated on TiO2 nanorod arrays for photocatalytic hydrogen evolution. Appl. Catal. B: Environ. 241, 236–245 (2019). 

37. Yu, J. G., Qi, L. F. & Jaroniec, M. Hydrogen production by photocatalytic water splitting over Pt/TiO2 nanosheets with exposed (001) facets. J. Phys. Chem. C. 114, 13118–13125 (2010). 

38. Shiraishi, Y., Ueda, Y., Soramoto, A., Hinokuma, S. & Hirai, T. Photocatalytic hydrogen peroxide splitting on metal-free powders assisted by phosphoric acid as a stabilizer. Nat. Commun. 11, 3386 (2020). 

39. Wolff, C. M. et al. All-in-one visible-light-driven water splitting by combining nanoparticulate and molecular co-catalysts on CdS nanorods. Nat. Energy 3, 862–869 (2018). 

40. Chen, S. S., Takata, T. & Domen, K. Particulate photocatalysts for overall water splitting. Nat. Rev. Mater. 2, 17050 (2017). 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

8 

NATURE COMMUNICATIONS | (2021) 12:4412 | https://doi.org/10.1038/s41467-021-24702-8 | www.nature.com/naturecommunications 

