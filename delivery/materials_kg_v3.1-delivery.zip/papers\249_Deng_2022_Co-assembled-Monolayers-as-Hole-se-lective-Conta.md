# Co-assembled Monolayers as Hole -se lective Contact for High-Performance Inverted Perovskite Solar Cells with Optimized Recombination Loss and Long-Term Stability.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Angewandte Chemie |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 231 |
| 作者 | Xiang Deng, Feng-Xiao Qi, Fengzhu Li, Shengfan Wu, Francis R. Lin, Zhuomin Zhang, Zhi-Qiang Guan, Zheng-Bao Yang et al. |
| DOI | 10.1002/anie.202203088 |
| 源文件 | 037_Deng_2022_Co-assembled-Monolayers-as-Hole-se-lective-Conta.pdf |

---
**_Angewandte Chemie_** 

**_Research Articles_** 

www.angewandte.org 







## **_Solar Cells Hot Paper_** 

How to cite: _Angew. Chem. Int. Ed._ **2022,** _61,_ e202203088 International Edition: doi.org/10.1002/anie.202203088 German Edition: doi.org/10.1002/ange.202203088 

# **Co-assembled Monolayers as Hole-Selective Contact for HighPerformance Inverted Perovskite Solar Cells with Optimized Recombination Loss and Long-Term Stability** 

_Xiang Deng_<sup>_+_</sup> _, Feng Qi_<sup>_+_</sup> _, Fengzhu Li, Shengfan Wu, Francis R. Lin,* Zhuomin Zhang, Zhiqiang Guan, Zhengbao Yang, Chun-Sing Lee, and Alex K.-Y. Jen*_ 

### **_Introduction_** 

**Abstract:** Self-assembled monolayers (SAMs) have been widely employed as an effective way to modify interfaces of electronic/optoelectronic devices. To achieve a good control of the growth and molecular functionality of SAMs, we develop a co-assembled monolayer (coSAM) for obtaining efficient hole selection and suppressed recombination at the hole-selective interface in inverted perovskite solar cells (PSCs). By engineering the position of methoxy substituents, an aligned energy level and favorable dipole moment can be obtained in our newly synthesized SAM, ((2,7-dimethoxy-9 _H_ -carbazol-9-yl) methyl) phosphonic acid (DC-PA). An alkyl ammonium containing SAM is co-assembled to further optimize the surface functionalization and interaction with perovskite layer on top. A champion device with an excellent power conversion efficiency (PCE) of 23.59% and improved device stability are achieved. This work demonstrates the advantage of using co-SAM in improving performance and stability of PSCs. 

[*] X. Deng,<sup>+</sup> F. Qi,<sup>+</sup> F. Li, Dr. S. Wu, Prof. A. K.-Y. Jen Department of Materials Science and Engineering, City University of Hong Kong Kowloon 999077 (Hong Kong) E-mail: alexjen@cityu.edu.hk X. Deng,<sup>+</sup> F. Qi,<sup>+</sup> F. Li, Dr. F. R. Lin, Dr. Z. Guan, Prof. C.-S. Lee, Prof. A. K.-Y. Jen Department of Chemistry, City University of Hong Kong Kowloon 999077 (Hong Kong) E-mail: franclin@cityu.edu.hk 

Z. Zhang, Dr. Z. Yang 

Department of Mechanical Engineering, City University of Hong Kong Kowloon 999077 (Hong Kong) Prof. A. K.-Y. Jen 

Department of Materials Science & Engineering, University of Washington Seattle, WA 98195 (USA) 

X. Deng,<sup>+</sup> F. Qi,<sup>+</sup> F. Li, Dr. S. Wu, Dr. F. R. Lin, Prof. A. K.-Y. Jen Hong Kong Institute for Clean Energy, 

City University of Hong Kong Kowloon 999077 (Hong Kong) 

[<sup>+</sup> ] These authors contributed equally to this work. 

Self-assembled monolayers (SAMs) have garnered much attention as they can provide diverse functionalities in a molecular monolayer with few nanometers thickness on the substrates, as the reactivity between various types of anchoring groups and different substrates leads to a thermodynamically stable self-assembly.<sup>[1–3]</sup> To further introduce interactions with adjacent layer on top of SAMs, combinations of linkers and terminal groups can be manipulated to accomplish different functionalities, such as charge selection and transport,<sup>[4,5]</sup> interfacial energy level alignment,<sup>[2]</sup> crystallization templating and surface energy modification.<sup>[6]</sup> Since deposition of SAMs can be easily achieved by immersing substrates into the solution with very low material consumption, it is considered as a promising strategy for interfacial modification in scalable fabrication of large-area devices.<sup>[7]</sup> Thus, it has been widely adopted as an interfacial modifier in various organic electronic devices such as organic field-effect transistors (OFETs),<sup>[8–10]</sup> organic solar cells (OSCs)<sup>[2,11]</sup> and perovskite solar cells (PSCs).<sup>[12]</sup> 

In solution-processed PSCs with a device architecture of stacked layers, normally charge selection layers and coordinating agents for perovskites are deposited at the interface between the perovskite active layer and electrodes to minimize charge-transporting loss and prevent interfacial charge recombination.<sup>[13,14]</sup> Surprisingly, these functions can be achieved by the employment of SAMs where charges can hop through this ultrathin monolayer with minimum transporting loss. In the meantime, charge selective SAMs are likely to accomplish a “recombination-free” interface with perovskite.<sup>[7,15]</sup> As a successful precedent, C60-SAM was developed to modify the surface of TiO2 to reduce surface defects and assist electron extraction in n-i-p PSCs.<sup>[16]</sup> Since then, different electron-selective SAMs based on C60, naphthalene diimide, perylene diimide and other electronaccepting materials have been investigated.<sup>[17,18]</sup> 

Furthermore, Albrecht et al. made use of the carbazolebased hole-selective SAM system in silicon/perovskite tandem solar cells and reached an outstanding efficiency of 29.15%.<sup>[5]</sup> Through systematically studying the structureproperty-performance relationships, they stressed the importance of energy level alignment, alkyl linker length and molecular dipole orientation in the design of hole-selective SAMs.<sup>[5,7,15]</sup> Thereafter, significant efforts have been devoted to the engineering of charge selective SAMs<sup>[19]</sup> and their 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (1 of 8) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



applications,<sup>[20,21]</sup> which have achieved great success in highperformance photovoltaic devices. Due to the strong adhesion to substrates and well controllable molecular orientation, the functional groups on SAM can be engineered to introduce various dipoles and interactions with perovskite through ionic/electron coupling,<sup>[12,22,23]</sup> and help assist charge extraction and reduce interfacial recombination.<sup>[24]</sup> Moreover, photo-induced chemical reactions and ion migration leading to degraded device performance and stability can be prevented by using properly designed SAMs.<sup>[25,26]</sup> Incorporating iodo, ammonium, or other coordinative terminal groups have been demonstrated to improve the quality of the interface, thus significantly enhancing the stability of PSC devices.<sup>[12,27]</sup> 

Besides the molecular design of SAMs, precisely controlled SAM growth is also necessary in forming a densely packed monolayer with minimal defects.<sup>[8–12]</sup> The dynamics of monolayer growth can be briefly described in a two-stage manner: adsorption of molecules on the surface by forming covalent bonds, followed by rearrangement and reorientation to pack in a highly ordered manner which is forced by the free energy reduction.<sup>[28]</sup> A dense monolayer is critical for performance and stability of organic electronic devices because it can minimize the direct contact between active layer and electrode. Learned from the molecular design evolution of hole-selective SAMs for high-performance PSCs, SAMs with simple structures are beneficial for avoiding steric hinderance to ensure the formation of a densely packed monolayer.<sup>[5,7,29]</sup> 

However, due to the roughness of substrates and film deposition conditions, defects are unavoidable in these monolayers,<sup>[30]</sup> especially at the sites with no SAM coverage. These defects might induce leakage current at the interface and undermine the performance and stability of the optoelectronic devices.<sup>[31–33]</sup> To resolve this problem, an alkyl insulating filler molecule can be introduced to form a coassembled monolayer (co-SAM) with better coverage, leading to enhanced device performance and stability.<sup>[29]</sup> The co-SAMs can also form a multifunctional interface,<sup>[34]</sup> possessing highly tunable properties that could match the various needs for achieving high-performance PSCs. 

To achieve all the above-mentioned functions, we have designed a carbazole-based hole-selective SAM molecule, ((2,7-dimethoxy-9 _H_ -carbazol-9-yl) methyl) phosphonic acid (DC-PA), in which the 2,7-substituted methoxy groups help reduce the electron-donating strength,<sup>[35]</sup> leading to a downshifted highest occupied molecular orbital (HOMO) energy level and a larger molecular dipole. These synergistically ensure good energy level alignment with the valence band maximum (VBM) of the perovskite used in device for achieving minimum energy offset.<sup>[36]</sup> In order to minimize the defects in monolayer and simultaneously passivate the perovskite on top, an alkyl ammonium SAM, 6-(iodo-λ<sup>5</sup> - azanyl) hexanoic acid (IAHA) is used as the second component in the hole-selective SAM matrix. With this rationally designed co-SAM substrate, the inverted PSCs can reach high efficiency approaching 23.59% with improved device stability. This work demonstrates that the coSAM modified substates can contribute to efficient hole 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (2 of 8) 

selection, reduced interfacial recombination loss, and templated growth of perovskite to achieve highly efficient and stable PSCs. 

### **_Results and Discussion_** 

To deposit the co-SAM, a hole-selective SAM molecule, DC-PA is synthesized based on the synthetic route shown in Figure S1. Meanwhile, an alkyl ammonium salt, IAHA, is adopted to form co-SAM for improving the coverage of monolayer and passivating the perovskite on top. The molecular structures of DC-PA and IAHA are shown in Figure 1a. As demonstrated by Albrecht et al., carbazole is an effective hole-selective building block in designing SAM molecules.<sup>[5]</sup> According to the literature, the methoxy group can also work as an efficient coordination group with perovskite and improve the wettability of the substrate.<sup>[37]</sup> However, the methoxy groups at 3,6-positions are strongly electron-donating to carbazole, leading to a higher HOMO energy level and subsequently unfavorable energy level alignment with perovskite. The weak dipole of MeO-2PACz cannot work well in tuning the work function of ITO electrode. To mitigate these problems, we have changed the position of methoxy substituents to the 2,7-positions of carbazole. As shown in Figure S2, this leads to a lower-lying HOMO energy level of DC-PA from � 4.98 eV to � 5.08 eV, and its dipole is increased from 0.12 D to 1.64 D compared to MeO-2PACz. The effect of better energy level alignment and larger molecular dipole is illustrated by fabricating PSC devices with MeO-2PACz and DC-PA as hole-selective SAMs. As shown in Figure S3, the smaller energy offset between DC-PA and perovskite helps reduce the energy loss to result in a higher _V_ oc. Cyclic voltammetry (CV) was conducted to determine the energy levels (Figure S4) for DC-PA. The HOMO energy level is determined to be � 5.38 eV, which enables better energy level alignment with the VBM of perovskite (� 5.82 eV) than MeO-2PACz, suggesting efficient hole extraction can be achieved from perovskite to DC-PA. Similarly, the lowest unoccupied molecular orbital (LUMO) energy level of DC-PA is calculated to be � 2.11 eV with its band gap of 3.27 eV (obtained from UV/Vis absorption profile, Figure S5), which is much higher than the conduction band minimum (CBM) of perovskite for blocking electrons. 

Besides realizing efficient charge extraction, the charge recombination can also be suppressed by the co-assembly with the ammonium SAM. Carboxylic group is chosen as the anchor because it possesses weaker acidity than phosphonic acid. Therefore, the phosphonic acid based holeselective SAM is more robust to anchor on the substrate and will not be replaced by the ammonium SAM. The linker is a linear alkyl chain with five-carbon length having sufficient flexibility and small steric hindrance, which can avoid interfering with the anchored DC-PA SAM. More importantly, the ammonium terminal group on top can coordinate with perovskite through ionic interaction to passivate the bottom surface.<sup>[38–40]</sup> The overall molecular length of IAHA is about 1 nm, which is slightly longer than that of DC-PA ( 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 1._** Co-SAM deposition. a) Molecular structures of DC-PA and IAHA. b) Schematic diagram for co-assemble monolayer fabrication. c), d) UPS spectra (using the He� I lamp with a photon energy of 21.22 eV) of DC-PA and DC-PA/IAHA substrates. e) Schematic diagram of energy level alignment. 

� 8 Å), to ensure that the ammonium group can be exposed for interacting with perovskite (Table S1). 

As shown in Figure 1b, the co-SAM is deposited by spincoating the mixed solution of DC-PA and IAHA onto ITO substrates. Simply after the acid-base reaction, SAM molecules anchor on the substrate by forming a monodentate or bidentate covalent bonds.<sup>[41]</sup> The physically absorbed molecules can be removed by a washing step. It is noted that the ratio of DC-PA SAM and ammonium SAM should be adjusted carefully because overdose of ammonium SAM will inevitably affect hole extraction, and its molecular dipole pointing towards perovskite is theoretically less favorable for the modification of the ITO work function. Therefore, the ratio of co-SAM was optimized by characterizing their surface potential through Kelvin probe force microscopy (KPFM) (Figure S6). The contact potential difference (CPD) indicates fermi levels of co-SAM-modified substrates become shallower with the increasing ratios of IAHA. When the ratio of DC-PA and IAHA reaches 4:6, the surface potential is close to that of pure IAHA film, which can’t effectively minimize the energy offset. The energy levels of co-SAM were also characterized with ultraviolet photoelectron spectrometry (UPS). As shown in Figure 1c– e, the HOMO energy level of DC-PA-modified ITO surface is � 5.32 eV, which is slightly higher than that determined by CV measurement. Once IAHA is introduced, the HOMO energy level is downshifted to � 5.37 eV, which is in good alignment with perovskite to reduce energy offset. This is potentially originated from the varied molecular packing modes of DC-PA in the co-SAM.<sup>[42]</sup> As the molecular dipole of IAHA (points from ITO to perovskite) may down-shift the vacuum level, the Fermi level ( _E_ f) of co-SAM-modified ITO is 50 meV higher than that only treated with DC-PA. Although the difference may be within the error bar of UPS 

measurements (about 0.1 eV), it can be qualitatively concluded from the KPFM results that co-SAM with IAHA could fine-tune the energy level of substrates. Overall, the co-SAM-modified substrates show better energy level alignment, which is beneficial for hole-selection at the interface. 

The best device performance can be achieved when the ratio of DC-PA and IAHA is tuned to be 6:4, which is used as an optimized ratio for studies conducted throughout this work. Due to the acidity difference between anchoring groups, the composition of final co-assembled film might not be exactly the same as that in solution phase. Hence, to accurately determine the composition of co-SAM on ITO, X-ray photoelectron spectrometry (XPS) is conducted. Based on the results presented in Figure 2a–c, both DC-PA and IAHA can be identified to successfully anchor onto the substrates from the C1s characterized peak of co-assembled film, i.e., the C� P and O� C=O peaks located at binding energy of 286.3 eV and 289.0 eV, respectively.<sup>[29]</sup> Moreover, by integrating the peak area of the C1s peaks, the ratio between DC-PA and IAHA is approximately calculated to be 7:3, which slightly deviates from that in solution. 

As the introduction of IAHA in DC-PA SAM may have influence on the properties of the interfaces, contact angles are also measured to investigate their coverage and surface energy. As shown in Figure 2d, the substrates modified with IAHA, DC-PA and DC-PA/IAHA co-SAM exhibit contact angles of 32.5°, 47.6° and 62.2°, respectively. In comparison, the neat ITO substrate shows significantly smaller contact angle (Figure S7a) due to the hydroxyl- and epoxy-rich surface. Therefore, the anchoring of SAM molecules contributes to a more hydrophobic surface. The larger contact angle of DC-PA than IAHA is due to its denser coverage caused by the higher reactivity of phosphonic acid towards hydroxyl/epoxy groups on the ITO surface,<sup>[41]</sup> together with 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (3 of 8) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 2._** Properties of co-SAM. High-resolution XPS spectra of C1s for films of a) DC-PA and b) DC-PA/IAHA monolayer films, respectively. c) Ratio of C� P and O� C=O bonds extracted from high-resolution XPS spectra. d) Contact angles of ITO, DC-PA and DC-PA/IAHA substrates. 

a more hydrophilic surface induced by the ammonium groups on IAHA. It is found that the co-SAM-treated ITO substrate leads to an even larger contact angle, which can be attributed to the better coverage of co-SAM that isolates the highly hydrophilic ITO surface from the water droplet. The more hydroscopic surface of co-SAM is also confirmed by the larger contact angle measured with perovskite precursor (Figure S7b). In this case, the co-SAM can effectively prevent direct contact between perovskite and ITO substrate, thus contributing to larger shunt resistance and smaller current leakage in the resulting PSC devices. 

Since the buried interface plays an important role in the perovskite crystallization dynamics and the ammonium terminal groups in our co-SAM can coordinate with perovskite lattice, the morphologies and structural properties of the perovskite films grown on different substrates were also investigated. The film morphologies are characterized by atomic force microscopy (AFM) and scanning electron microscope (SEM) as shown in Figure 3a,b. The perovskite grown on co-SAM exhibits a lower surface roughness of 13.9 nm than that of DC-PA (16.7 nm), implying a more homogeneous crystallization surface. In addition, the larger perovskite crystals are observed for coSAM-based perovskite films in the SEM image while the less conductive phase (i.e., the shiny solid) could be ascribed to excess PbI2 used in perovskite precursor. 

The structural properties of perovskite films were further characterized by X-ray diffraction (XRD) and the diffraction patterns are recorded in Figure 3c. The perovskite film grown on co-SAM displays a lower PbI2 diffraction intensity and a stronger (110) crystal face diffraction, which is consistent with those observed in the SEM studies. In this case, the less PbI2 can be attributed to the coordination between the ammonium terminal groups with excess PbI2 in perovskite, which further validates our assumption that the ammonium SAM can interact with upper perovskite layer. 

By fitting the (110) characterized peaks, the full width at half maximum (FWHM) of the peaks were obtained to be 0.05 and 0.06 for co-SAM and DC-PA-based perovskite, respectively. This confirms the templating effect of ammonium SAM for the as-grown perovskite with improved crystallinity. Additionally, the reduced peak intensity of (312) crystal face at 35 degree suggests the preferred crystal orientation that is beneficial for charge transport. To study the carrier transport dynamics at the ITO/perovskite interface, steady-state photoluminescence (PL) intensity and time-resolved PL (TRPL) were carried out. As shown in Figure 3d,e, DC-PA-based perovskite film shows a quite strong PL intensity and long PL lifetime (3402.40 ns), which agrees well with previous studies based on hole-selective SAMs.<sup>[5]</sup> After the introduction of the ammonium SAM, the perovskite film shows even higher PL intensity and longer PL lifetime (increased to 4782.88 ns), indicting less-defect and suppressed non-radiative recombination at the interface (Table S2).<sup>[24,43]</sup> 

Based on these encouraging results, the co-SAM functionalized substrates are incorporated for hole-collection in inverted PSC devices with the configuration of ITO/coSAM/ perovskite/C60/BCP/Ag. A sequential ratio of DC-PA: IAHA in solution are deposited on ITO substrates and their device performance is recorded in Figure 4a–c. As the proportion of IAHA increases, the performance is improved and reaches the highest PCE at the ratio of 6:4. Further increase of the IAHA ratio will lead to a drop of fill factor ( _FF_ ) (Figure S8) and PCE because of its relatively poor ability for hole-extraction. With co-SAM used as the HSL, the average open circuit voltage ( _V_ oc) is improved from 1.04 eV to 1.09 eV, with a reduced voltage loss of 50 meV, which contributes to the enhanced average PCE from 19.86% to 20.62%. The co-SAM strategy is also applied to the commercially available MeO-2PACz. As shown in Figure S9 and Table S3, while incorporating MeO-2PACz/ 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (4 of 8) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 3._** Characterization of perovskite films. a) AFM images, b) SEM images of perovskite films deposited on DC-PA and DC-PA/IAHA substrates. c) The XRD patterns (inset is the fitting (110) peaks), d) PL spectra and e) TRPL spectra of perovskite films deposited on DC-PA and DC-PA/IAHA substrates. The direction of incident light comes from the perovskite side. 



**_Figure 4._** Device performance. a) _J_ – _V_ curves, box plots of the photovoltaic parameters b) _V_ oc and c) PCE of the perovskite solar cells with coassemble substrates of different ratio of DC-PA and IAHA. d) _J_ – _V_ curves, e) EQE and f) Steady-state power output at the MPP of the champion device based on co-assemble monolayer substrate. 

IAHA as the hole selective interface, the devices demonstrate an average _V_ oc improvement of 38 meV compared to pristine MeO-2PACz, which further demonstrates the universal applicability of co-SAM in enhancing device performance. 

To verify whether the photovoltage enhancement is originated from the bottom interface passivation effect of ammonium terminal groups in IAHA, hexanoic acid (ACH) 

without ammonium terminal groups is used to replace IAHA in the devices. As shown in Figure S10, the co-SAM with ACH leads to much lower _V_ oc, clearly proving the dominant role of ammonium terminal groups in passivating the defect at the bottom interface. The minor _V_ oc enhancement for ACH based co-SAM can be merely attributed to better coverage of co-SAM that impedes the shunt path at the interface. While for IAHA based co-SAM, 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (5 of 8) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



the significantly higher _V_ oc is originated from the combined passivation effect of ammonium terminal groups and better coverage. To exploit the full potential of the co-SAM-based substrates, top surface passivation and light management through anti-reflection coating are also applied. As shown in Figure 4d, the champion co-SAM-based device achieves a PCE of 23.59% with the _V_ oc, _J_ sc and _FF_ of 1.16 V, 24.66 mAcm<sup>�2</sup> and 82.45%, respectively, while the highest PCE of DC-PA based devices is 22.64% with the _V_ oc, _J_ sc and _FF_ of 1.13 V, 24.58 mAcm<sup>�2</sup> and 81.52%, respectively. To demonstrate the reliability of the device, external quantum efficiency (EQE) of the device is also measured for _J_ sc calibration, with the corresponding EQE curve displayed in Figure 4e. An integrated _J_ sc of 24.53 mAcm<sup>�2</sup> is obtained, which is consistent with the _J_ sc extracted from the _J–V_ curve. In addition, the stabilized power output (SPO) is tracked at the maximum power point (MPP), which shows a stabilized PCE of 23.04% (Figure 4f). 

The hole-selective SAMs were reported to be capable of stabilizing perovskite and enhancing device stability.<sup>[5]</sup> Therefore, the stability of our co-SAM-based PSCs is also evaluated under thermal stress at 65 °C in a nitrogen atmosphere (Figure S11). As expected, both SAM- and coSAM-based devices exhibit good thermal stability which is consistent with the previous reports.<sup>[5,7]</sup> Notably, the coSAM-based devices could maintain even better long-term thermal stability than that of DC-PA based devices, which could retain 97% of its highest PCE after being aged for 450 h. As shown in Figure S12, both the _J–V_ curves and statistical hysteresis index ( _HI_ ) indicate slightly larger hysteresis is caused in DC-PA based devices after the aging due to the thermal degradation of devices. 

The improved device performance and stability have a strong correlation with defect nature of the modulated hole- 

selective interface and enhanced perovskite crystallinity. To probe the defect nature in the device, space-charge-limitedcurrent (SCLC) and light-dependent _V_ oc measurements were conducted. As shown in Figure 5a, the cross points of ohmic region and trap-filling region indicate the trap-filled limit voltage ( _V_ TFL), which are determined to be 0.24 V and 0.33 V for co-SAM and DC-PA based devices, respectively. According to the relationship of _nt_ / _V_ TFL, the trap density _nt_ is proportional to the _V_ TFL. Thus, the lower _V_ TFL indicates lower trap density in the PSC devices after the co-SAM functionalization on ITO. Given that the charge selection layer and the defect nature are highly influential to the ideality factor ( _n_ ) of the devices. By measuring the light intensity-dependent _V_ oc, the _n_ for co-SAM and DC-PA based devices can be calculated to be 1.18 and 1.27, respectively (Figure 5b). The smaller n value may stem from either faster charge extraction or lower recombination in device.<sup>[44,45]</sup> As illustrated from our TRPL results, the PL quenching is dominated by the recombination process and co-SAM leads to significantly reduced non-radiative recombination to prolong lifetime. Therefore, the smaller _n_ value of co-SAM-based device illustrates better suppressed Shockley-Read-Hall (SRH) recombination at the bottom surface, which can be attributed to the IAHA passivation effect.<sup>[46,47]</sup> 

Benefitted by the better energy alignment and passivated interface, the co-SAM-based device leads to a higher build-in potential of 0.77 V than that of 0.70 V for DC-PA based device, as measured by the capacitance-voltage curves (Figure 5c). Excluding the factor of fermi level, the enhanced build-in potential can be attributed to the better passivated interface with lower trap density, thus contributing to higher _V_ oc. 

Defects, including point defect, line defect, and face defect etc., usually account for mobile ions because they will 



**_Figure 5._** Defect nature in PSC devices. a) SCLC, b) light intensity dependence of _V_ oc, c) C� V curves, d) C� F curves, e) dark _J_ – _V_ curves, f) series and shunt resistance of perovskite solar cells with different substrates. 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (6 of 8) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



introduce additional strain in perovskite lattice that further reduce the activation energy for ion migration. To have a better understanding of the effect of co-SAM on modulating defects, capacitance-frequency (C–F) curves were measured and recorded (Figure 5d). A lower capacitance is observed in co-SAM-based devices at the low frequency _<_ 10<sup>3</sup> s<sup>�1</sup> region, which also indicates less defects in the co-SAMbased devices. As mentioned above, the better coverage of co-SAM reduces the contact between perovskite and ITO electrode, which should result in lower leakage current and enhanced recombination resistance. The dark current and shunt resistance of devices based on different substrates are analyzed in Figure 5e and f, which show lower leakage current and larger shunt resistance for co-SAM-based device while both substates have similar series resistance (boxplot of shunt resistances is provided in Figure S13a). To further characterize the charge transfer in the devices, recombination resistance ( _R_ rec) is also fitted from the impedance curves shown in Figure S13b. The larger arc at low-frequency region indicates a larger _R_ rec for the co-SAM-based devices.<sup>[48]</sup> Through the device characterization, it can be concluded that a high-quality co-SAM and perovskite layer with optimized interfacial connection can be realized by tuning the functional groups and self-assembly conditions in co-SAM, leading to suppressed charge recombination and improved device performance and stability. 

### **_Conclusion_** 

Through the rational molecular design, the DC-PA SAM molecule with reduced HOMO energy level and desirable dipole moment is synthesized to ensure good energy alignment with perovskite. More importantly, by adopting a coSAM strategy and delicately tuning their ratio (i.e., DC-PA: IAHA), the anchor strength and packing density of co-SAM on ITO surface are successfully modulated, affording the multifunctional co-SAM with excellent film coverage and good passivation effect for the perovskite on top. As a result, the champion device of co-SAM-based PSCs achieves a PCE of 23.59% with improved device stability for the inverted PSCs. This work can serve as important supplement to bottom surface passivation of perovskite film where hole extraction and surface passivation can be simultaneously realized with a co-SAM. In addition, we demonstrate that more functionalities can be introduced through the coassembly of two or more components or combining multiple functional groups on the same molecules to explore further advancements in the PSC development. 

### **_Acknowledgements_** 

A.K.Y.J. thanks the sponsorship of the Lee Shau-Kee Chair Professor (Materials Science), and the support from the APRC Grant of the City University of Hong Kong (9380086), Innovation and Technology Fund (GHP/018/ 20SZ), the GRF grant (11307621) from the Research Grants Council of Hong Kong, Guangdong Major Project of Basic 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (7 of 8) 

and Applied Basic Research (2019B030302007), Guangdong-Hong Kong-Macao Joint Laboratory of Optoelectronic and Magnetic Functional Materials (2019B121205002). 

### **_Conflict of Interest_** 

The authors declare no conflict of interest. 

**Keywords:** Hole Selective Layer **·** Interfaces **·** Perovskites **·** Self-Assembled Monolayer **·** Solar Cells 

- [1] M. Kim, J. N. Hohman, Y. Cao, K. N. Houk, H. Ma, A. K.-Y. Jen, P. S. Weiss, _Science_ **2011** , _331_ , 1312. 

- [2] H.-L. Yip, S. K. Hau, N. S. Baek, H. Ma, A. K.-Y. Jen, _Adv. Mater._ **2008** , _20_ , 2376. 

- [3] O. Acton, D. Hutchins, L. Árnadóttir, T. Weidner, N. Cernetic, G. G. Ting, T.-W. Kim, D. G. Castner, H. Ma, A. K.-Y. Jen, _Adv. Mater._ **2011** , _23_ , 1899. 

- [4] K. Wojciechowski, S. D. Stranks, A. Abate, G. Sadoughi, A. Sadhanala, N. Kopidakis, G. Rumbles, C.-Z. Li, R. H. Friend, A. K. Y. Jen, H. J. Snaith, _ACS Nano_ **2014** , _8_ , 12701. 

- [5] A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. Morales Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matič, B. Rech, R. Schlatmann, M. Topič, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science_ **2020** , _370_ , 1300. 

- [6] J. S. Kim, J. H. Park, J. H. Lee, J. Jo, D.-Y. Kim, K. Cho, _Appl. Phys. Lett._ **2007** , _91_ , 112111. 

- [7] A. Al-Ashouri, A. Magomedov, M. Roß, M. Jošt, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Márquez, E. Köhnen, E. Kasparavičius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356. 

- [8] M. Halik, H. Klauk, U. Zschieschang, G. Schmid, C. Dehm, M. Schütz, S. Maisch, F. Effenberger, M. Brunnbauer, F. Stellacci, _Nature_ **2004** , _431_ , 963. 

- [9] D. J. Gundlach, J. E. Royer, S. K. Park, S. Subramanian, O. D. Jurchescu, B. H. Hamadani, A. J. Moad, R. J. Kline, L. C. Teague, O. Kirillov, C. A. Richter, J. G. Kushmerick, L. J. Richter, S. R. Parkin, T. N. Jackson, J. E. Anthony, _Nat. Mater._ **2008** , _7_ , 216. 

- [10] H. Ma, O. Acton, G. Ting, J. W. Ka, H.-L. Yip, N. Tucker, R. Schofield, A. K.-Y. Jen, _Appl. Phys. Lett._ **2008** , _92_ , 113303. 

- [11] Y. Lin, Y. Firdaus, F. H. Isikgor, M. I. Nugraha, E. Yengel, G. T. Harrison, R. Hallani, A. El-Labban, H. Faber, C. Ma, X. Zheng, A. Subbiah, C. T. Howells, O. M. Bakr, I. McCulloch, S. D. Wolf, L. Tsetseris, T. D. Anthopoulos, _ACS Energy Lett._ **2020** , _5_ , 2935. 

- [12] Z. Dai, S. K. Yadavalli, M. Chen, A. Abbaspourtamijani, Y. Qi, N. P. Padture, _Science_ **2021** , _372_ , 618. 

- [13] D. Zhao, Z. Zhu, M.-Y. Kuo, C.-C. Chueh, A. K.-Y. Jen, _Angew. Chem. Int. Ed._ **2016** , _55_ , 8999; _Angew. Chem._ **2016** , _128_ , 9145. 

- [14] S. Wu, Z. Li, J. Zhang, X. Wu, X. Deng, Y. Liu, J. Zhou, C. Zhi, X. Yu, W. C. H. Choy, Z. Zhu, A. K.-Y. Jen, _Adv. Mater._ **2021** , _33_ , 2105539. 

- [15] I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, A. Drevilkauskaite, V. Getautis, D. Menzel, K. 

   - © 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



   - Hinrichs, T. Unold, S. Albrecht, T. Dittrich, _Joule_ **2021** , _5_ , 2915. 

- [16] A. Abrusci, S. D. Stranks, P. Docampo, H.-L. Yip, A. K. Y. Jen, H. J. Snaith, _Nano Lett._ **2013** , _13_ , 3124. 

- [17] L. Li, Y. Wu, E. Li, C. Shen, H. Zhang, X. Xu, G. Wu, M. Cai, W.-H. Zhu, _Chem. Commun._ **2019** , _55_ , 13239. 

- [18] K. Liu, S. Chen, J. Wu, H. Zhang, M. Qin, X. Lu, Y. Tu, Q. Meng, X. Zhan, _Energy Environ. Sci._ **2018** , _11_ , 3463. 

- [19] E. J. Cassella, E. L. K. Spooner, T. Thornber, M. E. O’Kane, T. E. Catley, J. E. Bishop, J. A. Smith, O. S. Game, D. G. Lidzey, _Adv. Sci._ **2022** , _9_ , 2104848. 

- [20] Y. Lin, A. Magomedov, Y. Firdaus, D. Kaltsas, A. El-Labban, H. Faber, D. R. Naphade, E. Yengel, X. Zheng, E. Yarali, N. Chaturvedi, K. Loganathan, D. Gkeka, S. H. AlShammari, O. M. Bakr, F. Laquai, L. Tsetseris, V. Getautis, T. D. Anthopoulos, _ChemSusChem_ **2021** , _14_ , 3569. 

- [21] W. Peng, Y. Lin, S. Y. Jeong, Z. Genene, A. Magomedov, H. Y. Woo, C. Chen, W. Wahyudi, Q. Tao, J. Deng, Y. Han, V. Getautis, W. Zhu, T. D. Anthopoulos, E. Wang, _Nano Energy_ **2022** , _92_ , 106681. 

- [22] L. Zuo, Z. Gu, T. Ye, W. Fu, G. Wu, H. Li, H. Chen, _J. Am. Chem. Soc._ **2015** , _137_ , 2674. 

- [23] K. Choi, J. Lee, H. I. Kim, C. W. Park, G.-W. Kim, H. Choi, S. Park, S. A. Park, T. Park, _Energy Environ. Sci._ **2018** , _11_ , 3238. 

- [24] S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K. Y. Jen, _Joule_ **2020** , _4_ , 1248. 

- [25] S. G. Motti, D. Meggiolaro, A. J. Barker, E. Mosconi, C. A. R. Perini, J. M. Ball, M. Gandini, M. Kim, F. De Angelis, A. Petrozza, _Nat. Photonics_ **2019** , _13_ , 532. 

- [26] S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, _Nature_ **2019** , _571_ , 245. 

- [27] X. Deng, F. Li, Q. Wang, D. Liu, F. Lin, D. Shen, D. Lei, Y.-K. Peng, Z. Zhu, A. K. Y. Jen, _Matter_ **2021** , _4_ , 3301. 

- [28] A. Ulman, _Chem. Rev._ **1996** , _96_ , 1533. 

- [29] A. Magomedov, A. Al-Ashouri, E. Kasparavičius, S. Strazdaite, G. Niaura, M. Jošt, T. Malinauskas, S. Albrecht, V. Getautis, _Adv. Energy Mater._ **2018** , _8_ , 1801892. 

   - [33] L. Yuan, L. Jiang, D. Thompson, C. A. Nijhuis, _J. Am. Chem. Soc._ **2014** , _136_ , 6554. 

   - [34] Y. Hou, S. Scheiner, X. Tang, N. Gasparini, M. Richter, N. Li, P. Schweizer, S. Chen, H. Chen, C. O. R. Quiroz, X. Du, G. J. Matt, A. Osvet, E. Spiecker, R. H. Fink, A. Hirsch, M. Halik, C. J. Brabec, _Adv. Mater. Interfaces_ **2017** , _4_ , 1700007. 

   - [35] N. J. Jeon, H. G. Lee, Y. C. Kim, J. Seo, J. H. Noh, J. Lee, S. I. Seok, _J. Am. Chem. Soc._ **2014** , _136_ , 7837. 

   - [36] C. Goh, S. R. Scully, M. D. McGehee, _J. Appl. Phys._ **2007** , _101_ , 114503. 

   - [37] A. Torres, L. G. C. Rego, _J. Phys. Chem. C_ **2014** , _118_ , 26947. 

   - [38] J. Chen, X. Zhao, S.-G. Kim, N.-G. Park, _Adv. Mater._ **2019** , _31_ , 1902902. 

   - [39] L. Zuo, Q. Chen, N. De Marco, Y.-T. Hsieh, H. Chen, P. Sun, S.-Y. Chang, H. Zhao, S. Dong, Y. Yang, _Nano Lett._ **2017** , _17_ , 269. 

   - [40] X. Zheng, B. Chen, J. Dai, Y. Fang, Y. Bai, Y. Lin, H. Wei, X. C. Zeng, J. Huang, _Nat. Energy_ **2017** , _2_ , 17102. 

   - [41] J. A. Bardecker, H. Ma, T. Kim, F. Huang, M. S. Liu, Y.-J. Cheng, G. Ting, A. K.-Y. Jen, _Adv. Funct. Mater._ **2008** , _18_ , 3964. 

   - [42] J. Hoche, H.-C. Schmitt, A. Humeniuk, I. Fischer, R. Mitrić, M. I. S. Röhr, _Phys. Chem. Chem. Phys._ **2017** , _19_ , 25002. 

   - [43] F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S.-H. Jang, J. Zhang, X. Lu, D. Lei, C.-S. Lee, Z. Zhu, A. K. Y. Jen, _J. Am. Chem. Soc._ **2020** , _142_ , 20134. 

   - [44] C. M. Wolff, P. Caprioglio, M. Stolterfoht, D. Neher, _Adv. Mater._ **2019** , _31_ , 1902762. 

   - [45] V. Sarritzu, N. Sestu, D. Marongiu, X. Chang, S. Masi, A. Rizzo, S. Colella, F. Quochi, M. Saba, A. Mura, G. Bongiovanni, _Sci. Rep._ **2017** , _7_ , 44629. 

   - [46] W. Tress, M. Yavari, K. Domanski, P. Yadav, B. Niesen, J. P. Correa Baena, A. Hagfeldt, M. Graetzel, _Energy Environ. Sci._ **2018** , _11_ , 151. 

   - [47] K. W. Kemp, A. J. Labelle, S. M. Thon, A. H. Ip, I. J. Kramer, S. Hoogland, E. H. Sargent, _Adv. Energy Mater._ **2013** , _3_ , 917. 

   - [48] Z. Wei, H. Chen, K. Yan, S. Yang, _Angew. Chem. Int. Ed._ **2014** , _53_ , 13239; _Angew. Chem._ **2014** , _126_ , 13455. 

- [30] M. T. Cygan, T. D. Dunbar, J. J. Arnold, L. A. Bumm, N. F. Shedlock, T. P. Burgin, L. Jones, D. L. Allara, J. M. Tour, P. S. Weiss, _J. Am. Chem. Soc._ **1998** , _120_ , 2721. 

- [31] F. C. Simeone, H. J. Yoon, M. M. Thuo, J. R. Barber, B. Smith, G. M. Whitesides, _J. Am. Chem. Soc._ **2013** , _135_ , 18131. 

- [32] E. A. Weiss, R. C. Chiechi, G. K. Kaufman, J. K. Kriebel, Z. Li, M. Duati, M. A. Rampi, G. M. Whitesides, _J. Am. Chem. Soc._ **2007** , _129_ , 4336. 

Manuscript received: February 26, 2022 Accepted manuscript online: May 12, 2022 Version of record online: June 9, 2022 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088 (8 of 8) 

© 2022 Wiley-VCH GmbH 

