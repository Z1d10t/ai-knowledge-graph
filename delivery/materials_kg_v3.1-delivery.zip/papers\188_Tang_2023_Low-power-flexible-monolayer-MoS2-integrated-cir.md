# Low power flexible monolayer MoS2 integrated circuits

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 167 |
| 作者 | Jian Tang, Qinqin Wang, Jinpeng Tian, Xiaomei Li, Na Li, Yalin Peng, Xiuzhen Li, Yan-Chong Zhao et al. |
| DOI | 10.1038/s41467-023-39390-9 |
| 源文件 | 088_Tang_2023_Low-power-flexible-monolayer-MoS2-integrated-cir.pdf |

---
Article 



https://doi.org/10.1038/s41467-023-39390-9 

# Low power flexible monolayer MoS2 integrated circuits 

|Received: 12 December 2022<br>Accepted: 9 June 2023|Jian Tang<br>1,2,7, Qinqin Wang1,2,7, Jinpeng Tian1,2,7, Xiaomei Li1,2,3, Na Li1,4,<br>Yalin Peng<sup>1,2</sup>, Xiuzhen Li<sup>1,2</sup>, Yanchong Zhao<br>1,2, Congli He5, Shuyu Wu6,<br>Jiawei Li<sup>1,2</sup>, Yutuo Guo<sup>1,2</sup>, Biying Huang<sup>1,2</sup>, Yanbang Chu<sup>1,2</sup>, Yiru Ji<sup>1,2</sup>,|
|---|---|
|Check for updates|Dashan Shang<br>6, Luojun Du1,2, Rong Yang<br>1,4, Wei Yang<br>1,2,4,<br>Xuedong Bai<br>1,2, Dongxia Shi1,2& Guangyu Zhang<br>1,2,4|



Monolayer molybdenum disulfide (ML-MoS2) is an emergent two-dimensional (2D) semiconductor holding potential for flexible integrated circuits (ICs). The most important demands for the application of such ML-MoS2 ICs are low power consumption and high performance. However, these are currently challenging to satisfy due to limitations in the material quality and device fabrication technology. In this work, we develop an ultra-thin high-κ dielectric/ metal gate fabrication technique for the realization of thin film transistors based on high-quality wafer scale ML-MoS2 on both rigid and flexible substrates. The rigid devices can be operated in the deep-subthreshold regime with low power consumption and show negligible hysteresis, sharp subthreshold slope, high current density, and ultra-low leakage currents. Moreover, we realize fully functional large-scale flexible ICs operating at voltages below 1 V. Our process could represent a key step towards using energy-efficient flexible ML-MoS2 ICs in portable, wearable, and implantable electronics. 

Flexible electronics plays an integral role in a large spectrum of fields including information technology, energy generation and storage, biosensing, and diagnosis<sup>1–5</sup> . Among them, flexible integrated circuits (ICs) dealing with information processing are favorable in portable, wearable, and implantable electronics with technological demands towards flexibility and robustness of large-area devices<sup>6–8</sup> . Conventional flexible ICs are usually fabricated from organic semiconductors<sup>6,</sup> 8, silicon of either amorphous or polycrystalline forms9,10, oxide semiconductors<sup>11,12</sup> , and carbon nanotubes (CNTs)<sup>13–17</sup> via the thin-filmtransistor (TFT) technology. Recently, the 2D semiconductor of monolayer MoS2 (ML-MoS2) emerged as an advanced channel material in large-area flexible TFTs<sup>18–26</sup> . In principle, such TFTs have great potential in both high performance and low-power applications, if considering the following merits. First, ML-MoS2 is atomically thin 

(only ~0.7 nm) and smooth yet mechanically strong (in-plane) and flexible (out-of-plane)<sup>1,27</sup> . Such a thin channel also offers benefits in ultra-scale devices where short channel effects would be the main concern<sup>28–30</sup> . Second, its 2H phase has a moderate band gap of ~2 eV, between thatof silicon(~1.1 eV) and indium gallium zinc oxide (~3.5 eV), hence can work with both low off-state and high on-state currents<sup>31,32</sup> . Third, it has high electrical quality and is available at wafer scale<sup>22,33–36</sup> . 

It has been shown that, at room temperature, rigid ML-MoS2 TFTs can feature high electron mobility (μ) of >100 cm<sup>2</sup> ·V<sup>−1</sup> ·s<sup>−1</sup> , high on/off ratio of >10<sup>8</sup> , low subthreshold swing (SS) approaching the thermionic limit of 60 mV·dec<sup>−1</sup> , and high on-current of ~1.1 mA·μm<sup>−1</sup> at a supply voltage of 1.5 V<sup>37–39</sup> . Hence, one might ask if such TFT technologies developed on rigid substrates could be transferred onto flexible substrates and be superior to existing flexible TFT technologies. Up to 

> 1Beijing National Laboratory for Condensed Matter Physics and Institute of Physics, Chinese Academy of Sciences, Beijing 100190, China. 2School of Physical Sciences, University of Chinese Academy of Sciences, Beijing 100190, China.<sup>3</sup> Shanghai Key Laboratory of Multidimensional Information Processing, East China Normal University, Shanghai, China.<sup>4</sup> Songshan Lake Materials Laboratory, Dongguan 523808, China.<sup>5</sup> Institute of Advanced Materials, Beijing Normal University, Beijing 100875, China.<sup>6</sup> Institute of Microelectronics, Chinese Academy of Sciences, Beijing 100029, China.<sup>7</sup> These authors contributed equally: Jian Tang, Qinqin Wang, Jinpeng Tian. e-mail: gyzhang@iphy.ac.cn 

Nature Communications |  (2023) 14:3633 

1 

Article 

https://doi.org/10.1038/s41467-023-39390-9 

now, large-scale flexible ML-MoS2 ICs with various fully functional units such as logic gates, inverters, and ring oscillators (ROs) have been demonstrated vividly<sup>23–25</sup> . However, limited by materials and fabrications, such large-area flexible ICs suffer from either low performances or high-power consumptions, and it is challenging to realize both in a synergic manner. 

In this work, we demonstrate the realization of low-power flexible ICs based on ML-MoS2. The technological advances of this work lay on both the newly developed high-quality ML-MoS2 wafers and the ultrathin high-κ dielectric/metal-gate technology. High-quality 4-inch wafer-scale ML-MoS2 films are epitaxially grown on sapphire via an oxygen-assisted chemical vapor deposition (CVD) approach we developed recently<sup>34</sup> . As-grown films are strictly monolayer, uniform across entire substrates, and have large domain sizes over 200 μm. Such high-quality materials offer a desirable choice for realizing largescale flexible ICs. Here, the flexible ICs are fabricated via a gate-first technology in which ultra-thin high-κ dielectrics are deposited on gate electrodes to achieve a record-low equivalent oxide thickness (EOT). Due to the enhanced gating efficiency, our ML-MoS2 flexible TFTs can work under operation voltages below 1 V. 

## Results 

Gate-first technology for ultra-thin high-κ dielectric deposition In a power-efficient system, transistors and circuits should ideally have a low-driving voltage which can be created by using high-capacitance dielectric layers for efficient electrostatic gating. We thus employed 

ultra-thin high-κ dielectrics of HfO2, a technique widely used in the present silicon-based high-performance and low-power electronics. Since ultra-thin high-κ dielectrics are very difficult to deposit on MoS2 due to the lack of surface dangling bonds<sup>40,41</sup> , we hence developed the high-κ dielectric/metal-gate technology, i.e. a gate-first technology, for ML-MoS2 TFTs. Figure 1a illustrates the device geometry with buried Ti-Au-Ti as the local back-gate electrode, ultra-thin HfO2 as the dielectric layer, ML-MoS2 as the channel, and Au as the source/drain electrodes. 

During the device gate-first fabrication process, buried-gate electrodes of Ti-Au-Ti (1-5-1 nm) were first deposited on a substrate (either rigid or flexible) by standard lithography and electron beam evaporation processes. Note that the top 1 nm-Ti layer after oxidation in O2 plasma serves as the seeding layer for following atomic layer deposition (ALD) of the high-κ dielectrics; while the bottom 1 nm-Ti layer acts as the adhesive layer between Au and substrate. Other than the deposition of the seeding layer for the subsequent HfO2 deposition on 2D materials like graphene<sup>42</sup> , our approach employs the seeding layer on metal gates which are more general and compatible with the semiconductor fabrication process. Before and after metal gate depositions, we performed oxygen plasma cleaning to remove the photoresist residues on side walls and top surface of patterns/metalgates introduced from the lithography process, as illustrated in Supplementary Fig. 1. With the help of this cleaning process, we can produce flat metal gates with clean surfaces and sharp boundaries. After ALD, the deposited HfO2 layers on metal gates are very uniform, as 



<!-- Start of picture text -->
L<br>a e f 150<br>W 20 10 2<br>S(Au) D(Au) 3 120<br>MoS2 10 0 HfO2 HfO2<br>15 5nm  10nm<br>90<br>HfO2 2 10 -2<br>Gate(Ti/Au/Ti) 10 60<br>HfO2<br>b 5 εε rr (10 nm) (5 nm) 1 10 -4 30nm Al2O3 30<br>HfO2 EOT (10 nm) 10 -6<br>EOT (5 nm) 0<br>0 0<br>Ti/Au/Ti 200 °C 150 °C 110 °C 0 5 10 15<br>Deposition temperature ∆ V g (V)<br>c g 1000 h 10 3<br>V g from 0 V to 5 V in 0.25 V step<br>Hf V ds=1 V<br>Au Ti 800 L ch≈50 nm 10 1<br>Ti<br>Si 600 100 nm 10 -1<br>d 10 -2 ∆ V g=11.5 mV<br>400 10 -3<br>Au/MoS2 interface<br>200 10 -5 0.07 0.08 0.09 0.10<br>I g<br>0 10 -7<br>0.0 0.3 0.6 0.9 1.2 1.5 0 1 2 3 4 5<br>V ds (V) V g (V)<br>I =75 mV/decSS<br>EOT (nm)<br>·(/) (μA) WLI ds ) (μA)·(ds/ ILW<br>Dielectric constant () ε r<br>-1 /W  (μA·μm) I ds -1 /W  (μA·μm)  II ()dsg,<br><!-- End of picture text -->

Fig. 1 | Characterizations of monolayer MoS2 thin-film-transistor (TFTs) on SiO2 substrates. a Schematic illustration of a buried-gate MoS2 TFT. b, c Cross-sectional scanning transmission electron microscope (STEM) image (b) of 5-nm HfO2 on the buried Ti-Au-Ti (1-5-1 nm) gate electrode, and corresponding energy disperse spectroscopy (EDS) elemental mapping image (c) clearly shows the distribution of Au, Ti, Hf and Si elements. Scale bars, 10 nm. d Atomic-resolution cross-sectional STEM image of Au-MoS2 contact interface. Red, yellow, and blue spheres are Au, Mo, and S atoms, respectively. Scale bar, 1 nm. e The dielectric constant and equivalent oxide thickness (EOT) of HfO2 layers deposited at different 

temperatures. f Normalized transfer curves of MoS2 TFTs (L = 5 μm, W = 40 μm) at Vds = 1 V with 5 nm, 10 nm HfO2 and 30 nm Al2O3 as the dielectric layer, individually. g, h Typical electrical output and transfer curves of MoS2 TFTs with Lch ≈ 50 nm and 5-nm HfO2 as the dielectric layer. Inset to (g) is the scanning electron microscope (SEM) image of the Lch ≈ 50 nm device. The Ids/W-Vg curve features with the sharp subthreshold swing (ISS = 75 mV·dec<sup>−1</sup> , refer to the black dash line) and small hysteresis (ΔVg = 11.5 mV, inset to h). The leakage current (Ig) is represented in gray color in (h). 

Nature Communications |  (2023) 14:3633 

2 

Article 

https://doi.org/10.1038/s41467-023-39390-9 

characterized by the atomic force microscope (AFM). The measured surface roughness of 5-nm HfO2 deposited on Ti/Au/Ti metal gates is typically <0.5 nm. After high-κ dielectric deposition, a 4''-wafer-sized ML-MoS2 film (See Supplementary Fig. 2 and Table 1 for film quality characterizations and comparisons) was transferred onto the overall structure by a wet chemical etching, and the transferred ML-MoS2 films are almost intact and flat on target substrates process (see Methods and Supplementary Fig. 3). Finally, multistep lithography, reactive ion etching (RIE), and electron beam evaporation were performed to define the channel and source/drain (S/D) contact regions. 

For a typical TFT on the SiO2 substrate, we characterized its interfaces between different layers by cross-sectional scanning transmission electron microscope (STEM). Figure 1b, c shows a typical STEM image and corresponding Au, Ti, Hf, Si elemental mapping from energy disperse spectroscopy (EDS) at the HfO2/metal-gate interface. We can see a uniform and conformal coating of HfO2 with a thickness of 5 nm on the metal gate. Figure 1d shows an atomic-resolution STEM image of the Au-MoS2 interface. The sharp interface between periodically arranged Au atoms and three-atom-thick MoS2 surface without any defects or cracks suggests the high quality of contacts. 

To evaluate the dielectric properties of HfO2 layers deposited on metal gates by ALD, we performed capacitance measurements (Supplementary Fig. 4). In Fig. 1e, we plot the dielectric constants (εr) of 5-nm and 10-nm thick HfO2 layers deposited at 110, 150, and 200 °C. Obviously, higher deposition temperature and thicker thickness are beneficial to achieving a better dielectric property. Hence, the ALD temperature of 200 °C was applied for rigid devices; whereas it is 150 or 110 °C for flexible devices to reduce the temperature-induced substrate deformation. In our batch fabrication of devices, the minimum HfO2 thickness (tHfO2) is 5 nm on rigid substrates, e.g., SiO2, and 10 nm on flexible substrates, e.g., polyethylene terephthalate (PET, see Supplementary Fig. 5 for roughness characterizations), for a reliable device yield. Note that the 5-nm HfO2 layer has an effective oxide thickness (EOT) of only 1.1 nm. Such low EOT is beneficial to high device transconductance at low supply voltages and efficient gating of MoS2 channels. 

### ML-MoS2 TFTs on rigid substrates 

Firstly, let’s evaluate ML-MoS2 TFTs onSiO2 substrates with normalized channel lengths (Lch) and widths (W). Figure 1f shows the normalized transfer curves (Ids·L/W-ΔVg) of devices with HfO2 layer thickness of 5 and 10 nm. As a comparison, 30 nm thick Al2O3 devices are also included. It can be clearly seen that with decreased tHfO2 and increased εr, the gate voltages (Vg) can be reduced from 15 V to 3 V and the SS can be reduced from 250 mV·dec<sup>−1</sup> to 75 mV·dec<sup>−1</sup> , while preserving the onstate current (Ion) densities and on/off ratios. 

Figure 1g, h demonstrate typical output (Ids/W-Vds) and transfer curves (Ids/W-Vg) of a short channel device with tHfO2 = 5 nm and Lch ≈ 50 nm. This device features ultra-high on/off ratio of ~10<sup>9</sup> , sharp subthreshold slope (SS) of ISS = 75 mV·dec<sup>−1</sup> over 5 orders of magnitude, and negligible hysteresis (ΔVg ~ 11.5 mV, inset to Fig. 1h) subjected to the high quality of MoS2/HfO2 interface. The ultra-high on/off ratio could guarantee an ultra-low static power dissipation. When devices work at a stand-by mode (off state), the leakage current (Ig/W) can reach below 1 pA·μm<sup>−1</sup> (Fig. 1h) for a general W/Lch = 5 μm/50 nm device. Due to the high gating efficiency, the maximum field could approach ~1 V·nm<sup>−1</sup> and the carrier density can approach ni = 5.15 × 10<sup>13</sup> cm<sup>−2</sup> at Vg = 5 V. Note thatthe effective carrier densities in MoS2 channel would be overestimated based on the metal-insulatormetal capacitance (MIMCAP) results, thus we carried out metal-oxidesemiconductor capacitance (MOSCAP) measurements based on the MoS2 FET (Supplementary Fig. 6). Such high carrier densities in MLMoS2 channels are among the highest in previous reports. As a result, the maximum on-state current densities (Ion/W) could reach 936 μA·μm<sup>−1</sup> at Vds = 1.5 V with Lch = 50 nm in Fig. 1g, which is 

comparable to the highest value (1135 μA·μm<sup>−1</sup> at Vds = 1.5 V) previously achieved in Bi-contacted ML-MoS2 TFTs with Lch = 35 nm<sup>39</sup> . More data on MoS2 TFTs with Lch of 150 nm and 300 nm appears in Supplementary Fig. 7. Note that even Au-contacts show slightly higher contact resistances than Bi-contacts, our devices still show linear output characteristics at small bias and saturated output behaviors at high bias voltages, which is important for the output current capacity of short channel devices. Besides, Ion/W is ~720 μA·μm<sup>−1</sup> at Vds = 1 V, meeting the low-power application metrics of the International Roadmap for Devices and Systems (IRDS, 2024)<sup>43</sup> . 

### ML-MoS2 TFTs on flexible substrates 

Next, we implement the technique of ultra-thin high-κ dielectric/ metal gate deposition on flexible PET substrate. Figure 2a shows 4” wafer-scale ML-MoS2 TFTs on PET substrate. Now let’s evaluate devices on flexible substrates based on 10 nm HfO2. These longchannel TFTs have a high device yield (>96%) and nice spatial uniformity. In Fig. 2b we show transfer curves of 500 randomly picked TFTs with Lch varying from 5 to 75 μm. Statistics on the device’s μFE, on/off ratio, threshold voltage (Vth), and SS are shown in Fig. 2c. According to Lorentz distribution fittings, μFE averages at ~70 cm<sup>2</sup> ·V<sup>−1</sup> ·s<sup>−1</sup> (maximizes at >110 cm<sup>2</sup> ·V<sup>−1</sup> ·s<sup>−1</sup> ); on/off ratio averages at 5 × 10<sup>7</sup> (maximizes at ~1 × 10<sup>9</sup> ); Vth is centered at 0.96 ± 0.4 V; and SS averages at 83 mV·dec<sup>−1</sup> . All these performances are comparable to those previously achieved in rigid ML-MoS2 TFTs (Supplementary Table 2) and greatly improved over the previous state-of-theart flexible TFTs (Supplementary Table 3). It is worth noting here that both the positive Vth and small SS are critical for the low power consumption in our devices, as will be shown later. Note that we also realize the fabrications of flexible ML-MoS2 FETs based on 5 nm HfO2 as measured in Supplementary Figs. 8, 9. Considering the low device yield (~60%) and higher leakage current level of the 5 nm HfO2, we mainly adopt 10 nm HfO2 as dielectric layer for integrated logic gates in following experiments. 

According to previous studies<sup>44</sup> , the Vth variability comes mainly from sources including material uniformity (defects, grain boundaries, and layer thicknesses), oxide roughness, surface (MoS2 surface), and interface (contact interface, oxide-MoS2 interface) cleanness. In this study, MoS2 is strictly monolayer without additional layers and of high quality. High defects (mainly S-vacancies) density could cause severe n-doping in the devices, shifting Vth to very negative values. In present devices, the positive Vth reflects the low density of vacancy defects in the MoS2 channel region. The domain sizes in our samples are over 200 µm, much larger than the channel sizes, suggesting that grain boundaries are also not likely the source of Vth variations. The thin HfO2 layers deposited on metal gates are smooth with a surface roughness of ~0.5 nm, measured by AFM. We thus conclude that the main source of Vth variability, although it is small, comes mainly from the surface and interface cleanness. 

The high device performance is attributed to several aspects. First, our ML-MoS2 films are of high quality. The extracted sheet resistance R□ is ~5.2 kΩ at ni ≈ 2.8 × 10<sup>13</sup> cm<sup>−2</sup> fitted by the transfer length method (TLM), as shown in Fig. 2d. Second, the employment of HfO2 dielectrics allows us to tune carrier densities in MoS2 over than 5 × 10<sup>13</sup> cm<sup>−2</sup> . Third, the contact resistance Rc between Au and MoS2 is as low as ~0.59 kΩ·μm (see Fig. 2d and Supplementary Fig. 10 for the Rc extraction based on long channel and short channel devices). Such low Rc is facilitated by the ultra-slow Au-deposition rates (see Methods) and the bottom gate structure in which the contact region of ML-MoS2 can be doped to be metallic properties. Based on our data from both rigid and flexible TFTs, here we highlight the on-state current densities (Ids/W) as a function of Lch in Fig. 2e. Clearly, our data points lay at the upper envelope boundary if compared with literature works from monolayer flexible or rigid MoS2 TFTs (all reference data points acquired from Supplementary Tables 2, 3). 

Nature Communications |  (2023) 14:3633 

3 

Article 

https://doi.org/10.1038/s41467-023-39390-9 



<!-- Start of picture text -->
a b 10 1 c 160<br>4 inch MoS2 FETs<br>10 -2 80<br>0<br>10 -5 40 80 120<br>Mobility (cm 2 V -1 s -1 )<br>160<br>10 -8<br>80<br>1 cm 200 μm<br>10 -11<br>0 2 4 6 0<br>6 7 8 9<br>V g (V)<br>Log( I on/ I off)<br>d e 160<br>Theoretical value  [19] Flexible<br>400 2 R c=1.18 kΩ·μm 1000 IEDS LP Rigid<br>80<br>R ≈5.2 kΩ 2024  [43] V ds=1V<br>300<br>0<br>100 0.6 1.0 1.4<br>V th (V)<br>200<br>200<br>10<br>100<br>100<br>0 1 0<br>0 20 40 60 80 0.01 0.1 1 10 100 60 100 140<br>Channel length (μm) Channel length (μm) SS (mV/dec)<br>Count<br> (mA) I ds<br>Count<br>Count<br>-1/ (μA·μm) WI ds<br>Resiatence (k·μm)Ω<br>Count<br><!-- End of picture text -->

Fig. 2 | Flexible ML-MoS2 TFTs and electrical properties. a Photograph of an asfabricated 4-inch MoS2 TFTs on the polyethylene terephthalate (PET) substrate. Scale bar, 1 cm. b Transfer curves of 500 randomly picked TFTs with the 10 nm HfO2 dielectrics. Bias voltage (Vds) is 1 V, and the device yield is 96.2%. Inset to (b) shows the enlarged image of the device array. Scale bar, 200 μm. c Histogram and Lorentz distribution fits of the device mobility, on/off ratio, threshold voltage and subthreshold swing extracted from the transfer curves in (b). d Contact and sheet 

resistance measurements from transfer length method (TLM) at ni ≈ 2.8 × 10<sup>13</sup> cm<sup>−2</sup> . e Statistics and comparisons of the on-state current density of the flexible and rigid TFTs at Vds = 1 V versus channel length. This work is highlighted in red and blue circles, while the reference data points are drawn in gray and green squares (please refer to Supplementary Tables 2, 3 for details). Error bars in (d) and (e) are taken from 10 transistors with the same channel length. 

### Low-power and high-performance flexible ICs 

We further fabricated large-area flexible ICs based on ML-MoS2. Figure 3a shows a photograph of 4 × 4 cm<sup>2</sup> electronic circuits fabricated on the PET substrate. As logic gates and inverters are essential building blocks of ICs, we included logic inverters, NAND, NOR, and AND gates in this batch (Fig. 3b, c). 

The output characteristic of ML-MoS2 inverter shows abrupt switching behavior with power supply voltages Vdd = 0.5 V (Fig. 3d). The trip point of the inverter is when output voltage (Vout) equals input voltage (Vin) and of particular importance for low-power electronics as it determines the driving voltage of integrated logic circuits. The typical inverter also exhibits full swing output behavior with noise margin (NM) of 0.8×(Vdd /2) and voltage gain of 120. Note that the highest voltage gain is 192 at Vdd = 0.5 V and 397 at Vdd = 1 V, and it can approach 1000 (2670) at Vdd = 2 V (4 V), the highest ever achieved in MoS2 inverters (see Supplementary Fig. 11). Note that the rail-to-rail operations could be realized by further optimizing the circuit design of the FET units<sup>45</sup> , combing p-type FETs as building blocks<sup>46</sup> or introducing doping techniques<sup>47</sup> . As can be seen in Fig. 3e, our MoS2 inverters have ultra-high gains and reliable outputs within the sub-1V supply voltage zone, as compared with other flexible inverters or rigid inverters based on 2D materials (the reference data points acquired from Supplementary Table 4). The ultra-high voltage gain is enabled by the strong gate controllability, while the trip point is mainly 

determined by the Vth distribution in our MoS2 TFTs. We also analyzed the individual TFT unit within an inverter (Supplementary Fig. 12) with intrinsic gains<sup>48</sup> (defined as Ai = gm/gd) from 10<sup>3</sup> to 10<sup>4</sup> , where gm and gd are the transconductance and output conductance of the TFT. Through monitoring the channel current of an inverter, the MoS2 TFT unit works mainly at the deep-subthreshold regime with ultra-low current densities. The calculated maximum output power of an inverter is 10.3 pW·μm<sup>−1</sup> , at the same level as an oxide semiconductor inverter<sup>32</sup> ; and the quiescent power is below 0.1 pW·μm<sup>−1</sup> at Vdd = 1 V (see Supplementary Table 5 for power consumption comparisons). 

Typical output characteristics of ML-MoS2 logic NAND, NOR, AND gates are also shown in Fig. 3f. 0.5 V pulses of VA and VB with 1 s delay are used as input signals, where 0.5 V for the logic ‘1’ and 0 V for the logic ‘0’. All logic gates have correct Boolean output functionalities with a low supply voltage Vdd = 0.5 V. 

In addition to logic gates and inverters, flexible ML-MoS2 ROs with various number of stages were also fabricated to demonstrate the reliability for low voltage operations. Figure 4a shows the optical microscope image of 11-stage ROs which integrate cascading eleven inverters and an additional inverter as the output buffer for measurements. The corresponding schematic circuit with three terminal electrodes of Vdd, Vss, and Vout is shown in Fig. 4b. Figure 4c shows the stable electrical output signals of an 11-stage RO at supply voltage Vdd from 0.3 V to 1 V (Vss terminal is grounded). Such low-driving voltages 

Nature Communications |  (2023) 14:3633 

4 

Article 

https://doi.org/10.1038/s41467-023-39390-9 



<!-- Start of picture text -->
a d 0.5 e<br>100<br>1000 This work<br>0.4 Noise margain 50<br>0.8( V dd/2)<br>0<br>0.3 0.0 V 0.2in (V)0.4 100<br>0.2<br>Flexible<br>10<br>0.1<br>1 cm Rigid 2D materials<br>0.0<br>1<br>0.0 0.1 0.2 0.3 0.4 0.5 0 1 2 3 4 5<br>b f V in (V) V dd(V)<br>Inverter NAND NOR AND<br>0.5<br>V A<br>0.0<br>0.5<br>200 μm V B<br>5-stage ring oscillator 0.0<br>0.5<br>c V dd Inverter V in V NAND dd V B V A 0.00.5 NAND<br>V out V out NOR<br>0.0<br>NOR V B AND V out 0.5<br>V dd AND<br>V dd 0.0<br>V A V B<br>V out V A 0 4 8 12 16 20 24 28 32 36 40 44 48 52 56 60 64 68 72 76 80<br>Time (s)<br>Gain (V/V)<br>(V) V out<br>Gain (V/V)<br>Input (V)<br>Output (V)<br><!-- End of picture text -->

Fig. 3 | Flexible integrated circuits at low driving voltages. a Photograph of 4 × 4 cm<sup>2</sup> integrated monolayer MoS2 TFTs on the flexible PET substrate. Scale bar, 1 cm. b, c Optical image (b) and schematic circuits (c) of logic inverters, NAND, NOR, AND gates and 5-stage ring oscillators. Scale bar, 200 μm. Vdd, power supply voltage; Vin, VA, or VB, input voltages; Vout, output voltage. d Voltage transfer curves (VTCs) of a logic inverter with noise margin of 0.8(Vdd /2) at Vdd = 0.5 V. Inset shows 

corresponding voltage gain of 120. e Comparison of the inverter voltage gain as a function of Vdd among flexible inverters or rigid inverters based on 2D materials. The reference data points are listed in Supplementary Table 4. f Output characteristics of logic NAND, NOR, AND gates as a function of input voltage pulses with Vdd = 0.5 V. 

are facilitated from the small trip point of logic inverters. In contrast, if negative voltages are applied on the Vss terminal while the Vdd terminal is grounded, the RO could output negative signals starting from Vss = −0.4 V, as the swing threshold voltages of logic inverters shift negatively with the decreasing the operation voltages of Vss or Vdd terminal (Supplementary Fig. 11c, d). 

Generally, the output amplitude increases with the supply voltages and the oscillation frequency (f) decreases with the number of stages. Figure 4d shows the maximum output oscillation signals of 3-, 5- and 11-stage ROs operated at Vdd = 5 V. The ROs have reliable outputs with supply voltages varying from 0.3 V to 5 V (Fig. 4e). The maximum f is 24.8, 14.29, and 6.7 MHZ for 3-, 5- and 11-stage ROs, respectively. The corresponding propagation stage delay time (τpd = 1/2Nf, where N is RO stage number) at Vdd = 5 V is 6.7, 7.0, and 6.8 ns for 3-, 5-, and 11stage ROs, respectively. Compared with previous flexible ROs fabricated from other 2D materials, organic, oxides or CNTs, our ROs locate at the preferred conner with the low driving voltages (sub-1 V) and fast propagation stage delay time (Fig. 4f). Note that, in this work, the parasitic capacitance from the overlapping region between the contact electrodes/additionalouter MoS2 region with the gate is detrimentalto high-frequency operation. The typical channel length/width of TFT unit is 1 μm/3 μm for ROs, and more device details and parasitic capacitance optimization is demonstrated in Supplementary Fig. 13. A typical real-time outputs of oscillating RO is included in the Supplementary Movie to show the stable operation. 

Finally, we performed bending tests of the flexible ML-MoS2 ICs. As an example, here we show results from flexible MoS2 TFTs and 5-stage RO in Supplementary Figs. 14–17. On/off ratios as well as fieldeffect mobilities of individual TFTs could be well-preserved under a minimum bending radius (R = 2.4 mm). Under such bending, either along the X- or Y- direction, the 5-stage RO exhibits stable outputs 

without obvious degradations. The excellent mechanical flexibility and endurance, reliable electrical outputs of ROs, and high device yield indicate the good device performances and uniformity of our devices fabricated on flexible substrates; and the lowest operation supply voltage indicates the potential for low-power electronic applications. 

## Discussion 

We developed an ultra-thin high-κ dielectric on metal gate technology for ML-MoS2 TFTs. Benefiting from the high-quality ML-MoS2 wafers as well as ohmic contacts, our ML-MoS2 TFTs could be tuned to high carrier density of 5.15 × 10<sup>13</sup> cm<sup>−2</sup> and allow a high current capacity of 936 μA·μm<sup>−1</sup> at Vds = 1.5 V with sharp SS of 75 mV·dec<sup>−1</sup> , positive threshold voltages, negligible hysteresis, and ultra-low leakage currents. Large-area flexible TFTs and ICs show excellent spatial uniformity and a high device yield of >96% with fully functional inverters, logic gates, and ring oscillators working reliably under supply voltages below 1 V. The power consumption of an inverter can be as low as 10.3 pW·μm<sup>−1</sup> at Vdd = 1 V. Besides, both the voltage gains of inverters and the propagation delay time of ROs we achieved are record-high values against previous flexible devices. Our results suggest that MLMoS2 is a very competitive channel material in flexible ICs for both high performance and low power applications. 

## Methods 

### Growth of high-quality ML-MoS2 films 

The growth was carried out in a CVD system using S (Alfa, 99.5%, 8 g) and MoO3 (Alfa, 99.9995%, 30 mg) powder as reaction sources. 4-inch c-plane sapphire wafers were used as substrates. In order to achieve large domain sizes, we intended to reduce the nucleation density during the growth process and elongate the growth time accordingly. The nucleation density of MoS2 was 

Nature Communications |  (2023) 14:3633 

5 

Article 

https://doi.org/10.1038/s41467-023-39390-9 



<!-- Start of picture text -->
a c<br>0.8<br>1.0V<br>V ss=0V 0.9V<br>0.8V<br>0.7V<br>0.4 V dd<br>11-stage ring oscillator 0.5V 0.6V<br>V dd 0.4V<br>0.3V<br>V out<br>V ss 0.0<br>0.4V<br>200 μm -0.4 V ss 0.5V<br>0.6V<br>b V dd -0.8 V dd=0V 0.7V 0.8V<br>0.9V<br>V out 1.0V<br>V ss 0 100 200 300 400 500 600 700 800<br>Time (μs)<br>d e f<br>10 -4<br>3-stage RO 3-stage RO<br>1 5-stage RO<br>11-stage RO 10 -5<br>0<br>10<br>0.0 0.1 0.2 0.3 0.4 0.5 10 -6 Oxides<br>Organics<br>5-stage RO<br>1 10 -7<br>0<br>0.0 0.2 0.4 0.6 0.8 1.0 10 -8 This work<br>1 11-stage RO 11-stage RO MoS2<br>1 10 -9 5-stage RO<br>3-stage RO CNT<br>0 10 -10<br>0.0 0.5 1.0 1.5 2.0 2.5 1 10 0.1 1 10<br>Time (μs) V dd(V) V dd (V)<br>Output (V)<br>Output (V)<br>Frequency (MHZ)<br>Propagation delay (s per stage)<br><!-- End of picture text -->

Fig. 4 | Flexible ML-MoS2 ring oscillators (ROs) operated at sub-1 V supply voltages. a, b Optical image and schematic circuit diagram of 11-stage ROs. Scale bar, 200 μm. Vdd, or Vss, power supply voltages applied on drain or source electrodes. c Output signals of an 11-stage RO operated with sub-1 V supply voltages from 0.3 V to 1 V. d Output signals of 3-stage, 5-stage and 11-stage ROs operated at 

Vdd = 5 V. The output oscillation frequency increases by decreasing the stage number. e Summarized output frequencies of ROs as a function of Vdd from 0.3 V to 5 V. The output oscillation frequency increases with supply voltages. f Comparisons of propagation stage delay time as well as supply voltages with literature works. Detailed parameters are listed in Supplementary Table 6. 

reduced by using higher oxygen flow rate for MoO3 source and reducing the Mo-source flux by lowering its evaporation temperature, increasing the distance between the Mo-source and sapphire substrate. During the growth, carrier gases of Ar (40 sccm) and Ar (240 sccm)/O2 (10 sccm) were fluxed for S power and MoO3 individually and the pressure in the chamber is ~1 Torr; temperatures were hold at 130 °C, 530 °C, and 930 °C for the S-, MoO3-source and substrate; and the growth process lasts usually about 50 min. Supplementary Fig. 2 demonstrates an optical image of high-quality 4-inch ML-MoS2 wafer with large domain sizes between 200 μm and 500 μm. These domains are wellstitched together to form a continuous film with 100% coverage. 

### Device fabrications and measurements 

TFTs and logic devices were fabricated via standard microfabrication processes such as e-beam lithography or UV lithography, oxygen RIE, e-beam evaporation and lifting-off. Transfer of ML-MoS2 films from sapphire to target substrates were assisted by wet etching in KOH solution (1 Mol/L, 110 °C). The process is illustrated in Supplementary Fig. 3. Au contact electrodes (10–15 nm) with clean interfaces were fabricated by e-beam evaporation with an ultra-low deposition rate of ~0.01 Å·s<sup>−1</sup> . All the electrical measurements were carried out in a Janis probe station at a base pressure of 10<sup>−6</sup> Torr with an Agilent semiconductor parameter analyzer (B1500, high resolution modules) and Agilent digital oscilloscope (DSO-X 3054 A) at room temperature. 

### Deposition of High-κ dielectric layers 

ALD of HfO2 on Ti/Au/Ti (1 nm/5 nm/1 nm) local metal gates were carried out by Savannah-100 system (Cambridge NanoTech. Inc.) with H2O and tetrakis dimethylamino hafnium (TDMAH) as precursors. Prior to the deposition process, we used O2 plasma to treat the Ti/Au/ Ti electrode surface by reactive ion etching (RIE) to oxidize the surface Ti layer. The oxidized layer (TiO2-x) acts as a buffer layer for dense highκ dielectrics deposition. During the deposition, 20 sccm high-purity nitrogen was flowed as the carrier and purge gas; the reactor pressure was ~3 Torr; and the TDMAH precursor was heated to 75 °C. The deposition temperature is 110 °C or 150 °C for flexible samples, and 200 °C for rigid samples. The pulse and reaction time was 0.015/0.15 and 60/60 s for TDMAH/H2O precursors with deposition rate around 1 Å per cycle. 

### STEM characterizations 

The cross-sectional STEM characterizations were carried out by an aberration corrected JEOL ARM 300 F transmission electron microscope operated at 300 kV. 

## Data availability 

The Source Data underlying the figures of this study are available at https://doi.org/10.6084/m9.figshare.22776989. All raw data generated during the current study are available from the corresponding authors upon request. 

## References 

1. Wu, W. et al. Piezoelectricity of single-atomic-layer MoS2 for energy conversion and piezotronics. Nature 514, 470–474 (2014). 

Nature Communications |  (2023) 14:3633 

6 

Article 

https://doi.org/10.1038/s41467-023-39390-9 

2. Myny, K. The development of flexible integrated circuits based on thin-film transistors. Nat. Electron. 1, 30–39 (2018). 

3. Park, Y. J. et al. All MoS2-based large area, skin-attachable activematrix tactile sensor. ACS nano 13, 3023–3030 (2019). 

4. Zhang, X. et al. Two-dimensional MoS2-enabled flexible rectenna for Wi-Fi-band wireless energy harvesting. Nature 566, 368–372 (2019). 

5. Dai, Y. et al. Stretchable transistors and functional circuits for human-integrated electronics. Nat. Electron. 4, 17–29 (2021). 

6. Kaltenbrunner, M. et al. An ultra-lightweight design for imperceptible plastic electronics. Nature 499, 458–463 (2013). 

7. Gao, W. et al. Fully integrated wearable sensor arrays for multiplexed in situ perspiration analysis. Nature 529, 509–514 (2016). 

8. Wang, S. et al. Skin electronics from scalable fabrication of an intrinsically stretchable transistor array. Nature 555, 83–88 (2018). 

9. Kim, D. H. et al. Stretchable and foldable silicon integrated circuits. Science 320, 507–511 (2008). 

10. Shahrjerdi, D. & Bedell, S. W. Extremely flexible nanoscale ultrathin body silicon integrated circuits on plastic. Nano Lett 13, 315–320 (2013). 

11. Fortunato, E., Barquinha, P. & Martins, R. Oxide semiconductor thinfilm transistors: a review of recent advances. Adv. Mater. 24, 2945–2986 (2012). 

12. Papadopoulos, N. P. et al. Toward temperature tracking with unipolar metal-oxide thin-film SAR C-2C ADC on plastic. IEEE J SolidState Circuits 53, 2263–2272 (2018). 

13. Cao, Q. et al. Medium-scale carbon nanotube thin-film integrated circuits on flexible plastic substrates. Nature 454, 495–500 (2008). 

14. Sun, D. M. et al. Flexible high-performance carbon nanotube integrated circuits. Nat. Nanotechnol. 6, 156–161 (2011). 

15. Tang, J. et al. Flexible CMOS integrated circuits based on carbon nanotubes with sub-10 ns stage delays. Nat. Electron. 1, 191–196 (2018). 

16. Xiang, L. et al. Low-power carbon nanotube-based integrated circuits that can be transferred to biological surfaces. Nat. Electron. 1, 237–245 (2018). 

17. Long, G. et al. Carbon nanotube-based flexible high-speed circuits with sub-nanosecond stage delays. Nat. Commun. 13, 6734 (2022). 

18. Radisavljevic, B. et al. Single-layer MoS2 transistors. Nat. Nanotechnol. 6, 147–150 (2011). 

19. Yoon, Y., Ganapathi, K. & Salahuddin, S. How good can monolayer MoS2 transistors be? Nano Lett 11, 3768–3773 (2011). 

20. Fiori, G. et al. Electronics based on two-dimensional materials. Nat. Nanotechnol. 9, 768–779 (2014). 

21. Akinwande, D., Petrone, N. & Hone, J. Two-dimensional flexible nanoelectronics. Nat. Commun. 5, 5678 (2014). 

22. Kang, K. et al. High-mobility three-atom-thick semiconducting films with wafer-scale homogeneity. Nature 520, 656–660 (2015). 

23. Shinde, S. M. et al. Surface-functionalization-mediated direct transfer of molybdenum disulfide for large-area flexible devices. Adv. Funct. Mater. 28, 1706231 (2018). 

24. Li, N. et al. Large-scale flexible and transparent electronics based on monolayer molybdenum disulfide field-effect transistors. Nat. Electron. 3, 711–717 (2020). 

25. Conti, S. et al. Low-voltage 2D materials-based printed field-effect transistors for integrated digital and analog electronics on paper. Nat. Commun. 11, 3566 (2020). 

26. Liu, Y. et al. Promises and prospects of two-dimensional transistors. Nature 591, 43–53 (2021). 

27. Chang, H. Y. et al. High-performance, highly bendable MoS2 transistors with high-k dielectrics for flexible low-power systems. ACS Nano 7, 5446–5452 (2013). 

28. Desai, S. B. et al. MoS2 transistors with 1-nanometer gate lengths. Science 354, 99–102 (2016). 

29. Xie, L. et al. Graphene-contacted ultrashort channel monolayer MoS2 transistors. Adv. Mater. 929, 1702522 (2017). 

30. Daus, A. et al. High-performance flexible nanoscale transistors based on transition metal dichalcogenides. Nat. Electron. 4, 495–501 (2021). 

31. Wang, Q. H. et al. Electronics and optoelectronics of twodimensional transition metal dichalcogenides. Nat. Nanotechnol. 7, 699–712 (2012). 

32. Lee, S. & Nathan, A. Subthreshold Schottky-barrier thin-film transistors with ultralow power and high intrinsic gain. Science 354, 302–304 (2016). 

33. Yu, H. et al. Wafer-scale growth and transfer of highly-oriented monolayer MoS2 continuous films. ACS nano 11, 12001–12007 (2017). 

34. Wang, Q. et al. Wafer-scale highly oriented monolayer MoS2 with large domain sizes. Nano Lett 20, 7193–7199 (2020). 

35. Li, T. et al. Epitaxial growth of wafer-scale molybdenum disulfide semiconductor single crystals on sapphire. Nat. Nanotechnol. 16, 1201–1207 (2021). 

36. Kim, K. S. et al. Non-epitaxial single-crystal 2D material growth by geometric confinement. Nature 614, 88–94 (2023). 

37. Si, M. et al. Steep-slope hysteresis-free negative capacitance MoS2 transistors. Nat. Nanotechnol. 13, 24–28 (2018). 

38. Wang, Y. et al. Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. Nature 568, 70–74 (2019). 

39. Shen, P. C. et al. Ultralow contact resistance between semimetal and monolayer semiconductors. Nature 593, 211–217 (2021). 

40. Kim, H. G. & Lee, H. B. R. Atomic layer deposition on 2D materials. Chem. Mater. 29, 3809–3826 (2017). 

41. Li, W. et al. Uniform and ultrathin high-κ gate dielectrics for twodimensional electronic devices. Nat. Electron. 2, 563–571 (2019). 

42. Zhu, Y. et al. Monolayer molybdenum disulfide transistors with single-atom-thick gates. Nano Lett 18, 3807–3813 (2018). 

43. Moore, M. International Roadmap for Devices and Systems 2020 Edition. https://irds.ieee.org/images/files/pdf/2020/2020IRDS_ MM.pdf (2020). 

44. Smets, Q. et al. Sources of variability in scaled MoS2 FETs. In 2020 IEEE International Electron Devices Meeting (IEDM) 3.1.1–3.1.4 (IEEE, 2020). 

45. Wachter, S. et al. A microprocessor based on a two-dimensional semiconductor. Nat. Commun. 8, 14948 (2017). 

46. Guo, E. et al. Integrated complementary inverters and ring oscillators based on vertical-channel dual-base organic thin-film transistors. Nat. Electron. 4, 588–594 (2021). 

47. Tian, J. et al. Rail-to-rail MoS2 inverters. ACS Appl. Electron. Mater 4, 2636–2640 (2022). 

48. Li, S. et al. Nanometre-thin indium tin oxide for advanced highperformance electronics. Nat. Mater. 18, 1091–1097 (2019). 

## Acknowledgements 

This work was supported by the National Key Research and Development Program (Grant No. 2021YFA1202900, 2021YFA1400502), the Strategic Priority Research Program of Chinese Academy of Sciences (CAS, grant No. XDB30000000), the National Science Foundation of China (NSFC, grant No. 61888102, 11834017, 61734001, and 62122084), and the Key-Area Research and Development Program of Guangdong Province (Grant No. 2020B0101340001). The authors also thank Prof. Aizi Jin, Prof. Tianzhong Yang and Dr. Xiao Guo in IOP-CAS for the assistance on short channel device fabrications and CS-STEM sample preparations. 

## Author contributions 

J.Ta. fabricated the devices and carried out the electrical measurements with the help of J.Ti., N.L., Y.P., Xiu.L., Y.Z., C.H., B.H., and Y.C. J.Ta., J.Ti., 

Nature Communications |  (2023) 14:3633 

7 

Article 

https://doi.org/10.1038/s41467-023-39390-9 

S.W., J.L., Y.G., and Da.S. performed the high-κ dielectric deposition. Q.W. performed the growth of ML-MoS2 films. Xia.L. J.Ta., Y.J. and X.B. prepared the TEM samples and performed the TEM characterizations. G.Z., Do.S., W.Y., R.Y., and L.D. supervised the project. J.Ta. and G.Z. analyzed data and wrote the manuscript. All authors discussed and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-39390-9. 

Correspondence and requests for materials should be addressed to Guangyu Zhang. 

Peer review information Nature Communications thanks Alwin Daus for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2023 

Nature Communications |  (2023) 14:3633 

8 

