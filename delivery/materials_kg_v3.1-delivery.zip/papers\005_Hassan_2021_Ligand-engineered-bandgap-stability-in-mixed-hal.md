# Ligand-engineered bandgap stability in mixed-halide perovskite LEDs

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 691 |
| 作者 | Yasser Hassan, J. H. Park, M. Crawford, A. Sadhanala, Jeongjae Lee, J. Sadighian, E. Mosconi, Ravichandran Shivanna et al. |
| DOI | 10.1038/s41586-021-03217-8 |
| 源文件 | 005_Hassan_2021_Ligand-engineered-bandgap-stability-in-mixed-hal.pdf |

---
- 1 **Ligand engineered bandgap stability in mixed-halide perovskite LEDs** 

- 2 

- 3 <u>Yasser Hassan</u> ~~*~~ <u>1,15</u> ~~,~~ <u>Jong Hyun Par</u> ~~<u>k</u>~~ <u>2,15</u> ~~,~~ Michael L. Crawford<sup>3</sup> , Aditya Sadhanala<sup>1,13,14</sup> , Jeongjae 

- 4 Lee<sup>4</sup> , James C. Sadighian<sup>3</sup> , Edoardo Mosconi<sup>5</sup> , Ravichandran Shivanna<sup>14</sup> , Eros Radicchi<sup>5,11</sup> , Mingyu 5 Jeong<sup>6</sup> , Changduk Yang<sup>6</sup> , Hyosung Choi<sup>7</sup> , Sung Heum Park<sup>8</sup> , Myoung Hoon Song<sup>2</sup> , Filippo De 6 Angelis<sup>5,11,12</sup> , Cathy Y. Wong*<sup>3,9,10</sup> , Richard H. Friend<sup>14,</sup> Bo Ram Lee*<sup>8</sup> , and Henry J. Snaith*<sup>1</sup> 

- 7 **1** Clarendon Laboratory, Department of Physics, University of Oxford, Parks Road, Oxford OX1 3PU, UK. 

- 8 **2** School of Materials Science Engineering and KIST-UNIST Ulsan Center for Convergent Materials/Low Dimensional 9 Carbon Center/Perovtronics Research Center, Ulsan National Institute of Science and Technology (UNIST), UNIST-gil 

- 10 50, Ulsan, 44919, Republic of Korea. 

- 11 

- 12 

   - **3** Department of Chemistry and Biochemistry, University of Oregon, Eugene, Oregon 97403, USA. 

   - **4** School of Earth&Environmental Sciences, Seoul National University, Seoul 08826, Republic of Korea. 

- 13 **5** Computational Laboratory for Hybrid/Organic Photovoltaics (CLHYO), Istituto CNR di Scienze e Tecnologie Chimiche 

- 14 “Giulio Natta” (CNR-SCITEC), Via Elce di Sotto 8, 06123 Perugia, Italy. 

- 15 **6** Department of Energy Engineering, School of Energy and Chemical Engineering, Perovtronics Research Center, Low 16 Dimensional Carbon Materials Center, Ulsan National Institute of Science and Technology (UNIST), 50 UNIST-gil, 17 Ulju-gun, Ulsan 44919, Republic of Korea. 

- 18 **7** Department of Chemistry, Research Institute for Convergence of Basic Sciences, Research Institute for Natural 19 Sciences, Hanyang University, Seoul 04763, Republic of Korea. 

- 20 21 

- 22 

   - 8Department of Physics, Pukyong National University, 45 Yongso-ro, Nam-Gu, Busan 48513, Republic of Korea. 

   - 9Materials Science Institute, University of Oregon, Eugene, Oregon, 97403, United States. 

   - **10** Oregon Center for Optical, Molecular, and Quantum Science, University of Oregon, Eugene, Oregon, 97403, USA. 

- 23 **11** Department of Chemistry, Biology and Biotechnology, University of Perugia, Via Elce di Sotto 8, 06123 Perugia, 24 Italy. 

- 25 

- 26 

- 27 

- 28 

   - **12** CompuNet, Istituto Italiano di Tecnologia, Via Morego 30, 16163 Genova, Italy. 

   - **13** Centre for Nano Science and Engineering, Indian Institute of Science, Bangalore 560012, India. 

   - **14** Cavendish Laboratory, University of Cambridge, J J Thomson Avenue, Cambridge CB3 0HE, UK. 

   - **15** These authors contributed equally: Yasser Hassan, Jong Hyun Park. 

- 29 **Lead halide perovskites are promising semiconductors for light-emitting applications, owing** 30 **to their bright, bandgap tuneable, and high colour purity luminescence**<sup>**1,2**</sup> **. Close to unity** 31 **photoluminescence quantum yields have been achieved for perovskite nanocrystals across a** 32 **broad range of emission colours, and light-emitting diodes with external quantum efficiencies** 33 **exceeding 20%, which approach commercial OLEDs, have been demonstrated in both the** 34 **Infrared and green emission channels**<sup>**1,3,4**</sup> **. However, due to the formation of lower bandgap** 35 **iodide-rich domains in mixed-halide perovskites, achieving colour-stable and efficient red** 36 **electroluminescence has not been realised**<sup>**5,6**</sup> **. Here, we report mixed-halide perovskite** 37 **nanocrystals treated with multidentate ligands that suppress halide segregation under** 38 **electroluminescent operation. We demonstrate colour-stable red emission centred at 620 nm,** 39 **with electroluminescence external quantum efficiencies of 20.3% in light-emitting diodes. We** 40 **show that a key function of the ligand treatment is to “clean” the nanocrystal surface through** 41 **the removal of lead atoms, and via density functional theory, we find the nature of binding** 42 **between the ligands and the nanocrystal surface suppresses iodine Frenkel defect formation,** 43 **which inhibits halide-segregation. Our work exemplifies how the functionality of metal halide** 44 **perovskites is extremely sensitive to the nature of the (nano)crystalline surface and presents** 45 **a route for controlling surface defect formation and migration. This is critical for achieving** 

1 

- 46 **band gap stability for light emission and may also have a broader impact for other** 47 **optoelectronic applications, such as photovoltaics, where bandgap stability is required.** 

- 48 The bandgap, and hence emission wavelength, of metal halide perovskites, can be tuned 

- 49 by several means, such as quantum confinement<sup>7-10</sup> in nanocrystals (NCs)<sup>5,6</sup> and two- 

- 50 dimensional perovskites<sup>11-14</sup> , or by varying the halide composition in the ABX3 perovskite 

- 51 stoichiometry, where A is organic ammonium or alkaline metal cation, B is a group IV metal 

- 52 cation, typically lead, and X are halide anions<sup>5,6,15-17</sup> . A red emission wavelength between 615 and 

- 53 640 nm, required for displays, can be obtained with photoluminescence quantum yields (PLQY) 

- 54 approaching unity using a mixture of iodide and bromide NCs<sup>5,6,15,16</sup> . However, these NCs are 

- 55 susceptible to halide segregation upon photoexcitation and the application of electrical bias<sup>5,18-</sup> 

- 56 20. Despite much effort, colour-stable red electroluminescence (EL) from mixed halide perovskite 

- 57 

   - NCs has not yet been realised<sup>5,11-15,17,21-28</sup> . 

- 58 Recent investigations suggest halide segregation occurs via diffusion of vacancy and interstitial 

- 59 defects<sup>18,19</sup> . In mixed-halide perovskite films measured experimentally and neat-I systems 

- 60 studied computationally, halide defects appear to migrate to grain boundaries or crystal 

- 61 surfaces<sup>29-34</sup> . For polycrystalline films, improvements in bandgap stability and device efficiency 

- 62 have been achieved by passivating grain boundaries with alkali metal halides or larger organic 

- 63 ammonium cations<sup>7,8,11,17,27,35</sup> . For NCs, this is particularly critical due to the high surface area to 

- 64 volume ratio and reports that halide segregation can occur both within (intra) and between 

- 65 (inter) NCs<sup>20,36</sup> . An approach to solving the halide segregation issue in NCs may lie in discovering 

- 66 a surface treatment that removes or immobilises surface defects<sup>5,15</sup> . 

2 



67 

- 68 **Figure 1. Illustration of NC synthesis. a,** Synthesis and ligand treatment steps: (i) Dissolution of 69 perovskite precursors in acetonitrile (ACN) and methylamine (MA), (ii) NC synthesis by modified 70 LARP, and (iii) post-synthetic ligand treatment. **b** , chemical structures of ligands used. 

- 71 We synthesised CH3NH3Pb(IxBr1-x)3 NCs _via_ a modified ligand-assisted re-precipitation 

- 72 (LARP) method<sup>5</sup> . Following purification, we performed a ligand treatment with 

- 73 ethylenediaminetetraacetic acid (EDTA) and L-glutathione reduced (GL) ( **Fig. 1** ). These molecules 

- 74 bind strongly to lead in biological systems<sup>37-40</sup> . To assess the impact of the ligand treatment, we 

- 75 performed photoluminescence (PL), PLQY, attenuated total reflection Fourier transform infrared 

- 76 spectroscopy (ATR-FTIR), X-ray photoelectron spectroscopy (XPS), and X-ray diffraction (XRD) 

- 77 measurements, which we show in **Fig. 2** , and **(Extended Data Fig. 1)** . 

3 



78 

79 **Fig. 2. Impact of ligand treatment on the solution photoluminescence and NC** 80 **structural properties. a,** Absorption and PL spectra of as-synthesised MAPb(I 1-xBrx)3 81 NCs in solution. **b,** PL spectra of NC films following post-synthetic treatment with GL, 82 EDTA, and EDTA + GL (E+G). **c,** Excitation fluence dependence of PLQE of NC thin 83 films before and after ligand treatment, measured in an integrating sphere. **d,e** , High84 resolution transmission electron micrograph (HR-TEM) image for NCs before and after 85 ligand treatment with E+G, respectively. **f,** XRD for the NCs films before and after ligand 86 treatment. **g,h** , Decay associated difference spectra from a global fit of TAS 87 measurements of neat- and E+G-capped NCs, respectively. Solid and dashed lines are 88 spectra before and after 30 s of exposure to a 7.1 W cm<sup>-2</sup> 405 nm CW laser. Blue, 89 green, and red traces correspond to decay components with time constants of ~400 fs, 90 ~14 ps, and ~280 ps, respectively. Red arrows indicate the red edge of the spectra, 91 where changes in the bandgap of the material would result in changes to the bleaching 92 of the sample due to band filling. 

4 

- 93 As-synthesised MAPb(IxBr1-x)3 NCs in toluene exhibit PL centred at 642 nm **(Fig. 2a)** . After 

- 94 ligand treatment with GL, we observe an increase in intensity and a blue-shift in the PL peak 

- 95 position to 625 nm, **Fig. 2b** . We observe an increased PL intensity and only slight blue-shift to 

- 96 635 nm if EDTA is used instead. Using an equimolar mixture of EDTA and GL (denoted E+G), we 

- 97 observe emission at 630 nm and an overall increase in PL intensity, **Fig. 2b** . PLQY 98 measurements of NC thin films confirm that the ligand treatment decreases the total 99 number of active defects, **Fig. 2c** . These data are consistent with E+G treatment being most 

100 favourable for suppressing non-radiative recombination. High-resolution transmission electron 

101 microscopy (HR-TEM) shows size reduction of the E+G NCs compared to neat NCs (average cubic 102 dimensions of 12 ± 1.7 nm versus 16.3 ±2 nm, respectively, **Fig. 2d,e** and **Extended Data Fig. 2** ). 

103 Exciton energy is linearly dependent on the inverse square of NC size for weakly-confined 

104 excitons. A blue-shift in emission, consistent with quantum confinement and lattice relaxation, 

105 has been measured for perovskite nanoparticles within this size range<sup>41</sup> . Furthermore, we have 106 previously observed up to an 80 nm blue-shift in emission due to size confinement effects in 107 similarly sized MAPbI3 NCs<sup>5</sup> . We hence expect size reduction due to ligand treatment to 

108 increases quantum confinement, contributing to the observed blue-shift in emission<sup>41</sup> . 

- 109 Employing XPS ( **Extended Data Fig.1)** , we find the I:Br ratio changes from 2:1 in the 

110 precursor solution to approximately 2:3 in synthesised NCs. We expect a bulk emission at 647 to 111 655 nm for this composition. Following ligand treatment, we determine a minor enrichment 

112 in bromide content, which would account for up to 8nm blue shift in emission for the 113 E+G sample<sup>42</sup> . We also expect a change in lattice constant of ~0.019 Å per 10 nm shift 114 in PL peak position for changing halide compositions in polycrystalline MAPb(I 1-xBrx)3 

5 

- 115 films<sup>42</sup> , however, XRD measurements reveal a cubic lattice constant of 6.05 Å for NC 

- 116 films both before and after ligand treatment ( **Fig 2f** ). Collectively, these results suggest 

- 117 that both compositional changes and confinement effects are influencing the emission 

- 118 peak position. 

- 119 To assess if the ligand treatment suppresses halide segregation and improves bandgap 

- 120 stability, we performed transient absorption spectroscopy (TAS), **Extended Data Fig. 3** . We 

- 121 measured NC films with and without the E+G ligand treatment, as prepared and after exposure 122 to a 405 nm laser. A global fit of the signal yields decay associated difference spectra (DADS), 

- 123 **Fig. 2g,h** . The sub-ps TAS decay arises from bandgap renormalisation, Auger recombination, and 

- 124 carrier cooling<sup>43</sup> .  Carriers accumulate near the band edge, causing optical bleaching at these 

- 125 energies. The longest TAS decay originates from carrier recombination. After irradiation for 30 s, 

- 126 TAS spectra for the neat sample display a new low energy bleach, visible in the longest DADS 

- 127 component. In contrast, the DADS line-shape for the E+G treated sample remains approximately 

- 128 unchanged after irradiation. The emergence of the low energy bleach in the neat sample is 129 consistent with lower bandgap iodide-rich minority phases emerging, from which charge 

- 130 carriers recombine, which is hence suppressed in the E+G treated sample. 

- 131 Segregation between NCs necessitates the creation of Br-rich and I-rich NCs. This has been 

- 132 observed in other perovskite NCs and results in the presence of a second, higher energy PL 

- 133 emission in addition to the red-shifted PL<sup>20,36</sup> . In **Extended Data Fig. 4** we show that even at very 

- 134 low NC concentrations in a polymer matrix we observe a red-shifted emission, with no growth 

- 135 of a high energy peak nor broadening of the high energy emission shoulder following 

- 136 irradiation. Confocal PL measurements on such films reveal a red-shifted emission under 

6 

- 137 illumination from what appear to be single NCs. The lack of a high energy feature in the TAS 

- 138 spectra of illuminated neat NCs also indicates that Br-rich NCs are not forming, suggesting that 

- 139 segregation can occur within individual NCs. 

7 

140 



8 

- 141 **Figure 3. Device characterisation of mixed halide MAPb(I1-xBrx)3 NC-LEDs: a,** Schematic 

- 142 illustration of MAPb(I1-xBrx)3 NC-LED architecture and scanning electron microscopy (SEM) 

- 143 image showing the cross section of a device; thickness of each layer is confirmed by SEM image: 144 PEDOT:PSS/Poly-TPD/TFB HTLs (30 nm), NC emission layer (20 nm), TPBi ETL (70 nm), LiF/Al 145 electrode (80 nm). **b,** Energy band diagram of the materials employed in these LEDs, from 146 references<sup>44-46</sup> . Operational characteristics for LEDs incorporating neat and E+G ligand treated 147 NC layers; **c,** Current density–voltage and luminance(L)-voltage curves, **d,** EQE-current density 148 curves, **e,** device performance parameters of best-performing LEDs (LE is luminous efficiency) **. f,** 149 EL spectra at different time intervals for LEDs held at a constant current density of 1.5 mA cm<sup>-2</sup> 150 **g,** EL spectra at different current densities (mA cm<sup>-2</sup> ). 

151 We next assess the impact of the ligand treatment upon NC-LEDs. We find that 152 both EDTA and GL significantly suppress the halide segregation and improve bandgap 153 stability, but EDTA treated NC-LEDs exhibit a small broadening in the EL FWHM during 

154 operation. On the other hand, GL treated NC-LEDs show the most stable emission 155 spectra but lower device efficiency. Efficient and colour-stable NC-LEDs were achieved 156 with the E+G treatment ( **Extended Data Fig. 5** ). To better understand the role of each 157 ligand, we ran a second ligand treatment step using a soft Lewis base of adamantane 158 carboxylic acid (ADAC) and constructed LEDs. EDTA, GL, and E+G treated NC-LEDs 159 show a negligible peak shift and small FWHM broadening during operation. However, 160 EDTA and E+G treated NCs, which are treated with ADAC show a more significant peak 161 shift and broadening. In contrast, GL treated NC-LEDs show stable EL, even after the 162 ADAC treatment. These observations indicate that GL is more strongly bound to the NC 163 surface than EDTA, but EDTA appears to be important for achieving the highest 164 efficiencies. 

165 When choosing charge injection layers and optimising the performance of the 166 LEDs, we found that maximising the PLQY of the half-constructed devices led to a rapid 167 and effective selection of ideal materials. We show the results of such studies in 168 **Extended Data Fig. 6–7** . Our final device stack, together with a schematic and a 

9 

169 scanning electron microscopy (SEM) cross-sectional image, is shown in **Fig. 3a and b** . 170 We observe higher current densities in E+G NC-LEDs, and significantly improved EQEs 

171 ( **Fig. 3c,d)** . We measured a peak EQE of 20.3% at ~0.1 mAcm<sup>-2</sup> current density and 172 ~620 nm emission wavelength. This places red perovskite LEDs in the same quantum 173 efficiency range as commercial OLEDs. Considering the PLQY of the isolated perovskite NC 174 films, the refractive indices of the materials, optical outcoupling, and photon recycling, we 175 estimate a maximum feasible EQE of 32.4%,<sup>47,48</sup> discussed in **Methods** . This indicates that there 176 remains potential for further improvement through improved device design. 

177 The most pressing challenge for red-emitting metal halide perovskites is achieving 178 band gap stability. In **Fig. 3f,g** , we show the emission spectra for LEDs operating at a 179 fixed current density over time and over a range of current densities, respectively. For 180 the neat NC-LEDs held at a constant current density of 1.5 mAcm<sup>-2</sup> (and 10 mAcm<sup>-2</sup> 181 shown in **Extended Data Fig. 8** ) measured over 20 minutes, we observe a broadening 

182 of the emission peak and the emergence of a shoulder at ~680 nm. We observe a 183 similar broadening and the emergence of a shoulder when the neat NC-LEDs are 184 measured at increasing current densities. These observations are consistent with halide 185 segregation driven by electrical biasing/current injection during LED operation and 186 causing lower energy emission from iodide enriched regions. In contrast, the emission 187 spectrum for the E+G NC-LEDs is stable at 620 nm under the same operating 188 conditions and duration. We note, however, that the absolute EL intensity decays over 189 time. **Extended Data Fig. 8** shows the luminance as a function of time for E+G NC- 

- 190 LEDs held at current densities of 0.1, 1, and 10 mA<sup>-2</sup> . The time to 50% of initial 191 luminance (T50) decreased from 340, to 130, to 16 minutes, respectively. Therefore, 

10 

- 192 although we have achieved colour-stable red emission, the challenge to deliver long- 

- 193 term stability in absolute brightness and efficiency remains. 



- 194 195 **Figure 4. a,**<sup>13</sup> C solid-state NMR spectra of neat and ligand (GL, EDTA, E+G) treated NCs. Insets 196 show ligand structure. **b** , Molecular structure of EDTA and GL. Peaks a and b are characteristic of 

- 197 CH2 as labelled in the molecular structure of EDTA while peaks ,  and  are characteristic of 198 CH2 in GL. **c,** Solution<sup>1</sup> H NMR spectra of E+G with and without PbI2 in d-DMSO solutions. **d,** 199 Proposed molecular interactions of GL and EDTA with Pb<sup>2+</sup> atoms on the NC surface. 

- 200 Understanding the origin of this improved device performance requires identifying the key 

- 201 ligand-perovskite interactions that stabilise the surface. To this end, we performed solid-state 

- 202 13C NMR of the OA/OLA-capped NCs before and after the E+G treatment. The resulting data, **Fig.** 

- 203 **4a** , show a clear peak at 130.2 ppm (blue dot), which arises from the double-bonded carbons in 

- 204 the OA/OLA molecules. The presence of this peak, alongside the aliphatic -CH 2- peaks (30-27 

- 205 ppm), clearly signifies the existence of OA/OLA on the NC surface even after the EDTA, GL or 

11 

- 206 E+G ligand treatment; these remaining nonpolar OA/OLA chains are likely to ensure NC 

- 207 solubility in toluene even after the ligand treatment. The absence of EDTA peaks from the EDTA- 

- 208 treated sample shows that the amount of EDTA on the NC surface is below the detection limit of 

- 209 NMR, while clear GL peaks arising from the carbonyl (orange) and α-carbonyl (yellow) 

- 210 environments confirm their presence. The peak at 38 ppm (red dot), **Fig 4a** , suggests the 

- 211 presence of oxidised GL, which may indicate that reduction of some species on the 212 perovskite surface could serve as a part of the active role of GL, although this remains 213 speculative at this stage. A key function of GL and EDTA ligands can be inferred from 

- 214 their Pb binding ability: both EDTA and GL are known to bind strongly to Pb atoms, shown 215 through solution-state NMR ( **Fig. 4c** and **Extended Data Fig. 9,** details in **Method** ). 

- 216 We show the proposed molecular interactions of the E+G ligands with Pb<sup>2+</sup> on the NC 

- 217 surface in **Fig. 4d** . We postulate that part of the role of EDTA and GL is to remove 

- 218 undercoordinated lead from the NC surface, resulting in an electronically “cleaner”, less 219 defective surface. This “stripping” action is consistent with (i) reduction in NC sizes, (ii) existence 

- 220 of Pb-ligand complexes in solution, and (iii) large binding energy of EDTA and GL to Pb atoms 221 ( **Extended Data Fig. 10** ). We note that some of the excess ligands in the treatment may 

- 222 then bind to the remaining Pb on the “cleaned” perovskite surface, further decreasing 223 the defect concentration. 

12 



224 

225 **Figure 5.** Optimised structures of two interacting surface adsorbed **a,** GL, **b,** EDTA, and **c,** one GL 226 and one EDTA molecule, along with calculated total biding energies (E b) and their intermolecular 227 contribution (Einter) in eV calculated with respect to the isolated surface adsorbed molecules 228 (Eb=1.85 and 1.60 eV for GL and EDTA, respectively). **d,** Optimised structure of an iodine Frenkel 229 defect pair – defective sites highlighted by red and blue circles - in the presence of adsorbed 230 GL+EDTA along with the increase of defect formation energy compared to the unpassivated 231 surface (EFrenkel, in eV). 

- 232 To gain further understanding of ligand binding, we use DFT to model the interaction of GL 

- 233 and EDTA with the surface of MAPbI3 **(Fig. 5)** . We consider a PbI2-terminated surface 

234 representative of a completely unpassivated perovskite surface with exposed, undercoordinated 

13 

- 235 Pb atoms. We decomposed GL and EDTA into their possible binding moieties and calculated the 

- 236 binding energy (BE) of each ligand to the perovskite surface **(Extended Data Fig. 10)** . The 

- 237 binding energy is defined as BE = Elig@surface – Elig – Esurface, where the latter three terms are the 

- 238 energy of the surface and bound ligand, the energy of the isolated ligand, and the energy of the 

- 239 bare surface, respectively. Our calculated BE for GL is -1.85 eV, which is large compared to the 

- 240 calculated value of -0.58 eV for acetic acid or -0.84 eV for methylamine, representative of 

- 241 carboxylic acid and primary amine binding moieties of GL. We deduce that the large BE is due to 

- 242 contributions from multiple binding moieties. We also determine a large BE for EDTA (-1.60 eV), 

- 243 slightly lower than that of GL, with steric hindrance limiting binding from the tertiary aminic 244 group; this is also consistent with the observation of only GL in the<sup>13</sup> C solid-state NMR spectra 245 of E+G NCs **(Fig. 4a)** . 

- 246 We further evaluate the BE of two interacting GL molecules, two interacting EDTA molecules, 

- 247 and an interacting E+G pair of molecules on the perovskite surface **(Fig. 5, Extended Data Fig.** 

- 248 **10)** .  The E+G pair has the highest binding energy, enhanced by a synergistic effect between GL 

- 249 and EDTA; intermolecular hydrogen bonding between carboxylic groups of GL and EDTA 250 provides extra stabilisation to these surface adsorbed molecules, leading to a BE of -4.45 eV 251 **(Extended Data Fig. 10)** . 

- 252 Our calculations confirm that this specific pairing of ligands leads to a strong affinity with the 

- 253 perovskite surface. We now assess how this influences the migration of halide species. Iodine 

- 254 Frenkel defects, which are iodide interstitial-vacancy pairs, are the most energetically probable 255 defects at the PbI2-terminated perovskite surface, with shallow formation energy (0.03 eV). We 

- 256 calculate the formation energy of an iodine Frenkel defect at the PbI2-terminated perovskite 

14 

- 257 surface in the presence of GL, E+G, or without passivating molecules, details in **Methods** . We 

- 258 find that GL surface passivation raises the iodine Frenkel defect formation energy to 0.15 eV, 

- 259 while E+G further increases the formation energy to 0.18 eV. This is significantly higher than 

- 260 calculated values for other passivating agents, for example, in the presence of polyethylene 

- 261 oxide, the formation of an interstitial iodine defect becomes less favourable by 0.08 eV, 262 compared to bare perovskite surface.<sup>32</sup> To summarise, the high calculated binding energy, 

263 coupled with the significant increase in the iodide Frenkel defect formation energy, suggests 264 that the GL and the combination of E+G ligands significantly inhibits undercoordinated Pb atoms 265 from stabilising these Frenkel defects<sup>49</sup> . Since halide Frenkel defects are expected to be the ionic 266 species responsible for halide segregation under illumination or device operation, our results 267 are consistent with suppressed defect formation suppressing halide segregation in E+G treated 

- 268 NCs. 

269 In conclusion, we have demonstrated that a lead-complexing multidentate ligand 270 treatment leads to bandgap stable red electroluminescence from mixed halide 271 perovskite NC-LEDs, with a peak EQE at 620 nm surpassing 20%. We have found that 272 stripping the NC surface of defects is part of the active role of the ligands. Furthermore, 273 we have shown that both ligand-ligand and ligand-surface interactions are important for 274 achieving a stable ligand shell on the NC surface, and the multidentate ligand 275 interactions with the surface greatly suppress surface defect formation. Beyond light 276 emission, our work here is likely to be broadly applicable to stabilising the bandgap of 277 mixed-ion metal halide perovskites for a range of applications, including multi-junction 278 photovoltaics, and will enable perovskites to deliver upon the promise of being 

- 279 remarkably versatile and tuneable semiconductors. 

15 

# 280 **Methods** 

- 281 All NC syntheses were carried out at ambient conditions in a fume hood. 

# 282 **Materials** 

- 283 All chemicals were used as received without further purification. Lead iodide (PbI 2) (99.99 %) 

- 284 was purchased from TCI Chemicals; methylammonium iodide (MAI) and methylammonium 

- 285 bromide (MABr) from Dyesol; oleic acid (99.0 %), oleylamine (70 %), methylamine (MA) solution 

- 286 (33% in absolute ethanol), ethylenediaminetetraacetic acid (anhydrous, ≥99%), and L- 

- 287 glutathione reduced (≥98.0%) from Sigma-Aldrich. All solvents such as toluene, acetonitrile, and 

- 288 methyl acetate were anhydrous and were purchased from Sigma-Aldrich. PEDOT:PSS (AI 4083), 

- 289 Poly-TPD, and TPBi were purchased from OSM. TFB was purchased from Ossila. 

# 290 **Preparation of Lead Mixed Halide Perovskite Precursor** 

- 291 Typically, a perovskite precursor solution was prepared according to our recent work (ref 5), 

- 292 where 922 mg of PbI2 and 223 mg of MABr were mixed with 4 mL of acetonitrile (ACN) and 

- 293 shaken to form a green-black suspension. Dry CH3NH3 (MA) gas was bubbled through the 

- 294 suspension to form a compound solvent, hereafter referred to as ACN/MA, detailed elsewhere 295 (ref 5). 

# 296 **Synthesis of MAPb(I1-xBrx)3 Perovskite NCs for Red Emission** 

- 297 The synthesis of the MAPb(I1-xBrx)3 NCs was carried out by injecting 0.2 mL of perovskite 

- 298 precursor dissolved in ACN/MA into ~60<sup>°</sup> C toluene containing 2 mL of OA and 0.2 mL OLA. The 

- 299 NCs immediately nucleated, turning the suspension red. The reaction was continued for 1-2 min 

- 300 to allow for crystal growth before the NC suspension was immersed into an ice bath. We 

16 

- 301 synthesised six batches of NCs simultaneously, collected them into three centrifuge tubes (each 

- 302 containing 10 mL of NCs), and the NCs were iteratively precipitated by adding 20 mL of 

- 303 anhydrous methyl acetate. The NCs were separated from excess unreacted ligands/precursors 

- 304 and purified by centrifugation at 8,000 rpm for 10 min, then re-dispersed into 5 mL toluene. We 

- 305 added 10 mL methyl acetate to each tube and repeated the purification process before the NCs 

- 306 were re-dissolved in toluene to a concentration of 40 mg mL<sup>-1</sup> for further characterisation. 

- 307 These purified NCs, capped with OA and OLA, are denoted as “neat NCs.” These neat NCs 

- 308 exhibit PL at 630 nm, and their tetragonal phase was confirmed by powder X-ray diffraction 

- 309 (PXRD), **Fig. 2f** . 

- 310 **Ligand Treatment of MAPb(I1-xBrx)3 Perovskite NCs** 

- 311 The NCs underwent two washing cycles with a methyl acetate mixture, as described above. Each 

- 312 NC batch was dispersed in 2 mL of toluene after the washing process. Six batches of washed NCs 

- 313 were combined to make a 12 mL (40 mg mL<sup>-1</sup> ) stock solution. This solution was centrifuged 

- 314 another time at 5,000 rpm for 5 minutes to remove aggregates and large particles. The collected 

- 315 supernatant was divided into two portions: one was used as the control neat sample, while the 

- 316 other was treated by a new ligand. Typically, 2 mmol of ligand was added to 3 mL of NCs in 

- 317 toluene and stirred overnight (~12 hrs) at room temperature. The unreacted ligand powder was 

- 318 separated from the NCs after ligand treatment by centrifugation at 8,000 rpm for 10 min. The 

- 319 collected supernatant was filtered using a PTFE syringe filter (Whatman, 0.2 µm) and stored for 

- 320 further characterisation and device work. 

- 321 **Transient Absorption Spectroscopy of MAPb(I1-xBrx)3 NCs** 

17 

- 322 A Ti:Sapphire laser (Coherent Astrella) operating at 1 kHz pumped an optical parametric 

- 323 amplifier (Light Conversion, Topas Prime Plus) to generate 520 nm pump pulses. The 800 nm 

- 324 fundamental was used to generate white light probe pulses in a sapphire plate. The TAS pump 

- 325 pulse energy was 106 μJ cm<sup>-2</sup> . The broadband probe pulse energies were 124 μJ cm<sup>-2</sup> and 146 μJ 

- 326 cm<sup>-2</sup> for the E+G and C films, respectively. Transient absorption spectroscopy (TAS) spectra were 

- 327 collected using a homebuilt instrument with 100 fs time resolution and pump-probe time delays 

- 328 of up to 800 ps. The TAS signal at alternate time delays was collected in ascending order, and 

- 329 the signal at the remaining time delays in descending order, to ensure that any changes in the 

- 330 sample during the scan were not systematically encoded into the transient. Each scan required 

- 331 50 s. 72 TAS spectra for each film were measured prior to 30 s of exposure to a 405 nm CW laser 

- 332 with the power density set at 7.09 W cm<sup>-2</sup> . The 405 nm laser also acted as the excitation source 

- 333 for the measurement of fluorescence spectra. Fluorescence was collected through a fibre optic 

- 334 cable (Thorlabs M53L01) by a portable spectrometer (Ocean Optics, Flame-T). After completing 

- 335 the exposure, the TAS instrument was initialised, a process that requires 40 s. TAS scans were 

- 336 then collected, with a few seconds of exposure to the 405 nm CW laser before and after each 

- 337 scan to compensate for the recovery of the halide migration during the TAS scan. This procedure 

- 338 was repeated for 60 TAS scans, **Extended Data Fig. 3** . 

- 339 Absorbance, fluorescence, and TAS measurements were performed on OA/OLA- and EG-capped 

- 340 NCs in spin-cast encapsulated films. The average wavelength of the fluorescence immediately 

- 341 before and after each TAS scan was used to estimate the average fluorescence wavelength 

- 342 during the scan. This estimates the average amount of halide segregation over 60 TAS scans. The 

- 343 duration of exposure to the 405 nm light after each scan was set to minimise the change in the 

18 

- 344 average fluorescence wavelength during the 60 TAS scans, shown in **Extended Data Fig. 3** . TAS 

- 345 measurements were performed on different spots on each film using different durations of 405 

- 346 nm exposure between TAS scans until a small standard deviation in the average fluorescence 

- 347 wavelength was achieved. This indicated that, with this additional irradiation, the NCs were not 

- 348 continuing to undergo further halide segregation nor recovery of segregation during the 60 TAS 

- 349 scans. 

- 350 **Calculation of the EQE-EL Limit** 

- 351 Our observed EQE-EL of more than 20% appears to be at the limit of what is feasible when 

- 352 considering optical outcoupling efficiencies from perovskite thin films in LED device structures<sup>50</sup> . 

- 353 However, the precise outcoupling efficiency depends strongly upon the refractive index of the 

- 354 emission layer, and furthermore, photon recycling can contribute to enabling waveguided light 

- 355 to be reabsorbed and externally emitted from the device.  In order to quantify this is in more 

- 356 detail, we firstly estimated the refractive index of our nanocrystal films using spectroscopic 

- 357 ellipsometry and estimate an n = ~1.82 @ 620nm. Considering a thin film on glass, with an n = 

- 358 1.82, and accounting for emission from both the perovskite/air and perovskite/glass interfaces, 

- 359 we determine an outcoupling efficiency of 32.4%. Our observations of a PLQY of 70% for such 

- 360 films is clearly in excess of this, but can be understood by accounting for photon recycling, 

- 361 following the procedure of Richter _et. al_<sup>51</sup> . For our films, with an outcoupling efficiency of 

- 362 32.4% and an external PLQY of 70%, we estimate an internal PLQY of 87.6% (We show further 

- 363 details of this calculation below). For the LEDs, this calculation is slightly more complicated since 

- 364 there are a larger number of material layers, there is a reflective rear electrode, and parasitic 

- 365 absorption can occur in the charge injection layers and electrode materials<sup>52</sup> . However, detailed 

19 

- 366 calculations have been made for organic light-emitting diodes with very similar device stacks 

- 367 and refractive indices for the materials used, including the emission layer at n~1.8. Putting out 

- 368 internal PLQY of 87.8% into the calculated escape cone efficiencies of Salehi _et. al_<sup>53</sup> results in an 

- 369 estimated EQE for EL of 32.4%. Therefore, our measured EQE-EL of 20% is entirely feasible, and 

- 370 there yet remains a capacity for further improvement. 

- 371 **Details of the internal PLQY calculation [**<sup>**Ref 51**</sup> **]:** 

- 372 Here we measure the PLQY of a perovskite film coated upon a glass slide measured in an 

- 373 integrated sphere. The light will be isotopically emitted within the perovskite film, and a certain 

- 374 fraction emitted within a specific solid-angle will escape from the front and back surface of the 

- 375 film, with a considerable fraction of the light totally internally reflected and reabsorbed in the 

- 376 plane of the film. Since the overlap of emission and absorption spectra are significant for these 

- 377 perovskite materials, we estimate that within a few tens of microns, more than 90% of the 

- 378 waveguided light will be reabsorbed and hence very little light will be emitted from the edges of 

- 379 perovskite film coated on the 2 × 2cm glass slides.  The analysis which we set out below, which 

- 380 includes realistic parameters, determines the relationship between measured PLQE and internal 

- 381 PLQE. The probability for a photon isotopically emitted from within one medium, to be 

- 382 transmitted through an interface between the medium within which it was emitted and the 

- 383 adjacent medium, with refractive indices  and  respectively, can be estimated as 

384 

20 

- 385 where ��esc<sup>is the escape solid angle, and T is the transmittance. An ellipsometry measurement</sup> 

- 386 estimates the refractive index of perovskite NC films to be ~1.82 @ 620 nm. Taking the 

- 387 refractive index of air, glass, and the perovskite NC film to be 1, 1.5, and 1.82 respectively, we 

- 388 estimate the transmission probability of a photon from the above equation for the perovskite- 

- 389 air interface to be 6.9 % and the perovskite-glass interface to be 16.8 %. 

- 390 We assume the optical density of the NC films to be 0.02 at the PL emission wavelength of 

- 391 620 nm (or 2 eV). Before reaching an interface, photons will, on average, have travelled through 

- 392 an optical density of 0.01. Of the total photons emitted, 16.8% of the photons will be traveling 

- 393 towards the perovskite/glass interface within the escape cone, and 6.9% of the photons will be 

- 394 traveling towards the perovskite/air interface within the escape cone.   The photons emitted 

- 395 towards the perovskite/air interface, but within the solid-angle in between the perovskite/air 

- 396 and perovskite/glass escape cones (which accounts for 16.8%–6.9% = 9.9% of the 

- 397 photons), will be reflected off the perovskite/air, and then escape out of the perovskite/glass 

398 interface. Therefore, accounting for the small attenuation due to self-absorption, the total 

- 399 escape probability for the perovskite NC films is estimated to be 

400 

- 401 Following Richter _et. al_ ’s equation 3,<sup>51</sup> the relation between internal PLQY (), and measured 

- 402 PLQY () is given by 

403 

21 

- 404 Substituting the measured external PLQY of 70%, ( ) and total escape probability of 32.4%, (), we 

- 405 obtain internal PLQY () = 0.878 or 87.8%. We note that this expression accounts for the photon 

- 406 recycling and illustrates that the external measured PLQY can deviate considerably from the 

- 407 internal PLQY. 

## 408 

# **ICP-MS Analysis** 

- 409 To support the existence of this “stripped” Pb-ligand (EDTA, GL) complex in the sediment, we 

- 410 have performed an ICP-MS analysis of the resulting precipitates (which includes the potential 

411 Pb-ligand complex and undissolved ligand) after repeated washing with toluene (10 times). As 412 both EDTA and GL have very low solubility in toluene, this process effectively disperses and 413 removes the remaining NCs while retaining the Pb-ligand complexes in the residue. To rule out 

414 the spurious lead content arising from remaining NCs, toluene supernatant from the final 415 washing step was also subjected to ICP analysis. The result clearly shows an increasing quantity 416 of precipitate lead content in the order of GL (518 μg mg<sup>-1</sup> )>EG (428 μg mg<sup>-1</sup> )>EDTA (354 μg mg<sup>-</sup> 417 1)-treated samples when compared to the final supernatant (nearly 0 ug mg -1). To estimate 418 whether EDTA and GL have different Pb<sup>2+</sup> complexation ability, we calculated the 419 binding energy between the two ligands and a Pb<sup>2+</sup> ion, see **Extended Data Figure 10** . 420 The complexes show a hemidirected coordination of the ligands, with EDTA endowed 421 with a significantly higher binding energy to Pb<sup>2+</sup> than GL, by 0.80 eV. 

- 422 **Fabrication of MAPb(I1-xBrx)3 NC LEDs** 

423 Our final device stack, for which a schematic and a SEM cross-sectional image is 424 shown in **Fig. 3a and b** , includes a “triple-layer” hole-injection layer, comprising 425 Poly(3,4-ethylenedioxythiophene):poly( _p_ -styrene sulfonate) (PEDOT:PSS), Poly[N,N’– 

22 

426 bis(4-butylphenyl)-N,N’-bisphenylbenzidine] (poly-TPD) and the deep work-function 427 polymer - poly[(9,9-dioctylfluorenyl-2,7-diyl)-co-(4,4’-(N(4-sec- 

428 butylphenyl)diphenylamine)] (TFB), followed by a thin dense layer of the perovskite NCs 429 (~ 30nm), capped with the electron transport layer of 2,2',2"-(1,3,5-Benzinetriyl)-tris(1430 phenyl-1-Hbenzimidazole) (TBPi) and a lithium fluoride/aluminium cathode. Typically, 431 Indium tin oxide (ITO)-coated glass substrates were cleaned by an ultra-sonification 432 process in deionised water, acetone, and isopropanol for 10 min. PEDOT:PSS was spin433 coated onto an ITO substrate at 5,000 rpm for 40 s. The coated substrates were 434 transferred to an N2-filled glove box and annealed at 140 °C for 10 min. Poly-TPD 435 solution (15 mg ml<sup>-1</sup> ) in chlorobenzene and TFB solution (20 mg mL<sup>-1</sup> ) in p-xylene was 436 sequentially spin-coated onto the substrates at 4,000 rpm for 40 s. Each layer was 437 annealed at 140 °C for 30 min. The MAPbI2Br NCs were spin-coated onto the 438 substrates at 2,000 rpm for 40 s. 70 nm thick layer of TPBi, 1 nm thick layer of LiF, and 439 80 nm thick layer of Al were sequentially deposited using a thermal evaporation system. 

440 **Solid-state 13C NMR** 

441 Solid-state<sup>13</sup> C MAS NMR was performed at 9.4 T (KBSI Western Seoul Center) using a 4 mm 

- 442 Bruker triple resonance probe. The prepared nanocrystals were packed into reduced volume 

- 443 zirconia rotors under nitrogen atmosphere and were spun at 8 kHz.<sup>13</sup> C data were acquired by 

444 1H-13C Hartmann-Hahn cross polarization sequence with 100 kHz SPINAL64 1H decoupling. 

- 445 

# **Solution HNMR** 

- 446 In order to assess the interaction between the ligands and Pb<sup>2+</sup> , we measured<sup>1</sup> H NMR 447 spectra of the ligands mixed with PbI2. In **Fig. 4b** , we have annotated structural 

23 

- 448 diagrams of the ligands, indicating the different moieties responsible for the NMR 

- 449 resonances and the different binding units present in GL, namely, glutamine (glu), 

- 450 cysteine (cys) and glycine (gly). In **Fig. 4c** and **Extended Data Fig. 9,** we observe that both 

- 451 1H signals from EDTA shift downfield and broaden, indicating multidentate complexation 

- 452 of EDTA to Pb<sup>2+</sup> . We mixed GL and PbI2 in _d_ -DMSO and observed two changes: (i) significant 

453 broadening and increased chemical shifts of the cysteinyl β cys resonance and (ii) decreased 

454 chemical shifts of the amide NHcys resonances. The first change indicates that Pb<sup>2+</sup> binds to 

455 cysteinyl sulphur<sup>54,55</sup> . The shift of amide NHcys resonances is likely caused by the coordination of 

456 the amide NH to the S-bound Pb<sup>2+</sup> , as demonstrated for the case of chemically similar Cd<sup>2+</sup> 457 binding to GL<sup>56</sup> .  We also observe a weakening of the geminal<sup>2</sup> J coupling of glutamine’s beta 

- 458 protons (βglu), indicating that the COOH is also bound to Pb<sup>2+</sup> . The glycine’s alpha proton (αgly) 

- 459 displayed no observable shift upon addition of PbI2, in agreement with previous work showing 

- 460 that the COO<sup>-</sup> group of glycine does not bind to Pb<sup>2+57</sup> .  In **Extended Data Fig. 9** we show the<sup>1</sup> H 

461 NMR spectra when both ligands (E+G) are mixed with PbI2. We observe that all of the 

- 462 interaction changes present in the solutions containing the individual ligands are also present 

463 with the combined ligands, indicating that when both ligands are combined in the E+G mixture, 

464 they maintain their individual interactions with PbI2. We show the proposed molecular 465 interactions of the E+G ligands with Pb<sup>2+</sup> on the NC surface in **Fig. 4d** . We conclude that both 

- 466 EDTA and GL can coordinate with Pb<sup>2+</sup> via the aforementioned binding groups in this system. 

- 467 **DFT approach:** 

468 We model the interaction of glutathione (GL) and EDTA on perovskite surfaces by the state-of- 

- 469 the-art DFT calculations, including dispersion interactions, to mimic the surface chemistry of 

24 

- 470 perovskite NCs. Due to the uncertain nature of surfaces and their terminations in mixed halide 

- 471 perovskites, we focus here on MAPbI3, for which we have a trustful surface picture. We will 

- 472 evaluate in due course the possible impact on the results of considering a single halide in place 

- 473 of a mixed halide. All our results are obtained considering a PbI2-terminated surface, which is 

- 474 representative of the extreme situation of a fully unpassivated perovskite surface exposing 

- 475 undercoordinated surface Pb atoms. 

- 476 We proceed based on the following reasoning: 

- 477 1) halide demixing is triggered by defect formation and/or migration. 

- 478 2) most defects and migration channels are on surfaces, so surface passivation blocks defect 

- 479 formation, ion migration, and demixing. 

- 480 3) surface passivation molecules should bind effectively to the perovskite surface and pack 

- 481 tightly, thus being an effective migration blocker. 

- 482 4) We consider the adsorption of single GL and EDTA molecules and then move to GL-GL, EDTA- 

- 483 EDTA, and GL-EDTA coadsorption. 

- 484 Since GL is quite a complex molecule, we initially model what chemical fragment within GL is 

- 485 most strongly interacting with the perovskite surface. 

- 486 Thus, we decomposed GL and EDTA into the possible binding moieties and calculated the 

- 487 fragments binding energy (BE) to the perovskite, see **Extended Data Fig.10** . The binding energy 

- 488 is defined as: **BE=E(mol@surface) – E(mol) – E(surface) (1)** 

- 489 The results show that the ammidic fragment of GL is the most strongly binding one; see 

- 490 **Extended Data Fig. 10** . Typically, the calculated BE of GL is very high (-1.85 eV), coming from a 

- 491 partial sum of all binding ingredients. EDTA interaction with the perovskite shows a lower BE 

25 

- 492 than GL (-1.60 vs. -1.85 eV), with EDTA mainly binding through carboxylic groups. Although the 

- 493 tertiary amminic groups may show a higher BE to Pb than COOH ( **Extended Data Fig. 10** ), steric 

- 494 hindrance prevents EDTA from exploiting such interaction. 

- 495 To evaluate the energetics of forming a compact monolayer on the perovskite surface, thus 

- 496 effectively blocking all possible undercoordinated Pb atoms acting as defect-nucleating centres 

- 497 we next evaluated the BE of two interacting GL, two interacting EDTA, and an interacting 

- 498 GL/EDTA pair on the perovskite surface. In the case of two or more interacting molecules, the 

- 499 BE includes both surface-molecule and molecule-molecule interactions. The E+G pair was found 

- 500 to have the highest binding energy, enhanced by a synergistic effect between GL and EDTA. 

- 501 Intermolecular hydrogen bonding between carboxylic groups of the GL and EDTA provides extra 

- 502 stabilisation to these surface adsorbed molecules, leading to a BE of -4.45 eV ( **Extended Data** 503 **Fig. 10** ). 

- 504 Most notably, while both GL and EDTA may form a compact monolayer on the perovskite 

- 505 surface, _the strongest interaction comes from the synergistic binding of GL and EDTA_ , for which 

- 506 the highest BE to the perovskite surface is calculated. Notice that in the case of two (or more) 

- 507 interacting molecules, the BE includes surface/molecule and molecule/molecule interactions, 

- 508 delivering s total BE higher than the sum of the two individual BEs. In the E+G case, the 

- 509 intermolecular contribution, related to intermolecular hydrogen bonding between carboxylic 

- 510 groups, provides an extra stabilisation to the surface adsorbed molecules, delivering the highest 

- 511 BE (-4.45 eV), higher than the GL/GL and EDTA/EDTA BEs; see **Extended Data Fig. 10** . 

- 512 To connect the calculated BEs to the defect-blocking properties of the respective surface- 

- 513 adsorbed molecules, we have considered the energetics for formation of iodine Frenkel defect 

26 

- 514 pair ( _i.e._ iodine vacancy / interstitial iodine) at the surface. These defects are the energetically 

- 515 most probable defects at the PbI2-terminated perovskite surface; thus, they constitute a case 

- 516 study to evaluate the impact of surface adsorbed molecules on defect formation energies. We 

- 517 thus calculated the formation energy of an iodine Frenkel defect pair at the PbI 2-terminated 

- 518 perovskite surface without passivating molecules and in the presence of GL and of E+G. 

- 519 Formation of an iodine Frenkel defect on the PbI2-terminated perovskite surface has very low 

- 520 formation energy (0.03 eV), in line with the instability of the unpassivated surface (complete 

- 521 surface passivation by MAI raises the formation energy to 0.84 eV). GL surface passivation raises 

- 522 the formation energy to 0.15 eV, with E+G further raising it to 0.18 eV. This clearly demonstrates 

- 523 the GL surface defect blocking effect and the synergistic E+G effect. To put this value into 

- 524 context, when modelling the PEO interaction with the same perovskite surface, we calculated a 

- 525 defect formation energy increase of 0.08 eV for a complete monolayer of (CH 3OCH3, mimicking 

- 526 PEO) thus, the values obtained here for GL and E+G are to be considered extremely high. 

- 527 To sum up, we have evaluated the binding of GL, EDTA, and E+G on the perovskite surface and 528 evaluated their ability as Frenkel defect blocking agents. The results show a synergistic effect of 529 GL+EDTA in delivering the highest surface binding energy and the highest defect blocking 

- 530 activity. The key to efficient surface passivation is the concurrent action of strong 

- 531 molecule/surface and molecule/molecule interactions. 

- 532 All simulations have been carried out with the Quantum Espresso program package<sup>57</sup> . DFT 

- 533 calculations have been carried out on the (001) MAPbI3 surface within the supercell approach 

- 534 by using the Perdew-Burke-Ernzerhof (PBE)<sup>58</sup> functional by using ultrasoft pseudopotentials 

535 (shells explicitly included in calculations: I 5s, 5p; N, C 2s, 2p; O 2s 2p; H 1s; Pb 6s, 6p, 

27 

- 536 5d; S 3s 3p) and a cutoff on the wavefunctions of 25 Ryd (200 Ryd on the charge 

- 537 density). DFT-D3 dispersion interactions were included in the calculation<sup>58</sup> . 

- 538 Slabs models have been built starting from the tetragonal phase of MAPbI 359 by fixing cell 

- 539 parameters to the experimental values and generating a 2x2 supercell in a and b directions. A 10 

- 540 Å of vacuum was added along the non-periodic direction perpendicular to the slabs in all cases. 

- 541 A symmetric disposition of the organic cations on the external layers of the slabs has been 

- 542 adopted in all cases, leading to supercells with zero average dipole moments. Such an 

- 543 arrangement of organic cations provided a flat electrostatic potential in the vacuum region of 

- 544 the supercells for all the modelled slabs. 

- 545 

# **Methods extended reference list:** 

- 546 50 Zhao, B. _et al._ High-efficiency perovskite–polymer bulk heterostructure light547 emitting diodes. _Nature Photonics_ **12** , 783-789, doi:10.1038/s41566-018-0283-4 548 (2018). 

- 549 51 Richter, J. M. _et al._ Enhancing photoluminescence yields in lead halide 550 perovskites by photon recycling and light outcoupling. _Nature Communications_ **7** , 551 13941, doi:10.1038/ncomms13941 (2016). 

- 552 52 Cho, C. _et al._ The role of photon recycling in perovskite light-emitting diodes. 553 _Nature Communications_ **11** , 611, doi:10.1038/s41467-020-14401-1 (2020). 

- 554 53 Salehi, A., Chen, Y., Fu, X., Peng, C. & So, F. Manipulating Refractive Index in 555 Organic Light-Emitting Diodes. _ACS Applied Materials & Interfaces_ **10** , 9595556 9601, doi:10.1021/acsami.7b18514 (2018). 

- 557 54 Sisombath, N. S. & Jalilehvand, F. Similarities between N-Acetylcysteine and 558 Glutathione in Binding to Lead(II) Ions. _Chemical Research in Toxicology_ **28** , 559 2313-2324, doi:10.1021/acs.chemrestox.5b00323 (2015). 

- 560 55 Mah, V. & Jalilehvand, F. Lead(II) Complex Formation with Glutathione. _Inorganic_ 561 _Chemistry_ **51** , 6285-6298, doi:10.1021/ic300496t (2012). 

- 562 56 Delalande, O. _et al._ Cadmium–glutathione solution structures provide new 563 insights into heavy metal detoxification. _The FEBS Journal_ **277** , 5086-5096, 564 doi:10.1111/j.1742-4658.2010.07913.x (2010). 

- 565 57 Giannozzi, P. _et al._ QUANTUM ESPRESSO: a modular and open-source 566 software project for quantum simulations of materials. _Journal of Physics:_ 567 _Condensed Matter_ **21** , 395502, doi:10.1088/0953-8984/21/39/395502 (2009). 

- 568 58 Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized Gradient Approximation 569 Made Simple. _Physical Review Letters_ **77** , 3865-3868, 570 doi:10.1103/PhysRevLett.77.3865 (1996). 

28 

- 571 59 Poglitsch, A. & Weber, D. Dynamic disorder in ‐ 

- 572 methylammoniumtrihalogenoplumbates (II) observed by millimeter wave 573 spectroscopy. _The Journal of Chemical Physics_ **87** , 6373-6378, 574 doi:10.1063/1.453467 (1987). 

- 575 

# **FIGURE LEGENDS:** 

576 **Figure 1. Illustration of NC synthesis. a,** Synthesis and ligand treatment steps: (i) Dissolution of 577 perovskite precursors in acetonitrile (ACN) and methylamine (MA), (ii) NC synthesis by modified 578 LARP, and (iii) post-synthetic ligand treatment. **b** , chemical structures of ligands used. 

579 **Fig. 2. Impact of ligand treatment on the solution photoluminescence and NC** 580 **structural properties. a,** Absorption and PL spectra of as-synthesised MAPb(I 1-xBrx)3 581 NCs in solution. **b,** PL spectra of NC films following post-synthetic treatment with GL, 582 EDTA, and EDTA + GL (E+G). **c,** Excitation fluence dependence of PLQE of NC thin 583 films before and after ligand treatment, measured in an integrating sphere. **d,e** , High584 resolution transmission electron micrograph (HR-TEM) image for NCs before and after 585 ligand treatment with E+G, respectively. **f,** XRD for the NCs films before and after ligand 586 treatment. **g,h** , Decay associated difference spectra from a global fit of TAS 587 measurements of neat- and E+G-capped NCs, respectively. Solid and dashed lines are 588 spectra before and after 30 s of exposure to a 7.1 W cm<sup>-2</sup> 405 nm CW laser. Blue, 589 green, and red traces correspond to decay components with time constants of ~400 fs, 590 ~14 ps, and ~280 ps, respectively. Red arrows indicate the red edge of the spectra, 591 where changes in the bandgap of the material would result in changes to the bleaching 592 of the sample due to band filling. 

593 **Figure 3. Device characterisation of mixed halide MAPb(I1-xBrx)3 NC-LEDs: a,** Schematic 594 illustration of MAPb(I1-xBrx)3 NC-LED architecture and scanning electron microscopy (SEM) 595 image showing the cross section of a device; thickness of each layer is confirmed by SEM image: 596 PEDOT:PSS/Poly-TPD/TFB HTLs (30 nm), NC emission layer (20 nm), TPBi ETL (70 nm), LiF/Al 597 electrode (80 nm). **b,** Energy band diagram of the materials employed in these LEDs, from 598 references<sup>44-46</sup> . Operational characteristics for LEDs incorporating neat and E+G ligand treated 599 NC layers; **c,** Current density–voltage and luminance(L)-voltage curves, **d,** EQE-current density 600 curves, **e,** device performance parameters of best-performing LEDs (LE is luminous efficiency) **. f,** 601 EL spectra at different time intervals for LEDs held at a constant current density of 1.5 mA cm<sup>-2</sup> 602 **g,** EL spectra at different current densities (mA cm<sup>-2</sup> ). 603 

604 **Figure 4. Characterisation of ligand-NC surface interactions using NMR spectroscopy: a,** 605 Molecular structure of EDTA and GL. Peaks a and b are characteristic of CH 2 as labelled in the 606 molecular structure of EDTA while peaks ,  and  are characteristic of CH2 in GL. **b** ,<sup>13</sup> C solid607 state NMR spectra of neat and ligand (GL, EDTA, E+G) treated NCs. Insets show ligand structure. 608 **c,** Solution<sup>1</sup> H NMR spectra of E+G with and without PbI2 in d-DMSO solutions. **d,** Proposed 609 molecular interactions of GL and EDTA with Pb<sup>2+</sup> atoms on the NC surface. 

610 **Figure 5.** Optimised structures of two interacting surface adsorbed **a,** GL, **b,** EDTA, and **c,** one GL 611 and one EDTA molecule, along with calculated total biding energies (E b) and their intermolecular 612 contribution (Einter) in eV calculated with respect to the isolated surface adsorbed molecules 

29 

613 (Eb=1.85 and 1.60 eV for GL and EDTA, respectively). **d,** Optimised structure of an iodine Frenkel 614 defect pair – defective sites highlighted by red and blue circles - in the presence of adsorbed 615 GL+EDTA along with the increase of defect formation energy compared to the unpassivated 616 surface (EFrenkel, in eV). 

617 **Extended Data Figure 1. Extended Data Figure 1. Characteristics of NCs with and** 618 **without ligand treatment.** : Photothermal deflection spectroscopy (PDS) spectra of 619 perovskite neat NCs vs. NCs-treated with EDTA+GL films deposited on quartz 620 substrates. The inset shows the calculation of the average Urback energy for these two 621 samples. Time-resolved PL decay of neat NCs and NCs treated with EDTA+GL **b** , solution 622 dispersed in toluene, and **c** , films. **d,** time-resolved photoluminescence corresponding lifetimes 623 of the neat NCs, and E+G-treated NCs. **e,** FTIR for MAPb(IxBr1-x)3 perovskite NCs: drop-casted 624 films from NCs synthesised in oleic acid and after the treatment with EDTA, GL, or E+G ligands. **f** , 625 XPS results for NCs before and after ligand treatment, which shows the ligand-treated 626 NC final product approximately corresponds to MAPb(I0.4Br0.6)3, whereas the original 627 perovskite NC was synthesized using the composition of MAPb(I0.67Br0.33)3. 

- 628 **Extended Data Figure 2. High-resolution transmission electron micrograph (HR-TEM)** 629 **images for NCs.: a-b** ,HR-TEM image for neat NCs. **c,** fast Fourier transformation (FFT) of the 630 selected region in panel (b), where interplanar lattice spacing of cubic phase is spaced by 0.6 631 and 0.42 nm for the {001}, and {110} family of planes. **d-e,** HR-TEM image for neat NCs after 632 ligand treatment with E+G ligands. **f,** FFT of the selected region in panel (e) showing a similar 633 cubic structure as neat NCs. 

634 **Extended Data Figure 3** . **Impact of ligands upon the photoluminescence and** 635 **nanocrystal structural properties. a** , Schematic of TAS procedure. Coloured circles 636 represent PL measurements before (black) and after (red) illumination with a 405 nm laser. 637 Duration of periodic re-exposure, T (10 s for neat, 3 s for E+G-treated NCs), maintained a stable 638 PL wavelength during TAS scans. For neat NCs, PL wavelength was initially 649 nm, 669±1 nm 639 after exposure. PL of E+G-treated NCs was initially 628 nm, 632±1 nm after exposure. TAS of 640 neat/E+G-treated NCs before ( **b** / **d** ) and after ( **c** / **e** ) illumination. Transients of neat/E+G-treated 641 NCs before ( **f,g** / **j,k** ) and after ( **h,i** / **l,m** ) illumination. Traces are average signal in wavelength 642 ranges chosen to highlight wavelength-dependent dynamics. Blue, green, yellow, red traces for 643 the neat NCs/E+G-treated NCs correspond to 560-600/550-580 nm, 600-640/580-610 nm, 640644 680/610-640 nm, 680-720/640-670 nm. Black dashed lines are global fit to a tri-exponential 645 function. **n** , Time constants before (after) illumination of each NC sample, found by a global fit 646 of TA spectra. Colours refer to those in Figure 2 ( **g** , **h)** . 

647 **Extended Data Figure 4. Halide segregation in diluted neat NCs.** Normalized 648 photoluminescence spectra of spin-cast films of neat NCs and polymethyl methacrylate 649 (PMMA), in a NC:PMMA mass ratio of **a,** 1.03 and **b,** 0.006. A 405 nm CW laser was 650 used as an excitation source and caused halide segregation, with the duration of 651 irradiation indicated in the legend. The redshifted shoulder developed during irradiation 652 is ascribed to the recombination from within an iodide-enriched minority phase with a 653 smaller bandgap. The redshifted shoulder showed no dependence on the NC 654 concentration in the film, indicating that segregation can occur in isolated NCs. **c,** 

30 

- 655 Confocal PL images and **d,** normalized PL spectrum of spin-cast films of neat NCs over 656 time under constant excitation with 405 nm CW laser. PL spectrum was obtained from 657 selected region of panel (c). **e,** Confocal PL images and **f,** normalized PL spectrum of 658 spin-cast films of neat NCs and PMMA, in a NC:PMMA mass ratio of 0.001 over time 659 under constant excitation with 405 nm diode laser. PL spectrum was obtained from 660 selected region of panel (e). 

- 661 **Extended Data Figure 5. EL spectra stability in the mixed halides MAPb(IxBr1-x)3 NC-LEDs with** 662 **different ligand treatment.: a,** Current density–voltage (J–V) curves **b** , luminous (L) versus 663 voltage (V–L) curves **c** , EL-EQE curves of NC-LEDs current density (J–EQE) **d-f** , EL spectra of NC664 LEDs at different bias voltage. **g-I** , EL spectra of NC-LEDs with different ligand treatment at a 665 constant current density of 10 mA cm<sup>-2</sup> **j-l,** EL spectra of the second ligand treated NC-LEDs with 666 1- adamantane carboxylic acid (ADAC) at a constant current density of 10 mA cm<sup>-2</sup> . 

- 667 

- 668 **Extended Data Figure 6. Characteristics of NCs films with the different charge-transporting** 669 **layers (CTLs).: a,** Time-resolved photoluminescence decays of E+G-treated NCs films with 670 various CTLs (excitation at 450 nm), (PNCs: perovskite NCs, PD: PEDOT:PSS, P-TPD: Poly-TPD). **b** , 671 photoluminescence intensities of E+G-treated NCs films with various CTLs (excitation at 350 672 nm). PL decays significantly faster, and PL intensity is reduced in the presence of a poly-TPD hole 673 transporting layer (HTL), while little change is observed with a TPBi electron transporting layer 674 (ETL). This result shows that exciton quenching significantly affects the interface between poly675 TPD and the NCs, resulting in a deterioration of device efficiency. **c,** Time-resolved 676 photoluminescence decays of E+G-treated NCs films with various HTLs (excitation at 450 nm). **d** , 677 photoluminescence intensities of E+G-treated NCs films with various HTLs (excitation at 450 678 nm). TFB HTLs show longer PL decays and larger PL intensity compared to the Poly-TPD HTLs, 679 indicating less exciton quenching at the interface between NCs and TFB HTLs. **e,** Photoemission 680 cut off energy, and **f,** the valence-band region of neat and E+G-treated NCs from ultraviolet 681 photoemission spectroscopy (UPS) spectra. **g–h** , Optical band gap of Neat NCs, and E+G-treated 682 NCs. 

- 683 **Extended Data Figure 7. Device characteristics and EL spectra stability in the** 684 **mixed halides MAPb(IxBr1-x)3 NC-LEDs.: a** , Schematic illustrations of the NC-LED 685 configuration showing the device architecture: ITO/PEDOT:PSS/poly-TPD/MAPb(I1-xBrx)3 686 NCs/TPBi/LiF/Al. **b** , Current density–voltage (J–V) curves, and luminous (L) versus 687 voltage (V–L) of NC-LEDs. **c** , luminous efficiency (LE) versus current density (J–LE) 688 curves of NC-LEDs. **d** , EL-EQE curves of NC-LEDs current density (J–EQE). **e-f** , EL 689 spectra of OA-LEDs, E+G-treated NC-LEDs at different bias voltage. **g** , EL peak of OA690 LEDs, E+G-treated NC-LEDs at different current density. **h-i** , EL peak of OA-LEDs, 691 E+G-treated NC-LEDs at a constant current of 0.5 mA cm<sup>-2</sup> for one hour, and EL peak of 692 same device rest in the glove box for different times. Shifted EL peak position under the 693 constant current density of 0.5 mA cm<sup>-2</sup> recovers to the initial peak position after rest in 694 the glove box for 6 hours, indicating the reversibility of halide segregation. 

- 695 **Extended Data Figure 8: Peak EQE histogram and operation stability of mixed halides** 696 **MAPb(IxBr1-x)3 NC-LEDs. a,** The peak EQE histogram E+G-treated NC-LEDs was collected 

31 

697 from 25 devices. **b,** Operational stability of E+G-treated NC-LEDs measured in air at a 698 constant current of 0.1 ( _L_ 0 = 30 cd m<sup>-2</sup> , EQE0 = 16.4%), 1 ( _L_ 0 = 150 cd m<sup>-2</sup> , EQE0 = 9.1%), and 10 699 mA cm<sup>-2</sup> ( _L_ 0 = 600 cd m<sup>-2</sup> , EQE0 = 3.3%). EL spectra of NCs-LEDs with neat **c,d** , and E+G 700 ligand treated **h,I** , NC layers at a different lifetime of _T_ x with a constant current density of 1 mA 701 cm<sup>-2</sup> and 10 mA cm<sup>-2</sup> . 

702 **Extended Data Figure 9** **_._**<sup>**1**</sup> **H NMR spectra of solutions: a** , MAPb(IxBr1-x)3 NCs before and after 703 an treatment with E+G mixture in d-toluene. **b,** Magnification selected region of the 1H-NMR 704 spectra between 5.4 and 5.6 ppm in panel a, showing details of the proton bound to C=C of 705 OA/OLA in; reveals fine structure on top of the broad resonance after ligand treatment, which is 706 an indication of (OA/OLA) free ligands. **c,** systematic addition of E+G to PbI2 in d-DMSO 707 solutions. **d–e** , EDTA, GL and E+G ligands in d-DMSO, and D2O, respectively, where when both 708 ligands are combined in the E+G mixture, they maintain their individual peaks’ positions, 709 indicating there is no chemical interaction between the two ligands. **f,** GL in d-DMSO versus in d- 710 DMSO mixture with D2O showing the disappearing of amide NH, exchangeable protons, peaks in 711 the presence of D2O. **g–h** , systematic addition of EDTA, and GL to PbI2 in d-DMSO solutions, 712 respectively. 

713 **Extended Data Figure 10** . **DFT-optimised structures of surface adsorbed ligands: a,** Structure of 714 GL (left) and EDTA (right) along with fragments used to study its interaction with the perovskite. 715 DFT-optimised structures of surface absorbed **b,** GL, **c,** EDTA, **d,** one GL, and one EDTA molecule, 716 **e,** two EDTA molecules, **f,** and two GL molecules. The optimised structure of an iodine Frenkel 717 defect pair – defective iodine atoms in yellow – **g,** on the bare PbI2-terminated perovskite 718 surface, **h,** in the presence of adsorbed GL and, **i,** in the presence of adsorbed GL+EDTA. The 719 iodine vacancy is highlighted with the dashed circle. **j,** Binding energies of fragments and 720 complete molecules to the PbI2-terminated perovskite surface. Data in parenthesis shows the 721 data per adsorbed molecule. **k,** DFT-optimised structures of the [Pb(EDTA/GL)]<sup>2+</sup> complexes and 722 the relative binding energy showing stronger binding of EDTA to Pb<sup>2+</sup> than GL by 0.80 eV. 723 

# 724 **Online content** 

- 725 Any methods, additional references, Nature Research reporting summaries, source data, 

- 726 statements of data availability and associated accession codes are available at (link). 

- 727 

# **Acknowledgements** 

- 728 This work was partially funded by the Engineering and Physical Sciences Research Council 

- 729 (EPSRC) U.K. through Grants EP/M005143/1 and EP/M015254/2. This work is part of the 

32 

- 730 PEROCUBE project, which has received funding from the European Union’s Horizon 2020 

731 research and innovation program under grant agreement No. 861985. A.S., H.S., Y.H., R.S. 732 and R.H.F. acknowledge funding and support from the SUNRISE project 733 (EP/P032591/1), EPSRC. A.S. and R.H.F. acknowledge support from UKIERI project. 734 A.S. acknowledges funding and support from DST, IISc and MHRD. R.S. acknowledge 735 The Royal Society - Newton International Fellowship. M.L.C. acknowledges financial 736 support from Achievement Rewards for College Scientists (ARCS) Foundation, Oregon Chapter. 737 This study was partially supported by the National Research Foundation of the Republic of 738 Korea (NRF-2018R1C1B6005778, 2018R1A2B2006198, 2020R1A4A1018163, and 739 2019R1A6A1A10073437) and the Materials Innovation Project (NRF-2020M3H4A3081793) 740 funded by National Research Foundation of Korea. NMR data were acquired on 400MHz Solid 741 state NMR spectrometer (AVANCE III HD, Bruker, Germany) at KBSI Western Seoul Center. The 742 experiments of HR-TEM, XPS, NMR, confocal PL and SEM were supported by UNIST Central 743 Research Facilities (UCRF). Y.H. would like to thank Dr Dr. Mohsen Danie for assistance with 

744 TEM, Safwat M. Rabea, Dr Tarek S. Ibrahim, Dr Ahmed M. Ali and Dr Trevor Janes for assistance 

- 745 with NMR analysis, and to Dr. Mohammed Nour Ahmed for his advice on Figure 1. Y.H. 

746 acknowledges funding and support from LXT AI (Canada). 

747 **Author contributions** 

748 Y.H. initiated the project, synthesised the NCs, conceived the multidentate ligand 749 approach developed and performed the ligand treatment process and performed with 750 J.H.P. the TEM, UV–vis absorption, photoluminescence, and XRD measurement. Y.H. 751 and H.J.S. planned the experiments and overall project targets. Y.H. coordinated 

33 

- 752 collaboration efforts. J.H.P. fabricated LED devices. A.S. assisted in the NCs synthesis 

753 and performed the PLQY and Photothermal deflection spectroscopy (PDS) 754 measurements. R.S. assisted with the PLQY and PDS measurements. Y.H, M.L.C. M.J., 755 C.Y., and J.L. performed the NMR experiments and analysed its data. J.H.P. measured 756 the STEM and Y.H. performed their analysis. J.H.P. and B.R.L. assisted with the 757 materials and LED characterisation process. M.H.S., H.C., S.H.P., and B.R.L. supported 758 the material, and device characterisations. J.H.P., and B.R.L. carried out the device 759 stability tests. M.L.C. and J.C.S. designed and executed the TA experiments and M.L.C. 760 performed data analysis. E.M., E.R., and F.D.A conducted the computational 761 simulations. C.Y.W., B.R.L., R.H.F., and H.J.S. supervised the work undertaken in their 762 laboratories, which has contributed to this manuscript. Y.H. drafted the first version of 763 the manuscript, with assistance from J.C.S., C.Y.W., and H.J.S.. All the authors have 764 read and commented upon or contributed to the writing of the manuscript. Y.H. and 765 J.H.P. contributed equally to this work. 

766 **Competing interests:** The authors declare the following competing financial interest: HJS is a co- 

767 founder of Oxford PV ltd, which is commercialising perovskite-based photovoltaics. HJS and RHF 

768 are co-founders of Helio Display Materials Ltd, which is commercialising perovskite materials for 

- 769 light-emitting applications. 

- 770 Additional Information (Extended Data information is available for this paper at (link) 

- 771 **Reprints and permissions information** is available at <u>www.nature.com/reprints.</u> 

- 772 **Correspondence and requests for materials** should be addressed to Y.H. or H.J.S. 

- 773 Yasser Hassan: <u>Yasser.hassan@physics.ox.ac.uk; yasserhassan8085@gmail.com</u> 

34 

- 774 Cathy Wong: <u>cwong3@uoregon.edu</u> 

- 775 Bo Ram Lee: <u>brlee@pknu.ac.kr</u> 

- 776 Henry Snaith: <u>henry.snaith@physics.ox.ac.uk</u> 

- 777 **Publisher’s note:** Springer Nature remains neutral with regard to jurisdictional claims in 

- 778 published maps and institutional affiliations. 

# 779 **References** 

- 780 1 Tan, Z.-K. _et al._ Bright light-emitting diodes based on organometal halide 781 perovskite. _Nat Nano_ **9** , 687-692, doi:10.1038/nnano.2014.149 

- 782 <u>http://www.nature.com/nnano/journal/v9/n9/abs/nnano.2014.149.html#supplementary-</u> 783 <u>information</u> (2014). 

- 784 2 Xiao, Z. _et al._ Efficient perovskite light-emitting diodes featuring nanometre-sized 785 crystallites. _Nature Photonics_ **11** , 108 (2017). 

- 786 3 Zhao, X. & Tan, Z.-K. Large-area near-infrared perovskite light-emitting diodes. 787 _Nature Photonics_ **14** , 215-218, doi:10.1038/s41566-019-0559-3 (2020). 

- 788 4 Zhao, B. _et al._ High-efficiency perovskite–polymer bulk heterostructure light789 emitting diodes. _Nature Photonics_ **12** , 783-789, doi:10.1038/s41566-018-0283-4 790 (2018). 

- 791 5 Hassan, Y. _et al._ Facile Synthesis of Stable and Highly Luminescent 792 Methylammonium Lead Halide Nanocrystals for Efficient Light Emitting Devices. 793 _Journal of the American Chemical Society_ **141** , 1269-1279, 794 doi:10.1021/jacs.8b09706 (2019). 

- 795 6 Protesescu, L. _et al._ Nanocrystals of Cesium Lead Halide Perovskites (CsPbX3, 796 X = Cl, Br, and I): Novel Optoelectronic Materials Showing Bright Emission with 797 Wide Color Gamut. _Nano Letters_ **15** , 3692-3696, doi:10.1021/nl5048779 (2015). 798 7 Tian, Y. _et al._ Highly Efficient Spectrally Stable Red Perovskite Light-Emitting 799 Diodes. _Advanced Materials_ **30** , 1707093, doi:doi:10.1002/adma.201707093 800 (2018). 

- 801 8 Chang, J. _et al._ Enhanced Performance of Red Perovskite Light-Emitting Diodes 802 through the Dimensional Tailoring of Perovskite Multiple Quantum Wells. _The_ 803 _Journal of Physical Chemistry Letters_ **9** , 881-886, 804 doi:10.1021/acs.jpclett.7b03417 (2018). 

- 805 9 Cao, Y. _et al._ Perovskite light-emitting diodes based on spontaneously formed 806 submicrometre-scale structures. _Nature_ **562** , 249-253, doi:10.1038/s41586-018807 0576-2 (2018). 

- 808 10 Burlakov, V. M., Hassan, Y., Danaie, M., Snaith, H. J. & Goriely, A. Competitive 809 Nucleation Mechanism for CsPbBr3 Perovskite Nanoplatelet Growth. _The_ 810 _Journal of Physical Chemistry Letters_ **11** , 6535-6543, 811 doi:10.1021/acs.jpclett.0c01794 (2020). 

35 

- 812 11 Wang, Z. _et al._ Efficient ambient-air-stable solar cells with 2D–3D 813 heterostructured butylammonium-caesium-formamidinium lead halide 814 perovskites. _Nature Energy_ **2** , 17135, doi:10.1038/nenergy.2017.135 815 <u>https://www.nature.com/articles/nenergy2017135#supplementary-information</u> (2017). 816 12 Zhou, Y. _et al._ Benzylamine-Treated Wide-Bandgap Perovskite with High 817 Thermal-Photostability and Photovoltaic Performance. **7** , 1701048, 818 doi:doi:10.1002/aenm.201701048 (2017). 819 13 Yan, J., Qiu, W., Wu, G., Heremans, P. & Chen, H. Recent progress in 2D/quasi820 2D layered metal halide perovskites for solar cells. _Journal of Materials_ 821 _Chemistry A_ **6** , 11063-11077, doi:10.1039/C8TA02288G (2018). 822 14 Lee, D. S. _et al._ Passivation of Grain Boundaries by Phenethylammonium in 823 Formamidinium-Methylammonium Lead Halide Perovskite Solar Cells. _ACS_ 824 _Energy Letters_ **3** , 647-654, doi:10.1021/acsenergylett.8b00121 (2018). 

- 825 15 Zhang, X. _et al._ Bright Perovskite Nanocrystal Films for Efficient Light-Emitting 826 Devices. _The Journal of Physical Chemistry Letters_ **7** , 4602-4610, 827 doi:10.1021/acs.jpclett.6b02073 (2016). 828 16 Chiba, T. _et al._ Anion-exchange red perovskite quantum dots with ammonium 829 iodine salts for highly efficient light-emitting devices. _Nature Photonics_ **12** , 681830 687, doi:10.1038/s41566-018-0260-y (2018). 831 17 Xiao, Z. _et al._ Mixed-Halide Perovskites with Stabilized Bandgaps. _Nano Letters_ 832 **17** , 6863-6869, doi:10.1021/acs.nanolett.7b03179 (2017). 833 18 Barker, A. J. _et al._ Defect-Assisted Photoinduced Halide Segregation in Mixed834 Halide Perovskite Thin Films. _ACS Energy Letters_ **2** , 1416-1424, 835 doi:10.1021/acsenergylett.7b00282 (2017). 836 19 Meggiolaro, D., Mosconi, E. & De Angelis, F. Formation of Surface Defects 837 Dominates Ion Migration in Lead-Halide Perovskites. _ACS Energy Letters_ **4** , 779838 785, doi:10.1021/acsenergylett.9b00247 (2019). 839 20 Vashishtha, P. & Halpert, J. E. Field-Driven Ion Migration and Color Instability in 840 Red-Emitting Mixed Halide Perovskite Nanocrystal Light-Emitting Diodes. 841 _Chemistry of Materials_ **29** , 5965-5973, doi:10.1021/acs.chemmater.7b01609 842 (2017). 843 21 Yang, Z. _et al._ Stabilised Wide Bandgap Perovskite Solar Cells by Tin 844 Substitution. _Nano Letters_ **16** , 7739-7747, doi:10.1021/acs.nanolett.6b03857 845 (2016). 846 22 Bush, K. A. _et al._ Compositional Engineering for Efficient Wide Band Gap 847 Perovskites with Improved Stability to Photoinduced Phase Segregation. _ACS_ 848 _Energy Letters_ **3** , 428-435, doi:10.1021/acsenergylett.7b01255 (2018). 849 23 Yi, C. _et al._ Entropic stabilisation of mixed A-cation ABX3 metal halide 850 perovskites for high performance perovskite solar cells. _Energy & Environmental_ 851 _Science_ **9** , 656-662, doi:10.1039/C5EE03255E (2016). 852 24 Hu, M., Bi, C., Yuan, Y., Bai, Y. & Huang, J. Stabilized Wide Bandgap 853 MAPbBrxI3–x Perovskite by Enhanced Grain Size and Improved Crystallinity. **3** , 854 1500301, doi:doi:10.1002/advs.201500301 (2016). 855 25 Gualdrón-Reyes, A. F. _et al._ Controlling the Phase Segregation in Mixed Halide 856 Perovskites through Nanocrystal Size. _ACS Energy Letters_ **4** , 54-62, 857 doi:10.1021/acsenergylett.8b02207 (2019). 

36 

- 858 26 Zhou, Y. _et al._ Composition-Tuned Wide Bandgap Perovskites: From Grain 859 Engineering to Stability and Performance Improvement. **28** , 1803130, 860 doi:doi:10.1002/adfm.201803130 (2018). 861 27 Abdi-Jalebi, M. _et al._ Maximising and stabilising luminescence from halide 862 perovskites with potassium passivation. _Nature_ **555** , 497, 863 doi:10.1038/nature25989 (2018). 864 28 Belisle, R. A. _et al._ Impact of Surfaces on Photoinduced Halide Segregation in 865 Mixed-Halide Perovskites. _ACS Energy Letters_ **3** , 2694-2700, 866 doi:10.1021/acsenergylett.8b01562 (2018). 867 29 Zhang, L. & Sit, P. H. L. Ab initio study of the dynamics of electron trapping and 868 detrapping processes in the CH3NH3PbI3 perovskite. _Journal of Materials_ 869 _Chemistry A_ **7** , 2135-2147, doi:10.1039/C8TA09512D (2019). 

- 870 30 Li, W., Liu, J., Bai, F.-Q., Zhang, H.-X. & Prezhdo, O. V. Hole Trapping by Iodine 871 Interstitial Defects Decreases Free Carrier Losses in Perovskite Solar Cells: A 872 Time-Domain Ab Initio Study. _ACS Energy Letters_ **2** , 1270-1278, 873 doi:10.1021/acsenergylett.7b00183 (2017). 874 31 Meggiolaro, D. _et al._ Iodine chemistry determines the defect tolerance of lead875 halide perovskites. _Energy & Environmental Science_ **11** , 702-713, 876 doi:10.1039/C8EE00124C (2018). 

- 877 32 Motti, S. G. _et al._ Controlling competing photochemical reactions stabilises 878 perovskite solar cells. _Nature Photonics_ **13** , 532-539, doi:10.1038/s41566-019879 0435-1 (2019). 880 33 Shao, Y. _et al._ Grain boundary dominated ion migration in polycrystalline organic– 881 inorganic halide perovskite films. _Energy & Environmental Science_ **9** , 1752-1759, 882 doi:10.1039/C6EE00413J (2016). 883 34 Bischak, C. G. _et al._ Origin of Reversible Photoinduced Phase Separation in 884 Hybrid Perovskites. _Nano Letters_ **17** , 1028-1033, 885 doi:10.1021/acs.nanolett.6b04453 (2017). 

- 886 35 Wu, T. _et al._ High-Performance Perovskite Light-Emitting Diode with Enhanced 887 Operational Stability Using Lithium Halide Passivation. _Angewandte Chemie_ 888 _International Edition_ **59** , 4099-4105, doi:10.1002/anie.201914000 (2020). 

- 889 36 Zhang, H. _et al._ Phase segregation due to ion migration in all-inorganic mixed890 halide perovskite nanocrystals. _Nature Communications_ **10** , 1088, 891 doi:10.1038/s41467-019-09047-7 (2019). 

- 892 37 Flora, S. J. S. & Pachauri, V. Chelation in metal intoxication. _Int J Environ Res_ 893 _Public Health_ **7** , 2745-2788, doi:10.3390/ijerph7072745 (2010). 

- 894 38 Ferrero, M. E. Rationale for the Successful Management of EDTA Chelation 895 Therapy in Human Burden by Toxic Metals. _Biomed Res Int_ **2016** , 8274504896 8274504, doi:10.1155/2016/8274504 (2016). 

- 897 39 Mah, V. & Jalilehvand, F. Lead(II) Complex Formation with Glutathione. _Inorganic_ 898 _Chemistry_ **51** , 6285-6298, doi:10.1021/ic300496t (2012). 

- 899 40 Hayes, J. D. & Pulford, D. J. The Glutathione S-Transferase Supergene Family: 900 Regulation of GST and the Contribution of the lsoenzymes to Cancer 901 Chemoprotection and Drug Resistance Part I. _Critical Reviews in Biochemistry_ 902 _and Molecular Biology_ **30** , 445-520, doi:10.3109/10409239509083491 (1995). 

37 

- 903 41 Zhao, Q. _et al._ Size-Dependent Lattice Structure and Confinement Properties in 904 CsPbI3 Perovskite Nanocrystals: Negative Surface Energy for Stabilisation. _ACS_ 905 _Energy Letters_ **5** , 238-247, doi:10.1021/acsenergylett.9b02395 (2020). 

- 906 42 Noh, J. H., Im, S. H., Heo, J. H., Mandal, T. N. & Seok, S. I. Chemical 907 Management for Colorful, Efficient, and Stable Inorganic–Organic Hybrid 908 Nanostructured Solar Cells. _Nano Letters_ **13** , 1764-1769, doi:10.1021/nl400349b 909 (2013). 

- 910 43 Richter, J. M. _et al._ Ultrafast carrier thermalisation in lead iodide perovskite 911 probed with two-dimensional electronic spectroscopy. _Nature Communications_ **8** , 912 376, doi:10.1038/s41467-017-00546-z (2017). 

- 913 44 Sun, Q. _et al._ Bright, multicoloured light-emitting diodes based on quantum dots. 914 _Nature Photonics_ **1** , 717-722, doi:10.1038/nphoton.2007.226 (2007). 

- 915 45 Auer-Berger, M. _et al._ All-solution-processed multilayer polymer/dendrimer light 916 emitting diodes. _Organic Electronics_ **35** , 164-170, 

- 917 doi:10.1016/j.orgel.2016.04.044 (2016). 

- 918 46 Yan, F. _et al._ Highly Efficient Visible Colloidal Lead-Halide Perovskite Nanocrystal 919 Light-Emitting Diodes. _Nano Letters_ **18** , 3157-3164, 

- 920 doi:10.1021/acs.nanolett.8b00789 (2018). 

- 921 47 Richter, J. M. _et al._ Enhancing photoluminescence yields in lead halide 922 perovskites by photon recycling and light outcoupling. _Nature Communications_ **7** , 923 13941, doi:10.1038/ncomms13941 (2016). 

- 924 48 Cho, C. _et al._ The role of photon recycling in perovskite light-emitting diodes. 925 _Nature Communications_ **11** , 611, doi:10.1038/s41467-020-14401-1 (2020). 

- 926 49 Bodnarchuk, M. I. _et al._ Rationalising and Controlling the Surface Structure and 927 Electronic Passivation of Cesium Lead Halide Nanocrystals. _ACS Energy Letters_ 928 **4** , 63-74, doi:10.1021/acsenergylett.8b01669 (2019). 

- 929 

38 

