# Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 265 |
| 作者 | Zhi-Chun Yang, Wen-Jun Zhang, Shao-Hang Wu, Hongmei Zhu, Zong-Hao Liu, Zhi-Yang Liu, Zhao-Yi Jiang, Rui Chen et al. |
| DOI | 10.1126/sciadv.abg3749 |
| 源文件 | 030_Yang_2021_Slot-die-coating-large-area-formamidinium-cesium.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **AP P L IED SCIENCES AND E NG INE E RING** 

# **Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module** 

**Zhichun Yang**<sup>**1†**</sup> **, Wenjun Zhang**<sup>**1,2†**</sup> **, Shaohang Wu**<sup>**1,3†**</sup> **, Hongmei Zhu**<sup>**1†**</sup> **, Zonghao Liu**<sup>**1**</sup> ***, Zhiyang Liu**<sup>**1**</sup> **, Zhaoyi Jiang**<sup>**1**</sup> **, Rui Chen**<sup>**1**</sup> **, Jing Zhou**<sup>**1**</sup> **, Qian Lu**<sup>**1**</sup> **, Zewen Xiao**<sup>**1**</sup> **, Lei Shi**<sup>**2**</sup> **, Han Chen**<sup>**4**</sup> **, Luis K. Ono**<sup>**5**</sup> **, Shasha Zhang**<sup>**6**</sup> **, Yiqiang Zhang**<sup>**6**</sup> **, Yabing Qi**<sup>**5**</sup> **, Liyuan Han**<sup>**4**</sup> ***, Wei Chen**<sup>**1**</sup> ***** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

**Perovskite solar cells have emerged as one of the most promising thin-film photovoltaic (PV) technologies and have made a strong debut in the PV field. However, they still face difficulties with up-scaling to module-level devices and long-term stability issue. Here, we report the use of a room-temperature nonvolatile Lewis base additive, diphenyl sulfoxide(DPSO), in formamidinium-cesium (FACs) perovskite precursor solution to enhance the nucleation barrier and stabilize the wet precursor film for the scalable fabrication of uniform, large-area FACs perovskite films. With a parallel- interconnected module design, the resultant solar module realized a certified quasi-stabilized efficiency of 16.63% with an active area of 20.77 cm**<sup>**2**</sup> **. The encapsulated modules maintained 97 and 95% of their initial efficiencies after 10,000 and 1187 hours under day/night cycling and 1-sun equivalent white-light light-emitting diode array illumination with maximum power point tracking at 50°C, respectively.** 

#### **INTRODUCTION** 

Perovskite solar cells (PSCs) have attracted considerable interest in both research and industrial fields on account of their skyrocketing efficiency, ease of fabrication, and cost-effectiveness. Currently, the biggest challenges hampering the commercialization of this emerging photovoltaic (PV) technology are the scale-up of PSCs to module level without notable efficiency loss and affording their long-term stability ( _1_ , _2_ ). 

To fabricate high-efficiency perovskite solar modules (PSMs), it is essential to deposit uniform and high-quality perovskite films with full coverage over large scale ( _3_ ). Up to now, the scalable deposition methods, such as spray coating ( _4_ ), electrochemical deposition ( _5_ ), soft-cover deposition ( _6_ ), inkjet printing ( _7_ ), doctor blading ( _8_ , _9_ ), slot-die coating ( _10_ , _11_ ), hybrid chemical vapor deposition ( _12_ ), and vacuum evaporation ( _13_ ), have been used to fabricate large-area perovskite films for PSMs. Among these methods, the solution ink-based coating methods are superior thanks to their compatibility with continuous industrial production line processing, low equipment requirements, and low manufacturing cost. Many efforts have been made to use solution-based scalable methods to coat large-area CH3NH3PbI3 (MAPbI3) films for modules and achieved impressive device performance ( _8_ , _9_ , _12_ , _14_ ). However, the volatile properties and thermal decomposition of methylammonium (MA) cations limit the device’s long-term stability ( _13_ ). 

> 1Wuhan National Laboratory for Optoelectronics (WNLO), Huazhong University of Science and Technology (HUST), Wuhan 430074, China.<sup>2</sup> Hangzhou Zhongneng Photoelectricity Technology Co., Ltd., Hangzhou 310018, China.<sup>3</sup> Institute of New Energy Technology College of Information Science and Technology, Jinan University, Guangzhou 510632, China.<sup>4</sup> State Key Laboratory of Metal Matrix Composites, Shanghai Jiao Tong University, Shanghai 200240, China.<sup>5</sup> Energy Materials and Surface Sciences Unit (EMSSU), Okinawa Institute of Science and Technology Graduate University (OIST), 1919-1 Tancha, Onna-son, Kunigami-gun, Okinawa 904-0495, Japan.<sup>6</sup> School of Materials Science and Engineering and Henan Institute of Advanced Technology, Zhengzhou University, Zhengzhou 450001, China. *Corresponding author. Email: liuzonghao@hust.edu.cn (Z.L.); han.liyuan@sjtu.edu. cn (L.H.); wnlochenwei@hust.edu.cn (W.C.) †These authors contributed equally to this work. 

Formamidinium-cesium (FACs) mixed-cations perovskites have been demonstrated to be promising to achieve dominant operational stability in small-size (<1 cm<sup>2</sup> ) PSCs ( _15_ , _16_ ). It is thus desirable to construct highly efficient and stable PSMs with FACs perovskites ( _17_ ). However, the successful solution systems for scalable coating of MAPbI3 films are not completely compatible with FACs perovskites resulting from the different solvation characteristics of MAPbI3 and FACs perovskites ( _18_ ) and their different crystallization kinetics ( _19_ ). For example, a fraction of I<sup>−</sup> ions are usually substituted with Br<sup>−</sup> ions in FACs perovskites to stabilize the photoactive phase. This makes the nucleation and growth of FACs perovskites to be accelerated with the increasing Br content, which is likely due to the higher the diffusivity of Br<sup>−</sup> than I<sup>−</sup> in the solvent as a result of smaller ionic radius ( _20_ ). These characteristics largely increase the difficulty and complexity for scalable solution coating of highquality FACs perovskite films over large area ( _21_ ). Galagan _et al_ . ( _21_ ) reported the use of roll-to-roll slot-die–coated FA0.85Cs0.15PbI2.85 Br0.15 perovskite on a flexible polyethylene terephthalate/indium tin oxide substrate by the use of the nontoxic solvent of dimethyl sulfoxide/2-butoxyethanol, which is compatible with industrial manufacturing, and a moderate cell efficiency of 13.5% with an active area of 0.09 cm<sup>2</sup> was achieved. Guo _et al._ ( _22_ ) developed a vacuum-assisted precrystallization strategy to produce dense and uniform FA0.95Cs0.05PbI3 films with high crystallinity with the help of adding 30% MACl, and they achieved a decent cell efficiency of 16.63% with an active area of 0.09 cm<sup>2</sup> . Lim _et al._ ( _23_ ) used D-bar coating to deposit a large-area (FAPbI3)0.875(CsPbBr3)0.125 film by adding MACl as well as hexamethylphosphoramide Lewis base additive in perovskite/ _N_ , _N′_ - dimethylformamide (DMF) solution, and the as-fabricated n-i-p mini-module achieved an efficiency of 17.01% with an active area of 18.66 cm<sup>2</sup> . Nevertheless, so far, the reported strategies for the successful fabrication of FACs perovskite films over large area are very limited, and a credible third-party certification of the associated large-area devices’ efficiencies is also lacking. 

Similar to other PV technologies, the module design of PSMs plays an important role in charge collection, device performance, as 

**1 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

well as device stability ( _24_ ). To date, most of the reported PSMs are based on the series-connection design, which consists of subcells interconnected through P1-P2-P3 etched lines ( _1_ ). In such a design, the metal electrodes are in direct contact with the perovskite at the P2 channels, which causes potential concerns for the long-term stability of PSMs due to the possible reaction of the perovskite with the metals ( _1_ , _25_ ). An ingenious solution is to adopt a parallelinterconnected module design that does not have these P1-P2-P3 interconnections and avoids direct contact of the metal electrode/ grid with the perovskite to favor the long-term stability. In addition, the parallel PSMs with a low-voltage/high-current feature are well matched with silicon solar cells, which is beneficial for their potential application in perovskite/silicon tandem solar modules. Given that perovskite/silicon tandem solar modules have become an important direction of industrial development ( _26_ ), it is of specific importance to evaluate the operational stability of the parallel PSMs at the present stage. 

In this work, we introduce a room-temperature nonvolatile Lewis base additive with strong coordination capability, i.e., diphenyl sulfoxide (DPSO), into FA0.83Cs0.17PbI2.83Br0.17 precursor solution for coating large-area perovskite films and assemble them into parallel-interconnected solar modules. DPSO is demonstrated to impressively enlarge the nucleation energy barrier, effectively retard the natural nucleation of perovskite during the slot-die coating process, and stabilize the wet precursor film. Coupled with less toxic antisolvent _n_ -hexane extraction, high-quality FACs perovskite films with a size over 200 cm<sup>2</sup> are produced with high reproducibility. As a result, our p-i-n–structured PSMs with the parallel design have realized a certified quasi-stabilized efficiency of 16.63% with an active area of 20.77 cm<sup>2</sup> , which is the highest for parallel-designed PSMs to date. With a nonpermeable electrode barrier design, the encapsulated parallel PSMs show remarkable operational stabilities, retaining 97% of the initial efficiency after 10,000 hours under day/ night cycling and 95% of the initial efficiency under continuous light illumination with maximum power point (MPP) tracking at 50°C for 1187 hours. 

#### **RESULTS** 

### **Slot-die coating large-area FACs perovskite films** 

Here, a MA-free perovskite with the composition of FA0.83Cs0.17 PbI2.83Br0.17 is used as the light absorber ( _16_ , _27_ ). To fabricate largearea perovskite films, the perovskite precursor ink is first coated on a substrate to form a wet film via slot-die coating (fig. S1, A and B). Then, the obtained wet film is treated by antisolvent _n_ -hexane bath extraction to form a solid-state intermediate film. After further thermal annealing, a fully crystallized perovskite film is formed. 

We first used pure DMF and a mixture of DMF and _N_ -methyl2- pyrrolidinone (NMP) (denoted as DMF-NMP) as solvents to prepare FACs perovskite precursor solutions. A first visual inspection of the perovskite film in the pure DMF case (fig. S1C) shows a rough film with white precipitates and poor coverage. When DMF-NMP was used, the corresponding perovskite film showed improved morphology, but some rough areas with white precipitates are still observed (fig. S1C). From this comparison, it is found that the solvent volatilization time of the wet precursor film plays a critical role in determining the perovskite film morphology. To further improve the perovskite film quality, we introduce a room-temperature nonvolatile Lewis base DPSO (boiling temperature, 206° to 208°C, 

13 mmHg) into the DMF-NMP system that functions as an additive to modulate the perovskite nucleation/growth. The corresponding perovskite film showed notably improved film quality with a more uniform and mirror-like morphology than the other two cases (fig. S1C). 

### **Wet film stabilization** 

In general, there are three stages during perovskite crystallization: (i) solution stage, (ii) nucleation and fast-growth stage, and (iii) slow-growth stage. The mechanism of nucleation and crystal growth in the film formation process can be explained by the LaMer theory ( _2_ , _28_ , _29_ ). To reveal the role of DPSO in the perovskite nucleation and growth process, we studied its influence on the coated wet films stability. We first monitored the apparent evolution of the wet films fabricated from the above three solvent systems (DMF, precursor 1; DMF-NMP, precursor 2; and DMF-NMP-DPSO, precursor 3) by optical microscopy (Fig. 1A and movies S1 to S3). It is observed that the wet film stability of three precursors is gradually improved when DMF is replaced by DMF-NMP and DMF-NMP-DPSO, respectively. This observation indicates that the rapid natural supersaturation, uncontrollable nucleation, and grain growth processes in precursor 1 are retarded by the introduction of NMP or NMP-DPSO. The quantitative wet film stable times of three precursors were further evaluated by the absorbance intensity evolution of three precursor films as a function of time at the wavelength of 550 nm (Fig. 1B). With the introduction of DPSO, precursor 3 shows a wet film stable time of approximately 8 min, which is much longer than that of DMF (30 s) and DMF-NMP (100 s) cases. The largely extended wet film stable processing time enables a delicate control of the following antisolvent extraction and achievement of uniform and mirror-like perovskite films ( _14_ ). Above results also imply that DPSO should show strong interaction with the chemical components within the precursor solution and affect the wet film stability as well as the perovskite nucleation and growth. To further study the escape of solvent molecules from the wet films, thermogravimetric analysis (TGA) measurements of three precursor solutions based on DMF, DMF-NMP, and DMF-NMPDPSO were performed (Fig. 1C). It is observed that the temperature ranges of the first weight loss stages for the three cases gradually shift to higher temperatures, i.e., DMF (31° to 71°C), DMF-NMP (31° to 98°C), and DMF-NMP-DPSO (31° to 106°C). This observation clearly suggests that the removal of solvent from the wet films is suppressed when NMP and DPSO are used. In addition, 

To further study the escape of solvent molecules from the wet films, thermogravimetric analysis (TGA) measurements of three precursor solutions based on DMF, DMF-NMP, and DMF-NMPDPSO were performed (Fig. 1C). It is observed that the temperature ranges of the first weight loss stages for the three cases gradually shift to higher temperatures, i.e., DMF (31° to 71°C), DMF-NMP (31° to 98°C), and DMF-NMP-DPSO (31° to 106°C). This observation clearly suggests that the removal of solvent from the wet films is suppressed when NMP and DPSO are used. In addition, the DMF-NMP-DPSO ink exhibits the slowest solvent evaporation speed among the solutions. This is likely due to the enhanced interaction of DPSO with the other species in the precursor solution. The perovskite precursor solution evaporation speed is retarded with the addition of DPSO, while we consider that the coordination effect of DPSO with perovskites may be much more important to inhibit the precursor crystallization rate than the reduction of solvent volatilization. 

To further investigate the evolution of the chemical components in the wet films during their natural drying process, x-ray diffraction (XRD) measurements were also conducted. As shown in Fig. 1 (D to F), obvious XRD peaks at around 7.5<sup>o</sup> can be observed for all three cases, and they are likely assigned to CsBr-FAI-PbI2-DMF [Pb3(I1-zBrz)8 polymorphs], CsBr-FAI-PbI2-DMF-NMP [Pb3(I1-zBrz)8 polymorphs], and CsBr-FAI-PbI2-DMF-NMP-DPSO [Pb3(I1-zBrz)8 polymorphs], respectively ( _30_ , _31_ ). The evolutions of XRD peak 

**2 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Precursor ink engineering to stabilize the wet film.** ( **A** ) Semi–in situ observation of perovskite precursor film morphology evolutions over time with an optical microscope (scale bar, 100 m). The perovskite precursors dissolved in DMF, DMF-NMP, and DMF-NMP-DPSO are denoted as precursors 1, 2, and 3, respectively. ( **B** ) Optical absorbance evolution of perovskite precursor films as a function of time at the wavelength of 550 nm. a.u., arbitrary units. ( **C** ) TGA of perovskite inks without the addition of CsBr. ( **D** to **F** ) Semi–in situ XRD measurements of precursor films based on DMF (D), DMF-NMP (E), and DMF-NMP-DPSO (F). ( **G** ) DLS spectra of FACs perovskite precursor solutions. The concentrations of all samples are 0.5 mM. Unless otherwise specified, DMF, DMF-NMP, and DMF-NMP-DPSO represent the perovskite precursors dissolved in different solvents with or without additive, and the precursor films were dried in ambient air at room temperature during the measurements. 

intensity for the three cases are also consistent with the above wet film stable time study. With the evaporation of the solvent molecules, lead polyhalide colloids serve as nucleation centers, and the nucleation and subsequent crystal growth starts when the precursor concentration reaches the minimum supersaturated concentration limit, leading to the formation of CsBr-FAI-PbI2-S complexes (S represents generic solvent or additive molecules). Together, the above results confirm that the natural nucleation process has been successfully suppressed when DMF-NMP-DPSO is used to form a much more stable wet film, which facilitates the subsequent controllable nucleation for high-quality perovskite films when followed by the subsequent antisolvent extraction step. 

It has been widely revealed that the perovskite solution is a cluster- containing solution rather than a real solution ( _32_ ). The colloidal distribution within the perovskite precursor solution considerably affects the subsequent perovskite nucleation and growth progress ( _33_ ). To study the colloidal properties within the precursor solutions, we measured dynamic light scattering (DLS) spectra of the three precursor solutions. As shown in Fig. 1G, the colloid size 

is gradually reduced with the sequential introduction of NMP and DPSO compared with the pure DMF case, which is probably a result of the interaction of NMP and DPSO with the colloids ( _34_ , _35_ ). In terms of the dependence of the Gibbs free energy change on cluster size ( _33_ , _36_ ), we propose that the smaller cluster size implies a higher Gibbs free energy barrier for the formation of the crystal nucleus (fig. S2). Thus, the DMF-NMP-DPSO–based solution shows a higher nucleation barrier than the DMF and DMF-NMP cases. This is also the reason for the much slower nucleation and the longer wet film stable time, as observed in Fig. 1 (A and B) and movies S1 to S3. 

To further reveal the underlying mechanism for the improved wet film stability and slower perovskite nucleation when DPSO is used, the interaction of DPSO with the chemical components within the precursor solution is studied. As DPSO is a Lewis base, which has been used as a ligand to interact with Sn<sup>4+</sup> or other metal ions ( _37_ ), we first consider its interaction with Pb<sup>2+</sup> due to the Lewis acid base interaction. In the solution, DPSO molecules could act as ligands coordinating to the Pb<sup>2+</sup> ions, competing with other ligands such as I<sup>−</sup> , DMF, and NMP in the precursor solutions. This interaction is 

**3 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

verified by the largely increased solubility of lead(II) iodide (PbI2) with the further addition of DPSO when compared with the DMF and DMF-NMP cases (fig. S3). Furthermore, to confirm the interaction of solvents and DPSO molecules with the perovskite precursor species, ultraviolet-visible (UV-vis) absorption measurements of the diluted precursor solutions (0.5 mM) were carried out (fig. S4). The characteristic absorption peak assigned to the PbI2S4 species (S represents generic solvent or additive molecules) located at the wavelength of 324 nm for the pure DMF case is slightly shifted to 326 nm for the DMF-NMP case, indicating that some of the DMF molecules are replaced by NMP in PbI2S4 species ( _38_ ). Moreover, the characteristic absorption peak of PbIS5+ species located at the wavelength of 264 nm for the DMF and DMF-NMP cases is further shifted to 266 nm with the introduction of DPSO, indicating that some DMF and/or NMP molecules are further substituted by DPSO ( _39_ ). The room-temperature nonvolatile feature of DPSO causes its interaction with the perovskite precursor species to be stable and not considerably affected by the removal of DMF or NMP during the coating and the natural drying process of the wet films. 

To further investigate the interaction between DPSO and other components within the perovskite precursor solution, we studied the bonding nature of the adducts using Fourier transform infrared (FTIR) spectroscopy measurements. Figure 2A shows FTIR spectra for fingerprint regions of bare DMF, PbI2·DMF, and formamidinium iodide (FAI)·PbI2·DMF adducts (full spectra can be found in fig. S5A). The characteristic stretching vibration peak of C═O at around 1670 cm<sup>−1</sup> for a bare DMF molecule shifts to 1653 cm<sup>−1</sup> , indicating the formation of a PbI2·DMF adduct for the DMF case. The shifted stretching vibration frequency of C═O is owing to the formation of dative bond by sharing lone pair electrons in oxygen with Pb<sup>2+</sup> ( _40_ ). The stretching vibration peak of C═N for bare FAI appears at 1715 cm<sup>−1</sup> , while the vibration frequency is negligibly changed in the FAI·PbI2·DMF adduct, which may be ascribed to the weak interaction of DMF molecule with FAI. In contrast, the characteristic stretching vibration peak of C═O at around 1670 cm<sup>−1</sup> for a bare NMP molecule shifting to 1653 cm<sup>−1</sup> and a C═O splitting peak appears at 1627 cm<sup>−1</sup> after the introduction of PbI2, indicating successful coordination of the NMP molecule with Pb<sup>2+</sup> (Fig. 2B and fig. S5B) ( _18_ ). 



**Fig. 2. Interaction between the solvent or additive molecules and perovskite precursor species.** ( **A** to **C** ) FTIR spectra of fingerprint regions for C═O and S═O stretching vibrations. (A) C═O stretching detected from DMF (solution, black), PbI2·DMF (powder, red), FAI (powder, blue), and FAI·PbI2·DMF (powder, orange). (B) C═O stretching detected from NMP (solution, black), PbI2·NMP (powder, red), and FAI·PbI2·NMP (powder, orange). (C) S═O stretching measured for DPSO (powder, black), PbI2·DPSO (powder, red), and FAI·PbI2·DPSO (powder, orange). The blue line represents the spectra of FAI (powder). ( **D** to **I** ) Molecular structures resulting from DFT calculations. Molecular structures of (D) PbI2·DMF, (E) PbI2·NMP, (F) PbI2·DPSO, (G) FA<sup>+</sup> ·DMF, (H) FA<sup>+</sup> ·NMP, and (I) FA<sup>+</sup> ·DPSO. ( **J** ) Interaction energy of solvent or additive molecules with the perovskite precursor species FA<sup>+</sup> and PbI2. 

**4 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

In addition, the stretching vibration peak of C═N for bare FAI appears at 1715 cm<sup>−1</sup> , while the vibration frequency is shifted to 1720 cm<sup>−1</sup> in the FAI-PbI2-NMP sample, further indicating the formation of FAI·PbI2·NMP adduct ( _18_ ). As shown in Fig. 2C and fig. S5C, it is found that the S═O characteristic stretching vibration peak of a bare DPSO molecule at 1037 cm<sup>−1</sup> shifts to 968 cm<sup>−1</sup> for PbI2-DPSO sample, indicating the formation of PbI2·DPSO adduct. Moreover, the stretching vibration peak of C═N for bare FAI at 1715 cm<sup>−1</sup> shifts to 1710 cm<sup>−1</sup> for FAI-PbI2-DPSO sample, which indicates the formation of FAI·PbI2·DPSO adduct. In contrast to the inconspicuous shift of N—H stretching vibration peaks at 3351, 3207, and 3133 cm<sup>−1</sup> for FA cations in FAI·PbI2·DMF, the peaks considerably shift in the FTIR spectra of FAI·PbI2·DPSO and FAI·PbI2·NMP adduct (fig. S5D). This observation indicates that DPSO, NMP, or DMF interacts with FA cations through a hydrogen bond of the amine functional groups in FAI, which is consistent with the previous report ( _18_ ). 

The results clearly verify the interaction of the solvents as well as DPSO with the perovskite species. To further study the different strengths of interactions between DPSO as well as NMP and DMF with PbI2 and FAI, we conducted density functional theory (DFT) calculations to quantify their different interaction energies. Figure 2 (D to I) shows the stabilized molecular structures, and the calculated interaction energy results are summarized in Fig. 2J and table S1. As expected, PbI2 bonds with the oxygen in DMF, NMP, and DPSO molecules. The interaction energies of the corresponding bonds are calculated to be −0.980 eV for PbI2·DPSO, −0.765 eV for PbI2·NMP, and −0.627 eV for PbI2·DMF. The results indicate that the interaction energy of PbI2 with DPSO is stronger than that with NMP and DMF. Moreover, DPSO also shows a stronger interaction energy with FA cations (−1.496 eV) versus NMP (−1.429 eV) and DMF (−1.331 eV) by hydrogen bonding. These results are in agreement with the TGA analysis and DLS measurements, which further confirm that a much higher energy barrier must be overcome to enable perovskite nucleation/growth for the DMF-NMP-DPSO case compared with the other two cases. It also indicates that the wet film stable time is synergistically determined by the vapor pressure of the solvent or additive molecules (the solvent and additive properties are summarized in table S2) and their interactions with perovskite precursors. 

### **Perovskite film morphology** 

To obtain perovskite films, the wet films were further treated via a less toxic _n_ -hexane antisolvent bath treatment (AST) and thermal annealing. Antisolvent extraction can facilitate the removal of the redundant solvents from the wet film and achieve a controllable film morphology during the nucleation and crystal growth to enable uniform morphology (fig. S6) ( _41_ ). DPSO can be extracted from the wet film into the antisolvent to enable the formation of high-quality perovskite films. 

With regard to the crystallographic properties of the intermediate films, for the DMF case with AST at different time stages, it is clearly observed that the as-deposited perovskite intermediate films mainly consist of  phase (11.8° and 26.2°) perovskite rather than the preferred photoactive  phase (Fig. 3A) ( _15_ , _42_ ). This is attributed to the rapid evaporation of DMF from the wet films along with the overwhelming uncontrollable natural nucleation. For the DMF-NMP case, obvious peaks at 13.9° assigned to the (101) crystal planes of photoactive  phase perovskite are observed (Fig. 3B), while the 

peaks at 11.8° and 26.2° ascribed to the unfavorable  phase can still be detected. In contrast, the phase transformation from a much stable precursor wet film of DMF-NMP-DPSO case is complete, and the preferred  phase without any impure phase is obtained for the films treated by antisolvent at different time stages (Fig. 3C). We propose that the preferred  phase is favored by a stable CsBr-FAIPbI2-DMF-NMP-DPSO intermediate phase, which is due to the strong interaction between the nonvolatile DPSO additive and precursor molecules evidenced by the DFT calculations and FTIR results. 

With respect to the final perovskite morphology evolutions, the DMF-NMP-DPSO ink can deliver compact and uniform perovskite films from stable wet films within 8 min compared with the other two cases with random structures (Fig. 3D). The poor film coverage and inhomogeneous morphology are probably ascribed to the heterogeneous and uncontrollable natural nucleation process that can cause serious current loss in PSMs and lead to inferior device performance (fig. S7 and table S3). 

Because DPSO has a high sublimation temperature and strong chelating capability with perovskite species, it inspires us to investigate whether DPSO still exists in the obtained perovskite film after AST and thermal annealing treatment. We used x-ray photoelectron spectroscopy (XPS) to measure the S 2p signal in the corresponding perovskite films (fig. S8). Compared with the sample without either AST or annealing treatment, the sample without AST but with thermal annealing at 150°C for 30 min shows negligible change of the S 2p signal, implying that 150°C annealing cannot remove DPSO in the final perovskite film. In contrast, in the DMF-NMP-DPSO– based perovskite film with both AST and annealing treatment, negligible S 2p signal in the XPS spectrum could be detected. This observation suggests that DPSO in the obtained film is below the detection limit of XPS after being effectively extracted from the wet film with the help of AST. As a result, high-quality perovskite films with the preferred pure photoactive  phase are obtained (fig. S9), which is beneficial for high-performance device fabrication. 

### **Optical and electronic properties of large-area perovskite films** 

A uniform and high-quality perovskite film over large area is essential for high-performance PSMs. With the optimized perovskite precursor solution of DMF-NMP solvents containing DPSO additive, we slot-die–coated the FACs perovskite films on fluorine-doped tin oxide (FTO)/NiMgLiO substrate with the size of 20 cm by 14 cm (movie S4). Film thickness could be simply controlled by adjusting the concentration of the perovskite precursor ink (fig. S10). As shown in Fig. 4A, the coated perovskite film is mirror like. 

To further examine the uniformity of the slot-die–coated perovskite film, we performed photoluminescence (PL) mapping of a 5 cm by 5 cm sample cut from a 20 cm by 14 cm perovskite film sample on glass substrate (Fig. 4B). The film shows homogeneous PL intensity, which suggests good uniformity of the large-area perovskite films. Besides, their optical uniformity is further verified by UV-vis. We cut one 20 cm by 14 cm sample on FTO/NiMgLiO substrate into 12-piece 4 cm by 4 cm (Fig. 4C) samples and measured their UV-vis absorbance spectra. It is found that all 12 samples show nearly identical optical absorption response in Fig. 4D, suggesting a good uniformity of the optical properties over large scale. 

To further analyze the electronic uniformity of the deposited perovskite film over large area, one sample on glass substrate (20 cm by 14 cm) was cut into 12 pieces with a size of 4 cm by 4 cm 

**5 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. Crystal structure of intermediate films and surface morphology evolutions of the perovskite films.** ( **A** to **C** ) XRD characterization of three precursor wet films immersed into antisolvent at different time stages for 2 min without annealing treatment. (A) DMF, (B) DMF-NMP, and (C) DMF-NMP-DPSO. ( **D** ) Scanning electron microscopy (SEM) images of precursor films (DMF, DMF-NMP, and DMF-NMP-DPSO are denoted as precursors 1, 2, and 3, respectively) immersed into antisolvent at different wet film holding time stages for 2-min AST and annealed at 150°C for 30 min. “W/o AST” represents the films that are directly heated (150°C for 30 min) after coating. Scale bar, 1 m. 



**Fig. 4. Optical and electronic properties of large-area perovskite films.** ( **A** ) Optical image of large-area perovskite films. ( **B** ) Uniformity of large-area perovskite film on glass substrate characterized by PL mapping. ( **C** ) Schematic illustration of the fabricated large-area perovskite film cut into 12 pieces of 4 cm by 4 cm films. ( **D** ) Absorption spectra of 12-piece cut from a large-area perovskite sample. ( **E** ) Average TRPL lifetime distribution of 12-piece cut from a large perovskite film sample. ( **F** ) _J-V_ curves of 12 PSCs with an active area of 1 cm<sup>2</sup> ; the corresponding perovskite films were cut from a large-area perovskite film. Photo credit: Zhichun Yang, Huazhong University of Science and Technology. 

for time-resolved PL (TRPL) characterization. The TRPL decay curves were fitted with a biexponential function 



<!-- Start of picture text -->
Y  =   A 1 exp (−  t  / 1 ) +  A 2 exp (−  t  / 2 ) +   y 0 (1)<br><!-- End of picture text -->

where _A_ 1 and _A_ 2 are the relative amplitudes and 1 and 2 are the lifetimes for the fast and slow recombination, respectively. As 

shown in Fig. 4E, 12 pieces of samples give an average PL lifetime of 137.0 ns with a standard deviation (SD) of ±13.8 ns (the steady-state PL peak for the obtained perovskite film is detected before TRPL measurement as shown in fig. S11A, and the TRPL fitting results are exhibited in fig. S11B and table S4). The narrow distribution of TRPL lifetime indicates a good uniformity of the 

**6 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

defect nature over large scale within the large-area perovskite films. 

Furthermore, a 20 cm by 14 cm perovskite film sample on FTO/ NiMgLiO substrate was cut into 12 pieces with the size of 4 cm by 4 cm to fabricate PSCs with an active area of 1 cm<sup>2</sup> , with the device configuration of “FTO/NiMgLiO/FA0.83Cs0.17PbI2.83Br0.17/LiF/C60/ bathocuproine (BCP)/Bi/Ag” ( _43_ ). Figure 4F shows the photocurrent density–voltage ( _J-V_ ) curves of the 12 devices. All devices show nearly identical device performance and give an average efficiency of 18.2 ± 0.2% (table S5). The centrally distributed device performance of the 12 devices further verifies the uniformity of the perovskite film over large scale. 

### **PSM structure and performance** 

To apply the above large-area perovskite films to a module device, PSMs with a configuration of FTO/NiMgLiO/FA0.83Cs0.17PbI2.83 Br0.17/LiF/C60/BCP/Bi/Ag are manufactured ( _43_ ). Figure 5A illustrates the cross-sectional scanning electron microscopy (SEM) image of the PSMs. In our PSMs, all of the functional layers including the charge transport layers, perovskite layer, and electrodes are 

constructed with scalable fabrication methods (Fig. 5, B and C). This makes our PSM fabrication strategy promising for mass production with high technical reproducibility. 

In addition, our PSMs are based on a parallel-interconnected design, as shown in Fig. 5B and fig. S12A, which is different from the commonly reported PSMs with the series-interconnection design (table S6). The silver grids in our modules are designed to act as current collectors. They are beneficial to minimize the efficiency loss induced by the series resistance of the FTO substrate (fig. S12, B to E), which is a recognized reason for the efficiency mismatch between small-area devices and PSMs ( _1_ , _17_ ). Compared with the series-connected design, the parallel-connected module can realize less energy loss induced by the performance mismatch of adjacent subcells, which has been reported in dye-sensitized solar modules ( _24_ ). Such a module design avoids the direct contact between the perovskite and metal electrode/grid, as the direct contact of metal with perovskite at the P1-P2-P3 interconnection regions in seriesconnected PSMs was reported to be detrimental for module stability because of the reaction of the perovskite with metal ( _25_ ). The parallel module design is thus believed to be beneficial for PSMs’ long-term 



**Fig. 5. PSM structure and performance.** ( **A** ) High-resolution cross-sectional SEM image of a complete PSM. ( **B** ) Three-dimensional structure schematic diagram of the designed module connected in parallel. ( **C** ) Cross-sectional schematic illustration of the fabricated module coupled with the deposition methods of the functional layers. ( **D** ) _I-V_ curves of PSMs including a stabilized efficiency output and the device performance before and after stabilized test. FF, fill factor. ( **E** ) Reproducibility of PSMs (30 samples were tested); the inset is the optical image of some fabricated modules. Photo credit: Zhichun Yang, Huazhong University of Science and Technology. 

**7 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

operation. In addition, it has been confirmed that an ultrathin lithium fluoride (LiF) interlayer (0.8 nm) is effective for large-area perovskite films’ surface passivation, which can improve the opencircuit voltage ( _V_ OC) of the PSMs (fig. S13 and table S7) ( _44_ ). Moreover, a chemically inert bismuth interlayer (20 nm) is introduced between the BCP layer and the Ag electrode to serve as a robust permeation barrier layer to hamper Ag interdiffusion as well as the reaction of Ag with perovskite ( _45_ ). 

To check the PSM performance, we sent our module to the Newport Corporation Technology and Application Center PV Lab, which is a globally recognized PV testing center for certification. The module gives a quasi-stabilized power conversion efficiency (PCE) of 16.63% with an active area of 20.77 cm<sup>2</sup> (Fig. 5D and fig. S14). The detailed performance output includes the stabilized efficiency, and the efficiencies before and after stabilized test at forward and reverse scans are also provided. The well-overlapped results reflect that our PSMs exhibit negligible hysteresis and very stable output both before and after the stabilized current-voltage ( _I-V_ ) sweep configuration test (fig. S15). The corresponding external quantum efficiency result is exhibited in fig. S16. To the best of our knowledge, this is the first certified efficiency report of parallel-design PSMs (table S6). To verify the manufacturing reproducibility of our scheme toward efficient PSMs, we measured the device performances of 30 modules (Fig. 5E, fig. S17, and table S8). The narrow efficiency distribution confirms that our efficient solar modules are highly reproducible. It should be noted that the geometric factor (GFF) of our parallel module is around 92.7% (fig. S18). Thus, the aperture efficiency is estimated to 15.42%. This value can be further improved by optimizing the laser scribing process to achieve higher GFF ( _46_ ), reducing defects by interface engineering to suppress charge recombination ( _3_ ) and developing more effective coating methodologies for electron or hole transport layers ( _47_ ). 

### **PSM stability** 

We further evaluate the operational stability of our parallel PSMs. For stability tests, a highly compact and hydrophobic Al2O3 layer (fig. S19) was further deposited by atomic layer deposition (ALD) on top of the Ag electrode without sacrificing efficiency. Then, the module was carefully encapsulated by a cover glass with a hollow space via a hot melt adhesive membrane, and the four edges were further wrapped with butyl rubber/Al tape. First, an accelerated aging test of the encapsulated PSM was conducted under continuous 1-sun equivalent white-light light-emitting diode (LED) in ambient air with MPP tracking at the temperature around 50°C. The corresponding results are shown in Fig. 6A and fig. S20. The cover glass encapsulated module without the ALD Al2O3 layer retained 80% of its initial value ( _T_ 80) after 736 hours. In contrast, the module encapsulated simultaneously with ALD Al2O3 and a cover glass (ALD Al2O3/cover glass) retained 95% of its initial efficiency ( _T_ 95) after aging for 1187 hours. Beyond that, the real day/night cycling stability of ALD Al2O3/cover glass encapsulated PSMs was also studied (Fig. 6B, fig. S21, and table S9). Aging PSCs under light/dark cycles is another important protocol to mimic the device real working stability in practical application (table S10). The reversible degradation/recovery of PSCs has been studied in such light/dark cycling test ( _48_ , _49_ ). Such reversible performance is found to be caused by a reversible ion redistribution that induced by regular polling and electric field intensity changes during day/night cycles ( _49_ ). It is also reported that new recombination centers could form in the perovskite 

bulk or at the interfaces under test of day/night cycling combined with elevated temperature ( _50_ ). Outdoor test conditions are highly demanding, as the devices are characterized by real day (sunlight)/ night (dark), seasonal, and weather cycles that correspond to drastic variations in irradiation, temperature, and moisture ( _51_ , _52_ ). Here, to mimic the potential practical application scenarios such as building integrated PVs of perovskite PV technology, the fabricated module connected to a mini electric fan (~0.3 W) was placed near the indoor windows under real sunlight without humidity control for over 1 year and periodically taken to measure _I-V_ curves under a standard solar simulator. The device temperature did not exceed 55°C even in the summer because the indoor temperature was controlled by an air conditioner. Our indoor day/night cycling test has mimicked the real working conditions of a solar power window, which is normally integrated with human-living buildings. The PSM retains 97% of its initial efficiency after aging for 10,000 hours. This test also demonstrated that for the working conditions of an indoor environment (with air conditioner in summer) for PSMs, the _T_ 80 lifetime of PSMs could possibly exceed 5 to 6 years if the linear decrease of 3 to 4% PCE per year is valid in the following years. It is suggested that this indoor day/night cycling test makes sense and has a certain guiding effect on the differentiated application scenarios of perovskite PV technology. The good stability of our PSMs is suggested to be ascribed to the following critical points: (i) The high-quality and thermally stable FACs perovskite film over large area made by our room-temperature nonvolatile wet film stabilizer strategy, in combination with other function layers’ up-scaling fabrication, can largely prevent the formation of pin holes and the resultant shunt paths across the device, which could induce interlayers’ decomposition reactions and performance degradation; (ii) the robust permeation barrier design of Bi/Ag electrode as well as the further ALD-Al2O3 thin-film encap-2O3 thin-film encap-O3 thin-film encap-3 thin-film encap- thin-film encapsulation and the mechanical protection with a cover glass that can prevent the corrosion of Ag electrode, blocking the ingress of H2O/2O/O/ O2 from the ambient atmosphere and slowing down the fast volatil-2 from the ambient atmosphere and slowing down the fast volatil- from the ambient atmosphere and slowing down the fast volatilization of the degraded perovskite species during long-term aging ( _53_ ). In combination of Bi and Al2O3 barriers, the as-fabricated PSMs 2O3 barriers, the as-fabricated PSMs O3 barriers, the as-fabricated PSMs 3 barriers, the as-fabricated PSMs  barriers, the as-fabricated PSMs could withstand water immersing for several minutes without notable color change compared with the module without ALD Al2O32O3O33 thin-film encapsulation (movie S5), which visually proves the barriers’ nonpermeability. It is being revealed that the integration of a nonpermeable barrier in PSCs is important for the long-term stability, which can affect the equilibrium of perovskite decomposition 

The good stability of our PSMs is suggested to be ascribed to the following critical points: (i) The high-quality and thermally stable FACs perovskite film over large area made by our room-temperature nonvolatile wet film stabilizer strategy, in combination with other function layers’ up-scaling fabrication, can largely prevent the formation of pin holes and the resultant shunt paths across the device, which could induce interlayers’ decomposition reactions and performance degradation; (ii) the robust permeation barrier design of Bi/Ag electrode as well as the further ALD-Al2O3 thin-film encap-2O3 thin-film encap-O3 thin-film encap-3 thin-film encap- thin-film encapsulation and the mechanical protection with a cover glass that can prevent the corrosion of Ag electrode, blocking the ingress of H2O/2O/O/ O2 from the ambient atmosphere and slowing down the fast volatil-2 from the ambient atmosphere and slowing down the fast volatil- from the ambient atmosphere and slowing down the fast volatilization of the degraded perovskite species during long-term aging ( _53_ ). In combination of Bi and Al2O3 barriers, the as-fabricated PSMs 2O3 barriers, the as-fabricated PSMs O3 barriers, the as-fabricated PSMs 3 barriers, the as-fabricated PSMs  barriers, the as-fabricated PSMs could withstand water immersing for several minutes without notable color change compared with the module without ALD Al2O32O3O33 thin-film encapsulation (movie S5), which visually proves the barriers’ nonpermeability. It is being revealed that the integration of a nonpermeable barrier in PSCs is important for the long-term stability, which can affect the equilibrium of perovskite decomposition reaction from the perspective of thermodynamics ( _3_ , _54_ , _55_ ). (iii) The parallel module design avoids the direct contact of metal electrode/grid with perovskite and allows an adequate space between the grids or electrodes and the perovskite layer. The ALD-Al2O3 thin-film encapsulation further isolates the perovskite or its degradation by-products with metal electrode/grid. This can prevent the unexpected contact or corrosive reaction between the metal electrode/ grid and perovskite from the cross-sectional direction in the interconnection region as demonstrated in the series-designed PSMs ( _2_ , _25_ ). All above convictively guarantee the good stability of our solar modules. 

#### **DISCUSSION** 

In conclusion, perovskite ink engineering by using room-temperature nonvolatile DPSO as the wet film stabilizer was conducted to achieve 

**8 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 6. PSM stability.** ( **A** ) Operational stability of PSMs encapsulated by a cover glass or ALD Al2O3/cover glass under continuous light irradiation (the light source for the aging test was generated by a 1-sun equivalent white-light LED array) with MPP tracking at the temperature around 50°C in ambient air. ( **B** ) Stability of the ALD Al2O3/ cover glass–encapsulated module under real day/night cycling without any humidity control. The PCE evolutions are obtained from the average values of the forward and reverse scans. 

improved wet film stability for slot-die coating of large-area FACs perovskite films. Coupled with less toxic antisolvent extraction, high-quality FACs perovskite films are obtained over large area. As a result, a certified quasi-stabilized efficiency of 16.63% with an active area of 20.77 cm<sup>2</sup> was achieved for our parallel-interconnection solar module design based on the above strategy. Moreover, our encapsulated solar module remains 97% of its initial efficiency after operating for 10,000 hours under real day/night cycling. Our solar module also achieves a _T_ 95 lifetime of 1187 hours under continuous 1-sun equivalent white-light LED illumination with MPP tracking at the temperature around 50°C. Our demonstration paves a way for scalable fabrication of large-area and stable PSMs toward the commercialization of this promising thin-film PV technique. 

### **MATERIALS AND METHODS Materials** 

Nickel(II) acetylacetonate (95%), DMF (anhydrous, 99.8%), acetonitrile (anhydrous, 99.8%), and lithium fluoride (≥99.99%) were purchased from Sigma-Aldrich. Magnesium acetate tetrahydrate (99%) and lithium acetate (99%) were all purchased from Wako Co., Japan. Ethanol (analytically pure) and isopropanol were purchased from Sinopharm Chemical Reagent Company, China. FAI (99.9%) was provided by Hangzhou Zhongneng Photoelectricity Technology Co. Ltd. C60 was purchased from Luminescence Technology Corp. Cesium bromide (CsBr, 99.99%), PbI2 (>98%), DPSO (> 99.0%), BCP (>99.0%), _n_ -hexane (anhydrous, > 96%), and NMP (>99.0%) were purchased from Tokyo Chemical Industry Co. Ltd. All chemicals were used as received without any purification unless otherwise specified. 

### **Methods** 

### **_Precursor ink engineering_** 

Perovskite precursor ink (1.3 M) (FA0.83Cs0.17PbI2.83Br0.17, denoted as FACs) was prepared for the optimization of precursor inks. For the DMF-based precursor solution, 0.0941-g CsBr, 0.3712-g FAI, and 1.1986-g PbI2 were dissolved in 2 ml of DMF. For the DMFNMP–based precursor solution, 0.0941-g CsBr, 0.3712-g FAI, and 1.1986-g PbI2 were dissolved in 2-ml mixed solvent of DMF and NMP (volume ratio = 1:1, denoted as DMF-NMP). For the DMFNMP-DPSO–based precursor solution, 0.0941-g CsBr, 0.2630-g DPSO, 0.3712-g FAI, and 1.1986-g PbI2 were dissolved in 2-ml mixed solvent of DMF and NMP (volume ratio = 1:1, denoted as DMFNMP-DPSO). After that, the solutions were stirred for 12 hours at room temperature and filtrated before use. Typically, the DMFNMP-DPSO precursor ink was used for slot-die coating large-area perovskite films for the corresponding characterization and fabricating PSMs. In particular, the optimal amount of DPSO additive is determined by the device performance and provided in fig. S7 and table S3. 

### **_PSM fabrication_** 

A line (denoted as P1; the optical microscope image is exhibited in fig. S12B) was laser-scribed (27 W, 1064 nm, 40 kHz) on an FTO-coated glass substrate (TEC 8, Nippon Sheet Glass Co. Ltd.). Then, the scribed substrate was cleaned in an ultrasonic bath with detergent, deionized water, alcohol, and isopropanol for 15 min, respectively. After that, a NiMgLiO layer (hole transport layer) was deposited on the above cleaned FTO substrate. NiMgLiO solution was prepared with a mixed solvent of acetonitrile and ethanol (volume ratio = 95:5, 100 ml) of nickel acetylacetonate with the addition of magnesium acetate tetrahydrate and lithium acetate. The prepared 

**9 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

solution (the mole atomic ratio is Ni:Mg:Li = 80:15:5, and the total metal ion concentration is 0.02 M) was sprayed by an air nozzle on the heated FTO substrate (570°C). After spraying coating, the samples were further treated at 570°C for another 40 min and cooled naturally. Afterward, the perovskite layer was deposited in a dry air glovebox (humidity <3%) by slot-die coating technology. In detail, the prepared perovskite ink (1.3 M, DMF-NMP-DPSO) was squeezed out with a feed pump speed of 166.67 l/min, the gap between the slip and the coated substrate was 150 m, and the substrate moving speed was 5000 m/s. After that, the coated precursor wet film was transferred to an antisolvent bath of _n_ -hexane (300 ml) for 2 min and taken out for annealing on a hotplate at 150°C for 30 min. Then, the LiF, C60, and BCP layers were deposited by thermal evaporation at the vacuum of <5.0 × 10<sup>−4</sup> Pa, and the evaporation rate was controlled at 0.1 Å/s for the thickness of 0.8, 30, and 1 nm, respectively. The deposited layers were laser-scribed (14 W, 1064 nm, 40 kHz) for another line (denoted as P2; see fig. S12D) for the deposition of silver grids. A Bi interlayer (20 nm) and a Ag electrode (150 nm) were thermally evaporated by a pattered mask at high vacuum (< 5 × 10<sup>−4</sup> Pa) with a controlled evaporation rate of 0.1 and 0.1 to 0.5 Å/s, respectively. Last, the silver grids (6 m) were deposited by thermal evaporation at high vacuum (< 5 × 10<sup>−4</sup> Pa) with a designed mask, and the deposition speed was controlled at 10 Å/s. 

### **_Module encapsulation_** 

First, the modules for stability tests were all encapsulated by an ALD Al2O3 film unless otherwise specified. Briefly, trimethyl aluminum (TMA, Sigma-Aldrich) and deionized water were injected sequentially into the ALD chamber. The chamber pressure was <0.1 Pa, and the temperature was kept at 100°C. A single ALD cycle consisted of TMA pulse for 6 s, N2 purging for 12 s, H2O pulse for 6 s, and N2 purging for 12 s. After that, 45 cycles were repeated for 27 min. Second, a cover glass was further attached on the top of each PSM to provide mechanical protection. To achieve this, a cover glass sheet was carefully sealed on top of ALD-Al2O3 along its edge with bynel sealant at a temperature of 135°C for 10 min via a laminating machine. The edges of the PSMs were further encapsulated with butyl rubber/aluminum tape. After the corresponding encapsulation process, the fabricated solar modules were performed for stability test. The cover glass-encapsulated PSMs were the modules with cover glass encapsulation but without ALD Al2O3 film encapsulation. 

### **_Module stability test_** 

The operational aging test was performed at the MPP tracking under continuous white-light LED array illumination, and the light intensity was calibrated to achieve the same _I_ SC from the PSMs measured under a standard solar simulator (AM 1.5G, 100 mW cm<sup>−2</sup> ). The tests were carried out in ambient air, and the module temperature was at around 50°C. 

The real day/night cycling test was carried out by placing the fabricated PSM indoor close to the window, without any humidity control. The encapsulated module maintained 97% of its initial efficiency after 10,000 hours under real day/night cycling with a load of mini electric fan (~0.3 W). After aging for several days, it was tested under a standard solar simulator. It should be mentioned that the day/night cycling test in our work was carried out in a human living environment, which helped to reduce the effect of heat radiation and rain effect. The device temperature did not exceed 55°C even in the summer because the indoor temperature was controlled by an air conditioner. 

### **_Characterization_** 

Semi–in situ microscopy observations for the evolution of precursor wet films based on various perovskite precursors were carried out by an optical microscope equipped with a camera and a computer (HOMA-2000 L, Xipaike Co., China). UV-vis spectra of perovskite films were obtained from a Lambda 950 UV-vis spectrophotometer (PerkinElmer Co., USA). The absorption spectra of perovskite precursor solution were measured by a UV-vis near-IR spectrophotometer (SolidSpec-3700, Shimadzu). The volatility of perovskite precursor solutions was characterized by TGA (TGA8000, PerkinElmer Co., USA). The measurement was carried from room temperature to 150°C at a heat rate of 10°C/min under ambient air. DLS spectra of perovskite precursor solutions were done by a ZetaSizer Nano-ZS 90 (Malvern Instruments Ltd., Worcestershire, UK). To ensure the accuracy of the test results, the tube was washed three times by DMF solvent before injecting the perovskite precursor solution. Steady-state PL spectrum was measured using a LabRAM HR800 (Horiba Jobin Yvon) equipped with a laser, and the excitation source wavelength is 532 nm. TRPL measurements were conducted by a fluorescence spectrometer with an excitation wavelength of 478 nm (DeltaFlex, Horiba). PL mapping was carried out with a PL microscopic spectrometer (Flex One, Zolix, China) with mapping ability. The excitation source of PL is a continuous-wave laser with the wavelength of 532 nm, and the mapping was performed with a step size of 0.005 mm. Specially, for steady-state PL, TRPL, and PL mapping characterization, the large-area perovskite thin films were slot-die–coated on a glass substrate under the same deposition condition with their deposition on the charge-transport layer, except that the glass needed be treated with O2 plasma for 15 min. XRD characterization was performed on an Empyrean x-ray diffractometer with Cu Ka radiation (PANalytical B.V. Co., Netherlands). FTIR spectroscopy spectra were recorded by a VERTEX 70 FTIR microscopy (Bruker Co., Germany). The surface morphology and cross-sectional images of samples were observed by a fieldemission SEM (FEI NOVA NanoSEM 450). XPS measurements were performed on an AXIS- ULTRA DLD-600 W Ultra spectrometer (Kratos Co., Japan). A black mask with an illuminated aperture area (or active area, determined as the sum of areas of individual subcell aperture mask areas) of 20.77 cm<sup>2</sup> was used for PV performance measurements under standard AM 1.5G simulated sunlight (Oriel Class AAA, XES-160S1, SAN-EI ELECTRIC CO., LTD., Japan) with a source meter (Keithley 2601 B), and the simulated light intensity (100 mW cm<sup>−2</sup> ) was calibrated with a reference silicon solar cell. We sent one of the best modules to an independent solar cell– accredited laboratory (Newport, USA) for certification. 

### **_The preparation of adduct powders_** 

_PbI2·DMF adduct._ PbI2 (461 mg) was dissolved in 600 mg of DMF, which was magnetically stirred for 12 hours. Then, 400 l of solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1000 rpm for 120 s. The film was peeled off by a knife and dried at 50°C in vacuum oven for 2 hours, which was collected for FTIR spectroscopy measurement. 

_FAI·PbI2·DMF adduct._ FAI (172 mg) and 461 mg of PbI2 were dissolved in 600 mg of DMF, which was magnetically stirred for 12 hours. Then, 400 l of solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1000 rpm for 120 s. The film was peeled off by a knife and dried at 50°C in vacuum oven for 2 hours, which was collected for FTIR measurement. 

_PbI2·NMP adduct._ PbI2 (461 mg) was dissolved in 654 mg of NMP, which was magnetically stirred for 12 hours. Then, 400 l of 

**10 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

## SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1500 rpm for 300 s. The film was peeled off by a knife and dried at 60°C in vacuum oven for 6 hours, which was collected for FTIR measurement. 

_FAI·PbI2·NMP adduct._ FAI (172 mg) and 461 mg of PbI2 were dissolved in 654 mg of NMP, which was magnetically stirred for 12 hours. Then, 400 l of solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1500 rpm for 300 s. The film was peeled off by a knife and dried at 60°C in vacuum oven for 6 hours, which was collected for FTIR measurement. 

_PbI2·DPSO adduct._ PbI2 (461 mg) and 101.1 mg of DPSO were dissolved in 600 mg of DMF, which was magnetically stirred for 12 hours. Then, 400 l of solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1500 rpm for 120 s. The film was peeled off by a knife and dried at 80°C in vacuum oven for 3 hours, which was collected for FTIR measurement. 

_FAI·PbI2·DPSO adduct._ FAI (172 mg), 461 mg PbI2, and 101.1 mg DPSO were dissolved in 600 mg of DMF, which was magnetically stirred for 12 hours. Then, 400 l of solution was dropped on a glass substrate (5 cm by 5 cm) and spun at 1200 rpm for 120 s. The film was peeled off by a knife and dried at 80°C in vacuum oven for 6 hours, which was collected for FTIR measurement. 

### **_The solubility of DPSO in n-hexane_** 

To identify the solubility of DPSO in _n_ -hexane, first, plenty of DPSO powders is added into 3 ml of _n_ -hexane until the precipitation appeared even though vigorous stirring for 2 hours and ultrasonic for 1 hour. Second, an empty bottle is weighed and marked as _m_ 1 g. One milliliter of supernatant was extracted into the prepared bottle, and the solution was evaporated and dried at 50°C for 30 min. The bottle is weighed again and marked as _m_ 2 g. Last, the solubility of DPSO (denoted as _S_ ) in _n_ -hexane can be calculated as follows: _S_ = ( _m_ 2 − _m_ 1) g/ml. The solubility of DPSO in _n_ -hexane is determined to be around 0.0083 g/ml. In our experiment, a 20 cm by 14 cm perovskite film (around 111.3 l of perovskite precursor solution is used) is immersed into around 300 ml of _n_ -hexane bath. Thus, the large amount of _n_ -hexane has enough capability to effectively extract DPSO from the wet film. 

### **_Computational methods_** 

DFT calculations were performed with projector-augmented wave ( _56_ ) potential, as implemented in the Vienna Ab initio Simulation Package ( _57_ ). Perdew-Burke-Ernzerhof functional within the generalized gradient approximation ( _58_ ) was used to determine the exchange-correlation potential. The original molecular structures were obtained by experiments, and they were put into large enough boxes for relaxation and molecular interactions. -centered _k_ -meshes with a _k_ -spacing of 0.3 Å<sup>−1</sup> were used for Brillouin zone sampling. To treat the van der Waals interactions, DFT-D3 correction method of Grimme ( _59_ , _60_ ) was used. The kinetic energy cutoff for the electron wave functions was 500 eV, and all structures were fully relaxed until the force on each atom was smaller than 0.01 eV/Å. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/18/eabg3749/DC1 

### **REFERENCES AND NOTES** 

1. Z. Li, T. R. Klein, D. H. Kim, M. Yang, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Scalable fabrication of perovskite solar cells. _Nat. Rev. Mater._ **3** , 18017 (2018). 

2. N.-G. Park, K. Zhu, Scalable fabrication and coating methods for perovskite solar cells and solar modules. _Nat. Rev. Mater._ **5** , 333–350 (2020). 

3. Z. Liu, L. Qiu, L. K. Ono, S. He, Z. Hu, M. Jiang, G. Tong, Z. Wu, Y. Jiang, D.-Y. Son, Y. Dang, S. Kazaoui, Y. Qi, A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. _Nat. Energy_ **5** , 596–604 (2020). 

4. J. H. Heo, M. H. Lee, M. H. Jang, S. H. Im, Highly efficient CH3NH3PbI3− _x_ Cl _x_ mixed halide perovskite solar cells prepared by re-dissolution and crystal grain growth via spray coating. _J. Mater. Chem. A_ **4** , 17636–17642 (2016). 

5. H. Chen, Z. Wei, X. Zheng, S. Yang, A scalable electrodeposition route to the low-cost, versatile and controllable fabrication of perovskite solar cells. _Nano Energy_ **15** , 216–226 (2015). 

6. F. Ye, H. Chen, F. Xie, W. Tang, M. Yin, J. He, E. Bi, Y. Wang, X. Yang, L. Han, Soft-cover deposition of scaling-up uniform perovskite thin films for high cost-performance solar cells. _Energ. Environ. Sci._ **9** , 2295–2301 (2016). 

7. Z. Wei, H. Chen, K. Yan, S. Yang, Inkjet printing and instant chemical transformation of a CH3NH3PbI3/nanocarbon electrode and interface for planar perovskite solar cells. _Angew. Chem. Int. Ed._ **53** , 13239–13243 (2014). 

8. Y. Deng, X. Zheng, Y. Bai, Q. Wang, J. Zhao, J. Huang, Surfactant-controlled ink drying enables high-speed deposition of perovskite films for efficient photovoltaic modules. _Nat. Energy_ **3** , 560–566 (2018). 

9. M. Yang, Z. Li, M. O. Reese, O. G. Reid, D. H. Kim, S. Siol, T. R. Klein, Y. Yan, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Perovskite ink with wide processing window for scalable high-efficiency solar cells. _Nat. Energy_ **2** , 17038 (2017). 

10. J. B. Whitaker, D. H. Kim, B. W. Larson, F. Zhang, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Scalable slot-die coating of high performance perovskite solar cells. _Sustain. Energy Fuels_ **2** , 2442–2449 (2018). 

11. F. D. Giacomoa, S. Shanmugama, H. Fledderusa, B. J. Bruijnaersb, W. J. H. Verheesc, M. S. Dorenkamperc, S. C. Veenstrac, W. Qiud, R. Gehlhaard, T. Merckxd, T. Aernoutsd, R. Andriessena, Y. Galagana, Up-scalable sheet-to-sheet production of high efficiency perovskite module and solar cells on 6-in. substrate using slot die coating. _Sol. Energy Mater. Sol. Cells_ **181** , 53–59 (2018). 

12. M. R. Leyden, Y. Jiang, Y. Qi, Chemical vapor deposition grown formamidinium perovskite solar modules with high steady state power and thermal stability. _J. Mater. Chem. A_ **4** , 13125–13132 (2016). 

13. J. Li, H. Wang, X. Y. Chin, H. A. Dewi, K. Vergeer, T. W. Goh, J. W. M. Lim, J. H. Lew, K. Ping Loh, C. Soci, T. C. Sum, H. J. Bolink, N. Mathews, S. Mhaisalkar, A. Bruno, Highly efficient thermally co-evaporated perovskite solar cells and mini-modules. _Joule_ **4** , 1035–1053 (2020). 

14. D.-K. Lee, D.-N. Jeong, T. K. Ahn, N.-G. Park, Precursor engineering for a large-area perovskite solar cell with >19% efficiency. _ACS Energy Lett._ **4** , 2393–2401 (2019). 

15. J.-W. Lee, D.-H. Kim, H.-S. Kim, S.-W. Seo, S. M. Cho, N.-G. Park, Formamidinium and cesium hybridization for photo- and moisture-stable perovskite solar cell. _Adv. Energy Mater._ **5** , 1501310 (2015). 

16. S. H. Turren-Cruz, A. Hagfeldt, M. Saliba, Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

17. L. Qiu, S. He, L. K. Ono, S. Liu, Y. Qi, Scalable fabrication of metal halide perovskite solar cells and modules. _ACS Energy Lett._ **4** , 2147–2167 (2019). 

18. J.-W. Lee, Z. Dai, C. Lee, H. M. Lee, T.-H. Han, N. D. Marco, O. Lin, C. S. Choi, B. Dunn, J. Koh, D. D. Carlo, J. H. Ko, H. D. Maynard, Y. Yang, Tuning molecular interactions for highly reproducible and efficient formamidinium perovskite solar cells via adduct approach. _J. Am. Chem. Soc._ **140** , 6317–6324 (2018). 

19. J. Xu, C. C. Boyd, Z. J. Yu, A. F. Palmstrom, D. J. Witter, B. W. Larson, R. M. France, J. Werner, S. P. Harvey, E. J. Wolf, W. Weigand, S. Manzoor, M. F. A. M. van Hest, J. J. Berry, J. M. Luther, Z. C. Holman, M. D. McGehee, Triple-halide wide–band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097–1104 (2020). 

20. N.-G. Park, Crystal growth engineering for high efficiency perovskite solar cells. _CrstEngComm_ **18** , 5977–5985 (2016). 

21. Y. Galagan, F. D. Giacomo, H. Gorter, G. Kirchner, I. de Vries, R. Andriessen, P. Groen, Roll-to-roll slot die coated perovskite for efficient flexible solar cells. _Adv. Energy Mater._ **8** , 1801935 (2018). 

22. F. Guo, S. Qiu, J. Hu, H. Wang, B. Cai, J. Li, X. Yuan, X. Liu, K. Forberich, C. J. Brabec, Y. Mai, A generalized crystallization protocol for scalable deposition of high-quality perovskite thin films for photovoltaic applications. _Adv. Sci._ **6** , 1901067 (2019). 

23. K.-S. Lim, D.-K. Lee, J.-W. Lee, N.-G. Park, 17% efficient perovskite solar mini-module via hexamethylphosphoramide (HMPA)-adduct-based large-area D-bar coating. _J. Mater. Chem. A_ **8** , 9345–9354 (2020). 

24. H. Pettersson, T. Gruszecki, C. Schnetz, M. Streit, Y. Xu, L. Sun, M. Gorlov, L. Kloo, G. Boschloo, L. Häggman, A. Hagfeldt, Parallel-connected monolithic dye-sensitised solar modules. _Prog. Photovolt. Res. Appl._ **18** , 340–345 (2010). 

25. E. Bi, W. Tang, H. Chen, Y. Wang, J. Barbaud, T. Wu, W. Kong, P. Tu, H. Zhu, X. Zeng, J. He, S.-i. Kan, X. Yang, M. Grätzel, L. Han, Efficient perovskite solar cell modules with high stability enabled by iodide diffusion barriers. _Joule_ **3** , 2748–2760 (2019). 

**11 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

26. K. A. Bush, A. F. Palmstrom, Z. J. Yu, M. Boccard, R. Cheacharoen, J. P. Mailoa, D. P. McMeekin, R. L. Z. Hoye, C. D. Bailie, T. Leijtens, I. M. Peters, M. C. Minichetti, N. Rolston, R. Prasanna, S. Sofia, D. Harwood, W. Ma, F. Moghadam, H. J. Snaith, T. Buonassisi, Z. C. Holman, S. F. Bent, M. D. McGehee, 23.6%-efficient monolithic 

   - perovskite/silicon tandem solar cells with improved stability. _Nat. Energy_ **2** , 17009 (2017). 

27. D. P. McMeekin, G. Sadoughi, W. Rehman, G. E. Eperon, M. Saliba, M. T. Hörantner, A. Haghighirad, N. Sakai, L. Korte, B. Rech, M. B. Johnston, L. M. Herz, H. J. Snaith, A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151–155 (2016). 

28. F. Huang, M. Li, P. Siffalovic, G. Cao, J. Tian, From scalable solution fabrication of perovskite films towards commercialization of solar cells. _Energ. Environ. Sci._ **12** , 518–549 (2019). 

29. L. Zeng, S. Chen, K. Forberich, C. J. Brabec, Y. Mai, F. Guo, Controlling the crystallization dynamics of photovoltaic perovskite layers on larger-area coatings. _Energ. Environ. Sci._ **13** , 4666–4690 (2020). 

30. J. Cao, X. Jing, J. Yan, C. Hu, R. Chen, J. Yin, J. Li, N. Zheng, Identifying the molecular structures of intermediates for optimizing the fabrication of high-quality perovskite films. _J. Am. Chem. Soc._ **138** , 9919–9926 (2016). 

31. S. Paek, P. Schouwink, E. N. Athanasopoulou, K. T. Cho, G. Grancini, Y. Lee, Y. Zhang, F. Stellacci, M. K. Nazeeruddin, P. Gao, From nano- to micrometer scale: The role of antisolvent treatment on high performance perovskite solar cells. _Chem. Mater._ **29** , 3490–3498 (2017). 

32. K. Yan, M. Long, T. Zhang, Z. Wei, H. Chen, S. Yang, J. Xu, Hybrid halide perovskite solar cell precursors: Colloidal chemistry and coordination engineering behind device processing for high efficiency. _J. Am. Chem. Soc._ **137** , 4460–4468 (2015). 

33. A. Ummadisingu, L. Steier, J.-Y. Seo, T. Matsui, A. Abate, W. Tress, M. Grätzel, The effect of illumination on the formation of metal halide perovskite films. _Nature_ **545** , 208–212 (2017). 

34. N. Li, S. Tao, Y. Chen, X. Niu, C. K. Onwudinanti, C. Hu, Z. Qiu, Z. Xu, G. Zheng, L. Wang, Y. Zhang, L. Li, H. Liu, Y. Lun, J. Hong, X. Wang, Y. Liu, H. Xie, Y. Gao, Y. Bai, S. Yang, G. Brocks, Q. Chen, H. Zhou, Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. _Nat. Energy_ **4** , 408–415 (2019). 

35. N. Zhou, Y. Shen, Y. Zhang, Z. Xu, G. Zheng, L. Li, Q. Chen, H. Zhou, CsI pre-intercalation in the inorganic framework for efficient and stable FA1-xCsxPbI3(Cl) perovskite solar cells. _Small_ **13** , 1700484 (2017). 

36. Z. Liu, L. K. Ono, Y. Qi, Additives in metal halide perovskite films and their applications in solar cells. _J. Energy Chem._ **46** , 215–228 (2020). 

37. E. Wlaźlak, W. Macyk, W. Nitek, K. Szaciłowsk, Influence of -iodide intermolecular interactions on electronic properties of tin(IV) iodide semiconducting complexes. _Inorg. Chem._ **55** , 5935–5945 (2016). 

38. S. Rahimnejad, A. Kovalenko, S. M. Forés, C. Aranda, A. Guerrero, Coordination chemistry dictates the structural defects in lead halide perovskites. _ChemPhysChem_ **17** , 2795–2798 (2016). 

39. X. Deng, Z. Cao, Y. Yuan, M. O. L. Chee, L. Xie, A. Wang, Y. Xiang, T. Li, P. Dong, L. Ding, F. Hao, Coordination modulated crystallization and defect passivation in high quality perovskite film for efficient solar cells. _Coord. Chem. Rev._ **420** , 213408 (2020). 

40. P. Zhao, B. J. Kim, X. Ren, D. G. Lee, G. J. Bang, J. B. Jeon, W. B. Kim, H. S. Jung, Antisolvent with an ultrawide processing window for the one-step fabrication of efficient and large-area perovskite solar cells. _Adv. Mater._ **30** , 1802763 (2018). 

41. M. Xiao, F. Huang, W. Huang, Y. Dkhissi, Y. Zhu, J. Etheridge, A. Gray-Weale, U. Bach, Y.-B. Cheng, L. Spiccia, A fast deposition-crystallization procedure for highly efficient lead iodide perovskite thin-film solar cells. _Angew. Chem. Int. Ed._ **53** , 9898–9903 (2014). 

42. H. Min, M. Kim, S.-U. Lee, H. Kim, G. Kim, K. Choi, J. H. Lee, S. I. Seok, Efficient, stable solar cells by using inherent bandgap of -phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

43. W. Chen, Y. Wu, Y. Yue, J. Liu, W. Zhang, X. Yang, H. Chen, E. Bi, I. Ashraful, M. Grätzel, L. Han, Efficient and stable large-area perovskite solar cells with inorganic charge extraction layers. _Science_ **350** , 944–948 (2015). 

44. M. Stolterfoht, C. M. Wolff, J. A. Márquez, S. Zhang, C. J. Hages, D. Rothhardt, S. Albrecht, P. L. Burn, P. Meredith, T. Unold, D. Neher, Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

45. S. Wu, R. Chen, S. Zhang, B. H. Babu, Y. Yue, H. Zhu, Z. Yang, C. Chen, W. Chen, Y. Huang, S. Fang, T. Liu, L. Han, W. Chen, A chemically inert bismuth interlayer enhances long-term stability of inverted perovskite solar cells. _Nat. Commun._ **10** , 1161 (2019). 

46. A. L. Palma, F. Matteocci, A. Agresti, S. Pescetelli, E. Calabrò, L. Vesce, S. Christiansen, M. Schmidt, A. Di Carlo, Laser-patterning engineering for perovskite solar modules with 95% aperture ratio. _IEEE J. Photovolt._ **7** , 1674–1680 (2017). 

47. L. Qiu, Z. Liu, L. K. Ono, Y. Jiang, D.-Y. Son, Z. Hawash, S. He, Y. Qi, Scalable fabrication of stable high efficiency perovskite solar cells and modules utilizing room temperature sputtered SnO2 electron transport layer. _Adv. Funct. Mater._ **29** , 1806779 (2018). 

48. K. Domanski, E. A. Alharbi, A. Hagfeldt, M. Grätzel, W. Tress, Systematic investigation of the impact of operation conditions on the degradation behaviour of perovskite solar cells. _Nat. Energy_ **3** , 61–67 (2018). 

49. K. Domanski, B. Roose, T. Matsui, M. Saliba, S.-H. Turren-Cruz, J.-P. Correa-Baena, C. R. Carmona, G. Richardson, J. M. Foster, F. D. Angelis, J. M. Ball, A. Petrozza, N. Mine, M. K. Nazeeruddin, W. Tress, M. Grätzel, U. Steiner, A. Hagfeldt, A. Abate, Migration of cations induces reversible performance losses over day/night cycling in perovskite solar cells. _Energ. Environ. Sci._ **10** , 604–613 (2017). 

50. M. Jošt, B. Lipovšek, B. Glažar, A. Al-Ashouri, K. Brecl, G. Matič, A. Magomedov, V. Getautis, M. Topič, S. Albrecht, Perovskite solar cells go outdoors: Field testing and temperature effects on energy yield. _Adv. Energy Mater._ **10** , 2000454 (2020). 

51. M. V. Khenkin, E. A. Katz, A. Abate, G. Bardizza, J. J. Berry, C. Brabec, F. Brunetti, V. Bulović, Q. Burlingame, A. Di Carlo, R. Cheacharoen, Y.-B. Cheng, A. Colsmann, S. Cros, K. Domanski, M. Dusza, C. J. Fell, S. R. Forrest, Y. Galagan, D. Di Girolamo, M. Grätzel, A. Hagfeldt, E. von Hauff, H. Hoppe, J. Kettle, H. Köbler, M. S. Leite, S. Liu, Y.-L. Loo, J. M. Luther, C.-Q. Ma, M. Madsen, M. Manceau, M. Matheron, M. McGehee, R. Meitzner, M. K. Nazeeruddin, A. F. Nogueira, Ç. Odabaşı, A. Osherov, N.-G. Park, M. O. Reese, F. De Rossi, M. Saliba, U. S. Schubert, H. J. Snaith, S. D. Stranks, W. Tress, P. A. Troshin, V. Turkovic, S. Veenstra, I. Visoly-Fisher, A. Walsh, T. Watson, H. Xie, R. Yıldırım, S. M. Zakeeruddin, K. Zhu, M. Lira-Cantu, Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

52. E. Velilla, F. Jaramillo, I. Mora-Seró, High-throughput analysis of the ideality factor to evaluate the outdoor performance of perovskite solar minimodules. _Nat. Energy_ **6** , 54–62 (2021). 

53. J. A. Raiford, S. T. Oyakhire, S. F. Bent, Applications of atomic layer deposition and chemical vapor deposition for perovskite solar cells. _Energ. Environ. Sci._ **13** , 1997–2023 (2020). 

54. S. Zhang, Z. Liu, W. Zhang, Z. Jiang, W. Chen, R. Chen, Y. Huang, Z. Yang, Y. Zhang, L. Han, W. Chen, Barrier designs in perovskite solar cells for long-term stability. _Adv. Energy Mater._ **10** , 2001610 (2020). 

55. S. Seo, S. Jeong, C. Bae, N.-G. Park, H. Shin, Perovskite solar cells with inorganic electron- and hole-transport layers exhibiting long-term (≈500 h) stability at 85 °C under continuous 1 Sun illumination in ambient air. _Adv. Mater._ **30** , 1801010 (2018). 

56. G. Kresse, D. Joubert, From ultrasoft pseudopotentials to the projector augmented-wave method. _Phys. Rev. B_ **59** , 1758–1775 (1999). 

57. G. Kresse, J. Furthmüller, Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

58. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

59. S. Grimme, J. Antony, S. Ehrlich, H. Krieg, A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

60. S. Grimme, Density functional theory with London dispersion corrections. _WIREs Comput. Mol. Sci._ **1** , 211–228 (2011). 

61. D.-K. Lee, K.-S. Lim, J.-W. Lee, N.-G. Park, Scalable perovskite coating via anti-solvent-free Lewis acid–base adduct engineering for efficient perovskite solar modules. _J. Mater. Chem. A_ **9** , 3018–3028 (2021). 

62. L. Qiu, S. He, Y. Jiang, D.-Y. Son, L. K. Ono, Z. Liu, T. Kim, T. Bouloumis, S. Kazaoui, Y. Qi, Hybrid chemical vapor deposition enables scalable and stable Cs-FA mixed cation perovskite solar modules with a designated area of 91.8 cm<sup>2</sup> approaching 10% efficiency. _J. Mater. Chem. A_ **7** , 6920–6929 (2019). 

63. Y. Jiang, M. R. Leyden, L. Qiu, S. Wang, L. K. Ono, Z. Wu, E. J. Juarez-Perez, Y. Qi, Combination of hybrid CVD and cation exchange for upscaling Cs-substituted mixed cation perovskite solar cells with high efficiency and stability. _Adv. Funct. Mater._ **28** , 1703835 (2018). 

64. Y. Jiang, M. Remeika, Z. Hu, E. J. Juarez-Perez, L. Qiu, Z. Liu, T. Kim, L. K. Ono, D.-Y. Son, Z. Hawash, M. R. Leyden, Z. Wu, L. Meng, J. Hu, Y. Qi, Negligible-Pb-waste and upscalable perovskite deposition technology for high-operational-stability perovskite solar modules. _Adv. Energy Mater_ **9** , 1803047 (2019). 

65. S. Tian, J. Li, S. Li, T. Bu, Y. Mo, S. Wang, W. Li, F. Huang, A facile green solvent engineering for up-scaling perovskite solar cell modules. _Sol. Energy_ **183** , 386–391 (2019). 

66. T. Bu, L. Wu, X. Liu, X. Yang, P. Zhou, X. Yu, T. Qin, J. Shi, S. Wang, S. Li, Z. Ku, Y. Peng, F. Huang, Q. Meng, Y.-B. Cheng, J. Zhong, Synergic interface optimization with green solvent engineering in mixed perovskite solar cells. _Adv. Energy Mater._ **7** , 1700576 (2017). 

67. E. H. Jung, N. J. Jeon, E. Y. Park, C. S. Moon, T. J. Shin, T.-Y. Yang, J. H. Noh, J. Seo, Efficient, stable and scalable perovskite solar cells using poly (3-hexylthiophene). _Nature_ **567** , 511–515 (2019). 

68. T. Bu, J. Li, F. Zheng, W. Chen, X. Wen, Z. Ku, Y. Peng, J. Zhong, Y.-B. Cheng, F. Huang, Universal passivation strategy to slot-die printed SnO2 for hysteresis-free efficient flexible perovskite solar module. _Nat. Commun._ **9** , 4609 (2018). 

**12 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

69. A. Ren, H. Lai, X. Hao, Z. Tang, H. Xu, B. M. F. Y. Jeco, K. Watanabe, L. Wu, J. Zhang, 

   - M. Sugiyama, J. Wu, D. Zhao, Efficient perovskite solar modules with minimized 

   - nonradiative recombination and local carrier transport losses. _Joule_ **4** , 1263–1277 (2020). 

70. Z. Huang, X. Hu, C. Liu, X. Meng, Z. Huang, J. Yang, X. Duan, J. Long, Z. Zhao, L. Tan, Y. Song, Y. Chen, Water-resistant and flexible perovskite solar cells via a glued interfacial layer. _Adv. Funct. Mater._ **29** , 1902629 (2019). 

71. G. S. Han, J. Kim, S. Bae, S. Han, Y. J. Kim, O. Y. Gong, P. Lee, M. J. Ko, H. S. Jung, Spin-coating process for 10 cm × 10 cm perovskite solar modules enabled by self-assembly of SnO2 nanocolloids. _ACS Energy Lett._ **4** , 1845–1851 (2019). 

72. T. Bu, X. Liu, Y. Zhou, J. Yi, X. Huang, L. Luo, J. Xiao, Z. Ku, Y. Peng, F. Huang, Y.-B. Cheng, J. Zhong, A novel quadruple-cation absorber for universal hysteresis elimination for high efficiency and stable perovskite solar cells. _Energ. Environ. Sci._ **10** , 2509–2515 (2017). 

73. T. Bu, X. Liu, J. Li, W. Huang, Z. Wu, F. Huang, Y.-B. Cheng, J. Zhong, Dynamic antisolvent engineering for spin coating of 10 × 10 cm<sup>2</sup> perovskite solar module approaching 18%. _Sol. RRL_ **4** , 1900263 (2019). 

74. T. Bu, S. Shi, J. Li, Y. Liu, J. Shi, L. Chen, X. Liu, J. Qiu, Z. Ku, Y. Peng, J. Zhong, Y.-B. Cheng, 

   - F. Huang, Low-temperature presynthesized crystalline tin oxide for efficient flexible perovskite solar cells and modules. _ACS Appl. Mater. Interfaces_ **10** , 14922–14929 (2018). 

75. F. Zhang, J. Cong, Y. Li, J. Bergstrand, H. Liu, B. Cai, A. Hajian, Z. Yao, L. Wang, Y. Hao, X. Yang, J. M. Gardner, H. Ågren, J. Widengren, L. Kloo, L. Sun, A facile route to grain morphology controllable perovskite thin films towards highly efficient perovskite solar cells. _Nano Energy_ **53** , 405–414 (2018). 

76. S. Razza, F. Di Giacomo, F. Matteocci, L. Cinà, A. L. Palma, S. Casaluci, P. Cameron, A. D'Epifanio, S. Licoccia, A. Reale, T. M. Brown, A. Di Carlo, Perovskite solar cells and large area modules (100 cm<sup>2</sup> ) based on an air flow-assisted PbI2 blade coating deposition process. _J. Power Sources_ **277** , 286–291 (2015). 

77. Y. Deng, C. H. Van Brackle, X. Dai, J. Zhao, B. Chen, J. Huang, Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. _Sci. Adv._ **5** , eaax7537 (2019). 

78. X. Dai, Y. Deng, C. H. Van Brackle, S. Chen, P. N. Rudd, X. Xiao, Y. Lin, B. Chen, J. Huang, Scalable Fabrication of efficient perovskite solar modules on flexible glass substrates. _Adv. Energy Mater._ **10** , 1903108 (2020). 

79. Y. Deng, Z. Ni, A. F. Palmstrom, J. Zhao, S. Xu, C. H. V. Brackle, X. Xiao, K. Zhu, J. Huang, Reduced self-doping of perovskites induced by short annealing for efficient solar modules. _Joule_ **4** , 1949–1960 (2020). 

80. K. Hwang, Y.-S. Jung, Y.-J. Heo, F. H. Scholes, S. E. Watkins, J. Subbiah, D. J. Jones, D.-Y. Kim, D. Vak, Toward large scale roll-to-roll production of fully printed perovskite solar cells. _Adv. Mater._ **27** , 1241–1247 (2015). 

81. L. Cai, L. Liang, J. Wu, B. Ding, L. Gao, B. Fan, Large area perovskite solar cell module. _J. Semiconduct._ **38** , 014006 (2017). 

82. H. Chen, F. Ye, W. Tang, J. He, M. Yin, Y. Wang, F. Xie, E. Bi, X. Yang, M. Grätzel, L. Han, A solvent- and vacuum-free route to large-area perovskite films for efficient solar modules. _Nature_ **550** , 92–95 (2017). 

83. T. Gotanda, H. Oooka, S. Mori, H. Nakao, A. Amano, K. Todori, Y. Nakai, K. Mizuguchi, Facile and scalable fabrication of low-hysteresis perovskite solar cells and modules using a three-step process for the perovskite layer. _J. Power Sources_ **430** , 145–149 (2019). 

84. Z. Liu, L. Qiu, E. J. Juarez-Perez, Z. Hawash, T. Kim, Y. Jiang, Z. W. Wu, S. R. Raga, L. K. Ono, S. F. Liu, Y. B. Qi, Gas-solid reaction based over one-micrometer thick stable perovskite films for efficient solar cells and modules. _Nat. Commun._ **9** , 3880 (2018). 

85. L. Gao, L. Chen, S. Huang, X. Li, G. Yang, Series and parallel module design for large-area perovskite solar cells. _ACS Appl. Energy Mater._ **2** , 3851–3859 (2019). 

86. J.-S. Yeo, C.-H. Lee, D. Jang, S. Lee, S. M. Jo, H.-I. Joh, D.-Y. Kim, Reduced graphene oxide-assisted crystallization of perovskite via solution-process for efficient and stable planar solar cells with module-scales. _Nano Energy_ **30** , 667–676 (2016). 

87. J. H. Heo, H. J. Han, D. Kim, T. K. Ahn, S. H. Im, Hysteresis-less inverted CH3NH3PbI3 planar perovskite hybrid solar cells with 18.1% power conversion efficiency. _Energ. Environ. Sci._ **8** , 1602–1608 (2015). 

88. A. Agresti, S. Pescetelli, A. L. Palma, A. E. Del Rio Castillo, D. Konios, G. Kakavelakis, S. Razza, L. Cinà, E. Kymakis, F. Bonaccorso, A. Di Carlo, Graphene interface engineering for perovskite solar modules: 12.6% power conversion efficiency over 50 cm<sup>2</sup> active area. _ACS Energy Lett._ **2** , 279–287 (2017). 

89. C.-H. Chiang, M. K. Nazeeruddin, M. Grätzel, C.-G. Wu, The synergistic effect of H2O and DMF towards stable and 20% efficiency inverted perovskite solar cells. _Energ. Environ. Sci._ **10** , 808–817 (2017). 

90. A. Priyadarshi, L. J. Haur, P. Murray, D. Fu, S. Kulkarni, G. Xing, T. C. Sum, N. Mathews, S. G. Mhaisalkar, A large area (70 cm<sup>2</sup> ) monolithic perovskite solar module with a high efficiency and stability. _Energ. Environ. Sci._ **9** , 3687–3692 (2016). 

91. J. Troughton, K. Hooper, T. M. Watson, Humidity resistant fabrication of CH3NH3PbI3 perovskite solar cells and modules. _Nano Energy_ **39** , 60–68 (2017). 

92. E. Calabrò, F. Matteocci, A. L. Palma, L. Vesce, B. Taheri, L. Carlini, I. Pis, S. Nappini, J. Dagar, C. Battocchio, T. M. Brown, A. Di Carlo, Low temperature, solution-processed perovskite 

solar cells and modules with an aperture area efficiency of 11%. _Sol. Energy Mater. Sol. Cells_ **185** , 136–144 (2018). 

93. H.-C. Liao, P. Guo, C.-P. Hsu, M. Lin, B. Wang, L. Zeng, W. Huang, C. M. M. Soe, W.-F. Su, M. J. Bedzyk, M. R. Wasielewski, A. Facchetti, R. P. H. Chang, M. G. Kanatzidis, T. J. Marks, Enhanced efficiency of hot-cast large-area planar perovskite solar cells/modules having controlled chloride incorporation. _Adv. Energy Mater._ **7** , 1601660 (2017). 

94. Y. Hu, S. Si, A. Mei, Y. Rong, H. Liu, X. Li, H. Han, Stable large-area (10 × 10 cm<sup>2</sup> ) printable mesoscopic perovskite module exceeding 10% efficiency. _Solar RRL_ **1** , 1600019 (2017). 

95. G. Grancini, C. Roldán-Carmona, I. Zimmermann, E. Mosconi, X. Lee, D. Martineau, S. Narbey, F. Oswald, F. De Angelis, M. Gräetzel, M. K. Nazeeruddin, One-year stable perovskite solar cells by 2D/3D interface engineering. _Nat. Commun._ **8** , 15684 (2017). 

96. F. Bella, G. Griffini, J.-P. Correa-Baena, G. Saracco, M. Grätzel, A. Hagfeldt, S. Turri, C. Gerbaldi, Improving efficiency and stability of perovskite solar cells with photocurable fluoropolymers. _Science_ **354** , 203–206 (2016). 

97. Z. Fu, M. Xu, Y. Sheng, Z. Yan, J. Meng, C. Tong, D. Li, Z. Wan, Y. Ming, A. Mei, Y. Hu, Y. Rong, H. Han, Encapsulation of printable mesoscopic perovskite solar cells enables high temperature and long-term outdoor stability. _Adv. Funct. Mater._ **29** , 1809129 (2019). 

98. X. Li, M. Tschumi, H. Han, S. S. Babkair, R. A. Alzubaydi, A. A. Ansari, S. S. Habib, M. K. Nazeeruddin, S. M. Zakeeruddin, M. Grätzel, Outdoor performance and stability under elevated temperatures and long-term light soaking of triple-layer mesoporous perovskite photovoltaics. _Energ. Technol._ **3** , 551–555 (2015). 

99. M. V. Khenkin, K. M. Anoop, I. Visoly-Fisher, Y. Galagan, F. Di Giacomo, B. R. Patil, G. Sherafatipour, V. Turkovic, H.-G. Rubahn, M. Madsen, T. Merckx, G. Uytterhoeven, J. P. A. Bastos, T. Aernouts, F. Brunetti, M. Lira-Cantu, E. A. Katz, Reconsidering figures of merit for performance and stability of perovskite photovoltaics. _Energ. Environ. Sci._ **11** , 739–743 (2018). 

100. Y. Reyna, M. Salado, S. Kazim, A. Pérez-Tomas, S. Ahmad, M. Lira-Cantu, Performance and stability of mixed FAPbI3(0.85)MAPbBr3(0.15) halide perovskite solar cells under outdoor conditions and the effect of low light irradiation. _Nano Energy_ **30** , 570–579 (2016). 

**Acknowledgments:** We thank the Analytical and Testing Center from HUST and the Center for Nanoscale Characterization and Devices (CNCD) from WNLO (HUST) for the facility support of sample measurements. We would like to thank Ezhou Industrial Technology Research Institute (HUST) for the facility support of fabricating PSMs. We thank W. Bao and J. Hu from HUST for providing the facility of DLS measurements. We also thank W. Zhang and H. Han for providing the facility for the TRPL characterization in WNLO (HUST). We also would like to thank J. Yao and T. Wang from Wuhan University of Technology for providing the PL mapping measurement facility for large-area perovskite films. **Funding:** This work was financially supported by the National Natural Science Foundation of China (51672094, 51861145404, 51822203, and 52002140), the Natural Science Foundation of Hubei Province (ZRMS2020001132), and the Self-determined and Innovative Research Funds of HUST (2018KFYRCPY003 and 2020kfyXJJS008). L.K.O. and Y.Q. acknowledge the funding support from the Energy Materials and Surface Sciences Unit of the Okinawa Institute of Science and Technology Graduate University, the OIST R&D Cluster Research Program, and the OIST Proof of Concept (POC) Program. **Author contributions:** W.C. and Zonghao Liu supervised the whole project. Z.Y., W.Z., S.W., H.Z., and W.C. conceived the idea and designed the experiment. Z.Y. and S.W. prepared the perovskite precursors and films for characterization. Z.Y. and R.C. carried out the cross-sectional characterization of the fabricated solar module by SEM. Z.Y., Q.L., and J.Z. performed the ALD for Al2O3 film and cover glass encapsulation. W.Z. and H.Z. tested the module stability under real day/night cycling working conditions and continuous irradiation, respectively. W.Z. and W.C. performed the module certification process. W.Z. and Z.J. fabricated some modules for device performance characterization. Zhiyang Liu and Z.X. performed the theoretical calculation and analyzed the results. Z.Y. prepared the manuscript. Zonghao Liu, L.S., S.Z., Y.Z., L.K.O., Y.Q., H.C., L.H., and W.C. revised the paper. All authors contributed to the data analysis, discussed the results, and commented on the manuscript. **Competing interests:** W.C., S.W., and W.Z. are the inventors on a provisional patent application related to this work filed by Ezhou Industrial Technology Research Institute, HUST (no. CN201810683527.7, filed 28 June 2018). The authors declare that they have no other competing interests. **Data and materials availability:** All data are available in the manuscript or the Supplementary Materials. Additional data related to this paper may be requested from the corresponding authors. 

Submitted 31 December 2020 Accepted 11 March 2021 Published 30 April 2021 10.1126/sciadv.abg3749 

**Citation:** Z. Yang, W. Zhang, S. Wu, H. Zhu, Z. Liu, Z. Liu, Z. Jiang, R. Chen, J. Zhou, Q. Lu, Z. Xiao, L. Shi, H. Chen, L. K. Ono, S. Zhang, Y. Zhang, Y. Qi, L. Han, W. Chen, Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module. _Sci. Adv._ **7** , eabg3749 (2021). 

**13 of 13** 

Yang _et al_ ., _Sci. Adv._ 2021; **7** : eabg3749     30 April 2021 



## **Slot-die coating large-area formamidinium-cesium perovskite film for efficient and stable parallel solar module** 

Zhichun Yang, Wenjun Zhang, Shaohang Wu, Hongmei Zhu, Zonghao Liu, Zhiyang Liu, Zhaoyi Jiang, Rui Chen, Jing Zhou, Qian Lu, Zewen Xiao, Lei Shi, Han Chen, Luis K. Ono, Shasha Zhang, Yiqiang Zhang, Yabing Qi, Liyuan Han, and Wei Chen 

_Sci. Adv._ **7** (18), eabg3749.  DOI: 10.1126/sciadv.abg3749 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abg3749 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

> _Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

