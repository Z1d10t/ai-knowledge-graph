# Hydrogen-bond-bridged intermediate for perovskite solar cells with enhanced efficiency and stability

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Photonics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 290 |
| 作者 | Fengzhu Li, Xiang Deng, Zhang-Wang Shi, Shengfan Wu, Zi-Xin Zeng, Deng Wang, Yang Li, Feng-Xiao Qi et al. |
| DOI | 10.1038/s41566-023-01180-6 |
| 源文件 | 030_Li_2023_Hydrogen-bond-bridged-intermediate-for-perovskit.pdf |

---
## **nature photonics** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 

# **Hydrogen-bond-bridged intermediate for perovskite solar cells with enhanced efficiency and stability** 

|Received: 12 September 2022<br>Accepted: 17 February 2023<br>Published online: 10 April 2023|**Fengzhu Li**<sup>**1,2,3,6**</sup>**, Xiang Deng**<sup>**1,2,3,6**</sup>**, Zhangsheng Shi**<br> <sup>**2**</sup>**, Shengfan Wu**<sup>**1,3**</sup>**,**<br>**Zixin Zeng**<sup>**1**</sup>**, Deng Wang**<sup>**1,3**</sup>**, Yang Li**<sup>**2**</sup>**, Feng Qi**<sup>**2,3**</sup>**, Zhuomin Zhang**<br> <sup>**4**</sup>**,**<br>**Zhengbao Yang**<br> <sup>**4**</sup>**, Sei-Hum Jang**<sup>**5**</sup>**, Francis R. Lin**<br> <sup>**2,3**</sup>**, Sai**‐**Wing Tsang**<br> <sup>**1**</sup>**,**<br>**Xian-Kai Chen**<br> <sup>**1,2**</sup>**& Alex K.-Y. Jen**<br> <sup>**1,2,3,5**</sup>|
|---|---|
|Check for updates||
||Improving the intrinsic film quality of metal halide perovskites is very<br>critical to increase the power conversion efficiency and long-term stability<br>of perovskite solar cells. Here we report a multifunctional, non-volatile<br>additive that can be used to modulate the kinetics of perovskite film growth<br>through a hydrogen-bond-bridged intermediate phase. The additive enables<br>the formation of large perovskite grains and coherent grain growth from<br>bottom to the surface of the film. The enhanced film morphology results<br>in significantly reduced non-radiative recombinations, thus boosting the<br>power conversion efficiency of inverted (p–i–n) solar cells to 24.8% (24.5%<br>certified) with a low energy loss of 0.36 eV. The unencapsulated devices<br>exhibit improved thermal stability with a_T_98lifetime beyond 1,000 h under<br>continuous heating at 65 ± 5 °C in a nitrogen-filled glovebox. This effective<br>approach can also be applied to wide-bandgap perovskites and large-area<br>devices to show reduced voltage loss and high efficiency.|



Organic–inorganic hybrid perovskites have garnered great attention due to their impressive optoelectronic properties<sup>1</sup> . Combining compositional and interfacial engineering strategies, the record power conversion efficiency (PCE) of perovskite solar cells (PVSCs) has now reached 25.7% (ref. 2) (https://www.nrel.gov/pv/cell-efficiency.html). However, the reported high-efficiency devices mostly comprise the conventional (n–i–p) architecture<sup>3–5</sup> , whereas inverted (p–i–n) PVSCs still show inferior performance despite their low-temperature processability and better compatibility in fabricating tandem and flexible devices<sup>6–10</sup> . The major challenge stems from the severe energy loss in inverted PVSCs, especially the non-radiative recombination loss associated with defects embedded at the interfaces and grain boundaries<sup>11</sup> . A high-quality perovskite film with intrinsically low defect density is, thus, critical in determining the achievable efficiency and stability for PVSCs<sup>12</sup> . 

In a typical one-step solution process, perovskite precursors dissolved in polar aprotic solvents are spin coated onto the substrate. The introduction of an antisolvent then quickly extracts the residual solvents and templates the perovskite crystal growth through intermediate phases<sup>13</sup> . Various volatile solvents and organic salts have been employed as additives to tune the intermediate compositions for modulating the crystallization kinetics<sup>14–16</sup> . In one work, _N_ -methyl-2-pyrrolidone was added in the perovskite precursors to form a lead iodide (PbI2)– _N_ -methyl-2-pyrrolidone adduct for promoting the black-phase formation at room temperature<sup>15</sup> . In another work, methylammonium chloride (MACl) was used to facilitate the formation of an intermediate phase for stabilizing the perovskite α-phase<sup>16</sup> . However, these additives may volatilize during annealing, creating voids at the perovskite–substrate interface, 

> 1Department of Materials Science and Engineering, City University of Hong Kong, Hong Kong SAR, China. 2Department of Chemistry, City University of Hong Kong, Hong Kong SAR, China.<sup>3</sup> Hong Kong Institute for Clean Energy, City University of Hong Kong, Hong Kong SAR, China.<sup>4</sup> Department of Mechanical Engineering, City University of Hong Kong, Hong Kong SAR, China.<sup>5</sup> Department of Materials Science & Engineering, University of Washington, Seattle, WA, USA.<sup>6</sup> These authors contributed equally: Fengzhu Li, Xiang Deng. e-mail: alexjen@cityu.edu.hk 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**478** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 



<!-- Start of picture text -->
a c e<br>Target Control 160 Control<br>Target 140 Target<br>120<br>100<br>Control<br>Control 80<br>#<br>60<br>40<br>20<br>* #<br>0<br>3,400 3,230 3,060 1,800 1,750 1,700 1,650 5 10 15 20 25 30 35 40 45<br>Wavenumber (cm –1 ) 2 θ  (°)<br>b d f<br>0.6<br>Pb4 f 7/2 Target Target Control<br>Pb4 f 5/2 0.5 Target<br>0.4<br>0.3<br>Control<br>0.2<br>0.1<br>0<br>144 142 140 138 136 134 –1,000 –800 –600 –400 –200 0<br>Binding energy (eV) Potential (mV)<br> (%) T<br>3 a.u.)Intensity (×10<br>Data histogram (%)<br>Intensity (counts per second)<br><!-- End of picture text -->

**Fig. 1 | Chemical interaction and morphology characterization of the perovskite films. a** , FTIR spectra of the control and target films. **b** , Pb4 _f_ XPS spectra of the control and target films. **c** , **d** , Surface (up) and cross-section (down) SEM images of the control ( **c** ) and target ( **d** ) perovskite films. Scale bars, 1 μm. **e** , 

XRD patterns of the control and target films. Here * denotes the diffraction peak of PbI2, and # denotes the diffraction peak of ITO. **f** , Statistical distribution of surface potential extracted from the KPFM images. 

inducing unavoidable recombination loss and fast degradation of the perovskite<sup>17</sup> . 

Here we report the formation of a hydrogen-bond-bridged intermediate by adding a multifunctional molecule (4-guanidinobenzoic acid hydrochloride (GBAC)) into the perovskite precursor to modulate the crystallization kinetics and serve as an effective non-volatile passivation linker in the annealed film. Combining crystallography, in situ photoluminescence (PL) characterizations and density functional theory (DFT) calculations, we reveal that the crystal growth kinetics is regulated by additional energies required for hydrogen-bond breakage and cation exchange between the intermediate phase and perovskite. Therefore, the obtained perovskite films exhibit significantly enhanced crystallinity with larger grains. Besides, the additives can form tight packs at the grain boundaries due to π–π interaction of the aryls to effectively passivate the defects in perovskites. The derived inverted PVSCs achieved a champion PCE of 24.8% with an open-circuit voltage ( _V_ OC) of 1.19 V, short-circuit current density ( _J_ SC) of 24.55 mA cm<sup>–2</sup> and fill factor (FF) of 84.78%. A certified PCE of 24.5% was obtained from the Japan Electrical Safety & Environment Technology Laboratories, being among the highest reported for inverted PVSCs (Supplementary Table 1). We also applied this strategy to fabricate wide-bandgap and large-area PVSCs, paving the way for developing multijunction and scalable perovskite photovoltaics. 

#### **Characterization of perovskite films** 

We introduced GBAC as an additive into the perovskite precursor solution, which can interact with the uncoordinated lead and 

organic–inorganic vacancies via Lewis acid–base reactions with the carboxyl and guanidium groups<sup>18</sup> . To verify our hypothesis, we first conducted Fourier transform infrared (FTIR) spectrometry to study the interactions between GBAC and organic species in perovskites. As shown in Fig. 1a and Supplementary Fig. 1, the N–H stretching peak shifted from 3,352 to 3,378 cm<sup>−1</sup> for FA<sup>+</sup> /MA<sup>+</sup> and the C=N stretching peak in FA<sup>+</sup> also shifted from 1,713 to 1,709 cm<sup>−1</sup> on adding GBAC, suggesting the formation of hydrogen bonds between GBAC and organic cations<sup>19</sup> . These indicate that the interplay between GBAC and FA<sup>+</sup> / MA<sup>+</sup> in the perovskite can help strengthen the film stability, especially thermal stability that is mainly governed by the organic species. We then verified this through a thermogravimetric analysis (Supplementary Fig. 2), where the impeded decomposition of the target film suggests that more energy is required to disrupt the interaction between GBAC and perovskite<sup>20</sup> , ameliorating the film’s thermal stability. 

We performed high-resolution X-ray photoelectron spectrometry (XPS) to study the surface chemistry of perovskites (Supplementary Fig. 3). We clearly observed the peak corresponding to GBAC π–π interaction (293.10 eV, C1 _s_ spectrum) and increased the C=O peak area (O1 _s_ spectrum) in the target film, further validating the existence of the GBAC linker in the perovskite (Supplementary Figs. 4 and 5). In the Pb4 _f_ spectrum (Fig. 1b), the binding energy of 4 _f_ 5/2 and 4 _f_ 7/2 for divalent Pb<sup>2+</sup> shifted from 141.92 and 137.09 eV to 141.59 and 136.76 eV, respectively, due to the electrostatic interaction between the guanidium group and PbI64−. We further recorded the steady-state PL and time-resolved PL profiles of perovskite films to reveal how GBAC affects the film quality and charge-transport dynamics (Supplementary Fig. 6). The target 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**479** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 

film exhibits six times stronger PL intensity and three times longer PL lifetime than those of the control film, agreeing well with the FTIR and XPS results that GBAC suppresses the defect-induced non-radiative recombination to reduce energy loss for improving the photovoltaic performance. 

To understand how GBAC addition affects the film morphology, we collected scanning electron microscopy (SEM) images of the perovskite films. The target film shows considerably larger grains (~1 μm) and fewer residual PbI2 sheets than the control film (Fig. 1c,d), with a coherent bottom-to-surface grain growth that can facilitate the transport of carriers to electrodes. Besides good film morphology, the crystallinity of the target film is significantly improved (Fig. 1e). The decreased PbI2 sheets in the SEM images was also confirmed by the X-ray powder diffraction (XRD) patterns, suggesting that GBAC can interact with the uncoordinated Pb<sup>2+</sup> and modulate film growth to obtain fully grown grains. Moreover, the addition of GBAC significantly helps modulate the crystal orientation within the film for facilitating charge transport (Supplementary Fig. 7). 

Atomic force microscopy characterization reveals a lower surface roughness after GBAC addition (Supplementary Fig. 8). We also applied Kelvin probe force microscopy (KPFM) to evaluate the distribution of the surface potential of perovskite films, which shows an increment of 200–300 mV in the target film (Fig. 1f and Supplementary Fig. 9), indicating a Fermi level ( _E_ F) closer to the conductive band edge<sup>21</sup> . The higher work function measured by KPFM matches well with the results obtained from ultraviolet photoelectron spectrometry (UPS), showing a 0.25 eV shift in _E_ F by adding GBAC (Supplementary Fig. 10). The more n-characteristic film surface stems from the modified surface termination after adding GBAC (ref. 22), enabling more efficient charge transfer between the perovskite and electron-transporting materials (Supplementary Fig. 11). 

#### **In situ characterization of film formation** 

To gain more insights into the remarkably enhanced film quality, we adopted in situ PL spectrometry to understand the role of GBAC during film formation<sup>23–25</sup> . The evolution of the PL peak position in both control and target films shows similar trends in the long-term stage (0–750 s) (Supplementary Figs. 12–14). However, the initial peak position of the wet target film was slightly blueshifted compared with that of the control film due to the additional chloride from GBAC (Fig. 2a,b). Also, the target film exhibits a much slower shift with negligible fluctuation in the initial stage (0–10 s) compared with those of the control sample, implying that the crystallization process was significantly retarded by adding GBAC (Fig. 2b)<sup>23</sup> . Moreover, the PL peaks of the target film are more symmetric compared with the control film, indicating a more uniform distribution of crystallite sizes, which facilitates the significantly increased grain sizes, as shown in the SEM images (Fig. 1c,d)<sup>25</sup> . 

We then analysed the evolution of PL peak intensity, which shows typical PL quenching in both films but more severe in the control film (Fig. 2c,d)<sup>24,25</sup> . Such PL quenching originates from the continuously increased Urbäch energy, indicating the gradual formation of defects in the microstructures of perovskites<sup>24</sup> . However, it is considerably inhibited in the target film, showing a much lower defect density and better ambient stability than the control film (Fig. 2d)<sup>26</sup> . The initial stages (0–2 s for the control sample and 0–30 s for the target sample) were then enlarged to clearly show the PL intensity evolution (Fig. 2e,f). The control film shows a typical four-stage ‘up–down–up–down’ process with two states (Fig. 2e)<sup>24</sup> . In state ‘I’ (0–200 ms), the perovskite grains grow freely and are well crystallized/ordered, resulting in an increased PL intensity (‘up’). When the solvent is almost entirely evaporated, the perovskite crystallites are exposed to the surrounding atmosphere and the surfaces of other crystallites, forming grain boundaries and triggering rapid PL quenching (‘down’; 200–400 ms). In state ‘II’, the small crystallites further grow and merge into larger ones on annealing to reduce the overall grain boundaries, resulting in an increased 

PL intensity again (‘up’; 400–600 ms). Such a rapid film formation can also be attributed to the absorbed moisture accumulated within the grain boundaries, inducing grain-boundary creep and subsequent merging of adjacent grains to accelerate the film growth<sup>27</sup> . The partial recovery of PL intensity also comes from the passivation effect of excessive PbI2 at the perovskite grain boundaries<sup>28</sup> . Eventually, the film is vulnerable under ambient conditions and prone to decomposition. This results in a stabilized but almost one order of magnitude lower PL intensity than that of PLmax (‘down’; after 600 ms). However, adding GBAC introduces an extra stage involving the intermediate-induced pre-growth process in the target sample (Fig. 2f)<sup>24,25</sup> . The film formation is significantly slowed down, reaching its maximum PL intensity at ~20 s and maintained for longer time. These results imply that adding GBAC can modulate the crystallization kinetics by forming an additional intermediate to enhance the film quality, leading to larger grain sizes and high crystallinity. 

#### **Film growth with hydrogen-bond-bridged intermediate** 

To study the GBAC-induced intermediate phase, we grew the single crystal of GBAC–PbI2– _N_ , _N_ -dimethylformamide (DMF) (Supplementary Table 2)<sup>29</sup> . We observed strong cyclic hydrogen bonds between the carboxylic acid and guanidium groups as well as DMF and guanidium groups (Fig. 3a). The DMF molecules locked by hydrogen bonds help isolate the PbI2 sheets and GBAC layer, leading to a one-dimensional organic–inorganic hybrid chain structure. Due to the strong dipole of GBAC and the electron delocalization in the guanidium groups (Supplementary Fig. 15), these hydrogen bonds are very different from the typical linear hydrogen-bonded chains that serve as supramolecular synthons for layered perovskite structures<sup>30</sup> . This unique interaction mode helps build a bridge to connect the organic–inorganic components. Moreover, the interaction between GBAC and perovskite precursor components in solution was investigated by<sup>1</sup> H nuclear magnetic resonance spectrometry (Supplementary Fig. 16), of which the results are in good agreement with those observed from XPS and FTIR measurements<sup>7</sup> . Through these studies, we have identified that GBAC can simultaneously interact with the solvent, organic and inorganic components in the precursor solution through both Coulomb interaction and hydrogen bonding, demonstrating its multifunctionality in solution. 

We then conducted a thermal analysis of single crystals to study the phase transition from the intermediate state to perovskite. The experimental XRD pattern of the obtained transparent GBAC–PbI2– DMF crystals matches well with the XRD pattern simulated from the single-crystal structure, confirming their composition (Supplementary Fig. 17). The simultaneous thermal analysis profile shows an intense endothermic peak at ~80 °C corresponding to hydrogen-bond breakage (Supplementary Fig. 18). At elevated temperatures, DMF starts to evaporate, destabilizing the intermediate that then transforms into a new one-dimensional structure composed of GBAC–PbI2 (Fig. 3b and Supplementary Fig. 19). This GBAC–PbI2 phase can only be identified in a perovskite film with >4 mol% GBAC dosage (Supplementary Figs. 20 and 21), where a small dosage of GBAC, in turn, functions as a passivation linker anchoring at the grain boundaries to reduce the defect density and enhance the film stability with its rigid stacking<sup>8</sup> . 

To understand the impact of such hydrogen-bond-bridged intermediate on film growth, periodic DFT calculations were performed to understand if GBAC<sup>+</sup> can spontaneously exchange with FA<sup>+</sup> during the crystallization process. Due to the substantial hydrogen bonding, the formation energy of this intermediate (GBAC–PbI2–DMF) (–18.58 eV) is much lower than that of δ-FAPbI3 (–10.60 eV). Such extra stabilization is not thermodynamically favourable for crystal growth, since extra energy is required to enable the cation exchange between GBAC<sup>+</sup> and FA<sup>+</sup> (ref. 31). During the subsequent thermal annealing, the hydrogen bonds in the GBAC–PbI2–DMF phase were broken to form GBAC–PbI2 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**480** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 



<!-- Start of picture text -->
Evolution of PL peak position Evolution of PL intensity<br>a b c d<br>10,000 10,000 400 400<br>Control Target 350 Control 350 Target<br>8,000 8,000<br>300 300<br>250 250<br>6,000 6,000<br>200 200<br>4,000 4,000 150 150<br>1.0<br>100 100<br>2,000 2,000<br>0.5 50 50<br>0 0 0 0 0<br>720 760 800 840 720 760 800 840 720 760 800 840 720 760 800 840<br>Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>400 2,000 800 8,000 30<br>(i) (ii) (i) (ii) (iii)<br>25<br>1,600<br>300 600 6,000<br>20<br>1,200<br>200 400 4,000 15<br>800<br>10<br>100 200 2,000<br>400 5<br>0 0 0 0 0<br>720 760 800 840 720 760 800 840 720 760 800 840 720 760 800 840 720 760 800 840<br>e f<br>Typical four-stage Extra stage induced by intermediate phase<br>'up–down–up–down' process<br>(i) (ii) (i) (ii) (iii)<br>Time Time<br>3×10 3×10<br>Time (ms)<br>3×10<br>PL intensity PL intensity<br><!-- End of picture text -->

**Fig. 2 | Comparison of film growth kinetics by in situ PL. a** , **b** , Normalized in situ PL peak position evolution of the control ( **a** ) and target ( **b** ) perovskite films. **c** , **d** , Normalized in situ PL intensity evolution of the control ( **c** ) and target ( **d** ) perovskite films. **e** , **f** , Detailed analysis of PL intensity evolution of the control ( **e** ) 

and target ( **f** ) perovskite films. **e** and **f** are enlarged from **c** and **d** , respectively. The titles of the _x_ axis and _y_ axis are ‘wavelength (nm)’ and ‘time (ms)’, respectively, which are hidden to better display the evolution. All the figures use the same scale bar as panel **a** . 

with an energy of −11.85 eV (Fig. 3c). Although this significantly reduced energy barrier (1.25 eV) is easier to overcome, it will still hinder the free exchange between GBAC<sup>+</sup> and FA<sup>+</sup> , thereby slowing down the crystallization process<sup>32</sup> . 

In addition to thermodynamic control, the nucleation rate mediated by kinetic control can also be altered by increasing the activation energy of cation exchange<sup>33</sup> . Compared with the Lewis acid–base adduct formed between PbI2 and DMF (−0.79 eV) (Fig. 3d), the stronger ionic bonding between GBAC and PbI2 (−1.16 eV) will cost extra energy to overcome the saddling point (Supplementary Figs. 22 and 23)<sup>34,35</sup> . Moreover, based on the Arrhenius equation, the inherent nucleation and growth kinetics originating from the high volatility of DMF and strong FA–precursor binding to DMF (−1.00 eV) (ref. 36) will also be hindered by the more stable GBAC–PbI2 phase. Therefore, the crystal growth of the perovskite can be both thermodynamically and kinetically modulated by this hydrogen-bond-bridged intermediate (Supplementary Fig. 24). Due to the strong interaction between GBAC and perovskite, the retarded film formation would also accumulate GBAC at the bottom interface (Supplementary Fig. 25). Eventually, rigidly 

stacked GBAC can form at the grain boundaries due to π–π interaction after DMF evaporation, acting as a multifunctional passivation linker to enhance the photovoltaic performance (Fig. 3e)<sup>8</sup> . 

#### **Photovoltaic performance** 

The inverted PVSCs with a device configuration of indium tin oxide (ITO)/((2,7-dimethoxy-9H-carbazol-9-yl) methyl) phosphonic acid (DC-PA) (ref. 21)/perovskite (with/without GBAC)/C60/bathocuproine/Ag were fabricated to evaluate their photovoltaic performance (Fig. 4a, Supplementary Figs. 26 and 27 and Supplementary Table 3). As shown in Fig. 4b, the highest PCE of the control device is 22.8%, with _V_ OC of 1.12 V, _J_ SC of 24.48 mA cm<sup>–2</sup> and FF of 83.01%. However, the champion PCE of the GBAC-treated device can be further improved to 24.8% ( _V_ OC of 1.19 V, _J_ SC of 24.55 mA cm<sup>–2</sup> and FF of 84.78%), which is among the highest efficiencies reported so far for inverted PVSCs. The stabilized power output of the target champion device is 24.4%, matching well with the PCEs from the _J_ – _V_ measurement (Fig. 4c). The device performance was also validated at an independent laboratory (Japan Electrical Safety & Environment Technology Laboratories) to show a 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**481** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 



<!-- Start of picture text -->
a c d<br>c δ-FAPbl3 –1.2 –1.16<br>a –1.00<br>–1.0<br>GBAC–Pbl2 –0.8 –0.79<br>–0.6<br>GBAC–Pbl2–DMF –0.4<br>–18.58 –11.85 –10.60 DMF FA + GBAC +<br>Formation energy (eV) Type of molecules<br>b e<br>GBAC–Pbl2<br>Exchange Crystallization<br>GBAC–Pbl2–DMF<br>5 10 15 20 25 30 35 40<br>2 θ  (°)<br>Pbl64– GBAC + DMF FA +<br>Binding energy (eV)<br>Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 3 | Structure analysis and DFT calculations of the intermediatephase-induced crystallization. a** , Crystal structure of the GBAC–PbI2–DMF intermediate; hydrogen bonds are marked in cyan-blue. **b** , Simulated XRD patterns of GBAC–PbI2–DMF and GBAC–PbI2. **c** , Formation energies of 

GBAC–PbI2–DMF, GBAC–PbI2 and δ-FAPbI3 compounds. **d** , Binding energies between PbI2 and DMF as well as FA<sup>+</sup> and GBAC<sup>+</sup> . **e** , Schematic of the GBACassisted film growth. The brown arrows represent the breakage of hydrogen bonds, and the green arrows represent the cation exchange. 

certified PCE of 24.5% ( _V_ OC = 1.19 V, _J_ SC = 24.45 mA cm<sup>–2</sup> and FF = 84.20%) (Supplementary Fig. 28). The integrated photocurrent (24.38 mA cm<sup>–2</sup> ) from the external quantum efficiency (EQE) spectrum also matches well with the values obtained from the _J_ – _V_ measurements (Fig. 4d). The bandgap of the perovskite is 1.55 eV, as obtained by calculating the EQE derivative (Supplementary Fig. 29). Benefiting from the enhanced film quality and defect passivation aided by GBAC, the average _V_ OC value was boosted from 1.12 to 1.18 V (Fig. 4e). The overall energy loss of the champion target device can be reduced to 0.36 eV, which is very close to that of GaAs photovoltaics and represents one of the lowest energy losses in high-PCE cases (Fig. 4f)<sup>37,38</sup> . DFT calculations investigated the typical _I_ Pb antisite defect on a PbI2-terminated surface, revealing that GBAC passivation can help reduce these deep-level charge-carrier traps (Supplementary Fig. 30). The trap density was reduced from 2.58 × 10<sup>16</sup> to 1.53 × 10<sup>16</sup> cm<sup>−3</sup> after adding GBAC, further demonstrating the effectiveness of this strategy (Supplementary Fig. 31). 

Since adding GBAC can modulate crystallization to improve the film quality, this strategy can also be explored for fabricating large-area PVSCs (Supplementary Fig. 32). As shown in Fig. 4g, a large-area device (1.008 cm<sup>2</sup> ) delivered a PCE of 22.7% ( _V_ OC = 1.18 V, _J_ SC = 24.83 mA cm<sup>–2</sup> , FF = 77.43%), which is also one of the highest efficiencies reported for similar-sized PVSCs (Supplementary Table 4). Besides, the _V_ OC and _J_ SC values of this device are comparable with those obtained in small-area devices, showing great promise for device upscaling (Supplementary Fig. 33 and Supplementary Table 5). To demonstrate the general applicability of this approach to different perovskite compositions, we also fabricated devices based on a larger-bandgap perovskite (1.78 eV). The average PCE showed an increase from 15.70% to 16.61%, with average _V_ OC improvement from 1.19 to 1.25 V, which is highly favourable for fabricating tandem photovoltaics (Supplementary Fig. 34). 

Finally, we investigated the stability of devices under an accelerated aging condition based on the recognized protocols<sup>39</sup> . Unencapsulated devices were aged under continuous heating at 65 ± 5 °C (under N2). The target device showed a very small PCE decay (<3%) after 1,200 h, whereas that of the control device decreased nearly 30% during the same period (Fig. 4h). This shows that the interaction between GBAC and organic components (MA/FA) helps strengthen the film to avoid severe decomposition and sublimation under heating (Supplementary Fig. 35). The long-term operational stability of the unencapsulated devices was also measured by tracking the true maximum power point under continuous one-sun illumination (Supplementary Fig. 36) in a N2-filled glovebox. The target device maintained ~90% of its initial PCE after 500 h, whereas that of the control device decreased to ~30% of its original value (Supplementary Fig. 37). We also performed time-of-flight secondary ion mass spectrometry (ToF-SIMS) measurements to probe the compositional changes and ion migration related to device degradation. The control devices show dramatic changes with ions migrated to the perovskite/ETL interface after aging (Supplementary Fig. 38). However, only negligible changes were observed in the target sample aged under the same condition. Such improved device stability can be attributed to the enhanced film morphology and inhibited ion migration by adding GBAC. If GBAC can be used in conjunction with more efficient encapsulation techniques and optimal perovskite compositions, further improved PVSC efficiency and stability can be expected to meet the requirements for practical applications<sup>40–42</sup> . 

#### **Conclusion** 

In summary, we report an innovative strategy for achieving high-quality and stable perovskite films by employing a multifunctional, non-volatile additive, GBAC, which forms a unique hydrogen-bond-bridged 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**482** 

**Article** 



<!-- Start of picture text -->
Article https://doi.org/10.1038/s41566-023-01180-6<br>a b c<br>24 24<br>25<br>18 SPO = 24.4% 18<br>20 12 12<br>– 6 6<br>15<br>+ 0 0<br>–6 –6<br>10<br>–12 –12<br>5 Control –18 23.45 mA cm–2@1.04 V –18<br>Target –24 –24<br>0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 0 100 200 300 400 500 600<br>Voltage (V) Time (s)<br>d 100 25 e 1.20 f 26.0 0.30<br>PCE V OC loss<br>25.5<br>80 20 1.18 0.32<br>EQE 25.0<br>60 Integrated  J SC 15 1.16 24.5 0.34<br>40 10 1.14 24.0 0.36<br>1.12 23.5<br>20 5 0.38<br>23.0<br>1.10<br>0300 400 500 600 700 800 9000 Control Target 22.5 Ref. 1 Ref. 2 Ref. 3 Ref. 4 Ref. 5 Ref. 6 Ref. 7 This work0.40<br>Wavelength (nm)<br>g h<br>25 1.0<br>Forward Reverse<br>20 0.8<br>Active area: 1.008 cm2<br>15 0.6<br>10 0.4 Control<br>Target<br>5<br>0.2<br>0 Unencapsulated device aging at 65 ± 5 °C in N2-filled glovebox<br>0 0.2 0.4 0.6 0.8 1.0 1.2 0<br>0 200 400 600 800 1,000 1,200<br>Voltage (V)<br>Time (h)<br>C60/BCP<br>DC-PA<br>Ag<br>Perovskite<br>ITO glass<br>PCE (%)<br>–2)Current density (mA cm Current density (mA cm)–2<br>OC loss (V) V<br>EQE (%)  (V) V OC<br>Current density (mA cm)–2<br>PCE (%)<br>Normalized PCE (%)<br>–2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 4 | Characterization of photovoltaic performance and stability of PVSCs. a** , Device architecture of the inverted PVSC. **b** , _J_ – _V_ curves of the champion devices. **c** , **d** , Stable output ( **c** ) and EQE curve ( **d** ) of the target champion device. SPO, stabilized power output. **e** , Box plot of the _V_ OC distribution for control and target PVSCs. Data from 20 cells were statistically analysed. The box represents the median and quartiles, and the whisker covers the minima up to the maxima of the data points. The individual value of each data point is plotted as a point 

superimposed on the graph. **f** , Comparison of PCE and _V_ OC loss of inverted PVSCs reported in the literature (listed in Supplementary Table 1). **g** , _J_ – _V_ curve of the champion device with an active area of 1.008 cm<sup>2</sup> , and the inset shows a photograph of the device. **h** , Intrinsic stability of unencapsulated devices aged under 65 ± 5 °C in a N2-filled glovebox. Data from eight cells are collected and presented as mean values ± standard error of the mean. 

intermediate phase to modulate the perovskite crystallization process and simultaneously functions as an efficient passivation linker. We experimentally and theoretically unveil the mechanism of GBAC in assisting perovskite film formation, providing a design guideline for selecting suitable non-volatile additives to enhance the film quality. The greatly ameliorated optoelectronic properties are attributed to improved film morphology and crystallinity, effective defect passivation and more efficient charge transfer at the more n-characteristic film surface. Consequently, an impressive PCE of 24.8% (24.5% certified), low energy loss (0.36 eV) and remarkable device stability were achieved in inverted PVSCs. Our approach can also be extended to fabricate wide-bandgap perovskite devices and upscale devices, providing a simple and effective way towards fabricating scalable and highly efficient PVSCs. 

#### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, 

acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41566-023-01180-6. 

#### **References** 

1. Correa-Baena, J.-P. et al. Promises and challenges of perovskite solar cells. _Science_ **358** , 739–744 (2017). 

2. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic Cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

3. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ **598** , 444–450 (2021). 

4. Kim, M. et al. Conformal quantum dot–SnO2 layers as electron transporters for efficient perovskite solar cells. _Science_ **375** , 302–306 (2022). 

5. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**483** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 

6. Li, Z. et al. Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. _Science_ **376** , 416–420 (2022). 

7. Li, F. et al. Regulating surface termination for efficient inverted perovskite solar cells with greater than 23% efficiency. _J. Am. Chem. Soc._ **142** , 20134–20142 (2020). 

8. Zheng, X. et al. Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131–140 (2020). 

9. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434–437 (2022). 

10. Chen, H. et al. Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photon._ **16** , 352–358 (2022). 

11. Rajagopal, A., Yao, K. & Jen, A. K. Y. Toward perovskite solar cell commercialization: a perspective and research roadmap based on interfacial engineering. _Adv. Mater._ **30** , 1800455 (2018). 

12. Li, F. & Jen, A. K. Y. Interface engineering in solution-processed thin-film solar cells. _Acc. Mater. Res._ **3** , 272–282 (2022). 

13. Jeon, N. J. et al. Solvent engineering for high-performance inorganic–organic hybrid perovskite solar cells. _Nat. Mater._ **13** , 897–903 (2014). 

14. Liu, S. et al. A review on additives for halide perovskite solar cells. _Adv. Energy Mater._ **10** , 1902492 (2020). 

15. Bu, T. et al. Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ **372** , 1327–1332 (2021). 

16. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ **3** , 2179–2192 (2019). 

17. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902–907 (2021). 

18. Li, H. et al. Stiffening the Pb-X framework through a π-conjugated small-molecule cross-linker for high-performance inorganic CsPbI2Br perovskite solar cells. _ACS Appl. Mater. Interfaces_ **13** , 40489–40501 (2021). 

19. Li, N. et al. Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. _Nat. Energy_ **4** , 408–415 (2019). 

20. Wang, R. et al. Caffeine improves the performance and thermal stability of perovskite solar cells. _Joule_ **3** , 1464–1477 (2019). 

21. Deng, X. et al. Co-assembled monolayers as hole-selective contact for high-performance inverted perovskite solar cells with optimized recombination loss and long-term stability. _Angew. Chem. Int. Ed._ **61** , e202203088 (2022). 

22. Quarti, C., De Angelis, F. & Beljonne, D. Influence of surface termination on the energy level alignment at the CH3NH3PbI3 perovskite/C60 interface. _Chem. Mater._ **29** , 958–968 (2017). 

23. Song, T.-B. et al. Revealing the dynamics of hybrid metal halide perovskite formation via multimodal in situ probes. _Adv. Funct. Mater._ **30** , 1908337 (2020). 

24. Mrkyvkova, N. et al. Combined in situ photoluminescence and X-ray scattering reveals defect formation in lead-halide perovskite films. _J. Phys. Chem. Lett._ **12** , 10156–10162 (2021). 

25. Song, T.-B. et al. Dynamics of antisolvent processed hybrid metal halide perovskites studied by in situ photoluminescence and its influence on optoelectronic properties. _ACS Appl. Energy Mater._ **3** , 2386–2393 (2020). 

26. D’Innocenzo, V., Srimath Kandada, A. R., De Bastiani, M., Gandini, M. & Petrozza, A. Tuning the light emission properties by band gap engineering in hybrid lead halide perovskite. _J. Am. Chem. Soc._ **136** , 17730–17733 (2014). 

27. You, J. et al. Moisture assisted perovskite film growth for high performance solar cells. _Appl. Phys. Lett._ **105** , 183902 (2014). 

28. Shi, B. et al. Unraveling the passivation process of PbI2 to enhance the efficiency of planar perovskite solar cells. _J. Phys. Chem. C_ **122** , 21269–21276 (2018). 

29. Shi, D. et al. Low trap-state density and long carrier diffusion in organolead trihalide perovskite single crystals. _Science_ **347** , 519–522 (2015). 

30. Mei, A. et al. A hole-conductor–free, fully printable mesoscopic perovskite solar cell with high stability. _Science_ **345** , 295–298 (2014). 

31. Wang, K., Wu, C., Yang, D., Jiang, Y. & Priya, S. Quasi-two-dimensional halide perovskite single crystal photodetector. _ACS Nano_ **12** , 4919–4929 (2018). 

32. Wang, Y., He, J., Liu, C., Chong, W. H. & Chen, H. Thermodynamics versus kinetics in nanosynthesis. _Angew. Chem. Int. Ed._ **54** , 2022–2051 (2015). 

33. Han, T.-H. et al. Perovskite-polymer composite cross-linker approach for highly-stable and efficient perovskite solar cells. _Nat. Commun._ **10** , 520 (2019). 

34. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73–78 (2022). 

35. Fu, Y. et al. Stabilization of the metastable lead iodide perovskite phase via surface functionalization. _Nano Lett._ **17** , 4405–4414 (2017). 

36. Xia, Y., Xia, X. & Peng, H.-C. Shape-controlled synthesis of colloidal metal nanocrystals: thermodynamic versus kinetic products. _J. Am. Chem. Soc._ **137** , 7947–7966 (2015). 

37. Yao, J. et al. Quantifying losses in open-circuit voltage in solution-processable solar cells. _Phys. Rev. Appl._ **4** , 014020 (2015). 

38. Yamaguchi, M. in _Post-Transition Metals_ (ed Rahman, M. M.) Ch. 7 (IntechOpen, 2020). 

39. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

40. Mohammadi, M. et al. Encapsulation strategies for highly stable perovskite solar cells under severe stress testing: damp heat, freezing, and outdoor illumination conditions. _ACS Appl. Mater. Interfaces_ **13** , 45455–45464 (2021). 

41. Lin, Y.-H. et al. A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** , 96–102 (2020). 

42. Liu, Z. et al. A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. _Nat. Energy_ **5** , 596–604 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

Nature Photonics | Volume 17 | June 2023 | 478–484 

**484** 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 

#### **Methods** 

###### **Materials** 

All the materials are used as received without further purification, including DMF (99.99%, J&K), dimethyl sulfoxide (DMSO, 99.70%, J&K), isopropanol (IPA, 99.50%, J&K) and chlorobenzene (CB, 99.90%, J&K). Caesium iodide, caesium bromide, methylammonium iodide, formamidinium iodide (FAI) and formamidinium bromide were bought from Dysol. PbI2 (99.9985%) and lead bromide (>98.0000%) were bought from TCI. MACl, bathocuproine (99.9%) and C60 were bought from Xi’an Polymer Light Technology. GBAC (99%) was bought from Sigma-Aldrich. Piperazinium iodide<sup>7</sup> and DC-PA (ref. 21) were synthesized according to previous reports. 

###### **Synthesis of GBAC–PbI2–DMF single crystals** 

PbI2 and GBAC (1/1 by molar, 1.0 M) were dissolved in DMF and stirred overnight at 50 °C. The turbid liquid was filtered and transferred into a 4 mL vial. The vial was then placed into a sealed bottle filled with 2 mL CB. The GBAC–PbI2–DMF single crystals were grown along with the slow diffusion of the vapour of the antisolvent CB into the solution. 

###### **Device fabrication** 

ITO glass (15 Ω sq<sup>–1</sup> ; 1.5 × 1.5 cm<sup>2</sup> for a regular device and 2.5 × 2.5 cm<sup>2</sup> for a large-area device) was progressively washed by sonication with detergent (Decon 90), deionized water, acetone and IPA for 15 min. The washed ITO glass was dried in a 75 °C oven for over 12 h. Then, the cleaned ITO substrates were subjected to ultraviolet–ozone for 25 min and transformed in a N2-filled glovebox for film fabrication. DC-PA (2 mg mL<sup>–1</sup> in IPA) was dynamically spin coated onto the cleaned ITO at 3,000 rpm for 30 s, followed by annealing at 100 °C for 15 min. The substrates were cooled down to room temperature and washed with pure IPA and then annealed at 100 °C for 5 min. Then, 1.7 M perovskite precursor solutions were constructed by mixing FAI, PbI2, methylammonium iodide and caesium iodide in DMF:DMSO mixed solvent (4:1 v:v) with the chemical formula Cs0.06MA0.14FA0.80PbI3. Then, 10 mol% MACl was added into the precursor solution. For the target perovskite, 0.8 mol% GBAC was added to the precursor solution, and it was ensured that it is well mixed with the precursor. Then, 50 μL of the prepared precursor solution was spin coated at 1,000 rpm for 10 s and 5,000 rpm for 30 s onto the DC-PA-based ITO substrate; 170 μL CB as the antisolvent was dripped on the film at 10 s before the end of the last procedure and then annealed at 100 °C for 30 min. After deposition of the perovskite active layer, 50 μL piperazinium iodide (0.4 mg mL<sup>–1</sup> in IPA) solution was spin coated onto the film at 5,000 rpm for 30 s and annealed at 100 °C for 5 min. For the wide-bandgap perovskite, 1.2 M precursor solution with the chemical formula Cs0.2FA0.8Pb(I0.6Br0.4)3 was prepared from FAI, caesium iodide, formamidinium bromide, caesium bromide, PbI2 and lead bromide, and then dissolved in DMF:DMSO mixed solvents (4:1 v:v). Then, 5 mol% excess of PbI2 and 5 mol% MACl were added into the precursor solution. The target perovskite with 0.5 mol% GBAC was spin coated onto the DC-PA/ITO substrates at 5,000 rpm with an accelerating speed of 1,500 rpm for 30 s. Then, 150 μL CB as the antisolvent was dripped on the film at 15 s before the ending and then annealed at 100 °C for 10 min. The films were then cooled down to room temperature and readied for thermal evaporation. Subsequently, 25 nm C60, 8 nm bathocuproine and 100 nm Ag electrode were sequentially evaporated under a high vacuum (<4 × 10<sup>−6</sup> torr). 

###### **Characterizations** 

The<sup>1</sup> H nuclear magnetic resonance spectra were collected on a Bruker AVANCE III HD 300 MHz spectrometer in a DMSO-d6 solution with tetramethylsilane as a reference. The morphology of the samples was recorded by an SEM instrument (Philips XL30 FEG). Steady-state PL and time-resolved PL spectrum were obtained with an FLS980 

spectrofluorometer (Edinburgh) with a pulsed excitation laser of 485 nm. The XPS and UPS characterization measurements were conducted in a VG ESCALAB 220i XL surface analysis system equipped with a He-discharge lamp ( _hv_ = 21.22 eV) and a monochromatic Al Kα X-ray gun ( _hv_ = 1,486.60 eV), respectively. ToF-SIMS (ION TOF-SIMS5) data were analysed with the positive mode (Bi) under 30 keV (1.00 pA) with an area of 100 × 100 μm<sup>2</sup> . The sputter parameters for the device are O2 under 1 keV (100 nA) with an area of 300 × 300 μm<sup>2</sup> , and the sputter parameters for the film sample is gas cluster ion beam ion gun under 10 keV (10 nA) with an area of 800 × 800 μm<sup>2</sup> . XRD characterization was conducted on a D2 Phaser instrument with Cu Kα (wavelength, 1.5418 Å) radiation. Grazing-incidence wide-angle X-ray scattering measurements were conducted using a Xeuss 2.0 SAXS/WAXS laboratory beamline with a Cu X-ray source (8.05 keV, 1.54 Å) and a Pilatus 3R 300 K detector. The incidence angle is 1.0°. In situ PL spectra were characterized with home-built equipment. An excitation laser (315 nm) was introduced to the sample through a fibre, and the PL spectra were detected by using a detector connected to an Ocean Optics USB2000. PL mapping was collected using a WITec alpha300 M+ confocal microscope. The excitation laser was a diode-pumped solid-state laser (532 nm, Cobolt Laser). The _J_ – _V_ characteristics were measured in a N2-filled glovebox by a Keithley 2400 source meter under AM 1.5 G (100 mW cm<sup>−2</sup> ) irradiation using an Enlitech SS-F5 solar simulator. The light intensity was calibrated using a silicon solar cell (with a KG-2 filter) from the National Renewable Energy Laboratory. The device areas are 0.040 cm<sup>2</sup> for regular devices and 1.008 cm<sup>2</sup> for the large-size device, both of which are determined by metal aperture masks. A 150-nm-thick magnesium fluoride layer was deposited on the back of the glass before measurements. The EQE values were collected by an Enlitech EQE measurement system. A silicon solar cell calibrated by the National Renewable Energy Laboratory was used to obtain the AM 1.5 G solar simulator’s light intensity. The devices used for the stability test had the same structure as that for the _J_ – _V_ test. For thermal stability characterization, the devices were aged on a hotplate at 65 ± 5 °C in a N2-filled glovebox and cooled down to room temperature before the _J_ – _V_ test. For maximum power point tracking, the devices were tracked through the high-throughput solar-cell lifetime test system from CRYSCO with maximum power point tracking under light-emitting-diode-simulated AM 1.5 G spectrum. The light source is a superluminescent diode with a range from 400 to 1,000 nm. The superluminescent diode source is equipped with a silicon photoelectric probe to monitor the change in light intensity and automatically adjust the intensity with the control of the host. The intensity of the superluminescent diode source can be adjusted from 0.1 to 1.2 kW m<sup>–2</sup> . The duration between the two tests is 300 s. 

###### **Single-crystal analysis** 

The single-crystal structure of GBAC–PbI2–DMF was resolved and refined using the Bruker SHELXTL-2016/6 software package. All the non-hydrogen atoms were anisotropically refined, and all the hydrogen atoms were refined as riding atoms. The crystal data and data collection and refinement parameters are listed in Supplementary Table 1. Also, CCDC 2141303 contains the supplementary crystallographic data of GBAC–PbI2–DMF, which can be obtained free of charge from the Cambridge Crystallographic Data Centre via www.ccdc.cam.ac.uk/ data_request/cif. 

###### **DFT calculations** 

First-principles calculations based on DFT were performed with the Vienna ab initio simulation package<sup>43</sup> , using the generalized gradient approximation of the Perdew–Burke–Ernzerhof functional<sup>44</sup> for the exchange–correlation functional. Valence–core electron interactions were treated with the projector-augmented wave method<sup>45</sup> . We employed Grimme’s DFT-D3 scheme to include the van der Waals interactions<sup>45</sup> , and dipole correction for slab calculations<sup>46</sup> . The cutoff 

Nature Photonics 

**Article** 

https://doi.org/10.1038/s41566-023-01180-6 

energy of plane-wave expansions was set at 500 eV and the Hellmann– Feynman forces acting on atoms were converged below 0.01 eV Å<sup>−1</sup> for all the calculations. For the calculation of binding energies (defined as 

_E_ PbI2−molecule − _E_ PbI2 − _E_ molecule ), 1 × 1 × 1 Γ-centred _k_ -point grid was adopted, and the convergence criteria for the electronic wave function was 1.0 × 10<sup>−6</sup> eV energy difference. For geometry optimizations and energy calculations, 4 × 4 × 4 Γ-centred _k_ -point mesh for δ-FAPbI3, 2 × 4 × 2 Γ-centred _k_ -point mesh for GBAC–PbI2–DMF, 3 × 4 × 2 δ-centred _k_ -point mesh for GBAC–PbI 2 and 5 × 5 × 5 Γ-centred _k_ -point mesh for α-FAPbI3 were used. The convergence criteria of the energy difference was set to 1.0 × 10<sup>−5</sup> eV. Note that the formation energy (Δ _Eδ_ -FAPbI3) was calculated using the equation Δ _Eδ_ -FAPbI3 = 2 _Eδ_ -FAPbI3 − 2 _E_ PbI2 − 4 _E_ FAI for PbI2 + FAI→δ-FAPbI3, where _Eδ_ -FAPbI3 is the energy of δ-FAPbI3, _E_ PbI2 is the energy of PbI2 calculated from bulk PbI2 and _E_ FAI is the energy calculated from gas-phase FAI. The formation energy of bulk GBAC–PbI2 was calculated by the equation Δ _E_ GBAC−PbI2 = _E_ GBAC−PbI2 − 2 _E_ PbI2 − 4 _E_ GBAC for PbI2 + GBAC→ GBAC–PbI2, where _E_ GBAC is the energy calculated from gasphase GBAC. The formation energy of intermediatephase GBAC–PbI2–DMF was calculated with the equation Δ _E_ GBAC−PbI2−DMF = _E_ GBAC−PbI2−DMF − 2 _E_ PbI2 − 4 _E_ GBAC − 8 _E_ DMF for PbI 2 + GBAC + DMF→GBAC–PbI2–DMF, where _E_ DMF is the energy of the DMF molecules. For slab calculations, the Brillouin zone was sampled with a 2 × 2 × 1 Γ-centred _k_ -point mesh, and a vacuum of at least 30 Å was used to avoid the interaction of neighbouring interfaces along the _z_ direction. The electrostatic potentials ( _φ_ ) of the interacting pairs were calculated using the Gaussian 09 package at the B3LYP/def2TZVP level with DFT-D3. The maximum _φ_ ( _φ_ max) and minimum _φ_ ( _φ_ min) values of the interacting pairs were obtained with the help of Multiwfn code<sup>47</sup> . The structure models were drawn with the VESTA software<sup>48</sup> . Some data processing was done by VASPKIT<sup>49</sup> . 

###### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

#### **Data availability** 

All data supporting the findings of this study are available within this Article and its Supplementary Information. The .cif files corresponding to the single-crystal structures reported in this work are available from the Cambridge Crystallographic Data Centre (2141303). 

48. Momma, K. & Izumi, F. VESTA 3 for three-dimensional visualization of crystal, volumetric and morphology data. _J. Appl. Crystallogr._ **44** , 1272–1276 (2011). 

49. Wang, V., Xu, N., Liu, J.-C., Tang, G. & Geng, W.-T. VASPKIT: a user-friendly interface facilitating high-throughput computing and analysis using VASP code. _Comput. Phys. Commun._ **267** , 108033 (2021). 

#### **Acknowledgements** 

The work has been supported by the Lee Shau-Kee Chair Professor (Materials Science) (A.K.-Y.J.); the support from the APRC Grant of the City University of Hong Kong (9380086, 9610508) (A.K.-Y.J.); the TCFS Grant (GHP/018/20SZ) (A.K.-Y.J.) and MRP Grant (MRP/040/21X) (A.K.-Y.J.) from the Innovation and Technology Commission of Hong Kong; the Green Tech Fund (202020164) (A.K.-Y.J.) from the Environment and Ecology Bureau of Hong Kong; the GRF grant (11307621, 11316422) (A.K.-Y.J.); from the Research Grants Council of Hong Kong, Guangdong Major Project of Basic and Applied Basic Research (2019B030302007) (A.K.-Y.J.); and the Guangdong-Hong Kong-Macao Joint Laboratory of Optoelectronic and Magnetic Functional Materials (2019B121205002) (A.K.-Y.J.). We thank S. You for the technical support of single-crystal analysis and W. K. Wong for XPS measurements. A.K.-Y.J. thanks C. S. Lee for support with the UPS test. 

#### **Author contributions** 

F.L. and X.D. contributed equally to this work and were supervised by A.K.-Y.J. F.L. and X.D. conducted the film characterization, device fabrication and device characterization. F.L. synthesized the single crystal and analysed the results with S.-H.J. Z.S. performed the DFT calculations and was supervised by X.-K.C. S.W. contributed to fabricate the large-bandgap device. Z. Zeng helped collect the in situ PL data and was supervised by S.-W.T. D.W. performed the PL and time-resolved PL characterizations. Y.L. conducted the UPS measurement. F.Q. conducted the<sup>1</sup> H nuclear magnetic resonance measurements. Z. Zhang performed the atomic force microscopy and KPFM characterizations and was supervised by Z.Y. F.R.L., X.-K.C. and A.K.-Y.J. revised the manuscript. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

#### **References** 

43. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

44. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

45. Blöchl, P. E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953 (1994). 

46. Lee, K., Murray, É. D., Kong, L., Lundqvist, B. I. & Langreth, D. C. Higher-accuracy van der Waals density functional. _Phys. Rev. B_ **82** , 081101 (2010). 

47. Lu, T. & Chen, F. Multiwfn: a multifunctional wavefunction analyzer. _J. Comput. Chem._ **33** , 580–592 (2012). 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566-023-01180-6. 

**Correspondence and requests for materials** should be addressed to Alex K.-Y. Jen. 

**Peer review information** _Nature Photonics_ thanks Xiaojing Hao and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at 

www.nature.com/reprints. 

Nature Photonics 

Corresponding author(s): Alex K.-Y. Jen 



## <u>Solar Cells Reporting Summary</u> 

Nature Research wishes to improve the reproducibility of the work that we publish. This form is intended for publication with all accepted papers reporting the characterization of photovoltaic devices and provides structure for consistency and transparency in reporting. Some list items might not apply to an individual manuscript, but all fields must be completed for clarity. 

For further information on Nature Research policies, including our data availability policy, see Authors & Referees. 

### � Experimental design 

##### **Please check: are the following details reported in the manuscript?** 

1.   Dimensions 

|Area of the tested solar cells|Yes<br>No|In our lab, the area of the solar cells tested is 0.04 cm2 (Methods section: J-V and<br>EQE measurements).  For larger-size device, the device area is 1.008 cm2.|
|---|---|---|
|Method used to determine the device area|Yes<br>No|In our lab, the area of the solar cells tested is defined by a non-reflective metal mask<br>with an aperture area of 0.04  cm2 for regular device and 1.008 cm2 for larger-size<br>device.|
|Current-voltage characterization<br>Current density-voltage (J-V) plots in both forward<br>and backward direction|Yes<br>No|Forward and backward scans were performed on the cell (Supplementary Fig. S28).|
|Voltage scan conditions<br>_For instance: scan direction, speed, dwell times_|Yes<br>No|For the cells tested in our lab, the scan was performed in the range from -0.2 to 1.0<br>or 1.2 V, with a scan step of 0.02 V and dwell time of 10 ms.<br>The voltage scan conditions during certifications were provided in Supplementary Fig.<br>S28.|
|Test environment<br>_For instance: characterization temperature, in air or in glove box_|Yes<br>No|For the cells tested in our lab, the cells were non-encapsulated and the<br>measurements were performed in an N2-filled glove box at room temperature.<br>For the cells sent to certification, the cells were encapsulated and the measurements<br>were carried out in ambient atmosphere at room temperature. Further details<br>regarding test environment during certifications were provided in Supplementary Fig.<br>S28.|
|Protocol for preconditioning of the device before its<br>characterization|Yes<br>No|For the cell sent to JET for certification, the tests were conducted according to the IEC<br>60904-9 methods to determine the certified cell performance (Supplementary Fig.<br>S28).<br>For the cells tested in our lab, no preconditioning was applied.|
|Stability of the J-V characteristic<br>_Verified with time evolution of the maximum power point or with_<br>_the photocurrent at maximum power point; seeref. 7 for details._<br>Hysteresis or any other unusual behaviour|Yes<br>No|For the cell sent to JET for certification, the stability of J-V characteristics were<br>confirmed by the MPPT results (Supplementary Fig. 28).<br>In our lab, stabilized power output tracking was performed to confirm the stability of<br>J-V characteristics (Fig. 4c).|
|Description of the unusual behaviour observed during<br>the characterization|Yes<br>No|There is no unusual behaviour observed during the characterization, i.e, hysteresis.|
|Related experimental data|Yes<br>No|We are not reporting an unusual behaviour.|
|Efficiency<br>External quantum efficiency (EQE) or incident<br>photons to current efficiency (IPCE)|Yes<br>No|The EQE spectra were collected using an Enlitech QE-S EQE system equipped with a<br>standard Si diode, as shown in Fig. 4d.|
|A comparison between the integrated response under<br>the standard reference spectrum and the response<br>measure under the simulator|Yes<br>No|The values of the integrated current from EQE and the short-circuit current from J-V<br>curve measured under AM 1.5G solar simulator are matched well (within 2%<br>difference).|
|For tandem solar cells, the bias illumination and bias|Yes|We do not report tandem solar cells in this work.|
|voltage used for each subcell|No||



2.   Current-voltage characterization 

3.   Hysteresis or any other unusual behaviour 

4.   Efficiency 

1 

5.   Calibration 

|Light source and reference cell or sensor used for the<br>characterization|Yes<br>No|In our lab, the cells were measured under AM 1.5G (100 mW cm-2) irradiation using<br>an EnliTech SS-F5 solar simulator. The light intensity was calibrated using a silicon<br>solar cell (with a KG-2 filter) from the National Renewable Energy Laboratory<br>(Methods section: J-V and EQE measurements).<br>For the cells sent to certifications, please refer to Supplementary Fig. S28 (JET).|
|---|---|---|
|Confirmation that the reference cell was calibrated<br>and certified|Yes<br>No|The solar simulator in our lab is equipped with a silicon solar cell (with a KG-2 filter)<br>from the National Renewable Energy Laboratory (Methods section: J-V and EQE<br>measurements).<br>For the cells sent to certifications, calibrated and certified reference cells were used<br>(Supplementary Fig. S28).|
|Calculation of spectral mismatch between the<br>reference cell and the devices under test|Yes<br>No|In our lab, the spectral mismatch between the reference cell and the tested devices is<br>calculated to be around 1 with a deviation < 1%.<br>For the cell sent to JET for certification, the spectral mismatch correction factor was<br>calculated to be +2.25%.|
|6.   Mask/aperture|||
|Size of the mask/aperture used during testing|Yes<br>No|For the cells tested in our lab, the mask/aperture area is 4 mm2. (Methods section: J-<br>V and EQE measurements).<br>For the cells sent to certifications, the aperture area was defined as 0.04003 cm2.<br>(Supplementary Fig. S28).|
|Variation of the measured short-circuit current|Yes|For the cells tested in our lab, all cells were measured using one identical mask.|
|density with the mask/aperture area|No||
|7.   Performance certification|||
|Identity of the independent certification laboratory<br>that confirmed the photovoltaic performance|Yes<br>No|Champion cell was certified by JET (Supplementary Fig. S28).|
|A copy of any certificate(s)<br>_Provide in Supplementary Information_|Yes<br>No|The copy of certificates are provided as Supplementary Fig. S28 (JET).|
|8.   Statistics|||
|Number of solar cells tested|Yes<br>No|The data from 20 cells were statistically analyzed. The information is provided in<br>Supplementary Fig. S27.|
|Statistical analysis of the device performance|Yes<br>No|The information is provided in Supplementary Fig. S28.|
|9.   Long-term stability analysis|||
|Type of analysis, bias conditions and environmental<br>conditions<br>_For instance: illumination type, temperature, atmosphere_<br>_humidity, encapsulation method, preconditioning temperature_|Yes<br>No|For thermal stability, the unencapsulated devices were aged under continuous<br>heating at 65±5 °C in N2 atmosphere.<br>The long-term operational stability of the unencapsulated cells were tracked<br>through the high throughput solar cell lifetime test system from CRYSCO<br>cooperation with maximum power point tracking under LED simulated AM 1.5<br>spectrum  in an N2-filled glovebox. Duration between two test is 300 s.|



2 

