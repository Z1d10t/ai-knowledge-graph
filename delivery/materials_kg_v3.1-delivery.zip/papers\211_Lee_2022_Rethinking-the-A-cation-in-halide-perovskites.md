# Rethinking the A cation in halide perovskites

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 468 |
| 作者 | Jin-wook Lee, Shaun Tan, S. Seok, Yang Yang, Nam-Gyu Park |
| DOI | 10.1126/science.abj1186 |
| 源文件 | 011_Lee_2022_Rethinking-the-A-cation-in-halide-perovskites.pdf |

---
RESEARCH 



<mark>◥</mark> 

In this review, we examine the important developments enabled by the expanded role of the A cation. To highlight its importance, the vast majority of the record-breaking performances for OLHP-based photovoltaics have been enabled by breakthroughs related to the versatility of the A cation, which we discuss. Moreover, recently, bulky conjugated A cations have even been demonstrated to participate in constructing the OLHP band-edge structure, further challenging a long-held traditional notion regarding the role of the A cation. 

### <mark>REVIEW SUMMARY</mark> 

SOLAR CELLS 

## Rethinking the A cation in halide perovskites 

Jin-Wook Lee†, Shaun Tan†, Sang Il Seok*, Yang Yang*, Nam-Gyu Park* 

monium (MA<sup>+</sup> ), formamidinium (FA<sup>+</sup> ), and cesium (Cs<sup>+</sup> ), which were determined by size and structural constraints to fit within the spaces of the OLHP crystal lattice. Because the A cation, by itself, does not directly contribute to the OLHP band-edge construction, it was traditionally believed to hardly affect the optoelectronic properties of OLHPs. 

BACKGROUND: Organic-inorganic lead halide perovskites (OLHPs) represent a family of semiconducting materials that have attracted wide interest for their optoelectronic applications. By combining notable electronic and photophysical properties with low-temperature solution processability using earth-abundant materials, the field has experienced rapid breakthroughs over the past decade. OLHPbased optoelectronic devices have now been established as an independent field of study. In particular, solar cells that use OLHPs as the photoactive layer have exceeded 25% power conversion efficiency, which is competitive with photovoltaics based on traditional inorganic semiconductors such as silicon. However, unanswered questions remain to be addressed regarding the fundamental properties and our understanding of OLHP materials. 

OUTLOOK: Future opportunities entail either discovering new uses for existing A cation species or identifying new A cations for existing applications, or both simultaneously. When looking toward improving the commercialization readiness of OLHPs, A cation applications that involve addressing the module scale-up challenges and long-term operational instability issues must be further explored. This necessitates a more comprehensive understanding of the structure-property-performance-stability correlations conferred by the A cation by combining systematic experimental approaches with first-principles theoretical studies.▪ 

In contrast to these presumptions, advancements in recent years have unraveled the critical role of the A cation in determining the optoelectronic and physicochemical properties of OLHPs. Major breakthroughs in the field have been realized by using A cations to fine-tune the properties of OLHPs, including for (i) thermodynamic or kinetic stabilization of desirable OLHP phases, especially the metastable cubic formamidinium lead triiodide polymorph; (ii) impeding the migration of ions by electrostatic interactions and/or steric effects; and (iii) surface and interface functionalization and modification. These topics are now at the forefront of OLHP research, ultimately dictating the utility, function, performance, and stability of OLHP-based optoelectronic devices. 

The list of author affiliations is available in the full article online. *Corresponding author. Email: seoksi@unist.ac.kr (S.I.S.); yangy@ucla.edu (Y.Y.); npark@skku.edu (N.-G.P.) †These authors contributed equally to this work. Cite this article as J.-W. Lee et al., Science 375, eabj1186 (2022). DOI: 10.1126/science.abj1186 

ADVANCES: OLHPs have the general chemical formula of ABX3, where A represents a monovalent cation, B represents the divalent lead cation, and X is a halide anion. During its initial development, the A cation was limited to mainly three candidates, namely methylam- 

READ THE FULL ARTICLE AT https://doi.org/10.1126/science.abj1186 























































































Modifying perovskites through A site cations. In recent years, important breakthroughs have been enabled by the expanded role and function of the A cation in tailoring the physicochemical and optoelectronic properties of OLHPs. These advances ultimately dictate the utility, function, and performance of OLHP-based optoelectronic devices. 

1 of 1 

Lee et al., Science 375, 835 (2022) 25 February 2022 

RESEARCH 



<mark>◥</mark> 

physicochemical properties of OLHPs without substantially altering their optoelectronic properties. 



<!-- Start of picture text -->
of the<br><!-- End of picture text -->



### <mark>REVIEW</mark> 

The organic A cations interact with the surrounding BX64– octahedra through weak secondary hydrogen bonding, with bonding energies lower than 0.1 eV per bond (5). Owing to such weak interaction energies, the reorientation of the organic cation can be thermally activated at a finite temperature. [The residence time at room temperature is on the order of ~10<sup>2</sup> femtoseconds to picoseconds (6–8).] The activated reorientation of the organic A cation and its coupling with the surrounding inorganic framework result in a temperaturedependent order-disorder–type phase transition between the orthorhombic, tetragonal, and cubic phases (9, 10). For example, MAPbBr3 crystallizes in the orthorhombic phase at low temperatures (<180 K) where the MA<sup>+</sup> cations are ordered. As the temperature increases to more than 180 K, the MA<sup>+</sup> cation becomes disordered with anisotropic thermal motion, which is coupled to the surrounding PbBr64– octahedra to induce the crystal phase transition to the tetragonal symmetry (Fig. 2A) (11). Contribution of the A cation thermal motion in relation to the OLHP phase behavior has also been discussed for FAPbI3. The FA<sup>+</sup> cation, which has a larger ionic radius than MA<sup>+</sup> , cannot be stabilized in the cubic symmetry at temperatures below ~390 K, and thus it forms a hexagonal nonperovskite polymorph. At temperatures beyond ~390 K, the activated thermal motion of the FA<sup>+</sup> cation contributes entropic stabilization to the cubic perovskite polymorph, which is subsequently retained as a metastable phase at temperatures lower than the phase conversion temperature (12). Because the thermal motion of the organic A cation and its coupling with the surrounding inorganic sublattice dictates the crystal structure of the OLHP system and its stability at operating temperatures, not only the static geometry of the A cation but also its dynamic structure should be considered in designing the A cation. In this regard, to predict structural formability, the effective ionic radii of the nonspherical organic cations have been estimated by assuming rotational freedom about the center of mass, by adding the distance from the center of mass to the outermost ion (excluding hydrogen) to the radius of the ion (13). However, the recalculated t values for many organic cations are still not correlated with experimental results (14). Introducing other geometrical factors such as globularity improved the correlation, but the versatility of these approaches has not yet been confirmed (14). Further work is needed to enhance the accuracy of calculating t, which may include additional corrections to account for molecular symmetry and hydrogen-bond strength, as well as the A cation dipole. 

SOLAR CELLS 

## Rethinking the A cation in halide perovskites 

Jin-Wook Lee<sup>1</sup> †, Shaun Tan<sup>2,3</sup> †, Sang Il Seok<sup>4</sup> *, Yang Yang<sup>2,3</sup> *, Nam-Gyu Park<sup>5</sup> * 

The A cation in ABX3 organic-inorganic lead halide perovskites (OLHPs) was conventionally believed to hardly affect their optoelectronic properties. However, more recent developments have unraveled the critical role of the A cation in the regulation of the physicochemical and optoelectronic properties of OLHPs. We review the important breakthroughs enabled by the versatility of the A cation and highlight potential opportunities and unanswered questions related to the A cation in OLHPs. 

# O 

rganic-inorganic lead halide perovskites (OLHPs) have the general stoichiometry formula of ABX3, with A as the monovalent organic or inorganic cation, B as 

Traditionally, the A cation was not believed to directly contribute to the OLHP band-edge construction, which is primarily composed of orbital states from the B and X species (3). Resultantly, the A cation was not thought to substantially affect the optoelectronic properties of OLHPs. However, progress in recent years has since challenged this notion. Furthermore, the A cation has been shown to critically influence the physiochemical properties and the intrinsic and extrinsic stability of OLHPs. 

the divalent Pb<sup>2+</sup> cation, and X as the halide anion. Any of the A, B, and X sites can be occupied by a mixture of constituents to afford OLHPs a wide compositional breadth and tuneability toward different applications (1, 2). The Goldschmidt tolerance factor can be useful to predict structural formability and the resulting crystal phase based on ionic size considerations; it is defined by 

In this review, we evaluate the expanded role of the A cation (Fig. 1), which has enabled many important breakthroughs for highperformance and stable OLHP optoelectronics. Many of these developments were made possible by the introduction of oversized (t > 1) or undersized (t < 0.8) cations that may not necessarily fit the structural constraints of the lattice bulk. Conversely, such missized cations may occupy the A sites along the surfaces and/ or grain boundaries, which are free from the bulk steric constraints. By themselves, the oversized cations typically form lower-dimensional phases, such as the two-dimensional (2D) A2PbI4 perovskites, whereas the undersized cations are used to form the ABO3 oxide perovskite structures. We focus only on their utility to and function in tuning the properties of three-dimensional (3D) OLHPs. 



<!-- Start of picture text -->
rA þ rX<br>t ¼ f f<br>p 2ðrB þ rXÞ<br><!-- End of picture text -->

where rA, rB, and rX are the ionic radii of the A, B, and X species, respectively. The perovskite phase is desired for many practical optoelectronic applications and empirically observed to form at 0.8 < t < 1.0. The crystal structure consists of an inorganic BX64– octahedra network that is three-dimensionally connected through the corner halides, with structural stabilization contributed by the A cations that occupy the cuboctahedral spaces surrounded by eight BX64– octahedra. For APbI3-based stoichiometries, three A cations are known to definitively fit this geometric constraint, namely methylammonium (CH3NH3+, or MA<sup>+</sup> ), formamidinium [HC(NH2)2+, or FA+], and cesium (Cs<sup>+</sup> ), albeit FAPbI3 (t ~ 0.99) and CsPbI3 (t ~ 0.80) are at the edges of the t limits. 

Revisiting the conventional roles of the A cation: Progress and challenges Crystal symmetries and crystal phases 

The size and geometry of the A cation affect the bond length and angle between the B and X species to alter the arrangement of the surrounding BX64– octahedra and thus the resulting crystal symmetry and phase of the perovskite. The molecular orbitals of the A cation constitute deep energy states within the conduction and valence bands and thus do not directly affect the band-edge carrier properties (4). Consequently, A cation engineering has been considered as a useful approach to fine-tune the crystal structure (orthorhombic, tetragonal, and cubic) and 

1SKKU Advanced Institute of Nanotechnology (SAINT) and Department of Nanoengineering, Sungkyunkwan University, Suwon 16419, Republic of Korea.<sup>2</sup> Department of Materials Science and Engineering, University of California, Los Angeles, CA 90095, USA.<sup>3</sup> California NanoSystems Institute, University of California, Los Angeles, CA 90095, USA.<sup>4</sup> Department of Energy Engineering, School of Energy and Chemical Engineering, Ulsan National Institute of Science and Technology, Ulsan 44919, Republic of Korea. 5School of Chemical Engineering and Center for Antibonding Regulated Crystals, Sungkyunkwan University, Suwon 16419, Republic of Korea. 

*Corresponding author. Email: seoksi@unist.ac.kr (S.I.S.); yangy@ucla.edu (Y.Y.); npark@skku.edu (N.-G.P.) †These authors contributed equally to this work. 

1 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



3D layers (Fig. 2B) (27). However, the anisotropic charge transport and poor phase purity have limited the performance of such PSCs (28). Further developments are necessary for effective methods to grow phase-pure quasi2D OLHPs with a desired orientation, because they might be promising active material candidates for the top subcell of perovskite-based tandems owing to their superior stability compared with conventional 3D OLHPs. 





<!-- Start of picture text -->
A 1.6<br>Undersized<br>1.4 cations<br>1.2<br>1.0<br>PEA +<br>0.8 Oversized PA + FPEA +<br>Conventional  cations BA + PRA +<br>0.6 A cations OA + PRMA +<br>DA + PREA +<br>0.4<br>1 2 3 4<br>r A (angstrom)<br>B<br>methylammonium (MA) formamidinium (FA) ethylammonium (EA)<br>propylammonium (PA)<br>pyrene-ammonium (PRA) pyrene-methylammonium (PRMA)<br>acetamidinium (Ace) guanidinium (GA)<br>butylammonium (BA)<br>methylenediammonium (MDA) phenethylammonium (PEA)<br>octylammonium (OA)<br>dimethylammonium (DMA) dodecylammonium (DA) 4-fluoro-phenethylammonium (FPEA) pyrene-ethylammonium (PREA)<br>t  ,r<br>o<br>tca  (217)MA+  (253)FA+ 2+ (262)MDA  (273)DMA+  (274)EA+  (277)Ace+ GA (278)+<br>f  Cs (167)+<br>e  (152)Rb+<br>c  (138)K+<br>n<br>a<br>r<br>elo<br>T<br><!-- End of picture text -->

##### Charge-carrier dynamics 

Although band-edge carrier transport is mediated through the BX64– network, the thermally activated reorientational motion of dipolar A cations and coupled BX64– octahedra may interact with charge carriers to affect their dynamics (7). It was suggested that the formation of (ferroelectric) large polarons, that is, charge carriers dressed by long-range lattice deformations (Fig. 2C), may be the possible origin of the long carrier lifetimes of OLHPs (29, 30). The hot-carrier lifetime in OLHPs was found to be ~10<sup>2</sup> ps, which is exceptionally long compared with the ~10<sup>2</sup> fs lifetime of conventional polar semiconductors (7, 31). This further suggests the potential application of OLHPs to hot-carrier solar cells, which remain relatively unexplored. It was proposed that the ultrafast reorientational motion of the A cation in response to the photogeneration of charge carriers may form large polarons, resulting in an effective screening of the Coulomb potential to diminish hot-carrier scattering (7). The long-lived hot carriers are observed in MAPbBr3 and FAPbBr3, but not CsPbBr3. However, separate studies show an opposite trend, where the slower hot-carrier cooling of CsPbBr3 is attributed to a relatively weak charge carrier– phonon coupling compared with its hybrid counterparts (32). Nevertheless, these studies highlight the importance of the dynamic motion of the A cation. 

Fig. 1. Expanded role of A cations. (A) Selection of A cations that have enabled important breakthroughs in the field of OLHPs, classified by their cationic radius and corresponding tolerance factor based on the APbI3 lattice framework. The number in parentheses indicates the cation radius. (B) Molecular structures of the organic cations listed in (A). 

gap of ~1.74 eV and mobility of 21 cm<sup>2</sup> V<sup>−1</sup> . Such multication mixed-halide compositions are now widely used for fabricating highefficiency perovskite-silicon or perovskiteperovskite tandems (20–22). 

##### Compositional breadth and tunability for bandgap engineering 

State-of-the-art, high-performance singlejunction perovskite solar cells (PSCs) primarily incorporate Pb<sup>2+</sup> and I<sup>–</sup> in their B and X sites, respectively, because of the desirable bandgaps of such stoichiometries, which are closer to the ideal Shockley-Queisser theoretical value (~1.34 eV). Conversely, wide-bandgap OLHPs (~1.7 eV) are actively investigated for fabricating the top subcell of perovskite-based tandem solar cells by halide compositional tuning (15). However, continuous halide compositional tuning is not achievable for FAPb(I1−xBrx)3 because the t value of FAPbI3 is close to the cubic phase limit, and Br incorporation further increases t and reduces the A cuboctahedral space to aggravate structural formability. This results in the formation of an amorphous phase with high energetic disorder, low absorption, and inferior carrier mobility (~1 cm<sup>2</sup> V<sup>−1</sup> ) compared with the pure iodide phase (~20 cm<sup>2</sup> V<sup>−1</sup> ) (16, 17). By contrast, A cation compositional engineering offers a solution to enable access to the wider bandgap range. Partial replacement of FA<sup>+</sup> with the smaller MA<sup>+</sup> or Cs<sup>+</sup> cation reduces the t value to compensate for the increase in t owing to the Br incorporation (18, 19). This enables the formation of crystalline wide-bandgap compositions such as FA0.83Cs0.17Pb(Br0.4I0.6)3, with an optical band- 

Although widely used, the multication mixedhalide compositions suffer from spontaneous photo-induced phase segregation (23). The compositional engineering of A cations offers an advantage in this regard. In addition to compensating for t changes by halide substitution as discussed, more recently, A cation compositional engineering has been used to directly modulate the bandgap of the perovskite without changing the halide composition. CsPbI3 has a suitable bandgap of ~1.7 eV, but its cubic phase is thermodynamically unstable at room temperature because of its low t value. Additive engineering has enabled the synthesis of thermodynamically stabilized CsPbI3 with a power conversion efficiency (PCE) exceeding 19%, where CsPbI3 is synthesized using dimethylammonium iodide (DMAI) or HPbI3 (24, 25). Quasi-2D perovskites that incorporate oversized (t > 1) ammonium cations are another class of wide-bandgap OLHPs that have been broadly explored (26). The bulky insulating ammonium cations that are intercalated between the 3D OLHP layers induce charge-carrier quantum confinement to enable bandgap engineering by varying the number of 

The role of the A cation in the band-edge carrier dynamics is still under debate. In contrast to initial reports correlating polaronic stabilization with A cations (7), recent consensus seems to be that the generation of large polarons is more closely associated with the dipolar BX64– sublattice rather than the A cation, which is supported by the similar radiative recombination kinetics of band-edge carriers in MAPbBr3, FAPbBr3, and CsPbBr3 (33). Conversely, experimental observations still indicate that the lifetimes of band-edge carriers are greatly affected by the A cation composition. For example, FAPbI3-based compositions have demonstrated much longer charge-carrier lifetimes compared with that of MAPbI3, irrespective of the former’s generally inferior crystallinity and poor phase purity (34, 35). Based on solid-state nuclear magnetic resonance (NMR) investigations, there exists a correlation between the faster reorientation 

2 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



Therefore, further studies are required to unravel the correlations between the A cation and charge-carrier dynamics, which are essential for designing OLHP compositions. 





##### Expanded role of the A cation Phase stabilization of desired perovskite polymorphs 

More recent record-breaking PSCs contain continuously increasing proportions of FA<sup>+</sup> in their compositions (Fig. 2D). Compared with the prototypical MAPbI3, FAPbI3-dominant compositions generally boast longer carrier lifetimes, superior thermal and photostability, and a bandgap closer to the ideal for photovoltaic applications (3). Stabilization of the metastable cubic FAPbI3 phase at room temperature has become an important focus of ongoing research in the community (Fig. 3A). 

Initially, substitution with the smaller MA<sup>+</sup> cation was widely used to lower the t value of FAPbI3. Replacement of FAI with MAI or MABr in the precursor solution contributes to cubic phase stabilization at room temperature (19, 39). The (FAPbI3)1–x(MAPbI3)x or (FAPbI3)1–x(MAPbBr3)x compositions demonstrated superior optoelectronic properties and stability compared with pure MAPbI3 or FAPbI3, resulting in several record-breaking certified efficiencies around 2015 (Fig. 2D) (3). However, MA<sup>+</sup> forms a smaller number of hydrogen bonds than FA<sup>+</sup> with the surrounding PbI64– inorganic framework, and its consequent volatile nature aggravates the thermal and photo instability of the OLHP films (40, 41). This motivated the development of alternative cations to stabilize the cubic polymorph. The inorganic Cs<sup>+</sup> and Rb<sup>+</sup> cations have a smaller ionic radius than FA<sup>+</sup> but form stronger primary chemical bonding with the BX64– framework. Consequently, Cs<sup>+</sup> and Rb<sup>+</sup> effectively stabilize the cubic phase at lower temperatures while simultaneously enhancing the environmental stability of the films (41–43). It was also suggested that A cation mixing contributes entropic stabilization to the system (44), which motivated the development of more complex triple or quadruple cation systems such as FA1–x–yMAxCsy- or FA1–x–y–zMAxCsyRbzbased compositions (45, 46). Regardless of the improved phase stability of most FAPbI3based compositions by substitution with MA<sup>+</sup> , Br<sup>–</sup> , or Cs<sup>+</sup> , however, these approaches inevitably increase the bandgap to sacrifice the photocurrent. 

Fig. 2. Revisiting the conventional roles of the A cation. (A) Schematics illustrating the dynamic motion of the MA<sup>+</sup> cation (left) and temperature-dependent order-disorder–type phase transition of MAPbBr3 induced by the MA<sup>+</sup> cation motion (right). Adapted with permission from (6) and (11). Labels (1) and (2) on the left figure indicate the two reorientation modes: (1) methyl and/or ammonium rotation around the C–N axis (carbon and nitrogen atoms are depicted in blue and brown, respectively, and the axis is indicated by the green dotted lines); and (2) whole-molecule reorientation via rotation of the C–N axis itself. (B) Low-dimensional PEA2MAn–1PbnI3n+1 perovskites and their corresponding relative formation energy and stability. Adapted with permissions from (27). (C) Schematic of the ferroelectric large polarons and molecular dynamics simulation of the corresponding isodensity representation of holes, showing sheet-like charge localization in tetragonal MAPbI3. Adapted with permission from (29). (D) History of the record PSC performance and the A cation compositions that were used. The PCE data and compositions are retrieved from their respective publications (1, 2, 19, 45, 49–51, 87, 102–110). The PCEs are plotted based on publication date. This panel conveniently summarizes the composition evolution of state-of-the-art PSCs with time, but we note that the final PSC efficiency is not solely determined by composition alone. 

the BX64– sublattice (38). It was also suggested that polaron hopping is related to the random reorientation of the organic cations. This again implies that the dynamic structure of the organic A cation plays a crucial role in affecting OLHP optoelectronic properties. However, all the observed carrier dynamics could have also manifested from compositiondependent defect type, density, and energetics. 

dynamics of the A cation and longer chargecarrier lifetimes (36). The temperature and resulting phase-dependent charge-carrier lifetime have also been correlated with the rotational entropy of the A cation (37). Recent computational studies proposed that charge carriers are weakly localized by the fluctuating organic A cation, although the subsequent energetic stabilization to form polarons is mediated by 

Recently, the focus of the community has shifted to phase-stabilization strategies that can preserve the inherent bandgap of cubic FAPbI3. To minimize the bandgap penalty, “additive removal” approaches have been developed by using the smaller MA<sup>+</sup> cation to first form a highly crystalline perovskite phase and then removing it afterward. MACl is, at present, the most widely used additive among 

3 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



OLHP phases can be modulated by surfaceenergy manipulation. For example, it was demonstrated thatthe metastable CsPbI3 perovskite phase can be stabilized by synthesizing nanosized crystals where the surface-energy contribution becomes dominant compared with that of its bulk counterpart (54). Such an approach was found to be also valid for FAPbI3, where nanocrystalline FAPbI3 demonstrated a superior phase stability compared with its corresponding bulk crystals (55). Surface-energy modulation can also be achieved by adopting surface-functionalizing oversized A cations (56–58). Bulky ammonium cations, such as phenethylammonium(PEA<sup>+</sup> ), butylammonium (BA<sup>+</sup> ), or isopropylammonium, are spontaneously expelled to the grain boundaries and surfaces during perovskite crystallization because of their inability to incorporate into the crystalline lattice bulk. The bulky cations are free from steric constraints at the surface and thus can coordinate with the surface A site by bonding with the surface BX64–. Such surface functionalization was suggested to modulate the crystal surface energy to stabilize the cubic perovskite phase. This approach allows for the stabilization of metastable OLHP phases without changing its bulk composition and inherent bandgap. 





The phase energetics of OLHPs were also suggested to be dependent on the hydrogenbond number and bond strength between the A cation and surrounding inorganic framework (5). This is illustrated by using the divalent methylenediammonium (MDA<sup>2+</sup> ) cation that can form a greater number of hydrogen bonds with the BX64– lattice than FA+ (50). Compared with MA<sup>+</sup> , lower concentrations of MDA<sup>2+</sup> are required to stabilize the cubic phase of FAPbI3, even though the ionic radius of MDA<sup>2+</sup> is slightly oversized compared with that of FA<sup>+</sup> . The incorporation of MDACl2 may generate FA vacancy and interstitial Cl defects to maintain charge neutrality but, importantly, without forming deep trap states. It is noteworthy that the PSC performance and stability improved regardless of the generated additional defects, but further investigations may be necessary to decouple their full consequences. Nevertheless, incorporation of MDA<sup>2+</sup> inadvertently induces tensile lattice strain as a result of its large cation radius. A direct correlation between residual lattice strain and a detrimental effect on the OLHP charge carrier dynamics has been reported (59). To compensate for the residual strain, it was further reported that the smaller Cs<sup>+</sup> cation can be incorporated in equimolar amounts with MDA<sup>2+</sup> (Fig. 3B) (51). Tensile strain relaxation by Cs<sup>+</sup> incorporation resultingly increased the carrier lifetime owing to a reduced defect concentration in the film. The case of MDA<sup>2+</sup> illustrates the possibility of expanding into higher-valencycationsforuseinOLHPs,although 

Fig. 3. Stabilization of the cubic FAPbI3 phase by A cation engineering. (A) Schematics illustrating the metastability of the cubic a-FAPbI3 phase and its corresponding free-energy diagram (left) and approaches to stabilize the cubic a-FAPbI3 phase by tuning the bulk or surface free energy (right). R.T., room temperature. (B) Schematic illustration of lattice strain engineering by using MDA<sup>2+</sup> and Cs<sup>+</sup> cations. Adapted with permission from (51). (C) Schematics showing the free-energy diagrams at different temperatures and refined structures of FAPbI3 at the corresponding temperatures. At temperatures lower than the phase-transition temperature (Tc), the FA<sup>+</sup> cation is oriented within the hexagonal crystal structure, whereas its orientation becomes isotropic (random) in the cubic crystal structure at temperatures higher than Tc, contributing to the entropy of the system. Adapted with permission from (12). 

these approaches (47, 48). The MA<sup>+</sup> cation from the added MACl initially participates in forming the perovskite intermediate phase at room temperature. During the subsequent annealing process, the intermediate phase is converted into the perovskite crystals with the vaporization of MACl. The slow vaporization of MACl and thus retarded crystal growth kinetics promote the growth of highly crystalline perovskite crystals. Regardless of the high molar concentrations of the excess MACl (~40 mol %) in the precursor solution, the final OLHP films contain only a small amount of residual MA<sup>+</sup> (~5 mol %) (49), and thus their bandgaps (~1.50 to 1.53 eV) are comparable to that of pure FAPbI3. This approach enables the formation of phase-pure and highly crystalline FAPbI3-based films, and it has been broadly used in studies that report record-efficiency PSCs (vertical dashed line in Fig. 2D) (50, 51). 

Relatedly, the dual combination of MACl and CsCl was also found to effectively stabilize the perovskite phase (52). A similar approach was developed by using gaseous methylammonium thiocyanate (MASCN) (53). It was reported that MASCN is incorporated onto the surface of hexagonal FAPbI3 crystals to assist in the conversion of the hexagonal phase into the cubic polymorph. For either MACl or MASCN, the counter anions were also reported to contribute to stabilizing the FAPbI3 perovskite phase. Further developments may elucidate the different roles of the counter anions as well as explore alternative cations or counter anions that can impart additional functionalities. 

The phase energetics of materials is governed by the Gibbs free energy of the phase, which is in turn determined by the summation of the bulk and surface free energies. Therefore, the phase conversion of metastable 

4 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



their exact phase-stabilization mechanisms still need to be explored. 





More generally, the vast majority of FAPbI3 stabilization strategies now reported could be considered kinetic stabilization approaches, such that the cubic FAPbI3 phase only remains metastable and still spontaneously degrades into the equilibrium hexagonal phase. Although kinetic stabilization is effective in retarding phase degradation, true thermodynamic stabilization of cubic FAPbI3 as the equilibrium phase remains the elusive goal. To achieve this, understanding the many overlapping factors that affect the thermodynamic energetic landscape of OLHPs is required. For example, the thermally activated random motion of the FA<sup>+</sup> cation and its entropic contribution to the phase energetics were found to have a crucial role in stabilizing the cubic phase (Fig. 3C) (12, 60), but the entropic contribution of the different A cations has barely been explored. Also, the effects of strain on OLHP thermodynamics and energetics have not been fully elucidated and require further systematic investigations. Defect states must also be correlated with the thermodynamic energetics of metastable OLHPs, which has been shown to affect the phase degradation of FAPbI3 (61). 

##### Impeding ion migration by steric and electrostatic interactions 

The charged ionic constituents of OLHPs are mobile under an electric field and accelerated under illumination or at increased temperatures. An ion displaced from its original lattice site becomes a crystal defect (or Schottky, Frenkel defect pairs). Ion (or defect) migration are known to cause the current-voltage hysteresis, phase segregation, and chemical corrosion of reactive functional layers, which are responsible for PSC degradation during operation. Strategies to inhibit ion migration can be broadly categorized as reducing the density of mobile ions and/or increasing the activation energy barrier (Ea) for ions to migrate. 

Fig. 4. Impeding ion migration. (A) Summary of reported Ea enhancements by A cation engineering, including the measurement and calculation methodologies. (AZ, azetidinium; BDA, 1,4-butanediamonium; OAm, oleylaminium). The PCE data and compositions are retrieved from their respective publications (57, 60, 62, 111–113). (B) Theoretically simulated iodide migration pathway for single-cation (top row) or mixed-cation (bottom row) compositions. The simulations were performed using the nudged elastic band and constrained energy minimization methodology. Adapted with permission from (62). (C) X-ray fluorescence mapping of the halide distribution of various mixed-halide perovskite films with different A cation compositions. Scale bars indicate 2 mm. Adapted with permission from (65). Ref, reference; FAMA, mixture of 8.3% FAI and 1.7% MAI. (D) Schematic illustrating the suppressed ion migration by grain boundary 2D (PEA)2PbI4. Adapted with permission from (77). 

PbI64– lattice (62, 66). Molecular dynamics simulations have further indicated that ion migration is affected by the A cation polarity (67). The study suggests that more-polar A cations (e.g., MA<sup>+</sup> is more polar than FA<sup>+</sup> ) may detrimentally assist halide migration because of a reorientation and charge-screening mechanism. 

as a compensating strain relaxation mechanism (64). As a solution, partially substituting FA<sup>+</sup> in FAPbI3 with smaller Cs<sup>+</sup> and/or MA<sup>+</sup> relaxes the intrinsic strain to suppress ion migration and defect formation (41, 51). Such strain relaxation using Cs<sup>+</sup> has also been widely adopted to prevent phase segregation for wide-bandgap mixed-halide compositions (Fig. 4C) (65). Substitutional doping can also increase Ea by strengthening the structural integrity of the OLHP lattice. This is achieved by increasing the bond number and/or decreasing the bond length between the A cation and the BX64– framework. This is illustrated by partial substitution of guanidinium (GA<sup>+</sup> ) into MAPbI3, where GA<sup>+</sup> forms a greater number of effective hydrogen bonds than MA<sup>+</sup> (GA<sup>+</sup> , seven bonds; MA<sup>+</sup> , three bonds) with the 

Relative to single-cation compositions, substitutional doping to create mixed-cation compositions is broadly observed to alleviate PSC hysteresis. In mixed-cation compositions, the local lattice mismatch caused by A cations with different sizes was reported to distort the ionmigration pathways (Fig. 4, A and B) (62). This steric impediment effect was shown to increase Ea to suppress ion migration, which consequently improved the thermal and photostabilities of PSCs. Conversely, excessive lattice strain may detrimentally lower Ea, because ion redistribution constitutes a driving force to relieve residual strain (51, 63). This is especially relevant for pure CsPbI3 and FAPbI3 owing to their extreme t values. The intrinsic strain in FAPbI3 was also shown to promote the formation of Schottky vacancy defects 

The undersized alkali cations, focusing on Rb<sup>+</sup> and K<sup>+</sup> , are widely used as additive dopants to reduce ion migration. The strongly electropositive cations can bind and immobilize excess and undercoordinated halides to suppress their unwanted migration (68). Theoretical simulations also indicate that alkali cation doping increases the formation energy of mobile halide interstitial defects (69). Additionally, assuming incorporation into the A 

5 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



abundance of defective states (61, 86). Consequently, surface modification by posttreatments using A cations has become an essential processing step for state-of-the-art PSCs in recent years (Fig. 5, A and B). Unlike additive doping into the precursor solution that was discussed previously, surface treatments do not interfere with the initial perovskite crystallization process, which enables a larger variety of candidate cations to be used. An additional secondary annealing step typically follows deposition, which may facilitate a chemical reaction with BX2 to form thin lower-dimensional phases at the surface. The deposition of PEA<sup>+</sup> is a notable exception that omits the secondary annealing step. Formation of the 2D (PEA)2PbI4 was indeed observed to weaken the trap passivation effect (87). This distinction for different A cations, of whether formation of the lower-dimensional crystalline phase is preferred, is still not fully understood. 

composition, carbon-based 10-cm–by–10-cm solar modules doped with AVA<sup>+</sup> were shown to sustain their performance for more than 10,000 hours under continuous illumination at 55°C (79). 

site, the resultant lattice contraction decreases the ionic interaction distances to improve the structural integrity of the OLHP lattice (43, 46). There is ongoing debate regarding the residing location of the undersized cations, especially for Rb<sup>+</sup> . Experimental observations have been interpreted as incorporation into the lattice A site (43, 46). Based on t values, their ionic radii should be too small to fit into the A site of the APbI3 lattice. Theoretical calculations suggest that interstitial site occupation is energetically favorable (70–72). Conversely, solidstate NMR results suggest that Rb<sup>+</sup> and K<sup>+</sup> are entirely immiscible (even at the interstitial sites) and segregate into secondary photoinactive phases (73). These discrepancies may perhaps be related to varying miscibility limits of different OLHP compositions. For example, K<sup>+</sup> incorporation may be facilitated by Br<sup>–</sup> in mixed-halide APbI3−xBrx stoichiometries (74). Particularly, if assuming the undersized cations are indeed expelled from the A site, alternative mechanisms that do not involve lattice occupancy must be elucidated to explain their ion-migration impediment effects. For example, interstitial site occupancy has been suggested to prevent lattice iodine from displacing into the filled interstitial sites, which inhibits the formation of mobile iodide Frenkel defects (iodine interstitial-vacancy pairs) (70, 75). 





Bulky cyclic cation additives, including 1-butyl-1-methylpiperidinium (BMP) and 1-butyl-3-methylimidazolium (BMIM), have been reported to dramatically inhibit ion migration and OLHP decomposition even at increased temperatures (80, 81). It was proposed that BMP may simultaneously reduce the density of mobile iodide Frenkel defects and inhibit the migration of iodine interstitial defects, which quenched the formation rate of harmful I2 that catalyzes perovskite degradation (81). Ion migration–facilitated formations of d-FAPbI3 and segregated FAPbBr3 impurity phases during degradation may also be suppressed by BMP addition (81). Interestingly, BMIM was observed to aggregate predominantly at the buried interface, whereas BMP was distributed along the grain boundaries. It was suggested that the segregation of BMIM modified its interface dynamics to become incompatible with poly-TPD [poly(N,N′-bis4-butylphenyl-N,N′-bisphenyl)benzidine] as the bottom transport layer, whereas BMP addition was not affected by this problem. This comparison highlights the fact that additive doping can possibly incur unintentional side effects to negatively alter the perovskite crystallization dynamics or interfacial energy alignments. More generally, this emphasizes the importance of locating the distribution of different additive dopants within and around the OLHP layer. 

Surface functionalization of A cations often confers beneficial trap passivation and environmental protection effects. For the former, various functional groups on the cation can coordinate with surface defects to passivate their charge-trapping ability. Most commonly, the –NH3+ group of ubiquitous ammonium-based cations interacts with negatively charged defects (85). Chemical and structural tailoring of the cation backbone is often used to enhance its binding and interaction with surface traps. This is illustrated by the incorporation of the tert-butyl moiety (25, 88), which also has the additional benefit of improving the interfacial contact with spiro‐ MeOTAD [2,2′,7,7′-tetrakis(4,4′-dimethoxy-3methyldiphenylamino)-9,9′-spirobifluorene] to facilitate hole extraction (88). Conversely, the –NH3+ functionality is insensitive to positively charged defects, such as halide vacancies, which readily form at the OLHP surface. This can be remedied by using zwitterions to simultaneously coordinate with both oppositely charged defects, for instance, by incorporating carboxyl or phosphate groups into the ammonium chain (25, 89). Regarding environmental protection, bulky A cations with hydrophobic chains that orient out of plane with the surface can repel H2O and O2 ingression while simultaneously limiting the escape of the OLHP constituents from the active layer. Well-known hydrophobic groups include tertiary or quaternary hydrocarbons (e.g., tetra-ethylammonium) (88–90) and/or electron-withdrawing fluorine moieties, such as in 4-fluorophenylethylammonium or pentafluorophenylethylammonium (60, 91). In general, a large variety of useful backbone-chain modifications can be found in the literature to enhance such desirable effects. However, despite these successes, concrete selection and design rules still need to be established to avoid 

Oversized organic A cations are often used as additive dopants into the precursor solution. As discussed, the bulky cations segregate at the grain boundaries and surfaces, possibly forming lower-dimensional phases depending on the specific species. The bulky cations can act as physical barriers to increase Ea by blocking the low-energy ion-migration channels through the grain boundaries (Fig. 4D) (76, 77). The –NH3+ functional group of ammoniumbased cations can also bind with negatively charged defects (e.g., A cation vacancies, undercoordinated halides) by electrostatic interactions to inhibit their migration and deactivate their charge-trapping ability. In an alternate perspective, the replacement of defective grainboundary regions with lower-dimensional phases equivalently decreases the overall defect density, thus reducing the overall concentration of mobile defective species. Functional groups can be introduced to the A cation chain to strengthen the bonding interaction between adjacent cations along the grain boundary to improve structural rigidity. This is exemplified by incorporating a carboxyl tail into BA<sup>+</sup> , forming 5-ammoniumvaleric acid (5-AVA). Adjacent 5-AVA cations interact through stronger hydrogen bonding rather than the van der Waals interaction between BA<sup>+</sup> cations. Resultantly, doping of 5-AVA into MAPbI3 was reported to dramatically suppress the loss of MAI by ion migration–driven volatilization (78). Despite using the supposedly unstable MAPbI3 base 

Ion migration is fundamentally a defectdriven process. Theoretical studies show that halide migration, mediated by vacancy defects, is the lowest-energy transport mechanism, with an Ea between 0.1 and 0.6 eV (82). However, the vast majority of mitigation strategies in the literature fall short of pinpointing the specific defect species that are immobilized or suppressed. Further studies are necessary to investigate the binding and interaction of A cations with the complex defect landscape of OLHPs to mechanistically explain their ion-migration impediment effects. 

##### Surface functionalization and interfacial modification 

The OLHP surface is typically BX2-rich owing to a combination of volatilization of organic FA<sup>+</sup> or MA<sup>+</sup> during thermal annealing, dissolution of FA<sup>+</sup> or MA<sup>+</sup> by the deposition of solvent during surface posttreatment, or excess BX2, particularly excess PbI2, intentionally added to the precursor solution (83–85). Degradation initiation and nonradiative recombination losses predominantly occur at the OLHP top surface region as a result of an 

6 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



counter anion, including GABr (84), FABr (83), and MABr (94). Such grain recrystallization can effectively minimize surface pinhole and/or PbI2 formation (84). More generally, rather than the ubiquitous I<sup>–</sup> (or Br<sup>–</sup> ), pairing A cations with alternative counter anions presents further opportunities to modify the OLHP surface, in addition to avoiding the possible formation of iodine interstitial defects as a side effect (61). For instance, sulfate (SO42–) and phosphate (PO43–) counter anions [paired with octylammonium (OA<sup>+</sup> )] were reported to form thin (<5 nm) PbSO4 or Pb3(PO4)2 layers on the OLHP surface, which effectively inhibited ion migration owing to the strong chemical binding with the surface (95). Elsewhere, trifluoroacetate (CF3COO<sup>–</sup> ) as a counter anion was reported to interact more strongly with halide vacancies on the surface (61). As discussed, it was traditionally believed that A cations do not directly participate in constructing the OLHP band-edge electronic structure. This notion has since been challenged by the use of bulky polycyclic pyrenebased ammonium cations, where the frontier orbital separation of the cations was lowered by electron delocalization in the p-conjugated p-conjugated-conjugated pyrene tails (Fig. 5D) (96). This enabled the96). This enabled the). This enabled the orbitals of pyrene-methylammonium and pyrene-ethylammonium to overlap the I 5p and Pb 6s band-edge orbitals to contribute electronic states to the valence-band maximum, which increased hole mobility at the surface. Future works might explore whether the conjugated cations may have distorted the PbX64– octahedra differently, which could have64– octahedra differently, which could have4– octahedra differently, which could have– octahedra differently, which could have octahedra differently, which could have contributed to altering the band dispersion. Surface functionalization typically alters the OLHP energy-level alignment, which can beneficially promote carrier extraction by a contacting charge-selective layer. To maximize built-in potential, a pressure-assisted, solid-state growth strategy was reported by transfer from an as-grown (BA)2PbI42PbI4PbI44 template with annealing (97). The method was capable of growing a97). The method was capable of growing a). The method was capable of growing a highly crystalline and phase-pure 2D (BA)2PbI42PbI4PbI44 





As discussed, it was traditionally believed that A cations do not directly participate in constructing the OLHP band-edge electronic structure. This notion has since been challenged by the use of bulky polycyclic pyrenebased ammonium cations, where the frontier orbital separation of the cations was lowered by electron delocalization in the p-conjugated p-conjugated-conjugated pyrene tails (Fig. 5D) (96). This enabled the96). This enabled the). This enabled the orbitals of pyrene-methylammonium and pyrene-ethylammonium to overlap the I 5p and Pb 6s band-edge orbitals to contribute electronic states to the valence-band maximum, which increased hole mobility at the surface. Future works might explore whether the conjugated cations may have distorted the PbX64– octahedra differently, which could have64– octahedra differently, which could have4– octahedra differently, which could have– octahedra differently, which could have octahedra differently, which could have contributed to altering the band dispersion. Surface functionalization typically alters the OLHP energy-level alignment, which can beneficially promote carrier extraction by a contacting charge-selective layer. To maximize built-in potential, a pressure-assisted, solid-state growth strategy was reported by transfer from an as-grown (BA)2PbI42PbI4PbI44 template with annealing (97). The method was capable of growing a97). The method was capable of growing a). The method was capable of growing a highly crystalline and phase-pure 2D (BA)2PbI42PbI4PbI44 layer on top of the 3D perovskite. Thickness control was demonstrated by simply changing the annealing temperature or by an iteration process. Conversely, different studies have reported the formation of either type I or type II band alignments for identical or similar A cation species (92, 97–100). Further mechanistic studies are necessary to explain the conflicting results. One possibility may be related to varying A cation distribution and orientation at the surface, which shift the OLHP band energetics differently (100). Both type I or type II alignments beneficially repel electrons away from a hole-selective interface, but type I alignments may represent an extraction barrier for holes. Relatedly, the chain groups of bulky A cations are typically electrically insulating. This effect manifests where, 

Fig. 5. Surface and interface modification by oversized A cations. (A) Summary of state-of-the-art PSCs with certified performance since 2019, highlighting the surface functionalization by the oversized A cations that were used. The data are plotted based on publication date. NREL, National Renewable Energy Laboratory. (B) Corresponding photovoltaic parameters from (A), with the horizontal dashed lines marking the theoretical Shockley-Queisser limits of each parameter for a bandgap of 1.5 eV. JSC, short-circuit current; VOC, open-circuit voltage; FF, fill factor. (C) Schematic of the surface-induced secondary grain growth (SISG) process by using alkylammonium functionalization to control the surface-energy anisotropy (left). Top-view scanning electron microscopy images of the perovskite films treated with various alkylammonium cations of different chain lengths (right). Adapted with permission from (93). g, surface energy; OCA, octylammonium; OLA, oleylammonium. (D) Schematic illustrating the interactions of different pyrene-based ammonium cations with the OLHP film surface (left). Ultraviolet photoelectron spectroscopy spectra of OLHP films treated with the different cations (right). Red circles indicate the additional electronic states. Adapted with permission from (96). a.u., arbitrary units; PRA, pyrene-ammonium; PRMA, pyrene-methylammonium; PREA, pyrene-ethylammonium. 

on both HTA<sup>+</sup> and P3HT promoted the growth of P3HT with a fibril structure. The fibril structure was suggested to enhance the chargeextraction capability of P3HT as a dopant-free hole-transporting material. This notable breakthrough resulted in one of the previous worldrecord performance PSCs (green dot in Fig. 5A). Relatedly, A cations can also be used to manipulate the OLHP surface energy. This can be exploited to induce the preferential growth of specific crystallographic planes with lower energy. During a secondary graingrowth process, BA<sup>+</sup> , octylammonium, and oleylammonium progressively decreased the (100) plane surface energy to promote the recrystallization of highly textured (100) grains with greatly enlarged grain sizes (Fig. 5C) (93). Secondary surface grain growth has also been reported for A cations paired with Br<sup>–</sup> as the 

the utility of trial-and-error approaches and to maximize beneficial improvements. 

In addition to their contributions to hydrophobicity and defect passivation, important breakthroughs in recent years have been realized by A cation surface modification. The top surface of OLHP films forms a carrier-extraction interface with a contacting charge-selective layer, typically a hydrophobic organic material. Surface modification by A cations can be used to aid the assembly of the charge-transporting layer and improve interfacial contact, by tailoring the interaction between the charge-transporting layer species and specific moieties on the A cation. This is exemplified by the use of n-hexyl-trimethylammonium (HTA<sup>+</sup> ) to facilitate the self-assembly of poly(3-hexylthiophene) (P3HT) (92). Interdigitation of the hydrophobic hexyl (–C6H13) backbone chains contained 

7 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 



MA<sup>+</sup> . Besides size considerations, chemical efficiency exceeding 9%. Sci. Rep. 2, 591 (2012). design principles also include polarity, stereodoi: 10.1038/srep00591; pmid: 22912919 2. J.-H. Im, C.-R. Lee, J.-W. Lee, S.-W. Park, N.-G. Park, 6.5% chemistry, coordination, and bonding. The efficient perovskite quantum-dot-sensitized solar cell. characteristic dynamic nature of organic A Nanoscale 3, 4088–4093 (2011). doi: 10.1039/c1nr10867k; cations should also be taken into account. pmid: 21897986 3. J. Y. Kim, J.-W. Lee, H. S. Jung, H. Shin, N.-G. Park, These criteria are also applicable to chainHigh-efficiency perovskite solar cells. Chem. Rev. 120, group modification of bulky organic cations. 7867–7918 (2020). doi: 10.1021/acs.chemrev.0c00107; Chemical design of the A cation must further pmid: 32786671 be correlated with the structural and thermo4. S. Tao et al., Absolute energy level positions in tin- and lead-based halide perovskites. Nat. Commun. 10, 2560 dynamic stability of the lattice and its binding (2019). doi: 10.1038/s41467-019-10468-7; pmid: 31189871 and interaction with the ionic and defective 5. K. L. Svane et al., How strong is the hydrogen bond in hybrid constituents of OLHPs. Particularly, cation poperovskites? J. Phys. Chem. Lett. 8, 6154–6159 (2017). doi: 10.1021/acs.jpclett.7b03106; pmid: 29216715 larity has been investigated relatively less but 6. A. M. Leguy et al., The dynamics of methylammonium ions in profoundly influences ion migration (67), surhybrid organic–inorganic perovskite solar cells. Nat. face energy (93), trap passivation, and charge Commun. 6, 7124 (2015). doi: 10.1038/ncomms8124; pmid: 26023041 extraction (99, 101). Machine-learning meth7. H. Zhu et al.,., Screening in crystalline liquids protects odologies have been gaining traction in the energetic carriers in hybrid perovskites. Science 353,, community, which may prove useful for accel1409–1413–14131413 (2016). doi: 10.1126/science.aaf9570;; pmid: 27708033 erated screening and discovery. 8. A. A. Bakulin et al.,., Real-time observation of organic cation 

for example, with increasing alkylammonium chain length, the higher cation dipole moment enhances its interaction with traps to further reduce nonradiative recombination losses, but conversely, the longer insulating chain increases series resistance, which is detrimental for charge extraction (99, 101). Likewise, it is often observed that with increasingly higher A cation surface density, the PSC open-circuit voltage typically increases monotonously but the fill factor peaks at an optimum concentration before subsequently decreasing as the insulating surface layer becomes too thick. It is therefore crucial to carefully design the A cation chain group and elucidate its density, distribution, and orientation on the OLHP surface to maximize its beneficial effects while ensuringthatcarrierextractionisnotcompromised. 



7. H. Zhu et al.,., Screening in crystalline liquids protects energetic carriers in hybrid perovskites. Science 353,, 1409–1413–14131413 (2016). doi: 10.1126/science.aaf9570;; pmid: 27708033 

8. A. A. Bakulin et al.,., Real-time observation of organic cation reorientation in methylammonium lead iodide perovskites. J. Phys. Chem. Lett. 6, 3663–3669 (2015). doi: 10.1021/ acs.jpclett.5b01555; pmid: 26722739 

9. F. Brivio et al., Lattice dynamics and vibrational spectra of the orthorhombic, tetragonal, and cubic phases of methylammonium lead iodide. Phys. Rev. B 92, 144308 (2015). doi: 10.1103/PhysRevB.92.144308 

##### Perspectives 

Relatedly, to date, ammonium-based species constitute most of the A cations applied to OLHPs. However, the protic (acidic) ammonium group is susceptible to deprotonation by hydrogen donation, rendering it chemically vulnerable to water and radical and basic species. Therefore, the environmental stability of ammonium species is inherently limited by their proticity, despite the presence of hydrophobic chain groups. In this regard, replacing ammoniums with their analogous, aprotic sulfonium cations may offer a solution because of their lower acidity. It will be necessary to understand the likely different formability and interactions of sulfonium cations with the OLHP constituents and processing solvents, in consideration of the different polarity between sulfoniums and their ammonium counterparts. 

The structural flexibility of OLHPs has enabled A cation engineering to be a versatile approach to tailor and improve the properties of OLHPs for different applications. Future opportunities can be generally categorized as discovering new uses for existing A cation species or identifying new A cations for existing applications. 

10. J.-W. Lee et al., Dynamic structural property of organicinorganic metal halide perovskite. iScience 24, 101959 (2020). doi: 10.1016/j.isci.2020.101959; pmid: 33437939 

11. B. Yang et al., Real-time observation of order-disorder transformation of organic cations induced phase transition and anomalous photoluminescence in hybrid perovskites. Adv. Mater. 30, e1705801 (2018). doi: 10.1002/ adma.201705801; pmid: 29660765 

12. T. Chen et al., Entropy-driven structural transition and kinetic trapping in formamidinium lead iodide perovskite. Sci. Adv. 2, e1601650 (2016). doi: 10.1126/sciadv.1601650; pmid: 27819055 

The former category necessitates a more comprehensive understanding of the structureinteraction-property-performance-stability correlations conferred by A cations. A fundamental understanding of the atomistic and mechanistic origins of reported beneficial improvements conferred by A cation engineering is still lacking. This includes understanding the physicochemical interactions of A cations with the lattice constituents, band structure, and charge carriers, as well as their assembly, occupancy, and distribution within the OLHP layer. For instance, the correlation between the dynamic A cation motion and OLHP charge-carrier dynamics is still under debate. This understanding may enable the design of targeted A cation compositions for different device applications, such as solar cells, photodetectors, or light-emitting diodes. Also, the spontaneous expulsion and assembly of oversized cations along the surfaces and grain boundaries are poorly understood but crucial to understand because of the generally insulating nature of the organic side chains. 

13. G. Kieslich, S. Sun, A. K. Cheetham, Solid-state principles applied to organic–inorganic perovskites: New tricks for an old dog. Chem. Sci. 5, 4712–4715 (2014). doi: 10.1039/ C4SC02211D 

14. S. Gholipour et al., Globularity-selected large molecules for a new generation of multication perovskites. Adv. Mater. 29, 1702005 (2017). doi: 10.1002/adma.201702005; pmid: 28833614 

15. J. H. Noh, S. H. Im, J. H. Heo, T. N. Mandal, S. I. Seok, Chemical management for colorful, efficient, and stable inorganic-organic hybrid nanostructured solar cells. Nano Lett. 13, 1764–1769 (2013). doi: 10.1021/nl400349b; pmid: 23517331 

More generally, for OLHP optoelectronics to achieve market readiness, the challenge should now be focused on addressing their long-term operational instability issues, which remain far short of the acceptable lifetime guarantees of commercial products. Engineering of A cations has contributed immensely to the stabilization improvements to date, but further progress is required. Reducing the device-to-module upscaling gap of OLHP technology is another crucial hurdle, and it is necessary to investigate the application and adaptability of A cation engineering strategies at the module scale. It is also important to investigate the applicability of Pb-based A cation engineering strategies when extending toward Sn or Pb-Sn stoichiometries, which are attractive for tandem applications or to reduce toxic Pb usage. There is still much work left to be done, and it will be important to fully understand the role and contribution of the A cation. 

16. W. Rehman et al., Charge‐carrier dynamics and mobilities in formamidinium lead mixed‐halide perovskites. Adv. Mater. 27, 7938–7944 (2015). doi: 10.1002/adma.201502969; pmid: 26402226 

17. L. M. Herz, Charge-carrier mobilities in metal halide perovskites: Fundamental mechanisms and limits. ACS Energy Lett. 2, 1539–1548 (2017). doi: 10.1021/ acsenergylett.7b00276 

18. D. P. McMeekin et al., A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. Science 351, 151–155 (2016). doi: 10.1126/science.aad5845; pmid: 26744401 

For the latter category, despite the increasing number of candidates of oversized and undersized cations, only a limited number of cations can be bulk-incorporated into the lattice A site, limiting compositional diversity. Considerable efforts during the early days of OLHP research were devoted to identifying cations for bulk occupancy, but these have essentially ceased. This is related to an absence of working selection and design rules. The ideal bulk A cation should be slightly smaller than FA<sup>+</sup> but free of the volatility issues of 

19. N. J. Jeon et al., Compositional engineering of perovskite materials for high-performance solar cells. Nature 517, 476–480 (2015). doi: 10.1038/nature14133; pmid: 25561177 

20. A. Al-Ashouri et al., Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300–1309 (2020). doi: 10.1126/science. abd4016; pmid: 33303611 

21. D. Kim et al., Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. Science 368, 155–160 (2020). doi: 10.1126/science.aba3433; pmid: 32217753 

###### REFERENCES AND NOTES 

   22. G. E. Eperon et al., Perovskite-perovskite tandem photovoltaics with optimized band gaps. Science 354, 861–865 (2016). doi: 10.1126/science.aaf9717; pmid: 27856902 

1. H.-S. Kim et al., Lead iodide perovskite sensitized all-solidstate submicron thin film mesoscopic solar cell with 

8 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 







solar cells. Nat. Energy 2, 972–979 (2017). doi: 10.1038/ s41560-017-0054-3 

solar cells. Energy Environ. Sci. 9, 656–662 (2016). doi: 10.1039/C5EE03255E 

23. D. J. Slotcavage, H. I. Karunadasa, M. D. McGehee, Lightinduced phase segregation in halide-perovskite absorbers. ACS Energy Lett. 1, 1199–1205 (2016). doi: 10.1021/ acsenergylett.6b00495 

45. M. Saliba et al., Cesium-containing triple cation perovskite solar cells: Improved stability, reproducibility and high efficiency. Energy Environ. Sci. 9, 1989–1997 (2016). doi: 10.1039/C5EE03874J; pmid: 27478500 

   67. E. Mosconi, F. De Angelis, Mobile ions in organohalide perovskites: Interplay of electronic structure and dynamics. ACS Energy Lett. 1, 182–188 (2016). doi: 10.1021/ acsenergylett.6b00108 

24. X. Chang et al., Printable CsPbI3 perovskite solar cells with PCE of 19% via an additive strategy. Adv. Mater. 32, e2001243 (2020). doi: 10.1002/adma.202001243; pmid: 32864773 

      68. M. Abdi-Jalebi et al., Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. Nature 555, 497–501 (2018). doi: 10.1038/nature25989; pmid: 29565365 

   46. M. Saliba et al., Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 206–209 (2016). doi: 10.1126/science.aah5557; pmid: 27708053 

   47. Z. Wang et al., Additive-modulated evolution of HC(NH2)2PbI3 black polymorph for mesoscopic perovskite solar cells. Chem. Mater. 27, 7149–7155 (2015). doi: 10.1021/ acs.chemmater.5b03169 

25. Y. Wang et al., Thermodynamically stabilized b-CsPbI3-based perovskite solar cells with efficiencies >18. Science 365, 591–595 (2019). doi: 10.1126/science.aav8680; 

      69. L. Qiao, W. H. Fang, R. Long, O. V. Prezhdo, Extending carrier lifetimes in lead halide perovskites with alkali metals by passivating and eliminating halide interstitial defects. Angew. Chem. Int. Ed. 59, 4684–4690 (2020). doi: 10.1002/ ange.201911615; pmid: 31873979 

   - pmid: 31395783 

26. H. Tsai et al., High-efficiency two-dimensional RuddlesdenPopper perovskite solar cells. Nature 536, 312–316 (2016). doi: 10.1038/nature18306; pmid: 27383783 

48. M. Kim et al., Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. Joule 3, 2179–2192 (2019). doi: 10.1016/ j.joule.2019.06.014 

   70. D. Y. Son et al., Universal approach toward hysteresis-free perovskite solar cell via defect engineering. J. Am. Chem. Soc. 140, 1358–1364 (2018). doi: 10.1021/jacs.7b10430; pmid: 29300468 

27. L. N. Quan et al., Ligand-stabilized reduced-dimensionality perovskites. J. Am. Chem. Soc. 138, 2649–2655 (2016). doi: 10.1021/jacs.5b11740; pmid: 26841130 

28. C. Liang et al., Two-dimensional Ruddlesden–Popper layered perovskite solar cells based on phase-pure thin films. Nat. Energy 6, 38–45 (2021). doi: 10.1038/ s41560-020-00721-5 

49. J. Jeong et al., Pseudo-halide anion engineering for a-FAPbI3 perovskite solar cells. Nature 592, 381–385 (2021). doi: 10.1038/s41586-021-03406-5; pmid: 33820983 

      71. J. Cao, S. X. Tao, P. A. Bobbert, C. P. Wong, N. Zhao, Interstitial occupancy by extrinsic alkali cations in perovskites and its impact on ion migration. Adv. Mater. 30, e1707350 (2018). doi: 10.1002/adma.201707350; pmid: 29736912 

   50. H. Min et al., Efficient, stable solar cells by using inherent bandgap of a-phase formamidinium lead iodide. Science 366, 749–753 (2019). doi: 10.1126/science.aay7044; pmid: 31699938 

29. F. Wang et al., Solvated electrons in solids—Ferroelectric large polarons in lead halide perovskites. J. Am. Chem. Soc. 143, 5–16 (2021). doi: 10.1021/jacs.0c10943; pmid: 33320656 

      72. N. X. Li et al., Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells. Nat. Energy 4, 408–415 (2019). doi: 10.1038/s41560-019-0382-6 

   51. G. Kim et al., Impact of strain relaxation on performance of a-formamidinium lead iodide perovskite solar cells. Science 370, 108–112 (2020). doi: 10.1126/science.abc4417; pmid: 33004518 

30. X. Y. Zhu, V. Podzorov, Charge carriers in hybrid organicinorganic lead halide perovskites might be protected as large polarons. J. Phys. Chem. Lett. 6, 4758–4761 (2015). doi: 10.1021/acs.jpclett.5b02462; pmid: 26575427 

      73. D. J. Kubicki et al., Phase segregation in Cs-, Rb- and K-doped mixed-cation (MA)x(FA)1–xPbI3 hybrid perovskites from solid-state NMR. J. Am. Chem. Soc. 139, 14173–14180 (2017). doi: 10.1021/jacs.7b07223; pmid: 28892374 

   52. I. S. Yang, N. G. Park, Dual additive for simultaneous improvement of photovoltaic performance and stability of perovskite solar cell. Adv. Funct. Mater. 31, 2100396 (2021). doi: 10.1002/adfm.202100396 

31. N. Balkan, Hot Electrons In Semiconductors: Physics and Devices (Oxford Univ. Press, 1998). 

   74. Y. El Ajjouri, V. S. Chirvony, M. Sessolo, F. Palazon, H. J. Bolink, Incorporation of potassium halides in the mechanosynthesis of inorganic perovskites: Feasibility and limitations of ion-replacement and trap passivation. RSC Advances 8, 41548–41551 (2018). doi: 10.1039/ C8RA08823C 

   75. S.-G. Kim et al., Potassium ions as a kinetic controller in ionic double layers for hysteresis-free perovskite solar cells. J. Mater. Chem. A Mater. Energy Sustain. 7, 18807–18815 (2019). doi: 10.1039/C9TA07595J 

32. J. Chen, M. E. Messing, K. Zheng, T. Pullerits, Cation-dependent hot carrier cooling in halide perovskite nanocrystals. J. Am. Chem. Soc. 141, 3532–3540 (2019). doi: 10.1021/jacs.8b11867; pmid: 30685969 

   53. H. Lu et al., Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. Science 370, eabb8985 (2020). doi: 10.1126/science.abb8985; pmid: 33004488 

33. H. Zhu et al., Organic cations might not be essential to the remarkable properties of band edge carriers in lead halide perovskites. Adv. Mater. 29, 1603072 (2017). doi: 10.1002/ adma.201603072; pmid: 27792264 

   54. A. Swarnkar et al., Quantum dot-induced phase stabilization of a-CsPbI3 perovskite for high-efficiency photovoltaics. Science 354, 92–95 (2016). doi: 10.1126/science.aag2700; pmid: 27846497 

34. G. E. Eperon et al., Formamidinium lead trihalide: A broadly tunable perovskite for efficient planar heterojunction solar cells. Energy Environ. Sci. 7, 982–988 (2014). doi: 10.1039/ c3ee43822h 

55. J. Xue et al., Surface ligand management for stable FAPbI3 perovskite quantum dot solar cells. Joule 2, 1866–1878 (2018). doi: 10.1016/j.joule.2018.07.018 

56. Y. Fu et al., Stabilization of the metastable lead iodide perovskite phase via surface functionalization. Nano Lett. 17, 4405–4414 (2017). doi: 10.1021/acs.nanolett.7b01500; pmid: 28595016 

   76. Z. P. Wang et al., Efficient ambient-air-stable solar cells with 2D-3D heterostructured butylammonium-caesiumformamidinium lead halide perovskites. Nat. Energy 2, 17135 (2017). doi: 10.1038/nenergy.2017.135 

   77. J. Chen, D. Lee, N.-G. Park, Stabilizing the Ag electrode and reducing J–V hysteresis through suppression of iodide migration in perovskite solar cells. ACS Appl. Mater. Interfaces 9, 36338–36349 (2017). doi: 10.1021/ acsami.7b07595; pmid: 28952714 

35. G. Xing et al., Long-range balanced electron- and holetransport lengths in organic-inorganic CH3NH3PbI3. Science 342, 344–347 (2013). doi: 10.1126/science.1243167; pmid: 24136965 

36. D. J. Kubicki et al., Formation of stable mixed guanidinium– methylammonium phases with exceptionally long carrier lifetimes for high-efficiency lead iodide-based perovskite photovoltaics. J. Am. Chem. Soc. 140, 3345–3351 (2018). doi: 10.1021/jacs.7b12860; pmid: 29429335 

57. J.-W. Lee et al., 2D perovskite stabilized phase-pure formamidinium perovskite solar cells. Nat. Commun. 9, 3021 (2018). doi: 10.1038/s41467-018-05454-4; pmid: 30069012 

58. B. Park et al., Stabilization of formamidinium lead triiodide a-phase with isopropylammonium chloride for perovskite solar cells. Nat. Energy 6, 419–428 (2021). doi: 10.1038/ s41560-021-00802-z 

59. S.-G. Kim et al., How antisolvent miscibility affects perovskite film wrinkling and photovoltaic properties. Nat. Commun. 12, 1554 (2021). doi: 10.1038/s41467-021-21803-2; pmid: 33692346 

   78. A. Y. Mei et al., Stabilizing perovskite solar cells to IEC61215:2016 standards with over 9,000-h operational tracking. Joule 4, 2646–2660 (2020). doi: 10.1016/ j.joule.2020.09.010 

37. T. Chen et al., Origin of long lifetime of band-edge charge carriers in organic-inorganic lead iodide perovskites. Proc. Natl. Acad. Sci. U.S.A. 114, 7519–7524 (2017). doi: 10.1073/ pnas.1704421114; pmid: 28673975 

   79. G. Grancini et al., One-year stable perovskite solar cells by 2D/3D interface engineering. Nat. Commun. 8, 15684 (2017). doi: 10.1038/ncomms15684; pmid: 28569749 

38. F. Ambrosio, D. Meggiolaro, E. Mosconi, F. De Angelis, Charge localization, stabilization, and hopping in lead halide perovskites: Competition between polaron stabilization and cation disorder. ACS Energy Lett. 4, 2013–2020 (2019). doi: 10.1021/acsenergylett.9b01353 

      80. S. Bai et al., Planar perovskite solar cells with long-term stability using ionic liquid additives. Nature 571, 245–250 (2019). doi: 10.1038/s41586-019-1357-2; pmid: 31292555 

      81. Y. H. Lin et al., A piperidinium salt stabilizes efficient metalhalide perovskite solar cells. Science 369, 96–102 (2020). doi: 10.1126/science.aba1628; pmid: 32631893 

   60. J.-W. Lee et al., Solid-phase hetero epitaxial growth of a-phase formamidinium perovskite. Nat. Commun. 11, 5514 (2020). doi: 10.1038/s41467-020-19237-3; pmid: 33139740 

39. A. Binek, F. C. Hanusch, P. Docampo, T. Bein, Stabilization of the trigonal high-temperature phase of formamidinium lead iodide. J. Phys. Chem. Lett. 6, 1249–1253 (2015). doi: 10.1021/acs.jpclett.5b00380; pmid: 26262982 

61. S. Tan et al., Shallow iodine defects accelerate the degradation of a-phase formamidinium perovskite. Joule 4, 2426–2442 (2020). doi: 10.1016/j.joule.2020.08.016 

62. S. Tan et al., Steric impediment of ion migration contributes to improved operational stability of perovskite solar cells. Adv. Mater. 32, e1906995 (2020). doi: 10.1002/ adma.201906995; pmid: 32017283 

   82. C. Eames et al., Ionic transport in hybrid lead iodide perovskite solar cells. Nat. Commun. 6, 7497 (2015). doi: 10.1038/ncomms8497; pmid: 26105623 

40. A. Amat et al., Cation-induced band-gap tuning in organohalide perovskites: Interplay of spin-orbit coupling and octahedra tilting. Nano Lett. 14, 3608–3616 (2014). doi: 10.1021/nl5012992; pmid: 24797342 

      83. K. T. Cho et al., Highly efficient perovskite solar cells with a compositionally engineered perovskite/hole transporting material interface. Energy Environ. Sci. 10, 621–627 (2017). doi: 10.1039/C6EE03182J 

   63. J. Zhao et al., Strained hybrid perovskite thin films and their impact on the intrinsic stability of perovskite solar cells. Sci. Adv. 3, eaao5616 (2017). doi: 10.1126/sciadv.aao5616; pmid: 29159287 

41. J. W. Lee et al., Formamidinium and cesium hybridization for photo‐and moisture‐stable perovskite solar cell. Adv. Energy Mater. 5, 1501310 (2015). doi: 10.1002/aenm.201501310 

      84. D. Luo et al., Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. Science 360, 1442–1446 (2018). doi: 10.1126/science.aap9282;pmid: 29954975 

   64. M. I. Saidaminov et al., Suppression of atomic vacancies via incorporation of isovalent small ions to increase the stability of halide perovskite solar cells in ambient air. Nat. Energy 3, 648–654 (2018). doi: 10.1038/s41560-018-0192-2 

42. Z. Li et al., Stabilizing perovskite structures by tuning tolerance factor: Formation of formamidinium and cesium lead iodide solid-state alloys. Chem. Mater. 28, 284–292 (2016). doi: 10.1021/acs.chemmater.5b04107 

   85. S. Tan et al., Surface reconstruction of halide perovskites during post-treatment. J. Am. Chem. Soc. 143, 6781–6786 (2021). doi: 10.1021/jacs.1c00757; pmid: 33915050 

   86. Z. Ni et al., Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. Science 367, 1352–1358 (2020). doi: 10.1126/science.aba0893; pmid: 32193323 

43. Y. H. Park et al., Inorganic rubidium cation as an enhancer for photovoltaic performance and moisture stability of HC(NH2)2PbI3 perovskite solar cells. Adv. Funct. Mater. 27, 1605988 (2017). doi: 10.1002/adfm.201605988 

65. J. P. Correa-Baena et al., Homogenized halides and alkali cation segregation in alloyed organic-inorganic perovskites. Science 363, 627–631 (2019). doi: 10.1126/science.aah5065; pmid: 30733417 

   87. Q. Jiang et al., Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 460–466 (2019). doi: 10.1038/s41566-019-0398-2; pmid: 33416305 

44. C. Yi et al., Entropic stabilization of mixed A-cation ABX3 metal halide perovskites for high performance perovskite 

66. A. D. Jodlowski et al., Large guanidinium cation mixed with methylammonium in lead iodide perovskites for 19% efficient 

9 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 

RESEARCH | REVIEW 







88. H. Zhu et al., Tailored amphiphilic molecular mitigators for stable perovskite solar cells with 23.5% efficiency. Adv. Mater. 32, e1907757 (2020). doi: 10.1002/adma.201907757; pmid: 32068922 

99. J. J. Yoo et al., An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss. Energy Environ. Sci. 12, 2192–2199 (2019). doi: 10.1039/ C9EE00751B 

   109. J. J. Yoo et al., Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593 (2021). doi: 10.1038/s41586-021-03285-w; pmid: 33627807 

   110. H. Min et al., Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450 (2021). doi: 10.1038/s41586-021-03964-8; pmid: 34671136 

89. X. P. Zheng et al., Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. Nat. Energy 2, 17102 (2017). doi: 10.1038/ nenergy.2017.102 

100. R. Quintero-Bermudez et al., Ligand-induced surface charge density modulation generates local type-II band alignment in reduced-dimensional perovskites. J. Am. Chem. Soc. 141, 13459–13467 (2019). doi: 10.1021/jacs.9b04801; 

      111. D. W. Ferdani et al., Partial cation substitution reduces iodide ion transport in lead iodide perovskite solar cells. Energy Environ. Sci. 12, 2264–2272 (2019). doi: 10.1039/ C9EE00476A 

   - pmid: 31366193 

90. S. Yang et al., Functionalization of perovskite thin films with moisture-tolerant molecules. Nat. Energy 1, 15016 (2016). doi: 10.1038/nenergy.2015.16 

101. H. Kim et al., Optimal interfacial engineering with different length of alkylammonium halide for efficient and stable perovskite solar cells. Adv. Energy Mater. 9, 1902740 (2019). doi: 10.1002/aenm.201902740 

   112. X. Zheng et al., Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. Nat. Energy 5, 131–140 (2020). doi: 10.1038/ s41560-019-0538-4 

91. Y. Liu et al., Ultrahydrophobic 3D/2D fluoroarene bilayerbased water-resistant perovskite solar cells with efficiencies exceeding 22. Sci. Adv. 5, eaaw2543 (2019). doi: 10.1126/ sciadv.aaw2543; pmid: 31187060 

102. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051 (2009). doi: 10.1021/ja809598r; pmid: 19366264 

   113. K. H. Ngai et al., Enhanced electrochemical stability by alkyldiammonium in Dion–Jacobson perovskite toward ultrastable light‐emitting diodes. Adv. Opt. Mater. 9, 2100243 (2020). doi: 10.1002/adom.202100243 

92. E. H. Jung et al., Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). Nature 567, 511–515 (2019). doi: 10.1038/s41586-019-1036-3; pmid: 30918371 

103. M. M. Lee, J. Teuscher, T. Miyasaka, T. N. Murakami, H. J. Snaith, Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science 338, 643–647 (2012). doi: 10.1126/science.1228604; pmid: 23042296 

   114. M. Saliba et al., Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 206–209 (2016). doi: 10.1126/science.aah5557; 

93. J. Xue et al., Crystalline liquid-like behavior: Surface-induced secondary grain growth of photovoltaic perovskite thin film. J. Am. Chem. Soc. 141, 13948–13953 (2019). doi: 10.1021/ jacs.9b06940; pmid: 31403287 

   - pmid: 27708053 

104. J. H. Heo et al., Efficient inorganic–organic hybrid heterojunction solar cells containing perovskite compound and polymeric hole conductors. Nat. Photonics 7, 486–491 (2013). doi: 10.1038/nphoton.2013.80 

   115. M. Jeong et al., Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. Science 369, 1615–1620 (2020). doi: 10.1126/science.abb7167; pmid: 32973026 

94. M. Yang et al., Facile fabrication of large-grain CH3NH3PbI3–xBrx films for high-efficiency solar cells via CH3NH3Br-selective Ostwald ripening. Nat. Commun. 7, 12305 (2016). doi: 10.1038/ ncomms12305; pmid: 27477212 

   105. J. Burschka et al., Sequential deposition as a route to highperformance perovskite-sensitized solar cells. Nature 499, 316–319 (2013). doi: 10.1038/nature12340; pmid: 23842493 

95. S. Yang et al., Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. Science 365, 473–478 (2019). doi: 10.1126/science.aax3294; pmid: 31371610 

###### ACKNOWLEDGMENTS 

106. W. S. Yang et al., High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science 348, 1234–1237 (2015). doi: 10.1126/science.aaa9272; pmid: 25999372 

Funding: This work was supported by a Korea Institute of Energy Technology Evaluation and Planning (KETEP) grant funded by the Korean government (MOTIE) under award numbers 20213030010400 and 20214000000640 (J.-W.L.); by National Research Foundation of Korea grants NRF-2018R1A3B1052820 (S.I.S.) and NRF-2021R1A3B1076723 (N.-G.P.); and by the US Department of Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under the Solar Energy Technologies Office under award number DE-EE0008751 (S.T. and Y.Y.) Competing interests: The authors declare that they have no competing interests. 

96. J. Xue et al., Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. Science 371, 636–640 (2021). doi: 10.1126/science.abd4860; pmid: 33542138 

   107. W. S. Yang et al., Iodide management in formamidinium-leadhalide-based perovskite layers for efficient solar cells. Science 356, 1376–1379 (2017). doi: 10.1126/science. aan2301; pmid: 28663498 

97. Y. W. Jang et al., Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. Nat. Energy 6, 63–71 (2021). doi: 10.1038/s41560-020-00749-7 

   108. N. J. Jeon et al., A fluorene-terminated hole-transporting material for highly efficient and stable perovskite solar cells. Nat. Energy 3, 682–689 (2018). doi: 10.1038/ s41560-018-0200-6 

98. K. T. Cho et al., Selective growth of layered perovskites for stable and efficient photovoltaics. Energy Environ. Sci. 11, 952–959 (2018). doi: 10.1039/C7EE03513F 

10.1126/science.abj1186 

10 of 10 

Lee et al., Science 375, eabj1186 (2022) 25 February 2022 



#### **Rethinking the A cation in halide perovskites** 

Jin-Wook Lee, Shaun Tan, Sang Il Seok, Yang Yang, and Nam-Gyu Park 

_Science_ **375** (6583), eabj1186.  DOI: 10.1126/science.abj1186 

##### **Optimizing perovskite A sites** 

In the organic-inorganic lead halide perovskites (OLHPs) used in optoelectronics, the monovalent A site was thought initially to have little effect on band edge states compared with the divalent lead or tin cations and halide anions. However, the recent improvement performance breakthroughs for OLHP solar cells have largely come from modifications of A site cations. Lee _et al_ . reviewed their expanded roles and versatility in three-dimensional OLHPs, especially for structural stabilization, mitigation of ion migration, and surface functionalization for interface modification and trap passivation. —PDS 

**View the article online** https://www.science.org/doi/10.1126/science.abj1186 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2022 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

