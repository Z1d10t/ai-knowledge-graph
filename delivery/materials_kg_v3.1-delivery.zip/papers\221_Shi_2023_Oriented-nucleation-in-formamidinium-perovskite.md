# Oriented nucleation in formamidinium perovskite for photovoltaics

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 339 |
| 作者 | Peng Shi, Yong Ding, Bin Ding, Qiyu Xing, T. Kodalle, C. Sutter-Fella, I. Yavuz, Canglang Yao et al. |
| DOI | 10.1038/s41586-023-06208-z |
| 源文件 | 021_Shi_2023_Oriented-nucleation-in-formamidinium-perovskite.pdf |

---
Article 

# **Oriented nucleation in formamidinium perovskite for photovoltaics** 

|https://doi.org/10.1038/s41586-023-06208-z<br>Received: 9 February 2023<br>Accepted: 12 May 2023|**Pengju Shi**<sup>**1,2,13**</sup>**, Yong Ding**<sup>**3,4,13**</sup>**, Bin Ding**<sup>**3,13**</sup>**, Qiyu Xing**<sup>**5,13**</sup>**, Tim Kodalle**<sup>**6**</sup>**, Carolin M. Sutter-Fella**<sup>**6**</sup>**,**<br>**Ilhan Yavuz**<sup>**7**</sup>**, Canglang Yao**<sup>**8**</sup>**, Wei Fan**<sup>**1,2**</sup>**, Jiazhe Xu**<sup>**2**</sup>**, Yuan Tian**<sup>**1,2**</sup>**, Danyu Gu**<sup>**9**</sup>**, Ke Zhao**<sup>**1,2**</sup>**,**<br>**Shaun Tan**<sup>**5**</sup>**, Xu Zhang**<sup>**2**</sup>**, Libing Yao**<sup>**2**</sup>**, Paul J. Dyson**<sup>**3**</sup>**, Jonathan L. Slack**<sup>**10**</sup>**, Deren Yang**<sup>**1**</sup>**,**<br>**Jingjing Xue**<sup>**1** ✉</sup>**, Mohammad Khaja Nazeeruddin**<sup>**3** ✉</sup>**, Yang Yang**<sup>**5** ✉</sup>**& Rui Wang**<sup>**2,11,12** ✉</sup>|
|---|---|
|Published online: 21 June 2023||
|Check for updates|The black phase of formamidinium lead iodide (FAPbI3) perovskite shows huge<br>promise as an efficient photovoltaic, but it is not favoured energetically at room<br>temperature, meaning that the undesirable yellow phases are always present<br>alongside it during crystallization<sup>1–4</sup>. This problem has made it difficult to formulate<br>the fast crystallization process of perovskite and develop guidelines governing the<br>formation of black-phase FAPbI3(refs. 5,6). Here we use in situ monitoring of the<br>perovskite crystallization process to report an oriented nucleation mechanism that<br>can help to avoid the presence of undesirable phases and improve the performance of<br>photovoltaic devices in different film-processing scenarios. The resulting device has a<br>demonstrated power-conversion efficiency of 25.4% (certified 25.0%) and the module,<br>which has an area of 27.83 cm<sup>2</sup>, has achieved an impressive certified aperture<br>efficiency of 21.4%.|



FAPbI3 has an impressive bandgap and thermal resistance, and has therefore emerged as the most promising candidate perovskite for use as a photovoltaic device<sup>1–3,7,8</sup> . However, the photoactive black phase of FAPbI3 is not energetically favoured at room temperature<sup>4,9,10</sup> . Polytype formation and the presence of other intermediate non-photoactive phases can readily occur, which undermines its photovoltaic performance. Several approaches have been developed to promote the formation of black-phase FAPbI3 at room temperature, such as adduct formation with PbI2 and solvent engineering using ionic liquids<sup>11,12</sup> . Unfortunately, the fast crystallization kinetics of FAPbI3 perovskites precludes in-depth investigations of its film-formation processes<sup>5,6</sup> . The microscale mechanism of its phase evolution during crystallization has yet to be unambiguously defined<sup>13,14</sup> . This lack of information has hampered the development of more-rational and targeted design of film-processing methods for efficient FAPbI3 perovskite absorbers, especially for different film-processing scenarios, such as one-step and two-step film-deposition protocols and small- and large-area devices<sup>15–18</sup> . A strategy to promote the formation of black-phase FAPbI3 in one processing scenario usually fails when applied to other situations. In this study we observed an oriented nucleation mechanism that originated from the reduced surface energy of a specific crystallographic plane, and this enabled us to avoid the yellow phase of FAPbI3 and governed the formation of black-phase FAPbI3. We verified the mechanism for different film-deposition methods and found it could be applied to improve the performance of both small-area devices and solar modules. 

In a two-step deposition protocol for perovskite films, in which the PbI2 and organo-halide precursors were deposited sequentially, intermediate non-photoactive phases were always observed at room temperature. The X-ray diffraction (XRD) patterns of the deposited perovskite film at room temperature showed diffraction peaks corresponding to the (100) planes of the black phase, accompanied by diffraction peaks of the the hexagonal perovskite polytype 2H and 6H intermediate phases (Fig. 1a). When pentanamidine hydrochloride (PAD) was incorporated in the precursor of the organic cations, the intermediate phases were eliminated. Density-functional theory calculations and Fourier transform infrared (FTIR) spectroscopy were used to investigate how PAD interacts with the Pb–I framework. As modelled in Fig. 1b, the positively charged amidinium head of PAD was able to anchor into the octahedral cavity of the black-phase perovskite by means of electrostatic and hydrogen-bonding interactions. Peak shifts of the C=N and N–H vibration could be seen in the FTIR spectra of PAD after mixing with PbI2, confirming the strong interaction between PAD and the Pb–I framework through the amidinium unit (Extended Data Fig. 1). This interaction exposed the hydrophobic alkyl chain of PAD such that it was stacked in an ordered manner on the black-phase perovskite (100) plane. As a result, compared with the other planes, the surface energy of the perovskite (100) plane was decreased the most (it fell by 64% from 3.16 to 1.14 eV) when the plane was terminated by PAD (see Supplementary Note 1 for details of the calculation and the variations in surface energy of different crystallographic planes). The 

> 1State Key Laboratory of Silicon Materials and Advanced Semiconductor Materials, School of Materials Science and Engineering, Zhejiang University, Hangzhou, China. 2School of Engineering and Westlake Institute for Advanced Study, Westlake University, Hangzhou, China.<sup>3</sup> Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne, EPFL VALAIS, Sion, Switzerland.<sup>4</sup> Beijing Key Laboratory of Novel Thin-Film Solar Cells, North China Electric Power University, Beijing, China.<sup>5</sup> Department of Materials Science and Engineering and California NanoSystems Institute, University of California Los Angeles, Los Angeles, CA, USA.<sup>6</sup> Molecular Foundry, Lawrence Berkeley National Laboratory, Berkeley, CA, USA.<sup>7</sup> Department of Physics, Marmara University, Istanbul, Turkey.<sup>8</sup> Laboratory of Advanced Materials, Department of Chemistry, Fudan University, Shanghai, China.<sup>9</sup> Instrumentation and Service Center for Molecular Sciences, Westlake University, Hangzhou, China.<sup>10</sup> Advanced Light Source, Lawrence Berkeley National Laboratory, Berkeley, CA, USA.<sup>11</sup> Research Center for Industries of the Future, Westlake University, Hangzhou, China.<sup>12</sup> Division of Solar Energy Conversion and Catalysis at Westlake University, Zhejiang Baima Lake Laboratory Co., Ltd, Hangzhou, China.<sup>13</sup> These authors contributed equally: Pengju Shi, Yong Ding, Bin Ding, Qiyu Xing.<sup>✉</sup> e-mail: jjxue@zju.edu.cn; mdkhaja.nazeeruddin@epfl.ch; yangy@ucla.edu; wangrui@westlake.edu.cn 

Nature | Vol 620 | 10 August 2023 | **323** 

Article 



<!-- Start of picture text -->
a Control Control Control b C I H PAD NH2+<br>N Pb H2N<br>2H 6H<br>PAD PAD PAD<br>8 10 12 14 16 11.5 12.0 12.0 12.5 13.0<br>2 �  (degrees) 2 �  (degrees) 2 �  (degrees)<br>c<br>N E a,PAD Mixed phases (100) plane:<br>C E a,control and orientations  reduced surface energy<br>I – AI+PbI2<br>Black<br>phase<br>(100)<br>Oriented nucleation FA + PAD Pb–I framework<br>Normalized intensity (a.u.) Normalized intensity (a.u.) Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Direct formation of black-phase FAPbI3 at room temperature and the driving force. a** , XRD patterns of perovskite films after spin-coating the precursors at room temperature, where 2 _θ_ is the change in angle. **b** , Theoretical models of the perovskite (100) plane without PAD (left) and with PAD (right). 

**c** , Schematic illustration of the thermodynamic driving force and the kinetics of the oriented nucleation of perovskite films. _E_ , change in energy; a.u., arbitrary units. 

configuration of this interaction was corroborated by the formation of a two-dimensional perovskite phase, characterized by XRD of the perovskite film fabricated with PAD (Supplementary Fig. 1). The reduced dimension of the perovskite phase evidenced the extremely low surface energy of the (100) plane. This thermodynamic driving force led to the preferential formation of the (100) orientation of black-phase perovskite, which determined the crystallization texture and promoted the formation of black-phase perovskite crystals. By contrast, the relatively even energy profile of the phase transformation process without PAD resulted in the coexistence of several phases and orientations (Fig. 1c). 

We used synchrotron-based multimodal in situ probes to analyse the crystallization of perovskites from the precursors and to verify the oriented nucleation mechanism. The details of the measurements and film-processing procedures are shown in Supplementary Note 2. In situ grazing-incidence X-ray diffraction (GIXRD) measurements revealed that the perovskite nucleated when the formamidinium iodide solution was dropped onto pre-deposited PbI2; this could be seen by the emergence of the perovskite (100) diffraction peak (Fig. 2a). During the spin-coating process, the peak intensity of the (100) plane gradually increased, which we describe as a nucleation stage in which the disappearance, formation and growth of the nuclei take place concurrently. The subsequent annealing step led to a rapid rise in the intensity of the (100) peak, indicating a fast crystal growth process. During the nucleation stage, the control perovskite film showed diffraction peaks corresponding to multiple intermediate phases, whereas the film using PAD featured a clean (100) diffraction pattern of black-phase perovskite. This finding indicates that incorporating PAD suppressed the formation of yellow phases from the start of the nucleation process. Notably, the control film had a faster increase in the (100) peak intensity during the nucleation stage than that with PAD, indicating that PAD led to delayed nucleation kinetics. This slower nucleation may be attributed to the strong interaction of PAD with the Pb–I framework, because the formamidinium had to compete with PAD to interact with the Pb–I, 

slowing down the reaction. The in situ azimuth angle mapping was extracted from the GIXRD patterns of the perovskite (100) plane during the nucleation stage (Fig. 2b). The azimuth angle showed a broad distribution ranging approximately from 60° to 120°, indicating that the control sample had a fairly random crystallographic orientation. However, a sharp peak centred at the azimuth angle of 90° was observed when PAD was incorporated, and the half-peak width remained as small as around 8°. These findings verified that there is a nucleation stage with a preferred out-of-plane orientation along the (100) facet, which we described as an oriented nucleation mechanism. 

We studied the proposed mechanism further by varying the length of the alkyl chain attached to the organic amidinium cation, thereby modulating the effect on the surface energy. Butylamidine hydrochloride (BAD) and propionamidine hydrochloride (PRD), which have shorter alkyl chains than PAD, were investigated. Calculations based on density-functional theory revealed an increase in the surface energy of the perovskite (100) plane as the alkyl chain became shorter (Extended Data Fig. 2). The (100) plane that terminated with PRD, BAD or PAD, which featured an increasingly elongated and exposed organic tail and thus increased hydrophobicity, had a calculated surface energy of 1.57, 1.20 and 1.14 eV nm<sup>−2</sup> , respectively. In situ GIXRD measurements revealed that both BAD and PRD suppressed the formation of intermediate photo-inactive phases during the nucleation stage (Extended Data Fig. 3). However, the in situ azimuth angle mapped during the nucleation stage demonstrated different levels of oriented nucleation as the surface energy varied (Extended Data Fig. 4). Because adding PAD provided the lowest surface energy of the perovskite (100) plane, it induced the most-oriented nucleation of the three additives. Despite the ability of BAD and PRD to induce more-oriented nucleation than the control sample, they resulted in broader azimuth-angle distributions than did PAD. These observations demonstrated that the oriented nucleation and the promoted formation of black-phase perovskite were governed by the surface energy of perovskite (100) plane. 

**324** | Nature | Vol 620 | 10 August 2023 



<!-- Start of picture text -->
a 50 Control G 8 50 b 135 Control 1 c 850 Control 3.8 × 10 4<br>120<br>40 40 800<br>105<br>30 30<br>90 750<br>Ns<br>20 20 75<br>700<br>10 10 60<br>N0<br>0 5 10 15 20 25 30 110 8 6 4 2 0 45 25 30 35 40 0 650 5 10 15 20 0<br>2 �  (degrees) Intensity (a.u.) 20 Time (s) Time (s)<br>50 PAD G 8 50 135 PAD 1 850 PAD 3.2 × 10 4<br>120<br>40 40 800<br>105<br>30 30<br>Ns 90 750<br>20 20<br>75<br>700<br>10 10 60<br>N0<br>0 1 0 45 0 650 0<br>5 10 15 20 25 30 5 4 3 2 1 20 25 30 35 40 5 10 15 20<br>2 �  (degrees) Intensity (a.u.) Time (s) Time (s)<br>Time (s) Time (s)<br>Wavelength (nm) Photoluminescence intensity (a.u.)<br>Azimuth angle (degrees) Normalized intensity (a.u.)<br>Time (s) Time (s) Wavelength (nm) Photoluminescence intensity (a.u.)<br>Azimuth angle (degrees) Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | In situ multimodal monitoring of the crystallization process for perovskite films fabricated by the two-step method. a** , In situ GIXRD measurements of perovskite films fabricated without PAD (top) and with PAD (bottom), where N0 denotes the start of the nucleation, Ns denotes the nucleation stage and G denotes the growth stage. The black–red colour scale is 

the intensity in arbitrary units. **b** , The evolution of the azimuth angle during the nucleation stage of perovskite films without PAD (top) and with PAD (bottom). **c** , The evolution of the photoluminescence spectra during the nucleation stage of perovskite films without PAD (top) and with PAD (bottom). 

In situ photoluminescence measurements provided further evidence of the sluggish nucleation kinetics. The evolution of the photoluminescence spectra of the perovskite films during the nucleation stage is shown in Fig. 2c. Without PAD, a photoluminescence peak at 770 nm rose rapidly, which we attribute to the photoactive perovskite phase. With PAD in the precursor solution, the photoluminescence peak appeared at 760 nm with delayed kinetics. The slight blue-shift in the photoluminescence peak could be attributed to the smaller size of the nuclei, which could either lead to compressive lattice strain or induce stronger quantum confinement (Extended Data Fig. 5). This in turn provided evidence of the slower nucleation kinetics in perovskite films with PAD. Sluggish nucleation kinetics were also observed for BAD and PRD (Extended Data Fig. 6), but to a lesser extent than for PAD, further confirming the important role of surface energy in regulating the crystallization. The strong interaction between the inorganic framework of the perovskite and the PAD cation lowered the surface energy of the (100) plane, leading to slower nucleation kinetics with preferred crystallographic orientation. This oriented nucleation mechanism governed the subsequent crystal growth step, which also followed the preferred orientation along the (100) facet<sup>19</sup> (Supplementary Fig. 2). The resulting perovskite film exhibited higher crystallinity and conductivity, as indicated by the increased intensity of the XRD patterns and by conductive atomic-force-microscopy measurements, respectively (Supplementary Figs. 3 and 4). The film also had larger grain sizes as a result of the slower nucleation (Supplementary Fig. 5). The enhanced photoluminescence intensity and prolonged photoluminescence lifetime of the PAD-based perovskite film indicated that there were fewer non-radiative recombination sites (Extended Data Fig. 7). 

We investigated the incorporation of PAD in a one-step deposition protocol and observed the elimination of the yellow phase. As revealed by the in situ XRD measurements, a mixture of intermediate phases appeared with the black-phase perovskite during crystallization in the absence of PAD (Fig. 3a). By contrast, incorporating PAD eliminated all the intermediate phases, leading to a single diffraction feature apparent 

from the (100) plane of black-phase perovskite (Fig. 3b). In situ photoluminescence measurements of the perovskite films with and without PAD were performed (Supplementary Note 3). The evolution profiles of the photoluminescence peak positions and photoluminescence intensity with time are shown in Fig. 3c,d, respectively. In the control sample, we observed a turning point (highlighted by the red dashed area in Fig. 3c,d) in the evolution profile of the photoluminescence peak position, which coincides with fluctuations in photoluminescence intensity. In general, changes in the photoluminescence peak position may be related to lattice or structural changes. Therefore this turning point might indicate the emergence of intermediate phases during the crystallization, in addition to the black phase. The perovskite film with PAD instead exhibited a smooth photoluminescence evolution profile for both peak position and peak intensity, further verifying the direct conversion to the black phase. The perovskite film with PAD exhibited considerably enhanced photoluminescence intensity and photoluminescence lifetime (Fig. 3e,f), indicative of pure black-phase perovskite with reduced non-radiative recombination sites in the film. 

We subsequently evaluated the photovoltaic performance of the fabricated solar-cell devices. For the two-step deposition protocol (Extended Data Fig. 8), the device made with PAD had the best power conversion efficiency (PCE), achieving 24.0%, whereas the best control device had a PCE of only 22.9%, primarily because the PAD version had an increased fill factor and open circuit voltage (Fig. 4a). This was attributed to the reduced non-radiative recombination in the device with PAD, as demonstrated by the slower transient photovoltage decay (Supplementary Fig. 6). The short-circuit currents of the device were marginally enhanced, reflecting the slightly faster transient photocurrent decay of the device with PAD<sup>20,21</sup> (Supplementary Fig. 7). A similar trend in device performance was observed for the one-step method (Fig. 4b and Extended Data Fig. 9). The device with PAD demonstrated an improved PCE of up to 25.4% (certified at 25.0%). The histogram of PCEs for 36 devices is shown in Fig. 4c (the detailed parameters are shown in Supplementary Table 1), which confirms that the performance 

Nature | Vol 620 | 10 August 2023 | **325** 

## Article 



<!-- Start of picture text -->
a c e<br>300 8 × 10 3 1.60 4<br>Control Control Control<br>PAD PAD<br>120 3<br>1.59<br>Intermediate phase<br>60 2<br>1.58<br>30 1<br>0 0 1.57 0<br>6 8 10 12 14 16 18 20 0 5 10 15 20 700 750 800 850 900<br>b 2 �  (degrees) d Time (s) f Wavelength (nm)<br>300 8 × 10 3 4<br>PAd Control 1.0<br>PAD<br>120 3<br>60 2<br>30 1 Control<br>0.1 PAD<br>Fitting<br>0 0 0<br>6 8 10 12 14 16 18 20 0 5 10 15 20 0 1 2 3 4 5<br>2 �  (degrees) Time (s) Time (μs)<br>Fig. 3 | The crystallization process and optical properties of perovskite  perovskite films during the annealing process with and without PAD. The<br>films fabricated by the one-step method. a , b , In situ XRD measurements of  red dashed area highlights a turning point in the evolution profile of the<br>perovskite films fabricated without PAD ( a ) and with PAD ( b ). The control  photoluminescence peak position.  e , f , Comparison of the steady-state<br>sample has a mixture of intermediate phases but the sample with PAD during  photoluminescence spectra ( e ) and the time-resolved photoluminescence<br>the annealing process does not.  c , d , Evolution of the photoluminescence peak  ( f ) of perovskite films with and without PAD, demonstrating an increased<br>position ( c ) and evolution of the photoluminescence intensity ( d ) of the  photoluminescence lifetime from 0.19 μs to 4 μs in the film with PAD.<br>a b c<br>28 Two step 28 One step 15 Control<br>PAD<br>24 24<br>12<br>20 20<br>16 16 9<br>12 12<br>6<br>8 Control, forward 8 Control, forward<br>Control, reverse Control, reverse<br>4 PAD, forward 4 PAD, forward 3<br>PAD, reverse PAD, reverse<br>0 0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 0 0.2 0.4 0.6 0.8 1.0 1.2 23 24 25 26<br>Voltage (V) Voltage (V) PCE (%)<br>d e<br>90 700 25<br>75 600<br>20<br>500<br>60<br>400 15<br>45<br>300<br>10<br>30<br>200<br>15 100 5 Control<br>PAD<br>0 0 0<br>0 2 4 6 8 10 0 200 400 600 800 1,000<br>Voltage (V) Time (h)<br>Time (s)<br>Intensity (a.u.)<br>Peak position (eV) 5Intensity (× 10) (a.u.)<br>Time (s)<br>Intensity (a.u.)<br>3Peak intensity (× 10) (a.u.) Normalized intensity (a.u.)<br>Counts<br>–2Current density (mA cm)<br>–2Current density (mA cm)<br>Current (mA)  PCE (%)<br>Power (mW)<br><!-- End of picture text -->

**Fig. 3 | The crystallization process and optical properties of perovskite films fabricated by the one-step method. a** , **b** , In situ XRD measurements of perovskite films fabricated without PAD ( **a** ) and with PAD ( **b** ). The control sample has a mixture of intermediate phases but the sample with PAD during the annealing process does not. **c** , **d** , Evolution of the photoluminescence peak position ( **c** ) and evolution of the photoluminescence intensity ( **d** ) of the 

perovskite modules with an aperture area of 27.83 cm<sup>2</sup> fabricated with PAD. The certified PCE is 21.4%. Inset, a photograph of the module. **e** , MPP tracking of perovskite devices fabricated with and without PAD under ambient conditions (continuous illumination and a temperature of 30 ± 3 °C). 

**Fig. 4 | Performance of the photovoltaic devices. a** , **b** , Current density–voltage curves of the perovskite photovoltaic devices fabricated using two-step ( **a** ) and one-step ( **b** ) deposition methods with and without PAD. **c** , PCE distribution of perovskite solar cells with and without PAD. **d** , Certified device performance of 

**326** | Nature | Vol 620 | 10 August 2023 

improvements of devices made with PAD were highly reproducible (a 5.6% improvement in average PCE from 23.7 ± 0.4% to 25.0 ± 0.4% when PAD was incorporated). We further extended the application of PAD to the fabrication of solar modules to verify its compatibility with upscaled devices. A high aperture efficiency of 21.4% (certified) was achieved for the PAD-based perovskite module with an area of 27.83 cm<sup>2</sup> (Fig. 4d). The module showed an average PCE of 20.4%, whereas the control module had an average PCE of only 18.9%, further demonstrating the universality of the approach (Extended Data Fig. 10). Our fabricated devices also demonstrated considerably improved operational stability. When tracked at the maximum power point (MPP) with constant illumination at 30 ± 3 °C, the PCE of the control device fell by 30%, whereas the device fabricated with PAD maintained 95% of its initial PCE after more than 1,000 h (Fig. 4e). In an accelerated-ageing test at 65 ± 3 °C and 85 ± 5% relative humidity, the device with PAD kept more than 82% of its initial PCE after more than 500 h when held at the MPP under constant illumination, whereas the PCE of the control device decreased by around 37% (Supplementary Fig. 8). This increased stability could be attributed to the higher crystallinity, reduced defect density and reduced surface energy caused by PAD<sup>8,22,23</sup> (Supplementary Fig. 9). 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-023-06208-z. 

1. Doherty, T. A. S. et al. Stabilized tilted-octahedra halide perovskites inhibit local formation of performance-limiting phases. _Science_ **374** , 1598–1605 (2021). 

2. Lee, J.-W., Seol, D.-J., Cho, A.-N. & Park, N.-G. High-efficiency perovskite solar cells based on the black polymorph of HC(NH2)2PbI3. _Adv. Mater._ **26** , 4991–4998 (2014). 

3. Turren-Cruz, S.-H., Hagfeldt, A. & Saliba, M. Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

4. Xue, J. et al. Surface ligand management for stable FAPbI3 perovskite quantum dot solar cells. _Joule_ **2** , 1866–1878 (2018). 

5. Yang, M. et al. Facile fabrication of large-grain CH3NH3PbI3- _x_ Br _x_ films for high-efficiency solar cells via CH3NH3Br-selective Ostwald ripening. _Nat. Commun._ **7** , 12305 (2016). 

6. Sánchez, S., Pfeifer, L., Vlachopoulos, N. & Hagfeldt, A. Rapid hybrid perovskite film crystallization from solution. _Chem. Soc. Rev._ **50** , 7108–7131 (2021). 

7. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. _Energy Environ. Sci._ **7** , 982–988 (2014). 

8. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. _Nat. Photon._ **13** , 460–466 (2019). 

9. Qiu, Z. et al. Recent advances in improving phase stability of perovskite solar cells. _Small Methods_ **4** , 1900877 (2020). 

10. Zhang, Y. et al. Propylammonium chloride additive for efficient and stable FAPbI3 perovskite solar cells. _Adv. Energy Mater._ **11** , 2102538 (2021). 

11. Bu, T. et al. Lead halide-templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ **372** , 1327–1332 (2021). 

12. Hui, W. et al. Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. _Science_ **371** , 1359–1364 (2021). 

13. Nan, Z.-A. et al. Revealing phase evolution mechanism for stabilizing formamidiniumbased lead halide perovskites by a key intermediate phase. _Chem_ **7** , 2513–2526 (2021). 

14. Qin, M., Chan, P. F. & Lu, X. A systematic review of metal halide perovskite crystallization and film formation mechanism unveiled by in situ GIWAXS. _Adv. Mater._ **33** , 2105290 (2021). 

15. Li, Z. et al. Scalable fabrication of perovskite solar cells. _Nat. Rev. Mater._ **3** , 18017 (2018). 16. Xie, Y.-M., Xue, Q. & Yip, H.-L. Metal-halide perovskite crystallization kinetics: a review of experimental and theoretical studies. _Adv. Energy Mater._ **11** , 2100784 (2021). 

17. Lee, J.-W., Lee, D.-K., Jeong, D.-N. & Park, N.-G. Control of crystal growth toward scalable fabrication of perovskite solar cells. _Adv. Funct. Mater._ **29** , 1807047 (2019). 

18. Dubey, A. et al. A strategic review on processing routes towards highly efficient perovskite solar cells. _J. Mater. Chem. A_ **6** , 2406–2431 (2018). 

19. Engler, O., Vatne, H. E. & Nes, E. The roles of oriented nucleation and oriented growth on recrystallization textures in commercial purity aluminium. _Mater. Sci. Eng. A_ **205** , 187–198 (1996). 

20. Tan, H. et al. Efficient and stable solution-processed planar perovskite solar cells via contact passivation. _Science_ **355** , 722–726 (2017). 

21. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. _Nat. Energy_ **4** , 864–873 (2019). 

22. Lee, J.-W. et al. Solid-phase hetero epitaxial growth of α-phase formamidinium perovskite. _Nat. Commun._ **11** , 5514 (2020). 

23. Wang, F. et al. Phenylalkylamine passivation of organolead halide perovskites enabling high-efficiency and air-stable photovoltaic cells. _Adv. Mater._ **28** , 9986–9992 (2016). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

Nature | Vol 620 | 10 August 2023 | **327** 

Article **Methods** 

#### **Materials** 

Solvents and chemicals used in the two-step method were obtained commercially and used without further purification. _N_ , _N_ -dimethylformamide (DMF; anhydrous, 99.8%), dimethyl sulfoxide (DMSO; anhydrous, at least 99.9%), chlorobenzene (anhydrous, 99.8%), isopropanol (anhydrous, 99.5%), 2-methoxyethanol (anhydrous, 99.8%), water (ACS grade), 4- _tert_ -butylpyridine (99%), bis(trifluoromethane)sulfonimide lithium salt (Li–TFSI; 99.95% trace metal basis), PbI2 (99.999%, perovskite grade), caesium iodide (CsI; 99.999%), silver and gold were obtained from Sigma-Aldrich. Methylammonium chloride (MACl; 99%) and formamidinium iodide (FAI) were obtained from Greatcell Solar. FK209 and Spiro-OMeTAD (99.8%) were obtained from Xi’an Polymer Light Technology. Pentanamidine hydrochloride, butylamidine hydrochloride and propionamidine hydrochloride were obtained from BLDpharm. Tin oxide (SnO2) nanoparticles (15 wt% in water) were obtained from Alfa-Aesar. The materials used in the experiments of the one-step method included: lead(II) iodide (PbI2; 99.99%, TCI), tin(II) chloride dihydrate (SnCl2·2H2O; 98%, Acros), tin(IV) chloride (99%, Sigma-Aldrich), hydrochloric acid (HCl; 37 wt% in water, Sigma-Aldrich), MACl (99.99%, Greatcell Solar), FAI (99.99%, Greatcell Solar), DMF (99.8%, Sigma-Aldrich), DMSO (99.9%, Sigma-Aldrich), 2-propanol (99.5%, Sigma-Aldrich), chlorobenzene (99.8%, Sigma-Aldrich), Spiro-OMeTAD (Borun), Li–TFSI (99.95%, Sigma-Aldrich), FK209 Co(III) TFSI salt (Sigma-Aldrich) and acetonitrile (ACN; 99.8%, Sigma-Aldrich). 

#### **Device fabrication** 

**Fabrication of perovskite solar cells by the two-step method.** In the two-step method, perovskite solar cells were fabricated with the following structure: indium tin oxide (ITO)/SnO2/FA0.95Cs0.05PbI3/ Spiro-OMeTAD/Ag (or Au). The ITO glass was precleaned in an ultrasonic bath of acetone and isopropanol and was ultraviolet light–ozone treated for 20 min before use. A thin layer (around 30 nm) of SnO2 was spin-coated onto the ITO glass and baked at 165 °C for 35 min. SnO2 solution was diluted in water ( _V_ SnO2: _V_ H2O at a ratio of 1:4) before spin-coating. After cooling to room temperature, the glass, ITO and SnO2 substrates were transferred to a nitrogen glove box. The PbI2 solution was prepared by dissolving 1.4 M PbI2 and 0.07 M CsI into 1 ml DMF or DMSO (v/v 94/6). The FAI solution for the control film was prepared by dissolving 80 mg FAI and 13 mg MACl in 1 ml isopropanol. For the preparation of precursors with PAD, BAD or PRD, 2.05 mg PAD, 1.84 mg BAD or 1.63 mg PRD was added to the FAI solution in isopropanol. The solution was stirred overnight before use. To fabricate the perovskite layer, the PbI2 solution was spin-coated on the substrate at 1,500 rpm for 40 s, and the FAI–PAD, FAI–BAD or FAI–PRD solution was then spin-coated on the PbI2 film at 1,800 rpm for 40 s, followed by pre-annealing in the glove box at 90 °C for 1 min and annealing outside the glove box at 150 °C for 10 min with 30–40% humidity. The first-step and second-step precursors are denoted as the PbI2 solution and the FAI solution, respectively, for simplicity, with the exact compositions described above). The Spiro-OMeTAD solution (60 mg Spiro-OMeTAD in 700 μl chlorobenzene with 25.5 μl 4- _tert_ -butylpyridine, 15.5 μl Li– TFSI (520 mg ml<sup>−1</sup> in ACN) and 12.5 μl FK209 (375 mg ml<sup>−1</sup> in ACN)) was spun onto the perovskite film as a hole conductor. The devices were completed by evaporating 100 nm of either gold or silver in a vacuum chamber (base pressure, 5 × 10<sup>−4</sup> Pa), and the aperture area of the device is 0.1 cm<sup>2</sup> , designated by the shadow mask. 

**Fabrication of perovskite solar cells by the one-step method.** The device with an architecture of fluorine-doped tin oxide (FTO) glass/compact TiO2 layer (c-TiO2)/compact SnO2 layer, (c-SnO2)/ Cs0.05MA0.05FA0.9PbI3 (PVK)/spiro-OMeTAD (HTM)/Au structure was fabricated. The patterned FTO substrate (Asahi FTO glass, 12–13 Ω cm<sup>−2</sup> ) 

was sequentially cleaned with detergent (5% Hellmanex in water), deionized water, acetone and isopropanol in an ultrasonic bath for 30 min. The FTO substrate was then further cleaned with ultraviolet light–ozone surface treatment for 15 min. The c-TiO2 and SnO2 layers were sequentially deposited on the clean FTO substrate by chemical bath deposition. The substrate was annealed on a hotplate at 190 °C for 60 min. The perovskite precursor solution (1.4 M) was prepared by adding 645.4 mg PbI2, 216.7 mg FAI, 11.1 mg methylammonium iodide and 11.8 mg CsCl into a mixture of 200 μl DMSO and 800 μl DMF. The solution was then stirred for 2 h at 60 °C before 2.09 mg PAD was dissolved into 1.0 ml of DMSO to make a stock solution (concentration around 0.52 M). After ultraviolet light–ozone treatment of the substrates for 15 min, the perovskite precursor solution was spin-coated onto the surface of the FTO/c-TiO2/c-SnO2 substrate at 1,000 rpm for 10 s, accelerated to 5,000 rpm for 5 s and maintained at this speed for 20 s. This process was done in an N2-filled glove box. The substrate was then placed in custom-made rapid vacuum drying equipment. After pumping for 20 s, a brown, transparent perovskite film with a mirror-like surface was obtained. The fresh perovskite layer was annealed at 100 °C for 1 h and then at 150 °C for 10 min. Then 60 μl phenethylammonium iodide (PEAI) solution (5 mg ml<sup>−1</sup> in isopropanol) was spin-coated on the perovskite film at 5,000 rpm for 30 s. A hole transport layer was deposited on the perovskite film by depositing a doped spiro-OMeTAD solution at 3,000 rpm for 30 s. The doped spiro-OMeTAD solution was prepared by dissolving 105 mg of spiro-OMeTAD and 41 μl 4- _tert_ -butylpyridine in 1,343 μl chlorobenzene with an additional 25 μl Li–TFSI solution (517 mg ml<sup>−1</sup> in ACN) and 19 μl cobalt-complex solution (376 mg ml<sup>−1</sup> in ACN). Finally, a gold layer approximately 70 nm thick was evaporated on the spiro-OMeTAD layer as the back electrode, and the aperture area of the certified device is 0.06 cm<sup>2</sup> . 

**Fabrication of perovskite modules.** Perovskite solar modules, with 8 subcells connected in series, were fabricated on FTO glass substrates with a size of 6.5 × 7.0 cm. The series interconnection of the module was realized by P1, P2 and P3 lines, which were patterned using a laser scribing system with a 1,064 nm laser and a power of 20 W (Trotec). The FTO substrate was pre-patterned for P1 (a width of 50 μm) by means of 60% laser power at a speed of 300 mm s<sup>−1</sup> with a frequency of 65 kHz and a pulse width of 120 ns. The subsequent processes for the preparation of c-TiO2 and c-SnO2 substrates are the same as the procedures for the small-area device. The perovskite precursor deposition and fabrication procedures were similar to those of the small-size solar cells, except for the concentration of perovskite precursor. A perovskite precursor (1.2 M) was used to make the perovskite layer by spin-coating and the custom-made gas-induced pump method. The perovskite precursor was spin-coated on the c-TiO2 and c-SnO2 substrates, which are similar to those for the small-size devices. The perovskite films were annealed at 100 °C for 1 h and 150 °C for 10 min. After cooling to room temperature, the Spiro-OMeTAD layer was similar to those of the small-size devices. The P2 lines (a width of 150 μm) were patterned before the gold evaporation process step with an average laser power of 15% at a speed of 1,000 μm s<sup>−1</sup> and a frequency of 65 kHz for a pulse duration of 120 ns. When a gold layer 70 nm thick was deposited, the P3 line (a width of 100 μm) was fabricated under the same scribing conditions as the P2 line. The distance between P1 and P3 was around 400 μm and the geometric fill factor was around 0.93. 

For solar modules prepared by the blade-coating method (Coatmaster 510), perovskite solar modules with 9 subcells connected in series were fabricated on FTO glass substrates with a size of 6.5 × 7.0 cm. The processes for the preparation of c-TiO2 and c-SnO2 substrates and the fabrication of spiro-OMeTAD, as well as the gold electrode, were the same as for the gas-pump method. The perovskite precursor solution (1.2 M) was prepared by dissolving 580.9 mg PbI2, 185.7 mg 

FAI, 9.5 mg methylammonium iodide and 10.8 mg CsCl into 1.0 ml 2-methoxyethanol. The precursor solution was blade-coated onto the c-TiO2 and c-SnO2 substrates with a gap of 260 μm at a movement speed of 21 mm s<sup>−1</sup> in the N2 glovebox. The N2 knife was operated at 30 psi during blade-coating and the as-obtained perovskite films were annealed at 100 °C for 1 h and 150 °C for 10 min. The laser scribing procedures were the same as for the gas-pump method, but the geometric fill factor was 0.91. 

#### **Stability test** 

The photovoltaic devices to be tested for stability were fabricated as described above. They were encapsulated by a glass–glass encapsulation technology combined with an edge seal (curing sealant 3035B, ThreeBond) to seal the device under ultraviolet light (LED flood lamp, DELOLUX 20). The edge of the device was first cleared by laser. Indium was soldered on the FTO and gold electrodes on the edge of the 15 mm × 25 mm substrate. A glass coverslip with a size of 13 mm × 23 mm was placed on top of the gold layer of the device. Sealant was placed on the edges of the coverslip to seal the gap between the coverslip and device. Finally, ultraviolet light was used to induce cross-linking between the sealant and the coverslip at 25% of maximum power for 120 s in the glove box. For the stability test at ambient conditions (30 ± 3 °C), unencapsulated devices were evaluated. For the accelerated-degradation test, the encapsulated devices were kept in a thermo-hygrostat (GP/TH-150, SH Guangpin), which was set to 85 ± 5% relative humidity at 65 ± 3 °C. The performance of the devices was measured electronically using a 22-bit delta-sigma analogue-to-digital converter. A reference Si photodiode was placed in close to the devices to record the light intensity. Long-term stability tests were done at the MPP using a tracking algorithm for an illumination of 1 sun (standard illumination at 1 kW m<sup>−2</sup> ) according to the ISOS-L-3 protocol. 

#### **Device characterization** 

Current density–voltage characteristics of photovoltaic cells were determined using a Keithley 2400 source measurement unit under a simulated AM1.5G spectrum with an Oriel 9600 solar simulator. Typically, small devices were measured in a reverse scan (1.20 V to 0 V with steps of 0.01 V for one-step devices and 1.25 V to 0 V with steps of 0.02 V for two-step devices). The modules were measured in a reverse scan (from 9.45 V to 0 V) at a constant scan speed of 100 mV s<sup>−1</sup> with a step of 50 mV. For the measurement of high-efficiency devices, an antireflection film was applied to the surface of devices. All devices were measured without pre-conditioning such as light-soaking or a bias voltage. The steady-state power-conversion efficiency was calculated by measuring the stabilized photocurrent density under a constant bias voltage. External quantum efficiencies were measured using an integrated system (Enlitech) and a lock-in amplifier with a current preamplifier under the short-circuit condition. 

#### **Material characterization and spectroscopic investigation** 

Ultraviolet-light and visual-light absorption spectra of the perovskite films were obtained using a Shimadzu UV-VIS-NIR (UV3600Plus + UV2700) spectrometer equipped with an integrating sphere, in which monochromatic light was incident to the substrate side. To measure time-resolved photoluminescence, the sample was excited using a picosecond-pulse diode laser (Pico-quant LDH 450) with a roughly 70-ps pulse width and a repetition rate of 20 MHz or 10 MHz, focused on a sample with a 100× objective lens and a numerical aperture of 0.90. The photoluminescence signal was acquired through the TCSPC strobelock system. The total instrument response function for the photoluminescence decay was less than 200 ps and the temporal resolution was less than 30 ps. XRD experiments were performed using a sealed-tube Cu X-ray source, equipped with 1D LynxEye detector. The 

in situ experiment was performed with a high-brilliance rotational point-focused Cu X-ray source, equipped with duo detectors of a scintillation counter and LynxEye. The in situ chamber of TC DOME created a robust heating environment and measurement was initiated with a temperature increasing from room temperature to an air temperature of 450 K, followed by XRD data collection. The transient photovoltage and transient photocurrent were measured by a photo-electrochemical system. A conductive atomic-force microscope was used for environmental atomic force microscopy, and an X-ray photoelectron spectrometer was used (ThermoFisher ESCALAB Xi+). Al Kα radiation (1486.6 eV) was used as the excitation source. Transmission FTIR spectroscopy was done using an FT/IR-6100 (Jasco). PAD was mixed with PbI2 using a molar ratio of 1:1 for the FTIR measurements. Ultraviolet-light photoelectron spectroscopy measurements were carried out to determine the work function and the position of valence band maximum of materials. A helium discharge lamp, emitting ultraviolet-light energy at 21.2 eV, was used for excitation. All ultraviolet-light photoelectron spectroscopy measurements were made using standard procedures with a −10 V bias applied between the samples and detectors. Clean gold was used as a reference. 

Grazing-incidence X-ray diffraction (GIXRD) was performed during spin coating and thermal annealing in a custom-made spin coater. The spin coater is attached to the endstation of beamline 12.3.2 at the Advanced Light Source (ALS), Lawrence Berkeley National Laboratory. This custom-made setup allows thin film fabrication from solutions including remotely triggered antisolvent dripping during the measurement in the hutch. While the film is fabricated, diffraction and PL data can be collected simultaneously. The incoming X-ray beam was at a shallow angle of 1° with a beam energy of 10 keV. A DECTRIS Pilatus 1M X-ray detector at an angle of 35° to the sample plane and a sample-to-detector distance of ~189 mm was used. Measurements were carried out on an area of 0.06 mm<sup>2</sup> (12 mm × 0.005 mm) with an approximate flux of ~109 photons s<sup>–1</sup> . The spin coater setup is designed in such a way that the experiment can be performed remotely, avoiding any transfer delays between film deposition and annealing. Samples were heated using a temperature ramp of about 4.5 °C s<sup>–1</sup> to their annealing temperature. The diffraction data was collected with a frame rate of 1.8 s<sup>–1</sup> . The 2D diffraction images were initially analysed using custom-made software and then further analysed by using Igor Pro 8.04 software using Irena and Nika packages<sup>24,25</sup> . 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

The data that support the findings of this study are available from the corresponding authors upon reasonable request. 

24. Ilavsky, J. Nika: software for two-dimensional data reduction. _J. Appl. Crystallogr._ **45** , 324–328 (2012). 

25. Ilavsky, J. & Jemian, P. R. Irena: tool suite for modeling and analysis of small-angle scattering. _J. Appl. Crystallogr._ **42** , 347–353 (2009). 

**Acknowledgements** We thank X. Miao, L. Liu, T. Zhou from Instrumentation and Service Center for Physical Sciences, and X. Lu and Z. Chen from Instrumentation Service Center for Molecular Sciences, Westlake University for help with characterizations and S. Yuan from Zhejiang University for discussions about the crystallization of perovskites. J.Xue. and R.W. acknowledge a grant from the Natural Science Foundation of Zhejiang Province of China (LD22E020002). J.Xue. acknowledges grants from the National Natural Science Foundation of China (62274146), the Shanxi-Zheda Institute of Advanced Materials and Chemical Engineering (2021SZ-FR006) and the Foundation for Innovative Research Groups of the National Natural Science Foundation of China (61721005). R.W. acknowledges funding from Westlake University. M.K.N. and P.J.D. thank the Valais Energy Demonstrators fund. This work was also supported by the National Natural Science Foundation of China (62204209). We used the resources of the Advanced Light Source and the US Department of Energy Office of Science User Facility (contract DE-AC02-05CH11231), beamline 12.3.2 and the in situ spin coater. Work at the Molecular Foundry was supported by the Office of Science and Office of Basic Energy 

## Article 

Sciences of the US Department of Energy (contract DE-AC02-05CH11231) T.K. thanks the German Research Foundation (DFG) for funding (KO6414). Computing resources used in this work were provided by the National Center for High Performance Computing of Turkey (UHeM). 

provided discussions. J.Xue. wrote the manuscript. All the authors discussed the results and commented on the manuscript. 

**Competing interests** The authors declare no competing interests. 

**Author contributions** J.Xue., R.W. and P.S. conceived the idea. P.S. did the two-step fabrication **Additional information** of perovskite films and devices, and performed the data analysis under the supervision of J. **Supplementary information** The online version contains supplementary material available at Xue. and R.W. Y.D. and B.D. did the one-step fabrication of the small-area perovskite devices https://doi.org/10.1038/s41586-023-06208-z. and fabricated the modules under the supervision of M.K.N. Q.X. and S.T. did the in situ **Correspondence and requests for materials** should be addressed to Jingjing Xue, characterizations under the supervision of Y.Y. and C.M.S.-F. C.M.S.-F., J.L.S. and T.K. designed Mohammad Khaja Nazeeruddin, Yang Yang or Rui Wang. the in situ photoluminescence, the in situ multimodal diffraction monitoring system and **Peer review information** _Nature_ thanks the anonymous reviewers for their contribution to the facilitated the in situ measurements. I.Y. and C.Y. did the theoretical calculations. W.F., J.Xu., Y.T., peer review of this work. D.G., X.Z., K.Z. and L.Y. assisted with the characterizations and device fabrication. P.J.D. and D.Y. **Reprints and permissions information** is available at http://www.nature.com/reprints. 



**Extended Data Fig. 1 | FTIR measurements for investigating the interaction between PAd and Pb-I framework.** FTIR spectra of PAd, PbI2 and PAd mixed with PbI2. 

Article 



**Extended Data Fig. 2 | DFT slabs of FA-based perovskite lattice with different surface termination.** The slab of **a** , bare FA-based perovskite and the ones terminated with **b** , PRd, **c** , BAd, **d** , PAd, and the surface energies of the (100) planes. 



**Extended Data Fig. 3 | In-situ GIXRD patterns of perovskite films.** In-situ GIXRD patterns of **a** , the control perovskite film and the ones fabricated with **b** , PRd, **c** , BAd, **d** , PAd. 

## Article 



**Extended Data Fig. 4 | Evolutions of the azimuth angles during the nucleation stage of perovskite films.** Evolution of the azimuth angle during the nucleation of **a** , the control perovskite film and the films fabricated with **b** , PRd, **c** , BAd and **d** , PAd. 



**Extended Data Fig. 5 | In-situ GIXRD monitoring of the initial nucleation stage of perovskite films.** In-situ GIXRD monitoring of the initial nucleation stage of perovskite films fabricated **a** , with and **b** , without PAd. The control 

perovskite nuclei contained a diffraction peak at around 14°, whereas the one with PAd showed a diffraction peak at around 14.4°, indicating compressive strain within the lattice of the perovskite nuclei. 

## Article 



**Extended Data Fig. 6 | Evolution of the PL spectra during the perovskite nucleation stage.** Evolution of the PL spectra during the nucleation stage of **a** , the control perovskite film and the ones with **b** , PRd, **c** , BAd and **d** , PAd. 



**Extended Data Fig. 7 | Optical properties of perovskite films. a** , TRPL plots of the perovskite film with PAd and the control. The PL lifetime was fitted to be 4.89 μs and 0.5 μs for the perovskite film with PAd and the control, respectively. 

**b** , PL spectra of the perovskite film with PAd and the control. The abovementioned perovskite films were deposited by two-step method on glass substrates for measurements. 

## Article 



**Extended Data Fig. 8 | Photovoltaic parameters of perovskite devices made** Centre line, median; box limits, 25<sup>th</sup> and 75<sup>th</sup> percentiles; curve, normal **by two-step method.** Box plots showing the distribution of the **a** , PCE, **b** , FF, distribution curve; whiskers, outliers. **c** , _V_ oc, and **d** , _J_ sc for the control and the PAd devices made by two-step method. 



**Extended Data Fig. 9 | Photovoltaic parameters of perovskite devices made** median; box limits, 25<sup>th</sup> and 75<sup>th</sup> percentiles; curve, normal distribution curve; **by one-step method.** Box plots showing the distribution of the **a** , FF, **b** , _V_ oc, and whiskers, outliers. **c** , _J_ sc for the control and PAd devices made by one-step method. Centre line, 

## Article 



**Extended Data Fig. 10 | Photovoltaic parameters of perovskite modules.** Box plots showing the distribution of the **a** , PCE, **b** , FF, **c** , _V_ oc, **d** , _I_ sc for the control and the PAd-based perovskite modules with an aperture area of 30.86 cm<sup>2</sup> . Centre line, median; box limits, 25<sup>th</sup> and 75<sup>th</sup> percentiles; curve, normal 

distribution curve; whiskers, outliers. In this case, the width of P2 lines and P3 lines was 200 μm and 100 μm respectively and the geometric fill factor (GFF) is around 0.90. 









