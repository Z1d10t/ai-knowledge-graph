# An avalanche-and-surge robust ultrawide-bandgap heterojunction for power electronics

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 185 |
| 作者 | Feng Zhou, H. Gong, M. Xiao, Yunwei Ma, Zheng-Peng Wang, Xinxin Yu, Li Li, L. Fu et al. |
| DOI | 10.1038/s41467-023-40194-0 |
| 源文件 | 059_Zhou_2023_An-avalanche-and-surge-robust-ultrawide-bandgap.pdf |

---


Article 

https://doi.org/10.1038/s41467-023-40194-0 

# An avalanche-and-surge robust ultrawidebandgap heterojunction for power electronics 

|Received: 29 March 2023<br>Accepted: 17 July 2023|Feng Zhou<sup>1,5</sup>, Hehe Gong<sup>1,5</sup>, Ming Xiao<sup>2,5</sup>, Yunwei Ma<sup>2</sup>, Zhengpeng Wang<sup>1</sup>,<br>Xinxin Yu<sup>1</sup>, Li Li<br>3,4, Lan Fu<br>4, Hark Hoe Tan<br>3,4, Yi Yang1, Fang-Fang Ren1,<br>Shulin Gu<sup>1</sup>, Youdou Zheng<sup>1</sup>, Hai Lu<br>1<br>, Rong Zhang<br>1<br>, Yuhao Zhang<br>2<br>&|
|---|---|
||Jiandong Ye<br>1|
|Check for updates||
||Avalanche and surge robustness involve fundamental carrier dynamics under<br>high electricfield and current density. They are also prerequisites of any power<br>device to survive common overvoltage and overcurrent stresses in power<br>electronics applications such as electric vehicles, electricity grids, and<br>renewable energy processing. Despite tremendous efforts to develop the next-<br>generation power devices using emerging ultra-wide bandgap semi-<br>conductors, the lack of effective bipolar doping has been a daunting obstacle<br>for achieving the necessary robustness in these devices. Here we report ava-<br>lanche and surge robustness in a heterojunction formed between the ultra-<br>wide bandgap n-type gallium oxide and the wide-bandgap p-type nickel oxide.<br>Under 1500 V reverse bias, impact ionization initiates in gallium oxide, and the<br>staggered band alignment favors efficient hole removal, enabling a high ava-<br>lanche current over 50 A. Under forward bias, bipolar conductivity modulation<br>enables the junction to survive over 50 A surge current. Moreover, the asym-<br>metric carrier lifetime makes the high-level carrier injection dominant in nickel<br>oxide, enabling a fast reverse recovery within 15 ns. This heterojunction breaks<br>the fundamental trade-off between robustness and switching speed in con-<br>ventional homojunctions and removes a key hurdle to advance ultra-wide<br>bandgap semiconductor devices for power industrial applications.|



Power devices are essential building blocks for high-efficiency energy conversion in power electronics systems. The market size of power semiconductor devices has reached US$40 billion driven by applications like electric vehicles, data centers, electric grids, and renewable energy processing<sup>1</sup> . Deployment of new semiconductors is a fundamental driving force to advance power electronics. The last decade witnesses the success of wide bandgap (WBG) semiconductors, e.g., 

gallium nitride (GaN) and silicon carbide (SiC)<sup>2–5</sup> . On the horizon, ultrawide bandgap (UWBG) semiconductors hold tremendous promises for the next-generation power electronics<sup>6–9</sup> . 

Power devices operate as switches between the high blocking voltage and high conduction current. Their robustness against overvoltage and overcurrent stresses is as important as their performance under normal operations. Such robustness is crucial for any power 

> 1School of Electronic Science and Engineering, Nanjing University, 210008 Nanjing, China. 2Center for Power Electronics Systems, Virginia Polytechnic Institute and State University, Blacksburg 24060 VA, USA.<sup>3</sup> Australian National Fabrication Facility ACT Node, The Australian National University, Canberra ACT 2601, Australia.<sup>4</sup> ARC Centre of Excellence for Transformative Meta-Optical Systems, Department of Electronic Materials Engineering, Research School of Physics, The Australian National University, Canberra ACT 2600, Australia.<sup>5</sup> These author contributed equally: Feng Zhou, Hehe Gong, Ming Xiao. e-mail: hailu@nju.edu.cn; rzhang@nju.edu.cn; yhzhang@vt.edu; yejd@nju.edu.cn 

Nature Communications |  (2023) 14:4459 

1 

Article 

https://doi.org/10.1038/s41467-023-40194-0 

device, as they allow devices to temporarily survive the common faults in power systems, e.g., short circuit, excessive load, arc/ground faults, before the protection circuitry intervenes<sup>10</sup> . Avalanche is the desirable mechanism of power devices to withstand overvoltage stresses, as it allows them to accommodate high avalanche current (IAVA) at the avalanche breakdown voltage (BVAVA) and thus dissipate the excessive energy in circuits<sup>11</sup> . The avalanche and surge current capabilities usually represent the power device robustness against electrical and electrothermal overstress<sup>12</sup> . 

The native p-n junction is the enabling device structure for avalanche and surge robustness in silicon (Si), silicon carbide (SiC), and gallium nitride (GaN) devices<sup>12,13</sup> , the three power semiconductor technologies have reached commercialization. The avalanche hinges on the impact ionization (I. I.) and multiplication occurring at the junction, as well as the efficient removal of the I. I.-produced nonequilibrium carriers. Under forward bias, the capability to withstand high surge current relies on the high-level carrier injection across the p-n junction, which reduces the device resistance as well as suppresses the ramp-up of power loss and junction temperature<sup>12</sup> . In contrast to homojunctions, avalanche or surge current robustness has not been demonstrated in heterojunction-based power devices to date. Only a few avalanche-capable heterojunctions were reported in low-voltage, low-power optoelectronic devices, and the avalanche-like features observed in some unipolar heterostructures are still in debate<sup>14</sup> . 

Compared to Si and WBG counterparts, UWBG power devices possess superior performance limits<sup>1,8</sup> . However, native p-n homojunction is difficult to form in UWBG materials due to the challenges of achieving efficient bipolar doping<sup>15</sup> . This fundamentally limits the robustness of UWBG power devices, of which Gallium oxide (Ga2O3) is an example<sup>16–18</sup> . Benefitting from its high critical electric field, controllable n-type doping, and the large-area wafer availability, Ga2O3 power devices are advancing fast towards applications<sup>19,20</sup> , Whereas, due to the flat valence band and strong self-trapping of holes, the reliable p-type doping in Ga2O3 is very challenging, although p-type Ga2O3 has been reported by some group<sup>21–23</sup> . As an alternative, heterojunctions between Ga2O3 and foreign p-type oxide, e.g., nickel oxide (NiO) or copper oxide<sup>24</sup> , have recently been deployed in the design of Ga2O3 bipolar power devices<sup>15</sup> . Despite excellent device performance, the viability of avalanche and surge robustness in such heterojunctions remains a fundamental knowledge gap. Meanwhile, the impact of band discontinuity on carrier transport is largely unexplored under the high electric field (E-field), high current density, and fast switching conditions. 

This work fills this gap by demonstrating avalanche and surge robustness in NiO/Ga2O3 p-n heterojunctions through device innovations and circuit characterizations, whilst relevant carrier dynamics are also revealed through microscopic techniques and physics-based simulations. Large-area NiO/Ga2O3 p-n heterojunction diodes (HJDs) with advanced edge terminations are designed and fabricated, followed by the avalanche and surge circuit tests complying with industrial standards. Subsequently, the electron beam-induced current (EBIC) characterization and simulations reveal the carrier transport dynamics under critical avalanche and surge conditions. As a key enabler for surge robustness, the bipolar conductivity modulation is found to be dominantly in the NiO with a high hole concentration, while it is usually in the lightly-doped side in conventional homojunctions. This distinction allows NiO/Ga2O3 heterojunctions to simultaneously achieve a smaller reverse recovery and higher switching speed with robustness comparable or superior to that of conventional homojunction. 

## Results 

### NiO/Ga2O3 p-n heterojunction diode 

For power devices, edge termination design is critical to control the E- field crowding, avoid premature breakdown, and access the device 

BVAVA. Here we employ an edge termination that combines small-angle beveled junction termination extension (JTE) and a high-k field plate. Figure 1a presents the three-dimensional schematic diagram of the large-area (3 mm × 3 mm) NiO/Ga2O3 p-n HJD fabricated on 2-inch freestanding Ga2O3 wafers. The p-type region consists of lightly- and heavily-doped NiO layers (i.e., p-NiO and p<sup>+</sup> -NiO). The p-NiO layer can reduce the leakage current and favor the JTE design. At the device edge, the p-NiO extension functions as a JTE, and the small beveled angle allows for a gradual decrease in charge density away from the active region, which continuously reduces the depletion curvature and surface E-field<sup>25</sup> . The high-k field plate conformally covers the NiO JTE and can further passivate the peak E-field. 

The HJD fabrication starts with the deposition of NiO films on n-Ga2O3 drift layer via CMOS-compatible RF magnetron sputtering technique. The hole concentrations in NiO are modulated by tuning the gas flux ratios of Ar/O2 in the sputtering process, resulting in a hole concentration of 5.8 × 10<sup>17</sup> cm<sup>−3</sup> and 2.9 × 10<sup>19</sup> cm<sup>−3</sup> in p-NiO and p<sup>+</sup> -NiO layers, respectively. The beveled angle in NiO is implemented by adjusting the gap between the shadow mask and Ga2O3 wafer as well as the declination angle of the NiO target in the sputtering process, as detailed in Supplementary Section S1. Amorphous barium titanate (BaTiO3), a perovskite oxide with an ultrahigh dielectric constant, is deposited by RF sputtering between the anode metal and NiO to form the field plate. In addition to bare-die devices, some HJDs are sealed in TO-220 packages for circuit tests. More detailed fabrication and packaging process is described in Methods, Supplementary Section S1, and Supplementary Movie 1. Figure 1b shows the cross-sectional scanning transmittance electron microscopy (STEM) image of the edge termination, revealing a bevel angle of 11<sup>o</sup> . The high-resolution TEM image in Fig. 1c shows an atomically sharp interface of the NiO/ Ga2O3 junction with excellent lattice alignments of the (111)-oriented NiO with (001) Ga2O3. 

TCAD simulations are performed to investigate the heterojunction band structure and the device E-field management. The simulation models are detailed in Supplementary Section S4. As shown in Fig. 1d, at equilibrium, the NiO/Ga2O3 junction exhibits a type-II (staggered) band alignment with the conduction band and valence band offsets being 2.1 and 3.2 eV, respectively. Figure 1e shows the simulated E-field contours in the HJD with only the NiO JTE and full termination, both at a reverse bias of 1600 V. The high-k field plate shifts the peak E-field away from the junction edge and lowers the peak E-fields in Ga2O3 and NiO (from 6.61 MV/cm to 4.57 MV/cm and from 7.91 MV/cm to 2.62 MV/cm, respectively). As a result, a nearly uniform E-field is present at the NiO/ Ga2O3 junction, enabling a uniform and robust avalanche. 

Capacitance-voltage (C–V) characterizations are performed for the HJD at frequencies ranging from 1 kHz to 1 MHz, showing negligible frequency dispersion at various biases (Fig. 1f). This indicates the presence of minimal interface states at the heterojunction. The net donor concentration in the Ga2O3 drift layer and the built-in potential of the heterojunction are also extracted from the C–V characteristics to be 1.7 × 10<sup>16</sup> cm<sup>−3</sup> and 2.1 V, respectively (see Supplementary Section S2). From the built-in potential and band offsets, the barrier heights for electrons and holes are 4.2 and 5.3 eV, respectively. This suggests the electron injection could be more pronounced than hole injection at large forward biases. 

### Avalanche breakdown robustness 

Avalanche breakdown is desirable for both power devices and power electronics systems. For devices, it allows for a non-destructive breakdown with a positive temperature coefficient of BVAVA12 and a smaller overvoltage margin as required for a certain voltage rating<sup>26</sup> . For systems, the concurrence of high IAVA and high BVAVA can dissipate the surge energy and prevent it from further circulating in the circuitry<sup>11</sup> . The avalanche characterization should cover all these signatures. Here we employ the quasi-static current-voltage (I–V) characterization to 

Nature Communications |  (2023) 14:4459 

2 

Article 

https://doi.org/10.1038/s41467-023-40194-0 



<!-- Start of picture text -->
a b c<br>Au<br>Ni<br>BaTiO3<br>p + -NiO<br>p-NiO 11°<br>n-Ga2O3 500 nm 5 nm<br>d<br>e<br>6<br>(μm) (μm)<br>2 2 E -field<br>3 E C = 2.1 eV (MV/cm)<br>E C BaTiO3 4.5<br>0 Anode Cut line Anode<br>E F 0 0<br>-3 E V = 3.2 eV NiO Cut line NiO<br>E V<br>-6 Ga2O3 Ga2O3<br>0.0 0.2 Distance (μm)0.4 0.6 2 0 (μm) 55 2 0 (μm) 55 0<br>f 10<br>40<br>Reverse bias: 0 V    -1 V 8 E -field inside NiO<br>30 -5 V  -10 V 6 E -field inside Ga2O3<br>4<br>20<br>2<br>10<br>0<br>0 5 10 15 20 25 30 35 40 45 50 55<br>0 Position (μm)<br>10 3 10 4 10 5 10 6<br>Frequency (Hz)<br>Anode<br>p+-NiO<br>p-NiO<br>NiO<br>Ga2O3<br>n-Ga2O3<br>β -Ga2CathodeO3 substrate<br>BaTiO3<br>(eV)<br>y<br>gre<br>n<br>E<br>V<br>2(nF/cm) /cm)(M<br>e<br>c<br>ticna dleif- E<br>a<br>p<br>a<br>C<br><!-- End of picture text -->

Fig. 1 | NiO/Ga2O3 p-n heterojunction power device. a Three-dimensional schematic of the NiO/Ga2O3 HJD, showing the double-layered NiO (a 300-nm-thick p-NiO and a 100-nm-thick p<sup>+</sup> -NiO) and a high permittivity BaTiO3 dielectric layer with 11° beveled-mesa termination. b STEM image of the termination region of the heterojunction in false color to highlight different layers. c High-resolution cross- 

section TEM image of the heterojunction interface. d Schematic energy band diagram of the HJD at zero bias. e Simulated in-plane E-field contour of devices with and without the BaTiO3 dielectric layer. f Frequency-dependent capacitance characteristics measured at different reverse bias voltages. 

probe the BVAVA behaviors and the unclamped inductive switching (UIS) circuit to measure the IAVA and avalanche energy (EAVA)<sup>27</sup> . 

Figure 2a shows the reverse I–V–T characteristics of the NiO/ Ga2O3 HJD at temperatures (T) from 25 to 175 °C. The reverse current is low (<0.2 µA) and shows weak bias dependence below 1500 V. Then it rises sharply due to the initiation of I. I. and multiplication. The BVAVA increases from 1545 to 1683 V with T elevating from 25 to 175 °C, showing a positive temperature coefficient of 1 V/°C. As compared to a similarly-rated commercial SiC diode with a leakage current of ~10 µA under a reverse bias of 1200 V<sup>28</sup> , the NiO/Ga2O3 HJD shows 10<sup>2</sup> ~10<sup>3</sup> times lower leakage current at high bias, reflecting the superior properties of UWBG materials. 

The UIS setup and test procedure follows the industrial JEDEC standard<sup>29</sup> , with the details elaborated in Supplementary Section S3. Figure 2b shows the UIS circuit schematic and the prototyped test board. In the UIS test, the switch (a power transistor with BV higher than thatof the HJD) is first turned ON to charge the inductor (LUIS); the switch is then turned OFF, forcing the HJD to withstand the surge energy stored in LUIS. Figure 2c shows the test waveforms at T from 25 to 175 °C, revealing the desired avalanche waveforms: the HJD voltage clamps at BVAVA with the decreasing of IAVA from 30 A to zero, and the energy stored in LUIS is fully dissipated in the HJD in this 20 μs avalanche process. Repeating this avalanche process, Fig. 2c presents the sustainability of the HJD under 1-million cycles of repetitive avalanche tests. The device forward and reverse I–V characteristics before and after this cycle test show minimal parametric shifts, as presented in Supplementary Section S5. In addition, the BVAVA extracted from the 

UIS waveforms shows a temperature coefficient identical to that extracted from the I–V characteristics (Fig. 2d). Note the BVAVA in the UIS test (1740 V) is higher than that in the I–V characteristics, due to a higher junction temperature in the UIS test under high IAVA. 

The UIS tests are then performed under various LUIS and the relevant charging time, both of which can alter IAVA and EAVA. Avalanche waveforms are obtained under all these conditions. Figure 2a shows the expanded I–V characteristics that combine the quasi-static I–V curves (at low-current levels) and the IAVA ~ BVAVA data obtained from the UIS tests. Both the HJD and the reference SiC diode show a smooth transition between the two sets of data, suggesting a consistent avalanche across the main p-n junction under a wide range of IAVA (inconsistent avalanche locations would lead to abrupt transition<sup>27</sup> ). Figure 2e shows the IAVA and EAVA under three LUIS, revealing an IAVA up to 50 A and EAVA up to 730 mJ. 

Critical band structure and carrier dynamics are scrutinized to understand the robust avalanche in the HJD. As shown in Fig. 2f, after I. I. is initiated in n-Ga2O3, the high E-field sweeps the produced electrons and holes to the cathode and the heterojunction, respectively. Under reverse bias, the staggered band produces no barriers for hole transport, which enables efficient hole removal (and high IAVA). From the expanded avalanche I–V characteristics (Fig. 2a), the I. I. coefficients of electrons (αn) and holes (αp) in Ga2O3 are calculated. Note that only a theoretical αn30 and no αp have been reported for Ga2O3 previously. The calculated αn and αp are then fed into the TCAD simulation based on the Selberherr I. I. model<sup>31</sup> . The calculation and simulation models are detailed in Supplementary Section S4. Figure 2g shows the 

Nature Communications |  (2023) 14:4459 

3 

Article 

https://doi.org/10.1038/s41467-023-40194-0 



<!-- Start of picture text -->
a b V bus L load c 2800 25  o C 75  o C  50<br>10 2 UIS region 2100 125  o C 175  o C<br>25  o C      75  o C    Switch<br>10 0 100  o C    125  o C   Signal 1400 25<br>150  o C    175  o C 700<br>10 -2<br>V CC 0 0<br>0 10 20<br>10 -4 Time (μs)<br>10 -6 Part of the repetitive avalanche<br>breakdown waveforms BV AVA<br>V bus<br>10 -8 HJD I AVA<br>Quasi-static test region<br>L UIS<br>SiC MPS<br>10 -10 0 500 1000 1500 2000 Switch GND 1 ms<br>0 1 2 3 4 5 6 1.2×10 6<br>Reverse voltage (V)<br>Time (ms)<br>d e f<br>60 800 E C Ga2O3 region<br>1900<br>UIS test<br>600<br>1800 40 E V<br>Temp. coefficient: 1.0 V/ o C 400<br>1700<br>1600 20 200<br>Quasi-static test<br>1500 0 NiO region<br>0 50 100 150 200 10 -1 10 0 10 1<br>Temperature ( o C) L UIS (mH)<br>g h i<br>-2 (μm)Anode NiO 11.7 NiO Ga2O3 10 NiO Ga2O3 10 30<br>0 10 26 Hole Hole accumulation 8 10 24<br>2 Impact ionization BaTiO3 10 18 Electron 6 μμ hh=1x10=1 -4 10 18<br>4 μ h=1x10 -4<br>6 10 10 μ h=1x10 -4 4 μ h=1 10 12<br>Ga2O3 μ h=1 (cm 2 V -1 s -1 )<br>8 10 2 μ h=1x10 -4 2 10 6<br>10 μ h=1<br>(cm 2 V -1 s -1 )<br>12 0 10 -6 -0.4 0.0 0.4 4 8 12 0 -0.4 0.0 0.4 4 8 1210 0<br>0 20 40 55 (μm) Depth (μm) Depth (μm)<br>Avalanche<br>)(V<br>e<br>g<br>)(A tloa<br>tn V Current (A)<br>e<br>rr<br>u<br>c<br>e<br>sre<br>v<br>e<br>R<br>)(Veg )(A<br>tloa I AVA<br>V  (mJ) E AVA<br>-3(cm) )<br>n m<br>oit c/<br>a V<br>rtn (M<br>e<br>c<br>n<br>eirrocr dleif- E -3-1I.I. Gen. Rate (cm)s<br>I.I. Gen. Rate (10)s cm-3X-1 a<br>C<br><!-- End of picture text -->

Fig. 2 | Robust avalanche breakdown and the relevant carrier dynamics. a Temperature-dependent reverse I–V characteristics of the HJD. b Photograph of the UIS test setup and its circuit diagram. c Typical temperature-dependent UIS voltage and current waveforms for the Ga2O3 HJD at a LUIS of 1 mH. d Temperature coefficient values (1.0 V/°C) for BV extracted from quasi-static and UIS 

measurements, respectively. e IAVA and avalanche energy (EAVA) asa function of LUIS. f Illustration of the carrier transport dynamics under the avalanche condition. g Simulated contour of the impact ionization (I. I.) generation rate at BVAVA. h, i Simulated profiles of the electron and hole concentration, E-field, and I. I. generation rate in the HJD under two different hole mobilities, at an IAVA of 30 A. 

simulated contour of the I. I. generation rate at BVAVA. The peak I. I. is located in Ga2O3 near the junction and uniformly distributed in the lateral dimension, confirming I. I. initiation in Ga2O3 and avalanche process across the entire device active region. 

The demonstration of avalanche in Ga2O3, which has not been reported previously, also sheds light on the minority carrier (hole) transport in Ga2O3, which remains controversial<sup>32,33</sup> , and largely unexplored under high E-field. As high IAVA hinges on efficient hole removal, the I. I.-produced holes in Ga2O3 are believed to be exempt from self-trapping under high E-field and drift with considerable mobility (μp). To estimate μp, we simulate the avalanche dynamics with μp of 10<sup>−4</sup> and 1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> according to the low and high values theoretically predicted in the literature<sup>32,34</sup> , (μp is the low-field hole mobility, and field-dependent mobility model is detailed in Supplementary Section S4). Note that higher μp values, e.g., ~1.2 cm<sup>2</sup> /V s<sup>34</sup> and 8~10 cm<sup>2</sup> /V s<sup>22,35</sup> , have been reported experimentally. Here we use two lower μp values in the simulation mainly to consider the worst scenario of avalanche, as a high μp can allow for a more efficient hole removal and thus supports a high avalanche current. At BVAVA, the drift velocity does not reach saturation under either μp values. Figure 2h, i shows the simulated contours of carrier concentrations, E-field and I. I. 

generation rate for the two μp, respectively. The low μp would induce serious hole accumulation and high E-field crowding at the heterojunction, making it unlikely to sustain a stable avalanche. These effects are eliminated for μp = 1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , rendering it a more reasonable μp to explain the avalanche in n-Ga2O3. 

### Surge current and reverse recovery characteristics 

While avalanche represents the HJD’s robustness at reverse bias, surge current measures its capability to withstand forward overcurrent. Here, a 10-ms half-sinusoidal current pulse with an adjustable amplitude is employed for surge current characterization following the JEDEC standard<sup>36</sup> . Figure 3a shows the circuit schematic and the prototyped setup, with the circuit design detailed in Methods. Figure 3b, c shows the current and voltage waveforms in the surge current tests with increased amplitude. The HJD can withstand over 50 A surge current, under which condition the forward voltage approaches 14 V. Based on these time-resolved data, the surge current I–V locus are plotted in Fig. 3d for the HJD and a reference Ga2O3 Schottky barrier diode (SBD) fabricated on the same wafer. The surge current and voltage characteristics of the reference Ga2O3 SBD are shown in Supplementary Section S6. The locus of the HJD and SBD shows an 

Nature Communications |  (2023) 14:4459 

4 

Article 

https://doi.org/10.1038/s41467-023-40194-0 



<!-- Start of picture text -->
a b c<br>V BUS C load 60<br>I peak 15<br>Signal L load 40<br>10<br>V CC<br>Switch 20 5<br>0<br>0<br>V bus L surge Switch 0 2 4 6 8 10 -5 0 2 4 6 8 10<br>Time (ms) Time (ms)<br>C surge HJD GND<br>d e f<br>60 20 10 3 20 10 3<br>15 15<br>40<br>SBD<br>HJD 10 10 2 10 10 2<br>25  o C 50 μs<br>20<br>5 75  o C 5 100 μs<br>125  o C 300 μs<br>0 0 175  o C 10 1 0 500 μs 10 1<br>0 4 8 12 16 0 2 4 6 8 0 2 4 6 8<br>Surge voltage (V) Forward voltage (V) Forward voltage (V)<br>g V BUS h i<br>V CC 15 15<br>Ga2O3 HJD  5 A (25  o C)<br>10 t rr Ga2O3 SBD 10 10 A (25  o C)<br>5 Si FRD  10 A (175  o C)<br>Signal 0 5<br>L load -5 0<br>-10<br>-15 -5<br>V bus<br>Switch -50 0 50 100 150 -50 0 50 100 150<br>HJD Time (ns) Time (ns)<br>L load GND<br>(A) (V)<br>tnrre ega<br>u tlo<br>c v<br>e e<br>gru gru<br>S S<br>) )<br>(A)tne (Atne (Atne<br>rr rr<br>rrr u u<br>u c c<br>ce dra  (mΩ) R on dra  (mΩ) R on<br>Sgru Frow Frow<br>(A) (A)<br>tn tn<br>e e<br>rr rr<br>u u<br>c c<br>dra dra<br>row row<br>F F<br><!-- End of picture text -->

Fig. 3 | Surge current and reverse recovery characteristics. a Photograph of the surge current test setup and its circuit diagram. b, c Surge current and voltage waveforms of the HJD, respectively. d Surge I–V locus of the HJD and the reference Ga2O3 SBD, each set of locus with various amplitudes. e, f Quasi-static temperaturedependent I–V characteristics and pulse I–V characteristics of the HJD, respectively. 

g Photograph of the reverse recovery test setup and its circuit diagram. h reverse recovery characteristics of the Ga2O3 HJD, the reference Ga2O3 SBD, and a commercial Si fast-recovery diode (FRD). i reverse recovery waveforms of the HJD with different conditions. 

anticlockwise and clockwise signature, respectively, which signifies negative and positive temperature coefficients (ηT) of the differential on-resistance (RON)<sup>12,37</sup> , The RON’s negative ηT in the HJD is further confirmed by the forward I–V characteristics measured in the DC mode at elevated T (Fig. 3e) and in the pulse mode with various pulse widths (Fig. 3f). The differential RON decreases with the increased pulse width and forward voltage. 

While a positive ηT of RON is expected for the unipolar SBD due to the mobility drop at high T, the negative ηT suggests bipolar conductivity modulation in the HJD. Bipolar conduction in homojunction power devices is usually dominated by the high-level carrier injection into the lightly-doped drift region, e.g., hole injection into n<sup>-</sup> -type layer, which typically lead to the considerable reverse recovery<sup>38</sup> . When bipolar devices fast switches from a high forward current to high reverse bias, a wide depletion region has to be established in the lightly-doped drift region, requiring the removal of minority carriers that previously fill this region. This leads to a usual tradeoff between surge robustness and switching speed for bipolar power devices. 

To explore if a similar trade-off holds for the NiO/Ga2O3 heterojunction, reverse recovery characterization is performed for the HJD, the reference Ga2O3 SBD, and a similarly-rated commercial Si fast-recovery diode (FRD)<sup>39</sup> , with the circuit schematic and prototype shown in Fig. 3g and detailed in Methods. As shown in Fig. 3h, i, the 1200-V reverse 

recovery of the HJD is similar to the unipolar Ga2O3 SBD and much faster than the bipolar Si FRD. Moreover, the reverse recovery waveforms are nearly independent of the forward current (5–10 A) and temperature (25–175 °C), suggesting the reverse recovery waveform is dominated by the capacitive ringing instead of minority carrier recombination. The recombination process, if any, should be faster than the duration of the first ringing. Based on the method in ref. 12 and the reverse recovery time (trr) of 12.79 ns extracted from the first ringing waveform, the maximum hole lifetime in Ga2O3 is estimated to be 6.50 ns. 

### Microscopic EBIC characterization 

The high surge current capability albeit minimal reverse recovery in the HJD suggests a different origin of conductivity modulation as compared to conventional bipolar devices. We suspect the origin to be the electron injection into NiO. Under low forward bias, trap-assisted tunneling dominates the interfacial recombination, while under the elevated forward bias, high-level minority carrier (electrons) injection into the NiO layer occurs via tunneling or thermionic emission across the interfacial barrier at the conduction band. Injected electrons diffuse in the neutral region of NiO and contribute to current conduction, reducing the whole RON of the HJD<sup>40</sup> . Under reverse bias, as the depletion mainly occurs in the lightly-doped Ga2O3, minimal minority carries need to be recombined in p-NiO for switching to occur. Hence, the carrier dynamics in NiO insignificantly impact the device reverse recovery. 

Nature Communications |  (2023) 14:4459 

5 

Article 

https://doi.org/10.1038/s41467-023-40194-0 



<!-- Start of picture text -->
a b c IEBIC (Normalized)<br>IEBIC 0 0.01 0.1 1<br>Anode Anode (a.u.)<br>p + -NiO p + -NiO<br>NiO<br>L n,NiO: 413 nm<br>p-NiO p-NiO 500<br>n-Ga2O3 Space charge<br>region<br>n-Ga2O3 1000<br>Ga2O3<br>250 nm 250 nm<br>L p,GaO: 127 nm<br>d e<br>10 35<br>2<br>10 25 Hole accumulation Elec. accumulation<br>0 E C E Fn 10 15<br>Electron<br>Elec. injection<br>10 5 Hole injection<br>-2<br>Hole 10 -5<br>E Fp<br>-4 10 -15 Electron<br>E V<br>Hole<br>10 -25<br>-6 NiO region Ga2O3 region NiO Ga2O3<br>10 -35<br>-8 -6 -4 -2 0 2 4 6 8 -0.4 -0.2 0 2 4 6 8 10 12<br>Depth (nm) Depth (μm)<br>Profile (nm)<br>-3(cm)<br>) n<br>V oit<br>(e rta<br>y n<br>Egrne oecnc<br>eirrr<br>a<br>C<br><!-- End of picture text -->

Fig. 4 | EBIC characterization and the carrier dynamics under the surge condition. a False color cross-sectional scanning electron microscopy (SEM) image of the HJD. b The corresponding colored EBIC map of the heterojunction region under zero bias and at room temperature. c EBIC profile extracted by the integration of 

EBIC intensity map in the vertical direction. d Illustration of the carrier transport dynamics under the high forward current. e Simulated distribution of minority carriers on both sides of the HJD at a forward voltage of 6 V. 

To pursue the microscopic visualization of carrier diffusion, we apply microscopic EBIC characterization, an SEM-based technique widely used to image carrier dynamics to the NiO/Ga2O3 junction<sup>41</sup> . The EBIC signal is recorded simultaneously with the SEM detector signal, thereby allowing us to spatially correlate the EBIC signal. Figure 4a shows the cross-sectional SEM image of the HJD, and the corresponding EBIC map is provided in Fig. 4b. In the presence of built-in E- field in the depletion region, the EBIC signal decays from the junction interface to both sides of the junction, where a higher current signal is observed in NiO. This indicates more minority carriers are injected into NiO, since only minority carriers contribute to the induced current<sup>42</sup> . The exponential decay of the EBIC signals is well described in terms of I = I0e<sup>−x/L</sup> , where I0 is the maximum intensity and x is the distance from the junction<sup>41</sup> . Accordingly, the minority carrier diffusion length (L) for electrons in p-NiO and holes in n-Ga2O3 are determined to be 413 and 127 nm, respectively (Fig. 4c). The difference to the reported values in<sup>43,44</sup> , could be result of the variation in epitaxial quality, synthesis methods, and material conductivities. Consequently, the minority carrier lifetime (τ) for electrons in p-NiO and holes in Ga2O3 are extracted to be 124.0 and 6.2 ns, respectively, based on the relation L = (D × τ)<sup>1/2</sup> and the carrier diffusion coefficient (D) in respective materials<sup>45</sup> . The hole lifetime in Ga2O3 is consistent with the maximum value estimated from the reverse recovery waveform. In addition, in terms of Einstein’s relation, the hole mobility in Ga2O3 is estimated to be 1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which is consistent with the value estimated from the avalanche simulations shown in Fig. 2h, i. 

The EBIC results reveal that the L, τ, and minority carrier quantity in Ga2O3 are much smaller than those in NiO, making the conductivity modulation occurs predominantly in NiO. Accordingly, the schematic of band structure and carrier dynamics in the HJD at high forward bias is illustrated in Fig. 4d. At the heterojunction, electrons and holes 

primarily tunnel through the barriers produced by band offsets, whilst undergoing a trap-assisted band-to-band recombination<sup>46</sup> . Feeding the parameters extracted from EBIC into the simulation, the contours of electrons and holes are shown in Fig. 4e at a forward voltage of 6 V. High concentration of electrons approaching 10<sup>20</sup> cm<sup>−3</sup> are present in the entire NiO region, while the hole concentration in Ga2O3 is much lower and drops rapidly away from the junction. The simulation results validate the more pronounced minority carrier injection in NiO under the surge current condition. 

## Discussion 

The intriguing physics of the NiO/Ga2O3 heterojunction enables the fabricated HJD to deliver a breakthrough trade-off between device performance and robustness. Achieving low RON, high current, and high BV concurrently is a major pursuit for power device technologies<sup>1</sup> . As shown in Fig. 5a, the RON and BV trade-off of our HJD is the recordbreaking among the reported ampere-class Ga2O3 diodes with forward current >1 A<sup>37,47–55</sup> , In addition, the benchmark of specific on-resistance (Ron,sp) versus BV of the ampere-class Ga2O3 HJD against small-area Ga2O3 power diodes is shown in Supplementary Section S9. Figure 5b benchmarks the EAVA density of our HJD with homojunction-based Si, SiC, and GaN devices with a similar BVAVA. The EAVA density of our HJD is significantly higher than that of Si devices and comparable to the highest values reported in SiC and GaN devices<sup>12,27,28,56–62</sup> , In addition, as shown in Fig. 5c, our HJD shows an excellent combination of high surge current and surge energy comparable to the highest values reported in Si, SiC, and GaN devices<sup>12,39,60,61,63–67</sup> , Finally, as shown in Fig. 5d, our HJD breaks the trade-off between the reverse recovery time and surge energy in Si, SiC, and GaN devices<sup>12,28,39,61,63–67</sup> , enabling a much lower switching speed and loss, whilst demonstrating the state-of-the-art robustness. 

Nature Communications |  (2023) 14:4459 

6 

Article 

https://doi.org/10.1038/s41467-023-40194-0 



<!-- Start of picture text -->
10<br>10 1 Ga2O3: NiO/Ga2O3 (This work) Hetero.-  NiO/Ga2O3 (This work)<br>SBD  HJD  8 Homo.-  GaN  SiC  Si<br>10 0 6<br>4<br>10 -1<br>2<br>10 -2 0<br>10 2 10 3 10 4 0 500 1000 1500 2000<br>BV  (V) BV AVA  (V)<br>9 Hetero.-  NiO/Ga2O3 (This work) 9 Hetero.-  NiO/Ga2O3 (This work)<br>Homo.-  GaN  SiC  Si  Homo.-  GaN  SiC  Si<br>6 6<br>Bipolar<br>3 3 region<br>Unipolar<br>0 0 region<br>0 20 40 60 80 100 120 140 10 1 10 2<br>I SUR (A) t rr (ns)<br>SiC limit<br>limit<br>O<br>Ga<br>GaN limit<br>3<br>2<br>Ω R  ()on<br>2J/cm E ()AVA<br>E J()SUR E J()SUR<br><!-- End of picture text -->

Fig. 5 | Benchmarking performance and robustness of the Ga2O3 HJD against commercial Si, SiC, and GaN power diodes. a Ron versus BV benchmark for all the ampere-class Ga2O3 power diodes. b EAVA versus BVAVA benchmark, c Surge energy 

(ESUR) versus peak surge current (ISUR) benchmark, and d ESUR versus reverse recovery time (trr) benchmark, all for Ga2O3, GaN, SiC, and Si power diodes. 

In summary, this work demonstrates a NiO/Ga2O3 heterojunction architecture with high avalanche and surge current robustness, minimal reverse recovery, as well as an excellent trade-off between RON and BV. The robustness of the large-area, packaged HJD is characterized by incircuit tests following industrial standards, revealing the survival of >1700 V overvoltage and >50 A overcurrent. This robustness is attributable to the effective edge termination design, high-quality heterojunction, staggered band alignment, and conductivity modulation. Benefitting from the asymmetric minority carrier lifetimes, conductivity modulation is dominant in p-NiO, which is visualized through microscopic EBIC characterization and enables minimal reverse recovery in switching applications. The avalanche and surge current characteristics also provide physical insights into the fundamentals of hole transport dynamics in Ga2O3, particularly the parameters including impact ionization coefficient, high-field mobility, and a lifetime of minority carriers. This heterojunction is promising for making robust power devices in semiconductors lacking bipolar doping for applications in electric vehicles, aerospace, grid, and renewable energy processing. 

## Methods 

### Epitaxial structure 

The epitaxial structure was grown by hydride vapor phase epitaxy (HVPE) on a conductive Sn-doped (001) β-Ga2O3 substrate, consisting of a 10-μm Si-doped β-Ga2O3 drift layer with an electron concentration of 1.7 × 10<sup>16</sup> cm<sup>−3</sup> . Based on the Hall measurements of the controlled NiO samples on semi-insulating substrates, hole mobilities corresponding to p-NiO (5.8 × 10<sup>17</sup> cm<sup>−3</sup> ) and p<sup>+</sup> -NiO (2.9 × 10<sup>19</sup> cm<sup>−3</sup> ) layers were determined to be 0.87 cm<sup>2</sup> /V s and 0.34 cm<sup>2</sup> /V s, respectively. Schematic of the processing steps is shown in Supplementary Section S1. The current-voltage characteristics of the p-NiO layer are shown in Supplementary Section S8. 

Then, the Ga2O3 epi-wafers were annealed at 500 °C for 5 hours under the O2 ambient to partially compensate the donors in the epi-layer. The back-side Ohmic contact (cathode) was formed by the Ti/Au (20/ 80 nm) deposition through electron beam evaporation (EBE), followed by rapid thermal annealing at 500 °C for 1 min under N2 ambient. This annealing process has been reported to be able to effectively passivate near-surface defects in Ga2O3 epi-layer<sup>68</sup> . Note that the inter-diffusion of Sn from substrate and Si from epi-wafer is expected to be negligible at this annealing temperature<sup>69,70</sup> , Subsequently, by using an angled shadow mask, a 400-nm-thick double-layered NiO film with adjustable bevel angle was deposited on the Ga2O3 drift layer by RF magnetron sputtering technique at room temperature. During the sputtering process, the substrate was rotated at 4 rpm to enhance the film uniformity. The target was high-purity (99.99%) NiO ceramics. To alleviate the damage induced by sputtering plasma, the initial RF power was 50 W, and then increased to 150 W when the NiO thickness was above 20 nm. The distance between the target and the wafer was maintained at 13 cm. The growth pressure was 0.6 Pa in an Ar/O2 mixed ambient, and the flux ratios of Ar/O2 were tuned from 20:1 to 2:1 to modulate hole concentration in the double-layered NiO. A 300-nm-thick BaTiO3 was also deposited by RF magnetron sputtering at the same growth pressure of 0.6 Pa in an Ar/O2 mixed ambient with a flux ratio of 10:1, followed by annealing at 300 °C in oxygen ambient for 1 hour. The contact window was opened by a lift-off process, and Ni/Au (300/200 nm) metal stack was deposited by EBE to form the anode contact, producing an active area of 3 × 3 mm<sup>2</sup> . 

### Device package 

The device was sealed in a TO-220 package for circuit testing. For the comparison of surge current characteristics, 9-mm<sup>2</sup> Ni/β-Ga2O3 SBDs were also fabricated on the same wafer by identical processes except for the p-NiO deposition underneath the Schottky anode. 

### Device fabrication 

The device fabrication started with the substrate thinning from 640 μm to 150 μm by chemical mechanical polishing process, followed by substrate cleaning via ultrasonic treatment in acetone and soaking. 

### Device static electrical characterizations 

The quasi-static forward/reverse I–V characterizations were performed by a B1505 power device analyzer. The pulse measurement mode in the 

Nature Communications |  (2023) 14:4459 

7 

Article 

https://doi.org/10.1038/s41467-023-40194-0 

B1505 analyzer was adopted to characterize the forward current above 1 A (Fig. 3e, f), while the high-resolution DC mode was used to measure the log-scale forward I–V characteristics of the HJD (Supplementary Section S7). The C–V characteristics were measured by using an E4980A precision LCR meter at room temperature. 

### Device circuit-level characterizations 

The UIS, surge current, and reverse recovery characterizations were carried out by a customized circuit test platform. All test circuits and methods were formulated according to the Joint Electron Device Engineering Council (JEDEC) standards. Photographs of test circuits and experimental platforms are presented in Supplementary Section S3. 

### EBIC and TEM characterizations 

EBIC measurement was carried out in an FEI Helios 600 NanoLab Dualbeam FIB system equipped with Kleindiek Nano Control NC40 nanomanipulators and low-current measurement units. The top- and bottom electrodes were contacted to the nanomanipulator and sample stage, respectively, allowing electrical current to flowand pass through a current amplifier. The electron beam direction is perpendicular to the surface of the junction, and the acceleration voltage and electron beam current were 15 kV and 0.17 nA, respectively. Line-scan measurement from the top electrode down to the Ga2O3 drift layer was performed to extract the profile of the EBIC current across the junction. Scanning TEM, bright-field high-resolution TEM, and energy dispersive X-ray (EDX) spectroscopy elemental mapping were performed using an FEI Tecnai F-20 microscope (FEI TF-20), operated at an acceleration voltage of 200 kV. 

### Simulations 

The Technology Computer-Aided Design (TCAD) device simulations were performed using the Silvaco TCAD device package. Additional details for the simulations are provided in Supplementary Section S4. 

## Data availability 

The authors declare that the data supporting the findings of this study are available within the paper and its supplementary information files. Source data are provided with this paper. 

## References 

1. Zhang, Y., Udrea, F. & Wang, H. Multidimensional device architectures for efficient power electronics. Nat. Electron. 5, 723–734 (2022). 

2. Amano, H. et al. The 2018 GaN power electronics roadmap. J. Phys. D: Appl. Phys. 51, 163001 (2018). 

3. She, X., Huang, A. Q., Lucia, O. & Ozpineci, B. Review of silicon carbide power devices and their applications. IEEE Trans. Ind. Electron. 64, 8193–8205 (2017). 

4. Nela, L. et al. Multi-channel nanowire devices for efficient power conversion. Nat. Electron. 4, 284–290 (2021). 

5. Chen, K. J. et al. GaN-on-Si power technology: devices and applications. IEEE Electron Device Lett. 64, 779–795 (2017). 

6. Wan, H.-H. et al. NiO/β-(AlxGa1-x)2O3/Ga2O3 heterojunction lateral rectifiers with reverse breakdown voltage >7 kV. J. Vac. Sci. Technol., A 41, 032701 (2023). 

7. Yan, Q. et al. β-Ga2O3 hetero-junction barrier Schottky diode with reverse leakage current modulation and BV<sup>2</sup> /Ron,sp value of 0.93 GW/cm<sup>2</sup> . Appl. Phys. Lett. 118, 122102 (2021). 

8. Tsao, J. Y. et al. Ultrawide‐bandgap semiconductors: research opportunities and challenges. Adv. Electron. Mater. 4, 1600501 (2017). 

9. Qin, Y., Wang, Z., Sasaki, K., Ye, J. & Zhang, Y. Recent progress of Ga2O3 power technology: large-area devices, packaging and applications. Jpn. J. Appl. Phys. 62, SF0801 (2023). 

10. Yang, S. et al. Condition monitoring for device reliability in power electronic converters: a review. IEEE Trans. Power Electron. 25, 2734–2752 (2010). 

11. Zhang, R., Kozak, J. P., Xiao, M., Liu, J. & Zhang, Y. Surge-energy and overvoltage ruggedness of p-Gate GaN HEMTs. IEEE Trans. Power Electron. 35, 13409–13419 (2020). 

12. Liu, J. et al. Surge current and avalanche ruggedness of 1.2 kV vertical GaN p-n diodes. IEEE Trans. Power Electron. 36, 10959–10964 (2021). 

13. Lutz, J. & Baburske, R. Some aspects on ruggedness of SiC power devices. Microelectron. Reliab. 54, 49–56 (2014). 

14. Zhang, Q. et al. Enhanced gain and detectivity of unipolar barrier solar blind avalanche photodetector via lattice and band engineering. Nat. Commun. 14, 418 (2023). 

15. Zhang, J. et al. Ultra-wide bandgap semiconductor Ga2O3 power diodes. Nat. Commun. 13, 3900 (2022). 

16. Li, W. et al. 2.44 kV Ga2O3 vertical trench Schottky barrier diodes with very low reverse leakage current. In: IEDM Tech. Dig. 193–196; https://doi.org/10.1109/IEDM.2018.8614693. (IEEE, 2018). 

17. Lin, C.-H. et al. Vertical Ga2O3 Schottky barrier diodes with guard ring formed by nitrogen-ion implantation. IEEE Electron Device Lett. 40, 1487–1490 (2019). 

18. Pearton, S. J. et al. A review of Ga2O3 materials, processing, and devices. Appl. Phys. Rev. 5, 011301 (2018). 

19. Higashiwaki, M. & Jessen, G. H. Guest editorial: the dawn of gallium oxide microelectronics. Appl. Phys. Lett. 112, 060401 (2018). 

20. Green, A. J. et al. β-Gallium oxide power electronics. APL Mater. 10, 029201 (2022). 

21. Chikoidze, E. et al. Electrical properties of p-type Zn:Ga2O3 thin films. J. Vac. Sci. Technol., A 40, 043401 (2022). 

22. Chikoidze, E. et al. Enhancing the intrinsic p-type conductivity of the ultra-wide bandgap Ga2O3 semiconductor. J. Mater. Chem. C. 7, 10231–10239 (2019). 

23. Wu, Z. Y. et al. Energy-driven multi-step structural phase transition mechanism to achieve high-quality p-type nitrogen-doped β-Ga2O3 films. Mater. Today Phys. 17, 100356 (2021). 

24. Spencer, J. A. et al. A review of band structure and material properties of transparent conducting and semiconducting oxides: Ga2O3, Al2O3, In2O3, ZnO, SnO2, CdO, NiO, CuO, and Sc2O3. Appl. Phys. Rev. 9, 011315 (2022). 

25. Sung, W., Huang, A. Q. & Baliga, B. J. Bevel junction termination extension—a new edge termination technique for 4H-SiC highvoltage devices. IEEE Electron Device Lett. 36, 594–596 (2015). 

26. Kozak, J. P. et al. Degradation and recovery of GaN HEMTs in overvoltage hard switching near breakdown voltage. IEEE Trans. Power Electron. 38, 435–446 (2023). 

27. Liu, J. et al. Trap-mediated avalanche in large-area 1.2 kV vertical GaN p-n diodes. IEEE Electron Device Lett. 41, 1328–1331 (2020). 

28. Wolfspeed. C4D05120A Datasheet; https://assets.wolfspeed.com/ uploads/2020/12/C4D05120A.pdf. 

29. JESD24-5. Single pulse unclamped inductive switching (uis) avalanche test method Datasheet; https://www.jedec.org/sites/ default/files/docs/jesd24-5.pdf. 

30. Ghosh, K. & Singisetti, U. Impact ionization in β-Ga2O3. J. Appl. Phys. 124, 085707 (2018). 

31. ATLAS User’s Manual: Device Simulation Software Datasheet; https://www.eng.buffalo.edu/~wie/silvaco/atlas_user_manual.pdf. 

32. Varley, J. B., Janotti, A. & Franchini, C. & Van de Walle, C. G. Role of self-trapping in luminescence and p-type conductivity of wideband-gap oxides. Phys. Rev. B 85, 081109 (2012). 

33. Yakimov, E. B. et al. Diffusion length of non-equilibrium minority charge carriers in β-Ga2O3 measured by electron beam induced current. J. Appl. Phys. 123, 185704 (2018). 

Nature Communications |  (2023) 14:4459 

8 

Article 

https://doi.org/10.1038/s41467-023-40194-0 

34. Poncé, S. & Giustino, F. Structural, electronic, elastic, power, and transport properties of β-Ga2O3 from first principles. Phys. Rev. Res. 2, 033102 (2020). 

35. Chikoidze, E. et al. P-type β-gallium oxide: a new perspective for power and optoelectronic devices. Mater. Today Phys. 3, 118–126 (2017). 

36. JESD282B.01 Datasheet; https://www.jedec.org/standardsdocuments/docs/jesd-282b01#. 

37. Xiao, M. et al. Packaged Ga2O3 schottky rectifiers with over 60 a surge current capability. IEEE Trans. Power Electron. 36, 8565–8569 (2021). 

38. Baburske, R. et al. The trade-off between surge-current capability and reverse- recovery behaviour of high-voltage power diodes. In: Proc. Int. Seminar on Power Semicond. 87-92 (IEEE, 2010). 

39. DIODES. LTTH812W Datasheet; https://www.diodes.com/assets/ Datasheets/LTTH812W.pdf. 

40. Goyal, N. & Saxena, R. S. A New LDMOSFET with tunneling junction for improved on-state performance. IEEE Electron Device Lett. 34, 90–92 (2013). 

41. Gutsche, C. et al. Direct determination of minority carrier diffusion lengths at axial GaAs nanowire p-n junctions. Nano Lett. 12, 1453–1458 (2012). 

42. Chernyak, L. et al. Electron beam induced current measurements of minority carrier diffusion length in gallium nitride. Appl. Phys. Lett. 69, 2531–2533 (1996). 

43. Modak, S. et al. Variable temperature probing of minority carrier transport and optical properties in p-Ga2O3. APL Mater. 10, 031106 (2022). 

44. Lee, J. et al. Effect of 1.5 MeV electron irradiation on β-Ga2O3 carrier lifetime and diffusion length. Appl. Phys. Lett. 112, 082104 (2018). 

45. Handley, S. J. & Bradberry, G. W. Estimates of charge carrier mobility and lifetime in nickel oxide. Phys. Lett. A 40, 277–278 (1972). 

46. Maur, M. A. D. et al. Trap-assisted tunneling in InGaN/GaN single quantum-well light-emitting diodes. Appl. Phys. Lett. 105, 133504 (2014). 

47. Gong, H. et al. 1.37 kV/12 A NiO/β-Ga2O3 heterojunction diode with nanosecond reverse recovery and rugged surge-current capability. IEEE Trans. Power Electron. 36, 12213–12217 (2021). 

48. Wei, J. et al. Experimental study on electrical characteristics of large-size vertical β-Ga2O3 junction barrier Schottky diodes. In: IEEE 34th International Symposium on Power Semiconductor Devices and ICs. 97–100 (IEEE, 2022); https://doi.org/10.1109/ispsd49238. 2022.9813623. 

49. Otsuka, F. et al. Large-size (1.7 × 1.7 mm<sup>2</sup> ) β-Ga2O3 field-plated trench MOS-type Schottky barrier diodes with 1.2 kV breakdown voltage and 109 high on/off current ratio. Appl. Phys. Exp. 15, 016501 (2021). 

50. Ji, M. et al. Demonstration of large-size vertical Ga2O3 Schottky barrier diodes. IEEE Trans. Power Electron. 36, 41–44 (2021). 

51. Yang, J. et al. Reverse breakdown in large area, field-plated, vertical β-Ga2O3 rectifiers. ECS J. Solid State Sci. Technol. 8, Q3159–Q3164 (2019). 

52. Yang, J., Ren, F., Tadjer, M., Pearton, S. J. & Kuramata, A. Ga2O3 Schottky rectifiers with 1 ampere forward current, 650 V reverse breakdown and 26.5 MW.cm<sup>−2</sup> figure-of-merit. AIP Adv. 8, 055026 (2018). 

53. Lv, Y. et al. Demonstration of β-Ga2O3 junction barrier schottky diodes with a Baliga’s figure of merit of 0.85 GW/cm<sup>2</sup> or a 5A/700 V handling capabilities. IEEE Trans. Power Electron. 36, 6179–6182 (2020). 

54. Yang, J. et al. Vertical geometry 33.2 A, 4.8 MW cm<sup>2</sup> Ga2O3 field-plated Schottky rectifier arrays. Appl. Phys. Lett. 114, 232106 (2019). 

55. Gong, H. et al. 70-μm-body Ga2O3 Schottky barrier diode with 1.48 K/W thermal resistance, 59 a surge current and 98.9% conversion efficiency. IEEE Electron Device Lett. 43, 773–776 (2022). 

56. Nie, K.-W. et al. Highly enhanced inductive current sustaining capability and avalanche ruggedness in GaN p-i-n diodes with shallow bevel termination. IEEE Electron Device Lett. 41, 469–472 (2020). 

57. Aktas, O. & Kizilyalli, I. C. Avalanche capability of vertical GaN p-n junctions on bulk GaN substrates. IEEE Electron Device Lett. 36, 890–892 (2015). 

58. Zou, X., Zhang, X., Lu, X., Tang, C. W. & Lau, K. M. Breakdown ruggedness of quasi-vertical GaN-based p-i-n diodes on Si substrates. IEEE Electron Device Lett. 37, 1158–1161 (2016). 

59. Liu, L. et al. Investigation of avalanche capability of 1200 V 4H-SiC MPS diodes and JBS diodes. In: 32nd International Symposium on Power Semiconductor Devices and ICs. 210-213 (IEEE, 2020); https://doi.org/10.1109/ISPSD46842.2020.9170067. 

60. Ren, N., Wu, J., Liu, L. & Sheng, K. Improving surge current capability of SiC merged PiN schottky diode by adding plasma spreading layers. IEEE Trans. Power Electron. 35, 11316–11320 (2020). 

61. Zhou, F. et al. Demonstration of avalanche and surge-current robustness in GaN junction barrier schottky diode with 600 V/10 a switching capability. IEEE Trans. Power Electron. 36, 12163–12167 (2021). 

62. Qi, J. et al. Comprehensive assessment of avalanche operating boundary of SiC planar/trench MOSFET in cryogenic applications. IEEE Trans. Power Electron. 36, 6954–6966 (2021). 

63. Wolfspeed. C4D30120D Datasheet; https://assets.wolfspeed.com/ uploads/2020/12/C4D30120D.pdf. 

64. Zhou, F. et al. Flip-chip AlGaN/GaN schottky barrier diode using buried-ohmic anode structure with robust surge current ruggedness and transient energy sustaining capability. IEEE Trans. Electron Devices 69, 5664–5670 (2022). 

65. ROHM. RFN5TF8S Datasheet; https://www.rohm.com/products/ diodes/fast-recovery-diodes/standard/rfn5tf8s-product. 

66. RHOM. RF305BM6S Datasheet; https://rohmfs-rohm-com-cn.osscn-shanghai.aliyuncs.com/en/products/databook/datasheet/ discrete/diode/fast_recovery/rf305bm6s-e.pdf. 

67. Rectifiers, F. R. FR107 Datasheet; https://www.topdiode.com/pdf/ FR101-FR107.PDF. 

68. Hu, H. et al. The role of surface pretreatment by low temperature O2 gas annealing for β-Ga2O3 Schottky barrier diodes. Appl. Phys. Lett. 120, 073501 (2022). 

69. Frodason, Y. K. et al. Diffusion of Sn donors in β-Ga2O3. APL Mater. 11, 041121 (2023). 

70. Murakami, H. et al. Homoepitaxial growth of β-Ga2O3 layers by halide vapor phase epitaxy. Appl. Phys. Exp. 8, 015503 (2015). 

## Acknowledgements 

We thank Dr. Yu Deng for his assistance in TEM and EDX measurements, and Silvaco Inc. for collaboration and support of material and device TCAD simulations. This work was supported in part by the National Key R&D Program of China (No. 2022YFB3605403), the National Natural Science Foundation of China (62234007, 62293521, U21A20503, and U21A2071), the Key-Area R&D Program of Guangdong Province (2020B010174002). Access to the EBIC facility is made possible through support from the Australian National Fabrication Facility, ACT Node. We also thank Han Wang at the University of Southern California for valuable feedback on the manuscript. 

## Author contributions 

J.D.Y., Y.H.Z., R.Z., and H.L. proposed and directed the research. H.H.G. performed device design and fabrication. F.Z. and H.H.G. performed the characterization and data analysis. M.X. and Y.W.M. performed the 

Nature Communications |  (2023) 14:4459 

9 

Article 

https://doi.org/10.1038/s41467-023-40194-0 

physical-based simulations and theoretical calculations. Z.P.W. and X.X.Y. performed the Hall and TEM characterizations. L.L. and L.F. performed the EBIC characterization and analysis. Y.Y., F.F.R., S.L.G. H. H. T., and Y.D.Z discussed the results and commented on the manuscript. Y.H.Z., J.D.Y., and F.Z. wrote the manuscript, and all authors approved the final version of the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-40194-0. 

Correspondence and requests for materials should be addressed to Hai Lu, Rong Zhang, Yuhao Zhang or Jiandong Ye. 

Peer review information Nature Communications thanks Biplab Sarkar and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2023 

Nature Communications |  (2023) 14:4459 

10 

