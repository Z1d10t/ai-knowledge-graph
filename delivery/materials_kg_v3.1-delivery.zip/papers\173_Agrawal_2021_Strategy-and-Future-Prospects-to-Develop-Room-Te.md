# Strategy and Future Prospects to Develop Room-Temperature-Recoverable NO2 Gas Sensor Based on Two-Dimensional Molybdenum Disulfide

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nano-Micro Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Abhay V. Agrawal, Naveen Kumar, Mukesh Kumar |
| DOI | 10.1007/s40820-020-00558-3 |
| 源文件 | 073_Agrawal_2021_Strategy-and-Future-Prospects-to-Develop-Room-Te.pdf |

---
ISSN 2311-6706 e-ISSN 2150-5551 CN 31-2103/TB 

https://doi.org/10.1007/s40820-020-00558-3 

## **<mark>REVIEW</mark>** 



###### **Cite as** 

Nano-Micro Lett. (2021) 13:38 

Received: 26 August 2020 Accepted: 29 October 2020 Published online: 4 January 2021 © The Author(s) 2020 

# **Strategy and Future Prospects to Develop Room‑Temperature‑Recoverable  NO2 Gas Sensor Based on Two‑Dimensional Molybdenum Disulfide** 

Abhay V. Agrawal<sup>1</sup> , Naveen Kumar<sup>1</sup> , Mukesh Kumar<sup>1*</sup> 

#### **HIGHLIGHTS** 

- MoS2 shows enormous potential for gas sensing due to its high surface to volume ratio, position-dependent gas molecules adsorption and easy control on morphology. 

- The recent experimental and theoretical strategies to develop  NO2 chemiresistance sensors based on  MoS2 are addressed. 

- A detailed overview of the fabrication of  MoS2 chemiresistance sensors in terms of devices, structure, morphology, defects, heterostructures, metal doping, and under light illumination are discussed. 

**ABSTRACT** Nitrogen dioxide  (NO2), a hazardous gas with acidic nature, is continuously being liberated in the atmosphere due to human activity. The  NO2 sensors based on traditional materials have limitations of high-temperature requirements, slow recovery, and performance degradation under harsh environmental conditions. These limitations of traditional materials are forcing the scientific community to discover future alternative  NO2 sensitive materials. Molybdenum disulfide  (MoS2) has emerged as a potential candidate for developing next-generation  NO2 gas sensors.  MoS2 has a large surface area for  NO2 molecules adsorption with controllable morphologies, facile integration with other materials and compatibility with internet of things (IoT) devices. The aim of this review is to provide a detailed overview of the fabrication of  MoS2 chemiresistance sensors in terms of devices (resistor and transistor), layer thickness, morphology control, defect tailoring, heterostructure, metal nanoparticle 



<!-- Start of picture text -->
High surface to<br>volume ratio<br>Chemiresistance MoS2<br>based NO2 sensors<br>High adsorption<br>energy and active sites<br>Cost effective andIOT compatible<br>Highly sensitiveand selective<br>opertion<br>Room temperature<br>and recovery timeFast response<br><!-- End of picture text -->

doping, and through light illumination. Moreover, the experimental and theoretical aspects used in designing  MoS2-based  NO2 sensors are also discussed extensively. Finally, the review concludes the challenges and future perspectives to further enhance the gas-sensing performance of  MoS2. Understanding and addressing these issues are expected to yield the development of highly reliable and industry standard chemiresistance  NO2 gas sensors for environmental monitoring. 

**KEYWORDS** MoS2; NO2 gas sensors; Light illumination; Heterojunction 

> * Mukesh Kumar, mkumar@iitrpr.ac.in 

> 1 Functional and Renewable Energy Materials Laboratory, Indian Institute of Technology Ropar, Rupnagar, Punjab 140001, India 

1 3 

**38** Page 2 of 58 

Nano-Micro Lett. (2021) 13:38 

### **1 Introduction** 

The earth’s environment consists of various chemical elements, gases, and dust particles such as  N2,  O2, CO,  CO2, NO2,  NH3. Among these gases,  O2, present in the environment is beneficial to living beings, while some gases, such as  CO2,  NO2, are toxic and dangerous. The presence of these toxic gases is majorly fixed in the environment. Among all toxic and dangerous gases,  NO2, a hazardous gas, acidic in nature, highly reactive with a stinky smell is continuously being produced and liberated in the atmosphere due to human activity [1–6].  NO2 is produced by fossil fuel burning, forest fires, industry and motor vehicles [7–9].  NO2 has recently become a matter of concern in Europe and Australia, owing to its increased concentration. The recent satellite data revealed an unprecedented increase in  NO2 concentration due to motor vehicles, power plants and wildfire in Europe and Australia in the year 2019 [10–14]. Moreover, after the worldwide outbreak of the novel COVID-19 virus, the lockdown was implemented in highly affected countries, which resulted in the shutdown of factories, manufacturing firms, and transport. This lockdown benefitted the world inadvertently with a dramatic reduction in  NO2 emissions. Importantly, the high reactiveness of  NO2 molecules with moisture and its tendency to create an acidic environment makes  NO2 production thought of concern [5, 15, 16]. It causes respiratory diseases beyond a certain  NO2 concentration limit in the environment, e.g. coronary assault, cancer, asthma, pneumonia, coughing and bronchitis [16–18]. The presence of  NO2 in the environment makes the air hazy and thick, which reduces the visibility of human eyes. In addition, the World Health Organization (WHO) reported that major cities around the world had failed to qualify the WHO’s air quality standards [19]. An estimated 30.7 million people died due to cardiovascular disease, cancer and chronic respiratory disease in 2016 [19, 20]. Thus, considering the toxicity and hazardousness of  NO2 gas, there is an urgent need to detect the precise levels of  NO2 gas in the environment. 

A hazardous gas in the environment can be detected by a gas sensor which is an electronic device having two-essential parts; a receptor unit and a transducer unit. Chemical information generated due to gas molecules exposure is gathered and stored in the form of chemical energy in the receptor device. The energy stored in the transducer component is 

transmuted to an analytical signal [21]. Hulanicki et al. categorized the gas sensors into six classes depending on the transducer mechanism: (1) electrochemical, (2) mass sensitive, (3) magnetic, (4) optical, (5) thermoelectric, and (6) electrical. The classification of gas sensors is carried out on the basis of their transducer operating principle. In today’s fast moving and unstoppable life, the rapid detection of low concentration of toxic gases is indispensable. Among all gas sensors, electrical transducer-based  NO2 gas sensor has grabbed the prime attention due to their easy handling, simple fabrication process, easy to connect with IOTs, real-time gas detection provision, low-cost and power consumptions, small size and long-term stability in harsh working conditions. In electrical or chemical resistance sensors, the resistance of the sensing material is changed due to charge transfer between the gas molecules and the sensing materials whenever the gas molecules are exposed to the sensing device. The chemiresistance gas sensors have extensive applications in  H2,  NH3, NO,  H2S,  NO2 gas detection in the environment, industry, cities, space science, transport, vehicles, cultivation, indoors, and various health sectors [22, 23]. Some figures of merits are specified to compare the performance of a gas sensor with different sizes, morphologies and operating conditions, i.e. sensor response, response and recovery time, and selectivity. Generally, sensor response is the ratio of change in resistance with exposure of gas molecules to the resistance of the film before the exposure of gas molecules. It is given by different forms of expression by _R_ <u>gas</u> many groups such as _S_ =<sup><u>(</u></sup><sup>_R_</sup><sup><u>gas−</u></sup><sup>_R_air)</sup> ;<sup><u>(</u></sup><sup>_R_air−</sup><sup>_R_</sup><sup><u>gas)</u></sup> ;<sup><u>(</u></sup><sup>_I_</sup><sup><u>gas−</u></sup><sup>_I_air)</sup> ; _R_ air _R_ air _I_ air _R_ air<sup>,</sup> _R_ <u>air</u> _R_ gas<sup>[17, 24–36]. Where,</sup><sup>_R_gas(</sup><sup>_I_gas ) is the resistance (current)</sup> of the sensing film in the presence of the gas molecules, _R_ air ( _I_ air ) is the resistance (current) of the sensing film in the presence of the air and S is the sensor response. The response time is the time taken by any gas sensor to attain 90% of the maximum sensor response when the gas is introduced to the sensor. The recovery time is the time taken by any gas sensor to reach 10% of the maximum sensor response when the gas is turned off. The capacity of a gas sensor to respond to a particular gas in the presence of other gases is called selectivity ability of the gas sensor. Usually, sensing films are sensitive to every gas present in the atmosphere at a same time. Also, some gases have nearly same sensor response for specific sensing film. It is therefore difficult to determine the exact change in the sensor response 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 3 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

generated by the target gas. Therefore, sensing film must be very selective for the target gas with highest sensor response. 

Graphene as a 2D material has some unique properties such as the large surface area (2360  m<sup>2</sup> g<sup>−1</sup> ), zero rest mass of charge carriers near Dirac points and high carrier mobility 200,000  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at room temperature (RT) [37–42]. Similarly, other 2D layered materials have numerous properties and applications in comparison to their bulk form [43–45]. The intriguing properties of 2D TMDCs are their high surface to volume ratio, absence of dangling bonds in the pristine form, strong spin–orbit coupling interaction and the high interaction ability for the gas molecules adsorption [46–52]. These features of 2D materials offer interest in exploring their new fundamental physics [32, 53]. The layer-dependent mechanical, electronic, and optical properties of 2D materials create curiosity to learn and explore their fundamental properties [54–56]. A one atom thick layer of graphene has shown an appealing role in gas sensing by detecting 1 ppb concentration of various gases such as  NH3,  NO2,  H2O, and CO [57]. Gas sensors based on graphene have been widely inspected and employed owing to its high carrier mobility, mechanical strengths greater than to steal, remarkable optical and electronic properties [58–60]. Despite having an impressive sensor response and response time, the  NO2 sensors have suffered from long recovery time owing to the very high adsorption energy of gas molecules with graphene [61–63]. In terms of growth and production, the synthesis of graphene is very costly with the use of toxic chemicals at high temperatures [64–67]. Another challenge associated with graphene is the production of high quality and large surface area graphene film, which is very difficult to attain and the presence of any non-carbon elements disrupts the hexagonality of graphene [68]. Moreover, graphene has zero bandgap, and less environment stability which reduces the gas-sensing performance and long term stability of graphene-based sensors [47, 69]. 

These limitations of graphene mold the direction of research to discover new nonzero bandgap 2D materials like MoS2,  MoSe2,  MoTe2,  WS2,  WSe2, BP, and many more [70–83]. The interaction between the gas molecules and sensing materials is the indelible part of any gas-sensing process. In 2D materials, especially  MoS2, is at the forefront in the race of an ideal gas-sensing material [84, 85]. The other substitutes of the 2D materials family are  WS2,  WSe2, NbSe2,  MoTe2, etc. [86–90]. However, most of the research on  NO2 detection is carried out with  MoS2.  MoS2-based gas 

sensors have achieved noticeable research interest in recent years.  MoS2 has already shown emerging environmental applications in energy storage, light interaction, flexible electronic devices and in biofield due to its semiconducting nature [50, 91–96].  MoS2 has two possible crystal phases, trigonal and hexagonal, where hexagonal is semiconducting while trigonal is having metallic nature [97]. The presence of weak Van der Waals force enables the easy isolation of layers from bulk  MoS2. The indirect bandgap of 1.2 eV in bulk  MoS2 is converted to a direct bandgap of 1.8 eV for monolayer  MoS2 [50, 98, 99]. The absence of dangling bonds provides stability to pristine  MoS2 flakes in liquid and gaseous media in the presence of oxygen. These facilities make  MoS2 compatible for gas-sensing application [100]. The low binding energy of 6.1 and 13.9 eV is needed to create S and Mo vacancies, respectively, which can turn the edges of  MoS2 flakes into metallic sites [101, 102].  MoS2 has a tunable bandgap compared to graphene which increases the overall sensing performance of  MoS2 film [103]. The  MoS2 flakes have strong photoluminescence (PL) absorption due to the presence of direct bandgap, helpful to design the optical gas sensors. The high on/off ratio  (10<sup>8</sup> ), the high carrier mobility of 400  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> at RT, low effective electron mass of 0.48  me are advantageous for developing fast gas sensors [54, 104–106]. Owing to these electronic properties, any minor change in the electron concentration of  MoS2 flakes can be easily detected.  MoS2 flakes have four Raman active modes ( _E_ 1 _g_ , _E_ 2<sup>1</sup> _g_<sup>,</sup><sup>_A_1</sup><sup>_g_,</sup><sup>_E_</sup> 2<sup>2</sup> _g_<sup>).</sup> The _E_ 2<sup>1</sup> _g_<sup>mode is an in-plane mode and</sup><sup>_A_1</sup><sup>_g_is an out of plane</sup> mode [107, 108]. Chakraborty et al. studied in situ Raman spectroscopy of single-layer  MoS2 flakes [109]. It has been found that _E_ 2<sup>1</sup> _g_<sup>is not sensitive to electron doping while the</sup> _A_ 1 _g_ mode is very sensitive to electron doping [109]. With higher electron concentration, the _A_ 1 _g_ mode gets soften due to stronger electron–phonon coupling mode than _E_ 2<sup>1</sup> _g_<sup>mode</sup> [109]. These vibrational characteristics are ideal for the chemiresistance gas sensors where charge concentration has remained an important parameter. Furthermore,  MoS2 film has impressive mechanical and optical properties with high Young’s modulus up to 300 GPa, deformity up to 11% without any fracture and amazing transparent nature, making it a potential candidate for optical and flexible devices [110–114]. Moreover,  MoS2 flakes can be bent up to the radius of 0.75 mm, without deteriorating its electronic properties [115]. Excellent gas molecules detection ability, 

1 3 

**38** Page 4 of 58 

Nano-Micro Lett. (2021) 13:38 

enormous active sites, large surface to volume ratio and presence of favorable adsorption sites have endorsed  MoS2 as the unique sensing material. The development and key accomplishment of  MoS2-based  NO2 gas sensors in last 8 years are summarized in Fig. 1. With the discovery of the 

graphene by mechanical exfoliation (ME) technique by the Geim and Novoselov, they further revealed in 2005 that the ME technique can also be employed to thin down the other bulk materials such as  MoS2 [43]. Following the uniqueness of the  MoS2, Li et al. developed the  NOx sensitive gas sensor 



<!-- Start of picture text -->
START<br>UV light<br>NO2 UV NO2 TS<br>e − H NO2 e − B<br>Au/Cr<br>Au/Cr<br>h +<br>2L MoS2<br>20 µm SiO2 Mo S NO2<br>Multi-layer MoS2<br>UV Driven in-plane Verification of favorable NO2<br>MoS2 NO2 sensor adsorption sites on MoS2<br>(a) Heater (a)<br>Sensor<br>Pt/Ti A LSN<br>Silicon<br>Substrate<br>Poly-Si 100 nm<br>Atomic layered MoS2<br>Au NPs decorated<br>Ultrasensitive<br>MoS2 NO2 sensors<br>MoS2/Graphene NO2 sensor<br>(f)<br>0.10e Basal + edge<br>exposed (5 nm)<br>Edge-site<br>(e) NO2 exposed (15 nm) MoS2 PET<br>Theorectical verification of Morphology driven Utilization of visible<br>NO2 interaction with MoS2 NO2 sensor spectrum in NO2 sensing<br>NO2δ−<br>∆SB1 A A + Bare MoS2 : S atom : S vacancy<br>With NO2<br>∆SB2 Vbi<br>SB NH3δ'+ EC<br>EF<br>Eg A 0<br>EV<br>Ti/Au MoS2 1.839 1.840 1.841 1.842 1.843 1.844 NIR light active SV-MoS2<br>Photon energy (eV)<br>S vacancy enriched MoS2<br>Effect of NO2 adsorption<br>Effect of NO2 adsorption<br>on fermi level and with NIR light<br>on optical properties<br>NO2<br>Source<br>2012 2017<br>2018<br>2013<br>2016 2018<br>2013<br>2015 2019<br>2014 2015<br>PL intensity (a.u.) FUTURE<br>2020<br>Drain<br><!-- End of picture text -->

**Fig. 1** Schematic representation of the 8-year journey of  MoS2-based  NO2 sensors. Reproduced with permission from Refs. [34, 118]. Copyright @ Wiley-VCH; Refs. [17, 32, 35, 36, 119, 120, 123]. Copyright @ American Chemical Society; Ref. [117]. Copyright @ Springer; Ref. [121]. Copyright @ AIP Publishing; Ref. [122]. Copyright @ Elsevier 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 5 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

[34]. In a similar year, He et al. developed the  NO2 sensor based on multilayer  MoS2 flakes and confirm the role of MoS2 in  NO2 detection [42]. The fundamental research to study the electronic properties of  MoS2 was boosted after the fabrication of first  MoS2 transistor by Kis et al. [116]. In 2013, Late et al. studied the role of negative and positive back gate voltage on  NO2 sensing by fabricating the  MoS2 field effect transistor (FET) [17]. The year 2014–2015 was devoted to the charge transfer mechanism due to the gas molecules exposure. Yue et al. investigated theoretically and confirmed that gas molecule detection in  MoS2 is attributed to the charge transfer process [117]. Liu et al. demonstrated that  NO2 gas adsorption strongly affects the Schottky barrier height (SBH) [36]. Cho et al. performed the in-situ PL spectroscopy and investigated the p-type doping in  MoS2 flakes due to  NO2 exposure [32]. 

Till 2015,  MoS2 has been established itself as the potential candidate for the gas sensing with a well-defined gassensing mechanism. However,  MoS2-based  NO2 sensors suffered from the incomplete recovery due to the high adsorption of  NO2 on  MoS2. Cho et al. studied the role of active sites in gas sensing [35].  NO2 adsorption is very high at the active sites in  MoS2. The active sites are highest at the edges due to presence of dangling bonds, defects and vacancies, while the terrace of  MoS2 is inert due to absence of dangling bonds. Authors synthesized  MoS2 flakes of three different orientations: in-plane  MoS2, mixed  MoS2 and vertical aligned  MoS2 flakes. The number of active sites and  NO2 sensing performance were highest in the case of vertical MoS2 flakes. Several studies have been published in parallel years for the fabrication of hybrid  MoS2 heterostructures to improve the charge transfer in  MoS2. Long et al. fabricated the low temperature  MoS2/graphene hybrid structure and develop ultrasensitive  NO2 sensors up to 50 ppb [118]. Although researchers have achieved full recovery at high temperatures, but the production of RT-recoverable gas sensors has remained a challenging task. 

Since 2017, light-assisted  NO2 sensors have attracted the worldwide scientific community. Rahul et al. in 2017, investigated the role of ultraviolet (UV) light in basal plane MoS2 flakes and achieved the full recovery at RT under UV light illumination. Agrawal et al. demonstrated the role of favorable  NO2 adsorption sites in  MoS2 by synthesizing the unique morphology of  MoS2 flakes [119, 120]. Metal NP doping has theoretically proven to be a great combination for enhanced gas sensor response, reactivity and recovery 

in the past years. Zhou et al. developed the  MoS2 sensor decorated with Au NPs [121]. It is important to remember that, until 2018, most of the published report used only UV light to boost the efficiency of the sensing light. In the next years, 2019 and 2020 (running) researchers fabricated the visible spectra and near infrared (NIR) spectra-driven  NO2 sensors [122, 123]. 

Thus we may conclude that gas-sensing characteristics of  MoS2 film-based device are highly dependent on size, shape, thickness, morphology, growth direction, polytype composition, defects, metal functionality and the hybrid structure of  MoS2 films. These factors can be used to classify  MoS2-based  NO2 sensors [25, 42, 124]. 

Apart from the experimental efforts, theoretical studies have also played a noticeable role in designing the experiments and predicting the gas-sensing potential of the proposed materials [125]. Theoretical methods such as density functional theory (DFT) always prove their advantage in terms of time, efforts and cost [125]. DFT provides a broad and detailed view to understand the fundamental mechanism happening between the gas molecules and the sensing material [126, 127]. The key features of DFT are the pre-calculation of the charge transfer and understanding of fundamental interaction between the sensing material and gas molecules. These features are helpful to understand the physical and chemical adsorption of gas molecules, theoretical estimation of defects, their effects on electronic and optical properties and functionalizing the defects with other materials and noble metals. Very few reviews are focused on both the theoretical contribution and the experimental contribution of  MoS2 for  NO2 sensing. 

The goal of this review is to discuss in detail the MoS2-based  NO2 gas sensors and to provide in-depth insights into previously established theoretical and experimental approaches. We focused on the various properties of MoS2 which played a vital role in gas sensing. Mainly, the role of 1T and 2H  MoS2 phases, large surface area available in  MoS2 film for gas molecule adsorption, faster charge transport in  MoS2, effect of modulating favourable adsorption sites via morphology, optical properties and defects available in  MoS2 will be discussed. 

Considering all these points, we have categorized various strategies for enhancing the performances of  MoS2 sensors as follows: role of device structure (resistor and transistor), monolayer  MoS2, multilayer  MoS2, defect tailoring, morphology engineering, heterostructures, functionalizing 

1 3 

**38** Page 6 of 58 

Nano-Micro Lett. (2021) 13:38 

with noble metals and light-assisted  NO2 sensors. We have focused our present review in the direction as mentioned above and a schematic view is shown in Fig. 2. 

We also focus a little bit on the traditional  NO2 sensing materials such as metal oxides and carbon-based nanomaterials to gain a clear difference between  NO2 sensing performance of traditional materials and  MoS2. 

A tremendous effort has been employed to develop fast, high sensor response, selective and low-cost  NO2 electrical sensors. Various nanomaterial-based sensors from zero dimension (0D, quantum dots) [128–135] to two dimensions (2D, metal oxides, TMDCs) [27, 81, 83, 136–138] showed their exceptional detection ability to detect parts per billion (ppb)  NO2 gas traces [139–143]. Every nanomaterials has its own merits and demerits in the  NO2 gas detection. The traditional metal oxides (ZnO,  SnO2,  TiO2,  In2O3,  WO3 etc.) based  NO2 sensors showed a fast response and high sensor response. However, the highly sensitive nature of metal oxides to humidity reduces the sensor response and stability of gas sensors. Moreover, for accelerating the interaction between the gas molecules and metal oxides, metal oxides gas sensors are need to operate at a higher temperature (250–500 °C). High temperature results in the agglomeration of nanomaterials and increase the grain size of the metal oxide film [28, 143–155]. On the contrary, the carbon material-based  NO2 sensors provide the high sensor response but at RT the desorption rate of gas molecules is too slow. Thus, the CNT-based  NO2 sensors are suffered from long 



<!-- Start of picture text -->
Recent Approach to develop near RT MoS2 NO2 sensor<br>Morphology driven Hybrid MoS2<br>MoS2 Film<br>MoS2-Metal Light assisted (UV to NIR)<br><!-- End of picture text -->

**Fig. 2** Schematic representation of strategies adopted to develop a high-performance  NO2 gas sensor based on  MoS2 flakes 

recovery time [30, 156–158]. In summary, metal oxide and carbon-based  NO2 sensors are suffered from thermal safety due to high temperature, structure complexity and complex device fabrication, which restricts the use of metal oxides in smart, wearable and next-generation device for the internet of things (IoT). 

The problems associated with metal oxide and carbonbased  NO2 sensor have demanded the development of new noble materials with advanced gassensing properties. In Fig. 3, we have summarized the  NO2 detection performance of various reported traditional materials-based sensors such as ZnO,  SnO2, CNTs,  TiO2,  In2O3  SnS2, and  WO3, in terms of operating temperature, sensor response and recovery time [26, 91, 154, 159–197]. Most of the traditional nanomaterial-based  NO2 sensors reported good sensor response at high operating temperatures (purple star) and simultaneously, they also suffered from the high recovery time (green circles). However, for an ideal gas sensor, it should be operated near RT for high sensing performances. The ideal sensor should have a high sensor response, lower response, and recovery time near to RT, as shown in star region of Fig. 3. Therefore, there is a great demand to develop a low temperature, highly sensitive and fast  NO2 sensors. 

The roadmap of the review is as follows. In Sect. 1, we introduced  MoS2 as the  NO2 sensors and addressed its benefits over the traditional metal oxide sensors. In Sect. 2, we will present some peculiar properties of  MoS2, which played a critical role in gas molecule adsorption. Section 3 is focused on the interaction mechanism of  NO2 with MoS2 and effect of  NO2 on electronic, optical and surface 



<!-- Start of picture text -->
30<br>420<br>25<br>20<br>295<br>15<br>170 10<br>5<br>45<br>0<br>15 140 265 390<br>Sensitivity (%)<br>Temperature (°C) High sensitive, fast speed sensorNear RT temperature<br>Rec. time×100 (sec)<br><!-- End of picture text -->

**Fig. 3** Traditional material-based  NO2 gas sensors. Most of the traditional  NO2 sensors have a high operating temperature requirement. The colored star area shows the ideal states for a gas sensor. Data has been taken from Refs. [26, 91, 154, 160–209] 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 7 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

properties. In Sect. 4, we will discuss several theoretical findings in which, interaction between  NO2 and  MoS2 is discussed. Section 5 covers the experimental reports where bare  MoS2, morphology-driven  MoS2, metal-doped  MoS2, vacancy-driven and photon-assisted  MoS2-based  NO2 sensors will be discussed briefly. In Sect. 6, we are going to present some findings where  MoS2-based heterostructures are utilized for  NO2 sensing. Finally, in Sect. 7, we will conclude our review and discussed the future of  MoS2-based NO2 sensor. 

### **2  MoS2: A Unique Material for Gas Sensing** 

##### **2.1  Structure of  MoS2** 

The single layer of  MoS2 has two polymorphs: trigonal prismatic (2H-MoS2 Phase) and octahedral phase (1T-MoS2 Phase), belonging to _D_ 3h and _D_ 3d point groups, respectively. Both polytype structures are shown in Fig. 4a, c [210]. Here, H and T depict hexagonal and trigonal symmetry, respectively, while digits equate to layers repeat per unit cells. In general, the 2H phase is obtained by synthesizing MoS2 film using methods such as mechanical exfoliation (ME), chemical vapor deposition (CVD) or ultrasonication [108, 211]. The 1T phase is preferred by the Li intercalation method. The 2H and 1T phases has been widely studied experimentally and theoretically. The 2H-MoS2 phase is semiconducting, while the 1T-MoS2 phase exhibits metallic nature. The varied electronic nature of  MoS2 can be understood using crystal field theory (CFT). In CFT, five d orbital _dx_ 2− _y_ 2 , _dz_ 2 , _dxy_ , _dyz_ and _dzx_ of transition metal (Mo) are non-degenerate. These d-bands are located between the bonding ( _휎_ ) and antibonding bands ( _휎_<sup>∗</sup> ), shown in Fig. 4b, d. In trigonal prismatic ( _D_ 3h), the orbitals splits into three levels, _dz_ 2 ( _a_ 1 ), _dx_ 2− _y_ 2 + _dxy_ ( _e_ ) and _dyz_ + _dzx_ ( _e_<sup>′</sup> ). The octahedral group divided into levels _eg_ having _dz_ 2 and _dx_ 2− _y_ 2 orbital and in _t_ 2 _g_ having _dxy_ , _dyz_ and _dzx_ [212]. When the highest orbitals are partially filled the  MoS2 possess the metallic like conductivity (1T-MoS2, Fig. 4d) and if the highest orbitals are fully filled,  MoS2 behave like semiconductor (2H-MoS2, Fig. 4b). In recent years, a lot of research work has been done on 2H-MoS2 phases in gas-sensing applications and many of them addressed in the next sections [17, 34, 35, 42, 120, 213, 214]. The 1T-MoS2 has higher active sites and electronic conductivity reaches up to sixfold higher 

than the 2H-MoS2 [99]. Mark et al. prepared a stable metallic phase of  MoS2 and they observed an enhanced catalytic performance in 1T phase [215]. In addition, the metallic MoS2 showed enhanced photoluminescence due to higher sulfur vacancies [99]. Furthermore, Kappera et al. studied the device performance of both phases and observed the low contact resistance at zero bias gate voltage. The low contact resistance generates high drive current with high mobility of 50  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> [216, 217]. These all properties showed that 1T-MoS2 is an important phase for  NO2 gas sensing. Thus, consideration of the role of both phases in  NO2 sensing is equally important. 

##### **2.2  Large Surface Area for Gas Molecule Adsorption** 

In contrast to metal oxides, the  MoS2 has a large specific surface area. The large surface area provides maximum adsorption sites for the adsorption of gas molecules and enhances the surface perturbation in the presence of gas molecules. Moreover, in chemiresistance gas sensors, sensor response is directly proportional to the change in the resistance arises due to the adsorption of gas molecules on the surface [42, 218]. Tongay et al. proposed that if one O2 molecule gets physiosorbed on the unit cell of  MoS2, it withdraws 0.04e per unit cell and the sheet charge density reduced up to 5 × 10<sup>13</sup> cm<sup>−2</sup> [219]. Therefore,  MoS2 is very sensitive and amenable to be used in gas-sensing devices. In this context,  MoS2 established himself as the promising chemical sensing material due to large highly sensitive surface. CVD, ME, and hydrothermal methods are the most popular methods for synthesizing  MoS2 for the gas-sensing devices. Among them, the most effective and occupied method to grow large size wafer-scale  MoS2 flakes is the CVD. We have prepared a comparative graph of flakes sizes with the two most prominent methods i.e., ME and CVD. It has been observed that individual flakes size grown by the ME method can go maximum up to 10 µm. However, with CVD,  MoS2 flakes of larger size can be grown in comparison with ME. It is worth to mention, we collected data of domain size of only individual  MoS2 single-layer flakes generated by ME and CVD methods for the data in Fig. 4e. CVD can grow highly uniform, high density, large area and control on morphology of the film while the ME can synthesize highly pure  MoS2 flakes, which is desirable for many electrical and optical applications. Agrawal et al. synthesized uniform 

1 3 

**38** Page 8 of 58 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
σ * (e)<br>(a) (b) dyz dxz 60 CVD<br>ME<br>dxy dx 2 − y 2<br>dz 2 EF<br>σ D3h<br>(c) (d) σ * 30<br>dx 2 − y 2 dz 2<br>EF<br>dxy dyz dzx<br>D3d<br>σ 0<br>H K Г A H<br>(f) (g) MoS2<br>Ambient<br>c 1 100x X O<br>X −<br>A B E't I Et O2 35x<br>v 1 H2O 10x<br>v 2<br>In vacuum<br>1.6 1.7 1.8 1.9 2.0<br>Recombination rate Energy (eV)<br>(h) G (i)<br>nr nr<br>X O X O<br>X + X −<br>peq p-WSe2 n-MoS2 neq<br>n-MoSe2<br>molecular physi-sorption 1 nm 10 nm<br>(j) (k)<br>Vs<br>2H-MoS2<br>(CVD)<br>Semiconducting<br>Large size<br>Flakes size (µm)<br>1T-MoS2 Metallic<br>Small<br>size (ME)<br>PL signal (a.u.)<br><!-- End of picture text -->

**Fig. 4  a** Schematic structure of 2H-MoS2. **b** _d_ -orbital filling of the semiconducting 2H-MoS2. **c** Schematic structure of 1T-MoS2. **d** _d_ -orbital filling of the semiconducting 1T-MoS2. **e** The reported domain size of individual monolayer  MoS2 flakes from the ME and CVD technique. CVD provides a larger flake size compared to the ME technique. The data of  MoS2 flakes size has been taken from Refs. [50, 107, 220, 222– 239]. **f** Band structure of  MoS2. The ‘A’ and ‘B’ PL peaks are corresponding to the direct bandgap ( _E_ g) transition of  MoS2. Reproduced with permission from Ref. [50]. Copyright (2010) American Physical Society. **g** Spectral change in PL due to exposure of  O2 alone,  H2O alone and with both.  O2 and  H2O incorporate p-type doping which contribute to a blue shift in the peaks. **h** Rate of recombination with neutral exciton and charge trion as a function of charge density in n-type  MoS2 and p-type  MoSe2. Reproduced with permission from Ref. [219]. Copyright (2013) American Chemical Society. **i** TEM image of the as grown vertical aligned  MoS2 flakes. The edges have high catalytic activity than the basal plane and enhance the reactivity of the gas molecules. Reproduced with permission from Ref. [240]. Copyright (2013) American Chemical Society. **j** STM image of the triangular  MoS2 flakes where yellow perimeters were showing the presence of the metallic states at the edges. Reproduced with permission from Ref. [241]. Copyright (2001) American Physical Society. **k** ADF images of monovacancy S intrinsic defects. Reproduced with permission from Ref. [242]. Copyright (2013) American Chemical Society 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 9 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

vertical  MoS2 flakes of 1 × 2  cm<sup>2</sup> size on  SiO2/Si substrate. Furthermore, Lin et al. synthesized large size  MoS2 flakes of 308 µm [220]. Zhan et al. synthesized the centimeter size MoS2 layer by CVD method [221]. The nucleation rate, supply of precursors, S and  MoO3 powder, temperature and the carrier gas flow rate, by CVD is mainly responsible for large area  MoS2 growth [221, 222]. CVD provides great control on the nucleation rate and mass transport.  MoS2 flakes size is increased with time as the more and more nucleation center and sites grow over substrate. Hence, CVD is the better option to grow the large area  MoS2 flakes and to fabricate the gas-sensing devices. 

##### **2.3  Impact of Gas Adsorption on Optical Properties of  MoS2** 

The photoluminescence (PL) is an essential characterizations to detect changed in the electron concentration of a 2D material-based gas sensor. Gas-sensing ability of 2D materials is governed by either electron depletion or accumulation that depend on the doping behavior of the exposed gas molecules. 

The nature of dopants critically affect the PL spectra of MoS2.  MoS2 has two well-reported PL peaks ‘A’ and ‘B’. These PL peaks are emerged due to the splitting of the valence band in _v_ 1 and _v_ 2 [50]. The valence band splitting at the K-point is the collective effect of interlayer spacing and spin–orbit coupling. Figure 4f displays the direct bandgap transition peaks (A and B) and indirect bandgap transition (I) in the  MoS2 crystal structure. The spectral weight of exciton and trions can be significantly tuned by the electrical gating, n-type or p-type molecular adsorption (e.g.  H2O, TCNQ) doping, and defects present at the cracks [219, 243–245]. 

Nan et al. studied the role of molecular adsorption on the PL through oxygen exposure [246]. Micro PL analysis revealed the enhancement in PL intensity due to molecules adsorption by  MoS2 surface at moderate temperatures in high vacuum ambient. The PL spectroscopy was performed over the as prepared monolayer  MoS2 films, which were annealed for 1 h in vacuum at 350 and 500 °C. It was observed that the PL intensity was increased sixfold after annealing at 350 °C with the blue shift in energy (from 1.79 to 1.81 eV). Moreover, the PL intensity in sample annealed at 500 °C was erratic at different locations. When the  MoS2 film was annealed at 350 °C, the  MoS2 film was uniform and 

environmental  O2 and  H2O physically got adsorbed by  MoS2 flakes. Both  O2 and  H2O introduced p-type doping in  MoS2. When the flakes annealed at 500 °C, cracks were formed in the film with the generation of defects. At these defects’ sites  O2 and  H2O adsorbed chemically and introduced heavy _p_ doping. DFT calculations were also performed and calculated charge transfer between the  O2 and pristine  MoS2 was 0.021e, while at the defects site, the charge transfer was 0.997e. Thus, higher charge transfers at the defective sites introduced heavy p-type doping. Tongay et al. also studied the modulation in the PL due to the physisorption of  O2 and  H2O molecules. Physiosorbed  O2 and  H2O molecules bonded weakly with  MoS2 but introduced significant p doping. The variation in PL intensity due to exposure of  O2 alone (green),  H2O alone (blue) and with both (red) shown in Fig. 4g [247]. The 0.04e and 0.01e times charges were transferred from  MoS2 to  O2 and  H2O molecules, respectively. The  O2 and  H2O molecules adsorption modulate the charge concentration in the  MoS2. The electrons of the n-type  MoS2 flakes are depleted by both molecules. Here, the focus has been given on the low energy exciton peak which is the combination of the neutral exciton ( _X_<sup>0</sup> ) and charge trions ( _X_<sup>+</sup> / _X_<sup>−</sup> ). In actual, the  MoS2 layer has high sheet charge density ( _n_ eq) . The high _n_ eq , destabilizes the neutral exciton X<sup>0</sup> due to electrostatic screening between the holes and free electrons while the _X_<sup>−</sup> stabilizes due to high recombination rate of _X_<sup>−</sup> trions [248]. Hence, with high _n_ eq , the overall PL intensity becomes low. With physisorption and chemisorption of molecules such as  O2 and  H2O, the _n_ eq gets reduced. Hence, the number of electrons available in  MoS2 for trions formation is decreased. Thus, the intensity of _X_<sup>−</sup> decreased and _X_<sup>0</sup> enhanced with more stabilization, as can be seen from Fig. 4g, h. Moreover, it has been reported that the electronic gating and molecular doping can dramatically tune the PL [219, 244, 245, 249]. As the gas molecule adsorption introduces n or p doping, the study of PL with adsorption of molecules to  MoS2 is an important aspect to understand the nature of the gas molecules. 

##### **2.4  High Catalytic Nature and Presence of Metallic States** 

Another essential feature of  MoS2 is the presence of a large number of active sites for promoting the chemical reactions. Jaramillo et al. identified the active sites on the  MoS2 through 

1 3 

**38** Page 10 of 58 

Nano-Micro Lett. (2021) 13:38 

scanning tunneling microscopy (STM) [250]. The  MoS2 samples were synthesized on the Au substrate and STM imaging was performed in the ultra-high vacuum. The STM measurements confirmed that flat  MoS2 edges have bright rims which appeared as bright lines along the flakes perimeter. To validate the high activity of the edges, the hydrogen evolution reactions (HER) activity was investigated which also confirmed the high reactivity of edges. Kong et al. synthesized MoS2 by the sulfurization of Mo film deposited by e-beam lithography. The tunneling electron microscopy (TEM) image of vertical aligned  MoS2 flakes is shown in Fig. 4i and in inset. It is evident from these studies that edges have highly active site. Thermodynamically, the growth of in-plane  MoS2 is highly probable than the edge oriented  MoS2 flakes. The high activity of the edges boosts the motivation to grow edgeenriched film by forming the various morphology of  MoS2 nanoflakes such as vertical aligned  MoS2,  MoS2 nanowires, MoS2 spheres etc. Kim et al. fabricated 2D  SnS2 and develop NO2 sensor by enhancing the active sites [251]. The vertically aligned  SnS2 showed high  NO2 reactivity due to the presence of a large number of active sites in comparison to the basal plane  SnS2. Shim et al. synthesized  SiO2 nanorods (NRs) and decorated them with  MoS2 flakes [252]. These  SiO2 NRs enhanced the catalytic activity of  MoS2 flakes by exposing more edges of  MoS2 flakes [251]. Hence, the  NO2 detection ability of  SiO2 NRs encapsulated with  MoS2 is increased. The MoS2 surface has maximum number of active sites which enhance the chemical activity of  MoS2 film [240, 253, 254]. Another important feature of  MoS2 flakes is the presence of metallic states at the edges [241]. The  MoS2 edges behaved as the one-dimensional metallic wires and appeared as the bright brim of high conductance, as shown in Fig. 4j. The attention here is given to Mo edges having S dimers. The Mo edges have two metallic wave functions and generate metallic states in  MoS2. Therefore, the presence of metallic edges will be helpful in the fast transfer of generated electron and holes. The generated charge can be rapidly transferred along the edges in edge-enriched  MoS2 and will be helpful in developing the fast responsive and recoverable gas sensors [255]. 

##### **2.5  Impact of Gas Molecules Adsorption on Schottky Barrier Height** 

The gas-sensing performance of 2D materials based on chemiresistance gas sensors is critically influenced by the 

metal contacts [256–259]. In 2D materials, the gas molecule adsorption affects the charge concentrations and carrier density. Depending on the nature of the gas molecules, the charge carrier density either increases or reduces and Fermi level of 2D materials is modulated with gas molecule adsorption. The equilibrium Fermi level of metal and semiconductor before and after exposure to the gas molecule will be different due to variation in the charge carrier density in the sensing film. In chemiresistance sensors, the Schottky barrier height between the metal contact and the 2D material surface can alter the surface charge transfer mechanism. Various studies have been reported to understand the role of Schottky barrier height (SBH) and Schottky barrier modulation (SBM) with gas molecule exposure in traditional gas sensors as well as in 2D material-based gas sensors [260, 261]. The band structure of metal and semiconductor can be divided into two regions: (1) alignment of the energy levels of the metal and semiconductor for charge carrier injection and (2) band bending at the space charge region for charge carrier separation [262]. If the metal and semiconductor work functions are ∅ _M_ and ∅ _S_ respectively, the SBH determined by the Mott–Schottky rule is given by Eq. (1): 



<!-- Start of picture text -->
� b = � M  − 휒S<br><!-- End of picture text -->



<!-- Start of picture text -->
(1)<br><!-- End of picture text -->

Depending on the type of the semiconductor (n-type or p-type), the Schottky or ohmic contact nature of the junction is decided. In 2D materials, ohmic contacts are of great importance due to their low resistance and high charge transfer in terms of high mobility and current on/off ratio [104, 263, 264]. However, the ohmic contacts are not beneficial for gas-sensing point of view. The reason for this is the interaction of gas molecules with sensing film and their effect on the Schottky barrier modulation (SBM) [36, 72]. The importance of the Schottky contact is well established in the metal oxide sensors. Zhou et al. demonstrated the remarkable performance of the ZnO sensors by utilizing the Schottky contact in comparison to the ohmic contact [265]. Similarly, Wei et al. fabricated the ZnO NW-based CO sensor in such a way that one end behaved as the Schottky contact, while the other end behaved as the ohmic contact [266]. Schottky end behaves like a gate terminal and the Schottky barrier height (SBH) was tuned. Nearly 4 times enhanced sensor response with seven times reduce response and recovery time were observed. In all these reports, SBM provides an efficient and enhanced charge transport. Hence, gas-sensing performance is high in the Schottky contacted devices. 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 11 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

##### **2.6  Role of Defects in Gas Molecule Adsorption** 

In case of  MoS2, defects can be generated during the synthesis or transfer of  MoS2 due to synthesis imperfections [267–270]. In addition, these defects are susceptible to ambient environments conditions [271, 272]. Defects can also be created through the irradiations, metal doping and functionalization [273, 274]. Thus,  MoS2 structures unavoidably have various defects in terms of vacancies, dopants, adsorbates, adatoms, and impurities. On the contrary, the pristine MoS2 is assumed to have defect free surfaces. However, the synthesis of defect free  MoS2 flakes is quite difficult and convoluted. Defects are easily produced during the synthesis process. Defects crucially affect various mechanical, electronic, optical and catalytic properties. Zhou et al. fabricated MoS2 and studied the possible structural defects [242]. The authors studied atomic-resolution annular dark field (ADF) images of CVD-grown  MoS2 flakes. The defects were classified into six types (i) mono-sulfur Vacancies  (VS), (ii) di-sulfur vacancies  (VS2), (iii) Mo atom with three nearby sulfur  (VMoS3), (iv) Mo atom with three di sulfur pairs (VMoS6), (v–vi) Antisite defects, Mo atom at S vacancy site (MoS2) and S atom at Mo vacancy site  (S2Mo). The formation energy of these vacancies is studied in term of S chemical potential. The formation energy plot revealed that mono S vacancies are most probable and need lowest formation energies. The ADF image of S vacancy site is shown in Fig. 4k. These defects could play a crucial role in the gas molecule adsorption. The benefits of defects in graphene have already received great attention [275, 276]. The findings of the reports revealed that the sensing mechanism in pristine and defective graphene is completely different. The defective graphene has higher interaction with gas molecules due to the presence of the defects. Interestingly in  MoS2, defects can greatly influence the gas-sensing properties [86, 277]. Moreover, doping defects with substitutional impurities atoms can greatly improve the  MoS2 sensing performances. The effect of dopant and impurities is also well established in graphene. Zhang et al. studied the sensing performance of graphene-doped B, N, Si, Ca, Co and Fe, defective graphene and on pristine graphene [278]. The defective graphene doped with Ca, Co and Fe showed the highest interaction with  H2S molecules. In metal-doped graphene, mixing of the graphene orbitals and metals orbitals is enhanced with  H2S orbitals which leads to the strong interaction. 

- **3  Charge Transfer Mechanism Between  NO2 and  MoS2: Effect on Electronic Properties, Optical Properties, and Metal Contacts/ MoS2 Interface** 

In the present section, the nature and effect of  NO2 gas molecules on electrical conductivity, PL and  MoS2 band alignment will be addressed.  NO2 is a secondary product generated from the primary NO source as shown by Eq. (2) [279]. 2NO + O2 → 2NO2 (2) 



<!-- Start of picture text -->
(2)<br><!-- End of picture text -->

NO2 has the electron acceptor nature and behaves as a strong oxidizing agent due to the unpaired electrons of nitrogen atom.  NO2 molecules take the electrons from the sensing materials. Generally, a chemiresistance gas sensor has a sensing layer that detects the presence of interacting gas molecules. The electrical and optical properties changes depending on the nature of interacting gas molecules and the type of semiconducting film. The gas molecules that interact can either behave like a reduction gas (electron donor) or an oxidizing gas (electron acceptor). Similarly, the semiconductor film may also have an n-type or a p-type nature. 

In the case of TMDCs materials, gas molecules interaction depends on the nature of TMDC film and gas molecules. The interaction of gas molecules with TMDC film is governed via the physisorption or chemisorption process. The physisorption process occurs with pristine TMDC film while the chemisorption process happens with defective TMDC layers and on the defect sites. 

In the case of pristine TMDC films, the gas molecules and TMDC films interact through the physisorption process. The gas molecules have weak adsorption energy and long adsorption distance with pristine TMDC film. Moreover, there is a less charge transfer between the gas molecules and TMDC film with an almost unchanged electronic structure. Hence, gas sensors based on pristine TMDC films have fast recovery but with low sensor response. The physisorption-based gas sensing reported in  SnS2 [175]. The  SnS2 showed a highly selective nature for  NO2 molecules due to the physisorption process. Furthermore, the positive binding energy of  O2 molecules with the  SnS2 surface indicated high surface resistance for oxygen molecules and supported that  NO2 sensing response in  SnS2 was through the physisorption process [175]. 

1 3 

**38** Page 12 of 58 

Nano-Micro Lett. (2021) 13:38 

In the case of the chemisorption process, defects induce during the synthesis of  MoS2. The gas molecules interact chemically with  MoS2. The chemical interactions of gas molecules enhance gas-sensing performances of sensing material. The adsorption distance between the gas molecules and the adsorption sites is minimal in case of the chemisorption process. Hence, high charge transfer, strong adsorption energy, and significant change in the electronic states have been observed. The charge transfer schematic of  NO2 with the  MoS2 film (n-type or p-type) is shown in Fig. 5a and Eq. (3). 



<!-- Start of picture text -->
NO2 + e − → NO − 2 (3)<br><!-- End of picture text -->

Cho et al. experimentally verified the charge transfer mechanism between the  MoS2 and  NO2 gas molecules using PL spectroscopy [32]. The authors synthesized n-type MoS2 film by the chemical vapor deposition technique. The authors exposed  NO2 gas to  MoS2 film and investigated the charge transfer mechanism using photoluminescence (PL) spectroscopy. The authors observed that with  NO2 exposure, 

the resistance of the n-type  MoS2 film increased (positive sensor response). The increment in the resistance confirmed that  NO2 withdraws the electrons from the n-type  MoS2 film. NO2 gas molecules exposure modulates the electron concentration in  MoS2. The change in the electron concentrations dramatically affects the PL. The  MoS2 has two main PL exciton peaks named as ’A’ and ’B’ [50]. The intensities of these two PL peaks can either decreased or increased with a change in the electron concentrations [243, 244]. The low energy PL peak ’A’ can be expanded into a charged trions ( _A_<sup>+∕−</sup> ) and in neutral exciton ( _A_<sup>0</sup> ). The  MoS2 flakes grown on the  SiO2 substrate showed dominated behavior of _A_<sup>+</sup> peak over _A_<sup>0</sup> . Hence, the authors considered the positively charge trion peak ( _A_<sup>+</sup> ) and neutral exciton peak ( _A_<sup>0</sup> ). As  NO2 has an electron acceptor nature, it takes the electron from the MoS2 and intensity of the ( _A_<sup>+</sup> ) enhanced due to conversion of neutral exciton in ( _A_<sup>+</sup> ). Actually, the numerous number of holes generated in  MoS2 due to depletion of electrons by NO2. Therefore, intensity of _A_<sup>+</sup> trions enhanced and neutral exciton suppressed. Similar behavior is observed in the PL spectroscopy, shown in Fig. 5b. The effect of  NO2 exposure 



<!-- Start of picture text -->
(a) e − NO2δ−<br>(c) e − NO2δ− (d)<br>∆ESBNO2δ−<br>Ec<br>VBuilt-in<br>Ec Eg SB Eg<br>EF EF<br>EV EV VBuilt-in ∆ESBNO2δ− SB<br>n type MoS2<br>p-MoS2 n-MoS2<br>p type MoS2<br>Increase Resistance Decrease<br>(b) A A + Bare MoS2 (e) TM<br>(Top of Mo atom)<br>With NO2<br>TS<br>(Top of S atom)<br>A 0<br>B H<br>1.839 1.840 1.841 1.842 1.843 1.844 (Top of Mo-S bond) (Top of Hexagon)<br>Photon energy (eV)<br>e−<br>withdrawn<br>PL intensity (a.u.)<br><!-- End of picture text -->

**Fig. 5  a** Schematic interaction of  NO2 gas molecules with the n-type or p-type  MoS2 layer.  NO2 captures the electrons from  MoS2 layer. **b** Effect of  NO2 molecules adsorption on PL spectra. The spectral weight of positively charged trions is increased on the cost of excitons spectral weight in n-type  MoS2. Reproduced with permission from Ref. [32]. Copyright (2015) American Chemical Society. Schottky barrier height modulation after  NO2 molecules adsorption in **c** n-type  MoS2 **d** p-type  MoS2. **e** Four possible  NO2 adsorption sites on  MoS2. Reproduced with permission from Ref. [255]. Copyright (2017) AIP Publishing 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 13 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

on the Fermi level of n-type and p-type  MoS2 flakes is shown in Fig. 5c, d.  MoS2 can have both types of semiconducting nature. In both cases,  NO2 exposure depletes the electrons from the  MoS2 and manipulate the charge density in the conduction band. Due to electron extraction, the Fermi level in the n-type  MoS2 film moves downward toward the valence band and correspondingly the SBH and resistance increased. When  MoS2 film has the p-type nature, holes majority increased with  NO2 exposure. The Fermi level move toward the conduction band and SBH and resistance decreased. Thus,  NO2 adsorption critically affects the electronic as well as the optical properties of  MoS2. 

Yue et al. theoretically investigated the adsorption of several molecules using DFT on  MoS2 such as  H2,  O2,  H2O, NH3, NO,  NO2, and CO [117]. Theoretically, gas adsorption behavior is determined by the few terms namely: favorable adsorption sites on  MoS2 for particular gas molecule, distance between the gas molecule and the  MoS2 layer, the binding energy of gas molecule on the  MoS2 layer, charge transfer between the gas molecules and  MoS2 layer, and direction of charge transfer. For adsorption of any gas molecule on a sensing surface, there should be a strong favorable interaction between the gas molecules and  MoS2 flakes, and it should be adsorbed physically or chemically. This interaction is determined in terms of adsorption energy, calculated by Eq. (4): 



<!-- Start of picture text -->
E a =  E MoS2+molecule − ( E MoS2 +  E molecule) (4)<br><!-- End of picture text -->

where _E_ a is the adsorption energy, _E_ MoS2+molecule is the total energy of  MoS2 and the adsorbed gas molecule. _E_ MoS2 and _E_ molecule are the energy of the  MoS2 film and single gas molecule, respectively. For a strong interaction, the adsorption energy should be negative and the interaction process should be exothermic. Another term is the charge transfer process. The charge transfer process depends on the relative position of the highest occupied molecular orbitals (HOMO) and lowest unoccupied molecular orbitals (LUMO). If the Fermi level is below the HOMO, then charge transfer from molecule to sensing surface and gas is called the electron donor, and if the Fermi level is above the LUMO, then the charge transfer from sensing surface to molecule and gas called is the electron acceptor [280]. 

As mentioned above, the adsorption of the gas molecule is determined in terms of favorable adsorption sites. The gas molecules adsorption are highly position dependent in the case of  MoS2 due to the difference in the adsorption energy and charge transfer for gas molecules at different adsorption 

sites on  MoS2. The monolayer of  MoS2 has a hexagonally packed structure where Mo atoms are sandwiched between the two layers of S atoms. There are four possible adsorption sites, the H sites (Top of the hexagon),  TS (top of S atom),  TM (top of Mo atom), and B (top of Mo and S bond). The possible sites configurations are shown in Fig. 5e. In the case of  NO2, three different  NO2 molecules orientations have been considered with these four sites, starting from one N atom with N–O bonds parallel to monolayer, two with NO-bonds pointing up or down to monolayer. After the gas molecule adsorption on  MoS2,  MoS2 structure with adsorbed gas molecules is reached to the equilibrium state with the highest adsorption energy. 

The minimum distance between the adsorbed gas molecule and the relaxed  MoS2 surface is called as equilibrium height. The importance of distance between the  NO2 and top S layer of  MoS2 is also studied and investigated by Yue et al. The highest adsorption energy was found at an equilibrium height of 2.71 Å. It has to be noted that the highest adsorption energy is negative for adsorption of  NO2 on  MoS2, confirming the favorable adsorption of  NO2 on  MoS2. Among all, depending on the charge transfer and adsorption energy, the most favorable  NO2 orientation was estimated. The H, TS, and B sites (− 276, − 249, and − 249 meV, respectively) found favorable for  NO2 adsorption while no adsorption on  TM site was observed. The high adsorption energy was attributed to polarization produced in the  MoS2 sheet during NO2 adsorption. Hence, the interaction was determined by the electrostatic force and lead to strong adsorption energy. From the adsorption energy calculations, the highest favorable  NO2 adsorption site is at the H site. The charge transfer from  MoS2 to  NO2 was found to vary from 0.1e to 0.119e. The positive charge transfer value implies the transfer of charge from  MoS2 to  NO2. The difference in the charge density due to  NO2 exposure further confirmed the charge accumulation and depletion profile. The effect of  NO2 molecule on energy band structure is also studied and it has been found that the adsorbed  NO2 molecule introduces an unoccupied flat impurity state at 0.31 eV above the Fermi level in the conduction band of  MoS2. The used method, supercell size, lattice parameters and available favorable adsorption sites for  NO2 molecules adsorption on  MoS2 by Yue et al., are tabulated in Table 1. Another important aspect of the work is the study of the applied electric field on the NO2 adsorption on  MoS2. The charge transfer mechanism 

1 3 

**38** Page 14 of 58 

Nano-Micro Lett. (2021) 13:38 

**Table 1** Method, supercell size (S.S), lattice parameter (L.P) and favorable adsorption sites on  MoS2 calculated by Yue et al. using DFT [117] 

|Method|S. S (L.P)|H-site|||TS-site|||B-site|||Reference|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||d|_E_a|Δ_Q_|d|_E_a|Δ_Q_|d|_E_a|Δ_Q_||
|VASP (LDA)|4 × 4 (3.12)|2.65|− 276|0.1|2.71|− 249|0.119|2.62|− 249|0.114|[117]|



between the adsorbents and absorber is the key to the gas molecule adsorption. 

The amount of charge transfer is very sensitive to the electric field. The applied electric field is considered in two perpendicular directions (i)  MoS2 to  NO2 molecule (+E) and (ii)  NO2 to  MoS2 molecule (− E). The charge transfers from  MoS2 to  NO2 increase with an increase in the positive electric field and it tends to decrease when the direction of the field is reversed. The negative electric field forces the electrons to transfer from  NO2 to  MoS2. The external electric field and dipole moment direction are well correlated with each other. Hence the direction of the electric field is greatly affected by the charge transfer values. 

### **4  Theoretical Investigations of  NO2 Adsorption on  MoS2** 

Here, we discuss the reports where the interaction of  NO2 on MoS2, the role of  MoS2 polytype and metal doping investigated theoretically. 

##### **4.1  Adsorption of  NO2 Gas Molecules on Defective MoS2** 

In the present section, we will discuss some theoretical reports in which adsorption of  NO2 is studied on the defective  MoS2. The two types of defects are considered mainly in  MoS2 the monosulfur vacancies and the Mo-doped S vacancy sites. 

Owing to the chemical interaction of  NO2 with  MoS2, the adsorption mechanism is governed by the chemisorption mechanism. Li et al. used DFT to study the adsorption of NO2 molecule on the single S vacancy site [281]. Initially, the effect of vacancies on the electronic structures was studied. The schematic of a  MoS2 unit cell is shown in Fig. 6a. The bandgap with a single S vacancy in  MoS2 was decreased up to 1.07 eV [282, 283]. The S vacancies in 2D materials create midgap states which reduce the bandgap of  MoS2. 

These states arise due to the unsaturated Mo atoms near the vacant S sites [284]. When  NO2 molecules are adsorbed to the  MoS2 surface, the  NO2 molecule dissociates at the S vacancy sites into NO and O. The dissociated NO has a bond length equivalent to the free NO molecule. Hence, the dissociated O atom is adsorbed on the single S vacancy site and the other part NO is physiosorbed on the O-doped  MoS2. The activation barrier energy and transition states were also calculated. The activation energy of  NO2 dissociation was 0.21 eV and the reaction energy was 2.30 eV, as shown in Fig. 6b. This energetically favored the  NO2 dissociation process. Furthermore, adsorption energy of physiosorbed NO was 0.44 eV which is minimal and facilitates desorption of NO2 molecules from  MoS2. 

Sahoo et al. doped Mo atoms on S vacancy sites, and enhanced adsorption of  NO2, as shown in Fig. 6c, d with a red circle [285]. This type of doping is termed as antisite defects ( Mo _S_ ) in  MoS2 (A-MoS2). The insertion of Mo atoms at the S defects sites are highly probable with physical vapor deposition techniques. A-MoS2 may be an innovative method to improve the sensor response, selectivity, and sensing performance of the  MoS2 sensor. The insertion of Mo atom at the S vacancy site generates the three midgap states, two states are at -0.02 and -0.11 eV below the Fermi level and the third state above the Fermi level at 0.28 eV. Actually, 4d orbitals of antisite Mo atom is splitted into three states; a ( _dz_<sup>2 ) state lies above the fermi level, twofold degenerate</sup> _e_ 1( _dxy_ , _dx_ 2− _y_ 2 ), and _e_ 2( _dyz_ , _dzx_ ) due to the _C_ 3 _v_ symmetry, lies below the Fermi level. It is worth to note that _e_ 1 state splits into _e_ ′1<sup>and</sup><sup>_e_</sup> ′′1<sup>levels due to the John Teller distortion while</sup><sup>_e_2</sup> lies well below the valence band. The corresponding density of states (DOS) and partial density of states (PDOS) of Mo antisite-doped  MoS2 without  NO2 and with  NO2 exposure are shown in Fig. 6e. Finally, when  NO2 gas molecules are exposed to A-MoS2, the  NO2 interaction process is highly exothermic and higher charge transfer takes place in A-MoS2 in comparison to the pristine  MoS2. The paramagnetic  NO2 molecules are adsorbed in the tilted configuration. The strong mixing of antisite defect Mo _S_ and of  NO2 orbitals are 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 15 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(a) (b)<br>Mo<br>TS<br>Ea  = 0.21 eV<br>Mo<br>IS<br>Mo<br>FS<br>e1'  e1'' a<br>(c) (d) (e) 40 A-MoS2 TDOS N-p<br>20 O-p<br>C-p<br>0<br>60 A-MoS2/NH3 0.3<br>40 0.2<br>20 0.1<br>0 0.0<br>40 A-MoS2/NO2 2<br>20 1<br>0 0<br>40 A-MoS2/NO 8<br>20 4<br>0 0<br>6<br>100 A-MoS2/CO 4<br>50 2<br>0 0<br>40 A-MoS2/CO2 0.04<br>20 0.02<br>0 0.00<br>−2 −1 0 1 2<br>E−EF (eV)<br>2.30 eV<br>DOS (States/eV)<br>PDOS (a.u.)<br><!-- End of picture text -->

**Fig. 6  a** Structure of defected  MoS2. Black circles represent the S vacancy sites. **b** Dissociation of  NO2 onto the S vacant  MoS2. MoS . Reproduced with permission from Ref. [281]. Copyright (2016) The Royal society of chemistry. **c** Top view of pristine  MoS2 **d** Mo-doped S Antisite defects  (MoS) **e** DOS and PDOS of monolayer  MoS2 with Antisite defect-doped  MoS2 with gas molecules exposure. Reproduced with permission from Ref. [285]. Copyright (2016) American Chemical Society 

responsible for high charge transfer and strong adsorption energy. The p orbitals of N and O atom of  NO2 molecules are strongly hybridize with the three new mid gap states generated due to the antisites Mo _S_ defects. The DOS and PDOS states of A-MoS2 confirmed this behavior. The strong hybridization occurred between the  NO2 molecule and with three new mid gap states which enhanced the charge transfer. 

##### **4.2  Adsorption of  NO2 Gas Molecules on 2H‑MoS2 and 1T‑MoS2 Polytype** 

The two polytype of  MoS2, 2H-MoS2, and 1T-MoS2 have their own advantages in  NO2 sensing. Both polytypes have distinct electronic nature of semiconductors (2H-MoS2) and metallic (1T-MoS2). Here, in this section, we will enlighten the role of both pristine phases and defective phases  MoS2 in  NO2 sensing. Linghu et al. has compared the  NO2 sensing 

performance of pristine 2H-MoS2 and pristine 1T-MoS2 [286]. The 1T-MoS2 has shown promising sensing performances in comparison to the 2H-MoS2. The geometric optimization revealed that  NO2 has a closer and stronger interaction with the 1T-MoS2 phase than the 2H-MoS2. The calculated adsorption energies for the 2H-MoS2 and 1T-MoS2 phases are -0.21 eV and − 0.25 eV, respectively, reasonable to assume the higher  NO2 interaction with the 1T phase. The higher adsorption energy comparative to 2H -MoS2 confirmed the higher and closer interaction in 1T MoS2. 

Taking a step further, Linghu et al. studied the role of defects in both 2H and 1T polytype and found again that defective 1T-MoS2 is superior in  NO2 adsorption [287]. The single S vacancy defects are considered in both phases due to their low formation energy requirement. 

Figure 7a, b demonstrates the geometric perspective structure with S vacancy of 2H and 1T  MoS2. The S 

1 3 

**38** Page 16 of 58 

Nano-Micro Lett. (2021) 13:38 

vacancies in both 2H and 1T phase affect the electronic structure of the  MoS2. S vacancies introduced mid gaps states and further reduced the  MoS2 bandgap. Moreover, the metallic behavior of 1T-MoS2 is increased due to these mid gap states. The band structure of 2H and 1T  MoS2 of pristine and defective  MoS2 are shown in Fig. 7c–f. When NO2 is exposed to these polytypes, it dissociates in NO and O, as shown in Fig. 7g, h. The O atom tri-coordinated with the neighboring three Mo atom and occupied the S vacancy site and NO gets physisorbed on  MoS2. The variation of adsorption energy with different molecules is shown in Fig. 7i. The red encircled values depict the  NO2 adsorption energies. 

##### **4.3** **_Theoretical Adsorption of NO2 Gas Molecules on Metal‑Functionalized MoS2_** 

The absence of dangling bonds makes the pristine monolayer  MoS2 surface defects free. However, the defects are highly probable and S vacancies are the most favorable defect due to the less energy required for their formation [102, 288–290]. There are various experimental reports in which S defects have been controlled by using the argon and electron irradiation. Filling these mono vacancy sites with substitutional atoms can be a promising way to enhance the chemical, electrical and optical properties of  MoS2 layers [289, 291]. These vacancy sites have been filled with various metal atoms such as Cr, Nb, V, and N, experimentally and the electronic and chemical activities of  MoS2 layers changed dramatically [291–293]. Yuan et al. doped graphene with Al, Si, Cr, and Mn and studied the oxygen adsorption on the metaldoped graphene using DFT. The metal doping tuned the adsorption interaction of oxygen with carbon atoms of graphene. The bonding of the metal atom with the carbon atom is a responsible factor for enhance oxygen adsorption on the doped graphene [294]. Lu et al. embedded the graphene with Au and investigated the CO oxidation using DFT [295]. Au embedding reduces the reaction barrier and increases the oxidation rate of the CO on Au embedded graphene. Similarly, the inert 2D materials surface can be changed to a highly active surface for gas interaction due to the bonding of 2D materials with metal atoms. 

Therefore, metal doping has a great impact on the electronic and gas-sensing properties such as adsorption energy, charge transfer, the direction of charge transfer and interaction of gas molecules with the  MoS2 surface. The choice of appropriate metal for a particular gas will strongly modulate the chemical activity, selectivity and sensor response of the  MoS2 surface. 

Fan et al. investigated the effect of transition metals (Fe, Co, Ni, Cu, Ag, Au, Rh, Pd, Pt, and Ir) doping on  MoS2 flakes for various gas molecules adsorption (CO, NO,  O2, NO2, and  NH3). The effect of transition metal doping in the absence of the gas molecules has been systematically studied. All the mentioned metals have been doped on the mono-sulfur vacancy site due to the low formation energy of S vacancies in comparison to other vacancies such as Mo vacancy, dia Mo vacancy and antisite vacancies [102, 288–290]. The equilibrium height (M-Mo) is taken from the metal atom and S atom plane. The stability of the metal embedded  MoS2 in terms of binding energy and charge transfer was tested to have a better grasp. The binding energy ( _E_ b ) between the metal atom and unexposed  MoS2 is calculated by Eq. (5): 



<!-- Start of picture text -->
E b =  E MoS2 +  E metal − E MoS2+metal<br><!-- End of picture text -->



<!-- Start of picture text -->
(5)<br><!-- End of picture text -->

The highest binding energy (energy required to bind the metal atom on the S vacant  MoS2) was found 5.21 eV for Pt metal atoms and the lowest for 1.98 eV for the Ag atoms. The maximum charge 0.36e was transferred from Fe metal to  MoS2 and the lowest − 0.34e to Pt metal atom from  MoS2. The negative charge value means transition metals obtain the electrons from the  MoS2 and vice versa for positive charge value. The binding energy and charge transfer values mentioned above are without  NO2 exposure. The charge depletion and accumulation between the metals and  MoS2 are due to the Pauling electronegativity. For the case of  NO2 adsorption on the metal-doped MoS2 sheet, two different modes were obtained after the relaxation of the exposed  MoS2 system. One mode is with Fe, Co, Cu, Ag, and Au embedded  MoS2 system via bonding of two O atoms with transition metals forming TM–O–N–O (four membered ring). The other mode is the bonding of  NO2 with Ni-, Rh-, Pd-, Pt-, and Ir-doped MoS2 in which N-atom bonded with the transition metal. The adsorption energies and charge transfer in case of NO2 adsorbed on the metal-doped  MoS2 are tabulated in 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 17 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(a) (b)<br>VS<br>VS<br>(c) 1.5 (d) 1.5<br>1.0 1.0<br>0.5 2H-Pristine 0.5 1T'-Pristine<br>0.0 0.0<br>−0.5 −0.5<br>−1.0 −1.0<br>−1.5 −1.5<br>Γ M K Γ Γ M K Γ<br>(e) 1.5 (f) 1.5<br>1.0 1.0<br>0.5 0.5 1T'-Sv<br>2H-defective<br>0.0 0.0<br>−0.5 −0.5<br>−1.0 −1.0<br>−1.5 −1.5<br>Γ M K Γ Γ M K Γ<br>(i)<br>(g) (h) 0.0<br>−0.5<br>−1.0<br>−1.5<br>−2.0<br>O1 −2.5<br>1.168 O1<br>1.158 −3.0<br>2.754 2H-S vacancy<br>O2 1.681 −3.5 1T'-S vacancy<br>O2 −4.0 2H-Pristine<br>−4.5 1T'-Pristine<br>−5.0<br>CO CO2 NH3 SO2 NO NO2 O2<br>NO2 NO2<br>Gas molecules<br>Energy (eV) Energy (eV)<br>Energy (eV) Energy (eV)<br>Adsorption energy (eV)<br><!-- End of picture text -->

**Fig. 7  a** S vacancy in 2H-MoS2. **b** S vacancy in 1T-MoS2. Band structure of **c** pristine 2H-MoS2, **d** pristine 1T-MoS2, **e** S vacant 2H-MoS2, **f** S vacant 1T-MoS2. Adsorption of  NO2 on **g** defective 2H-MoS2, **h** defective 1T-MoS2. **i** Variation of adsorption energy for different molecules. Reproduced from Ref. [286]. Copyright (2019) American Chemical Society 

1 3 

**38** Page 18 of 58 

Nano-Micro Lett. (2021) 13:38 

Table 2. Fan et al. calculated the adsorption energy of gas molecules by Eq. (6): 

_E_ a = _E_ free molecule + _E_ free sheet − _E_ adsorbed sheet 



<!-- Start of picture text -->
(6)<br><!-- End of picture text -->

The Fe metal-embedded  MoS2 has shown promising NO2 adsorption properties with charge transfer value − 0.66e and adsorption energies of 210 meV. The negative values indicate that charge transferred from metal embedded  MoS2 to  NO2 than pristine  MoS2. These extra electrons are obtained from the embedded transition metals, which reflect the importance of the transition metals. The electronic structure with  NO2 and metal embedded  MoS2 was studied deeply. The higher interaction of  NO2 is due to the mixing of Fe 3d states and 6a1, 1a2, and 4b1 orbitals of NO2 over a wide range of energy, as shown in the Fig. 8a, b. These mixing or hybridization resulted in enhanced NO2 interaction with charge transfer of − 0.66e. A similar behavior is observed with other metal-doped  MoS2. 

Luo et al. doped Al, Si, and P metal atoms at the S vacancy site [297]. These metals were chosen because of their exactness and closeness of covalent radii to the radius of the S atom. The  NO2 and  NH3 adsorption were studied at five adsorption sites on  MoS2. The five adsorption sites are _Tx_ (gas molecule on top of doped metal), _Hx_ (gas molecule on top of hexagon near to doped metal), _T_ S (gas molecule on top of S atom near to doped metal), _T_ Mo (gas molecule on top Mo atom near to doped metal). Among all five sites, the most stable site for  NO2 adsorption was _Hx_ after a complete structure relaxation. The doping of Al, Si, and P generates impurities in the Mo 4d state which create strong hybridization coupling between the Al-3p, Si-3p, and P-3p. Therefore a strong charge is transferred between the atoms and monolayer  MoS2. Si-doped  MoS2 was found most suitable for NO2 adsorption due to the highest charge transfer between them. PDOS calculation was performed to investigate the NO2 adsorption on undoped  MoS2 and doped  MoS2, and 

**Table 2** Summary of the adsorption energy, charge transfer, and method utilized for the calculating the  NO2 adsorption on the various metaldoped 

|Metal|Supercell Size (lattice parameter in Å)|Method|_E_ads(eV)|Charge transfer (e)|References|
|---|---|---|---|---|---|
|Fe|4 × 4 (3.18)<br>_E_a =_E_free molecule+_E_free sheet−_E_adsorbed sheet|PBE*|1.92|− 0.66|[296]|
|Co|||1.45|− 0.61||
|Ni|||0.84|− 0.42||
|Cu|||1.02|− 0.64||
|Ag|||0.54|0.60||
|Au|||0.65|− 0.54||
|Rh|||1.13|− 0.31||
|Pd|||0.29|− 0.34||
|Pt|||0.37|− 0.34||
|Ir|||1.49|− 0.39||
|MoS2|4 × 4 (3.17)<br>_E_a =_E_MoS2+molecule−<sup>(</sup>_E_MoS2 +_E_molecule<br>)|PBE|− 0.07|− 0.02|[297]|
|Al|||− 3.02|− 0.50||
|Si|||− 2.58|− 0.52||
|P|||− 2.134|− 0.48||
|V|4 × 4 (3.17)|PBE|2.59|− 0.66|[298]|
||_E_a =_E_free molecule+_E_free sheet−_E_adsorbed sheet|||||
|Nb|||3.88|− 0.69||
|Ta|||3.64|− 0.72||
|Ag|4 × 4 (3.18)<br>_E_a =_E_MoS2+molecule−<sup>(</sup>_E_MoS2 +_E_molecule<br>)|PBE|− 2.83|− 0.61|[299]|
|Cu|5 × 5 (3.18)|PBE|1.66|0.64|[25]|
||_E_a =_E_free molecule+_E_free sheet−_E_adsorbed sheet|||||



* Perdew–Bruke–Ernzerh (PBE); The negative value means charge transfers from  MoS2 to gas molecules; the doping site is at S vacancies for all the reports 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 19 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(c) 3 NO2<br>(a) NO2/Fe-MoS2 0<br>−3<br>20 S atoms<br>0<br>−20<br>20 Mo atoms<br>0<br>−20<br>−14 −12 −10 −8 −6 −4 −2 0 2 4<br>Energy (eV)<br>4a1 5a1,3b1,1b2 Fe-3d<br>6a1 (d) 2 NO2<br>5a1,3b1,1b2 NO2 ads 0<br>4b1 1a2 −2<br>NO2 gas 0.5 Doped Si<br>0.0<br>−0.5<br>5a1 20 S atoms<br>4a1 0<br>1b2 1a2 −20<br>4b1 6a1 5a1 20 Mo atoms<br>(b) 4a1 5a1,3b1 4b1,1a2,6a1 −200<br>−10 −8 −6 −4 −2 0 2 4 6 −14 −12 −10 −8 −6 −4 −2 0 2 4<br>Energy (eV)<br>Energy (eV)<br>DOS<br>DOS (a.u.)<br>DOS<br><!-- End of picture text -->

**Fig. 8  a, b** Total density of states and density of states for Fe-embedded  NO2 molecule. Reproduced with permission from Ref. [296]. Copyright (2017) Elsevier; Calculated projected density of states **c** with  NO2 adsorbed on monolayer  MoS2, **d** Si-doped  MoS2. Reproduced with permission from Ref. [297]. Copyright (2016) Elsevier 

shown in Fig. 8c, d. In the case of undoped  MoS2, the  NO2 peaks were situated at − 7.7 and − 3.09 eV while the PDOS peak of bare  MoS2 was situated at 2.33, − 12.04 and between − 1.5 and − 5 eV. Hence the weak interaction occurs between NO2 and  MoS2. However, when Al was doped in  MoS2, there is more orbital coupling at − 1.35 and − 3.31 eV not only with Al orbitals but also with S and Mo orbitals. Hence, the interaction and charge transfer increased with Al doping. NO2 molecules partially obtained electrons from the doped Al. With Si atom, the hybridization of orbitals is further increased and a higher number of electrons, i.e., 0.52e transfer to  MoS2. Similar behavior was observed with the P atom. 

Zhu et al. studied the doping of V, Tb, and Ta on the S vacancy site [298]. It is important to note that the size of these metal atoms is large in comparison to the S atom. These atoms are thus situated outside the S plane. Among all, the high binding energy suggested that Ta atoms bound firmly with  MoS2. The  NO2 gas molecules prefer to make bond on metal atoms. The two oxygen atoms form bond with the metal atom and N atom, and form a four-membered ring like structure M–O–N–O, shown in Fig. 9a–c. 

The calculated adsorption energies were 2.59, 3.88, and 3.64 eV for V, Nb, and Ta atoms, respectively. The Bader charge analysis revealed that charge transferred from  MoS2 to  NO2 and with V, Nb, and Ta atoms metals doping.  NO2 has shown strong oxidizing behavior. The charge density differences are shown in Fig. 9d–f. The  NO2 adsorption with monolayer  MoS2 were further calculated with  NO2 exposure. 

However, the charge transfer and adsorption energies are comparatively smaller than metal-doped V, Nb, and Ta. Moreover,  NO2 as a paramagnetic molecule is critically affected by the bond length [300]. The bond length was 1.21 Å in the case of pristine  MoS2 while  NO2 bond length was elongated from 0.07 to − 0.11 Å with metal-doped  MoS2. Thus, the  NO2 activation on metal-doped  MoS2 is enhanced. Further electronic properties of  MoS2 after  NO2 doping was analyzed in terms of DOS, shown in Fig. 9g–i. The metal orbitals and  NO2 orbitals have a strong hybridization between their orbitals. The d orbitals of metals especially for Nb atoms get mixed with  NO2 orbitals over a wide range of energy. Hence, doping of  MoS2 with V, Nb, and Ta improves the electronic and chemical performance of the  NO2 molecule. The supercell 

1 3 

**38** Page 20 of 58 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(g) V 3d<br>(a) (d) NO2<br>1.275 1.309 5a1,3b1,1b2 4b1,1a2 5a1<br>2.123 2.015 6a1<br>V<br>−8 −6 −4 −2 0 2 4<br>Energy (eV)<br>(h) Nb 4d<br>(b) (e) NO2<br>1.279<br>1.310 4b1,1a2<br>5a1,3b1,1b2 5a1<br>2.253<br>2.159 6a1<br>Nb<br>−8 −6 −4 −2 0 2 4<br>Energy (eV)<br>Ta 5d<br>(c) (f) (i) NO2<br>1.283 4b1,1a2<br>1.315<br>5a1,3b1,1b2 6a1 5a1<br>2.221<br>2.138<br>Ta<br>−8 −6 −4 −2 0 2 4<br>Energy (eV)<br>DOS (a.u.)<br>DOS (a.u.)<br>DOS (a.u.)<br><!-- End of picture text -->

**Fig. 9  a, d, g** NO2 molecule adsorbed on V metal: optimized geometry after  NO2 adsorption ( **a** ) **,** charge density difference ( **d** ), spin-polarized density of state with V 3d and  NO2 ( **g** ). **b, e, h** NO2 molecule adsorbed on Nb metal: optimized geometry after  NO2 adsorption ( **b** ), charge density difference ( **e** ), spin-polarized density of state with Nb 4d and  NO2 ( **h** ). **c, f, i** NO2 molecule adsorbed on Ta metal: optimized geometry after NO2 adsorption ( **c** ), charge density difference ( **f** ), spin-polarized density of state with Ta 5d and  NO2 ( **i** ). Reproduced with permission from Ref. [298]. Copyright (2017) Elsevier 

size, lattice parameter, occupied method, adsorption energy, and charge transfer are summarized in Table 2. 

### **5  Experimental Investigations of  NO2 Adsorption on  MoS2** 

In this section, we discuss various experimental approaches employed to develop the  NO2 sensors. This section has been divided into five sub-section in which we summarize the various experimental approaches adopted in terms of bare  MoS2, morphology-driven  MoS2, metal-doped  MoS2, vacancy-driven  MoS2, and finally light-assisted  MoS2-based NO2 sensors. 

##### **5.1  Bare  MoS2  NO2 Sensor** 

Here, we addressed several efforts and experimental reports where  NO2 sensors were fabricated with single and multilayered  MoS2 flakes. The reports include the impact of  NO2 adsorption on the single and multilayer  MoS2 and as well as the on the SBH. Li et al. developed the first NOx gas sensor using an n-type  MoS2 flakes-based FET device [34]. The schematic of fabricated device is shown in Fig. 10a. The monolayer (1L) to quadrilayer (4L)  MoS2 flakes were synthesized by the mechanical exfoliation technique and had the detection limit of 0.8 ppm. The thickness of the  MoS2 layers was confirmed by the atomic force microscopy (AFM) technique. The current versus voltage 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 21 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(a) (b) 5 2.0 NO (c) 8 2 nm<br>1.5 N2 6<br>4 4 nm<br>0.3 ppm NO 1.0<br>0.8 ppm NO<br>3 1.5 ppm NO 800 Time (s)1000 1200 4 8 nm<br>2 2 ppm NO 2<br>18 nm<br>1<br>2L MoS2 0<br>20 µm 0<br>0 500 1000 1500 2000 0 30 60 90 120<br>Time (s) Time (min)<br>(d)<br>(e) 14001200 With Vg+ 15 V (f) 12 Vg = 0 V<br>1000 W/O Vg 10 Vg = 15 V<br>800 8<br>600 Gas on 6<br>400 4<br>200<br>2<br>0<br>0<br>0 500 1000 1500 2000 2500 3000 0 200 400 600 800 1000<br>Time (s) Concentration of NO2 (ppm)<br>(g) Gas molecules (h) 120 NONO22(RT)(100 °C) 50 )i( A + Bare MoSWith NO2 2<br>100<br>40<br>80<br>30<br>60<br>20<br>40<br>A 0<br>10<br>20<br>MoS2 0 0<br>gas sensor 0 10 20 30 40 50 60 70 1.839 1.840 1.841 1.842 1.843 1.844<br>Time (min) Photon energy (eV)<br> (nA)I ds<br> (nA)I ds ∆I/I (%)0<br>S (%)<br>9()×10ΩRg<br>Sensitivity (%) PL intensity (a.u.)<br>Concentration (ppm)<br><!-- End of picture text -->

**Fig. 10  a** Optical image of bilayer  MoS2-based FET NO sensor. **b** MoS2 FET response to different concentrations NO. The inset showed the typical response and recovery of the  MoS2 FET device. Reproduced with permission from Ref. [34]. Copyright (2012) Wiley-VCH. **c** MoS2 TFT NO2 sensor with different thickness  MoS2 flakes. Reproduced with permission from Ref. [42]. Copyright (2012) Wiley-VCH; **d** optical image of  MoS2 device mounted on a chip. **e** NO2 response for the bi and five-layer  MoS2 devices at different gate voltages. **f** Theoretically calculated resistance variation with different gate voltages. Reproduced with permission from Ref. [17]. Copyright (2013) American Chemical Society. **g** Device schematic of atomic layer  MoS2-based sensing device. **h** Response of  NO2 at RT and at moderate temperature of 100 °C. **i** Change in the low energy PL peak due to  NO2 adsorption. Reproduced with permission from Ref. [32]. Copyright (2015) Springer Nature 

characteristics measurements of the device with varied layers were performed. The single layer device showed unstable behavior while bi- to quadrilayer film-based devices demonstrated better sensing performance. The NO gas exposure to bilayer  MoS2 film showed a decrease in the current, which confirm the p-type doping due to the electron acceptor nature of the NO gas [57, 301]. Figure 10b displays the gas-sensing performance of the  MoS2 device with different NO concentrations. The adsorption and desorption rate of NO was a two-step process: fast rate and slower rate. The fast reduction in current confirmed the presence of a large number of NO adsorption sites and 

slow reduction confirmed saturation of  MoS2 film in NO exposure. Another significant aspect of the different thickness of  MoS2 film was the quick response to NO exposure. The single layer  MoS2 film showed a 50% response within 5 s while multilayer  MoS2 showed a 50% response in 30 s. However, the disadvantage with single-layer  MoS2 film was its instability. 

He et al. developed a flexible  MoS2 thin film transistor (TFT) arrays for the  NO2 sensing [42]. The single layer MoS2 film suspension was drop cast over patterned rGO electrodes covered with Ag pads. The Ag pads had only been used to improve the robustness of the rGO electrodes. 

1 3 

**38** Page 22 of 58 

Nano-Micro Lett. (2021) 13:38 

The  MoS2 area and thickness for  NO2 sensing were 1.5 mm<sup>2</sup> and 2, 4, 8, and 18 nm, respectively. It is worth to note that the deposited  MoS2 film showed p-type behavior attributing to the structural changes caused by the lithium intercalation process. The structural changes in the  MoS2 lead to a change in the band structures. During distortion from the octahedral system to zigzag chain, the system was filled up to _d_<sup>2+</sup><sup>_n_</sup> states. Hence, residual negative charges semi filled the bands and contributed to p-type conductivity [302]. The  NO2 gas exposed to the various thickness of MoS2 film and the highest change in the sensor response was occurred for the thinnest  MoS2 film. The  NO2 exposure increased the conductance of the film due to its electron acceptor nature. The high  NO2 detection ability of thin  MoS2 film was attributed to the increased surface area available in 2 nm film. The sensor response of different thickness of MoS2 film is shown in Fig. 10c. Late et al. studied the  NO2 sensing behavior of single and multiple layer  MoS2 film synthesized by the mechanical exfoliation method [17]. A detailed gas-sensing performance with and without applying the bias voltage was presented. A detailed AFM, Raman, and TEM characterization were performed to understand the thickness, expansion, crystallographic orientation, and structure of  MoS2. The device schematic with Ti/Au contact is shown in Fig. 10d. The _I_ – _V_ characteristic of single layer MoS2 device was unstable while multilayer  MoS2 showed stable _I_ – _V_ characteristics. Few layers (single and five layers)  MoS2 device demonstrated good behavior. The three and four-layer  MoS2 flakes device showed identical behavior to two layer and five-layer devices. The  NO2 sensing for five-layer  MoS2 device is shown in Fig. 10e. However, this higher performance was due to the redox potential that greatly influences the sensing behavior of  MoS2 flakes. Once again, the  NO2 interaction with  MoS2 revealed that the  NO2 has an electron acceptor nature. The influence of the external electric field in terms of bias voltage on the  NO2 sensing was further studied. When a positive back gate biasing voltage + 15 V was applied to two and five layers of  MoS2 flakes, the sensor response was improved in comparison to zero bias voltage. A larger number of electrons were collected at the MoS2 and  SiO2 interface under positive back gate voltage. Therefore,  NO2 has a higher number of electrons to detach from the  MoS2. With positive gate biasing voltage, the  NO2 sensor response was thus increased. In addition, Ti/Au electrode played a vital role under positive gate voltage. Under positive gate voltage, electrons get accumulated in  MoS2 

film and the barrier between the electrode and  MoS2 film is reduced. Thus, the charge transfer in  MoS2 film facilitated further. The device resistance in the presence of  NO2 gas is shown in Fig. 10f at different biasing voltages. 

Cho et al. synthesized the atomic layered  MoS2 flakes by the CVD technique and performed the  NO2 gas sensing [32]. The resistance of the n-type  MoS2 film increased due to the electron-accepting nature of  NO2. The interdigitated electrodes of Ag metal were fabricated on the  MoS2 film. The  NO2 sensing performance was studied at RT and at a moderate temperature of 100 °C. 

The device schematic and  NO2 sensor response versus time profile at each temperature are shown in Fig. 10g, h. It can be seen clearly that the RT sensor response was quite high in comparison to 100 °C, while the sensor showed rapid recovery at 100 °C and no recovery was obtained at RT. The  NO2 gas strongly adsorbed on  MoS2 and hence at RT the desorption rate is quite low. However, thermal energy greatly impacts the adsorption of  NO2 at a higher temperature. The thermal energy accelerates the  NO2 desorption rate than the adsorption rate. As a result, the  NO2 gas interaction decreases at a higher temperature at the sensor response cost. The  NO2 sensing mechanism based on the charge transfer process, confirmed by the change in the peaks of PL spectra is shown by Fig. 10i, as we discussed in Fig. 5b of Sect. 3. 

These all layer-dependent studies show that the single layer  MoS2-based gas sensors suffered from unstable current, but they have a quick response with  NO2 exposure. The few layer  MoS2 flakes-based gas sensors show a good response with the stable current. Moreover, the  MoS2 FET gas sensors are very sensitive to the applied bias voltage. However, the  MoS2 gas sensors have an incomplete recovery at RT. So, operating sensors at a higher temperature may be a good option to achieve full recovery but it will reduce the sensor response. The summary of the results for bare MoS2-based  NO2 gas sensors by various groups are tabulated in Table 3. 

Liu et al. studied the  NO2 sensing efficiency of monolayer  MoS2 flakes grown by CVD [36, 303]. The effect of gas molecules adsorption on the Schottky barrier height (SBH) between the  MoS2 and metal electrodes was studied. The sensing device area was 1 µm<sup>2</sup> and film showed the 3  cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> mobility with Ti/Au electrodes, shown in Fig. 11a. The Ti was used for improving the electrode adhesion with  MoS2 film. The device showed highly rectifying behavior with a positive and negative drain to source voltage 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 23 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

|References|[34]|[42]|[17]|[36]|[303]|[303]|[303]|[32]|[32]|[31]|[31]|[35]|[304]|[304]|[305]|[120]|[120]|[214]|[33]|[306]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Rec time|–|–|600|–|–|–|–|–|–|720|2340|–|–|132|318|–|19.6|172|–|12|
|Res time|–|–|300|300|–|–|–|–|–|660|2460|–|98|34|678|8.51|4.44|16|–|15|
|S (%)|80|7|1372|> 20|80|98|60|~ 120|> 40|1.15|5.80|> 10|48.32|24.26|2.6|10.36|7.79|18.1|78|60|
|Tem. (°C)|RT|RT|RT|RT|RT|RT|RT|RT|100|200|200|RT|RT|RT|RT|RT|125|60|150|150|
|(ppm)|||||||||||||||||||||
|Conc.|2|1.2|1000|.02|10|10|10|50|50|1|1|100|50|50|1|10|10|5|50|50|
|Device|FET|TFT|FET|FET|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|
|Electrodes|Ti/Au|rGO|Ti/Au|Ti/Au|Al|Ag|Au|Ag|Ag|Pt|Pt|Ti/Au|Au/Cr|Au/Cr|Au|Au/Cr|Au/Cr|Au|Au|Ag/Pd|
|Def.|((_I_gas−_I_air)<br>_I_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_G_gas−_G_air)<br>_G_air<br>)|((_I_gas−_I_air)<br>_I_air<br>)|((_I_gas−_I_air)<br>_I_air<br>)|((_I_gas−_I_air)<br>_I_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|_R_gas<br>_R_|air<br>_R_gas<br>_R_|air<br>((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_air−_R_gas)<br>_R_air<br>)|_R_gas<br>|_R_air<br>((_R_air−_R_gas)<br>_R_air<br>)|
|Method|M.E.|E.L.|M.E.|CVD|CVD|CVD|CVD|CVD|CVD|L.E.|L.E.|CVD|CVD|CVD|CVD|CVD|CVD|CVD|Hyd.|Hyd.|
|Type|n|p|n|n|p|p|p|n|n|p|n|p|n|n|p|p|p|n|p|n|
|Sensing film|1L  MoS2|MoS2sheets|5L  MoS2|1L  MoS2|3L  MoS2|2L  MoS2|4L  MoS2|Atomic layered  MoS2|Atomic layered  MoS2|Few layer  MoS2|Few layer  MoS2|Vertical  MoS2|Vertical  MoS2|Vertical  MoS2|2L  MoS2|Mixed  MoS2|Mixed  MoS2|MoS2NWs|MoS2nanoflower|MoS2nanosphere/CTAB|



1 3 

**38** Page 24 of 58 

Nano-Micro Lett. (2021) 13:38 

|References|[307]|[308]|[308]|[24]|[309]|[121]|[121]|[310]|[310]|[119]|[119]|[121]||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Rec time|225|485|320|107|2|39|840|328|–|–|310|840|sed (S.P.)|
|Res time|79|125|95|33|42|41|240|56|142|249|71|240|olution proces|
|S (%)|40.3|67.4|22|11|29|171|30|72|27|27.92|21.56|30|on (T.D.); s|
|Tem. (°C)|150|RT|150|200|RT|RT|RT|50|50|RT|100|RT|al decompositi|
|Conc. (ppm)|100|5|5|0.5|100|20|2.5|50|50|100|100|2.5|mal (Hyd.); therm|
|Device|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|Resistor|L.); hydrother|
|Electrodes|Au/Cr|Pt|Pt|Pt/Ti|Ag/Pd|Ag/Pd|Au|Au|Au|Au/Cr|Au/Cr|Au|cal lithiation (E.|
|Def.|((_R_air−_R_gas)<br>_R_air<br>)|((_R_air−_R_gas)<br>_R_air<br>)|((_R_air−_R_gas)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|_R_gas<br>_R_i|ar<br>((_R_air−_R_gas)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|((_R_gas−_R_air)<br>_R_air<br>)|E.); electrochemi|
|Method|Hyd.|Hyd.|Hyd.|T.D.|M.E.|Hyd.|S.P.|CVD|CVD|CVD|CVD|Redox|exfoliation (L.|
|Type|p|p|p|p|p|n|p|p|n|n|n|p|.); liquid|
|g film|hollow microsphere|Nanoflowers|Nanoflowers|Aerogel|Nanosheets|-W|-Au|v-MoS2||MoS2|MoS2|-Au NPs|anical exfoliation (M.E|
|Sensin i|MoS2|MoS2l|MoS2l|MoS2|MoS2|MoS2|MoS2|rGO/S|MoS2|Multi|Multi|MoS2|Mech|



© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 25 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

( _V_ DS) with 400 ppb  NO2 exposure, as shown in Fig. 11b. The device showed an excellent sensor response of 174% with back gate voltage 30 V. The response time was 300 to 540 s with the full recovery in 12 h. To confirm the  NO2 gas-sensing mechanism via the charge transfer process, the back gate voltage was fixed at 5 V and gas concentration was varied from 20 to 400 ppb. The threshold voltage for the  NO2 sensing received a monotonic shift in the positive _V_ DS direction. The resistance modulation in the device due to gas exposure is the sum of channel resistance ( _R_ channel) and _R_ contact determined by Eq. (7): 



<!-- Start of picture text -->
휑 SB<br>R  = ( R channel ∝ 1 ∕ n ) + ( R contact ∝ n 1 e kT ) (7)<br><!-- End of picture text -->

where _n_ is the electron concentration, _휑_ SB is the Schottky barrier height between the  MoS2 and metal electrodes. The SBH is greatly influenced by the above equation when the electron concentration in the device is changed. Figure 11c, d indicates the transfer characteristics at a fixed back gate voltage of 5 V. An increment in the threshold voltage with higher gas concentration is observed.  NO2 is strong oxidizing gas and has an electron acceptor nature. More number of electrons withdraw from  MoS2 film as the gas concentration is increased. Thus, a monotonic shift in the positive _V_ DS direction was observed. Considering the effect of the  NO2 adsorption on SBH, the proposed band alignment before and after exposure to  NO2 is shown in Fig. 11e, f.  NO2 gas captured the electrons from the conduction band and the electron concentration in  MoS2 film was decreased. The decrease in electron concentration shifts the Fermi level towards the valence band which increases the SBH. Hence, the conductance is decreased. 

Kim et al. recently fabricated the  MoS2 gas sensor with different metal contacts of different work functions [303]. The sensor response of the  MoS2 sensor was different with different metals. First, the effect of the layer thickness from single to four layers with Au electrodes was studied. The _I_ – _V_ characteristic is shown in Fig. 11h revealed a linear behavior and a decrease in resistance with an increase in layer observed. The work-function was increased with the number of layers, shown in Fig. 11g. Hence, for a higher number of layers, the SBH is decreased and according to Eq. 11, the resistance is also decreased. Further,  NO2 exposure on different thickness layer devices is also displayed in Fig. 11i. The device showed p-type behavior to NO2 exposure. Further, the bilayer  MoS2 device showed the highest sensor response for 10 ppm  NO2 concentration 

up to 60%. Finally, for bilayer and trilayer  MoS2, the Au ( � _M_ = 5.1 eV ), Al ( � _M_ = 4.06 eV), and Ag ( � _M_ = 4.26 eV ) electrodes were used. Among all, aluminum electrodebased sensing device showed promising sensor response, 80% for bilayer and 98% for trilayer  MoS2-based device. Conclusively, the device with lower work function metal electrodes showed better performance. The band alignment between the aluminum (lower work function metal) and  MoS2 is responsible for high performance as shown in Fig. 11l–o. The SBH is higher for Al electrodes than the Au electrodes. Under positive biasing, a higher number of holes are transferred from Au electrode due to the low SBH. When  NO2 gas is exposed, the SBH decreases with a decrease in electron depletion due to the p-type nature. Relatively, the ratio of charge transferred in Al/ MoS2 device is higher than the Au/MoS2. Hence, better performance is observed. 

These reports confirmed that sensing response is critically affected by the SBH. In chemiresistance gas sensors, the SBH is modulated with gas molecules adsorption due to charge transfer between the molecules and sensing film. Thus, Schottky contacted devices are a good candidate for fabricating gas sensors. Hence, the choice of metal contacts played an important role in gas sensing. 

##### **5.2  Morphology‑Driven  NO2 Sensors** 

In the 2D materials, especially in  MoS2, morphology plays a vital role in determining the optical, electrical, and catalytic properties. The  NO2 molecule adsorption in  MoS2 is position-dependent and there are specific  NO2 favourable sites for molecules adsorption in  MoS2. These favourable NO2 adsorption sites can be controlled by synthesizing various  MoS2 film surface morphology. In this section, we will discuss various reports where morphology-dependent  NO2 sensors based on  MoS2 developed. 

Cho et al. studied the role of  MoS2 edges in  NO2 gas molecules adsorption [35]. The orientation of the  MoS2 film greatly affects the adsorption of  NO2 molecules. Authors varied the orientation of the  MoS2 film from horizontal to vertical align by depositing different thickness Mo films. The surface topography is shown in Fig. 12a. The inset of the Fig. 12a showed the schematic of the sensing device with an active area of 100µm<sup>2</sup> . The  NO2 gas molecule adsorption enhanced up to fivefold in vertical aligned  MoS2 flakes 

1 3 

**38** Page 26 of 58 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
Vacuum<br>(b) 0.9 (e)<br>(a) Before NO2 exposure eχ<br>eφMetal<br>0.6 In 400 ppb NO2<br>EC<br>EF<br>0.3 Eg<br>EV<br>0.0<br>0 1 2 3 4 5 Ti/Au MoS2<br>VDS (V)<br>(c) (d) 25 (f) NO2δ−<br>0.4 VDS =5 V ∆SB1<br>Before exposure 20 ∆SB2 Vbi<br>0.3 20 ppb<br>δ'+ EC<br>40 ppb 15 SB NH3<br>0.2 100 ppb EF<br>200 ppb<br>10<br>0.1 400 ppb Eg<br>NO2 5 EV<br>0.0<br>−40 −20 0 20 40 0 100 200 300 400<br>VBG (V) NO2 concentration (ppb) Ti/Au MoS2<br>(g) Electrode MOS2 (j) 120100 NO2 3L MoS3L MoS22 (Al) (Ag) 120100 (k) NO2 2L MoS2L MoS22 (Al) (Ag)<br>80 3L MoS2 (Au) 80 2L MoS2 (Au)<br>χ = 4.3 eV 60 60<br>Au<br>40 40<br>ë = 5.1 eV<br>EC 20 20<br>Eg (4L) Eg (3L) Eg (2L) Eg (1L)<br>1.2 eV 1.35 eV 1.65 eV 1.8 eV 0 0<br>EF 0 20 40 60 80 100 0 20 40 60 80 100<br>0.4 eV 0.55 eV Time (min) Time (min)<br>0.85 eV 1.0 eV<br>)l( MoS2 Electrode (m) MoS2 Electrode<br>EV EF Au EF Au<br>NO2<br>SBH<br>(h) 10×105×10 −2−2 4L MoS3L MoS2L MoS222 8060 (i) NO2 4L MoS3L MoS2L MoS222 charge transfer(i) Surface (ii) Schottky barriermodulation (SBM)<br>1L MoS2 1L MoS2<br>40 (n) MoS2 Electrode (o) MoS2 Electrode<br>0<br>20 EF Al NO E 2 F Al<br>−5×10 −2<br>0 SBH<br>−10×10 −2 −5 −3 −1 1 3 5 0 20 Time (min)40 60 80 100 SBM<br>Voltage (V)<br>Ti/Au<br>SiO2/Si<br> (µA)IDS<br> (µA)IDS  (V)Vth<br>Response (%) Response (%)<br>Current (µA) Response (%)<br><!-- End of picture text -->

**Fig. 11  a** Schematic of the monolayer  MoS2 device. **b** Change in current after 400 ppb  NO2 exposure. **c** _I_ – _V_ characteristics after the  NO2 exposure of different concentration. **d** A monotonic shift in threshold voltage towards the positive side of applied voltage. **e, f** Energy band alignment before and after  NO2 exposure. The blue solid lines are corresponding to the band alignment of  MoS2 and Ti/Au contact in the absence of NO2 while the green dotted lines are corresponding to  NO2 exposure. Reproduced with permission from Ref. [36]. Copyright (2014) American Chemical Society. **g** Band alignment of  MoS2 with Au metal contact. **h** Current versus voltage characteristics with gold contact. **i** NO2 response with  MOS2-Au device. Sensor response for  NO2 with different metal contacts Al, Ag, and Au electrodes: **j** 3L  MoS2 film, **k** 2L  MoS2 film. Proposed band alignment of  MoS2-Au device: **l** before, **m** after  NO2 exposure. Proposed band alignment of  MoS2-Al device: **n** before, **o** after  NO2 exposure. Reproduced with permission from Ref. [303]. Copyright (2019) American Chemical Society. (Color figure online) 

compared to the horizontal  MoS2 film, as shown in Fig. 12b. The Mo film was deposited through an electron beam evaporator and was sulfurized in the CVD. The orientation of the MoS2 film was determined through the FESEM, XRD, TEM, and Raman spectra. The  MoS2 films (horizontal, mixed, and 

vertical  MoS2) showed a p-type nature. The p-type behavior was verified through the positive increase in the resistance due to the exposure of oxidizing  NO2 gas. Interestingly, vertical aligned  MoS2 flakes faced the highest change in the sensor response to the  NO2 gas, which means that 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 27 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

the morphology of  MoS2 flakes crucially regulates the gassensing behavior. The reason is the presence of numerous active sites at the edges. 

As we discussed in Sect. 3, the horizontal (basal plane) and vertical aligned  MoS2 flakes have different adsorption sites (H site,  TS site, and  TM site) for  NO2 molecules with different adsorption energy and charge transfer. Moreover, the edges of vertical aligned  MoS2 flakes have high catalytic properties in comparison with the basal plane, which enhanced the  NO2 reactivity of the edges. The vertical aligned  MoS2 flakes thus displayed the great potential to communicate with  NO2. The adsorption of  NO2 on the basal plane  MoS2 and at the edges is shown in Fig. 12c. 

Kumar et al. synthesized the horizontally aligned  MoS2 (HA-MoS2) and vertically aligned (VA-MoS2) by the CVD method [304]. The  NO2 sensing behavior for each structure was determined in the operating temperature range from RT to 150 °C. The VA-MoS2 flakes showed better  NO2 sensing performance in all temperature range. Moreover, the VA  MoS2 film quickly detected 1 ppm  NO2 concentration. However, the sensor response for 1 ppm  NO2 concentration with HA  MoS2 flakes could not be achieved. These results revealed the high  NO2 detection ability of VA  MoS2 flakes even for the low concentration also. Another fascinating aspect of VA-MoS2 is the sensor recovery after  NO2 exposure which didn’t occur with the HA-MoS2 flakes. The recovery of the VA and HA-MoS2 flakes was substantially improved by operating devices at high temperatures but again at the expense of sensor response. Notably, the  NO2 selectivity of the VA-MoS2 device was also high. The high sensor response of VA-MoS2 flakes is due to the high adsorption sites and the higher number of charge transfer at the edges of the VAMoS2 flakes in comparison with HA-MoS2 flakes. 

Agrawal et al. synthesized a combination of vertical aligned  MoS2 flakes and in-plane  MoS2 flakes (mixed  MoS2 flakes) by a modified CVD technique. The surface morphology is shown in Fig. 12d. The black region is the in-plane MoS2 flakes while the white region is the vertical  MoS2 flakes. The fabricated sensing system suggested the existence of the p-type nature of  MoS2 film. The resistance of the device was decreased with the exposure of oxidizing  NO2 gas which means there is a decrease in the electron concentration and simultaneously an increase in the hole concentrations. The transient response curve with  NO2 exposure at 125 °C is shown in Fig. 12e. The  NO2 detection at RT was also studied. However, full recovery could not be achieved. 

The sensing mechanism of  NO2 interaction is based on the favorable adsorption sites available on the  MoS2 flakes, shown in Fig. 12f.  MoS2 has four adsorption sites as we discussed in Sect. 3, H site, B site,  TM, and  TS site. Yue et al. theoretically showed that the H site,  TM site, and B site are the most favorable sites for the  NO2 adsorption. The maximum combination of these sites was synthesized to obtain the selective, highly responsive and recoverable  NO2 sensor. 

Kumar et al. synthesized the  MoS2 nanowire through the controlled turbulent vapor flow, shown in Fig. 12g. The  NO2 sensing behavior of the n-type  MoS2 NWs was investigated at the RT, 60 °C, and 120 °C for  NO2 concentrations of 1, 2, 3, and 5 ppm, shown in Fig. 12h. The  MoS2 NWs showed a high sensor response with an incomplete recovery due to the strong bonding of  NO2 molecules with NWs. A moderate temperature of 60 °C helped the  MoS2 NWs to obtain a recovery. The  MoS2 NWs showed good response time (16 s) and recovery time (172 s) for the 5 ppm  NO2 concentration with sensor response 18% at 60 °C. The  NO2 sensing mechanism proposed in  MoS2 NWs is based on the physisorption and chemisorption of gas molecules, as shown in Fig. 12i. The humidity and environmental oxygen get adsorbed on the surface of the NWs and reduced the detection of the  NO2 gas molecule at the RT. However, at 60 °C, the humidity and adsorbed oxygen were removed and generated new active sites for the  NO2 adsorption. Hence,  NO2 detection was high at a moderate temperature. Moreover, the high temperature generates thermal energy which also helps in the recovery. 

Yu et al. adopted the facile hydrothermal method and fabricated the edge-enriched flower-like  MoS2 spheres [33]. The diameter of the structure estimated through the SEM was 1–2 µm displayed in Fig. 13a. These nanospheres exhibited a large surface area with edge-enriched  MoS2 flakes. Also, the flakes were interconnected with each other and provided a quick path for the diffusion of gas molecules and charge transfer. The inset of Fig. 13a showed the high magnification FESEM image. These unique structures showed excellent sensor response, cyclability, and selectivity. The 50 ppm NO2 concentration is discussed here. The device was operated at different operating temperatures from 100 to 250 °C, displayed in Fig. 13b. The highest sensor response for the 50 ppm  NO2 concentration was 78% at 150 °C. The resistance versus time profile is shown in the inset of Fig. 13c, confirming the p-type nature of  MoS2 due to a decrease in the resistance of the sensor device. 

1 3 

**38** Page 28 of 58 

Nano-Micro Lett. (2021) 13:38 



**Fig. 12  a** TEM image of the vertically grown  MoS2. **b** Response of various morphology  MoS2 flakes with  NO2 gas. **c** DFT calculated  NO2 adsorption profile on the edges and basal plane  MoS2. Edges have high adsorption of  MoS2 flakes. Reproduced with permission from Ref. [35]. Copyright (2015) American Chemical Society. **d** FESEM image of mixed  MoS2 flakes and inset showed the high-resolution image of  MoS2 flakes and the device schematic. **e** The response of mixed  MoS2 flakes with  NO2 gas at 125 °C. **f** Schematic of favorable adsorption sites on the MoS2 flakes. Reproduced with permission from Ref. [120]. Copyright (2018) American Chemical Society. **g** FESEM image of the grown  MoS2 NWs. **h** Response of  MoS2 NWs with  NO2 exposure. **i** Proposed a mechanism of  NO2 adsorption on the  MoS2 NWs. Reproduced with permission from Ref. [214]. Copyright (2018) AIP Publishing 

Zhang et al. proposed the controlled growth of 3D flowerlike  MoS2 nanospheres assisted with cetyltrimethyl ammonium bromide (CTAB) [306]. CTAB played a crucial role in determining the morphology of the  MoS2 spheres. The average size of the synthesized nanospheres was 300 nm, displayed in Fig. 13d. This SEM revealed that these  MoS2 nanospheres were formed due to the bending of the randomly assembled  MoS2 sheets. These structures provide the path for the diffusion of the gas. The  NO2 sensing performance was studied in the operating temperature range from RT to 130 °C as shown in Fig. 13e. The highest reported sensor response was 60% observed for the 100 °C temperature. The MoS2 nanospheres behaved as the n-type semiconductor. 

The response and recovery time profile was 15 and 12 s for 50 ppm  NO2 at 100 °C shown in Fig. 13f. 

Li et al. followed a new step and prepared the hollow, solid and smooth  MoS2 nanospheres by the hydrothermal methods [307]. The hydrothermal process reaction time was maintained at 2-h, 5-h, 18-h in the presence of polyvinyl pyrrolidone (PVP) to synthesize the various morphology MoS2 flakes. The polystyrene template (PS) spheres are the platform for the nucleation of  MoS2 nanosheets. The SEM images of a fully prepared solid sphere and hollow spheres (inset) are shown in Fig. 13g. The 500 ppm  NO2 concentration is tested in the temperature range from 25 to 250 °C. Hollow spheres have shown the remarkably high sensor response with p-type nature, as shown in Fig. 13h, 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 29 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(a) (d) (g)<br>MoS2 sphere Hollow MoS2<br>assisted with CTAB  sphere<br>MoS2 nanosphere<br>Solid MoS2<br>sphere 2 µm<br>1 µm 1 µm<br>70 100<br>80 (b) (e) (h) Hollow Hollow sphere<br>60 Solid sphere<br>75 80<br>Smooth sphere<br>70 50<br>60<br>65 40<br>60 30 40 Solid<br>55<br>20 20<br>50 Smooth<br>45 10 0<br>40 0<br>80 100 120 140 160 180 200 220 240 260 0 20 40 60 80 100 120 140 0 100 200 300 400 500 600<br>Operating temperature (°C) Temperatures (°C) Time (s)<br>2000 (c) Gas in 3.5 (f) 90 (i)<br>1800 3.0 75<br>1600 2.5 60 Hollow sphere<br>Solid sphere<br>1400 2.0 45 Smooth sphere<br>1.5 Gas in Gas out<br>1200 30<br>1000 Gas off 1.0 15<br>0.5<br>0 100 200 300 400 500 0 20 40 60 80 100 120 0 50 100 150 200 250<br>Time (s) Time (s) Temperature (°C)<br>S (%) S (%)<br>Gas response<br>S (%)<br>Voltage (V) Sensing signal<br>Resistance (k)Ω<br><!-- End of picture text -->

**Fig. 13  a** FESEM image of the  MoS2 nanosphere. **b** Sensor response profile. **c** Transient resistance profile. Reproduced with permission from Ref. [33]. Copyright (2016) from Elsevier. **d** FESEM image of the CTAB-assisted  MoS2 sphere. **e** Gas response obtained at different temperature range. **f** Time response profile of  NO2 sensing. Reproduced with permission from Ref. [306]. Copyright (2018) from Elsevier. **g** FESEM image of solid  MoS2 sphere and hollow sphere. **h** Obtained sensor response for hollow, solid and smooth spheres. **i** Sensor response at different temperatures. The highest sensor response obtained for the hollow spheres. Reproduced with permission from Ref. [307]. Copyright (2019) from Elsevier 

i. About 2.5-fold enhancement is observed in the hollow spheres compared to solid spheres observed. 

Nanospheres improved  NO2 sensing due to the large surface area of the spheres. The sensing mechanism between the  MoS2 and  NO2 is based on the transfer of charge carrier concentration between them. The oxygen gas is adsorbed on the  MoS2 and introduced p-type doping in  MoS2. When  NO2 gas exposed to  MoS2 spheres, the  NO2 accepts the electrons from  MoS2 and gets adsorbed as NO<sup>−</sup> 2<sup>on  MoS2. Moreover,</sup> NO2 also reacts with adsorbed O<sup>−</sup> 2<sup>and gets adsorbed as NO−</sup> 2<sup>.</sup> The possible reactions of adsorbed oxygen and with  NO2 are as follows [311]: 



<!-- Start of picture text -->
O2(g) → O 2(ads) (8)<br><!-- End of picture text -->



<!-- Start of picture text -->
O2(ads) + e − → O − 2 (ads) (9)<br><!-- End of picture text -->



<!-- Start of picture text -->
O2(ads) + e − → 2O − 2 (ads) (10)<br><!-- End of picture text -->



<!-- Start of picture text -->
O − (ads) + e − → O − 2 (ads) (11)<br><!-- End of picture text -->



<!-- Start of picture text -->
NO2 + e − → NO − 2 (12)<br><!-- End of picture text -->



<!-- Start of picture text -->
NO2(gas) + e − → NO − 2 (ads) (13)<br><!-- End of picture text -->

1 3 

**38** Page 30 of 58 

Nano-Micro Lett. (2021) 13:38 

NO2(gas) + O<sup>−</sup> 2<sup>(ads) + 2e−→2NO−</sup> 2<sup>(ads) + 2O−</sup> 2<sup>(ads)</sup> (14) 



<!-- Start of picture text -->
NO − 2 (ads) + O− 2 (ads) → 2O−(ads) + NO2 (15)<br><!-- End of picture text -->

The above discussion clearly shows that different  MoS2 morphologies could boost the efficiency of gas sensors such as high sensor response, speed (response and recovery time), and selectivity. By choosing the different synthesis modes such as mechanical exfoliation, chemical exfoliation and CVD techniques, various  MoS2 morphologies can be synthesized ranging from in-plane  MoS2, flower like  MoS2, MoS2 NWs, vertical  MoS2 flakes. Different  MoS2 morphologies like vertical aligned, nanowires, solid and hollow spheres provide the path for the diffusion of gas molecules into the nanostructures so that gas molecules interacts more efficiently. Each morphologies have its own advantage and contributes in improving gas sensing. The  MoS2 flowers have a high surface area and provide higher adsorption sites for gas molecule adsorption. The hollow microspheres offer a larger surface area (inner and outer surface for molecule adsorption) than the solid spheres. The one-dimensional MoS2 NWs provides a combination of high surface area and active sites which will be further increased at moderate temperature. 

##### **5.3  Experimental Investigation of Metal Nanoparticle Doping of  MoS2** 

In Sect. 4.4, we already discussed various theoretical reports where  MoS2 was doped with different metal atoms and the advantage of metal doping in  MoS2 predicted for  NO2 sensing. Here, we addressed the experimental picture of metal doping in  MoS2 for  NO2 sensing.  MoS2 has a large surface to volume ratio which provides unique opportunities to surface functionalization with metal nanoparticles (NPs) such as Ag, Au, Pt, Pd, and Rh and many more. The incorporation of  MoS2 surface with metal NPs could be an efficient way to improve the electronic, optical, energy storage and catalytic properties [312–316]. Undoubtedly, functionalizing the  MoS2 film with metal NPs could open up a new era in the gas-sensing applications. 

He et al. used metal nanoparticles to fabricate  NO2 gas sensor based on  MoS2 flakes. The 4-nm-thick  MoS2 film was functionalized with Pt NPs [42]. The FESEM image of Pt-doped  MoS2 film is shown in Fig. 14a. The comparative 

sensing performance of Pt NP-doped  MoS2, rGO-MoS2, bare rGO, and bare  MoS2 is shown in Fig. 14b. The highest sensor response was achieved with Pt-doped  MoS2. The modulated Schottky barrier height and spillover effect was responsible for enhanced  NO2 sensing of Pt-doped  MoS2 [317–319]. The Pt NPs formed nano-Schottky barriers at different places with  MoS2. Pt extracted the electrons from the MoS2 film and introduced p-type doping in  MoS2. Moreover, due to the spillover effect, the catalytic reactivity of NO2 molecules was also increased. Hence, the high sensor response with Pt-doped  MoS2 was achieved. The selectivity of the Pt-doped  MoS2 is shown in Fig. 14c. 

Zhou et al. decorated Au nanoparticles on  MoS2 film and performed the  NO2 detection stability of the  MoS2-Au composite [121]. The gold NPs of 50 nm diameter formed a strong bond with defects present on the edges. The Au NPs adsorbed at the edges can be seen in Fig. 14d. The  NO2 sensing ability in the dark and with the UV light exposure was also performed. The  MoS2 and  MoS2-Au composites exhibited p-type nature. The full recovery with bare  MoS2 and Au decorated  MoS2 in the dark did not be achieve. However, when sensors were illuminated with UV light, fast response with a complete recovery and a three-time greater sensor response was achieved. Figure 14e shows all sensor responses. The band diagram between MoS2 and gold NPs are shown in Fig. 14f. It revealed that electrons were transferred from gold NPs to  MoS2 due to the difference in work function. Au NPs increased  MoS2 activity and catalytic reactivity [321]. Under UV illumination, charge transfer between the  MoS2 and Au NPs rapidly increased and led to a fast recovery. The physiosorbed  O2 and chemically adsorbed  O2 also produce a hole accumulation (HAL) layer in the  MoS2 surface similar to the metal oxides. Under  NO2 exposure, the width of the HAL layer increases and the resistance of  MoS2-Au decreases. 

Liu et al. doped  MoS2 with different ratios of W metal [320]. The W metal atoms were doped in the following ratio Mo: W: 1:0, 1:1, 1:2, and 1:3 and nominated as  W0,  W1,  W2, and  W3. The FESEM images of all the four samples are shown in Fig. 14g. The average crystallite size of the W metals was 52, 45, 29, and 32 nm. When  NO2 gas exposed to W-doped MoS2 film, sample  W2 showed the highest sensor response among all with the fastest response and recovery time. 

The undoped  MoS2 has the numerous number of defects. NO2 gas molecules adsorbed on these defective sites through the chemisorption process which leads to strong adsorption 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 31 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



**Fig. 14  a** Pt-doped 4-nm-thick  MoS2. **b** Response of the Pt NP-doped  MoS2,  MoS2-rGo and of bare rGO. Pt NP-doped  MoS2 showed the highest response for the  NO2 adsorption. **c** Selectivity profile. Reproduced with permission from Ref. [42]. Copyright (2012) Wiley-VCH. **d** Au NP-doped  MoS2. **e** Response profile with different concentrations of Au decorated  MoS2 and with UV light exposure. **f** Band alignment of  MoS2 and Au NPs and mechanism of  NO2 adsorption. Reproduced with permission from Ref. [121]. Copyright (2018) AIP Publishing. **g** Different concentration W metal loaded  MoS2. **h** Sensor response profiles of W loaded  MoS2. **i** Response and recovery profile for 20 ppm  NO2 exposure. Reproduced with permission from Ref. [320]. Copyright (2020) Elsevier 

between the  MoS2 and  NO2 molecules. Hence,  NO2 desorption is difficult from  MoS2, which leads to the sluggish recovery. Metal doping is an efficient way to improve the sensing performance. Here, authors doped  MoS2 with atoms of W metal which have close radii to Mo atoms. There are no additional defects produced in  MoS2 due to comparable radii of the Mo and W atoms. Thus the defects in  MoS2 are significantly suppressed with W metals, and  NO2 sensing performance is enhanced. The highest sensor response achieved was 56.91% in  W2 sample, can be seen from Fig. 14h. Interestingly, the response and recovery were the fastest for the sample  W2. The observed response and recovery time were 24 and 19 s, shown in Fig. 14i. 

It is clear from the proposed discussion that metal NPs doping is an efficient way to enhance the gas-sensing performances of  MoS2 gas sensors. Metal (NPs) doping not only improved the chemical and catalytic reactivity in  MoS2 but also affected the electronic properties. Metal NPs formed nano-Schottky barriers in different regions of the  MoS2, which greatly increases the transfer of charges in  MoS2. Thus, metal (NPs) doping also helps in full recovery of the  MoS2-based NO2 sensors with improved sensor response, selectivity and long term stability. In addition, illuminating the metal (NPs)doped  MoS2 sensors could improve the sensing characteristics. However, some more rigorous efforts are still needed to completely explore the effect of light illumination on metal-doped MoS2. 

1 3 

**38** Page 32 of 58 

Nano-Micro Lett. (2021) 13:38 

##### **5.4  Vacancy‑Driven  NO2 Sensors** 

Vacancies in  MoS2 played a key role and contributed to increased efficiency in gas sensing. Long et al. synthesized 3D  MoS2 aerogel by the thermal decomposition technique [24]. A two-step sulfur treatment method was employed to fabricate the  NO2 gas sensor. Figure 15a and its inset shows surface morphology without treatment and with treatment. The  MoS2 aerogel became more pours after the sulfur treatment. The  MoS2 aerogel showed a high sensor response to NO2 gas at RT, and a rapid response and full recovery with the sulfur treatment device. The as prepared  MoS2 aerogels showed a good sensor response. However, due to the strong bonding of  NO2 with  MoS2, it suffered from slow response and recovery. The sulfur treatment in the  H2 ambient produces new sulfur vacancies. The elevated temperature generally removes the S atoms from  MoS2 and increases the vacancies in sensing film. Figure 15b, c displays the resistance versus time profile for 50 ppb  NO2 concentration at 200 °C. Furthermore, the response and recovery time were further improved with the temperature attributed to the fast desorption of  NO2 molecule at high temperature. Donarelli et al. reported the formation of n and p-type  MoS2 flakes annealed at 250 and 150 °C [31]. The SEM image of  MoS2 flakes deposited onto the  Si3N4 with Pt electrodes is shown in Fig. 15d. Figure 15e, f shows the relative response of MoS2 flakes to 150 and 250 °C. With the electron acceptor nature of  NO2, the resistance of the  MoS2 device annealed at 150 °C was decreased while resistance was increased at 250 °C. The device annealed at 150 °C did not respond at RT but a high sensor response was obtained at RT when the device was annealed at 250 °C. Moreover, the sensor showed better sensing performances with 250 °C annealed devices. The n-type and p-type behavior of different devices can be understood in terms of used synthesis method. The NMP was used for the synthesis of  MoS2. The NMP intercalate in between the  MoS2 layers at 150 °C. The NMP degraded and introduced the N atom at the S vacancy sites. N atom is an electron acceptor and responsible for p-type behavior [322]. In addition,  MoS2 surface was partially reduced to  MoO3 layers and more S and O vacancies were created when  MoS2 flakes are annealed at 250 °C [323]. The interaction between NO2 sensing and n-type  MoS2 is crucially dependent on the 

S and O vacancies [324]. Equations 16 and 17 demonstrate the possible reaction mechanism between p-type  MoS2 and NO2. 



<!-- Start of picture text -->
MoS2 + VS + NO2 + e − CB → MoS2 + (NO 2 − + VS) (16)<br><!-- End of picture text -->



<!-- Start of picture text -->
MoO3 + VO + NO2 + e − CB → MoO3 + (NO 2 − + VO) (17)<br><!-- End of picture text -->

where (NO<sup>−</sup> 2<sup>+ VO) and (NO2+ e−) are the adsorbed  NO2 on</sup> the oxygen and S vacancies. e<sup>−</sup> CB<sup>is the electron in the con-</sup> duction band. Hence,  NO2 interacts with e<sup>−</sup> CB<sup>and leads to a</sup> decrease in the conduction band electrons with an increase in the resistance of the electrons. 

Kumar et al. annealed the vertical aligned  MoS2 flakes at 600 °C to obtain vacancy-enriched  MoS2 flakes. The S atom has low binding energy of (2.12 eV). Hence annealing the  MoS2 flakes at higher temperatures could be useful to create the S vacancies. Further, the  MoS2 flakes were decorated with the crumpled rGO. The FESEM image of vertical aligned  MoS2 flakes is shown in Fig. 15g and rGO decorated flakes showed in the inset of Fig. 15g. The dynamic sensing response of pristine  MoS2, Sv-MoS2, rGO-MoS2, and rGO/Sv-MoS2 investigated at 50 °C with 50 ppm  NO2 concentration and showed in Fig. 15h. 

The  NO2 sensor response was 27%, 34%, and 39% for pristine  MoS2, Sv-MoS2, and rGO-MoS2, respectively. However, the full recovery and high sensor response of 72% was achieved with rGO/Sv-MoS2. The oxygen present in rGO formed strong bonds with S vacancies of  MoS2 and attracted 0.997 electrons from  MoS2/rGO. Therefore, there was sufficient transfer of charge between the  MoS2 and rGO which modified the nature of  MoS2 from n-type to p-type. S vacancies specifically play a major role in the charge transfer between  MoS2 and rGO. When  NO2 molecules were exposed to rGO/Sv-MoS2, electrons were depleted from rGO to  MoS2 and the Fermi level of rGO shifted towards the valence band. Hence, a large number of electrons transferred from the  MoS2 to rGO. Also, further NO2 exposure enhances the holes in  MoS2 and therefore MoS2 behaves as a p-type. The schematic of the proposed mechanism is shown in Fig. 15i. 

The role of vacancies in gas sensing has been cleared from the above discussion. The vacancies can change the electronic, optical, and chemical activity of the  MoS2. The gas molecules interaction at these vacancies sites 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 33 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
(a) (b) 4 12 (c) 200 °C<br>200 °C<br>10 0<br>3 8 100 °C<br>200 nm −10<br>6<br>2 4 25 °C<br>−20<br>2 0.5 ppm<br>50 ppb<br>1 0 −30<br>200 nm 0 20 40 60 80 100 120 0 5 10 15 20 25 30<br>Time (min) Time (min)<br>(d) (e) (f) 1.5<br>25 °C 100 °C 150 °C 200 °C 25 °C 100 °C 150 °C 200 °C<br>10 7<br>500 nm 10 6 1.0<br>10 6<br>0.5<br>30 µm<br>10 5 10 5 0.0<br>0 180 360 540 720 0 180 360 540 720<br>(g) Time (min) Time (min)<br>(h) 5040 NO2 50 ppm NO2 (i) NO2 NO2 −<br>e −<br>20<br>5 µm<br>0<br>0 100 200 300 400 500 600 700<br>−20 Time (s)<br>−40 rGO/MoS2<br>Sv-MoS2<br>−60 MoS2<br>5 µm rGO/Sv-MoS2 h h h h h h<br>−80<br>hole transport<br>)/R(R−Rairairgas<br>Resistance (MOhm)<br>NO concentration (ppm)2<br>Resistance ()Ω<br>NO concentration (ppm)2<br>Relative response (∆R/R%)<br><!-- End of picture text -->

**Fig. 15  a** FESEM image of 3D  MoS2 aerogels. **b** Response of  MoS2 aerogel with  NO2 at 200 °C. **c** Device response to  NO2 at different temperatures. Reproduced with permission from Ref. [24]. Copyright (2017) Wiley-VCH. **d** FESEM image of  MoS2 flakes distributed on the Pt electrodes.  NO2 response of the  MoS2 flakes: **e** annealed at 150 °C showed p-type behavior; **f** annealed at 250 °C showed n-type behavior. Reproduced with permission from Ref. [31]. Copyright (2015) Elsevier. **g** FESEM image of sulfur vacancy-enriched  MoS2 flakes. **h** Response of 50 ppm  NO2 with  MoS2, rGO/MoS2, Sv-MoS2, rGO/Sv-MoS2. rGO deposited Sv-MoS2 shown p-type behavior. **i** Mechanism of  NO2 interaction with rGO deposited Sv-MoS2. Reproduced with permission from Ref. [310]. Copyright (2019) IEEE 

is governed by the chemisorption process. Thus, the vacancy-enriched  MoS2 has enhanced  NO2 sensing performance in terms of sensor response and speed. The vacancies can be tailored through morphology and these vacancies work as the active sites to enhance the gas molecules adsorption. Moreover, the functionalization of vacancies with substitutional atoms can change their electronic nature from n-type to p-type such as N, B, O, and Ni. Another important aspect on the vacancies is the effect of the high temperature annealing of the  MoS2 film. The high temperature ~ 500–600 °C annealing can generate the more vacancies in  MoS2 which will be helpful in designing the high-performance  NO2 sensors based on MoS2. 

##### **5.5  Light‑Assisted  NO2 Sensors** 

The  MoS2 has shown high adsorption energy for  NO2 molecules at RT.  NO2 is adsorbed through the chemisorption and physisorption process on the  MoS2 surface. This high adsorption energy causes difficulty in the full recovery of  MoS2.  MoS2 requires additional efforts to remove adsorbed  NO2 molecules for complete recovery at RT. The one possible solution is to isolate the device temporarily from the toxic environment for complete recovery at high temperatures. However, to develop real time  NO2 sensor, this method is not feasible. Moreover, it demands necessary engineering efforts which will raise 

1 3 

**38** Page 34 of 58 

Nano-Micro Lett. (2021) 13:38 

the cost of the sensor and time consuming process. In order to accelerate the desorption rate of  NO2 molecules from the  MoS2 surface, researchers used thermal energy to achieve the fast and full recovery of  MoS2-based  NO2 sensors. However, there are certain disadvantages of running sensors at elevated temperatures. The speedy recovery is achieved at the cost of the lower sensor response. In addition, it also deteriorates the sensor’s long term stability, which raises the complexity and cost of manufacturing sensing devices. Thus, it is not an effective way to run the  NO2 sensor at high temperatures. The light illumination could be an effective way to enhance the sensing performance of  MoS2-based sensors while keeping the sensor at RT. The light illumination greatly influences the adsorption, desorption and the adsorption energy. Here, we will focus on the impact of light illumination on the  NO2 sensing in this section. We have divided the light illumination into three parts UV light illumination, visible light illumination and finally in the NIR illumination. 

##### **_5.5.1  Ultraviolet‑Activated NO2 Sensor_** 

Kumar et al. studied the role of the UV light in developing the RT  NO2 sensor [119]. The CVD grown in-plane  MoS2 flakes was utilized for  NO2 gas sensing. The device schematic is shown in Fig. 16a. The  NO2 sensing was carried out at RT, 100 °C, and with UV illumination at RT (Fig. 16b, c). Among them, the highest sensor response with full recovery was found with the UV light illumination at RT (Fig. 16c). The sensor did not recover fully at RT without UV lighting. The sensor response under tunable UV light intensities from 0.3 to 2 mW  cm<sup>−2</sup> was tested. The sensor response was lowest at 2 mW  cm<sup>−2</sup> and the highest sensor response was recorded at 1.2 mW  cm<sup>−2</sup> . The high light intensity allows NO2 molecules to desorb easily than their adsorption. Thus, NO2 sensor response was lowest at a high light intensity. 

Agrawal et al. utilized mixed  MoS2 flakes for  NO2 sensing [120]. The  NO2 sensing at RT, 125 °C, and with UV light illumination at RT was explored. The highest sensor response, fast and full recovery were obtained with UV light illumination at RT. The schematic of the mixed  MoS2 flakes with possible  NO2 adsorption sites, the response of mixed MoS2 flakes and comparative sensor response under UV light is shown in Fig. 16e–g. The gas-sensing mechanism for 

both the studies is discussed as follows. The sensing behavior of  MoS2 flakes is highly dependent on the surface morphology, the number of active sites and notably on the defects in the form of vacancies. The environmental impurities such as oxygen and humidity get adsorbed on these defects. The adsorbed oxygen takes the electrons from the  MoS2 flakes and introduces p-type doping. At RT without UV light illumination, a high amount of oxygen is adsorbed on the  MoS2 flakes and a large number of electrons are extracted from MoS2 flakes. Owing to the electron acceptor,  NO2 withdrawn electrons from the  MoS2. However, the desorption rate is not fast due to the strong bonding of  NO2 and led to incomplete recovery. Moreover, when thermal energy is added in  MoS2 from external sources, some oxygen in the  MoS2 flake is desorbed and more fresh active sites in the form of defects are formed. In addition, thermal energy speeds up the desorption process that causes the sensor response to decrease. The desorption rate of oxygen molecules was highest under UV illumination. UV light illumination generates new electron and hole pairs. The photogenerated holes react with adsorbed oxygen and adsorbed oxygen gets released from the  MoS2 surface. The UV light illumination creates more fresh active sites. On these fresh active sites, the  NO2 molecules get adsorbed and increase sensor response. Moreover, when  NO2 gas turned off, the adsorbed oxygen reacted with the photogenerated electrons and desorbed easily from the MoS2 surface. The recovery rate therefore improves under UV lighting. The proposed sensing mechanism for both the reports is shown in Fig. 16d, h. 

Zhou et al. fabricated an ultrasensitive, fast UV assisted, RT  NO2 sensor [325]. The detection limit of the fabricated MoS2/ZnO  NO2 was very low (50 ppb). The n-type ZnO NWs were synthesized using the hydrothermal process, while the ultrasonic method was used to synthesize the p-type  MoS2. Two types of sensors were fabricated with different composites amount of  MoS2 and ZnO such as  MoS2/ZnO (0.5:0.25) and  MoS2/ZnO (0.25:0.25). The device schematic is shown in Fig. 16i. The bare  MoS2 device did not show any  NO2 sensing capability which may be due to the low conductivity of the flakes. However, both devices exhibited significant sensor response under UV exposure. Moreover, devices with equal  MoS2 and ZnO composites showed better  NO2 sensing performance under UV light illumination, can be seen from Fig. 16j. The gas-sensing mechanism was proposed based on the band alignment as shown in Fig. 16k, l.  MoS2 has p-type nature and electrons transferred from the  MoS2 conduction 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 35 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 



<!-- Start of picture text -->
UV light<br>(e)<br>(a) (i)<br>MoS2/ZnO<br>NO2 UV NO2 TS<br>e − H NO2 e − B Source<br>Au/Cr<br>Au/Cr<br>Drain<br>h +<br>SiO2<br>Mo S NO2 N +  Si(100) SiO2 Au/Ti Sensing Au/Ti<br>layer gate<br>36<br>(b) UV 100 ppm −28 (f) Sensitivity (%) 200 (j) MoS2/ZnO (0.5:0.25) 200 ppb<br>50 ppm MoS2/ZnO (0.25:0.25)<br>27<br>10 ppm −21 150<br>18 5 ppm −14 100 100 ppb 150 ppb<br>N2<br>9 −7 50 NO2<br>50 ppb<br>0<br>0<br>0 500 1000 1500 2000 0<br>Time (s) 0 1000 2000 3000 0 40 80 120 160 200<br>Time (s) Time (min)<br>36<br>(c) UVRT −28 (g) (k) MoS2 ZnO<br>100 °C Evacuum<br>30<br>−21<br>24 −14<br>Ec Ec<br>18 −7 EF EF<br>Ev<br>12 0 Ev<br>0 40 80 120 RT 125 °C  RT + UV<br>(d) Before NO NO 2 2 (ppm) After NO2 (h) O2 − O2 − e − e − O2 − O2 − eO − 2 − O 2 − (l) MoS2 − Built-in field + ZnO<br>Cleaned MoS2 O2 − O 2 −<br>e −<br>Without UV light at RT Ec e −<br>Temp UV Lamp UV light e − − +<br>EF<br>Ev UV light e −<br>Top view of MoS2 Oe2 − e − O2 e − eO − 2 e − h +<br>With UV light at RT − + h +<br>RT<br>UV<br>Senstivity (%)<br>Response (%)<br>Relative response (∆R/R%)<br>5.22 eV 4.0 eV 4.35 eV 4.5 eV<br>Senstivity (%) 1.4 eV<br>3.25 eV<br>Relative response (∆R/R%)<br><!-- End of picture text -->

**Fig. 16  a** Schematic view of the proposed device under UV illumination. **b** NO2 response under UV light, **c** comparative performance under UV at RT, RT, and at higher temperature. **d** Working mechanism. Reproduced with permission from Ref. [119]. Copyright (2017) American Chemical Society. **e** Proposed working mechanism under UV light. **f** Sensor response profile under UV light. **g** Comparative  NO2 sensing bar profile. **h** Working mechanism under UV illumination. Reproduced with permission from Ref. [120]. Copyright (2018) American Chemical Society. **i** Device schematic for  NO2 sensing. **j** NO2 response with different concentration  MoS2/ZnO composite device. **k** , **l** Band alignment before the junction and after the formation of contact with  NO2 exposure. Reproduced with permission from Ref. [325]. Copyright (2018) The Royal Society of Chemistry 

1 3 

**38** Page 36 of 58 

Nano-Micro Lett. (2021) 13:38 

band to the ZnO conduction band under UV illumination. Thus, the photogenerated charge carriers were segregated efficiently and prevent further recombination. 

##### **_5.5.2  Visible Light‑assisted NO2 Sensors_** 

The UV light illumination has evidently proved its significance and its critical role in achieving the fast recoverable NO2 sensors for the RT. However, the UV illumination has certain disadvantages as well. Practically, the use of UV light is still a vivid challenge. UV radiation is harmful to human wellbeing. World cancer research agency identified that the continuous use of UV radiation is harmful to humans. Continuous exposure of UV light can cause premature aging of the skin in terms of wrinkles, leathery skin and solar elastosis. UV radiation is therefore particularly harmful to human vision. UV radiation can easily damage the corona of the eyes. The UV rays can significantly affect the immune system. Furthermore, the cost of UV lamps is 

very high. Therefore, it is essential to study the role of visible light on the gas sensing. 

Late et al. studied the role of light exposure in  NO2 gas sensing. Traditionally, the UV light is the most adopted light source for sensing measurements. However, continuous UV light exposure may degrade the sensing performance of the device and harmful to humans [327]. Thus, the authors used safe green light of 532 nm to perform the  NO2 gas-sensing measurements. 

The irradiated green light has tunable power densities from 4 to 50 mW  cm<sup>−2</sup> . The highest resistance change has been observed with higher incident power, which is attributed to the higher number of photogenerated electrons and holes with higher incident light power. The change in the resistance with incident light power density is shown in Fig. 17a. With light illumination, the desorption rate of NO2 gas molecule is relatively high in comparison with the adsorption rate. Moreover, a small fraction of electrons reacts with  NO2 gas due to the high power density of incident light. Therefore, the  NO2 sensor response is reduced 



<!-- Start of picture text -->
(a) 1 (b) 180 No light<br>160 4 mW cm −2<br>15 mW cm −2<br>140<br>120<br>100<br>Light on<br>80<br>Gas on<br>60<br>40<br>0.1<br>4 mW cm −2<br>20 Gas off<br>15 mW cm −2<br>50 mW cm −2 0<br>500 1000 0 500 1000 1500 2000 2500 3000<br>Time (s) Time (s)<br>(c) 250 NO2 (d) 15<br>NH3 10 NH3<br>200<br>Gas on<br>Gas off 5 Gas on<br>150<br>Light source<br>100 moleculesGas 0<br>50 −5<br>NO2<br>Light on MoS2 device<br>0 −10<br>0 20 40 60 80 100 120 140 160 60 80 100 120 140 160<br>Time (s) Time (s)<br>S (%)<br>Normalized resistance<br>Gas off<br>Current (µA) Sensitivity (%)<br><!-- End of picture text -->

**Fig. 17  a** Effect of power density on the resistance. **b** Effect of power density on the  NO2 response. Reproduced with permission from Ref. [17]. Copyright (2013) American Chemical Society. **c** Detection of the  NO2 and  NH3 exposure with 650 nm wavelength exposure. **d** Change in the sensor response under light illumination. Reproduced with permission from Ref. [326]. Copyright (2015) American Chemical Society 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 37 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

with a high incident power density as shown in Fig. 17b. The full recovery is obtained with green light illumination. Similarly, Cho et al. synthesized atomic layered  MoS2 and illuminated device with 650 nm red light [326]. The schematic of the device is shown in the inset of Fig. 17c. The photogenerated current increased rapidly when the red light was turned on after 30 s.  NO2 gas was turned on after 60 s. The current increased further implying the p-type characteristic of the  MoS2 flakes. The calculated sensor response with red light illumination is shown in Fig. 17d. 

##### **_5.5.3  Near‑Infrared (NIR)‑Assisted NO2 Sensor_** 

Xia et al. recently used NIR light to develop sensitive fast NO2 sensor with sulfur vacancy-enriched  MoS2 flakes [123]. The conventional  MoS2 (C-MoS2) and sulfur vacancyenriched  MoS2 (S-MoS2) flakes were synthesized by the traditional microwave-hydrothermal method. The sulfur vacancies were investigated by the electron paramagnetic resonance (EPR), XPS, and XRD. The schematic structure 

of C-MoS2 and Sv-MoS2 is shown in Fig. 18a. Further, the absorption spectroscopy has been performed for both the C-MoS2 and Sv-MoS2 which revealed the high absorption of NIR light by Sv-MoS2. The  NO2 sensing ability of the C-MoS2 and Sv-MoS2 is shown in Fig. 18b, c. Interestingly, the observed sensor response with Sv-MoS2 was high in the presence and in the absence of NIR light. The presence of S vacancies modulated the band structure of  MoS2 flakes and generated three additional localized states in  MoS2 bandgap, i.e., two unoccupied states at 0.63 eV below the conduction band and one shallow state near the valence band (Fig. 18d, e). Both additional states narrow down the  MoS2 bandgap in contrast with the pure  MoS2 bandgap. Hence, Sv-MoS2 showed a high NIR photoresponse. 

The S vacancies quickly reduced the Gibbs free energy of adsorbed gas molecules and increased the electron transfer rate from  MoS2 to  NO2. The Sv-MoS2, therefore provides enhanced sensing efficiency not only in the dark but also with NIR lighting. The gas sensing performances of light driven  MoS2-based  NO2 sensors summarized in Table 4. 



<!-- Start of picture text -->
1.2<br>(b) C-MoS2 Air<br>Dark<br>(a) Mo atom S atom S vacancy 1.0 NIR light<br>0.8<br>0.6 200 ppb<br>NO2<br>0.4<br>0.2<br>0.0<br>NIR light active SV-MoS2 0 200 400 600 800 1000<br>Time (s)<br>(c) 50 Air SV-MoS2 (d) 2.0 (e) 2.0<br>200 ppb 1.5 1.5<br>40 NO2 DarkNIR light 1.0 1.0<br>30 0.5 0.5<br>20 0.0 0.0<br>10 Air −0.5 −0.5<br>−1.0 −1.0<br>0<br>0 200 400 600 800 100012001400 −1.5 −1.5<br>Time (s) K G M K K G M K<br>Response (%)<br>Response (%) Energy (eV) Energy (eV)<br><!-- End of picture text -->

**Fig. 18  a** Schematic of NIR light-activated sulfur vacancy-enriched  MoS2 (Sv-MoS2). **b** Response of C-MoS2 in dark and NIR with  NO2 exposure. **c** Response of Sv-MoS2 in dark and NIR with  NO2 exposure. Band structure of **d** C-MoS2 (blue) and **e** Sv-MoS2 (red). Reproduced with permission from Ref. [123]. Copyright (2019) American Chemical Society. (Color figure online) 

1 3 

**38** Page 38 of 58 

Nano-Micro Lett. (2021) 13:38 

|References|[119]|[120]|[325]|[328]|[329]|[122]|
|---|---|---|---|---|---|---|
|Rec. time|350|146.5|60|63.9|72|65|
|Res time|29|6.1|60|–|258|16|
|S (%)|35.16|21.78|188|25.3|293|670|
|T (°C)|RT + UV|RT + UV|RT + UV|RT + UV|RT + UV|RT + 625|
|_P_/_λ_(mW/cm2/nm)|1.2/365|3/365|1/365|0.29/365|360|4/625|
|(ppm)|||||||
|Conc.|100|10|50|10|10|0.4|
|Device|Resistor|Resistor|FET|Resistor|Resistor|Resistor|
|Def.|(_R_gas−_R_air)<br>_R_air|(_R_gas−_R_air)<br>_R_air|(_R_gas−_R_air)<br>_R_air|_R_gas<br>_R_|air<br>(_R_gas−_R_air)<br>_R_air|(_R_gas−_R_air)<br>_R_air|
|Electrodes|Au/Cr|Au/Cr|Au/Ti|Pt|ITO|Cr/Pd/Au|
|Method|CVD|CVD|Hydrothermal|CVD|Ultrasonication|CVD|
|sing film|ti  MoS2|MoS2|S2/ZnO|S2|/MoS2|MoS2|
|Sen i|Mul|Mix|Mo|Mo|ZnO|1L|



These studies revealed that under light illumination gassensing performance of  MoS2 is critically affected. Light illumination is a promising approach to enhance the sensor response of  MoS2 in comparison with providing thermal activation. The electrons and holes pairs generated due to light illumination provide a sufficient number of charge carriers to increase the gas-sensing response of the  MoS2 sensors. Traditionally, UV light is the most verified technique to enhance the sensor response of gas sensors and also with  MoS2. UV illumination provides better treatment of adsorbed ambient oxygen than thermal energy. UV illumination significantly cleans environmental oxygen from the  MoS2 surface without any structural loss than the thermal energy. But, long term exposure of UV is not good for living cells. 

Furthermore, the integration of  MoS2 with  NO2 sensitive materials could be helpful in developing ultrasensitive  NO2 sensors at RT with light.  MoS2-Heterojunctions rapidly separate the generated electron and holes pairs due to light and  NO2 exposure, which will improve the gassensing performance. 

MoS2 has a high absorption coefficient in the visible region of spectrum of spectrum. Thus, a large number of electrons generate in  MoS2 in visible region and  NO2 has high number of electron available to withdraw from  MoS2 surface. However, with UV light, the number of generated electrons holes pairs are not so high. So, utilizing the visible spectra in gas sensing could be a better and safe approach to fabricate the high-performance gas sensors. To further utilize the NIR spectra, some engineering efforts may be needed to enhance the absorption of  MoS2 in NIR. Use of NIR light sources will reduce the high cost of the sensors in comparison with UV and visible light sources. 

### **6  MoS2‑Heterostructure  NO2 Sensor** 

Advancement in  MoS2 gas sensors can be achieved by forming the heterostructures. The production of single or few layer  MoS2 is considered not an easy approach and limits the high throughput of gas sensor. Ambiguity in the gas-sensing mechanism of  MoS2 with  NO2 gas has also been a topic of debate. Integration of  MoS2 with other materials such as graphene derivative, metal oxides and carbon materials create heterostructure at the junction. The formation of heterostructure affects the gas-sensing properties in both positive and 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

Page 39 of 58 **38** 

Nano-Micro Lett. (2021) 13:38 

negative aspects. Forming a heterojunction can improve the intrinsic electronic properties of  MoS2 that tends to improve the sensor response and recovery time. However, the integration of heterostructure also puts a bit of complexity in the gas-sensing mechanism. Here, in this section, we tend to summarize the advancement in the material of different dimensions with  MoS2 equipped gas sensor over time. 

Despite showing high sensor response by few layer MoS2-based TFT sensor, their low conductivity limits the performance of device [34, 218]. The high surface to volume ratio of graphene and its derivatives opened up possibilities of hybrid gas sensors, where graphene and its derivative provided better electrical conductivity to the device. Theoretical calculations done using DFT have expounded that pollutant gases, like  NO2, NO, and  SO2, firmly interact with  MoS2 surfaces. Numerous experimental confirmations of these theoretical results have been reported. A three-layer-grown MoS2-based resistive sensor showed a  NO2 detection limit of 120 ppb in dark conditions [326]. 

In order to improve the sensing behavior, the blending of MoS2 with graphene nanosheet was adopted [42, 330, 331]. To enhance the sensor response and selectivity to  NO2 more, a composite of reduced graphene oxide (rGO) and  MoS2 was prepared [332]. The p-type nature of rGO, due to oxygen and water doping and n-type nature of  MoS2 make p–n junction. MoS2 provided selectivity and sensibility, while rGO had provided betterment in electronic properties. Zhou et al. also fabricated rGO/MoS2 gas sensor for  NO2 detection [333]. The fabricated composite structure showed 200% enhanced performance than the bare rGO sensor. The device showed sensing response of 59.8% towards 2 ppm  NO2 at 60 °C. 

On the contrary, Long et al., fabricated gas sensor using MoS2/graphene hybrid aerogel for  NO2 detection [118]. The MoS2/graphene-based sensor showed ultralow detection limit of 50 ppb  NO2. The hybrid was integrated over low power micro heater for temperature-dependent gas detection measurement and on heating at 200 °C sensor show improved recovery and response time of less than 1 min compared to RT measurements. The schematic and optical image of the device with microheater is shown in Fig. 19. 

Many other works have been reported where the sensing performance was improvised by using graphene over  MoS2 [334, 335]. Despite the good selectivity of the  MoS2/rGO sensor, the  MoS2 has serious issues like agglomeration on the substrate. Therefore, the fabrication of  MoS2 gas sensor with enhanced sensing activity was a challenge. CdS was used as sensing material and assumed to provide good electron transfers between heterostructure [336]. 

Tabata et al., fabricated gate tunable  MoS2/graphene  NO2 sensor [29]. To understand the role of only heterojunction, the other gas-sensing parts were passivated by the gas barrier layer. Poly methyl methacrylate (PMMA) was used as gas barrier layer. The device showed the strong dependencies on the type of bias (forward or reverse) and back gate voltage. With an increase in reverse bias and negative gate voltage device showed better performance. Jung et al. also fabricated the flexible gas sensor by transferring the  MoS2/ rGO on the PET substrate that showed optical transmittance ~ 93% [337]. The flexible  MoS2/rGO showed good performance at a bending radius of 14 mm and detection as low as 0.15 ppm of  NO2. 



<!-- Start of picture text -->
(a) Heater (b)<br>Sensor Heating area<br>A<br>Pt/Ti LSN LSN P/tTi<br>Silicon<br>Substrate<br>Poly-Si<br>Poly-Si<br><!-- End of picture text -->

**Fig. 19  a** Schematic diagram of  NO2 gas sensor with microheater sensor. **b** Optical image of poly-silicon microheater with Pt/Ti electrodes. Reproduced with permission from Ref. [118]. Copyright (2016) Wiley-VCH 

1 3 

**38** Page 40 of 58 

Nano-Micro Lett. (2021) 13:38 

On the contrary, Ikram et al. used a thin layer of In(OH)3 on the  MoS2 nanosheets to improve the performance of  NO2 gas sensor [338]. The presence of point and line defects in MoS2/In(OH)3 improves the electrical conductivity and provides the accessibility of active sites for target gas. The ease of fabrication of  MoS2/MoO3 composites in one step has also grabbed attention and the sensor showed a remarkable sensor response of ~ 33.6% with complete recovery to 10 ppm  NO2 at RT [339]. The sensor response of 2D materials to the surrounding critically affect the long-term reliability of the sensing device. Therefore, Shi et al. fabricated a layered device using black phosphorus (BP) as the top gate, Boron nitride as a dielectric layer and  MoS2 as conduction channel [340]. The gas adsorption ability of BP makes it a gas-sensing material and BN isolates the conduction channel of  MoS2 from ambient. The multilayered gas sensor showed a detection limit of 3.3 ppb to  NO2. The  SnS2 nanosheets were also used to fabricate the sensor due to their 



<!-- Start of picture text -->
V<br>NO2 NO2−(Adsorb)<br>e −<br>Ag top contact MoS2 HNPs Ag top contact<br>e −<br>NO2<br>NO2−(Adsorb)<br>Additional<br>access-gate va-CNTs<br>e −<br>Si NO2<br><!-- End of picture text -->

**Fig. 20** Schematic of  MoS2 deposited over CNT-based device. Reproduced with permission from Ref. [342]. Copyright (2017) Wiley-VCH 

high adsorption sites availability and showed response 22.3 times higher than pristine  SnS2 sensor [341]. 

Apart from the integration of 2D nanostructure with MoS2, integration of 1D also offers enhancement in gassensing properties. Deokar et al. fabricated CNT/MoS2based hybrid  NO2 gas sensor [342]. Hexagonal shaped  MoS2 nanoplates were grown on vertical aligned CNTs. Few tens (25, 50, 100) of ppm to hundreds (25, 100) of ppb of  NO2 at RT was monitored. An illustration of the gas-sensing mechanism of 2D/1D heterostructure is depicted in Fig. 20. 

Zhao et al. fabricated a hybrid of  MoS2/porous Si nanowire [343]. The  MoS2 nanosheets were grown by sulfurization of Mo thin film deposited using DC magnetic sputtering. The hybrid device showed better performance than bare  MoS2 and porous Si NW with low detection concentration of 1 ppm. Keeping the success of  MoS2 and porous Si NW in attention, ZnO nanowires were also used in forming the heterostructure [344].  MoS2 was grown by the same sulfurization of Mo thin films deposited by DC magnetic sputtering. The  MoS2 on ZnO NW showed an excellent sensor response, recovery, repeatability and selectivity up to low detection of 200 ppb.  MoS2, that naturally act as n-type semiconductor forms heterostructure with n-type ZnO NW and charge interfacial charge separation takes place. The electron in the CB of  MoS2 flows to the CB of ZnO NWs till their Fermi level gets aligned. The type of heterostructure (type I and type II) can be decided by the band gap and the work function of the two materials. Similarly, other reports were also reported where ZnO nanowires were used with p-type  MoS2 nanosheets to improve the sensors performance [345]. 



<!-- Start of picture text -->
(aI )n ari (bI )n NO2<br>E0 E0<br>E0<br>E0<br>φ 1 = 4.15 eV φ 2 = 4.7 eV φ 1 = 4.15 eV φ 2 = 4.7 eV<br>Ec − − − − Ec Ec − − − − − − Ec<br>EF + − EF EF + + − − EF<br>Eg1 = 3.6 eV + − Eg2 = 1.8 eV + + − − Eg2 = 1.8 eV<br>+ + + EV Eg1 = 3.6 eV + + + + + + EV<br>EV EV<br>n-In2O3 n-MoS2 n-In2O3 n-MoS2<br>Depletion layer Accumulation layer Depletion layer Accumulation layer<br><!-- End of picture text -->

**Fig. 21** Energy band diagram of  In2O3/MoS2 heterojunction in **a** air and **b** NO2 ambient. Reproduced with permission from Ref. [346]. Copyright (2019) Elsevier 

© The authors 

https://doi.org/10.1007/s40820-020-00558-3 

