# Ammonium cations with high pKa in perovskite solar cells for improved high-temperature photostability

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 216 |
| 作者 | Meng-Ru Wang, Zhi-Fang Shi, Cheng-Bin Fei, Zhe-Wen J. D. Deng, Guang Yang, Sean P. Dunfield, D. Fenning, Jin-Song Huang |
| DOI | 10.1038/s41560-023-01362-0 |
| 源文件 | 012_Wang_2023_Ammonium-cations-with-high-pKa-in-perovskite-sol.pdf |

---
https://doi.org/10.1038/s41560-023-01362-0 

# **Ammonium cations with high p** **_K_ a in perovskite solar cells for improved high-temperature photostability** 

Received: 24 March 2023 Accepted: 29 August 2023 Published online: 28 September 2023 

**Mengru Wang**<sup>**1,6**</sup> **, Zhifang Shi**<sup>**1,6**</sup> **, Chengbin Fei**<sup>**1**</sup> **, Zhewen J. D. Deng**<sup>**2**</sup> **, Guang Yang**<sup>**1**</sup> **, Sean P. Dunfield**<sup>**3**</sup> **, David P. Fenning**<sup>**2,3,4**</sup> **& Jinsong Huang**<sup>**1,5**</sup> 

Phenethylammonium (PEA<sup>+</sup> ) and butylammonium (BA<sup>+</sup> ) are widely used in three-dimensional (3D) perovskites to form two-dimensional perovskites at film surfaces and grain boundaries (GBs) for defect passivation and performance enhancement. Here we show that these cations are unstable with 3D formamidinium (FA<sup>+</sup> )-containing perovskites under high-temperature light soaking. PEA<sup>+</sup> and BA<sup>+</sup> are found to deprotonate to amines, which then react with FA<sup>+</sup> to produce (phenethylamino) methaniminium (PEAMA<sup>+</sup> ) and (butylamino)methaniminium (BAMA<sup>+</sup> ), respectively, severely limiting device high-temperature photostability. Removing these cations greatly improves the photostability but compromises device efficiency by leaving non-fully passivated surfaces and GBs. Ammonium cations with a high acid dissociation constant (p _K_ a), including PEAMA<sup>+</sup> (p _K_ a = 12.0) and BAMA<sup>+</sup> (p _K_ a = 12.0), can replace PEA<sup>+</sup> or BA<sup>+</sup> for passivation and are stable with FA-based perovskites due to their resistance to further deprotonation. P–i–n structure solar cells with PEAMA<sup>+</sup> additive maintained over 90% of their initial efficiency after light soaking at open circuit and 90 °C for 1,500 hours. 

Two-dimensional (2D) perovskites have many interesting physical properties due to confinement effects that three-dimensional (3D) perovskites do not have, including exciton dynamics, spin dynamics and electron–phonon coupling<sup>1–3</sup> . Generally, 2D perovskites are considered to be much more stable than their 3D counterparts due to better moisture resistance of the hydrophobic organic cation<sup>4,5</sup> , larger energy barrier to ion migration<sup>6,7</sup> and increased tolerance to structural stress<sup>8,9</sup> . As a result, they have been widely applied in perovskite solar cells (PSCs) to improve device efficiency and stability in various ways<sup>4,10–12</sup> . To overcome their poor carrier transport along the out-of-plane direction, a thin layer of 2D perovskite can be stacked on top of 3D perovskites 

via sequential deposition, which not only protects but also passivates the 3D perovskite surface<sup>10,13</sup> . They can also be incorporated into the grain boundaries (GBs) of 3D perovskites by adding the large organic cations into the precursor solution<sup>14</sup> . The much larger size of these organic cations causes them to be excluded form the 3D lattice to GBs which, in return, stablizes the GBs<sup>5,15</sup> . Additionally, high layer number ( _n_ ) phase-pure quasi-2D perovskites have been developed to retain both the advantages of 3D perovskites—such as good charge transport and carrier lifetimes—and 2D perovskites, such as good stability, but neither their efficiency nor stability have reached the parity of other multi-dimensional perovskites<sup>16,17</sup> . 

> 1Department of Applied Physical Sciences, University of North Carolina at Chapel Hill, Chapel Hill, NC, USA. 2Chemical Engineering Program, Department of NanoEngineering, University of California San Diego, La Jolla, CA, USA.<sup>3</sup> Department of NanoEngineering, University of California San Diego, La Jolla, CA, USA.<sup>4</sup> Materials Science and Engineering Program, University of California, San Diego, La Jolla, CA, USA.<sup>5</sup> Department of Chemistry, University of North Carolina at Chapel Hill, Chapel Hill, NC, USA.<sup>6</sup> These authors contributed equally: Mengru Wang, Zhifang Shi. e-mail: jhuang@unc.edu 

The ability of 2D perovskites to enhance the efficiency of perovskite solar cells as additive or surface capping layer is very evident<sup>4,12,13,18–20</sup> . Among the numerous organic cations reported for 2D perovskites, phenethylammonium (PEA<sup>+</sup> ) and butylammonium (BA<sup>+</sup> ) are the most frequently used ammonium cations. Additionally, they have yielded many certified record power conversion efficiencies<sup>12,13,21</sup> . Encouraging shelf lifetime or even operational stability under light has also been frequently reported<sup>22,23</sup> . Nevertheless, almost all previous studies were conducted at relatively low temperatures. Because the operational lifetime of perovskite solar cells are reaching several thousand hours, higher temperatures are needed to accelerate the operational stability test, as demonstrated by several recent studies<sup>22,23</sup> . Some recent studies have shown poor stability of 2D:3D mixed perovskites and 2D/3D stacking structure at a high temperature of 85 °C, despite their promising stability at a lower temperature of 55 °C<sup>24–27</sup> , which raises concerns about whether 2D:3D mixture structure or stacking structure is viable for long-term stability. The underlying mechanism of 2D:3D interfacial instability is still unclear. 

In this manuscript, we show that several commonly used ammonium cations, including PEA<sup>+</sup> and BA<sup>+</sup> , are not stable with formamidinium (FA)-containing perovskites at 85 °C under illumination. We identify the easy deprotonation of PEA<sup>+</sup> and BA<sup>+</sup> cations as the underlying chemistry for the observed instability. New ammonium cations with high p _K_ a, a parameter characterizing the resistance to deprotonation<sup>28</sup> , were used to replace PEA<sup>+</sup> and BA<sup>+</sup> cations. These devices based on formamidinium caesium (FACs) perovskites not only retain the high efficiencies but also dramatically enhanced the high-temperature photostability of perovskite solar cells. 

## **PEA**<sup>**+**</sup> **induced worse high-temperature photostability** 

PSCs with a structure of indium tin oxide (ITO)/poly[bis(4-phenyl) (2,4,6-trimethylphenyl)amine (PTAA)/FA0.9Cs0.1PbI3/C60/bathocuproine (BCP)/copper (Cu) (Supplementary Fig. 1a) were fabricated via blade coating. A methylammonium (MA<sup>+</sup> )-free perovskite composition with a slight excess of FAI or caesium iodide (CsI) (0.25 mol%) was used to achieve high intrinsic stability<sup>29</sup> . Additionally, 0.25 mol% phenethylammonium chloride (PEACl) (relative to Pb<sup>2+</sup> ) and several other additives were added to the perovskite precursor solution to passivate defects at grain boundaries and film surfaces, which has been widely shown to improve the efficiency and stability of PSCs at relatively low testing temperatures<sup>29–31</sup> . The optimized PSCs yielded a power conversion efficiency (PCE) of 23.3% (Supplementary Fig. 1b). Additionally, they showed remarkably good operational stability when soaked under open circuit condition beneath a white light emitting diode (LED) lamp at 1 sun intensity with a spectrum as shown in Supplementary Fig. 2a. The lamp also heated the devices to a temperature of 55 ± 5 °C. These devices maintained 90% of their initial efficiency after 3,200 hours on operational stability test, as shown in Fig. 1a. However, when the temperature was raised to 85 °C using the testing setup shown in Supplementary Fig. 2b with the actual temperature of perovskites of 90 °C as shown in Supplementary Fig. 2d, the PSCs showed dramatically faster degradation. The efficiencies of the PSCs reduced to 90% of their initial value within ~150 hours (Fig. 1b). Stability data from additional devices is displayed in Supplementary Fig. 3a–d. All photovoltaic parameters, including short-circuit current ( _J_ SC), open circuit voltage ( _V_ OC) and fill factor (FF), rapidly declined. Furthermore, when elevating the measurement temperature to 100 °C, the average _T_ 90 lifetime ( _T_ 90: the time it takes for device efficiency to drop to 90% of initial value) of the devices decreased to ~80 hours. The quick degradation of PSCs at high temperature and under light is not sensitive to encapsulation methods. The PSCs encapsulated with epoxy, polyisobutylene and atomic layer deposition SnO2 all showed quick degradation (Supplementary Fig. 3e). 

The perovskite precursor solutions in this study had several additives to improve device efficiency, including phenethylammonium 

chloride (PEACl), formamidinium hypophosphite (FAH2PO2), formamidinium chloride (FACl), Zinc chloride (ZnCl2) and excess CsI. FAH2PO2 and FACl were added to enlarge the grain size of perovskite films and passivate the non-radiative recombination defects<sup>30</sup> . PEACl was added to passivate the surface and grain boundaries by formation of 2D perovskite and suppress the halide ion migration<sup>32</sup> . ZnCl2 was added to increase device efficiency by optimizing the perovskite morphology and decrease trap density<sup>33</sup> . Excess CsI was added to compensate iodide vacancies and suppress ion migration and defect generation during long-term illumination<sup>29</sup> . We speculated that some additive(s) may induce the quick degradation observed at high temperatures. To verify this, additives were removed one by one from the perovskite precursor solutions, PSCs were fabricated and then the same high-temperature photostability study was conducted (Supplementary Fig. 3g–h). Results showed that the PSCs became much more stable after the PEACl additive was removed from the perovskite precursor solution. As shown in Fig. 1b and Supplementary Fig. 3h, devices without PEACl retained 90% of their initial efficiency over 750 hours at 85 °C under 1 sun light illumination but started with a lower efficiency of ~20%. This suggests that PEA<sup>+</sup> cations were the main reason for the poor photostability of FACs-perovskites at high temperatures; note that chloride was excluded using control studies where chloride was replaced by iodide (Supplementary Fig. 3i). Additionally, to evaluate whether the location of phenethylammonium iodide (PEAI) makes a difference, we removed PEAI in the precursor and instead applied PEAI as surface treatment to the perovskite films. A poor stability was again observed for these PSCs with PEAI surface treatment (Supplementary Fig. 3i). This shows that the PEA<sup>+</sup> cations cause poor high-temperature photostability, regardless of how PEA<sup>+</sup> is introduced into the FACs-perovskites. 

The impact of PEA<sup>+</sup> on FACs-perovskite intrinsic stability was manifested by the perovskite morphology and crystallinity evolution after light soaking at 85 °C for different durations. X-ray diffraction (XRD) results shown in Supplementary Fig. 4 revealed that the crystallinity of FACs-perovskite films with PEA<sup>+</sup> quickly decreased after testing for 260 hours, while FACs-perovskite films without PEA<sup>+</sup> experienced a slower degradation in crystallinity and retained the majority of their initial crystallinity over 860 hours of testing. This is evidenced by a slower decrease in XRD peak intensity and smaller changes in full-width half maximum values of the (001) plane peak. Additionally, cross-sectional scanning electron microscopy (SEM) showed that voids formed along grain boundaries during the stability measurement for films containing PEA<sup>+</sup> (Fig. 1c). This can be explained by the PEA<sup>+</sup> ions that accumulated at the GBs, which damaged the 3D perovskites during the high-temperature light soaking testing. In contrast, devices without PEA<sup>+</sup> did not develop voids even after testing for 860 hours (Fig. 1d). 

Electron beam induced current (EBIC) measurements were conducted to further research the stability of PSCs with and without PEACl. For this measurement, devices with thinner electrodes (30 nm) were deposited so that an electron beam with an energy of 5–15 keV could penetrate through the electrode and electron transport layer (ETL), depositing its energy into the perovskite layer. Monte Carlo simulations of the electron trajectories indicate that 75% of the beam energy was deposited within the ETL and the first 10 s of nanometers (nms) of the perovskite (Supplementary Fig. 5). EBIC results in Fig. 1e reveal that PEA<sup>+</sup> incorporation results in a lower and less uniform current that further decreases over device ageing, in contrast to PSCs without PEA<sup>+</sup> . As can be seen in Fig. 1f, the pristine PSCs without PEA<sup>+</sup> show an average EBIC current of ~3.0 nA. PSCs with PEACl show both a more heterogenous and lower average current collection of ~2.2 nA. Because the devices with PEACl have a larger photocurrent under 1 sun light, we interpret the smaller and more heterogenous EBIC by the faster degradation of the device with PEACl under electron beam. After the devices light soaked under 85 °C 1 sun for 250 hours, the mean current extraction from the device with PEACl decreased to ~1.1 nA. In contrast, the device without PEACl showed a modest increase in current to ~3.7 nA 



<!-- Start of picture text -->
a 25 c With PEACl d Without PEACl<br>0 hours 0 hours<br>20<br>15 55 ± 5 °C, 1 sun Perovskite<br>With PEACl<br>10<br>80 hours 160 hours<br>5<br>0<br>0 600 1,200 1,800 2,400 3,000 3,600<br>Time (h)<br>b 24 160 hours 480 hours<br>20<br>16<br>12 85 ± 5 °C 1 sun<br>8 With PEACl 260 hours 860 hours<br>Without PEACl<br>4<br>0<br>0 200 400 600 800<br>Time (h)<br>e f<br>4<br>4<br>3<br>3<br>2<br>2<br>1<br>1<br>(1) With PEACl (2) With PEACl (3) Without PEACl (4) Without PEACl 0<br>pristine sample  aged sample pristine sample  aged sample  (1) (2) (3) (4)<br>PCE (%)<br>PCE (%)<br>Current (nA)<br>Current (nA)<br><!-- End of picture text -->

**Fig. 1 | Temperature-dependent photostability of FA0.9Cs0.1PbI3-perovskites with PEA**<sup>**+**</sup> **additives. a** , PCE of encapsulate devices with PEACl as a function of measurement time under ~55 °C 1 sun illumination at _V_ OC conditions in N2. Data are presented as mean values of 12 devices ± standard deviation. **b** , PCE of unencapsulated devices with PEACl (five samples) and without PEACl (eight samples) as a function of measurement time under ~85 °C 1 sun illumination at open circuit conditions condition in N2. Data are presented as mean values ± standard deviation. **c** , Cross-sectional SEM images of PSCs prepared with PEACl after stability measurement under 1 sun illumination at 85 °C and open circuit condition for 0, 80, 160 and 250 hours, respectively. Red circles indicate voids 

formed along grain boundaries. **d** , Cross-sectional SEM of PSCs without PEACl after stability measurement under 1 sun illumination at 85 °C and open circuit condition for 0, 160, 480 and 860 hours, respectively. The scale bar in the SEM images is 3 μm. **e** , EBIC mapping of PSCs with or without PEACl before and after ageing at 85 °C under 1 sun illumination for 250 hours. Scale bar is 2 μm. **f** , EBIC current of PSCs with or without PEACl before and after ageing condition. The bars and whiskers show the mean EBIC current value and its standard deviation from five scans taken on each sample before and after ageing condition. Each plot represents the EBIC current from each scan. 

after the same ageing. The faster degradation of current collection during ageing indicates that the PEACl probably creates new mechanisms for the perovskite to degrade under operational stressors. 

## **The mechanism for PEA**<sup>**+**</sup> **induced instability** 

To further understand how PEA<sup>+</sup> cations damage FACs-perovskites, we increased the amount of PEA<sup>+</sup> cations in the FA0.9Cs0.1PbI3 films by directly mixing PEA2PbI4 and FA0.9Cs0.1PbI3 solutions at molar ratios of 2:1 and 1:2 so that the 2D perovskites could be clearly observed in XRD. These mixed films, pure PEA2PbI4 and FA0.9Cs0.1PbI3 were encapsulated by an inert poly(methyl methacrylate) (PMMA) layer with >1 μm thickness and stressed under 1 sun illumination at 120 °C for a further accelerated photostability test. As shown by the XRD patterns in Fig. 2, pure PEA2PbI4 remained unchanged after testing for 260 hours while FA0.9Cs0.1PbI3 decomposed slightly to PbI2, showing the better intrinsic stability of PEA2PbI4 than FA0.9Cs0.1PbI3. For the fresh PEA2PbI4: FA0.9Cs0.1PbI3 mixture films, only 2D phases with _n_ = 1 and/or _n_ = 2 showed up in the XRD patterns. After testing for 130 hours, the mixture films quickly degraded, and a new set of XRD peaks appears at 7.1° and 

14.2° that do not belong to any known low-dimensional perovskites of PEA<sup>+</sup> . This suggests that a chemical reaction occurred between the PEA<sup>+</sup> and FA0.9Cs0.1PbI3 during testing. 

It has been established that amines with lone pairs of electrons can easily attack the electrophilic imine bond in FA<sup>+</sup> cations, even at room temperature<sup>34,35</sup> . We thus hypothesize that PEA<sup>+</sup> and FA<sup>+</sup> ions react via deprotonation of PEA<sup>+</sup> to PEA<sup>0</sup> followed by a quick condensation reaction between PEA<sup>0</sup> and FA<sup>+</sup> to form (phenethylamino)methaniminium (PEAMA<sup>+</sup> ), as shown by the scheme in Fig. 3a. To provide further evidence for this, we verified that the same reaction product could be produced from the reactions of (1) PEA<sup>0</sup> with FA0.9Cs0.1PbI3 and (2) PEAI with FA0.9Cs0.1PbI3. In this study, both PEAI and PEA<sup>0</sup> were spun onto FA0.9Cs0.1PbI3 films, followed by annealing at 120 °C for 0, 130 and 260 hours under 1 sun illumination. The PEAI-treated samples showed the formation of the PEA<sup>+</sup> -based 2D perovskites with _n_ = 1 and _n_ = 2 in the fresh films. These PEA<sup>+</sup> -based 2D perovskites transferred from lower _n_ 2D phases to a higher _n_ 2D phase ( _n_ = 3) after annealing at 120 °C for 130 hours, as shown in Fig. 2e, indicating loss of PEA<sup>+</sup> in the films. Meanwhile, the XRD peak at 7.1° emerged. This new material 



<!-- Start of picture text -->
a b c<br>1:0  2:1 #  1:2<br>* 0 # 0 0<br>*<br>+<br>130 hours + 130 hours 130 hours<br>+<br>260 hours 260 hours<br>+ 260 hours<br>6 12 18 24 30 6 12 18 24 30 6 12 18 24 30<br>2θ (°) 2θ (°) 2θ (°)<br>d e f<br> 0:1 0 * PEAI  0  PEA 0 0<br>+<br>#<br>130 hours + 130 hours<br>130 hours<br>+<br>+ 260 hours<br>260 hours 260 hours<br>+<br>6 12 18 24 30 6 12 18 24 30 6 12 18 24 30<br>2θ (°) 2θ (°) 2θ (°)<br>Intensity<br><!-- End of picture text -->

**Fig. 2 | Phase changes in FACs-perovskite films with and without PEA**<sup>**+**</sup> **under high-temperature light soaking. a** – **d** , XRD of perovskite films that were prepared by mixing PEA2PbI4 and FA0.9Cs0.1PbI3 at different molar rations of 1:0 (pure PEA2PbI4) ( **a** ), 2:1 ( **b** ), 1:2 ( **c** ), 0:1 (pure FA0.9Cs0.1PbI3) ( **d** ). **e** , FA0.9Cs0.1PbI3 perovskite films with PEAI surface treatment. **f** , FA0.9Cs0.1PbI3 perovskite films 

with PEA<sup>0</sup> surface treatment. The films were annealed at 120 °C for 0 hours, 130 hours and 260 hours in a N2 glovebox under 1 sun light soaking. Here the symbol ***** denotes 2D PEA2 (FA) _n_ −1Pb _n_ I3 _n_ +1 with _n_ = 1; **#** denotes 2D PEA2 (FA) _n_ −1Pb _n_ I3 _n_ +1 with _n_ = 2; ♠ denotes 2D PEA2 (FA) _n_ −1Pb _n_ I3 _n_ +1 with _n_ = 3; ☘ denotes FA0.9Cs0.1PbI3; ♦ denotes PbI2 **; +** denotes new product phase with XRD peaks at 7.1° and 14.2°. 

was denoted as PEAMA product hereinafter and could be a lead iodide octahedral-based low-dimensional perovskite. This result resembles that of directly mixing PEAI with FA0.9Cs0.1PbI3, indicating that the PEA<sup>+</sup> -based 2D perovskites reacted with FA0.9Cs0.1PbI3. The same PEAMA product was observed from the reaction of PEA<sup>0</sup> with FA0.9Cs0.1PbI3 as shown by the 7.1° peak in the XRD pattern in Fig. 2f. This indicates the reaction of PEAI with FA0.9Cs0.1PbI3 goes through a deprotonation process to generate PEA<sup>0</sup> . 

To understand why PEA<sup>+</sup> easily deprotonates at high temperature, we examined its acid dissociation constant (p _K_ a), which represents a cation’s deprotonation capacity: 



<!-- Start of picture text -->
[A 0 ] [H + ]<br>pKa (A + ) = − log10<br>[A + ]<br><!-- End of picture text -->

in which [A<sup>0</sup> ], [H<sup>+</sup> ], [A<sup>+</sup> ] represent the concentrations of A<sup>0</sup> , H<sup>+</sup> and A<sup>+</sup> , respectively. The lower the p _K_ a of a cation, the greater its ability to deprotonate. p _K_ a is also temperature dependent based on Van’t Hoff equation<sup>36</sup> : 



<!-- Start of picture text -->
dln (Ka) = Δ H<br>d T RT 2<br><!-- End of picture text -->

Because the acid dissociation is an endothermic reaction, the reaction enthalpy change ∆ _H_ is positive. _R_ and _T_ indicate the ideal gas constant and temperature, respectively. Thus p _K_ a increases with temperature, and deprotonation accelerates at higher temperatures. Figure 3b shows the p _K_ a values of common A-site cations. p _K_ a of MA +, 

ethylammonium (EA<sup>+</sup> ), dimethylammonium (DMA<sup>+</sup> ) and BA<sup>+</sup> have similar values between 10.6 and 10.8 (ref. 37), which are much smaller than those of FA<sup>+</sup> (11.5–13) and guanidinium (GA<sup>+</sup> ) (13.6) (refs. 38–40). The chemical structures of these cations are shown in Fig. 3c. FA<sup>+</sup> and GA<sup>+</sup> differ from other ammonium cations by their conjugated structure with better stabilized electrons, which results in more stable interaction with the proton and thus makes deprotonation more difficult. Among all these cations, PEA<sup>+</sup> has the smallest p _K_ a of 9.8 (ref. 38), explaining its quick deprotonation to PEA<sup>0</sup> and the resultant device degradation under high-temperature photostability study. It is noted that BA<sup>+</sup> , the other most widely used cation for 2D perovskites in perovskite solar cells, also has a small p _K_ a of 10.8. We thus followed the same process to evaluate the protonation and chemical reaction of BA<sup>+</sup> with FA0.9Cs0.1PbI3. As shown in the XRD patterns in Supplementary Fig. 6, the reactions of BAI or BA2PbI4 and FA0.9Cs0.1PbI3 were also observed under high-temperature photostability tests, regardless of whether BAI was mixed directly into or deposited onto the surface of FA0.9Cs0.1PbI3. Similarly, the reaction generated a new phase with XRD peaks at 7.9° and 15.7°, resembling the reaction of BA<sup>0</sup> with FA0.9Cs0.1PbI3. The p _K_ a table also predicts that GA<sup>+</sup> cations should be more stable with FA<sup>+</sup> . To verify this, we introduced 0.2 mol% GAI in PSCs and conducted high-temperature photostability measurements. As illustrated in Supplementary Fig. 7, the addition of GAI did not accelerate the degradation, as evidenced by the retention of 90% of the initial efficiency after a light soaking stability test at 85 °C for 600 hours, in striking contrast to PEA<sup>+</sup> . These results suggest that p _K_ a is a reliable parameter for evaluating the high-temperature photostability of various ammonium cations with FA<sup>+</sup> . However, oversized GA<sup>+</sup> incorporation into FACs-perovskites 



<!-- Start of picture text -->
a b<br>Step I : Cation deprotonation<br>14<br>NH3 endo NH2<br>exo + H<br>PEA + PEA 0 H + 12<br>Step II : Amine/FA + reaction<br>H<br>NH2 N NH2<br>+ H2N NH2 + NH3 10<br>PEA 0 FA + PEAMA +<br>8<br>Cation<br>c Low p K a d<br>PEAMA-FAI3<br>NH3 H2<br>N<br>NH3 NH3 H3C NH3<br>PEA + BA + EA + MA + DMA + PEAMA +<br>High p K a FA +<br>NH2<br>C I –<br>HN NH2 H2N NH2 c<br>FA + GA + a b<br>PEA+ MA+ DMA+ EA+ BA+ FA+ GA+<br>K pa<br><!-- End of picture text -->

**Fig. 3 | Chemical reactions in PEA**<sup>**+**</sup> **/FACsPbI3 films. a** , Reaction scheme of PEA<sup>+</sup> with FA<sup>+</sup> . **b** , Acid dissociation constant (p _K_ a) of common A-site cations in H2O at 25 °C. Orange: low p _K_ a cations; green: high p _K_ a cations. **c** , Chemical structure of common A-site cations in **b** . **d** , Photograph and crystal structure of PEAMA-FAI3 co-crystal. Scale bar: 10 mm. 

may induce local strain and potentially trigger degradation<sup>41</sup> ; therefore, new cations are still needed. 

The rapid degradation of FACsPbI3 with PEA<sup>+</sup> can be explained by the generated ammonia (NH3) by the reaction of PEA<sup>0</sup> and FA<sup>+</sup> . NH3 has a strong coordination with FACsPbI3 and can dissolve it<sup>34</sup> , which can accelerate the decomposition of FACsPbI3 into yellow phases. It also explains the observed void formation at the GBs in the devices with PEA<sup>+</sup> (Fig. 1c), considering that PEA<sup>+</sup> cations are generally excluded to GBs during the crystallization process. The reaction of amines (including PEA<sup>0</sup> ) with FA<sup>+</sup> in solution has been reported to be as fast as seconds at room temperature<sup>34,42</sup> , which was also confirmed in this study. Thus we can reasonably infer that the reaction rate between PEA<sup>+</sup> and FA<sup>+</sup> ions is limited by the PEA<sup>+</sup> deprotonation process. Because light also enhances the mobility of proton, light should also accelerate the deprotonation of PEA<sup>+</sup> in the photostability test. 

## **Passivation additives with high p** **_K_ a** 

Although completely removing PEA<sup>+</sup> ions from the precursor solution improves the high-temperature photostability of the devices, it also reduces the device efficiency because of the exposed unpassivated film surfaces and GBs. A passivator is still needed to enhance the device efficiency. The passivator needs to meet three criteria: (1) it should have a suitable terminal size to fit into A-site vacancy at the perovskite surfaces and GBs; (2) it should have a high p _K_ a to resist deprotonation; (3) it should not react with FA<sup>+</sup> itself. Fortunately, we found that the reaction product of PEA<sup>0</sup> and FA<sup>+</sup> , that is, PEAMA<sup>+</sup> , perfectly meets these criteria. It terminates with an amidinium group with the same size as FA<sup>+</sup> , it keeps delocalized electron structure of FA<sup>+</sup> , making it 

difficult to deprotonate, and its lack of deprotonation prevents further reactions with FA<sup>+</sup> . We calculated the p _K_ a of PEAMA<sup>+</sup> to be 12.0, which is higher than the PEA<sup>+</sup> benchmark. To better understand this cation, we synthesized PEAMAI by the reaction of PEA<sup>0</sup> with FAI, generating white powders. The single crystals of this salt can be formed by the recrystallization process, with a photograph of the crystal shown in Fig. 3d. The crystal structure obtained from single-crystal XRD confirmed the crystal is PEAMAI co-crystallized with two FAI (Supplementary Table 1). The bond lengths of C1–N1 and C1–N2 in PEAMAI are 1.30 Å, which is same as in FAI, indicating the resonance stabilization as we expected (Supplementary Table 2). The<sup>1</sup> H,<sup>13</sup> C nuclear magnetic resonance (NMR) in Supplementary Figs. 8 and 9 confirmed the chemical structure of the obtained salt. The BAMAI was synthesized by the reaction of BA<sup>0</sup> and FAI confirmed by the<sup>1</sup> H,<sup>13</sup> C NMR in Supplementary Figs. 10 and 11. The BAMA<sup>+</sup> showed a similar p _K_ a value of 12.0 with PEAMA<sup>+</sup> . In addition, the synthesized co-crystal was mixed with PbI2 in dimethylformamide (DMF) to fabricate films by spin coating. The XRD pattern in Supplementary Fig. 12 verified that PEAMAI-FAI reacted with PbI2 to form a low-dimensional perovskite phase with XRD peaks at 7.1° and 14.2°, and BAMAI-FAI reacted with PbI2 to form a low-dimensional perovskite phase with XRD peaks at 7.9° and 15.7°. 

To evaluate if PEAMAI is capable of passivating FA0.9Cs0.1PbI3, we used PEAMAI as a surface treatment for FA0.9Cs0.1PbI3. Different from using PEAMAI as additive, using PEAMAI as a surface treatment avoids a perovskite morphology change as shown by the SEM included in Supplementary Fig. 13. The optimized surface treatment using PEAMAI resulted in a 57% increase of steady-state photoluminescence (PL) intensity, accompanied by a small blue shift of the PL peak (Fig. 4a). 



<!-- Start of picture text -->
a b e<br>PEAMA +  surface treatment PEAMA +  surface treatment PEAMA +<br>(001)<br>Control 103 Control Control<br>102<br>13.8 14.0<br>2θ (°)<br>101<br>100<br>650 700 750 800 850 900 950 0 1,000 2,000 3,000 5 10 15 20 25 30 35<br>Wavelength (nm) Time (ns) 2θ (°)<br>c d f<br>PEAMA + PEAMA + 1E+17 PEAMA +<br>Control  103 Control<br>Control<br>102<br>1E+16<br>101<br>100 1E+15<br>650 700 750 800 850 900 950 0 1,000 2,000 3,000 0.30 0.35 0.40 0.45 0.50 0.55<br>Wavelength (nm) Time (ns) E w (eV)<br>g h<br>1.0E–8 PEAMA + n  = 1.33E16 cm –3 1.20 0.57 µs PEAMA +<br>Control<br>n  = 4.89E16 cm –3 Control<br>5.0E–9<br>1.15<br>Fit of PEAMA +<br>0.0E+0 Fit of control<br>1.10 0.35 µs<br>–5.0E–9<br>1.05<br>–1.0E–8<br>1.00<br>30.0 30.5 31.0 31.5 32.0 32.5 33.0 0 1 2 3<br>Time (s) Time (µs)<br>Intensity (counts)<br>Intensity (counts) Intensity (counts)<br>PL intensity (counts)<br>Intensity (counts) –3–1)tDOS (cm eV<br>PL intensity (counts)<br>Current (A)<br>Transient photovoltage (V)<br><!-- End of picture text -->

**Fig. 4 | Passivation of PEAMA**<sup>**+**</sup> **cations. a** , **b** , PL ( **a** ) and time-resolved photoluminescene (TRPL) ( **b** ) of control perovskite films without or with PEAMAI surface treatment. **c** , **d** , PL ( **c** ) and TRPL ( **d** ) spectra of control perovskite films and PEAMA<sup>+</sup> perovskite films formed using PEAMAI additive. TRPL spectra were fitted by a bi-exponential decay function to obtain the carrier lifetime. **e** , XRD of the control perovskite films and PEAMA<sup>+</sup> perovskite films deposited on glass substrates. The inset shows the amplification of the (001) plane peak. 

**f** , tDOS curves of the control and PEAMA<sup>+</sup> devices. Ew is the demarcation energy. **g** , Transient currents of the devices under a step voltage (1.5 V forward bias for ~30 s and zero bias). Arrows represent the time interval for mobile ions to reach the steady state. **f** , Transient photovoltage response of the control and PEAMA<sup>+</sup> devices under continuous AM 1.5 G illumination with laser pulse perpetuation. TPV curves were fitted by bi-exponential decay function. 

Furthermore, the carrier lifetime increased from 390 ns to 496 ns (Fig. 4b), confirming that PEAMAI passivates traps on the perovskite surface. To passivate perovskite GBs, we added 0.2 mol% PEAMAI as an additive in the perovskite precursor solution. The samples with and without PEAMAI are referred to as PEAMA<sup>+</sup> device and control device. We blade coated perovskite films with or without PEAMA<sup>+</sup> on glass substrates and checked material morphology and passivation effect. Adding PEAMAI increased the steady-state PL intensity by 56% (Fig. 4c) and increased the carrier lifetime from 384 ns to 497 ns (Fig. 4d), indicating a reduced density of deep traps. Direct defect density measurement by thermal admittance spectroscopy shows that the trap density of states (tDOS) in PEAMA<sup>+</sup> devices is much lower within the trap band III (Fig. 4f). A previous study indicates that this trap 

band is caused by the amorphous phase in the perovskite material<sup>43</sup> . Therefore, it appears the PEAMAI additive does change the crystallization process and slightly changes the morphology of perovskite film. This is consistent with PEAMA<sup>+</sup> films showing better crystallinity with stronger and sharper XRD peaks (Fig. 4e). 

We estimated the mobile ion concentration in these devices by applying a 1.5 V forward bias for about 30 s to perturb the ion distribution and then measuring the current induced by the back diffusion of ions at zero bias. The measurements were performed in the dark. As shown in Fig. 4g, the mobile ions in the control devices required a much longer time (~5 s) to reach the steady state compared to the mobile ions in the PEAMA<sup>+</sup> -devices (~1 s). Additionally, the mobile ion concentration in the PEAMA<sup>+</sup> devices is three times smaller than the 



<!-- Start of picture text -->
a b<br>1.20<br>25<br>26<br>20 1.15<br>25<br>15 PEAMA + , reverse scan<br>PEAMA + , forward scan 1.10<br>Control, reverse scan<br>10 Control, forward scan 24<br>1.05<br>5<br>23<br>0 1.00<br>0 0.2 0.4 0.6 0.8 1.0 1.2 Control PEAMA+ Control PEAMA+<br>Voltage (V) Device Device<br>c 26 85<br>25 25<br>20 20 24 80<br>15 J sc PEAMA + 15<br>J sc control 22 75<br>10 PCE_PEAMA + 10<br>PCE_control<br>20 70<br>5 5<br>0 0<br>0 100 200 300 18 65<br>Time (s) Control PEAMA+ Control PEAMA+<br>Device Device<br>d e<br>100<br>25 24<br>80 20<br>20<br>PEAMA +<br>16<br>60 Control 15<br>12 85 ± 5 °C<br>40 10 PEAMA +<br>8 Control<br>20 5<br>4<br>0 0<br>300 400 500 600 700 800 900 0 250 500 750 1,000 1,250 1,500<br>Wavelength (nm) Time (h)<br>V oc<br>–2) (mA cm J sc<br>–2)Current density (mA cm<br>PCE (%) PCE (%) FF (%)<br>–2)Current density (mA cm<br>EQE (%) PCE (%)<br>scIntegrated  (mA cm) J –2<br><!-- End of picture text -->

**Fig. 5 | Device performance. a** , _J_ – _V_ curves of the control and PEAMA<sup>+</sup> devices under reverse-scan and forward-scan conditions. An anti-refection coating was used during measurement. **b** , Distribution of PCE, _V_ OC, FF and _J_ SC of the control and PEAMA<sup>+</sup> devices from 20 and 27 devices, respectively. The box plots display the mean, median line, 25–75% box limits and the whiskers represent the minimum and maximum values. Each dot represents one device. **c** , Steady-state 

PCE of the control and PEAMA<sup>+</sup> devices under simulated AM 1.5 G illumination. **d** , EQE and integrated _J_ sc of the control and PEAMA<sup>+</sup> devices. The arrow indicates the line + solid dots represent EQE curves. **e** , PCE of unencapsulated control and PEAMA<sup>+</sup> devices as a function of measurement duration under 85 °C 1 sun illumination at _V_ OC condition in N2. Eight samples were measured. Data are presented as mean values ± standard deviation. 

control devices, again indicating that PEAMAI additive improved the crystallinity of FACs-perovskites. The transient photovoltage (TPV) was measured in Fig. 4h. Devices without and with PEAMA<sup>+</sup> show _V_ OC of 1.06 V and 1.15 V under AM 1.5 G illumination and carrier recombination lifetimes of 350 ns and 570 ns, respectively. They are very close to the measured TRPL lifetime in the films, which indicates the charge transport layers do not introduce additional non-radiative recombination channels and confirms the reduced non-radiative recombination by the PEAMAI additive. 

## **Device efficiency and high-temperature photostability** 

The impact of PEAMA<sup>+</sup> on the performance of FA0.9Cs0.1PbI3 PSCs was investigated. Figure 5a shows typical current density ( _J_ )–voltage ( _V_ ) curves of PSCs with and without PEAMA<sup>+</sup> under both forward 

and reverse scans. The control PSCs had a PCE of 21.2% with a _J_ SC of 24.7 mA cm<sup>−2</sup> , a _V_ OC of 1.07 V and a fill factor (FF) of 80.2%. PEAMA<sup>+</sup> -PSCs had a PCE of 24.1% with a JSC of 25.8 mA cm<sup>−2</sup> , a VOC of 1.14 V, and a FF of 82.1%. The statistical distributions of the _V_ OC, _J_ SC, FF and PCE are shown in Fig. 5b. The steady-state PCEs of the devices with and without PEAMA<sup>+</sup> under AM 1.5 illumination are 20.9% and 23.8%, respectively (Fig. 5c). The external quantum efficiency (EQE) spectra of the devices are shown in Fig. 5d. PEAMA<sup>+</sup> primarily increased the EQE in the long wavelength range, consistent with a longer carrier diffusion length due to reduced non-radiative charge recombination. The calculated _J_ SC from EQE agrees well with the measured _J_ SC. Figure 5e shows the PCE of unencapsulated control devices and PEAMA<sup>+</sup> devices as a function of measurement duration under 85 °C 1 sun illumination under _V_ OC condition in N2. Stability data for each sample are listed in Supplementary Fig. 14a,b. The devices maintained 90% of the initial efficiency after ~800 hours in the 

absence of ammonium cations in the perovskites, while the devices with PEAMA<sup>+</sup> maintained 90% of the initial efficiency after ~1,500 hours. The _J_ – _V_ curves of the PSCs with PEAMA<sup>+</sup> after operational measurement for different durations were exhibited in Supplementary Fig. 14c. Furthermore, the high-temperature light stability of PEAMA<sup>+</sup> devices was also evaluated at 100 °C under 1 sun illumination. As illustrated in Supplementary Fig. 14d,e, the average _T_ 90 of PEAMA<sup>+</sup> devices was approximately 500 h, notably surpassing that of the control devices. The improved high-temperature stability of PSCs is attributed to the increased crystallinity and passivation induced by PEAMA<sup>+</sup> in perovskite films. Supplementary Fig. 14f,g displayed the cross-sectional SEM images and XRD patterns of PSCs before and after 1,400 hours of 1 sun illumination at 85 °C and the _V_ OC condition. The cross-sectional SEM images of the stressed PSCs showed no voids, in striking contrast to the PEA<sup>+</sup> containing FACs-perovskite devices, which showed voids along the GBs. It demonstrates the excellent high-temperature photostability of PEAMA<sup>+</sup> with FACs-perovskites. The XRD patterns revealed that the PEAMA<sup>+</sup> devices had a relatively slower crystallinity degradation compared to PSCs with PEA<sup>+</sup> after the initial crystallization process induced by heat. 

## **Conclusion** 

In conclusion, we found the widely used organic cations PEA<sup>+</sup> and BA<sup>+</sup> for 2D perovskites are unstable in FA<sup>+</sup> -containing perovskites when the films or devices were subject to high-temperature light soaking. The PEA<sup>+</sup> and BA<sup>+</sup> deprotonate to amines, which further react quickly with FA<sup>+</sup> to produce PEAMA<sup>+</sup> and BAMA<sup>+</sup> , respectively. This process also generates ammonia, which causes damage to perovskite interfaces and grain boundaries, severely limiting the high-temperature photostability of perovskite solar cells. Removing PEA<sup>+</sup> or BA<sup>+</sup> cations from precursors or using ammonium cations with high p _K_ a, including PEAMA<sup>+</sup> and BAMA<sup>+</sup> can improve the high-temperature photostability due to the difficulty of deprotonation. 

## **Methods** 

### **Materials** 

FAI, formamidinium chloride (FACl), zinc chloride (ZnCl2) and phenylethylammonium chloride (PEACl) were purchased from GreatCell Solar and used without further purification. Lead iodide (PbI2, 99.99%) was purchased from Tokyo Chemical Industry. 2-Mercaptoethanol (2-ME), dimethylformamide (DMF), dimethyl sulfoxide (DMSO), toluene (TL), isopropanol (IPA), ethanol (EtOH), ethyl acetate (EtOAc), caesium iodide (CsI; 99.999%), PTAA (average Mn 7,000–10,000), BCP ( > 96%), deuterated dimethyl sulfoxide (DMSO- _d6_ ) and phenylethylamine (>99.5%) were purchased from Sigma-Aldrich. C60 ( > 99.55%) was purchased from Nano-C. Formamidinium hypophosphite (FAH2PO2) was synthesized via a method that was based on and modified from a previously published method<sup>30</sup> . Copper (Cu) pellets were purchased from Kurt J. Lesker Company. 

### **Synthesis of PEAMAI** 

A colourless solution of 7.74 g (45 mmol) FAI in 50 ml absolute ethanol (EtOH) was stirred with an ice bath and added dropwise into a solution of 0.5 ml (4.5 mmol) phenylethylamine in 50 ml absolute ethanol. After the addition finished, the reaction was stirring for another 2 h and then worked up by evaporating the solvent. The crude product was washed out by 30 ml ethyl acetate two times to remove excess FAI. The eluate was concentrated by rotary evaporation resulting in light yellow oil. Recrystallization from 30 ml EtOAc/EtOH/IPA under −18 °C yielded 0.879 g (1.4 mmol, 31.1%) white solid, which is a co-crystal of PEAMAI and 2 FAI. The co-crystals are mixture of trans- and cis-PEAMAI isomers determined by NMR spectra (Supplementary Fig. 8).<sup>1</sup> H NMR (400 MHz, DMSO- _d6_ ) δ: 8.54–9.64 (m, 11H), 7.82–7.93 (m, 3H), 7.22–7.35 (m, 5H), 3.47–3.59 (m, 2H), 2.82–2.87 (m, 2H).<sup>13</sup> C NMR (101 MHz, DMSO- _d6_ ) δ: 157.84, 157.65, 154.68, 138.40, 138.26, 129.39, 129.27, 128.99, 128.90, 

127.06, 127.02, 47.71, 42.57, 36.12, 33.58. Single-crystal XRD structure of a trans-PEAMAI-2FAI co-crystal (150 K) is shown in Fig. 3d and Supplementary Tables 2 and 3. The mass-to-charge ratio ( _m/z_ ) was determined using high-resolution mass spectrum (HRMS) in conjunction with the electrospray ionization (ESI) technique, and this value was compared to the calculated (calcd) _m/z_ value. HRMS (ESI, _m/z_ ): calcd. for [C9H13N2]<sup>+</sup> 149.1074 found 149.1072. 

### **Synthesis of BAMAI** 

BAMAI can be similarly prepared from BA<sup>0</sup> and excess FAI. The crude product as a mixture of BAMAI and FAI was used without further purification. The ratio of BAMAI: FAI was determined by NMR spectra (Supplementary Fig. 10).<sup>1</sup> H NMR (400 MHz, DMSO- _d6_ ) δ: 7.97,7.90 (s, 1H), 7.87 (s, 1H), 3.30, 3.20 (t, _J_ = 7.1 Hz, 2H), 1.50 (m, 2H), 1.33 (m, 2H), 0.89 (t, _J_ = 7.3 Hz, 3H).<sup>13</sup> C NMR (101 MHz, DMSO- _d6_ ) δ: 157.64, 154.65, 46.28, 41.10, 32.06, 29.70, 19.78, 19.35, 13.96, 13.94. HRMS (ESI, _m/z_ ): calcd. for [C5H13N2]<sup>+</sup> 101.1074 found 101.1078. 

### **Preparation of PSCs** 

The ITO glass was cleaned with acetone and isopropanol using ultrasonic cleaning for 15 minutes, followed by 15 minutes of ultraviolet ozone treatment before blade coating the hole transport layer (HTL) layer using 2.2 mg ml<sup>−1</sup> PTAA in toluene with a 200 μm blade gap. To fabricate high-quality FACsPbI3 films with PEACl, a mixture of 0.9 M FAPbI3 (in 2-ME solution) and 0.1 M CsPbI3 (in DMSO solution) was prepared with a molar percentage of DMSO to Pb around 56% in precursor solutions. 2.5% FACl, 1.0% FAH2PO2, 0.25% PEACl, 0.5% ZnCl2 and 0.25% CsI were added to the perovskite precursor solution. The FA0.9Cs0.1PbI3 films were blade coated on PTAA/ITO substrates at room temperature with a gap of 300 μm and N2 blowing at 20 pound per square inch (psi), followed by annealing at 150 °C for 3 min to obtain the perovskite phase. The humidity and temperature of the air is ~30% and 21 °C, respectively. We removed each of the additives from the perovskite precursor to fabricate perovskite solar cells and evaluated their effect on the high-temperature photostability of PSCs. For instance, in FACsPbI3 films without PEACl, a mixture of 0.9 M FAPbI3 (in 2-ME solution) and 0.1 M CsPbI3 (in DMSO solution) was used with a molar percentage of DMSO to Pb around 56% in precursor solutions. To produce high-quality perovskite films, the perovskite precursor solution was supplemented with 2.5% FACl, 1.0% FAH2PO2, 0.5% ZnCl2 and 0.25% CsI, too. 

In addition, we replaced PEACl with PEAI in the precursor solution, adding 0.25% PEAI while retaining the other additives, including 2.5% FACl, 1.0% FAH2PO2, 0.5% ZnCl2 and 0.25% CsI in the perovskite precursor solution. To check PEAI surface treatment effect on stability of PSCs at high-temperature light soaking condition, 1 mg ml<sup>−1</sup> PEAI solution was prepared in IPA. The solution was spin coated onto perovskite films without PEACl at 5,000 r.p.m. for 30 s, followed by annealing at 100 °C for 10 min. To check the passivation effect of PEAMAI, 1 mg ml<sup>−1</sup> PEAMAI solution was prepared in IPA. The solution was spin coated onto perovskite films without PEACl at 5,000 r.p.m. for 30 s, followed by annealing at 100 °C for 10 min. For FACsPbI3 films with PEAMAI, 0.2% PEAMAI was added to the FACs-perovskite solution along with 2.5% FACl, 1.0% FAH2PO2, 0.5% ZnCl2 and 0.25% CsI in the perovskite precursor solution. To prepare FACsPbI3 with PEAMAI, we used 0.9 M FA0.99PbI3 (in 2-ME solution) and 0.1 M CsPbI3 (in DMSO solution), as the synthesized PEAMAI lattice contains FAI. The precursor solution was blade coated with a 300 μm blade gap and N2 blowing at 20 psi, followed by immediate annealing at 150 °C for 3 minutes. 

To assemble PSCs, we first evaporated 30 nm of C60 onto the perovskite films at a vacuum pressure of 10<sup>−6</sup> Pa. We then evaporated 6 nm of BCP onto the sample substrates, which had been heated to approximately 80 °C before BCP deposition. Finally, we thermally evaporated Cu electrodes with 150 nm thickness. The area of shadow masks used in this work is 0.08 cm<sup>2</sup> . 

PEA<sup>+</sup> and FA<sup>+</sup> mixed perovskite film fabrication: for high-temperature photostability check of PEA<sup>+</sup> , we prepared a 1 M PEA2PbI4 precursor solution by mixing 2 M PEAI and 1 M PbI2 in 1 ml DMF solution, while a 1 M FA0.9Cs0.1PbI3 solution was prepared by mixing 0.9 M FAI, 0.1 M CsI and 1 M PbI2 in 1 ml DMF solution. Then we mixed the PEA2PbI4 and FA0.9Cs0.1PbI3 solutions at a ratio of 1:0, 2:1, 1:2 and 0:1. Subsequently, 40 μl perovskite solution was spin coated onto glass substrates at 4,000 r.p.m. for 30 s in a glovebox, followed by the addition of 130 μl TL after ~12 s and annealing at 120 °C for 15 minutes. The 3D films were prepared by spin coating FA0.9Cs0.1PbI3 solution onto glass substrates at 4,000 r.p.m. for 30 s in a glovebox, followed by the addition of 130 μl TL as antisolvent after ~6 s and annealing at 150 °C for 15 minutes. A PMMA solution in TL was dropped onto the prepared films and annealed at 100 °C for 1 minute to form a PMMA layer with a thickness >1 μm to cover on perovskite films. The BA<sup>+</sup> and FA<sup>+</sup> mixed perovskite films were fabricated by mixing 1 M BA2PbI4 precursor solution and 1 M FA0.9Cs0.1PbI3 using same way to the PEA<sup>+</sup> and FA<sup>+</sup> mixed perovskite film fabrication. 

### **Monte Carlo simulation** 

Monte Carlo simulations of the electron beam interaction volume were performed using Monte Carlo simulation of electron trajectory in solids (CASINO) open-source software to estimate the beam spot size and penetration depth. In CASINO, each electron trajectory is approximated as a zigzag trajectory as a result of elastic and inelastic collision of the electron with the atoms in the material<sup>49</sup> . For this study, 1,600 electron trajectories were simulated for each run. The incident beam radius is set to 10 nm. 

### **EQE** 

A Newport QE measurement kit was used to measure the EQE of PSCs. A monochromatic light beam from a Xenon Arc lamp coupled with a Bruker Vertex 80 v Fourier Transform Interferometer was incident and focused onto the devices. Then, the photocurrent was obtained through a Stanford Research SR570 current pre-amplifier. EQE of devices was calibrated by a Newport reference silicon solar cell with a known EQE. 

### **TPV** 

### **XRD** 

Powder XRD patterns were measured by a Rigaku Smart Lab diffractometer with CuKα radiation (λ = 1.5406 Å). The scan rate was 10° min<sup>−1</sup> at the step-scan size of 0.01°. Single-crystal XRD was performed on a Bruker D8 VENTURE diffractometer with CuKα radiation (λ = 1.54178 Å). The diffraction data were handled by Olex2 software<sup>44</sup> , and the crystal structures were solved and refined by the ShelXT<sup>45</sup> and ShelXL<sup>46</sup> programmes, respectively. Thermal ellipsoid models were rendered by VESTA<sup>47</sup> or Ortep3<sup>48</sup> . PEAMAI-FAI-PbI2 and BAMAI-FAI-PbI2 films in Supplementary Fig. 12 were prepared by spin coating 1 M PEAMAI-FAI (or BAMAI-FAI) and PbI2 with equal molar ratio in DMF solution at 3,000 r.p.m. for 30 s, followed by annealing at 100 °C for 10 min. 

### **SEM** 

The morphology of the samples was measured by a Hitachi-4700 microscope with an electron beam accelerated at 10 kV. The surface of the samples was coated with Au to prevent charging during the measurement. 

TPV decays were measured under 1 sun illumination with a 337 nm laser pulse (SRS NL 100 Nitrogen Laser, pulse duration of less than 3.5 ns) to add a small perturbation to the background illumination. The voltage of the device was measured with a digital oscilloscope (DOS-X 3104 A) with an input impedance set to 1 MΩ. 

### **PL** 

PL spectra were collected with a Horiba iHR320 Spectrometer. A 532 nm green laser (Laserglow Technologies) with an intensity of 100 mW cm<sup>−2</sup> was used as the excitation source. 

### **TRPL** 

TRPL measurement was conducted on a DeltaFlex modular fluorescence lifetime system from Horiba Scientific with a pulsed laser source at 406 nm (Horiba NanoLED 402-LH; pulse width below 200 ps, 20 pJ per pulse, ~1 mm<sup>2</sup> spot size) with a repetition rate of 0.3125 MHz. The signal was recorded using time-corrected single photon counting (TCSPC). The fluence of excitation light was 200 nJ m<sup>−2</sup> . 

### **tDOS** 

### **Photocurrent measurement** 

_J_ – _V_ curves were measured using a Keithley 2400 source meter under the simulated AM 1.5 G 1 sun illumination (100 mW cm<sup>−2</sup> ) using a solar simulator (Oriel Sol 3 A class AAA) equipped with 450 W Xenon lamp (Newport 6280NS). The light intensity was calibrated using a Si solar cell with a KG-5 filter. The active area of devices is 0.08 cm<sup>2</sup> , defined by the size of the Cu electrode. The devices were measured at ambient air with humidity of 30–60% without temperature control. The scan rate during measurement was set to 50 mV s<sup>−1</sup> . Steady-state PCE was conducted by measuring stabilized photocurrent density under a constant bias voltage at maximum power point derived from _J_ – _V_ curves. An anti-refection coating was used during measurement. 

### **EBIC** 

EBIC was performed using a Mighty EBIC 2.0 Controller from Ephemeron Labs Inc. (currently Ephemeral Devices) and a FEMTO DLPCA-200 pre-amplifier. EBIC and a SEM image were collected concurrently in an FEI Scios DualBeam FIB/SEM from Thermo Fisher Scientific. In this study, EBIC was measured at a short-circuit condition. To collect an EBIC scan, first the electron beam was focused on the edge of the device area at low magnification, then moved along the edge to a fresh area to focus on a higher magnification. Once the desired magnification was achieved, the beam was moved towards the centre of the device in one direction to take EBIC measurements on unscanned fresh areas. Five EBIC scans in fresh regions were collected on each active device area. 

tDOS measurement was performed by the thermal admittance spectroscopy measurement using an LCR meter (Agilent E4980A). The tDOS was derived from the frequency-dependent capacitance and voltagedependent capacitance based on the equation: _N_ T ( _Eω_ ) = − _qkT_ 1 _ω_ dd _ωC VW_ bi<sup>~~,~~</sup> where _q_ , _k_ , _T_ , _ω_ and _C_ are elementary charge, Boltzmann’s constant, temperature, angular frequency and specific capacitance, respectively. _W_ and _V_ bi are the depletion width and build-in potential, respectively. 

### **Mobile ion concentration measurement** 

The measurement of mobile ion concentration was conducted using Keithley 4200A-SCS system. We estimated the mobile ion concentration in these devices by applying 1.5 V forward bias for about 30 s to perturb the ion distribution and then measuring current induced by the back diffusion of ions that were quickly zero biased to allow ions to diffuse back to steady state. The transient current induced by ion back diffusion was recorded and the measurements were performed with devices in the dark. The mobile ion concentration was obtained from the integrated transient current over time divided by the perovskite volume and the elementary charge. 

### **NMR and HRMS** 

1H and 13C NMR spectra were measured on a Bruker Neo 400 MHz spectrometer. Clear and transparent solutions of PEAMAI-FAI3 crystal or BAMAI-FAI mixture powder that dissolved in DMSO- _d6_ were measured 

following the standard procedure for<sup>1</sup> H and<sup>13</sup> C. Chemical shifts were referenced to tetramethylsilane as the internal standard. HRMS was measured by a Q Exactive HF-X (ThermoFisher) mass spectrometer. 

### **p** **_K_ a calculation** 

The p _K_ a values of PEAMA<sup>+</sup> and BAMA<sup>+</sup> were calculated using MarvinSketch software (https://www.chemaxon.com). 

### **Stability characterization** 

Photostability measurement was conducted at 55 ± 5 °C; before conducting photostability measurements, the PSCs were encapsulated by epoxy and glass. The encapsulated PSCs were then exposed to white LED irradiation at an intensity of 1 sun, which was calibrated using a Si reference solar cell with a KG-5 filter. The spectral distribution of the lamp used was depicted in Supplementary Fig. 2a. The PSCs were measured under _V_ oc conditions without temperature controlling. Due to the light exposure, the sample temperature rose to 50–60 °C. High-temperature photostability measurement: to prevent the release of toxic gas into the air due to the instability of the epoxy under high temperature and light, the PSCs were not encapsulated during high temperature photostability measurements. Instead, the measurements were conducted in an N2 glovebox to maintain an inert atmosphere. The arrangement used for the high-temperature photostability measurement is illustrated in Supplementary Fig. 2b, wherein unencapsulated PSCs were placed on a hot plate set at a temperature of 85 °C or 100 °C. The PSCs were then exposed to white LED irradiation from above. The uniformity of the hot plate, as displayed in Supplementary Fig. 2c, was verified using a thermometer. In addition, the actual temperatures of perovskite under different set temperatures and 1 sun LED light were monitored by sticking a temperature sensor directly onto the Cu electrode layer. As shown in Supplementary Fig. 2d, the actual temperature of perovskites was about 90 °C when the set hot plate temperature was 85 °C. After continuous illumination at high temperature for 48 or 72 hours, unencapsulated devices were taken out from the N2 glovebox for the _J_ – _V_ measurement. The _J_ – _V_ measurement was conducted in air with humidity of 30–60% without temperature control. An anti-refection coating was used during measurement. 

### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## **Data availability** 

The main data supporting the findings of this study are available within the published article and its Supplementary Information. Source data are provided with this paper. 

## **References** 

1. Thouin, F. et al. Electron–phonon couplings inherent in polarons drive exciton dynamics in two-dimensional metal-halide perovskites. _Chem. Mater._ **31** , 7085–7091 (2019). 

2. Burgos-Caminal, A., Socie, E., Bouduban, M. E. F. & Moser, J.-E. Exciton and carrier dynamics in two-dimensional perovskites. _J. Phys. Chem. Lett._ **11** , 7692–7701 (2020). 

3. Bourelle, S. A. et al. Optical control of exciton spin dynamics in layered metal halide perovskites via polaronic state formation. _Nat. Commun._ **13** , 3320 (2022). 

4. Leung, T. L. et al. Stability of 2D and quasi-2D perovskite materials and devices. _Commun. Mater._ **3** , 63 (2022). 

5. Lee, J.-W. et al. 2D perovskite stabilized phase-pure formamidinium perovskite solar cells. _Nat. Commun._ **9** , 3021 (2018). 

6. Xiao, X. et al. Suppressed ion migration along the in-plane direction in layered perovskites. _ACS Energy Lett._ **3** , 684–688 (2018). 

7. Yan, L. et al. Charge‐carrier transport in quasi‐2D Ruddlesden– Popper perovskite solar cells. _Adv. Mater._ **34** , 2106822 (2022). 

8. Xia, M. et al. Two-dimensional perovskites as sensitive strain sensors. _J. Mater. Chem. C._ **8** , 3814–3820 (2020). 

9. Wu, G. et al. 2D hybrid halide perovskites: structure, properties, and applications in solar cells. _Small_ **17** , 2103514 (2021). 

10. Jang, Y.-W. et al. Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. _Nat. Energy_ **6** , 63–71 (2021). 

11. Spanopoulos, I., Ke, W. & Kanatzidis, M. G. In quest of environmentally stable perovskite solar cells: a perspective. _Helv. Chim. Acta_ **104** , e2000173 (2021). 

12. Kim, M. et al. Conformal quantum dot–SnO2 layers as electron transporters for efficient perovskite solar cells. _Science_ **375** , 302–306 (2022). 

13. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460–466 (2019). 

14. Tong, J. et al. Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642–651 (2022). 

15. Wang, Z. et al. Efficient ambient-air-stable solar cells with 2D–3D heterostructured butylammonium-caesium-formamidinium lead halide perovskites. _Nat. Energy_ **2** , 17135 (2017). 

16. Zhang, Y. & Park, N.-G. Quasi-two-dimensional perovskite solar cells with efficiency exceeding 22%. _ACS Energy Lett._ **7** , 757–765 (2022). 

17. Gong, J., Hao, M., Zhang, Y., Liu, M. & Zhou, Y. Layered 2D halide perovskites beyond the Ruddlesden–Popper phase: tailored interlayer chemistries for high‐performance solar cells. _Angew. Chem. Int. Ed._ **61** , e202112022 (2022). 

18. Li, G. et al. Highly efficient pin perovskite solar cells that endure temperature variations. _Science_ **379** , 399–403 (2023). 

19. Grancini, G. et al. One-year stable perovskite solar cells by 2D/3D interface engineering. _Nat. Commun._ **8** , 15684 (2017). 

20. Ahmad, S. et al. Dion–Jacobson phase 2D layered perovskites for solar cells with ultrahigh stability. _Joule_ **3** , 794–806 (2019). 

21. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

22. Li, C. et al. Rational design of Lewis base molecules for stable and efficient inverted perovskite solar cells. _Science_ **379** , 690–694 (2023). 

23. Zhao, X. et al. Accelerated aging of all-inorganic, interfacestabilized perovskite solar cells. _Science_ **377** , 307–310 (2022). 

24. Castro-Méndez, A.-F. et al. Vapor phase infiltration improves thermal stability of organic layers in perovskite solar cells. _ACS Energy Lett._ **8** , 844–852 (2023). 

25. Hartono, N. T. P. et al. Tailoring capping-layer composition for improved stability of mixed-halide perovskites. _J. Mater. Chem. A_ **10** , 2957–2965 (2022). 

26. Fiorentino, F., Albaqami, M. D., Poli, I. & Petrozza, A. Thermal- and light-induced evolution of the 2D/3D interface in lead-halide perovskite films. _ACS Appl. Mater. Interfaces_ **14** , 34180–34188 (2021). 

27. Sutanto, A. A. et al. In situ analysis reveals the role of 2D perovskite in preventing thermal-induced degradation in 2D/3D perovskite interfaces. _Nano Lett._ **20** , 3992–3998 (2020). 

28. Zumdahl, S. S. _Chemistry_ , 677–713 (D.C. Heath, Lexington, Mass., 1986). 

29. Deng, Y. et al. Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ **6** , 633–641 (2021). 

30. Xiao, Z. et al. Unraveling the hidden function of a stabilizer in a precursor in improving hybrid perovskite film morphology for high efficiency solar cells. _Energy Environ. Sci._ **9** , 867–872 (2016). 

31. Fei, C. et al. Lead-chelating hole-transport layers for efficient and stable perovskite minimodules. _Science_ **380** , 823–829 (2023). 

32. Wu, W. Q., Rudd, P. N., Wang, Q., Yang, Z. & Huang, J. Blading phase-pure formamidinium-alloyed perovskites for high-efficiency solar cells with low photovoltage deficit and improved stability. _Adv. Mater._ **32** , e2000995 (2020). 

33. Que, M. et al. Effects of Zn<sup>2+</sup> ion doping on hybrid perovskite crystallization and photovoltaic performance of solar cells. _Chem. Phys._ **517** , 80–84 (2019). 

34. Li, Z. et al. Ammonia for post-healing of formamidinium-based perovskite films. _Nat. Commun._ **13** , 4417 (2022). 

35. Valenzano, V. et al. Methylammonium-formamidinium reactivity in aged organometal halide perovskite inks. _Cell Rep. Phys. Sci._ **2** , 100432 (2021). 

36. Rayer, A. V., Sumon, K. Z., Jaffari, L. & Henni, A. Dissociation constants (p _K_ a) of tertiary and cyclic amines: structural and temperature dependences. _J. Chem. Eng. Data_ **59** , 3805–3813 (2014). 

37. Haynes, W. M. _CRC Handbook of Chemistry and Physics_ (CRC Press, 2016). 

38. Song, J. et al. Pentamidine is not a permeant but a nanomolar inhibitor of the _Trypanosoma brucei_ aquaglyceroporin-2. _PLoS Pathog._ **12** , e1005436 (2016). 

39. Angyal, S. & Warburton, W. 549. The basic strengths of methylated guanidines. _J. Chem. Soc_ . 2492–2494 (1951). 

40. Schutt, K. et al. Overcoming zinc oxide interface instability with a methylammonium‐free perovskite for high‐performance solar cells. _Adv. Funct. Mater._ **29** , 1900466 (2019). 

41. Jiang, J. et al. Synergistic strain engineering of perovskite single crystals for highly stable and sensitive X-ray detectors with low-bias imaging and monitoring. _Nat. Photonics_ **16** , 575–581 (2022). 

42. Wang, X. et al. Perovskite solution aging: what happened and how to inhibit? _Chem_ **6** , 1369–1378 (2020). 

43. Wang, M., Fei, C., Uddin, M. A. & Huang, J. Influence of voids on the thermal and light stability of perovskite solar cells. _Sci. Adv._ **8** , eabo5977 (2022). 

44. Dolomanov, O. V., Bourhis, L. J., Gildea, R. J., Howard, J. A. & Puschmann, H. OLEX2: a complete structure solution, refinement and analysis program. _J. Appl. Crystallogr._ **42** , 339–341 (2009). 

45. Sheldrick, G. M. SHELXT–integrated space-group and crystalstructure determination. _Acta Crystallogr. Sect. A_ **71** , 3–8 (2015). 

46. Sheldrick, G. M. Crystal structure refinement with SHELXL. _Acta Crystallogr. Sect. C_ **71** , 3–8 (2015). 

47. Momma, K. & Izumi, F. VESTA: a three-dimensional visualization system for electronic and structural analysis. _J. Appl. Crystallogr._ **41** , 653–658 (2008). 

48. Farrugia, L. J. WinGX and ORTEP for Windows: an update. _J. Appl. Crystallogr._ **45** , 849–854 (2012). 

49. Hovington, P., Drouin, D. & Gauvin, R. CASINO: a new Monte Carlo code in C language for electron beam interaction—part I: description of the program. _Scanning_ **19** , 1–14 (1997). 

## **Acknowledgements** 

Energy Efficiency and Renewable Energy, under award number DE-EE0009520. The chemical synthesis and related charaterization were supported as part of the Center for Hybrid Organic Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the US DOE. The University of California San Diego (UCSD) portion of the work was supported mainly by the Solar Energy Technologies office within the US DOE, Office of Energy Efficiency and Renewable Energy, under award number DE-EE0009527. The EBIC work was performed at the San Diego Nanotechnology Infrastructure of UCSD, an National Science Foundation-supported National Nanotechnology Coordinated Infrastructure site (ECCS1542148). The views expressed herein do not necessarily represent the views of the U.S. Department of Energy or the United States Government. 

## **Author contributions** 

M.W. fabricated perovskite films and perovskite solar cells and conducted SEM, powder XRD, tDOS, mobile ion concentration and device stability measurements. Z.S. developed the empirical criterion and carried out organic systhesis, NMR, MS and SC-XRD measurements. Z.J.D.D. conducted the EBIC measurement and Monte Carlo simulation under the supervision of S.P.D. and D.P.F. C.F. conducted the PL and TRPL measurements. G.Y. performed TPV measurements. M.W, Z.S. and J.H. analysed data and wrote the paper, and all authors reviewed the paper. 

## **Competing interests** 

The authors declare no competing interests. 

## **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560-023-01362-0. 

**Correspondence and requests for materials** should be addressed to Jinsong Huang. 

**Peer review information** _Nature Energy_ thanks Shuping Pang and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

#### **Reprints and permissions information** is available at 

www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

This work was mainly supported by the Solar Energy Technologies office within the US Department of Energy (DOE), Office of 





