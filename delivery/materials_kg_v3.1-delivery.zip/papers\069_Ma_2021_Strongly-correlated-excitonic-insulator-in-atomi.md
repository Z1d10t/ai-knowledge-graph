# Strongly correlated excitonic insulator in atomic double layers

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 287 |
| 作者 | Li-Guo Ma, P. Nguyen, Ze-Fang Wang, Yong-Xin Zeng, K. Watanabe, T. Taniguchi, A. Macdonald, K. Mak et al. |
| DOI | 10.1038/s41586-021-03947-9 |
| 源文件 | 069_Ma_2021_Strongly-correlated-excitonic-insulator-in-atomi.pdf |

---
# **Strongly correlated excitonic insulator in atomic double layers** 

- Liguo Ma<sup>1</sup> , Phuong X. Nguyen<sup>1</sup> , Zefang Wang<sup>1</sup> , Yongxin Zeng<sup>2</sup> , Kenji Watanabe<sup>3</sup> , Takashi Taniguchi<sup>3</sup> , Allan H. MacDonald<sup>2</sup> , Kin Fai Mak<sup>1,4,5</sup> *, Jie Shan<sup>1,4,5</sup> * 

- 1School of Applied and Engineering Physics, Cornell University, Ithaca, NY, USA 2Department of Physics, University of Texas at Austin, Austin, TX, USA 3National Institute for Materials Science, Tsukuba, Japan 

- 4Laboratory of Atomic and Solid State Physics, Cornell University, Ithaca, NY, USA 5Kavli Institute at Cornell for Nanoscale Science, Ithaca, NY, USA 

*Email: <u>jie.shan@cornell.edu; kinfai.mak@cornell.edu</u> These authors contributed equally: Liguo Ma and Phuong X. Nguyen. 

**Excitonic insulators (EI) arise from the formation of bound electron-hole pairs (excitons)**<sup>**1, 2**</sup> **in semiconductors and provide a solid-state platform for quantum many-boson physics**<sup>**3-8**</sup> **.  Strong exciton-exciton repulsion is expected to stabilize condensed superfluid and crystalline phases by suppressing both density and phase fluctuations**<sup>**8-11**</sup> **.  Although spectroscopic signatures of EIs have been reported**<sup>**6, 12-14**</sup> **, conclusive evidence for strongly correlated EI states has remained elusive.  Here, we demonstrate a strongly correlated spatially indirect two-dimensional (2D) EI ground state formed in transition metal dichalcogenide (TMD) semiconductor double layers.  An equilibrium interlayer exciton fluid is formed when the bias voltage applied between the two electrically isolated TMD layers, is tuned to a range that populates bound electron-hole pairs, but not free electrons or holes**<sup>**15-17**</sup> **. Capacitance measurements show that the fluid is exciton-compressible but chargeincompressible – direct thermodynamic evidence of the EI.  The fluid is also strongly correlated with a dimensionless exciton coupling constant exceeding 10. We further construct an exciton phase diagram that reveals both the Mott transition and interaction-stabilized quasi-condensation.  Our experiment paves the path for realizing the exotic quantum phases of excitons**<sup>**8**</sup> **, as well as multi-terminal exciton circuitry for applications**<sup>**18-20**</sup> **.** 

In bulk materials EIs can occur in small band gap semiconductors and small band overlap semimetals<sup>21</sup> .  In the semiconductor limit, EIs occur when the electron-hole binding energy of an exciton exceeds the charge band gap.  The ground state exciton population is then determined by balancing the negative exciton formation energy against the mean excition-exciton repulsion energy.  Although the concept has been understood for sixty years, it has been challenging to establish distinct experimental signatures of its realization.  One problem is that exciton coherence in condensed phases inevitably couples to the crystal Hamiltonian, disordered or not, so that condensation does not imply superfluidity<sup>22</sup> .  A second problem is that the exciton population of a particular material depends very sensitively on band structure details and cannot be controlled.  Here we solve both problems by establishing electrical control of the chemical potentials of excitons that are spatially indirect; the electron and hole wavefunctions do not interfere so that macroscopic phase coherence is spontaneous, allowing exciton superfluidity<sup>15, 16, 23,</sup> 

1 

24.  We achieve these properties in atomic 2D semiconductor double layers, whose emergence has opened new paths to realize and control the many-exciton states<sup>15-17, 23-32</sup> . Both the formation of dipolar excitons (i.e. excitons with a permanent dipole) and the reduced dielectric screening of the electrostatic interactions favor strong exciton-exciton repulsion.  Separate electrical contacts to isolated electron and hole layers provides a reservoir for interlayer excitons with a conveniently tunable chemical potential that allows us to probe thermodynamic properties of the exciton fluid<sup>15, 16, 24</sup> . 

Consider TMD double layers with a type II band alignment and a spatially indirect band gap 𝐸� (Fig. 1a).  The conduction and valence band edges are located in two separate layers; it is therefore possible to make separate contact to each layer.  The application of an interlayer bias voltage, 𝑉�, splits the electron and hole electrochemical potentials.  It reduces the effective band gap (or the charge gap) by 𝑒𝑉� (here 𝑒 denotes the elementary charge).  When the charge gap, 𝐸� �𝑒𝑉� , is below the binding energy, 𝐸� , of an interlayer exciton, formation of an interlayer exciton fluid is expected<sup>15, 16, 24</sup> .  The exciton chemical potential is defined by 𝜇� �𝑒𝑉� in thermal equilibrium since it is the sum of the electron and hole electrochemical potentials<sup>15, 16, 24</sup> .  Because of the large exciton binding energies in atomically thin TMD semiconductors (10’s – 100’s meV)<sup>23,</sup> 24, 32, exciton fluids with a widely tunable chemical potential are achievable.  A reservoir for interlayer excitons is established. 

TMD double layer devices with separate electrical contacts have been demonstrated recently<sup>27, 28</sup> .  However, equilibrium interlayer exciton fluids whose thermodynamic properties could be studied have not been achieved previously.  The earlier devices allowed substantial tunneling between the two layers and therefore operated only in the small tunnel junction resistance regime (that is, electrical contact resistances exceeded the tunnel junction resistance); the electron/hole layers could not be maintained at the same electrochemical potential as the contacts<sup>16</sup> .  The new results employ a device design that allows us to reach the large tunnel junction resistance regime and demonstrate direct thermodynamic evidence of an EI ground state. 

Figure 1b is a schematic cross-section of our devices (see Methods for details on device design and fabrication).  We choose monolayer MoSe2 (Mo) as the electron layer and monolayer WSe2 (W) as the hole layer.  A hexagonal boron nitride (hBN) tunnel barrier separates the two TMDs, which are angle-misaligned and have negligible moiré effect. The structure is completed with symmetric top and bottom gates that consist of hBN gate dielectrics (~ 10 nm) and graphite gate electrodes.  A key part of the strategy used to achieve small contact resistances is to separate the device into a contact region and a region of interest.  We electrostatically dope the TMDs heavily in the contact region, but keep the region of interest charge neutral by employing different barrier thicknesses: 1-2 nm in the region of interest and ~ 10 nm in the contact region.  When the device is subjected to anti-symmetric gating, ∆ ≡�𝑉�� �𝑉���/2, where 𝑉�� and 𝑉�� are the bottom and top gate voltages, respectively, a vertical electric field is generated.  The field induces a large potential drop on the double layers in the contact region, which closes the band gap and introduces free carriers; the field reduces the band gap energy (but does not close it) in the region of interest.  The reduced gap energy also favors a smaller bias threshold 

2 

to form excitons.  We achieve good electrical contacts down to ~ 10-15 K with ∆ �4.6 V. Unless otherwise specified, all results presented below are obtained at 15 K. 

We characterize the thermodynamic properties of the double layer, including both the exciton compressibility and the charge compressibility, using the capacitance technique ���� (Methods).  The penetration capacitance per unit area, 𝐶� �𝑒 , measures the ���� differential charge density on the bottom gate, 𝑑𝑛��, induced by a small AC voltage, 𝑑𝑉��, on the top gate (Fig. 1c).  It characterizes how well the double layer as a whole screens an AC electric field; it approximately measures the charge compressibility of the entire double layer (Methods). 

Figure 1d shows 𝐶� as a function of symmetric gating, 𝑉� ≡�𝑉�� �𝑉���/2.  Symmetric gating (referred to as gating below) shifts the chemical potential of the electrons and holes together; it controls the electron-hole density imbalance in the double layer.  We first consider the case of zero bias; the electrons and holes have the same chemical potential.  When the chemical potential is inside the band gap of the double layer, the double layer is charge incompressible; 𝐶� is given by the gate-to-gate geometrical capacitance, 𝐶�� .  Once the chemical potential touches either the conduction or the valence band edge, the double layer becomes charge-compressible; it screens out the AC electric field, and 𝐶� drops to a small value.  (The observed negative values of 𝐶� arise from the electron correlation effects in the double layer<sup>33</sup> and the non-overlapped monolayer regions in the dual-gated device, Extended Data Fig. 1.)  The gate voltage between the rising and falling edges of 𝐶� gives an estimate of the band gap energy 𝐸� � 0.68 eV (see Extended Data Fig. 2 for 𝐸� as a function of ∆).  Figure 1d also shows that the charge gap energy decreases with the application of a bias voltage; the gap closes at 𝑒𝑉� �𝐸�.  More rigorously, the charge gap energy (that is, the charge chemical potential jump across the incompressible regime) can be evaluated by integrating the penetration capacitance with respect to gate voltage<sup>33</sup> , ∆𝜇��𝑑𝑉� �𝐶�/𝐶���. 

Simultaneously we measure the exciton compressibility through the interlayer capacitance.  We probe the differential charge density on one layer (W-layer) induced by an AC voltage 𝑑𝑉� that is applied to the other layer (Mo-layer) (Fig. 1e).  The differential charge density, arising from transfer of a charge carrier from one layer to the other, is also the differential density of excitons, 𝑑𝑛�.  The AC voltage 𝑑𝑉� modulates the exciton ��� chemical potential<sup>15, 16</sup> .  The interlayer capacitance per unit area, 𝐶� �𝑒 , thus ��� ��� .  Figure 1f shows directly measures the isothermal exciton compressibility 𝜅� ������� the bias dependence of 𝐶� at equal electron and hole densities (𝑉� �0 V).  The interlayer capacitance rises abruptly from zero when 𝑉� exceeds a threshold (�𝐸�/𝑒).  It decreases gradually and approaches the geometrical capacitance of the double layer, 𝐶�� , with further increase of bias voltage.  We determine the exciton density by integrating 𝐶� with �� respect to the bias voltage, 𝑛� ��𝑑𝑉� (red curve).  An exciton density up to a few � times of 10<sup>12</sup> cm<sup>-2</sup> can be achieved with a bias on the order of 1 V. 

3 

We analyze the dual-gated double-layer device based on the parallel-plate capacitor model and known device parameters (Methods).  The W-layer is grounded, as in the experiment. Figure 2a shows four doping regions for the double layer as a function of bias and gate voltages when electron-hole interactions are neglected.  Here, _i_ , _p_ and _n_ denote intrinsic, positively doped, and negatively doped regions for each layer, respectively.  Under small bias and gate voltages, both layers are intrinsic (the _ii-_ region). The double layer enters the _pn_ -region when 𝑉� exceeds a threshold.  The threshold is weakly dependent on 𝑉� because with 𝐶�� ≫𝐶��, the bias voltage is much more efficient than the gate voltage in tuning the charge chemical potentials. 

The electrostatics simulation is in good agreement with the experimental capacitance results: the area with large 𝐶� (�𝐶��, shown in red in Fig. 2b) corresponds to the _ii_ - region, and the area with large 𝐶� (also shown in red, Fig. 2c) corresponds to the _pn_ - region.  This agreement shows that the electron-hole fluid is in equilibrium with the electrodes, which provide an electrical reservoir for interlayer excitons.  The conclusion is further supported by the long interlayer exciton lifetime (~ 1 ms), determined from an independent tunneling measurement (Extended Data Fig. 3). 

In the absence of electron-hole interactions in the double layer, charge gap closing (at the tip of the red triangle in Fig. 2b) and electron-hole pair injection (emergence of 𝐶�, the red region in Fig. 2c) are expected to occur at the same bias threshold that is defined by the band gap energy 𝐸�.  A careful examination reveals, however, that the bias threshold for pair injection (horizontal white line II) is about 25 mV lower than the threshold for band gap closing (horizontal white line I).  There exists a finite range of the bias and gate voltages (enclosed by the red and white dashed lines), within which a charge gap and electrons and holes are both present.  In this regime the electron-hole fluid is a bosonic fluid of bound electron-hole pairs.  The presence of excitons in the charge-incompressible region is a hallmark of the EI<sup>15, 16</sup> .  The difference between the two bias thresholds also provides an estimate of the interlayer exciton binding energy ~ 25 � 5 meV. 

The charge-gap can be viewed as density-dependent exciton binding energy 𝐸� since it corresponds to the chemical potential jump from an exciton fluid with one extra electron to one with an extra hole<sup>16</sup> , and is generally expected to vanish when a critical (Mott) density is reached<sup>23</sup> .  Our ability to continuously vary the density of the exciton fluid in the double layer allows us to measure 𝐸� as a function of exciton density.  We vary the exciton density by tuning 𝑉� according to Fig. 1f.  At each bias, we determine the charge gap energy ∆𝜇 from the gate dependence of the penetration capacitance (Extended Data Fig. 4).  We use the charge gap at 15 K to approximate 𝐸�.  The binding energy decreases continuously with increasing 𝑛� (Fig. 3).  The extrapolated value at zero density, 17.5 � 2.5 meV, is consistent with our previous 𝐸� estimate and corresponds to an exciton Bohr radius of 𝑎� ~ 7 nm.  The binding energy drops to zero around 𝑛� �8 �10<sup>��</sup> cm<sup>-2</sup> (the Mott density), above which the EI turns into an electron-hole plasma<sup>23</sup> .  We obtain 𝑛�𝑎�� ~0.4, which agrees reasonably well with the Mott density estimate 𝑛�𝑎�� ~ 0.3 � 0.7 (Ref.<sup>34, 35</sup> ).  We do not observe any abrupt transition from the EI to a charge conductor around the Mott density down to 10-15 K, indicating the possibility of a continuous Mott transition. 

4 

The charge gap at a given exciton density also depends on temperature (Fig. 3).  It decreases with increasing temperature and vanishes around 𝑇�.  Figure 4a shows 𝑇� (open squares) as a function of exciton density.  The trend is similar to the density dependence of 𝐸� (15 K in Fig. 3).  We find 𝑘�𝑇�  (𝑘� denoting the Boltzmann constant) is about 40% of the exciton binding energy for the entire density range.  The temperature 𝑇� thus represents the ionization temperature (or Saha temperature) of the exciton fluid<sup>23</sup> .  Above 𝑇�, a sizable portion of the excitons is ionized and the double layer becomes chargecompressible (𝐶� �0). 

Finally, we construct the density-temperature phase diagram of the excitons at equal electron and hole densities in Fig. 4a.  The color represents the magnitude of the interlayer capacitance 𝐶� , or equivalently, the exciton compressibility 𝜅� .  The phase diagram consists of a dome of large exciton compressibility (shown in red).  The exciton ionization temperature 𝑇� defines the right crossover boundary of the dome: below 𝑇� the system is an EI, and above it, a mixture of excitons and electron-hole plasma.  Figure 4b shows representative horizontal line cuts of Fig. 4a.  At a given temperature, 𝐶� increases linearly with density, reaches a peak, and gradually approaches the interlayer geometrical capacitance 𝐶��.  With increasing temperature, the peak shifts towards higher density while the peak amplitude decreases.  We mark the peak location (𝑇<sup>∗∗</sup> ) with a dotted line in Fig. 4a.  The scale of 𝑇<sup>∗∗</sup> is 5-6 times larger than the degeneracy temperature estimated for non-interacting bosons, 𝑇<sup>∗</sup> �2𝑛�/𝐷 (dashed line)<sup>23</sup> , where 𝐷� � is the exciton �ℏ<sup>�</sup> density of states in 2D, defined by the exciton mass 𝑚�𝑚� and the reduced Planck constant ℏ (𝑚� is the free electron mass). 

The density dependence of the exciton compressibility in Fig. 4b indicates the importance of exciton-exciton interactions<sup>15, 16, 24, 25, 36</sup> .  We consider an interacting Bose gas model with a coupling constant 𝑔 (Ref.<sup>24</sup> ) for the system below 𝑇�.  The product 𝑔𝑛� describes the interaction energy per exciton.  The mean-field isothermal compressibility is given by � 𝜅� � (Methods).  The result reduces to a linear density dependence, ����������/�������<sup>��</sup> 𝜅� �𝑛�/�𝑔𝑛� �𝑘�𝑇�, in the high-temperature (non-degenerate) limit, and then to a constant, 𝜅� �𝑔<sup>��</sup> , in the low-temperature (degenerate) limit.  The value of the dimensionless coupling constant 𝑔𝐷�11 obtained from this analysis (Extended Data Fig. 5) is in reasonably good agreement with mean-field calculations for interacting bosons in TMD double layers<sup>15, 16, 24</sup> .  The compressibility peak in Fig. 4b is, however, in contradiction to mean-field-theory with a density-independent interaction.  This behavior suggests that the coupling constant increases with density as the exciton wavefunctions start to overlap.  The compressibility peak occurs when the thermal excitation energy is comparable to the interaction energy, 𝑘�𝑇<sup>∗∗</sup> ~ 𝑔𝑛�.  The ratio of 𝑇<sup>∗∗</sup> and 𝑇<sup>∗</sup> therefore corresponds to ~𝑔𝐷/2~5 �6, consistent with the independent analysis in Extended Data Fig. 5. 

The large dimensionless coupling constant 𝑔𝐷 shows that the exciton fluid is strongly correlated.  The strong correlation is expected to suppress exciton density fluctuations<sup>9, 37</sup> and enhance the effective degeneracy temperature from 𝑇<sup>∗</sup> to ~𝑔𝐷𝑇<sup>∗</sup> /2~𝑇<sup>∗∗</sup> (Ref.<sup>10</sup> ). 

5 

The region bound by 𝑇<sup>∗∗</sup> and 𝑇� in Fig. 4a therefore represents a degenerate exciton fluid with suppressed density fluctuations (i.e. a quasi-condensate<sup>9, 10, 37</sup> ).  The strong correlation is also expected to suppress phase fluctuations and enhance the exciton superfluid transition temperature<sup>9, 10, 37</sup> .  Our results pave the path for future studies on exciton superfluidity and the BEC-BCS crossover in TMD double layers.  (BEC and BCS stand for Bose-Einstein condensation and Bardeen-Cooper-Schrieffer, respectively). 

# **Methods** 

# **Device design and fabrication** 

A schematic of the dual-gated MoSe2/hBN/WSe2 devices is shown in Fig. 1b. The top and bottom gates consist of hBN gate dielectric of 10 - 20 nm in thickness and few-layer graphite gate electrodes. The two gates are typically symmetric. The hBN spacer between the two TMD monolayers has a different thickness in the region of interest (~ 1.5 - 2 nm) and in the contact region (10 - 20 nm). This is crucial to achieve good metal-TMD contacts as discussed below. The design allows us to achieve equilibrium exciton fluids by biasing the two TMD monolayers at ~ 1 V. Before the charge gap is closed, the tunneling current is negligible (Extended Data Fig. 3) and the exciton density is fully determined by the electrostatics (Fig. 2). 

This is in contrast to the previously reported devices<sup>27</sup> . There, excitons can be injected only under high bias (~ 5 - 6 V) because there is a large Schottky barrier at the graphiteTMD contacts and a significant portion of the bias voltage drops at the contact<sup>16</sup> . The electron/hole layer cannot be maintained at the same chemical potential as the contacts. The electrical contact resistance dominates the tunnel junction resistance and the devices are in the small tunnel junction resistance regime. A large tunneling current accompanies the injection of excitons. The exciton density is determined by balancing the pumping and recombination rates of excitons<sup>16</sup> . They are non-equilibrium exciton fluids. 

The current design circumvents the electrical contact issue by combining several strategies. We use Pt instead of graphite as contact electrodes; Pt has been reported to form good contacts to both MoSe2 and WSe2 monolayers<sup>38, 39</sup> . We heavily dope the TMDs in the contact region (but not in the region of interest) to form good metal-TMD contacts. This is achieved by applying a large vertical electric field (from anti-symmetric gating). The field creates a vertical voltage drop between the two TMD layers that is linearly proportional to the layer separation. We design a substantially thicker hBN spacer in the contact region than in the region of interest so that the interlayer band gap is closed in the contact region while it is only reduced in the region of interest. In addition, to further suppress electron tunneling between the TMD layers, we increase the thickness of the hBN spacer in the region of interest from 2-3 layers as in the reported devices<sup>27</sup> to 5-6 layers. Our devices are in the large tunnel junction resistance regime. We also find that it is crucial to have the electron and hole contacts close by to inject bound pairs at low temperatures. 

We fabricate the devices using the reported dry transfer technique<sup>40</sup> . The constituent layers are exfoliated from bulk TMD crystals (HQ Graphene) and other crystals onto Si 

6 

substrates covered by a 285 nm-thick SiO2 layer. Their thickness is first identified by optical reflection microscopy and subsequently confirmed by atomic force microscopy (AFM). The layers are picked up from substrates consecutively at ~ 50<sup>o</sup> C using a polymer stamp made of a thin layer of polycarbonate on a polypropylene-carbonatecoated polydimethylsiloxane block. The complete stack is then released onto an amorphous quartz substrate with pre-patterned Pt electrodes at 200<sup>o</sup> C. The residual polycarbonate film is removed in chloroform and isopropanol. Amorphous quartz is chosen as substrates for minimal parasitic capacitance background. The background is also temperature independent, which allows capacitance studies over a broad temperature range. Extended Data Figure 1 shows the optical image of a typical device. We have examined multiple devices in this study. The results are highly reproducible. Main results from an additional device (device 2) are shown in Extended Data Fig. 6. 

# **Capacitance measurements** 

We perform two types of capacitance measurements. The first is the penetration capacitance. We apply a small AC voltage 𝑑𝑉�� of root mean square (rms) amplitude 5 mV and frequency 423 Hz to the top gate. It generates an AC electric field that can penetrate the AC-grounded TMD double layer and induce a small charge density 𝑑𝑛�� on the bottom gate. The induced charge density is measured using a low-temperature integrated capacitance bridge based on a GaAs high-electron-mobility transistor (HEMT) amplifier<sup>41</sup> . The measurement circuit diagram is shown in Extended Data Fig. 7a. The AC voltage 𝑑𝑉�� modulates both the charge carrier density 𝑑𝑛 and the chemical potential 𝑑𝜇 of the entire double layer. Using an equivalent circuit model for the device (Extended Data Fig. 7b) and ignoring a small contribution from the layer polarizability of the double ���� ���� � layer<sup>42</sup> , we derive the penetration capacitance, 𝐶� �𝑒 , where 𝐶� � ���� ��/����� 𝑒<sup>�</sup> 𝑑𝑛/𝑑𝜇 is the junction’s quantum capacitance, and 𝐶�� is the gate-to-gate geometrical capacitance per unit area. The measured 𝐶� is independent of frequency ranging from 77 Hz to 3.3 kHz. 

We also measure the interlayer capacitance (the capacitance of the MoSe2/hBN/WSe2 junctions). The equivalent circuit consists of an interlayer capacitance and a tunneling resistance in parallel. For each DC bias voltage and gate voltage, we apply a small AC excitation voltage 𝑑𝑉� (rms amplitude 5 mV and frequency _f_ = 1187 Hz) to the Mo-layer, and detect the induced interlayer current 𝑑𝐼 from the W-layer. The interlayer current is complex in general. The in-phase component 𝑑𝐼<sup>���</sup> corresponds to the interlayer tunneling current; and the out-of-phase component, the displacement current 𝑑𝐼<sup>���</sup> , is proportional to the change in exciton density 𝑑𝑛� . Both in-phase and out-of-phase components (after a preamplifier) are detected with a lock-in amplifier (SR830). The interlayer capacitance reported in the main text is defined by the displacement current, � ��<sup>���</sup> 𝐶� � , where 𝐴�34 μm<sup>2</sup> is the area of the double layer region. The ���� ��� measurement results are independent of the excitation amplitude (2 - 15 mV) and frequency (77 Hz to 7.7 kHz). 

# **Interlayer band gap** 

7 

The interlayer band gap 𝐸� of the TMD double layer is controlled by anti-symmetric gating ∆ ≡�𝑉�� �𝑉���/2. It creates an out-of-plane electric field and a voltage drop of � ��� 2∆ between the TMD layers from the geometrical considerations. Here 𝑡�� and 𝑡�� are ��� the TMD interlayer separation and the gate-to-gate separation, respectively. The voltage drop reduces the interlayer band gap linearly, 𝐸� �𝐸�� � ��� 2𝑒∆ , where 𝐸�� is the ��� intrinsic gap value. As described in the main text, the interlayer band gap can be measured from the penetration capacitance under zero bias; it corresponds to the voltage separation between the capacitance rising and falling edges (Fig. 1d). Extended Data Fig. 2 shows the measured gap value as a function of anti-symmetric gating ∆. It is well described by the above linear dependence with a slope of about 0.21 _e_ . This is fully ��� � �� consistent with the geometry of the device 2 �2 �0.2. The extrapolated gap ��� �� �� 

value at zero bias (1.6 eV) is also in good agreement with the reported interlayer band gap (under zero electric field) for MoSe2/WSe2 double layers<sup>43</sup> . All the data presented in the main text were taken at Δ �4.6 V, which corresponds to 𝐸� �0.68 eV. 

# **Electrostatics simulation** 

We can model the electrostatics of the devices approximately using a parallel-plate capacitor model (Extended Data Fig. 8) that neglects the exciton binding energy. We express the electron density (𝑛� �0) in the Mo-layer and the hole density (𝑛� �0) in the W-layer for given bias voltage 𝑉� and gate voltages 𝑉�� and 𝑉�� as 



<!-- Start of picture text -->
𝑛�𝑒 � �2𝐶���𝑒𝑉�� �𝜙���𝐶���𝜙� �𝜙��, (1)<br><!-- End of picture text -->



<!-- Start of picture text -->
𝑛�𝑒 � �2𝐶���𝜙� �𝑒𝑉����𝐶���𝜙� �𝜙��. (2)<br><!-- End of picture text -->

Here 𝜙� �𝜇� �𝑒𝑉� and 𝜙� ��𝜇� are the electrostatic potential of the Mo- and W- layer, respectively; 𝜇� �0 and 𝜇� �0 are the electron and hole chemical potentials, respectively; 𝐶�� and 𝐶�� are the gate-to-gate and the TMD double layer geometrical capacitance per unit area, respectively. They are determined by the separation between the capacitor plates and the dielectric constant of the dielectric medium. We can relate the chemical potentials to the carrier densities through the electronic density of states, 𝜇� � �� 𝜋ℏ<sup>2</sup> �� 𝜋ℏ<sup>2</sup> � 𝑛� and 𝜇� � � 𝑛�. Here 𝑚� �𝑚��� 0.5𝑚�)<sup>44</sup> are the electron and hole � �� � �� band masses (𝑚� denoting the free electron mass), and ℏ is the reduced Planck constant. We solve equations (1) and (2) for 𝑛� and 𝑛�. The result in Fig. 2a corresponds to the reported hBN dielectric constant (�3.5)<sup>38</sup> and the measured hBN thickness between the gates (�20 nm) and between the TMD layers (�2 nm) for device 1. 

# **Interlayer tunneling current and exciton lifetime** 

In addition to the interlayer capacitance, we monitor the DC tunneling current 𝐼 in the double layer. Extended Data Fig. 3 shows the tunneling current as a function of bias voltage 𝑉� near equal electron and hole densities. The different curves correspond to different anti-symmetric gating Δ, which varies the interlayer band gap energy 𝐸�. The current onset is observed approximately when 𝑒𝑉� ≳ 𝐸�. 

8 

The different regimes of tunneling are illustrated in Extended Data Fig. 3b for a fixed anti-symmetric gating Δ �4 V. The tunneling current remains relatively small over an extended range of bias voltage above the threshold (~ 1 nA or smaller, corresponding to a tunneling current density of no more than 0.03 nA/μm<sup>2</sup> ). The tunneling current density is over four orders of magnitude smaller than that in the devices reported in Ref.<sup>27</sup> . Tunneling in this regime arises from a non-resonant process (left inset). When 𝑉� exceeds ~ 1.7 V (independent of ∆), the tunneling current increases dramatically. The value agrees well with the band gap of monolayer MoSe2 (Ref.<sup>43</sup> ). In this regime, tunneling arises from a resonant process (right inset) and a non-equilibrium exciton fluid is formed. The exciton density is determined by balancing the pumping and recombination rates, rather than by electrostatics. 

We focus on the equilibrium regime (𝑉� �1.7 V) in this study. In this regime, the exciton lifetime, 𝜏�, can be estimated from the tunneling current density and the exciton ���� density: 𝜏� � . Extended Data Figure 3c shows the bias dependence of 𝜏� . The � exciton lifetime is on the order of millisecond. 

# **Compressibility of a 2D interacting Bose gas** 

The density of a 2D interacting Bose gas is defined by the Bose-Einstein statistics as 



<!-- Start of picture text -->
𝑛� ���� 𝑑𝜖� ����������������/������ ��𝐷𝑇�ln �1 �exp ������������.   (3)<br><!-- End of picture text -->

� Here 𝐷� is the exciton density of states in 2D with exciton mass 𝑚�𝑚� �𝑚�, 𝜖� �ℏ<sup>�</sup> and 𝜇� are the exciton kinetic energy and chemical potential, respectively, and 𝑔 is the exciton-exciton coupling constant. The mean-field isothermal exciton compressibility is ��� . evaluated as 𝜅� ������� 

In the main text we estimate the exciton-exciton coupling constant 𝑔 in the low-density limit from the crossover of the compressibility from the high-temperature to the lowtemperature behavior. We can also evaluate the coupling constant 𝑔 by analyzing the compressibility in the high-temperature limit. Extended Data Figure 5 shows the temperature dependence of the inverse interlayer capacitance (symbols) at representative densities in this regime. The data are well described by the mean-field result (solid lines), 𝐶��� ∝ 𝜅��� �𝑔� �� 𝑇. The _y_ -intercept is proportional to 𝑔, and the _x_ -intercept is given �� by �𝑔𝑛�/𝑘� . Extended Data Figure 5b shows the magnitude of the _x_ -intercept as a function of density. We extract 𝑔��2.6 �0.1��10<sup>���</sup> eVcm<sup>2</sup> (𝑔𝐷�11) from the slope of the linear fit (solid line). A similar value is also obtained from the _y_ -intercept and the known device area of 𝐴. The positive sign of 𝑔 indicates a repulsive interaction. The 𝑔 value is also in good agreement with a mean-field calculation for interacting bosons in TMD double layers (𝑔�3 �10<sup>���</sup> eVcm<sup>2</sup> )<sup>24</sup> . 

9 

# **Data availability** 

The data that support the plots within this paper, and other findings of this study, are available from the corresponding authors upon reasonable request. 

# **Acknowledgements** 

We thank Erich J. Mueller and Cory Dean for fruitful discussions. 

# **References** 

1. Mott, N.F. The transition to the metallic state. _The Philosophical Magazine: A Journal of Theoretical Experimental and Applied Physics_ **6** , 287-309 (1961). 

2. Jérome, D., Rice, T.M. & Kohn, W. Excitonic Insulator. _Physical Review_ **158** , 462-475 (1967). 

3. Zhu, X., Littlewood, P.B., Hybertsen, M.S. & Rice, T.M. Exciton Condensate in Semiconductor Quantum Well Structures. _Physical Review Letters_ **74** , 1633-1636 (1995). 

4. Sun, Z. & Millis, A.J. Topological Charge Pumping in Excitonic Insulators. _Physical Review Letters_ **126** , 027601 (2021). 

5. Eisenstein, J.P. & MacDonald, A.H. Bose–Einstein condensation of excitons in bilayer electron systems. _Nature_ **432** , 691-694 (2004). 

6. Kogar, A., Rak, M.S., Vig, S., Husain, A.A., Flicker, F., Joe, Y.I., Venema, L., MacDougall, G.J., Chiang, T.C., Fradkin, E., van Wezel, J. & Abbamonte, P. Signatures of exciton condensation in a transition metal dichalcogenide. _Science_ **358** , 1314 (2017). 

7. Butov, L.V. Condensation and pattern formation in cold exciton gases in coupled quantum wells. _Journal of Physics: Condensed Matter_ **16** , R1577-R1613 (2004). 

8. Baranov, M.A., Dalmonte, M., Pupillo, G. & Zoller, P. Condensed Matter Theory of Dipolar Quantum Gases. _Chemical Reviews_ **112** , 5012-5061 (2012). 

9. Z. Hadzibabic & Dalibard, J. Two-dimensional Bose fluids: An atomic physics perspective. _Rivista del Nuovo Cimento_ **34** , 389 (2011). 

10. Lozovik, Y.E., Kurbakov, I.L., Astrakharchik, G.E., Boronat, J. & Willander, M. Strong correlation effects in 2D Bose–Einstein condensed dipolar excitons. _Solid State Communications_ **144** , 399-404 (2007). 

11. Ha, L.-C., Hung, C.-L., Zhang, X., Eismann, U., Tung, S.-K. & Chin, C. Strongly Interacting Two-Dimensional Bose Gases. _Physical Review Letters_ **110** , 145302 (2013). 

12. Cercellier, H., Monney, C., Clerc, F., Battaglia, C., Despont, L., Garnier, M.G., Beck, H., Aebi, P., Patthey, L., Berger, H. & Forró, L. Evidence for an Excitonic Insulator Phase in 1T-TiSe2. _Physical Review Letters_ **99** , 146403 (2007). 

13. Seki, K., Wakisaka, Y., Kaneko, T., Toriyama, T., Konishi, T., Sudayama, T., Saini, N.L., Arita, M., Namatame, H., Taniguchi, M., Katayama, N., Nohara, M., Takagi, H., Mizokawa, T. & Ohta, Y. Excitonic Bose-Einstein condensation in Ta2NiSe5. _Physical Review B_ **90** , 155116 (2014). 

10 

14. Du, L., Li, X., Lou, W., Sullivan, G., Chang, K., Kono, J. & Du, R.-R. Evidence for a topological excitonic insulator in InAs/GaSb bilayers. _Nature Communications_ **8** , 1971 (2017). 

15. Xie, M. & MacDonald, A.H. Electrical Reservoirs for Bilayer Excitons. _Physical Review Letters_ **121** , 067702 (2018). 

16. Zeng, Y. & MacDonald, A.H. Electrically controlled two-dimensional electronhole fluids. _Physical Review B_ **102** , 085154 (2020). 

17. Burg, G.W., Prasad, N., Kim, K., Taniguchi, T., Watanabe, K., MacDonald, A.H., Register, L.F. & Tutuc, E. Strongly Enhanced Tunneling at Total Charge Neutrality in Double-Bilayer Graphene-WSe2 Heterostructures. _Physical Review Letters_ **120** , 177702 (2018). 

18. Su, J.-J. & MacDonald, A.H. How to make a bilayer exciton condensate flow. _Nature Physics_ **4** , 799-802 (2008). 

19. Yu. E. Lozovik & Yudson, V.I. A new mechanism for superconductivity: pairing between spatially separated electrons and holes. _Zh. Eksp. Teor. Fiz._ **71** , 738-753 (1976). 

20. Dolcini, F., Rainis, D., Taddei, F., Polini, M., Fazio, R. & MacDonald, A.H. Blockade and Counterflow Supercurrent in Exciton-Condensate Josephson Junctions. _Physical Review Letters_ **104** , 027004 (2010). 

21. Halperin, B.I. & Rice, T.M. Possible Anomalies at a Semimetal-Semiconductor Transistion. _Reviews of Modern Physics_ **40** , 755-766 (1968). 

22. Kohn, W. & Sherrington, D. Two Kinds of Bosons and Bose Condensates. _Reviews of Modern Physics_ **42** , 1-11 (1970). 

23. Fogler, M.M., Butov, L.V. & Novoselov, K.S. High-temperature superfluidity with indirect excitons in van der Waals heterostructures. _Nature Communications_ **5** , 4555 (2014). 

24. Wu, F.-C., Xue, F. & MacDonald, A.H. Theory of two-dimensional spatially indirect equilibrium exciton condensates. _Physical Review B_ **92** , 165121 (2015). 

25. Skinner, B., Yu, G.L., Kretinin, A.V., Geim, A.K., Novoselov, K.S. & Shklovskii, B.I. Effect of dielectric response on the quantum capacitance of graphene in a strong magnetic field. _Physical Review B_ **88** , 155417 (2013). 

26. Zhiyuan Sun, Tatsuya Kaneko, Denis Golež & Millis, A.J. Second order Josephson effect in excitonic insulators. _arXiv:2102.10455_ (2021). 

27. Wang, Z., Rhodes, D.A., Watanabe, K., Taniguchi, T., Hone, J.C., Shan, J. & Mak, K.F. Evidence of high-temperature exciton condensation in two-dimensional atomic double layers. _Nature_ **574** , 76-80 (2019). 

28. Jauregui, L.A., Joe, A.Y., Pistunova, K., Wild, D.S., High, A.A., Zhou, Y., Scuri, G., De Greve, K., Sushko, A., Yu, C.-H., Taniguchi, T., Watanabe, K., Needleman, D.J., Lukin, M.D., Park, H. & Kim, P. Electrical control of interlayer exciton dynamics in atomically thin heterostructures. _Science_ **366** , 870 (2019). 

29. Paik, E.Y., Zhang, L., Burg, G.W., Gogna, R., Tutuc, E. & Deng, H. Interlayer exciton laser of extended spatial coherence in atomically thin heterostructures. _Nature_ **576** , 80-84 (2019). 

30. Li, J.I.A., Taniguchi, T., Watanabe, K., Hone, J. & Dean, C.R. Excitonic superfluid phase in double bilayer graphene. _Nature Physics_ **13** , 751-755 (2017). 

11 

31. Liu, X., Watanabe, K., Taniguchi, T., Halperin, B.I. & Kim, P. Quantum Hall drag of exciton condensate in graphene. _Nature Physics_ **13** , 746-750 (2017). 

32. Rivera, P., Yu, H., Seyler, K.L., Wilson, N.P., Yao, W. & Xu, X. Interlayer valley excitons in heterobilayers of transition metal dichalcogenides. _Nature Nanotechnology_ **13** , 1004-1015 (2018). 

33. Eisenstein, J.P., Pfeiffer, L.N. & West, K.W. Negative compressibility of interacting two-dimensional electron and quasiparticle gases. _Physical Review Letters_ **68** , 674-677 (1992). 

34. De Palo, S., Rapisarda, F. & Senatore, G. Excitonic Condensation in a Symmetric Electron-Hole Bilayer. _Physical Review Letters_ **88** , 206401 (2002). 

35. López Ríos, P., Perali, A., Needs, R.J. & Neilson, D. Evidence from Quantum Monte Carlo Simulations of Large-Gap Superfluidity and BCS-BEC Crossover in Double Electron-Hole Layers. _Physical Review Letters_ **120** , 177701 (2018). 

36. Skinner, B. & Shklovskii, B.I. Anomalously large capacitance of a plane capacitor with a two-dimensional electron gas. _Physical Review B_ **82** , 155111 (2010). 

37. Kagan, Y., Kashurnikov, V.A., Krasavin, A.V., Prokof’ev, N.V. & Svistunov, B.V. Quasicondensation in a two-dimensional interacting Bose gas. _Physical Review A_ **61** , 043608 (2000). 

38. Fallahazad, B., Movva, H.C.P., Kim, K., Larentis, S., Taniguchi, T., Watanabe, K., Banerjee, S.K. & Tutuc, E. Shubnikov--de Haas Oscillations of High-Mobility Holes in Monolayer and Bilayer WSe2: Landau Level Degeneracy, Effective Mass, and Negative Compressibility. _Physical Review Letters_ **116** , 086601 (2016). 

39. Larentis, S., Movva, H.C.P., Fallahazad, B., Kim, K., Behroozi, A., Taniguchi, T., Watanabe, K., Banerjee, S.K. & Tutuc, E. Large effective mass and interactionenhanced Zeeman splitting of K-valley electrons in MoSe2. _Physical Review B_ **97** , 201407 (2018). 

40. Wang, L., Meric, I., Huang, P.Y., Gao, Q., Gao, Y., Tran, H., Taniguchi, T., Watanabe, K., Campos, L.M., Muller, D.A., Guo, J., Kim, P., Hone, J., Shepard, K.L. & Dean, C.R. One-Dimensional Electrical Contact to a Two-Dimensional Material. _Science_ **342** , 614 (2013). 

41. Ashoori, R.C., Stormer, H.L., Weiner, J.S., Pfeiffer, L.N., Pearton, S.J., Baldwin, K.W. & West, K.W. Single-electron capacitance spectroscopy of discrete quantum levels. _Physical Review Letters_ **68** , 3088-3091 (1992). 

42. Young, A.F. & Levitov, L.S. Capacitance of graphene bilayer as a probe of layerspecific properties. _Physical Review B_ **84** , 085441 (2011). 

43. Wilson, N.R., Nguyen, P.V., Seyler, K., Rivera, P., Marsden, A.J., Laker, Z.P.L., Constantinescu, G.C., Kandyba, V., Barinov, A., Hine, N.D.M., Xu, X. & Cobden, D.H. Determination of band offsets, hybridization, and exciton binding in 2D semiconductor heterostructures. _Science Advances_ **3** , e1601832 (2017). 

44. Mak, K.F. & Shan, J. Photonics and optoelectronics of 2D semiconductor transition metal dichalcogenides. _Nature Photonics_ **10** , 216-226 (2016). 

12 

# **Figures** 



**Figure 1 | Electrical reservoir for interlayer excitons. a,** Type II band alignment of MoSe2/WSe2 double layers with interlayer band gap 𝐸� (left). A bias voltage 𝑉� across the layers separates the electron and hole chemical potentials (dashed lines) and reduces the charge gap (right). Interlayer excitons are formed spontaneously when the bias voltage, which acts as a chemical potential for excitons, exceeds the exciton energy 𝐸� � 𝐸�. **b,** Schematic cross-section of dual-gated double layer devices. The anti-symmetric gating ∆ reduces 𝐸� in the region of interest; it closes 𝐸� in the contact region to heavily dope the TMDs. The symmetric gating 𝑉� shifts the electron and hole chemical potentials together and tune their density difference. **c, e,** Schematics of the penetration ( **c** ) and interlayer capacitance ( **e** ) measurements. The double layer is AC grounded in **c** . **d,** Gate dependence of the normalized penetration capacitance at representative bias voltages. The sharp capacitance drops signify electron or hole doping into the double layer. The charge gap is closed for 𝑉� � 0.7 V. **f,** Bias dependence of the normalized interlayer capacitance (black) and the exciton density (red) at 𝑉� = 0. **d** and **f** are measured at 15 K and ∆ = 4.6 V. 

13 



**Figure 2 | Exciton and charge compressibility. a,** Electrostatics simulation of double layer device 1 based on the parallel-plate capacitor model. The electron-hole interaction is ignored. The double layer can be in one of the four doping regions as a function of bias and gate voltages ( _i_ , _p_ and _n_ denoting an intrinsic, positively and negatively doped layer). The _ii_ region (white) is enclosed by a vertical line (valence band edge of the grounded W- layer) and a line of slope -1 (conduction band edge of the Mo-layer). **b, c,** Normalized penetration capacitance 𝐶�/𝐶�� ( **b** ) and interlayer capacitance 𝐶�/𝐶�� ( **c** ) as a function of bias and gate voltages, where 𝐶�� and 𝐶�� are the gate-to-gate and interlayer geometrical capacitances, respectively. The charge incompressible region in **b** is enclosed by red dashed lines. White dashed line I and II correspond to the bias voltages at which the charge gap closes and the exciton population appears, respectively. Their difference (25 mV) provides an estimate of the exciton binding energy at zero density. The measurements are performed at 15 K and ∆ = 4.6 V. 

14 



**Figure 3 | Charge gap energy of the double layer.** The charge gap energy as a function of exciton density at different temperatures (symbols). Each data point is extracted from the gate dependence of the penetration capacitance for a fixed bias voltage and temperature. The error bar shows the typical uncertainty of the analysis as described in Extended Data Figure 4. The lines are a guide to the eye. 

15 



**Figure 4 | Exciton phase diagram. a,** Normalized interlayer capacitance, or equivalently, exciton compressibility as a function of temperature and exciton density. The white squares denote the exciton ionization temperature 𝑇�, which separates the crossover from the excitonic insulator (EI) (below) to a mixture of excitons and electron-hole plasma (above). The dashed line 𝑇<sup>∗</sup> and dotted line 𝑇<sup>∗∗</sup> show, respectively, the degeneracy temperature of non-interacting excitons and the temperature for the exciton compressibility peak. The error bar represents the typical uncertainty in density of the compressibility peak. **b,** Exciton compressibility as a function of exciton density at varying temperatures. The compressibility peak divides the high-temperature (left) and low-temperature (right) regime. 

16 

# **Extended Data Figures.** 



**Extended Data Figure 1 | Device image. a,** Optical image of the MoSe2/WSe2 device presented in the main text (Device 1). The dashed lines mark the boundaries of the top and bottom graphite gates (purple), the MoSe2 monolayer (yellow), the WSe2 monolayer (red), and the thick hBN spacer in the contact region (light-blue). The thin hBN spacer that separates the two TMD layers is not shown. The black solid line marks the boundary of the contact region and the region of interest (shaded). **b,** Atomic force microscopy (AFM) profile of the thin BN spacer, showing a step height of ~1.7 nm (~ 6-layer). 



**Extended Data Figure 2 | Dependence of interlayer band gap on anti-symmetric gating. a,** Gate dependence of penetration capacitance at 15 K under varying antisymmetric gating Δ and 𝑉� �0 V. The step falls signify electron doping into the MoSe2 conduction band (CB) or hole doping into the WSe2 valence band (VB). The separation between the rising and falling edges determines the band gap 𝐸�. An additional step on the electron-doping side arises from the presence of a small isolated MoSe2 monolayer inside the dual-gated device that affects the penetration capacitance. **b,** Interlayer band gap 𝐸� (symbols) extracted from **a** as a function of ∆. The linear fit (dashed line) has a slope of ~ 0.21 _e_ . The gap energy extrapolated for ∆ = 0 corresponds to the intrinsic band gap energy 𝐸�� �1.6 eV. 

17 



**Extended Data Figure 3 | Tunneling current and exciton lifetime. a,** Bias-dependent interlayer tunneling current of device 1 under Δ �4.6 V (red), 4.25 V (blue), 4.00 V (black), and 3.75 V (green). The shift of the onset with Δ is caused by the changing interlayer band gap. **b,** Interlayer tunneling current over a larger bias range at Δ �4 V. The insets illustrate both the non-resonant (blue-shaded) and resonant (orange-shaded) tunneling regimes. **c,** Estimated exciton lifetime as a function of 𝑉� from the tunneling data at Δ �4.6 V in **a** . 

18 





**Extended Data Figure 4 | Determination of the charge gap.** The penetration capacitance ( **a** ) and the charge chemical potential of the double layer ( **b** ) at 15 K as a function of 𝑉� at varying exciton densities. The capacitance peak shows the presence of a charge-incompressible state. The integrated area of the peak gives the chemical potential jump (or the charge gap) at equal electron-hole density. The zero point of the chemical potential shift in **b** has been shifted to 𝑉� = 0 V for comparison of different exciton densities. The charge gap closes near the Mott density. **c, d,** Similar to **a, b,** at a fixed exciton density 𝑛� �2.4 �10<sup>��</sup> cm<sup>-2</sup> for different temperatures. The charge gap closes at the ionization temperature. 

19 



**Extended Data Figure 5 | Exciton compressibility in the high-temperature limit. a,** Inverse interlayer capacitance (or exciton compressibility) as a function of temperature at varying exciton densities. The dashed lines are linear fits in the high-temperature limit, i.e. 𝑔𝑛�/𝑘� ≲𝑇≲𝑇�. **b,** Amplitude of the extracted _x_ -intercept in **a** as a function of exciton density. A linear fit (blue) gives 𝑔 = �2.6 �0.1��10<sup>���</sup> eVcm<sup>2</sup> . The inset shows the experimental (black) and expected (red) exciton density dependence of the slope of the linear fits in **a** . The density range is the same as the main panel. 



**Extended Data Figure 6 | Main results from device 2.** Penetration capacitance **(a)** and interlayer capacitance **(b)** as a function of bias and gate voltages. The Mo-layer is grounded. The two red dashed lines denote the conduction band edge of MoSe2 (vertical line) and the valance band edge of WSe2 (line with slope +1). The two white dashed lines denote the bias voltage at which the charge gap closes (I) and the exciton fluid becomes compressible (II). The difference between the two values (~ 40 mV) corresponds to the exciton binding energy at 𝑛� �0, which is slightly larger than in Device 1 shown in the main text (~ 25 mV) because the hBN barrier is slightly thinner (~ 5-layer). 

20 



**Extended Data Figure 7 | Circuit diagram. a,** Circuit diagram for the penetration capacitance measurement. The red dashed line encloses the sample area. The reference part (𝑉��� and 𝐶���) is used to cancel the parasitic background capacitance. The HEMT is biased at voltage 𝑉� . **b,** Equivalent circuit model of 𝐶� in **a** . Here 𝐶� �2𝐶�� is the sample-to-gate geometrical capacitance, which is about twice the gate-to-gate geometrical capacitance 𝐶��. 



**Extended Data Figure 8 | Equivalent device circuit model for electrostatics simulation.** 𝐶�,� and 𝐶�,� are the quantum capacitances of the MoSe2 and WSe2 monolayers, respectively. Details see Methods. 

21 

