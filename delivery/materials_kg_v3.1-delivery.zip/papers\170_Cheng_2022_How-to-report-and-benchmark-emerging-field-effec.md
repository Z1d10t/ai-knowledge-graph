# How to report and benchmark emerging field-effect transistors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Zhihui Cheng, C. Pang, Peiqi Wang, S. Le, Yan-Qing Wu, D. Shahrjerdi, I. Radu, M. Lemme et al. |
| DOI | 10.1038/s41928-022-00798-8 |
| 源文件 | 070_Cheng_2022_How-to-report-and-benchmark-emerging-field-effec.pdf |

---
The journal version of this paper can be accessed in Nature Electronics https://doi.org/10.1038/s41928-022-00798-8 

How to Report and Benchmark Emerging Field-Effect Transistors 

Zhihui Cheng<sup>1,2,☨</sup> , Chin-Sheng Pang<sup>2</sup> , Peiqi Wang<sup>3</sup> , Son T. Le<sup>1,4</sup> , Yanqing Wu<sup>5</sup> , Davood Shahrjerdi<sup>6,7</sup> , Iuliana Radu<sup>8</sup> , Max C. Lemme<sup>9,10</sup> , Lian-Mao Peng<sup>11</sup> , Xiangfeng Duan<sup>3</sup> , Zhihong Chen<sup>2</sup> , Joerg Appenzeller<sup>2</sup> , Steven J. Koester<sup>12</sup> , Eric Pop<sup>13</sup> , Aaron D. Franklin<sup>14,15,☨</sup> , Curt A. Richter<sup>1,☨</sup> 

**The use of organic, oxide and low-dimensional materials in field-effect transistors has now been studied for decades. However, properly reporting and comparing device performance remains challenging due to the interdependency of multiple device parameters. The interdisciplinarity of this research community has also led to a lack of consistent reporting and benchmarking guidelines. Here we propose guidelines for reporting and benchmarking key field-effect transistor parameters and performance metrics. We provide an example of this reporting and benchmarking process by using a two-dimensional semiconductor field-effect transistor. Our guidelines should help promote an improved approach for assessing device performance in emerging field-effect transistors, helping the field to progress in a more consistent and meaningful way.** 

Research into field-effect transistors (FETs) based on emerging nanomaterials, including carbon nanotubes<sup>1,2</sup> , graphene<sup>3</sup> , phosphorene<sup>4</sup> , silicene<sup>5</sup> , tellurene<sup>6</sup> , transition metal dichalcogenides<sup>7–9</sup> , organic semiconductors<sup>10,11</sup> and ultrathin metal oxides<sup>12</sup> , is thriving. Such studies allow the fundamental properties of the materials to be explored, and may lead to the development of various commercial applications; however, effectively and uniformly assessing the performance of emergent FETs is difficult due to the dependence of performance metrics on unique aspects of the device structure (Fig. 1a)<sup>13</sup> . 

Structural parameters that influence device performance include channel ( _L_ ch) and contact lengths ( _L_ c), gate insulator thickness ( _t_ ins) and permittivity ( _ϵ_ ins), contact metal types, the thickness of channel material ( _t_ ch), and gating scheme (e.g., top, bottom, gate-all-around, multi-channel). Performance metrics include on-current ( _I_ on), off-current ( _I_ off), _I_ on/ _I_ off ratio, contact resistance ( _R_ c), transconductance ( _g_ m), subthreshold swing ( _SS_ ), channel mobilities, and drain-induced barrier lowering (DIBL). While different studies reported in the literature often include some of these benchmarking figures, they struggle to capture the myriad variables, making comparisons inaccurate or even biased at times. In addition, the emerging device community consists of researchers from disparate disciplines — including electrical engineering, chemistry, materials science, and physics — which also makes consistent reporting and benchmarking challenging. In this Perspective, we examine the challenges involved in assessing the operation and performance of FETs based on emerging materials, and provide guidelines on how to report and benchmark the devices. 

A full list of affiliations appears at the end of the paper. 

1 

### **Field-effect transistor structure and key parameters** 

In a FET, the structural parameters determine the electric fields and the eventual device performance (Fig. 1a). Subthreshold, transfer, and output characteristics in Figs. 1b-d are the most common _I_ - _V_ (current-voltage) curves to capture the device performance. Plotting the log of the drain current ( _I_ D) as a function of gate-source voltage ( _V_ GS) highlights the subthreshold (i.e., off-state) device behaviour. In contrast, transfer characteristics plot _I_ D vs. _V_ GS on a linear scale and emphasize the device behaviour after _V_ GS exceeds the threshold voltage ( _V_ T), where the device is in the on-state. Ideally, the gate leakage current ( _I_ G) vs. _V_ GS should be plotted on the subthreshold plot as well. 



<!-- Start of picture text -->
a L ch<br>L c 1D<br>G<br>Nanotube/Nanowire<br>S E gate D<br>t ch<br>2D<br>E ch<br>‘X’-ene, TMDs,<br>Ultra-thin materials…<br>b c d<br>Log Linear Linear V DS (sat) =  V GS -  V T<br>Pinch-off<br>I ON I ON V GS =  V DD<br>linear velocity<br>saturation<br>I sat ∝ V OV  v sat<br>△ V GS<br>SS -1<br>I sat ∝ V OV  2<br>I OFF I G<br>V GS (V) V T V GS (V) V DD V DS (V) V DD<br>Fig. 1 | Basic device structure and electrical characteristics .  a , Diagram of a typical nanomaterial-based n-type<br>FET highlighting the structure parameters and electric fields.  b , Subthreshold and  c , transfer ( I D- V GS) curves of an  n -<br>type FET under different  V DS voltages. Representative curves are shown for single-sweep in ( b ), but forward- and<br>backward-sweeps of  VGS should be collected to determine hysteresis, as shown in ( c ). The gate leakage current is also<br>shown in ( b ).  d , Output ( I D- V DS) curves of the device with three main operation regimes labelled. 14 V GS is swept from<br>low to high in steps of Δ V GS.  v sat is the saturation velocity of carriers in the channel material.  I sat scales as  V OV 2  in the<br>classical pinch-off regime, but only linearly with  V OV when the velocity saturates. Self-heating could render this<br>increase even sub-linear. 14,15  Note,  V DD is the supply voltage for the transistor (i.e., the target maximum voltage of<br>operation for both  V DS and  V GS).<br>t ins<br>Small  V DS<br>Small  V DS<br>VDS =  V DD<br>W ch<br>V DS = VDD<br>I  (μA/μm)D I  (μA/μm)D I  (μA/μm)D<br><!-- End of picture text -->

The _I_ D- _V_ GS sweeps in Fig. 1b-c should be conducted at both “small” and “high” drain-source voltage ( _V_ DS) values to characterize the device operation in both linear and saturation regimes. We note 

2 

that the “small” _V_ DS value should be sufficiently small to ensure linear regime operation, but greater than ~2 _k_ B _T_ (where _k_ B is the Boltzmann constant and _T_ is the absolute temperature, i.e., ~50 mV at room temperature) to ensure that the subthreshold behaviour, and here in particular DIBL (∂ _V_ T/∂ _V_ DS), is not misinterpreted due to thermal injection of carriers from the drain. These curves enable easy extraction of DIBL to demonstrate how _V_ DS impacts _V_ T. The transfer characteristics should be acquired with forward and backward sweeps, checking for the presence of any hysteresis due to charge trapping<sup>16</sup> . When comparing hysteresis from different devices, the precise measurement conditions such as sweep rates, hold times, and maximum bias voltages should be listed as these parameters influence hysteresis. If hysteresis exists, it should be accounted for in the analysis of _V_ T uncertainty and other device parameters that depend on _V_ T. 

In the output characteristics (Fig. 1d), three main operation regimes are highlighted. The linear regime is characterized by the linear increase of _I_ D with both _V_ DS and _V_ GS. After _V_ DS surpasses the overdrive voltage ( _V_ OV = _V_ GS - _V_ T, for _n_ -channel FETs), _I_ D starts to saturate to _I_ sat, which could (based on the classical FET model<sup>17</sup> ) increase quadratically with _V_ OV in the pinch-off regime and linearly with _V_ OV in the velocity saturation regime<sup>14</sup> . Note, the linear regime may present as nonlinear (often exponential) in the event of poor carrier injection at the contacts, such as from large Schottky barriers. 

Multiple performance parameters can be extracted from the _I-V_ curves in Fig. 1b-d. The most important performance metrics are the currents, which must be reported normalized by the channel width, _W_ ch (e.g., units of μA/μm). For 1D or quasi-1D devices, it is common to first report the current per CNT/nanowire/nanosheet stack. Then the current can be normalized to μA/μm by considering the expected channel density and pitch of the channel material (e.g., 10 µA/CNT with 50 CNTs/µm, giving 500 µA/µm) since the aerial footprint of the device is a critical aspect of performance. When extracting _I_ on and _I_ off from these _I-V_ curves, in a simplified scenario, _I_ off is the _I_ D measured at _V_ GS = 0 and _V_ DS = _V_ DD, whereas _I_ on is the _I_ D measured at _V_ GS = _V_ DS = _V_ DD. Here, _V_ DD is the voltage that would be supplied to operate the transistors. (For mainstream silicon technology, _V_ DD has dropped to 1 V near 2010 and to 0.7 V in recent years<sup>18</sup> .) For modern technologies, the exact value of _V_ DD depends on the application. For example, if the emergent transistor is used as an access transistor in a dynamic random-access memory (DRAM), then its _V_ DD will be a small value to ensure linear regime operation in the on-state. Reported emergent devices often do not have threshold voltages tuned such that _V_ GS = 0 is a sensible off-state; additionally, there is often not a well-defined _V_ DD value due to the wide variety of device structural parameters. We hence suggest extracting the maximum and minimum _I_ D ( _I_ max and _I_ min) from 

3 

a typical subthreshold curve and reporting the _I_ max/ _I_ min ratios when _V_ DS is biased in both linear and saturation regimes. A more detailed description on reporting and benchmarking _I_ max/ _I_ min is in Note S1. 

When reporting the _I_ sat of a device, it is necessary to note the carrier density _n_ , at which the _I_ sat is extracted. Ideally, the Hall effect is used to measure the carrier density for the channel material, but for most researchers in the FET community, more accessible approaches are needed that do not require specially designed test structures. In the linear regime, the average carrier density can be estimated as _n_ ≈ _C_ ins ( _V_ OV - _V_ DS/2)/ _q_ , where _C_ ins is the gate insulator capacitance and _q_ is the elementary charge; however, in the saturation regime, the depletion region in the channel complicates the estimation. The carrier density _near the source side_ is the same for both the linear and saturation regimes. For convenience and simplicity, we recommend clearly labelling the carrier density near the source as _n_ S (= _C_ ins _V_ OV/ _q_ ) and using this value for both operation regimes. To determine _V_ OV, _V_ T is usually estimated using extrapolation in the linear portion of the transfer curve, as listed in Table 1. Other methods, such as constant current<sup>19</sup> , Y-function methods<sup>20,21</sup> and four-probe measurements<sup>22</sup> , can be used to crosscheck the linear extraction of _V_ T and reduce the variation when estimating _n_ S. More discussion regarding _V_ T extraction is given in Note S2. 

In addition to _I_ D, _R_ c is also essential to represent device performance. The transfer length method (TLM) is the most commonly used approach for extracting _R_ c, along with the sheet resistance, _R_ sh, of the channel (in units of Ω/square)<sup>23</sup> . The TLM approach requires a series of FETs with different channel lengths and consistent contact and gating configurations. It entails plotting the total resistance of each device versus _L_ ch at a given _n_ S, allowing _Rc_ to be extracted as the extrapolated y-axis intercept from a linear fit to the data points. Typically, the _V_ DS for calculating the total resistance is the “small” _V_ DS used in Fig. 1b to ensure linear regime operation. The channel lengths in the TLM should range from “short” (where the total resistance is dominated by _R_ c) to “long” (dominated by channel resistance, _R_ ch = _R_ tot - 2 _R_ c or _R_ sh _L_ ch) where the actual “short” and “long” channel lengths will depend on the relationship between the channel resistance and the contact resistance. A more detailed discussion on extracting _R_ c and other considerations using TLM data is in Note S3. 

Another frequently reported parameter is the carrier mobility of the channel material. Among various forms of mobility, the field-effect mobility _μ_ FE = _L_ ch _g_ m/( _W_ ch _C_ ins _V_ DS) is often used. However, _μ_ FE can be underestimated<sup>21,24</sup> or overestimated<sup>22,25,26</sup> relative to the drift mobility of the channel material depending on the details of _V_ DS, _V_ GS, _R_ c, _L_ ch, and gate capacitance. In particular, gated contact effects can significantly affect mobility extraction. Although different approaches<sup>21,23</sup> have been proposed to make _μ_ FE less dependent on various factors, such as _R_ c and _L_ ch, none of them is sufficiently general 

4 

enough to be widely adopted. Conductivity mobility ( _μ_ con) has the advantage of strictly reflecting the channel material properties and the quality of the channel-dielectric interface<sup>23,27</sup> . In a FET, _μ_ con23 can be estimated from the sheet resistance of the semiconductor channel and the carrier density _n_ S (see Table 1); thus, it does not involve the contact resistance or the device structure. High mobility is often a goal for research FETs; when such reports are made, it is critical to clearly state how the values are determined, and ideally multiple approaches (such as _μ_ FE and four-probe measurements<sup>22</sup> ) are taken to cross-validate the claims. It is worth noting that the usefulness of channel mobility as an indicator of performance in aggressively scaled FETs is debatable as devices with channel lengths < 30 nm are going to be strongly limited by contact resistance (including carrier injection efficiency) with minimal dependence on transport in the channel<sup>28,29</sup> . 

The most representative FET parameters are listed in Table 1 as a suggested reporting checklist. Additional parameters are briefly discussed in Note S4. 

**Table 1| Checklist of suggested device parameters to report** 

|**Name**|**Characteristics**|**Additional details**|
|---|---|---|
|Structural parameters|Contact length,_L_c<br>Channel length,_L_ch<br>Channel width, _W_ch<br>Insulator thickness,_t_ins<br>Channel thickness,_t_ch|Specify contact and gating geometry/materials;<br>include high-resolution electron microscopy evidence<br>when reporting sub-20 nm dimensions (especially for<br>_L_cand_L_ch)|
|Insulator capacitance,|Capacitance-voltage or|Measured_C_insis more accurate than estimating_ϵ_ins|
|_C_ins|Capacitance-frequency|especially when a high-_k_insulator is used|
|||•_I_D-_V_GSshould have forward and backward sweeps|
|Threshold voltage,_V_T,<br>and hysteresis, Δ_V_T|Extrapolation in the linear<br>portion of the transfer curve<sup>19</sup>|•Consider_V_Tuncertainty due to hysteresis (charge<br>trapping), the dependence of_V_DSand_I_-_V_sweeps<br>(Note S2)|
|Drain current in<br>saturation regime,_I_sat|_I_D-_V_DS(saturation regime)|•Sweep_I_D-_V_DSto saturation regime<br>•Specify carrier density where_I_satis extracted<br>•Normalized by channel width<br>•Linear regime (small_VDS_)<br>•Specify carrier density_n_S or plot_R_cvs._n_S|
|Contact resistance,_R_c<br>Conductivity mobility,<br>_μ_con|TLM<sup>23</sup> (Note S3)<br>1<br>q𝑛!𝑅"#|•TLM should have at least four channels and include<br>at least one each of contact and channel resistance<br>dominated devices<br>•_R_shis extracted from the slope of TLM plots or from<br>four-probe measurements<sup>22</sup>. Unit: Ω/square<br>•Carrier density near the source:_n_S≈_C_ins_V_OV/_q_<br>•Mobility from𝑅"# = (𝑞𝑛!𝜇)<sup>$%</sup><br>•Plot mobility vs_n_Sto show field dependence|



5 

|Transconductance,_g_m|Transfer or output curves<br>_g_m =<br>&'!<br>&("#<br>at certain_V_DS|Specify_g_m(linear) or_g_m(saturation)|
|---|---|---|
|Subthreshold Swing,|Subthreshold curves (inverse|•_SS_depends on_C_insand interface trap capacitance_C_it|
|_SS_|slope in mV/decade below_V_T)|•Plot_SS_vs. log10(_I_D)|
|_I_on_/ I_off|Subthreshold curves at<br>saturation regime,_V_DS=_V_DS<br>(sat)|•Report_I_max/_I_minas an alternative along with_n_Srange<br>•Plot_I_Gvs_V_GSto show leakage current|
|DIBL|Δ_V_T/ Δ_V_DSfrom transfer curves|Key for short-channel devices|



Beyond the parameters in Table 1, showing statistics and variation is strongly encouraged to obtain comprehensive coverage of the device performance. The variation can be shown as error bars, box plots, coefficient of variation, or cumulative distribution function (see Note S5 for demonstration). Due to many nonidealities associated with emerging materials or unconventional device geometries, it is almost unavoidable that there could be considerable uncertainties in many extracted parameters, including _R_ c, _n_ S, and mobilities. These parameters are often interdependent. Reducing device variation is a major research theme for the eventual application of emergent FETs. Whatever measurements and specific analysis approaches are taken to determine these parameters, the details should be clearly and explicitly reported, and our recommended approaches are demonstrated herein. 

Once an emerging FET has been systematically parameterized, benchmarking tables and plots are extremely useful for comparing devices from different reports. Because the electric fields are the driving forces within FETs, benchmarking performance metrics based on electric fields is natural. However, special care is needed in considering electric fields in devices, because they are spatially non-uniform and depend on many other factors, such as fringing fields and quantum capacitance _C_ q. Thus, the electric fields in nanoscale FETs are more complicated than the simple definition of an applied voltage divided by a physically defined length. For example, it is a reasonable assumption that the channel electric field in the channel, _E_ ch increases linearly from source to drain in the linear region of operation, but _E_ ch peaks sharply at the drain end of the channel in classical pinch-off (saturation)<sup>30</sup> . To account for this, the _average E_ ch can be approximated as ( _V_ DS − 2 _I_ lin _R_ c)/ _L_ ch in the linear regime, accounting for voltage dropped at the contacts. 

The vertical electric field at the source end, _E_ gate, can be estimated as _V_ OV/ _t_ ins if a planar gate is used. In turn, _E_ gate and the gate insulator permittivity determine the carrier density in the channel. Yet, both _E_ gate and the gate insulator permittivity are rather challenging to measure accurately. One more word of caution is justified: because many low-dimensional materials exhibit a low density of states, _C_ ins needs to be replaced by _C_ ins _C_ q/( _C_ ins+ _C_ q) where quantum capacitance ( _C_ q) can be approximated as _q_<sup>2</sup> DOS (density of states)<sup>31,32</sup> . Only for _C_ ins ≪ _C_ q this expression becomes equivalent to _C_ ins. Because multiple parameters in Table 1 depend on _n_ S, benchmarking these versus _n_ S is recommended to 

6 

evaluate devices from different studies. A suggested list of benchmarking plots to evaluate device parameters and performance metrics is given in Table 2. 

**Table 2| Suggested benchmarking plots for evaluating device performance compared with other FETs** 

|**Parameter**|**Benchmarking Plot**|**Notes**|
|---|---|---|
|||•Specify_L_chor_L_ch/EOT|
|_I_min and_I_max|_I_min vs_. I_max|•Ideally specify the carrier density at which_I_maxis extracted<br>(Note S1)|
|_I_sat|_I_satvs. _n_S|Label_L_chand_t_chto imply channel resistance|
|_I_D|_I_D_vs. L_ch|At certain_V_DSand_n_S (_e.g._,_V_DS= 1 V and_n_S = 10<sup>13</sup> cm<sup>_-_2</sup>)|
|_R_c|_R_cvs._n_S|•Or benchmark_R_cvs._t_chat certain_n_S<br>•Specify if semiconductor in contact regions is gated or not|
|µcon|µcon vs. _t_ch|For the same material, a thicker channel could have higher<br>mobility due to less surface scattering|
|gm|gmvs._n_S/_L_ch|• Since gm=<br>!<br>"<br>𝜇_C_ins_V_ov,gm∝ _C_ins_V_ov/_L_ch<br>• _n_S ≈ _C_ins_V_OV/_q_near the source end, so_g_m∝ _n_S/_L_ch|
|||•Larger_C_inscan yield smaller_SS_|
|_SS_|_SS vs. C_ins|•Identify Schottky barrier branch and thermal branch<br>•Or plot_SS_vs._L_chto show short-channel robustness<br>•Or plot_SS_vs log10(_I_D)|



Drain current is the key output of a FET and is also frequently benchmarked and compared. However, many comparisons are oversimplified and not fairly conducted as the drain current depends on many parameters. As mentioned in Table 2, we recommend benchmarking _I_ D vs. _L_ ch at certain _V_ DS and _n_ S values, enabling fair comparison between devices having different channel lengths. On the other hand, if a record _I_ sat is claimed, we recommend benchmarking the maximum _I_ sat vs. _n_ S because it is a much closer indicator for the eventual drive current and ultimately sets the operating delay of a circuit stage (delay τ ∝ _CV_ DD/ _I_ sat). As mentioned previously, assuming limited short-channel effects, _I_ sat mainly depends on _n_ S and not on _E_ ch. Usually, one performance metric depends on multiple parameters; hence, key parameters should be annotated on the benchmarking plot (see Table 2). 

### **Reporting and benchmarking example** 

To demonstrate reporting and benchmarking based on the principles proposed above, MoS2 is chosen as the example emerging channel material because it is among the most studied semiconducting nanomaterials in recent years and represents a family of 2D materials that holds promise for future transistor applications. Fig. 2a shows an example transistor based on monolayer (1L) MoS2 grown by chemical vapor deposition (CVD). The device is top-contacted and back-gated, which is the most 

7 

common and convenient FET structure used to explore emergent channel materials. The approach is as follows: 

**Step 1** . The structural parameters of the device are determined and labelled (Fig. 2a). In this example, the gate insulator is AlOx, which is grown by atomic layer deposition (ALD) with the oxide capacitance ( _C_ ins ≈ 280 nF/cm<sup>2</sup> ) evaluated from a capacitance-voltage measurement of a large-area test capacitor. The thickness of the oxide ( _t_ ins ≈ 20 nm) is further confirmed by cross-sectional transmission electron microscope (TEM) imaging. From the thickness and capacitance, the dielectric constant of the oxide is estimated to be _ɛ_ ins ≈ 6. Other dimensions such as _L_ ch, _W_ ch, and _L_ c are confirmed by scanning electron microscopy (SEM) after electrical characterization. 

**Step 2** . _I_ D- _V_ GS and _I_ D- _V_ DS characterization are performed, making sure that _V_ DS and _V_ GS are swept high enough for the device to reach saturation, and the _V_ GS sweep range is sufficient to observe _I_ min in both the linear (low _V_ DS) and saturation (high _V_ DS) operation regions. _I_ max/ _I_ min of ~4×10<sup>7</sup> at _V_ DS = 4 V can be extracted from the subthreshold curve in Fig. 2b. _I_ max is extracted at _n_ S ≈ 1.4×10<sup>13</sup> cm<sup>-2</sup> . _I_ min is extracted under subthreshold conditions, where _V_ GS < _V_ T, yielding a negative _V_ OV and _n_ S ≈ 0. The larger hysteresis for _V_ DS = 4 V in Fig. 2b,c highlights the impact of the larger source-drain field on the interface charges in the channel. Due to hot-carrier stress from the high _V_ DS (explained later), _V_ T increases for high _V_ DS, resulting in an extracted DIBL of -274 to -436 mV/V considering the effect of hysteresis. Also, from the transfer curves in Fig. 2c, the maximum _g_ m(sat) and _g_ m(lin) are estimated to be ~ 59 µS/µm and ~1.7 µS/µm, respectively. In Fig. 2d, approximate current saturation is observed with _I_ sat around 325 µA/µm obtained at _n_ S ≈ 1.3×10<sup>13</sup> cm<sup>-2</sup> at _V_ DS = 4 V. The blue and red shows linear and saturation regions, approximately. The _I_ D- _V_ DS spacing is sub-linear at the highest _V_ GS, which is a sign of possible self-heating. 

8 



<!-- Start of picture text -->
a 280 nm 120 nm b I max c 35 0 d 35 0 I sat at  n S ≈ 1.3 x 10 13  cm -2<br>2 V DS (V)<br>10 30 0 30 0<br>4.0<br>AlOx 0 25 0 1.0 25 0<br>P++ Si 10 V DS (V) 20 0 0.1 20 0<br>-2 4.0<br>W ch 10 0.1 15 0 15 0<br>1.4 µm<br>10-4 10 0 10 0<br>t ins  I min I G 5 0 5 0<br>20 nm 10-6 0 0<br>0 4 8 12 0 4 8 12 0 1 2 3 4<br>V GS (V) V GS (V) V DS (V)<br>e 70 0 f 6 0 g 1 0 h 7 0 7 0<br> Backward V DS = 0.1 V V DS = 0.1 V<br>60 0  Forward 5 0 6 0 6 0<br>8<br>50 0 5 0 5 0<br>4 0<br>40 0 2 V 6 4 0 4 0<br>3 0<br>30 0 4 3 0 3 0<br>2 0<br>20 0 2 0 2 0<br>10 0 1 0 2 1 0 1 0<br>V DS = 4 V<br>0 0 0 0 0<br>-5 -3 -1 0 400 800 1200 0 0.4 0.8 1.2 1.6 0.0 0.4 0.8 1.2 1.6<br>10 10 10<br>I D (µA/µm) L ch (nm) n S (1013cm-2) n S (1013cm-2)<br>Au<br>VOV  = 9 V<br>I  (µA/µm)D I  (µA/µm)D I  (µA/µm)D<br>= 3.5      12.5 V V GS<br>con µ  (cm<br>V2<br>SS  (mV/dec) R  (kΩ•µm)tot R  (kΩ•µm)c R  (kΩ/square)sh )s -1-1<br><!-- End of picture text -->

**Fig. 2| Example of reporting device performance for monolayer Au-contacted MoS2 FETs** . **a,** Device schematic and the basic structural parameters of the MoS2 FET. An SEM image of a TLM structure with false-colored MoS2 area (scale bar, 1 µm) and a cross-section TEM image of the AlOx (scale bar, 10 nm). **b** , Subthreshold ( _I_ D- _V_ GS) curve of the device with _I_ max and _I_ min labelled. The _I_ G is the gate leakage current at _V_ DS = 4 V. The curve for _V_ DS = 1 V is intentionally not shown so the plot is less crowded. **c** , Transfer ( _I_ D- _V_ GS) curves of the device showing larger hysteresis with larger _V_ DS. **d** , Output ( _I_ D- _V_ DS) curves of the device. _V_ GS changes in steps of 1 V. **e** , _SS_ vs. _I_ D for both forwards and backwards _V_ GS sweeps in ( **b** ). **f** , Extraction of _R_ c from the TLM structure in ( **a** ). The _R_ tot is extracted at _V_ DS = 100 mV. **g** , Contact resistance vs. _n_ S showing the contact gating effect that is a result of the device operating as a Schottky barrier transistor with the gate modulating the semiconductor in the source/drain contact regions<sup>33</sup> . **h,** Extracted sheet resistance (left axis) and conductivity mobility (right axis) versus _n_ S. In **g** and **h** , error bars reflect 90% confidence interval from a least-squares fit of the TLM. 

Figures 2a-d are used for primary characterization of one device, and more derived plots are shown in Fig. 2e-h, providing a more complete picture of the device characteristics. The device spread and parameter variations based on ten similar TLM structures are shown in Fig. S5. The full range of _SS_ vs. _I_ D is plotted in Fig. 2d, with a minimum _SS_ of 280 mV/dec extracted in the subthreshold regime. Additionally, because _V_ T depends on _V_ DS, it is key to extract _V_ T at the associated _V_ DS (as noted in Table 1). _R_ c, Rsh, and subsequently _μ_ !"# are extracted by using a TLM structure as shown in Fig. 2f-h. The _R_ c is estimated to be around 2.1 kΩ⋅µm, which is comparable to the _R_ ch of 2.8 kΩ⋅µm for the device with channel length of 280 nm. The relation between _n_ S and extracted _R_ c is plotted in Fig. 2g to show the effect of the overall back gate on the contact resistance (i.e., contact gating<sup>33–35</sup> ). Fig. 2h shows 

9 

_μ_ !"# decreases from 59 to 40 cm<sup>2</sup> V<sup>-1</sup> s<sup>-1</sup> with increasing _n_ S, likely due to the increased electron scattering with the oxide surface roughness. 

**_Step 3_** : As a simplified example, we benchmark key device performance parameters in Fig. 3 with a limited number of reports included. Currently, most papers do not report _I_ D- _V_ GS at _V_ DS (sat) or close to _V_ DD as recommended above. Hence, plotting _I_ min vs _. I_ max at certain _V_ DS ( _e.g._ , _V_ DS = 1 V) while annotating _L_ ch is an acceptable approach (Fig. 3a). The upper limit of the carrier density is set at _n_ S = 10<sup>13</sup> cm<sup>-2</sup> , ensuring a fair comparison of _I_ max. The _I_ max/ _I_ min ratio annotated on the right axis is also shown in the dashed lines in Fig. 3a. Due to a better electrostatic control from the gate, devices with a larger _L_ ch/EOT ratio tend to yield a higher _I_ max/ _I_ min (where EOT is the equivalent oxide thickness). Other parameters also play a role such as the leakage currents through the gate insulator or from source to drain. Large channel width can also produce a more accurate width-normalized _I_ min, especially when _I_ min is below the instrument noise floor. For example, Illarionov _et al._<sup>36</sup> demonstrated a relatively high _I_ max/ _I_ min ratio in devices with a 20 µm channel width. Further study is still needed to investigate how to achieve high _I_ max and small _I_ min in aggressively scaled devices (small _L_ ch, _L_ c, and EOT). 

As mentioned previously, a high drain current in the saturation regime is a key performance metric. In Fig. 3b, _I_ sat is plotted versus _n_ S from representative studies of FETs based on MoS2 as the channel material. We note that the _I_ sat is extracted at different _V_ DS because different devices have different channel lengths, as annotated in Fig. 3b. We caution against plotting _I_ sat/ _L_ ch vs. _n_ S because it implies that _L_ ch is the main limiting factor for _I_ sat, which is not necessarily true, especially for scaled devices where contact resistance typically dominates _I_ sat performance. Importantly, it is clear that _I_ sat needs to be further improved to meet the high-performance target of the most recent technology guidelines (at _V_ DD ≈ 0.65 V near 2030)<sup>37</sup> . Many reports already used high _n_ S but fell short on _I_ sat even with channel lengths down to ~10 nm<sup>38</sup> , being strongly limited by their contacts. 

Recently, semimetal contacts such as bismuth have been shown to produce high-quality contacts<sup>39</sup> . It is nevertheless noteworthy that the two Bi-1L MoS2 devices have a wide range of _I_ sat performance, encompassing all the other devices in Fig. 3b, yet the channel length difference between the two devices is only 115 nm. Interestingly, one of the Bi-contacted devices ( _L_ ch = 150 nm) actually underperforms other Au-contacted devices with longer channel lengths. Hence, although some approaches show potential to achieve the International Roadmap for Devices and Systems (IRDS) high-performance goal of _I_ sat for the post-2030 era<sup>37</sup> , further investigation is still needed to reliably and reproducibly realize high _I_ sat from a monolayer channel. In next-generation FETs, _I_ sat could also be 

10 

increased by shifting to nanosheet device designs, which stack multiple channels vertically to improve current density in the same device footprint<sup>40</sup> . 



<!-- Start of picture text -->
a I max/ I min b<br>10-3 Metal ( L ch (nm)) 1 0 6 120 0 Metal ( L ch (nm))<br>Bi (3 5)<br>V DS = 1 V Bi (35)<br>10-4 I max at  n S = 10 13  cm -2 Sb (50) 1 0 7 100 0<br>Bi (50 ) IRDS HP<br>10-5 Au(280) 1 0 8 80 0<br>Sn (3 5)<br>Sn (35)<br>10-6 Au(500)41 Bi (150) 1 0 9 60 0<br>10-7 40 0 Au (20)<br>36<br>10-8 Au(8000) 20 0<br>Best corner<br>-9<br>10 2 4 6 8 2 4 6 8 2 4 6 8 0<br>1 10 100 1000 0.5 1 1.5 2 2.5 3 3.5<br>I max (µA/µm) n S (1013cm-2)<br>c 80 0 d 5<br>Bi V DS = 1 V 2 R c dominated<br>n S = 10 13  cm -2<br>4 R ch dominate d<br>60 0<br>Sb In<br>3<br>Sn<br>40 0<br>AlOx –doped/Au 2 Au<br>20 0 Au38 Ag Sb Sn Ag<br>27 1 Sn/Au<br>Au Au In/Au<br>41<br>0 2 3 4 5 6 7 2 3 Au 4 5 6 7 0 0 Bi 0.5 1 1.5 2<br>10 100 1000<br>L ch (nm) n S (1013cm-2)<br>AlOx doped/Au<br>Bi (150)<br>AlOx doped/Au (380)<br>Ag (72)<br>Au (280)<br>I  (µA/µm)min I  (µA/µm)sat<br> (µA/µm) I D R  (kΩ•µm)c<br><!-- End of picture text -->

**Fig. 3 | Example Benchmarking device performance of monolayer MoS2 FETs** . **a** , Benchmarking _I_ min vs. _I_ max. The _I_ max is extracted at _n_ S = 10<sup>13</sup> cm<sup>-2</sup> . For simplicity, the _I_ min of the data points are extracted at their respective smallest current. More rigorous benchmarking of _I_ min vs _I_ max is in Note S1. **b** , Benchmarking _I_ sat versus _n_ S, where the channel length in nm is labelled next to the contact metals used in the devices. _I_ sat are extracted at different _V_ DS (listed in Table 3). These devices do not have the same _V_ DS(sat) as devices with different channel lengths and saturate at different _V_ DS. The IRDS HP is shown in a range of _n_ S to represent uncertainties of the carrier density in future generation technologies. **c** , Benchmarking _I_ D versus _L_ ch at _V_ DS = 1 V and _n_ S = 10<sup>13</sup> cm<sup>-2</sup> . Ref.<sup>41</sup> uses top-gate, while other reports use back-gate. **d** , Benchmarking _R_ c versus _n_ S in a few representative reports. The shaded regions represent uncertainties reported in the respective studies (Ag<sup>14</sup> uses 95% confidence interval, while In/Au<sup>42</sup> , Sn/Au<sup>42</sup> , and Au use standard error from the linear regression of TLM). The _R_ c vs. _n_ S of Sb<sup>43</sup> is obtained from Y-function method. The filled and open symbol show that the shortest channel device in the TLM structure is 2 _R_ c and _R_ ch dominated, respectively. If _R_ ch dominates or the _R_ c is over an order of magnitude smaller than the _R_ tot for the smallest device in TLM, the extracted _R_ c is of questionable validity; i.e., solid symbol data is more reliable per Note S3. Different colors are assigned to different reported devices. The purple Au data denote devices in Fig. 2. Most of the data are extracted from published reports: Ag<sup>14</sup> , AlOx doped/Au<sup>15</sup> , In/Au<sup>42</sup> , Sn/Au<sup>42</sup> , Sb<sup>43</sup> , In<sup>44</sup> and Sn<sup>45</sup> . In **a** and **c** , reference numbers are added for Au-contacted devices to better differentiate their performance. A few studies are plotted as dotted lines to highlight the trends and to improve the clarity of the plots. 

11 

In some reports, a proper saturation current is not given. Also, since different devices use different channel lengths, _I_ sat is often extracted at different _V_ DS. To highlight the impact of channel length, we recommend benchmarking _I_ D vs. _L_ ch at _V_ DS = 1 V and _n_ S = 10<sup>13</sup> cm<sup>_-_2</sup> . This plot enables a direct comparison of devices with similar _L_ ch. In Fig. 3c, with channel length decreasing from 200 nm to 38 nm, both Bi<sup>39</sup> and Sn<sup>45</sup> contacted devices yield relatively large increases in drain current. We note that the Bi-contacted devices are based on different MoS2 films. The different quality of the MoS2 may partially contribute to the large increase of _I_ D with a relatively small change in _L_ ch. Nevertheless, Figures 3c,d present the potential of atomic thin materials for producing high drain current, especially for scaled devices. 

In Fig. 3d, _R_ c is plotted against _n_ S considering most devices have gated contacts (i.e., the backgate modulates the channel and contacts<sup>33–35</sup> ). While some reported _R_ c values reach below 500 Ω⋅µm, their TLM extractions are all based on channel resistance-dominated devices, which can lead to questionable validity in their claimed _R_ c (an artificially small or even a negative _R_ c can be extracted, see Note S3 for details). We advocate that if a record _R_ c is claimed from TLM, _R_ sh should be crossexamined by using other methods such as four-probe measurements, which can provide a relatively accurate estimation of _R_ sh vs. _n_ S (Note S3). With _R_ sh vs. _n_ S from four-probe measurements, _R_ c vs. _n_ S can be derived by deducting the _R_ ch = _R_ sh _L_ ch from _R_ tot to confirm the TLM extracted value. Showing extraction of _R_ c from many TLM structures can also increase confidence in the data by providing an average value of the _R_ c rather than just the minimal value from a single TLM<sup>46,47</sup> . Furthermore, _R_ c is heavily impacted by contact gating, as evident from the similar trends of _Rc_ vs. _n_ S observed in different studies; therefore, further research is needed to obtain a small _R_ c without gating the contacts. 

Looking forward, many opportunities remain to develop transistors that simultaneously have small contact resistance, high _I_ sat, large _I_ max/ _I_ min ratio, and minimal short-channel effects by using emergent nanomaterials. To achieve this technological goal, interface engineering at the contacts and gate dielectric needs to be further investigated<sup>48–50</sup> , along with progress in material synthesis<sup>51</sup> and integration<sup>52</sup> . Moreover, it is important to focus on channel thicknesses below ~3 nm, where lowdimensional nanomaterials can excel compared to Si, which suffers from poor carrier transport properties and a widened band gap in this thickness regime<sup>53</sup> . 

In addition to the example benchmarking plots in Fig. 3, other benchmarks can also be used to compare different devices. For example, as included in Table 2, plotting _I_ max/ _I_ min vs. _t_ ch or _I_ max/ _I_ min vs. _L_ ch/EOT to compare the off-state device performance. Plotting _SS_ vs. _C_ ins or _SS_ vs. log10( _I_ D)<sup>54</sup> can be used to evaluate subthreshold behaviour and trends across different devices. Finally, to show the 

12 

quality of the channel materials, the channel sheet resistance or conductivity mobility can be plotted vs. carrier densities, as in Fig. 2h. Representative reports with relatively large _I_ sat are listed in Table S1, including results for FETs with both monolayer and multilayer MoS2 channels (example benchmarking plots in Note S6). In the literature, notable benchmarking examples can be found in Refs.<sup>39,55</sup> that highlight different channel materials, and in Ref.<sup>56</sup> that focuses on device performance in integrated circuits (speed, gain, density, power consumption, and fan-out capabilities, etc.). 

### **Conclusions** 

Our guidelines should help put key performance metrics in a proper context and enable researchers to effectively report and benchmark emergent transistors based on various emergent nanomaterials. While each of the listed metrics is significant, it is not necessary — nor always possible — to extract and present all of them. As such, it is essential to completely describe the device geometry, to collect and report appropriate current-voltage characteristics, and to describe in detail the procedures followed in the experiments. The approaches used to analyze data and extract benchmarking metrics should also be described in detail. Depending on the context and need, we recommend three sets of parameters to report and benchmark. The first includes maximum saturation current, on/off-current ratio, transconductance, and subthreshold swing. These values can be directly obtained from the measured _I_ - _V_ characteristics that cover both linear and saturation regimes. These values are mainly determined by the intrinsic material properties, gate stack configuration, and contact quality. The second includes the derived parameters such as mobilities and contact resistance, where uncertainty and statistical spread on these derived parameters should be shown. The third set of parameters are those specific to certain transistor demonstrations based on the target application<sup>57,58</sup> . For example, DIBL is essential when reporting and evaluating ultra-scaled FETs. It is important <mark>— whenever possible —</mark> to benchmark against other novel materials and also state-of-the-art in mature technology<sup>39,55</sup> . By using these guidelines, it should be possible to comprehensively and consistently reveal, highlight, discuss, compare, and evaluate device performance, thus helping to identify advances and opportunities in the search for improved transistors. 

#### **References** 

1. Chen, Z. _et al._ An integrated logic circuit assembled on a single carbon nanotube. _Science_ **311** , 1735 (2006). 

2. Franklin, A. D. _et al._ Sub-10 nm carbon nanotube transistor. _Nano Lett._ **12** , 758–762 (2012). 

3. Geim, A. K. Graphene: Status and prospects. _Science_ **324** , 1530–1534 (2009). 

> 4. Ye, P. D. _et al._ Phosphorene An Unexplored 2D Semiconductor with a High Hole Mobility. _ACS Nano_ **8** , 4033–4041 (2014). 

5. Tao, L. _et al._ Silicene field-effect transistors operating at room temperature. _Nat. Nanotechnol._ **10** , 

13 

- 227–231 (2015). 

- 6. Wang, Y. _et al._ Field-effect transistors made from solution-grown two-dimensional tellurene. _Nat. Electron._ **1** , 228–236 (2018). 

7. Radisavljevic, B., Radenovic, A., Brivio, J., Giacometti, V. & Kis, A. Single-layer MoS2 transistors. _Nat. Nanotechnol._ **6** , 147–150 (2011). 

8. Das, S., Chen, H. Y., Penumatcha, A. V. & Appenzeller, J. High performance multilayer MoS2 transistors with scandium contacts. _Nano Lett._ **13** , 100–105 (2013). 

9. English, C. D., Shine, G., Dorgan, V. E., Saraswat, K. C. & Pop, E. Improved Contacts to MoS2 Transistors by Ultra-High Vacuum Metal Deposition. _Nano Lett._ **16** , 3824–3830 (2016). 

10. Sirringhaus, H. 25th Anniversary Article: Organic Field-Effect Transistors: The Path Beyond Amorphous Silicon. _Adv. Mater._ **26** , 1319–1335 (2014). 

11. Waldrip, M., Jurchescu, O. D., Gundlach, D. J. & Bittle, E. G. Contact Resistance in Organic Field-Effect Transistors: Conquering the Barrier. _Adv. Funct. Mater._ **30** , 1904576 (2020). 

12. Li, S. _et al._ Nanometre-thin indium tin oxide for advanced high-performance electronics. _Nat. Mater._ **18** , 1091–1097 (2019). 

13. Li, M. Y., Su, S. K., Wong, H. S. P. & Li, L. J. How 2D semiconductors could extend Moore’s law. _Nature_ **567** , 169–170 (2019). 

14. Smithe, K. K. H., English, C. D., Suryavanshi, S. V. & Pop, E. High-Field Transport and Velocity Saturation in Synthetic Monolayer MoS2. _Nano Lett._ **18** , 4516–4522 (2018). 

15. McClellan, C. J., Yalon, E., Smithe, K. K. H., Suryavanshi, S. V. & Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **15** , 1587–1596 (2021). 

16. Datye, I. M. _et al._ Reduction of hysteresis in MoS2 transistors using pulsed voltage measurements. _2D Mater._ **6** , 011004 (2019). 

17. Streetman, B. G. & Banerjee, S. K. _Solid State Electronic Devices, 6th Edition_ . (Pearson, 2006). 18. Pinckney, N. _et al._ Impact of FinFET on near-threshold voltage scalability. _IEEE Des. Test_ **34** , 31– 38 (2017). 

19. Ortiz-Conde, A. _et al._ A review of recent MOSFET threshold voltage extraction methods. _Microelectron. Reliab._ **42** , 583–596 (2002). 

20. Ghibaudo, G. New method for the extraction of MOSFET parameters. _Electron. Lett._ **24** , 543–545 (1988). 

21. Chang, H. Y., Zhu, W. & Akinwande, D. On the mobility and contact resistance evaluation for transistors based on MoS2 or two-dimensional semiconducting atomic crystals. _Appl. Phys. Lett._ **104** , 113504 (2014). 

22. Pang, C. _et al._ Mobility Extraction in 2D Transition Metal Dichalcogenide Devices—Avoiding Contact Resistance Implicated Overestimation. _Small_ **17** , 2100940 (2021). 

23. Schroder, D. K. _Semiconductor Material and Device Characterization, 3rd Edition_ . (Wiley-IEEE Press, 2015). 

24. Mleczko, M. J. _et al._ HfSe2 and ZrSe2: Two-dimensional semiconductors with native high-k oxides. _Sci. Adv._ **3** , e1700481 (2017). 

25. Nasr, J. R., Schulman, D. S., Sebastian, A., Horn, M. W. & Das, S. Mobility Deception in Nanoscale Transistors: An Untold Contact Story. _Adv. Mater._ **31** , 1806020 (2019). 

26. Bittle, E. G., Basham, J. I., Jackson, T. N., Jurchescu, O. D. & Gundlach, D. J. Mobility overestimation due to gated contacts in organic field-effect transistors. _Nat. Commun._ **7** , 10908 (2016). 

27. Smithe, K. K. H., English, C. D., Suryavanshi, S. V. & Pop, E. Intrinsic electrical transport and performance projections of synthetic monolayer MoS2 devices. _2D Mater._ **4** , 011009 (2017). 

28. Franklin, A. D. Nanomaterials in transistors: From high-performance to thin-film applications. _Science_ **349** , (2015). 

29. Das, S. _et al._ Transistors based on two-dimensional materials for future integrated circuits. _Nat. Electron. 2021 411_ **4** , 786–799 (2021). 

30. Pao, H. C. & Sah, C. T. Effects of diffusion current on characteristics of metal-oxide (insulator)- 

14 

semiconductor transistors. _Solid State Electron._ **9** , 927–937 (1966). 

31. John, D. L., Castro, L. C. & Pulfrey, D. L. Quantum capacitance in nanoscale device modeling. _J. Appl. Phys._ **96** , 5180 (2004). 

32. Xu, H., Zhang, Z. & Peng, L.-M. Measurements and microscopic model of quantum capacitance in graphene. _Appl. Phys. Lett._ **98** , 133122 (2011). 

33. Appenzeller, J., Zhang, F., Das, S. & Knoch, J. Transition metal dichalcogenide schottky barrier transistors: A device analysis and material comparison. in _2D Materials for Nanoelectronics_ (eds. Houssa, M., Dimoulas, T. & Molle, A.) 207–240 (CRC Press, 2016). 

34. Arutchelvan, G. _et al._ From the metal to the channel: A study of carrier injection through the metal/2D MoS2 interface. _Nanoscale_ **9** , 10869–10879 (2017). 

35. Prakash, A., Ilatikhameneh, H., Wu, P. & Appenzeller, J. Understanding contact gating in Schottky barrier transistors from 2D channels. _Sci. Rep._ **7** , 12596 (2017). 

36. Illarionov, Y. Y. _et al._ Improved Hysteresis and Reliability of MoS2 Transistors with High-Quality CVD Growth and Al2O3 Encapsulation. _IEEE Electron Device Lett._ **38** , 1763–1766 (2017). 

37. IEEE International Roadmap for Devices and Systems. https://irds.ieee.org/ (2020). 

38. Patel, K. A., Grady, R. W., Smithe, K. K. H., Pop, E. & Sordan, R. Ultra-scaled MoS2 transistors and circuits fabricated without nanolithography. _2D Mater._ **7** , 015018 (2020). 

39. Shen, P.-C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). 

40. Ahmed, Z. _et al._ Introducing 2D-FETs in device scaling roadmap using DTCO. in _International Electron Devices Meeting, IEDM_ 22.5.1-22.5.4 (2020). doi:10.1109/IEDM13553.2020.9371906. 

41. Lembke, D. & Kis, A. Breakdown of High-Performance Monolayer MoS2 Transistors. _ACS Nano_ **6** , 10070–10075 (2012). 

42. Kumar, A. _et al._ Sub-200 Ω·µm Alloyed Contacts to Synthetic Monolayer MoS2. in _IEEE International Electron Devices Meeting (IEDM)_ 154–157 (2021). 

43. Chou, A. _et al._ Antimony Semimetal Contact with Enhanced Thermal Stability for High Performance 2D Electronics. in _IEEE International Electron Devices Meeting (IEDM)_ 150–153 (2021). 

44. Wang, Y. _et al._ Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. _Nature_ **568** , 70–74 (2019). 

45. Chou, A. S. _et al._ High On-State Current in Chemical Vapor Deposited Monolayer MoS2 nFETs with Sn Ohmic Contacts. _IEEE Electron Device Lett._ **42** , 272–275 (2021). 

46. Sebastian, A., Pendurthi, R., Choudhury, T. H., Redwing, J. M. & Das, S. Benchmarking monolayer MoS2 and WS2 field-effect transistors. _Nat. Commun._ **12** , 693 (2021). 

47. Kumar, A., Tang, A., Philip Wong, H. S. & Saraswat, K. Improved Contacts to Synthetic Monolayer MoS2 – A Statistical Study. in _IEEE International Interconnect Technology Conference_ (IEEE, 2021). doi:10.1109/IITC51362.2021.9537515. 

48. Cheng, Z., Price, K. & Franklin, A. D. Contacting and Gating 2-D Nanomaterials. _IEEE Trans. Electron Devices_ **65** , 4073–4083 (2018). 

49. Illarionov, Y. Y. _et al._ Insulators for 2D nanoelectronics: the gap to bridge. _Nat. Commun. 2020 111_ **11** , 1–15 (2020). 

50. Cheng, Z. _et al._ Are 2D Interfaces Really Flat? _ACS Nano_ **16** , 5316–5324 (2022). 51. Zhou, J. _et al._ A library of atomically thin metal chalcogenides. _Nat. 2018_ **556** , 355–359 (2018). 52. Liu, Y. _et al._ Van der Waals heterostructures and devices. _Nat. Rev. Mater._ **1** , 16042 (2016). 53. Uchida, K., Koga, J. & Takagi, S. Experimental study on electron mobility in ultrathin-body silicon-on-insulator metal-oxide-semiconductor field-effect transistors. _J. Appl. Phys._ **102** , 074510 (2007). 

54. Haratipour, N., Namgung, S., Oh, S. H. & Koester, S. J. Fundamental Limits on the Subthreshold Slope in Schottky Source/Drain Black Phosphorus Field-Effect Transistors. _ACS Nano_ **10** , 3791– 3800 (2016). 

55. Liu, Y. _et al._ Promises and prospects of two-dimensional transistors. _Nature_ **591** , 43–53 (2021). 

15 

56. Nikonov, D. E. & Young, I. A. Benchmarking of Beyond-CMOS Exploratory Devices for Logic Integrated Circuits. _IEEE J. Explor. Solid-State Comput. Devices Circuits_ **1** , 3–11 (2015). 

57. Abuzaid, H., Williams, N. X. & Franklin, A. D. How good are 2D transistors? An applicationspecific benchmarking study. _Appl. Phys. Lett._ **118** , 030501 (2021). 

58. Lemme, M. C., Akinwande, D., Huyghebaert, C. & Stampfer, C. 2D materials for future heterogeneous electronics. _Nat. Commun. 2022 131_ **13** , 1–5 (2022). 

1Nanoscale Device Characterization Division, National Institute of Standards and Technology, Gaithersburg, MD 20899, USA.<sup>2</sup> Department of Electrical and Computer Engineering, Purdue University, West Lafayette, IN 47907, USA.<sup>3</sup> Department of Chemistry and Biochemistry, University of California, Los Angeles, Los Angeles, CA 90095, USA.<sup>4</sup> Theiss Research, La Jolla, CA 92037, USA.<sup>5</sup> School of Integrated Circuits, Peking University, Beijing 100871, China.<sup>6</sup> Electrical and Computer Engineering, New York University, Brooklyn, NY 11201, USA.<sup>7</sup> Center for Quantum Phenomena, Physics Department, New York University, New York, NY 10003, USA.<sup>8</sup> IMEC, Leuven, Belgium.<sup>9</sup> RWTH Aachen University, Chair of Electronic Devices, Otto-Blumenthal-Str. 2, Aachen 52074, Germany. 10AMO GmbH, Advanced Microelectronic Center Aachen, Otto-Blumenthal-Str. 25, Aachen, 52074 Germany.<sup>11</sup> Key Laboratory for the Physics and Chemistry of Nanodevices and Center for Carbon-based Electronics, Department of Electronics, Peking University, Beijing, China.<sup>12</sup> Department of Electrical and Computer Engineering, University of Minnesota, Minneapolis, MN 55455 USA.<sup>13</sup> Department of Electrical Engineering, Stanford University, Stanford, CA 94305, USA.<sup>14</sup> Department of Electrical and Computer Engineering, Duke University, Durham, NC 27708, USA.<sup>15</sup> Department of Chemistry, Duke University, Durham, NC 27708, USA. ☨: corresponding authors. 

16 

### **Acknowledgements** 

We acknowledge Dr. Huairuo Zhang and Dr. Albert Davydov from the National Institute of Standards and Technology for their help on the TEM images of the oxide in Fig. 2. We acknowledge Dr. Guoqing Li and Prof. Linyou Cao from North Carolina State University for providing the CVD MoS2 film. This work is supported by NEWLIMITS, a center in nCORE, a Semiconductor Research Corporation (SRC) program sponsored by NIST through award number 70NANB17H041. A.D.F acknowledges the support from the National Science Foundation under Grant ECCS 1915814. M.C.L. acknowledges funding from the European Union's Horizon 2020 research and innovation program under grant agreements 881603 (Graphene Flagship), 952792 (2D-EPL) and 829035 (QUEFORMAL), as well as the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) through the grants LE 2440/7-1 and LE 2440/8-1. Furthermore, support by the Bundesministerium für Bildung und Forschung (BMBF, German Ministry of Education and Research) through the grants 03XP0210 (GIMMIK) and 03ZU1106 (NeuroSys) is acknowledged. L.-M.P. acknowledges the National Science Foundation of China under the grant 61888102. S.J.K. acknowledges support from the NSF through award no. DMR-1921629. Fabrication and measurements were partially performed at the NIST Center for Nanoscale Science and Technology and at Duke Shared Manufacturing and Instrument Facility (SMIF). 

### **Author contributions** 

All authors contributed to the preparation of the manuscript. 

### **Notes** 

The authors declare no competing financial interest. 

Certain commercial equipment, instruments, or materials are identified in this paper to specify the experimental procedure adequately. Such identifications are not intended to imply recommendation or endorsement by the National Institute of Standards and Technology (NIST), nor it is intended to imply that the materials or equipment identified are necessarily the best available for the purpose. 

### **Corresponding authors** 

Zhihui Cheng, zhihui.cheng@alumni.duke.edu Aaron D. Franklin, aaron.franklin@duke.edu Curt A. Richter, curt.richter@nist.gov 

### **Data availability** 

The data used in the paper are available from the corresponding authors upon reasonable request. 

17 

# Supplementary Information for 

## **How to Report and Benchmark Emerging Field-Effect Transistors** 

Zhihui Cheng<sup>1,2,☨</sup> , Chin-Sheng Pang<sup>2</sup> , Peiqi Wang<sup>3</sup> , Son T. Le<sup>1,4</sup> , Yanqing Wu<sup>5</sup> , Davood Shahrjerdi<sup>6,7</sup> , Iuliana Radu<sup>8</sup> , Max C. Lemme<sup>9,10</sup> , Lian-Mao Peng<sup>11</sup> , Xiangfeng Duan<sup>3</sup> , Zhihong Chen<sup>2</sup> , Joerg Appenzeller<sup>2</sup> , Steven J. Koester<sup>12</sup> , Eric Pop<sup>13</sup> , Aaron D. Franklin<sup>14,15,☨</sup> , Curt A. Richter<sup>1,☨</sup> 

1Nanoscale Device Characterization Division, National Institute of Standards and Technology, Gaithersburg, MD 20899, USA.<sup>2</sup> Department of Electrical and Computer Engineering, Purdue University, West Lafayette, IN 47907, USA.<sup>3</sup> Department of Chemistry and Biochemistry, University of California, Los Angeles, Los Angeles, CA 90095, USA.<sup>4</sup> Theiss Research, La Jolla, CA 92037, USA.<sup>5</sup> School of Integrated Circuits, Peking University, Beijing 100871, China.<sup>6</sup> Electrical and Computer Engineering, New York University, Brooklyn, NY 11201, USA.<sup>7</sup> Center for Quantum Phenomena, Physics Department, New York University, New York, NY 10003, USA.<sup>8</sup> IMEC, Leuven, Belgium.<sup>9</sup> RWTH Aachen University, Chair of Electronic Devices, Otto-Blumenthal-Str. 2, Aachen 52074, Germany. 10AMO GmbH, Advanced Microelectronic Center Aachen, Otto-Blumenthal-Str. 25, Aachen, 52074 Germany.<sup>11</sup> Key Laboratory for the Physics and Chemistry of Nanodevices and Center for Carbon-based Electronics, Department of Electronics, Peking University, Beijing, China.<sup>12</sup> Department of Electrical and Computer Engineering, University of Minnesota, Minneapolis, MN 55455 USA.<sup>13</sup> Department of Electrical Engineering, Stanford University, Stanford, CA 94305, USA.<sup>14</sup> Department of Electrical and Computer Engineering, Duke University, Durham, NC 27708, USA.<sup>15</sup> Department of Chemistry, Duke University, Durham, NC 27708, USA. ☨: corresponding authors. 

Note S1: Rigorously reporting and benchmarking _I_ max/ _I_ min 

Note S2: Different methods to extract threshold voltage _V_ T and its uncertainties 

Note S3: Extracting _R_ c from TLM 

Note S4: Additional Parameters 

Note S5: Demonstration of device spread and parameter variations 

Note S6: Benchmarking devices with different channel thicknesses 

18 

**Note S1: Rigorously reporting and benchmarking** **_I_ max/** **_I_ min** 

The _I_ max/ _I_ min ratio is the most-used figure of merit for evaluating off-state performance of a transistor and it depends on multiple factors. First, _I_ max/ _I_ min is impacted by material properties such as material quality, bandgaps, and doping conditions. Secondly, the specific device structure and geometry, including the channel length and gate capacitance, also affect the achievable _I_ max/ _I_ min. Thirdly, the same device operating at different operation regimes might also have different _I_ max/ _I_ min. Combined with the absence of a welldefined _V_ DD, these factors make rigorous reporting and benchmarking guidelines strongly desired for _I_ max/ _I_ min. Rigorously reporting _I_ max/ _I_ min involves clearly identifying the _V_ DS and _V_ GS values at which the _I_ max and _I_ min are extracted. This practice will help fairly benchmark _I_ max/ _I_ min between different devices. 

Similar to Fig. 3a, Fig. S1a represents benchmarking _I_ max/ _I_ min at _V_ DS = 1 V, which is a commonly used bias condition when obtaining subthreshold curves. Under _V_ DS = 1 V, short-channel devices (e.g., Device A) may operate at the saturation regime, whereas long-channel devices (e.g., Device B) at the linear regime. While using the same _V_ DS = 1 V is a convenient and simple method, the _I_ max/ _I_ min likely represent different operation regimes for the two example devices. For a more precise comparison, instead of extracting the _I_ max and _I_ min at the same _V_ DS value for the different devices, it is possible to ensure they are extracted in the same regime (linear or saturation) by using the drain-source electric field instead of _V_ DS; e.g., _E_ DS = 0.1 V/µm for the linear regime. This improved comparison is demonstrated in Fig. S1b, where the carrier density at which the _I_ max is extracted is also labeled. 



<!-- Start of picture text -->
a Device name ( L ch (nm)) I max/ I min b Device name ( L ch  (nm)) I max/ I min<br>10-3 1 0 6 10 -3 10 6<br>V DS = 1 V Lin ear regime ( E DS = 0.1 V / µm)<br>10-4 Im ax  at n S ≅ 10 13  cm -2 A (30 n m) 1 0 7 10 -4 Im ax  at n S ≅ 10 13  cm -2 10 7<br>10-5 1 0 8 10 -5 10 8<br>A (30 nm)<br>10-6 1 0 9 10 -6 10 9<br>-7 -7<br>10 10<br>B (8000 nm)<br>-8 B (8000 nm) -8<br>10 10<br>Best corne r Best corner<br>-9 -9<br>10 2 4 6 8 2 4 6 8 2 4 6 8 10 2 4 6 8 2 4 6 8 2 4 6 8<br>1 10 100 1000 1 10 100 1000<br>I max (µA/µm) I max (µA/µm)<br>I  (µA/µm)min I  (µA/µm)min<br><!-- End of picture text -->

**Fig. S1 |** Rigorously benchmarking _I_ max/ _I_ min. **a** , Benchmarking _I_ max/ _I_ min at _V_ DS = 1 V, similar to Fig. 3a. Devices A and B are not actual experimental data and are used to demonstrate benchmarking devices with different channel lengths. The carrier densities at which the _I_ max and _I_ min are extracted are also labeled. **b** , Benchmarking _I_ max/ _I_ min at the same operation regime, which is the linear regime with drain-tosource field _E_ DS = 0.1 V/µm used as an example. Note, the diagonal dashed lines indicate certain values of _I_ max/ _I_ min. 

Additional factors can impact _I_ max/ _I_ min ratio. When benchmarking devices with the same channel material but with different channel thicknesses, plotting _I_ max/ _I_ min vs. _t_ ch is suggested. It is noteworthy 

19 

that _I_ max/ _I_ min also depends on channel length and the equivalent oxide thickness (EOT) of the gate insulator. When the devices to be benchmarked have the same channel thickness, then benchmarking _I_ max/ _I_ min vs. _L_ ch/EOT should be considered. In addition, _I_ min can be limited by the measurement instrumentation, especially in materials with larger band gap such as monolayer TMDs. Additional factors impacting _I_ max/ _I_ min include contact resistance (which limits _I_ max), leakage currents (which dominate _I_ min) and parasitic capacitances (which affect electrostatic control of the gate), etc. 

#### **Note S2: Different methods to extract threshold voltage** **_V_ T and its uncertainties** 

#### **_Different methods to extract VT_** 

<mark>A standard method to extract the</mark> _<mark>V</mark>_ T <mark>is not yet available.</mark> Refs.<sup>4–7</sup> <mark>have investigated and compared different</mark> _<mark>V</mark>_ T <mark>extraction methods. Specifically, in Ref.</mark><sup>4</sup> <mark>, the authors investigated eleven approaches to extract the</mark> _<mark>V</mark>_ T <mark>and found that similar</mark> _<mark>V</mark>_ T <mark>values in the linear regime can be extracted. In Refs.</mark><sup>5,6</sup> , <mark>the authors proposed the Y-function method to eliminate the</mark> _<mark>R</mark>_ c <mark>effect when evaluating mobility values. In their studies, the</mark> _<mark>V</mark>_ T <mark>is extracted from the</mark> _<mark>I</mark>_ D <mark>/</mark> _<mark>g</mark>_ m<sup>0.5</sup> <mark>curve.</mark> 

#### **_Uncertainty of VT induced by I-V sweeps_** 

The threshold voltage _V_ T uncertainties can propagate to the estimation of carrier density. Fig. S2 shows an example of _V_ T shift due to different sweeps ( _I_ D- _V_ GS vs. _I_ D- _V_ DS) on the same device illustrated in Fig. 2c. 



<!-- Start of picture text -->
30 0 From  I D V GS<br>From  I D V DS<br>25 0<br>V DS = 4 V<br>20 0<br>15 0<br>10 0<br>5 0<br>0<br>0 4 8 12<br>V GS (V)<br>I  (µA/µm)D<br><!-- End of picture text -->

**Fig. S2 |** Comparison of transfer curves at _V_ DS = 4 V from _I_ D- _V_ GS sweep (red) and extraction from _I_ D- _V_ DS sweeps (black) based on data in Figures 2b,d of the main text. The direction of the sweeps is the same (backward). A _V_ T shift of ~0.6 V is observed comparing the _I_ D- _V_ GS and _I_ D- _V_ DS sweeps. We presume this shift arises from hot-carrier stress during the _I_ D- _V_ DS sweeping at high _V_ DS and _V_ GS. Due to high electric fields, energetic electrons become trapped in the gate oxide as fixed charges<sup>8</sup> , increasing the _V_ T. This phenomenon highlights the dependence of _V_ T on _I_ D- _V_ DS sweeping. 

20 

#### **Note S3: Extracting** **_R_ c from TLM** 

Extracting _R_ c from TLM data can lead to significant uncertainties. As a reminder, TLM data is a plot of the total resistance ( _R_ tot) from a set of devices having all things consistent with their structure and materials except their channel length. TLM data is plotted as _R_ tot vs _L_ ch, where the _R_ tot = _R_ ch + 2 _R_ c = _R_ sh _L_ ch + 2 _R_ c, which means when the channel length is zero (y-axis intercept) _R_ tot = 2 _R_ c. A reliable _R_ c must be derived from TLM data that includes devices in the short-channel limit, where **_R_ c dominates the total resistance** or at least is comparable to the _R_ ch. Ideally, the sheet resistance and its variation need to be sufficiently small; otherwise, a small variation in _R_ sh could lead to substantial errors in _R_ c. Three examples of TLM data are presented in Fig. S3a, all claiming an _R_ c of 500 Ω⋅µm, based on the intercepts to the _R_ tot axis. However, due to the larger _R_ sh, the uncertainty of _R_ c in TLM A is significantly larger than TLM B (e.g., a small change in _R_ sh for TLM A would result in a large change in the extracted _Rc_ ). In TLM A, the shortest channel device has an _R_ tot of 10 kΩ⋅µm, which is much larger than the claimed _R_ c of 500 Ω⋅µm, whereas in TLM B, the _R_ tot is 2 kΩ⋅µm and the claimed _R_ c is 500 Ω⋅µm. As noted above, with a slight variation in the _R_ sh in TLM A, the _R_ c might be extracted as a very small (and often untrue) value or even a negative value. 

Hence, it is critical to have both of the following in a TLM: 1) devices with channel length small enough to ensure 2 _Rc_ dominates _R_ tot and 2) a sufficient number of longer channel length devices to ensure a reliable _R_ sh extraction based on a linear fit. Another possible scenario to avoid is illustrated with TLM C, which represents a TLM data set where all of the devices are 2 _R_ c dominated thus leading to an inaccurate estimation of _R_ sh. This comparison further highlights the need for proper TLM data; as a summary, a valid TLM data set should have at least four channels and include at least one each of contact and channel resistance-dominated devices. 



**Fig. S3 | a** , Demonstration of TLM data sets with all _R_ ch-dominant devices (TLM A, leading to unreliable _Rc_ extraction), all _R_ c-dominant devices (TLM C, leading to unreliable _Rsh_ extraction), and an appropriate balance of devices (TLM B). **b** , Example diagram of four-probe measurements to extract _R_ sh, with a backgate as a demonstration. The channel resistance _R_ ch between probe 2 and 3 is _R_ 14,23 = _V_ 23/ _I_ 14, where _I_ 14 is the current flowing from probe 1 to 4 and _V_ 23 is the voltage between probe 2 and 3. _R_ sh = _R_ 14,23 ( _W_ / _L_ ). _R_ sh can be obtained while _V_ GS is swept, yielding _R_ sh vs. _V_ GS or carrier density, which can be used to crossexamine the _R_ sh extracted from TLM. 

21 

Since there can be considerable variation in the quality of emerging semiconducting materials, even on the same chip (e.g., variation in crystal quality in MoS2), this can translate to a sizeable variation in _R_ sh from one device to another. Note, a perfect TLM is based on the assumption that _R_ sh is the same for all devices being tested, so any disruption to this assumption translates to inaccuracy in the extraction of _Rc_ . Hence, it is highly recommended to fabricate several TLM device sets and plot the full distribution of resultant TLM data (multiple data points for each channel length). This provides evidence for how dependable the extraction is; a good example of this is in Ref.<sup>9</sup> and Fig. S5g below. 

Another critical aspect of proper TLM data sets is the need for reporting the uncertainties of _R_ sh and _R_ c in standard error or confidence interval from a least-squares fit of the TLM curve; an example of this can be seen in Fig.2h and Ref.<sup>10</sup> . Lastly, if a record parameter is claimed based on TLM, fourprobe measurements<sup>7,11</sup> should ideally be used as a complementary method to cross-check the results. Traditionally, four-probe measurements are used to characterize the resistivity of “bulk” doped films and a gate bias is not involved. However, to estimate the _R_ sh for emergent semiconducting materials, it is necessary to sweep the gate bias so that _R_ sh vs. gate voltage (carrier density, _n_ S) can be obtained. An example of the four-probe measurement is given in Fig. S3b. It is key to have probe 2 and 3 placed to the side of the channel so that the voltage probes (2 and 3) do not obstruct the current flow from probe 1 to 4. After obtaining _R_ sh vs. _n_ S, _R_ c vs. _n_ S can be derived by subtracting _R_ sh from _R_ tot. 

A final caution regarding the use of TLM data is regarding the transfer length ( _L_ T), which is the length of the contact over which the majority of carrier injection occurs between the metal and semiconductor. Traditionally, _L_ T was also extracted from TLM data as the intercept of the linear fit with the _L_ ch (x-axis). However, extracting _L_ T in this manner assumes that the sheet resistance of the semiconductor in the metal-contacted region is the same as for the semiconductor in the channel region. For emergent semiconducting materials, particularly low-dimensional materials like CNTs or 2D TMDs, this is not a valid assumption as transport through the materials happens predominantly (if not entirely) on the surface and is strongly dependent on the materials interfacing with the semiconductor. Because _L_ T has significant implications for the scalability of the contact length in emergent FETs, it must not be improperly extracted and reported from simple TLM data sets. This is commented on further in the next section (Note S4). 

22 

### **Note S4: Additional Parameters** 

In the main text, we covered the most representative parameters for reporting and benchmarking emergent FETs. Here we describe some additional parameters used in specific studies. 

**_Normalization of I_ D** **_for 1D devices_** : For 1D or close to 1D devices, to compare _I_ D, it is sometimes necessary to convert the _I_ D per CNT/nanowire/nanosheet stack to _I_ D per µm. If the 1D channel materials are aligned CNTs or nanowires (Fig. S4a), the normalization of currents depends on the density of the 1D channel or the number of 1D channels in 1 µm. If the CNTs or nanowire are a dense network, treating the channel similar to a 2D material is more appropriate. For gate-all-around nanosheet devices (Fig. S4b), it is common to report _I_ D per nanosheet stack. If reporting the _I_ D per channel footprint, then the current per nanosheet stack should be divided by the nanosheet width ( _W_ NS). A more detailed reporting of _I_ D per channel width would require the calculation total channel width of the nanosheets in the stack, which is close to _W_ NS × _T_ NS × number of nanosheets in the stack. The normalized drain currents per channel width is _I_ D per stack divided by the total channel width of the stack. Ultimately, what matters is both an indication of what is achieved on a per nanomaterial/structure basis (e.g., per CNT or per nanosheet stack) as well as what is achieved on a per aerial footprint width basis (i.e., µA per _Wch_ ). 



<!-- Start of picture text -->
a CNT/nanowire<br>Aligned Dense network<br>W ch S D S D<br>L ch<br>b Gate-all-around nanosheet<br>W NS Gate<br>Oxide<br>T NS Si<br>S D<br>Side view Top-down view<br><!-- End of picture text -->

**Fig. S4** | Normalization of currents for transistors based on 1D or close to 1D channel materials. **a** , topdown view of transistors based on CNTs or nanowires in the form of aligned channels and a dense network. **b** , side-view and top-down (aerial) view of gate-all-around nanosheet transistors. 

23 

**_Schottky barrier height_** : For Schottky contacts between metal and semiconductors, the Schottky barrier height determines the efficiency of carrier transport in the contacts. Hence, properly extracting the barrier height is key for comparing different contact engineering approaches. Examples of Schottky barrier extraction can be found in Ref.<sup>3,12–14</sup> , with some variances in the equations and approaches used. 

**_Transfer length_** ( _L_ T): Because charge carriers tend to crowd near the contact edge when transported between the metal contacts and the channel material, only a certain portion of the contacts actively participate in the carrier transport process. The transfer length denotes the distance over which most of <u>$#</u> from the transfer length $$% the current transfers in the contact. Traditionally, _L_ T can be estimated as & method plot, where the 𝜌% is the specific contact resistivity (unit: Ω⋅cm<sup>2</sup> ) and 𝜌&' is the sheet resistance underneath the contact (unit: <mark>Ω/square)</mark> – this is discussed in some detail in Note S3 above. However, this estimation is not reliable for emergent transistors due to: 1) many of the emergent transistors use ultra-thin, low-dimensional nanomaterials, which can alter the current crowding behavior; 2) lots of research-grade emergent transistors have gated contacts, which complicates the estimation of the sheet resistance underneath the contact; and 3) the difference in the interface between the metalsemiconductor and gate insulator semiconductor leads to further differences in sheet resistance of the semiconductor in these regions. Hence, accurately determining _L_ T will depend on physically scaled contacts to observe the contact scaling behavior. 

**_Interface trap density_** ( _D_ it): This parameter is essential for studying and evaluating novel gate dielectrics. Different methods for determining _D_ it can be found in Ref.<sup>12</sup> . 

**_High-frequency response of the gate insulator capacitance_** : Although most of the parameters covered in the main text are low-frequency parameters, for devices to be eventually used in high-frequency and high-performance applications, it is necessary to properly evaluate the high-frequency response of the gate insulator capacitance and the current-voltage characteristics<sup>15</sup> . 

24 

### **Note S5: Demonstration of device spread and parameter variations** 

As indicated in the main text, we recommend showing device spread and parameter variations to demonstrate the full picture of the reported devices. In Fig. S5, based on ten TLM structures similar to the one used in Fig. 2, we demonstrate the spread of device characteristics and parameter variations using a cumulative distribution function plot and boxplots. 



<!-- Start of picture text -->
2 10 0<br>a b 10 c<br>14 0  2 L 80 nmch 10 1<br>12 0  4 00 nm 0 8 0<br>10<br> 5 50 nm<br>10 0  7 50 nm 10- 1<br>6 0<br> 9 80 nm - 2<br>8 0 10<br> 1 300 nm<br>6 0 V DS = 1 V 10- 3 4 0<br>10- 4<br>4 0 10- 5 2 0<br>L ch ≈ 280 nm L ch ≈ 280 n m<br>2 0 - 6<br>10<br>V DS = 1 V V DS = 1 V<br>0 10- 7 0<br>0 4 8 12 0 4 8 12 0 0.2 0.4 0.6 0.8 1<br>V GS (V) V GS (V) V hy (V)<br>d 6 e 14 0<br>5 12 0<br>10 0<br>4<br>8 0<br>3<br>6 0<br>2<br>4 0<br>V DS = 1 V<br>1 2 0<br>V DS = 1 V n S ≈ 1.3 x 10 13  cm -2<br>0 0<br>0 200 400 600 800 1000 1200 1400 0 200 400 600 800 1000 1200 1400<br>L ch (nm) L ch (nm)<br>f 40 0 g 3 0<br>V DS = 0.1 V<br>2 5<br>30 0 n S ≈ 1.3 x 10 13  cm -2<br>2 0<br>20 0 1 5<br>1 0<br>10 0<br>5<br>Near  I D = 10 nA<br>0 0<br>0 200 400 600 800 1000 1200 1400 0 200 400 600 800 1000 1200 1400<br>L ch (nm) L ch (nm)<br>I  (µA/µm)D I  (µA/µm)D  CDF (%)<br>V  (V)T<br>I  (µA/µm)D<br>SS  (mV/dec) R  (kΩ·µm)tot<br><!-- End of picture text -->

**Fig. S5** | Demonstration of device spread and parameter variations based on ten TLM structures. **a** , Example transfer curves ( _I_ D- _V_ GS) for the TLM structure in Fig. 2. **b** , Measured subthreshold curves ( _I_ D- _V_ GS) of ten devices with _L_ ch of 280 nm of 280 nm. **c** , Cumulative distribution function (CDF) of the hysteresis voltage for the ten devices with _L_ ch of 280 nm.  Boxplots of ( **d** ) _V_ T, ( **e** ) _I_ D at VDS = 1 V and _n_ S = 1.3×10<sup>13</sup> cm<sup>-2</sup> , ( **f** ) the minimal _SS_ extracted near _I_ D _=_ 10 nA, and ( **g** ) ten TLM plots with the median _R_ c value of 3 kΩ⋅µm _._ 

25 

**Note S6: Benchmarking devices with different channel thicknesses** 



**Fig. S6 |** Example benchmarking device performance of MoS2 FETs with different channel thicknesses. **a** , Benchmarking _I_ sat versus _n_ S, where the channel length in nm is labeled next to the metal contacts used in the devices. **b** , Benchmarking _R_ c versus _n_ S in a few representative reports, where the channel thickness is labeled for the multilayer channels. “a” stands for the example device in Fig. 2. A few studies are plotted as dotted lines to keep the plots from cluttering and also highlight the trends. Different colors are assigned to different reported devices. Most of the data are extracted from the following published reports: transferred Ag<sup>16</sup> , AlOx doped+Au<sup>17</sup> , Ag<sup>18</sup> , In<sup>19</sup> , Ni<sup>20</sup> , Cl doping<sup>1</sup> , Ni/Gr<sup>2</sup> , and Bi<sup>3</sup> . 

26 

Representative reports with relatively large _I_ sat are listed in Table S1, with both monolayer and multilayer MoS2 channels included. 

|**Table S1| Rep**|**resentat**|**ive reporti**|**ng on stud**|**ies of MoS2 FETs**|**with****_I_sat**|||
|---|---|---|---|---|---|---|---|
|**Contacts**|**Ref.**|**_t_ch** <br>(nm)|**_L_ch** <br>(nm)|**_n_S**<br>(10<sup>13</sup>cm<sup>-2</sup>)<br>|**_R_c**<br> (kΩ⋅µm)|**_V_**DS<br>(V)|**_I_sat**<br>(µA/µm)|
|Ag|18|1L|72|1.44|1.3|1.8|320|
|Au|a|1L|280|1.3|2|4|325|
|Au|21|1L|20|2.8|N/A|2|350|
|Bi|3|1L|150|3.4|0.12|2|380|
|Ni+Cl<br>doping|1|4|100|2.16|0.5|1.6|460|
|Au|21|6|10|2.19|N/A|2|470|
|Sn|22|1L|35|1|0.84|1.5|615|
|Transferred<br>Ag|16|4~20|160|1.58|N/A|3|660|
|AlOx+Au|17|1L|380|2|0.48|5|700|
|Ni/Gr|2|10L|80|2.58|0.54|2|830|
|Ni|23TG|4.2|1000|2.43|N/A|3|290|
|Au|24TG|1L|10|~7|1.7|2|425|
|Cr|25TG|~4L|400|2.44|3.3|4|526|



a: the example MoS2 FET in Fig. 2a; TG = top gate; 1L = monolayer; 2L = bilayer, etc. The Table lists _I_ sat in ascending order but not including the last three rows because they are top-gated. All other FETs were back-gated. _μ_ FE is not benchmarked as several of the studies listed have overestimated values. More studies that may not have _I_ sat reported can be accessed at Ref.<sup>26</sup> . 

27 

#### **References:** 

1. Yang, L. _et al._ High-Performance MoS2 Field-Effect Transistors Enabled by Chloride Doping : Record Low Contact Resistance (0.5 k·µm) and Record High Drain Current (460 µA/µm). in _VLSI Technology_ (2014). 

2. Liu, Y. _et al._ Pushing the Performance Limit of Sub-100 nm Molybdenum Disulfide Transistors. _Nano Lett_ **16** , 6337–6342 (2016). 

3. Shen, P.-C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). 

4. Ortiz-Conde, A. _et al._ A review of recent MOSFET threshold voltage extraction methods. _Microelectron. Reliab._ **42** , 583–596 (2002). 

5. Ghibaudo, G. New method for the extraction of MOSFET parameters. _Electron. Lett._ **24** , 543–545 (1988). 

6. Chang, H. Y., Zhu, W. & Akinwande, D. On the mobility and contact resistance evaluation for transistors based on MoS2 or two-dimensional semiconducting atomic crystals. _Appl. Phys. Lett._ **104** , 113504 (2014). 

7. Pang, C. _et al._ Mobility Extraction in 2D Transition Metal Dichalcogenide Devices—Avoiding Contact Resistance Implicated Overestimation. _Small_ **17** , 2100940 (2021). 

8. Streetman, B. G. & Banerjee, S. K. _Solid State Electronic Devices, 6th Edition_ . (Pearson, 2006). 9. Kumar, A. _et al._ Sub-200 Ω·µm Alloyed Contacts to Synthetic Monolayer MoS2. in _IEEE International Electron Devices Meeting (IEDM)_ 154–157 (2021). 

10. Smithe, K. K. H., English, C. D., Suryavanshi, S. V & Pop, E. Intrinsic electrical transport and performance projections of synthetic monolayer MoS2 devices. _2D Mater._ **4** , (2016). 

11. Guros, N. B. _et al._ Reproducible Performance Improvements to Monolayer MoS2 Transistors through Exposed Material Forming Gas Annealing. _ACS Appl. Mater. Interfaces_ **11** , 16683–16692 (2019). 

12. Schroder, D. K. _Semiconductor Material and Device Characterization, 3rd Edition_ . (Wiley-IEEE Press, 2015). 

13. Das, S., Chen, H. Y., Penumatcha, A. V & Appenzeller, J. High performance multilayer MoS2 transistors with scandium contacts. _Nano Lett_ **13** , 100–105 (2013). 

14. Cheng, Z. _et al._ Immunity to Contact Scaling in MoS2 Transistors Using in Situ Edge Contacts. _Nano Lett._ **19** , 5077–5085 (2019). 

15. Bethge, O. _et al._ Process temperature dependent high frequency capacitance-voltage response of ZrO2/GeO2/germanium capacitors. _Appl. Phys. Lett._ **96** , 052902 (2010). 

16. Liu, Y. _et al._ Approaching the Schottky-Mott limit in van der Waals metal-semiconductor junctions. _Nature_ (2018) doi:10.1038/s41586-018-0129-8. 

17. McClellan, C. J., Yalon, E., Smithe, K. K. H., Suryavanshi, S. V. & Pop, E. High Current Density in Monolayer MoS2 Doped by AlOx. _ACS Nano_ **15** , 1587–1596 (2021). 

18. Smithe, K. K. H., English, C. D., Suryavanshi, S. V. & Pop, E. High-Field Transport and Velocity Saturation in Synthetic Monolayer MoS2. _Nano Lett._ **18** , 4516–4522 (2018). 

19. Wang, Y. _et al._ Van der Waals contacts between three-dimensional metals and two-dimensional semiconductors. _Nature_ **568** , 70–74 (2019). 

20. Smets, Q. _et al._ Ultra-scaled MOCVD MoS2 MOSFETs with 42nm contact pitch and 250μA/μm drain current. in _Technical Digest - International Electron Devices Meeting, IEDM_ (2019). doi:10.1109/IEDM19573.2019.8993650. 

21. Patel, K. A., Grady, R. W., Smithe, K. K. H., Pop, E. & Sordan, R. Ultra-scaled MoS2 transistors and circuits fabricated without nanolithography. _2D Mater._ **7** , 015018 (2020). 

22. Chou, A. S. _et al._ High On-State Current in Chemical Vapor Deposited Monolayer MoS2 nFETs with Sn Ohmic Contacts. _IEEE Electron Device Lett._ **42** , 272–275 (2021). 

23. Li, X. _et al._ Effect of Dielectric Interface on the Performance of MoS2 Transistors. _ACS Appl Mater Interfaces_ **9** , 44602–44608 (2017). 

24. English, C. D., Smithe, K. K. H., Xu, R. L. & Pop, E. Approaching ballistic transport in monolayer 

28 

MoS2 transistors with self-aligned 10 nm top gates. _Tech. Dig. - Int. Electron Devices Meet (IEDM)_ 5.6.1-5.6.4 (2017) doi:10.1109/IEDM.2016.7838355. 

25. Zou, X. _et al._ Interface engineering for high-performance top-gated MoS2 field-effect transistors. _Adv. Mater._ **26** , 6255–6261 (2014). 

26. McClellan, C. J. _et al._ 2D Device Trends. http://2d.stanford.edu. 

29 

