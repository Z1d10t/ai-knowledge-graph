# Directional and Ultrafast Charge Transfer in Oxygen-Vacancy-Rich ZnO@Single-Atom Cobalt Core-Shell Junction for Photo-Fenton-Like Reaction.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Angewandte Chemie |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 194 |
| 作者 | Xi-Lin Wu, Shiang-Lin Liu, Min-Jia Yan, Hong-Jun Lin, Jian-Rong Chen, Shou-Jie Liu, Shao-Bin Wang, Xiao-Guang Duan |
| DOI | 10.1002/anie.202305639 |
| 源文件 | 051_Wu_2023_Directional-and-Ultrafast-Charge-Transfer-in-Oxy.pdf |

---
**_Angewandte Chemie_** 

**_Research Articles_** 

www.angewandte.org 





## **_Advanced Oxidation Processes_** 

How to cite: _Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 doi.org/10.1002/anie.202305639 

# **Directional and Ultrafast Charge Transfer in Oxygen-Vacancy-Rich ZnO@Single-Atom Cobalt Core-Shell Junction for Photo-FentonLike Reaction** 

_Xi-Lin Wu,* Shiang Liu, Yu Li, Minjia Yan, Hongjun Lin, Jianrong Chen, Shoujie Liu, Shaobin Wang, and Xiaoguang Duan*_ 

### **_Introduction_** 

**Abstract:** In photosynthesis, solar energy is harvested by photosensitizers, and then, the excited electrons transfer via a Z-Scheme mode to enzymatic catalytic centers to trigger redox reactions. Herein, we constructed a core– shell Z-scheme heterojunction of semiconductor@singleatom catalysts (SACs). The oxygen-vacancy-rich ZnO core and single-atom Co� N4 sites supported on nitrogen-rich carbon shell (SA-Co-CN) act as the photosensitizer and the enzyme-mimicking active centers, respectively. Driven by built-in electric field across the heterojunction, photoexcited electrons could rapidly (2 ps) transfer from the _n_ -type ZnO core to the _p_ -type SA-Co-CN shell, finally boosting the catalytic performance of the surface-exposed single-atom Co� N4 sites for peroxymonosulfate (PMS) activation under light irradiation. The synergies between photocatalysis and heterogeneous Fenton-like reaction lead to phenomenally enhanced production of various reactive oxygen species for rapid degradation of various microcontaminants in water. Experimental and theoretical results validate that the interfacial coupling of SA-Co-CN with ZnO greatly facilitates PMS adsorption and activation by reducing the adsorption energy and enhancing the cascade electron transfer processes for the photo-Fenton-like reaction. 

[*] Prof. X.-L. Wu, S. Liu, Y. Li, M. Yan, Prof. H. Lin, Prof. J. Chen College of Geography and Environmental Science, Zhejiang Normal University Jinhua, 321004 (China) E-mail: dbwxl@zjnu.cn Prof. S. Liu Chemistry and Chemical Engineering of Guangdong Laboratory Shantou, 515063 (China) Prof. S. Wang, Dr. X. Duan 

School of Chemical Engineering and Advanced Materials, The University of Adelaide Adelaide, SA (Australia) E-mail: xiaoguang.duan@adelaide.edu.au 



© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution Non-Commercial License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited and is not used for commercial purposes. 

In nature, solar energy is utilized by plants through a cascade of electron transfer processes, including the lightharvesting process and the Z-scheme charge transfer processes for redox reactions (Scheme S1).<sup>[1]</sup> Semiconductorbased Z-scheme photocatalyst can mimic the charge transfer processes of natural photosynthesis,<sup>[1]</sup> which has shown great potential for solar-to-fuel conversion and environmental remediation.<sup>[2]</sup> Light-absorption, generation and separation of charge carriers and surface redox reactions are key steps in semiconductor-based photocatalysis.<sup>[3]</sup> However, bottlenecks such as poor light harvesting and rapid combination of the charge carriers restrict the improvement of the overall efficiency of photocatalysis.<sup>[4]</sup> Constructing heterojunction between semiconductors is a promising approach to improve light-harvesting, separation of charge carriers, and redox potentials of photocatalysts.<sup>[3,5]</sup> Among the various types of heterojunctions, p-n junction between p-type photocatalyst and n-type semiconductor could generate powerful built-inelectric field (BIEF) within the heterojunction, due to their large potential difference in Fermi level.<sup>[6]</sup> The chargetransfer modes in p-n junction can be classified into traditional type-II and direct Z-scheme mechanisms.<sup>[7]</sup> The BIEF provides a strong driving force to accelerate charge carriers separation and transfer and to navigate their transportation paths.<sup>[8]</sup> For example, ultra-fast electron transfer ( _<_ 280 fs) from CuSnI to ZnO has been observed in the CuSnI/ZnO p- n heterojunction via a type-II charge transfer pathway.<sup>[9]</sup> The CoFe2O4/g-C3N4 p-n junction improved charge separation and accelerated the Z-scheme electron transfer from CoFe2O4 to g-C3N4 (86.99 ps) to boost photocatalytic performance for H2 evolution.<sup>[10]</sup> However, the construction of p-n junctions with Z-scheme charge transfer pathways is still challenging and the charge-transfer mechanisms are still not well understood.<sup>[3,11]</sup> 

Single-atom catalysts (SACs), composed of isolated metal sites supported on various substrates, can mimic enzyme catalysis and can bridge the gap between homogeneous and heterogeneous catalysis.<sup>[12]</sup> Generally, carbon materials and metal oxides are applied as the supports to anchor single-atom catalytic sites,<sup>[13]</sup> whereas the unexposed single-atom sites confined in carbon layers or in bulk phase of the metal oxides are inactive for the catalytic reactions. In addition, the metal loading of SACs is usually very low, which provides a limited quantity of exposed metal sites to 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (1 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



catalyze the surface redox reactions.<sup>[14]</sup> On account of these concerns, it is of great demand to develop new strategies to improve the catalytic performance of SACs. Till now, the intrinsic catalytic activity of SACs is typically regulated by the geometric and electronic structures of single-atom metal sites on various supports.<sup>[15]</sup> The types of single-atom metals, the coordination environment and support properties are the critical factors in determining the intrinsic catalytic activity and selectivity of SACs.<sup>[15b]</sup> However, apart from tailoring the atomic-local environments, tuning the properties of SACs at architectural levels remains challenging and rare in new catalyst design. 

As inspired by the cascade electron transfer between photosensitizer (for light-harvesting) and the redox centers (for catalysis) in natural photosynthetic system (Scheme S1),<sup>[16]</sup> we speculate that the efficient electron communication between semiconducting photocatalysts and SACs will boost the performance of the single-atom metal redox centers for heterogeneous catalysis.<sup>[17]</sup> Herein, we designed and fabricated core–shell p-n junction consists of n-type ZnO and p-type Co SACs. The single-atom Co sites supported on nitrogen-rich carbons (SA-Co-CN) were deposited on the surface of ZnO to form a core–shell heterostructure, which improves light-harvesting, maximizes the contact interfaces between the two semiconductors, and allows the exposure of abundant active single-atom Co sites for surface redox reactions (Scheme 1). Driven by built-in electric field (BIEF), this ingenious heterostructure promotes Z-scheme charge transfer from the ZnO “core” to the SA-Co-CN “shell” to optimize the electronic structures of single cobalt sites under light excitation, ultimately enhancing the performance of ZnO@SA-Co-CN for peroxymonosulfate (PMS) activation under visible (Vis) light. Abundant reactive species (SO4*� , *OH and 1O2) were detected for efficient degradation and mineralization of trace organic contaminants (TrOC) in aqueous solution. This work provides a new strategy for boosting the catalytic perform- 



**_Scheme 1._** Z-scheme electron transfer in ZnO@SA-Co-CN for enhanced surface redox reaction. 

ance of SACs by steering the charge transfer at interfaces of SACs-based core–shell nanoarchitectures. 

### **_Results and Discussion_** 

SACs with metal-nitrogen (M� N _x_ ) coordination behave as p-type semiconductors, owing to the strong interactions between the mobilized π _-_ and localized _d_ -electrons in the M� N _x_ moiety.<sup>[18]</sup> In contrast, ZnO is a prototypical _n_ -type semiconductor.<sup>[19]</sup> Herein, we designed a core–shell heterostructure with n-type ZnO and p-type SACs. The _p-n_ heterojunction creates built-in electric field (BIEF) to form a space-charged (or depletion) region,<sup>[20]</sup> which spontaneously drives the directional electrons/holes separation and diffuse toward the positively and negatively charged layers. The efficient interfacial charge communication leads to the spatial charge redistribution, which modulates the local electronic structure of the M� N _x_ with higher intrinsic activity. Furthermore, the BIEF promotes the efficient separation and migration of light-induced charge carriers across the heterojunction, thereby accelerating the redox cycle of the metallic single sites for Fenton catalysis. This rational design allows us to fine-tune the charge carrier dynamics in semiconductors and to synergistically boost the performances of SACs under light irradiation. 

The ZnO@SA-Co-CN heterojunction was fabricated by coating Co, C and N precursors on ZnO, followed by the calcination of the mixture. The scanning electron microscope (SEM) images of pristine ZnO (Figure S1) and ZnO@SA-Co-CN (Figure 1A) exhibit the spindle-like morphology. Transmission electron microscope (TEM) image (Figure 1B) reveals the rough and amorphous surface of ZnO@SA-Co-CN, which is beneficial to the exposure of surface catalytic sites, light trapping, and enrichment of reactants in the microenvironment. The high-resolution TEM image (Figure 1C) verifies that amorphous carbons are deposited on the surface of ZnO. From the high-angle annular dark-field scanning TEM (HAADF-STEM) images (Figure 1D and E), one can clearly observe that the thickness of the carbon layers was in the range of 1–10 nm, demonstrating the successful fabrication of the core–shell heterostructure. HAADF-STEM image (Figure 1F) of the surface carbon layers shows the presence of abundant bright spots (partially marked with circles), corresponding to the Co single atoms. From the lattice fringe analysis, the lattice spacings of 0.25, 0.28 and 0.19 nm are assigned to (101), (100) and (102) crystal planes of ZnO.<sup>[21]</sup> Moreover, the apparent signals of Zn, O and the surface C, N, Co elements can be detected by energy dispersive spectroscopy (EDS) elemental mapping (Figure 1G–L), suggesting the even distribution of the C, N, Co elements on the surface of ZnO. From the X-ray diffraction (XRD) patterns of ZnO@SACo-CN (Figure S2), the peaks are all indexed to monoclinic ZnO (JCPDS No. 89-7102), and no evident peak for Co species (Co<sup>0</sup> or CoO _x_ ) is detected, verifying the Co atoms are atomically dispersed in the surface CN layers. Figure S3 shows the Fourier transform infrared spectra (FTIR) of pure ZnO and ZnO@SA-Co-CN, the peak at 1392 cm<sup>�1</sup> is 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (2 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 1._** A) SEM image, B) TEM image, C) high resolution TEM image, D)–F) HAADF-STEM images of the ZnO@SA-Co-CN, G) SEM image and H)–L) the corresponding EDX mapping of ZnO@SA-Co-CN, M) The XAENS spectra (inset shows the pre-edge of the XAENS spectra), N) Fourier transformed EXAFS spectra of Co foil, CoO, Co3O4 and ZnO@SA-Co-CN. O) The EXAFS fitting for ZnO@SA-Co-CN at R space (inset is the wavelet transformed EXAFS spectrum). 

assigned to the symmetric carboxylate stretching vibration,<sup>[22]</sup> and the broad peaks in the range of 1540– 1560 cm<sup>�1</sup> are due to the carboxylate stretching vibration and skeletal vibration (C=C) of graphitic carbons.<sup>[22,23]</sup> As compared with pure ZnO, the C� O stretching vibrations shifted from 1100 to � 1000 cm<sup>�1</sup> and the Zn� O bending vibrations shifted from 900 to 877 cm<sup>�1</sup> , indicating the formation of C� O� Zn bonds in ZnO@SA-Co-CN, which can serve as tunnels to accelerate charge migration at the interfaces.<sup>[24]</sup> The presence of the aromatic C� H bonds (752 and 720 cm<sup>�1</sup> )<sup>[25]</sup> in the FTIR spectrum and the D and G bands in the Raman spectrum (Figure S4)<sup>[26]</sup> collectively confirms the presence of graphitic carbons in ZnO@SA-CoCN. Furthermore, the presence of C, N, O, Co and Zn elements and the corresponding C=C, C=O, C� O, C� N and Zn� O chemical bonds in ZnO@SA-Co-CN are also verified by X-ray photoelectron spectroscopy (XPS) (Figure S5). From the above characterizations, one can conclude that the ZnO@SA-Co-CN heterostructure was successfully constructed. 

From the high-resolution Co 2p XPS spectrum (Figure S5d), the peaks at 781.4 and 796.9 eV are assigned to Co 2p3/2 and Co 2p1/2 orbits of the Co<sup>2+</sup> species, respectively.<sup>[27]</sup> The high-resolution N 1s XPS spectrum (Figure S6) shows 

the peaks at 398.7, 399.4 and 400.5 eV, corresponding to pyridinic-N, Co� N _x_ and pyrrolic-N, respectively. The configuration of the Co sites was further probed by X-ray absorption near edge structure (XANES) spectra. As shown in Figure 1M, the XANES absorption edge of ZnO@SA-CoCN is close to that of CoO, suggesting the valence state of the Co single-sites is about + 2. From the Fourier-transformed (FT) k<sup>3</sup> -weighted EXAFS spectra (Figure 1N), ZnO@SA-Co-CN displays one main peak at � 1.5 Å for the Co� N first coordination shell with the absence of the peak at � 2.2 Å for Co� Co coordination, demonstrating the Co atoms are atomically dispersed in the CN substrates. As shown in Figure 2c, the wavelet transformed (WT) plot of ZnO@SA-Co-CN shows the WT maximum at � 4.2 Å<sup>�1</sup> , confirming the formation of Co� N coordination.<sup>[31]</sup> The EXAFS spectra in R space (Figure 1O) and k space (Figure S7) are fitted and the corresponding parameters are listed in Table S2. The fitting results reveal that the Co single sites are coordinated with four N atoms with an average bond length of � 2.0 Å. Thus, the Co� N4 single-sites are successfully implanted in surface CN layers to form the ZnO@SA-Co-CN heterostructure. The WT EXAFS spectrum of ZnO@SA-Co-CN (inset in Figure 1O) confirms the dominance of Co� N bonding with WT contour maximum of 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (3 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Research Articles Chemie_** 





**_Figure 2._** A) UV/Vis DRS spectra (insets show the digital picture of the samples), B) tauc plots, C) Mott–Schottky plots and D) time-resolved PL decay of pristine ZnO and ZnO@SA-Co-CN. E) fs-TA spectra and the corresponding TA kinetic (inset) of ZnO. F) fs-TA spectra and the corresponding TA kinetic (inset) of ZnO@SA-Co-CN. G) Schematic representation of proposed charge trapping models for ZnO and ZnO@SA-CoCN. H) The proposed charge transfer process for catalysis by using ZnO@SA-Co-CN. 

4.2 Å<sup>�1</sup> .<sup>[28]</sup> These results corroborate the successful fabrication of the core–shell heterojunction between semiconductor (ZnO) and SACs (SA-Co-CN). The pure SA-Co-CN was also fabricated and characterized by TEM, XRD, Raman, XANES and EXAFS (Figure S8 and S9). 

After introducing the SA-Co-CN “shell”, the optical and electronic properties of ZnO were altered. The UV/Vis diffuse reflectance spectra (DRS) (Figure 2A) reflect the enhanced light absorption and extended absorption bandwidth of ZnO@SA-Co-CN as compared with pristine ZnO, implying its improved light-harvesting. This is also observed in the color change from white for ZnO to grey for ZnO@SA-Co-CN (inset in Figure 2A). As shown in Figure 2B, the direct band gaps of ZnO and ZnO@SA-Co-CN were determined to be 3.18 and 2.91 eV, respectively. The improved light absorption and narrowed band gap of ZnO@SA-Co-CN are beneficial to the excitation and generation of photogenerated carriers, resulting in enhanced 

photocatalytic activity.<sup>[29]</sup> ZnO and ZnO@SA-Co-CN (Figure 2C) have positive slopes for Mott–Schottky (M–S) plots, indicating electrons are the majority charge carriers (n-type semiconductor).<sup>[30]</sup> The charge carrier density (ND) of the catalysts is inversely proportional to the slope of the M� S curves, as described by the following equation.<sup>[31]</sup> 





<!-- Start of picture text -->
(1)<br><!-- End of picture text -->

Herein, q, ɛ and ɛ0 are all constants,<sup>[31]</sup> and thus the smaller M� S slope for ZnO@SA-Co-CN than that for ZnO suggests its higher charge carrier density. More interestingly, the M� S plot of ZnO@SA-Co-CN shows an inverted “VShape”, indicating the formation of _p-n_ junctions between ZnO and SA-Co-CN and the existence of a BIEF.<sup>[32]</sup> The BIEF within the _p-n_ junction will provide strong driving force for charge migration between the ZnO “core” and the 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (4 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



SA-Co-CN “shell”. The presence of BIEF in ZnO@SA-CoCN can be verified by using electrochemical impedance spectroscopy (EIS) and Zeta potential. As shown in Figure S10, the arc radius of EIS Nyquist plots of ZnO@SACo-CN was smaller than that of ZnO and SA-Co-CN,<sup>[33]</sup> suggesting BIEF has improved the electron transfer efficiency. According to Poisson’s equation-derived Kanada model, the BIEF is positively correlated with the Zeta potential.<sup>[34]</sup> As shown in Figure S11, the Zeta potential for ZnO@SA-Co-CN is � 14.4 mV; the absolute value is 4.2 and 3.1 times greater than that for SA-Co-CN (� 3.4 mV) and ZnO (� 4.6 mV), respectively. The presence of strong BIEF in ZnO@SA-Co-CN can significantly promote the separation and migration of the charge carriers at the interface of the heterojunction upon light irradiation.<sup>[35]</sup> From the photoluminescence (PL) emission spectra (Figure S12), one can observe that ZnO@SA-Co-CN well inherits the emission feature of ZnO with much smaller PL intensity, demonstrating less recombination of the separated photogenerated carriers.<sup>[29]</sup> As shown in Figure 2D, decay curves of the timeresolved PL spectra are fitted by a biexponential equation (2):<sup>[29]</sup> 



<!-- Start of picture text -->
I t ¼  I 0 þ  A 1 expð� t= t1Þ þ  A 2 expð� t= t2Þ (2)<br><!-- End of picture text -->

Herein, _I_ , _τ_ and _A_ are the PL intensity, decay time and PL amplitude, respectively. From the fitting data (inset table in Figure 2D), the ZnO@SA-Co-CN possesses a longer average lifetime ( _τ_ avg = 18.48 ns), which is 3 times of that for pure ZnO ( _τ_ avg = 6.12 ns). The prolonged average lifetime confirms an improved charge carrier separation efficiency in ZnO@SA-Co-CN, thus prolonging the lifetime of photocarriers to involve in surface redox reactions.<sup>[36]</sup> The promoted production and transportation of charge carriers in ZnO@SA-Co-CN were also verified from the enhanced photocurrent response under visible light ( _λ >_ 420 nm) as compared with pure ZnO (Figure S13).<sup>[37]</sup> These results corroborate the enhanced generation of photo-induced charge carriers in ZnO@SA-Co-CN. Driven by BIEF, the produced charge carriers will easily transfer to the surfaceexposed Co� N4 single sites, ultimately promoting its catalytic performance in catalysis. 

We further applied ultrafast transient absorption spectroscopy (TAS) to probe the charge carrier dynamics. The femtosecond (fs) TAS were performed upon 360 nm pulse pump and a white-light pulse (390–680 nm) probe. As illustrated in Figure 2E and F, all fs-TA spectra show broad negative absorption signals, owing to stimulated emission and bleaching of the ground state.<sup>[38]</sup> The intensity of TA signals was increased very fast within few ps after photoexcitation and then gradually decayed ( � 2 ns), which can be interpreted as the instantaneous generation of charge carriers and recombination of electron-hole pairs, respectively.<sup>[39]</sup> Through monitoring the intensity maximum of TA signals with different delay times, we noticed that the ZnO@SA-Co-CN exhibited stronger TA intensity than pure ZnO, suggesting more charge carriers are generated in the ZnO@SA-Co-CN heterostructure.<sup>[39]</sup> The decay kinetics of the fs-TAS spectra were fitted by multi-exponential func- 

tions (insets of Figure 2E and F). The fast components are assigned to the charge transfer processes (in picoseconds), while the slow components are due to the recombination of the electron-hole pairs (in nanoseconds).<sup>[40]</sup> For pure ZnO (Figure 2G), the decay traces are composed of two components, including a fast component ( _τ_ 1 = 223 ps) for the electron transfer process from the conduction band (CB) to the trapping state (TS) and a slow component ( _τ_ 2 = 1873 ps) for radiative recombination process (from CB to valence band (VB)).<sup>[41]</sup> The trapped charges in intrinsic TS of ZnO are photocatalytic inertness, which restrains their participation in surface redox reactions.<sup>[38]</sup> As illustrated in Figure 2H, one can observe that the ZnO@SA-Co-CN possesses two fast decay components. The fastest one ( _τ_ 1 = 2 ps) is assigned to electron transfer from the ZnO “core” to the SA-Co-CN “shell”, owing to the presence of strong BIEF across the heterojunctions.<sup>[42]</sup> As compared with pure ZnO, the ZnO@SA-Co-CN possesses much faster electron transfer ( _τ_ 2 = 94 ps) from CB to TS, which is due to the presence of abundant oxygen vacancies (OV, discussed below), providing a stronger driving force to accelerate charge migration.<sup>[42]</sup> Moreover, the narrowed band gap and abundant Ov of ZnO@SA-Co-CN enabled the generation of more photo-induced charge carriers, which are beneficial to the interfacial electron transfer process for catalysis at the surface region. The ZnO@SA-Co-CN possesses much longer lifetime for direct charge recombination ( _τ_ 3 = 2575 ps) than pure ZnO ( _τ_ 2 = 1873 ps), corroborating the prolonged lifespan and inhibited recombination of the photogenerated charge carriers in the core–shell heterostructure. As illustrated in Figure 2I, the BIEF within the heterojunctions has accelerated the electron transfer from the ZnO “core” to the surface Co� CN SACs “shell”, which will accelerate the redox cycle of the exposed Co single sites for catalytic reactions. 

A proof-of-concept application of ZnO@SA-Co-CN catalyst for PMS activation under visible light (Vis) has been carried out. Since Co� CN SACs were conformally grown on the ZnO surface, the efficient electron communications within the core–shell heterostructure will boost the redox reaction at the surface of ZnO@SA-Co-CN, thus facilitating PMS activation to produce reactive oxygen species (ROS). The catalytic performance was evaluated for degradation of sulfamethoxazole (SMX), a model of the TrOCs, in different systems. The catalyst and PMS dosages were optimized to 0.1 and 0.3 gL<sup>�1</sup> , respectively (Figure S14 and S15). As shown in Figure 3A, SMX degradation percentages reached 3.1% and 25.4% in PMS + Vis, ZnO + PMS systems respectively, indicating that Vis or ZnO alone is inefficient for PMS activation. Interestingly, � 63.3% of SMX was eliminated in the ZnO@SA-Co-CN + PMS system, which suggests efficient PMS activation by introducing the Co� CN SACs “shell” on ZnO. Besides, without PMS, SMX degradation reached � 1.6% in the ZnO + Vis system and � 13.1% in the ZnO@SA-Co-CN + Vis system, demonstrating the enhanced intrinsic photocatalytic activity of ZnO@SA-Co-CN. Surprisingly, SMX degradation efficiency was improved from � 26.3% in the ZnO + Vis + PMS system and � 63.3% in the ZnO@SA-Co-CN + PMS system to � 100% in the 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (5 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 3._** A) Degradation of SMX in the various systems and B) the corresponding kinetic rate constants. C) Effect of solution pH on SMX degradation. D) Cyclic degradation of SMX and E) degradation of the various TrOC in ZnO@SA-Co-CN + PMS + Vis system (Reaction conditions: [SMX] = [TBBPA] = [BPA] = [SIZ] = [MDZ] = 20 mgL<sup>�1</sup> ; [catalyst] = 0.1 gL<sup>�1</sup> ; [PMS] = 0.3 gL<sup>�1</sup> ; pH 7.0.). F) Quenching experiments for SMX degradation. DMPO spin-trapping EPR spectra for G) *OH, SO4*� and H) O2*� (* represents DMPO� OH*, ◇ represents DMPO� SO4*� and ◆ represents DMPO� O2*� ), I) TEMP spin-trapping EPR spectra for 1O2 (* represents TEMP� 1O2). 

ZnO@SA-Co-CN + Vis + PMS system, implying the synergy between photocatalysis and heterogeneous PMS oxidation mediated by the ZnO@SA-Co-CN heterostructure contributed to � 23.6% of the enhanced SMX degradation. 

The SMX degradation kinetic was fitted by pseudo-firstorder kinetic model (Figure S16) and the corresponding parameters were listed in Table S3. As shown in Figure 3B, the value of observed rate constant ( _k_ obs, 0.52 min<sup>�1</sup> ) for ZnO@SA-Co-CN + Vis + PMS system is � 7.0 and � 22.0 folds larger than that for ZnO@SA-Co-CN + PMS and ZnO + Vis + PMS systems, confirming the boosted performance of ZnO@SA-Co-CN in the Fenton-like reactions under visible light. Compared to state-of-the-art catalysts (Table S4), the ZnO@SA-Co-CN possesses much larger k value for the degradation of organic pollutants via PMS activation, demonstrating the high intrinsic catalytic activity of ZnO@- 

SA-Co-CN. The mineralization efficiency of SMX in the ZnO@SA-Co-CN + PMS + Vis system was evaluated by using the total organic carbon (TOC) analysis.<sup>[43]</sup> The high TOC removal percentage (76.8%) of SMX in the ZnO@SACo-CN + PMS + Vis system implies its excellent oxidation capacity for decomposing of TrOCs into CO2 and H2O (Figure S17).<sup>[44]</sup> Besides, the ZnO@SA-Co-CN + PMS + Vis system functions well in a wide working pH range (3–11), maintaining over 97% of SMX degradation (Figure 3C). In addition, more than 95% of SMX can be eliminated after 10 successive cycles of the catalytic degradation process (Figure 3D), implying the excellent stability and reusability of the ZnO@SA-Co-CN catalyst. The recycled ZnO@SA-CoCN was characterized by EXAFS (Figure S18), XRD (Figure S2) and XPS (Figure S5), which suggests a well-preserved structure of ZnO@SA-Co-CN after the photo- 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (6 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



Fenton-like reaction. The excellent robustness of ZnO@SACo-CN could be due to its unique core–shell structure, where the ZnO is well protected by the surface-coated CN layers. More importantly, the ZnO@SA-Co-CN + PMS + Vis system was proven to be efficient for the abatement of tetrabromobisphenol A, bisphenol A, sulfisoxazole and metronidazole (Figure 3E), and for the purification of SMX spiked effluent from wastewater treatment plant (Figure S19), indicating the photocatalyst/SACs core–shell heterostructure is applicable for purifying various TrOCs via photo-Fenton-like reactions. Production of ROS in the ZnO@SA-Co-CN + PMS + Vis system was probed by radical-quenching experiments. Methanol (MeOH) is able to quench SO4*� and *OH, and isopropanol (IPA), nitro blue tetrazolium (NBT), β-carotene and methyl phenyl sulfoxide (PMSO) were applied for quenching *OH, O2*� , 1O2 and high-valent Co species, respectively.<sup>[45]</sup> As shown in Figure 3F, PMSO and NBT shows negligible impact on SMX degradation, which suggests that high-valent Co and O2*� played insignificant roles in SMX oxidation. SMX degradation was obviously inhibited in the presence of IPA and MeOH, unveiling the dominant contributions of *OH and SO4*� to SMX oxidation. In addition, β-carotene showed almost no impact on SMX degradation, implying that<sup>1</sup> O2 may not involve in SMX oxidation. Furthermore, adding D2O into the SA-Co-CN/ZnO + PMS + Vis system to prolong the life-span of<sup>1</sup> O2 shows neligible promotion effect on SMX degradation (Figure S20), verifying insiginificant contribution of 1O2. The intermediate products from SMX degradation in the SA-Co-CN/ZnO + PMS + Vis system were studied (Figure S21). The characterized degradation products and pathways further confirm that *OH and SO4*� radicals are the dominant ROS for the oxidation of SMX (Details see Supporting Information). 

The produced ROS in the various systems was further probed by the electron paramagnetic resonance (EPR) spectroscopy. In Figure 3G, no signals can be observed in the ZnO + PMS systems and the absence of SO4*� signals in the ZnO + PMS + Vis system collectively corroborate that ZnO is inert for PMS activation. As expected, ZnO@SACo-CN was efficient for PMS activation, as evidenced by the presence of strong DMPO-*OH and DMPO-SO4*� signals in the ZnO@SA-Co-CN + PMS system. Moreover, much stronger EPR signals for *OH and SO4*� radicals can be observed in the ZnO@SA-Co-CN + PMS + Vis system, suggesting the enhanced PMS activation under light irradiation. These results verify that the efficient electron transfer from the ZnO “core” to the SA-Co-CN SACs “shell” has boosted the performance of ZnO@SA-Co-CN for PMS activation. Interestingly, prominent DMPO-O2*� signals emerged in the ZnO@SA-Co-CN + PMS + Vis system (Figure 3H), owing to the enhanced photocatalytic activity of ZnO@SA-Co-CN for reduction of dissolved oxygen (O2+e<sup>�</sup> !O2*� ). In addition, strong TEMP-<sup>1</sup> O2 signals were found in the ZnO@SA-CoCN + PMS + Vis system (Figure 3H), owing to the oxidation of O2*� (O2*� +h +!1O2; O2*� + *OH!1O2+OH� ).[46] Furthermore, the Ov may also contribute to the generation of 1O2 by promoting the decomposition of PMS (Ov+HSO5� ! HSO4� +1O2).[47] To investigate the presence of Ov in the 

ZnO@SA-Co-CN, we tested solid EPR of pure ZnO and ZnO@SA-Co-CN. As shown in Figure 4A, the ZnO@SACo-CN shows much stronger EPR intensity at _g_ = 2.002 as compared with pure ZnO, demonstrating the presence of abundant surface single ionized Ov. Besides, the Ov was also evidenced by the prominent peak at � 531 eV in the O 1s XPS of ZnO@SA-Co-CN (Figure S5C). The presence of more Ov in ZnO@SA-Co-CN certainly improves the lightharvesting and narrows the band gap,<sup>[48]</sup> thereby benefiting the generation of more charge carriers for the photocatalytic process. In addition, the abundant Ov also improves the interface charge transfer and increases the donor density,<sup>[49]</sup> which facilitates the electron transfer from the Ov-rich ZnO core to the surface catalytic sites for PMS activation. Thus, synergies between the Ov-rich ZnO core and the SACs shell collaboratively contributed to the enhanced production of ROS via the photo-Fenton-like reaction. 

To further elucidate the assumptions that efficient electron communications between the ZnO “core” and the SA-Co-CN “shell” has facilitated PMS activation, the charge transfer process between the catalyst and PMS were monitored by the responses of amperometric _i_ – _t_ curves and open circuit voltage (OCP). As shown in Figure S22, the ZnO@SA-Co-CN emerged a strong current signal promptly with the addition of PMS in the electrolyte solution, whereas the current response of ZnO to PMS is sluggish with much lower current intensity, demonstrating the faster and more efficient electron transfer from SA-Co-CN SACs to PMS. Similarly, the ZnO@SA-Co-CN + PMS system exhibits much stronger OCP response than the ZnO + PMS system (Figure S23), which corroborated the accelerated electron transfer from the SA-Co-CN “shell” to PMS. In situ Raman spectroscopy was applied to reveal the surface chemical evolution of ZnO@SA-Co-CN with the addition of PMS and SMX (Figure 4B and 4C). The Raman spectrum of PMS displays three peaks at 887, 984 and 1057 cm<sup>�1</sup> , corresponding to HSO5� , SO42� and HSO4� , respectively.[50] From the magnified view of the Raman spectra (Figure 4B), the peak of O� O bond in PMS (HO� OSO3� ) shifts from 887 to 879 cm<sup>�1</sup> in ZnO@SA-Co-CN + PMS system, owing to the strong interaction between absorbed PMS and the surface active sites of ZnO@SA-Co-CN.<sup>[51]</sup> When SMX was added, the peaks of HSO5� and HSO4� vanished and the signal of SO42� increased, illustrating the efficient electron-transfer process has triggered the break of O� O bonds in PMS (HO� OSO3� ) to produce reactive ROS. 

Theoretical calculations were applied to reveal the electronic structure of the catalysts and the electron transfer processes for PMS activation. The density of states (PDOS) of ZnO (Figure S24) and ZnO@SA-Co-CN (Figure 4D) are similar to each other, mainly contributing from the O 2p and Zn 3d orbitals. For pure SA-Co-CN, C 2p are hybridized with N 2p and Co 3d orbitals, owing to its π-conjugated structure. For the ZnO@SA-Co-CN, C 2p and the adjacent O 2p orbitals of the C� O� Zn linkage also hybridized with the O 2p and Zn 3d orbitals of ZnO at VB, which enabled the fast and efficient electron transfer between ZnO and SA-Co-CN via the C� O-Zn linkage. The Co 3d orbitals across the Fermi level and partially contributed to the CB of 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (7 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 





**_Figure 4._** A) EPR spectra of pure ZnO and ZnO@SA-Co-CN at room temperature. B), C) In situ Raman spectroscopy for the various systems. D) PDOS of pure ZnO and ZnO@SA-Co-CN. Adsorption configuration and energy of PMS on to Co� N4 sites of E) SA-Co-CN and F) ZnO@SA-CoCN. Bader charge of PMS on to Co� N4 sites of G) SA-Co-CN and H) ZnO@SA-Co-CN. 

ZnO@SA-Co-CN, which promotes the electron transportation from the VB to the Co catalytic sites.<sup>[43]</sup> Thus, the tailored electronic structure endows ZnO@SA-Co-CN with efficient electron communications across the heterojunctions. In addition, the PDOS shows that the _d_ -band center ( _ɛ_ d) of Co atom in ZnO@SA-Co-CN is shifted to a higher energy (� 1.09 eV) than that in pure SA-Co-CN (� 1.43 eV). This suggests that more antibonding states of adsorbed intermediates can be pulled above the Fermi level,<sup>[52]</sup> thus enhancing the binding strength betwen the Co single-sites and the absorbed PMS molecule. From the density functional theory (DFT) calculations (Figure 4E and F), the Co� N4 sites of ZnO@SA-Co-CN are evidently more favorable for PMS adsorption with larger absolute value of adsorption energy ( _E_ ad = � 1.98 eV, Figure 4E) than the isolated Co� N4 sites of pure SA-Co-CN ( _E_ ad = � 1.87 eV, Figure 4F). Bader charge analysis of PMS onto the Co� N4 sites (Figure 4G and H) also reveals the more efficient electron transfer from ZnO@SA-Co-CN to PMS, promoting the breakage of the O� O bonds of HSO5� (HO� OSO3) to generate the SO4*� and *OH radicals (HSO5� +e� !SO42� +*OH; HSO5� +e� !SO4*� +OH� ; SO4*� +H2O!*OH+SO4*� 

+SO42� +H +).[53] In general, Ov acted as the “electrons resovior” to increase electron density of the valence band top of ZnO, and the BIEF within the heterojunction will be a “pump” to drive the fast and efficient electron migration in ZnO@SA-Co-CN, thereby boosting generation of the radical species via PMS activation. 

We also compared the catalytic performances of the exposed Co� N4 single sites in pure SA-Co-CN and in ZnO@SA-Co-CN for SMX degradation. As shown in Figure S25, the more sluggish SMX degradation kinetic in the SA-Co-CN + PMS system than in the ZnO@SA-Co-CN + PMS system verifies the higher intrinsic activity of the Co� N4 sites in the ZnO@SA-Co-CN heterostructure than in the SA-Co-CN. In addition, the exposed ZnO supported on SA-Co-CN (ZnO/SA-Co-CN) was also fabricated. Both the SA-Co-CN + PMS + Vis and ZnO/SA-Co-CN + PMS + Vis systems were inefficient for SMX degradation (Figure S25), verifying that the enhanced catalytic performance of ZnO@SA-Co-CN is originate from the unique core–shell heterostructure. Additionally, the fast electron transfer from the photocatalytic ZnO “core” to the SA-Co-CN “shell” accelerated the redox cycle of Co<sup>3+</sup> /Co<sup>2+</sup> of Co� N4 single 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (8 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



atom sites, which can be verified by the Co 2p XPS spectra of the recycled ZnO@SA-Co-CN (Figure S5d), subsequently boosting the photo-Fenton-reactions. From the differential charge distribution analysis (Figure S26), more electrons are inclined to accumulate at the Co atom after the injection of an extra electron, which substantiate the accelerated redox cycle of the Co single sites of ZnO@SA-Co-CN with the help of photo-generated electrons under light irradiation. Thus, the efficient electron communications across the heterojunction as well as the high intrinsic activity of the Co� N4 sites collectively led to the high activity of ZnO@SACo-CN for TrOCs degradation via photo-Fenton-like reactions. 

To study the application of ZnO@SA-Co-CN for practical wastewater treatment, a continuous flow photoFenton reactor was constructed by using a LED light source (Figure 5a). The PMS and the wastewater with catalyst were pumped separately into the continuous flow reactor and exposed to light irradiation to trigger the photo-Fenton-like reaction. The treated water and catalyst were separated by a membrane filter. We evaluated the performance of the continuous flow photo-Fenton system for degradation of rhodamine B (RhB). As shown in Figure 5b, the PMS solution and the red RhB solution were pumped separately into the continuous flow photo-Fenton reactor and exposed to LED light irradiation. It is evident that the red-colored RhB solution gradually became colorless, suggesting rapid oxidation of contaminants through the photo-Fenton-like reaction. As compared with pure ZnO and SA-Co-CN (Figure 5c), ZnO@SA-Co-CN exhibited an enhanced performance for RhB degradation with the removal efficiency maintained � 100% over 300 min of continuous operation. This indicates that more ROS were produced in the ZnO@SA-Co-CN mediated photo-Fenton-like system, leading to constant and efficient oxidation of contaminants in aqueous solution. Thus, it can be concluded that the 



**_Figure 5._** A) Schematic illustration of the continuous flow photo-Fenton reactor. B) Picture of the continuous flow photo-Fenton reactor and its application for wastewater treatment. C) Long-term operation of the continuous flow photo-Fenton for the degradation of RhB. 

ZnO@SA-Co-CN holds great potential for practical wastewater treatment. 

### **_Conclusion_** 

We demonstrated a promising strategy to enhance the performance of SACs by constructing a photocatalyst/SACs core–shell heterostructure. The adjacent SAC and its induced oxygen defects benefit light-harvesting, promote the generation of light-induced charge carriers and improve the charge separation and transportation. Owing to the strong BIEF within the _p_ - _n_ heterojunction, the photo-induced electrons spontaneously transfer from the ZnO core to the SA-Co-CN SACs shell to boost the catalytic performance of the surface exposed Co� N4 sites for heterogeneous catalysis. Results from the optical, electrochemical and fs-TAS analysis corroborated the efficient generation, separation, and transportation of the charge carriers in ZnO@SA-CoCN. Experimental and theoretical calculations confirmed that the Co� N4 sites in ZnO@SA-Co-CN have higher intrinsic catalytic activity than that in the pure SA-Co-CN in PMS activation. As a result, ZnO@SA-Co-CN mediated photo-Fenton-like reactions produced massive ROS (*OH, SO4*� and 1O2), leading to the efficient degradation and mineralization of TrOCs in the aqueous solution. This work opens an avenue for rational design and synthesis of novel SACs-based heterojunctions and establishes a new tactic for enhancing the performance of SACs for heterogeneous catalysis. 

### **_Acknowledgements_** 

X.-L.W. acknowledges the financial support from the Independent Designing Scientific Research Project of Zhejiang Normal University (2020ZS0302), J.C. acknowledges the Key R&D Project of Zhejiang Province (No. 2021C03163). X.D. acknowledges the support from National Computational Infrastructure (NCMAS-2023-78) and Australian Research Council (DE210100253). The authors acknowledge Shenzhen HUASUAN Technology Co. LTD for helping the DFT calculations. Open Access publishing facilitated by The University of Adelaide, as part of the Wiley - The University of Adelaide agreement via the Council of Australian University Librarians. 

### **_Conflict of Interest_** 

The authors declare no conflict of interest. 

### **_Data Availability Statement_** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (9 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



**Keywords:** Core–Shell Heterojunction **·** Fenton-Like Reaction **·** Interfacial Charge Transfer **·** Single-Atom Catalysts **·** Trace Organic Pollutants 

   - [20] X. Zhao, M. Liu, Y. Wang, Y. Xiong, P. Yang, J. Qin, X. Xiong, Y. Lei, _ACS Nano_ **2022** , _16_ , 19959–19979. 

   - [21] S. Park, S. An, H. Ko, C. Jin, C. Lee, _ACS Appl. Mater. Interfaces_ **2012** , _4_ , 3650–3656. 

   - [22] A. M. Katzenmeyer, J. Canivet, G. Holland, D. Farrusseng, A. Centrone, _Angew. Chem. Int. Ed._ **2014** , _53_ , 2852–2856. 

- [1] A. H. Proppe, Y. C. Li, A. Aspuru-Guzik, C. P. Berlinguette, C. J. Chang, R. Cogdell, A. G. Doyle, J. Flick, N. M. Gabor, R. van Grondelle, S. Hammes-Schiffer, S. A. Jaffer, S. O. Kelley, M. Leclerc, K. Leo, T. E. Mallouk, P. Narang, G. S. SchlauCohen, G. D. Scholes, A. Vojvodic, V. W.-W. Yam, J. Y. Yang, E. H. Sargent, _Nat. Rev. Mater._ **2020** , _5_ , 828–846. 

- [2] a) W. Zhang, A. R. Mohamed, W. J. Ong, _Angew. Chem. Int. Ed._ **2020** , _59_ , 22894–22915; b) Y. J. Lai, D. J. Lee, _Chemosphere_ **2021** , _282_ , 131059. 

- [3] Y. X. Ye, J. Pan, F. Xie, L. Gong, S. Huang, Z. Ke, F. Zhu, J. Xu, G. Ouyang, _Proc. Natl. Acad. Sci. USA_ **2021** , _118_ , e2103964118. 

- [4] a) B. Qiu, M. Du, Y. Ma, Q. Zhu, M. Xing, J. Zhang, _Energy Environ. Sci._ **2021** , _14_ , 5260–5288; b) M. Schreier, L. Curvat, F. Giordano, L. Steier, A. Abate, S. M. Zakeeruddin, J. Luo, M. T. Mayer, M. Grätzel, _Nat. Commun._ **2015** , _6_ , 7326. 

- [5] A. Raza, H. Shen, A. A. Haidry, _Appl. Catal. B_ **2020** , _277_ , 119239. 

- [6] H. Wang, R. Niu, J. Liu, S. Guo, Y. Yang, Z. Liu, J. Li, _Nano Res._ **2022** , _15_ , 6987–6998. 

- [7] L. Che, J. Pan, K. Cai, Y. Cong, S.-W. Lv, _Sep. Purif. Technol._ **2023** , _315_ , 123708. 

- [8] G. Zhang, X. Li, M. Wang, X. Li, Y. Wang, S. Huang, D. Chen, N. Li, Q. Xu, H. Li, J. Lu, _Nano Res._ **2023** , _16_ , 6134– 6141. 

- [9] Z. Li, H. Wu, H. Cao, L. Liang, Y. Han, J. Yang, Y. Song, C. Burda, _J. Phys. Chem. Lett._ **2022** , _13_ , 9072–9078. 

- [10] W. He, L. Liu, T. Ma, H. Han, J. Zhu, Y. Liu, Z. Fang, Z. Yang, K. Guo, _Appl. Catal. B_ **2022** , _306_ , 121107. 

- [11] P. Li, X. Zhang, C. Hou, Y. Chen, T. He, _Appl. Catal. B_ **2018** , _238_ , 656–663. 

- [12] F. Chen, X.-L. Wu, C. Shi, H. Lin, J. Chen, Y. Shi, S. Wang, X. Duan, _Adv. Funct. Mater._ **2021** , _31_ , 2007877. 

- [13] a) R. Lang, X. Du, Y. Huang, X. Jiang, Q. Zhang, Y. Guo, K. Liu, B. Qiao, A. Wang, T. Zhang, _Chem. Rev._ **2020** , _120_ , 11986–12043; b) M. Primbs, Y. Sun, A. Roy, D. Malko, A. Mehmood, M.-T. Sougrati, P.-Y. Blanchard, G. Granozzi, T. Kosmala, G. Daniel, P. Atanassov, J. Sharman, C. Durante, A. Kucernak, D. Jones, F. Jaouen, P. Strasser, _Energy Environ. Sci._ **2020** , _13_ , 2480–2500. 

- [14] J. Wang, Z. Li, Y. Wu, Y. Li, _Adv. Mater._ **2018** , _30_ , 1801649. 

- [15] a) W.-H. Lai, Z. Miao, Y.-X. Wang, J.-Z. Wang, S.-L. Chou, _Adv. Energy Mater._ **2019** , _9_ , 1900722; b) J. Zhang, H. Yang, B. Liu, _Adv. Energy Mater._ **2021** , _11_ , 2002473. 

- [16] a) B. Zhang, L. Sun, _Chem. Soc. Rev._ **2019** , _48_ , 2216–2264; b) E. S. Andreiadis, M. Chavarot-Kerlidou, M. Fontecave, V. Artero, _Photochem. Photobiol._ **2011** , _87_ , 946–964. 

- [17] M. Xu, D. Li, K. Sun, L. Jiao, C. Xie, C. Ding, H. L. Jiang, _Angew. Chem. Int. Ed._ **2021** , _60_ , 16372–16376. 

- [18] a) Z. Zhuang, L. Xia, J. Huang, P. Zhu, Y. Li, C. Ye, M. Xia, R. Yu, Z. Lang, J. Zhu, L. Zheng, Y. Wang, T. Zhai, Y. Zhao, S. Wei, J. Li, D. Wang, Y. Li, _Angew. Chem. Int. Ed._ **2023** , _62_ , e202212335; b) H. Murakawa, A. Kanda, M. Ikeda, M. Matsuda, N. Hanasaki, L. Liu, Z. Mei, A. Tang, A. Azarov, A. Kuznetsov, Q.-K. Xue, X. Du, M. Primbs, Y. Sun, A. Roy, D. Malko, A. Mehmood, M.-T. Sougrati, P.-Y. Blanchard, G. Granozzi, T. Kosmala, G. Daniel, P. Atanassov, J. Sharman, C. Durante, A. Kucernak, D. Jones, F. Jaouen, P. Strasser, _Phys. Rev. B_ **2015** , _92_ , 054429. 

- [19] L. Liu, Z. Mei, A. Tang, A. Azarov, A. Kuznetsov, Q.-K. Xue, X. Du, _Phys. Rev. B Phys. Rev. B_ **2016** , _93_ , 235305. 

- [23] H. Li, X. He, Z. Kang, H. Huang, Y. Liu, J. Liu, S. Lian, C. H. A. Tsang, X. Yang, S.-T. Lee, _Angew. Chem. Int. Ed._ **2010** , _49_ , 4430–4434. 

- [24] A. R. Malik, S. Sharif, F. Shaheen, M. Khalid, Y. Iqbal, A. Faisal, M. H. Aziz, M. Atif, S. Ahmad, M. Fakhar-e-Alam, N. Hossain, H. Ahmad, T. Botmart, _J. Saudi Chem. Soc._ **2022** , _26_ , 101438. 

- [25] a) E. T. Vickers, T. A. Graham, A. H. Chowdhury, B. Bahrami, B. W. Dreskin, S. Lindley, S. B. Naghadeh, Q. Qiao, J. Z. Zhang, _ACS Energy Lett._ **2018** , _3_ , 2931–2939; b) Y. Li, X. Liu, J. Li, _J. Rare Earths_ **2010** , _28_ , 571–575. 

- [26] P. Xiao, P. Wang, H. Li, Q. Li, Y. Shi, X.-L. Wu, H. Lin, J. Chen, X. Wang, _J. Hazard. Mater._ **2018** , _345_ , 123–130. 

- [27] W. Bai, S. Li, J. Ma, W. Cao, J. Zheng, _J. Mater. Chem. A_ **2019** , _7_ , 9086–9098. 

- [28] C. Rong, X. Shen, Y. Wang, L. Thomsen, T. Zhao, Y. Li, X. Lu, R. Amal, C. Zhao, _Adv. Mater._ **2022** , _34_ , 2110103. 

- [29] H. Zhang, J. Lin, Z. Li, T. Li, X. Jia, X.-L. Wu, S. Hu, H. Lin, J. Chen, J. Zhu, _Catal. Sci. Technol._ **2019** , _9_ , 502–508. 

- [30] H. Wan, Y. Li, M. Wang, Q. Zhao, Y. Fu, Y. Chen, P. He, L. Wu, Q. Meng, T. Ma, J. Yang, T. Duan, _Chem. Eng. J._ **2022** , _430_ , 133139. 

- [31] C. Zhang, D. Qin, Y. Zhou, F. Qin, H. Wang, W. Wang, Y. Yang, G. Zeng, _Appl. Catal. B_ **2022** , _303_ , 120904. 

- [32] a) D. Shi, M. Yang, B. Zhang, Z. Ai, H. Hu, Y. Shao, J. Shen, Y. Wu, X. Hao, _Adv. Funct. Mater._ **2022** , _32_ , 2108843; b) W. He, L. Liu, T. Ma, H. Han, J. Zhu, Y. Liu, Z. Fang, Z. Yang, K. Guo, _Appl. Catal. B_ **2022** , _306_ , 121107. 

- [33] Y. Lin, C. Yang, S. Wu, X. Li, Y. Chen, W. L. Yang, _Adv. Funct. Mater._ **2020** , _30_ , 2002918. 

- [34] J. Xu, W. Li, W. Liu, J. Jing, K. Zhang, L. Liu, J. Yang, E. Zhu, J. Li, Y. Zhu, _Angew. Chem. Int. Ed._ **2022** , _61_ , e202212243. 

- [35] L. Zhai, X. She, L. Zhuang, Y. Li, R. Ding, X. Guo, Y. Zhang, Y. Zhu, K. Xu, H. J. Fan, S. P. Lau, _Angew. Chem. Int. Ed._ **2022** , _61_ , e202116057. 

- [36] a) S. Gao, X. Wang, C. Song, S. Zhou, F. Yang, Y. Kong, _Appl. Catal. B_ **2021** , _295_ , 120272; b) Y. Xiao, G. Tian, W. Li, Y. Xie, B. Jiang, C. Tian, D. Zhao, H. Fu, _J. Am. Chem. Soc._ **2019** , _141_ , 2508–2515. 

- [37] D. Zhao, Y. Wang, C.-L. Dong, Y.-C. Huang, J. Chen, F. Xue, S. Shen, L. Guo, _Nat. Energy_ **2021** , _6_ , 388–397. 

- [38] L. Jing, R. Zhu, D. L. Phillips, J. C. Yu, _Adv. Funct. Mater._ **2017** , _27_ , 1703484. 

- [39] W. Lei, Y. Mi, R. Feng, P. Liu, S. Hu, J. Yu, X. Liu, J. A. Rodriguez, J.-o. Wang, L. Zheng, K. Tang, S. Zhu, G. Liu, M. Liu, _Nano Energy_ **2018** , _50_ , 552–561. 

- [40] X. Jin, L. Zhang, X. Fan, J. Tian, M. Wang, J. Shi, _Appl. Catal. B_ **2018** , _237_ , 888–894. 

- [41] Z. Wang, J. Fang, Y. Mi, X. Zhu, H. Ren, X. Liu, Y. Yan, _Appl. Surf. Sci._ **2018** , _436_ , 596–602. 

- [42] Y. Liu, J. Shi, C. Li, Z. Niu, X. Du, Z. Liu, X. Yue, _Int. J. Hydrogen Energy_ **2022** , _47_ , 28845–28858. 

- [43] S. Liu, D. Liu, Y. Sun, P. Xiao, H. Lin, J. Chen, X.-L. Wu, X. Duan, S. Wang, _Appl. Catal. B_ **2022** , _310_ , 121327. 

- [44] L.-S. Zhang, X.-H. Jiang, Z.-A. Zhong, L. Tian, Q. Sun, Y.-T. Cui, X. Lu, J.-P. Zou, S.-L. Luo, _Angew. Chem. Int. Ed._ **2021** , _60_ , 21751–21755. 

- [45] H. C. Zhang, Z. X. Kang, J. J. Han, P. Wang, J. T. Fan, G. P. Sheng, _Angew. Chem. Int. Ed._ **2022** , _61_ , e202200093. 

- [46] Y. Nosaka, A. Y. Nosaka, _Chem. Rev._ **2017** , _117_ , 11302–11336. 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (10 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Research Articles_** 



- [47] J. Zhu, Y. Zhu, W. Zhou, _J. Colloid Interface Sci._ **2022** , _610_ , 504–517. 

- [48] W. Jiang, H. Loh, B. Q. L. Low, H. Zhu, J. Low, J. Z. X. Heng, K. Y. Tang, Z. Li, X. J. Loh, E. Ye, Y. Xiong, _Appl. Catal. B_ **2023** , _321_ , 122079. 

   - [52] J. Yu, J. Li, C.-Y. Xu, Q. Li, Q. Liu, J. Liu, R. Chen, J. Zhu, J. Wang, _Nano Energy_ **2022** , _98_ , 107266. 

   - [53] C. Guo, C. Chen, J. Lu, D. Fu, C.-Z. Yuan, X.-L. Wu, K. N. Hui, J. Chen, _J. Colloid Interface Sci._ **2021** , _599_ , 219–226. 

- [49] S. Cai, L. Wang, S. Heng, H. Li, Y. Bai, D. Dang, Q. Wang, P. Zhang, C. He, _J. Phys. Chem. C_ **2020** , _124_ , 24566–24579. 

- [50] M. Ding, W. Chen, H. Xu, Z. Shen, T. Lin, K. Hu, C. h. Lu, Z. Xie, _J. Hazard. Mater._ **2020** , _382_ , 121064. 

- [51] W. Ren, G. Nie, P. Zhou, H. Zhang, X. Duan, S. Wang, _Environ. Sci. Technol._ **2020** , _54_ , 6438–6447. 

Manuscript received: April 22, 2023 Accepted manuscript online: May 30, 2023 Version of record online: June 20, 2023 

_Angew. Chem. Int. Ed._ **2023** , _62_ , e202305639 (11 of 11) 

© 2023 The Authors. Angewandte Chemie International Edition published by Wiley-VCH GmbH 

