# Vertical organic electrochemical transistors for complementary circuits

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 389 |
| 作者 | Wei Huang, Jianhua Chen, Yao Yao, Ding Zheng, Xudong Ji, Liang-Wen Feng, David C. Moore, Nicholas Glavin et al. |
| DOI | 10.1038/s41586-022-05592-2 |
| 源文件 | 031_Huang_2023_Vertical-organic-electrochemical-transistors-for.pdf |

---
# Article **Vertical organic electrochemical transistors for complementary circuits** 

|https://doi.org/10.1038/s41586-022-05592-2<br>Received: 5 July 2021<br>Accepted: 24 November 2022|**Wei Huang**<sup>**1,2,12** ✉</sup>**, Jianhua Chen**<sup>**2,3,4,12**</sup>**, Yao Yao**<sup>**2,5,6,12**</sup>**, Ding Zheng**<sup>**2** ✉</sup>**, Xudong Ji**<sup>**7**</sup>**, Liang-Wen Feng**<sup>**2,8**</sup>**,**<br>**David Moore**<sup>**9**</sup>**, Nicholas R. Glavin**<sup>**9**</sup>**, Miao Xie**<sup>**1**</sup>**, Yao Chen**<sup>**2**</sup>**, Robert M. Pankow**<sup>**2**</sup>**,**<br>**Abhijith Surendran**<sup>**7**</sup>**, Zhi Wang**<sup>**2,10**</sup>**, Yu Xia**<sup>**11**</sup>**, Libing Bai**<sup>**1**</sup>**, Jonathan Rivnay**<sup>**7**</sup>**, Jianfeng Ping**<sup>**5,6**</sup>**,**<br>**Xugang Guo**<sup>**4**</sup>**, Yuhua Cheng**<sup>**1** ✉</sup>**, Tobin J. Marks**<sup>**2** ✉</sup>**& Antonio Facchetti**<sup>**2,11** ✉</sup>|
|---|---|
|Published online: 18 January 2023||
|Open access|Organic electrochemical transistors (OECTs) and OECT-based circuitry offer great<br>i|
|Check for updates|potential in bioelectronics, wearable electronics and artificial neuromorphic<br>electronics because of their exceptionally low driving voltages (<1 V), low power<br>consumption (<1 µW), high transconductances (>10 mS) and biocompatibility<sup>1–5</sup>.<br>However, the successful realization of critical complementary logic OECTs is<br>currently limited by temporal and/or operational instability, slow redox processes<br>and/or switching, incompatibility with high-density monolithic integration and<br>inferior n-type OECT performance<sup>6–8</sup>. Here we demonstrate p- and n-type vertical<br>OECTs with balanced and ultra-high performance by blending redox-active<br>semiconducting polymers with a redox-inactive photocurable and/or photopatternable<br>polymer to form an ion-permeable semiconducting channel, implemented in a simple,<br>scalable vertical architecture that has a dense, impermeable top contact. Footprint<br>current densities exceeding 1 kA cm<sup>−2</sup>at less than ±0.7 V, transconductances of 0.2–0.4 S,<br>short transient times of less than 1 ms and ultra-stable switching (>50,000 cycles) are<br>achieved in, to our knowledge, the first vertically stacked complementary vertical OECT<br>logic circuits. This architecture opens many possibilities for fundamental studies of<br>organic semiconductor redox chemistry and physics in nanoscopically confined<br>spaces, without macroscopic electrolyte contact, as well as wearable and implantable<br>device applications.|



Organic electrochemical transistors (OECTs) are attractive for bioelectronics, wearable electronics and neuromorphic electronics because of their low driving voltage, low power consumption, high transconductance and facile integration in mechanically flexible platforms<sup>1–3,5,9–11</sup> . However, further OECT advances face challenges. (1) Despite progress<sup>8</sup> , poor electron-transporting (n-type) OECT performance versus their hole-transporting (p-type) counterparts (approximately 1,000 times lower transconductance and/or current density)<sup>6,7,12</sup> , hinders the development of complementary logic and sensitivity to in vivo relevant analyte cations (for example, Na<sup>+</sup> , K<sup>+</sup> , Ca<sup>2+</sup> , Fe<sup>3+</sup> and Zn<sup>2+</sup> ) for biosensor development. (2) Temporal and/or operational instability hinders all possible applications. (3) Unbalanced p-type and n-type OECT performance prevents integration into complementary circuits<sup>13,14</sup> . (4) Slow redox processes lead to sluggish switching. (5) State-of-the-art conventional OECTs (cOECTs), having planar source–drain electrode architectures, require small channel lengths ( _L_ ) of at most 10 µm, along with precisely patterned semiconducting layers and electrode 

coatings with passive materials, for high transconductance ( _g_ m) and fast switching (approximately in the millisecond range)<sup>15</sup> , requiring complex fabrication methodologies<sup>15,16</sup> . Note that conventional photolithography can only reliably realize features or _L_ larger than 1 µm (ref.<sup>16</sup> ), and although printing and laser cutting offer simplified cOECT fabrication, this is at the expense of performance<sup>17–19</sup> . Moreover, to increase _g_ m, OECTs typically use thick semiconducting films, inevitably compromising switching speeds because high _g_ m values require efficient ion exchange between the electrolyte and the bulk semiconductor<sup>20</sup> . Consequently, without progress in materials design, particularly for n-type semiconductors, and the realization of new device architectures, OECT applications will remain limited in scope. 

In this report, we demonstrate high-performance p- and n-type OECTs and complementary circuits by using a vertical device architecture (vertical OECT, hereafter named vOECT) readily fabricated by thermal evaporation and masking of impermeable and dense Au source–drain electrodes and spin-coating and photopatterning of an ion-conducting 

> 1School of Automation Engineering, University of Electronic Science and Technology of China (UESTC), Chengdu, China. 2Department of Chemistry and the Materials Research Center, Northwestern University, Evanston, IL, USA.<sup>3</sup> Department of Chemical Science and Technology, Yunnan University, Kunming, China.<sup>4</sup> Department of Materials Science and Engineering and the Shenzhen Key Laboratory for Printed Organic Electronics, Southern University of Science and Technology (SUSTech), Shenzhen, China.<sup>5</sup> School of Biosystems Engineering and Food Science, Zhejiang University, Hangzhou, China.<sup>6</sup> Innovation Platform of Micro/Nano Technology for Biosensing, ZJU-Hangzhou Global Scientific and Technological Innovation Center, Hangzhou, China. 7Department of Biomedical Engineering, Northwestern University, Evanston, IL, USA. 8College of Chemistry, Sichuan University, Chengdu, China. 9Air Force Research Laboratory, Materials and Manufacturing DirectorateWPAFB, Ohio, OH, USA.<sup>10</sup> School of Materials Science and Engineering, North University of China, Taiyuan, China.<sup>11</sup> Flexterra Inc. 8025 Lamon Avenue, Skokie, IL, USA. 

> 12These authors contributed equally: Wei Huang, Jianhua Chen, Yao Yao. ✉ e-mail: whuang@uestc.edu.cn; ding-zheng@northwestern.edu; yhcheng@uestc.edu.cn; t-marks@northwestern.edu; a-facchetti@northwestern.edu 

**496** | Nature | Vol 613 | 19 January 2023 



<!-- Start of picture text -->
a Ag/AgCl<br>(i) Au (ii) (iii) Au (iv)<br>Substrate Semiconductor PBS<br>b<br>R1 gDPP-g2T (p type) R3 OR3 c Ag/AgCl d e<br>S N O R2 O O Cin-CellOR3 gDPP-g2T:Cin-Cell Bottom Top Height 20.0 nm<br>S S R3O R3O O Au PBS Au Au<br>O NR1 S R2 n R3O RO3O n OR3 Substrate 200 μm 200 nm –20.0 nm<br>R1 Homo-gDPP (n type) Cell UV<br>S N O Ph O L gDPP-g2T:Cin-Cell Phase 80.0º<br>Ph d<br>S<br>O N n Cross-linked Cin-CellO Cell W<br>R1 = * RO1 O O O O R3 = Ph O 500 nm 200 nm –70.0º<br>O O and H<br>R2 = * O O * *<br><!-- End of picture text -->

**Fig. 1 | Fabrication scheme and vOECT materials used. a** , Fabrication process for vOECTs: thermal evaporation of the bottom source electrode with a shadow mask (i), spin-coating and photopatterning of the semiconducting polymer + Cin-Cell blend (ii), thermal evaporation of the top drain electrode with a shadow mask (iii) and application of phosphate buffer solution (PBS) electrolyte and Ag/AgCl gate electrode (iv). **b** , Chemical structures of the redox-active semiconducting polymers (gDPP-g2T (p-type); Homo-gDPP (n-type)), and the 

redox-inactive cross-linkable polymer (Cin-Cell, cross-linking occurs through a photo-induced 2 + 2 cycloaddition reaction). **c** , Cross-section illustration of p-type vOECTs, along with a false-coloured cross-section SEM image showing the phase-separated layer sandwiched between two dense Au electrodes. **d** , Optical image of a p-type vOECT, in which the electrode overlapping area is enlarged ( _W_ = _L_ = 70 µm). **e** , AFM height and phase images of gDPP-g2T:Cin-Cell blends. In all samples, the gDPP-g2T:Cin-Cell weight ratio is 9:2. 

semiconductor channel. The vOECT fabrication process is illustrated in Fig. 1a and details can be found in the Methods. The key to this process is the use of a redox-active p-type (gDPP-g2T) or n-type (Homo-gDPP) semiconducting polymer blended with a redox-inert and photocurable polymer component (cinnamate-cellulose polymer (Cin-Cell)) as the OECT channel (see the structures in Fig. 1b, the synthesis process in the Methods and Extended Data Fig. 1). On the basis of the control experiments (vide infra) the optimal semiconducting polymer:Cin-Cell weight ratio was found to be 9:2. A vOECT geometry cross-section and selected optical and scanning electron microscopy (SEM) images (Fig. 1c,d) indicate that the channel length ( _L_ ) is the semiconductor layer thickness (approximately 100 nm), the widths of the bottom and the top electrodes define the channel width ( _W_ ) and the nominal depth ( _d_ ) of the semiconductor, respectively. cOECTs and vOECTs that use polymers without ion-conducting ethylene glycol side chains were also fabricated as controls; their performance is marginal (Extended Data Fig. 2). 

Before evaluation of the device, the morphology and microstructure of the semiconducting polymer:Cin-Cell blend were characterized. As shown in Extended Data Fig. 3a,b, the pristine gDPP-g2T and HOMO-gDPP films are continuous and smooth (root-mean-square roughness, _σ_ r.m.s. ≈ 1 nm), whereas both polymer blends with Cin-Cell are rougher after ultraviolet (UV) cross-linking/patterning ( _σ_ r.m.s. ≈ 3 nm) with evidence of phase separation in atomic force microscopy (AFM) (Fig. 1e), in which the Cin-Cell forms pillar-like structures that should enhance the structural robustness and stability. Thus, the Cin-Cell in the semiconducting matrix acts not only as a photopatterning component of the channel, but, most importantly, as an OECT structural stabilizer (vide infra). The two-dimensional grazing incidence wide-angle X-ray scattering (2D–GIWAXS, Extended Data Fig. 3c–e) patterns of the pure polymer and polymer:Cin-Cell mixture films are similar, corroborating phase separation and demonstrating that Cin-Cell addition does not 

substantially alter the overall film texturing and the polymer chain order. 

Next, the vOECTs and cOECTs were tested and the performance parameters were extracted following standard procedures (Extended Data Table 1)<sup>7,21</sup> . Before discussing the results, note that control vOECTs based on semiconducting polymers without ethylene glycol side chains exhibit a negligible transistor response, demonstrating that the hydrophilic ion-complexing polymer facilitates ion penetration across the nanoscopic thin electrolyte-blend interface (Extended Data Fig. 2b,c). Furthermore, the performance of control vOECTs with varying Cin-Cell weight contents indicate (Extended Data Fig. 2d–g) that the device yield without Cin-Cell is low and, most importantly, that such devices are unstable after very few repeated gate voltage ( _V_ G) cycles, mainly reflecting top electrode delamination, whereas those that use a semiconducting polymer:Cin-Cell weight ratio of more than 9:2 exhibit poor performance (low current on ( _I_ ON) and large hysteresis), because of reduced redox-active polymer content and constricted ion diffusion. Consequently, all of the data reported here are for cross-linked semiconducting polymer:Cin-Cell blends with a 9:2 weight ratio. 

The vOECT and cOECT transfer characteristics and the corresponding _g_ m–subthreshold swing (SS) plots (Fig. 2a–d and Extended Data Fig. 4) demonstrate extraordinary performances for both p- and n-type vOECTs, achieving maximum drain currents ( _I_ ON) of (8.2 ± 0.5) × 10<sup>−2</sup> A (drain voltage ( _V_ D) = −0.5 V, _V_ G = −0.5 V) and (2.5 ± 0.1) × 10<sup>−2</sup> A ( _V_ D = +0.5 V, _V_ G = +0.7 V), and _g_ m values as high as 384.1 ± 17.8 mS and 251.2 ± 7.6 mS, respectively (Fig. 2e). Note that despite the ultra-small channel lengths ( _L_ ≈ 100 nm), the _I_ ON/current off ( _I_ OFF) ratios of both devices are impressive (≥10<sup>6</sup> ), exclusively due to the higher _I_ ON and low _I_ OFF. All of the p- and n-type vOECTs retain stable turn-on voltages ( _V_ ON) of +0.10 and +0.21 V as well as SS values of approximately 60 and approximately 62 mV per decade, respectively, upon scanning _V_ D from ±0.1 to ±0.5 V. More relevant parameters for vertical architectures 

Nature | Vol 613 | 19 January 2023 | **497** 

## Article 



<!-- Start of picture text -->
a b 200 120 c d 200 120<br>V D = V D = V D =<br>10 –2 –0.1 V 10 –2 0.1 V 0.1 V<br>10 –3 –0.2 V–0.3 V 150 90 10 –3 0.2 V0.3 V 150 0.2 V0.3 V 90<br>10 –4 –0.4 V–0.5 V 10 –4 0.4 V0.5 V 0.4 V0.5 V<br>10 –5 100 V D = 60 10 –5 100 60<br>10 –6 –0.1 V 10 –6<br>–0.2 V<br>10 –7 I G 50 –0.3 V–0.4 V 30 10 –7 I G 50 30<br>10 –8 –0.5 V 10 –8<br>10 –9 0 0 10 –9 0 0<br>–0.4 –0.2 0 0.2 –0.4 –0.2 0 0 0.2 0.4 0.6 0.3 0.4 0.5 0.6 0.7<br>V GS (V) V GS (V) V GS (V) V GS (V)<br>e 10 3 f g h<br>p type Vertical<br>10 7 This work 10 7 cOECT<br>10 2 n type<br>10 6 This work 10 6 W<br>10 1<br>10 5 10 5 L<br>10 0 10 4 Vertical 10 4 vOECT<br>10 –1 p type 10 3 Planar 10 3 Planar d<br>This work p type<br>10 –2 n type 10 2 10 2 This work W<br>This work n type<br>This work Substrate Au<br>10 1 10 1<br>10 –3<br>10 0 10 2 10 4 10 –4 10 –2 10 0 10 2 10 –1 10 0 10 1 10 2 10 3 Semiconductor<br>Wd/L  (μm) g m,A (μS μm –2 ) I ON,A (A cm –2 )<br> (A) l –DS  (mS) g m  (A) l DS  (mS) g m<br>SS (mV per decade) SS (mV per decade)<br> (mS) g m / II ONOFF / I ONOFF<br><!-- End of picture text -->

**Fig. 2 | OECT performance and comparison with literature data. a** – **d** , Representative transfer characteristics ( **a** , **c** ) and corresponding _g_ m and SS curves ( **b** , **d** ) of p-type gDPP-g2T ( _W_ = _d_ = 30 µm) ( **a** , **b** ) and n-type Homo-gDPP ( _W_ = _d_ = 50 µm) ( **c** , **d** ) vOECTs. ( _L_ ≈ 100 nm). **e** , _g_ m as a function of _Wd/L_ for the present vOECTs and cOECTs as well as the previously reported OECTs<sup>7,8,14,15,21,23–32</sup> . Comparisons of current on/off ratio ( _I_ ON/ _I_ OFF) versus _g_ m per unit area ( _g_ m,A) 

( **f** ) and on-current per unit area ( _I_ ON,A) ( **g** ) for different v- and cOECTs. Note, different asterisks are data of this work based on different _W_ and _d_ (Extended Data Table 1). **h** , Cartoon illustrating how the _g_ m,A and _I_ ON,A are calculated, where _g_ m,A = _g_ m/( _WL_ ), _I_ ON,A = _I_ ON _/(WL_ ) for cOECT, whereas _g_ m,A = _g_ m/( _Wd_ ), _I_ ON,A = _I_ ON/( _Wd_ ) for vOECT. 

are the area-normalized _g_ m ( _g_ m,A) and _I_ ON ( _I_ ON,A) metrics<sup>22</sup> . As shown in Fig. 2f,g, _g_ m,A ( _I_ ON,A) values as high as 226.1 µS µm<sup>−2</sup> (4,036 A cm<sup>−2</sup> ) and 112.4 µS µm<sup>−2</sup> (1,015 A cm<sup>−2</sup> ) are achieved for p- and n-type vOECTs, respectively. These values are about 18 times (13 times) and 100 times (1,000 times) greater than those measured in the corresponding p- and n-type cOECTs, respectively (Extended Data Table 1). Thus, the present p-type vOECTs exhibit, to our knowledge, the highest _g_ m,A and _I_ ON,A values reported up until now, even surpassing those of heavily doped and/ or depletion-mode poly(3,4-ethylenedioxythiophene):polystyrene sulfonate (PEDOT:PSS) cOECTs. In addition, to our knowledge, the present n-type vOECT performance surpasses all previously reported OECTs (including p-type OECTs) in terms of _g_ m,A and _I_ ON/ _I_ OFF(refs.<sup>7,8,14,15,21,23–32</sup> ). Importantly, the present vOECT structures also have reduced footprints because the contacting lines also function as source and drain contacts, eliminating the need for extra source–drain pads overlapping with the channel materials that are required in cOECTs. This vertical architecture and blending strategy with the Cin-Cell is also applicable to other mixed ionic-electronic semiconductors, with the vOECTs based on two p-type (Pg2T-T and PIBET-AO) and two n-type (polyethylene glycol-N2200 (PEG-N2200) and BTI2) polymers exhibiting similarly enhanced transistor performance versus their planar counterparts (Extended Data Fig. 5). 

To our knowledge, there are no examples of truly vertical electrochemical devices in which transistor behaviour is observed throughout the entire semiconductor bulk by using ion-impermeable contacts. Previously reported pioneering organic transistor architectures with vertical source–drain arrangements functioned as OECTs only when using permeable (for example, Ag nanowires) electrodes<sup>22,26,33</sup> , or when operated as electrical double-layer transistors or field-effect transistors. Therefore, bulk ion penetration and redox reactions are not involved, and only a small semiconductor volume under the top contact 

functions as the charge-carrying channel<sup>34–38</sup> . In contrast, the present approach uses simple thermal evaporation of dense and thick (150 nm) Au electrodes through a shadow mask, in combination with a photopatternable semiconductor layer, to create a structure with excellent ion intercalation. By using a semi-transparent Au top electrode (Extended Data Fig. 6a–c), Supplementary Video 1 demonstrates that the electrochromic switch associated with the redox chemistry encompasses the entire semiconductor area between the top and bottom electrodes and is not confined to the two narrow regions of the semiconductor that are in direct contact with the electrolyte. Evidence for bulk doping is further supported by the following observations: (1) _I_ ON and _g_ m of the vOECTs with different top electrode widths but identical bottom electrode widths, thus meaning an equal electrolyte–semiconductor interfacial area but a different semiconductor area or mass available for doping or de-doping, increase linearly (Extended Data Fig. 6d–f), illustrating that doping is not limited to the semiconductor–electrolyte interface. (2) Depletion-mode PEDOT:PSS vOECTs exhibit excellent switching behaviour and can be efficiently turned off (Extended Data Fig. 6g), which would be impossible if only interfacial redox chemistry was occurring in the vOECTs. (3) The measured saturation _I_ ON values of the present vOECTs would carry unreasonably large electrical current densities (>10<sup>7</sup> A cm<sup>−2</sup> ) if the channel were only few nanometres thick, as in typical electrical double-layer transistors. (4) Finally, devices based on very hydrophobic blends, which do not support ion intercalation across the nanoscopic interface, are non-functional (vide supra, Extended Data Fig. 2c). 

The present vOECTs also exhibit good transistor behaviour even when operated at a _V_ D of only ±0.001 V (Extended Data Fig. 7a,b). Note, especially for the n-type vOECTs, _V_ ON shifts from +0.43 to +0.21 V when _V_ D is only increased from +0.001 to +0.1 V because of the drain-induced barrier lowering, which is a short channel effect<sup>22</sup> . For n-type cOECTs 

**498** | Nature | Vol 613 | 19 January 2023 



<!-- Start of picture text -->
a b<br>10 –2<br>10 –2<br>10 –3<br>10 –3<br>10 –4<br>10 –4<br>10 –5<br>10 –5<br>10 –6<br>10 –6<br>10 –7<br>0 300.0 3,970.0 3,970.5 4,600.0 5,000.0 0 300.0 3,990.0 3,990.5 4,700.0 5,000.0<br>Time (s) Time (s)<br>c e g<br>10 f C ≈ 500 Hz Test 80<br>10 2<br>10 6 Fitting<br>86 425 τON =μs VV DG = –0.5 V = –0.5 V 10 5 60<br>40<br>4<br>τOFF = 10 1 10 4 R/C 20<br>2 85 μs<br>0 10 3 Substrate W 0<br>0.01 0.02 10 0 10 1 10 2 10 3 10 4 10 –1 10 0 10 1 10 2 10 3 10 4 10 5<br>Time (s) Frequency (Hz) Frequency (Hz)<br>d 6 f h 80<br>f C ≈ 1,200 Hz 10 6 Test<br>5 10 2 Fitting 60<br>4 366 τON =μs V D = 0.5 V 10 5<br>3 V G = 0.7 V 40<br>2<br>τOFF = 10 4 C 20<br>1 45 μs 10 1 R s<br>0 R ct W 0<br>10 3<br>0.01 0.02 10 0 10 1 10 2 10 3 10 4 10 –1 10 0 10 1 10 2 10 3 10 4 10 5<br>Time (s) Frequency (Hz) Frequency (Hz)<br> (A) –I D  (A) I D<br>Ω |Z|  ()<br> (mA) –I DA (mS) g m –Phase (º)<br> (mA) I DS (mS) g m Ω |Z|  () –Phase (º)<br><!-- End of picture text -->

**Fig. 3 | vOECT stability, switching time and frequency-dependent transconductance (bandwidth) characteristics. a** – **d** , Cycling stability (cycling frequency of 10 Hz) ( **a** , **b** ) and transient response ( **c** , **d** ) of p-type gDPP-g2T ( **a** , **c** ) and n-type Homo-gDPP ( **b** , **d** ) vOECTs, where _V_ D = −0.1 V, _V_ G is switching between 0 V and −0.5 V for the p-type vOECT, and _V_ D = +0.1 V, _V_ G is switching between 0 V and +0.7 V for the n-type vOECT. Note, for both vOECTs, _W_ = _d_ = 30 µm, _L ≈_ 100 nm. **e** , **f** , Frequency-dependence of the small signal 

transconductance of p-type gDPP-g2T ( **e** ) and n-type Homo-gDPP ( **f** ) vOECTs, where the bias status is indicated in the figure and an additional 10 mV peak-to-peak gate voltage oscillation is applied (error bars represent s.d. for _n_ = 6). **g** , **h** , EIS of vertical configuration (| _Z_ |) ( _W_ = _d_ = 30 µm, _L ≈_ 100 nm) based on p-type gDPP-g2T:Cin-Cell ( **g** ) and Homo-gDPP:Cin-Cell ( **h** ). The insets in **g** and **h** are the EIS measurement setup ( **g** ) and the equivalent circuit (2R1C behavior) ( **h** ). 

reported in the literature, and here specifically for Homo-gDPP cOECT control (Extended Data Fig. 4h), the energetic mismatch between the n-type semiconductor LUMO level and the Au electrode work function results in a very high VON (>+0.4 V), and the limited electrochemical window of the aqueous electrolyte prevents the application of large _V_ G biases. This is one of the key limitations of current n-type cOECTs<sup>39</sup> and it is where drain-induced barrier lowering plays a key role in the n-type vOECT performance enhancement seen here. Common issues of short channel transistors, such as loss of saturation<sup>40</sup> , _V_ T roll-off and reduced current modulation<sup>22</sup> , which are equally as important, are absent in the vOECTs (Fig. 2 and Extended Data Fig. 7c,d). This result is possible only if the redox processes modulate the carrier concentration of the entire semiconducting layer<sup>2,41</sup> . The low SS of approximately 60 mV per decade measured for both vOECTs (Fig. 2b,d) provides more convincing proof of the extremely effective gating in the present vertical architecture. Furthermore, unlike cOECTs in which the region with SS approximately 60 mV per decade, if achieved, is narrow (Extended Data Fig. 4g,h), the present vOECTs have a very wide subthreshold region (0.0 ≈ −0.2 V for gDPP-g2T and +0.3 ≈ +0.6 V for Homo-gDPP) with SS near or equalling the approximately 60 mV per decade thermal limit. The wide subthreshold region is particularly useful for applications in which high voltage gain and low power consumption are vital<sup>42,43</sup> . 

The cycling stability along with the transient response of the OECTs were next assessed. As shown in Fig. 3a,b, for both p- and n-type vOECTs, 

more than 50,000 stable switching cycles are recorded, which is an order of magnitude higher than for literature values of OECTs, especially for n-type devices<sup>21,44</sup> . Note that the stability of the ubiquitous PEDOT:PSS in depletion-mode vOECTs is also greatly stabilized compared to that in cOECT architectures (Extended Data Fig. 7e,f). Furthermore, the vOECT turn-on transient time ( _τ_ ON) is less than 0.5 ms for both devices (Fig. 3c,d), and is comparable to those of the corresponding precisely patterned cOECTs (Extended Data Fig. 7g,h). 

To validate the fast switching process and to understand the underlying mechanism, bandwidth and electrochemical impedance spectroscopy (EIS) measurements for both cOECTs and vOECTs were carried out (Fig. 3e,f and Extended Data Figs. 7i and 8). Cut-off frequencies ( _f_ c) of approximately 500 and approximately 1,200 Hz are measured for p- and n-type vOECTs, respectively, which are consistent with the transient responses in Fig. 3c, whereas the EIS based on the vertical configuration also exhibits typical 2R1C behaviour as that in standard two-electrode configurations (Fig. 3g,h and Extended Data Fig. 8a–c). Moreover, vOECTs with different semiconductor film thicknesses were also fabricated and the transient responses were accessed (Extended Data Fig. 8d). As the film thickness (that is, the vOECT channel length) increases from 100 to 400 nm, _τ_ ON and _τ_ OFF increase from 425 µs and 85 µs (100 nm) to 32.6 ms and 966 µs (400 nm), respectively, showing that the confined electric field in the channel is the key for the fast transient response (Supplementary 

Nature | Vol 613 | 19 January 2023 | **499** 



<!-- Start of picture text -->
Article<br>a b e<br>Bottom<br>Au<br>n-type V IN<br>OSC V DD<br>p-typeOSC PBS GND Top Au<br>Middle  V OUT<br>V OUT Au<br>GND 1 mm<br>200 μm<br>V DD<br>c 0.7 150 d f<br>0.7<br>0.8 V DD = 0.7 V,  f  = 17.7 Hz<br>0.6<br>0.6<br>0.5 100 0.5 0.6<br>0.4 0.4<br>0.4<br>0.3 0.3<br>0.2 50 0.2 0.2<br>0.1<br>0.1<br>0<br>0<br>0 0<br>0.3 0.4 0.5 0.6 0.7 0 200.0 460.1 460.3 2,800.0 3,000.0 0.1 0.3 0.5 0.7<br>V IN (V) Time (s) Time (s)<br>g h j<br>V DD V DD<br>V IN+<br>V IN-A<br>V OUT V OUT GND<br>V OUT<br>V IN-B<br>V IN-A V IN-B<br>GND 1 mm GND 1 mm V IN– 1 mm<br>i 0.7 k 0.35<br>V IN-A (V)<br>0.0<br>0<br>0.7<br>V IN-B (V)<br>0 –0.35<br>0.6 0.35<br>0.4<br>0.2<br>0<br>0.6<br>0.4<br>0.2 0<br>0<br>0 0.5 1.0 1.5 2.0 2.5 0 2 4 6 8 10<br>Time (s) Time (s)<br> (V) V OUT  (V) V OUT  (V) V OUT<br>Gain (V/V)<br> (V) V IN<br>NAND  (V) V OUT<br> (V) V OUT<br>NOR<br> (V) V OUT<br><!-- End of picture text -->

**Fig. 4 | Vertically stacked complementary circuits based on vOECTs. a** , Illustration of a VSCI based on vOECTs (OSC = organic semiconductor). **b** , Top view of the VSCI, for which the Au electrode locations are indicated. **c** , Voltage output characteristics of the VSCI, along with the voltage gain. **d** , Switching stability of the VSCI with a switching frequency of 10 Hz. **e** , **f** , Photograph of a five-stage ring oscillator ( **e** ) and the corresponding output characteristics ( **f** ). 

**g** – **i** , Photograph of NAND ( **g** ) and NOR ( **h** ) circuits, and the corresponding voltage input/output characteristics ( **i** ). **j** , Photograph of a rectifier and the corresponding output characteristics ( **k** ). Note, in photographs **g** , **h** and **i** , the electrolyte and Ag/AgCl are omitted to provide a better view of the channel areas. 

Video 2). On the basis of these results, it is fast bulk redox instead of interfacial doping near the semiconductor–electrolyte interface that is established, in which the short channel length leads to a strong electric field in the channel that effectively enhances the ion drift velocity, thereby leading to fast doping. Consequently, even in vOECTs for which the ion diffusion length is greater than 15 µm, the vOECT response times are amongst the shortest of the known 

n-type OECTs and are comparable to current state-of-the-art p-type OECTs, without extensive vOECT electrolyte or electrode patterning optimization<sup>7,8,14,15,21,23–29,45</sup> . 

So far, complementary logic has not been demonstrated for any type of vertical organic transistor architecture, mainly because of immaturity of the fabrication processes<sup>22</sup> . Here vertically stacked complementary inverters (VSCIs) are possible because of the unique vOECT 

**500** | Nature | Vol 613 | 19 January 2023 

operation mechanism, simple fabrication process and high stability of the present devices. Figure 4a shows a schematic of the VSCI, in which the n-type vOECT is located directly on top of the p-type vOECT. Such three-dimensional geometries enable much higher integration densities that require a 50% smaller footprint per inverter (Fig. 4b). The voltage output characteristics indicate that the VSCI possesses a sharp voltage transition with a gain of up to approximately 150 (driving voltage = +0.7 V, Fig. 4c) and is stable for more than 30,000 switching cycles (Fig. 4d), further corroborating the excellent stability of both the n-type and p-type vOECTs. Thus, the present VSCI can also be used as an effective ion sensor over a wide concentration range (1 µM to approximately 0.1 M of KCl aqueous solution, Extended Data Fig. 8e,f), for which the transition voltage of the inverter can be effectively modulated to near half of voltage drain drain, _V_ DD/2. 

In addition, a five-stage ring oscillator was fabricated based on the present VSCI (Fig. 4e and Extended Data Fig. 9), and the output signal begins to oscillate between 0.0 and +0.7 V at a frequency of 17.7 Hz ( _V_ DD = +0.7 V, Fig. 4f). This corresponds to a propagation delay of approximately 5.6 ms for each inverter. Finally, NAND and NOR logic gates operating between 0.0 and +0.7 V (Fig. 4g–i and Extended Data Fig. 9) as well as a VSCI-based rectifier (0.35 V amplitude, Fig. 4j,k and Extended Data Fig. 9) were fabricated, demonstrating a versatile library of circuitry elements. Note that previous cOECT-based ring oscillators, NANDs and NORs were fabricated with unipolar p-type cOECTs<sup>17,46–48</sup> , whereas complementary circuits were limited at the preliminary stage of an inverter because of the low performance of the n-type cOECTs<sup>12,14</sup> . Thus, the present vOECTs enable not only VSCIs, which far outperform the corresponding state-of-the-art cOECT inverters<sup>17,49,50</sup> , but they also facilitate the integration of this electrochemical technology into more complex complementary electronics. 

In summary, this work reports vOECTs that demonstrate unprecedented performances for both p- and n-type operation modes. The device architecture demonstrated here is enabled by the synthesis of new electro-active and ion-permeable semiconducting polymers and by the interface engineering of electro-active blend layers. The devices are accessible by conventional fabrication processes and provide high fidelity and stable performance characteristics. They open up opportunities for fundamentally new system designs in diverse applications including low-cost diagnostics, brain-machine interfaces, implantable and wearable devices, prosthetics and intelligent soft robotics, for which small effective footprints along with high _g_ m and low driving voltage metrics are essential requirements. Moreover, vOECTs offer a new design paradigm for flexible and stretchable complementary devices and related logic circuits. 

9. Kim, J. H., Kim, S. M., Kim, G. & Yoon, M. H. Designing polymeric mixed conductors and their application to electrochemical-transistor-based biosensors. _Macromol. Biosci._ **20** , e2000211 (2020). 

10. Spyropoulos, G. D., Gelinas, J. N. & Khodagholy, D. Internal ion-gated organic electrochemical transistor: a building block for integrated bioelectronics. _Sci. Adv._ **5** , eaau7378 (2019). 

11. Yang, A. et al. Fabric organic electrochemical transistors for biosensors. _Adv. Mater._ **30** , e1800051 (2018). 

12. Sun, H. D., Gerasimov, J., Berggren, M. & Fabiano, S. n-Type organic electrochemical transistors: materials and challenges. _J. Mater. Chem. C_ **6** , 11778 (2018). 

13. Romele, P. et al. Multiscale real time and high sensitivity ion detection with complementary organic electrochemical transistors amplifier. _Nat. Commun._ **11** , 3743 (2020). 

14. Sun, H. et al. Complementary logic circuits based on high-performance n-type organic electrochemical transistors. _Adv. Mater._ **30** , 1704916 (2018). 

15. Khodagholy, D. et al. High transconductance organic electrochemical transistors. _Nat. Commun._ **4** , 2133 (2013). 

16. Donahue, M. J. et al. High-performance vertical organic electrochemical transistors. _Adv. Mater._ **30** , 1705031 (2018). 

17. Andersson Ersman, P. et al. All-printed large-scale integrated circuits based on organic electrochemical transistors. _Nat. Commun._ **10** , 5053 (2019). 

18. Rashid, R. B., Ciechowski, R. J. & Rivnay, J. Self-aligned, laser-cut organic electrochemical transistors. _Flex. Print. Electron._ **5** , 014007 (2020). 

19. Schmatz, B., Lang, A. W. & Reynolds, J. R. Fully printed organic electrochemical transistors from green solvents. _Adv. Funct. Mater._ **29** , 1905266 (2019). 

20. Jiang, C., de Rijk, S. R., Malliaras, G. G. & Bance, M. L. Electrochemical impedance spectroscopy of human cochleas for modeling cochlear implant electrical stimulus spread. _APL Mater._ **8** , 091102 (2020). 

21. Moser, M. et al. Side chain redistribution as a strategy to boost organic electrochemical transistor performance and stability. _Adv. Mater._ **32** , e2002748 (2020). 

22. Kleemann, H., Krechan, K., Fischer, A. & Leo, K. A review of vertical organic transistors. _Adv. Funct. Mater._ **30** , 1907113 (2020). 

23. Giovannitti, A. et al. Energetic control of redox-active polymers toward safe organic bioelectronic materials. _Adv. Mater._ **32** , e1908047 (2020). 

24. Wu, X. et al. Enhancing the electrochemical doping efficiency in diketopyrrolopyrrole‐ based polymer for organic electrochemical transistors. _Adv. Electron. Mater._ **7** , 2000701 (2020). 

25. Bischak, C. G., Flagg, L. Q., Yan, K., Li, C. Z. & Ginger, D. S. Fullerene active layers for n-type organic electrochemical transistors. _ACS Appl. Mater. Interfaces_ **11** , 28138–28144 (2019). 

26. Yan, Y. et al. High-performance organic electrochemical transistors with nanoscale channel length and their application to artificial synapse. _ACS Appl. Mater. Interfaces_ **12** , 49915–49925 (2020). 

27. Chen, X. et al. n-Type rigid semiconducting polymers bearing oligo(ethylene glycol) side chains for high-performance organic electrochemical transistors. _Angew. Chem. Int. Ed. Engl._ **60** , 9368–9373 (2021). 

28. Savva, A. et al. Solvent engineering for high‐performance n‐type organic electrochemical transistors. _Adv. Electron. Mater._ **5** , 1900249 (2019). 

29. Wang, Y. et al. Hybrid alkyl–ethylene glycol side chains enhance substrate adhesion and operational stability in accumulation mode organic electrochemical transistors. _Chem. Mater._ **31** , 9797–9806 (2019). 

30. Marks, A. et al. Synthetic nuances to maximize n-type organic electrochemical transistor and thermoelectric performance in fused lactam polymers. _J. Am. Chem. Soc._ **144** , 4642–4656 (2022). 

31. Feng, K. et al. Cyano-functionalized n-type polymer with high electron mobility for highperformance organic electrochemical transistors. _Adv. Mater._ **34** , e2201340 (2022). 

32. Kim, S. M. et al. Influence of PEDOT:PSS crystallinity and composition on electrochemical transistor performance and long-term stability. _Nat. Commun._ **9** , 3858 (2018). 

33. Guo, E. et al. Vertical organic permeable dual-base transistors for logic circuits. _Nat. Commun._ **11** , 4725 (2020). 

34. Abarkan, M. et al. Vertical organic electrochemical transistors and electronics for low amplitude micro-organ signals. _Adv. Sci._ **9** , e2105211 (2022). 

#### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-022-05592-2. 

   35. Xie, Z. C. et al. All-solid-state vertical three-terminal n-type organic synaptic devices for neuromorphic computing. _Adv. Funct. Mater._ **32** , 2107314 (2022). 

   36. Rashid, R. B. et al. Ambipolar inverters based on cofacial vertical organic electrochemical transistor pairs for biosignal amplification. _Sci. Adv._ **7** , eabh1055 (2021). 

   37. Lenz, J., Del Giudice, F., Geisenhof, F. R., Winterer, F. & Weitz, R. T. Vertical, electrolytegated organic transistors show continuous operation in the MA cm<sup>−2</sup> regime and artificial synaptic behaviour. _Nat. Nanotechnol._ **14** , 579–585 (2019). 

   38. Liu, G. et al. Ultralow‐Power and multisensory artificial synapse based on electrolyte‐ gated vertical organic transistors. _Adv. Funct. Mater._ **32** , 2200959 (2022). 

   39. Paterson, A. F. et al. On the role of contact resistance and electrode modification in organic electrochemical transistors. _Adv. Mater._ **31** , e1902291 (2019). 

1. Park, S. et al. Self-powered ultra-flexible electronics via nano-grating-patterned organic photovoltaics. _Nature_ **561** , 516–521 (2018). 

2. Rivnay, J. et al. Organic electrochemical transistors. _Nat. Rev. Mater._ **3** , 17086 (2018). 3. van de Burgt, Y. et al. A non-volatile organic electrochemical device as a low-voltage artificial synapse for neuromorphic computing. _Nat. Mater._ **16** , 414–418 (2017). 

4. Khau, B. V., Scholz, A. D. & Reichmanis, E. Advances and opportunities in development of deformable organic electrochemical transistors. _J. Mater. Chem. C_ **8** , 15067 (2020). 

5. Ji, X. et al. Mimicking associative learning using an ion-trapping non-volatile synaptic organic electrochemical transistor. _Nat. Commun._ **12** , 2480 (2021). 

6. Zeglio, E. & Inganas, O. Active materials for organic electrochemical transistors. _Adv. Mater._ **30** , e1800941 (2018). 

7. Ohayon, D. et al. Influence of side chains on the n-type organic electrochemical transistor performance. _ACS Appl. Mater. Interfaces_ **13** , 4253–4266 (2021). 

8. Giovannitti, A. et al. N-type organic electrochemical transistors with stability in water. _Nat. Commun._ **7** , 13066 (2016). 

40. Haddock, J. N. et al. A comprehensive study of short channel effects in organic fieldeffect transistors. _Org. Electron._ **7** , 45–54 (2006). 

41. Thiburce, Q., Giovannitti, A., McCulloch, I. & Campbell, A. J. Nanoscale ion-doped polymer transistors. _Nano Lett._ **19** , 1712–1718 (2019). 

42. Venkatraman, V. et al. Subthreshold operation of organic electrochemical transistors for biosignal amplification. _Adv. Sci._ **5** , 1800453 (2018). 

43. Lee, S. & Nathan, A. Subthreshold schottky-barrier thin-film transistors with ultralow power and high intrinsic gain. _Science_ **354** , 302–304 (2016). 

44. Wu, X. et al. Universal spray-deposition process for scalable, high-performance, and stable organic electrochemical transistors. _ACS Appl. Mater. Interfaces_ **12** , 20757–20764 (2020). 

45. Wu, H. Y. et al. Influence of molecular weight on the organic electrochemical transistor performance of ladder-type conjugated polymers. _Adv. Mater._ **34** , e2106235 (2022). 

46. Mannerbro, R., Ranlöf, M., Robinson, N. & Forchheimer, R. Inkjet printed electrochemical organic electronics. _Synth. Met._ **158** , 556–560 (2008). 

Nature | Vol 613 | 19 January 2023 | **501** 

## Article 

47. Nilsson, D., Robinson, N., Berggren, M. & Forchheimer, R. Electrochemical logic circuits. _Adv. Mater._ **17** , 353–358 (2005). 

48. Doris, S. E., Pierre, A. & Street, R. A. Dynamic and tunable threshold voltage in organic electrochemical transistors. _Adv. Mater._ **30** , e1706757 (2018). 

49. Romele, P., Ghittorelli, M., Kovacs-Vajna, Z. M. & Torricelli, F. Ion buffering and interface charge enable high performance electronics with organic electrochemical transistors. _Nat. Commun._ **10** , 3044 (2019). 

50. Leydecker, T., Wang, Z. M., Torricelli, F. & Orgiu, E. Organic-based inverters: basic concepts, materials, novel architectures and applications. _Chem. Soc. Rev._ **49** , 7627–7670 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2023 

**502** | Nature | Vol 613 | 19 January 2023 

### **Methods** 

###### **Materials synthesis** 

The synthetic route to the new polymers gDPP-g2T and Homo-gDPP is illustrated in Extended Data Fig. 1a. Unless otherwise stated, all reactions were carried out under argon and the solvents were used without any purification. The reagents 2,5,8,11,14-pentaoxah exadecan-16-yl 4-methylbenzenesulfonate ( **1** )<sup>51</sup> , 3,6-di(thiophen-2-yl)-2, 5-dihydropyrrolo[3,4-c]pyrrole-1,4-dione ( **2** )<sup>52</sup> and 5,5′-bis(trimethyltin)3,3′-bis(2-(2-(2-methoxyethoxy)ethoxy)ethoxy)-2,2′-bithiophene ( **5** )<sup>53</sup> were synthesized according to previously reported procedures. Hexabutyldistannane ( **6** ) was purchased from Sigma-Aldrich. The Cin-Cell ploymer was prepared according to our previous publication<sup>54</sup> . 

**Synthesis of 2,5-di(2,5,8,11,14-pentaoxahexadecan-16-yl)-3,6di(thiophen-2-yl)-2,5-dihydropyr-rolo[3,4-c]pyrrole-1,4-dione (3).** Compound **1** (6.00 g, 14.76 mmol), compound **2** (1.84 g, 6.15 mmol), K2CO4 (4.25 g, 30.75 mmol) and 40 ml of dimethylformamide were added to a 100 ml single-neck round-bottom flask. The reaction mixture was purged with argon for 15 min and was then heated to 150 °C overnight. After cooling to 25 °C, the solvent was removed under reduced pressure. The residue was next dissolved in chloroform and was then washed with water and brine 3 times each. The organic phase was then dried over anhydrous Na2SO4, filtered and the solvent was removed under vacuum to leave the crude product, which was then purified by silica gel chromatography, eluting with chloroform/methanol (100:1 to 20:1). Compound **3** was obtained as a red solid (1.71 g; yield, 36%).<sup>1</sup> H NMR (500 MHz, CDCl3, Extended Data Fig. 1b): _δ_ (ppm) = 8.75 (d, _J_ = 3.9 Hz, 2H), 7.64 (d, _J_ = 5.0 Hz, 2H), 7.26 (dd, _J_ = 5.0 Hz, 3.9 Hz, 2H), 4.26 (t, _J_ = 6.3 Hz, 4H), 3.78 (t, _J_ = 6.4 Hz, 4H), 3.66–3.51 (m, 32H), 3.36 (s, 6H).<sup>13</sup> C NMR (126 MHz, CDCl3, Extended Data Fig. 1c): _δ_ (ppm) = 161.54, 140.44, 134.78, 130.91, 129.68, 128.46, 107.89, 71.94, 70.72, 70.62, 70.60, 70.58, 70.57, 70.52, 68.94, 59.04, 41.88. Highresolution mass spectrometry (HRMS) matrix-assisted laser desorption– ionization (MALDI): calcd for C36H52N2NaO12S2 (M + Na<sup>+</sup> ): 791.2859; found, 791.2851. 

**Synthesis of 3,6-bis(5-bromothiophen-2-yl)-2,5-di(2,5,8,11, 14-pentaoxahexadecan-16-yl)-2,5-dihydropyrrolo[3,4-c]pyrrole-1, 4-dione (4).** Compound **3** (1.00 g, 1.30 mmol) was dissolved in 30 ml of chloroform in a 100 ml single-neck round-bottom flask. The reaction mixture was cooled to 0 °C and _N_ -bromosuccinimide  (0.48 g, 2.73 mmol) was added in one portion under argon. The reaction mixture was slowly warmed to room temperature and was stirred overnight in the dark. Water (100 ml) was added and the resutling solution was stirred for 30 min. The organic layer was separated and was dried over anhydrous Na2SO4, filtered and the solvent was removed under vacuum to leave a residue that was purified by silica gel chromatography with chloroform/methanol (100:1 to 50:1). Compound **4** was obtained as a purple solid (0.86 g, yield 71%).<sup>1</sup> H NMR (500 MHz, CDCl3, Extended Data Fig. 1d): _δ_ (ppm) = 8.48 (d, _J_ = 4.2 Hz, 2H), 7.20 (d, _J_ = 4.2 Hz, 2H), 4.16 (t, _J_ = 6.0 Hz, 4H), 3.76 (t, _J_ = 6.0 Hz, 4H), 3.66–3.51 (m, 32H), 3.36 (s, 6H).<sup>13</sup> C NMR (126 MHz, CDCl3, Extended Data Fig. 1e): _δ_ (ppm) = 161.26, 139.48, 134.86, 131.41, 131.12, 119.35, 107.97, 71.93, 70.76, 70.61, 70.58, 70.56, 70.50, 68.94, 59.03, 42.24, 29.60. HRMS (MALDI): calcd for C36H50Br2N2NaO12S2 (M + Na<sup>+</sup> ): 949.1049; found, 949.1044. 

**Synthesis of polymer gDPP-g2T.** Compound **4** (92.67 mg, 0.10 mmol), compound **5** (81.62 mg, 0.1 mmol), Pd2(dba)3 (3.00 mg) and P( _o_ -tol)3 (7.60 mg) were added to a 10 ml reaction vessel. After the reaction mixture was pump–purged for three cycles with argon, anhydrous toluene (1.5 ml) and dimethylformamide (1.5 ml) were added. The sealed vessel was next heated at 110 °C for 12 h. The polymer was then end-capped with 20 µl of 2-(tributylstannyl)-thiophene and then 50 µl of 2-bromothiophene, with each step being carried out at 110 °C for 1 h. 

After cooling to room temperature, the mixture was poured into 100 ml of MeOH + 1 ml of concentrated HCl. The resulting precipitate was collected by filtration and then purified by Soxhlet extraction using methanol, acetone, hexane and then chloroform. The chloroform portion was concentrated and then poured into MeOH (approximately 100 ml). The resulting precipitate was collected by vacuum filtration as a black solid (106.51 mg, yield 86%).<sup>1</sup> H NMR (500 MHz, C2D2Cl4, Extended Data Fig. 1f): _δ_ (ppm) = 8.73–8.69 (br, 2H), 7.43–6.84 (br, 4H), 4.34–4.25 (br, 8H), 3.94–3.45 (m, 56H), 3.29 (s, 12H). Anal. calcd for [C58H84N2O20S4] _n_ : C, 55.40; H, 6.73; N, 2.23. Found: C, 55.41; H, 6.67; N, 2.37. 

**Synthesis of polymer Homo-gDPP.** The polymer Homo-gDPP was synthesized by using the same method as used for gDPP-g2T. Compound **4** (199.00 mg, 0.21 mmol), compound **6** (124.57 mg, 0.21 mmol), Pd2(dba)3 (5.00 mg) and P( _o_ -tol)3 (13.00 mg) were used as starting materials. The pure polymer was obtained as a black solid (100.00 mg, yield 62%). 1H NMR (500 MHz, C2D2Cl4, Extended Data Fig. 1g): _δ_ (ppm) = 8.91–8.69 (br, 2H), 7.43–7.22 (br, 2H), 4.25 (br, 4H), 3.78–3.54 (br, 36H), 3.46 (br, 6H). Anal. calcd for [C36H52N2O12S2] _n_ : C, 56.23; H, 6.82; N, 3.64. Found: C, 56.26; H, 6.83; N, 3.76. 

###### **Materials characterization** 

The<sup>1</sup> H and<sup>13</sup> C NMR spectra of the intermediates were recorded on a Bruker Ascend 500 MHz spectrometer by using deuterochloroform (CDCl3) as the solvent at room temperature. The<sup>1</sup> H spectra of the polymers were recorded on a Bruker Ascend 500 MHz spectrometer by using dideutero-1,1,2,2-tetrachloroethane (C2D2Cl4) at 100 °C, which was also used to estimate the molecular weight. The purity of the polymers was verified by elemental analysis carried out at Midwest Microlabs Inc. 

**VT–NMR and** **_M_ n estimation by end-group analysis.** The solutions for the NMR experiments were prepared by dissolving approximately 5 mg of polymer in 0.7 ml of C2D2Cl4. The solutions were heated at 100 °C for 16 h before the measurements were taken to ensure complete dissolution of the polymer. The measurements were performed on a 400 MHz Bruker Avance III HD Nanobay at 100 °C, and the spectra were referenced to C2DHCl4 at 5.90 ppm. End-groups were identified based on literature compounds of similar structure<sup>55,56</sup> . Calculation of the _M_ n from the end-group analysis is based on equation (1), which is described in the literature<sup>57</sup> . 



<!-- Start of picture text -->
nx = axmyny (1)<br>aymx<br><!-- End of picture text -->

where _ax_ is the corrected number of repeat unit protons, _my_ is the number of end-group protons used for the calculation, _ay_ is the area of the end-group protons and _mx_ is he number of repeat unit protons. 

For Homo-gDPP: _nx_ = [(10.65)(2)(2)]/[(1)(2)] = 21.3 ≈ 21 and _M_ n = (21 × 0.76893) = 16.4 kDa. 

For gDPP-g2T: _n_ x = [(16.8)(2)(2)]/[(1)(2)] = 33.6 ≈ 34 and _M_ n = (34 × 1.16744) = 39.7 kDa. 

###### **OECT and complementary circuit fabrication** 

**Semiconductor solution preparation.** The gDPP-g2T, Homo-gDPP and Cin-Cell were first dissolved in chloroform at a concentration of 20 mg ml<sup>−1</sup> and were filtered through a 0.45 µm polyvinylidene difluoride filter. Then, the gDPP-g2T or Homo-gDPP solution was mixed with the Cin-Cell solution in a volume ratio of 9:2 for device fabrication by using the blends. For Pg2T-T, PIBET-AO, PEG-N2200 and BTI2, they were also first dissolved in chloroform at a concentration of 20 mg ml<sup>−1</sup> and were filtered through a 0.45 µm polyvinylidene difluoride filter, then mixed with the Cin-Cell solution in a volume ratio of 9:2. For PEDOT:PSS (Xi’an Polymer Light Technology Corp.), a solution containing 1 ml of PH1000 (solid content approximately 1.3%, PEDOT 

## Article 

content approximately 0.37%), 1 polyethylene glycol dimethacrylate (1.2:1 weight ratio versus PEDOT), 5 wt% of Irgacure 2959 (versus polyethylene glycol dimethacrylate) and 1 wt% of Capstone FS-30 (versus PH1000)<sup>58</sup> was prepared. 

**Conventional OECT fabrication.** A Si wafer with a 300-nm-thick SiO2 layer was used as the substrate. It was ultrasonically cleaned, first in an isopropyl alcohol bath for 20 min and then with oxygen plasma for 5 min. The S1813 photoresist was spin-coated at 4,000 rpm for 45 s, followed by annealing at 110 °C for 60 s and was then exposed under a maskless aligner system (MLA150; Heidelberg Instruments), developed in AZ400k (Microchemicals) for 40 s, rinsed with deionized water and blow-dried. Next, 3 nm of Cr and 50 nm of Au were deposited by thermal evaporation and were developed by soaking in acetone for 5 min to remove the S1813. Here, the patterned planar Au source–drain electrodes defined the channel dimension of _W_ = 100 µm and _L_ = 10 µm. The p- or n-type semiconductor blend solution was then spin-coated at 3,000 rpm for 20 s and was UV cross-linked for 30 s (Inpro Technologies F300S). At last, a droplet (approximately 1–20 µl, based on the channel area) of phosphate buffer solution (PBS, 1×) was applied onto the electrode overlapping area, and an Ag/AgCl electrode was inserted in the droplet acting as the OECT gate electrode. For the well-patterned cOECTs, the fabrication process can be found in the literature<sup>59</sup> , and the devices have patterned semiconductor areas (100 × 20 µm<sup>2</sup> , in which the channel length is 10 µm, the channel width is 100 µm, the channel thickness is 100 nm and the overlap with the source and/or drain is 5 µm on each side) and encapsulated source–drain electrodes. 

**Vertical OECT fabrication.** An illustration of the vOECT fabrication process can be also found in Fig. 1a. The vOECTs were also fabricated on a pre-cleaned Si/300 nm SiO2 wafer. First, 3 nm of Cr and 150 nm of Au (rate approximately 0.5–2.0 Å s<sup>−1</sup> ) were thermally evaporated with a shadow mask as the bottom source electrode. Next, the semiconductor blend solution was spin-coated on the substrate at 3,000 rpm for 20 s. The semiconducting layer was then UV cross-linked for 30 s (Inpro Technologies F300S). Note that the semiconducting layer can be further patterned by developing it in chloroform for 3 s and blow-drying if cross-linked with a photomask. The top drain electrode (150 nm Au) was then thermally evaporated (rate approximately 0.5–2.0 Å s<sup>−1</sup> ) with a shadow mask while maintaining the substrate at a temperature of approximately 20 °C with a back water-cooling system. Finally, a droplet (approximately 1–20 µl, based on the channel area) of PBS (1×) was applied on the electrode overlapping area, and an Ag/AgCl electrode was inserted in the droplet acting as the OECT gate electrode. Control devices using the pure semiconductors were fabricated following the same procedure but by using pure polymer solutions and without UV exposure. 

**Complementary inverter fabrication.** An illustration of the fabrication process can be found in Extended Data Fig. 9a. For the inverter fabrication, a layer of the opposite type of semiconductor blend was spin-coated (3,000 rpm for 20 s) directly onto the first vOECT (before applying the PBS electrolyte and the Ag/AgCl electrode), and was UV cross-linked for 30 s. Next, the third Au electrode (150 nm) was evaporated with a shadow mask as describe above. Note that the third Au electrode was carefully aligned to overlap with the active area of the bottom vOECT. Finally, a droplet (approximately 1–20 µl, based on the channel area) of PBS (×1) was applied on the electrode overlapping area, and an Ag/AgCl electrode was inserted in the droplet acting as _V_ IN of the inverter. 

**Complementary ring oscillator fabrication.** An illustration of the fabrication process can be found in Extended Data Fig. 9b. The five-stage ring oscillator was also fabricated on a pre-cleaned Si/300 nm SiO2 wafer. First, 3 nm Cr and 150 nm Au were thermally evaporated with a shadow mask as the bottom electrode ( _V_ DD). Next, the p-type 

gDPP-g2T:Cin-Cell mixture solution was spin-coated on the substrate at 3,000 rpm for 20 s and was cross-linked under UV light for 30 s with a shadow mask. The film was patterned by immersing it in chloroform for 3 s and blow-drying. Next, 150 nm Au were thermally evaporated with a shadow mask as the middle electrode ( _V_ OUT). The n-type Homo-gDPP:Cin-Cell mixture was then spin-coated and photopatterned in the same way as for the p-type polymer blend. Then, 150 nm Au top electrode (ground, GND) was thermally evaporated with a shadow mask. Pure Cin-Cell solution was then spin-coated at 5,000 rpm for 20 s, cross-linked under UV light for 60 s with a shadow mask and developed in chloroform for 3 s, to leave openings for the active channel areas and _V_ OUT electrodes. A Ag/AgCl paste (Creative Materials, 125-20) was applied on the _V_ OUT electrodes of each inverter and vacuum dried for 30 min. Finally, a drop of PBS electrolyte (approximately 2 µl) was applied on each _V_ OUT electrode and its adjacent inverter active channel area. 

**NAND and NOR fabrication.** An illustration of the fabrication process can be found in Extended Data Fig. 9c,d. NAND and NOR logic gates were also fabricated on a pre-cleaned Si/300 nm SiO2 wafer. First, 3 nm Cr and a 150 nm Au were thermally evaporated with a shadow mask as the bottom electrode. Next, the p-type gDPP-g2T:Cin-Cell mixture solution was spin-coated on the substrate at 3,000 rpm for 20 s and was cross-linked under UV light for 30 s with a shadow mask. The film was patterned by immersing in chloroform for 3 s and blow-dried. Next, 150 nm Au were thermally evaporated with a shadow mask as the middle electrode ( _V_ OUT). The n-type Homo-gDPP:Cin-Cell mixture was then spin-coated and photopatterned in the same way as for the p-type polymer blend but with a different shadow mask. Then, 150 nm Au top electrode was thermally evaporated with a shadow mask. Pure Cin-Cell solution was spin-coated at 5,000 rpm for 20s, cross-linked under UV light for 60 s with a shadow mask and developed in chloroform for 3 s, to leave openings for the active channel areas. Finally, two drops of PBS electrolyte (approximately 2 µl) were applied on each _V_ IN area along with two Ag/AgCl electrodes as _V_ IN-A and _V_ IN-B, respectively. 

**Rectifier fabrication.** An illustration of the fabrication process can be found in Extended Data Fig. 9e. The rectifier was also fabricated on a pre-cleaned Si/300 nm SiO2 wafer. First, 3 nm Cr and 150 nm Au were thermally evaporated with a shadow mask as the bottom electrode ( _V_ OUT). Next, the p-type gDPP-g2T:Cin-Cell mixture solution was spin-coated on the substrate at 3,000 rpm for 20 s and was cross-linked under UV light for 30 s with a shadow mask. The film was patterned by immersing it in chloroform for 3 s and blow-drying. Next, 150 nm Au were thermally evaporated with a shadow mask as middle electrode ( _V_ IN+ and _V_ IN−). The n-type Homo-gDPP:Cin-Cell mixture was then spin-coated and photopatterned as that of the p-type polymer blend. Then, 150 nm Au top electrode (GND) was thermally evaporated with a shadow mask. Pure Cin-Cell solution was then spin-coated at 5,000 rpm for 20 s, cross-linked under UV light for 60 s with a shadow mask and developed in chloroform for 3 s to leave openings for the active channel areas and _V_ IN electrodes. A Ag/AgCl paste (Creative Materials, 125-20) was applied on the _V_ IN electrodes and was vacuum dried for 30 min. Finally, two drops of PBS electrolyte (approximately 2 µl) were applied on each _V_ IN electrode and its adjacent active channel area. 

###### **Device characterization** 

**Transistor measurement.** The electrical characterization of the OECTs and inverters was carried with an Agilent B1500A semiconductor parameter analyser in ambient conditions. The voltage sweeping speed was 0.1 V s<sup>−1</sup> for the OECT measurements. For the transistor and inverter cycling tests, the voltage pulse was generated by a Keysight waveform generator (33500B), whereas the current–voltage variation was monitored with an Agilent B1500A. During the cycling tests, to maintain a relatively stable PBS electrolyte concentration, a PDMS mould was placed on top of the device active area to confine the electrolyte displacement 

and to slow water evaporation. Transient time measurements were carried out with an FS-Pro (PDA) semiconductor parameter analyser. For the ring oscillator characterization, a constant _V_ DD of +0.7 V was applied with an Agilent B1500A, and the _V_ OUT was monitored by an oscilloscope (Tektronix, TDS 2014). For NAND and NOR characterization, square pulses (from 0.0 to ±0.7 V) with a frequency of 5 Hz and 10 Hz were applied as _V_ IN-A and _V_ IN-B, respectively, by a Keysight waveform generator (33500B), and _V_ OUT was monitored by an Agilent B1500A. For rectifier characterization, two sinusoidal _V_ IN ( _V_ IN+ and _V_ IN− have a phase difference of 180°) with an amplitude of 0.35 V were generated by a Keysight waveform generator (33500B), and the _V_ OUT was monitored by an Agilent B1500A. All measurements were carried out in ambient conditions. 

**EIS measurements.** All measurements were conducted by using a PalmSens4 potentiostat (PalmSens) with an Ag/AgCl pellet (Warner Instruments) as the reference and counter electrode, and a gold electrode coated with active materials as the working electrode. For measurements on the vertical structure, details can be found in Extended Data Fig. 7, which were performed in PBS (1×) electrolyte with a direct current offset as 0.5 V (for the p-type material) and −0.7 V (for the n-type material), superimposed by a 10 mV alternating current (a.c.) oscillation. The frequency of the a.c. oscillation ranges from 0.1 to 10<sup>5</sup> Hz. 

**Bandwidth measurements.** Bandwidth measurements were conducted by accessing the _g_ m of the OECT as a function of the frequency of the gate voltage oscillation. The National Instruments (NI) SMU unit (NI PXIe-4143) was used for sourcing and measuring the drain–source voltage and current, as well as the gate current. The gate voltage was applied by using the data acquisition (DAQ) card from NI (NI PXIe-6363)] and was measured with a NI BNC-2110. During the measurement, _V_ DS is equal to −0.5 V (p-type) and 0.5 V(n-type), whereas _V_ G is equal to −0.5 V (p-type) and 0.7 V (n-type), superimposed by a 10 mV a.c. oscillation. The frequency of the a.c. oscillation ranges from 1 to 10<sup>4</sup> Hz. All measurements were automated by using a custom LabVIEW programme (NI) and the data were processed by using the MATLAB software (Mathworks). 

###### **Semiconductor film characterization** 

SEM characterizations were carried out on a Hitachi SU8030 FE-SEM. AFM characterizations were acquired with a Bruker ICON System. GIWAXS measurements were performed at Beamline 8-ID-E1 at the Advanced Photon Source (APS) at Argonne National Laboratory. Samples were irradiated with a 10.9 keV X-ray beam at an incidence angle 0.125° to 0.135° in a vacuum for two summed exposures of 2.5 s (totalling 5 s of exposure), and scattered X-rays were recorded by a Pilatus 1 M detector located 228.16 mm from the sample at two different heights. 

###### **Discussion of the calculated mobilities of cOECT and vOECTs** 

The carrier mobilities of both the gDPP-g2T:Cin-Cell and HomogDPP:Cin-Cell were measured in vertical and planar OECTs<sup>59</sup> . For the planar or conventional architecture, the carrier mobility of the p-type cOECT is found to be 1.69 ± 0.19 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which is comparable to other high-performance p-type OECTs. The n-type cOECT exhibits a high mobility of 0.13 ± 0.03 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which is among the highest reported up until now. However, for the vertical devices, the calculated carrier mobilities are much lower, (3.33 ± 0.27) × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and (3.06 ± 0.61) × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for the p-type and n-type vOECTs, respectively. 

The much lower and similar carrier mobilities in the vOECTs probably originate from the large series resistance from the source–drain electrodes and, to a lesser extent, the non-optimal polymer morphology of the spin-coated films, which typically enhances in-plane rather than out-ofplane organic semiconductor charge transport. Because the measured channel resistance in the vertical structure in the on-state is less than 10 Ω, series resistances originating at the electrode–semiconductor interface and within the electrode contact will reduce the measured 

drain current notably<sup>16</sup> . Overall, these observations indicate that further optimization of charge injection and connecting-line conductivity, and the use of organic semiconductors that favour vertical charge transport as in those for organic photovoltaics, will probably enhance the current densities even further. Nevertheless, to properly evaluate the true carrier mobilities for the unconventional vertical architecture reported here, additional modelling and simulation efforts are required. This would be of great interest to the entire community. 

#### **Data availability** 

Source data are provided with this paper. Additional data related to this work are available from the corresponding authors upon request. 

51. Tzirakis, M. D., Alberti, M. N., Weissman, H., Rybtchinski, B. & Diederich, F. Enantiopure laterally functionalized alleno-acetylenic macrocycles: synthesis, chiroptical properties, and self-assembly in aqueous media. _Chemistry_ **20** , 16070–16073 (2014). 

52. Chen, J. et al. Tuning the central fused ring and terminal units to improve the photovoltaic performance of Ar(A–D)2 type small molecules in solution-processed organic solar cells. _J. Mater. Chem. A_ **4** , 4952–4961 (2016). 

53. Song, C. K., Eckstein, B. J., Tam, T. L., Trahey, L. & Marks, T. J. Conjugated polymer energy level shifts in lithium-ion battery electrolytes. _ACS Appl. Mater. Interfaces_ **6** , 19347–19354 (2014). 

54. Wang, Z. et al. Cinnamate-functionalized natural carbohydrates as photopatternable gate dielectrics for organic transistors. _Chem. Mater._ **31** , 7608–7617 (2019). 

55. Wang, K. & Wang, M. Hyperbranched narrow-bandgap DPP homopolymers synthesized via direct arylation polycondensation. _J. Polym. Sci. A Polym. Chem._ **55** , 1040–1047 (2017). 

56. Punzi, A. et al. Synthetic Routes to TEG-substituted diketopyrrolopyrrole-based low band-gap polymers. _Eur. J. Org. Chem._ **2016** , 3233–3242 (2016). 

57. Izunobi, J. U. & Higginbotham, C. L. Polymer molecular weight analysis by 1H NMR spectroscopy. _J. Chem. Educ._ **88** , 1098–1104 (2011). 

58. Zheng, Y. Q. et al. Monolithic optical microlithography of high-density elastic circuits. _Science_ **373** , 88–94 (2021). 

59. Inal, S., Malliaras, G. G. & Rivnay, J. Benchmarking organic mixed conductors for transistors. _Nat. Commun._ **8** , 1767 (2017). 

**Acknowledgements** We gratefully acknowledge financial support from the AFOSR (grant nos. FA9550-18-1-0320 and FA9550-22-1-0423), the Northwestern University MRSEC (grant no. NSF DMR-1720139), the US Department of Commerce, National Institute of Standards and Technology as part of the Center for Hierarchical Materials Design (CHiMaD) (award no. 70NANB19H005), the National Natural Science Foundation of China (grant nos. U1830207, 21774055 and 62273073), the National Key R&D Program of China (grant no. 2022YFE0134800), the Sichuan Science and Technology Program (grant no. 2022NSFSC0877) and Flexterra Corp. This work made use of the Northwestern University Micro/Nano Fabrication Facility (NUFAB), the EPIC facility, the Keck-II facility and the SPID facility of the NUANCE Center at Northwestern University, which is partially supported by the Soft and Hybrid Nanotechnology Experimental (SHyNE) Resource (NSF ECCS-2025633), the Materials Research Science and Engineering Center (DMR-1720139), the State of Illinois and Northwestern University. R.M.P acknowledges support from the Intelligence Community Postdoctoral Research Fellowship Program at Northwestern University administered by Oak Ridge Institute for Science and Education (ORISE) through an interagency agreement between the U.S. Department of Energy and the Office of the Director of National Intelligence (ODNI). N.R.G. and D.M. acknowledge support from AFOSR under grant number FA9550-23RXCOR011. We thank J. Strzalka of the Argonne National Laboratory Advanced Photon Source for assistance with the GIWAXS measurements. Use of the Advanced Photon Source, an Office of Science User Facility operated for the US DOE Office of Science by Argonne National Laboratory, was supported by the US DOE under contract no. DE‐AC02‐06CH11357. We thank W. Yue and Y. Wang from Sun Yat-Sen University for providing the PIBET-AO polymer. We also thank Z. Ye and C. Wu from Zhejiang University for their discussion and help. W.H. thanks the UESTC Excellent Young Scholar Project for financial support. 

**Author contributions** W.H., Y. Cheng, T.J.M. and A.F. conceived the idea and designed the experiments. J.C., R.M.P. and X.G. synthesized the polymer semiconductors. W.H., Y.Y., D.Z., M.X., Y.X., L.B. and J.P. fabricated and characterized the devices. X.J., D.M., N.R.G., A.S. and J.R. conducted the bandwidth and EIS measurements. Y. Chen measured and analysed the GIWAXS. L.-W.F. and Z.W. synthesized the Cin-Cell. 

**Competing interests** A patent application has been filed by Northwestern/Flexterra with inventors W.H., J.C., Y.X., A.F. and T.J.M. 

###### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-022-05592-2. **Correspondence and requests for materials** should be addressed to Wei Huang, Ding Zheng, Yuhua Cheng, Tobin J. Marks or Antonio Facchetti. **Peer review information** _Nature_ thanks Magnus Berggren and Aristide Gumyusenge for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at http://www.nature.com/reprints. 

Article 



**Extended Data Fig. 1 | Synthesis and characterizations of gDPP-g2T and Homo-gDPP. a** , Synthetic route to the semiconductors gDPP-g2T (p-type) and Homo-gDPP (n-type). **b** ,<sup>1</sup> H NMR spectrum of compound **3** . **c** ,<sup>13</sup> C NMR spectrum 

of compound **3** . **d** ,<sup>1</sup> H NMR spectrum of compound **4** . **e** ,<sup>13</sup> C NMR spectrum of compound **4** . **f** ,<sup>1</sup> H NMR spectrum of polymer gDPP-g2T. **g** ,<sup>1</sup> H NMR spectrum of polymer Homo-gDPP. 



**Extended Data Fig. 2 |** See next page for caption. 

## Article 

**Extended Data Fig. 2 | Fabrication process for conventional planar OECTs, performance evaluation for vOECTs based on polymers DPP-2T, HomoDPP, and vOECTs with and without different Cin-Cell contents in the active layer. a** , Fabrication process for a conventional OECT (cOECT). i) Source/drain Au electrode fabrication (this involves photolithography, Au thermal evaporation, and lift-off processes); ii) spin-coating of the semiconducting layer and UV crosslinking; iii) PBS and Ag/AgCl as electrolyte dielectric and gate electrode. **b** , Chemical structures of the redox-inactive semiconducting polymers **DPP-2T** 

(p-type); **Homo-DPP** (n-type). **c** , Representative transfer characteristics of p-type **DPP-2T** and n-type **Homo-gDPP** based vOECTs. **d** , Representative transfer characteristics of ( **d** ) n-type vOECTs with a pristine **Homo-gDPP** and **Homo-gDPP:Cin-Cell** (9:2) as the semiconductor channel and ( **e** ) p-type vOECTs with a pristine **gDPP-g2T** and **gDPP-g2T:Cin-Cell** (9:2) as the semiconductor channel. W= d = 30 µm, VD = ±0.1 V. Representative transfer characteristics of ( **f** ) **Homo-gDPP:Cin-Cell** and ( **g** ) **gDPP-g2T:Cin-Cell** based vOECTs with weight ratios of 9:2, 8:3 and 6:4, respectively. W= d = 50 µm. 



**Extended Data Fig. 3 | Semiconductor film morphologies and microstructures. a** , AFM height images and phase images of a pristine **gDPP-g2T** film and **gDPP-g2T:Cin-Cell blend** (9:2 in mass) film. **b** , AFM height images and phase images of a pristine **Homo-gDPP** film and a **Homo-gDPP:Cin-Cell** blend (9:2 in mass) film. **c** , 2D-GIWAXS images and corresponding ( **d** ) in-plane and ( **e** ) out-of-plane one-dimensional line-cuts for **gDPP-g2T** , **gDPP-g2T** : **Cin-Cell** , **Homo-gDPP** , **Homo-gDPP** : **Cin-Cell** , and **Cin-Cell** films. The **gDPP-g2T** in both 

pristine and blend films exhibits a preferential π-face-on orientation, yet with a considerable portion of crystallites being edge-on oriented. In all cases the lamellar and π-π periodicities are pinned at 20.2 Å and 3.6 Å, respectively. However, in both **Homo-gDPP** and **Homo-gDPP:Cin-Cell** the polymer orientation is preferentially edge-on and while the π-π distance is pinned at 3.6 Å, and the lamellar spacings vary slightly, from 20.2 Å to 19.6 Å, respectively. 

## Article 



**Extended Data Fig. 4 | OECT performance.** ( **a** , **c** ) Representative transfer characteristics and ( **b** , **d** ) corresponding gm and SS curves of ( **a** , **b** ) p-type **gDPP-g2T:Cin-Cell** and ( **c** , **d** ) n-type **Homo-gDPP:Cin-Cell** vOECTs with the indicated W and d values ranging from 30, 50, and 70 µm. vOECT performance with unpatterned semiconducting layers, where **e** and **f** are representative transfer characteristics and the corresponding gm and SS curves of an unpatterned p-type **gDPP-g2T:Cin-Cell** vOECT (W= d = 30 µm) and an unpatterned n-type **Homo-gDPP:Cin-Cell** vOECT (W= d = 50 µm), respectively. Impressively, these 

devices exhibit almost identical performance parameters (ION, VON, gm) versus those of the corresponding p- and n-type vOECTs having a patterned channel, with the exception of a higher off-current for the p-type vOECT. This is due to confinement of the charge transport within the overlapping source/drain electrodes, and the ultra-small L prevents substantial fringing effects. Representative transfer characteristics and corresponding gm and SS curves for ( **g** ) p-type **gDPP-g2T:Cin-Cell** cOECTs and ( **h** ) n-type **Homo-gDPP:Cin-Cell** . Note, W = 100 µm, L = 10 µm. 



**Extended Data Fig. 5 | Chemical structures and OECT performance of the indicated polymer semiconductors blended with Cin-Cell. a** , Chemical structures of the redox-active semiconducting polymers [Pg2T-T and PIBET-AO (p-type); PEG-N2200 and BTI2 (n-type)]. Representative transfer and gm characteristics of planar **(b** , **d** , **f** , **and h** ) and vertical ( **c** , **e** , **g** , **and i** ) OECTs based on Pg2T-T ( **b** , **c** ), PIBET-AO ( **d** , **e** ), PEG-N2200 ( **f** , **g** ), and BTI2 ( **h** , **i** ). Note, W and d 

are both 30 µm for the vOECT, while W and L are 100 µm and 10 µm, respectively, for the cOECT. For PEG-N2200 and BTI2 based planar OECTs, the gms are too small when plotted on the same scale as that of the vOECT counterparts, so therefore insets with magnified Y axis are included. In all samples, the semiconductor:Cin-Cell weight ratio is 9:2. 

## Article 



**Extended Data Fig. 6 | Vertical device structures for the direct observation of the electrochromic and performance characteristics of vOECTs with different top electrode widths. a** , Top view photograph and ( **b** ) corresponding p-type vOECT schematic indicating the large electrode overlapping area (~2 × 0.5 mm) used to monitor the electrochromic process associated to the redox chemistry of semiconducting layer. Here a L-shaped bottom Au electrode (100 nm thick) and an L-shaped top Au electrode (20 nm) are grounded and biased with −0.1 V, respectively. **c** , Cross section illustration of the vOECT from the indicated red dashed line in ( **b** ). **d** , Optical image of a p-type gDPP-g2T 

based vOECT array with different top electrode widths but identical bottom electrode. Note, these devices were fabricated by photolithography to accurately pattern the electrode dimensions and locate the semiconductor at the electrode cross points. **e** , Representative transfer characteristics of p-type and n-type (Homo-gDPP) vOECTs for the indicated top electrode width. **f** , Dependence of gm on top electrode width for the p- and n-type vOECTs, where VD  = −0.5 V and 0.5 V, respectively. Data are from the average of 8 different devices. **g** , Transfer and gm characteristics of PEDOT:PSS based vOECTs (W = d = 30 µm) and cOECTs (W = 100 µm, L = 10 µm);, VD = −0.1 V. 



**Extended Data Fig. 7 | Transfer characteristics, output characteristics, transient properties, and bandwidth characteristics of OECTs.** Transfer characteristics of ( **a** ) n-type **Homo-gDPP:Cin-Cell** and ( **b** ) p-type **gDPPg2T:Cin-Cell** vOECTs with VD from ±1 mV to ±500 mV. W = d = 30 µm. Output characteristics of ( **c** ) n-type **Homo-gDPP:Cin-Cell** and ( **d** ) p-type **gDPPg2T:Cin-Cell** vOECTs with W = d = 30, 50, and 70 µm. Cycling stability (cycling frequency of 10 Hz) of PEDOT:PSS based ( **e** ) cOECT and ( **f** ) vOECT, where VD = −0.1 V, VG is switching between −0.1 V and 0.7 V with a frequency of 10 Hz. **g** , Illustration of the cOECT and vOECT structures characterized by transient and bandwidth measurements. **h** , Drain current transient responses of cOECTs based on **gDPP-g2T:Cin-Cell** (9:2) and **Homo-gDPP:Cin-Cell** (9:2). (Semiconductor thicknesses are 100 nm, VG is a square pulse from 0.0 to −0.5 V and 0.0 to 0.7 V for p-type and n-type cOECTs, respectively). **i** , Frequency 

dependent transconductance of cOECTs based on **gDPP-g2T:Cin-Cell** (9:2), and **Homo-gDPP:Cin-Cell** (9:2) (Error bars represent s. d. for N = 6). Cutoff frequencies (fc) of ~800 and ~500 Hz were measured for **gDPP-g2T** based cOECT and vOECT, respectively. This result is consistent with the transient response, where both τON and τOFF of the vOECT are greater than those of the corresponding cOECT. In contrast, the fc of Homo-gDPP based vOECT is ~1200 Hz, which is much higher than that in the corresponding cOECT (~ 600 Hz). This reflects the unstable cycling behavior of Homo-gDPP based cOECTs, which degrades the transconductance during bandwidth measurements, especially at high frequencies. Note, in the vertical structure, the cycling stability is greatly enhanced due to the protection of the top electrode which prevents doped polymer film dissolution/delamination, thereby maintaining structural stability. 

## Article 



**Extended Data Fig. 8 | Electrochemical impedance spectroscopy, transient response, and ion sensing using vOECT-based vertically stacked inverters. a** , EIS measurement setup of typical two-electrode along with the corresponding spectroscopies based on ( **b** ) **gDPP-g2T:Cin-Cell** (9:2) and ( **c** ) **Homo-gDPP:Cin-Cell** (9:2). **d** , Drain current transient responses of vOECTs with **gDPP-g2T:Cin-Cell** (9:2) thicknesses of 100 nm, 200 nm, 300 nm, 400 nm. VG is a square pulse 

between 0.0 and −0.5 V. **e** , Voltage output characteristics of the vOECT-based vertically stacked complementary inverter for ion sensing over a wide concentration range of KCl in water. **f** , Measured transition voltage as a function of KCl concentration. Sensitivities of 31 mV/dec (10<sup>−6</sup> ~ 10<sup>−3</sup> M) and 89 mV/dec (10<sup>−3</sup> ~ 1 M) are obtained with linear approximation (dash line) of the measurements. 



**Extended Data Fig. 9 | Fabrication process for the Vertically stacked complementary inverter (VSCI) and circuits. a** , _For the Inverter:_ i). Bottom electrodes (VDD) evaporation; ii). P-type semiconducting layer fabrication; iii). Middle electrode (VOUT) evaporation; iv). N-type semiconducting layer fabrication; v). Top electrodes (GND) evaporation; vi). Application of the PBS electrolyte and Ag/AgCl electrode. **b** , _For the Ring Oscillator_ (enlarged plots are also provided) _:_ i). Bottom Au electrodes (VDD) evaporation; ii). P-type semiconducting layer fabrication; iii). Middle electrodes (VOUT) evaporation; iv). N-type semiconducting layer fabrication; v). Top electrodes (GND) evaporation; vi). Cin-Cell encapsulation layer fabrication, where the channel areas and Middle electrode acting as VOUT are left open; vii). Application of the Ag/AgCl paste on top of the Middle electrode VOUT region; viii) Apply the PBS electrolyte. **c** , _For the NAND:_ i). Bottom electrodes (VDD, and GND) evaporation; ii). P-type semiconducting layer fabrication; iii). Middle electrodes (VOUT) 

evaporation; iv). N-type semiconducting layer fabrication; v). Top electrodes fabrication; vi). Cin-Cell encapsulation layer fabrication, where the channel areas are left open; vii). Apply the PBS electrolyte and Ag/AgCl electrode. **d** , _For the NOR:_ i). Bottom electrodes evaporation; ii). P-type semiconducting layer fabrication; iii). Middle electrodes (VOUT) evaporation; iv). N-type semiconducting layer fabrication; v). Top electrodes (VDD, and GND) evaporation; vi). Cin-Cell encapsulation layer fabrication, where the channel areas are left open; vii). Apply the PBS electrolyte and Ag/AgCl electrode. **e** , _For the rectifier_ : i). Bottom Au electrodes (VOUT) evaporation; ii). P-type semiconducting layer fabrication; iii). Middle electrodes (VIN+, and VIN-) evaporation; iv). N-type semiconducting layer fabrication; v). Top electrodes (GND) evaporation; vi). Cin-Cell encapsulation layer fabrication, where the channel areas and the middle electrode acting as VIN are left open; vii). Application of the Ag/AgCl paste on top of the middle electrode VIN region; viii). Apply the PBS electrolyte. 

Article 

##### **Extended Data Table 1 | Summary of OECT performance metrics** 



a) For vOECT, the channel area is W×d; for cOECT, the area is W×L. b) The standard deviation of the OECT metrics is from the performance of at least 10 devices. c) Here the volume-normalized gm is not reported, since it is a parameter only suitable for evaluating the performance of a material in the same architecture. Importantly, for real-world applications, a transistor footprint (area-normalized) gm and current are far more relevant when fabricating circuits, as they determine how dense the OECT integration can be while retaining high performance. Thus, the goal in most transistor circuitry fabrication is not to achieve high geometry-normalized gm, but high gm/current in limited areas, which are the ION,A and gm,A reported here. Similarly, the calculated mobilities of cOECTs and vOECTs are discussed in Methods. 

