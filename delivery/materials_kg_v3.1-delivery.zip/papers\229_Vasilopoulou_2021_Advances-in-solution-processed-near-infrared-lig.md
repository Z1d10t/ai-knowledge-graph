# Advances in solution-processed near-infrared light-emitting diodes

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Photonics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 293 |
| 作者 | M. Vasilopoulou, A. Fakharuddin, F. D. de Arquer, D. Georgiadou, Hobeom Kim, A. R. M. Mohd Yusoff, F. Gao, M. Nazeeruddin et al. |
| DOI | 10.1038/s41566-021-00855-2 |
| 源文件 | 029_Vasilopoulou_2021_Advances-in-solution-processed-near-infrared-lig.pdf |

---
Review ARticle | FOCUS 

> **https://doi.org/10.1038/s41566-021-00855-2** Review ARticle | FOCUS 





# **Advances in solution-processed near-infrared light-emitting diodes** 

**Maria Vasilopoulou**<sup>**1,11**✉</sup> **, Azhar Fakharuddin**<sup>**2,11**</sup> **, F. Pelayo García de Arquer**<sup>**3,4**</sup> **, Dimitra G. Georgiadou**<sup>**5,6**</sup> **, Hobeom Kim**<sup>**7**</sup> **, Abd. Rashid bin Mohd Yusoff**<sup>**8**</sup> **, Feng Gao**<sup>**9**</sup> **, Mohammad Khaja Nazeeruddin**<sup>**7**</sup> **, Henk J. Bolink**<sup>**10**✉</sup> **and Edward H. Sargent**<sup>**3**✉</sup> 

**Near-infrared light-emitting diodes based on solution-processed semiconductors, such as organics, halide perovskites and colloidal quantum dots, have emerged as a viable technological platform for biomedical applications, night vision, surveillance and optical communications. The recently gained increased understanding of the relationship between materials structure and photophysical properties has enabled the design of efficient emitters leading to devices with external quantum efficiencies exceeding 20%. Despite considerable strides made, challenges remain in achieving high radiance, reducing efficiency roll-off and extending operating lifetime. This Review summarizes recent advances on emissive materials synthetic methods and device key attributes that collectively contribute to improved performance of the fabricated light-emitting devices.** 

ight-emitting diodes (LEDs) with emission in the near-infrared (NIR) part of the spectrum (700–2,500 nm) (termed NIR-LEDs) Lsupport a large variety of applications, such as optical diagnosis and biomedical imaging<sup>1</sup> , optical communication, remote sensing, security, night vision and data storage<sup>2</sup> . The specific application field determines the spectral range of interest within the NIR (Fig. 1a). With regards to in vivo bioimaging, the semi-transparency of biological tissues, oxygenated and deoxygenated blood in specific NIR wavelength regions, also known as biological windows, makes NIR particularly appealing for optical imaging, biomedical sensing and photodynamic therapy. In the field of optical wireless communications, the spectral range is also divided into bands, which correlate with the wavelength regions where optical fibres have small transmission losses<sup>3</sup> . NIR-LEDs are also in demand for security authentication, optogenetics, life-cycle management of crops, light fidelity and surveillance<sup>4</sup> . 

Common NIR-LEDs are epitaxial heterostructures of III–V inorganic semiconductors (for example, GaAs, InGaAs, InGaAlAs)<sup>5–7</sup> . Commercially available products also employ inorganic phosphors, namely compounds doped with transition metals<sup>8</sup> or rare-earth trivalent ions<sup>9</sup> . An external quantum efficiency (EQE) of 72% at 880 nm has been reported for an AlGaAs/GaAs/AlGaAs III–V LED<sup>6</sup> , and 44.5% at 775 nm for LEDs based on LaMgGa11O19:Cr<sup>3+</sup> phosphors<sup>10</sup> . However, III–V LEDs require post-fabrication substrate replacement with highly reflective mirror structures to increase their poor power output, which originates from the refractive index mismatch between those materials (>3.0)<sup>7</sup> and common substrates. In addition, inorganic phosphors require very-high-temperature sintering treatment (above 1,000 °C). These processing requirements are an obstacle for low-cost, handheld portable implementations. 

Organic semiconductor (OSC)<sup>11</sup> , metal halide perovskite (HP)<sup>12</sup> and colloidal quantum dot (QD)<sup>13</sup> light-emitting materials can be processed using low-cost and low-temperature methods on a wide variety of substrates: for example, via solution-based processes such 

as ink-jet printing, doctor blade and spray coating (Fig. 1b). These qualities make these thin-film LEDs a potentially cost-efficient alternative to their inorganic counterparts and of interest for emerging applications in wearable, implantable and portable electronics. Although there has been progress in different performance metrics such as EQE, challenges remain in reducing the efficiency roll-off, increasing the lifetime and alleviating the toxicity issues of some of the emissive materials. In this Review, we provide an overview of strategies used to achieve high performance in these thin-film LEDs. The material and device design considerations affecting the peak emission wavelength, efficiency and operational stability are described. We conclude with an outlook on future improvements linked to specific applications. 

## **Towards high-efficiency solution-processed NIR-LEDs** 

The key performance metrics of an NIR-LED are the EQE, optical output power ( _P_ ) and radiance ( _R_ ) (Box 1). The EQE is the product of four parameters, namely, the fraction of charge carriers passing through the electrodes that are injected into the emissive layer ( _γ_ ), the fraction of excitons whose states have spin-allowed optical transitions ( _r_ ), the photoluminescence quantum yield (PLQY or _φ_ PL) of the emitter and the light outcoupling efficiency ( _η_ out), which describes the probability that a photon escapes the device in the viewing direction. The parameters _r_ and _φ_ PL are intrinsic properties of the selected emitters, _γ_ depends on the device configuration and the charge-injection interlayers, and _η_ out depends on the refractive indices of the functional layers and the substrate along with the orientation of the transition dipole moments of the emitter on the substrate. To maximize the EQE, it is crucial to simultaneously optimize all four parameters<sup>14–16</sup> . In the following sections, we present the recent progress on the development of narrow-bandgap OSC, HP and QD emitters and devices with efficient and stable electroluminescence (EL) in the NIR. 

> 1Institute of Nanoscience and Nanotechnology, National Center for Scientific Research Demokritos, Agia Paraskevi, Greece. 2Department of Physics, University of Konstanz, Konstanz, Germany.<sup>3</sup> Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario, Canada.<sup>4</sup> ICFO - Institut de Ciències Fotòniques, The Barcelona Institute of Science and Technology, Barcelona, Spain.<sup>5</sup> Centre for Electronics Frontiers, Zepler Institute for Photonics and Nanoelectronics, University of Southampton, Southampton, UK.<sup>6</sup> Department of Physics, Imperial College London, London, UK.<sup>7</sup> Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Sion, Switzerland.<sup>8</sup> Department of Chemical Engineering, Pohang University of Science and Technology (POSTECH), Pohang, Republic of Korea.<sup>9</sup> Department of Physics, Chemistry and Biology (IFM), Linköping University, Linköping, Sweden.<sup>10</sup> Instituto de Ciencia Molecular, Universidad de Valencia, Paterna, Spain.<sup>11</sup> These authors contributed equally: Maria Vasilopoulou, Azhar Fakharuddin.<sup>✉</sup> e-mail: m.vasilopoulou@inn.demokritos.gr; henk.bolink@uv.es; ted.sargent@utoronto.ca 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**656** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 



<!-- Start of picture text -->
a 700 nm 1,400 nm 3 µm 1 mm<br>IR-A (NIR)  IR-B (SWIR) IR-C (MIR, LIR, FIR)<br>700–1,400 nm 1,400 nm–3 µm 3 µm –1 mm<br>NIR-I NIR-II C-band<br>650–950 nm 1,100–1,350 nm 1,530–1,565 nm<br>Telecom window O-band<br>800–900 nm 1,260–1,360 nm<br>Organometallic perovskites and perovskite–metal complexes (up to 1,550 nm)<br>Organic semiconductor dyes, organometallic complexes (1,600 nm)<br>Quantum dots (~2.5 µm)<br>Optical  Remote<br>Data storage Imaging Optogenetics Biosensing communications sensing Night vision<br>b<br>Piezo<br>Flow rate Gas flow Ink<br>Solution Substrate Solution<br>Solvent withdrawn Head reservoir d v /d t  waveform<br>evaporation Wet film Moving Ink moves<br>Substrate blade reservoir<br>Rotating Wet film Substrate Wet film Thin film Droplets Printed pattern<br>chuck<br>Substrate moves Substrate moves<br>Spin coating Dip coating Doctor blade Slot-die coating Spray coating Inkjet printing<br><!-- End of picture text -->

**Fig. 1 | Applicability and scalability of solution-processed NIR-LEDs. a** , The three infrared (IR) spectral regions IR-A (NIR), IR-B (SWIR) and IR-C (MIR, LIR, FIR) and illustration of selected applications. FIR, far infrared; LIR, long infrared; MIR, mid-infrared; NIR, near infrared; SWIR, short-wave infrared. NIR sources are in demand for application in biosensing, optogenetics, biometrics, night vision, data storage, surveillance and 3D imaging. Biological transparency windows are defined as follows: first (NIR-I, 650–950 nm), second (NIR‐II, 1,100–1,350 nm), third (NIR-III, 1,600–1,870 nm) and fourth (NIR-IV, centred at 2,200 nm) NIR windows that allow for clearer imaging due to a scattering and absorption reduction. The telecom window between 800 nm and 900 nm was originally used for transmitting information, followed by the range 1,260–1,360 nm (or O-band) for short-distance communication, whereas today the 1,530–1,565 nm range (known as the C-band) is the most commonly used band for long-haul optical transmission. **b** , Solution-processed NIR-LEDs can be processed from inks using various methods as shown. 

**Recent progress in NIR organic LEDs.** To maximize organic light-emitting diode (OLED) efficiency, both _r_ and _φ_ PL should approach unity; the latter is defined as the ratio of the radiative ( _k_ r) to the sum of radiative and non-radiative ( _k_ nr) decay rates ( _k_ r + _k_ nr). Spin statistics suggest that _r_ is at most 25% for pure fluorescent emitters and nearly 100% for phosphorescent<sup>17</sup> and thermally activated delayed fluorescent (TADF)<sup>18</sup> ones. Furthermore, via triplet–triplet annihilation (TTA), _r_ can reach 25% + 0.5 × 75% = 62.5% (ref.<sup>19</sup> ), under the requirement that the singlet populated states are spin-allowed. Finally, singlet fission in the presence of a suitable sensitizer can potentially increase _r_ up to 200% (ref.<sup>20</sup> ; Fig. 2a–c). 

To extend the emission of π-conjugated molecules to the NIR, the gap between the highest occupied molecular orbital (HOMO) and lowest unoccupied molecular orbital (LUMO) must be reduced. This can be accomplished by a number of chemical modifications that extend the effective conjugation length or selectively influence 

the energy level of the HOMO or the LUMO (Fig. 2d)<sup>21</sup> . The introduction of electron-withdrawing (acceptor) substituents in the aromatic ring can reduce its aromatic character and as a result reduce the electron confinement. Inserting electron-releasing (donor) substituents into a π-conjugated molecule tends to increase the HOMO energy more than that of the LUMO, and as such effectively reducing the gap between them. Another approach relies on the planarization and rigidification of the conjugated system. 

However, there is an intrinsic quenching mechanism known as the ‘energy gap law’ according to which, as the energy gap decreases, coupling of the zero-vibration level of the lowest excited state (either singlet, S1, or triplet, T1) with the higher vibration levels of the ground state (S0) promotes non-radiative recombination pathways<sup>22</sup> . The energy gap law induces fundamental constraints on how much the energy gap of OSCs can be effectively decreased, thus limiting the emission of many OSC emitters below 900 nm (Fig. 2e)<sup>23</sup> . 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**657** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 

### **Box 1 | Device architecture and key performance parameters of solution-processed NIR-LEDs** 

Typical solution-processed NIR-LEDs consist of a multilayer architecture, embedding the semiconductor EML between an electron-injection layer (EIL) and a hole-injection layer (HIL), similarly to their visible emitting counterparts, as illustrated in the figure. In some cases, appropriate interlayers are also applied to block opposite charges from leaking through the device (which are the hole-blocking layer, HBL, and the electron-blocking layer, EBL). Under forward bias, electrons and holes injected from the electrodes drift and diffuse within the EML (electrons are transferred to the LUMO of the organic emissive semiconductor or the conduction band minimum of the inorganic ones, such as perovskites and colloidal QDs, whereas holes are transferred towards the HOMO or the valence band maximum of either the organic or the inorganic semiconductor, respectively; see panel **b** ), and eventually recombine, emitting photons or heat. 

The key performance parameters of an NIR-LED are the EQE, the power density ( _P_ ) or radiance, the device lifetime and efficiency roll-off. EQE denotes the ratio of emitted photons versus the injected charges under external bias and is expressed as the product of the IQE and _η_ out: 



<!-- Start of picture text -->
EQE = Emitted  Injected charges photons = IQE ×  η out (1)<br><!-- End of picture text -->

The _η_ out is the outcoupling efficiency and the IQE value (equation (2)) is proportional to the probability for radiative decay to occur ( _r_ ), the PLQY (or _φ_ PL), and the probability that electrons and holes recombine ( _γ_ ): 



<!-- Start of picture text -->
IQE = r ×  φ PL ×  γ (2)<br><!-- End of picture text -->

Luminance is a figure of merit not relevant to NIR-LEDs; instead, measuring the amount of radiant intensity per unit projected area (the so-called radiance given in W m<sup>−2</sup> sr<sup>−1</sup> ) is more appropriate. 

The emitted light intensity or power output density ( _P_ ) of an NIR-LED is important for applications, such as spectroscopy and sensing. This is proportional to the EQE and the current density ( _J_ ): 



<!-- Start of picture text -->
P = E q ν J EQE (3)<br><!-- End of picture text -->

where EQE is derived by equation (1), _E𝜐_ is the energy of a photon and _q_ is the elementary charge. 



<!-- Start of picture text -->
a b E vacuum<br>Metal<br>EIL<br>–<br>V EML – –<br>–<br>–<br>HIL –<br>ITO Cathode EIL HBL + EML EBL HIL hν<br>Glass + + + Anode<br>Light out +<br>+<br>Energy<br><!-- End of picture text -->

**A solution-processed NIR-LED. a** , **b** , Device architecture ( **a** ) and working principle ( **b** ) of a solution-processed LED driven by a voltage _V_ . _E_ vacuum denotes the vacuum energy. Red and white circles are for electrons and holes, respectively, while the yellow star-shaped symbol denotes formation of a photon. 

Most fluorescent molecules have two electrons in their HOMOs at the ground state, referred to as ‘a closed shell’. Upon excitation, the excited state is either a singlet or a triplet. Most organic molecules can only harvest the singlet excited states radiatively at room temperature, as the transition from a triplet to the ground state is forbidden. This means that these molecules are subjected to _r_ ≈ 25%. As a result, NIR-OLEDs using conventional closed-shell emitters, without an assistant dopant to achieve sensitization and in the absence of outcoupling structures or photon recycling, are limited to EQEs of 5% (refs.<sup>24,25</sup> ). 

Open-shell radical emitters have a singly occupied molecular orbital (SOMO) in the ground state, giving an overall spin-1/2 doublet (D0). If holes and electrons are injected into the HOMO and SOMO, respectively, a fluorescence doublet excited state (D1) is obtained, which gives a spin-allowed emission, and _r_ approaches unity (Fig. 2f)<sup>26–28</sup> . One such organic radical, termed TTM–3NCz— incorporating 3-substituted-9-(naphthalen-2-yl)-9H-carbazole (3NCz) added to the tris(2,4,6-trichlorophenyl)methyl (TTM) core—has recently achieved a high _φ_ PL of (85.6 ± 5.4)% when doped in 4,4′-bis( _N_ -carbazolyl)-1,10-biphenyl (CBP)<sup>28</sup> . The fabricated 

TTM-3NCz-based OLEDs emitted at 710 nm with EQEs of 27% and 10% at current densities ( _J_ ) of 5 × 10<sup>−3</sup> mA cm<sup>−2</sup> and 1 mA cm<sup>−2</sup> , respectively. 

In TADF emitter-based LEDs, excited long-lived triplet states can decay via the singlet states through reverse intersystem crossing radiatively (Fig. 1a) and as a result, _r_ can approach unity. To enable this process, it is essential that the singlet–triplet energy difference (Δ _E_ ST) is small. In general, Δ _E_ ST is minimized by localizing the HOMO and LUMO orbitals on different fragments of the emitting molecule. This is observed in systems containing spatially separated donor (D) and acceptor (A) heterocycles with twisted linkages. Emission from such molecules occurs from intramolecular charge transfer (CT) states. It is therefore difficult to achieve a low energy gap, small Δ _E_ ST and a large fluorescence rate ( _k_ F) in one molecule<sup>29</sup> . The first successful TADF NIR-OLED employed a phenanthrene-based molecule with a small Δ _E_ ST of 0.13 eV as a non-doped emitter; it achieved an EQE of 2.1% at a peak emission of 710 nm (ref.<sup>30</sup> ). Since then, several studies have also reported NIR EL from TADF molecules, albeit with EQE values hardly exceeding 10% (refs.<sup>31–34</sup> ). These devices were mostly based on multiple 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**658** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 



<!-- Start of picture text -->
a b c<br>37.5% S2<br>RISC 2T1 T2<br>25% 25% ISC TT<br>75%<br>S1 ISC75% ∆ E ST S1 75% T2 2 S1 ISC<br>T1 IC<br>RISC T1<br>(1)FL TADF(3) PH(2) DF(4) TTA T1<br>PH (5) PH<br>S0 S0 S0<br>d Bond length Substitution g 0.7 6<br>alternation<br>Resonance 0.6 4 78<br>x energy 2<br>0.5<br>X X<br>10<br>Planarity 0.4<br>0.3 15<br>e Perylene bisimides F F 20<br>1.0 Squaraines 0.2 O B O<br>BODIPY dyes 40<br>Cyanine dyes 0.1 N O O N 60<br>0.8 Terrylene bisimides 100<br>PPCy dyes 0<br>0.6 700 720 740 760 780<br>Wavelength (nm)<br>0.4 h<br>N CF3 CF3 Bu t CF3<br>0.2 N N N N N N N N N<br>Pt Pt Pt<br>0 550 600 650 700 750 800 850 900 950 N N N N N N N N N<br>Emission wavelength (nm) CF3 N CF3 N CF3 N<br>Compound 1 Compound 2 Compound 3<br>f i<br>SOMO [S] – ‘HOMO’<br>electron hole 1.0 3<br>injection ‘SOMO’ injection 2<br>D0 D1 0.8 1<br>‘HOMO’<br>SOMO ‘SOMO’<br>0.6<br>hν<br>HOMO ‘HOMO’<br>[S, T0, T+, T–] + 0.4<br>‘SOMO’ 0.2<br>HOMO<br>injectionhole ‘HOMO’ electron‘SOMO’ 0500 600 700 800 900<br>injection<br>Wavelength (nm)<br>PLQY<br>PLQY<br>Photoluminescence intensity (normalized)<br><!-- End of picture text -->

**Fig. 2 | NIR emission from organic semiconductors. a** – **c** , Energy diagram depicting photophysical processes for light emission. **a** , Fluorescence (FL) (1), phosphorescence (PH) (2), internal conversion (IC), intersystem crossing (ISC) from singlet to triplet levels, and TADF (3), obtained upon reverse intersystem crossing (RISC). **b** , Delayed fluorescence (DF) (4) due to TTA. **c** , Singlet fission to two triplets (5). **d** , Molecular parameters controlling bandgap narrowing in organic chromophores. **e** , PLQY ( _φ_ PL) for different organic chromophores in relation to their emission wavelength. The dashed line is a guide to the eye. BODIPY, boron-dipyrromethene. PPCy, pyrrolopyrrole cyanine dyes. **f** , Electroluminescence by selective HOMO and SOMO hole and electron injection. The scheme shows two routes to create D1 (first doublet excited state). [S]<sup>−</sup> and [S, T0, T+, T−]<sup>+</sup> denote negatively and positively charged intermediates. **g** , PLQY values of CBP blend films doped with the curcuminoid NIR TADF emitter (shown as inset) at various concentrations, shown as a percentage beside each dot. **h** , **i** , Chemical structures of Pt(II) phosphorescence complexes 1–3: [Pt(fprpz)2] (compound 1), Pt(fprpz) (fppz)] (compound 2) and [Pt(fprpz)(tbfppz)] (compound 3) (where fprpz, fppz and tbfppz derive from 2-pyrazinyl pyrazole, 2-pyridyl pyrazole and 2-(4- _t_ -butylpyridyl) pyrazole, respectively) ( **h** ) and the normalized photoluminescence spectra of these emitters in thin films ( **i** ). Panels adapted with permission from: **d** , ref.<sup>21</sup> , Wiley-VCH; **f** , ref.<sup>28</sup> , Springer Nature Ltd; **h** , **i** , ref.<sup>46</sup> , Springer Nature Ltd. Panels reproduced with permission from: **e** , ref.<sup>23</sup> , Wiley-VCH; **g** , ref.<sup>32</sup> , Springer Nature Ltd. 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**659** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 

donor–acceptor (D _i_ –A _j_ ) structures. One successful example is an emitter composed of two triphenylamine donors and one acetylacetonate boron difluoride acceptor (inset in Fig. 2g)<sup>32</sup> . This material exhibited a _φ_ PL of up to 70% when doped (~6%) in a CBP host (Fig. 2g). The LEDs showed a maximum EQE of 10% (at 721 nm) and a high radiance of 3,000 W sr<sup>−1</sup> m<sup>−2</sup> , albeit at a very high _J_ of 1,000 mA cm<sup>−2</sup> . Recently, NIR TADF emitters employing simpler D–A structures with strong and planar acceptor units were found to enable _J_ -aggregate formation with strong intermolecular CT<sup>35</sup> . Favoured by the fast radiative decay rates of the aggregated emitters, the fabricated OLEDs reached an EQE of 14.1% (at 700 nm and _J_ = 10<sup>−2</sup> mA cm<sup>−2</sup> ). Through donor substitution, the intermolecular CT was further strengthened and tuned the OLED emission at 1,010 nm (ref.<sup>36</sup> ). Similarly, a D–A acenaphthene-based emitter greatly stabilized the intramolecular CT; the fabricated OLEDs displayed peak EL at 904 nm (ref.<sup>37</sup> ). Notably, apart from leveraging NIR emission, TADF molecules were recently applied as assistant dopants in hyperfluorescent OLEDs<sup>38,39</sup> , demonstrating promising EQEs up to 3.8% ( _J_ = 5 × 10<sup>−2</sup> mA cm<sup>−2</sup> ) with a narrow EL peak (full-width at half-maximum, FWHM, of 40 nm) centred at 840 nm (ref.<sup>38</sup> ). 

The most successful examples of NIR OSCs are organometallic complexes based on third-row transition metal elements, such as platinum (Pt(II)), osmium (Os(II)) and iridium (Ir(III)). In these emitters _r_ = 1, as all the triplet states can decay radiatively at room temperature owing to presence of strong spin–orbit coupling enabled by the metal element. So far, Pt(II) phosphors are the most efficient NIR emitters due to the strong metal–metal-to-ligand charge transfer (MMLCT) transition character at the excited-state manifolds and the shortest radiative lifetime for phosphorescence<sup>40</sup> . Os(II) phosphors represent the next more efficient class of NIR emitters due to the high metal-to-ligand charge transfer (MLCT) contribution, originating from the lower oxidation potential of the metal _dπ_ orbitals combined with a reduced radiative lifetime to the submicrosecond region. In contrast, Ir(III) phosphors present a longer radiative lifetime and inferior efficiency compared with Pt(II) and Os(II) ones<sup>41,42</sup> . For example, the state-of-the-art Ir(III)-based NIR-OLEDs have reached a maximum EQE of 9.59% (at 706 nm) by using cyano groups attached in a commercial red emitter Ir(III)-bis(1-phenylisoquinoline)(acetylacetonate) (Ir(piq)2(acac))<sup>43</sup> . The record-performing Os(II)-based NIR-OLEDs employ a series of _trans_ -substituted complexes combining pyrazinyl azolate chelates and dimethyl(phenyl)phosphane ancillaries<sup>44</sup> . They achieved a maximum EQE of 11.5% (at 710 nm), which remained quite high (~8.2%) for a high _J_ = 100 mA cm<sup>−2</sup> . A cyclometallated Pt(II) complex of high planarity, bearing the 1,3-di(2-pyridyl)benzene terdentate ligand with a methyl-3,5-di(2-pyridyl)benzoate substitute at C2 of the benzene ring (abbreviated as PtL<sup>2</sup> Cl), enabled NIR-OLEDs with a peak excimer emission at ∼700 nm and an EQE of 14.5% (ref.<sup>45</sup> ). 

A breakthrough in NIR-OLEDs was accomplished through the strategic design of a series of 2-pyrazinylpyrazolate Pt(II) fluorinated compounds (1–3 in Fig. 2h); they achieved extraordinary _φ_ PL of 81%, 55% and 85% in thin films at peak emission of 740 nm, 703 nm and 673 nm, respectively (Fig. 2i)<sup>46</sup> . OLEDs based on compound 1 exhibited a remarkable EQE of 24% (at 740 nm) originating from exciton-like emission along the 5dz2 direction of edge-on molecular _J_ -aggregates. Owing to the short stacking distance in these aggregates, a strong interaction among HOMO and LUMO levels was achieved, which strongly prohibited non-radiative deactivation paths through exciton–optical phonon coupling according to the energy gap law. More recently, the same group demonstrated that delocalized excitonic aggregates can decouple the exciton band from highly vibrational ladders in the ground state, thus further enhancing the _φ_ PL in the NIR region<sup>40,47</sup> . On this basis, they successfully fabricated NIR-OLEDs achieving a high EQE of 2.18% in the 

NIR region of 890–930 nm (ref.<sup>40</sup> ); added to the merits, these devices exhibited negligible efficiency roll-off for _J_ up to 500 mA cm<sup>−2</sup> . In a recent study, the non-doped emissive layer (EML) of Pt(II) emitters enabled OLEDs with EQEs >10% at 794 nm ( _J_ = 100 mA cm<sup>−2</sup> )<sup>48</sup> , with low efficiency roll-off. Compared with a host–guest EML, the complexity is reduced when no host is used, yet the required amount of Pt-containing emitters is increased. 

Pt-metalloporphyrins also enable NIR EL with narrow emission spectra. As an example, OLEDs based on Pt(II)–tetraphenyltetrabenzoporphyrin (Pt(tpbp)) presented an NIR emission spectrum centred at 765 nm with an FWHM of ~35 nm and an EQE of 6.3% ( _J_ = 0.1 mA cm<sup>−2</sup> )<sup>49</sup> . However, porphyrin-based phosphors typically suffer from efficiency roll-off due to the long-lived triplet exciton resulting in self-quenching. Lanthanide phosphors, such as erbium (Er(III)) and niobium (Nd(III)), also exhibit NIR emission bands at the 800–1,600 nm spectral region. They originate from efficient energy transfer from the triplet states of the organic ligand to the 4 _f_ states of the lanthanide core and radiative recombination therefrom. However, the fabricated OLEDs achieved poor EQEs not exceeding 0.15% (ref.<sup>50</sup> ). OLEDs based on a rubrene singlet fission sensitizer blended with a phosphorescence emitter (termed ErQ3) have also achieved NIR emission centred at 1,530 nm (ref.<sup>20</sup> ). 

**The emergence of NIR perovskite LEDs.** Metal halide perovskites exhibit an AMX3 chemical structure (Fig. 3a), where A is a monovalent cation (organic, such as methyl ammonium, MA, and formamidinium, FA, or inorganic like caesium, Cs, or their combination), M is a divalent metal such as lead (Pb<sup>2+</sup> ) or tin (Sn<sup>2+</sup> ), and X is a halide (Cl<sup>−</sup> , Br<sup>−</sup> , I<sup>−</sup> ). Their advantages for light-emitting applications include facile bandgap tunability through chemical composition, high defect tolerance, symmetric and narrow emission spectra (FWHM <40 nm) and high carrier mobilities<sup>51</sup> ; the latter is useful in achieving high brightness at low driving voltages. They can access the 400 nm to 1,100 nm NIR part of the spectrum via changes in composition and dimensionality<sup>52–56</sup> (Fig. 3a,b). To optimize the performance of NIR perovskite LEDs (NIR-PeLEDs), it is important to simultaneously maximize the radiative recombination via defect passivation while suppressing non-radiative Auger recombination. Three-dimensional (3D) perovskite emitters exhibit fast electron–hole dissociation, which decreases the probability of radiative recombination events. Strategies pursuing the confinement of charge carriers via dimensionality tailoring, reduction in the grain size and/or film thickness, and growth of perovskite nanocrystals (NCs) have been widely explored. 

The first successful NIR-PeLED employed a thin (~15 nm) EML of a mixed HP emitter, namely MAPbI3− _x_ Cl _x_ , sandwiched between two charge-injection layers<sup>57</sup> . The device achieved an EQE and internal quantum efficiency (IQE) of 0.76% and 3.4% (at 754 nm), respectively<sup>58</sup> . After this, following attempts aimed to increase the device performance and extend the peak emission wavelength further into the NIR. The most successful approaches include the development of formamidinium-based emitters such as FAPbI3 (refs.<sup>59–61</sup> ), Pb-based mixed quasi-two-dimensional (2D)/3D perovskites<sup>62,63</sup> , mixed Pb–Sn<sup>49</sup> and Pb-free perovskites with either an organic<sup>50</sup> or inorganic<sup>64</sup> cation at the A site and 2D perovskites<sup>65,66</sup> . Partial or complete replacement of the M-site cation, that is, Pb<sup>2+</sup> (ionic radius 1.19 Å), with alternative metals, such as Sn<sup>2+</sup> and germanium (Ge<sup>2+</sup> ), characterized by smaller ionic radii (1.02 Å and 0.73 Å, respectively), reduced the bandgap and redshifted the emission. For example, systematic replacement of Pb<sup>2+</sup> with Sn<sup>2+</sup> in MAPb1− _x_ Sn _x_ I3 perovskites extended the emission peak from 750 nm (for _x_ = 0) to ~950 nm ( _x_ = 0.8)<sup>52</sup> . The EML, stabilized by incorporating a large cation, for example, 4-fluorobenzylammonium iodide (FPMAI), exhibited an EQE of 5% (at ~917 nm). A longer NIR emission (at 950 nm) with an EQE of 3.8% was reported for CsSnI3 perovskite<sup>64</sup> . 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**660** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 



<!-- Start of picture text -->
a Bandgap larger (for 2D) to smaller (for 3D) Dimensionality lower to higher (2D to 3D) b<br>~1 ps<br>E2<br>n  = 1<br>n  = 3<br>X –<br>n  = 5<br>n  = ∞<br>M 2+<br>hv<br>A +<br>A′ + n  = 1 n  = ∞ E1<br>n  = 2<br>3D/2D<br>n  = 3 random  n<br>c d<br>1.0 PL<br>EL 90°<br>0.8 EL 60°<br>O EL 30°<br>0.6<br>H2N OH<br>ZnO-PEIE Perovskite precursor(5AVA/FAI/Pbl2) Annealing Spontaneously formedsubmicrometre structure 0.4<br>0.2<br>0<br>700 750 800 850 900<br>Wavelength (nm)<br>e f g<br>20<br>1 FAPbl3 0.5 DDS<br>FAPbl3 1.0 DDS 2.0 DDS<br>0.5 DDS<br>MoO x /Au h 1.0 DDS 15<br>h 2.0 DDS<br>TFB h × h<br>10<br>FAPbl3 DDS FAPbl3<br>×<br>PEIE-ZnO e e<br>e 5<br>ITO e<br>0<br>0<br>650 700 750 800 850 900 0 100 200 300 400 500 600<br>Wavelength (nm) Current density (mA cm –2 )<br>Excitation Emission<br>Normalized EL and PL (a.u.)<br>NH2<br>O S O<br>(DDS) EQE (%)<br>-diaminodiphenyl sulfone4,4′ EL intensity (normalized)<br>HN2<br><!-- End of picture text -->

**Fig. 3 | NIR light emission from perovskite LEDs. a** , Illustration of the crystal structure of dimensionally engineered halide pure-phase ( _n_ = 1, 2, 3), mixed-phase (2D/3D) and a classical polycrystalline 3D perovskite. **b** , Schematic showing energy (charge) funnelling from larger- to smaller-bandgap perovskite domains. The process takes place on an ultrafast timescale (picoseconds). **c** , Formation of submicrometre perovskite structure via solution processing. **d** , Photoluminescence (PL) and EL spectra of the device at different viewing angles. **e** – **g** , Device architecture ( **e** ), EL spectra ( **f** ) and EQE curves ( **g** ) of LEDs employing 3D perovskite nanocrystals embedded in an electron-transport molecular matrix of DDS. PEIE, polyethylenimine ethoxylated; 5AVA, 5-aminovaleric acid; TFB, poly[(9,9-dioctyl-fluorenyl-2,7-diyl)-co-(4,4′-(N-(4-secbutylphenyl) diphenylamine)]. Panels reproduced with permission from: **c** , **d** , ref.<sup>58</sup> , Springer Nature Ltd; **e** , ref.<sup>60</sup> , Springer Nature Ltd. Panels adapted with permission from: **f** , **g** , ref.<sup>60</sup> , Springer Nature Ltd. 

Point defects present in the polycrystalline films, such as A- and X-site vacancies, interstitials and Pb–X anti-sites, act as non-radiative recombination centres and require passivation approaches to suppress electronic trap states and increase _φ_ PL close to unity for efficient NIR-PeLEDs<sup>58–61,67</sup> . This can be accomplished through the incorporation of passivation agents into the precursor solution or via post-deposition treatments. Effective passivation materials contain functional groups for coordination to undercoordinated Pb<sup>2+</sup> or halide ions or ionic bonding to neutralize charged defects<sup>59</sup> . They include Lewis acid and base moieties, alkali metal ions, charged organic components and so on. For example, a breakthrough was achieved by introducing amino acid additives into the FAPbI3 precursor solutions<sup>58</sup> . These additives passivated surface defects and reduced non-radiative recombination, increasing _φ_ PL to ~70%. Moreover, they led to the spontaneous formation of submicrometre-scale structures (Fig. 3c), which improved the outcoupling efficiency and viewing angle (Fig. 3d). 

NIR-PeLEDs employing a 3D FAPbI3 perovskite EML achieved an EQE of 20.7% (at 803 nm, _J_ = 18 mA cm<sup>−2</sup> )<sup>58</sup> . Notably, these devices showed a high photon flux of 2.33 × 10<sup>20</sup> m<sup>−2</sup> s<sup>−1</sup> at the peak EQE. Amino-functionalized passivation agents have also proven effective in suppressing non-radiative recombination in FAPbI3 perovskites<sup>59</sup> . Control over the hydrogen bonding between the functional moieties of the passivation agent and the organic cation of perovskite led to a record EQE of 21.6% for NIR-PeLEDs (at 800 nm, _φ_ PL of 65%, radiance of 308 W sr<sup>−1</sup> m<sup>−2</sup> , _J_ = 15.8 mA cm<sup>−2</sup> ). 

Improvements in NIR-PeLEDs have also been accomplished using mixed 2D/3D domains that lead to an electron–hole-confining cascaded energy landscape (Fig. 3b). The carrier population is funnelled within a few picoseconds to the lowest-bandgap domains and remains confined therein such that radiative recombination and EL emission increase<sup>62,63</sup> . The spatial and energy distribution of the different domains within the perovskite films is crucial to maximize a homogeneous energy funnelling to the lowest-bandgap 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**661** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 

light-emitting domains. Addition of 1-naphthylmethylamine iodide (NMAI) into a perovskite precursor solution (FAI:PbI2) resulted in the formation of multiple quantum wells (MQWs) through self-organization<sup>62</sup> . The MQW-based LED exhibited an EQE of 11.7%. This performance originated from highly confined charge carriers within the lower-bandgap light-emitting 3D regions by the higher bandgap (2D) regions of the perovskite MQWs. The efficiency of this 2D/3D system was further improved by blending a small fraction of an insulating polymer into the perovskite EML—a technique that has been able to simultaneously reduce non-radiative defects and the refractive index of the perovskite film<sup>63</sup> . The latter also led to an enhanced light outcoupling from PeLEDs. A device using a quasi-2D/3D perovskite ((NMA)2(FA) Pb2I7) blended with an insulating polymer (poly(2-hydroxyethyl methacrylate, PHEMA)) showed an EQE of 20.1% ( _φ_ PL = 96%, EL ≈ 795 nm, _J_ = 0.1 mA cm<sup>−2</sup> )<sup>63</sup> , representing the best-performance 2D/3D HP-based NIR-PeLEDs. 

Colloidal HP NCs, pristine<sup>68–70</sup> or metal doped<sup>71–74</sup> , have recently attracted attention due to their advantages of quantum-confined emission and low defect density with no shell passivation requirements<sup>68</sup> . NIR-PeLEDs based on FAPbI3 NCs exhibited peak emission at 780 nm with an EQE of 2.3% (ref.<sup>69</sup> ), whereas those using Cs _x_ FA1− _x_ Pb(Br1− _y_ I _y_ )3 NCs exhibited a narrow (FWHM 27 nm) NIR emission at 735 nm with an EQE of 5.9% (ref.<sup>70</sup> ). In another approach, blend EMLs consisted of FAPbI3 NCs embedded in a molecular matrix that also served as the electron-transporting layer namely 4,4′-diaminodiphenyl sulfone (DDS). In this so-called perovskite–molecule composite (PMC) approach<sup>60</sup> , the DDS matrix effectively controlled the nucleation process of the perovskite NCs, leading to the formation of PMC thin films with _φ_ PL approaching 90% (Fig. 3e–g). NIR-PeLEDs with a PMC EML achieved an EQE of 17.3% (at 805 nm). Notably, the hybrid perovskite:metal NCs can achieve deeper NIR emission as they rely on energy transfer from the perovskite to the metal and emission therefrom<sup>73</sup> . As an example, ytterbium (Yb<sup>3+</sup> )-doped CsPbCl3 NCs showed NIR emission at 984 nm (EQE of 5.9%)<sup>74</sup> . 

**Progress in NIR QDLEDs.** Colloidal QDs are inorganic semiconductor NCs with emission properties that can be widely tuned through size control due to the quantum confinement effect<sup>75</sup> . They are prepared by wet chemical synthetic procedures that offer precise control over shape and size, which allows them to access the whole NIR spectrum. Their emission tunability can be achieved through increasing size and compositional engineering (Fig. 4a)<sup>76</sup> . Lead chalcogenide QDs such as lead sulfide (PbS), selenide (PbSe) and telluride (PbTe), pristine or capped, dominate the NIR applications<sup>77–79</sup> . NIR emission from silicon (Si) QDs has been also observed<sup>80</sup> . The appropriate selection of a wider-bandgap inorganic semiconductor shell epitaxially grown around the emissive QD leads to core–shell structures with significantly increased exciton binding energy<sup>81</sup> . In these structures, the electron wavefunction is shifted away from the surface to the QD core, reducing non-radiative recombination. Organic ligands also decorate the core–shell structure (Fig. 4a, inset) to enable solubility in a large variety of non-polar solvents and offer additional surface passivation<sup>82</sup> . 

In spite of the development of a large variety of NIR emissive QD species, the efficiency of NIR-QDLEDs was initially low. This was caused by self-quenching of QDs in the solid state leading to low _φ_ PL in thin films combined with moderate carrier mobilities caused by the insulating organic ligands. Auger recombination are also high in QDs. To mitigate the self-quenching limitation, the first successful NIR-QDLEDs employed EMLs consisting of QDs dispersed into an organic medium or forming a monolayer embedded between two organic interlayers. The operation of these hybrid devices was based on exciton formation in the organic host/surrounding interlayers followed by Förster energy transfer to the QDs by means of 

dipole–dipole interaction. The _φ_ PL of the EML depended critically on this energy-transfer step, which competes with various radiative and non-radiative recombination pathways. In addition, the performance of these devices was limited by the low mobility of the organic medium/surrounding interlayers and the lack of materials with suitable energetics to enhance charge injection<sup>83–86</sup> . For example, the first demonstration of an NIR-QDLED was based on core– shell indium arsenide–zinc selenide (InAs–ZnSe) QDs embedded into a poly[2-methoxy-5-(2-ethylhexyloxy)-1,4-phenylenevinylene] (MEH-PPV) matrix<sup>83</sup> . The devices exhibited emission from 1,000 nm to 1,300 nm, albeit with low EQE <0.5%. 

A breakthrough in NIR-QDLEDs was achieved through the realization of devices using pristine QD-based thick (~40–50 nm) EMLs<sup>87</sup> . In this approach, excitons are directly generated on the emissive QDs, thus enhancing the radiative recombination rates. In addition, the charge-injection efficiency was separately optimized using appropriate charge-transporting layers. As a result, a device using a neat PbS EML exhibited a maximum EQE of 1.15% (at 1,200 nm), representing a significant improvement over previous reports. A further enhancement in NIR-QDLED performance was achieved through the precise length control of the organic ligands of PbS QDs<sup>88</sup> . An optimized length of these ligands enabled the simultaneous enhancement in radiative recombination and carrier mobility in the QD films. Appropriate interlayers injected charges directly to QDs, allowing for exciton formation therein and preventing their direct contact with the electrodes, thereby avoiding plasmonic quenching. As a result, an EQE of ~2% (at 1,054 nm, _J_ = 1.0 mA cm<sup>−2</sup> ) was obtained. An interlayer engineering approach was also employed in the first reported Si QD NIR-LEDs, which displayed an EQE of 8.6% (at ~850 nm, _J_ = 0.01 mA cm<sup>−2</sup> )<sup>89</sup> . 

Some heavy metal-free QDs are considered promising for biological applications. These are either binary, such as silver (Ag) sulfide, selenide and telluride (Ag2S, Ag2Se, Ag2Te), indium phosphide and arsenide (InP, In As), or ternary copper (Cu)- or Ag-based materials (CuInSe2, CuInS2, AgInS2, AgInSe2) with tunable fluorescent properties and emission maxima up to 1,400 nm (ref.<sup>90</sup> ). However, the reported efficiencies of the fabricated NIR-QDLEDs had been low (<0.5%; ref.<sup>83</sup> ). Recently, an efficient heavy metal-free NIR-QDLED was demonstrated using a giant shell In(Zn)As–In(Zn)P–GaP–ZnS QD emitter<sup>91</sup> . Strongly luminescent QDs were prepared through a continuous injection methodology, which enabled a high _φ_ PL of 75% and NIR-LEDs with EQEs of 4.6% (at 857 nm, _J_ = 1.5 mA cm<sup>−2</sup> ). Notably, LEDs with high power and large spectral bandwidth based on InAs/GaAs QDs have also been reported<sup>92</sup> . They achieved strong emission at ∼1,255 nm, with a maximum output power of 2.6 mW at room temperature. 

Despite great progress in pristine QD-based NIR-LEDs, optimizing radiative recombination and charge injection/transport simultaneously in these devices is challenging due to their wide-bandgap inorganic shells and long-chain organic ligands, which impede carrier transport in the neat QD film<sup>93–98</sup> . Recently, this issue was successfully addressed by following a QD-in-perovskite approach using hybrid EMLs consisting of QD emitters evenly distributed in a perovskite transport medium<sup>99,100</sup> . Unlike previous approaches, where QDs were either enclosed in a protective shell and/or insulating ligand or dispersed in a low-mobility organic medium, here, PbS QDs were embedded in a high-mobility MAPbI _x_ Br3− _x_ perovskite matrix, which epitaxially grew around the QD surface, also acting as an efficient surface passivation agent. This hybrid system benefited from the high _φ_ PL of QDs and the superior carrier mobility of the perovskite medium. The halide ratio in the perovskite was finely tuned to avoid lattice mismatch, leading to defect sites that would act as traps for non-radiative recombination (Fig. 4b,c)<sup>99</sup> . QD-in-perovskite LEDs achieved 150 times higher EQE (5.2%, emission peak at 1,391 nm) and 15 times higher brightness (2.6 W sr<sup>−1</sup> m<sup>−2</sup> at 3.5 V) than a control QD-only LED. 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**662** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 



<!-- Start of picture text -->
a b MAPbl x Br3– x  matrix MAPbl3 matrix c<br>PbS–CdS QDs CdSe–ZnS QDs<br>1.0 +<br>+ Perovskite + 10 0<br>0.8 hv matrix – Trapping<br>–<br>0.6 – Iodine<br>– η inj – η diff CB 10 –1 concentration (%)<br>0.4 – – – hv – – 10091<br>0.2 η PLQE Trapping 8380<br>+ + + + + 10 –2 67<br>0 + VB<br>0.5 1.0 1.5 2.0 2.5 3.0 η tot =  η diff η inj η PLQE 10 –5 10 –4 10 –3 10 –2 10 –1 10 0<br>Energy (eV) Current density (A cm –2 )<br>d e Radiative  Non-radiative  f<br>recombination recombination<br>Recombination through non-radiative channel<br>10 1<br>e –<br>e – 10 0 Single<br>e – Binary<br>Ternary<br>L d 10 –1<br>L  d<br>10 –2<br>10 –4 10 –3 10 –2 10 –1 10 0<br>Current density (A cm –2 )<br>EQE (%)<br>Normalized photoluminescence<br>EQE (%)<br><!-- End of picture text -->

**Fig. 4 | NIR emission from colloidal QDs. a** , Normalized photoluminescence from QDs with a core–shell structure (shown as inset). **b** , QD-in-perovskite approach: radiative recombination dominates when QDs and perovskite are lattice matched (left). Lattice mismatch causes interfacial defects (dashed lines) and non-radiative recombination (right). CB and VB, conduction and valence band, respectively. _η_ PLQE, photoluminescence quantum efficiency; _η_ tot, _η_ diff and _η_ inj, total, diffusion and injection efficiency, respectively. **c** , Variation of EQE with _J_ in devices using mixed halide perovskite matrices with different iodine molar concentrations. **d** , The emitter-only QD array approach. The pink spheres are the emissive QDs and the purple spheres represent defective QDs. The charge-collection zones illustrated as yellow circles around the QDs are defined by the carrier diffusion length ( _L_ d). **e** , The matrix inclusion architecture. Large QDs are dispersed in a matrix of smaller QDs. Radiative recombination channels (green circles) increase whereas non-radiative recombination channels decrease. **f** , EQE of the single, binary and ternary devices plotted against injected current. Panels adapted with permission from: **a** , ref.<sup>75</sup> , Springer Nature Ltd. Panels reproduced with permission from: **b** , **c** , ref.<sup>99</sup> , Springer Nature Ltd; **d** – **f** , ref.<sup>103</sup> , Springer Nature Ltd. 

This approach was further optimized through the incorporation of PbS QDs in a low-dimensional layered perovskite<sup>101</sup> . The number of perovskite repeated units < _n_ > confined between bulk organic cations determined the bandgap and exciton binding energy of the resultant quantum well. This allowed transitioning from a fully excitonic character ( _n_ = 1, 2) to a mixed scenario where free charges and excitons coexist ( _n_ > 2). This was leveraged to manipulate energy transfer into the QDs, achieving balanced charge transport into the QD emitters and hence minimizing Auger recombination. The devices achieved tunable emission in the 980–1,600 nm spectral region with a maximum EQE of 8.1% (at 980 nm, _J_ = 1.65 mA cm<sup>−2</sup> , radiance of 7.4 W sr<sup>−1</sup> m<sup>−2</sup> ). In another case, non-toxic silicon dioxide (SiO2)-encapsulated Ag2S QDs were epitaxially dispersed in a caesium-containing triple cation perovskite matrix<sup>102</sup> . The optimized NIR-LEDs demonstrated an EQE of 17.0% (at 1,397 nm, _J_ = 11.28 mA cm<sup>−2</sup> ), originating from charge balance close to unity enabled by a thin porphyrin hole-transporting interlayer that also protected the perovskite matrix from metal oxide (that is, molybdenum oxide)-induced degradation. 

A different approach employed an EML composed of a ternary blend, including a binary host matrix and the QD emitters. This matrix consisted of small-size, wide-bandgap PbS QDs that electronically passivated the larger-size, low-bandgap PbS QD emitters blended with zinc oxide (ZnO) NCs to balance carrier supply<sup>103</sup> . The larger-size emitters exhibited reduced non-radiative recombination rates and balanced charge injection (Fig. 4d–f). The fabricated QDLEDs showed a peak emission at 1,400 nm with an EQE of ~7.9%, which is the highest reported value for any NIR-QDLED 

based on a neat QD EML. The same authors have recently achieved a higher EQE of 8.0% through further engineering at the supra-nanocrystalline level and optimization of charge carrier balance within the device<sup>104</sup> . 

## **comparison of different solution-processed NIR-LEDs** 

OLEDs and PeLEDs have already achieved high EQEs over 20% at wavelengths <1,000 nm, whereas QDLEDs can span a larger part of the NIR spectrum with emission up to 1,500 nm, albeit with lower efficiencies (Fig. 5a and Supplementary Table 1). Metal halide perovskites and QDs generally enable response speeds of ~100 ns (refs.<sup>105,106</sup> ), whereas OSCs based on CT states have reached response times of 14.7 ns (ref.<sup>107</sup> ). However, hybrid perovskite–polymer materials have reached high speeds of 5 ns (ref.<sup>108</sup> ), whereas QDs recently attained an ultrafast response of 74 ps (FWHM)<sup>109</sup> , by allowing carriers to be swept to the electrodes before they fall into the band tail states; these values indicate that these solution-based semiconductors will be soon appropriate for NIR applications with high-speed requirements. Device engineering and the design and development of novel emitters have played a crucial role to reach such performance. 

**Interface engineering and light outcoupling approaches.** The aforementioned classes of NIR-LEDs require similar architectural design considerations that mainly target the reduction of charge-injection barriers, blocking of carrier leakage and exciton confinement within the EML. They have all benefited from a rich knowledge gathered through progress in visible OLEDs from 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**663** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 



<!-- Start of picture text -->
a b 20<br>30 NIR-I Telecom NIR-II O-band<br>18 3D PeLED<br>(729 nm )<br>15 15 Hybrid<br>QDLED (1,301 nm)<br>13<br>0 QDLED (1,400 nm)<br>700 800 900 1,000 1,100 1,200 1,300 1,400 1,500 1,600 10 3D µ-PeLED<br>Wavelength (nm) (754 nm)<br>8<br>30 NIR-I OLEDs<br>PeLEDs 5<br>20 QDLEDs<br>3<br>10 0 2D PeLED<br>QLED (725 nm) PHOLED (930 nm) (755 nm)<br>–3<br>0 10 –1 10 0 10 1 10 2 10 3 10 4<br>700 750 800 850 900 950<br>Current density (mA cm –2 )<br>Wavelength (nm)<br>c d<br>1,000 OLED   T 50<br>OLED  > T 85<br>1,000 PeLED  T 50<br>7,400 W m –2 OLEDs QDLED  T 50<br>100 QDLED > T 85<br>100<br>10<br>QDLEDs<br>1 PeLED 10 PeLEDs<br>Hybrid QDLED<br>QDLED<br>0.1 OLED 1<br>1 × 10 –5 0.001 0.1 10 8,000 10 0 10 1 10 2 10 3<br>Radiance (W sr –1  m –2 )/irradiance (W m –2 ) Current density (mA cm –2 )<br>EQE (%)<br>EQE (%)<br>EQE (%)<br>Lifetime (h) Lifetime (h)<br><!-- End of picture text -->

**Fig. 5 | Figures of merit of NIR-LEDs. a** , EQE versus wavelength of solution-processed NIR-LEDs based on results of Supplementary Table 1. **b** , EQE roll-off of state-of-the-art TADF<sup>32</sup> and phosphorescence<sup>40</sup> OLED, QDLED<sup>103</sup> , hybrid (QD-in-perovskite) QDLED<sup>101</sup> , 3D<sup>61</sup> and 2D<sup>65</sup> PeLEDs, and 3D μ-PeLED<sup>128</sup> as a function of current density. μ-PeLED, micrometre-sized perovskite LED; PHOLED, phosphorescent OLED. **c** , **d** , Reported lifetime of various solution-processed NIR-LEDs based on the data provided in Supplementary Table 2. In **c** , the lifetime is plotted versus the initial device radiance (given in W sr<sup>−1</sup> m<sup>−2</sup> ) except for the OLED device where the initial irradiance is presented. In **d** , the lifetime is plotted versus injected current density into the device. _T_ 85 and _T_ 50 (or half-lifetime) denote the time of constant operation until the light output decreases to 85% and 50%, respectively, of the initial value. 

which they have borrowed charge-transporting interlayers, such as organic small molecules, polymers and metal oxides with appropriate energy landscapes. Extra caution, however, should be paid as physicochemical interactions between these materials and novel emitters, for example, perovskite ones, may negatively impact on the device performance and reliability<sup>110</sup> . Besides high efficiency, other device performance metrics such as EQE roll-off and operational lifetime are improved through interface engineering as explained in the next sections. 

Light trapping is a critical factor that restricts the thin-film LED efficiency. For example, the high EQE of GaAs NIR-LEDs (~72%; ref.<sup>6</sup> ) would be <5% without the application of complex mirror structures to extract light in the viewing angle. The low outcoupling efficiency of thin-film LEDs is due to the waveguide modes in the multilayered sandwich structures and plasmonic quenching at the metallic electrode. In addition, the photon reabsorption by the EML and the low transmittance of the indium-tin-oxide (ITO) transparent electrode also contribute to efficiency losses. The waveguide modes have the major contribution in light propagation losses; they divide into the glass total internal reflection and the ITO/functional layers guided mode. They are regulated by Snell’s law according to the refractive indices of the EML (that is, 1.7–2.0 for OSCs<sup>111</sup> , and >2.0 for perovskites and QDs<sup>111,112</sup> ), ITO (~2.0), glass substrate (1.5) and ambient air (1.0), with the _η_ out of these devices limited 

at 20–25%. Due to the high refractive indices of perovskites and QDs compared with those of the substrate and the commonly used charge-transporting interlayers, a large portion of the generated light is confined in the EML and propagates in the lateral direction, which further compromises _η_ out. 

To enhance light outcoupling, numerous low-cost methods have been advanced, including patterned or roughened substrates using wet-etching methods or insertion of low-index materials on the substrate/air interface to extract substrate modes, low-index grids and index-matched functional layers for extracting waveguide modes and corrugated metal electrodes for plasmonic modes<sup>111</sup> . However, adopting simpler methods, such as manipulating the emitter’s morphology<sup>113</sup> , inducing spontaneous formation of submicrometre-scale structures<sup>58</sup> , enhancing horizontal orientation of emissive dipoles<sup>46</sup> , applying cavity engineering and top emitting devices<sup>114,115</sup> , using small-thickness EMLs<sup>116</sup> , tuning the width in MQW structures<sup>111,114</sup> or enhancing photon recycling<sup>117</sup> , can beneficially influence light extraction without increasing device fabrication cost and complexity. 

**Low power output, EQE roll-off and lifetime in solution-processed NIR-LEDs.** To meet the technical specifications of III–V LEDs for commercial applications, these solution-processed NIR-LEDs need a stable power output of ~10–100 mW for wavelengths 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**664** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 

_λ_ < 1,000 nm and up to several milliwatts for _λ_ > 1,200 nm (at a _J_ of 1,000–2,000 mA cm<sup>−2</sup> ). For example, for surveillance or night-vision applications (850–900 nm), the requirements are for a power output of 10–100 mW, which is equivalent to an irradiance of 10<sup>3</sup> –10<sup>4</sup> mW cm<sup>−2</sup> . For bioimaging in the first and second biological windows (Fig. 1a), the requirements are for 10–100 mW cm<sup>−2</sup> depending on the wavelength of interest. The recent developments in all three classes of the solution-processed NIR-LEDs indicate that these devices will soon have the potential for applications with lower-power output demands such as bioimaging. 

Another major issue in all LED technologies is the drop of EQE at high _J_ , the so-called EQE roll-off, which has been generally attributed to charge imbalance, field-induced quenching of luminescence, Auger recombination and Joule heating<sup>118</sup> . The considerable EQE roll-off also indicates that these devices are subjected to increased electrical stress to achieve a given radiance, which in turn reduces the useful lifetime; that is, the time after which the radiance (or EQE) drops below a predefined level. In OLEDs, in particular, as the carrier concentration increases, the bound electron–hole pairs or excitons get annihilated<sup>119</sup> and EQE typically drops at _J >_ 100 mA cm<sup>−2</sup> . Apart from these reasons, notable underlying processes for such efficiency loss are singlet–triplet and triplet– triplet annihilation, as well as host-induced quenching (in doped OLEDs)<sup>120</sup> . Through careful design of novel emitters, judicious engineering of the host–guest system and adoption of non-doped EMLs based on _J_ -aggregated emitters, suppression of various inherent loss processes has been achieved. We note the exceptional examples of NIR-OLEDs based on the boron difluoride curcuminoid TADF emitter<sup>32</sup> , or on Pt(II) complexes forming _J_ -aggregates<sup>40</sup> , which showed negligible EQE roll-off for _J_ values up to 700 mA cm<sup>−2</sup> and 500 mA cm<sup>−2</sup> , respectively (Fig. 5b). Moreover, OLEDs have demonstrated a moderate lifetime of ×100–1,000 h at _J_ < 50 mA cm<sup>−2</sup> (Fig. 5c,d and Supplementary Table 2). Notorious reasons for low lifetime are exciton quenching mechanisms explained above, presence of impurities in the EML, appearance of dark spots, oxidation, corrosion and electrochemical degradation, all caused by the attack of moisture<sup>121</sup> . Besides successful encapsulation, device engineering targeting the alleviation of exciton quenching and broadening of the emission zone boosts operational stability<sup>24</sup> . For example, incorporation of diketopyrrolopyrrole emitters in a polymer medium demonstrated OLEDs with improved durability<sup>119</sup> . Nevertheless, the device stability will need to be improved to enable practical applications (>10,000 h depending on the type of application). Encouraging in these regards are the OLEDs using wide-bandgap perovskite charge-injection interlayers<sup>122</sup> . 

QDLEDs suffer from severe EQE roll-off<sup>103</sup> (Fig. 5b), which originates, apart from charge-injection imbalance and Auger recombination rates, by the formation of electric fields inside the QDs, known as the quantum-confined Stark effect<sup>123</sup> . This causes a redshift of the exciton emission energy accompanied by a strong separation of electron–hole wavefunctions that dramatically decreases luminescence efficiency. When QDs are dispersed in a high-mobility perovskite matrix, this phenomenon is suppressed due to an increase in the carrier density that screens the QD field. Reduced Auger recombination is also expected in the QD-in-perovskite architecture due to the epitaxial passivation provided by the perovskite matrix and reduced energetic disorder, ultimately promoting radiative decay pathways<sup>124</sup> . For example, the incorporation of PbS QDs in a quasi-2D perovskite EML<sup>101</sup> has been reported to result in balanced charge injection up to high currents nearing _J_ = 170 mA cm<sup>−2</sup> . The devices showed a maximum EQE of ~8% and threshold current density ( _J_ 0, corresponding to 50% EQE drop) approaching 400 mA cm<sup>−2</sup> . This approach has also led to improved operational stability as the main device degradation mechanisms have been alleviated (Fig. 5c,d). QDLEDs using a binary blend of small- and large-size PbS QDs exhibited an estimated half-lifetime ( _T_ 50) of 

more than 26,000 h (at initial radiance of 1 W sr<sup>−1</sup> m<sup>−2</sup> )<sup>104</sup> , paving the way for durable QDLEDs operating at low brightness. 

Perovskites possess high carrier mobilities compared with OSCs and QDs, which implies that charges are spread uniformly in the EML even at higher _J_ , mitigating Auger recombination<sup>125</sup> . Therefore, NIR-PeLEDs show a lower EQE roll-off and a _J_ 0 between 300 mA cm<sup>−2</sup> and 1,500 mA cm<sup>−2</sup> . For example, PeLEDs employing a 3D perovskite Cs0.17FA0.83PbI2.5Br0.5 with an excess of FAI as the EML showed an EQE of 17.4% with a negligible roll-off up to _J_ = 600 mA cm<sup>−2</sup> (Fig. 5b)<sup>61</sup> . Similarly, PeLEDs based on 2D perovskites retained a nearly stable EQE for _J_ = 1,500 mA cm<sup>−2</sup> (Fig. 5b)<sup>65</sup> . The observed EQE roll-off in these devices is due to Joule heating, a mechanism that is more critical for PeLEDs than for other types of LED. In fact, even small temperature changes significantly affect the device efficiency and induce severe EQE roll-off<sup>116</sup> . Joule heating originates from inefficient charge injection into the EML, conductivity mismatch between the perovskite and charge-transporting interlayers, and poor perovskite film morphology that can increase series resistance. Selecting suitable interlayers, pristine or doped<sup>126,127</sup> , optimizing the device geometry, using sapphire substrates to better dissipate heat or attaching heat spreaders and sinks, downscaling the device active area or driving these LEDs with current pulses are a few of the adopted thermal management strategies<sup>128,129</sup> . For example, through employing a polymer hole-transporting layer with high ionization energy, large-area (900 mm<sup>2</sup> ) NIR-PeLEDs emitting at 799 nm with a high EQE of 12.1% (EQE of small area devices 20.2%) were successfully demonstrated<sup>127</sup> . Higher lifetime is generally accomplished in pure-phase 2D, mixed-phased 2D/3D and passivated 3D PeLEDs where mobile ions and defects are significantly suppressed<sup>130–133</sup> . Alleviating Joule heating and interface degradation<sup>132,134</sup> has prolonged the lifetime of PeLEDs considerably. 

**Issues of some emitters.** The presence of toxic elements, such as Pb in HPs and Cd in QDs<sup>135</sup> , and the high costs of noble metals in phosphorescent complexes raises concerns about the suitability of such materials for consumer electronics. The European Restriction of Hazardous Substances Directive (RoHS) has set strict rules about the use of toxic elements in electronic equipment. The current limit is 1,000 ppm for Pb and 100 ppm for Cd by weight of solid device components. Commercially available QD TV displays use QD quantities within the RoHS limits (a 55-inch display requires about 1.5 mg of Cd). This will also stand for perovskites, which have an identical extinction coefficient (of the order of 10<sup>5</sup> cm<sup>−1</sup> M<sup>−1</sup> ) to QDs and similar _φ_ PL at the same emission wavelengths (530 nm and 630 nm). Although efforts to find environmentally benign alternatives are also underway, up to now OLEDs based on fluorescent and TADF emitters are the elective choice for in vivo biomedical applications, where the material’s low toxicity is an advantage. 

## **outlook and future directions** 

The inherent suitability of solution-processed semiconductors for large-area applications allows unparalleled design freedom in developing novel concepts in illumination systems. As highlighted in this Review, considerable progress in the development of narrow-bandgap emissive materials and device engineering has already been accomplished in recent years, leading to high-performance solution-processed NIR-LEDs. Primary challenges still remain in terms of high radiance, especially in the longer wavelength range, and long operation stability. 

**Challenges associated with pristine emitters.** From a material-engineering point of view, synthetic approaches have recently contributed towards the improved device performance as they led to emitters with radiative efficiency approaching unity. However, intrinsic material limitations pose restrictions on how 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**665** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 

much the bandgap of OSCs and HPs can be effectively decreased, constituting their emission efficient for wavelengths up to 1,000 nm for the former and below 900 nm for the latter class. QDs can efficiently span most of the NIR spectrum through the size confinement effect, albeit with lower efficiencies. 

Appropriate manipulation in the chemical design of OSCs and chromophores has led to some notable performance levels in OLEDs in the 700–1,000 nm wavelength region. Extending their luminescence into the infrared can be pursued by the design of molecules possessing a shallow potential energy surface in their ground state, so that non-radiative recombination originating from high-frequency vibrational quenching would be significantly suppressed. Alternatively, _J_ -aggregated emitters allowing long-wavelength emission from CT states also offer a viable path to redshift the emission wavelengths without compromising the device efficiency and stable operation. 

Perovskites show high performance levels with narrow emission spectra, albeit at shorter wavelengths in the NIR region. Control over their composition/dimensionality raises the prospect of further expanding their luminescence efficiency. Moreover, most of the passivation methods applied to tackle the high-defect-density issue were borrowed from the solar cell research community using trial-and-error approaches. With the increased demand for extended stability, these approaches are now starting to reach their limits, such that future major advances will require new methodologies that can analyse the material and device characteristics and establish useful guidelines for rational device optimization. 

The unique optical properties of colloidal QDs have motivated an early surge of interest for their application in NIR-LEDs. However, the low carrier mobility of thin-film QDs has precluded the achievement of high performance. The recently proposed ternary QD and QD-in-perovskite hybrid solutions offer a promising path to overcome this limitation, enabling QDLEDs with performance metrics similar to those of OLEDs and PeLEDs at much longer wavelengths. These hybrid approaches are characterized by the simultaneous achievement of high mobility and enhanced non-radiative recombination rates not observed in independent QD emitters. Therefore, the hybrid systems offer all the advantages of individual counterparts, including the long-wavelength emission, and are likely to play a central role in the next generation of NIR-LEDs. 

The hybrid materials can indeed create functionalities that couldn’t have been possible otherwise. Apart from the QD-in-perovskite approach, the perovskite–organic molecule composite represents a nice example of how to overcome the weaknesses and strengthen the advantages of individual components to some extent. In the same direction could be the implementation of high-mobility ambipolar perovskite host matrices combined with _J_ -aggregated or open-shell OSCs to alleviate constraints relative to moderate charge carrier mobility of the OSC class. Inclusion of perovskite single crystals into conjugated polymer matrices to form EMLs with a continuous transport phase or substitution of insulating ligands of QDs with high-mobility OSCs directly anchored onto the QD surface are some examples that might offer viable future solutions. An added advantage of these hybrid materials comes from the inherent solution processability of the individual components that facilitates their easy integration into devices and systems to eventually transform present materials and prototypes into a promising technology. 

**Limitations associated with the device design and operation.** From the device-engineering point of view, considerable progress has already been made based on advances in charge-transporting interlayers developed for the more mature visible emitting OLED and QDLED technologies. However, extra caution is needed before the application of conventional and novel interfacial materials in devices embedding HPs due to the suspected physicochemical 

interaction at the heterointerfaces. Moreover, since the commonly used ITO transparent electrode presents high absorption in the NIR, considering its replacement with alternative electrodes, such as silver nanowires<sup>136</sup> , will offer advantages with respect to high efficiency and cost effectiveness. 

Challenges remain when targeting high and stable power output. Significant efficiency roll-off at elevated _J_ and moderate lifetimes below the 10,000 h target remain key obstacles before the commercialization of these devices. Besides the design of novel emitters, ingenious device engineering, suitable encapsulation, and successful management of thermal and electrical stress will prolong the device lifespan considerably as they successfully counter the intrinsic and extrinsic degradation mechanisms. To conclude, LEDs based on OSCs, HPs and QDs, pristine and hybridized, are suitable for many established and emerging NIR lighting applications. There are, of course, important challenges ahead. As research continues to progress both in the development of emitters and devices, we can expect even more advanced performances through deepening of the physical understanding and optimization of each technology combined with fruitful interactions and increased influence between them. 

Received: 4 December 2020; Accepted: 1 July 2021; Published online: 27 August 2021 

## **References** 

1. Gu, Y. Y. et al. High-sensitivity imaging of time-domain near-infrared light transducer. _Nat. Photon._ **13** , 525–531 (2019). 

2. Smith, A. M., Mancini, M. C. & Nie, S. Second window for in vivo imaging. _Nat. Nanotechnol._ **4** , 710–711 (2009). 

3. Ramaswami, R. Optical fiber communication: from transmission to networking. _IEEE Commun. Mag._ **40** , 138–147 (2002). 

4. Wu, X. et al. Dye-sensitized core/active shell upconversion nanoparticles for optogenetics and bioimaging applications. _ACS Nano_ **10** , 1060–1066 (2016). 

5. Mokkapati, S. & Jagadish, C. III–V compound SC for optoelectronic devices. _Mater. Today_ **12** , 22–32 (2009). 

6. Schnitzer, I., Yablonovitch, E., Caneau, C. & Gmitter, T. J. Ultrahigh spontaneous emission quantum efficiency, 99.7% internally and 72% 

   - externally, from AlGaAs/GaAs/AlGaAs double heterostructures. _Appl. Phys. Lett._ **62** , 131 (1993). 

7. Broell, M. et al. New developments on high efficiency infrared and InGaAlP light emitting diodes at OSRAM opto-semiconductors. _Proc. SPIE_ **9003** , 90030L (2014). 

8. Mao, M. et al. Broadband near-infrared (NIR) emission realized by the crystal-field engineering of Y3− _x_ Ca _x_ Al5− _x_ Si _x_ O12:Cr<sup>3+</sup> ( _x_ = 0–2.0) garnet phosphors. _J. Mater. Chem. C_ **8** , 1981–1988 (2020). 

9. Zhong, Y. & Dai, H. A mini-review on rare-earth down-conversion nanoparticles for NIR-II imaging of biological systems. _Nano Res._ **13** , 1281–1294 (2020). 

10. Liu, S., Wang, Z., Cai, H., Song, Z. & Liu, Q. Highly efficient near-infrared phosphor LaMgGa11O19:Cr<sup>3+</sup> . _Inorg. Chem. Front._ **7** , 1467–1473 (2020). 

11. Zampetti, A., Minotto, A. & Cacialli, F. Near-infrared (NIR) organic light-emitting diodes (OLEDs): challenges and opportunities. _Adv. Funct. Mater._ **29** , 1807623 (2019). 

12. Kumawat, N. K., Dey, A., Narasimhan, K. L. & Kabra, D. Near infrared to visible electroluminescent diodes based on organometallic halide perovskites: structural and optical investigation. _ACS Photon._ **2** , 349–354 (2015). 

13. Sargent, E. H. Infrared quantum dots. _Adv. Mater._ **17** , 515–522 (2005). 

14. Mikhnenko, O. V., Blom, P. W. M. & Nguyen, T.-Q. Exciton diffusion in organic semiconductors. _Energy Environ. Sci._ **8** , 1867–1888 (2015). 

15. Voznyy, O., Sutherland, B. R., Ip, A. H., Zhitomirsky, D. & Sargent, E. H. Engineering charge transport by heterostructuring solution-processed semiconductors. _Nat. Rev. Mater._ **2** , 17026 (2017). 

16. Liu, X.-K. et al. Metal halide perovskites for light-emitting diodes. _Nat. Mater._ **20** , 10–21 (2021). 

17. Zhang, Y. et al. Near-infrared emitting materials _via_ harvesting triplet excitons: molecular design, properties, and application in organic light emitting diodes. _Adv. Opt. Mater._ **6** , 1800466 (2018). 

18. Uoyama, H., Goushi, K., Shizu, K., Nomura, H. & Adachi, C. Highly efficient organic light-emitting diodes from delayed fluorescence. _Nature_ **492** , 234–238 (2012). 

19. Adachi, C. Third-generation organic electroluminescence materials. _Jpn J. Appl. Phys._ **53** , 060101 (2014). 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**666** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 

20. Nagata, R., Nakanotani, H., Potscavage, W. J. Jr. & Adachi, C. Exploiting singlet fission in organic light-emitting diodes. _Adv. Mater._ **30** , 1801484 (2018). 

21. Roncali, J. Molecular engineering of the band gap of π‐conjugated systems: facing technological applications. _Macromol. Rapid Commun._ **28** , 1761–1775 (2007). 

22. Englman, R. & Jortner, J. The energy gap law for radiationless transitions in large molecules. _Mol. Phys._ **18** , 145–164 (1970). 

23. Mayerhoffer, U., Gsanger, M., Stolte, M., Fimmel, B. & Wurthner, F. Synthesis and molecular properties of acceptor-substituted squaraine dyes. _Chem. Eur. J._ **19** , 218–232 (2013). 

24. Minotto, A. et al. Efficient near-infrared electroluminescence at 840 nm with “metal-free” small-molecule:polymer blends. _Adv. Mater._ **30** , 1706584 (2018). 

25. Minotto, A. et al. Towards efficient near-infrared fluorescent organic light-emitting diodes. _Light Sci. Appl._ **10** , 18 (2021). 

26. Peng, Q., Obolda, A., Zhang, M. & Li, F. Organic light-emitting diodes using a neutral π radical as emitter: the emission from a doublet. _Angew. Chem. Int. Ed._ **54** , 7091–7095 (2015). 

27. Guo, H. et al. High stability and luminescence efficiency in donor–acceptor neutral radicals not following the Aufbau principle. _Nat. Mater._ **18** , 977–984 (2019). 

28. Ai, X. et al. Efficient radical-based light-emitting diodes with doublet emission. _Nature_ **563** , 536–540 (2018). 

29. Yamanaka, T., Nakanotani, H., Hara, S., Hirohata, T. & Adachi, C. Near-infrared organic light-emitting diodes for biosensing with high operating stability. _Appl. Phys. Express_ **10** , 074101 (2017). 

30. Wang, S. et al. Highly efficient near-infrared delayed fluorescence organic light emitting diodes using a phenanthrene-based charge-transfer compound. _Angew. Chem. Int. Ed._ **54** , 13068–13072 (2015). 

31. Yuan, Y. et al. Over 10% EQE near-infrared electroluminescence based on a thermally activated delayed fluorescence emitter. _Adv. Funct. Mater._ **27** , 1700986 (2017). 

32. Kim, D. H. et al. High-efficiency electroluminescence and amplified spontaneous emission from a thermally activated delayed fluorescent near-infrared emitter. _Nat. Photon._ **12** , 98–104 (2018). 

33. Ye, H. et al. Near-infrared electroluminescence and low threshold amplified spontaneous emission above 800 nm from a thermally activated delayed fluorescent emitter. _Chem. Mater._ **30** , 6702–6710 (2018). 

34. Hu, Y. et al. Efficient near‐infrared emission by adjusting the guest–host interactions in thermally activated delayed fluorescence organic light‐ emitting diodes. _Adv. Funct. Mater._ **28** , 1802597 (2018). 

35. Xue, J. et al. Highly efficient thermally activated delayed fluorescence via _J_ -aggregates with strong intermolecular charge transfer. _Adv. Mater._ **31** , 1808242 (2019). 

36. Liang, Q., Xu, J., Xue, J. & Qiao, J. Near-infrared-II thermally activated delayed fluorescence organic light-emitting diodes. _Chem. Commun._ **56** , 8988–8991 (2020). 

37. Congrave, D. G. et al. A simple molecular design strategy for delayed fluorescence toward 1,000 nm. _J. Am. Chem. Soc._ **141** , 18390–18394 (2019). 

38. Shahalizad, A. et al. Efficient solution-processed hyperfluorescent OLEDs with spectrally narrow emission at 840 nm. _Adv. Funct. Mater._ **31** , 2007119 (2021). 

39. Brodeur, J. et al. Highly efficient and spectrally narrow near-infrared fluorescent OLEDs using a TADF-sensitized cyanine dye. _Adv. Optical Mater._ **7** , 1901144 (2019). 

40. Wei, Y. C. et al. Overcoming the energy gap law in near-infrared OLEDs by exciton–vibration decoupling. _Nat. Photon._ **14** , 570–577 (2020). 

41. Xue, J. et al. Homoleptic facial Ir(III) complexes via facile synthesis for high-efficiency and low-roll-off near-infrared organic light-emitting diodes over 750 nm. _Chem. Mater._ **29** , 4775–4782 (2017). 

42. Lee, T.-C. et al. Rational design of charge‐neutral, near‐infrared‐emitting osmium(II) complexes and OLED fabrication. _Adv. Funct. Mater._ **19** , 2639–2647 (2009). 

43. Chen, Z. et al. A simple and efficient approach toward deep-red to near-infrared-emitting iridium(III) complexes for organic light-emitting diodes with external quantum efficiencies of over 10%. _Chem. Sci._ **11** , 2342–2349 (2020). 

44. Yuan, Y. et al. Boosting efficiency of near‐infrared organic light‐emitting diodes with Os(II)‐based pyrazinyl azolate emitters. _Adv. Funct. Mater._ **30** , 1906738 (2020). 

45. Cocchi, M., Kalinowski, J., Virgili, D. & Williams, J. A. G. Excimer-based red/near-infrared organic light-emitting diodes with very high quantum efficiency. _Appl. Phys. Lett._ **92** , 113302 (2008). 

46. Tuong, Ly,K. et al. Near-infrared organic light-emitting diodes with very high external quantum efficiency and radiance. _Nat. Photon._ **11** , 63–68 (2017). 

47. Chen, W.-C. et al. Modulation of solid‐state aggregation of square‐planar Pt(II) based emitters: enabling highly efficient deep‐red/near infrared electroluminescence. _Adv. Funct. Mater._ **30** , 2002494 (2020). 

48. Wang, S. F. et al. Highly efficient near-infrared electroluminescence up to 800 nm using platinum(II) phosphors. _Adv. Funct. Mater._ **30** , 2002173 (2020). 

49. Borek, C. et al. Highly efficient, near-infrared electrophosphorescence from a Pt–metalloporphyrin complex. _Angew. Chem. Int. Ed._ **46** , 1109–1112 (2007). 

50. Jinnai, K., Kabe, R. & Adachi, C. A near-infrared organic light-emitting diode based on an Yb(III) complex synthesized by vacuum co-deposition. _Chem. Commun._ **53** , 5457–5460 (2017). 

51. Sutherland, B. R. & Sargent, E. H. Perovskite photonic sources. _Nat. Photon._ **10** , 295–302 (2016). 

52. Qiu, W. et al. Mixed lead–tin halide perovskites for efficient and wavelength-tunable near-infrared light-emitting diodes. _Adv. Mater._ **31** , 1806105 (2019). 

53. Lai, M. L. et al. Tunable near-infrared luminescence in tin halide perovskite devices. _J. Phys. Chem. Lett._ **7** , 2653–2658 (2016). 

54. Smith, M. D., Connor, B. A. & Karunadasa, H. I. Tuning the luminescence of layered halide perovskites. _Chem. Rev._ **119** , 3104–3139 (2019). 

55. Akkerman, Q. A., Rainò, G., Kovalenko, M. V. & Manna, L. Genesis, challenges and opportunities for colloidal lead halide perovskite nanocrystals. _Nat. Mater._ **17** , 394–405 (2018). 

56. Xing, G. et al. Low-temperature solution-processed wavelength-tunable perovskites for lasing. _Nat. Mater._ **13** , 476–480 (2014). 

57. Tan, Z.-K. et al. Bright light-emitting diodes based on organometal halide perovskite. _Nat. Nanotechnol._ **9** , 687–692 (2014). 

58. Cao, Y. et al. Perovskite light-emitting diodes based on spontaneously formed submicrometre-scale structures. _Nature_ **562** , 249–253 (2018). 

59. Xu, W. et al. Rational molecular passivation for high-performance perovskite light-emitting diodes. _Nat. Photon._ **13** , 418–424 (2019). 

60. Wang, H. et al. Perovskite–molecule composite thin films for efficient and stable light-emitting diodes. _Nat. Commun._ **11** , 891 (2020). 

61. Jia, Y.-H. et al. Role of excess FAI in formation of high-efficiency FAPbI3-based light-emitting diodes. _Adv. Funct. Mater._ **30** , 1906875 (2020). 

62. Wang, N. et al. Perovskite light-emitting diodes based on solution-processed self-organized multiple quantum wells. _Nat. Photon._ **10** , 699–704 (2016). 

63. Zhao, B. et al. High-efficiency perovskite–polymer bulk heterostructure light-emitting diodes. _Nat. Photon._ **12** , 783–789 (2018). 

64. Hong, W.-L. et al. Efficient low-temperature solution-processed lead-free perovskite infrared light-emitting diodes. _Adv. Mater._ **28** , 8029–8036 (2016). 

65. Yang, R. et al. Oriented quasi-2D perovskites for high performance optoelectronic devices. _Adv. Mater._ **30** , 1804771 (2018). 

66. Tsai, H. et al. Stable light-emitting diodes using phase-pure Ruddlesden– Popper layered perovskites. _Adv. Mater._ **30** , 1704217 (2018). 

67. Giuri, A. et al. Ultra-bright near-infrared perovskite light-emitting diodes with reduced efficiency roll-off. _Sci. Rep._ **8** , 15496 (2018). 

68. Kovalenko, M. V., Protesescu, L. & Bodnarchuk, M. I. Properties and potential optoelectronic applications of lead halide perovskite nanocrystals. _Science_ **358** , 745–750 (2017). 

69. Protesescu, L. et al. Dismantling the “red wall” of colloidal perovskites: highly luminescent formamidinium and formamidinium–cesium lead iodide nanocrystals. _ACS Nano_ **11** , 3119–3134 (2017). 

70. Lignos, I. et al. Exploration of near-infrared-emissive colloidal multinary lead halide perovskite nanocrystals using an automated microfluidic platform. _ACS Nano_ **12** , 5504–5517 (2018). 

71. Pan, G. et al. Doping lanthanide into perovskite nanocrystals: highly improved and expanded optical properties. _Nano Lett._ **17** , 8005–8011 (2017). 

72. Shen, X. et al. Zn-alloyed CsPbI3 nanocrystals for highly efficient perovskite light-emitting devices. _Nano Lett._ **19** , 1552–1559 (2019). 

73. Milstein, T. J., Kroupa, D. M. & Gamelin, D. R. Picosecond quantum cutting generates photoluminescence quantum yields over 100% in ytterbium-doped CsPbCl3 nanocrystals. _Nano Lett._ **18** , 3792–3799 (2018). 

74. Ishii, A. & Miyasaka, T. Sensitized Yb<sup>3+</sup> luminescence in CsPbCl3 film for highly efficient near-infrared light-emitting diodes. _Adv. Sci._ **7** , 1903142 (2020). 

75. Shirasaki, Y., Supran, G. J., Bawendi, M. G. & Bulovic, V. Emergence of colloidal quantum-dot light-emitting technologies. _Nat. Photon._ **7** , 13–23 (2013). 

76. Ma, Y., Zhang, Y. & Yu, W. W. Near infrared emitting quantum dots: synthesis, luminescence properties and applications. _J. Mater. Chem. C_ **7** , 13662–13679 (2019). 

77. Rogach, A. L. et al. Colloidally prepared HgTe nanocrystals with strong room‐temperature infrared luminescence. _Adv. Mater._ **11** , 552–555 (1999). 

78. Harrison, M. T. et al. Wet chemical synthesis of highly luminescent HgTe/ CdS core/shell nanocrystals. _Adv. Mater._ **12** , 123–125 (2000). 

79. Harris, D. K. et al. Synthesis of cadmium arsenide quantum dots luminescent in the infrared. _J. Am. Chem. Soc._ **133** , 4676–4679 (2011). 

80. Cheng, K.-Y., Anthony, R., Kortshagen, U. R. & Holmes, R. J. Hybrid silicon nanocrystal–organic light-emitting devices for infrared electroluminescence. _Nano Lett._ **10** , 1154–1157 (2010). 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**667** 

**<mark>Review ARticle | FOCUS</mark>** 

**NaTuRe PhoToNics** 

81. Tang, R. et al. Tunable ultrasmall visible-to-extended near-infrared emitting silver sulfide quantum dots for integrin-targeted cancer imaging. _ACS Nano_ **9** , 220–230 (2015). 

82. Hinds, S. et al. NIR-emitting colloidal quantum dots having 26% luminescence quantum yield in buffer solution. _J. Am. Chem. Soc._ **129** , 7218–7219 (2007). 

83. Tessler, N., Medvedev, V., Kazes, M., Kan, S. & Banin, U. Efficient near-infrared polymer nanocrystal light-emitting diodes. _Science_ **295** , 1506–1508 (2002). 

84. Steckel, J. S., Coe-Sullivan, S., Bulovic, V. & Bawendi, M. G. 1.3 μm to 1.55 μm tunable electroluminescence from PbSe quantum dots embedded within an organic device. _Adv. Mater._ **15** , 1862–1866 (2003). 

85. Konstantatos, G., Huang, C. J., Levina, L., Lu, Z. H. & Sargent, E. H. Efficient infrared electroluminescent devices using solution-processed colloidal quantum dots. _Adv. Funct. Mater._ **15** , 1865–1869 (2005). 

86. Choudhury, K. R., Song, D. W. & Franky, S. Efficient solution-processed hybrid polymer–nanocrystal near infrared light-emitting devices. _Org. Electron._ **11** , 23–28 (2010). 

87. Bourdakos, K. N., Dissanayake, D. M. N. M., Lutz, T., Silva, S. R. P. & Curry, R. J. Highly efficient near-infrared hybrid organic–inorganic 

   - nanocrystal electroluminescence device. _Appl. Phys. Lett._ **92** , 153311 (2008). 

88. Sun, L. et al. Bright infrared quantum-dot light-emitting diodes through inter-dot spacing control. _Nat. Nanotechnol._ **7** , 369–373 (2012). 

89. Cheng, K.-Y., Anthony, R., Kortshagen, U. R. & Holmes, R. J. High efficiency silicon nanocrystal light-emitting devices. _Nano Lett._ **11** , 1952–1956 (2011). 

90. Franke, D. et al. Continuous injection synthesis of indium arsenide quantum dots emissive in the short-wavelength infrared. _Nat. Commun_ **7** , 12749 (2016). 

91. Wijaya, H. et al. Efficient near-infrared light-emitting diodes based on In(Zn)As–In(Zn)P–GaP–ZnS quantum dots. _Adv. Funct. Mater._ **30** , 1906483 (2020). 

92. Chen, S. et al. InAs/GaAs quantum-dot superluminescent light-emitting diode monolithically grown on a Si substrate. _ACS Photon._ **1** , 638–642 (2014). 

93. Hu, W. et al. Near-infrared quantum dot light emitting diodes employing electron transport nanocrystals in a layered architecture. _Nanotechnology_ **23** , 375202 (2012). 

94. Ma, X., Xu, F., Benavides, J. & Cloutier, S. G. High performance hybrid near-infrared LEDs using benzenedithiol cross-linked PbS colloidal nanocrystals. _Org. Electron._ **13** , 525–531 (2012). 

95. Zhitomirsky, D., Voznyy, O., Hoogland, S. & Sargent, E. H. Measuring charge carrier diffusion in coupled colloidal quantum dot solids. _ACS Nano_ **7** , 5282–5290 (2013). 

96. Sanchez, R. S. et al. All solution processed low turn-on voltage near infrared LEDs based on core–shell PbS–CdS quantum dots with inverted device structure. _Nanoscale_ **6** , 8551–8555 (2014). 

97. Supran, G. J. et al. High-performance shortwave-infrared light-emitting devices using core–shell (PbS–CdS) colloidal quantum dots. _Adv. Mater._ **27** , 1437–1442 (2015). 

98. Yang, X. et al. Iodide capped PbS/CdS core–shell quantum dots for efficient long-wavelength near-infrared light-emitting diodes. _Sci. Rep._ **7** , 14741 (2017). 

99. Gong, X. et al. Highly efficient quantum dot near-infrared light-emitting diodes. _Nat. Photon._ **10** , 253–257 (2016). 

100. Ning, Z. et al. Quantum-dot-in-perovskite solids. _Nature_ **523** , 324–328 (2015). 

101. Gao, L. et al. Efficient near-infrared light-emitting diodes based on 

   - quantum dots in layered perovskite. _Nat. Photon._ **14** , 227–233 (2020). 

102. Vasilopoulou, M. et al. Efficient colloidal quantum dot light-emitting diodes operating in the second near-infrared biological window. _Nat. Photon._ **14** , 50–56 (2020). 

103. Pradhan, S. et al. High-efficiency colloidal quantum dot infrared light-emitting diodes via engineering at the supra-nanocrystalline level. _Nat. Nanotechnol._ **14** , 72–79 (2019). 

104. Pradhan, S., Dalmases, M., Baspinar, A.-B. & Konstantatos, G. Highly efficient, bright, and stable colloidal quantum dot short-wave infrared light-emitting diodes. _Adv. Funct. Mater._ **30** , 2004445 (2020). 

105. Li, L. et al. Self‐filtered narrowband perovskite photodetectors with ultrafast and tuned spectral response. _Adv. Opt. Mater._ **5** , 1700672 (2017). 

106. Dortaj, S. et al. High-speed and high-precision PbSe/PbI2 solution process mid-infrared camera. _Sci Rep._ **11** , 1533 (2021). 

107. Ullbrich, S. et al. Fast organic near-infrared photodetectors based on charge-transfer absorption. _J. Phys. Chem. Lett._ **8** , 5621–5625 (2017). 

108. Shen, L. et al. Integration of perovskite and polymer photoactive layers to produce ultrafast response, ultraviolet-to-near-infrared, sensitive photodetectors. _Mater. Horiz._ **4** , 242–248 (2017). 

109. Gao, J., Nguyen, S., Bronstein, N. D. & Alivisatos, A. P. Solution-processed, high speed and high quantum efficiency quantum dot infrared photodetectors. _ACS Photon._ **3** , 1217–1222 (2016). 

110. Quan, L. N. et al. Perovskites for next-generation optical sources. _Chem. Rev._ **119** , 7444–7477 (2019). 

111. Zhang, Q. et al. Light out-coupling management in perovskite LEDs—what can we learn from the past? _Adv. Funct. Mater._ **30** , 2002570 (2020). 

112. Zhang, X., Hägglund, C. & Johansson, E. M. J. Electro-optics of colloidal quantum dot solids for thin-film solar cells. _Adv. Funct. Mater._ **26** , 1253–1260 (2016). 

113. Xiao, Z. et al. Efficient perovskite light-emitting diodes featuring nanometre-sized crystallites. _Nat. Photon._ **11** , 108–115 (2017). 

114. Miao, Y. et al. Microcavity top-emission perovskite light-emitting diodes. _Light Sci. Appl._ **9** , 89 (2020). 

115. Shen, Y. et al. High‐efficiency perovskite light‐emitting diodes with synergetic outcoupling enhancement. _Adv. Mater._ **31** , 1901517 (2019). 

116. Zhao, L., Lee, K. M., Roh, K., Khan, S. U. Z. & Rand, B. P. Improved outcoupling efficiency and stability of perovskite light‐emitting diodes using thin emitting layers. _Adv. Mater._ **31** , 1805836 (2019). 

117. Cho, C. et al. The role of photon recycling in perovskite light-emitting diodes. _Nat. Commun._ **11** , 611 (2020). 

118. Murawski, C., Leo, K. & Gather, M. C. Efficiency roll-off in organic light-emitting diodes. _Adv. Mater._ **25** , 6801–6827 (2013). 

119. Sassi, M. et al. Near-infrared roll-off-free electroluminescence from highly stable diketopyrrolopyrrole light emitting diodes. _Sci. Rep._ **6** , 34096 (2016). 

120. Bencheikh, F., Sandanayaka, A. S. D., Fukunaga, T., Matsushima, T. & Adachi, C. Origin of external quantum efficiency roll-off in 4,4′-bis[(N-carbazole)styryl]biphenyl (BSBCz)-based inverted organic light emitting diode under high pulsed electrical excitation. _J. Appl. Phys._ **126** , 185501 (2019). 

121. Swayamprabha, S. S. et al. Approaches for long lifetime organic light emitting diodes. _Adv. Sci._ **8** , 2002254 (2020). 

122. Matsushima, T. et al. High performance from extraordinarily thick organic light-emitting diodes. _Nature_ **572** , 502–506 (2019). 

123. Titov, A. et al. 6-3: Quantum dot LEDs: problems & prospects. _SID Symp. Dig. Tech. Pap._ **48** , 58–60 (2017). 

124. Gao, Y. et al. Disorder strongly enhances Auger recombination in conductive quantum-dot solids. _Nat. Commun._ **4** , 2329 (2013). 

125. Kim, K. et al. Hybrid perovskite light emitting diodes under intense electrical excitation. _Nat. Commun._ **9** , 4893 (2018). 

126. Fakharuddin, A. et al. Reduced efficiency roll-off and improved stability of mixed 2D/3D perovskite light emitting diodes by balancing charge injection. _Adv. Funct. Mater._ **29** , 1904101 (2019). 

127. Zhao, X. & Tan, Z.-K. Large-area near-infrared perovskite light-emitting diodes. _Nat. Photon._ **14** , 215–218 (2020). 

128. Zhao, L. et al. Thermal management enables bright and stable perovskite light‐emitting diodes. _Adv. Mater._ **32** , 2000752 (2020). 

129. Zou, C., Liu, Y., Ginger, D. S. & Lin, L. Y. Suppressing efficiency roll-off at high current densities for ultra-bright green perovskite light-emitting diodes. _ACS Nano_ **14** , 6076–6086 (2020). 

130. Yoshida, K., Nakanotani, H. & Adachi, C. Effect of Joule heating on transient current and electroluminescence in p–i–n organic lightemitting diodes under pulsed voltage operation. _Org. Electron._ **31** , 287–294 (2016). 

131. Kim, H. et al. Proton-transfer-induced 3D/2D hybrid perovskites suppress ion migration and reduce luminance overshoot. _Nat. Commun._ **11** , 3378 (2020). 

132. Prakasam, V., Tordera, D., Bolink, H. J. & Gelinck, G. Degradation mechanisms in organic lead halide perovskite light‐emitting diodes. _Adv. Opt. Mater._ **7** , 1900902 (2020). 

133. Guo, Y. et al. Phenylalkylammonium passivation enables perovskite light emitting diodes with record high-radiance operational lifetime: the chain length matters. _Nat. Commun._ **12** , 644 (2021). 

134. Yuan, Z. et al. Unveiling the synergistic effect of precursor stoichiometry and interfacial reactions for perovskite light-emitting diodes. _Nat. Commun._ **10** , 2818 (2019). 

135. Moroz, P. et al. Infrared emitting PbS nanocrystal solids through matrix encapsulation. _Chem. Mater._ **26** , 4256–4264 (2014). 

136. Xie, C., Zhao, X., Ong, E. W. Y. & Tan, Z.-K. Transparent nearinfrared perovskite light-emitting diodes. _Nat. Commun._ **11** , 4213 (2020). 

## **Acknowledgements** 

M.V. acknowledges funding by the project ‘Development of Materials and Devices for Industrial, Health, Environmental and Cultural Applications’ (MIS 5002567), which is implemented under the ‘Action for the Strategic Development on the Research and Technological Sector’, funded by the Operational Programme ‘Competitiveness, Entrepreneurship and Innovation’ (NSRF 2014-2020) and co-financed by Greece and the European Union (European Regional Development Fund). H.J.B. acknowledges funding from the European Research Council (ERC) under the European Union’s Horizon 2020 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**668** 

**<mark>FOCUS | Review ARticle</mark>** 

**NaTuRe PhoToNics** 

research and innovation programme (grant agreement no. 834431) and the Spanish Ministry of Science, Innovation and Universities MAT2017-88821-R and CEX2019000919-M. F.P.G.d.A. and E.H.S. acknowledge support from the Canada Research Chair. F.P.G.d.A. was also supported by the Ministry of Economy and Competitiveness of Spain through the “Severo Ochoa” programme for Centres of Excellence in R&D (SE5-0522), Fundació Privada Cellex, Fundació Privada Mir-Puig, and the Generalitat de Catalunya through the CERCA programme. 

## **competing interests** 

The authors declare no competing interests. 

## **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566-021-00855-2. 

**Correspondence** should be addressed to M.V., H.J.B. or E.H.S. **Peer review information** _Nature Photonics_ thanks Yun Chi, Zhi-Kuang Tan and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at www.nature.com/reprints. **Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. © Springer Nature Limited 2021 

**NATuRE PHoToNIcS** | VOL 15 | SEPTEMBER 2021 | 656–669 | www.nature.com/naturephotonics 

**669** 

