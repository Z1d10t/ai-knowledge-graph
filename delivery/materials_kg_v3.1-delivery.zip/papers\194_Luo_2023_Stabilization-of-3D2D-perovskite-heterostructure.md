# Stabilization of 3D/2D perovskite heterostructures via inhibition of ion diffusion by cross-linked polymers for solar cells with improved performance

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 164 |
| 作者 | Long Luo, Haipeng Zeng, Zai-Wei Wang, Min Li, Shuai You, Bin Chen, Aidan Maxwell, Q. An et al. |
| DOI | 10.1038/s41560-023-01205-y |
| 源文件 | 094_Luo_2023_Stabilization-of-3D2D-perovskite-heterostructure.pdf |

---




<!-- Start of picture text -->
Crosslinked ion diffusion inhibitors stabilize 3D/2D<br>perovskite heterostructures for e�cient and stable<br>photovoltaics<br>Long Luo<br>Haipeng Zeng<br><!-- End of picture text -->

Huazhong University of Science and Technology Zaiwei Wang University of Toronto Min Li Huazhong University of Science and Technology Shuai You Huazhong University of Science and Technology Bin Chen University of Toronto https://orcid.org/0000-0002-2106-7664 Aidan Maxwell University of Toronto Chao Wang Wuhan University of Technology Shangzhi Li Huazhong University of Science and Technology Xueqing Cai Huazhong University of Science and Technology Weixi Li Huazhong University of Science and Technology Lin Li Huazhong University of Science and Technology 

Huazhong University of Science and Technology 

Suzhou Institute of Nano-Tech and Nano-Bionics (SINANO), Chinese Academy of Sciences Wenxi Liang Huazhong University of Science and Technology 

Huazhong University of Science and Technology https://orcid.org/0000-0003-4794-8213 

University of Toronto https://orcid.org/0000-0003-0396-6495 Xiong Li  (  xiongli@hust.edu.cn ) Huazhong University of Science and Technology 

Posted Date: July 15th, 2022 

DOI: https://doi.org/10.21203/rs.3.rs-1776271/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

1 2 

3 

7 

8 

9 

10 

11 

12 

13 

14 

15 

16 17 

18 

19 

20 

21 22 23 24 25 26 27 28 29 30 

31 

# **Crosslinked ion diffusion inhibitors stabilize 3D/2D perovskite heterostructures for efficient and stable photovoltaics** 

4 Long Luo<sup>1†</sup> , Haipeng Zeng<sup>1†</sup> , Zaiwei Wang<sup>2†</sup> , Min Li<sup>1</sup> , Shuai You<sup>1</sup> , Bin Chen<sup>2</sup> , Aidan Maxwell<sup>2</sup> , 5 Chao Wang<sup>3</sup> , Shangzhi Li<sup>1</sup> , Xueqing Cai<sup>1</sup> , Weixi Li<sup>1</sup> , Lin Li<sup>1</sup> , Rui Guo<sup>1</sup> , Rong Huang<sup>4</sup> , Wenxi 6 Liang<sup>1</sup> , Yaoguang Rong<sup>1*</sup> , Edward H. Sargent<sup>2*</sup> , Xiong Li<sup>1*</sup> 

1L. Luo, H. Zeng, M. Li, S. You, S. Li, X. Cai, W. Li, L. Li, R. Guo, W. Liang, Y. Rong, X. Li. 

Michael Grätzel Center for Mesoscopic Solar Cells, Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Wuhan 430074, China 

2Z. Wang, B. Chen, A. Maxwell, E. H. Sargent 

Department of Electrical and Computer Engineering, University of Toronto, Toronto, Ontario, Canada. 

#### 3C. Wang 

State Key Laboratory of Advanced Technologies for Materials Synthesis and Processing, Wuhan University of Technology, Wuhan 430070, China. 

#### 4R. Huang 

Vacuum Interconnected Nanotech Workstation (Nano-X), Suzhou Institute of Nano-Tech and Nano-Bionics, the Chinese Academy of Sciences, Suzhou 215123, China. 

*Corresponding author. Email: ygrong@hust.edu.cn; <u>ted.sargent@utoronto.ca; xiongli@hust.edu.cn</u> 

†These authors contributed equally to this work. 

**Two-dimensional (2D) and quasi-2D modifications of 3D perovskite active layers have contributed to advances in the performance of perovskite solar cells (PSCs); however, the ionic diffusion between the surface 2D and bulk 3D perovskites leads to the degradation of the 2D/3D perovskite heterostructure and limits the long-term stability of PSCs. Here we incorporate a crosslinked ion diffusion inhibitor (CDI) on the top of a 3D perovskite layer, and then deposit a 2D perovskite layer via a vapor-assisted two-step process to form a 3D/CDI/2D perovskite heterostructure. Photoluminescence spectra and thickness-profiled elemental analysis indicate that it is by inhibiting ion diffusion between the 2D and 3D perovskites that the CDI stabilizes the heterostructures. Based on carbon electrodes, we report small-area devices with an efficiency of 21.17%, and mini-modules with an efficiency of 19.56%. After 4,390hours operation under maximum power point tracking and one-sun illumination at elevated temperature, devices retain 90% of initial performance.** 

1 

32 

33 

34 

35 36 37 38 39 

40 41 42 43 

44 45 46 47 48 49 

50 51 52 53 54 55 56 57 58 59 

60 

61 62 63 64 65 66 67 68 69 70 

Organic-inorganic hybrid perovskite solar cells (PSCs) have recently undergone a rapid rise in certified power conversion efficiencies (PCEs) to exceed 25% for sub-1 cm<sup>2</sup> PSCs and ~20% for perovskite solar modules (PSMs)<sup>**1-7**</sup> . Many of the best PSCs employ 2D and quasi-2D modified 3D perovskite (3D/2D perovskite) heterostructures **(Supplementary Table 1)** , and these provide defect passivation and favorable band alignment<sup>**8-22**</sup> . However, ion diffusion between the surface 2D and bulk 3D perovskites is known to contribute to the degradation of 3D/2D perovskite heterostructures under bias, illumination, and heat<sup>**23,24**</sup> . Currently, the long-term operational stability of these highly efficient PSCs is limited to < 2000 hours at room temperature, and ~500 hours at ≥ 60 °C under maximum power point (MPP) tracking and continuous illumination **(Supplementary Table 1)** . 

Mitigation of ion diffusion has been sought-after _via_ halide compositional tuning<sup>**25-27**</sup> , the incorporation of large organic cations<sup>**28-31**</sup> , the introduction of ionic additives in perovskite films<sup>**32-36**</sup> , and the construction of nanostructured barrier layers between stacked layers<sup>**37-42**</sup> . However, stabilizing 3D/2D perovskite heterostructures and inhibiting ion diffusion between the 3D and 2D perovskites remains an ongoing challenge<sup>**23,24**</sup> . 

In order to construct a highly stable 3D/2D perovskite heterostructure, we explored the introduction of a crosslinked ion diffusion inhibitor (CDI) layer between the 3D and 2D perovskites to form a 3D/CDI/2D perovskite heterostructure ( **Fig. 1a** ). We first needed to overcome three challenges. (1) Designing the CDI to effectively inhibit ion diffusion between the 3D and 2D perovskite layers under thermal stress. (2) Introducing the CDI layer on the top of the 3D perovskite layer without degrading the 3D perovskite layer. (3) Depositing a standalone 2D perovskite layer on the 3D perovskite/CDI film without damaging the underlying heterostructure. 

First, comparing small-molecule _vs._ regular polymers as the CDI, we found that a highly crosslinked network polymer is more effective at inhibiting ion diffusion and stabilizing the 3D/2D perovskite heterostructure. Second, we selected a polymer-based CDI layer fabricated by self-polymerization under moderate conditions (≤ 100<sup>o</sup> C) and processed from a solution that does not degrade the 3D perovskite. Third, we developed a vapor-assisted two-step process to form the 2D perovskite layer on the 3D perovskite/CDI film, which prevented the destruction of the film during deposition. We fabricated carbon-electrode-based PSCs using the 3D/CDI/2D perovskite heterostructure with an efficiency of 21.17% (aperture area of 0.16 cm<sup>2</sup> ), and demonstrate a carbon-electrode-based PSM with a certified efficiency of 18.23% (aperture area of 17.12 cm<sup>2</sup> ). The cell achieves a T90 (the time taken for device efficiency to reduce to 90% of its initial value) of 4390 hours under one-sun illumination and MPP tracking at 60 °C, showing superior stability compared to the PSCs based on conventional 3D/2D perovskite heterostructures (~500 h) at elevated temperatures ( **Supplementary Table 1** ). 

**Preparation and stabilization of the 3D/CDI/2D heterostructure** 

To fabricate the conventional 3D/2D perovskite heterostructure, we deposit a (FAPbI3)0.95(MAPbBr3)0.05 (formamidinium, FA; methylammonium, MA) 3D perovskite layer using the antisolvent process, and then post-treat the surface with a solution of 4-fluorophenylethylammonium iodide (4F-PEAI) in isopropanol (IPA)<sup>**8,9**</sup> . The x-ray diffraction (XRD) patterns in **Fig. 1b** show a characteristic diffraction peak at 5.2°, which indicates the formation of 2D 4F-PEA2PbI4 **43** . After thermal aging at 100 °C for 120 min, the 2D 4F-PEA2PbI4 diffraction peak in the 3D/2D heterostructure disappears. Additionally, the PL spectra show that the emission peaks of 3D (FAPbI3)0.95(MAPbBr3)0.05 and 2D 4F-PEA2PbI4 are located at 800 nm and 511 nm respectively for the 3D/2D perovskite heterostructure ( **Fig. 1c)** . After thermal aging, the emission peak of 4F-PEA2PbI4 for the 3D/2D heterostructure also completely disappears. These results are indicative of the instability of the 3D/2D perovskite heterostructure, which we attribute to ion diffusion between the surface 2D and bulk 3D perovskites **23,24** . 

2 

71 

72 

73 

74 

75 

76 

77 

78 

79 

80 81 

82 83 

84 

85 

86 

87 

88 

89 

90 91 92 93 94 

In rechargeable batteries or fuel cells, ion diffusion is inhibited by inserting separation materials (such as polyhedral oligomeric silsesquioxane (POSS) and ethylene dimethacrylate (EDMA) based polymers) as proton exchange membranes **44-47** . POSS consists of a rigid, cubic Si-O-Si cage-type core with eight ethylene groups that can bridge the linear EDMA in various directions _via_ olefin polymerization. ~3% mol POSS dispersed in EDMA provides crosslinking points and leads to the formation of a polymer film with highly crosslinked networks ( **Fig. 1a** )<sup>**48**</sup> . We posited that the POSS-EDMA-based polymer could act as a CDI layer between the 3D perovskite and a 2D perovskite to form a 3D/CDI/2D perovskite heterostructure (details can be found in **Supplementary Fig. 1** ). For simplicity, CDI represents the POSS-EDMA-based polymer below. 



<!-- Start of picture text -->
a<br>Synthesis of cross-linked ion diffusion inhibitor (CDI)<br>Carbon<br>HTL<br>2D perovskite<br>CDI<br>3D perovskite<br>SnO2 EDMA (97% mol)<br>ITO<br>polymerization<br>Deposition of 2D perovskite layer<br>4F-PEAI<br>PbI2<br>H2O IPA DMF<br>(i) Thermal evaporation (ii) Spin coating POSS (3% mol)<br>b c d<br>CDI<br>3D/CDI/2D (aged) 3D/CDI/2D (aged)<br>3D/CDI/2D (initial) EDMA<br>3D/CDI/2D (initial)<br>3D/2D (aged) C=O<br>3D/2D (aged)<br>POSS<br>3D/2D (initial) 3D/2D (initial) C=C<br>Si-O-Si =CH2<br>5 10 15 20 25 30 35 40 45 50 500 600 700 800 900 3500 3000 2500 2000 1500 1000 500<br>2θ (degree) Wavelength (nm) Wavenumber (cm-1)<br>Intensity (a.u.) Intensity (a.u.) Transmittance<br><!-- End of picture text -->

**Fig. 1| Preparation and stability of the 2D/CDI/2D perovskite heterostructure. a,** Schematic of the device structure, the deposition of the 2D perovskite layer, and the synthesis and structures of POSS, EDMA and CDI (inset: photos of CDI films in H2O, IPA and DMF). **b** and **c** , XRD patterns and PL spectra of initial and aged (heated at 100 °C for 120 min) 3D/2D and 3D/CDI/2D perovskite heterostructures. **d,** FTIR spectra of POSS, EDMA and CDI. 

The CDI layer is formed by spin-coating a POSS and EDMA mixed solution with an optimal concentration ( **Supplementary Fig. 2** ) i <mark>n chlorobenzene and ethylacetate mixed-solvent o</mark> n the above 3D perovskite, and annealing at 100°C for 10 min. Thes <mark>e low-polarity solvents are compatible with</mark> 3D perovskites and thus do not induce degradation of the 3D perovskite. The self-polymerization reaction was confirmed by fourier transform infrared spectroscopy (FTIR). The strong stretching vibration peaks of C=C and =CH2 at ~ 1640 cm<sup>-1</sup> and ~ 903 cm<sup>-1</sup> in both pure EDMA and POSS are observed ( **Fig. 1d)** . These vibration peaks in the CDI from the 3D perovskite/CDI film significantly weaken or even disappear, while the intensity of other characteristic peaks such as C=O (1734 cm<sup>-1</sup> ) in EDMA and in the CDI remain similar. This is indicative of the formation of the CDI by self-polymerization of EDMA and POSS. When the self-polymerization is carried out on a glass substrate, a uniform and free-standing transparent CDI thin film is obtained ( **Supplementary Fig. 3** ). Fourier transform infrared (FTIR) spectra in **Supplementary Fig. 4** show that the CDI interacts with FAI, and the photo in in Fig. 1A shows that the CDI is insoluble in common polar solvents such as H2O, IPA and dimethyl formamide (DMF). 

3 

95 

96 

97 

98 

99 

100 101 102 103 104 

105 106 

107 

108 109 110 

111 112 

113 114 115 

116 

117 

118 

119 

120 

121 

122 123 124 125 

126 

127 

128 

129 

130 

131 132 

These properties are highly beneficial for improving the stability of 3D perovskites and ensuring that the CDI remains intact during the deposition process of the 2D perovskite layer. Scanning electron microscope (SEM) and elemental energy dispersive spectroscopy (EDS) show a uniform distribution of the CDI on the surface of the 3D perovskite ( **Supplementary Fig. 5** ). 

XRD spectra in **Fig. 1b** show a stronger characteristic diffraction peak at 5.2 ° for the 3D/CDI/2D perovskite heterostructure than the 3D/2D perovskite heterostructure, which indicates the formation of a thicker 2D perovskite layer. The cross-sectional SEM images show a ~500 nm 3D perovskite layer and a ~10 nm low-dimensional perovskite layer for the 3D/2D heterostructure, and a ~500 nm 3D perovskite layer, a several nanometer CDI layer and a thicker ~30 nm 2D perovskite layer for the 3D/CDI/2D heterostructure ( **Supplementary Fig. 6)** . The XRD spectrum of the aged 3D/CDI/2D perovskite heterostructure shows that the characteristic diffraction peak at 5.2° in the 3D/CDI/2D heterostructure remains relatively unchanged. A similar effect is observed for the PL spectra, where the PL emission peaks for the aged 3D/CDI/2D perovskite heterostructure retain their initial positions and intensities. 

To clarify that the stabilization effect is mainly due to the CDI layer and not the thick 2D perovskite layer, a thick 2D perovskite layer was directly prepared on a 3D perovskite without the CDI layer by the same vapor-assisted two-step process as in the 3D/CDI/2D perovskite heterostructure. The intensity of the PL emission peak of 4F-PEA2PbI4 significantly decreased after thermal aging of the 3D/thick 2D heterostructure ( **Supplementary Fig. 7** ). This indicates that the CDI layer plays the dominant role of stabilizing the 3D/2D perovskite heterostructure. In addition, the EDMA monomer and crosslinked EDMA polymer were also incorporated as the barrier layer between 3D and 2D perovskites, and neither can stabilize the perovskite heterostructure as evidenced by PL spectra ( **Supplementary Fig. 8** ). Thus, the high degree of crosslinking and the network structure of the POSS-EDMA-based polymer play crucial roles in stabilizing the 3D/2D perovskite heterostructure. 

### **Characterization of ion diffusion in the perovskite heterostructures** 

We conducted ultrafast transient absorption (TA) spectroscopy measurements of 3D/2D and 3D/CDI/2D perovskite heterostructures as shown in **Fig. 2a** and **2b**<sup>**49,50**</sup> . Both initial perovskite heterostructures show the characteristic peaks at 773 nm from 3D perovskite, and at 515 nm from _n_ = 1 low-dimentional perovskites ( _28)_ . After aging at 100 °C for 120 min, the characteristic peak from n = 1 perovskite for the 3D/2D heterostructure almost completely vanished, while the peak for the 3D/CDI/2D heterostructure remained unchanged. 

To correlate the degradation of the 2D perovskite to ion diffusion, we employed atomic force microscopy-based infrared spectroscopy (AFM-IR) measurements to investigate the surface properties of the perovskite heterostructures. Imaging results were recorded at 1712 cm<sup>−1</sup> , which corresponds to the symmetric C=NH2<sup>+</sup> bending of FA<sup>+</sup> . Initially, the 3D/2D perovskite heterostructure shows distinct signals of FA<sup>+</sup> cations ( **Fig. 2c** ), while there are low signals of FA<sup>+</sup> cations in the initial 3D/CDI/2D perovskite heterostructure ( **Fig. 2d** ). This indicates that the 2D perovskite layer in the 3D/CDI/2D perovskite heterostructure achieves more complete and uniform coverage on the 3D perovskite layer than that in the 3D/2D perovskite heterostructure. After the perovskite heterostructures are aged at 100 °C for 120 min, the FA<sup>+</sup> signal largely increases on the surface of the 3D/2D perovskite heterostructure, which indicates the significant upward diffusion of FA<sup>+</sup> ions and the phase transformation from the 2D perovskite of 4F-PEA2PbI4 into 3D perovskite during thermal stress. On the contrary, the 3D/CDI/2D perovskite heterostructure shows an almost unchanged FA<sup>+</sup> signal, which verifies the limited ion diffusion between the 3D and 2D perovskites, and the enhanced stability of the 3D/CDI/2D heterostructure. 

4 

133 134 135 136 137 

138 

139 

140 

141 

142 143 144 145 

146 

147 148 

149 

150 

151 

152 

153 

154 155 156 



<!-- Start of picture text -->
a 4 3D/2D (initial) 4 3D/2D (aged) b 4 3D/CDI/2D (initial) 4 3D/CDI/2D (aged)<br>2 2 2 2<br>0 0 0 0<br>- 2 n= 2 - 2 - 2 n= 2 - 2<br>--- 468 n= 1  - 0 1 5 5 ps.5 ps ps ps --- 468  - 0 1 5 5 ps.5 ps ps ps --- 468 n= 1  - 0 1 5 5 ps.5 ps ps ps --- 468  - 0 1 5 5 ps.5 ps ps ps<br>-1 0 -1 0 -1 0 -1 0<br>500 550 600 650 700 750 800 500 550 600 650 700 750 800 500 550 600 650 700 750 800 500 550 600 650 700 750 800<br>Wavelength (nm) Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>c d<br>3D/2D (initial) 1.5 3D/2D (aged) 1.5 3D/CDI/2D (initial)  1.5 3D/CDI/2D (aged)  1.5<br>200 nm -1.5 200 nm -1.5 200 nm -1.5 200 nm -1.5<br>e 0 F 1s 0 F 1s f 0 F 1s 0 F 1s<br>3 0 3 0 30 30<br>6 0 6 0 60 60<br>9 0 9 0 90 90<br>12 0 12 0 120 120<br>15 0 3D/2D (initial) 15 0 3D/2D (aged) 150 3D/CDI/2D (initial) 150 3D/CDI/2D (aged)<br>680 682 684 686 688 690 692 694 680 682 684 686 688 690 692 694 680 682 684 686 688 690 692 694 680 682 684 686 688 690 692 694<br>Binding energy (eV) Binding energy (eV) Binding energy (eV) Binding energy (eV)<br>IR intensity (V) IR intensity (V) IR intensity (V) IR intensity (V)<br>A (mD)Δ A (mD)Δ A (mD)Δ A (mD)Δ<br>Sputtering time (s) Sputtering time (s) Sputtering time (s) Sputtering time (s)<br><!-- End of picture text -->

**Fig. 2| Investigation of ion diffusion in perovskite heterostructures. a** and **b** , TA spectra of 3D/2D and 3D/CDI/2D perovskite heterostructures before and after aging at 100 °C for 120 min. **c** and **d,** AFM-IR (recorded at 1712 cm<sup>−1</sup> corresponding to the symmetric C=NH2+ bending of FA+) images of 3D/2D and 3D/CDI/2D perovskite heterostructures before and after aging. **e** and **f** , XPS in-depth profiling of 3D/2D and 3D/CDI/2D perovskite heterostructures before and after aging. 

X-ray photoelectron spectroscopy (XPS) spectra show that the characteristic peaks of N in FA<sup>+</sup> for the 3D perovskite layer and 4F-PEA<sup>+</sup> for the 2D perovskite layer are at 400.8 eV and at 402.0 eV, respectively ( **Supplementary Fig. 9** ). XPS in-depth profiling in **Fig. 2e** shows that the characteristic peak of F in 4F-PEA<sup>+</sup> can only be detected on the top surface for ~45 s. For the 3D/CDI/2D perovskite heterostructure, 4F-PEA<sup>+</sup> can be detected on the film surface for ~120 s ( **Fig. 2f)** , which is also indicative of the thicker 2D layer in the 3D/CDI/2D perovskite heterostructure. Meanwhile, the downward diffusion of 4F-PEA<sup>+</sup> ions in the 3D/2D perovskite heterostructure is observed after thermal aging, which is inhibited by the CDI layer in the 3D/CDI/2D heterostructure. Thus, we conclude that the CDI layer can effectively inhibit the ion (including both FA<sup>+</sup> and 4F-PEA<sup>+</sup> ) diffusion between the 3D and 2D perovskites. 

### **Charge carrier dynamics and device performance** 

To investigate the carrier dynamics within the 3D/CDI/2D perovskite heterostructure and with perovskite/HTL stacks, we conducted time-resolved photoluminescence (TRPL) measurements. On glass substrates, the 3D/2D perovskite heterostructure shows a longer average carrier lifetime ( _τ_ avg) (315.46 ns) than the pristine 3D perovskite (248.24 ns) ( **Fig. 3a** and **Supplementary Table 2** ). The _τ_ avg of the 3D/CDI/2D perovskite heterostructure further increases to 423.56 ns. This indicates that the 2D perovskite together with the CDI layer provides improved passivation over the pure 2D perovskite. When a 2,2′,7,7′-tetrakis(N,N-di-p-methoxyphenyl-amine)-9,9′-spirobifluorene (spiro-OMeTAD) layer is deposited on top of the samples, the 3D perovskite, 3D/2D and 3D/CDI/2D perovskite heterostructures show similar _τ_ avg and _τ_ 1 **(Fig. 3b)** . This indicates efficient charge extraction from the perovskites to the HTL can still be achieved after incorporating the CDI layer in the perovskite heterostructure. Space-charge-limited-current (SCLC) spectra of the perovskite heterostructures show that the 3D/2D and 3D/CDI/2D perovskite heterostructures generate _J-V_ curves with similar shapes and comparable current 

5 

157 

158 

160 161 162 163 164 165 166 

167 168 

169 

170 

171 

172 

173 

174 175 

- values ( **Supplementary Fig. 10** and **Supplementary Fig. 11** ) in both electron-only and hole-only devices. By fitting the 

- linear regions, the electron and hole mobilities of the 3D/CDI/2D heterostructure are similar compared to that of the 3D 

159 

- perovskite or 3D/2D heterostructure. Thus, the CDI layer has not hindered the transport of either the electrons or the holes. 



<!-- Start of picture text -->
a 1 b<br>1 (3D/CDI/2D)/Spiro-OMeTAD<br>(3D/2D)/Spiro-OMeTAD<br>τavg = 423.56 ns 3D/Spiro-OMeTAD<br>0. 1 0. 1<br>τavg = 29.53 ns<br>τavg = 315.46 ns τavg = 26.61 ns<br>0.0 1<br>0.0 1<br>τavg = 23.16 ns<br>3D/2D3D/CDI/2D τavg = 248.24 ns<br>3D  0.00 1<br>0.00 1<br>0 500 1000 1500 2000 2500 3000 0 50 100 150 200 250 300 350<br>Time (ns) Time (ns)<br>c d 10 0 2 5<br>2 4<br>2 0 3D/2D3D 8 0 2 0<br>1 6 3D/CLP/2D 60 1 5<br>1 2 V OC J SC FF PCE<br>(V) (mA cm-2) (%) 40 1 0<br>8 1.07 23.87 0.78 19.92<br>4 1.11 23.89 0.77 20.42 20 5<br>1.13 24.00 0.78 21.17<br>0 0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 800 900<br>Voltage (V) Wavelengt (nm)<br>e f 4 2 0<br>4 PCE = 19.56%<br>3 1 5<br>2 1 0<br>3<br>1 at bias of 5.5  V  5<br>PCE ~ 19.1%<br>2 0 0<br>- 1 - 5<br>1 - 2 - 10<br>Carbon electrode-based PSM (17.1 cm2) - 3 - 15<br>0 - 4 - 20<br>0 1 2 3 4 5 6 7 0 20 40 60 80 100<br>Voltage (V) Time (s)<br>Normalized PL intensity (a.u.) Normalized PL intensity (a.u.)<br>EQE (%)<br>-2Current density (mA cm) -2Integrated  J  (mA cm)SC<br>PCE (%)<br>-2Current density (mA cm) -2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 3| Charge carrier dynamics and device performance. a,** TRPL spectra of 3D perovskite, 3D/2D and 3D/CDI/2D perovskite heterostructures on glass substrates. **b** , TRPL spectra of 3D perovskite/Spiro-OMeTAD, 3D/2D perovskite heterostructure/Spiro-OMeTAD and 3D/CDI/2D perovskite heterostructure/Spiro-OMeTAD. **c,** _J_ - _V_ curves of PSCs fabricated with 3D perovskite, 3D/2D and 3D/CDI/2D perovskite heterostructures as the light absorbing layer. **d,** EQE spectrum and corresponding integrated current density of the champion cell based on the 3D/CDI/2D perovskite heterostructure. **e,** _J-V_ curves of the champion PSM based on the 3D/CDI/2D perovskite heterostructure. The inset shows a photograph of the PSM. **f,** the stabilized output and calculated PCE of the PSM at a fixed bias. 

To avoid the instability issues associated with metal electrodes, we prepared carbon electrodes based on the screenprinting technique ( **Supplementary Fig. 12** ) to fabricate PSCs with a device architecture of ITO/SnO2/Perovskite/SpiroOMeTAD/Carbon. The cell using (FAPbI3)0.95(MAPbBr3)0.05 as the light absorbing layer achieves an efficiency of 19.92% with an open-circuit voltage ( _V_ OC) of 1.07 V, a short-circuit current density ( _J_ SC) of 23.87 mA cm<sup>-2</sup> , and a fill factor (FF) of 0.78 ( **Fig. 3c** ). The efficiency of 3D/2D cells is enhanced to 20.42%, which mainly originates from the increase of _V_ OC from 1.07 V to 1.11 V. This is consistent with previous reports showing that the 2D perovskite layer passivates the surface defects of the 3D perovskite and suppresses non-radiative recombination<sup>**51,52**</sup> . For the 3D/CDI/2D PSC, we achieve an efficiency of 21.17% with a _V_ OC of 1.13 V, a _J_ SC of 24.00 mA cm<sup>-2</sup> , and a FF of 0.78. The steady-state power output of the device reaches ~20.87% ( **Supplementary Fig. 13** ). The external quantum efficiency (EQE) spectrum of the 3D/CDI/2D PSC shows an 

6 

176 

177 

178 

179 

180 

181 182 183 

184 

185 186 

187 

190 

191 

192 193 

194 

195 

196 

197 

198 199 

integrated short-circuit current density of 23.34 mA cm<sup>-2</sup> ( **Fig. 3d** ), which agrees with the current density–voltage ( _J_ - _V)_ scanning result. Statistical analysis of the photovoltaic parameters obtained by fifteen cells demonstrates the reproducibility of high-performance 3D/CDI/2D PSCs ( **Supplementary Fig. 14** ). We further fabricated a PSM with six sub-cells in series, as shown in **Fig. 3e** and **Supplementary Fig. 15** . The champion PSM based on the 3D/CDI/2D perovskite heterostructure with a carbon electrode and a mask area of 17.1 cm<sup>2</sup> achieves a PCE of 19.56% with a _V_ OC of 6.73 V, a _J_ SC of 3.87 mA cm<sup>-</sup> 2, and a FF of 0.751. Furthermore, it also exhibits a steady-state power output of 19.1% under a bias voltage of 5.5 V for 100 s ( **Fig. 3f** ). Meanwhile, the PSM also achieves a certified efficiency of 19.3% and a SPO of 18.2% ( **Supplementary Fig. 16** ). 



<!-- Start of picture text -->
a<br>2 0<br>1 6 Repaired<br>1 2<br>8<br>4 (3D/CDI/2D)/spiro-OMeTAD MPP tracking under one-sun illumination at 60 °C<br>0<br>0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000<br>Time (h)<br>b<br>1. 0<br>0. 8 T90<br>0. 6<br>0. 4<br>0. 2 (3D/2D)/P3HT-spiro-OMeTAD<br>MPP tracking under one-sun illumination at 60 °C<br>(3D/CDI/2D) /P3HT-spiro-OMeTAD<br>0. 0<br>0 1000 2000 3000 4000 5000<br>Time (h)<br>PCE (%)<br>Normalized PCE<br><!-- End of picture text -->

188 

## 189 

**Fig. 4| Long-term stability test. a** , The operational stability of PSCs using spiro-OMeTAD as the HTL under continuous illumination in N2 at 60 ℃. The cells are repaired by re-depositing the spiro-OMeTAD after every 1000 hours of continuous illumination. **b** , The operational stability of PSCs using a mixed P3HT-spiro-OMeTAD HTL under continuous illumination in N2 at 60 ℃ (The initial PCEs of the cells based on 3D/2D and 3D/CDI/2D perovskite heterostructures are 18.09% and 18.59%, respectively) 

### **Device Stability** 

To study operational stability, we monitored the cell performance under MPP tracking conditions and continuous onesun illumination at 60 °C ( **Supplementary Fig. 17** ). The estimated T90 lifetime (the time taken for device efficiency to reduce to 90% of its initial value) of the 3D/2D PSC is 560 h. The PSC based on the 3D/CDI/2D perovskite heterostructure maintains ~92% of the initial efficiency after 1000 hours under continuous illumination. According to time-of-flight secondary-ion mass spectrometry (TOF-SIMS) of these 1000-h aged cells, the diffusion of iodide ions from the perovskite layer to the spiro-OMeTAD layer is significantly suppressed in the 3D/CDI/2D PSC ( **Supplementary Fig. 18** ). To eliminate the negative effect of spiro-OMeTAD on the cell stability, and verify the stability of the perovskite heterostructures, we carry out 4 repair cycles of the cell by re-depositing the spiro-OMeTAD ( **Fig. 4a** ). The cell maintains ~90% of the initial efficiency after 5000 h continuous operation. The cell performance recovery indicates that the 3D/CDI/2D perovskite heterostructure is highly stable against light and heat stress. Furthermore, a more stable poly(3-hexylthiophene)-spiro- 

7 

200 

201 

202 

203 

204 

205 

206 

211 

- OMeTAD (P3HT-spiro) (3:1 w/w) mixed HTL is adopted to replace the unstable spiro-OMeTAD **(Fig. 4b)**<sup>**15**</sup> . The initial efficiencies of as-fabricated PSCs slightly reduce to 18.59% based on 3D/CDI/2D perovskite heterostructure and 18.04% based on 3D/2D perovskite heterostructure ( **Supplementary Fig. 19** ). For the long-term operational stability, the efficiency of the 3D/2D PSC decays to ~90% of the initial value after 672 h of continuous operation, while the 3D/CDI/2D PSC maintains 90% of its initial efficiency after continuous operation for 4392 h at 60 °C ( **Fig. 4b** ). 

### **Conclusion** 

- 206 In summary, we successfully suppress the ion diffusion between surface 2D and bulk 3D perovskites by introducing a 207 CDI layer of a highly crosslinked network polymer. A highly stable 3D/CDI/2D perovskite heterostructure is constructed 208 and combined with a Carbon electrode to fabricate PSCs with an efficiency of 21.17% (aperture area of 0.16 cm<sup>2</sup> ) and a 209 mini-PSM with an efficiency of 19.56% (certified efficiency of 18.2%). After 4392 hours of continuous operation under 210 MPP tracking and one-sun illumination, the PSC retains 90% of its initial performance. 

8 

212 

213 214 215 216 217 218 219 220 221 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 250 251 252 

253 254 255 256 257 

## **Methods** 

**Materials.** All perovskite reagents including lead iodide (PbI2, 99.99%), formamidinium iodide (FAI, > 99.5%), methylammonium bromide (MABr, > 99.5%), lead bromide (PbBr2, 99.99%), methylammonium chloride (MACl, > 99.5%), 4-fluorophenylethylammonium iodide (4F-PEAI, > 99.5%), SpiroOMeTAD (99.5%) and poly(3-hexylthiophene) (P3HT) were purchased from Xi’an p-OLED Corp. Dimethylformamide (DMF, 99.8%), dimethyl sulfoxide (DMSO, 99.7%), and chlorobenzene (CB, 99.8%) were purchased from Acros. 4-tert-butyl pyridine (tBP, 96%), lithium bistrifluorosulfonyl imide (LiTFSI, 99.95%), and isopropanol (IPA, 99.99%) were obtained from Sigma-Aldrich. The dimercaptosuccinic acid (DMSA, 98%), ethylene dimethacrylate (EDMA, 98%), octavinyloctasilasesquioxane (POSS, 95%) and 2,2'-Azobis(2-methylpropionitrile) (AIBN, 98%) were purchased from 

Aladdin. The SnO2 colloid dispersion was purchased from Alfa Aesar (tin (IV) oxide, 15 wt% in H2O colloidal dispersion). Graphite and carbon black powder were purchased from Aladdin. Indium tin oxide (ITO) (transmission >95%) substrates were purchased from South China Science & Technology Company Limited. Other materials were purchased from Aladdin and all the materials were used as received unless otherwise specified. 

**Synthesis of CDI.** 1.0 g of dimercaptosuccinic acid (DMSA) (5.5 mmol), 0.99 g of ethylene dimethacrylate (EDMA) (5 mmol), 79.1 mg of octavinyloctasilasesquioxane (POSS) (0.125 mmol) and 38 mg of 2, 2-dimethoxy-2-phenylacetophenone (DMPA) (2 wt% of reactants) were well dispersed in the tetrahydrofuran (THF) (20 mL) in a quartz flask. The mixture was irradiated using a 365 nm UV lamp (25 W) for 2 h at room temperature. After the reaction was complete, n-hexane was added to obtain a solid crude product. The obtained product was dissolved in THF and precipitated in excess hexane again. Then, the solid was washed with deionized water and further dried under vacuum. Finally, 1.57 g of CDI white powder was obtained. 

**Preparation of carbon paste and carbon electrode.** 6 g graphite, 2 g carbon black powder and 0.8 g polyacrylate were mixed in the 2-butoxyethanol/pentyl acetate/ethyl acetate(v/v=5:3:2) mixed solvents and kept ball-milling for 12 h to obtain the pristine carbon paste. CDI-modified carbon paste was obtained by adding 1.76 g CDI power in the same raw materials of pristine carbon paste to keep ball-milling for 12 h. The pre-prepared carbon paste was coated onto the cleaned carbon cloth _via_ a screen-printing process to obtain about 25 mm thickness of carbon film. The carbon paste/carbon cloth electrode was peeled off and then soaked in an ethanol solution while sonicating for 10 min to remove the residual solvent. Finally, the carbon electrode was taken out and dried at room temperature. 

**Fabrication of perovskite solar cells and modules.** ITO glass was patterned by laser etching (Universal Laser Systems, VLS2.30) with a femtosecond laser. Then the glass substrates were cleaned by sequential ultrasonication in a detergent solution, deionized (DI) water, and anhydrous ethanol. The SnO2 dispersion was spin-coated on the substrates at 4000 rpm for 30 s and then annealed at 150 °C for 30 min. After that, the perovskite precursor solution was prepared by mixing 245.06 mg FAI, 8.4 mg MABr, 27.53 mg PbBr2, 705.35 mg PbI2 and 33.76 mg MACl as an additive in DMF/DMSO (v/v = 8:1) for a chemical formula of (FAPbI3)0.95(MAPbBr3)0.05. The perovskite precursor solution was spin-coated on SnO2 at 1000 r.p.m. for 10 s and 5000 r.p.m. for 20 s. The wet film was then immediately put into a sealed sample chamber connected to a home-built vacuum pumping system and immediately exposed to low pressure (20 Pa) for 10 s. Subsequently, the perovskite film was put on a hotplate and annealed at 120 °C for 40 min to obtain the pristine three-dimensional (3D) perovskite film. Next, 15 mM 4F-PEAI/IPA solution was spun on the above 3D perovskite at 4000 r.p.m. for 30 s to prepare 3D/2D perovskite heterostructure. For the 3D/CDI/2D perovskite film, 3 mg EDMA, POSS (3% mol of EDMA) and 2,2'-Azobis(2-methylpropionitrile) initiator (2% mol of EDMA) were first dissolved in 1ml of chlorobenzene and ethylacetate mixed solution (v:v = 1:1), and then spun on the above 3D perovskite at 4000 r.p.m. for 30 s and annealed at 100 °C for 10 min. Then a 30 nm thick layer of PbI2 was evaporated at a rate of 0.3 Å/s onto the 3D/CDI bilayer film in a vacuum chamber. Subsequently, the same concentration of 4F-PEAI/IPA solution was spun on the above 3D/CDI/PbI2 film at 4000 r.p.m. for 30 s and annealed at 100 ℃ for 10 min to prepare the 3D/CDI/2D perovskite heterostructure. After cooling down to room temperature, a hole transporting layer (73 mg mL<sup>-1</sup> spiro-OMeTAD in chlorobenzene with 9.36 mg LiTFSI salt and 30 μL 4-tert-butylpyridine) was deposited on the perovskite film by spin coating at 3000 r.p.m. for 30 s. For the stability test, the P3HT-spiro mixed HTL (54.75 mg P3HT and 18.25 mg spiro-OMeTAD with 4.68 mg Li-TFSI and 15 μL 4-tert-butylpyridine) was deposited with the same spin-coating process. Finally, the pre-prepared carbon electrode was pressed onto the hole-transporting layer under a pressure of 0.3 MPa at 60 ℃ for 15 s _via_ a pneumatic hot-press to complete the whole devices fabrication. For fabricating carbon-based modules, laser scribing was performed twice, before and after perovskite film deposition, to form P1 and P2 with 1064 nm wavelength to complete the series interconnection between sub-cells in the module. Meanwhile, mechanical scribing was performed on the carbon electrode to obtain sub-electrode units insulated from each other before assembly. Finally, the electrode was pressed onto the HTL with the same process of small devices. 

**Recycling and repair of PSCs with CDI.** The degraded DC-PSCs were firstly disassembled to obtain the free-standing electrode and perovskite/spiroOMeTAD semi-cell. The perovskite/spiro-OMeTAD semi-cell was subsequently washed out with chlorobenzene to recycle spiro-OMeTAD material. The recycled spiro-OMeTAD solution was washed with toluene and concentrated using a rotary evaporator. The obtained powder was further washed by deionized water, extracted with ethyl acetate, and dried in a vacuum oven to be reused for spin-coating the recycled spiro-OMeTAD film on the perovskite film. Ultimately, the above disassembled carbon electrode was reassembled on the perovskite/recycled spiro-OMeTAD unit to complete the repair of PSCs. 

9 

258 259 260 261 262 263 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 279 280 281 282 283 284 285 286 287 288 289 290 

291 292 293 294 295 296 297 298 299 300 301 302 303 304 305 306 

**Device characterization.** The surface microstructure and cross-sectional structure of carbon film were investigated by a field-emission scanning electron microscopy (FE-SEM, Hitachi SU8010). The time-resolved photoluminescence (TRPL) spectra were measured by a HORIBA Jobin-Yvon Fluorolog-III fluorimeter. The steady-state photoluminescence (PL) spectra were measured by a Horiba JobinYvon LabRAM HR800s Raman spectrometer with a 450 nm wavelength excitation source. The X-ray diffraction (XRD) patterns were collected from X-ray diffractometer (D8 Advance). Atomic force microscopybased infrared spectroscopy (AFM-IR) experiments were carried out using a commercial AFM-IR setup (NanoIR3s, Bruker, CA, USA) that consists of an AFM microscope operating in contact mode and a Quantum Cascade Laser or QCL laser (MIRcat, Daylight Solutions Inc., CA, USA), that was tunable from 2350 cm<sup>-1</sup> to ≈ 870 cm<sup>-1</sup> (from 4.25 to 11.49 μm). The current density-voltage (J-V) curves were measured using a solar simulator (Oriel 94023A, 300 W) with a source meter (Keithley 2400) under 100 mW cm-2 illumination (AM 1.5G) with a scan rate of 10 mV s<sup>-1</sup> for solar cells and 50 mV s<sup>-1</sup> for modules. The intensity was calibrated using a standard Si solar cell (Oriel, VLSI standards). The small-area PSCs and large-area PSMs are measured using masks with aperture area of 0.16 cm<sup>2</sup> and 17.1 cm<sup>2</sup> , respectively. 

**Fourier transform infrared spectroscopy (FTIR) measurement.** The polymer monomers were first polymerized on the perovskite surface, and then the sample was cleaned with DMF solution and dried under vacuum to remove the perovskite material. The IR spectra were recorded with a VERTEX 70 Infrared Fourier transform microscope (Bruker Co., Germany). 

**X-ray photoelectron spectroscopy (XPS) measurement.** XPS measurements were performed with a PHI VersaProbe II scanning XPS microprobe using a monochromatic Al Kα x-ray of 24.8-W power with a beam size of 100 µm. All peaks were calibrated using C 1s peak at 284.8 eV to correct charge shift of binding energies. Depth profiling etching speed was calibrated using Si as standard. 

**Time-of-flight secondary-ion mass spectrometry (TOF-SIMS) Measurements.** Compositional depth profiling of perovskite films was carried out using a TOF-SIMS 5 system from IONTOF, operated in the spectral mode and using a 30-keV Bi<sup>3+</sup> primary ion beam with an ion current of 0.8 pA. For depth profiling, a 1-keV Cs<sup>+</sup> sputter beam with a current of 28 nA was used to remove material layer by layer in interlaced mode, from a raster area of 300 μm × 300 μm. Mass spectrometry was performed on an area of 80 μm × 80 μm in the center of the sputter crater. 

**Transient absorption (TA) measurements.** Femtosecond laser pulses of 800 nm fundamental beam (5 kHz repetition rate, 35 fs pulse width) were produced using a Ti: Sapphire regenerative amplifier (Legend Duo, Coherent Inc.).Part of the fundamental beam was used to pump an optical parametric amplifier (TOPAS-Prime, Light Conversion) to serve as a narrowband pump, while the other part was focused on a sapphire crystal to generate a white-light supercontinuum probe (420-780nm window with various optical filters).The pump wavelength was 400 nm under pump power of 3 μJ/cm<sup>2</sup> . Both the pump and probe pulses were directed into a commercial TA spectrometer (Helios, Ultrafast Systems). Delaying the probe pulse relative to the pump pulse provides a time window of up to 8 ns. The instrument response function (IRF) was determined to be ∼ 200 fs by a routine cross-correlation procedure. All TA spectra were chirp-corrected. 

**Stability test.** For the stability tests of 3D/2D perovskite heterostructure, all samples were aged at 100<sup>o</sup> C for 120 min under nitrogen atmosphere. The operational stability tests were carried out at the MPP for the encapsulated cells under one sun illumination (100 mW cm<sup>-2</sup> ). The cells were tested in a chamber with an ambient atmosphere temperature of ~60 °C. The bias at the MPP was calculated and applied automatically. The cells were encapsulated in a N2-filled glovebox. A hot melt film was attached around the active area of the cells, and a glass slide was employed as the back sheet. Then the sample (cell/hot melt film/glass slide) was heated at 100 °C under a vacuum condition (<100 Pa) for 15 min by a commercial laminating system. 

**Reporting Summary.** Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

## **Data availability** 

The datasets analysed and generated during the current study are included in the paper and its Supplementary Information. Source data are provided with this paper. 

## **References** 

1. Min, H. _et al._ Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ , **598** , 444-450 (2021). 

2. Bu, T. _et al._ Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. _Science_ , **372** , 1327-1332 (2021). 

3. Chen, S. _et al._ Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ , **373** , 902-907 (2021). 4. National Renewable Energy Laboratory (NREL), Best research-cell efficiency chart (2021), <u>http://www.nea.gov.cn/202102/03/c_139717609.htm (2021).</u> 

5. Jeong, J. _et al._ Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ , **592** , 381-385 (2021). 

6. Yoo, J. J. _et al._ Efficient perovskite solar cells via improved carrier management. _Nature_ , **590** , 587-593 (2021). 

7. Deng, Y. _et al._ Defect compensation in formamidinium–caesium perovskites for highly efficient solar mini-modules with improved photostability. _Nat. Energy_ , **6** , 633-641 (2021). 

8. Y. Liu _et al._ Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant perovskite solar cells with efficiencies exceeding 22%. _Sci._ 

10 

307 308 309 310 311 312 313 314 315 316 317 318 319 320 321 322 323 324 325 326 327 328 329 330 331 332 333 334 335 336 337 338 339 340 341 342 343 344 345 346 347 348 349 350 351 352 353 354 355 356 357 358 359 360 361 362 363 364 365 366 367 368 369 370 371 372 373 374 375 376 377 

|9.<br>10.|_Adv._,**5**, eaw2543 (2019).<br>Yang, G._et al._Stable and low-photovoltage-loss perovskite solar cells by multifunctional passivation._Nat. Photon._,**15**, 681-689 (2021).<br> Yao, Q._et al._Graded 2D/3D Perovskite Heterostructure for Efficient and Operationally Stable MA-Free Perovskite Solar Cells._Adv. Mater._,<br>**32**2000571 (2020)|
|---|---|
|11. <br>12. <br>13. <br>14. <br>15.|,  .<br> Zhang, F._et al._Metastable Dion-Jacobson 2D structure enables efficientand stable perovskite solar cells._Science_,**375**, 71-76 (2021).<br> Chen, H._et al._Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells._Nat. Photon._,**16**, 352-358 (2022).<br> Tan, S._et al._Stability-limiting heterointerfaces of perovskite photovoltaics._Nature_,**605**, 268-273 (2022).<br> Azmi, R._et al._Damp heat–stable perovskite solar cells with tailored-dimensionality 2D/3D heterojunctions._Science_,**376**, 73-77 (2022).<br> Liu, Z._et al._A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability._Nat._<br>_Energy_,**5**, 596-604 (2020).|
|16.|Alharbi, E. A._et al._Atomic-level passivation mechanism of ammonium salts enabling highly efficient perovskite solar cells._Nat. Commun._,<br>**10**9 (2019).|
|17. <br>18.|,<br> Proppe, A. H._et al._Multication perovskite 2D/3D interfaces form via progressive dimensional reduction._Nat. Commun._,**12**, 3472 (2021).<br> Wang, F._et al._2D-Quasi-2D-3D Hierarchy Structure for Tin Perovskite Solar Cells with Enhanced Efficiency and Stability._Joule_,**2**, 2732-<br>2743 (2018).|
|19.|<br> Wang, Z._et al._Efficient ambient-air-stable solar cells with 2D–3D heterostructured butylammonium-caesium-formamidinium lead halide<br>perovskites._Nat. Energy_,**2**, 17135 (2017).|
|20.|<br> Chen, J._et al._Simultaneous Improvement of Photovoltaic Performance and Stability by In Situ Formation of 2D Perovskite at<br>(FAPbI3)0.88(CsPbBr3)0.12/CuSCN Interface._Adv. Energy Mater._,**8**, 1702714 (2018).|
|21.|Bu, T._et al._Modulating crystal growth of formamidinium–caesium perovskites for over 200 cm2 photovoltaic sub-modules._Nat. Energy_,<br>2022|
|22.|().<br> Yoo, J. W._et al._Efficient perovskite solar mini-modules fabricated via bar-coating using 2-methoxyethanol-based formamidinium lead tri-<br>iodide precursor solution._Joule_,**5**, 1-17 (2021).|
|23.|Sutanto, A. A._et al._In Situ Analysis Reveals the Role of 2D Perovskite in Preventing Thermal-Induced Degradation in 2D/3D Perovskite<br>Interfaces._Nano Lett._,**20**, 3992-3998 (2020).|
|24.|Sutanto, A. A._et al._Dynamical evolution of the 2D/3D interface: a hidden driver behind perovskite solar cell instability._J. Mater. Chem. A_,**8**,<br>23432348 (2020)|
|25.|- .<br> Mosconi, E._et al._Mobile Ions in Organohalide Perovskites: Interplay of Electronic Structure and Dynamics._ACS Energy Lett._,**1**, 182-188<br>(2016)|
|26.|.<br> Motti, S. G._et al._Defect Activity in Lead Halide Perovskites._Adv Mater_,**31**, e1901183 (2019).|
|27. <br>28.|<br> Zhou, Y._et al._Defect activity in metal halide perovskites with wide and narrow bandgap._Nat. Rev. Mater._,**6**, 986-1002 (2021).<br> Chen, J._et al._Stabilizing the Ag Electrode and Reducing J-V Hysteresis through Suppression of Iodide Migration in Perovskite Solar Cells.<br>_ACS Appl Mater Interfaces_ **9**36338-36349 (2017)|
|29. <br>30|,,  .<br> Grancini, G._et al._Dimensional tailoring of hybrid perovskites for photovoltaics._Nat. Rev. Mater._,**4**, 4-22 (2019).<br>Lee J-W_et al_2D erovskite stabilized hase-ure formamidinium erovskite solar cells_Nat Commun_**9**3021 (2018)|
|. <br>31.|, .._._p  pp  p  ._. ._,,  .<br> Luo, C._et al._Facet orientation tailoring via 2D-seed- induced growth enables highly efficient and stable perovskite solar cells._Joule_,**6**, 1-18<br>(2022)|
|32.|.<br> Bi, E._et al._Mitigating ion migration in perovskite solar cells._Trends Chem._,**3**, 575-588 (2021).|
|33. <br>34.|Bai, S._et al._Planar perovskite solar cells with long-term stability using ionic liquid additives._Nature_,**571**, 245-250 (2019).<br> Yuan, Y._et al._Ion Migration in Organometal Trihalide Perovskite and Its Impact on Photovoltaic Efficiency and Stability._Accounts Chem._<br>_Res_**49**286-293 (2016)|
|35. <br>36.|_._,,  .<br> Lee, J.-W._et al._Verification and mitigation of ion migration in perovskite solar cells._APL Mater._,**7**,  (2019).<br> Li, N._et al._Cation and anion immobilization through chemical bonding enhancement with fluorides for stable halide perovskite solar cells.<br>|
|37. <br>38. <br>39.|_Nat. Energy_,**4**, 408-415 (2019).<br> Wang, Y._et al._Stabilizing heterostructures of soft perovskite semiconductors._Science_,**365**, 687-691 (2019).<br> Bi, E._et al._Efficient Perovskite Solar Cell Modules with High Stability Enabled by Iodide Diffusion Barriers._Joule_,**3**, 2748-2760 (2019).<br> Lin, X._et al._In situ growth of graphene on both sides of a Cu–Ni alloy electrode for perovskite solar cells with improved stability._Nat. Energy_,<br>2022|
|40. <br>41. <br>42. <br>43.|().<br> Li, Z._et al._Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells._Science_,**376**, 416-420 (2022).<br> Li, X._et al._Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells._Science_,**375**, 434-437 (2022).<br> Yang, S._et al._Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts._Science_,**365**, 473-478 (2019).<br> Kikuchi, K._et al._Structure and optical properties of lead iodide based two-dimensional perovskite compounds containing<br>fluorophenethylamines._Curr. Appl. Phys._,**4**, 599-602 (2004).|
|44.|<br> Chen, H._et al._The research progress of polyhedral oligomeric silsesquioxane (POSS) applied to electrical energy storage elements._Funct._<br>_Mater. Lett._,**10**, 1730001 (2017).|
|45. <br>46.|<br> Pan, H._et al._Organic–inorganic hybrid proton exchange membrane based on polyhedral oligomeric silsesquioxanes and sulfonated polyimides<br>containing benzimidazole._J. Power Sources_,**263**, 195-202 (2014).<br> Li, Z._et al._In situ implantation of cross-linked functional POSS blocks in Nafion® for high performance direct methanol fuel cells._J._<br>_Membrane Sci._,**640**, 119798 (2021).|
|47.|<br> Ma, J._et al._Dipentaerythritol penta-/hexa-acrylate based-highly cross-linked hybrid monolithic column: Preparation and its applications for<br>ultrahigh efficiency separation of proteins._Anal Chim Acta_,**963**, 143-152 (2017).|
|48.|<br> Cobos, M._et al._PCL/POSS Nanocomposites: Effect of POSS Derivative and Preparation Method on Morphology and Properties._Polymers_,<br>**11**, 33 (2018).|
|49|<br>Quintero-Bermudez R_et al_Compositional and orientational control in metal halide perovskites of reduced dimensionalit_Nat Mater_**17**|
|.|, ._._y._. ._,,<br>900-907 (2018).|
|50.|<br> Hu, J._et al._Synthetic control over orientational degeneracy of spacer cations enhances solar cell efficiency in two-dimensional perovskites.<br>_Nat. Commun._,**10**, 1276 (2019).|



51. Jang, Y.-W. _et al._ Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. _Nat. Energy_ , **6** , 63-71 (2021). 

52. Zhou, Q. _et al._ High‐Performance Perovskite Solar Cells with Enhanced Environmental Stability Based on a (p‐FC6H4C2H4NH3)2[PbI4] Capping Layer. _Adv. Energy Mater._ , **9** , 1802595 (2019). 

11 

379 We thank the Analytical and Testing Center from HUST and the Center for Nanoscale Characterization and Devices (CNCD) from WNLO (HUST) for the 380 facility support of sample measurements. We would like to thank Suzhou Institute of Nano-Tech and Nano-Bionics for performing TOF-SIMS. Z.W. 381 acknowledges the Banting Postdoctoral Fellowships Program of Canada. This work was financially supported by the National Natural Science Foundation 382 of China (21875081, 91733301, and 51972251), the Chinese National 1000-Talent-Plan program, the Foundation of State Key Laboratory of Coal Conversion 383 (Grant No. J18-19-913). 

384 

385 L. Luo, H. Zeng and Z. Wang contributed equally to this work. X. Li directed and supervised the project. L. Luo, Z. Wang and Y. Rong designed the 386 experiments. L. Luo fabricated the perovskite devices. H. Zeng synthesized polymer materials. L. Luo, M. Li and S. You contributed to the certification of 387 mini-modules. C. Wang, W. Li and L. Luo carried out the SEM, PL and TRPL experiments. S. Zhang and X. Zheng conducted the XRD and XPS measurement. 388 L. Luo and H. Zeng conducted the ICP-OES measurement and contributed to the data analysis. L. Li and Y. Zhao conducted the AFM-IR measurement. R. 389 Guo conducted the stability tests on the devices. R. Huang conducted the TOF-SIMS measurement. X. Cai and W. Liang conducted the TA measurements. 390 L. Luo wrote the first draft of the manuscript. X. Li, E. H. S., Y. Rong, Z. Wang, B. Chen, A. Maxwell and H. Zeng revised the manuscript. All authors 

## 378 **Acknowledgements** 

## **Author contributions** 

- 390 L. Luo wrote the first draft of the manuscript. X. Li, E. H. S., Y. Rong, Z. Wang, B. Chen, A. Maxwell and H. Zeng revised the manuscript. All authors 391 analyzed the data and reviewed the manuscript. 

## 392 

## **Competing interests** 

393 The authors declare no competing interests. 

## 394 

## **Additional information** 

- 395 **Supplementary information** The online version contains supplementary material available at 

- 396 **Correspondence and requests for materials** should be addressed to Yaoguang Rong, Edward H. Sargent, Xiong Li. 

12 





This is a list of supplementary �les associated with this preprint. Click to download. 

supplementaryinformation.pdf 

