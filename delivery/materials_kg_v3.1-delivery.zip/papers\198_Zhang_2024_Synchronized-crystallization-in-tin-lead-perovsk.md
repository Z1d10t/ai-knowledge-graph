# Synchronized crystallization in tin-lead perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 162 |
| 作者 | Yao Zhang, Chunyan Li, Haiyan Zhao, Zhongxun Yu, Xiaoan Tang, Jixiang Zhang, Zhen-Hua Chen, Jian-Rong Zeng et al. |
| DOI | 10.1038/s41467-024-51361-2 |
| 源文件 | 098_Zhang_2024_Synchronized-crystallization-in-tin-lead-perovsk.pdf |

---
Article 



https://doi.org/10.1038/s41467-024-51361-2 

# Synchronized crystallization in tin-lead perovskite solar cells 

Received: 2 July 2024 Yao Zhang 1,2,7, Chunyan Li 1,2,7, Haiyan Zhao 1,2, Zhongxun Yu1,2,3, Xiaoan Tang<sup>1,2</sup> , Jixiang Zhang<sup>1,2,3</sup> , Zhenhua Chen<sup>4</sup> , Jianrong Zeng<sup>4,5</sup> , Accepted: 2 August 2024 Peng Zhang<sup>1,6</sup> , Liyuan Han 1 & Han Chen 1,2,6 Check for updates Tin-lead halide perovskites with a bandgap near 1.2 electron-volt hold great promise for thin-film photovoltaics. However, the film quality of solutionprocessed Sn-Pb perovskites is compromised by the asynchronous crystallization behavior between Sn and Pb components, where the crystallization of Sn-based perovskites tends to occur faster than that of Pb. Here we show that the rapid crystallization of Sn is rooted in its stereochemically active lone pair, which impedes coordination between the metal ion and Lewis base ligands in the perovskite precursor. From this perspective, we introduce a noncovalent binding agent targeting the open metal site of coordinatively unsaturated Sn(II) solvates, thereby synchronizing crystallization kinetics and homogenizing Sn-Pb alloying. The resultant single-junction Sn-Pb perovskite solar cells achieve a certified power conversion efficiency of 24.13 per cent. The encapsulated device retains 90 per cent of the initial efficiency after 795 h of maximum power point operation under simulated one-sun illumination. 

Tin-lead halide perovskites have great photovoltaic potential, either as a single-junction solar cell<sup>1–3</sup> or as a subcell in all-perovskite tandems<sup>4–7</sup> . Compared to lead perovskites, the incorporation of tin can extend the exploitation of the solar spectrum and reduce toxic lead content. By the principle of detailed balance<sup>8</sup> , mixed Sn-Pb perovskite solar cells (PSCs) possess a higher radiative efficiency limit than the Pb-based analogs. However, the practical efficiency of Sn-Pb PSCs thus far remains below 24%, lagging behind that of the Pb-based devices which have exceeded 26%<sup>9</sup> . 

A primary challenge introduced by Sn incorporation, besides the Sn(II) oxidation issue which has been extensively addressed<sup>10,11</sup> , lies in the faster crystallization of Sn-based perovskites compared to the Pb-based component<sup>12,13</sup> . The metal ion-induced nonuniform nucleation and rapid growth result in chemical heterogeneity and optoelectronic defects, substantially compromising film quality and device performance. To reach the full photovoltaic potential of Sn- 

Pb perovskites, it is crucial to resolve this asynchronous crystallization behavior. Recently, through introducing strongly coordinating ligands, notable progress has been achieved in balancing the crystallization in Sn-Pb perovskites<sup>14–16</sup> . However, the underlying chemistry deriving this disparity between Sn and Pb has yet to be understood. 

In this work, we reveal that the sterically active Sn(II) lone pair, which repels Lewis base ligands and destabilizes the high-coordination solvate intermediates, can account for the rapid crystallization of Sn perovskites. In this light, we introduce a noncovalent binding agent that can circumvent the lone pair repulsion and selectively bind to Sn(II) over Pb(II) in the precursor solution. As a result, high-quality SnPb perovskite films with homogenized composition and enhanced optoelectronic properties are produced, enabling a photovoltaic efficiency of 24.5% (certified 24.13%) for single-junction Sn-Pb PSCs, along with improved operational stability. 

> 1State Key Laboratory of Metal Matrix Composites, Shanghai Jiao Tong University, Shanghai, China. 2Innovation Center for Future Materials, Zhangjiang Institute for Advanced Study, Shanghai Jiao Tong University, Shanghai, China.<sup>3</sup> Shanghai Jiao Tong University JA Technology New Energy Materials Joint Research Center, Shanghai, China.<sup>4</sup> Shanghai Synchrotron Radiation Facility, Shanghai Advanced Research Institute, Chinese Academy of Sciences, Shanghai, China.<sup>5</sup> Shanghai Institute of Applied Physics, Chinese Academy of Sciences, Shanghai, China.<sup>6</sup> Joint Research Center for Clean Energy Materials, Shanghai Jiao Tong University, Shanghai, China.<sup>7</sup> These authors contributed equally: Yao Zhang, Chunyan Li. e-mail: chen.han@sjtu.edu.cn 

Nature Communications |  (2024) 15:6887 

1 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

## Results 

### Cause of the asynchronous crystallization 

Crystallization of halide perovskite (ABX3) generally involves the reaction between metal halides (BX2) and monovalent halides (AX), where X is (mostly) iodide in photovoltaic devices. According to the Hard and Soft Acids and Bases (HSAB) theory<sup>17</sup> , Sn(II) being a harder acid than Pb(II) implies that Sn(II) has a relatively lower affinity with the soft iodide ion. We calculated the reaction enthalpies between BX2 (SnI2 and PbI2) and common AX iodides through density functional theory (DFT) simulations (Fig. 1a and Supplementary Fig. 1). As indicated by the HSAB theory, compared with PbI2, SnI2 demonstrates lower binding energies with AX. This suggests that Sn(II) is thermodynamically less favored than Pb(II) for reacting with the AX iodides; the rapid crystallization of Sn perovskites should be more of a kinetic issue. 

Since the perovskite thin films are generally solution-processed, an essential factor governing the crystallization kinetics is the solventsolute interactions, which dictate the structure of the solvate intermediates and hence the activation barrier of the BX2-AX reaction. A common practice to retard perovskite crystallization involves the introduction of Lewis base ligands, such as dimethyl sulfoxide (DMSO)<sup>18</sup> , chloride<sup>19</sup> , acetate<sup>20</sup> , formate<sup>21</sup> , thiocyanate<sup>22</sup> , and amino acids<sup>2,23</sup> . These donor ligands can form coordinated covalent bonds with the metal ion, thereby hindering the BX2-AX reaction and slowing film growth. However, this Lewis base approach may be relatively less effective for Sn(II) than it is for Pb(II), as discussed below. 

Although Sn is above Pb in group 14 on the periodic table, the energy level of Sn 5 s orbital is higher than that of Pb 6s due to the relativistic contraction of the latter, which also makes the Pb(II) state more stable than Pb(IV). This difference in chemistry between Sn(II) and Pb(II) substantially impacts how the metal ion interacts with the donor ligands. In the frontier orbital perspective, there are mainly two interactions (Fig. 1b): one is between the highest occupied molecular orbital (HOMO) of ligand and the unoccupied metal np orbital (gray lines), forming the attractive dative bond; the other is between ligand HOMO and the metal ns<sup>2</sup> lone pair (red/blue lines), which is destabilizing and repulsive due to the occupied anti-bonding orbital. According to the second-order perturbation theory, the strength of the HOMO-ns<sup>2</sup> interaction can be measured based on orbital overlap and energy level separation<sup>24</sup> : 



<!-- Start of picture text -->
2<br>ΔE = ���Hij��� ð1Þ<br>E 0 i � E0 j<br><!-- End of picture text -->

where Hij is the Hamiltonian matrix element, E<sup>0</sup> i<sup>andE0</sup> j<sup>arethe</sup> unperturbed energies of the two orbitals. Compared to Pb 6s, Sn 5s is closer to, or more resonant with, the ligand HOMO, hence the repulsion between Sn(II) lone pair and the ligand is more pronounced<sup>25</sup> . This prominent repulsive orbital interaction is the origin of the narrow bandgap and light holes of Sn perovskites. However, it also impedes the coordination between Sn(II) and Lewis base ligands in the perovskite precursor, limiting the efficacy of the Lewis base approach. 

We present the reaction coordinate diagram of BX2 coordinated with DMSO (Fig. 1c) and dimethylformamide (DMF, Supplementary Fig. 2), two common solvents employed in perovskite fabrication. When the coordination number is low (small Hij), the ns<sup>2</sup> lone pair remains largely non-bonding and the stereochemical expression is insignificant. Hence, SnI2 exhibits slightly higher binding strength with the solvent molecule than PbI2, which can also be understood by the HSAB theory as the oxygen atom (of the solvent) is a hard base. Upon higher coordination numbers, however, the ligand HOMO-ns<sup>2</sup> overlap inevitably increases (large Hij) and the lone pair stereochemistry becomes significant, making the cohesive energies of the SnI2•nL (n = 2‒4, L = DMSO or DMF) complexes lower than that of PbI2•nL. Furthermore, a geometric disparity between SnI2•4DMSO and 

PbI2•4DMSO highlighting the lone pair activity of Sn(II) is noted; the SnI2•4DMSO exhibits a hemi-directed environment while PbI2•4DMSO is holo-directed. This distorted coordination of Sn(II) is also observed in some tin chalcogenides (SnS and SnSe)<sup>26</sup> , contrasting with PbS and PbSe which are rock salt structures. 

The disparity in the structure of the BX2 solvate intermediates has been observed by the community. Experimentally determined Sn(II) solvates in DMF or DMSO are generally isolated complexes and feature coordinatively unsaturated geometry with open Sn sites, including SnI2•DMF<sup>27</sup> , SnI2•DMSO<sup>27</sup> , SnI2•2DMSO<sup>27</sup> , SnI2•3DMSO<sup>12</sup> , and Sn(II) •5DMSO<sup>28</sup> . The absence of reports regarding [SnX6] suggests the instability of such a hexa-coordinated solvate intermediate in the solution state. As for Pb(II), although the solvate phases can be isolated complexes, bridged chains, or clusters, the local structures are ubiquitously mixed-ligand [PbX6] octahedra<sup>29–31</sup> , with X being halide or solvent. For SnI2•3DMSO, the SnI2 solvate with the highest coordination level, the cohesive energy delivered by the three DMSO ligands was found to be −1.920 eV through DFT, lower than that of the PbI2•4DMSO (−2.592 eV). For polyiodide [PbX6] in chain or cluster intermediates, the cohesive energy should be comparable to or higher than that of PbI2•4DMSO, as the Pb-I bond is stronger than Pb-DMSO dative bond. Therefore, since the BX2-AX reaction involves the decomplexation of the solvate intermediates, the crystallization of Sn perovskites should have a lower activation barrier and accordingly a higher rate than that of Pb perovskites. 

### Noncovalent binding agent 

Given the Sn(II) lone pair disfavoring coordinate covalent bonds, we resort to noncovalent interactions to regulate the crystallization kinetics of Sn(II) perovskites. Noncovalent interactions have been utilized to modulate perovskite crystallization, including hydrogen bond<sup>32</sup> , halogen bond<sup>33</sup> , and anion-π interaction<sup>34</sup> . Amines and nucleophilic aromatic molecules are favorable candidates to bind with the unsaturated Sn(II) solvate through noncovalent forces, such as aniline<sup>35</sup> , piperazine<sup>36</sup> , pyrazine<sup>37</sup> , and aminopyridine<sup>38,39</sup> , which have been proven beneficial in Sn-Pb or neat-Sn perovskites. Here, a simple aromatic amine molecule, p-phenylenediamine (PPD), is employed as the noncovalent binding agent. The resonance effect of PPD, where the nitrogen lone pairs are partially delocalized into the benzene π system, makes the aromatic ring highly nucleophilic and polarizable and thus suitable to establish noncovalent interactions with the Sn(II) solvate, as will be discussed. 

We simulated the interactions of PPD with the typical BX2 solvate intermediates reported in the literature (Fig. 1d and Supplementary Fig. 3). For PPD to bind with the hexa-coordinated Pb(II) in PbI2•DMSO<sup>30</sup> (Fig. 1d), it would need to substitute a DMSO ligand. However, as the intramolecular resonance reduces the basicity of PPD, such a substitution is thermodynamically unfavored with an energy change of +0.31 eV. For PbI2•DMF (Supplementary Fig. 3a), owing to the lower coordinating ability of DMF, the substitution results in an energy change of −0.06 eV. In the PbI2•2DMSO chain, where the Pb-Pb distance is shorter than in PbI2•DMSO, PPD can form H-bonds with adjacent DMSO ligands, further lowering the energy and yielding an energy change of −0.22 eV. In contrast, for the coordinatingly unsaturated SnI2•3DMSO<sup>8</sup> (Fig. 1d) and SnI2•2DMSO<sup>27</sup> (Supplementary Fig. 3b), PPD can directly occupy the open site without forming a dative bond with the metal ion, yielding binding energies of −0.74 eV and −0.64 eV, respectively. 

Ab initio molecular dynamics (AIMD) simulation was conducted to elucidate the dynamic interaction between PPD and the solvate intermediates. The PPD molecule readily engaged and anchored to the SnI2•3DMSO intermediate (Supplementary Movie 1), and the resulting complex structure is consistent with the DFT result. Whereas for PbI2•DMSO and PbI2•2DMSO (Supplementary Movies 2 and 3), PPD primarily interacted with solvent ligands and iodide ions through 

Nature Communications |  (2024) 15:6887 

2 

Article 

https://doi.org/10.1038/s41467-024-51361-2 



<!-- Start of picture text -->
a b<br>-2.5<br> PbI2 0<br> SnI2<br>-2.0 -2<br>Sn 5 p<br>-4<br>-1.5<br>-6<br>DMSO HOMO<br>DMF HOMO<br>-1.0 -8 Iodide 5 p<br>-10<br>-0.5<br>Sn 5 s<br>-12<br>0.0 Pb 6 s<br>FAI MAI CsI RbI DMF DMSO -14<br>c<br>PbI2 SnI2 DMSO<br>0<br>-1.071 eV<br>-1.576 eV<br>-1.920 eV<br>-1 -2.194 eV<br>-1.076 eV<br>-2<br>-1.579 eV<br>-3 -2.048 eV<br>-2.592 eV<br>Coordination number (n)<br>d<br>e<br>+0.31 eV<br>+ +<br>-0.74 eV<br>+<br>Attraction Repulsion<br>Pb 6 p<br>Energy (eV)<br>Binding Energy (eV)<br>Binding Energy (eV)<br><!-- End of picture text -->

Fig. 1 | DFT analysis of the BX2–ligand interactions. a Binding energy of BX2 (SnI2 and PbI2) with the AX iodides and solvent molecules. FAI formamidinium iodide, MAI methylammonium iodide, CsI cesium iodide, RbI rubidium iodide, DMSO dimethyl sulfoxide, DMF dimethylformamide. b Frontier orbital interaction diagram of the metal ion-DMSO complex. HOMO highest occupied molecular orbital. 

c Reaction coordinate diagram of BX2 binding with different numbers of DMSO ligands. d Simulated reactions between PPD and the solvate intermediates (PbI2•DMSO and SnI2•3DMSO) and the corresponding energy changes. e IGMH analysis of the intermolecular noncovalent interactions between PPD and SnI2•3DMSO. 

H-bonds during the 3-µs simulation, with no direct coupling to Pb(II) observed. The DFT and AIMD results indicate that PPD preferentially binds to Sn(II) over Pb(II) in the precursor, both thermodynamically and kinetically. 

To gain more insight into the intermolecular interactions between PPD and Sn(II) solvate, symmetry-adapted perturbation theory (SAPT)<sup>40</sup> was used to decompose the intermolecular interaction energy (Supplementary Table 1), which revealed that electrostatics and 

Nature Communications |  (2024) 15:6887 

3 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

dispersion are mainly responsible for the intermolecular attraction, while the charge-transfer contribution is negligible. The Hirshfeld charge of Sn in SnI2•3DMSO before and after PPD binding is 0.34e and 0.35e, respectively, also indicating trivial charge transfer. Furthermore, an independent gradient model based on Hirshfeld partition (IGMH)<sup>41</sup> was used to visualize the interactions in real space (Fig. 1e). Apart from the hydrogen bonds, a notable attractive force between Sn(II) cation and the aromatic ring is detected, which indicates the cation-π interaction, a noncovalent effect essentially of electrostatic origin and tending to be stronger than hydrogen bond<sup>42</sup> . With these insights, we can discuss the molecular design of the noncovalent binding agent. 

To promote intermolecular electrostatics and dispersion, a nucleophilic and polarizable π system is of interest. Besides PPD, molecules with different substituent groups on the aromatic ring were also studied, including benzene, toluene, aniline, phenol, o-phenylenediamine (OPD), and m-phenylenediamine (MPD). The electrostatic potential (ESP) profiles at the van der Waals surface and the local ESP minimum near the ring center were obtained through DFT (Supplementary Fig. 4). Owing to the resonance effect, PPD exhibited the most electron-rich ring center, showing a local ESP minimum of −1.15 eV. The complex structures and binding energies of these agents with SnI2•3DMSO were also simulated (Supplementary Fig. 5), where PPD delivered the highest binding energy with Sn(II) solvate. Notably, the binding energy is positively correlated to the local ESP minimum at the ring center (Supplementary Fig. 6), indicating the predominant role of electrostatics in the intermolecular interactions. 

### Selective targeting of PPD towards Sn(II) 

To explore the interactions between PPD and BX2, solutions of BX2 without and with PPD were prepared in DMSO and DMF/DMSO (3:1, v/ v) solvents. The mixtures were dissolved at 50 °C (Supplementary Fig. 7) and stored for 12 h in an N2 atmosphere at ambient temperature for a complete reaction (Fig. 2a–c). In the case of PbI2, the incorporation of PPD darkened the solutions and redshifted the absorption spectra. This effect arose from the acid-base reaction between PbI2 and protic PPD<sup>43</sup> (Supplementary Fig. 8). This reaction could be facilitated by the Pb-N dative bond which acidifies the -NH2 protons. Conversely, PPD caused a slight blueshift in the SnI2 solutions, suggesting that the coupling between PPD and Sn(II) solvates reduced the iodide coordination level of the solvate species. 

The mixed SnI2 + PbI2 solutions exhibited a narrower optical bandgap than both SnI2 and PbI2 solutions, implying the presence of the bandgap bowing effect in the solution state, through the local Sn-IPb bond. With PPD introduced, the SnI2 + PbI2 solutions also demonstrated blueshifted spectra, indicating that PPD could suppress the formation of the Sn-I-Pb bridge structure. Meanwhile, the lighter color also revealed prevented PPD-PbI2 reaction and the selective binding of PPD towards Sn(II). This selectivity was also observed in a mixed Sn(II)/ Sn(IV) solution (Supplementary Note 1 and Supplementary Fig. 9). Without a stereochemically active lone pair, Pb(II) and Sn(IV) were fully coordinated by solvent ligands in the solution, and thus exhibited lower affinity with PPD than under-coordinated Sn(II). 

Proton nuclear magnetic resonance spectroscopy (<sup>1</sup> H NMR, Fig. 2d) was conducted to investigate the interactions between PPD and BX2 in a DMSO solution. When mixing PPD into PbI2 solution (DMSO-d6), no discernible shift of the protons was observed, suggesting that the majority of PPD had not interacted with the DMSOcoordinated PbI2. Meanwhile, three tiny peaks emerged at 7.12, 7.52, and 8.12 ppm and are ascribed to protonated PPD, evidencing the acidbase reaction. In contrast, no signal of protonated PPD is observed in SnI2 + PPD, revealing that the acid-base reaction does not occur with SnI2. The nucleophilic attack of the -NH2 group could be blocked by the Sn(II) lone pair. Additionally, compared to the Pb-I bond, the Sn-I bond has a more covalent character, making the iodine anion harder to ionize. 

In the PbI2 + SnI2 + PPD mixture, the protonated PPD signals were also absent, revealing that SnI2 could prevent the reaction between PPD and PbI2, as the PPD molecules were captured by SnI2 solvates. For the SnI2-containing solutions, the PPD protons, especially those of the amine group, exhibited prominent downfield shifts and peak splitting/ broadening. The deshielding is caused by the intermolecular H-bonds and the inductive effect of Sn(II) cation, and the peak splitting/ broadening should result from the equivalence breaking of the aromatic/amine protons. We also conducted NMR measurements in mixed DMF-d7/DMSO-d6 and studied the interactions of PPD with FA cation in the perovskite precursors, as discussed in Supplementary Note 2 and Supplementary Figs. 10–12. 

Fourier-transform infrared spectroscopy (FTIR, Fig. 2e) measurements were also performed on the DMSO solutions. No discernible vibration shift was observed between the PPD and PPD+PbI2 samples, consistent with the NMR result that the majority of PPD agents did not bind with PbI2 under the screen of DMSO. In contrast, when PPD was mixed into SnI2 and PbI2 + SnI2 solutions, the vibrations of C-N stretching, N-H bending (overtone), and N-H stretching all shifted to lower wavenumbers. These redshifts were likely caused by the intermolecular coupling between PPD and the Sn(II) solvate, perturbing the intramolecular vibrations. 

Extended X-ray absorption fine structure (EXAFS, Fig. 2f) measurements were conducted to detect the local coordination environment of Sn(II) and Pb(II) within the perovskite precursor. The 2 M pristine precursor (Rb0.04Cs0.2FA0.76Pb0.5Sn0.5I3) is denoted as ‘control’ and the precursor doped with PPD (0.08 M) is denoted as ‘target’. Noteworthy, the Pb-O shell exhibited a lower intensity than the Pb-I shell, while the Sn-O shell intensity was higher than the Sn-I shell. This revealed the disparity in the solvate structure between Pb(II) and Sn(II); the Pb(II) solvates tended to form extended structures with polyiodide plumbates [PbX6], whereas the Sn(II) solvates were isolated complexes with more solvent ligands in the Sn(II) surrounding. 

With PPD incorporated, the Pb-O shell intensity slightly increased, while the Pb-I shell intensity decreased. This suggests increased solvent content and reduced iodide in the [PbX6] plumbates, indicating reduced polymeric Pb(II) solvate intermediates in the target precursor. For Sn(II), the Sn-O and Sn-I shells slightly shifted to longer radial distances. This is consistent with the DFT-simulated complex structure, where the average lengths of the Sn-O and Sn-I bonds tend to increase with PPD adsorption (Supplementary Fig. 13). Meanwhile, the ‘Sn-I’ shell of the target precursor exhibited a higher intensity than that of the control. This is attributed to the presence of the PPD molecule, as the distance between Sn(II) and PPD is comparable to the Sn-I bond length. 

### Crystallization and film quality 

To investigate the impact of PPD on the crystallization kinetics of the Sn-Pb perovskite, in situ photoluminescence (PL) spectra were collected during spin-coating and annealing (Fig. 3a). The perovskite films were fabricated through the conventional one-step anti-solvent approach. For the control sample, after the anti-solvent (ethyl acetate) treatment, the wet film exhibited a gradually redshifted and broadened emission. The PL peak approached approximately ~1000 nm within 20 s, indicating spontaneous crystallization at room temperature. In contrast, the target wet film at this stage displayed narrower emission spectra and limited evolution of the peak position, demonstrating suppressed crystallization. 

During the annealing stage, PL emission of the control film was quenched within 40 sec, resulting from thermally induced defects and subsequent non-radiative recombination. In contrast, the thermal quenching of the target film was significantly slowed down, indicating enhanced crystallinity and heat resistance. Notably, within the initial 5 sec of annealing, the PL intensity of the target film exhibited multiple stages of increase and decrease, accompanied by a prominent redshift. 

Nature Communications |  (2024) 15:6887 

4 

Article 

https://doi.org/10.1038/s41467-024-51361-2 



<!-- Start of picture text -->
a b<br>PbI2 PbI2+PPD SnI2 SnI2+PPD PbI2+SnI2 PbI2+SnI2+PPD 2<br>PbI2<br>DMSO  PbI2 + PPD<br>SnI2<br> SnI2 + PPD<br>PbI2 + SnI2<br>DMSO  PbI2 + SnI2 + PPD<br>1<br>DMF/DMSO<br>0<br>400 450 500 550<br>Wavelength (nm)<br>d c<br>NH2a 2 PbI2<br>b  PbI2 + PPD<br>H2N b H3N NH2 SnI2<br>a  SnI2 + PPD<br>PPD H2O DMSO PbI2 + SnI2<br>b b  PbI2 + SnI2 + PPD<br>1<br>PPD+PbI2<br>b a DMF/DMSO<br>a<br>PPD+SnI2 b<br>b<br>a<br>PPD+PbI2 +SnI2 a<br>0<br>10 8 6 4 2 0 8.0 7.5 7.0 6.5 6.0 5.5 400 450 500 550<br>δ (ppm) δ(ppm) δ (ppm) Wavelength (nm)<br>e f<br>Neat DMSO Pb L3-edge Pb-I Control<br> Target<br>PPD C-N stretch<br>N-H bend Pb-O<br>N-H stretch<br>PPD+PbI2<br>PPD+SnI2 Sn K-edge Control<br>PPD+PbI2+SnI2 Sn-O  Target<br>Sn-I<br>1100      1150      1200     1250      1300 310 0       3200       3300       3400       3500<br>1                            2                            3                            4<br>Wavenumber (cm -1 ) Wavenumber (cm -1 ) Radial distance (Å)<br>Absorption (arb. units)<br>Intensity ()arb. units Absorption ()arb. units<br>-3Å|χ(R)| ( )<br>Transmittance ()arb. units<br><!-- End of picture text -->

Fig. 2 | Interactions between PPD and the BX2 solvates. a Photos of PbI2 (1 M), SnI2 (1 M), and PbI2 + SnI2 (0.5 M + 0.5 M) solutions without and with PPD additive (0.08 M). The solutions were stored (N2; 20‒30 °C) for 12 h after dissolution. Upper row, DMSO solvent; row below, DMF/DMSO (3:1, v/v) solvent. Note the PbI2 needles precipitated in the DMF/DMSO-based PbI2 solution, the concentration of which should be lower than 1 M. b Absorption spectra of the DMSO-based solutions. 

c Absorption spectra of the DMF/DMSO-based solutions. d<sup>1</sup> H NMR spectra of PPD, PbI2 + PPD, SnI2 + PPD, and SnI2 + PbI2 + PPD in DMSO-d6, and magnified spectra at the ranges of 5.5‒6.8 ppm and 7.0‒8.3 ppm. e FTIR spectra of neat DMSO, and DMSO solutions of PPD, PbI2 + PPD, SnI2 + PPD, and SnI2 + PbI2 + PPD. f Fouriertransformed radial distribution function of EXAFS spectra of the control and target perovskite precursors. 

These evolutions demonstrated the occurrence of the crystallization process, and the fluctuations of PL intensity were related to the decomplexation of the intermediate phases<sup>32</sup> . 

Scanning electron microscopy (SEM) images of the control and target films are presented in Fig. 3b. Compared with the control, the target Sn-Pb perovskite film exhibits enlarged crystal grains and more compact surface morphology. The enhanced crystallinity is further confirmed by X-ray diffraction (XRD) measurements (Supplementary Fig. 14). The target film showed diffraction peaks with higher intensity and smaller full width at half-maximum than that of the control. No diffraction signal was observed at the low 2θ range, suggesting the absence of low-dimensional perovskite structures. This reveals that the protonated PPD, which induces 2D perovskite<sup>44</sup> , was absent or in a very 

low content in the perovskite films. PPD has low basicity (conjugate acid pKa 6.3) owing to the resonance effect, thus excluding a proton transfer reaction with the FA cation (pKa 11.5–13). X-ray photoelectron spectrometry (XPS) measurements (Supplementary Fig. 15) also detected no signal of PPD. Therefore, PPD should be effectively removed from the annealed film. 

Time-of-flight secondary ion mass spectrometry (ToF-SIMS) was conducted to detect the composition profile throughout the film depth (Fig. 3c). An evident compositional gradient of Sn and Pb was observed in the control film, with Sn enriched at the upper region of the film (approximately 250 nm depth assuming constant etching speed). This compositional gradient can be understood by the fast crystallization of Sn and the fact that the perovskite film is grown from 

Nature Communications |  (2024) 15:6887 

5 

Article 

https://doi.org/10.1038/s41467-024-51361-2 



<!-- Start of picture text -->
a b<br>500 Control Intensity Control<br>(counts)<br>6000<br>600<br>Antisolvent Annealing started<br>700<br>800<br>900<br>100<br>1000<br>1100<br>0 5 10 15 20 0 10 20 30 40 50 60<br>Time (s) Time (s)<br>500 Target Intensity Target<br>(counts)<br>6000<br>600<br>700<br>800<br>900<br>100<br>1000<br>1100<br>0 5 10 15 20 0 10 20 30 40 50 60<br>Time (s) Time (s)<br>c d<br>Control Target<br>1<br>1.5 1.5<br>0.9<br>Control SnITarget  SnI33-- 1.0 1.0<br>Control PbI2 -<br>0.8 Target  PbI2- 0.5 0.5<br>0 100 200 300 400 0 0.5 1.0 1.5 0 0.5 1.0 1.5<br>Sputtering time (s) q y (Å -1 ) q y (Å -1 )<br>Wavelength (nm)<br>Wavelength (nm)<br> (Å-1) q z  (Å-1) q z<br>Normalized intensity (log)<br><!-- End of picture text -->

Fig. 3 | Crystallization process and film quality. a In-situ PL monitored during spin-coating (after the anti-solvent was applied) and annealing stages of the perovskite films. b Surface SEM images of the control and target perovskite films; the 

scale bar is 2 µm. c Normalized ToF-SIMS depth profiles of the Sn and Pb species in the control and target perovskite films. d GIWAXS patterns of the control and target perovskite films. 

top to bottom<sup>45</sup> . With PPD applied, the target film exhibited a homogenized distribution of the Sn and Pb along the vertical direction. Meanwhile, the surface Sn/Pb molar ratios derived from the XPS results (Supplementary Fig. 16) were 2.5 and 1.4 for the control and target films, respectively. 

To probe this upper region of the perovskite films, synchrotronbased grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements (Fig. 3d) were carried out. With 10 KeV X-rays and a grazingincidence angle of 0.5°, the penetration depth should be somewhere between 100 and 200 nm<sup>46</sup> . The control film exhibited nearly isotropic diffraction rings, whereas the target sample presented a preferred (100) orientation, indicative of a better-controlled growth. Noteworthy, asymmetric peaks were observed in the control sample (Supplementary Fig. 17), where the long tail indicated the presence of Sn-enriched phases. In contrast, the target film presented symmetric 

and narrower diffraction peaks, demonstrating enhanced film homogeneity and crystallinity. 

Ultraviolet photoelectron spectroscopy (UPS, Supplementary Fig. 18) was conducted to probe the surface electronic structure. The Fermi levels of the control and target films were located at 0.50 eV and 0.59 eV, respectively, above the valence band maximum (VBM), suggesting suppressed p-type doping in the target film. Meanwhile, the target film exhibited a deeper VBM (−5.21 eV) than the control (−5.15 eV). This is consistent with the reduced Sn content at the film surface, as Sn-based perovskite has a more dispersive valence band than the Pb-based analog. 

Steady-state PL and time-resolved PL spectra (Supplementary Fig. 19) showed higher emission intensity and elongated carrier lifetimes of the target film compared to the control. Derived from the absorption spectra (Supplementary Fig. 20), the target film featured a 

Nature Communications |  (2024) 15:6887 

6 

Article 

https://doi.org/10.1038/s41467-024-51361-2 



<!-- Start of picture text -->
a b<br>35<br>Cu<br>C60/BCP 30  Control, forwardControl, reverse<br>Target, reverse<br>25  Target, forward<br>Sn-Pb<br>20<br>15 Scan J SC (mA cm -2 ) V OC (mV) FF (%) PCE (%)<br>Pedot:PSS Reverse 32.85 856 79.43 22.33<br>10 Forward 32.53 852 77.12 21.37<br>Reverse 33.55 895 81.59 24.50<br>FTO 5<br>Forward 33.42 894 80.94 24.18<br>0<br>0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9<br>Voltage (V)<br>c d<br>100 35<br>Control<br>1.0<br>30 Target<br>80 Control<br>Target 25 0.9<br>T90= 193 h T90= 795 h<br>60 33.50 mA cm -2 20<br>0.8<br>T90= 438 h<br>32.68 mA cm -2 15<br>40<br>0.7<br>MPP tracking under simulated one-sun illumination<br>10<br>Encapsulated devices operated in air<br>20 5 0.6 20-30 ℃,   RH 30-40%<br>0 0 0.5<br>300 400 500 600 700 800 900 1000 1100 0 200 400 600 800<br>Wavelength (nm) Time (h)<br>-2Current Density (mA cm)<br>EQE (%)<br>Normalized PCE<br>Current density (mA cm)-2<br><!-- End of picture text -->

Fig. 4 | Photovoltaic performances and device stability. a Cross-sectional SEM image of a single-junction Sn-Pb PSC; the scale bar is 1 µm. b J–V curves of the control and target devices, and the corresponding photovoltaic parameters in 

reverse and forward scan. c External quantum efficiency spectra and integrated JSC of the control and target devices. d Continuous maximum power point tracking of the encapsulated devices. 

smaller Urbach tail (47 meV) than the control (64 meV). Moreover, Kelvin probe force microscopy (KPFM) results (Supplementary Fig. 21) revealed suppressed surface potential fluctuation in the target film, attributed to the improved compositional uniformity and reduced grain boundaries. These results demonstrate enhanced optoelectronic quality of the target film. 

### Device performances and stability 

We fabricated single-junction Sn-Pb PSCs with the architecture fluorinedoped tin oxide (FTO)/Poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS)/Sn-Pb perovskite/C60/bathocuproine (BCP)/Cu (Fig. 4a). The highest efficiency achieved by the target device (0.0916 cm<sup>2</sup> ) was 24.18% in forward scan and 24.50% in reverse scan (Fig. 4b), whereas the control device showed a power conversion efficiency (PCE) of 21.37% in forward scan and 22.33% in reverse scan. The target device also demonstrated a stabilized output efficiency of 24.4% (Supplementary Fig. 22). The champion device was measured in an accredited laboratory (Test and Calibration Centre of the New Energy Device and Module, Chinese Academy of Sciences). The certified PCE was 24.13% in the reverse scan and 23.59% in the forward scan (Supplementary Fig. 23). The effect of the PPD concentration was investigated (Supplementary Fig. 24), and the highest average PCE was achieved with 8 mol% (with respect to SnI2) PPD incorporated. Several other agents were also studied (Supplementary Fig. 25), and aniline was also found to deliver a prominent impact on device performance. Moreover, PPD was extended to neat Sn-based perovskites and demonstrated a substantial improvement in the device efficiency (Supplementary Fig. 26). 

External quantum efficiency (EQE) spectra (Fig. 4c) revealed that the JSC increase mainly originated from EQE enhancement at the 

infrared range (750–950 nm). This is attributed to the improved film quality at the upper region (rear part) of the perovskite absorber. Through the inflection point method<sup>47</sup> , bandgaps of the control and target films were determined as 1.259 eV and 1.253 eV, respectively (Supplementary Fig. 27). The sharpened absorption edge and narrowed bandgap revealed reduced band tail states within the target film. 

We monitored the efficiency evolution of 16 unencapsulated target cells during a six-month storage in N2 atmosphere under ambient temperature (following the ISOS-D-1I protocol<sup>48</sup> ; Supplementary Fig. 28). The average PCE of the freshly fabricated devices reached the highest point after six days of storage. The devices retained > 97% of the highest average PCE after six months of storage. Maximum power point tracking (MPPT, Fig. 4d) following the ISOS-L-1I protocol was conducted with the encapsulated devices under simulated one-sun illumination (Xenon lamp simulator, Supplementary Fig. 29) in ambient air. The PCE of the control device declined to 80% after 438 h of aging, whereas the target device retained 90% of its initial PCE after 795 h. This result stands as a remarkable MPPT performance among single-junction Sn-Pb PSCs recently reported (Supplementary Table 2). The stability enhancement is attributed to the suppressed surface Snenrichment and enhanced crystallinity, which could suppress oxidative degradation and moisture intrusion at grain boundaries<sup>49</sup> (Supplementary Fig. 30). 

## Methods 

### Computational methods 

DFT and AIMD simulations of isolated complexes were conducted with the ORCA5.0.3 package<sup>50</sup> . Geometry optimizations were performed at 

Nature Communications |  (2024) 15:6887 

7 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

the M06-2X<sup>51</sup> /Def2-TZVP<sup>52,53</sup> level of theory with D3zero<sup>54</sup> dispersion correction. The single point energies were obtained at the PWPB95<sup>55</sup> - D4<sup>56</sup> /Def2-TZVPP<sup>57</sup> level of theory. AIMD was performed at the ωB97XD3<sup>58</sup> /def2-SVP<sup>52</sup> level of theory. The temperature was maintained at 300 K by the Nosé-Hoover chain<sup>59</sup> thermostat and the time step was set to 1.0 fs. Simulations of the crystalline PbI2 solvates (periodic structures) were conducted by CP2K9.1<sup>60</sup> . Geometry optimization and AIMD were performed using PBE<sup>61</sup> functional with DFT-D3<sup>54</sup> dispersion correction. The Brillouin zone is sampled at the gamma point and the plane wave cutoff energy is 500 Ry. The temperature was maintained at 300 K by the CSVR<sup>62</sup> thermostat and the time step was set to 1.0 fs. SAPT analysis at the SAPT2 level was carried out by PSI4<sup>63</sup> code. The Multiwfn<sup>64</sup> code was used for the ESP and IGMH analysis. Visualization was conducted by Visual Molecular Dynamics (VMD)<sup>65</sup> . 

### Materials 

Dimethylformamide (DMF, anhydrous 99.8%), dimethyl sulfoxide (DMSO, >99.9%), methanol (MeOH, anhydrous 99.8%), ethylene glycol (EG, anhydrous 99.8%), ethyl acetate (EA, anhydrous 99.8%), isopropyl alcohol (IPA, anhydrous 99.5%), cesium carbonate (99.9%), cesium iodide (99.999%, anhydrous), ethylenediammonium diiodide (EDAI2, 99%), rubidium iodide (RbI, 99.9%), SnF2 (99%), aniline (>=99.5%), and p-phenylenediamine (PPD, >=99%) are purchased from Sigma-Aldrich. Toluene (99.5%) is obtained from Sinopharm. PEDOT:PSS (Clevious P VP AI 4083) is obtained from Heraeus. SnI2 (99.99%) is obtained from Advanced Election Technology. Lead iodide (PbI2, 99.99%), phenol (99.5%), and ammonium thiocyanate (NH4SCN, 98%) are purchased from TCI. Formamidinium iodide (FAI) is purchased from Greatcell Solar Materials. C60, indene-C60-bisadduct (ICBA), phenylethylammonium bromide (PEABr), and phenethylammonium chloride (PEACl) are purchased from Xi’an Yuri Solar. Bathocuproine (BCP) is obtained from Wako Chemical. The commercial SnI2 powder was purified via a reported toluene washing method<sup>66</sup> . Other materials were used as received. 

### Precursors preparation 

Sn-Pb perovskite (Rb0.04Cs0.2FA0.76Pb0.5Sn0.5I3): The 2 M precursor was prepared by mixing RbI (0.08 mmol), CsI (0.4 mmol), FAI (1.52 mmol), PbI2 (1 mmol), SnI2 (1 mmol), SnF2 (0.1 mmol), NH4SCN (0.045 mmol), and PEACl (0.008 mmol) into 750 µL of DMF and 250 µL of DMSO. For the target sample, 8 mol% PPD (0.08 mmol) regarding SnI2 was added into the precursor. The precursors were dissolved at 50 °C overnight and filtered through a 0.22-μm PTFE filter before use. 

Sn perovskite (PEA0.15FA0.85SnI2.85Br0.15): The 0.8 M precursor was prepared by dissolving PEABr (0.12 mmol), FAI (0.68 mmol), SnI2 (0.8 mmol), SnF2 (0.06 mmol), NH4SCN (0.04 mmol), and EDAI2 (0.008 mmol) in 800 µL of DMF and 200 µL of DMSO. For the target sample, PPD (0.064 mmol) was added to the precursor. The precursor was dissolved at 50 °C overnight and filtered through a 0.22-μm PTFE filter before use. 

PEDOT:PSS dispersion: The commercial PEDOT:PSS was mixed with cesium carbonate at the ratio of 1 mL: 2 mg, and the mixture was filtered through a 0.45-μm PVDF filter. 

Surface passivating solution: The EDAI2 solution was prepared by mixing EDAI2 (3 mg) with IPA (2 mL) and toluene (2 mL), heated at 50 °C overnight, and filtered through a 0.22-μm PTFE filter before use. 

filled glovebox after annealing. The perovskite precursor was spincoated with a two-step procedure. The first step was at 1000 rpm for 10 s with an acceleration of 200 rpm·s<sup>−1</sup> ; the second step was at 4000 rpm for 50 s with an acceleration of 1000 rpm·s<sup>−1</sup> . Ethyl acetate (350 μL) was dropped 20 s before the end of the spin, and then the substrates were annealed at 100 °C for 10 min. The EDAI2 solution was applied onto the cooled perovskite films and spin-coated at 4000 rpm for 25 s, followed by annealing at 100 °C for 5 min. C60 (20 nm), BCP (7 nm), and Cu (100 nm) in sequentialorder were thermally evaporated in a vacuum chamber ( < 3 × 10<sup>−4</sup> Pa). 

Sn PSCs: FTO substrates cleaning, plasma treatment, and the PEDOT:PSS layer deposition followed the same procedures as the SnPb PSCs. The Sn perovskite precursor was spin-coated with a two-step procedure. The first step was at 1000 rpm for 10 s with an acceleration of 200 rpm·s<sup>−1</sup> , and the second step was at 5000 rpm for 32 s with an acceleration of 1000 rpm·s<sup>−1</sup> . Toluene (600 μL) was dropped 10 s before the end of the spin, and then the substrates were annealed at 80 °C for 10 min. ICBA (5 mg mL<sup>−1</sup> in chlorobenzene) was spin-coated onto the perovskite film at 5000 rpm for 40 s and annealed at 70 °C for 5 min. C60 (18 nm), BCP (7 nm), and Cu (100 nm) in sequential order were thermally evaporated in a vacuum chamber ( < 3 × 10<sup>−4</sup> Pa). 

### Solar cell characterizations 

J–V curves of the perovskite solar cells were measured with a Keithley 2400 source meter under simulated one-sun illumination from a dual light source simulator (WXS-90S-L2, Wacom). The light intensity was calibrated by a mono-Si reference cell (91150-KG5, calibrated by Newport). The spectral mismatch factor was controlled within 0.99‒1 at the wavelength range of 350‒1100 nm. The PCE measurements were conducted in dry air (RH 10‒20%, environment temperature 20‒ 30 °C), and no preconditioning was performed. J–V curves were measured in reverse scan (1.0 V to −0.1 V) and forward scan (−0.1 V to 1.0 V) under a constant scan speed of 100 mV·s<sup>−1</sup> with voltage steps of 10 mV and a delay time of 100 ms. A metal aperture (0.0916 cm<sup>2</sup> ) was used to define the active area of the devices. The stable power output efficiency was recorded by monitoring the output efficiency with the biased voltage set at the maximum power point. External quantum efficiency was obtained using monochromatic incident light of 1 × 10<sup>16</sup> photons cm<sup>−2</sup> in direct current mode (CEP-2000BX, Bunko-Keiki). Antireflecting coating layers (Mosmite, Mitsubishi) were applied for the champion cells during PCE and EQE measurements. 

### Encapsulation and stability test 

For device encapsulation, a polytetrafluoroethylene (PTFE) layer (~10 µm, measured by a profilometer) was deposited on the device (leaving the electrode contact uncovered) through thermal evaporation (Supplementary Fig. 31). Then glass-to-glass sealing using a caved glass cover and epoxy sealing was conducted to complete the encapsulation. For the shelf stability measurement, the unencapsulated devices were stored in the N2-filled glovebox (H2O, <0.01 ppm; O2, <0.01 ppm) in the dark. For maximum power point tracking, the encapsulated device was operated at the VMPP voltage (0.76 V) in ambient air (RH 30‒40%, temperature 20‒30 °C) under simulated onesun illumination (Xenon lamp; SS-X100R, Enlitech). 

### Other characterizations 

### Devices fabrication 

Sn-Pb PSCs: Pre-patterned FTO substrates (AGC, 6‒8 Ω) were cleaned using deionized water, acetone, and IPA under ultrasonication. The dried substrates were treated with Ar/O2 (1:1, v/v) plasma for 5 mins. The PEDOT:PSS dispersion was spin-coated onto the FTO substrates at 6000 rpm for 40 s. After air drying for 20 min, a mixed solvent of MeOH/EG (50:1, v/v) was applied on the deposited PEDOT:PSS and spin-coated at 6000 rpm for 30 s, followed by annealing at 160 °C for 20 min in air. The substrates were immediately transferred to the N2- 

GIWAXS measurements were performed at the BL17B beamline of the Shanghai Synchrotron Radiation Facility (SSRF) using 10 KeV X-rays. The grazing-incidence angle was 0.5° and the exposure time was 20 s. The EXAFS spectra were collected at the BL13SSW beamline in SSRF. The measurements were conducted under transmission mode with a germanium solid-state detector. The X-ray energy was calibrated by the absorption edge of pure Sn/Pb foil. Fourier-transformed radial distribution functions of k<sup>2</sup> -weighted EXAFS spectra were obtained in the k range between 3 and 12.5 Å<sup>−1</sup> through the ATHENA<sup>67</sup> code. 

Nature Communications |  (2024) 15:6887 

8 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

The NMR spectra were measured on an Avance III 400 MHz NMR spectrometer, using DMSO-d6 as the solvent. The FTIR measurements were conducted using the attenuated total reflectance (ATR) method on a Nicolet 6700 spectrophotometer. For sampling, a small drop of the solution was placed onto the ATR crystal. The crystal was wiped clean using DMSO and ethanol after each measurement. In situ PL measurement was conducted with a homebuilt setup in glovebox. A diode laser (405 nm, 50 mW) was introduced onto the sample through an optical fiber, and the emission spectra were collected by a fibercoupled with a USB 2000+ spectrometer (450‒1100 nm, Ocean Optics), calibrated by the local vendor. A 450-nm optical filter is applied between the sample and the fiber detector. ToF-SIMS experiments were performed using a ToF-SIMS 5-100 (ION TOF) instrument. The sputter ion was 20 keV Cs ion and a 400 × 400 µm<sup>2</sup> sputter crater was used. A 30 keV Bi<sup>3+</sup> ion beam with an ion current of 0.45 pA was applied over a 100 × 100 µm<sup>2</sup> area at the center of the sputter crater. 

Absorption spectra were recorded by a UV–Vis–NIR spectrometer (PerkinElmer Lambda 750 S). The solutions were stored in sealed quartz vials during absorption measurement. The SEM images of perovskite films were obtained using a JSM‐7800F instrument. The X-ray diffraction (XRD) was conducted using an X-ray diffractometer (Ultima IV) with Cu Kα radiation at a scan speed of 2° min<sup>−1</sup> . X-ray photoelectron spectroscopy (XPS) measurements were performed on a Kratos AXIS Ultra DLD spectrometer using an Al Ka X-ray source. Au layer (5 Å) was deposited on the sample through thermal evaporation and the spectra were calibrated with Au 4f7/2 binding energy (84.0 eV). Ultraviolet photoelectron spectroscopy (UPS) spectra were measured with a He Iα photon source. The binding energy scale was calibrated using a clean gold film. PL spectra and time-resolved PL spectra were recorded by a fluorescence spectrometer (FLS1000). AFM morphology and KPFM measurements were conducted on the FastScan Bio (Bruker). 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

The source data underlying Fig. 4b–d, Supplementary Fig. 24, and Supplementary Fig. 28 have been deposited in the Figshare repository (https://doi.org/10.6084/m9.figshare.26150392). Atomic coordinates of the DFT-optimized structures and AIMD trajectories are available from Materials Cloud (https://doi.org/10.24435/materialscloud:kv-g1). All other data of this study are available from the corresponding author. Source data are provided in this paper. 

## References 

1. Hao, F., Stoumpos, C. C., Chang, R. P. H. & Kanatzidis, M. G. Anomalous band gap behavior in mixed Sn and Pb perovskites enables broadening of absorption spectrum in solar cells. J. Am. Chem. Soc. 136, 8094–8099 (2014). 

2. Hu, S. et al. Optimized carrier extraction at interfaces for 23.6% efficient tin–lead perovskite solar cells. Energy Environ. Sci. 15, 2096–2107 (2022). 

3. Wang, J. et al. Enhancing photostability of Sn‐Pb perovskite solar cells by an alkylammonium pseudo‐halogen additive. Adv. Energy Mater. 13, 2204115 (2023). 

4. Tong, J. et al. Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. Nat. Energy 7, 642–651 (2022). 

5. Lin, R. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. Nature 620, 994–1000 (2023). 

6. Chen, H. et al. Regulating surface potential maximizes voltage in allperovskite tandems. Nature 613, 676–681 (2023). 

7. He, R. et al. Improving interface quality for 1-cm<sup>2</sup> all-perovskite tandem solar cells. Nature 618, 80–86 (2023). 

8. William, S. & Queisser, H. J. Detailed balance limit of efficiency of p‐ n junction solar cells. J. Appl. Phys. 32, 510–519 (1961). 

9. Green, M. A. et al. Solar cell efficiency tables (Version 63). Prog. Photovolt. Res. Appl. 32, 3–13 (2024). 

10. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(ii) oxidation in precursor ink. Nat. Energy 4, 864–873 (2019). 

11. Halder, A., Yeom, K.-W. & Park, N.-G. Strategies toward suppression of Sn(II) oxidation for stable Sn–Pb perovskite solar cells. ACS Energy Lett. 8, 4267–4277 (2023). 

12. Hao, F. et al. Solvent-mediated crystallization of CH3NH3SnI3 films for heterojunction depleted perovskite solar cells. J. Am. Chem. Soc. 137, 11445–11452 (2015). 

13. Hu, S., Smith, J. A., Snaith, H. J. & Wakamiya, A. Prospects for tincontaining halide perovskite photovoltaics. Precis. Chem. 1, 69–82 (2023). 

14. Gao, H. et al. Homogeneous crystallization and buried interface passivation for perovskite tandem solar modules. Science 383, 855–859 (2024). 

15. Zhang, W. et al. Component distribution regulation in Sn‐Pb perovskite solar cells through selective molecular interaction. Adv. Mater. 35, 2303674 (2023). 

16. Zhou, J. et al. Mixed tin-lead perovskites with balanced crystallization and oxidation barrier for all-perovskite tandem solar cells. Nat. Commun. 15, 2324 (2024). 

17. Pearson, R. G. Hard and soft acids and bases. J. Am. Chem. Soc. 85, 3533 (1963). 

18. Jeon, N. J. et al. Solvent engineering for high-performance inorganic–organic hybrid perovskite solar cells. Nat. Mater. 13, 897–903 (2014). 

19. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. Joule 3, 2179–2192 (2019). 

20. Chen, Y. et al. Impacts of alkaline on the defects property and crystallization kinetics in perovskite solar cells. Nat. Commun. 10, 1112 (2019). 

21. Jeong, J. et al. Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. Nature 592, 381–385 (2021). 

22. Tong, J. et al. Carrier lifetimes of >1 μs in Sn-Pb perovskites enable efficient all-perovskite tandem solar cells. Science 364, 475–479 (2019). 

23. Zhou, S. et al. Aspartate all-in-one doping strategy enables efficient all-perovskite tandems. Nature 624, 69–73 (2023). 

24. Hoffmann, R. A chemical and theoretical way to look at bonding on surfaces. Rev. Mod. Phys. 60, 601–628 (1988). 

25. Fu, Y., Jin, S. & Zhu, X.-Y. Stereochemical expression of ns<sup>2</sup> electron pairs in metal halide perovskites. Nat. Rev. Chem. 5, 838–852 (2021). 

26. Walsh, A., Payne, D. J., Egdell, R. G. & Watson, G. W. Stereochemistry of post-transition metal oxides: revision of the classical lone pair model. Chem. Soc. Rev. 40, 4455–4463 (2011). 

27. Ozaki, M. et al. Solvent-coordinated tin halide complexes as purified precursors for tin-based perovskites. ACS Omega 2, 7016–7021 (2017). 

28. Persson, I., D’Angelo, P. & Lundberg, D. Hydrated and solvated Tin(II) ions in solution and the solid state, and a coordination chemistry overview of the d<sup>10</sup> s<sup>2</sup> metal ions. Chem. A Eur. J. 22, 18583–18592 (2016). 

29. Rahimnejad, S., Kovalenko, A., Forés, S. M., Aranda, C. & Guerrero, A. Coordination chemistry dictates the structural defects in lead halide perovskites. ChemPhysChem. 17, 2795–2798 (2016). 

30. Cao, J. et al. Identifying the molecular structures of intermediates for optimizing the fabrication of high-quality perovskite films. J. Am. Chem. Soc. 138, 9919–9926 (2016). 

Nature Communications |  (2024) 15:6887 

9 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

31. Petrov, A. A. et al. Crystal structure of DMF-intermediate phases uncovers the link between CH3NH3PbI3 morphology and precursor. Stoichiom. J. Phys. Chem. C. 121, 20739–20743 (2017). 

32. Li, F. et al. Hydrogen-bond-bridged intermediate for perovskite solar cells with enhanced efficiency and stability. Nat. Photon. 17, 478–484 (2023). 

33. Ruiz-Preciado, M. A. et al. Supramolecular modulation of hybrid perovskite solar cells via bifunctional halogen bonding revealed by two-dimensional<sup>19</sup> F solid-state NMR spectroscopy. J. Am. Chem. Soc. 142, 1645–1654 (2020). 

34. Huang, Z. et al. Anion–π interactions suppress phase impurities in FAPbI3 solar cells. Nature 623, 531–537 (2023). 

35. Tang, Z. et al. Regulating the crystallization dynamics through hydrogen bonding for high efficiency tin halide perovskite solar cells. Chem. Commun. 59, 9477–9480 (2023). 

36. Hu, S. et al. Synergistic surface modification of tin–lead perovskite solar cells. Adv. Mater. 35, 2208320 (2022). 

37. Lee, S. J. et al. Fabrication of efficient formamidinium tin iodide perovskite solar cells through SnF2–pyrazine complex. J. Am. Chem. Soc. 138, 3974–3977 (2016). 

38. Gao, C. et al. Improving hybrid tin halide layers by melt assisted annealing for lead‐free perovskite solar cells. Adv. Mater. Technol. 9, 2302029 (2024). 

39. Ban, H. et al. Fully inorganic CsSnI3 mesoporous perovskite solar cells with high efficiency and stability via coadditive engineering. Sol. RRL 5, 2100069 (2021). 

40. Jeziorski, B., Moszynski, R. & Szalewicz, K. Perturbation-theory approach to intermolecular potential-energy surfaces of van-derwaals complexes. Chem. Rev. 94, 1887–1930 (1994). 

41. Lu, T. & Chen, Q. Independent gradient model based on Hirshfeld partition: a new method for visual study of interactions in chemical systems. J. Comput. Chem. 43, 539–555 (2022). 

42. Mahadevi, A. S. & Sastry, G. N. Cation−π interaction: its role and relevance in chemistry, biology, and material science. Chem. Rev. 113, 2100–2138 (2013). 

43. Kerner, R. A. et al. Amine additive reactions induced by the soft Lewis acidity of Pb<sup>2+</sup> in halide perovskites. Part I: evidence for Pb–alkylamide formation. J. Mater. Chem. C. 7, 5251–5259 (2019). 

44. Yao, H. et al. Structural tailoring the phenylenediamine isomers to obtain 2D Dion–Jacobson tin perovskite solar cells with record efficiency. Adv. Funct. Mater. 34, 2312287 (2023). 

45. Chen, S. S. et al. Crystallization in one-step solution deposition of perovskite films: Upward or downward? Sci. Adv. 7, 8 (2021). 

46. Steele, J. A. et al. How to GIWAXS: grazing incidence wide angle X-ray scattering applied to metal halide perovskite thin films. Adv. Energy Mater. 13, 2300760 (2023). 

47. Krückemeier, L., Rau, U., Stolterfoht, M. & Kirchartz, T. How to report record open‐circuit voltages in lead‐halide perovskite solar cells. Adv. Energy. Mater. 10, 1902573 (2020). 

48. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49 (2020). 

49. Prasanna, R. et al. Design of low bandgap tin–lead halide perovskite solar cells to achieve thermal, atmospheric and operational stability. Nat. Energy 4, 939–947 (2019). 

50. Neese, F., Wennmohs, F., Becker, U. & Riplinger, C. The ORCA quantum chemistry program package. J. Chem. Phys. 152, 224108 (2020). 

51. Zhao, Y. & Truhlar, D. G. The M06 suite of density functionals for main group thermochemistry, thermochemical kinetics, noncovalent interactions, excited states, and transition elements: two new functionals and systematic testing of four M06-class functionals and 12 other function. Theor. Chem. Acc. 120, 215–241 (2008). 

52. Weigend, F. & Ahlrichs, R. Balanced basis sets of split valence, triple zeta valence and quadruple zeta valence quality for H to Rn: design and assessment of accuracy. Phys. Chem. Chem. Phys. 7, 3297 (2005). 

53. Weigend, F. Accurate Coulomb-fitting basis sets for H to Rn. Phys. Chem. Chem. Phys. 8, 1057 (2006). 

54. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104 (2010). 

55. Goerigk, L. & Grimme, S. Efficient and accurate double-hybridmeta-GGA density functionals-evaluation with the extended GMTKN30 database for general main group thermochemistry, kinetics, and noncovalent interactions. J. Chem. Theory Comput. 7, 291–309 (2011). 

56. Caldeweyher, E. et al. A generally applicable atomic-charge dependent London dispersion correction. J. Chem. Phys. 150, 154122 (2019). 

57. Chmela, J. & Harding, M. E. Optimized auxiliary basis sets for density fitted post-Hartree–Fock calculations of lanthanide containing molecules. Mol. Phys. 116, 1523–1538 (2018). 

58. Chai, J.-D. & Head-Gordon, M. Long-range corrected hybrid density functionals with damped atom–atom dispersion corrections. Phys. Chem. Chem. Phys. 10, 6615 (2008). 

59. Martyna, G. J., Klein, M. L. & Tuckerman, M. Nosé–Hoover chains: the canonical ensemble via continuous dynamics. J. Chem. Phys. 97, 2635–2643 (1992). 

60. Kühne, T. D. et al. CP2K: an electronic structure and molecular dynamics software package-quickstep: efficient and accurate electronic structure calculations. J. Chem. Phys. 152, 194103 (2020). 

61. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865–3868 (1996). 

62. Bussi, G., Donadio, D. & Parrinello, M. Canonical sampling through velocity rescaling. J. Chem. Phys. 126, 014101 (2007). 

63. Parrish, R. M. et al. PSI4 1.1: an open-source electronic structure program emphasizing automation, advanced libraries, and interoperability. J. Chem. Theory Comput. 13, 3185–3197 (2017). 

64. Lu, T. & Chen, F. Multiwfn: a multifunctional wavefunction analyzer. J. Comput. Chem. 33, 580–592 (2012). 

65. Humphrey, W., Dalke, A. & Schulten, K. VMD: visual molecular dynamics. J. Mol. Graph. 14, 33–38 (1996). 

66. Zeng, G. et al. Enhancing the performance of tin-based perovskite solar cells through solvent purification of tin iodide. J. Mater. Chem. A 11, 11245–11253 (2023). 

67. Ravel, B. & Newville, M. ATHENA, ARTEMIS, HEPHAESTUS: data analysis for X-ray absorption spectroscopy using IFEFFIT. J. Synchrotron Radiat. 12, 537–541 (2005). 

## Acknowledgements 

This work is funded by the Natural Science Foundation of Shanghai (20ZR1424900, H.C.), the National Ten Thousand Talent Program (H.C.), and the National Natural Science Foundation of China (grant no. 51902198, H.C.). The authors thank Limin Sun, Xue Ding, Nannan Zhang, Jiaxin Ding, Ruibin Wang, Mei Gao, Zhongqiu Bao, Bangshang Zhu, Linlin Ma, and other staff of the Instrumental Analysis Center of Shanghai Jiao Tong University for their help with the characterizations. The authors thank the staff of the beamlines BL13SSW and BL17B at SSRF for experiment support. 

## Author contributions 

H.C. designed and directed the study. Y.Z. and C.L. developed the solar cells. Y.Z. conducted the numerical simulations and drafted the manuscript. C.L. conducted the solar cell measurements and the stability test. 

Nature Communications |  (2024) 15:6887 

10 

Article 

https://doi.org/10.1038/s41467-024-51361-2 

Z.C. and Jianrong Z. contributed to the GIWAXS and EXAFS measurements. H.Z., Z.Y., X.T., and Jixiang Z. provided aid in the lab and contributed to the characterizations. P.Z. and L.H. contributed to the data analysis. All authors revised the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-024-51361-2. 

Correspondence and requests for materials should be addressed to Han Chen. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2024, corrected publication 2024 

Reprints and permissions information is available at 

http://www.nature.com/reprints 

Nature Communications |  (2024) 15:6887 

11 

