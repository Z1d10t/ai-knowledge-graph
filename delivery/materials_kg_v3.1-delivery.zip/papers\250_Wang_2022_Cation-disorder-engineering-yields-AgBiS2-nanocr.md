# Cation disorder engineering yields AgBiS2 nanocrystals with enhanced optical absorption for efficient ultrathin solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Photonics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 230 |
| 作者 | Yongjie Wang, Seán R. Kavanagh, Ignasi Burgués-Ceballos, Aron Walsh, D. Scanlon, G. Konstantatos |
| DOI | 10.1038/s41566-021-00950-4 |
| 源文件 | 050_Wang_2022_Cation-disorder-engineering-yields-AgBiS2-nanocr.pdf |

---
Articles 

**https://doi.org/10.1038/s41566-021-00950-4** 





# **Cation disorder engineering yields AgBiS2 nanocrystals with enhanced optical absorption for efficient ultrathin solar cells** 

**Yongjie Wang**<sup>**1,6**</sup> **, Seán R. Kavanagh**<sup>**2,3,6**</sup> **, Ignasi Burgués-Ceballos**<sup>**1**</sup> **, Aron Walsh**<sup>**3,4**</sup> **, David O. Scanlon**<sup>**2**</sup> **and Gerasimos Konstantatos**<sup>**1,5**✉</sup> 

**Strong optical absorption by a semiconductor is a highly desirable property for many optoelectronic and photovoltaic applications. The optimal thickness of a semiconductor absorber is primarily determined by its absorption coefficient. To date, this parameter has been considered as a fundamental material property, and efforts to realize thinner photovoltaics have relied on light-trapping structures that add complexity and cost. Here we demonstrate that engineering cation disorder in a ternary chalcogenide semiconductor leads to considerable absorption increase due to enhancement of the optical transition matrix elements. We show that cation-disorder-engineered AgBiS2 colloidal nanocrystals offer an absorption coefficient that is higher than other photovoltaic materials, enabling highly efficient extremely thin absorber photovoltaic devices. We report solution-processed, environmentally friendly, 30-nm-thick solar cells with short-circuit current density of 27 mA cm**<sup>**−2**</sup> **, a power conversion efficiency of 9.17% (8.85% certified) and high stability under ambient conditions.** 

igh-performance, lightweight solar cells featuring low cost and environmental friendliness have been a long-sought Htarget in the photovoltaic field. Ultrathin solar cells can reduce material consumption and manufacturing demands, directly lowering the cost. Owing to an absorber thickness that is orders of magnitude lower than conventional solar cells, ultrathin solar cells further allow for flexible and lightweight form factors suited for building- or wearable-integrated photovoltaics. A thinner absorber layer also improves charge carrier collection and reduces bulk recombination, which are particularly prevalent in nanocrystalline solution-processed semiconductors<sup>1,2</sup> , thus improving performance and providing strong light absorption. Furthermore, high absorption in small absorber volumes allows for operating the device at high photogenerated carrier densities, a physical regime that maximizes the open-circuit voltage ( _V_ oc) and permits advanced high-efficiency concepts such as hot carrier solar cells<sup>3</sup> . 

Currently, high-performance ultrathin solar cells are mainly realized via different light-trapping strategies, which are employed to compensate for the short-circuit current drop due to incomplete absorption in the ultrathin absorbing layer<sup>4,5</sup> . The use of optical architectures, however, increases non-radiative recombination<sup>4,6</sup> and complicates the manufacturing process, introducing additional obstacles towards low-cost high-efficiency devices. 

Typically, the absorption coefficient of a material determines the required thickness for optimal light harvesting under photovoltaic operation. The absorption coefficient of a semiconductor has been considered as a fundamental parameter of the material, with efforts to enhance light absorption in ultrathin absorbers relying on optical means<sup>4,5</sup> . We instead took the view—motivated by the fundamental relationship between atomic geometry, electronic structure and optical absorption—that the absorption coefficient 

of a semiconductor can be tuned by engineering the atomistic material structure. 

Cation disorder is a widely observed phenomenon in multinary materials, referring to the deviation of atomic positions in the cationic sublattice from an ordered crystalline arrangement. This phenomenon substantially impacts the optoelectronic properties of semiconductors<sup>7–9</sup> and has traditionally been considered an undesirable (and often unavoidable) effect, due to its entropically driven nature<sup>7,8,10,11</sup> . Here we leverage the modulation of cation disorder homogeneity in multinary semiconductors as a pathway to enhance the optical transition matrix elements such that improved absorption coefficient and photovoltaic device efficiency can be achieved. 

#### **Cation disorder homogeneity and absorption behaviour** 

In this work, we focus on ternary AgBiS2 nanocrystals (NCs), a solution-processed nanomaterial comprising environmentally friendly elements<sup>12,13</sup> with reported efficiencies exceeding 6% in thin-film solar cells<sup>1,14</sup> . The cation distribution around Ag sites in AgBiS2 NCs has shown evidence for non-random Ag–Ag correlation<sup>15</sup> , indicating the presence of inhomogeneous cation disorder (that is, cation segregation with local Ag-rich and Bi-rich regions), likely due to growth kinetics during synthesis and surface–ligand interactions<sup>16–18</sup> . 

An illustration of inhomogeneous cation disorder within AgBiS2 NCs is shown in Fig. 1a. The valence band maximum (VBM) of AgBiS2 primarily derives from Ag _d_ and S _p_ states, whereas the conduction band minimum (CBM) arises from Bi _p_ and S _p_ interactions<sup>19,20</sup> (Fig. 1b and Supplementary Fig. 1). A clear spatial separation of the Ag-derived VBM and Bi-derived CBM for the cation-segregated configuration can be observed in the local electronic density of states (Fig. 1c). In contrast, under homogeneous 

> 1ICFO—Institut de Ciencies Fotoniques, The Barcelona Institute of Science and Technology, Castelldefels, Barcelona, Spain. 2Thomas Young Centre and Department of Chemistry, University College London, London, UK.<sup>3</sup> Thomas Young Centre and Department of Materials, Imperial College London, London, UK.<sup>4</sup> Department of Materials Science and Engineering, Yonsei University, Seoul, Republic of Korea.<sup>5</sup> ICREA—Institució Catalana de Recerca i Estudia Avançats, Barcelona, Spain.<sup>6</sup> These authors contributed equally: Yongjie Wang, Seán R. Kavanagh.<sup>✉</sup> e-mail: Gerasimos.Konstantatos@icfo.eu 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**235** 

<mark>Articles</mark> 

**Nature PhotoNics** 



<!-- Start of picture text -->
a b<br>Ag  d<br>Bi  p<br>S  p<br>Ag<br>Bi<br>S<br>Cation segregation Homogeneous cation disorder –3 –2 –1 0 1 2 3 4<br>Energy (eV)<br>c d e<br>1<br>Cation segregation<br>2 2<br>1 1 Ag<br>1 1 Bi<br>Overlap<br>0<br>0 0 Position along axis (Å)<br>1<br>Homogeneous<br>–1 –1<br>0 0<br>–2 –2<br>0<br>0 2 4 6 8 10 12 0 2 4 6 8 10 12 0 2 4 6 8 10 12<br>Position along axis (Å) Position along axis (Å) Position along axis (Å)<br>Density of states (a.u.)<br>Normalized KDEs (a.u.)<br>Energy (eV) Energy (eV)<br>Normalized KDEs (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Absorption enhancement via cation disorder homogenization. a** , Schematic of AgBiS2 NCs with cation segregation and homogeneous cation disorder. **b** , Electronic density of states of homogeneous disordered AgBiS2. The VBM is set to 0 eV. **c** , Planar-averaged local electronic density of states for cation-segregated AgBiS2. The colour bar indicates normalized ~~√~~ DOS. **d** , Planar-averaged local electronic density of states for homogeneous cation-disordered AgBiS2. The colour bar indicates normalized ~~√~~ DOS. **e** , Normalized kernel density estimates (KDEs) of Ag and Bi for cation segregation and homogeneous cation-disordered AgBiS2. The shadow area shows the overlap of Ag and Bi KDEs. 

cation disorder, we predict a VBM and CBM delocalized over the entire material (Fig. 1d), with the correlation between cation distribution and spatial (de)localization of the band extrema (Fig. 1e). 

The theoretically simulated absorption spectra of AgBiS2 for both inhomogeneous and homogeneous cation disorders are provided in Fig. 2a. As expected, we find a substantially increased refractive index _n_ and transition dipole matrix element (Supplementary Fig. 2) and therefore enhanced optical absorption on homogenizing disorder. 

To experimentally tune the cationic disorder, we first assessed the thermodynamics of atomic reordering, particularly the formation energy difference needed to induce disorder. Density functional theory (DFT) was employed to calculate the inter-site cation exchange energy. Under the highest level of theory employed for phase energetics (hybrid DFT including spin–orbit-coupling effects), the bulk order–disorder enthalpy difference is calculated as 17.4 meV per atom, indicating the accessibility of cation site swapping in AgBiS2 under mild annealing conditions. The mechanism behind cation inter-site exchange probably is defect-mediated ionic migration. Indeed, cation mobility aided by Ag vacancies and bond anharmonicity has been demonstrated in AgBiS2 NCs<sup>21–23</sup> . Considering the low inter-site cation exchange energy in AgBiS2, we sought to anneal AgBiS2 NCs under low-temperature conditions to facilitate cation inter-site exchange and thus an entropically driven transition to homogeneous cation distribution. Figure 2b plots the absorption coefficient of our NC films on annealing under different temperatures. Comparing Fig. 2a and b, the simulated absorption spectrum for cation segregation configurations (inhomogeneous disorder) matches well with the as-prepared AgBiS2 NC film, both exhibiting Urbach band tailing at longer wavelengths, which is 

pernicious for photovoltaic devices<sup>24,25</sup> . However, in the homogeneous cation-disordered structure, the simulated absorption coefficient is much higher than the cation-segregated case, with reduced band tailing, manifesting favourable properties for optoelectronic applications<sup>26</sup> . As shown in Fig. 2b, the absorption coefficient of AgBiS2 NC films is enhanced by up to a factor of two after annealing, alongside reduced Urbach energy from 173 to 26 meV (Supplementary Fig. 3), as predicted by ab initio calculations. Furthermore, this enhanced absorption is stable in the ambient atmosphere, as spontaneous cation segregation is thermodynamically and entropically unfavourable (Supplementary Fig. 4). With this low-energy, scalable annealing process, we produce a semiconducting material that exhibits an absorption coefficient 5–10 times greater than any other material currently used in photovoltaic technology<sup>4,27–31</sup> , across a wide spectral range from 400 to 1,000 nm (Fig. 2c). 

With the high absorption coefficient of our films, an ultrathin layer of AgBiS2 NCs would be sufficient to absorb most of the light in the visible range. To assess the potential of our strongly absorbing NC films, we calculate the maximum achievable short-circuit current density _J_ sc using the transfer matrix method (TMM)<sup>32,33</sup> , assuming 100% internal quantum efficiency (IQE) (Supplementary Fig. 5). Figure 2d plots the maximum _J_ sc as a function of the active layer thickness for different annealing temperatures, corresponding to varying degrees of cation disorder homogeneity. On increasing the annealing temperature, we witness an increase in _J_ sc at low active layer thicknesses ( _t_ < 200 nm). We predict a maximum _J_ sc of ~28 mA cm<sup>−2</sup> (32 mA cm<sup>−2</sup> ) for AgBiS2 NC films annealed at 115 °C (150 °C), with a thickness of only ~30 nm. Furthermore, the spectroscopic limited maximum efficiency (SLME) was calculated assuming only radiative recombination in the devices<sup>34</sup> . As shown in 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**236** 

**Nature PhotoNics** 

## <mark>Articles</mark> 



<!-- Start of picture text -->
a b c<br>8 8 10 7<br>Theory Experiment CdTe Perovskite<br>CZTSe CIGS<br>6 Cation segregation averageHomogeneous cation disorder average 6 150 °C 10 6 GaAsInP SbPbS2Se3<br>115 °C AgBiS2 (150 °C)<br>80 °C<br>As prepared 10 5<br>4 4<br>10 4<br>2 2<br>10 3<br>0 0<br>400 600 800 1,000 1,200 1,400 400 600 800 1,000 1,200 1,400 400 600 800 1,000 1,200 1,400<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>d e<br>40 30<br>35<br>25<br>30<br>20<br>25<br>20 15<br>15 150 °C 150 °C<br>10<br>115 °C 115 °C<br>10<br>80 °C 80 °C<br>5<br>5 As prepared As prepared<br>0 0<br>0 100 200 300 400 0 100 200 300 400<br>Absorber thickness (nm) Absorber thickness (nm)<br>–1Absorption coefficient (cm)<br>–15Absorption coefficient (10) cm –15Absorption coefficient (10) cm<br>SLME (%)<br>–2 (mA cm)Predicted  J sc<br><!-- End of picture text -->

**Fig. 2 | Absorption coefficients and optical modelling. a** , Simulated absorption coefficients of AgBiS2 with different cation distributions. The data are presented as mean values ± standard deviation. **b** , Absorption coefficients of AgBiS2 NCs annealed at different temperatures. **c** , Absorption coefficient of AgBiS2 NC films compared with other photovoltaic materials (CdTe (ref.<sup>27</sup> ), CZTSe (ref.<sup>28</sup> ), GaAs (ref.<sup>4</sup> ), InP (ref.<sup>29</sup> ), perovskite<sup>30</sup> , copper indium gallium selenide (CIGS)<sup>4</sup> , PbS and Sb2Se3 (ref.<sup>31</sup> )). **d** , Predicted short-circuit current density ( _J_ sc) of AgBiS2 NCs using the TMM. **e** , The SLME of AgBiS2 NCs as a function of film thickness. 

Fig. 2e, a high photovoltaic efficiency up to 26% was predicted for a 30 nm absorber layer, indicating the performance potential of ultrathin solar cells based on AgBiS2 NC films. Furthermore, with the thickness reduction of the AgBiS2 absorber from 500 nm (common photovoltaic thickness) to 30 nm, we estimate ~50% cost reduction over the full photovoltaic device cost (Supplementary Fig. 6 and Supplementary Note). 

#### **Cation configuration transition** 

To further verify the proposed cation homogenization as the underlying mechanism responsible for the optical absorption enhancement in AgBiS2 NC films, film thicknesses were first measured to exclude NC densification as the dominant factor. Negligible thickness changes were observed between the as-prepared and the samples annealed at 115 °C (Supplementary Fig. 7), with only a slight decrease for the films annealed at 150 °C, contributing to a very small (~8%) absorption enhancement for this sample. These film thickness measurements demonstrate that the densification effect is not the dominant factor in the absorption enhancement of these materials. Furthermore, we used X-ray diffraction (XRD) and transmission electron microscopy (TEM) to probe the changes in the crystal structure due to cation disorder homogenization on annealing. Interestingly, although XRD analysis suggested increased crystallite size (from 4.2 to 6.2 nm) on annealing at 115 °C, high-resolution transmission electron microscopy (HRTEM) showed no measurable size differences in these samples (Supplementary Fig. 8). 

The sharpening of the XRD peaks despite negligible NC growth indicates improved crystallinity due to atomic rearrangements within the NCs. Further increasing the annealing temperature to 150 and 200 °C causes the NCs to fuse into larger crystals (28 and 47 nm, respectively; Supplementary Fig. 8). Point defects are observable in the HRTEM data after high-temperature annealing, which could be harmful for optoelectronic applications<sup>35</sup> (Supplementary Fig. 9). In addition to peak narrowing in the XRD patterns, the peak positions were also found to shift to higher angles on annealing (Fig. 3a). To deconvolute the effect of crystal size and cation arrangement, as well as explain the apparent changes in crystallinity, we calculated the expected XRD patterns for homogeneously disordered cubic AgBiS2 (space group Fm<sup>¯</sup> 3m; Supplementary Fig. 10), with crystal size as the only variable parameter (Supplementary Fig. 11). The full-width at half-maximum of all the peaks sharpens with crystal growth, whereas the peak positions remain essentially the same, as expected. However, when transitioning from cation-segregated configurations to homogeneous cation disorder, as well as fixing the crystallite size, the simulated XRD patterns of AgBiS2 show distinct peak shifts to higher angles and peak narrowing (Fig. 3b), matching the experimental observations of improved crystallinity on annealing. These XRD peak shifts primarily originate from the shortening of the Ag–S bond lengths, whereas peak narrowing occurs due to narrowing of the bond length distributions and reduction in octahedral distortion on homogenization of the cation distribution (Supplementary Fig. 12). This phenomenon was further confirmed 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**237** 

<mark>Articles</mark> 

**Nature PhotoNics** 



<!-- Start of picture text -->
a b c<br>Experiment Theory As prepared<br>Homogeneous<br>200 °C<br>150 °C<br>After annealing<br>115 °C<br>As prepared<br>Clustered<br>25 27 29 31 33 42 44 46 48 50 25 27 29 31 33 42 44 46 48 50<br>2Theta 2Theta<br>e f g d<br>Cation segregation Theory As prepared Experiment<br>Homogeneous cation disorder 115 °C 0.3<br>1<br>1 150 °C 0.3 eV<br>0.2<br>As prepared<br>After annealing<br>0.1<br>0 0 0<br>22 24 26 28 30 22 24 26 28 30 115 150 0 0.5 1.0 1.5 2.0 2.5 3.0<br>Binding energy (eV) Binding energy (eV) Annealing Position (nm)<br>temperature (°C)<br>Intensity (a.u.) Intensity (a.u.) Peak shift (eV)<br><!-- End of picture text -->

**Fig. 3 | Characterization of cation configuration transition. a** , Experimental XRD patterns of AgBiS2 NCs annealed at different temperatures. **b** , Simulated XRD of 10 nm AgBiS2 NCs with varying cation distribution homogeneities, from cation segregation to homogeneous cation disorder. **c** , hRTEM images of AgBiS2 NCs before and after annealing at 200 °C. Scale bar, 2 nm. This experiment was independently repeated twice and similar results were observed. **d** , Integrated line profiles of the {200} crystal plane indicated by the dashed lines in **c** . **e** , Simulated valence-band XPS spectra of AgBiS2 with different cation configurations. **f** , Experimental XPS spectra of AgBiS2 NCs annealed at different temperatures. The dashed lines indicate the peak positions before and after annealing. **g** , Statistics of XPS peak shifts from three different batches of samples. The data are presented as mean values ± standard deviation. 

with HRTEM measurements (Fig. 3c,d), with integrated line profiles of the {200} plane showing a slight shrinkage after annealing, further confirming the transition from cation segregation to homogeneous disorder. 

Considering the difference in local bonding environments for different cation configurations, changes in the Madelung potential were expected<sup>36</sup> . We calculate the average Madelung potential at the Bi sites as 3.29 and 4.66 V for segregated and homogeneous cation configurations, respectively, using Bader atomic charges. A greater Madelung potential suggests a decrease in the X-ray photoelectron (XPS) binding energy, on transitioning from inhomogeneous to homogeneous cation disorder<sup>36,37</sup> . As shown in Fig. 3e, the Bi 5 _d_ peaks in the simulated XPS spectra are noticeably shifted to lower binding energies for homogeneous cation disorder, compared with cation-segregated configurations. Likewise, the annealed AgBiS2 NCs show a small but notable chemical shift to a lower energy, compared with the as-prepared samples (Fig. 3f,g), in agreement with our proposition of cation homogenization on annealing. 

#### **ultrathin AgBiS2 NC solar cells** 

Having developed a material with such strong optical absorption, we next sought to produce highly efficient ultrathin solution-processed solar cells with these NCs. The solar cells were fabricated with an architecture of glass/indium tin oxide (ITO)/SnO2/AgBiS2/ hole transport layer (HTL)/MoO3/Ag (Fig. 4a). Cross-sectional TEM confirms the ultrathin nature of the device layers (Fig. 4b). We first used poly[[4,8-bis[(2-ethylhexyl)oxy]benzo[1,2-b:4,5-b’] 

dithiophene-2,6-diyl][3-fluoro-2-[(2-ethylhexyl) carbonyl]thieno [3,4-b]thiophenediyl]] (PTB7) as an electron-blocking layer, in accordance with previous studies<sup>1,14</sup> . The devices showed an average power conversion efficiency (PCE) of 6.4 ± 0.6%, with a champion device reaching a PCE of 7.6% (Table 1)—higher than the previously reported record performance of 6.3% (refs.<sup>1,14,38–40</sup> ). Atomic force microscopy (AFM) revealed a surface roughness of 0.6 nm for a 4 nm PTB7 film (Supplementary Fig. 13), which undermines the performance of the cells by introducing interface recombination<sup>41</sup> . We sought to replace PTB7 with an alternative electron-blocking layer with improved morphological characteristics. We found that poly(triaryl amine) (PTAA) yielded improved uniformity (root-mean-square roughness of 0.4 nm), a prerequisite for suppressing current leakage and interface recombination. To further assess the superiority of PTAA, transient photocurrent and transient photovoltage were measured under a bias of one sun light (Supplementary Fig. 14). Devices with PTAA showed a faster photocurrent decay and longer carrier lifetime than that with PTB7 as the HTL, which indicates improved charge extraction and reduced interface recombination. As a result, replacing PTB7 with PTAA leads to substantial improvement in _V_ oc and fill factor (FF) (Supplementary Fig. 13) and results in an ~20% increase in PCE to 8.7 ± 0.3%, with the best device reaching 9.17% (Fig. 4c,d). One of our champion devices was sent to an accredited photovoltaic calibration laboratory (Newport, USA), which certified the PCE of 8.85% under AM1.5G full-sun illumination, with negligible hysteresis (Fig. 4e and Supplementary Fig. 15). The measured _J_ sc of 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**238** 

**Nature PhotoNics** 

## <mark>Articles</mark> 



<!-- Start of picture text -->
a b c<br>20<br>SnO2/ABS-MPA/PTAA<br>Ag<br>SnO2/ABS-MPA/PTB7<br>Ag MoO3 (3 nm) 15<br>MoO3 PTAA (4 nm)<br>AgBiS2 (30 nm) 10<br>SnO2 (15 nm) 5<br>20 nm ITO<br>0<br>5 6 7 8 9 10<br>Efficiency,  η  (%)<br>d e f<br>30 30 100<br>25 25<br>Reverse scan Reverse scan 80<br>Forward scan Forward scan<br>20 20<br>60<br>15 V oc = 0.495 V 15 V oc = 0.482 V<br>J sc = 27.1 mA cm –2 J sc = 26.8 mA cm –2 40<br>10 FF = 0.684 10 FF = 0.685<br>η  = 9.17% η  = 8.85%<br>5 5 20 annealingBefore  After annealing<br>Measured EQE<br>Predicted EQE<br>0 0 0<br>–0.5 –0.4 –0.3 –0.2 –0.1 0 –0.5 –0.4 –0.3 –0.2 –0.1 0 400 600 800 1,000<br>V  (V) V  (V) Wavelength (nm)<br>g<br>10<br>8<br>6<br>4<br>ABS-MPA/PTAA<br>ABS-MPA/PTB7<br>2<br>0<br>0 1 2 3 4 5 6 7 8 9 10<br>Elapsed time (h)<br>PTAA<br>AgBiS2 NCs<br>SnO2<br>Glass/ITO<br>Counts<br>EQE (%)<br>–2(mA cm) J  –2(mA cm) J<br>MPP efficiency (%)<br><!-- End of picture text -->

**Fig. 4 | ultrathin AgBiS2 NC solar cells. a** , Schematic of the AgBiS2 (ABS) NC solar cells. **b** , Cross-sectional TEM image of the device. This experiment was independently repeated on two different devices and similar results were observed. **c** , Statistical histogram of AgBiS2 NC solar cells with PTB7 and PTAA as the hTL. **d** , _J_ – _V_ curves of the champion device with PTAA as the hTL. **e** , _J_ – _V_ curves of AgBiS2 NC solar cells certified at Newport, USA. **f** , Measured and predicted EQE curves of devices before and after annealing. **g** , MPP test of AgBiS2 devices with PTB7 and PTAA as the hTL. 

|**Table 1 | Photovoltaic pa**|**rameters of devices based on**|**different htLs**|||
|---|---|---|---|---|
||**_V_oc (V)**|**_J_sc (mA cm**<sup>−</sup><sup>**2**</sup>**)**|**Fill factor**|**PCe (%)**|
|AgBiS2NCs/PTB7|0.437±0.011|25.59±0.81|0.57±0.03|6.42±0.55|
|Champion device|0.450|26.75|0.63|7.63|
|AgBiS2NCs/PTAA|0.489±0.005|26.99±0.76|0.66±0.02|8.70±0.31|
|Champion device|0.495|27.11|0.68|9.17|
|Certified|0.482|26.8|0.68|8.85|
|Note: statistics are based on 31 differ|ent devices.||||



27 mA cm<sup>−2</sup> was further confirmed by the external quantum efficiency (EQE) spectrum, which gives a value of 26.5 mA cm<sup>−2</sup> (Fig. 4f). In addition, the measured EQE spectrum matched well 

with the TMM-predicted EQE, indicating a near-unity IQE. However, unannealed devices showed not only lower absorption (that is, the predicted EQE) in the near-infrared region but also a 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**239** 

<mark>Articles</mark> 

**Nature PhotoNics** 

lower IQE (Fig. 4f) and larger _V_ oc deficit, which is ascribed to slower charge extraction, Urbach band tailing and higher trap density (Supplementary Fig. 16). Higher-temperature annealing leads to remarkably lower performance, which is consistent with the defects forming from uncontrolled NC fusing (Supplementary Figs. 8 and 17). Analysing the absorption loss of our record-performance ultrathin devices, a large part of the incident light (~10 mA cm<sup>−2</sup> ) was reflected (Supplementary Fig. 18) and further improvement in device performance is expected by introducing an antireflection layer or advanced light-trapping techniques. 

On the other hand, thicker (200 nm) devices are also fabricated for direct comparison with ultrathin devices: as expected, a low _J_ sc (~15 mA cm<sup>−2</sup> ) was obtained (Supplementary Fig. 19). To further understand the devices, time-of-flight data were employed to investigate the charge carrier mobilities in our AgBiS2 NC films (Supplementary Fig. 20). The hole and electron mobilities are calculated to be 1.2 × 10<sup>−4</sup> and 5.7 × 10<sup>−5</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively. Combining with the carrier lifetime extracted from transient photovoltage measurements, the diffusion length is estimated to be ~25.4 nm, which rationalizes the near-unity IQE in our 30 nm devices and the low performance in 200-nm-thick devices. Mid-gap trap density was estimated from the transient photocurrent/transient photovoltage measurements (Supplementary Fig. 16). In our optimal AgBiS2 NC films, the trap density is ~9 × 10<sup>16</sup> cm<sup>−3</sup> . Although this trap density is four times lower than that before annealing (~4 × 10<sup>17</sup> cm<sup>−3</sup> ), efforts are needed to further passivate the trap states for higher _V_ oc and thus higher efficiency. 

In addition to PCE, stability is another important figure of merit of photovoltaic devices. Therefore, to assess the stability of our AgBiS2 NC solar cells, we first measured their shelf lifetime by storing the un-encapsulated devices in ambient conditions (temperature, ~25 °C; relative humidity, ~30%). The device showed a gradual improvement in the first 20 days (Supplementary Fig. 21), which is probably a result of the oxidation of the MoO _x_ layer and better band alignment<sup>42</sup> (Supplementary Fig. 22). Furthermore, the device retained its original performance after aging for four months. The operational stability was further investigated by subjecting the un-encapsulated device to AM1.5G one-sun illumination in the ambient atmosphere (relative humidity, ~60%). The device performance was measured by applying a forward bias fixed at the maximum power point (MPP). As shown in Fig. 4g, the PCE of the PTB7 device dropped below 2% after 20 min illumination, whereas the PTAA device demonstrated much better operational stability under continuous operation. After 10 h of MPP testing on the un-encapsulated cell in ambient conditions, the device retained 85% of its original efficiency. Longer stability at the MPP was also recorded with a class AA solar light source, showing ~80% of the original performance after 40 h test in ambient air (Supplementary Fig. 23). To the best of our knowledge, the devices reported here set a record among low-temperature and solution-processed, non-toxic inorganic solar cells in terms of stability and performance<sup>43–46</sup> . These results support the fact that AgBiS2 NCs are an extremely promising material for low-cost, efficient, stable and environmentally friendly solar cells. 

In conclusion, we have demonstrated that the absorption coefficients of ternary AgBiS2 NCs can be enhanced via cation disorder homogenization under mild annealing conditions. Ultrahigh absorption coefficients were obtained in annealed AgBiS2 NC films, with a calculated SLME of over 26% for a 30 nm NC film. The transition in cation configuration was further confirmed by the combination of ab initio calculations with XRD, HRTEM and XPS measurements. Ultrathin solar cells are fabricated based on ultra-absorbing AgBiS2 NCs. A high _J_ sc of 27 mA cm<sup>−2</sup> and a record efficiency of up to 9.17% were obtained with an independent certification of 8.85% from Newport, USA. The air stability and photostability were also recorded in high-performance devices. Our work 

not only establishes the potential of ultrathin AgBiS2 NC solar cells, which are solution processable and restriction of hazardous substances (RoHS) compliant, but also demonstrates the importance of atomic configuration engineering in multinary systems. 

#### **Online content** 

Any methods, additional references, Nature Research reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/ s41566-021-00950-4. 

Received: 10 September 2021; Accepted: 9 December 2021; Published online: 14 February 2022 

#### **References** 

1. Bernechea, M. et al. Solution-processed solar cells based on environmentally friendly AgBiS2 nanocrystals. _Nat. Photon._ **10** , 521–525 (2016). 

2. Boles, M. A., Ling, D., Hyeon, T. & Talapin, D. V. The surface science of nanocrystals. _Nat. Mater._ **15** , 364–364 (2016). 

3. Green, M. A. & Bremner, S. P. Energy conversion approaches and materials for high-efficiency photovoltaics. _Nat. Mater._ **16** , 23–34 (2017). 

4. Massiot, I., Cattoni, A. & Collin, S. Progress and prospects for ultrathin solar cells. _Nat. Energy_ **5** , 959–972 (2020). 

5. Chen, H.-L. et al. A 19.9%-efficient ultrathin solar cell based on a 205-nm-thick GaAs absorber and a silver nanostructured back mirror. _Nat. Energy_ **4** , 761–767 (2019). 

6. Adhyaksa, G. W. P., Johlin, E. & Garnett, E. C. Nanoscale back contact perovskite solar cell design for improved tandem efficiency. _Nano Lett._ **17** , 5206–5212 (2017). 

7. Bosson, C. J. et al. Cation disorder and phase transitions in the structurally complex solar cell material Cu2ZnSnS4. _J. Mater. Chem. A_ **5** , 16672–16680 (2017). 

8. Chen, W., Dahliah, D., Rignanese, G.-M. & Hautier, G. Origin of the low conversion efficiency in Cu2ZnSnS4 kesterite solar cells: the actual role of cation disorder. _Energy Environ. Sci._ **14** , 3567–3578 (2021). 

9. Malerba, C., Valentini, M. & Mittiga, A. Cation disorder in Cu2ZnSnS4 thin films: effect on solar cell performances. _Sol. RRL_ **1** , 1700101 (2017). 

10. Li, J. et al. Defect control for 12.5% efficiency Cu2ZnSnSe4 kesterite thin-film solar cells by engineering of local chemical environment. _Adv. Mater._ **32** , e2005268 (2020). 

11. Zawadzki, P., Zakutayev, A. & Lany, S. Entropy-driven clustering in tetrahedrally bonded multinary materials. _Phys. Rev. Appl_ . **3** , 034007 (2015). 

12. Mohan, R. Green bismuth. _Nat. Chem._ **2** , 336–336 (2010). 

13. Vesborg, P. C. K. & Jaramillo, T. F. Addressing the terawatt challenge: scalability in the supply of chemical elements for renewable energy. _RSC Adv._ **2** , 7933–7947 (2012). 

14. Burgués-Ceballos, I., Wang, Y., Akgul, M. Z. & Konstantatos, G. Colloidal AgBiS2 nanocrystals with reduced recombination yield 6.4% power conversion efficiency in solution-processed solar cells. _Nano Energy_ **75** , 104961 (2020). 

15. Kopula Kesavan, J. et al. Cation disorder and local structural distortions in Ag _x_ Bi1– _x_ S2 nanoparticles. _Nanomaterials_ **10** , 316 (2020). 

16. Schnepf, R. R. et al. Utilizing site disorder in the development of new energy-relevant semiconductors. _ACS Energy Lett._ **5** , 2027–2041 (2020). 

17. Yang, W.-C., Miskin, C. K., Carter, N. J., Agrawal, R. & Stach, E. A. Compositional inhomogeneity of multinary semiconductor nanoparticles: a case study of Cu2ZnSnS4. _Chem. Mater._ **26** , 6955–6962 (2014). 

18. Hao, M. et al. Ligand-assisted cation-exchange engineering for high-efficiency colloidal Cs1− _x_ FA _x_ PbI3 quantum dot solar cells with reduced phase segregation. _Nat. Energy_ **5** , 79–88 (2020). 

19. Ju, M.-G., Dai, J., Ma, L., Zhou, Y. & Zeng, X. C. AgBiS2 as a low-cost and eco-friendly all-inorganic photovoltaic material: nanoscale morphology– property relationship. _Nanoscale Adv._ **2** , 770–776 (2020). 

20. Viñes, F., Bernechea, M., Konstantatos, G. & Illas, F. Matildite versus schapbachite: first-principles investigation of the origin of photoactivity in AgBiS2. _Phys. Rev. B_ **94** , 235203 (2016). 

21. Guin, S. N., Banerjee, S., Sanyal, D., Pati, S. K. & Biswas, K. Origin of the order–disorder transition and the associated anomalous change of thermopower in AgBiS2 nanocrystals: a combined experimental and theoretical study. _Inorg. Chem._ **55** , 6323–6331 (2016). 

22. Khan, M. D. et al. Electrochemical investigation of uncapped AgBiS2 (schapbachite) synthesized using in situ melts of xanthate precursors. _Dalton Trans._ **48** , 3714–3722 (2019). 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**240** 

<mark>Articles</mark> 

### **Nature PhotoNics** 

23. Ren, X. et al. In situ exsolution of Ag from AgBiS2 nanocrystal anode boosting high-performance potassium-ion batteries. _J. Mater. Chem. A_ **8** , 15058–15065 (2020). 

24. Liu, M. et al. Hybrid organic–inorganic inks flatten the energy landscape in colloidal quantum dot solids. _Nat. Mater._ **16** , 258–263 (2017). 

25. Kagan, C. R. & Murray, C. B. Charge transport in strongly coupled quantum dot solids. _Nat. Nanotechnol._ **10** , 1013–1026 (2015). 

26. Wong, J., Omelchenko, S. T. & Atwater, H. A. Impact of semiconductor band tails and band filling on photovoltaic efficiency limits. _ACS Energy Lett._ **6** , 52–57 (2021). 

27. Treharne, R. E. et al. Optical design and fabrication of fully sputtered CdTe/ CdS solar cells. _J. Phys. Conf. Ser._ **286** , 012038 (2011). 

28. ElAnzeery, H. et al. Refractive index extraction and thickness optimization of Cu2ZnSnSe4 thin film solar cells. _Phys. Status Solidi A_ **212** , 1984–1990 (2015). 

29. Palik, E. D. _Handbook of Optical Constants of Solids_ (Academic Press, 1998). 30. Manzoor, S. et al. Optical modeling of wide-bandgap perovskite and perovskite/silicon tandem solar cells using complex refractive indices for arbitrary-bandgap perovskite absorbers. _Opt. Express_ **26** , 27441–27460 (2018). 

31. Chen, C. et al. Characterization of basic physical properties of Sb2Se3 and its relevance for photovoltaics. _Front. Optoelectron._ **10** , 18–30 (2017). 

32. Pettersson, L. A. A., Roman, L. S. & Inganäs, O. Modeling photocurrent action spectra of photovoltaic devices based on organic thin films. _J. Appl. Phys._ **86** , 487–496 (1999). 

33. Centurioni, E. Generalized matrix method for calculation of internal light energy flux in mixed coherent and incoherent multilayers. _Appl. Opt._ **44** , 7532–7539 (2005). 

34. Guillemoles, J.-F., Kirchartz, T., Cahen, D. & Rau, U. Guide for the perplexed to the Shockley–Queisser model for solar cells. _Nat. Photon._ **13** , 501–505 (2019). 

35. Gilmore, R. H. et al. Epitaxial dimers and Auger-assisted detrapping in PbS quantum dot solids. _Matter_ **1** , 250–265 (2019). 

36. Bagus, P. S., Illas, F., Pacchioni, G. & Parmigiani, F. Mechanisms responsible for chemical shifts of core-level binding energies and their relationship to chemical bonding. _J. Electron. Spectrosc. Relat. Phenom._ **100** , 215–236 (1999). 

37. Tambo, T. & Tatsuyama, C. XPS study on the chemical shifts of crystalline III–VI layered compounds. _J. Phys. Soc. Jpn_ **54** , 4382–4389 (1985). 

38. Akgul, M. Z., Figueroba, A., Pradhan, S., Bi, Y. & Konstantatos, G. Low-cost RoHS compliant solution processed photovoltaics enabled by ambient condition synthesis of AgBiS2 nanocrystals. _ACS Photonics_ **7** , 588–595 (2020). 

39. Hu, L. et al. Enhanced optoelectronic performance in AgBiS2 nanocrystals obtained via an improved amine-based synthesis route. _J. Mater. Chem. C_ **6** , 731–737 (2018). 

40. Oh, J. T. et al. Water-resistant AgBiS2 colloidal nanocrystal solids for eco-friendly thin film photovoltaics. _Nanoscale_ **11** , 9633–9640 (2019). 

41. Pan, H. et al. Advances in design engineering and merits of electron transporting layers in perovskite solar cells. _Mater. Horiz_ . **7** , 2276–2291 (2020). 

42. Irfan et al. Energy level evolution of air and oxygen exposed molybdenum trioxide films. _Appl. Phys. Lett._ **96** , 243307 (2010). 

43. Yu, B.-B. et al. Heterogeneous 2D/3D Tin-halides perovskite solar cells with certified conversion efficiency breaking 14%. _Adv. Mater_ . **33** , 2102055 (2021). 

44. Jiang, X. Ultra-high open-circuit voltage of tin perovskite solar cells via an electron transporting layer design. _Nat. Commun_ . **7** , 1245 (2020). 

45. Choi, Y. C., Lee, D. U., Noh, J. H., Kim, E. K. & Seok, S. I. Highly improved Sb2S3 sensitized-inorganic–organic heterojunction solar cells and quantification of traps by deep-level transient spectroscopy. _Adv. Funct. Mater._ **24** , 3587–3592 (2014). 

46. Wu, C. et al. Water additive enhanced solution processing of alloy Sb2(S1− _x_ Se _x_ )3-based solar cells. _Sol. RRL_ **4** , 1900582 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2022, corrected publication 2022 

**NAtuRe PhOtONICS** | VOL 16 | MARCh 2022 | 235–241 | www.nature.com/naturephotonics 

**241** 

<mark>Articles</mark> 

**Nature PhotoNics** 

#### **Methods** 

**DFT simulations.** The AiiDA infrastructure was used to maintain the data provenance for all the calculations performed in this study<sup>47</sup> . The calculations were performed using DFT within periodic boundary conditions through the Vienna ab initio simulation package<sup>48–50</sup> . Using the projector augmented-wave method, scalar-relativistic potentials were employed to describe the interaction between the core and valence electrons<sup>51</sup> . The calculations were carried out using Γ-centred _k_ -point meshes with a reciprocal space sampling of 0.11 Å<sup>−1</sup> and a plane-wave kinetic energy cutoff of 300 eV (increased to 450 eV for structural relaxations to avoid the possibility of Pulay stress). With these parameter choices, the ground-state energies of all the known structures in the Ag–Bi–S system were converged to within 1 meV per atom. 

**Cation disorder.** To model the effects of varying degrees of cation order/disorder, two approaches were employed. First, to simulate the total random cation disorder, a 64 atom supercell for AgBiS2 in the Fm<sup>¯</sup> 3m rock-salt structure was generated using the special quasi-random structure (SQS) method<sup>52</sup> , in which the cation–cation cluster correlations are optimized to obtain the best approximation to an ideal infinite random distribution for a given supercell. Here the alloy theoretic automated toolkit<sup>53</sup> was used to generate the SQS supercell via Monte Carlo–simulated annealing loops<sup>54–56</sup> . Eight Monte Carlo simulations were performed, with the structure giving the best match to the true disordered solid solution chosen for further calculations. This corresponded to an ‘objective function’ of −81.18, considering two-atom clusters with up to 12 Å separation, three-atom clusters up to a maximum of 10 Å pair separation and four-atom clusters up to 8 Å pair separation (using the experimental rock-salt crystal structure)<sup>37</sup> . 

The screened hybrid DFT exchange–correlation functional of Heyd, Scuseria and Ernzerhof (HSE06)<sup>38</sup> was used to calculate the structural and electronic properties of Fm<sup>¯</sup> 3m (using this SQS structure) and R<sup>¯</sup> 3m AgBiS2, unless otherwise stated, having been demonstrated to accurately predict the electronic structures of semiconductor materials<sup>57,58</sup> . To account for relativistic effects, due to the presence of heavy-atom elements Ag and Bi, spin–orbit-coupling (SOC) effects were included in all the electronic and optical calculations. 

Second, to investigate the effects of both partial order and inhomogeneous disorder (that is, cation segregation with Ag-rich and Bi-rich regions) on the cation sublattice, all the possible configurations for AgBiS2 in a 32 atom rock-salt structure were enumerated using the Transformer package<sup>59–61</sup> , yielding 440 symmetry-inequivalent arrangements. Here the PBEsol<sup>62</sup> semi-local exchange– correlation functional was used for geometry optimizations and energetic analysis, motivated by its well-established accuracy for the structural relaxation of bulk solids<sup>63</sup> and moderate computational cost. Moreover, this functional was tested against both experiment and computationally intensive HSE06 hybrid DFT functional for bulk geometry optimization and energetics, respectively, using all the known structures in the Ag–Bi–S system. Here PBEsol was found to accurately reproduce experimentally reported crystal structures, with a mean absolute error of <1.5% in the lattice parameters, as well as reproducing the energetic ordering of phases on the convex hull according to both HSE06 and experiment. 

To ensure consistency when comparing the results of these calculations to that of Fm<sup>¯</sup> 3m (SQS) AgBiS2, a new 32 atom SQS supercell was generated (using the same procedure as outlined above) and relaxed with PBEsol. In this case, a perfect ‘objective function’ match to the true disordered solution was obtained. Although appropriate for structural and energetic analysis of cation configurations in AgBiS2, semi-local DFT is known to severely underestimate electronic bandgaps<sup>64–67</sup> ; therefore, the HSE06 + SOC hybrid DFT functional was used to calculate the optical and electronic properties of these configurations. In this case, downsampling of the Fock exchange matrix by a factor of 2 (NKRED = 2) was employed to reduce the computational cost to a manageable level. This choice was confirmed to affect the electronic bandgap by <0.05 eV for the 32 atom SQS supercell. 

To investigate the impact of supercell size on the calculated properties, the 32 atom SQS supercell was also relaxed with the HSE06 functional, to then compare with the 64 atom structure. The total energy was found to match that of the 64 atom SQS supercell to <1 meV per atom, whereas the bandgap was found to slightly increase from 0.69 to 0.83 eV for the 32 atom supercell. 

**Post-processing.** Primitive and unfolded electronic band structure diagrams were generated using sumo and PyVaspwfc<sup>44,45</sup> , respectively. Further, effmass was used to calculate the effective masses of the carrier<sup>68</sup> , and the photoemission spectra were generated using Galore<sup>69–71</sup> .Crystal orbital Hamilton population analysis and charge-density partitioning were performed using LOBSTER<sup>48</sup> , and the vasppy package<sup>71</sup> was used to calculate the radial distribution functions. The pymatgen package was used throughout for the manipulation and analysis of the calculated inputs and outputs<sup>72</sup> . 

**Chemicals and materials.** Reagents were purchased from Sigma-Aldrich, except SnO2 colloid precursor (tin(iv) oxide, 15% in H2O colloidal dispersion), which was obtained from Alfa Aesar. PTAA was purchased from EM Index and PTB7 was purchased from 1-Material. 

**Synthesis of AgBiS2 NCs.** The Schlenk technique was used to synthesize AgBiS2 NCs, following a previous report with modifications<sup>1,14</sup> . Further, 4 mmol Bi(OAc)3, 3.2 mmol Ag(OAc), 24 ml oleic acid and 15 ml 1-octadecene were pumped at 100 °C for 2 h (~0.2 mbar) to remove oxygen and moisture. Then, 4 mmol hexamethyldisilathiane dissolved in 5 ml 1-octadecene was quickly injected into the flask. The heating mantel was removed and the reaction was cooled down in a water bath for ~5 min. After that, the crude solution was stirred for 1 h at room temperature. The NCs were isolated by adding acetone, followed by centrifugation. The extracted NCs were redispersed in toluene, and acetone was added to precipitate the NCs. The redispersion/precipitation was repeated once more. Finally, the obtained AgBiS2 NC powder was dispersed in anhydrous toluene (20 mg ml<sup>−1</sup> ) and stored in the ambient atmosphere for device fabrication. 

**Characterization of AgBiS2 NCs and films.** Films exchanged with 3-mercaptopropionic acid (MPA) were grown on glass substrates, followed by annealing at different temperatures in a glovebox. The thicknesses were measured using a profilometer. The complex refractive index was measured at various angles using a broadband Sopra Ellipsometer GES5E instrument. The SEMILAB spectroscopic ellipsometry analyser software was utilized to fit a model of stacked layers of appropriate optical constants and the thickness from the profilometer was used as an input. The absorption coefficients are calculated from the extinction coefficients. The XRD data were collected using a Rigaku SmartLab powder diffractometer in the Bragg–Brentano geometry with Cu Kα radiation. The XPS measurements were performed with a SPECS PHOIBOS 150 hemispherical analyser under ultrahigh-vacuum conditions (10<sup>−10</sup> mbar), with a monochromatic Kα X-ray source (1,486.74 eV) at the Institut Català de Nanociència i Nanotecnologia. TEM was performed at the Scientific and Technological Centres of the University of Barcelona. The TEM images were obtained using a JEOL 2100 microscope operating at an accelerating voltage of 200 kV. 

**Optical modelling and SLME.** A home-made MATLAB (R2021a) code was used to implement the transfer matrix formalism. We assumed that each layer was flat and considered no scattering effects. The short-circuit current density was calculated with the assumption of 100% IQE. The SLME was calculated according to 



<!-- Start of picture text -->
SLME = Pmax,<br>P = −V × J0 exp − 1 − Jsc,TMM ,<br>{ [ ( eVkT ) ] }<br><!-- End of picture text -->

where _e_ denotes the elementary charge; _k_ , the Boltzmann constant; _T_ , the temperature; and _J_ 0, the dark saturation current density calculated with the assumption of only radiative recombination: 



<!-- Start of picture text -->
+∞<br>J0 = e × ∫ EQETMM × ∅BB (E) dE,<br>0<br><!-- End of picture text -->

where EQETMM is the calculated total absorption in the AgBiS2 NCs layer and ∅BB is the black-body radiation spectra at 300 K. 

**Solar cell fabrication.** All the solar cell fabrication steps were performed in ambient air, unless with specific descriptions. ITO-covered glass substrates (Universität Stuttgart, Institut für Großflächige Mikroelektronik) were cleaned by ultrasonication in soapy water, acetone and isopropanol for 20 min each and dried with nitrogen, followed with 0.5 h ultraviolet/ozone treatment. SnO2 electron transport layer was then spin cast from diluted Alfa SnO2 colloid solution (1:5.6 v/v with H2O) at a spin speed of 2,000 r.p.m. and annealed at 270 °C for 15 min. Afterwards, three layers of AgBiS2 NCs were deposited from 20 mg ml<sup>−1</sup> toluene solution via the layer-by-layer method. For each AgBiS2 NC layer, one drop of AgBiS2 NC solution was spin coated onto SnO2/ITO substrates during spinning (2,000 r.p.m.). Then, 3-MPA/methanol (1% v/v) solution was applied to the NC film for 45 s, followed by two rinse–spin steps with methanol and once with toluene. The films were transferred into the glovebox for 10 min annealing at 115 °C and then stored in dry air before spin coating PTB7 (5 mg ml<sup>−1</sup> in dichlorobenzene) or PTAA solution (2 mg ml<sup>−1</sup> in toluene) at 3,000 r.p.m. Finally, a Kurt J. Lesker NANO 36 system was used to deposit 3 nm MoO3 and 120 nm Ag through a shadow mask to produce solar cells with a diameter of 2 mm (area, 3.14 mm<sup>2</sup> ). 

**Solar cell characterization.** All the device characterizations were performed in air under ambient conditions. Current–voltage ( _J_ – _V_ ) measurements were performed with a Keithley 2400 sourcemeter and a Newport Oriel Sol3A solar simulator with an AM1.5G filter. The intensity of solar light was calibrated using a Hamamatsu S1336 silicon photodiode that was calibrated at the Fraunhofer Institute of Solar Energy Systems. The solar cells were measured with and without masks, and a slightly lower _V_ oc was observed when measuring with masks due to the masking effect. For certified cells, appropriate masks were always used. The EQE was measured using a Newport Cornerstone 260 monochromator, a Thorlabs MC2000 chopper, a Stanford Research SR570 transimpedance amplifier and a Stanford Research SR830 lock-in amplifier. A calibrated Newport 818-UV 

**NAtuRe PhOtONICS** | www.nature.com/naturephotonics 

<mark>Articles</mark> 

### **Nature PhotoNics** 

photodetector was used as the reference. The shelf stability was obtained from the devices stored in air without encapsulation. For the MPP measurement, the MPP voltage ( _t_ = 0) was measured before MPP testing. The device was then held at the MPP voltage ( _t_ = 0) for the operation stability test. The device was un-encapsulated under AM1.5G illumination. All the devices were characterized under ambient conditions (relative humidity, >60%; ambient temperature, ~25 °C). Longer-time photostability was measured with a low-cost solar simulator from Abet Technologies. Transient photocurrent and transient photovoltage of the devices were measured with a home-made setup. This setup comprises a light-emitting diode lamp (to provide steady-state white-light bias), a 637 nm laser and an Agilent 4000X oscilloscope. The _V_ oc values of the devices are controlled by the light intensity of the light-emitting diode lamp, and the transient voltage induced by the laser pulse are controlled within 5% of the _V_ oc value. The time-of-flight method is used for the mobility measurements. Electron-only and hole-only devices are fabricated with the structure of ITO/SnO2/AgBiS2/Phenyl-C61-butyric acid methyl ester (PC60BM)/Ag and ITO/NiO _x_ /AgBiS2/PTAA/MoO _x_ /Ag. The thickness of the AgBiS2 layer was controlled to ~200 nm. A 520 nm nanosecond laser was used as the excitation light. Photocurrent decay was recorded at various biases with an oscilloscope. The mobility was calculated by fitting the _d_<sup>2</sup> / _t_ – _V_ bias plots, where _d_ is the thickness, _t_ is time and _V_ bias is the bias voltage. 

**Reporting Summary.** Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

#### **Data availability** 

The experimental and computational data that support the current study are available in a public repository (https://doi.org/10.5281/zenodo.5733213). Supplementary Information data are available from the corresponding author upon reasonable request. 

#### **Code availability** 

The code that supports this study is available in a public repository (https://doi. org/10.5281/zenodo.5733213). 

#### **References** 

47. Huber, S. P. et al. AiiDA 1.0, a scalable computational infrastructure for automated reproducible workflows and data provenance. _Sci. Data_ **7** , 300 (2020). 

48. Kresse, G. & Hafner, J. Ab initio molecular dynamics for liquid metals. _Phys. Rev. B_ **47** , 558–561 (1993). 

49. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

50. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

51. Blöchl, P. E. Projector augmented-wave method. _Phys. Rev. B_ **50** , 17953–17979 (1994). 

52. Zunger, A., Wei, S.-H., Ferreira, L. G. & Bernard, J. E. Special quasirandom structures. _Phys. Rev. Lett._ **65** , 353–356 (1990). 

53. van de Walle, A., Asta, M. & Ceder, G. The alloy theoretic automated toolkit: a user guide. _Calphad_ **26** , 539–553 (2002). 

54. van de Walle, A. et al. Efficient stochastic generation of special quasirandom structures. _Calphad_ **42** , 13–18 (2013). 

55. Geller, S. & Wernick, J. H. Ternary semiconducting compounds with sodium chloride-like structure: AgSbSe2, AgSbTe2, AgBiS2, AgBiSe2. _Acta Crystallogr._ **12** , 46–54 (1959). 

56. Heyd, J., Scuseria, G. E. & Ernzerhof, M. Hybrid functionals based on a screened Coulomb potential. _J. Chem. Phys._ **118** , 8207–8215 (2003). 

57. Borlido, P. et al. Exchange-correlation functionals for band gaps of solids: benchmark, reparametrization and machine learning. _npj Comput. Mater._ **6** , 96 (2020). 

58. Krukau, A. V., Vydrov, O. A., Izmaylov, A. F. & Scuseria, G. E. Influence of the exchange screening parameter on the performance of screened hybrid functionals. _J. Chem. Phys._ **125** , 224106 (2006). 

59. Skelton, J. JMSkelton Transformer. https://github.com/JMSkelton/Transformer (2021). 

60. Perdew, J. P. et al. Restoring the density-gradient expansion for exchange in solids and surfaces. _Phys. Rev. Lett._ **100** , 136406 (2008). 

61. Csonka, G. I. et al. Assessing the performance of recent density functionals for bulk solids. _Phys. Rev. B_ **79** , 155107 (2009). 

62. Diedenhofen, S. L., Bernechea, M., Felter, K. M., Grozema, F. C. & Siebbeles, L. D. A. Charge photogeneration and transport in AgBiS2 nanocrystal films for photovoltaics. _Sol. RRL_ **3** , 1900075 (2019). 

63. Cao, Y., Stavrinadis, A., Lasanta, T., So, D. & Konstantatos, G. The role of surface passivation for efficient and photostable PbS quantum dot solar cells. _Nat. Energy_ **1** , 16035 (2016). 

64. Hoye, R. L. Z. et al. Perovskite-inspired photovoltaic materials: toward best practices in materials characterization and calculations. _Chem. Mater._ **29** , 1964–1988 (2017). 

65. Huang, Y.-T., Kavanagh, S. R., Scanlon, D. O., Walsh, A. & Hoye, R. L. Z. Perovskite-inspired materials for photovoltaics and beyond—from design to devices. _Nanotechnology_ **32** , 132004 (2021). 

66. Zheng, Q. QijingZheng/VaspBandUnfolding. https://github.com/QijingZheng/ VaspBandUnfolding (2021). 

67. Popescu, V. & Zunger, A. Extracting _E_ versus →<sup>−</sup> k effective band structure from supercell calculations on alloys and impurities. _Phys. Rev. B_ **85** , 085201 (2012). 

68. Whalley, L. D. effmass: an effective mass package. _J. Open Source Softw._ **3** , 797 (2018). 

69. Jackson, A. J., Ganose, A. M., Regoutz, A., Egdell, R. G. & Scanlon, D. O. Galore: broadening and weighting for simulation of photoelectron spectroscopy. _J. Open Source Softw._ **3** , 773 (2018). 

70. Nelson, R. et al. LOBSTER: local orbital projections, atomic charges, and chemical-bonding analysis from projector-augmented-wave-based density-functional theory. _J. Comput. Chem._ **41** , 1931–1940 (2020). 

71. Morgan, B. J. vasppy. https://doi.org/10.5281/zenodo.4460130 (2021). 

72. Ong, S. P. et al. Python materials genomics (pymatgen): a robust, open-source Python library for materials analysis. _Comput. Mater. Sci._ **68** , 314–319 (2013). 

#### **Acknowledgements** 

G.K. acknowledges financial support from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement no. 725165), the Fundació Joan Ribas Araquistain (FJRA), the Fundació Privada Cellex, the program CERCA, EQC2019-005797-P (AEI/FEDER UE), 2017SGR1373 and ‘Severo Ochoa’ Centre of Excellence CEX2019-000910-S funded by the Spanish State Research Agency. Y.W. acknowledges support from the European Union’s Horizon 2020 research and innovation programme under the Marie Skłodowska-Curie grant agreement no. 754558. I.B.-C. acknowledges support from the Government of Catalonia’s Beatriu de Pinós postdoctoral programme (grant no. 2017BP00241). S.R.K. thanks L. Harnett-Caulfield for help with using the alloy theoretic automated toolkit software package and Y.-S. Choi for help with calculating the Madelung potentials; he also acknowledges the EPSRC Centre for Doctoral Training in the Advanced Characterisation of Materials (CDT-ACM) (EP/S023259/1) for funding a PhD studentship. A.W. and D.O.S. acknowledge the use of the UCL Kathleen High Performance Computing Facility (Kathleen@UCL), the Imperial College Research Computing Service and associated support services. By the membership of the UK’s HEC Materials Chemistry Consortium, which is funded by the EPSRC (EP/L000202, EP/R029431 and EP/T022213), this work used the ARCHER2 UK National Supercomputing Service and the UK Materials and Molecular Modelling (MMM) Hub (Thomas EP/P020194 and Young EP/T022213). D.O.S. acknowledges support from the EPSRC (EP/N01572X/1) and the European Research Council, ERC (grant no. 758345). 

#### **Author contributions** 

G.K. supervised and directed the study. Y.W. and G.K. conceived the idea, designed this study and co-wrote the manuscript, with feedback from the co-authors. Y.W. synthesized the AgBiS2 NCs, performed the material characterization, fabricated and characterized the solar cells, and analysed the data, with help from I.B.-C. Y.W. performed the optical modelling. S.R.K. designed and conducted the theoretical modelling, analysed the DFT simulations, interpreted the data, provided insights and contributed to manuscript writing. D.S and A.W. supervised the theoretical modelling. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41566-021-00950-4. 

**Correspondence and requests for materials** should be addressed to Gerasimos Konstantatos. 

**Peer review information** _Nature Photonics_ thanks Rui Zhu, Sergio Brovelli and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at www.nature.com/reprints. 

**NAtuRe PhOtONICS** | www.nature.com/naturephotonics 











