# CMOS-compatible ferroelectric NAND flash memory for high-density, low-power, and high-speed three-dimensional memory

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 242 |
| 作者 | Min-Kyu Kim, Ik-Jyae Kim, J. Lee |
| DOI | 10.1126/sciadv.abe1341 |
| 源文件 | 032_Kim_2021_CMOS-compatible-ferroelectric-NAND-flash-memory.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

#### **M A T E RIALS SCIENC E** 

# **CMOS-compatible ferroelectric NAND flash memory for high-density, low-power, and high-speed three-dimensional memory** 

### **Min-Kyu Kim*, Ik-Jyae Kim*, Jang-Sik Lee**<sup>**†**</sup> 

**Ferroelectric memory has been substantially researched for several decades as its potential to obtain higher speed, lower power consumption, and longer endurance compared to conventional flash memory. Despite great deal of effort to develop ferroelectric memory based on perovskite oxides on Si, formation of unwanted interfacial layer substantially compromises the performance of the ferroelectric memory. Furthermore, three-dimensional (3D) integration has been unimaginable because of high processing temperature, non-CMOS compatibility, difficulty in scaling, and complex compositions of perovskite oxides. Here, we demonstrate a unique strategy to tackle critical issues by applying hafnia-based ferroelectrics and oxide semiconductors. Thus, it is possible to avoid the formation of interfacial layer that finally allows unprecedented Si-free 3D integration of ferroelectric memory. This strategy yields memory performance that could be achieved neither by the conventional flash memory nor by the previous perovskite ferroelectric memories. Device simulation confirms that this strategy can realize ultrahigh-density 3D memory integration.** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

#### **INTRODUCTION** 

Current flash memory devices used in massive data storage for mobile devices and servers are based on floating-gate or charge-trap memory transistors using electron tunneling through a tunnel oxide ( _1_ , _2_ ). As the electron-tunneling process requires voltage pulses with high amplitude and long duration, current flash memory devices usually require high operation voltage of ~20 V and slow speed of ~10<sup>−3</sup> s and show limited endurance of ~10<sup>4</sup> cycles ( _3_ – _5_ ). In addition, it requires high deposition (>600°C) and/or annealing (>900°C) temperatures to form channel and oxide layers ( _6_ , _7_ ). To overcome these limitations, many types of emerging memory devices have been evaluated, but still, there have been no alternatives to current flash memory ( _8_ – _10_ ). A ferroelectric memory transistor can be a viable candidate to replace current flash memory because of its potential to obtain fast operation at a low power ( _11_ , _12_ ). In a ferroelectric memory transistor, the charges in the channel layer can be directly controlled by the polarization of a ferroelectric layer that is incorporated into the gate stack of the ferroelectric transistor ( _13_ ). Although previous studies that use ferroelectric perovskite oxides deposited on Si wafers show the feasibility as high-performance flash memory applications, formation of an interfacial layer with a Si channel imposes limits of memory window, endurance, and data retention properties ( _14_ – _17_ ). In addition, the complex compositions of perovskite oxides limit the applicability of ferroelectric memory as next- generation flash memory devices ( _18_ , _19_ ). Furthermore, threedimensional (3D) integration of such ferroelectric memories is a key requirement for commercialization but has been unattainable because deposition of perovskite oxides and noble metals in 3D structures is a difficult task and those materials are very difficult to etch ( _19_ ). 

Hafnia-based ferroelectric materials have gained research interest because of their potential to have complementary metal-oxide semiconductor (CMOS) compatibility, low power consumption, 

> Department of Materials Science and Engineering, Pohang University of Science and Technology (POSTECH), Pohang 37673, Korea. 

*These authors contributed equally to this work. 

> †Corresponding author. Email: jangsik@postech.ac.kr 

and fast switching speed ( _19_ ). In addition, recent studies suggested that hafnia-based ferroelectrics could be scaled down to <1 nm while maintaining ferroelectricity ( _20_ ). Because of these advantages, hafnia-based ferroelectric materials have been adopted in ferroelectric memory transistors, negative-capacitance field-effect transistors (FETs), ferroelectric tunneling junctions, and artificial synapses ( _21_ – _26_ ). Hafnia-based ferroelectric materials can be deposited conformally on the vertical structures using atomic layer deposition (ALD), so ferroelectric transistors that use them are regarded as promising candidates for use in 3D memory such as 3D NAND ( _27_ , _28_ ). However, device performance issues derived from the formation of an interfacial layer with a Si channel still need to be solved ( _29_ ). 

Here, we present unique integration strategies to overcome the aforementioned key issues in ferroelectric memory transistors by introducing indium zinc oxide (InZnO _x_ ) as the semiconductor layer and zirconium-doped hafnium oxide (HfZrO _x_ ) as the ferroelectric layer. First, SiO _x_ interfacial layer inherently unavoidable from the conventional perovskite oxide– or hafnia-based ferroelectric memories on Si could be effectively prevented by using InZnO _x_ as a semiconductor while maintaining necessary material qualities (or comparable materials quality as that of Si) to obtain high-performance memories. This results in several hundreds of times faster operation speed (<10<sup>−6</sup> s) and four times lower operation voltage (<5 V) compared to current flash memory ( _3_ , _30_ ). In addition, the absence of an interfacial layer allows outstanding endurance characteristics (>10<sup>8</sup> cycles) of ferroelectric transistors compared to both charge-trap flash memory (~10<sup>4</sup> ) and ferroelectric transistor with a Si channel (~10<sup>7</sup> ) ( _5_ , _23_ , _29_ , _31_ ). As all processes can be done below 400°C, the integrated ferroelectric memory devices are CMOS compatible such that we are able to confirm that our process can achieve commercialization milestones including demonstration of NAND flash arrays and 3D vertical structures. Our nanoscale 3D vertical flash memory exhibits excellent performances that promise ultrahigh-density 3D flash memory in the future. The 3D device shows a large memory window of 2.5 V and stable switching characteristics for 10<sup>8</sup> cycles. Device simulation confirms the operation mechanism and possibility of ultrahigh-density 3D memory integration. These results demonstrate 

**1 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

the plausibility of ALD-based ferroelectric memory as future 3D nonvolatile memory devices such as 3D vertical NAND. 

#### **RESULTS** 

### **Combination of hafnia-based ferroelectrics and oxide semiconductor for high-performance ferroelectric transistor** 

To confirm ferroelectric properties of HfZrO _x_ , we fabricated a capacitor that had a TiN/HfZrO _x_ /TiN structure and measured the polarization–electric field ( _P_ - _E_ ) characteristics of 24-nm-thick HfZrO _x_ (fig. S1A). HfZrO _x_ showed a positive remnant polarization of + _P_ r = 15.1 C/cm<sup>2</sup> and a negative remnant polarization of − _P_ r = −13.8 C/ cm<sup>2</sup> . The coercive electric field of HfZrO _x_ was ~1.2 MV/cm; this is larger than those of ferroelectric perovskite oxides (~0.05 MV/cm) and can be advantageous in ferroelectric transistor because large coercive electric field can lead to a large memory window ( _18_ ). Therefore, a sufficient memory window can be achieved using a thin HfZrO _x_ layer compared to perovskite oxides. The ferroelectricity of HfZrO _x_ was also confirmed using piezoresponse force microscopy (PFM) and capacitance-voltage ( _C_ - _V_ ) measurements. The PFM amplitude and phase images were measured after applying −6 V to the outer square region and then with +6 V to the inner square region of the sample. The clear difference in contrast showed different polarization states of HfZrO _x_ in PFM amplitude (fig. S1B) and phase images (fig. S1C). The _C-V_ curve exhibited butterfly-shaped hysteresis, which is a result of the ferroelectric property of HfZrO _x_ (fig. S1D). These results confirmed the ferroelectric nature of HfZrO _x_ film. The endurance and polarization switching characteristics of HfZrO _x_ were characterized. For endurance characteristics, repeated voltage pulses with an amplitude of ±6 V and a width of 5 s were applied (fig. S1E). The ferroelectric HfZrO _x_ showed stable switching characteristics for 10<sup>8</sup> cycles. The polarization switching characteristics 

of the HfZrO _x_ were evaluated by measuring switching and nonswitching polarization characteristics under application of voltage pulses with an amplitude of 7.2 V (i.e., 3 MV/cm) and different widths (fig. S1F). As a pulse width was increased from 30 to 700 ns, the switched polarization of HfZrO _x_ increased. 

To investigate the feasibility of our integration strategies, ferroelectric thin-film transistors (FeTFTs) with a bottom-contact structure were fabricated by combining ALD-based HfZrO _x_ and InZnO _x_ (Fig. 1A). Their electrical characteristics were quantified by sweeping gate voltage _V_ G between −5 and 5 V at source-drain voltages _V_ DS of 0.1, 0.05, and 0.01 V. The FeTFT showed counterclockwise hysteresis, which originated from ferroelectric polarization switching in the HfZrO _x_ (Fig. 1B). The linear field-effect mobility of InZnO _x_ channel in FeTFTs was ~1.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which is lower than that of InZnO _x_ on the SiO2 layer (~7.8 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). This difference seems to originate from the high dielectric constant of the HfZrO _x_ layer, which can induce remote phonon scattering ( _32_ ). This remote phonon scattering can be reduced by using gate electrode layers with a high electron density ( _33_ , _34_ ). In addition, the mobility of InZnO _x_ channel can be further increased by optimizing process parameters, such as doping and growth temperature ( _35_ ). To quantify the memory window of the FeTFT, the device was programmed and erased by applying positive (5 V, 10 ms) and negative (−5 V, 10 ms) _V_ G pulses, respectively. After each pulse had been applied, _V_ G was swept from 0 to −5 V to verify the state of devices. The threshold voltages _V_ th of programmed and erased states were extracted using linear extrapolation (Fig. 1C) ( _36_ ). The memory window, which is the difference between _V_ th of programmed and erased states, was larger in our FeTFT (>2 V) than previously reported FeTFTs with hafnia-based ferroelectric materials and oxide semiconductors (0.5 to 1 V) ( _21_ , _22_ ). To determine the switching characteristics of FeTFT based on HfZrO _x_ and InZnO _x_ , the _V_ G pulses with different amplitudes and widths were 



<!-- Start of picture text -->
A B C<br>10−6<br>4 x 10−7<br>10−7<br>10−8<br>2 x 10−7<br>10−9 V DS= 0.1 V<br>V DS= 0.05 V<br>10−10 V DS= 0.01 V<br>0<br>−4 −2 0<br>V G(V) V G(V)<br>D E F<br>−1.2<br>−1 −1<br>−1.4<br>−2 −2 −1.6<br>−1.8<br>−3 3 4 5 −3 10−7 10−6 −2.0100 102 104 106 108<br>Pulse amplitude (V) Pulse width (s) Pulse cycles<br> (A) I DS  (A) I DS<br> (V) V th  (V) V th  (V) V th<br><!-- End of picture text -->

**Fig. 1. FeTFT for nonvolatile memory applications.** ( **A** ) Schematic illustration of FeTFT that uses HfZrO _x_ and InZnO _x_ . ( **B** ) Transfer curves of FeTFT with _V_ DS = 0.1, 0.05, and 0.01 V. ( **C** ) _I_ DS- _V_ G curves of FeTFT in erased and programmed states. Threshold voltage _V_ th is extracted using the linear extrapolation. A memory window is the difference between erased and programmed _V_ th of FeTFT. _V_ th change of FeTFT according to ( **D** ) amplitudes and ( **E** ) widths of program pulses. In operation with different pulse amplitudes, pulse amplitudes are increased from 3 to 5 V and a width is fixed at 1 s. In operation with different pulse widths, pulse widths are increased from 100 ns to 1 s and an amplitude is fixed at 5 V. ( **F** ) Endurance characteristics of FeTFT for 10<sup>8</sup> cycles using positive (5 V, 500 ns) and negative (−7 V, 1 s) triangular pulses for program and erase operations, respectively. 

**2 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

applied. Before measurement, FeTFTs were erased by applying a negative _V_ G pulse (−5 V, 10 ms). Then, pulses with a width of 1 s and amplitudes of 3 to 5 V in increments of 0.2 V were applied. As the amplitudes of pulses were increased, the _V_ th of the device was changed (Fig. 1D). A memory window of ~2 V could be achieved using a pulse that had an amplitude of 5 V, which is about four times lower than the pulse amplitude required for conventional flash memory ( _37_ , _38_ ). _V_ th change was also observed as pulse widths were increased from 100 ns to 1 s at an amplitude of 5 V (Fig. 1E). These switching characteristics may be a result of partial polarization switching of the HfZrO _x_ layer, which can be controlled by the condition of applied pulses ( _39_ , _40_ ). A memory window of ~1 V could be achieved using a voltage pulse width of 500 ns, which was about several hundreds times faster than the erase operation speed of conventional flash memory for acquiring a similar memory window ( _30_ , _41_ ). The memory window of flash memory is dependent on memory operations, such as multilevel data storage, and flash memory can be operated faster when a small memory window is required ( _42_ ). However, still much higher program/erase voltages are required, compared to the ferroelectric memory presented in this study ( _30_ ). To confirm the reliability of FeTFT based on HfZrO _x_ and InZnO _x_ , we investigated the endurance properties using devices with different memory windows of 0.5 and 1.5 V. Memory windows of 0.5 and 1.5 V were obtained by applying triangular pulses (5 V, −7 V) and (6 V, −8 V), respectively (Fig. 1F and fig. S2). The pulse width of 500 ns and 1 s was used for program and erase operation, respectively. After consecutive program and erase pulses had been applied, the device states were confirmed by sweeping _V_ G from 0 to −5 V. With a memory window of 0.5 V, FeTFT using ALD-based HfZrO _x_ and InZnO _x_ showed stable switching characteristics for 10<sup>8</sup> cycles. The robust endurance characteristics of ALD-based FeTFTs seem to originate from its metal-ferroelectric-semiconductor structure without interfacial layer ( _29_ ). When a Si layer is used as a channel, SiO _x_ interfacial layer can be formed between the channel and ferroelectric layer, so ferroelectric transistors with a Si channel have a metalferroelectric-insulator-semiconductor (MFIS) structure ( _31_ , _43_ , _44_ ). When _V_ G is applied to the MFIS structure, much of the applied electric field can be induced in SiO _x_ interfacial layer because of its low dielectric constant compared to the ferroelectric layer. The high electric field in SiO _x_ interfacial layer can cause charge tunneling across the SiO _x_ interfacial layer and induce charge trapping in the ferroelectric layer; it can degrade endurance characteristics ( _29_ , _31_ ). In our FeTFTs, the formation of an interfacial layer can be suppressed by using an oxide semiconductor channel; the absence of an interfacial layer yielded stable endurance characteristics. In addition, a comparison was made between this work and previous memory devices such as charge-trap memory, perovskite oxide–based ferroelectric transistors, and hafnia-based ferroelectric transistors (table S1) ( _12_ , _23_ , _29_ , _31_ , _45_ – _51_ ). The use of HfZrO _x_ and InZnO _x_ resulted in lower operation voltage, faster operation speed, and lower processing temperature compared to conventional charge-trap memory and perovskite oxide–based ferroelectric transistor. In addition, by avoiding the formation of the SiO _x_ interfacial layer, robust endurance characteristics were achieved compared to charge-trap memory and ferroelectric transistors. 

### **Memory operation of integrated ferroelectric NAND** 

The structure of a ferroelectric NAND (FeNAND) flash memory array is analogous to that of NAND flash devices (fig. S3A). The 

difference is the type of memory cell; FeNAND uses ferroelectric transistors, whereas NAND flash uses conventional flash memory. In FeNAND, a page consists of ferroelectric transistor memory cells that share a word line (WL). An FeNAND string includes ferroelectric transistor memory cells connected in series. All of the FeNAND strings share a source line (SL). Each NAND string is connected to bit lines (BLs) ( _12_ , _52_ ). We fabricated a 4 × 4 FeNAND array by integrating FeTFTs with a ferroelectric HfZrO _x_ layer and an InZnO _x_ channel layer (fig. S3B). The fabrication process of FeNAND was CMOS compatible and could be done below 400°C. First, TiN was deposited for WLs on the SiO2/Si substrate, and HfZrO _x_ layer was deposited for the ferroelectric layer. A Mo layer was deposited for BL/SL, and an InZnO _x_ layer was deposited for the channel layer. ALD was used to deposit the HfZrO _x_ and InZnO _x_ layers. The annealing process to induce the ferroelectric phase in the HfZrO _x_ layer was performed at 400°C after deposition of the InZnO _x_ layer. The processing temperature of FeNAND is lower than that of ferroelectric devices based on perovskite oxides (>700°C) ( _12_ , _48_ , _49_ ). Last, etching process was done to open the contacts for WLs. The fabricated 4 × 4 FeNAND array was composed of four WLs (WL _n_ ; _n_ = 0, 1, 2, and 3) and four NAND strings (Fig. 2A). Each NAND string was connected to BLs (BL _m_ ; _m_ = 0, 1, 2, and 3). All NAND strings were connected to the same SL. In this 4 × 4 FeNAND array, each of the 16 memory cells _Cnm_ was positioned on the cross-point of WL _n_ and NAND strings on BL _m_ . This array was used to demonstrate program operation of FeNAND. In a NAND structure, an unwanted programming may occur in memory cells that share a WL with the selected memory cell during program operation; this phenomenon is called program disturbance ( _12_ , _52_ ). To avoid program disturbance, the program-inhibit operation method was used. As an example, memory cells of _C_ 20 and _C_ 21 were selected as programmed and program-inhibited cells, respectively. Before program operation, FeTFT memory cells in FeNAND array were erased by applying an erase pulse with an amplitude of _V_ E = −5 V and a width of 10 ms to WL2, while 0 V was applied to the BLs and SL (Fig. 2B). Then, to program _C_ 20, a program pulse with an amplitude of _V_ P = 5 V and a width of 10 ms was applied to the selected WL2, and 0 V was applied to the BL0. To inhibit the program of _C_ 21 that shared the WL2 with _C_ 20, program-inhibit pulses with an amplitude of _V_ inhibit = 2.5 V and a width of 30 ms were applied to BL1 and SL (Fig. 2C). Pass voltage with an amplitude of _V_ pass = 2.5 V and a width of 30 ms was applied to unselected WLs. _V_ pass can also disturb the states of the memory cell. Therefore, the effect of _V_ pass on pass disturbance was investigated by increasing the amplitude of _V_ pass from 0.5 to 4 V. In the range of _V_ pass > 3 V, pass disturbance occurred, so _V_ pass with an amplitude of 2.5 V was used for program-inhibit operation (fig. S4). After erase and program operations, the states of memory cells were confirmed by applying WL voltage _V_ WL sweep (0 → −5 V) to the selected WL2. During these operations, only the memory cell _C_ 20 could be programmed by the difference in voltage between the gate and channel layer ( _53_ ). Otherwise, the program could be inhibited by program-inhibit operation in the program-inhibited cell _C_ 21. While _V_ inhibit was applied to BL1 and SL, the channel potential could be increased; the difference in voltage between gate and channel could be decreased to _V_ P − _V_ inhibit ( _52_ – _54_ ). The program of _C_ 21 was prevented by program-inhibit operation method using _V_ inhibit = 2.5 V because polarization switching of HfZrO _x_ layer in _C_ 21 was hindered (Fig. 2D). These results indicated that the difference in voltage between gate and channel was small enough to avoid erroneous program of 

**3 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



<!-- Start of picture text -->
A B<br>SL BL0<br>BL1<br>BL2<br>BL3<br>WL0 WL3<br>WL1 WL2<br>C D 10−6<br>10−7<br>10−8<br>10−9<br>Programmed cell<br>Program-inhibited cell<br>10−10 Erased cells<br>−4 −2 0<br>VWL(V)<br> (A) I BL<br><!-- End of picture text -->

**Fig. 2. Operation characteristics of FeNAND.** ( **A** ) Optical image of 4 × 4 FeNAND flash memory array (left) and NAND strings in FeNAND flash memory array including programmed cell ( _C_ 20) and program-inhibited cell ( _C_ 21) (right). ( **B** and **C** ) Equivalent circuits of FeNAND flash memory array and erase/program operations. _V_ P, _V_ E, _V_ pass, and _V_ inhibit stand for program, erase, pass, and inhibit voltages, respectively. ( **D** ) _I_ BL- _V_ WL curves of _C_ 20 memory cell and _C_ 21 memory cell after erase and program operations. Program of _C_ 21 memory cell is prevented by program-inhibit operation. Program-inhibit pulse with an amplitude of _V_ inhibit = 2.5 V is used for program-inhibit operation. During program-inhibit operation, the channel potential of _C_ 21 memory cell could be boosted to _V_ inhibit. 

_C_ 21. To investigate how program-inhibit pulses affect the programinhibited cell, the program operation was performed using program-inhibit pulses with different amplitudes (fig. S5). The amplitudes of program-inhibit pulses were increased from 0 to 2.5 V in increments of 0.5 V. The program-inhibit behaviors depended on the amplitudes of _V_ inhibit. At _V_ inhibit < 1 V, the unwanted program of memory cell _C_ 21 (unwanted cell) happened. As the amplitude of _V_ inhibit was increased, program of memory cell _C_ 21 was inhibited ( _53_ ). Program-inhibit operation using _V_ inhibit = 2.5 V could successfully prevent unwanted program; this was confirmed by repeated program and program-inhibit operations (fig. S6). These results indicated that program disturbance could be effectively reduced by applying _V_ inhibit. 

All 16 memory cells in FeNAND array were operated without any failures. The states of memory cells were confirmed by measuring _I_ BL- _V_ WL curves of programmed and erased states (Fig. 3A). Memory cells showed a clear separation in _I_ BL- _V_ WL curves after program and erase operations. The device states could be confirmed nondestructively by measuring the string current while the read voltage _V_ R was applied to the selected cell. For nondestructive read operation, the amplitude of _V_ R was chosen within a range that did not induce switching of the polarization state in the ferroelectric layer. During application of _V_ R with an amplitude of −2 V, the states of the memory cells did not change. Therefore, to read the state of the selected memory cell, _V_ R = −2 V was applied to the selected WL while BL read voltage _V_ RBL was swept from 0 to 0.5 V. By measuring readout current _I_ readout of memory cell, the polarization state of ferroelectric layer in the selected memory cell was confirmed. _I_ readout of the 16 memory cells in the 4 × 4 FeNAND array was measured in programmed and erased states (fig. S7). _I_ readout showed clear difference according to memory states (Fig. 3B). The string- and page-level NAND operations were demonstrated using the FeNAND device. Three different cases of NAND strings (all programmed cells, one 

erased and all other programmed cells, and all erased cells) were used (Fig. 3C). _I_ readout of a string was measured while _V_ R = −2 V was applied to all WLs. When all memory cells were programmed, the NAND string was on state. However, when the string included at least one erased cell, the NAND string was off state because all memory cells in a string were connected in series (Fig. 3D). These results confirmed that NAND memory operation is possible using an array of FeTFTs. 

To investigate the wafer-scale uniformity of devices, we fabricated FeNAND arrays on the 4-inch SiO2/Si wafer (fig. S8A). Program and erase operations of nine memory cells from different positions on the wafer were measured (fig. S8B). Memory cells in programmed and erased states showed clear differences in _I_ readout (fig. S8C). These results indicated that FeNAND fabricated using ALD could exhibit uniform electrical characteristics on the wafer scale. Using a program pulse with different amplitudes, _V_ th tuning characteristics of memory cell in FeNAND were demonstrated (fig. S9A). First, the memory cell was erased by applying an erase pulse (−5 V, 10 ms). Then, program pulses with amplitudes of 3.3, 3.8, and 5 V were applied. As the amplitude of program pulses was increased, _I_ BL- _V_ WL curves were shifted to the negative direction. Memory cells in FeNAND showed _V_ th of four different states for repeated cycles using program pulses with different amplitudes (fig. S9B). 

### **Nanoscale vertical FeTFTs for high-density** 

### **ferroelectric memory** 

To confirm the feasibility of FeTFTs as a 3D memory device, we fabricated a vertical FeTFT array by sequentially depositing a 50-nmthick SiO2 insulator and 100-nm-thick TiN gate electrodes (Fig. 4, A and B). As HfZrO _x_ and InZnO _x_ layers were deposited using ALD, both layers were conformally deposited (Fig. 4C). Here, we defined the FeTFT using the middle TiN gate electrode positioned 

**4 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. Memory operation of FeNAND.** ( **A** ) _I_ BL- _V_ WL of 16 memory cells in programmed and erased states. ( **B** ) Statistical distribution of readout current _I_ readout of 16 memory cells in programmed (blue) and erased (red) states. ( **C** ) NAND operations: All programmed cells (case 1), one erased and all other programmed cells (case 2), and all erased cells (case 3). ( **D** ) _I_ readout of NAND strings in cases 1, 2, and 3. Only the memory string that has all programmed cells shows the on state; when even one cell is erased, the off state is obtained. 

between the SiO2 layers as middle TFT (m-TFT). The effective channel area of the m-TFT was 10 m<sup>2</sup> (channel length/width, 100 nm/100 m). The electrical characteristics of m-TFT were investigated by applying _V_ G sweep to the m-TFT gate electrode at _V_ DS = 1 V, while applying _V_ pass of 1 V to the unselected gate (i.e., top and bottom TiN) electrodes (Fig. 4D). An n-type transfer characteristic with counterclockwise hysteresis was observed when _V_ G sweep of −5 → 5 → −5 V was applied to the m-TFT gate electrode. The memory window of vertical FeTFT was about 2.5 V. This result implies that the FeTFTs can be operated in a vertically stacked structure with a channel length of 100 nm. The switching characteristics of the m-TFT were verified by applying voltage pulses with different pulse widths and amplitudes (Fig. 4E). The required pulse width for program operation was decreased as the amplitude of voltage pulse increased. To confirm the reliability of m-TFT, the endurance properties were investigated by applying positive (6 V, 1 s) and negative (−7 V, 1 s) triangular pulses as program and erase pulses, respectively (Fig. 4F). After consecutive program and erase pulses had been applied, the device states were confirmed by sweeping _V_ G from 0 to −3 V. m-TFT showed stable switching characteristics for 10<sup>8</sup> cycles. In addition, similar transfer characteristic with counterclockwise hysteresis was observed in m-TFT device with the effective channel area of 0.2 m<sup>2</sup> (length/width, 20 nm/10 m). These results indicate that fabrication processes using our integration strategies are compatible with 3D structured devices with a large memory window and excellent endurance characteristics. 

We simulated the vertical FeTFT array using Technology ComputerAided Design (TCAD) tool (Fig. 5A). Before FeTFT simulation, we first simulated _P-E_ characteristics of a ferroelectric capacitor using 24-nm-thick HfZrO _x_ and compared with experimental results (fig. S10) ( _55_ , _56_ ). TiN was used for both top and bottom electrodes; saturation polarization, remnant polarization, coercive electric field, and LandauKhalatnikov parameters of the HfZrO _x_ were extracted from the experimental data ( _55_ , _57_ ). The simulated _P-E_ hysteresis was similar to the experimental result, which indicated that the ferroelectric characteristics could be properly simulated using the TCAD tool. The materials and their thicknesses were set by reference to the experimental results (Fig. 5B). Positive (5 V, 100 s) and negative (−5 V, 100 s) pulses were applied to the m-TFT gate electrode (i.e., selected cell) for program and erase operation while applying _V_ pass = 1 V to unselected gate electrodes. The polarization in HfZrO _x_ layer was clearly changed after program and erase operation (Fig. 5, C and D). Last, _V_ G sweep from −3.5 to 2 V was applied to fabricated and simulated vertical FeTFT arrays after program and erase operation (Fig. 5E). Experimental and simulated results showed similar program and erase characteristics. The results confirmed that the electrical characteristics and operation of FeTFTs could be properly simulated using the TCAD tool. 

### **Device simulation of 3D FeNAND** 

To estimate the feasibility of FeTFTs based on HfZrO _x_ and InZnO _x_ in future 3D FeNAND, we simulated a single string that contained 16 WLs, a string select line, and a ground select line (Fig. 6A) 

**5 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



<!-- Start of picture text -->
A<br>B C<br>100 µm<br>−1<br>D E F<br>0<br>10−9<br>Pulse amplitude<br>−1 4 V<br>5 V −2<br>6 V<br>−2<br>10−10<br>V G (V) −3 10−7 10−6 10−5 10−4 10−3 −3 100 102 104 106 108<br>Pulse width (s) Pulse cycles<br> (A) I DS  (V) V th  (V) V th<br><!-- End of picture text -->

**Fig. 4. Nanoscale vertical FeTFT array.** ( **A** ) Fabrication process flow for vertical FeTFT array. ( **B** ) Optical image of the vertical FeTFT device array. S and D stand for source and drain, respectively. ( **C** ) Cross-sectional scanning electron microscope image (false colors) of the vertical FeTFT array. ( **D** ) Transfer curve of m-TFT with counterclockwise hysteresis. For characterization, _V_ G sweep is applied to m-TFT gate electrode, while _V_ pass = 1 V is applied to unselected gate electrodes. ( **E** ) _V_ th change of m-TFT device according to program pulse amplitudes and widths. ( **F** ) Endurance characteristics of m-TFT device for 10<sup>8</sup> cycles using positive (6 V, 1 s) and negative (−7 V, 1 s) triangular pulses for program and erase operations, respectively. 



<!-- Start of picture text -->
A B Material Thickness<br>SiO insulator<br>m-TFT gate TiN<br>Ferroelectric HfZrO x<br>InZnO x  channel<br>C D E<br>Experiment (PGM)<br>2 × 10–9 Experiment (ERS)Simulation (PGM)<br>Simulation (ERS )<br>10–9<br>–3 –2 –1 0 1 2<br>V G (V)<br> (A) I DS<br><!-- End of picture text -->

**Fig. 5. Device simulation of vertical FeTFT array.** ( **A** ) Device structure of simulated vertical FeTFT array. ( **B** ) Materials and their thicknesses used for simulation. ( **C** ) Magnified image of the vertical FeTFT array. ( **D** ) Simulated polarization in HfZrO _x_ layer at programmed and erased states. For program and erase operations, voltage pulses (5 V, 100 s) and (−5 V, 100 s) are applied to the m-TFT gate, respectively. Polarization in the HfZrO _x_ layer is clearly changed after program and erase operations. ( **E** ) Experimental and simulated _I_ DS- _V_ G curves of the m-TFT at programmed and erased state. 

( _58_ , _59_ ). The single string of 3D FeNAND was fabricated using the gate-last process, which is similar to terabit cell array transistors (fig. S11) ( _5_ , _60_ ). First, nitride and oxide layers were sequentially deposited on the p-type (100) Si substrate in which n-well, p-well, and source were formed by implantation of phosphorous of 10<sup>13</sup> 

cm<sup>−3</sup> , boron of 10<sup>13</sup> cm<sup>−3</sup> , and arsenic of 10<sup>16</sup> cm<sup>−3</sup> , respectively. A channel hole with a radius of 80 nm was etched; a 10-nm-thick oxide semiconductor channel was deposited, and the channel hole was filled with SiO2 (i.e., filler material). Nitride layers were etched, and 24-nm-thick HfZrO _x_ was deposited. Last, TiN WLs and Mo BLs 

**6 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 6. Device simulation of 3D FeNAND.** ( **A** ) Device structure of simulated 3D FeNAND. A single string containing 16 WLs, ground select line (GSL), and string select line (SSL) is simulated. The 30-nm-thick TiN, 24-nm-thick HfZrO _x_ , and 10-nm-thick InZnO _x_ are used as WL, ferroelectric gate insulator, and oxide semiconductor channel, respectively. SiO2 is used as oxide filler material. The thickness of SiO2 spacer between adjacent WLs is 30 nm. ( **B** ) Simulated polarization in HfZrO _x_ layer after block-erase and program operations. First, all WLs are erased by block-erase operation. Then, WL11 and WL13 cells are programmed. Last, WL12 cell is programmed. Polarization in HfZrO _x_ layer is clearly changed after block-erase and program operations. ( **C** ) Polarization change after block-erase and program operations. a.u., arbitrary units. ( **D** ) _I_ BL- _V_ WL curves in WL12 cell after block-erase and program operations. 

were deposited. In our suggested 3D FeNAND, 30-nm-thick TiN, 24-nm-thick HfZrO _x_ , 10-nm-thick InZnO _x_ , and Mo were used as WL, ferroelectric gate insulator, oxide semiconductor channel, and BL, respectively, and the thickness of the SiO2 spacer between adjacent WLs was 30 nm. To observe the operation characteristics of the 3D FeNAND, block-erase and program operations were performed (Fig. 6, B and C). First, all WLs were block-erased by applying a voltage pulse (10 V, 10 s) to the substrate. Then, WL11 and WL13 cells were sequentially programmed by applying a voltage pulse (4 V, 1 s) to the selected WLs. After programming WL11 and WL13 cells, WL12 cell was programmed using the same method. The polarization in the HfZrO _x_ layer was clearly changed after block-erase and program operations. In addition, the polarization state in WL12 was not changed after programming WL11 and WL13; this result indicated that adjacent cells caused no noticeable disturbance. Last, _V_ WL sweep from −3 to 1 V was done to WL12 after block-erase and program operations (Fig. 6D). The _I_ BL- _V_ WL characteristics of WL12 were not changed after programming adjacent cells (i.e., WL11 and WL13), and it was clearly switched to programmed state after programming WL12. In addition, 3D FeNAND with a higher number of stacked cells was simulated using TCAD tool. The number of stacked cells was 32, 64, and 128 (fig. S12). The electrical characteristics of 3D FeNAND were characterized using the same program and block-erase operation method discussed above. All 3D FeNANDs were successfully programmed and block-erased using above voltage pulses, and the memory window was not significantly affected by the number of stacked cells, which confirmed that the 3D FeNAND could be operated with highly stacked structures. These 

results indicated that the suggested 3D FeNAND composed of FeTFTs with low power consumption and fast operation speed could replace 3D NAND flash memory. 

#### **DISCUSSION** 

We demonstrated a combination of ferroelectric HfZrO _x_ and InZnO _x_ oxide semiconductor channel as unique integration strategies to solve the key issues in ferroelectric memory transistors. The devices were fabricated using CMOS-compatible processes at low processing temperature (400°C) and showed fast operation speed (<10<sup>−6</sup> s), low operation voltage (<5 V), and excellent endurance (>10<sup>8</sup> cycles), which were achieved by the synergistic effect of ferroelectric HfZrO _x_ and InZnO _x_ oxide semiconductor. We also investigated the potential of our ferroelectric memory as an alternative to conventional flash memory using an integrated FeNAND and a vertical FeTFT array. In FeNAND, the program disturbance was minimized by using the program-inhibit operation method. In program-inhibit operation, the polarization switching of ferroelectric layer was hindered by decreasing the difference in voltage between gate and channel. The states of memory cells in NAND strings were successfully confirmed by nondestructive read operation. The _I_ readout for erased and programmed FeTFT memory cells exhibited distinguishable programmed and erased states. In addition, the string- and page-level NAND operations were demonstrated using the FeNAND array. Only the memory string that had all programmed cells showed the on state; when even one cell was erased, the string showed the off state. Vertical FeTFT array was fabricated by vertically stacking the 

**7 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

TiN gate electrode and SiO2 insulating layer to investigate its feasibility for 3D FeNAND. We verified that the FeTFTs could be operated in the vertical structure, and operation mechanism was confirmed using the device simulation. Last, the possibility of ultrahigh- density 3D memory integration was confirmed by simulating program and block-erase operation in 3D FeNAND cells. These results suggest that ALD-based FeTFTs have the potential in future high-density 3D memory applications. 

#### **MATERIALS AND METHODS** 

(outer square regions) was poled by application of −6 V at a scan rate of 0.5 Hz; then, 1.5 m by 1.5 m (inner square regions) was scanned by application of 6 V at a scan rate of 0.5 Hz. After that, the reading process was performed over an area of 3 m by 3 m to verify the polarization states. The _C-V_ curve was measured using an impedance analyzer (4194A, HP). Optical images of the devices were captured using an optical microscope (LV100ND, Nikon). The cross-sectional images of the devices were obtained using a high-resolution field-emission scanning electron microscope (JSM7800F PRIME, JEOL). Simulations were conducted using Sentaurus TCAD (Synopsys Inc.) software. 

### **Materials** 

Hf[N(C2H5)CH3]4 [tetrakis(ethylmethylamido)hafnium (TEMAH)] and Zr[N(C2H5)CH3]4 [tetrakis(ethylmethylamido)zirconium (TEMAZ)] were purchased from UP Chemical, Korea. C10H28NSi2In4 [bis(trimethysilyl)amidodiethyl indium (INCA-1)] and Zn(C2H5)2 [diethylzinc (DEZ)] were purchased from iChems, Korea. Si wafers with 100-nm-thick thermally grown SiO2 were used as substrates. 

### **Device fabrication** 

The devices were fabricated on the SiO2/Si substrate. The photolithography was done using a mask aligner (MA6, Suss MicroTec). An FeNAND array was fabricated by integrating FeTFTs. First, DC sputtering was used to deposit TiN on the SiO2/Si substrate as the gate electrode for FeTFT and as WLs for FeNAND. The TiN layer was patterned using a lift-off method. Then, 24-nm-thick HfZrO _x_ film was deposited on the TiN/SiO2/Si by alternating ALD cycles of HfO2:ZrO2 at 280°C, using TEMAH, TEMAZ, and O3 as the Hf precursor, Zr precursor, and oxygen source, respectively. Electron beam evaporation was used to deposit Mo as source/drain electrodes for FeTFTs and as SL/BLs for FeNAND. The Mo layer was patterned using a lift-off method. A layer of 20-nm-thick InZnO _x_ film was deposited at 150°C using INCA-1, DEZ, and O3 as an indium precursor, zinc precursor, and oxygen source, respectively. The InZnO _x_ layer was patterned using a combination of lithography and wet etching. The channel length and width were 10 and 50 m, respectively. Then, the devices were thermally annealed for 10 min at 400°C under N2 environment. Etching process was done to open the contacts for WLs. For the vertical FeTFT array, 100-nm-thick TiN and 50-nm-thick SiO2 layers were sequentially deposited using sputtering and plasma-enhanced chemical vapor deposition, respectively. TiN/SiO2/TiN/SiO2/TiN layers were etched by dry etch (NE-7800, ULVAC) using sulfur hexafluoride (SF6) plasma. The 24-nm-thick HfZrO _x_ layer, 20-nm-thick InZnO _x_ channel layer, and Mo source/drain electrodes were deposited using the same method described above. 

### **Characterizations** 

All electrical properties were measured under ambient conditions and at room temperature. The electrical characteristics were obtained using a semiconductor parameter analyzer (4200A-SCS, Keithley Instruments). The ferroelectric characteristics were measured after applying 10<sup>3</sup> cycles of rectangular bipolar pulses (±7.2 V, 5 s) for the wake-up of HfZrO _x_ (fig. S1). The _P-E_ curves were measured using a pulse measurement unit (4225-PMU, Keithley Instruments). PFM images were obtained using a scanning probe microscopy system (NX10, Park Systems). For PFM measurement, a cantilever that had a Pt-coated conductive tip was used to apply voltages to the sample, and the bottom electrode was grounded. An area of 2.5 m by 2.5 m 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/3/eabe1341/DC1 

### **REFERENCES AND NOTES** 

1. S. J. Whang, K. H. Lee, D. G. Shin, B. Y. Kim, M. S. Kim, J. H. Bin, J. H. Han, S. J. Kim, B. M. Lee, Y. K. Jung, S. Y. Cho, C. H. Shin, H. S. Yoo, S. M. Choi, K. Hong, S. Aritome, S. K. Park, S. J. Hong, Novel 3-dimensional dual control-gate with surrounding floating-gate (DC-SF) NAND flash cell for 1 Tb file storage application, in _2010 IEEE International Electron Devices Meeting (IEDM)_ (IEEE, 2010), pp. 29.7.1-29.7.4. 

2. C. Kim, D. Kim, W. Jeong, H. Kim, I. H. Park, H. Park, J. Lee, J. Park, Y. Ahn, J. Y. Lee, S. Kim, H. Yoon, J. D. Yu, N. Choi, N. Kim, H. Jang, J. Park, S. Song, Y. Park, J. Bang, S. Hong, Y. Choi, M. Kim, H. Kim, P. Kwak, J. Ihm, D. S. Byeon, J. Lee, K. Park, K. Kyung, A 512-Gb 3-b/Cell 64-stacked WL 3-D-NAND flash memory. _IEEE J. Solid-State Circuits_ **53** , 124–133 (2018). 

3. C.-H. Lee, S.-H. Hur, Y.-C. Shin, J.-H. Choi, D.-G. Park, K. Kim, Charge-trapping device structure of SiO2∕SiN∕high- _k_ dielectric Al2O3 for high-density flash memory. _Appl. Phys. Lett._ **86** , 152908 (2005). 

4. W. He, J. Pu, D. S. H. Chan, B. J. Cho, Performance improvement in charge-trap flash memory using lanthanum-based high- blocking oxide. _IEEE Trans. Electron Devices_ **56** , 2746–2751 (2009). 

5. J. Jang, H.-S. Kim, W. Cho, H. Cho, J. Kim, S. I. Shim, Y. Jang, J. Jeong, B. Son, D. W. Kim, K. Kim, J. Shim, J. S. Lim, K. Kim, S. Y. Yi, J. Lim, D. Chung, H.-C. Moon, S. Hwang, J.-W. Lee, Y.-H. Son, U. Chung, W.-S. Lee, Vertical cell array using TCAT (Terabit Cell Array Transistor) technology for ultra high density NAND flash memory, in _2009 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2009), pp. 192–193. 

6. S. Spiga, F. Driussi, A. Lamperti, G. Congedo, O. Salicio, Effects of thermal treatments on the trapping properties of HfO2 films for charge trap memories. _Appl. Phys. Express_ **5** , 021102 (2012). 

7. S. B. Hong, J. H. Park, T. H. Lee, J. H. Lim, C. Shin, Y. W. Park, T. G. Kim, Variation of poly-Si grain structures under thermal annealing and its effect on the performance of TiN/Al2O3/ Si3N4/SiO2/poly-Si capacitors. _Appl. Surf. Sci._ **477** , 104–110 (2019). 

8. J. S. Meena, S. M. Sze, U. Chand, T.-Y. Tseng, Overview of emerging nonvolatile memory technologies. _Nanoscale Res. Lett._ **9** , 526 (2014). 

9. F. Pan, S. Gao, C. Chen, C. Song, F. Zeng, Recent progress in resistive random access memories: Materials, switching mechanisms, and performance. _Mater. Sci. Eng. R Rep._ **83** , 1–59 (2014). 

10. S. Yu, P. Chen, Emerging memory technologies: Recent trends and prospects. _IEEE Solid-State Circuits Mag._ **8** , 43–56 (2016). 

11. X. Zhang, K. Miyaji, M. Takahashi, K. Takeuchi, S. Sakai, 0.5V bit-line-voltage self-boostprogramming in ferroelectric-NAND flash memory, in _2011 IEEE International Memory Workshop (IMW)_ (IEEE, 2011), pp. 1–4. 

12. X. Zhang, M. Takahashi, K. Takeuchi, S. Sakai, 64 kbit ferroelectric-gate-transistorintegrated NAND flash memory with 7.5 V program and long data retention. _Jpn. J. Appl. Phys._ **51** , 04DD01 (2012). 

13. Y. Kaneko, Y. Nishitani, H. Tanaka, M. Ueda, Y. Kato, E. Tokumitsu, E. Fujii, Correlated motion dynamics of electron channels and domain walls in a ferroelectric-gate thin-film transistor consisting of a ZnO/Pb(Zr,Ti)O3 stacked structure. _J. Appl. Phys._ **110** , 084106 (2011). 

14. K. Takahashi, K. Aizawa, B.-E. Park, H. Ishiwara, Thirty-day-long data retention in ferroelectric-gate field-effect transistors with HfO2 buffer layers. _Jpn. J. Appl. Phys._ **44** , 6218–6220 (2005). 

15. T. Fukushima, T. Yoshimura, K. Masuko, K. Maeda, A. Ashida, N. Fujimura, Electrical characteristics of controlled-polarization-type ferroelectric-gate field-effect transistor. _Jpn. J. Appl. Phys._ **47** , 8874–8879 (2008). 

16. T. Horiuchi, M. Takahashi, K. Ohhashi, S. Sakai, Memory window widening of Pt/SrBi2Ta2O9/HfO2/Si ferroelectric-gate field-effect transistors by nitriding Si. _Semicond. Sci. Technol._ **24** , 105026 (2009). 

**8 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

17. M. T. Do, N. Gauquelin, M. D. Nguyen, J. Wang, J. Verbeeck, F. Blom, G. Koster, E. P. Houwman, G. Rijnders, Interfacial dielectric layer as an origin of polarization fatigue in ferroelectric capacitors. _Sci. Rep._ **10** , 7310 (2020). 

18. E. Yurchuk, J. Müller, J. Paul, T. Schlösser, D. Martin, R. Hoffmann, S. Müeller, S. Slesazeck, U. Schröeder, R. Boschke, R. V. Bentum, T. Mikolajick, Impact of scaling on the performance of HfO2-based ferroelectric field effect transistors. _IEEE Trans. Electron Devices_ **61** , 3699–3706 (2014). 

19. S. J. Kim, J. Mohan, S. R. Summerfelt, J. Kim, Ferroelectric Hf0.5Zr0.5O2 thin films: A review of recent advances. _JOM_ **71** , 246–255 (2019). 

20. S. S. Cheema, D. Kwon, N. Shanker, R. dos Reis, S.-L. Hsu, J. Xiao, H. Zhang, R. Wagner, A. Datar, M. R. McCarter, C. R. Serrao, A. K. Yadav, G. Karbasian, C.-H. Hsu, A. J. Tan, L.-C. Wang, V. Thakare, X. Zhang, A. Mehta, E. Karapetrova, R. V. Chopdekar, P. Shafer, 

   - E. Arenholz, C. Hu, R. Proksch, R. Ramesh, J. Ciston, S. Salahuddin, Enhanced 

   - ferroelectricity in ultrathin films grown directly on silicon. _Nature_ **580** , 478–482 (2020). 

21. Y. Li, R. Liang, J. Wang, Y. Zhang, H. Tian, H. Liu, S. Li, W. Mao, Y. Pang, Y. Li, Y. Yang, T. L. Ren, A ferroelectric thin film transistor based on annealing-free HfZrO film. _IEEE J. Electron Devices Soc._ **5** , 378–383 (2017). 

22. F. Mo, Y. Tagawa, C. Jin, M. Ahn, T. Saraya, T. Hiramoto, M. Kobayashi, Experimental demonstration of ferroelectric HfO2 FET with ultrathin-body IGZO for high-density and low-power memory application, in _2019 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2019), pp. T42-T43. 

23. K. Chatterjee, S. Kim, G. Karbasian, D. Kwon, A. J. Tan, A. K. Yadav, C. R. Serrao, C. Hu, S. Salahuddin, Challenges to partial switching of Hf0.8Zr0.2O2 gated ferroelectric FET for multilevel/analog or low-voltage memory operation. _IEEE Electron Device Lett._ **40** , 1423–1426 (2019). 

24. D. Kwon, S. Cheema, N. Shanker, K. Chatterjee, Y. Liao, A. J. Tan, C. Hu, S. Salahuddin, Negative capacitance FET with 1.8-nm-thick Zr-doped HfO2 oxide. _IEEE Electron Device Lett._ **40** , 993–996 (2019). 

25. Y. Goh, S. Jeon, Enhanced tunneling electroresistance effects in HfZrO-based ferroelectric tunnel junctions by high-pressure nitrogen annealing. _Appl. Phys. Lett._ **113** , 052905 (2018). 

26. M.-K. Kim, J.-S. Lee, Ferroelectric analog synaptic transistors. _Nano Lett._ **19** , 2044–2050 (2019). 

27. K. Florent, S. Lavizzari, L. D. Piazza, M. Popovici, E. Vecchio, G. Potoms, G. Groeseneken, J. V. Houdt, First demonstration of vertically stacked ferroelectric Al doped HfO2 devices for NAND applications, in _2017 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2017), pp. T158-T159. 

28. K. Florent, M. Pesic, A. Subirats, K. Banerjee, S. Lavizzari, A. Arreghini, L. D. Piazza, G. Potoms, F. Sebaai, S. R. C. McMitchell, M. Popovici, G. Groeseneken, J. V. Houdt, Vertical ferroelectric HfO2 FET based on 3-D NAND architecture: Towards dense low-power memory, in _2018 IEEE International Electron Devices Meeting (IEDM)_ (IEEE, 2018), pp. 2.5.1–2.5.4. 

29. K. Ni, P. Sharma, J. Zhang, M. Jerry, J. A. Smith, K. Tapily, R. Clark, S. Mahapatra, S. Datta, Critical role of interlayer in Hf0.5Zr0.5O2 ferroelectric FET nonvolatile memory performance. _IEEE Trans. Electron Devices_ **65** , 2461–2469 (2018). 

30. H. Tanaka, M. Kido, K. Yahashi, M. Oomura, R. Katsumata, M. Kito, Y. Fukuzumi, M. Sato, Y. Nagata, Y. Matsuoka, Y. Iwata, H. Aochi, A. Nitayama, Bit cost scalable technology with punch and plug process for ultra high density flash memory, in _2007 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2007), pp. 14–15. 

31. T. Ali, P. Polakowski, S. Riedel, T. Büttner, T. Kämpfe, M. Rudolph, B. Pätzold, K. Seidel, D. Löhr, R. Hoffmann, M. Czernohorsky, K. Kühnel, P. Steinke, J. Calvo, K. Zimmermann, J. Müller, High endurance ferroelectric hafnium oxide-based FeFET memory without retention penalty. _IEEE Trans. Electron Devices_ **65** , 3769–3774 (2018). 

32. M. V. Fischetti, D. A. Neumayer, E. A. Cartier, Effective electron mobility in Si inversion layers in metal–oxide–semiconductor systems with a high- insulator: The role of remote phonon scattering. _J. Appl. Phys._ **90** , 4587–4608 (2001). 

33. R. Shah, M. M. D. Souza, Impact of a nonideal metal gate on surface optical phononlimited mobility in high- gated MOSFETs. _IEEE Trans. Electron Devices_ **54** , 2991–2997 (2007). 

34. C. Y. Han, Y. X. Ma, W. M. Tang, X. L. Wang, P. T. Lai, A study on pentacene organic thin-film transistor with different gate materials on various substrates. _IEEE Electron Device Lett._ **38** , 744–747 (2017). 

35. J. Sheng, H.-J. Lee, S. Oh, J.-S. Park, Flexible and high-performance amorphous indium zinc oxide thin-film transistor using low-temperature atomic layer deposition. _ACS Appl. Mater. Interfaces_ **8** , 33821–33828 (2016). 

36. A. Ortiz-Conde, F. J. García-Sánchez, J. J. Liou, A. Cerdeira, M. Estrada, Y. Yue, A review of recent MOSFET threshold voltage extraction methods. _Microelectron. Reliab._ **42** , 583–596 (2002). 

37. C. Lee, J. Choi, C. Kang, Y. Shin, J. Lee, J. Sel, J. Sim, S. Jeon, B. Choe, D. Bae, K. Park, K. Kim, Multi-level NAND flash memory with 63 nm-Node TANOS (Si-Oxide-SiN-Al2O3-TaN) cell structure, in _2006 IEEE Symposium on VLSI Technology (VLSIT), 2006. Digest of Technical Papers_ (IEEE, 2006), pp. 21–22. 

38. R. Katsumata, M. Kito, Y. Fukuzumi, M. Kido, H. Tanaka, Y. Komori, M. Ishiduki, J. Matsunami, T. Fujiwara, Y. Nagata, L. Zhang, Y. Iwata, R. Kirisawa, H. Aochi, A. Nitayama, Pipe-shape BiCS flash memory with 16 stacked layers and multi-level-cell operation for ultra high density storage devices, in _2009 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2009), pp. 136–137. 

39. Y. Nishitani, Y. Kaneko, M. Ueda, T. Morie, E. Fujii, Three-terminal ferroelectric synapse device with concurrent learning function for artificial neural networks. _J. Appl. Phys._ **111** , 124108 (2012). 

40. Y. Nishitani, Y. Kaneko, M. Ueda, E. Fujii, A. Tsujimura, Dynamic observation of brain-like learning in a ferroelectric synapse device. _Jpn. J. Appl. Phys._ **52** , 04CE06 (2013). 

41. Y. Komori, M. Kido, M. Kito, R. Katsumata, Y. Fukuzumi, H. Tanaka, Y. Nagata, M. Ishiduki, H. Aochi, A. Nitayama, Disturbless flash memory due to high boost efficiency on BiCS structure and optimal memory film stack for ultra high density storage device, in _2008 IEEE International Electron Devices Meeting (IEDM)_ (IEEE, 2008), pp. 1–4. 

42. S. Wang, H. Lue, T. Hsu, P. Du, S. Lai, Y. Hsiao, S. Hong, M. Wu, F. Hsu, N. Lian, C. Lu, J. Hsieh, L. Yang, T. Yang, K. Chen, K. Hsieh, _C. Lu_ , A high-endurance (>100k) BE-SONOS NAND flash with a robust nitrided tunnel oxide/Si interface, in _2010 IEEE International Reliability Physics Symposium (IRPS)_ (IEEE, 2010), pp. 951–955. 

43. K. Florent, S. Lavizzari, M. Popovici, L. D. Piazza, U. Celano, G. Groeseneken, J. V. Houdt, Understanding ferroelectric Al:HfO2 thin films with Si-based electrodes for 3D applications. _J. Appl. Phys._ **121** , 204103 (2017). 

44. M. H. Lee, C. Y. Kuo, C.-H. Tang, H.-H. Chen, C.-Y. Liao, R.-C. Hong, S.-S. Gu, Y.-C. Chou, Z.-Y. Wang, S.-Y. Chen, P. Chen, M. Liao, K. Li, Ferroelectric characteristics of ultra-thin Hf1-xZrxO2 gate stack and 1T memory operation applications, in _2018 IEEE Electron Devices Technology and Manufacturing Conference (EDTM)_ (IEEE, 2018), pp. 271–273. 

45. Y. Q. Wang, W. S. Hwang, G. Zhang, G. Samudra, Y. Yeo, W. J. Yoo, Electrical characteristics of memory devices with a high- _k_ HfO2 trapping layer and dual SiO2/Si3N4 tunneling layer. _IEEE Trans. Electron Devices_ **54** , 2699–2705 (2007). 

46. G. V. d. Bosch, L. Breuil, A. Cacciato, A. Rothschild, M. Jurczak, J. V. Houdt, Investigation of window instability in program/erase cycling of TANOS NAND flash memory, in _2009 IEEE International Memory Workshop (IMW)_ (IEEE, 2009), pp. 1–2. 

47. B. Tsui, J. Lai, A study on poly-Si thin-film transistor (TFT) SONOS memory cells with source/drain engineering, in _2011 Proceedings of the European Solid-State Device Research Conference (ESSDERC)_ (IEEE, 2011), pp. 199–202. 

48. K. Yan, M. Takahashi, S. Sakai, Electrical properties of ferroelectric-gate FETs with SrBi2Ta2O9 formed using MOCVD technique. _Appl. Phys. A_ **108** , 835–842 (2012). 

49. W. Zhang, M. Takahashi, Y. Sasaki, M. Kusuhara, S. Sakai, 3.3 V write-voltage Ir/ Ca0.2Sr0.8Bi2Ta2O9/HfO2/Si ferroelectric-gate field-effect transistors with 10<sup>9</sup> endurance and good retention. _Jpn. J. Appl. Phys._ **56** , 04CE04 (2017). 

50. J. Müller, E. Yurchuk, T. Schlösser, J. Paul, R. Hoffmann, S. Müller, D. Martin, S. Slesazeck, P. Polakowski, J. Sundqvist, M. Czernohorsky, K. Seidel, P. Kücher, R. Boschke, M. Trentzsch, K. Gebauer, U. Schröder, T. Mikolajick, Ferroelectricity in HfO2 enables nonvolatile data storage in 28 nm HKMG, in _2012 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2012), pp. 25–26. 

51. T. Ali, P. Polakowski, K. Kühnel, M. Czernohorsky, T. Kämpfe, M. Rudolph, B. Pätzold, D. Lehninger, F. Müller, R. Olivo, M. Lederer, R. Hoffmann, P. Steinke, K. Zimmermann, U. Mühle, K. Seidel, J. Müller, A multilevel FeFET memory device based on laminated HSO and HZO ferroelectric layers for high-density storage, in _2019 IEEE International Electron Devices Meeting (IEDM)_ (IEEE, 2019), pp. 28.27.21–28.27.24. 

52. S. Wang, M. Takahashi, Q.-H. Li, K. Takeuchi, S. Sakai, Operational method of a ferroelectric (Fe)-NAND flash memory array. _Semicond. Sci. Technol._ **24** , 105029 (2009). 

53. P. Wang, Z. Wang, W. Shim, J. Hur, S. Datta, A. I. Khan, S. Yu, Drain–erase scheme in ferroelectric field-effect transistor—Part I: Device characterization. _IEEE Trans. Electron Devices_ **67** , 955–961 (2020). 

54. T. Hatanaka, M. Takahashi, S. Sakai, K. Takeuchi, A zero VTH meory cell ferroelectric-NAND flash memory with 32% read disturb, 24% program distrub, 10% data retention improvement for enterprise SSD, in _2009 Proceedings of the European Solid State Device Research Conference (ESSDERC)_ (IEEE, 2009), pp. 225–228. 

55. K. Jang, N. Ueyama, M. Kobayashi, T. Hiramoto, Experimental observation and simulation model for transient characteristics of negative-capacitance in ferroelectric HfZrO2 capacitor. _IEEE J. Electron Devices Soc._ **6** , 346–353 (2018). 

56. S. K. Thirumala, S. K. Gupta, Reconfigurable ferroelectric transistor—Part I: Device design and operation. _IEEE Trans. Electron Devices_ **66** , 2771–2779 (2019). 

57. M. Kobayashi, N. Ueyama, K. Jang, T. Hiramoto, Experimental study on polarization-limited operation speed of negative capacitance FET with ferroelectric HfO2, in _2016 IEEE International Electron Devices Meeting (IEDM)_ (2016), pp. 12.13.11–12.13.14. 

58. A. Saeidi, A. Biswas, A. M. Ionescu, Modeling and simulation of low power ferroelectric non-volatile memory tunnel field effect transistors using silicon-doped hafnium oxide as gate dielectric. _Solid-State Electron._ **124** , 16–23 (2016). 

59. H. Mehta, H. Kaur, Modeling and simulation study of novel Double Gate Ferroelectric Junctionless (DGFJL) transistor. _Superlattices Microstruct._ **97** , 536–547 (2016). 

**9 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

60. W. Cho, S. I. Shim, J. Jang, H. Cho, B. You, B. Son, K. Kim, J. Shim, C. Park, J. Lim, K. Kim, D. Chung, J. Lim, H. Moon, S. Hwang, H. Lim, H. Kim, J. Choi, C. Chung, Highly reliable vertical NAND technology with biconcave shaped storage layer and leakage controllable offset structure, in _2010 IEEE Symposium on VLSI Technology (VLSIT)_ (IEEE, 2010), pp. 173–174. 

##### **Acknowledgments** 

**Funding:** This work was supported by Samsung Research Funding and Incubation Center of Samsung Electronics under project no. SRFC-TA1903-05. The Sentaurus TCAD simulator was provided by the Electronic Design Automation (EDA) tool program of IC Design Education Center (IDEC) in Korea. **Author contributions:** J.-S.L. conceived and directed the research. J.-S.L., M.-K.K., and I.-J.K. designed and planned the experiment, analyzed the data, and wrote the manuscript. M.-K.K. and I.-J.K. performed the experiment and acquired the data. 

**Competing interests:** The authors declare that they have no competing interests. **Data and materials availability** : All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from the authors. 

Submitted 2 August 2020 Accepted 20 November 2020 Published 13 January 2021 10.1126/sciadv.abe1341 

**Citation:** M.-K. Kim, I.-J. Kim, J.-S. Lee, CMOS-compatible ferroelectric NAND flash memory for high-density, low-power, and high-speed three-dimensional memory. _Sci. Adv._ **7** , eabe1341 (2021). 

**10 of 10** 

Kim _et al_ ., _Sci. Adv._ 2021; **7** : eabe1341     13 January 2021 



## **CMOS-compatible ferroelectric NAND flash memory for high-density, low-power, and high-speed three-dimensional memory** Min-Kyu Kim, Ik-Jyae Kim, and Jang-Sik Lee 

_Sci. Adv._ **7** (3), eabe1341.  DOI: 10.1126/sciadv.abe1341 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abe1341 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

> _Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

