# An In‐Depth Investigation of the Combined Optoelectronic and Photovoltaic Properties of Lead‐Free Cs2AgBiBr6 Double Perovskite Solar Cells Using DFT and SCAPS‐1D Frameworks

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Electronic Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 235 |
| 作者 | M. Shihab Uddin, M. K. Hossain, Md Borhan Uddin, Gazi F. I. Toki, Mohamed Ouladsmane, M. H. K. Rubel, D. Tishkevich, P. Sasikumar et al. |
| DOI | 10.1002/aelm.202300751 |
| 源文件 | 035_Uddin_2024_An-InDepth-Investigation-of-the-Combined-Optoele.pdf |

---
**RESEARCH ARTICLE** 



**www.advelectronicmat.de** 

# **An In-Depth Investigation of the Combined Optoelectronic and Photovoltaic Properties of Lead-Free Cs2AgBiBr6 Double Perovskite Solar Cells Using DFT and SCAPS-1D Frameworks** 

_M. Shihab Uddin, M. Khalid Hossain,* Md Borhan Uddin, Gazi F. I. Toki, Mohamed Ouladsmane, Mirza H. K. Rubel,* Daria I. Tishkevich, P. Sasikumar, Rajesh Haldhar,* and Rahul Pandey_ 

**In the backdrop of today’s environmental priorities, where toxicity and stability hinder lead-based perovskite solar cell (PSC) progress, the emergence of lead-free alternatives like Cs2AgBiBr6 perovskites has gained significance. This study revolves around the comprehensive evaluation of Cs2AgBiBr6 as a potential photovoltaic (PV) material, using density functional theory (DFT) calculations with CASTEP. Revealing a vital bandgap of 1.654 eV and emphasizing the contributions of Ag-4** **_d_ and Br-4** **_p_ orbitals, this analysis also underscores Ag atoms’ dominance in charge distribution. Optically, Cs2AgBiBr6 exhibits UV absorption peaks around 15 eV, intensifying with photon energy up to 3.75 eV, hinting at its promise for solar applications. Guided by DFT, forty configurations involving various electron transport layers (ETLs) and hole transport layers (HTLs) are explored. Among these, CNTS emerges as the prime HTL due to ideal absorber alignment. The spotlight architecture, FTO/AZnO/Cs2AgBiBr6/CNTS/Au, boasts exceptional efficiency (23.5%),** **_V_ oc (1.38 V),** **_J_ sc (21.38 mA cm**<sup>**−2**</sup> **), and FF (79.9%). In contrast, FTO/CdZnS/Cs2AgBiBr6/CNTS/Au achieves a slightly lower 23.15% efficiency. Real-world intricacies are probed, encompassing resistances, temperature, current–voltage (** **_J_ –** **_V_ ) traits, and quantum efficiency (QE), enhancing practical relevance. These findings are thoughtfully contextualized within prior literature, showcasing the study’s contributions to non-toxic, inorganic perovskite solar technology. This work aspires to positively steer sustainable PV advancement.** 

## **1. Introduction** 

Perovskite solar cells (PSCs) have gained considerable attention in response to the rapid progress in solar technology,<sup>[1–8]</sup> as seen by the notable enhancement in efficiency from a modest 3.8% to 25.7% over the course of a decade.<sup>[9–13]</sup> This incredible enhancement was made likely by the halide perovskite materials’ superior photo-electronic properties, which include their higher absorption coefficient, long-range charge diffusion lengths, low exciton binding energies, adequate bandgaps, and higher charge carrier mobility.<sup>[10,11,13–16]</sup> In general, leadbased PSCs yield better efficiency.<sup>[17–20]</sup> Lead-based cells, however, have several problems, like performance declines when exposed to moisture and light, and a major problem is lead toxicity which is thought to be a significant barrier to the commercialization of such cells.<sup>[21–23]</sup> Other additives with the same group of lead (Pb) were thoroughly explored in order to address the existing deficit brought on by the presence of Pb in PSCs 

M. S. Uddin Department of Electrical and Electronic Engineering Islamic University Kushtia 7000, Bangladesh 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aelm.202300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

M. K. Hossain Institute of Electronics Atomic Energy Research Establishment Bangladesh Atomic Energy Commission Dhaka 1349, Bangladesh E-mail: khalid.baec@gmail.com, khalid@kyudai.jp M.K.Hossain Department of AdvancedEnergy Engineering Science Interdisciplinary GraduateSchool of Engineering Sciences Kyushu University Fukuoka 816-8580, Japan 

### **DOI: 10.1002/aelm.202300751** 

**2300751 (1 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

including tin (Sn) and germanium (Ge).<sup>[24–26]</sup> But Tin-based SCs have some disadvantages of being oxidized from Sn<sup>2+</sup> to Sn<sup>4+</sup> when kept open to the air for a long time.<sup>[27]</sup> Because of these insecurities, other PSCs needed to be considered that can replace Pb<sup>2+</sup> ion containing a monovalent and trivalent ion mixed, such as Cs2AgBiBr6,<sup>[28]</sup> Cs2AgBiCl6,<sup>[29]</sup> (MA)2AgBiBr6[30] which are known as double perovskite SCs. Among them, Cs2AgBiBr6 is the most promising structure, in which lead is substituted by silver (Ag<sup>+</sup> ) and bismuth (Bi<sup>3+</sup> ) cations, has been described as having a good crystal structure, a long lifetime of charge carrier, and good stability when compared to lead-based perovskites.<sup>[31]</sup> 

Some experiments have been conducted to improve the features of Cs2AgBiBr6 in recent years. Greul et al. investigated Cs2AgBiBr6 experimentally and got a PCE of 1.66%.<sup>[32]</sup> Another experimental investigation was done by Igbari et al. and ended up getting 2.51% PCE.<sup>[33]</sup> Theoretical investigations were also done by some researchers on Cs2AgBiBr6. Zhang et al. and Alanazi et al. combined SnO2 and Spiro-MeOTAD with Cs2AgBiBr6 and got a PCE of 6.37%<sup>[34]</sup> and 14.29%<sup>[35]</sup> respectively. Islam et al. combined TiO2 and Cu2O with Cs2AgBiBr6 and got a PCE of 7.25%<sup>[36]</sup> while Alkhammash et al. used ZnO and NiO to get a PCE of 21.88%.<sup>[37]</sup> Chabri et al. and his team investigated Cs2AgBiBr6 and got a PCE of 7.16%.<sup>[38]</sup> So, it is noteworthy that further research on Cs2AgBiBr6 is needed to bring out the best possible combination and further improvement of photovoltaic (PV) properties for this PSC. 

Notably, every layer in PSC including fluorine doped tin oxide (FTO), hole transport layer (HTL), electron transport layer (ETL), perovskite absorber layer (PAL), and back metal contact 

|M. B. Uddin, M. H. K. Rubel|
|---|
|Department of Materials Science and Engineering<br>|
|University of Rajshahi<br>|
|Rajshahi 6205, Bangladesh<br>|
|E-mail: mhk_mse@ru.ac.bd|
|G.F.I.Toki<br>|
|Collegeof Materials ScienceandEngineering<br>|
|Donghua University<br>|
|Shanghai 201620,China|
|M.Ouladsmane<br>|
|Department of Chemistry<br>|
|Collegeof Science<br>|
|King SaudUniversity|
|Riyadh 11451,Saudi Arabia|
|D.I.Tishkevich|
|SSPA “Scientific-Practical Materials Research Centreof NAS of Belarus”<br>P.Brovki str.19,Minsk 220072,Belarus|
|P.Sasikumar<br>|
|Department of Physics,Saveetha School of Engineering<br>|
|Saveetha Instituteof Medical andTechnical Sciences (SIMATS)<br>Thandalam, Chennai, Tamil Nadu 602105,India|
|R.Haldhar<br>|
|School of Chemical Engineering|
|Yeungnam University<br>|
|Gyeongsan 38541,Republicof Korea|
|E-mail:rajeshhaldhar.lpu@gmail.com|
|R.Pandey|
|VLSI Centreof Excellence|
|Chitkara University Instituteof Engineering andTechnology<br>Chitkara University<br>|
|Punjab 140401, India|





### **www.advelectronicmat.de** 

(BMC) aids in working the device properly.<sup>[15,39,40]</sup> The movement of charge carriers in PAL is greatly influenced by ETL and HTL in PSC. The most used ETL in PSCs is TiO2 and HTL is Spiro-MeOTAD for its excellent bandgap, charge mobility, and band alignment.<sup>[33,35,41,42]</sup> Due to the continuous improvement of the PSCs, there are some ETLs and HTLs that are not frequently used. Among them aluminum doped zinc oxide (AZnO),<sup>[43]</sup> cadmium zinc oxide (CdZnS),<sup>[44]</sup> La-doped BaSnO3 (LBSO),<sup>[45]</sup> niobium pentoxide (Nb2O5)<sup>[46]</sup> make good band alignments with Cs2AgBiBr6 absorber. In the case of HTLs, copper zinc tin selenide (CZTSe),<sup>[44]</sup> cadmium telluride (CdTe),<sup>[47]</sup> copper nickel tin sulfide (CNTS),<sup>[44]</sup> nitrogen-doped titanium dioxide (TiO2:N),<sup>[48]</sup> poly(triarylamine) (PTAA),<sup>[49]</sup> nickel cobaltite (NiCo2O4),<sup>[50]</sup> antimony sulfide (Sb2S3),<sup>[51]</sup> n-propyl bromide (nPB),<sup>[52]</sup> gallium arsenide (GaAs),<sup>[53]</sup> Zinc telluride (ZnTe)<sup>[54]</sup> makes good band alignment with Cs2AgBiBr6, although they are not used frequently. CNTS emerges as a promising choice for the hole transport layer in perovskite solar cells. Its high hole mobility, favorable energy levels, chemical stability, earth-abundant composition, reduced environmental impact (lead-free), facile synthesis, and tunable properties collectively position CNTS as a potential contributor to the enhanced performance and sustainability of perovskite solar cell technologies.<sup>[44]</sup> 

Interestingly, electronic assets like band structure, bandgap, DOS (density-of-states), electron density mapping, etc. are very important parameters for the exploration of each element’s contributions to electronic properties.<sup>[55]</sup> A significant number of researchers are performing theoretical calculations to understand the physical properties of the DFT (density function theory) method. According to these reports,<sup>[56,57]</sup> a lot of halide perovskite exhibits promising physical properties such as electrical, structural, optical, etc. suit them for photovoltaics and optoelectronic applications. McClure et al.<sup>[29]</sup> and Lei et al.<sup>[58]</sup> reported that Cs2AgBiBr6 has almost similar electronic properties but is more stable and non-toxic compared to organic– inorganic lead halide perovskite absorbers. Some similar compounds such as Cs2AgBiCl6 has a bandgap of 2.77 eV,<sup>[29]</sup> and Cs2AgInCl6 has a bandgap of 3.23 eV<sup>[59]</sup> are less suitable for their relatively higher bandgap. However, this is the first combined DFT and SCAPS-1D study of Cs2AgBiBr6 double perovskite to evaluate optoelectronic properties for solar cell applications. 

In this study, 4 ETLs and 10 HTLs are combined together with Cs2AgBiBr6 PAL to investigate and find the best four structures among 40 combinations. First, DFT is utilized to compute the bandgap of Cs2AgBiBr6 (1.654 eV), and as well as optoelectrical properties are identified. Then SCAPS 1D simulation computer software<sup>[60–62]</sup> is equipped to simulate the structures for calculating performance parameters by employing the bandgap value of the DFT result. After finding the best four combinations among 40 different structures, the effect of absorber and ETL layer thickness on the performance parameters is observed. Furthermore, the effect of series like resistance, shunt, in addition, temperature on PSCs are also investigated. Additionally, the current– voltage density ( _J–V_ ) and quantum efficiency ( _QE_ ) characteristics along with the generation and recombination rates of charge carriers for the PSCs are also shown. Finally, a detailed comparison of experimental and theoretical analysis was studied to validate 

**2300751 (2 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

the outcomes of this study. From the investigation, it is anticipated that the tools will assist academics in looking into a more prevalent arrangement of solar cells based on Cs2AgBiBr6-based PAL. 

In this study, we have introduced and proposed novel ETLs and HTLs to enhance the novelty the our work. Given the extensive research on conventional transport layers like TiO2, SnO2, and Spiro-MeOTAD, among others, opting for these familiar choices would not align with our goal of advancing scientific understanding in this field. These choices were made to address specific performance criteria in our study. The introduction of new transport layers is intended to contribute to the diversification and progression of materials used in perovskite solar cells. Moreover, our considered HTLs offer distinct advantages, CZTSe and CdTe provide cost-effective options, PTAA boasts high hole mobility, NiCo2O4 demonstrates good stability, and Sb2S3 is both cost-effective and earth-abundant. 

## **2. Experimental Section** 

### **2.1. First Principal Calculations of Cs2AgBiBr6 Absorber Layer** 

DFT<sup>[63]</sup> calculations on structure, electronic, and optical characters were done by the CASTEP program. Here, the HSE06 hybrid function for the exchange-correlation potentials was selected for the precise estimation of electronic exchange potential. Geometrical, optical, electronic, and physical properties were estimated by Vanderbilt-type norm-conserving pseudopotential. The BFGS (Broy–Den–Fletcher–Goldfarb–Shanno)<sup>[64]</sup> approximation opts for the stable state energy. The electronic configuration of Cs (Xe6s<sup>1</sup> ), Ag (Kr4d<sup>10</sup> 5s<sup>1</sup> ), Bi (Xe4f<sup>14</sup> 5d<sup>10</sup> 6s<sup>2</sup> 6p<sup>3</sup> ), and Br (Ar4s<sup>2</sup> 3d<sup>10</sup> 4p<sup>5</sup> ) were used for the Cs, Ag, Bi, and Br respectively to derive the conduction and valance bands architecture. The energy cut-off for the PW (plane waves) function and Monkhorst pack grid were taken 500 eV and 8 × 8 × 8 respectively. The SCF (self-consistent function) was done while the total energy difference remained _<_ 2 × 10<sup>−6</sup> eV per atom. The system was converted to the ground state through this process until the ionic forces were _<_ 0.03 eV Å<sup>−1</sup> and the maximum stress was _<_ 0.05 GPa. The calculations were done by allowing for the plenary relaxation of volume, lattice constant, and atomic location. 



**www.advelectronicmat.de** 

where, _𝜓_ = Electric potential, _𝜖r_ = Relative permittivity, _𝜖_ 0 = Permittivity of free space, _ND_ = Donor density, _NA_ = Acceptor density, _𝜌p_ = Hole charge density, _𝜌n_ = Electron charge density, _q_ = Electronic charge. 

Equations (2) and (3) represent the continuity equations for electrons and holes respectively. 



<!-- Start of picture text -->
dn 𝜕Jn<br>dt = 1 q 𝜕x + ( Gn  − Rn ) (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
dp 𝜕Jp<br>dt = 1 q 𝜕x + ( Gp  − Rp ) (3)<br><!-- End of picture text -->

where, _Jn_ = Current densities of electrons, _Jp_ = Current densities for holes, _Gn_ = Electron generation rate, _Gp_ = Hole generation rate, _Rn_ = Recombination rate for electron, _Rp_ = Recombination rate for a hole. 

Both the electron current density and the hole current density are computed using the charge carrier drift-diffusion equation which is given in Equations (4) and (5). 



<!-- Start of picture text -->
Jn = q𝜇nn  ∈+ qDn𝜕n (4)<br><!-- End of picture text -->



<!-- Start of picture text -->
Jp = q𝜇pp  ∈+ qDp𝜕p (5)<br><!-- End of picture text -->

where, _Dn_ = Electron’s diffusion coefficient, _Dp_ = Hole’s diffusion coefficient, _𝜇n_ = Mobility of electron, _𝜇p_ = Mobility of hole. 

The FF can be determined using Equation (6).<sup>[69]</sup> 



<!-- Start of picture text -->
Jmp  ×  Vmp<br>FF = (6)<br>J sc ×  V oc<br><!-- End of picture text -->

where, _Jmp_ = Maximum obtainable current, _Vmp_ = Maximum obtainable voltage, _J_ sc = Short circuit current, _V_ oc = Open circuit voltage. 

The efficiency of the device can be obtained using Equation (7)<sup>[70]</sup> 



<!-- Start of picture text -->
𝜂 = V OC × J SC × FF (7)<br>Pin<br><!-- End of picture text -->

### **2.3. Cs2AgBiBr6 Perovskite Solar Cell Structure** 

### **2.2. SCAPS-1D Numerical Simulation** 

The study is supported using 1D solar cell capacitance software (SCAPS 1D) which was established by Mark Burgelman and his team at the University of Gent.<sup>[65–67]</sup> By putting suitable defect values, this software could provide efficiency near the experimental values. The mechanisms of light absorption, exciton production, transfer of charge and assemblage, and recombination were all simulated by this program. Poisson’s equation, which describes the relationship between electrostatic potential and the charge density distribution, is defined by Equation (1).<sup>[68]</sup> 



<!-- Start of picture text -->
d 2 q<br>dx 2 𝜓 ( x ) = 𝜀 0 𝜀r [ p  ( x ) − n  ( x ) +  ND  − NA  +  𝜌p  − 𝜌n (1)<br><!-- End of picture text -->



<!-- Start of picture text -->
2300751 (3 of 17)<br><!-- End of picture text -->

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

Several layers were introduced in the PSC structure of FTO/ETL/PAL/HTL/Au. Where Fluorine-doped tin oxide (FTO) was utilized as front contact, the ETL was utilized to transport electrons to the absorber and black holes, the PAL acted as the main layer of the PSC, HTL was used to transport holes and block electrons, and at the back, there was back metal contact. **Figure 1** a shows the PSC structure that was designed for this study. Where AZnO, CdZnS, LBSO, and Nb2O5 were used as ETL, Cs2AgBiBr6 was used as PAL, CZTSe, CdTe, PTAA, TiO2:N, NiCo2O4, Sb2S3, nPB, GaAs, ZnTe, CNTS were used as HTL and gold (Au) was used as back metal contact. There were 4 ETLs and 10 HTLs which made a total of 40 combinations studied in this paper to find out the best structure for each ETL. **Tables 1** and **2** show the input parameters for FTO, Cs2AgBiBr6, ETLs, and HTLs, and 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 1.** a) Design arrangement of the Cs2AgBiBr6-based PSC, and b) the 3D construction of Cs2AgBiBr6 double perovskite. 

**Table 1.** Input parameters of FTO, ETLs, and absorber layer (Cs2AgBiBr6). 

|Material property|FTO|AZnO|LBSO|Nb2O5|CdZnS|Cs2AgBiBr6|
|---|---|---|---|---|---|---|
|Thickness [nm]|200|30|120|100|100|600|
|Bandgap,_E_g [eV]|3.5|3.33|3.12|3.46|3.2|1.654|
|Electron affinity,Χ[eV]|4.00|4.55|4.4|4.33|4.2|4.19|
|Relative dielectric permittivity,_𝜖_r|9.00|8.12|22|45|9.12|5.8|
|Conduction band effective density of states_N_C (1 cm<sup>−3</sup>)|2.2 × 10<sup>18</sup>|4.1 × 10<sup>18</sup>|1.8 × 10<sup>20</sup>|1.0×10<sup>19</sup>|1.5 × 10<sup>18</sup>|1 × 10<sup>16</sup>|
|Valence band effective density of states_N_V (1 cm<sup>−3</sup>)|1.8 × 10<sup>19</sup>|8.2 × 10<sup>19</sup>|1.8 × 10<sup>20</sup>|2.2 × 10<sup>18</sup>|1.8 × 10<sup>18</sup>|1 × 10<sup>16</sup>|
|Electron thermal velocity (cm s<sup>−1</sup>)|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|
|Hole thermal velocity (cm s<sup>−1</sup>)|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|
|Electron mobility,μn (cm<sup>2 </sup>Vs<sup>−1</sup>)|20|20|0.69|20.73|250|11.81|
|Hole mobility,μh (cm<sup>2 </sup>Vs<sup>−1</sup>)|10|10|0.69|20.73|40|0.49|
|Donor density_, N_D (1 cm<sup>−3</sup>)|10<sup>18</sup>|21 × 10<sup>19</sup>|2 × 10<sup>21</sup>|1 × 10<sup>15</sup>|1 × 10<sup>16</sup>|10<sup>19</sup>|
|Acceptor density,_N_A (1 cm<sup>−3</sup>)|0|0|0|0|0|10<sup>19</sup>|
|Total density (cm<sup>−3</sup>)|10<sup>15</sup>|10<sup>15</sup>|10<sup>14</sup>|10<sup>15</sup>|10<sup>14</sup>|10<sup>15</sup>|
|References|[71]|[43]|[45]|[46,72–74]|[44]|[35–38]|



**Table 2.** Input parameters of different HTLs. 

|Material property|CZTSe|CdTe|PTAA|TiO2:N|NiCo2O4|Sb2S3|nPB|GaAs|ZnTe|CNTS|
|---|---|---|---|---|---|---|---|---|---|---|
|Thickness [nm]|100|200|150|50|70|250|50|150|250|100|
|Bandgap,_E_g [eV]|1.4|1.5|2.96|3|2.3|1.62|2.4|1.42|2.25|1.74|
|Electron affinity,Χ[eV]|4.1|3.9|2.3|2.2|3.48|3.7|3|4.07|3.73|3.87|
|Relative dielectric permittivity,_𝜖_r|9|9.4|9|3|11.9|7.08|3|12.9|7.3|9|
|Conduction band effective DOS_N_C<br>(1 cm<sup>−3</sup>)|2.2×10<sup>18</sup>|8 × 10<sup>17</sup>|2.0×10<sup>21</sup>|1.3 × 10<sup>14</sup>|2.2 × 10<sup>18</sup>|20 × 10<sup>18</sup>|1 × 10<sup>21</sup>|2.2×10<sup>18</sup>|2.2 × 10<sup>18</sup>|2.2 × 10<sup>18</sup>|
|Valence band effective DOS_N_V<br>(1 cm<sup>−3</sup>)|1.8 × 10<sup>19</sup>|1.8 × 10<sup>19</sup>|2.0×10<sup>21</sup>|1.3 × 10<sup>15</sup>|1 × 10<sup>19</sup>|10 × 10<sup>18</sup>|1 × 10<sup>21</sup>|1.8 × 10<sup>19</sup>|1.8 × 10<sup>19</sup>|1.8 × 10<sup>19</sup>|
|Electron thermal velocity (cm s<sup>−1</sup>)|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|
|Hole thermal velocity (cm s<sup>−1</sup>)|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|10<sup>7</sup>|
|Electron mobility,μn (cm<sup>2 </sup>Vs<sup>−1</sup>)|100|3.2 × 10<sup>2</sup>|1|2|1.05|9.8|6.1 × 10<sup>−6</sup>|8500|300|11|
|Hole mobility,μh (cm<sup>2 </sup>Vs<sup>−1</sup>)|12.5|4 × 10<sup>1</sup>|40|2|1.61|10|6.1 × 10<sup>−4</sup>|400|100|11|
|Donor density_, N_D (1 cm<sup>−3</sup>)|0|0|0|0|0|0|0|0|||
|Acceptor density,_N_A (1 cm<sup>−3</sup>)|1 × 10<sup>19</sup>|2.0 × 10<sup>14</sup>|1 × 10<sup>18</sup>|1.3 × 10<sup>14</sup>|1 × 10<sup>16</sup>|5.7 × 10<sup>15</sup>|1 × 10<sup>16</sup>|1 × 10<sup>11</sup>|1.0 × 10<sup>16</sup>|1.0 × 10<sup>19</sup>|
|Total density (cm<sup>−3</sup>)|1 × 10<sup>14</sup>|1 × 10<sup>15</sup>|1 × 10<sup>15</sup>|1 × 10<sup>15</sup>|1 × 10<sup>15</sup>|1 × 10<sup>14</sup>|1 × 10<sup>15</sup>|1 × 10<sup>14</sup>|1 × 10<sup>14</sup>|1 × 10<sup>14</sup>|
|References|[75]|[47,76,77]|[49]|[48]|[50]|[51]|[52]|[53]|[54]|[44]|



**2300751 (4 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advelectronicmat.de** 





**Table 3.** Input parameters of interface defect layers.<sup>[55]</sup> 

|Interface|Defect|Capture Cross Section:|Energetic|Reference for defect|Total density [cm<sup>−2</sup>]|
|---|---|---|---|---|---|
||type|Electrons/holes [cm<sup>2</sup>]|Distribution|energy level|(integrated over all|
||||||energies)|
|ETL/Cs2AgBiBr6|Neutral|1.0×10<sup>−17 </sup>and 1.0×10<sup>−18</sup>|Single|Above the VB maximum|1.0×10<sup>10</sup>|
|Cs2AgBiBr6/HTL|Neutral|1.0×10<sup>−18 </sup>and 1.0×10<sup>−19</sup>|Single|Above the VB maximum|1.0×10<sup>10</sup>|



**Table 3** displays the input constraints for interfacial defects of PSCs. 

tion energy is a very crucial parameter and its negative value indicates the thermodynamic and structural durability of a material. The calculated formation energy of our studied compound is −3.016 eV per atom which is determined by Equation (8): 

## **3. Results and Discussion** 

### **3.1. Analysis of DFT Results** 

### _3.1.1. Structural Properties of Cs2AgBiBr6 Compound_ 

From the optimization data, we found that the Cs2AgBiBr6 is a double perovskite cubic system with the space group Fm _̄_ 3 _m_ (S.G. #225). The structure of Cs2AgBiBr6 comprises a derivative of simple perovskite which forms crystals in the cubic Fm3 _̄ m_ space group (Figure 1b). To generate CsBr12 cuboctahedra, Cs<sup>1+</sup> is bound to twelve equivalent Br1 atoms, which connect corners of other twelve CsBr12 cuboctahedra, faces containing other six CsBr12 cuboctahedra, placed with four same AgBr6 octahedra, and further faces with four same BiBr6 octahedra. The bond length of Cs-Br is 4.06 Å. AgBr6 octahedra, which share eight faces with equivalent CsBr12 cuboctahedra and six corners with six BiBr6 octahedra, are created via the bonding of Ag<sup>1+</sup> to six equivalent Br1 atoms. There is no tilt in the octahedra that shares a corner. Ag─Br bonds are all 2.86 Å long. For the formation of BiBr6 octahedra, Bi<sup>3+</sup> is chemically bonded with six Br1 atoms and all Bi─Br bonds have a length of 2.88 Å. These two octahedra (AgBr6 and BiBr6) share their corners and faces with equivalent eight CsBr12 cuboctahedra. These octahedra share their corners linearly. Br1 forms a combination of deformed face, corner, and edge-sharing BrCs4AgBi octahedra when it is attached to the equivalent of four Cs<sup>1+</sup> , equivalent of one Ag<sup>1+</sup> , and one similar Bi<sup>3+</sup> ion. The octahedral corner-sharing tilting angles vary from 0° to 60°. The atomic symbols and the Wykoff position of atoms used for the optimization are mentioned in **Table 4** . 

The best-optimized lattice parameter is _a_ = 11.41 Å which is very consistent with the previous results,<sup>[28]</sup> and the corresponding 3D structure is projected in Figure 1b. Moreover, the forma- 

**Table 4.** Wyckoff position and fractional coordinates of Cs2AgBiBr6 cubic double perovskite absorber. 

|Atom|Wyckoff|Fra|ctional coordinates||
|---|---|---|---|---|
||position||||
|||x|y|Z|
|Bi|4a|0|0|0|
|Ag|4b|0.5|0|0|
|Cs|8c|0.25|0.25|0.25|
|Br|24e|0.2507|0|0|





<!-- Start of picture text -->
[ E ( Cs 2 AgBiBr 6) − 2 E  ( Cs ) − E ( Ag ) − E  ( Bi ) − 6 E  ( Br )]<br>Δ E =<br>N<br>(8)<br><!-- End of picture text -->

Here, E(Cs), E(Ag), E(Bi), and E(Br) are the energy of Cs, Ag, Bi, and Br in bulk form and E(Cs2AgBiBr6) is the total energy of the system and N is the total number atom in the system. The es- 



**Figure 2.** a) Band structure, b) DOS, c) charge density mapping of Cs2AgBiBr6 (100) plane, d) (101) plane, e) (110) plane, and f) charge scale for charge density mapping. 

**2300751 (5 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advelectronicmat.de** 



**Figure 3.** Optical properties of Cs2AgBiBr6 a) dielectric function ( _𝜖_ ), b) loss function ( _L_ ), c) refractive index ( _𝜂_ ), d) reflectivity ( _R_ ), e) absorption ( _𝛼_ ) and f) conductivity ( _𝜎_ ). 

timated formation energy of this double perovskite indicates the structural stability which is even better than earlier studies.<sup>[28,29]</sup> 

### _3.1.2. Band Structure and DOS of Cs2AgBiBr6 Compound_ 

Electronic properties give us some crucial reports such as bonds among anions and cations, photon absorbing ability, electrical conductivity, and some related properties.<sup>[78]</sup> These properties are attached to electronic band structure, DOS (Density of States), electronic charge distribution, and so on. The band spectrum is estimated along the Brillouin path X-R-M-Γ-R for Cs2AgBiBr6 and is demonstrated in **Figure 2** a. In this figure, redlines indicate the Fermi energy level ( _E_ F), the bands that have values more than _E_ F are called conduction bands, and those bands that have values less than _E_ F are called valance bands. It is seen that neither both bands cross the Fermi level nor they interfere with each other. So, this compound has a bandgap and the bandgap nature is indirect as the energy paths R (conduction band minima) to Γ (valance band maxima) coincide at different points. The calcu- 

lated value of the bandgap is 1.654 eV which has been obtained by the more reliable HSE06 (Figure 2b) hybrid function compared to the GGA method. This observed value is within the ranges of other earlier calculations (2.18 to 1.64 eV),<sup>[34]</sup> (2.19 eV).<sup>[28,29]</sup> However, the bandgap value is lower than some other related double perovskites such as Cs2AgBiCl6 (2.77 eV)<sup>[29]</sup> and Cs2AgInCl6 (3.23 eV)<sup>[59]</sup> which implies it is potent for optoelectronic applications. Furthermore, the VBM (valance band maxima) is closest to the Fermi level and crossing nature of TDOS at _E_ F confirming the p-type carriers with semiconductor behavior. The deviating phenomena of bands from the Fermi level in electronic spectra might give a hint that the carriers are not highly mobile and can be assumed to have a relatively higher value of effective mass in this region. 

TDOS (total density of states) with PDOS (partial density of states) gives information on the total atoms/orbital’s contribution to chemical bonding characteristics in Figure 2b. Fermi level is sketched at 0 eV by a vertical pink color dotted line. The total density of states (TDOS) points out that the bandgap of Cs2AgBiBr6 represents the analogous value as the band structure. However, 

**2300751 (6 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advelectronicmat.de** 



**Figure 4.** EBD of Cs2AgBiBr6-based PSC with CNTS HTL, and four different ETLs: a) AZnO, b) CdZnS, c) LBSO, and d) Nb2O5. 

the valance band is predominantly formed by Ag-4 _d_ and Br-4 _p_ orbitals, whereas Bi-6 _s_ and Bi-6 _p_ states have a lower amount of contribution. In contrast, the conduction band near the Fermi level consists of Ag-5 _s_ , Bi-6 _s_ , and Br-4 _p_ states have very trivial contributions. Remarkably, Br-4 _p_ and Ag-4 _d_ are influenced to generate valance band maxima as they are the main contributors to the Fermi level in DOS. So, Br-4 _p_ and Ag-4 _d_ orbitals are very important to absorb light and produce conductivity for the proposed solar device. 

### _3.1.3. Charge Density Map of Cs2AgBiBr6_ 

Transformation of charge and bonding nature among the constituent atoms are very useful to give further explanation of electronic characters and it can be described by a charge density map.<sup>[79]</sup> Importantly, the choice of crystallographic planes for investigating charge transport properties in materials often relies on the crystal structure and electronic properties of the material. Further, the predominant charge transport direction in Cs2AgBiBr6 double perovskite also depends on the band structure, the effective mass of charge carriers, and the specific crystallographic orientation. However, the (110) plane is a common choice for studying charge transport in double perovskite materials due to its specific crystallographic characteristics and electronic structure. Furthermore, the (110) plane in the case of Cs2AgBiBr6 cubic crystal system corresponds to a set of crystallo- 

graphic planes that are perpendicular to the [110] direction where the dominant charge transport character was clearly visualized in the image of a single plane for predominant Ag and all other atoms. In cubic crystals or perovskite materials, charge transport properties are often isotropic and thus we also calculated it for another (101) which did not vary along the crystallographic directions or other planes. The charge density map along the (110) and (101) plane and their charge scale are demonstrated in Figure 2e. It is seen that the Ag atoms have the highest intensity whereas the Bi atoms have the lowest intensity of charge. No overlapping between the charge contours atoms of Cs and Br is seen, indicating the ionic bonding between them. This similar bonding phenomenon is also investigated for Ag─Br bonds (ionic bonds). On the other hand, the existence of contour elliptical charges of Bi and Br indicates the presence of a strong covalent bond between them. This covalent bond is formed by the strong hybridization of Bi-6 _p_ and Br-4 _p_ orbitals. Additionally, the isoline in between the Bi and Br elements suggests that they may transfer charges more easily to each other.<sup>[57]</sup> 

### _3.1.4. Optical Properties of Cs2AgBiBr6 Compound_ 

Optical properties play a vital role in the perception of the characteristics of specimens when light falls on it. Through these properties, possible uses of our material like PSCs, and optoelectronics equipment. can be predicted. To understand the specific 

**2300751 (7 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 5.** Distinction of PV constraints a) _V_ OC (V), b) _J_ SC (mA cm<sup>−2</sup> ), c) FF (%), and d) PCE (%) of the Cs2AgBiBr6-based PSCs for the studied HTLs with different ETLs and Au as back contact. 

properties of a material it is important to query against the photon energy (IR, visible, and ultraviolet). Optical properties such as absorption ( _𝛼_ ), dielectric function ( _𝜖_ ), refractive index ( _𝜂_ ), loss function ( _L_ ), reflectivity ( _R_ ), and conductivity ( _𝜎_ ) are calculated to explore the response of Cs2AgBiBr6 against photon energy from 0 to 30 eV. In general, the calculation of the dielectric constant is performed with the consideration of inter-band and intra-band transitions but in this calculation, only the inter-band transitions are assessed because it is the only way for electrons to be exited from the valance band to the conduction band. **Figure 3** a shows that both real and imaginary parts of dielectric functions are larger at low photon energy and noticeably decreased at high photon energy. This phenomenon suggests that Cs2AgBiBr6 can be used in microelectronics, IC (integrated circuit), etc.<sup>[55]</sup> The _𝜖_ is related to the excitement of electrons mainly produced for interband transition with a trivial peak of approximately ≈6.5 eV because of the intraband transition of electrons. The loss function **_L_** shown in Figure 3b demonstrates the loss of energy when the electrons get polarized.<sup>[80]</sup> It is observed that Cs2AgBiBr6 loses negligible energy up to ≈2 eV, then the energy loss rises sharply and the maximum loss occurs at ≈21.6 eV. The real part and imaginary part of the refractive index ( _𝜂)_ are presented in Figure 3c which gives information on light speed in the dense medium these properties are also directly related to the dielectric function; that’s why the curve of the real part of the dielectric constant and refractive index have the same manner. 

The imaginary part of the refractive index crosses the real part slightly at 13.4 eV then falls behind again at 16.6 eV. The real part of the refractive index is higher in lower photon energy and it has the highest value at 2.5 eV. Hence, it can be used in solar cells, light-emitting diodes, organic light-emitting diodes, and photoguides.<sup>[79,81]</sup> 

Reflectivity is the phenomenon of reflection of light energy of a material from its surface. Figure 3d shows the reflectivity (R) behavior where 15.4% reflectivity of radiation is found at 0 eV energy and it increases with the increase of energy up to 3.74 eV has the highest value is 27.5% because of interband transitions. After that reflectivity decreases to lower values. R has low values ( _<_ 30%) in the study range (0 to 30 eV) suggesting that Cs2AgBiBr6 can absorb a giant amount of photon energy to be suited for optoelectronic applications.<sup>[79]</sup> Further, the amount of light absorbed is very important for photovoltaic applications which can be described by the absorption coefficient ( **_𝜶_ )** shown in Figure 3e. The absorption of our studied perovskite mainly starts from 1.6 eV because the estimated bandgap is 1.654 eV by the HSE06 function. The absorption coefficient is relatively sufficient in order of 10<sup>5</sup> times even in the lower energy range it is highly convenient for solar energy applications. However, the highest investigated absorption coefficient (2.21 × 10<sup>5</sup> ) at ≈14.65 eV and the variation trend of that is comparable to the already studied materials.<sup>[82,83]</sup> The conductivity ( _𝜎_ ) nature of Cs2AgBiBr6 is shown in Figure 3f starts mainly from 1.85 eV because of its 

**2300751 (8 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 6.** Contour plots display the variation in _V_ OC for Cs2AgBiBr6-based PSCs with a) AZnO, b) CdZnS, c) LBSO, and d) Nb2O5 ETLs accompanied by the concurrent variation in absorber layer and ETL thicknesses. 

bandgap barrier. On the other hand, the maximum value of conductivity was achieved at 9.71 eV in the relatively lower energy range of the spectrum. This nature of conductivity hints at the conventional optoelectronics applications of materials. 

### **3.2. Analysis of SCAPS-1D Results** 

photons in the device introduces a disturbance to this alignment, leading to the generation of quasi-Fermi energy levels. From all four figures, it can be seen that the VBO of the CNTS/Cs2AgBiBr6 interface is small which helps the holes to move easily, and because of the small CBO of the Cs2AgBiBr6/ETL interface, it helps electrons to move easily which results in higher and almost same efficiency for all four devices. 

### _3.2.1. Energy Band Diagram (EBD) of Cs2AgBiBr6_ 

### _3.2.2. Effect of ETL and HTL_ 

ETL, PAL, and HTL play vital roles in the impact of the conduction band (CB)/valence band (BD) offset of the EBD of PSCs. The energy level of the materials in PSC has an enormous impact on the efficiency. In PSCs, holes are transported to CNTS HTL and electrons are infused to ETL CB. In FTO and Au, electrons and holes are collected simultaneously. For better efficiency, the electron affinity of ETLs (AZnO, CdZnS, LBSO, and Nb2O5) should be greater than PAL to collect electrons from ETL/Cs2AgBiBr6 and the ionization energy of CNTS would be lesser than PAL to extract holes from Cs2AgBiBr6/HTL interface. Mismatch of the EBD of the interfaces can cause a decline in the PV attributes of the PSCs. **Figure 4** a–d shows the EBD for the structure of FTO/AZnO/Cs2AgBiBr6/CNTS/Au, FTO/CdZnS/Cs2AgBiBr6/CNTS/Au, FTO/LBSO/Cs2AgBiBr6/ CNTS/Au, and FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au, respectively. In the state of thermal equilibrium, the Fermi level exhibits uniformity within the entire framework. However, the presence of 

**Figure 5** shows the PV parameters for 40 different structures including four ETLs and ten HTLs along with the absorber. These structures are analyzed to find the best HTL for the corresponding ETL. Figure 5a shows that the lowest and highest _V_ OC of 0.716 and 1.426 V are registered while CdZnS and LBSO are used as ETL, respectively. The same phenomenon is observed for the value of _J_ SC as LBSO provides the highest and CdZnS provides the lowest _J_ SC which is shown in Figure 5b. In Figure 5c, the data indicates the occurrence of both the maximum and minimum levels of FF when CdZnS is employed as the ETL in the given situation of FF. According to the data presented in Figure 5d, it can be observed that CdZnS exhibits the lowest PCE, whereas AZnO demonstrates the highest PCE among the 40 structures that were investigated. 

Ten HTLs are used to combine with 4 ETLs to make 40 structures. After the analysis, it can be seen that among these 10 HTLs, 

**2300751 (9 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 

**www.advelectronicmat.de** 





**www.advancedsciencenews.com** 



**Figure 7.** Contour plots display the variation in _J_ SC for Cs2AgBiBr6-based PSCs with a) AZnO, b) CdZnS, c) LBSO, and d) Nb2O5 ETLs accompanied by the concurrent variation in absorber layer and ETL thicknesses. 

CNTS provides the best efficiency when combined with AZnO, CdZnS, LBSO, and Nb2O5 which is shown in Figure 5. Since investigated HTLs are p-type layers, the HTL should be thicker or equivalent to the n-type ETL in order to decrease the risk of recombination, primarily because it allows for the quick transfer of an equivalent number of charge carriers to the structure. Although CNTS is not used rapidly, it is chosen for this study for its suitable bandgap, better absorption coefficient and conductivity, non-toxicity, and environmental stability. 

### _3.2.3. Effect of Absorber and ETL Thickness on PV Performance_ 

**Figure 6** shows the change in _V_ OC with the variation of the absorber and ETL thickness where the thickness of the absorber is varied from 400 to 900 nm and the thickness of ETL is varied from 20 to 400 nm for the best ETL/HTL combinations. In Figure 6a, for the structure of FTO/AZnO/Cs2AgBiBr6/CNTS/Au, the best _V_ OC of 1.375 V is recorded at an absorber thickness of _<_ 500 nm and it hardly depends on the change in ETL thickness. While observing the change in _V_ OC for the structure of FTO/CdZnS/Cs2AgBiBr6/CNTS/Au which is shown in Figure 6b, it can be seen that _V_ OC decreases with the increase in absorber layer thickness, and like the previous structure, it barely depends on the ETL thickness. At an absorber thickness of _<_ 450 nm, the device shows the highest _V_ OC, and at a thickness of _>_ 800 nm, it shows the lowest _V_ OC. In Figure 6c, for the structure of FTO/LBSO/Cs2AgBiBr6/CNTS/Au, the highest value of 

_V_ OC is achieved at absorber thickness of _<_ 500 nm and decreases with the increase in absorber thickness and the effect is free from ETL thickness. A similar trend is registered while Nb2O5 is used as ETL in Figure 6d. 

**Figure 7** shows the change in _J_ SC with the increase in absorber and ETL layer thickness. Similar trends can be seen for all four structures. The value of JSC increases with the increase in absorber layer thickness and it barely depends on the thickness of ETL. All four devices provide the best _J_ SC at an absorber layer thickness of _>_ 750 nm and the highest _J_ SC of 22.46 mA cm<sup>−2</sup> is recorded while Nb2O5 is used as ETL which is shown in Figure 7d. 

**Figure 8** depicts the change in FF with the increase in absorber and ETL thickness. While AZnO, CdZnS, and LBSO are used as ETL, they show the same characteristics. The value of FF decreases with the increase in absorber layer thickness and is independent of change in ETL thickness. The highest FF is seen at the thickness of _<_ 500 nm for these three structures. The device FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au shows some different phenomena from the devices where AZnO, CdZnS, and LBSO are used as ETL. Here highest _J_ SC of 82.3% is achieved at an absorber thickness of _<_ 450 nm and ETL thickness of _<_ 100 nm which is shown in Figure 8d. 

**Figure 9** depicts the variation in PCE as a function of the augmenting thickness of both the absorber layer and the ETL. In the case of PCE, different ETLs show different phenomena. Figure 9a,c shows the change in PCE for the structure of FTO/AZnO/Cs2AgBiBr6/CNTS/Au and 

**2300751 (10 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 8.** Contour plots display the variation in FF for Cs2AgBiBr6-based PSCs with a) AZnO, b) CdZnS, c) LBSO, and d) Nb2O5 ETLs accompanied by the concurrent variation in absorber layer and ETL thicknesses. 

FTO/LBSO/Cs2AgBiBr6/CNTS/Au while absorber layer thickness is kept between 550 and 800 nm, the devices provide the best PCE of 23.35% and 23.28%, respectively, and they’re almost independent of ETL thickness. For the device of FTO/CdZnS/Cs2AgBiBr6/CNTS/Au, it can be seen in Figure 9b that while absorber layer thickness is between 500 and 800 nm and ETL thickness is _>_ 20 nm, the maximum PCE of 23.02% is attained. The structure of FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au is shown in Figure 9d and observed that while the absorber thickness is between 500 and 850 nm and the thickness of ETL is under 20 nm, the device provides the best PCE of 23.69%. 

### _3.2.4. Effect of HTL Thickness Variation_ 

Hole transport layers are placed between the absorber layer and back metal contact and help the holes move to the respective electrode. The thickness of HTL can play a crucial role in gaining higher efficiency.<sup>[84]</sup> Normally HTL’s thickness needs to be thinner than ETL to reduce the recombination rate in the layer.<sup>[47]</sup> **Figure 10** depicts the change in _V_ OC, _J_ SC, FF, and PCE with the change in HTL thickness. The thickness of HTL is varied from 50 to 500 nm to observe its effect on PV parameters. It is seen that the value of _V_ OC, _J_ SC, and PCE increased gradually with the increase in HTL thickness, but FF declined. The increase in PV parameters is due to greater hole extraction in the device with the increased thickness of HTL. 

### _3.2.5. Effect of Series Resistance_ 

As they regulate the slopes and shapes of the current–voltage characteristics, individual shunt ( _R_ SH) and series ( _R_ S) resistances have a significant influence on proceeding PSC performance.<sup>[85]</sup> Perovskite performance is meaningfully obstructed by _R_ SH and _R_ S, which are largely formed by connections between structures’ various layers, metal contacts, the semiconductor-metal interface, and improper solar cell processing processes.<sup>[83]</sup> To observe the effect of _R_ S on the PSC, the value of _R_ S is varied from 0 to 6 Ω-cm<sup>2</sup> while the value of _R_ SH is kept fixed at 10<sup>5</sup> Ω-cm<sup>2</sup> which is shown in **Figure 11** a. It can be seen that _V_ OC and _J_ SC are almost independent of change in _R_ S but FF greatly declines resulting in a decrease in PCE with the increase in _R_ S for all four structures. The JV characteristics of a heterojunction SC are shown in a typical diode model as Equation (9).<sup>[86]</sup> 



<!-- Start of picture text -->
J =  J L − J 0 exp e ( V +  J  ×  R S) − 1 − V + J  ×  R S (9)<br>[ ( AK B T ) ] R SH<br><!-- End of picture text -->

where, _J_ = Circuit current, _J_ L = Current induced from light absorbance, _V_ = Voltage, _J_ 0 = Reverse saturation current, _A_ = Ideality factor, _e_ = Charge of electron, _K_ B = Boltzmann constant, _R_ S = Series resistance, _R_ SH = Shunt resistance, T = Temperature. 

**2300751 (11 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advelectronicmat.de** 



**Figure 9.** Contour plots display the variation in PCE for Cs2AgBiBr6-based PSCs with a) AZnO, b) CdZnS, c) LBSO, and d) Nb2O5 ETLs accompanied by the concurrent variation in absorber layer and ETL thicknesses. 

### _3.2.6. Effect of Shunt Resistance_ 

Essential calculations have been carried out to observe the effect of _R_ SH on the PSCs. The value of _R_ SH is varied from 10 Ω to 10<sup>6</sup> Ω- cm<sup>2</sup> and the changes in PV parameters are shown in Figure 11b. It can be seen that all the PV attributes react the same for all four devices we have chosen. The PV parameters tend to increase with the increase in shunt resistance till 10<sup>3</sup> Ω-cm<sup>2</sup> and after that, they do not change with further increase in _R_ SH. This may be because the p–n junction affords a low-resistance channel for junction current flow after a specific _R_ SH threshold is attained.<sup>[55]</sup> The most variation occurred while AZnO is used as ETL as its PCE has increased from 1.095% to 23.29% while _R_ SH is increased to 10<sup>3</sup> Ω-cm<sup>2</sup> . Similar trends have been seen in previous published literature.<sup>[87]</sup> So higher value of _R_ SH helps the PSCs to perform with better efficiency. 

300 to 450 k and it is shown in Figure 11c. It is seen that _V_ OC is decreased with the increase in temperature for all four devices. It may be because of creating reverse saturation current in the devices. Equations (10) and (11) show the dependency of _V_ OC on temperature. 



<!-- Start of picture text -->
VOC = nKT log + 1 (10)<br>q ( JJSC 0 )<br>Eg<br>dVOC = VOC − q (11)<br>dT T T<br><!-- End of picture text -->

where, _J_ 0 = Reverse saturation current, T = Temperature, _Eg_ = Bandgap, _q_ = Electronic charge, _n_ = ideality factor, _K_ = Boltzmann constant. 

Change in temperature does not have much effect on _J_ SC but FF and PCE tend to decrease with the increase in temperature. The highest stability in PCE is shown by the device where AZnO is used as ETL as it remains stable till 325 k. 

### _3.2.7. Effect of Temperature_ 

Solar cells have drawn a lot of interest in the PV industry, however, they still demonstrate thermal instability when opened to light.<sup>[88]</sup> The efficiency may be greatly hampered while kept open for too long at higher temperatures.<sup>[87,89]</sup> So, observing the effect of temperature on the PSCs was needed. To see the effect of temperature on the PSCs, the value of temperature is varied from 

### _3.2.8. Effect of Generation and Recombination Rate_ 

**Figure 12** a illustrates the generation rate of electron-hole for the four structure pairs with respect to the position. It can be seen that the best generation rate is achieved between 0.6 and 0.7 μm and the structure FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au holds the 

**2300751 (12 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 10.** Effect of change in HTL thickness on _V_ OC, _J_ SC, FF, and PCE of the devices. 

best generation rate among the four devices. SCAPS 1D uses Equation (12) to calculate the generation rate by considering the contribution of electron-hole pairs for each position and spectral region. 



<!-- Start of picture text -->
G  ( 𝜆, x ) =  𝛼 ( 𝜆, x ) × Nphot ( 𝜆, x ) (12)<br><!-- End of picture text -->

where, Nphot( _𝜆_ , _x_ ) = Photon flux 

The recombination rate is actually opposite to the generation rate as it reduces photo-current by destroying electronhole pairs. Figure 12b shows the recombination rates for four structures where it can be seen that recombination of electronhole pairs increases till 0.5 μm then it starts to decline and becomes minimum at 0.7 μm. Like the generation rate, the highest recombination rate is achieved by the structure of FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au. The charge carriers’ density and lifespan have an impact on the rate of recombination in PSCs. The increase in electron-hole recombination is caused by defect states at the interfaces and in the absorber layer.<sup>[83]</sup> 

### _3.2.9. J–V and QE characteristics_ 

**Figure 13** displays _J–V_ characteristics and _QE_ for the structure of FTO/ETL/Cs2AgBiBr6/CNTS/Au where AZnO, CdZnS, LBSO, and Nb2O5 are used as ETL. All four ETLs show almost the same value in the _J–V_ curve which is shown in Figure 13a. The same current density is because of the same photo-generated current in the device for each studied ETL. Often the variation occurs due to 

the band structure of ETLs.<sup>[90]</sup> Figure 13b shows the QE curve for the devices with respect to wavelength of light. The wavelength is adjusted between 300 and 800 nm to see how it goes for the selected devices. It can be seen that _QE_ rises when increasing the wavelength and when the value crosses 350 nm, _QE_ of 100% is achieved. Then _QE_ gradually decreases to zero when the wavelength reaches 750 nm. Like _J–V_ characteristics, _QE_ also shows the same phenomena for all four devices. 

### **3.3. Comparison of SCAPS-1D Results with Previous Work** 

**Table 5** represents the assessment results among previously experimental<sup>[32,33]</sup> and theoretical<sup>[34–38]</sup> studies on PV parameters of Cs2AgBiBr6-based PSC. Among the previous studies, Alkhammash et al. were able to get the highest 21.88% PCE with the structure of FTO/ZnO/Cs2AgBiBr6/NiO/Au.<sup>[37]</sup> While experimental works FTO/TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Au and FTO/TiO2/Cs2AgBiBr6/Spiro-OMeTAD/MoO3/Ag structures PCE was 1.66%<sup>[32]</sup> and 2.51%<sup>[33]</sup> respectively, that is not upto the mark. Whereas by combining Ten different HTLs with 4 ETLs, the best efficiency of 23.50% is achieved for the proposed structure of FTO/AZnO/Cs2AgBiBr6/CNTS/Au in this study which is exceptional. So, it is evident that this study demonstrates superior efficiency and PV performance compared to earlier research endeavors. All four devices examined in this study have demonstrated exceptional PCE in comparison to previous theoretical and experimental studies. Therefore, our proposed solar cell scheme in this study using both SCAPS-1D 

**2300751 (13 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



### **www.advelectronicmat.de** 



**Figure 11.** Effect of a) series resistance, b) shunt resistance, and c) temperature on PV features for different ETLs. 



**Figure 12.** a) Generation, and b) recombination rates for Cs2AgBiBr6-based PSCs with different ETLs. 

**2300751 (14 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 



**www.advelectronicmat.de** 



**Figure 13.** a) _J_ – _V_ curve for four studied structures of FTO/ETL/Cs2AgBiBr6/CNTS/Au; b) QE curve for the structure of FTO/ETL/Cs2AgBiBr6/CNTS/Au. 

simulation and DFT computations explores a new guideline to gain higher efficient devices in the near future. 

## **4. Conclusion** 

By synergizing the DFT approach with SCAPS simulation, this study comprehensively elucidates the optoelectronic and photovoltaic attributes of Cs2AgBiBr6 perovskite. The key findings are as follows: 

- 1) Exploiting the double cubic perovskite Cs2AgBiBr6, our study unveils an indirect bandgap of 1.654 eV through DFT calculations. SCAPS 1D simulation harnesses this bandgap to evaluate PV parameters. Notably, Ag-4d and Br-4p orbitals dominate sunlight absorption, fostering material photoconductivity. 

- 2) The Ag element/atom emerges from the charge density map as the primary charge reservoir, surpassing other constituents. Additionally, while Cs─Br and Ag─Br electronic bonds exhibit ionicity, a strong covalent Bi─Br bond characterizes the Cs2AgBiBr6 absorber perovskite. 

- 3) The correlation between six optical parameters and electronic properties underscores the potential optoelectronic applications. Of note, the absorption profile for PV applications initiates ≈1.61 eV, rising to 3.75 eV within the visible and UV spectra, with peak absorption at 15 eV (UV range). 

- 4) Employing the DFT-derived bandgap, we assess 40 configurations comprising 4 ETLs and 10 HTLs. Remarkably, CNTS as HTL consistently yields optimal PCE across all ETL choices. 

- 5) Variations in absorber and ETL thickness impact PV attributes in the top four structures. Significantly, PCE escalates with absorber thickness increase, while ETL thickness exerts minimal influence. 

- 6) Attaining a notable efficiency of 23.50%, the architecture FTO/AZnO/Cs2AgBiBr6/CNTS/Au triumphs, whereas the structure FTO/CdZnS/Cs2AgBiBr6/CNTS/Au achieves a slightly lower 23.15% efficiency among the four. 

- 7) The study delves into the effects of series resistance, shunt resistance, and temperature on PSCs, encompassing generation and recombination rates. Robust _J_ – _V_ and QE characteristics further validate the performance of all four PSCs. 

**Table 5.** The comparison of PV constraints of Cs2AgBiBr6-based PSCs. 

|Type|Device structure|_V_OC [V]|_J_SC [mA cm<sup>−2</sup>]|FF [%]|PCE [%]|Refs.|
|---|---|---|---|---|---|---|
|1|FTO/TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Au|1.057|3.87|40.58|1.66|[32]|
|1|FTO/TiO2/Cs2AgBiBr6/Spiro-OMeTAD/MoO3/Ag|1.01|3.82|65|2.51|[33]|
|1|FTO/TiO2/Cs2AgBiBr6/Spiro-OMeTAD/Au|1.511|3.89|51.76|3.04|[32]|
|2|ITO/SnO2/Cs2AgBiBr6/spiro-OMeTAD/Au|0.92|11.4|60.93|6.37|[34]|
|2|FTO/SnO2/Cs2AgBiBr6/Spriro-OMeTAD/Au|1.3|17.44|62.59|14.29|[35]|
|2|Glass/FTO/TiO2/Cs2AgBiBr6/Cu2O/Au|1.5|11.45|42.1|7.25|[36]|
|2|FTO/ZnO/Cs2AgBiBr6/NiO/Au|1.29|20.69|81.72|21.88|[37]|
|2|ITO/CdS/Cs2AgBiBr6/CuAlO2/Pt|1.642|4.913|88.74|7.16|[38]|
|2|FTO/AZnO/Cs2AgBiBr6/CNTS/Au|1.375|21.38|79.93|23.50|a)|
|2|FTO/CdZnS/Cs2AgBiBr6/CNTS/Au|1.372|21.41|78.82|23.15|a)|
|2|FTO/LBSO/Cs2AgBiBr6/CNTS/Au|1.373|21.40|79.72|23.42|a)|
|2|FTO/Nb2O5/Cs2AgBiBr6/CNTS/Au|1.376|21.41|78.87|23.23|a)|



Note: 1- Experimental, 2- Theoretical. a) This work. 

**2300751 (15 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

These outcomes hold promise for propelling economically viable, lead-free double PSCs with enhanced efficiency, thus paving the way for their integration in future applications. This research contributes significantly to the advancement of sustainable photovoltaics. Furthermore, to enhance the performance of Cs2AgBiBr6 perovskite solar cells, we suggest exploring material and interface engineering, stability enhancement, optimizing device architecture, and employing advanced characterization techniques. 

## **Acknowledgements** 

M.K.H. led and supervised this research work. The authors extend their appreciation to the Deputyship for Research and Innovation, “Ministry of Education” in Saudi Arabia for funding this research (IFKSUOR3–39–3). The SCAPS-1D program was kindly provided by Dr. M. Burgelman of the University of Gent in Belgium. The authors would like to express their gratitude to him. 



**www.advelectronicmat.de** 

- [12] M. Yang, Y. Zhou, Y. Zeng, C. Jiang, N. P. Padture, K. Zhu, _Adv. Mater._ **2015** , _27_ , 6363. 

- [13] Y. Zhou, M. Yang, S. Pang, K. Zhu, N. P. Padture, _J. Am. Chem. Soc._ **2016** , _138_ , 5535. 

- [14] M. J. Kadhim, M. K. A. Mohammed, _Mater. Res. Bull._ **2023** , _158_ , 112047. 

- [15] A. Thakur, D. Singh, S. Kaur Gill, _Mater. Today: Proc._ **2022** , _71_ , 195. 

- [16] M. K. A. Mohammed, M. S. Jabir, H. G. Abdulzahraa, S. H. Mohammed, W. K. Al-Azzawi, D. S. Ahmed, S. Singh, A. Kumar, S. Asaithambi, M. Shekargoftar, _RSC Adv._ **2022** , _12_ , 20461. 

- [17] T. I. Alanazi, O. S. Game, J. A. Smith, R. C. Kilbride, C. Greenland, R. Jayaprakash, K. Georgiou, N. J. Terrill, D. G. Lidzey, _RSC Adv._ **2020** , _10_ , 40341. 

- [18] S. Abdelaziz, A. Zekry, A. Shaker, M. Abouelatta, _Opt. Mater._ **2022** , _123_ , 111893. 

- [19] Z. T. M. Noori, A. M. Naji, O. A. Nief, M. K. A. Mohammed, N. M. Ahmed, S. Singh, _Int. J. Energy Res._ **2022** , _46_ , 17285. 

- [20] S. H. Kareem, M. H. Elewi, A. Muhson Naji, D. S. Ahmed, M. K. A. Mohammed, _Chem. Eng. J._ **2022** , _443_ , 136469. 

- [21] T. He, Y. Jiang, X. Xing, M. Yuan, _Adv. Mater._ **2020** , _32_ , 1903937. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

- [22] A. N. Singh, S. Kajal, J. Kim, A. Jana, J. Y. Kim, K. S. Kim, _Adv. Energy Mater._ **2020** , _10_ , 2070129. 

- [23] J. Xu, R. Saklatvala, S. Mittal, S. Deshmukh, A. Procopio, _Adv. Sci._ **2020** , _7_ , 1903394. 

- [24] M. Pitaro, E. K. Tekelenburg, S. Shao, M. A. Loi, _Adv. Mater._ **2022** , _34_ , 2105844. 

## **Data Availability Statement** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

## **Keywords** 

copper nickel tin sulfide (CNTS) HTL, Cs2AgBiBr6 absorber, DFT analysis, lead-free perovskite solar cell, optoelectronic properties, SCAPS-1D 

Received: October 30, 2023 Revised: December 31, 2023 Published online: March 5, 2024 

   - [25] Z. Omarova, D. Yerezhep, A. Aldiyarov, N. Tokmoldin, _Crystals_ **2022** , _12_ , 699. 

   - [26] M. Liu, H. Pasanen, H. Ali-Löytty, A. Hiltunen, K. Lahtonen, S. Qudsia, J. Smått, M. Valden, N. V. Tkachenko, P. Vivo, _Angew. Chem., Int. Ed._ **2020** , _59_ , 22117. 

   - [27] J. Chen, Z. Luo, Y. Fu, X. Wang, K. J. Czech, S. Shen, L. Guo, J. C. Wright, A. Pan, S. Jin, _ACS Energy Lett._ **2019** , _4_ , 1045. 

   - [28] A. H. Slavney, T. Hu, A. M. Lindenberg, H. I. Karunadasa, _J. Am. Chem. Soc._ **2016** , _138_ , 2138. 

   - [29] E. T. McClure, M. R. Ball, W. Windl, P. M. Woodward, _Chem. Mater._ **2016** , _28_ , 1348. 

   - [30] F. Wei, Z. Deng, S. Sun, F. Zhang, D. M. Evans, G. Kieslich, S. Tominaka, M. A. Carpenter, J. Zhang, P. D. Bristowe, _Chem. Mater._ **2017** , _29_ , 1089. 

   - [31] X. Yang, Y. Chen, P. Liu, H. Xiang, W. Wang, R. Ran, W. Zhou, Z. Shao, _Adv. Funct. Mater._ **2020** , _30_ , 2001557. 

- [1] H. Li, C. Zhang, C. Gong, D. Zhang, H. Zhang, Q. Zhuang, X. Yu, S. Gong, X. Chen, J. Yang, X. Li, R. Li, J. Li, J. Zhou, H. Yang, Q. Lin, J. Chu, M. Grätzel, J. Chen, Z. Zang, _Nat. Energy_ **2023** , _8_ , 946. 

- [2] Q. Zhuang, H. Li, C. Zhang, C. Gong, H. Yang, J. Chen, Z. Zang, _Adv. Mater._ **2023** , _35_ , 2303275. 

- [3] C. Zhang, H. Li, C. Gong, Q. Zhuang, J. Chen, Z. Zang, _Energy Environ. Sci._ **2023** , _16_ , 3825. 

- [4] C. Gong, C. Zhang, Q. Zhuang, H. Li, H. Yang, J. Chen, Z. Zang, _NanoMicro Lett._ **2023** , _15_ , 17. 

- [5] Y. Zhao, H. Xiang, R. Ran, W. Zhou, W. Wang, Z. Shao, _J. Energy Chem._ **2023** , _83_ , 189. 

- [6] L. Song, _Mater. Rep.: Energy_ **2022** , _2_ , 100171. 

- [7] W. Shen, Y. Dong, F. Huang, Y.-B. Cheng, J. Zhong, _Mater. Rep.: Energy_ **2021** , _1_ , 100060. 

- [8] X. Yang, W. Wang, R. Ran, W. Zhou, Z. Shao, _Energy Fuels_ **2020** , _34_ , 10513. 

- [9] T. Ye, K. Wang, Y. Hou, D. Yang, N. Smith, B. Magill, J. Yoon, R. R. H. H. Mudiyanselage, G. A. Khodaparast, K. Wang, S. Priya, _J. Am. Chem. Soc._ **2021** , _143_ , 4319. 

- [10] S. D. Stranks, H. J. Snaith, _Nat. Nanotechnol._ **2015** , _10_ , 391. 

- [11] Y. Zhou, K. Zhu, _ACS Energy Lett._ **2016** , _1_ , 64. 

- [32] E. Greul, M. L. Petrus, A. Binek, P. Docampo, T. Bein, _J. Mater. Chem. A_ **2017** , _5_ , 19972. 

- [33] F. Igbari, R. Wang, Z.-K. Wang, X.-J. Ma, Q. Wang, K.-L. Wang, Y. Zhang, L.-S. Liao, Y. Yang, _Nano Lett._ **2019** , _19_ , 2066. 

- [34] Z. Zhang, Q. Sun, Y. Lu, F. Lu, X. Mu, S. H. Wei, M. Sui, _Nat. Commun._ **2022** , _13_ , 3397. 

- [35] T. I. Alanazi, _Crystals_ **2023** , _13_ , 267. 

- [36] M. T. Islam, M. R. Jani, S. M. Al Amin, M. S. U. Sami, K. M. Shorowordi, M. I. Hossain, M. Devgun, S. Chowdhury, S. Banerje, S. Ahmed, _Opt. Mater._ **2020** , _105_ , 109957. 

- [37] H. I. Alkhammash, M. Mottakin, M. M. Hossen, M. Akhtaruzzaman, M. J. Rashid, _Semicond. Sci. Technol._ **2023** , _38_ , 015005. 

- [38] I. Chabri, Y. Benhouria, A. Oubelkacem, A. Kaiba, I. Essaoudi, A. Ainane, _Optik_ **2023** , _274_ , 170560. 

- [39] T. Dureja, A. Garg, S. Bhalla, D. Bhutani, A. Khanna, _Mater. Today: Proc._ **2022** , _71_ , 239. 

- [40] R. Pandey, A. Khanna, K. Singh, S. K. Patel, H. Singh, J. Madan, _Sol. Energy_ **2020** , _207_ , 893. 

- [41] Y. Raoui, H. Ez-Zahraouy, N. Tahiri, O. El Bounagui, S. Ahmad, S. Kazim, _Sol. Energy_ **2019** , _193_ , 948. 

- [42] S. Abdelaziz, A. Zekry, A. Shaker, M. Abouelatta, _Opt. Mater._ **2020** , _101_ , 109738. 

**2300751 (16 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

- [43] M. Alla, V. Manjunath, E. Choudhary, M. Samtham, S. Sharma, P. A. Shaikh, M. Rouchdi, B. Fares, _Phys. Status Solidi_ **2023** , 220. 

- [44] Z. Khan, M. Noman, S. Tariq Jan, A. Daud Khan, _Sol. Energy_ **2023** , _257_ , 58. 

- [45] K. Shivesh, I. Alam, A. K. Kushwaha, M. Kumar, S. V. Singh, _Int. J. Energy Res._ **2022** , _46_ , 6045. 

- [46] M. S. Shamna, K. S. Sudheer, _J. Photonics Energy_ **2022** , _12_ , 032211. 

- [47] O. Ahmad, A. Rashid, M. W. Ahmed, M. F. Nasir, I. Qasim, _Opt. Mater._ **2021** , _117_ , 111105. 

- [48] N. R. Pochont, Y. R. Sekhar, _Inorganics_ **2023** , _11_ , 3. 

- [49] H. Arbouz, _Appl. Rheol._ **2023** , _33_ , 20220138. 

- [50] M. Mottakin, D. K. Sarkar, V. Selvanathan, M. J. Rashid, K. Sobayel, A. K. M. Hasan, M. Ariful Islam, G. Muhammad, M. Shahiduzzaman, M. Akhtaruzzaman, _Optik_ **2023** , _272_ , 170232. 

- [51] N. K. Singh, A. Agarwal, _Util. Environ. Eff._ **2023** , _45_ , 3087. 

- [52] D. K. Jarwal, C. Dubey, K. Baral, A. Bera, G. Rawat, _IEEE Trans. Electron Devices_ **2022** , _69_ , 5012. 

- [53] I. Qasim, O. Ahmad, A. Rashid, T. Zehra, M. I. Malik, M. Rashid, M. W. Ahmed, M. F. Nasir, _Opt. Quantum Electron._ **2021** , _53_ , 713. 

- [54] N. K. Singh, A. Agarwal, _Opt. Mater._ **2023** , _139_ , 113822. 

- [55] M. K. Hossain, M. H. K. Rubel, G. F. I. Toki, I. Alam, M. F. Rahman, H. Bencherif, _ACS Omega_ **2022** , _7_ , 43210. 

- [56] M. I. Kholil, M. T. H. Bhuiyan, M. A. Rahman, M. S. Ali, M. Aftabuzzaman, _AIP Adv._ **2021** , _11_ , 035229. 

- [57] M. K. Hossain, A. A. Arnab, R. C. Das, K. M. Hossain, M. H. K. Rubel, M. F. Rahman, H. Bencherif, M. E. Emetere, M. K. A. Mohammed, R. Pandey, _RSC Adv._ **2022** , _12_ , 34850. 

- [58] H. Lei, D. Hardy, F. Gao, _Adv. Funct. Mater._ **2021** , _31_ , 2105898. 

- [59] F. Paquin, J. Rivnay, A. Salleo, N. Stingelin, C. Silva, _J. Mater. Chem. C_ **2015** , _3_ , 10715. 

- [60] M. K. A. Mohammed, R. K. Al-Azzawi, H. H. Jasim, S. H. Mohammed, S. Singh, H. H. Kadhum, A. Kumar, P. Sasikumar, M. S. Revathy, M. S. Jabir, _Opt. Mater._ **2022** , _133_ , 112901. 

- [61] S. M. Majeed, M. K. A. Mohammed, D. S. Ahmed, _J. Mater. Chem. C_ **2022** , _10_ , 16480. 

- [62] A. M. Naji, S. H. Kareem, A. H. Faris, M. K. A. Mohammed, _Ceram. Int._ **2021** , _47_ , 33390. 

- [63] D. A. Dixon, Density Functional Theory In W. White, _Encyclopedia of Geochemistry. Encyclopedia of Earth Sciences Series._ , Springer, Cham **2016** , 1. 

- [64] T. H. Fischer, J. Almlof, _J. Phys. Chem._ **1992** , _96_ , 9768. 

- [65] M. D. Humadi, H. T. Hussein, M. S. Mohamed, M. K. A. Mohammed, E. Kayahan, _Opt. Mater._ **2021** , _112_ , 110794. 

- [66] H. G. Abdulzahraa, M. K. A. Mohammed, A. S. M. Raoof, _Surf. Interfaces_ **2022** , _31_ , 102092. 

- [67] A. K. Kadhim, M. R. Mohammad, A. I. Abd Ali, M. K. A. Mohammed, _Energy Fuels_ **2021** , _35_ , 8944. 

- [68] R. A. Jabr, M. Hamad, Y. M. Mohanna, _Int. J. Electr. Eng. Educ._ **2007** , _44_ , 23. 



**www.advelectronicmat.de** 

- [69] M. K. Hossain, M. F. Pervez, M. N. H. Mia, A. A. Mortuza, M. S. Rahaman, M. R. Karim, J. M. M. Islam, F. Ahmed, M. A. Khan, _Results Phys._ **2017** , _7_ , 1516. 

- [70] P. Lin, L. Lin, J. Yu, S. Cheng, P. Lu, Q. Zheng, _J. Appl. Sci. Eng._ **2014** , _17_ , 383. 

- [71] A. Kumar, S. Singh, _Mater. Today: Proc._ **2021** , _44_ , 2215. 

- [72] J. Feng, Z. Yang, D. Yang, X. Ren, X. Zhu, Z. Jin, W. Zi, Q. Wei, S. F. Liu, _Nano Energy_ **2017** , _36_ , 1. 

- [73] A. Hosen, M. S. Mian, S. R. Al Ahmed, _Adv. Theory Simul._ **2023** , _6_ , 2200652. 

- [74] X. Ling, J. Yuan, D. Liu, Y. Wang, Y. Zhang, S. Chen, H. Wu, F. Jin, F. Wu, G. Shi, _ACS Appl. Mater. Interfaces_ **2017** , _9_ , 23181. 

- [75] Y. H. Khattak, E. Vega, F. Baig, B. M. Soucase, _Mater. Res. Bull._ **2022** , _151_ , 111802. 

- [76] D. Jha, A. Dixit, A. Sushrutha, P. K. Patel, _Opt. Commun._ **2022** , _523_ , 128717. 

- [77] K. Fatema, _Mater. Today Commun._ **2023** , _35_ , 105860. 

- [78] W.-C. C. Hu, Y. Liu, D.-J. J. Li, X.-Q. Q. Zeng, C.-S. S. Xu, _Comput. Mater. Sci._ **2014** , _83_ , 27. 

- [79] M. H. K. Rubel, M. A. Hossain, M. K. Hossain, K. M. Hossain, A. A. Khatun, M. M. Rahaman, M. Ferdous Rahman, M. M. Hossain, J. Hossain, _Results Phys._ **2022** , _42_ , 105977. 

- [80] S. Bouhmaidi, A. Azouaoui, N. Benzakour, A. Hourmatallah, L. Setti, _Comput. Condens. Matter_ **2022** , _33_ , e00756. 

- [81] M. H. K. Rubel, K. M. Hossain, S. K. Mitro, M. M. Rahaman, M. A. Hadi, A. K. M. A. Islam, _Mater. Today Commun._ **2020** , _24_ , 100935. 

- [82] M. K. Hossain, G. F. I. Toki, A. Kuddus, M. H. K. Rubel, M. M. Hossain, H. Bencherif, M. F. Rahman, M. R. Islam, M. Mushtaq, _Sci. Rep._ **2023** , _13_ , 2521. 

- [83] M. K. Hossain, M. K. A. Mohammed, R. Pandey, A. A. Arnab, M. H. K. Rubel, K. M. Hossain, M. H. Ali, M. F. Rahman, H. Bencherif, J. Madan, M. R. Islam, D. P. Samajdar, S. Bhattarai, _Energy and Fuels_ **2023** , _37_ , 6078. 

- [84] M. K. Hossain, M. S. Uddin, G. F. I. Toki, M. K. A. Mohammed, R. Pandey, J. Madan, F. Rahman, R. Islam, S. Bhattarai, H. Bencherif, D. P. Samajdar, M. Amami, D. K. Dwivedi, _RSC Adv._ **2023** , _13_ , 23514. 

- [85] S. Karthick, S. Velumani, J. Bouclé, _Sol. Energy_ **2020** , _205_ , 349. 

- [86] Y. Li, B. Ding, Q.-Q. Chu, G.-J. Yang, M. Wang, C.-X. Li, C.-J. Li, _Sci. Rep._ **2017** , _7_ , 46141. 

- [87] M. K. Hossain, M. S. Uddin, G. F. I. Toki, M. K. A. Mohammed, R. Pandey, J. Madan, M. F. Rahman, M. R. Islam, S. Bhattarai, H. Bencherif, D. P. Samajdar, M. Amami, D. K. Dwivedi, _RSC Adv._ **2023** , _13_ , 23514. 

- [88] P. Holzhey, M. Saliba, _J. Mater. Chem. A_ **2018** , _6_ , 21794. 

- [89] R. Roesch, T. Faber, E. Von Hauff, T. M. Brown, M. Lira-Cantu, H. Hoppe, _Adv. Energy Mater._ **2015** , _5_ , 1501407. 

- [90] M. Samiul Islam, K. Sobayel, A. Al-Kahtani, M. A. Islam, G. Muhammad, N. Amin, M. Shahiduzzaman, M. Akhtaruzzaman, _Nanomaterials_ **2021** , _11_ , 1218. 

**2300751 (17 of 17)** 

_Adv. Electron. Mater._ **2024** , _10_ , 2300751 

© 2024 The Authors. Advanced Electronic Materials published by Wiley-VCH GmbH 

