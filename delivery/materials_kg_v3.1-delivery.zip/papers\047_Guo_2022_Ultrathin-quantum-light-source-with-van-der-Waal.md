# Ultrathin quantum light source with van der Waals NbOCl_2 crystal

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 344 |
| 作者 | Qiang-Bing Guo, Xiao-Zhuo Qi, Li-Shu Zhang, Meng Gao, Sanlue Hu, Wen-Ju Zhou, W. Zang, Xiao-Xu Zhao et al. |
| DOI | 10.1038/s41586-022-05393-7 |
| 源文件 | 047_Guo_2022_Ultrathin-quantum-light-source-with-van-der-Waal.pdf |

---
# **Ultrathin quantum light source enabled by a nonlinear van der Waals crystal with vanishing interlayer-electronic-coupling** 

**Authors:** Qiangbing Guo<sup>1,2</sup> *†, Xiao-Zhuo Qi<sup>3,4</sup> † Meng Gao<sup>5</sup> , Sanlue Hu<sup>6</sup> , Lishu Zhang<sup>7</sup> , Wenju Zhou<sup>8</sup> , Wenjie Zang<sup>1</sup> , Xiaoxu Zhao<sup>9</sup> , Junyong Wang<sup>2,7</sup> , Bingmin Yan<sup>8</sup> , Mingquan Xu<sup>5</sup> , Yun-Kun Wu<sup>3,4</sup> , Goki Eda<sup>2,7</sup> , Zewen Xiao<sup>6</sup> , Huiyang Gou<sup>8</sup> , Yuan Ping Feng<sup>2,7</sup> , Guang-Can Guo<sup>3,4</sup> , Wu Zhou<sup>5</sup> , Xi-Feng Ren<sup>3,4</sup> *, Cheng-Wei Qiu<sup>10</sup> *, Stephen J. Pennycook<sup>1,2,5</sup> * and Andrew T. S. Wee<sup>2,7</sup> * 

**Affiliations:** 

1Department of Materials Science and Engineering, National University of Singapore, Singapore 117575, Singapore. 

2Centre for Advanced 2D Materials and Graphene Research Centre, National University of Singapore, Singapore 117546, Singapore. 

3Key Laboratory of Quantum Information, CAS, University of Science and Technology of China, Hefei, Anhui 230026, China. 

4Synergetic Innovation Center of Quantum Information & Quantum Physics, University of Science and Technology of China, Hefei, Anhui 230026, China. 

5School of Physical Sciences and CAS Key Laboratory of Vacuum Physics, University of Chinese Academy of Sciences, Beijing 100049, China. 

6Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Wuhan 430074, China. 

7Department of Physics, National University of Singapore, Singapore 117542, Singapore. 

8Center for High Pressure Science and Technology Advanced Research, Beijing 100094, China. 

9School of Materials Science and Engineering, Nanyang Technological University, Singapore 639798, Singapore. 

10Department of Electrical and Computer Engineering, National University of Singapore, Singapore 117583, Singapore. 

*Corresponding author. Email: qb_guo@nus.edu.sg (Q.G.); renxf@ustc.edu.cn (X.-F.R.); chengwei.qiu@nus.edu.sg (C.-W.Q.); stephen.pennycook@cantab.net (S.J.P.); phyweets@nus.edu.sg (A.T.S.W.) 

†These authors contributed equally to this work 

1 

**Abstract:** Interlayer electronic coupling in two-dimensional (2D) materials enables tunable and emergent properties by stacking engineering. However, it also brings significant evolution of electronic structures and attenuation of excitonic effects in 2D semiconductors as exemplified by quickly degrading excitonic photoluminescence and optical nonlinearities in transition metal dichalcogenides when monolayers are stacked into van der Waals structures. Here we report a novel van der Waals crystal, niobium oxide dichloride, featuring a vanishing interlayer electronic coupling and scalable second harmonic generation intensity of up to three orders higher than that of exciton-resonant monolayer WS2. Importantly, the strong second-order nonlinearity enables correlated parametric photon pair generation, via a spontaneous parametric down-conversion (SPDC) process, in flakes as thin as ~46 nm. To our knowledge, this is the first SPDC source unambiguously demonstrated in 2D layered materials, and the thinnest SPDC source ever reported. Our work opens an avenue towards developing van der Waals material-based ultracompact on-chip SPDC sources, and high-performance photon modulators in both classical and quantum optical technologies. 

**One-Sentence Summary:** A novel van der Waals crystal with vanishing interlayer electronic coupling and giant second-order optical nonlinearity is discovered, which enables highperformance quantum light source. 

2 

**Main Text:** Spontaneous parametric down-conversion (SPDC), a second-order nonlinear optical (NLO) process where one photon is fissioned into a pair of correlated photons under energy and momentum conservation, lies at the core of quantum light sources for modern quantum technologies ( _1-4_ ). Currently, SPDC-based quantum light sources are typically enabled by second-order NLO bulk crystals such as beta barium borate (BBO) and lithium niobate (LiNbO3) ( _3, 4_ ), which, however, are intrinsically disadvantageous for hybrid integrated quantum photonics on CMOS-compatible platforms due to their three-dimensional (3D) covalent bonding nature, in addition to the relatively weak nonlinearities. The two-dimensional (2D) layered materials, with unique van der Waals structure, enable bond-free integration without lattice and processing limitations ( _5_ ). They also show enhanced many-body electronic effects and relaxed phase-matching conditions, leading to large optical nonlinearity at the 2D limit ( _6-8_ ), and have therefore attracted intense interest for integrated NLO optoelectronics and photonics ( _1, 5_ ). However, to our knowledge, no unambiguous evidence of any SPDC process has ever been observed in 2D layered materials, primarily due to low second-order NLO conversion efficiencies in so far reported layered materials ( _4, 9, 10_ ). 

On one hand, the nonlinear conversion efficiency is restricted by the vanishing light-matter interaction length due to the atomic thickness ( _6, 8_ ). For example, the absolute light-matter interactions in monolayer (ML) transition metal dichalcogenides (TMDCs) are too weak for practical applications, despite their extremely large second-order susceptibility ( _6_ ). On the other hand, the nonlinear efficiency of many 2D layered materials is not scalable with thickness due to ( **1** ) Centrosymmetry variation with layer-number ( _8, 11_ ). Typically, TMDCs usually stack in _2H_ - polytype by alternate orientation of each ML along the _c_ -axis, thus only odd-layers have nonzero χ<sup>(2)</sup> under the electric dipole approximation ( _12, 13_ ). This is also applicable to other 2D materials including _h_ -BN, group IV monochalcogenides ( _14_ ), PdSe2 ( _15_ ), and AgInP2S6 ( _14_ ). ( **2** ) Significantly modified electronic structure due to strong interlayer electronic coupling that leads to decreased nonlinearity in addition to the self-absorption effects ( _11-17_ ), such as TMDC oddlayers ( _11-13_ ), _α_ -In2Se3 ( _17_ ), and _3R_ -MoS2 ( _8, 14_ ). 

Therefore, a van der Waals crystal with scalable second-order NLO response is highly desirable, especially for the rapidly developing hybrid integrated photonic platforms where facile van der Waals integration will facilitate unprecedented technology opportunities ( _1, 5, 18, 19_ ). Here, a novel van der Waals crystal niobium oxide dichloride (NbOCl2) is presented that features vanishing interlayer electronic coupling, non-centrosymmetric structure, large in-plane anisotropy as well as scalable and strong second-harmonic generation (SHG) response of up to three orders of magnitude greater than that of monolayer WS2. The giant classical second-order nonlinearity stimulates us to explore its quantum counterparts providing the quantum-classic correspondence ( _9_ ). For the first time, nonclassical parametric photon pair generation via the SPDC process was unambiguously observed in flakes as thin as ~46 nm, with a figure of merit for SPDC efficiency as large as 49000 GHz W<sup>-1</sup> m<sup>-1</sup> , being 5 orders of magnitude higher than conventional bulky SPDC sources ( _9, 20_ ). Our work demonstrates NbOCl2 as a giant secondorder NLO van der Waals crystal with great potential for applications in both classical and quantum nonlinear optical systems. 

Niobium oxide dichloride crystallizes in the _C2_ space group ( _21, 22_ ) with a van der Waals stacking behavior along the _a_ -axis (Figs. 1A, 1B, and fig. S1) and an interlayer distance of ~0.65 nm. Nb atoms display a one-dimensional (1D) Peierls distortion ( _22_ ), resulting in a polarization along the _b_ -axis and two alternating unequal Nb-Nb distances (L1≠L2) along the _c_ -axis (Fig. 1a), which can be directly observed by atomic-resolved annular dark field-scanning transmission 

3 

electron microscopy (ADF-STEM) characterization and confirmed by the corresponding simulated images (Figs. 1A-E), where alternate Nb-Nb distances can be clearly identified (Figs. 1D and 1E). The single-crystalline nature was further checked and collaboratively confirmed by X-ray diffraction (fig. S2), fast Fourier transform (FFT) pattern (Fig. 1F) and electron energy loss spectroscopy (EELS) mapping images (Fig. 1G and fig. S3). Notably, niobium oxide dichloride crystals can be easily exfoliated by the normal mechanical exfoliation method. Monolayer and few-layer flakes are regularly obtained as well as large rectangular thin flakes (lateral size up to 10<sup>2</sup> μm) with sharp edges (fig. S4), indicative of weak interlayer interaction and strong intralayer crystallographic anisotropy. The exfoliated flakes are stable under ambient conditions with no obvious change in two weeks (figs. S5 and S6). 



**Fig. 1. Structural characterizations.** ( **A** ) Out-of-plane (top) and in-plane (bottom) representations of the crystal structure of NbOCl2. The thickness of a single layer is about 6.5 Å. NbOCl2 crystalizes in the _C2_ space group, in which Nb atoms show a 1D Peierls distortion, inducing a polarization along the _b_ -axis and two alternating unequal Nb-Nb distances (L1≠L2) along the _c_ -axis. ( **B** and **C** ) Cross-section atomic-resolution ADF-STEM image of the crystal viewed along the _b_ -axis and corresponding simulated image (C right). Scale bars, 2 nm in (B), 0.5 nm in (C). ( **D** ) Line intensity profile along the _c_ -axis in (C), showing the alternating unequal Nb-Nb distances. ( **E** ) In-plane atomic-resolution ADF-STEM and corresponding simulated image of the crystal. Scale bars, 0.2 nm. ( **F** ) FFT pattern obtained from a typical in-plane ADFSTEM image. ( **G** ) HAADF image of a flake and corresponding EELS elemental mapping images. Scale bar, 50 nm. 

## **Vanishing interlayer electronic coupling** 

The layer-dependent electronic structures were characterized by STEM-based valence EELS, which is known as a powerful tool for studying optical excitations in nanostructures with ultrahigh spatial and energy resolutions ( _23_ ). Figure 2A shows the normalized EELS results for different layers, where we can see that the optical excitation starts from around 1.6 eV but remains a low intensity up to 3 eV. Significant optical excitation only appears after 3 eV and comes to its first peak at around 4 eV. As shown in Fig. 2B, through fitting the onset region of EELS, a bandgap of ~1.62 eV is derived for bilayer flakes. The bandgaps for other flakes are also extracted (~1.60 eV for 4-layer, 1.60 eV for 10-layer and 1.61 eV for 18-layer flakes 

4 

investigated here, see Fig. 2B), which, impressively, exhibit almost no energy shift (experimental energy resolution of 0.021 eV) and are very close to that of the bilayer flakes. In other word, the bandgap is insensitive to thickness (or layer number). As seen from Fig. 2C, this is in stark contrast with other typical 2D layered materials, especially TMDCs and black phosphorus (bP) whose bandgaps evolve significantly with layer number due to considerable interlayer coupling ( _13, 24, 25_ ). 

The weak bandgap evolution is supported by the electronic structure calculations. The electronic structures for monolayer, bilayer and bulk forms were calculated and shown in Figs. 2D-F, respectively. Indeed, a very close bandgap can be seen in all layers (the results are also included in Fig. 2C for reference), being consistent with the experimental results ( _26_ ). From the electronic structures, we can derive that an indirect transition exists for all thicknesses, excluding a band structure crossover (direct to indirect evolution as exists in TMDCs due to strong interlayer electronic coupling ( _27_ )). By carefully analyzing the electronic structure, the low optical excitation intensity below 3eV and the peak at around 4 eV (well beyond the bandgap) result from the quite localized Nb- _4d_ orbitals around the valence band maximum that contribute little to the optical excitation, and a gap in the upper valence band (a detailed analysis can be found in ( _28_ ) and fig. S9) ( _22_ ). This can be clearly demonstrated by the calculated absorption spectrum and further supported by experimental optical absorption measurement (fig. S10). 

To further reveal the origin of weak interlayer electronic coupling, we calculated the interlayer charge density, as shown in Fig. 2G (see fig. S11 for more details). The electrons are mainly localized in the intralayer (mostly on Nb and O atoms, fig. S11) with negligible distribution in the interlayer region, implying mainly in-plane bonding. This can be further evidenced by the interlayer differential charge density (Fig. 2H) that is calculated by assembling the bulk system from isolated monolayers and reveals a charge redistribution process during interlayer coupling ( _25_ ). Also, a negligible charge redistribution can be found in the interlayer region, indicating almost no covalency in the out-of-plane direction. By contrast, significant charge distribution can be found in the interlayer region of TMDCs and bP, indicative of stronger interlayer bonding ( _24, 25_ ). This rather weak interlayer coupling character in NbOCl2 can be understood as follows. After grabbing an electron from Nb atom, the p-shell of Cl atom is complete and becomes inert. Consequently, the interlayer interaction/bonding is rather weak as Nb and O atoms are sandwiched by Cl atoms. The ionic bond of Nb-Cl is different from the Mo-S bond in MoS2, for example, which is more covalent ( _25, 27_ ). 

To gain more insights into the weak interlayer interactions, we also calculated and compared the interlayer binding energy, cleavage energy and translation energy, all of which reveal relatively low levels (fig. S12). Besides, vibrational properties were also studied via Raman spectroscopy (S4 in ( _28_ )), and a thickness-insensitive and strongly in-plane anisotropic Raman response was observed (figs. S13-S16). The Raman peak corresponding to mostly out-of-plane vibration also demonstrates a weak pressure- and temperature-dependence (fig. S17), pointing towards a weak interlayer vibrational coupling that deserves further investigations. 

5 



**Fig. 2. Weak interlayer electronic coupling.** ( **A** ) STEM-based valence EELS results for NbOCl2 flakes of different thicknesses. The curves are normalized and an offset along the _y_ -axis is adopted for each curve for clarity. ( **B** ) Corresponding enlargements of the onset region in (A), which are fitted by a tangent method. ( **C** ) Comparison of bandgap evolution with thickness among typical 2D layered materials. Detailed information can be found in table S1. Clearly, a quite weak bandgap evolution in NbOCl2 can be seen from both theoretical calculations and experimental results, compared with other typical layered materials. ( **D-F** ) Calculated electronic structures and projected density of states (PDOS) for monolayer (D), bilayer (E) and bulk (F), respectively. More details can be found in ( _28_ ) and fig. S9. ( **G** ) Interlayer charge density with an isosurface of 0.2 e Bohr - 3. ( **H** ) Interlayer differential charge density with an isosurface of 0.0007 e Bohr<sup>-3</sup> . This is calculated through assembling the bulk system from isolated monolayers, demonstrating a charge redistribution process. Yellow and purple color denote depleted and accumulated charge density, respectively. Both (G) and (H) show charge mainly distributes in the intralayer region, illustrating a negligible electronic wavefunction overlap between layers. 

## **Classical second-order optical nonlinearity** 

The second-order NLO response of NbOCl2 was investigated by SHG experiments under a back reflection configuration (Fig. 3A). As shown in Fig. 3B, strong emission signals at half the corresponding excitation wavelengths were observed, with a quadratic excitation-powerdependence (Fig. 3C and fig. S18), being a typical SHG process. The SHG intensity undergoes a slow increase when approaching to shorter wavelength and starts to become obvious from 

6 

around 400 nm, which is well consistent with the EELS results (Fig. 2A) and optical absorption characters (figs. S10). Specifically, the SHG intensity increases with EELS intensity. This is because the EELS probability is intimately related to the local density of optical states (LDOS) ( _23_ ), which dominates the transition rate from two-photon excited state to the ground state and thus the SHG intensity ( _29, 30_ ). As known from Fig. 2A and discussions above, the spectral range (400-470 nm) for SHG measurements here locates within the low-optical-excitation range, thus weak enhancement/resonance is expected. A considerable higher increment shall be expected upon approaching shorter wavelengths as the optical excitation only starts to gain considerable strength from ~3eV towards its first peak at ~4 eV, which, nevertheless, is limited by the available detectors and laser sources in our laboratory. 

As shown in Fig. 3D, the SHG response is also highly in-plane anisotropic with a maximum response along the crystal polarization direction ( _b_ -axis), which can be well explained and fitted based on the crystal symmetry analysis (see details in S5.2 in ( _28_ )). Intriguingly, the overall SHG intensity also exhibits a strong azimuthal dependence on excitation with a maximum along the _b_ - axis and minimum along the _c_ -axis (fig. S20), due to low crystallographic symmetry, being basically different from TMDCs whose overall SHG response show no polarization dependence ( _29-31_ ). In particular, the high orthorhombic SHG contrast promises an easier crystallographic orientation identification and other polarization-related second-order nonlinear applications that are beyond the reach of TMDCs ( _12, 31-35_ ). 

As the polar space group of bulk NbOCl2 underpins a noncentrosymmetric character, along with the weak interlayer electronic coupling, we checked the layer-number dependent SHG intensity. As shown in Figs. 3E and 3F, a positive scaling of SHG intensity with layer number, in a quadratic behavior (within the penetration depth and coherence length, see S5.3 in ( _28_ )), is observed. Additional interference effects should be considered for the peaks and dips in Fig. 3H when the thickness is beyond the coherence length (see S5.3 in ( _28_ ) and fig. S23 for detailed analysis). As a comparison, we also measured the layer-dependent SHG intensity of WS2 where the SHG response only exists in odd-layers and quickly decreases with layer number (fig. S24). Notably, scalable and strong SHG intensity can be obtained in NbOCl2 flakes, up to a level well beyond the access of monolayer WS2 (up to 10<sup>2-3</sup> times, see Figs. 3F and 3H) though that of monolayer NbOCl2 is weaker (fig. S21). It’s noteworthy here that the SHG at 404 nm is strongly _C_ -exciton resonant for monolayer WS2 ( _30_ ) but weakly resonant for NbOCl2. The effective second-order nonlinear coefficient ( _deff_ ) was further calculated (see S5.4 in ( _28_ ) and shown in Fig. 3G) and a layer-independent and high value of ~200 pm/V can be derived (comparison with other χ<sup>(2)</sup> materials can be referred to S5.4 in ( _28_ ), table S4 and fig. S25), benefiting from the vanishing interlayer coupling electronic structure and strong in-plane polarization. This layer independence of _deff_ is also in contrast with that of TMDCs (including _3R_ -MoS2 and _2H_ -TMDC odd layers) of which evolving electronic structures bring significant change in nonlinear susceptibilities ( _12, 13_ ). 

7 



**Fig. 3. Anisotropic and scalable SHG response.** ( **A** ) Schematic illustration of the measurement geometry. ( **B** ) SHG spectra at different excitation wavelengths. ( **C** ) Typical pump power dependent SHG intensity, which can be linearly fitted with a slope of 2.07, indicating the quadratic nature of the nonlinear optical process. ( **D** ) Polarization-dependent SHG, indicating a highly anisotropic SHG response. ( **E** and **F** ) SHG spectra of layers with different thickness (E) and corresponding thickness-dependent SHG intensity (F) when pumped at 808 nm. SHG intensity scales with layer number in a manner that can be well fitted by a square function as indicated in (F). The SHG intensity of monolayer WS2 under the same condition is also presented for comparison. ( **G** ) Thickness-dependent effective second-order nonlinear coefficient. ( **H)** Thickness-dependent SHG intensity in a broader thickness range (beyond the coherence length) where interference effects will take on a role, and peaks and dips can be observed when further scaling with thickness. Error bars represent standard deviations from ten measurements. 

## **Nonclassical correlated photon pair generation** 

Ultracompact and integratable SPDC sources are under intense development for chip-based photonic quantum circuits but hindered by unavailable high-nonlinearity and integratable thin films ( _4, 36-38_ ). The giant second-order optical nonlinearity in 2D layered NbOCl2 stimulates us to explore it for a quantum light source. Accordingly, as illustrated in Figs. 4A and 4B, the SPDC process was firstly checked on a subwavelength NbOCl2 flake (thickness of ~150 nm, exfoliated on a transparent sapphire substrate) with a laser at 404 nm. Photon pair generation was recorded by registering photon coincidences between two detectors ( _4, 36_ ). The normalized second-order correlation functions g<sup>(2)</sup> (τ) measured on sample and blank substrate are presented in Figs. 4C and 4D, respectively, where a peak at zero-time delay means simultaneous arrival of one photon at each detector and thus is a signature of correlated photon pair generation. An 

8 

obvious two-photon correlation peak with a peak-to-background ratio well over 2 at zero-time delay (g<sup>(2)</sup> (0)) was observed in the sample while not in the substrate, unambiguously demonstrating a correlated photon pair generation via the SPDC process in the sample as the effects of thermal light bunching and substrate can be excluded ( _4, 36, 38_ ). In addition, the g<sup>(2)</sup> (0) value under different pumping power was also measured and exhibits an inverse pump powerdependence (Fig. 4E), further evidencing a photon pair generation process. The polarization dependent response (Fig. 4F) indicates the pump, signal and idler photons are all polarized along the crystallographic _b_ -axis. The pump power-dependent photon pair coincidence rate was calculated from the data in Fig. 4E and follows a linear scaling relation (Fig. 4G), being a typical feature of the SPDC process (see S6.2 in ( _28_ ) for detailed analysis) ( _2, 4, 9_ ). Notably, with a pump power of 59 mW (available maximum power with our laser), a coincidence rate of ~86 Hz is detected. When the detection loss is considered, the actual value could be ~430 kHz with a figure of merit of 49000 GHz W<sup>-1</sup> m<sup>-1</sup> , which is of several orders of magnitude higher than conventional on-chip or bulky SPDC sources (see S6.1 in ( _28_ ) for detailed comparison) ( _9, 20_ ). 

As shown in Fig. 4H, we also measured the SPDC response in flakes of different thicknesses, of which the coincidence rate increases with thickness following a quadratic relation as expected (see S6.2 in ( _28_ ) for detailed analysis) ( _2, 9_ ). Impressively, a SPDC response can be unambiguously observed in flakes as thin as 46 nm (corresponding normalized second-order correlation functions can be found in fig. S26) which, to the best of our knowledge, is the thinnest SPDC source that has ever been reported ( _2_ ). It is noteworthy that higher coincidence rate could be obtained by optimizing the pump conditions (power and wavelength) and additional enhancement effects (for example, from resonant structures) ( _4, 36-39_ ), and consequently thinner SPDC sources might be expected. 

9 



**Fig. 4. Nonclassical parametric photon pair generation via SPDC** . ( **A** ) Schematic illustration of the SPDC process, where a high-energy pump photon (𝜔𝑝) converts into a pair of low-energy photons consisting of a signal photon (𝜔𝑠) and an idler photon (𝜔𝑖). The NbOCl2 flakes exfoliated on a sapphire substrate were used for measurements. ( **B** ) Schematic illustration of the optical setup for SPDC experiments. PBS, polarizing beam splitter. HWP, half-wave plate. SPD, single-photon detector. The band pass filter centers at 810 nm with a 10 nm full-width-at-halfmaximum (FWHM). ( **C** and **D** ) Normalized two-photon temporal correlation functions of the sample (C) and blank sapphire substrate (D) at different pump power. ( **E** ) Pump powerdependent normalized correlation function at zero-time delay. ( **F** ) The normalized two-photon temporal correlation under different polarization configurations. The pump polarization is along the crystallographic _b_ -axis (denoted as H), HH (VV) represents the signal and idler photons are polarized parallel (perpendicular) to the pump. ( **G** ) Pump power-dependent coincidence rate. ( **H** ) Thickness dependent coincidence rate at a pump power of 3 mW. 

As interlayer electronic coupling plays a vital role in shaping the properties of 2D materials-as particularly exemplified by the recently emerging twistronics that fundamentally results from interlayer coupling and hybridization effects ( _39-43_ )-this interlayer electronically decoupling system would be an interesting and complementary building block for atomic-scale Legos ( _5, 44, 45_ ) and new physics and functionalities could be expected, in addition to the scalable optical nonlinearity reported in this work. 

10 

## **References and Notes** 

1. A. W. Elshaari, W. Pernice, K. Srinivasan, O. Benson, V. Zwiller, Hybrid integrated quantum photonic circuits. _Nat. Photonics_ **14** , 285-298 (2020). doi:10.1038/s41566-0200609-x 

2. Y. Wang, K. D. Jöns, Z. Sun, Integrated photon-pair sources with nonlinear optics. _Appl. Phys. Rev._ **8** , 011314 (2021). doi: 10.1063/5.0030258 

3. L. Li, Z. Liu, X. Ren, S. Wang, V.-C. Su, M.-K. Chen, C. H. Chu, H. Y. Kuo, B. Liu, W. Zang, G. Guo, L. Zhang, Z. Wang, S. Zhu, D. P. Tsai, Metalens-array–based highdimensional and multiphoton quantum source. _Science_ **368** , 1487-1490 (2020). doi:10.1126/science.aba9779 

4. T. Santiago-Cruz, V. Sultanov, H. Zhang, L. A. Krivitsky, M. V. Chekhova, Entangled photons from subwavelength nonlinear films. _Opt. Lett._ **46** , 653-656 (2021). doi:10.1364/OL.411176 

5. Y. Liu, Y. Huang, X. Duan, Van der Waals integration before and beyond two-dimensional materials. _Nature_ **567** , 323-333 (2019). doi:10.1038/s41586-019-1013-x 

6. H. Hong, C. Wu, Z. Zhao, Y. Zuo, J. Wang, C. Liu, J. Zhang, F. Wang, J. Feng, H. Shen, J. Yin, Y. Wu, Y. Zhao, K. Liu, P. Gao, S. Meng, S. Wu, Z. Sun, K. Liu, J. Xiong, Giant enhancement of optical nonlinearity in two-dimensional materials by multiphoton-excitation resonance energy transfer from quantum dots. _Nat. Photonics_ **15** , 510-515 (2021). doi:10.1038/s41566-021-00801-2 

7. G. Wang, X. Marie, I. Gerber, T. Amand, D. Lagarde, L. Bouet, M. Vidal, A. Balocchi, B. Urbaszek, Giant enhancement of the optical second-harmonic emission of WSe2 monolayers by laser excitation at exciton resonances. _Phys. Rev. Lett._ **114** , 097403 (2015). doi:10.1103/PhysRevLett.114.097403 

8. J. Shi, P. Yu, F. Liu, P. He, R. Wang, L. Qin, J. Zhou, X. Li, J. Zhou, X. Sui, S. Zhang, Y. Zhang, Q. Zhang, T. C. Sum, X. Qiu, Z. Liu, X. Liu, 3R MoS2 with Broken Inversion Symmetry: A Promising Ultrathin Nonlinear Optical Device. _Adv. Mater._ **29** , 1701486 (2017). doi:10.1002/adma.201701486 

9. L. Marini, L. G. Helt, Y. Lu, B. J. Eggleton, S. Palomba, Constraints on downconversion in atomically thick films. _J. Opt. Soc. Am. B_ **35** , 672 (2018). doi:10.1364/josab.35.000672 

10. H. Dinparasti Saleh, S. Vezzoli, L. Caspani, A. Branny, S. Kumar, B. D. Gerardot, D. Faccio, Towards spontaneous parametric down conversion from monolayer MoS2. _Sci. Rep._ **8** , 3862 (2018). doi:10.1038/s41598-018-22270-4 

11. N. Kumar, S. Najmaei, Q. Cui, F. Ceballos, P. M. Ajayan, J. Lou, H. Zhao, Second harmonic microscopy of monolayer MoS2. _Phys. Rev. B_ **87** , 161403 (2013). doi:10.1103/PhysRevB.87.161403 

12. Y. Li, Y. Rao, K. F. Mak, Y. You, S. Wang, C. R. Dean, T. F. Heinz, Probing symmetry properties of few-layer MoS2 and h-BN by optical second-harmonic generation. _Nano Lett._ **13** , 3329-3333 (2013). doi:10.1021/nl401561r 

13. C. T. Le, J. Kim, F. Ullah, A. D. Nguyen, T. N. Nguyen Tran, T. E. Le, K. H. Chung, H. Cheong, J. I. Jang, Y. S. Kim, Effects of interlayer coupling and band offset on second 

11 

harmonic generation in vertical MoS2/MoS2(1-x)Se2x structures. _ACS Nano_ **14** , 4366-4373 (2020). doi:10.1021/acsnano.9b09901 

14. J. Zhang, W. Zhao, P. Yu, G. Yang, Z. Liu, Second harmonic generation in 2D layered materials. _2D Mater._ **7** , 042002 (2020). doi:10.1088/2053-1583/abaf68 

15. J. Yu, X. Kuang, J. Li, J. Zhong, C. Zeng, L. Cao, Z. Liu, Z. Zeng, Z. Luo, T. He, A. Pan, Y. Liu, Giant nonlinear optical activity in two-dimensional palladium diselenide. _Nat. Commun._ **12** , 1083 (2021). doi:10.1038/s41467-021-21267-4 

16. Y. Song, S. Hu, M.-L. Lin, X. Gan, P.-H. Tan, J. Zhao, Extraordinary second harmonic generation in ReS2 atomic crystals. _ACS Photonics_ **5** , 3485-3491 (2018). doi:10.1021/acsphotonics.8b00685 

17. L. Hu, X. Huang, Peculiar electronic, strong in-plane and out-of-plane second harmonic generation and piezoelectric properties of atom-thick α-M2X3 (M = Ga, In; X = S, Se): role of spontaneous electric dipole orientations. _RSC Adv._ **7** , 55034-55043 (2017). doi:10.1039/c7ra11014f 

18. J. Leuthold, C. Koos, W. Freude, Nonlinear silicon photonics. _Nat. Photonics_ **4** , 535-544 (2010). doi:10.1038/nphoton.2010.185 

19. I. Datta, S. H. Chae, G. R. Bhatt, M. A. Tadayon, B. Li, Y. Yu, C. Park, J. Park, L. Cao, D. N. Basov, J. Hone, M. Lipson, Low-loss composite photonic platform based on 2D semiconductor monolayers. _Nat. Photonics_ **14** , 256-262 (2020). doi:10.1038/s41566-0200590-4 

20. G. Marino, A. S. Solntsev, L. Xu, V. F. Gili, L. Carletti, A. N. Poddubny, M. Rahmani, D. A. Smirnova, H. Chen, A. Lemaître, G. Zhang, A. V. Zayats, C. De Angelis, G. Leo, A. A. Sukhorukov, D. N. Neshev, Spontaneous photon-pair generation from a dielectric nanoantenna. _Optica_ **6** , 1416 (2019). doi:10.1364/optica.6.001416 

21. H. Hillebrecht, P. J. Schmidt, H. W. Rotter, G. Thiele, P. Zönnchen, H. Bengel, H.-J. Cantow, S. N. Magonov, M.-H. Whangbo, Structural and scanning microscopy studies of layered compounds MCl3 (M = Mo, Ru, Cr) and MOCl2 (M =V, Nb, Mo, Ru, Os). _J. Alloys. Compd._ **246** , 70-79 (1997). doi:10.1016/S0925-8388(96)02465-6 

22. Y. Jia, M. Zhao, G. Gou, X. C. Zeng, J. Li, Niobium oxide dihalides NbOX2: a new family of two-dimensional van der Waals layered materials with intrinsic ferroelectricity and antiferroelectricity. _Nanoscale Horiz._ **4** , 1113-1123 (2019). doi:10.1039/c9nh00208a 

23. A. Polman, M. Kociak, F. J. Garcia de Abajo, Electron-beam spectroscopy for nanophotonics. _Nat. Mater._ **18** , 1158-1171 (2019). doi:10.1038/s41563-019-0409-1 

24. L. Li, J. Kim, C. Jin, G. J. Ye, D. Y. Qiu, F. H. da Jornada, Z. Shi, L. Chen, Z. Zhang, F. Yang, K. Watanabe, T. Taniguchi, W. Ren, S. G. Louie, X. H. Chen, Y. Zhang, F. Wang, Direct observation of the layer-dependent electronic structure in phosphorene. _Nat. Nanotechnol._ **12** , 21-25 (2017). <mark>doi:10.1038/nnano.2016.171</mark> 

25. Y. Yang, X. Wang, S. C. Liu, Z. Li, Z. Sun, C. Hu, D. J. Xue, G. Zhang, J. S. Hu, Weak interlayer interaction in 2D anisotropic GeSe2. _Adv. Sci._ **6** , 1801810 (2019). doi:10.1002/advs.201801810 

26. A. J. Garza, G. E. Scuseria, Predicting band gaps with hybrid density functionals. _J. Phys. Chem. Lett._ **7** , 4165-4170 (2016). doi:10.1021/acs.jpclett.6b01807 

12 

27. W. Jin, P. C. Yeh, N. Zaki, D. Zhang, J. T. Sadowski, A. Al-Mahboob, A. M. van der Zande, D. A. Chenet, J. I. Dadap, I. P. Herman, P. Sutter, J. Hone, R. M. Osgood, Jr., Direct measurement of the thickness-dependent electronic band structure of MoS2 using angleresolved photoemission spectroscopy. _Phys. Rev. Lett._ **111** , 106801 (2013). doi:10.1103/PhysRevLett.111.106801 

28. Supplementary materials. 

29. X. Zhou, J. Cheng, Y. Zhou, T. Cao, H. Hong, Z. Liao, S. Wu, H. Peng, K. Liu, D. Yu, Strong second-harmonic generation in atomic layered GaSe. _J. Am. Chem. Soc._ **137** , 79947997 (2015). doi:10.1021/jacs.5b04305 

30. K. Yao, E. Yanev, H. J. Chuang, M. R. Rosenberger, X. Xu, T. Darlington, K. M. McCreary, A. T. Hanbicki, K. Watanabe, T. Taniguchi, B. T. Jonker, X. Zhu, D. N. Basov, J. C. Hone, P. J. Schuck, Continuous wave sum frequency generation and imaging of monolayer and heterobilayer two-dimensional semiconductors. _ACS Nano_ **14** , 708-714 (2020). doi:10.1021/acsnano.9b07555 

31. Y. Wang, J. Xiao, S. Yang, Y. Wang, X. Zhang, Second harmonic generation spectroscopy on two-dimensional materials [Invited]. _Opt. Mater. Express_ **9** , 1136-1149 (2019). doi:10.1364/ome.9.001136 

32. Q. Wu, T. D. Hewitt, & X.-C. Zhang, Two-dimensional electro-optic imaging of THz beams. _Appl. Phys. Lett._ **69** , 1026-1028 (1996). doi:10.1063/1.116920 

33. A. V. Platonov, V. P. Kochereshko, E. L. Ivchenko, G. V. Mikhailov, Giant electro-optical anisotropy in type-II heterostructures. _Phys. Rev. Lett._ **83** , 3546-3549 (1999). doi:10.1103/PhysRevLett.83.3546 

34. J. Ribeiro-Soares, C. Janisch, Z. Liu, A. L. Elías, M. S. Dresselhaus, M. Terrones, L. G. Cançado, A. Jorio, Second harmonic generation in WSe2. _2D Mater._ **2** , 045015 (2015). doi:10.1088/2053-1583/2/4/045015 

35. A. Autere, H. Jussila, Y. Dai, Y. Wang, H. Lipsanen, Z. Sun, Nonlinear optics with 2D layered materials. _Adv. Mater._ **30** , 1705963 (2018). doi:10.1002/adma.201705963 

36. C. Okoth, A. Cavanna, T. Santiago-Cruz, M. V. Chekhova, Microscale generation of entangled photons without momentum conservation. _Phys. Rev. Lett._ **123** , 263602 (2019). doi:10.1103/PhysRevLett.123.263602 

37. C. Trovatello, A. Marini, X. Xu, C. Lee, F. Liu, N. Curreli, C. Manzoni, S. Dal Conte, K. Yao, A. Ciattoni, J. Hone, X. Zhu, P. J. Schuck, G. Cerullo, Optical parametric amplification by monolayer transition metal dichalcogenides. _Nat. Photonics_ **15** , 6-10 (2020). doi:10.1038/s41566-020-00728-0 

38. T. Santiago-Cruz, A. Fedotova, V. Sultanov, M. A. Weissflog, D. Arslan, M. Younesi, T. Pertsch, I. Staude, F. Setzpfandt, M. Chekhova, Photon pairs from resonant metasurfaces. _Nano Lett._ **21** , 4423-4429 (2021). doi:10.1021/acs.nanolett.1c01125 

39. Q. Zhang, G. Hu, W. Ma, P. Li, A. Krasnok, R. Hillenbrand, A. Alu, C. W. Qiu, Interface nano-optics with van der Waals polaritons. _Nature_ **597** , 187-195 (2021). doi:10.1038/s41586021-03581-5 

40. E. Y. Andrei, A. H. MacDonald, Graphene bilayers with a twist. _Nat. Mater._ **19** , 1265-1275 (2020). doi:10.1038/s41563-020-00840-0 

13 

41. B. Urbaszek, A. Srivastava, Materials in flatland twist and shine. _Nature_ **567** , 39-40 (2019). doi:10.1038/d41586-019-00704-x 

42. G. Hu, Q. Ou, G. Si, Y. Wu, J. Wu, Z. Dai, A. Krasnok, Y. Mazor, Q. Zhang, Q. Bao, C.-W. Qiu, A. Alu, Topological polaritons and photonic magic angles in twisted alpha-MoO3 bilayers. _Nature_ **582** , 209-213 (2020). doi:10.1038/s41586-020-2359-9 

43. W. Ma, G. Hu, D. Hu, R. Chen, T. Sun, X. Zhang, Q. Dai, Y. Zeng, A. Alu, C.-W. Qiu, P. Li, Ghost hyperbolic surface polaritons in bulk anisotropic crystals. _Nature_ **596** , 362-366 (2021). doi:10.1038/s41586-021-03755-1 

44. A. K. Geim, I. V. Grigorieva, Van der Waals heterostructures. _Nature_ **499** , 419-425 (2013). doi:10.1038/nature12385 

45. K. S. Novoselov, A. Mishchenko, A. Carvalho, A. H. Castro Neto, 2D materials and van der Waals heterostructures. _Science_ **353** , aac9439 (2016). doi:10.1126/science.aac9439 

**Acknowledgments:** Q.G. sincerely thanks Miss Q. Zhang at Shenzhen, Mr. K. Zheng at Ningbo and Mr. G. Xu at Nanchang for help with chemicals and furnace facilities for crystal synthesis and XRD measurements. Q.G. sincerely thanks Dr. M. Li for valuable discussions and M. Wu, Y. Yu and J. Dan for help with STEM. This work was partially carried out at the USTC Center for Micro and Nanoscale Research and Fabrication. 

**Funding:** Q.G., S.J.P. and A.T.S.W acknowledge financial support from MOE Tier 2 grant MOE2017-T2-2-139. W.Z. acknowledges financial support from the National Key R&D Program of China (2018YFA0305800) and Beijing Outstanding Young Scientist Program (BJJWZYJH01201914430039). X.-F.R. and G.-C.G. acknowledge financial support from National Natural Science Foundation of China (NSFC) (Grants No. 61590932, No. 11774333, No. 62061160487, No. 12004373), the Anhui Initiative in Quantum Information Technologies (Grant No. AHY130300), and the Strategic Priority Research Program of the Chinese Academy of Sciences (Grant No. XDB24030601). C.-W.Q. acknowledges financial support from the National Research Foundation, Prime Minister’s Office, Singapore under Competitive Research Program Award NRF-CRP22-2019-0006. X.Z. thanks the support from the Presidential Postdoctoral Fellowship, Nanyang Technological University, Singapore via grant 03INS000973C150. 

**Author contributions:** Q.G. conceived the ideas, designed the experiments, and organized the research project under supervision of A.T.S.W., S.J.P. and C.-W.Q.. Q.G. synthesized the crystals and prepared all samples for the experiments. Q.G., J.W., B.Y., W.J.Zhou, G.E. and H.G. measured Raman spectra. M.G., W.J.Zang., X.Z., M.X., W.Zhou. and S.J.P. carried out STEM related characterizations. X.-Z.Q., Q.G., Y.-K.W., X.-F.R. and G.-C.G. designed and conducted the harmonic generation and parametric down-conversion experiments. S.H., L.Z., Z.X. and Y.P.F. did the theoretical calculations. Q.G. analyzed the data and drafted the manuscript with inputs from all authors. C.-W.Q., S.J.P., A.T.S.W. and X.-F.R. commented and provided major revisions. All authors discussed the results and contributed to the manuscript. 

**Competing interests:** Authors declare that they have no competing interests. 

**Data and materials availability:** All data are available in the main text or the supplementary materials. 

14 

## **Supplementary Materials** 

Materials and Methods Supplementary Text Figs. S1 to S26 Tables S1 to S4 References ( _46_ – _107_ ) 

15 

