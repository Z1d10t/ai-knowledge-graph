# Integrated optical frequency division for microwave and mmWave generation

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | Shu-qin Sun, Beichen Wang, Kai-Kai Liu, M. Harrington, Fatemehsadat Tabatabaei, Ruxuan Liu, Jia-Wei Wang, Samin Hanifi et al. |
| DOI | 10.1038/s41586-024-07057-0 |
| 源文件 | 048_Sun_2024_Integrated-optical-frequency-division-for-microw.pdf |

---
Article 

# **Integrated optical frequency division for microwave and mmWave generation** 

|https://doi.org/10.1038/s41586-024-07057-0<br>Received: 21 July 2023<br>Accepted: 10 January 2024|**Shuman Sun**<sup>**1,6**</sup>**, Beichen Wang**<sup>**1,6**</sup>**, Kaikai Liu**<sup>**2**</sup>**, Mark W. Harrington**<sup>**2**</sup>**, Fatemehsadat Tabatabaei**<sup>**1**</sup>**,**<br>**Ruxuan Liu**<sup>**1**</sup>**, Jiawei Wang**<sup>**2**</sup>**, Samin Hanifi**<sup>**1**</sup>**, Jesse S. Morgan**<sup>**1**</sup>**, Mandana Jahanbozorgi**<sup>**1**</sup>**,**<br>**Zijiao Yang**<sup>**1,3**</sup>**, Steven M. Bowers**<sup>**1**</sup>**, Paul A. Morton**<sup>**4**</sup>**, Karl D. Nelson**<sup>**5**</sup>**, Andreas Beling**<sup>**1**</sup>**,**<br>**Daniel J. Blumenthal**<sup>**2** ✉</sup>**& Xu Yi**<sup>**1,3** ✉</sup>|
|---|---|
|Published online: 6 March 2024||
|Open access|The generation of ultra-low-noise microwave and mmWave in miniaturized,|
|Check for updates|chip-based platforms can transform communication, radar and sensing systems<sup>1–3</sup>.<br>Optical frequency division that leverages optical references and optical frequency<br>combs has emerged as a powerful technique to generate microwaves with superior<br>spectral purity than any other approaches<sup>4–7</sup>. Here we demonstrate a miniaturized<br>optical frequency division system that can potentially transfer the approach to a<br>complementary metal-oxide-semiconductor-compatible integrated photonic<br>platform. Phase stability is provided by a large mode volume, planar-waveguide-based<br>optical reference coil cavity<sup>8,9</sup>and is divided down from optical to mmWave frequency<br>by using soliton microcombs generated in a waveguide-coupled microresonator<sup>10–12</sup>.<br>Besides achieving record-low phase noise for integrated photonic mmWave<br>oscillators, these devices can be heterogeneously integrated with semiconductor<br>lasers, amplifiers and photodiodes, holding the potential of large-volume, low-cost<br>manufacturing for fundamental and mass-market applications<sup>13</sup>.|



Microwave and mmWave with high spectral purity are critical for a wide range of applications<sup>1–3</sup> , including metrology, navigation and spectroscopy. Owing to the superior fractional frequency stability of reference-cavity stabilized lasers when compared to electrical oscillators<sup>14</sup> , the most stable microwave sources are now achieved in optical systems by using optical frequency division<sup>4–7</sup> (OFD). Essential to the division process is an optical frequency comb<sup>4</sup> , which coherently transfers the fractional stability of stable references at optical frequencies to the comb repetition rate at radio frequency. In the frequency division, the phase noise of the output signal is reduced by the square of the division ratio relative to that of the input signal. A phase noise reduction factor as large as 86 dB has been reported<sup>4</sup> . However, so far, the most stable microwaves derived from OFD rely on bulk or fibre-based optical references<sup>4–7</sup> , limiting the progress of applications that demand exceedingly low microwave phase noise. 

Integrated photonic microwave oscillators have been studied intensively for their potential of miniaturization and mass-volume fabrication. A variety of photonic approaches have been shown to generate stable microwave and/or mmWave signals, such as direct heterodyne detection of a pair of lasers<sup>15</sup> , microcavity-based stimulated Brillouin lasers<sup>16,17</sup> and soliton microresonator-based frequency combs<sup>18–23</sup> (microcombs). For solid-state photonic oscillators, the fractional stability is ultimately limited by thermorefractive noise (TRN), which decreases with the increase of cavity mode volume<sup>24</sup> . Large-mode-volume integrated cavities with metre-scale length and a greater than 100 million quality (Q)-factor have been shown recently<sup>8,25</sup> to reduce laser linewidth to Hz-level while maintaining chip footprint 

at centimetre-scale<sup>9,26,27</sup> . However, increasing cavity mode volume reduces the effective intracavity nonlinearity strength and increases the turn-on power for Brillouin and Kerr parametric oscillation. This trade-off poses a difficult challenge for an integrated cavity to simultaneously achieve high stability and nonlinear oscillation for microwave generation. For oscillators integrated with photonic circuits, the best phase noise reported at 10 kHz offset frequency is demonstrated in the SiN photonic platform, reaching −109 dBc Hz<sup>−1</sup> when the carrier frequency is scaled to 10 GHz (refs. 21,26). This is many orders of magnitude higher than that of the bulk OFD oscillators. An integrated photonic version of OFD can fundamentally resolve this trade-off, as it allows the use of two distinct integrated resonators in OFD for different purposes: a large-mode-volume resonator to provide exceptional fractional stability and a microresonator for the generation of soliton microcombs. Together, they can provide major improvements to the stability of integrated oscillators. 

Here, we notably advance the state of the art in photonic microwave and mmWave oscillators by demonstrating integrated chip-scale OFD. Our demonstration is based on complementary metal-oxidesemiconductor-compatible SiN integrated photonic platform<sup>28</sup> and reaches record-low phase noise for integrated photonic-based mmWave oscillator systems. The oscillator derives its stability from a pair of commercial semiconductor lasers that are frequency stabilized to a planar-waveguide-based reference cavity<sup>9</sup> (Fig. 1). The frequency difference of the two reference lasers is then divided down to mmWave with a two-point locking method<sup>29</sup> using an integrated soliton microcomb<sup>10–12</sup> . Whereas stabilizing soliton microcombs to 

> 1Department of Electrical and Computer Engineering, University of Virginia, Charlottesville, VA, USA. 2Department of Electrical and Computer Engineering, University of California Santa Barbara, Santa Barbara, CA, USA.<sup>3</sup> Department of Physics, University of Virginia, Charlottesville, VA, USA.<sup>4</sup> Morton Photonics, Palm Bay, Florida, USA.<sup>5</sup> Honeywell Aerospace Technologies, Plymouth, MN, USA.<sup>6</sup> These authors contributed equally: Shuman Sun, Beichen Wang.<sup>✉</sup> e-mail: danb@ucsb.edu; yi@virginia.edu 

**540** | Nature | Vol 627 | 21 March 2024 



<!-- Start of picture text -->
a Optical reference Optical to mmWave divider mmWave<br>CC-MUTC PD<br>Soliton microcombs PLL output<br>Pump<br>Δ =  f A –  f B – ( n  –  m ) f r f r = ( f A –  f B)/( n  –  m )<br>Laser A f p PD<br>Δ1<br>OBPF PD Microwave<br>Δ2 output<br>Laser B m th n th<br>f B f A PLL<br>f VCO =  f r / M<br>Frequency f n =  f p +  nf r Δ2  =  f B – ( f p +  mf r ) Δ1  =  f A – ( f p +  nf r ) VCO<br>b<br><!-- End of picture text -->

**Fig. 1 | Conceptual illustration of integrated OFD. a** , Simplified schematic. A pair of lasers that are stabilized to an integrated coil reference cavity serve as the optical references and provide phase stability for the mmWave and microwave oscillator. The relative frequency difference of the two reference lasers is then divided down to the repetition rate of a soliton microcomb by feedback control of the frequency of the laser that pumps the soliton. A high-power, low-noise mmWave is generated by photodetecting the OFD soliton microcomb on a CC-MUTC PD. The mmWave can be further divided 

down to microwave through a mmWave to microwave frequency division with a division ratio of _M_ . PLL, phase lock loop. **b** , Photograph of critical elements in the integrated OFD. From left to right are: a SiN 4 m long coil waveguide cavity as an optical reference, a SiN chip with tens of waveguide-coupled ring microresonators to generate soliton microcombs, a flip-chip bonded CC-MUTC PD for mmWave generation and a US 1-cent coin for size comparison. Microscopic pictures of a SiN ring resonator and a CC-MUTC PD are shown on the right. Scale bars, 100 μm (top and bottom left), 50 μm (bottom right). 

long-fibre-based optical references has been shown very recently<sup>30,31</sup> , its combination with integrated optical references has not been reported. The small dimension of microcavities allows soliton repetition rates to reach mmWave and THz frequencies<sup>12,30,32</sup> , which have emerging applications in 5G/6G wireless communications<sup>33</sup> , radio astronomy<sup>34</sup> and radar<sup>2</sup> . Low-noise, high-power mmWaves are generated by photomixing the OFD soliton microcombs on a high-speed flip-chip bonded charge-compensated modified uni-travelling carrier photodiode (CC-MUTC PD)<sup>12,35</sup> . To address the challenge of phase noise characterization for high-frequency signals, a new mmWave to microwave frequency division (mmFD) method is developed to measure mmWave phase noise electrically while outputting a low-noise auxiliary microwave signal. The generated 100 GHz signal reaches a phase noise of −114 dBc Hz<sup>−1</sup> at 10 kHz offset frequency (equivalent to −134 dBc Hz<sup>−1</sup> for 10 GHz carrier frequency), which is more than two orders of magnitude better than previous SiN-based photonic microwave and mmWave oscillators<sup>21,26</sup> . The ultra-low phase noise can be maintained while pushing the mmWave output power to 9 dBm (8 mW), which is only 1 dB below the record for photonic oscillators at 100 GHz (ref. 36). Pictures of chip-based reference cavity, soliton-generating microresonators and CC-MUTC PD are shown in Fig. 1b. 

The integrated optical reference in our demonstration is a thin-film SiN 4-metre-long coil cavity<sup>9</sup> . The cavity has a cross-section of 6 μm width × 80 nm height, a free-spectral-range (FSR) of roughly 50 MHz, an intrinsic quality factor of 41 × 10<sup>6</sup> (41 × 10<sup>6</sup> ) and a loaded quality factor of 34 × 10<sup>6</sup> (31 × 10<sup>6</sup> ) at 1,550 nm (1,600 nm). The coil cavity provides exceptional stability for reference lasers because of its large-mode volume and high-quality factor<sup>9</sup> . Here, two widely tuneable lasers (NewFocus Velocity TLB-6700, referred to as laser A and B) are frequency stabilized to the coil cavity through Pound–Drever–Hall locking technique with a 

servo bandwidth of 90 kHz. Their wavelengths can be tuned between 1,550 nm ( _f_ A = 193.4 THz) and 1,600 nm ( _f_ B = 187.4 THz), providing up to 6 THz frequency separation for OFD. The setup schematic is shown in Fig. 2. 

The soliton microcomb is generated in an integrated, bus-waveguidecoupled Si3N4 micro-ring resonator<sup>10,12</sup> with a cross-section of 1.55 μm width × 0.8 μm height. The ring resonator has a radius of 228 μm, an FSR of 100 GHz and an intrinsic (loaded) quality factor of 4.3 × 10<sup>6</sup> (3.0 × 10<sup>6</sup> ). The pump laser of the ring resonator is derived from the first modulation sideband of an ultra-low-noise semiconductor extended distributed Bragg reflector laser from Morton Photonics<sup>37</sup> , and the sideband frequency can be rapidly tuned by a voltage-controlled oscillator (VCO). This allows single soliton generation by implementing rapid frequency sweeping of the pump laser<sup>38</sup> , as well as fast servo control of the soliton repetition rate by tuning the VCO<sup>30</sup> . The optical spectrum of the soliton microcombs is shown in Fig. 3a, which has a 3 dB bandwidth of 4.6 THz. The spectra of reference lasers are also plotted in the same figure. 

The OFD is implemented with the two-point locking method<sup>29,30</sup> . The two reference lasers are photomixed with the soliton microcomb on two separate photodiodes to create beat notes between the reference lasers and their nearest comb lines. The beat note frequencies are _Δ_ 1 = _f_ A − ( _f_ p + _n_ × _f_ r) and _Δ_ 2 = _f_ B − ( _f_ p + _m_ × _f_ r), where _f_ r is the repetition rate of the soliton, _f_ p is pump laser frequency and _n_ , _m_ are the comb line numbers relative to the pump line number. These two beat notes are then subtracted on an electrical mixer to yield the frequency and phase difference between the optical references and _N_ times of the repetition rate: _Δ_ = _Δ_ 1 − _Δ_ 2 = ( _f_ A − _f_ B) − ( _N_ × _f_ r), where _N_ = _n_ − _m_ is the division ratio. Frequency _Δ_ is then divided by five electronically and phase locked to a low-frequency local oscillator (LO, _f_ LO1) by feedback 

Nature | Vol 627 | 21 March 2024 | **541** 

Article 



<!-- Start of picture text -->
Optical reference lasers OFD locking Optical domain f p +  k  ×  f r<br>Servo Phase noise measurement p<br>LO1<br>Servo PD f<br>PC Δ1 =  f A –  f p BPF AOM Δϕ = ( l  –  k ) ×  � r<br>LO WS EDFA PC BPF P D<br>÷5<br>Laser A PM PD<br>PC PC Reference cavity F BG BPF 200 m fibre delay<br>Laser B PM Δ =  f A –  f B –  N  ×  f r p f p +  k  ×  f r f p +  l  ×  f r p f p +  l  ×  f r<br>PC PC<br>LO TEC f f<br>Electrical domain d.c.<br>PC Servo P D Phase noise measurement f r SM<br>Δ2  =  f B – ( f p –  N  ×  f r ) WS EDFA VOA Prob e T RF 100 GHz output<br>Soliton microcombs Photodiode Bias-tee<br>VCO1 Amp Cavity BPF BPF BPF Amp f r – 5 × RF f VCO2 T f r Harmonicmixer<br>Laser C EDFA SSB-SC EDFA BPF TEC FBG EDFA LO2 1 kd.c.Ω f VCO2 20 GHz output<br>PC PC<br>p f C p f p =  f C +  f VCO1 p f n =  f p +  n  ×  f r Servo PNA<br>f f f VCO2<br>PD<br>Hilbert  transform<br>Oscilloscope<br>PD<br><!-- End of picture text -->

**Fig. 2 | Experimental setup.** A pair of reference lasers is created by stabilizing frequencies of lasers A and B to a SiN coil waveguide reference cavity, which is temperature controlled by a thermoelectric cooler (TEC). Soliton microcomb is generated in an integrated SiN microresonator. The pump laser is the first modulation sideband of a modulated continuous wave laser, and the sideband frequency can be rapidly tuned by a VCO. To implement two-point locking for OFD, the 0th comb line (pump laser) is photomixed with reference laser A, while the – _N_ th comb line is photomixed with reference laser B. The two photocurrents are then subtracted on an electrical mixer to yield the phase difference between the reference lasers and _N_ times the soliton repetition rate, which is then used to servo control the soliton repetition rate by controlling the frequency of the pump laser. The phase noise of the reference lasers and the 

soliton repetition rate can be measured in the optical domain by using dual-tone delayed self-heterodyne interferometry. Low-noise, high-power mmWaves are generated by detecting soliton microcombs on a CC-MUTC PD. To characterize the mmWave phase noise, a mmWave to  microwave frequency division is implemented to stabilize a 20 GHz VCO to the 100 GHz mmWave and the phase noise of the VCO can be directly measured by a phase noise analyser (PNA). Erbium-doped fibre amplifiers (EDFAs), polarization controllers (PCs), phase modulators (PMs), single-sideband modulator (SSB-SC), band pass filters (BPFs), fibre-Bragg grating (FBG) filters, line-by-line waveshaper (WS), acoustic-optics modulator (AOM), electrical amplifiers (Amps) and a source meter (SM) are also used in the experiment. 

control of the VCO frequency. The tuning of VCO frequency directly tunes the pump laser frequency, which then tunes the soliton repetition rate through Raman self-frequency shift and dispersive wave recoil effects<sup>20</sup> . Within the servo bandwidth, the frequency and phase of the optical references are thus divided down to the soliton repetition rate, as _f_ r = ( _f_ A − _f_ B − 5 _f_ LO1)/ _N_ . As the local oscillator frequency is in the 10 s MHz range and its phase noise is negligible compared to the optical references, the phase noise of the soliton repetition rate ( _S_ r) within the servo locking bandwidth is determined by that of the optical references ( _S_ o): _S_ r = _S_ o/ _N_<sup>2</sup> . 

To test the OFD, the phase noise of the OFD soliton repetition rate is measured for division ratios of _N_ = 2, 3, 6, 10, 20, 30 and 60. In the measurement, one reference laser is kept at 1,550.1 nm, while the other reference laser is tuned to a wavelength that is _N_ times of the microresonator FSR away from the first reference laser (Fig. 3a). The phase noise of the reference lasers and soliton microcombs are measured in the optical domain by using dual-tone delayed self-heterodyne interferometry<sup>39</sup> . In this method, two lasers at different frequencies can be sent into an unbalanced Mach–Zehnder interferometer with an acoustic-optics modulator in one arm (Fig. 2). Then the two lasers are separated by a fibre-Bragg grating filter and detected on two different photodiodes. The instantaneous frequency and phase fluctuations of these two lasers can be extracted from the photodetector signals by using Hilbert transform. Using this method, the phase noise of the phase difference between the two stabilized reference lasers is measured and shown in Fig. 3b. In this work, the phase noise of the reference lasers does not reach the thermal refractive noise limit of the reference cavity<sup>9</sup> and is likely to be limited by environmental acoustic and mechanical noises. For soliton repetition rate phase noise measurement, a pair of comb lines with comb numbers _l_ and _k_ are selected by a programmable line-by-line waveshaper and sent into the interferometry. The phase 

noise of their phase differences is measured, and its division by ( _l_ − _k_ )<sup>2</sup> yields the soliton repetition rate phase noise<sup>39</sup> . 

The phase noise measurement results are shown in Fig. 3c,d. The best phase noise for soliton repetition rate is achieved with a division ratio of 60 and is presented in Fig. 3c. For comparison, the phase noises of reference lasers and the repetition rate of free-running soliton without OFD are also shown in the figure. Below 100 kHz offset frequency, the phase noise of the OFD soliton is roughly 60<sup>2</sup> , which is 36 dB below that of the reference lasers and matches very well with the projected phase noise for OFD (noise of reference lasers – 36 dB). From roughly 148 kHz (OFD servo bandwidth) to 600 kHz offset frequency, the phase noise of the OFD soliton is dominated by the servo pump of the OFD locking loop. Above 600 kHz offset frequency, the phase noise follows that of the free-running soliton, which is likely to be affected by the noise of the pump laser<sup>20</sup> . Phase noises at 1 and 10 kHz offset frequencies are extracted for all division ratios and are plotted in Fig. 3d. The phase noises follow the 1/ _N_<sup>2</sup> rule, validating the OFD. 

The measured phase noise for the OFD soliton repetition rate is low for a microwave or mmWave oscillator. For comparison, phase noises of Keysight E8257D PSG signal generator (standard model) at 1 and 10 kHz are given in Fig. 3d after scaling the carrier frequency to 100 GHz. At 10 kHz offset frequency, our integrated OFD oscillator achieves a phase noise of −115 dBc Hz<sup>−1</sup> , which is 20 dB better than a standard PSG signal generator. When comparing to integrated microcomb oscillators that are stabilized to long optical fibres<sup>30</sup> , our integrated oscillator matches the phase noise at 10 kHz offset frequency and provides better phase noise below 5 kHz offset frequency (carrier frequency scaled to 100 GHz). We speculate this is because our photonic chip is rigid and small when compared to fibre references and thus is less affected by environmental noises such as vibration and shock. This showcases the capability and potential of integrated photonic oscillators. 

**542** | Nature | Vol 627 | 21 March 2024 



<!-- Start of picture text -->
a b<br>60<br>Ref. lasers ( N  = 10) Relative noise: Laser A – B<br>40<br>Ref. lasers ( N  = 30) Free running<br>20 Coil cavity referenced<br>Ref. lasers ( N  = 60) 0 Ref. cavity TRN<br>Soliton –20<br>–40<br>–60<br>–80<br>–100<br>–120<br>1,450 1,500 1,550 1,600 1,650 1,700 10 100 1,000 10,000 100,000 1 million<br>Wavelength (nm) Offset frequency (Hz)<br>c 20 d –50<br>Ref. lasers Carrier frequency 100 GHz<br>0 100 GHz free-running soliton –60<br>100 GHz soliton, OFD by 60<br>Projection from ref. lasers<br>–20 –70<br>–40 –80<br>Scaled PSG, 1 kHz offset<br>–60 –90<br>Scaled PSG,10 kHz offset<br>–80 –100<br>–100 –110<br>OFD soliton, 1 kHz offset<br>–120 –120 1/ N 2  projection,1 kHz offset<br>OFD soliton, 10 kHz offset<br>1/ N 2  projection,10 kHz offset<br>–140 –130<br>10 100 1,000 10,000 100,000 1 million 1 10 100<br>Offset frequency (Hz) Division ratio<br>Power (20 dB per div) –1Phase noise (dBc Hz)<br>–1Phase noise (dBc Hz) –1Phase noise (dBc Hz)<br><!-- End of picture text -->

**Fig. 3 | OFD characterization. a** , Optical spectra of soliton microcombs (blue) and reference (Ref.) lasers corresponding to different division ratios. **b** , Phase noise of the frequency difference between the two reference lasers stabilized to coil cavity (orange) and the two lasers at free running (blue). The black dashed line shows the thermal refractive noise (TRN) limit of the reference cavity. **c** , Phase noise of reference lasers (orange), the repetition rate of 

free-running soliton microcombs (light blue), soliton repetition rate after OFD with a division ratio of 60 (blue) and the projected repetition rate with 60 division ratio (red). **d** , Soliton repetition rate phase noise at 1 and 10 kHz offset frequencies versus OFD division ratio. The projections of OFD are shown with coloured dashed lines. 

When comparing to integrated photonic microwave and mmWave oscillators, our oscillator shows exceptional performance: at 10 kHz offset frequency, its phase noise is more than two orders of magnitude better than other demonstrations, including the free-running SiN soliton microcomb oscillators<sup>21,26</sup> and the very recent single-laser OFD<sup>40</sup> . A notable exception is the recent work of Kudelin et al.<sup>41</sup> , in which 6 dB better phase noise was achieved by stabilizing a 20 GHz soliton microcomb oscillator to a microfabricated Fabry–Pérot reference cavity. 

The OFD soliton microcomb is then sent to a high-power, high-speed flip-chip bonded CC-MUTC PD for mmWave generation. Similar to a uni-travelling carrier PD<sup>42</sup> , the carrier transport in the CC-MUTC PD depends primarily on fast electrons that provide high speed and reduce saturation effects due to space-charge screening. Power handling is further enhanced by flip-chip bonding the PD to a gold-plated coplanar waveguide on an aluminium nitride submount for heat sinking<sup>43</sup> . The PD used in this work is an 8-μm-diameter CC-MUTC PD with 0.23 A/W responsivity at 1,550 nm wavelength and a 3 dB bandwidth of 86 GHz. Details of the CC-MUTC PD are described elsewhere<sup>44</sup> . Whereas the power characterization of the generated mmWave is straightforward, phase noise measurement at 100 GHz is not trivial as the frequency exceeds the bandwidth of most phase noise analysers. One approach is to build two identical yet independent oscillators and down-mix the frequency for phase noise measurement. However, this is not feasible for us due to the limitation of laboratory resources. Instead, a new mmWave to microwave frequency division method is 

developed to coherently divide down the 100 GHz mmWave to 20 GHz microwave, which can then be directly measured on a phase noise analyser (Fig. 4a). 

In this mmFD, the generated 100 GHz mmWave and a 19.7 GHz VCO signal are sent to a harmonic radio-frequency (RF) mixer (Pacific mmWave, model number WM/MD4A), which creates higher harmonics of the VCO frequency to mix with the mmWave. The mixer outputs the frequency difference between the mmWave and the fifth harmonics of the VCO frequency: Δ _f_ = _f_ r − 5 _f_ VCO2 and Δ _f_ is set to be around 1.16 GHz. Δ _f_ is then phase locked to a stable local oscillator ( _f_ LO2) by feedback control of the VCO frequency. This stabilizes the frequency and phase of the VCO to that of the mmWave within the servo locking bandwidth, as _f_ VCO2 = ( _f_ r − _f_ LO2)/5. The electrical spectrum and phase noise of the VCO are then measured directly on the phase noise analyser and are presented in Fig. 4b,c. The bandwidth of the mmFD servo loop is 150 kHz. The phase noise of the 19.7 GHz VCO can be scaled back to 100 GHz to represent the upper bound of the mmWave phase noise. For comparison, the phase noise of reference lasers and the OFD soliton repetition rate measured in the optical domain with dual-tone delayed self-heterodyne interferometry method are also plotted. Between 100 Hz to 100 kHz offset frequency, the phase noise of soliton repetition rate and the generated mmWave match very well with each other. This validates the mmFD method and indicates that the phase stability of the soliton repetition rate is well transferred to the mmWave. Below 100 Hz offset frequency, measurements in the optical domain suffer from phase drift 

Nature | Vol 627 | 21 March 2024 | **543** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
a Freq. c 20 d 10<br>6 THz Opt. refs. Ref. lasers 5 Carrier frequency 100 GHz<br>Phase noise at 20 GHz, electrical<br>OFD, by 60 0 Phase noise at 100 GHz, electrical 0<br>100 GHz Phase noise at 100 GHz, optical –5<br>(optical) Kerr solitons –20 –10<br>–15<br>(electrical)100 GHz PD –40 –20 1 2 3 4 5 6 7 8 9 10 20<br>mmFD, by 5 Photocurrent (mA)<br>20 GHz –60 e<br>(electrical) PNA –70 Carrier frequency 100 GHz 1 kHz offset<br>VCO<br>b –80 –80 Scaled PSG, 1 kHz offset 10 kHz offset<br>Free-running  RBW 10 Hz<br>soliton –90<br>OFD soliton –100<br>–100 Scaled PSG,10 kHz offset<br>–120<br>–110<br>–140 –120<br>–50 –25 0 25 50 10 100 1,000 10,000 100,000 1 million 2 4 6 8 10 12 14 16 18 20<br>kHz + 19.7 GHz Offset frequency (Hz) Photocurrent (mA)<br>Power (dBm)<br>–1Phase noise (dBc Hz)<br>Power<br>(20 dB per div) –1Phase noise (dBc Hz)<br><!-- End of picture text -->

**Fig. 4 | Electrical domain characterization of mmWaves generated from integrated OFD. a** , Simplified schematic of frequency division. The 100 GHz mmWave generated by integrated OFD is further divided down to 20 GHz for phase noise characterization. **b** , Typical electrical spectra of the VCO after mmWave to microwave frequency division. The VCO is phase stabilized to the mmWave generated with the OFD soliton (red) or free-running soliton (black). To compare the two spectra, the peaks of the two traces are aligned in the figure. RBW, resolution bandwidth. **c** , Phase noise measurement in the electrical 

domain. Phase noise of the VCO after mmFD is directly measured by the phase noise analyser (dashed green). Scaling this trace to a carrier frequency of 100 GHz yields the phase noise upper bound of the 100 GHz mmWave (red). For comparison, phase noises of reference lasers (orange) and the OFD soliton repetition rate (blue) measured in the optical domain are shown. **d** , Measured mmWave power versus PD photocurrent at −2 V bias. A maximum mmWave power of 9 dBm is recorded. **e** , Measured mmWave phase noise at 1 and 10 kHz offset frequencies versus PD photocurrent. 

in the 200 m optical fibre in the interferometry and thus yield phase noise higher than that measured with the electrical method. 

Finally, the mmWave phase noise and power are measured versus the MUTC PD photocurrent from 1 to 18.3 mA at −2 V bias by varying the illuminating optical power on the PD. Although the mmWave power increases with the photocurrent (Fig. 4d), the phase noise of the mmWave remains almost the same for all different photocurrents (Fig. 4e). This suggests that low phase noise and high power are simultaneously achieved. The achieved power of 9 dBm is one of the highest powers ever reported at 100 GHz frequency for photonic oscillators<sup>36</sup> . 

### **Summary** 

In summary, we have demonstrated low-noise mmWave and microwave generation by using integrated OFD. The achieved phase noise is primarily limited by the technical noise in the reference lasers and can be improved in the future to the TRN limit of the reference cavity by packaging the reference cavity to isolate environmental noises<sup>9</sup> . Common mode noise cancellation can be further leveraged at that point to reduce the relative noise between the two reference lasers to below the TRN limit. In addition, interesting developments in vacuum-gap cavities using microfabricated mirrors have been shown to overcome the TRN limit of planar-waveguide reference cavities<sup>45</sup> . Chip-based stimulated Brillouin lasers are useful in reducing phase noise of optical references at high offset frequency<sup>17,46</sup> . The division ratio demonstrated in this work is limited by the frequency range of our tuneable lasers instead of the optical span of the soliton microcombs. Microcomb-based OFD that leverages 10s THz optical span or even octave span is possible by using dispersion-engineered microresonators<sup>47</sup> . Furthermore, recent developments in the integration of high- _Q_ resonators and stress-optic modulators<sup>48,49</sup> will enable feedback control of microresonator frequency for OFD, which can greatly increase the OFD servo bandwidth. Therefore, although our demonstration has improved the phase noise of integrated photonic microwave and mmWave oscillators by more than 20 dB, it is feasible to further advance the phase noise by several orders of magnitude in the future, allowing integrated photonic oscillators to, in a certain offset frequency range, for example, 10 kHz, 

match some of the best bulk optical OFD oscillators<sup>4</sup> . Finally, there is potential for fully integrated OFD oscillators through heterogeneous integration of SiN reference cavities and microresonators with other components<sup>13</sup> , for example, semiconductor lasers, optical amplifiers and photodiodes. In the OFD oscillator, it is possible to replace bulk commercial lasers with integrated lasers for the optical references without compromising the phase noise performance because some newly developed integrated lasers have shown better coherence than the commercial tuneable lasers used in our experiments<sup>50</sup> . Hybrid integration and heterogeneous integration of lasers and soliton microcombs have been shown recently<sup>51,52</sup> , and given that the soliton nonlinear conversion efficiency has surpassed 50% with a newly developed pump recycling method<sup>53</sup> , it may be possible to eliminate optical amplifiers used in this OFD demonstration in the future. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-024-07057-0. 

1. Koenig, S. et al. Wireless sub-THz communication system with high data rate. _Nat. Photonics_ **7** , 977–981 (2013). 

2. Ghelfi, P. et al. A fully photonics-based coherent radar system. _Nature_ **507** , 341–345 (2014). 

3. Long, D. & Ulaby, F. _Microwave Radar and Radiometric Remote Sensing_ (Artech, 2015). 4. Fortier, T. M. et al. Generation of ultrastable microwaves via optical frequency division. _Nat. Photonics_ **5** , 425–429 (2011). 

5. Xie, X. et al. Photonic microwave signals with zeptosecond-level absolute timing noise. _Nat. Photonics_ **11** , 44–47 (2017). 

6. Nakamura, T. et al. Coherent optical clock down-conversion for microwave frequencies with 10<sup>-18</sup> instability. _Science_ **368** , 889–892 (2020). 

7. Li, J. & Vahala, K. Small-sized, ultra-low phase noise photonic microwave oscillators at X-Ka bands. _Optica_ **10** , 33–34 (2023). 

8. Puckett, M. W. et al. 422 million intrinsic quality factor planar integrated all-waveguide resonator with sub-MHz linewidth. _Nat. Commun._ **12** , 934 (2021). 

9. Liu, K. et al. 36 Hz integral linewidth laser based on a photonic integrated 4.0 m coil resonator. _Optica_ **9** , 770–775 (2022). 

10. Brasch, V. et al. Photonic chip–based optical frequency comb using soliton Cherenkov radiation. _Science_ **351** , 357–360 (2016). 

**544** | Nature | Vol 627 | 21 March 2024 

11. Kippenberg, T. J., Gaeta, A. L., Lipson, M. & Gorodetsky, M. L. Dissipative Kerr solitons in optical microresonators. _Science_ **361** , eaan8083 (2018). 

12. Wang, B. et al. Towards high-power, high-coherence, integrated photonic mmwave platform with microcavity solitons. _Light Sci. Appl._ **10** , 4 (2021). 

13. Xiang, C., Jin, W. & Bowers, J. E. Silicon nitride passive and active photonic integrated circuits: trends and prospects. _Photonics Res._ **10** , A82–A96 (2022). 

14. Matei, D. et al. 1.5 μm lasers with sub-10 MHz linewidth. _Phys. Rev. Lett._ **118** , 263202 (2017). 

15. Kittlaus, E. A. et al. A low-noise photonic heterodyne synthesizer and its application to millimeter-wave radar. _Nat. Commun._ **12** , 4397 (2021). 

16. Li, J., Lee, H. & Vahala, K. J. Microwave synthesizer using an on-chip Brillouin oscillator. _Nat. Commun._ **4** , 2097 (2013). 

17. Gundavarapu, S. et al. Sub-Hertz fundamental linewidth photonic integrated Brillouin laser. _Nat. Photonics_ **13** , 60–67 (2019). 

18. Herr, T. et al. Temporal solitons in optical microresonators. _Nat. Photon._ **8** , 145–152 (2014). 19. Liang, W. et al. High spectral purity Kerr frequency comb radio frequency photonic oscillator. _Nat. Commun._ **6** , 7957 (2015). 

20. Yi, X. et al. Single-mode dispersive waves and soliton microcomb dynamics. _Nat. Commun._ **8** , 14869 (2017). 

21. Liu, J. et al. Photonic microwave generation in the X- and K-band using integrated soliton microcombs. _Nat. Photonics_ **14** , 486–491 (2020). 

22. Bai, Y. et al. Brillouin-Kerr soliton frequency combs in an optical microresonator. _Phys. Rev. Lett._ **126** , 063901 (2021). 

23. Yao, L. et al. Soliton microwave oscillators using oversized billion Q optical microresonators. _Optica_ **9** , 561–564 (2022). 

24. Matsko, A. B., Savchenkov, A. A., Yu, N. & Maleki, L. Whispering-gallery-mode resonators as frequency references. I. Fundamental limitations. _J. Opt. Soc. Am. B_ **24** , 1324–1335 (2007). 

25. Lee, H. et al. Spiral resonators for on-chip laser frequency stabilization. _Nat. Commun._ **4** , 2468 (2013). 

26. Jin, W. et al. Hertz-linewidth semiconductor lasers using CMOS-ready ultra-high- _Q_ microresonators. _Nat. Photonics_ **15** , 346–353 (2021). 

27. Li, B. et al. Reaching fiber-laser coherence in integrated photonics. _Opt. Lett._ **46** , 5201–5204 (2021). 

28. Blumenthal, D. J., Heideman, R., Geuzebroek, D., Leinse, A. & Roeloffzen, C. Silicon nitride in silicon photonics. _Proc. IEEE_ **106** , 2209–2231 (2018). 

29. Swann, W. C., Baumann, E., Giorgetta, F. R. & Newbury, N. R. Microwave generation with low residual phase noise from a femtosecond fiber laser with an intracavity electro-optic modulator. _Opt. Express_ **19** , 24387–24395 (2011). 

30. Tetsumoto, T. et al. Optically referenced 300 GHz millimetre-wave oscillator. _Nat. Photonics_ **15** , 516–522 (2021). 

31. Kwon, D., Jeong, D., Jeon, I., Lee, H. & Kim, J. Ultrastable microwave and soliton-pulse generation from fibre-photonic-stabilized microcombs. _Nat. Commun._ **13** , 381 (2022). 

32. Zhang, S. et al. Terahertz wave generation using a soliton microcomb. _Opt. Express_ **27** , 35257–35266 (2019). 

33. Rappaport, T. S. et al. Wireless communications and applications above 100 GHz: opportunities and challenges for 6G and beyond. _IEEE Access_ **7** , 78729–78757 (2019). 

34. Clivati, C. et al. A VLBI experiment using a remote atomic clock via a coherent fibre link. _Sci. Rep._ **7** , 40992 (2017). 

35. Xie, X. et al. Improved power conversion efficiency in high-performance photodiodes by flip-chip bonding on diamond. _Optica_ **1** , 429–435 (2014). 

36. Sun, K. & Beling, A. High-speed photodetectors for microwave photonics. _Appl. Sci._ **9** , 623 (2019). 

37. Morton, P. A. & Morton, M. J. High-power, ultra-low noise hybrid lasers for microwave photonics and optical sensing. _J. Lightwave Technol._ **36** , 5048–5057 (2018). 

38. Stone, J. R. et al. Thermal and nonlinear dissipative-soliton dynamics in Kerr-microresonator frequency combs. _Phys. Rev. Lett._ **121** , 063902 (2018). 

39. Kwon, D. et al. Reference-free, high-resolution measurement method of timing jitter spectra of optical frequency combs. _Sci. Rep._ **7** , 40917 (2017). 

40. Zhao, Y. et al. All-optical frequency division on-chip using a single laser. _Nature_ https:// doi.org/10.1038/s41586-024-07136-2 (2024). 

41. Kudelin, I. et al. Photonic chip-based low-noise microwave oscillator. _Nature_ https://doi. org/10.1038/s41586-024-07058-z (2024). 

42. Ishibashi, T., Kodama, S., Shimizu, N. S. N. & Furuta, T. F. T. High-speed response of uni-traveling-carrier photodiodes. _Jpn. J. Appl. Phys._ **36** , 6263 (1997). 

43. Beling, A., Xie, X. & Campbell, J. C. High-power, high-linearity photodiodes. _Optica_ **3** , 328–338 (2016). 

44. Li, Q. et al. High-power flip-chip bonded photodiode with 110 GHz bandwidth. _J. Light. Technol._ **34** , 2139–2144 (2016). 

45. Guo, J. et al. Chip-based laser with 1-Hertz integrated linewidth. _Sci. Adv._ **8** , eabp9006 (2022). 

46. Lee, H. et al. Chemically etched ultrahigh-Q wedge-resonator on a silicon chip. _Nat. Photon._ **6** , 369–373 (2012). 

47. Spencer, D. T. et al. An optical-frequency synthesizer using integrated photonics. _Nature_ **557** , 81–85 (2018). 

48. Liu, J. et al. Monolithic piezoelectric control of soliton microcombs. _Nature_ **583** , 385–390 (2020). 

49. Wang, J., Liu, K., Harrington, M. W., Rudy, R. Q. & Blumenthal, D. J. Silicon nitride stress-optic microresonator modulator for optical control applications. _Opt. Express_ **30** , 31816–31827 (2022). 

50. Morton, P. A. et al. Integrated coherent tunable laser (ICTL) with ultra-wideband wavelength tuning and sub-100 Hz Lorentzian linewidth. _J. Light. Technol._ **40** , 1802–1809 (2022). 

51. Stern, B., Ji, X., Okawachi, Y., Gaeta, A. L. & Lipson, M. Battery-operated integrated frequency comb generator. _Nature_ **562** , 401–405 (2018). 

52. Xiang, C. et al. Laser soliton microcombs heterogeneously integrated on silicon. _Science_ **373** , 99–103 (2021). 

53. Helgason, Ó. B. et al. Surpassing the nonlinear conversion efficiency of soliton microcombs. _Nat. Photonics_ **17** , 992–999 (2023). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2024 

Nature | Vol 627 | 21 March 2024 | **545** 

## Article 

### **Data availability** 

Data for Figs. 3 and 4 can be accessed at https://doi.org/10.6084/ m9.figshare.24813927. 

### **Code availability** 

The codes that support the findings of this study are available from the corresponding authors upon reasonable request. 

**Acknowledgements** We acknowledge M. Woodson and S. Estrella from Freedom Photonics for MUTC PD fabrication, Ligentec for SiN microresonator fabrication, K. Vahala at Caltech for the access to tuneable optical filters and gratefully acknowledge DARPA GRYPHON (grant no. HR0011-22-2-0008), National Science Foundation (grant no. 2023775), Advanced Research Projects Agency–Energy (grant no. DE-AR0001042). The views and conclusions contained in 

this document are those of the authors and should not be interpreted as representing official policies of DARPA, ARPA-E or the US Government. 

**Author contributions** X.Y., S.S., B.W., Z.Y., D.J.B., S.M.B., A.B. and P.A.M. designed the experiments. S.S., B.W., R.L., F.T. and S.H. performed the system measurements. K.L., M.W.H., J.W., D.J.B., K.D.N. and P.A.M. developed the reference lasers. J.S.M. and A.B. designed and fabricated the CC-MUTC PDs. S.S., B.W., X.Y., F.T., S.M.B. and A.B. analysed the experimental results. All authors participated in preparing the manuscript. 

**Competing interests** The authors declare no competing interests. 

#### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-024-07057-0. **Correspondence and requests for materials** should be addressed to Daniel J. Blumenthal or Xu Yi. 

**Peer review information** _Nature_ thanks the anonymous reviewers for their contribution to the peer review of this work. Peer reviewer reports are available. **Reprints and permissions information** is available at http://www.nature.com/reprints. 

