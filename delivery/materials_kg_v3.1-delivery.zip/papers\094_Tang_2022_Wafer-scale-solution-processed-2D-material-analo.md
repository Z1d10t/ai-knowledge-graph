# Wafer-scale solution-processed 2D material analog resistive memory array for memory-based computing

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 230 |
| 作者 | B. Tang, H. Veluri, Yida Li, Zhi-Gen Yu, Moaz Waqar, J. Leong, M. Sivan, E. Zamburg et al. |
| DOI | 10.1038/s41467-022-30519-w |
| 源文件 | 094_Tang_2022_Wafer-scale-solution-processed-2D-material-analo.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-022-30519-w **OPEN** 

# Wafer-scale solution-processed 2D material analog resistive memory array for memory-based computing 

Baoshan Tang 1, Hasita Veluri1, Yida Li1, Zhi Gen Yu 2, Moaz Waqar 3, Jin Feng Leong1, Maheswari Sivan 1, Evgeny Zamburg 1, Yong-Wei Zhang 2, John Wang 3 & Aaron V-Y. Thean 1✉ 

Realization of high-density and reliable resistive random access memories based on twodimensional semiconductors is crucial toward their development in next-generation information storage and neuromorphic computing. Here, wafer-scale integration of solutionprocessed two-dimensional MoS2 memristor arrays are reported. The MoS2 memristors achieve excellent endurance, long memory retention, low device variations, and high analog on/off ratio with linear conductance update characteristics. The two-dimensional nanosheets appear to enable a unique way to modulate switching characteristics through the inter-flake sulfur vacancies diffusion, which can be controlled by the flake size distribution. Furthermore, the MNIST handwritten digits recognition shows that the MoS2 memristors can operate with a high accuracy of >98.02%, which demonstrates its feasibility for future analog memory applications. Finally, a monolithic three-dimensional memory cube has been demonstrated by stacking the two-dimensional MoS2 layers, paving the way for the implementation of two memristor into high-density neuromorphic computing system. 

> 1 Department of Electrical and Computer Engineering, National University of Singapore, Singapore 117576, Singapore. 2 Institute of High Performance Computing, Singapore 138632, Singapore.<sup>3</sup> Department of Materials Science and Engineering, National University of Singapore, Singapore 117574, Singapore. ✉email: Aaron.Thean@nus.edu.sg 

1 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 

nalog non-volatile memory devices capable of multi-states like memristors, promise to enable new classes of energyAefficient computation like in-memory computing<sup>1,2</sup> and neuromorphic computing<sup>3,4</sup> to disrupt conventional graphics processing unit (GPU)-based neural-network accelerators. In this case, memory devices assume compute roles beyond just data storage. As such, memory device endurance and variability comparable to logic devices are now desired. However, endurance and variability for analog resistive random access memory (RRAM), especially for resistive switching devices based on traditional amorphous and polycrystalline metal oxides continues to suffer material-level challenges due to the unavoidable tradeoffs between defect stability and defect recovery, forcing limited optimization window between endurance, programming voltage, and memory retention<sup>5</sup> . 

Two-dimensional (2D) materials with a wide variety of electronic properties including an expanded range of vacancy activation energies offer a new palette to engineer the switching materials and their defects for resistive memories<sup>6</sup> . With improved large-scale growth techniques and the compatibility with CMOS integration, emerging 2D materials have attracted increasing attention in memristive devices<sup>7–10</sup> . Recent studies have revealed that 2D materials, with their unique edge and layered properties, can be more accurately tuned to enhance their switching characteristic not seen in oxide-based memristive devices<sup>11,12</sup> . Several intriguing performance milestones have been achieved so far in 2D memristive devices, eg., sub-pA current with femtojoule per bit energy consumption<sup>13</sup> ; operation up to 50 GHz in radio frequency switches<sup>14</sup> ; switching thresholds approaching 100 mV<sup>15</sup> ; stable operation up to 340 °C<sup>11</sup> and switching in sub-nanometer thickness<sup>16,17</sup> . However, most of these reports are based on isolated device without indication of its viability in large-scale arrays. Despite 10 × 10 memristive crossbar arrays being demonstrated by chemical vapor deposition (CVD) h-BN<sup>18,19</sup> , the high growth temperature and post-synthesis transfer process increase the integration complexity, thus impeding their implementation in large-scale circuit application. With low process temperature and compatibility with highprecision optical lithography patterning, solution-processed 2D materials offer a practical approach to co-integrate 2D material with Si CMOS to enhancing future on-chip computational functionality. 

The liquid-exfoliated 2D nanosheets retain pristine crystal quality and clean van der Waals interfaces, thus ensuring excellent charge transport<sup>20,21</sup> . Analogous to the grain boundaries defects in CVD-grown 2D materials<sup>22</sup> , the edge defects in the liquid-exfoliated nanosheets assist the interlayer diffusion of conductive filament (CF) and present an efficient pathway for resistive switching (RS) modulation. This is further enhanced by the ability to control the size distribution and edge defects density of the liquid exfoliated 2D nanosheets<sup>23–27</sup> . Despite the promises, the solution-processed 2D memristors devices reported to date are still challenged by poor endurance, low yield, and large device-to-device variation<sup>25,28,29</sup> . 

In this work, we demonstrate a reliable and scalable approach to fabricate memristor arrays at wafer-scale. Through solution processing and spin-coating on wafer, we produce a continuous thin-film network of monodispersed MoS2 nanosheets. Remarkably, the MoS2 memristor exhibits forming-free switching with a high endurance of 1 × 10<sup>7</sup> cycles, low device-to-device variability (19.7% for set and 18.5% for reset), excellent retention for 10 years and a remarkable wafer-scale crossbar arrays scalability. Indepth materials and property characterization reveal that the RS characteristics of the 2D MoS2 memristors are modulated by the sulfur vacancies (VS) percolation along the flake edges. As a demonstration, we implemented a 3-layer convolutional neural 

network (CNN) model using the MoS2 memristors for the recognition of MNIST handwritten digits. With excellent switching linearity and low variation, our CNN model achieved high recognition accuracy of 98.02%. Furthermore, we proposed a 3D memory cube through layer-by-layer stacking the 2D MoS2 nanosheets in a transfer-free manner, opening a promising pathway for building 3D integrated circuits with 2D materials. 

### Results 

Production of MoS2 nanosheets dispersion. The MoS2 bulk crystal was exfoliated into nanosheets by electrochemical intercalation followed by a mild sonication as illustrated in Fig. 1a (see Method)<sup>20,21</sup> . This process creates a dark green MoS2 suspension (Fig. 1b inset). The optical UV-Vis absorption spectroscopy of the obtained MoS2 suspension exhibits two excitonic peaks near 678 nm and 614 nm, suggesting the high-quality semiconducting MoS2 nanosheets<sup>30,31</sup> . Raman spectroscopy indicates the existence of monolayer to few-layer MoS2 nanosheets (Fig. 1c)<sup>32,33</sup> . Distinct peak positions and high intensity at around 678 nm and 614 nm in photoluminescence spectroscopy (PL) are also observed in exfoliated MoS2 monolayers, consistent with the UVVis absorption spectroscopy, further confirming that the intrinsic electronic properties of MoS2 are preserved (Supplementary Fig. S1). Based on atomic force microscopy statistics, the exfoliated MoS2 nanosheets are about 2.6 nm thick on average, corresponding to few-layer MoS2 (Fig. 1d). By cascade centrifuging<sup>20</sup> , three batches of MoS2 suspensions are obtained with narrow lateral size distribution centered at 0.48 µm, 1.20 µm, and 2.40 µm, denoted as suspension A, B and C, respectively (Fig. 1e). X-ray photoelectron spectroscopy (XPS) of the exfoliated MoS2 nanosheets corroborated that the MoS2 nanosheets exhibit pristine chemical states with no oxidation (Supplementary Fig. S2). The stoichiometry of MoS2 with Mo/S ratio of 1:1.93 is determined from the XPS results, corresponding to MoS2 with sulfur deficiency. The above experimental observations validate the successful exfoliation of the bulk MoS2 crystals into fewlayered sub-stoichiometric MoS2 nanosheets laced with VS. 

Fabrication and characterization of the MoS2 Film. Using the MoS2 nanosheets suspension, we prepared uniform MoS2 thin film on standard 2-inch Si/SO2 wafer via a simple spin coating process, achieving a smooth and continuous surface with roughness of 1.2 nm and average thickness ranging from 10.5 to 11.4 nm (Fig. 2a, Supplementary Fig. S3, 4). The smooth and continuous surface plays a significant role in the enhancement of device yield and reduction of the performance variability. Raman mapping of the patterned letters ‘NUS’ (Fig. 2b–d) together with identical Raman spectra at random spots on the MoS2 film (Fig. 2e) further confirm the superior uniformity and full coverage of the MoS2 film. With 2D layered morphology, the ultrathin MoS2 nanosheets can evenly and tightly overlap with each other to form a continuous thin film with reduced areal density of grain boundaries within the horizontal plane as evidenced by the scanning electron microscopy image (Fig. 2f). 

The obtained MoS2 thin film possesses high crystallinity with perfect hexagonal atomic arrangement of Mo and S atoms in MoS2 basal planes (Fig. 2g), typical of a high-quality MoS2 flake. In addition, the tightly stacked MoS2 layers in the vertical direction have been confirmed by the cross-sectional scanning transmission electron microscopy (STEM) imaging and corresponding electron energy loss spectroscopy (EELS) mapping. As shown in Fig. 2h, the MoS2 stacking layers exhibit large-area plane-to-plane contact with nearly atomically flat 2D interfaces, ensuring efficient charge transport across the MoS2 stacks. EELS mapping of the MoS2 layers demonstrates the preservation of its 

2 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 



<!-- Start of picture text -->
a<br>Intercalation Sonication<br>b 0.4 c d e<br>0.3 100 A B C<br>Bulk<br>0.3<br>80<br>24.0<br>4 Layers 0.2<br>0.2 614 nm 23.3 60<br>678 nm 3 Layers<br>18.5 0.1 40<br>0.1 2 Layers<br>17.9<br>1 Layer 20<br>0.0 0.0<br>500 600 700 800 360 380 400 420 440 0 4 8 0 2 4 6 8<br>Wavelength (nm) Raman Shift (cm -1 ) Thickness (nm)<br>The liquid exfoliation of MoS22 Nanosheets. a Schematic illustration of the liquid exfoliation process of bulk MoS22 crystal. b UV-vis absorption<br>spectrum of MoS2-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2 nanosheets. Raman signal of bulk nanosheets. Raman signal of bulk<br>crystal is also presented for comparison. d Atomic force microscopy statistics indicating the flakeake thickness distribution of the MoS22 dispersions.<br>lateral flakeake size distribution of three types of MoS22 dispersions. To be noted, arb. units refer to arbitrary units.<br>b c d<br>a<br>e 8 f g (110)<br>7 0.209 nm<br>6<br>5 (100)<br>4<br>3<br>2<br>0.601 nm<br>1<br>1 nm<br>350 375 400 425 450<br>Raman Shift (cm -1 )<br>h j k<br>A<br>2 nm<br>i S Mo B A<br>B<br>10 nm<br>150 180 210 240 270<br>Energy Loss (eV)<br>)<br>stin ) n )<br>(brau. stinbru . oitu bstinru .<br>oitn a birtsiD a<br>bApros ( ytisItnen  laNmro ( ytisItnen<br>y<br>tis<br>n<br>Iten<br>rom.<br>N 0.334 nm<br>ytis<br>n<br>Iten<br><!-- End of picture text -->

Fig. 1 The liquid exfoliation of MoS22 Nanosheets. a Schematic illustration of the liquid exfoliation process of bulk MoS22 crystal. b UV-vis absorption spectrum of MoS2-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk-IPA solution. Inset is the photograph of the MoS2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk-IPA dispersion. c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk c Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk Raman spectra of exfoliated MoS2 nanosheets. Raman signal of bulk2 nanosheets. Raman signal of bulk nanosheets. Raman signal of bulk MoS2 crystal is also presented for comparison. d Atomic force microscopy statistics indicating the flakeake thickness distribution of the MoS22 dispersions. e The lateral flakeake size distribution of three types of MoS22 dispersions. To be noted, arb. units refer to arbitrary units. 

Fig. 2 Characterization of spin-cast MoS2 thin film. a Optical image of the wafer-scale MoS2 thin film. b optical image of patterned MoS2 thin film and corresponding Raman mapping of E<sup>1</sup> 2g<sup>mode (c) and A1g mode (d). The scale bar in (b) is 10 μm. e Raman spectra collected on random spots from a. f SEM</sup> image of the MoS2 thin film. The wrinkles are the edges of MoS2 nanosheets. g Atomic resolution high-angle annular dark field (HAADF) STEM image of MoS2 nanosheets (false-colored). h Cross-sectional HAADF-STEM image and i. corresponding elemental mapping of MoS2 thin film. j The cross-sectional ADF-STEM image taken at the junction region of the MoS2 thin film. k EELS spectra of region A and B taken from j. 

3 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 

intrinsic chemical composition without noticeable oxidation due to the room-temperature processing involved in materials preparation and device fabrication (Fig. 2i and Supplementary Fig. S5). Figure 2j shows the junction region of the two MoS2 stacking layers. Two EELS spectra of the S-L1,2 and the Mo-M4,5 edges have been obtained exactly at the junction site (region B) and away from the junction site (region A), respectively (Fig. 2k). It clearly shows that region B has a weaker intensity in S-L1,2 edge, indicative of the sulfur deficiency at the junction region of MoS2 stacks. Furthermore, as an electron donor, VS can effectively tune the work function of MoS2. As shown in Supplementary Fig. S6, the peripheral regions of MoS2 nanosheets possess distinctly more negative potential than the central region, corresponding to lower work function induced by VS. The defective edges serve as a vertical percolation path for VS across the MoS2 stacks, offering a unique approach for the RS modulation of the solution-processable MoS2 memristor by engineering their flake sizes. 

Electrical characterization of the solution processable MoS2 memristor. In order to gain insight into the underlying transport mechanism associated with VS in the MoS2 switching layer, RS switching characteristics of a single MoS2 flake are examined. As shown in the conductive AFM (C-AFM) measurement (Supplementary Fig. S7), a large hysteresis window at low voltage in the I-V curve is observed at the flake edges, while being absent at the center of the flakes, thus revealing the importance of the VS in the RS phenomenon. To be noted, the observed hysteresis in the C-AFM experiment shows the stable and repeatable RS behavior of the MoS2 memristors even in scaled devices down to 10 nm (tip size), demonstrating their ability for high-density memory integration. Furthermore, by applying constant voltage stress on the MoS2 memristors, we observe the characteristic random telegraph signal with two discrete conductance states, revealing the charge trapping and de-trapping related to VS (Supplementary Fig. S8). The sweep rate-dependent set/reset threshold voltages imply that the memory effect of MoS2 memristors is dominated by nanoionics transport mechanism (Supplementary Fig. S9)<sup>16</sup> , further confirming the significant role that VS plays in the RS conduction mechanism in MoS2 memristor. 

Considering that the VS are confined at the edges of the MoS2 nanosheets, a strong correlation between MoS2 nanosheet size and the corresponding RS characteristics is expected. To validate that assumption, memristors with different MoS2 nanosheet sizes are fabricated (Supplementary Fig. S10). Their typical I-V characteristics are shown in Fig. 3a–c. All MoS2 memristors exhibit forming-free switching characteristics, promoted by the presence of VS in the exfoliated MoS2 nanosheets, which would be favorable to produce smooth dielectric breakdown<sup>18,22,34–36</sup> . A clear bipolar switching with stable low resistance state (LRS) and high resistance state (HRS) is observed. Due to the presence of edge-confined VS, an anomalous nanosheet-size dependent RS characteristic have been observed, where the shrinking in the average nanosheets size (λ) results in a reduced set/reset voltage (Vset/Vreset) and their cycle-to-cycle variations. Specifically, the memristor with the smallest MoS2 nanosheets exhibits the lowest Vset (0.65 V)/Vreset (−0.90 V) and cycle-to-cycle switching voltage variations. The discrepancy in the switch voltage arises from the difference in nanosheet size-related VS defect density. Consequently, smaller nanosheets are expected to have higher VS density attributed to increased edge-to-basal plane ratio, implying the possibility of achieving ultra-low switching voltage by modulating the nanosheet size. Meanwhile, the nanosheet size plays an important role in the reduction of the cycle-to-cycle switching voltage variations. This is attributed to more uniform 

average VS percolation length under the circumstance of smaller MoS2 nanosheets (Supplementary Fig. S11). Small MoS2 nanosheets are expected to provide a smoother and more uniform pathway for VS percolation while larger flakes would produce more tortuous channels. The statistical analyses of 50 devices under different flake sizes further confirm the flake size dependent RS characteristics in MoS2 memristor (Supplementary Fig. S12). In order to better understand the geometric effect of the MoS2 nanosheets on the RS characteristics, the diffusion energy landscape of VS is further explored by the density functional theory (DFT) calculations (details in Supplementary Note I, Figure S13). Figure 3d shows the impact of the MoS2 molecular sizes on the VS migration barriers. Clearly, decreasing the MoS2 molecular size results in the reduction of the diffusion energy barrier for VS, reaching a small VS diffusion energy barrier of 0.75 eV, which is consistent with the reported behavior of polycrystalline MoS2 memtransistor<sup>37</sup> . Supported by the DFT calculations, the kinetics of the VS diffusion reveals that the nanosheet size effect is highly related to the VS diffusion barrier along the nanosheets edges, representing an effective way for the engineering of RS in MoS2 memristor. 

Given that the migration of VS is a thermodynamic process, it is expected that the MoS2 memristor should be influenced by temperature. Temperature dependent I-V sweeps at HRS and LRS states have been performed as shown in Fig. 3e, f. For both LRS and HRS profile, the current shows a non-linear relationship with voltage and increases with the increase of temperature, suggesting the existence of Schottky barrier. By considering different transport models, the I-V relationship under HRS and LRS states are well-fitted with Schottky emission model as a linear dependence of J on E<sup>1/2</sup> is obtained, where J is the current density and E is the electric field (Fig. 3g, h). The Schottky emission function is expressed as below: **f f f f f f f f f** 



<!-- Start of picture text -->
f f f f f f f f f<br>J / A * T 2 exp½�qð+B � pqE=4πεrε0=ðkTÞ�<br><!-- End of picture text -->

where T is the absolute temperature, q is the electronic charge, A<sup>*</sup> is the effective Richardson constant, +B is the Schottky barrier height. k is the Boltzmann’s constant, ε0 is the vacuum permittivity, and εr is the optical dielectric constant. From the Schottky emission equation, the barrier height for HRS is calculated as high as 500 meV, whereas, the barrier height is greatly reduced to only 93 meV in LRS state. The doublelogarithmic plots of the I-V curve of MoS2 memristor shows that the HRS state follows trap-associated space-charge limited conduction (SCLC) theory, while the LRS state is governed by Ohmic conduction behavior which is caused by the formation of conductive filaments (Supplementary Fig. S14). At HRS states, since the height of the Schottky barrier is very large, only few electrons can be injected from the metal to the semiconductor in MoS2 because the thermionic current exponentially decreases with the increasing of barrier height. In LRS state, the current gradually increases with increasing temperature, showing semiconductor-like behaviors, excluding the metal conductive filaments (Fig. 3e, g). By plotting ln I a function of T<sup>−1/4</sup> (Fig. S14), the transport characteristics can be well fitted with the Mott-Variable range hopping model (Mott-VRH) at temperature above 110 K<sup>38,39</sup> . This suggests that the electrons hop through the conductive filament composed of VS in the LRS states. 

Based on the above observation, the conduction mechanism of the MoS2 memristor is schematically illustrated in Fig. 3i, j. At HRS, the conduction mechanism follows the SCLC conduction. When positive voltage is applied to the top contact (Ti), the positively charged VS diffuse along the MoS2 nanosheet edges towards bottom contact (Pt). As VS approaching the Pt electrode, the Schottky barrier height is reduced at the Pt-MoS2 interface. 

4 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 



<!-- Start of picture text -->
a 10 -2 b 10 -2 c 10 -2 d 5.0<br>10 -4 10 -4 10 -4 4.0<br>3.0<br>10 -6 10 -6 10 -6<br>2.0<br>10 -8 10 -8 10 -8<br>Suspension A Suspension B Suspension C 1.0<br>10 -10 10 -10 10 -10<br>-2 -1 0 1 2 -2 -1 0 1 2 -2 -1 0 1 2 1.0 1.5 2.5 3.0<br>Voltage (V) Voltage (V) Voltage (V) Flake size (nm)<br>e 600 f 15 g h 10 2<br>LRS HRS 10 3 LRS HRS<br>400 10 1<br>200 300 K 10 10 2 300 K<br>10 0<br>300 K<br>0 130 K 5 10 1 10 -1 3 00 K<br>-200<br>0 90 K 10 0 1 30 K 10 -2<br>-400 90 K<br>-600 -5 10 -1 10 -3<br>-0.4 -0.2 0.0 0.2 0.4 -0.4 0.0 0.4 150 300 450 200 400 600<br>Voltage (V) Voltage (V) E 1/2  (V/cm) 1/2 E 1/2  (V/cm) 1/2<br>i j<br>Thermionic<br>Thermionic<br>e -<br>Tunneling e -<br>Pt MoS2<br>MoS2 Ti Pt<br>Ti<br>LRS HRS<br>)V<br>e<br>)A )A )A ( r<br>( tn ( tn ( tn eirr<br>e e e a<br>rr rr rr b<br>u u u n<br>C C C ois<br>u<br>ffi<br>D<br>2) 2)<br>m m<br>c/ c/<br>A A<br>( J ( J<br><!-- End of picture text -->

Fig. 3 Electrical performance characterization of the MoS2 memristors. a–c 200 representative I-V curves of MoS2 memristors made from suspensions A, B, and C, respectively. To be noted, the electrode size is 5 × 5 μm. d Calculated VS diffusion barrier energy versus flake size. I-V characteristics of MoS2 memristor measured at different temperatures in LRS (e) and HRS (f). Schottky emission fitting for LRS (g) and HRS state (h). Schematic diagrams of the set (i)/reset (j) process and corresponding interface band alignment. The light blue balls represent VS. 

The continuous positive bias causes a large accumulation of VS and eventually results in the formation of VS conductive filaments, bridging the Ti and Pt electrode. The device is set to the LRS state (Fig. 3i). At LRS state, the conduction mechanism follows the Mott-VRH model, where electrons hop through the conductive filament composed of VS. When a negative bias is applied to the top electrode, VS are extracted backwards and the conductive filaments rupture (Fig. 3j). The device is reset to the HRS state. Meanwhile, the depletion of VS at the Pt-MoS2 interfaces leads to the increase in the Schottky barrier associated with reduced current conductance. Due to the migration of VS under voltage bias, we observe a dynamic modulation of the Schottky barrier near the MoS2-Pt interface with 500 meV and 93 meV under HRS and LRS, respectively. Overall, the conduction mechanism in the MoS2 memristors is dominated by the formation and rupture of the conductive filaments due to the percolation of VS along the nanosheet edges. Unlike the stochastic formation of CF in amorphous oxide-based memristor, the solution-processed MoS2 memristor enables a better control over RS characteristic due to the unique edge-confined VS conduction mechanism. Therefore, it provides an effective engineering way for the modulation of the RS characteristics via controlling the size of the MoS2 nanosheets, not possible in conventional oxidesbased memristors<sup>40</sup> . 

Implementation of CNN with the solution-processed MoS2 memristor. The MoS2 memristor shows robust and reliable switching characteristics as supported by their excellent endurance and retention. As shown in Supplementary Fig. S15, the 

time-dependent resistance exhibits little change in ON and OFF state for 1 × 10<sup>5</sup> s without degradation and demonstrates extrapolated 10-year retention at 85 °C. Moreover, the repeatability has been studied through setting/resetting the device by voltage pulses up to 1 × 10<sup>7</sup> cycles (Fig. 4a). The resistances at the LRS and HRS extracted from different pulse cycles show record-high endurance, even comparable to the typical endurance of commercial flash memories<sup>41</sup> . The uniform bipolar RS behavior can also be preserved when the device size is reduced to 100 nm × 100 nm (Supplementary Fig. S16), demonstrating good scalability of the proposed process. Given the superior uniformity of the MoS2 thin film and reliable performance in our MoS2 memristors, the waferscale MoS2 memristors arrays (Fig. 4b inset and Supplementary Fig. S17) were fabricated. To address the device-to-device reproducibility, the distributions of Vset and Vreset obtained by measuring 73 devices over the entire wafer has been done. As shown in Fig. 4b, the variations (defined as σ=V mean) for set and reset voltages are calculated to be only 19.7% and 18.5%, which are much smaller as compared to other solution-processed 2D memory devices<sup>28</sup> . Furthermore, the conductance of a 6 × 6 MoS2 memristor array was programmed into displaying the number “2” and alphabet “D”; spatially representing the analog conductance states across the array, over a period of 1 h without losing its programmed state (Supplementary Fig. S18). 

The dynamic response of the solution-processed MoS2 memristors have been studied under pulsed electric stimuli with different amplitudes, durations and intervals. Overall, an accurate CNN training requires multibit analog resistive states and symmetric conductance change. Therefore, we characterized the 

5 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 



<!-- Start of picture text -->
a 10 5 c 60 e 40<br>HRS 50<br>30<br>40<br>10 4 T = 300 K 30 20<br>20 x160<br>10<br>10<br>P D<br>LRS<br>0 0<br>10 3<br>10 0 10 1 10 2 10 3 10 4 10 5 10 6 10 7 0.00 0.05 0.10 0.15 0.20 0.25 0 20 40 60 80 100<br>Pulse cycles Time (ms) Pulse number<br>b d f 100<br>20 State 1<br>100<br>16<br>95<br>12 10<br>Reset Set<br>8 90<br>1<br>GPU<br>4<br>State 10 This Work<br>0 0.1 85<br>-1.8 -1.2 -0.6 0.0 0.6 1.2 1.8 0 200 400 600 800 1000 0 20 40 60 80 100<br>Voltage (V) Duration (s) Training Epoch<br>g Fully Connected<br>Original Image Compressed Feature Maps<br>28 14<br>28 14<br>Convolutions Pooling VMM VMM<br>+ReLU +ReLU +Softmax<br>CN1 FC1 FC2<br>)(%<br>Ctnou caryu<br>c<br>c<br>A<br><!-- End of picture text -->

Fig. 4 Dynamic response of the MoS2 memristor for memory-based computing. a AC endurance obtained with 1 μs pulse width (1.5 V for set, and -2.0 V for reset). b Statistical distribution of the set/reset voltages for 73 devices measured over the entire wafer. The inset is the MoS2 memristors on a 2-inch wafer. c Potentiation and depression of MoS2 memristor by sequence of pulse train showing high analog on/off conductance ratio. d I-t measured at 0.2 V after sequentially resetting the MoS2 memristors into 10 memory states. e Conductance update as a function of incremental potentiation and depression pulse numbers. f Comparison of classification accuracy of a 3-layer CNN executed in-memory with GPU execution over 100 epochs. GPU execution achieved 98.24% accuracy while proposed technique achieved a similar accuracy 98.02%. g A 3-layer DCNN with 1 convolutional and 2 fully-connected layers used to classify handwritten digits. The convolution layer consists of 5 7 × 7 filters while the hidden node in the fully connected layers has 30 neurons. Notably, MoS2 memristor with flake size of 0.48 um was examined in this section. 

analog conductance response by applying sequence of pulse train consisting of set (1.5 V, 1 us), reset (−2 V, 10 us) for potentiationdepression (P-D) pulses and read pulses (0.1 V, 1 us) after each P-D pulse. As shown in Fig. 4c, the conductivity of the MoS2 memristors show analog potentiation and depression between different resistive states with a remarkably high on/off ratio of 160. The high analog on/off ratio in our MoS2 memristor is beneficial for accessing multiple synaptic weight values in neural network algorithms<sup>40,42</sup> . Each of the ten selected conductive states shows no degradation in conductance over time, indicating excellent multilevel retention capability of the MoS2 memristor (Fig. 4d). The multiple memory states are programmable within single device, (Supplementary Fig. S19), and further demonstrated to be highly reproducible among different devices (Supplementary Fig. S20). Despite our MoS2 memristor showing high analog memory states, the weight updates in an asymmetry way, especially at the start of the P-D cycle where the MoS2 memristor conductance abruptly arises and decays. The abrupt weight update can be ascribed to the fast switch time in our MoS2 memristors due to mobile VS with reduced diffusion barrier 

energy. Indeed, as shown in Supplementary Fig. S21, the MoS2 has a fast switch time of 40 ns at a pulse amplitude of 2.0 V. Therefore, to avoid the abrupt potentiation and depression and reach a linear weight update, an incremental voltage operating scheme with a shorter pulse width and lower amplitude (potentiation: 1.0 V to 1.75 V with 15 mV steps, pulse width 100 ns; depression: −1.5 V to −2.25 V with steps of 15 mV; pulse width 500 ns) was applied to the MoS2 memristor. As a result, symmetric conductance potentiation and depression with nearly linear modulation have been achieved, with an on/off conductance ratio of 10, which is essential to implement reliable lowcomplexity and low-energy analog in-memory matrix multiplication (Fig. 4e)<sup>43–45</sup> . To estimate the effect of the MoS2 memristor on the pattern recognition accuracy, we performed a three-layer CNN simulation based on the MNIST handwritten data set (See details in Supplementary Note II, Figs. S22–S24). Considering the size of the RRAM-array data, the 28 × 28-pixel raw images are compressed into smaller images with 14 × 14 pixels and processed as shown in Fig. 4g. After training the 3-layer deep convolutional neural network (DCNN) implemented 

6 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 

on MoS2 RRAM array with 50,000 images using the in-memory computation technique, we achieved a high accuracy of 98.02% (Fig. 4f and Supplementary Table I). Supplementary Table II benchmarks the overall performance metrics of different 2D materials-based memristors as well as the conventional oxidebased memristors. Our MoS2 memristor shows the best performance in the integration size, endurance, learning accuracy and number of conductance states relative to other 2D materials. Especially, our proposed processes are transfer-free and roomtemperature based, offering great compatibility with thermal budget limited 3D monolithic integration as well as flexible electronics. Moreover, our devices feature an alternate process dimension of performance modulation via flake size engineering, which is lacking in current oxide-based RRAMs. Despite limitations in high switching power and relatively large device variations of the current design, we believe there is still significant opportunity for improvement by materials, devices and circuits co-optimization in the future. 

Demonstration of monolithic 3D memory cube. Monolithic 3D integration (M3D) of memory and logic component leads to high-density device, providing a promising avenue to address the conventional memory wall bottleneck<sup>46,47</sup> . However, for M3D integration of 2D materials, the challenges lie in the hightemperature growth and post-synthesis transfer. On the one hand, the CVD growth process requires high temperature that violates the M3D thermal budget. In M3D, the process temperature of the upper tiers should not exceed a critical temperature of 500 °C, above which, back-end-of-line degradation, silicide deterioration and dopant diffusion in the lower tiers will take place<sup>48</sup> . On the other hand, the post-growth transfer of 2D film with the assistance of polymer film often suffers from problems like film cracks, surface wrinkles and contamination from polymer residues. Those problems often lead to large performance variation and even failure of the devices. More importantly, the transfer process increases the integration complexity, especially for M3D integration, thus impeding their application in large-scale manufacturing. In contrast, solution processing of 2D materials bears several advantages including room temperature processing, substrate agnosticism, low fabrication cost and waferscale scalability, thus representing an ideal platform for M3D integration with 2D materials. 

As a proof of concept, a three-layered memory stack has been fabricated via sequential deposition of Ti, Pt and spin-coating MoS2. The overview of the 3D stacked MoS2 memristor and the corresponding electrical measurements can be found in Supplementary Fig. S25. To study the structure of the 3D stacked MoS2 memristor, cross-sectional TEM and energy-dispersive X-ray spectroscopy (EDS) were carried out. As shown in the Fig. 5a, the 3D stacked MoS2 memristor features a simple configuration in which the adjacent memory layers have the shared contact, demonstrating the successful fabrication of the 3D stacked MoS2 memristor. The MoS2 layers in the top, middle and bottom memristor show similar thickness of around 10 nm, which indicates the controllability of the deposition process and excellent uniformity of the solution-processed MoS2 film. A high-resolution cross-section TEM taken in the middle layer shows the intimate contact between MoS2 and electrodes, ensuring the efficient charge transport and intactness of the structure (Fig. 5b). The delicate 3D structure has been further elaborated by the elemental mapping, which shows the alternative distribution of Pt, Ti, and MoS2 in sequence (Fig. 5c). Each representative layer of the MoS2 memory stack can be accessible and programmable independently, exhibiting stable and bipolar switching characteristics analog to their planar memristor 

counterpart (Fig. 5d, Supplementary Fig. S25d–f). Ultimately, a monolithic 3D circuit has been proposed based on the solutionprocessable 3D MoS2 memristors. Figure 5e depicts a vertically stacked memory architecture with solution-processed 2D MoS2 thin film as the active switching layer, sandwiched between metal lines of top and bottom electrodes. Etch node at the cross-point of the arrays represents an individual memory cell. Benefits provided by room-temperature process, the storage nodes are vertically stacked in a facile manner through a sequential spincoating of 2D MoS2 and deposition of metal contacts. Based on our previous reports on M3D integration<sup>26,49</sup> , inter-layer dielectric between each layer of metal lines and selectors at each node of cross-point can be readily integrated in our monolithic 3D circuits to minimize the cross-talk issue and accurately program each memory cell. As an example, the M3D integrated one transistor one RRAM (1T1R) arrays with corresponding circuit diagram are illustrated in Supplementary Fig. S26. Our demonstration shows that the solution-processed 2D materials can be 3D monolithically integrated in back-end-of-line (BEOL) for high density embedded memory for storage and analog computing. 

### Discussion 

In summary, we demonstrate wafer-scale memristor arrays by using solution-processed MoS2 nanosheets. The solutionprocessed MoS2 memristor arrays exhibit robust and reliable performance with excellent endurance, low device-to-device variation, linear weight updates and high analog on/off ratio. Materials characterization and electrical measurement reveals that the migration of VS along the edges of the MoS2 nanosheets play a critical role, which provides a flake-based way for the RS modulation. The transfer-free processing of 2D layers at room temperature has the potential to be scaled up for mass production, and enable their integration on flexible substrates, thus providing a versatile platform for flexible and wearable electronics. With the excellent properties, the solution-processed MoS2 memristor arrays can achieve 98.02% pattern recognition accuracy. Furthermore, a fully functional 3-layered memristors have been demonstrated based on the solution-processed 2D memristors, which provides a promising strategy for the M3D integration of 2D materials. The present work opens a door for largescale and reliable memory integration based on 2D materials for neuromorphic computing implementation. 

### Methods 

Preparation of MoS2 nanosheets dispersions. Typically, MoS2 single crystal was intercalated with tetraethylammonium bromide (Sigma-Aldrich) solution in acetonitrile (5 mg mL<sup>−1</sup> ). After the electrochemical intercalation, the MoS2 crystal was rinsed with isopropyl alcohol (IPA) three times, followed by ultrasonication in dimethylformamide (DMF). The MoS2 dispersion was subsequently centrifuged at 1000 rate per minute (r.p.m) for 5 min to remove the unexfoliated particles. To prepare nanosheets with different sizes, the supernatant was collected and subjected to a second sonication for 6 h. Subsequently, the dispersions were centrifuged at centrifuge speeds of 1.0 krpm for 5 min. The sediment was collected and re-dispersed in IPA (suspension C). The supernatant was subjected to further centrifuge at 2.0 krpm. Again, the sediment was collected and re-dispersed in IPA (suspension B). The final supernatant was collected and named suspension A. To prepare suspension D, suspension A was further sonicated, followed by centrifuge at 5000 r.p.m for 3 min. The supernatant was collected and named suspension D. 

Fabrication of RRAM devices. To make the device, the MoS2 nanosheets dispersion was directly spin-coated onto Si/SiO2 substrate with pre-patterned bottom contact of Ti/Pt (30 nm/30 nm) at room temperature. After that, Ti contacts (30 nm) were deposited capped with Pt (30 nm) by e-beam evaporator to form the Ti/Pt-MoS2-Ti/Pt crossbar devices. 

Characterization. Room-temperature electrical measurement was conducted in a four-probe station connected to semiconductor parameter analyser (Agilent B1500A) and a waveform function generator (B1530, Agilent). Varied temperature 

7 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 



<!-- Start of picture text -->
ARTICLE NATURE COMMUNICATIONS | https://doi.org/10.1038/s41467-022-30519-w<br>a b Ti c Pt Ti Mo/S<br>Pt MoS2<br>Ti<br>MoS2 Pt<br>5 nm<br>Pt<br>Ti d e<br>MoS2<br>Pt<br>Ti<br>Layer 3<br>MoS2<br>Layer 2<br>Pt<br>Layer 1<br>20 nm Ti<br><!-- End of picture text -->

Fig. 5 Demonstration of 3D stacked 2D MoS2 memristors. Cross-sectional TEM images of the full stack (a) and middle layer (b) of MoS2 memristor. c Elemental mapping of the 3D stacked MoS2 memristor. d I-V characteristics of 3D stacked MoS2 memristors, showing stable and bipolar resistive switching at each layer. e Schematic diagram of 3D memristor array with buried metal interconnects and logic circuits. 

electrical measurement was conducted in a Lakeshore cryo-probe station. During all electrical measurements, the bottom electrode was grounded and top electrode was biased. Optical images were captured with Olympus BX 51M microscope. AFM images were taken with Bruker Dimension Icon in tapping mode. The surface chemistry of the samples was examined with an XPS in a VG ESCALAB 220i-XL system using a monochromatic Al Kα source at the pass energy of 10 eV for high measurement resolution. Raman spectra were obtained on a Renishaw Raman microscope with a 514 nm excitation and a 100× objective. The laser power was kept below 1 mW to avoid damage. The Si peak at 520.7 cm<sup>−1</sup> was used for calibration in the data analysis of Raman and PL spectra. Kelvin probe force microscope (KPFM) was performed using a Park atomic force microscope under ambient conditions. A Si cantilever tip coated with Pt-Ir (SCM-PIT, Bruker Co.) was used in the tapping mode. Electrical contacts to the cantilever were grounded during the measurements. An AC voltage of 2 V was applied to the tip while the tip height was kept constant at 5 nm. The STEM and EELS studies were conducted using a JEOL ARM200F atomic resolution analytical electron microscope operating at 200 kV equipped with a cold field-emission gun and a new ASCOR 5th order aberration corrector and a Gatan Quantum ER spectrometer. For qualitative comparison, both the EELS spectra have been normalized to the Mo peak. 

Calculation details. All calculations were carried out using the density functional theory (DFT) with the generalized Perdew-Burke-Ernzerhof (PBE)<sup>50</sup> and the projector augmented-wave (PAW) pseudopotential plane-wave method<sup>51</sup> as implemented in the Vienna Ab initio Simulation Package (VASP) code<sup>52</sup> . For the PAW pseudopotential of Mo, we included 4d<sup>4</sup> and 5s<sup>2</sup> as valence; For S, the n = 3 shell was included as valence (3s<sup>2</sup> and 3p<sup>4</sup> ). A 12 × 12 × 1 Monkhorst-Pack k- point grid was used for monolayer unit cell geometry optimization and a planewave basis set with an energy cut-off of 500 eV was adopted. The optimized unitcell was used to build the multilayer MoS2 flake with different sizes. In this study, we carried out calculations with the van der Waals correction by employing optB88vdW functional<sup>53</sup> . Good convergence was obtained with these parameters and the total energy was converged to 1.0 × 10<sup>−6</sup> eV per atom. No spin polarization was considered in this study. The energy minimization was performed using the limited memory BFGS method. The climbing-image Nudged Elastic Band (NEB) method<sup>54</sup> was used to figure out the diffusion of S vacancy in the minimum energy landscape and energy barriers. 

Received: 3 October 2021; Accepted: 27 April 2022; 



### References 

1. Veluri, H., Li, Y., Niu, J. X., Zamburg, E. & Thean, A. V.-Y. High throughput, area-efficient, and variation-tolerant 3D In-memory compute system for deep convolutional neural networks. IEEE Internet Things J. https://doi.org/10. 1109/JIOT.2021.3058015 (2021). 

2. Ielmini, D. & Wong, H.-S. P. In-memory computing with resistive switching devices. Nat. Electron. 1, 333–343 (2018). 

3. Pickett, M. D., Medeiros-Ribeiro, G. & Williams, R. S. A scalable neuristor built with Mott memristors. Nat. Mater. 12, 114 (2013). 

4. Wang, Z. et al. Memristors with diffusive dynamics as synaptic emulators for neuromorphic computing. Nat. Mater. 16, 101 (2017). 

5. Nail, C. et al. Understanding RRAM endurance, retention and window margin trade-off using experimental results and simulations. 2016 IEEE International Electron Devices Meeting (IEDM). https://doi.org/10.1109/IEDM.2016. 7838346 (IEEE, 2016). 

6. Dabral, A., Lu, A., Chiappe, D., Houssa, M. & Pourtois, G. A systematic study of various 2D materials in the light of defect formation and oxidation. Phys. Chem. Chem. Phys. 21, 1089–1099 (2019). 

7. Liu, Y. & Gu, F. A wafer-scale synthesis of monolayer MoS2 and their fieldeffect transistors toward practical applications. Nanoscale Adv. 3, 2117–2138 (2021). 

8. Timpel, M. et al. 2D-MoS2 goes 3D: transferring optoelectronic properties of 2D MoS2 to a large-area thin film. npj 2D Mater. Appl. 5, 1–10 (2021). 

9. Nardi, M. V. et al. Versatile and scalable strategy to grow sol–gel derived 2HMoS2 thin films with superior electronic properties: a memristive case. ACS Appl. Mater. Interfaces 10, 34392–34400 (2018). 

10. Lee, C.-S. & Kim, T. H. Large-scale preparation of MoS2/Graphene composites for electrochemical detection of morin. ACS Appl. Nano Mater. 4, 6668–6677 (2021). 

11. Wang, M. et al. Robust memristors based on layered two-dimensional materials. Nat. Electron. 1, 130 (2018). 

### Data availability 

The authors declare that the data that support the findings of this study are available within the article and its Supplementary Information files. All other relevant data are available from the corresponding author upon request. 

### Code availability 

All relevant code or algorithm are available from the corresponding author upon request. 

12. Hui, F. et al. Graphene and related materials for resistive random access memories. Adv. Electron. Mater. 3, 1600195 (2017). 

13. Zhao, H. et al. Atomically thin femtojoule memristive device. Adv. Mater. 29, 1703232 (2017). 

14. Kim, M. et al. Zero-static power radio-frequency switches based on MoS2 atomristors. Nat. Commun. 9, 1–7 (2018). 

15. Xu, R. et al. Vertical MoS2 double-layer memristor with electrochemical metallization as an atomic-scale synapse with switching thresholds approaching 100 mV. Nano Lett. 19, 2411–2417 (2019). 

8 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-30519-w 

16. Ge, R. et al. Atomristor: nonvolatile resistance switching in atomic sheets of transition metal dichalcogenides. Nano Lett. 18, 434–441 (2018). 

17. Wu, X. et al. Thinnest nonvolatile memory based on monolayer h‐BN. Adv. Mater. 31, 1806790 (2019). 

18. Chen, S. et al. Wafer-scale integration of two-dimensional materials in highdensity memristive crossbar arrays for artificial neural networks. Nat. Electron. 3, 638–645 (2020). 

19. Sun, L. et al. Self-selective van der Waals heterostructures for large scale memory array. Nat. Commun. 10, 1–7 (2019). 

20. Backes, C. et al. Production of highly monolayer enriched dispersions of liquid-exfoliated nanosheets by liquid cascade centrifugation. ACS Nano 10, 1589–1601 (2016). 

21. Lin, Z. et al. Solution-processable 2D semiconductors for high-performance large-area electronics. Nature 562, 254 (2018). 

22. Pan, C. et al. Coexistence of grain‐boundaries‐assisted bipolar and threshold resistive switching in multilayer hexagonal boron nitride. Adv. Func. Mater. 27, 1604811 (2017). 

23. Sangwan, V. K. et al. Visualizing thermally activated memristive switching in percolating networks of solution-processed 2D semiconductors. Adv. Funct. Mater. 31, 2107385 (2021). 

24. Tan, C., Liu, Z., Huang, W. & Zhang, H. Non-volatile resistive memory devices based on solution-processed ultrathin two-dimensional nanomaterials. Chem. Soc. Rev. 44, 2615–2628 (2015). 

25. Han, S. T. et al. Black phosphorus quantum dots with tunable memory properties and multilevel resistive switching characteristics. Adv. Sci. 4, 1600435 (2017). 

26. Sivan, M. et al. All WSe2 1T1R resistive RAM cell for future monolithic 3D embedded memory integration. Nat. Commun. 10, 1–12 (2019). 

27. Abdelkader, A., Cooper, A., Dryfe, R. A. & Kinloch, I. How to get between the sheets: A review of recent works on the electrochemical exfoliation of graphene materials from bulk graphite. Nanoscale 7, 6944–6956 (2015). 

28. Son, D. et al. Colloidal synthesis of uniform‐sized molybdenum disulfide nanosheets for wafer‐scale flexible nonvolatile memory. Adv. Mater. 28, 9326–9332 (2016). 

29. Bessonov, A. A. et al. Layered memristive and memcapacitive switches for printable electronics. Nat. Mater. 14, 199–204 (2015). 

30. Eda, G. et al. Photoluminescence from chemically exfoliated MoS2. Nano Lett. 11, 5111–5116 (2011). 

31. Wilcoxon, J., Newcomer, P. & Samara, G. Synthesis and optical properties of MoS2 and isomorphous nanoclusters in the quantum confinement regime. J. Appl. Phys. 81, 7934–7944 (1997). 

32. Lee, C. et al. Anomalous lattice vibrations of single-and few-layer MoS2. ACS Nano 4, 2695–2700 (2010). 

33. Zhan, Y., Liu, Z., Najmaei, S., Ajayan, P. M. & Lou, J. Large‐area vapor‐phase growth and characterization of MoS2 atomic layers on a SiO2 substrate. Small 8, 966–971 (2012). 

34. Bhattacharjee, S. et al. Insights into multi-level resistive switching in monolayer MoS2. ACS Appl. Mater. Interfaces 12, 6022–6029 (2020). 

35. Yin, X. et al. Memristive behavior enabled by amorphous–crystalline 2D oxide heterostructure. Adv. Mater. 32, 2000801 (2020). 

36. Fang, Z. et al. HfOx\TiOx\HfOx\TiOx multilayer-based forming-free RRAM devices with excellent uniformity. IEEE Electron. Device Lett. 32, 566–568 (2011). 

37. Sangwan, V. K. et al. Multi-terminal memtransistors from polycrystalline monolayer molybdenum disulfide. Nature 554, 500–504 (2018). 

38. Choi, S., Yang, Y. & Lu, W. Random telegraph noise and resistance switching analysis of oxide based resistive memory. Nanoscale 6, 400–404 (2014). 

39. Zhang, Y. et al. Metallic to hopping conduction transition in Ta2O5− x/TaOy resistive switching device. Appl. Phys. Lett. 105, 063508 (2014). 

40. Choi, S. et al. SiGe epitaxial memory for neuromorphic computing with reproducible high performance based on engineered dislocations. Nat. Mater. 17, 335–340 (2018). 

41. Zhao, C., Zhao, C. Z., Taylor, S. & Chalker, P. R. Review on non-volatile memory with high-k dielectrics: flash for generation beyond 32 nm. Materials 7, 5117–5145 (2014). 

42. Chen, P.-Y., Gao, L. & Yu, S. Design of resistive synaptic array for implementing on-chip sparse learning. IEEE Trans. Multi-Scale Comput. Syst. 2, 257–264 (2016). 

43. Wu, W. et al. A methodology to improve linearity of analog RRAM for neuromorphic computing. 2018 IEEE Symposium on VLSI Technology. 103104. https://doi.org/10.1109/VLSIT.2018.8510671. (IEEE, 2018). 

44. Chang, C.-C. et al. Challenges and opportunities toward online training acceleration using RRAM-based hardware neural network. 2017 IEEE International Electron Devices Meeting (IEDM). 11.16. 11-11.16. 14. https:// doi.org/10.1109/IEDM.2017.8268373. (IEEE, 2017). 

45. Yao, P. et al. Fully hardware-implemented memristor convolutional neural network. Nature 577, 641–646 (2020). 

46. Batude, P. et al. Advances, challenges and opportunities in 3D CMOS sequential integration. 2011 IEEE International Electron Devices Meeting 

(IEDM). 7.3. 1-7.3. 4. https://doi.org/10.1109/IEDM.2011.6131506. (IEEE, 2011). 

47. Shulaker, M. M. et al. Monolithic 3D integration of logic and memory: Carbon nanotube FETs, resistive RAM, and silicon FETs. 2014 IEEE International Electron Devices Meeting (IEDM). 27.24. 21-27.24. 24. https://doi.org/10.1109/ IEDM.2014.7047120 (IEEE, 2014). 

48. Jiang, J., Parto, K., Cao, W. & Banerjee, K. Ultimate monolithic-3D integration with 2D materials: rationale, prospects, and challenges. IEEE J. Electron Devices Soc. 7, 878–887 (2019). 

49. Chand, U. et al. 2-kbit array of 3-D monolithically-stacked IGZO FETs with low SS-64mV/dec, ultra-low-leakage, competitive μ-57 cm<sup>2</sup> /Vs performance and novel nMOS-only circuit demonstration. 2021 Symposium on VLSI Technology. 1-2 (IEEE, 2021). 

50. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865 (1996). 

51. Blöchl, P. E. Projector augmented-wave method. Phys. Rev. B 50, 17953 (1994). 

52. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio totalenergy calculations using a plane-wave basis set. Phys. Rev. B 54, 11169 (1996). 

53. Klimeš, J., Bowler, D. R. & Michaelides, A. Van der Waals density functionals applied to solids. Phys. Rev. B 83, 195131 (2011). 

54. Henkelman, G., Uberuaga, B. P. & Jónsson, H. A climbing image nudged elastic band method for finding saddle points and minimum energy paths. J. Chem. Phys. 113, 9901–9904 (2000). 

### Acknowledgements 

This work is supported in part by Singapore’s National Research Foundation grant NRFRSS2015-003, NRF-CRP24-2020-0002, and Hybrid Integrated Flexible Electronic System (HiFES) Prog. (hifes.nus.edu.sg), E6 Nanofab. Y-W.Z. acknowledges the support from Singapore A*STAR SERC CRF Award. Many thanks to A*STAR Computational Resource Centre and Singapore National Supercomputer Centre through the use of its high-performance computing facilities and Dr. Chai jianwei and Dr. Yu Bingxue for technical support. 

### Author contributions 

B.T., and A.V.-Y.T. conceived the project and wrote the paper. B.T., Y.L., J.F.L., and M.S. fabricated the RRAM devices. B.T. performed the MoS2 exfoliation, UV-vis, Raman, PL, and electrical measurements. Z.G.Y. and Y.-W.Z. performed the DFT calculation. H.V. contributed to the CNN simulation and data analyses. E.Z. contributed to the AFM measurement and analysis. M.W. and J.W. performed STEM and data analysis. B.T., and A.V.-Y.T. provided input into the design of the experiments and the preparation of the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-30519-w. 

Correspondence and requests for materials should be addressed to Aaron V-Y. Thean. 

Peer review information Nature Communications thanks the anonymous reviewers for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

9 

NATURE COMMUNICATIONS | (2022) 13:3037 | https://doi.org/10.1038/s41467-022-30519-w | www.nature.com/naturecommunications 

