# High thermal conductivity in wafer-scale cubic silicon carbide crystals

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 195 |
| 作者 | Zhe Cheng, Jianbo Liang, K. Kawamura, Hao Zhou, Hidetoshi Asamura, H. Uratani, Janak Tiwari, S. Graham et al. |
| DOI | 10.1038/s41467-022-34943-w |
| 源文件 | 041_Cheng_2022_High-thermal-conductivity-in-wafer-scale-cubic-s.pdf |

---
High Thermal Conductivity in Wafer-Scale Cubic Silicon Carbide Crystals 

Zhe Cheng<sup>1,*</sup> , Jianbo Liang<sup>2,*</sup> , Keisuke Kawamura<sup>3</sup> , Hidetoshi Asamura<sup>4</sup> , Hiroki Uratani<sup>3</sup> , Samuel Graham<sup>5</sup> , Yutaka Ohno<sup>6</sup> , Yasuyoshi Nagai<sup>6</sup> , Naoteru Shigekawa<sup>2</sup> , David G. Cahill<sup>1,*</sup> 

- 1 Department of Materials Science and Engineering and Materials Research Laboratory, University of Illinois at Urbana-Champaign, Urbana, IL 61801, United States. 

- 2 Department of Electronic Information Systems, Osaka Metropolitan University, Sugimoto 3-3138, Sumiyoshi, Osaka 558-8585, Japan. 

- 3 The SIC Division, Air Water Inc. 2290-1 Takibe, Toyoshina Azumino, Nagano 399-8204, Japan. 4 Specialty Materials Department, Electronics Unit, Air Water Inc. 4007-3 Yamato, Azusagawa, Nagano 390-1701, Japan. 

- 5 George W. Woodruff School of Mechanical Engineering, Georgia Institute of Technology, Atlanta, GA 30332, USA. 

- 6 Institute for Materials Research, Tohoku University, 2145-2 Narita, Oarai, Ibaraki 311-1313, Japan. 

- *Corresponding authors: zcheng18@illinois.edu; <u>liang@omu.ac.jp; d-cahill@illinois.edu.</u> 

1 

# **ABSTRACT** 

High thermal conductivity electronic materials are critical components for high-performance electronic and photonic devices as either active functional materials or thermal management materials. We report an isotropic high thermal conductivity over 500 W m<sup>-1</sup> K<sup>-1</sup> at room temperature in high-quality wafer-scale cubic silicon carbide (3C-SiC) crystals, which is the second highest among large crystals (only surpassed by diamond). Furthermore, the corresponding 3C-SiC thin films are found to have record-high in-plane and cross-plane thermal conductivity, even higher than diamond thin films with equivalent thicknesses. Our results resolve a long-lasting puzzle that the literature values of thermal conductivity for 3C-SiC are perplexingly lower than the structurally more complex 6H-SiC. Further analysis reveals that the observed high thermal conductivity in this work arises from the high purity and high crystal quality of 3C-SiC crystals which excludes the exceptionally strong defect-phonon scatterings in 3C-SiC. Moreover, by integrating 3C-SiC with other semiconductors by epitaxial growth, we show that the measured 3CSiC-Si TBC is among the highest for semiconductor interfaces. These findings not only provide insights for fundamental phonon transport mechanisms, also suggest that 3C-SiC may constitute an excellent wide-bandgap semiconductor for applications of power electronics as either active components or substrates. 

2 

# **INTRODUCTION** 

Silicon carbide (SiC) plays a fundamental role in many emerging technologies such as power electronics, optoelectronics, and quantum computing.<sup>1-4</sup> SiC based power devices can lead a revolution in power electronics to replace Si-based technology due to its fast switching speeds, low losses, and high blocking voltage.<sup>5</sup> In power electronics and optoelectronics, the high localized heat flux leads to overheating of devices.<sup>6,7</sup> The increased device temperature degrades their performance and reliability, making thermal management a grand challenge.<sup>6,8</sup> High thermal conductivity (κ) is critical in thermal management design of these electronics and optoelectronics, especially for high-power devices.<sup>9,10</sup> 

Current high κ electronic materials such as hexagonal SiC and AlN have room-temperature c-axis κ of 324 W m<sup>-1</sup> K<sup>-1</sup> for 6H-SiC, 348 W m<sup>-1</sup> K<sup>-1</sup> for 4H-SiC, and 321 W m<sup>-1</sup> K<sup>-1</sup> for AlN, which are lower than metals such as silver and copper (~400 W m<sup>-1</sup> K<sup>-1</sup> ).<sup>11,12</sup> It is notable that the widely-used high κ value (490 W m<sup>-1</sup> K<sup>-1</sup> ) for 6H-SiC is from Slack’s measurements back to 1964 with a steadystate technique.<sup>13,14</sup> Recent more advanced measurements based on time-domain thermoreflectance (TDTR) narrowed down the errors and corrected this value to ~320 W m<sup>-1</sup> K<sup>-1</sup> for 6H-SiC,<sup>11,15,16</sup> which is consistent with first-principles calculations of perfect single crystal 6HSiC based on density functional theory (DFT).<sup>17</sup> 

Compared with the extensively studied and widely used hexagonal phase SiC polytypes (6H and 4H), the cubic phase SiC (3C) is much less well understood even though it potentially has the best electronic properties and much higher κ.<sup>1,5</sup> The metal oxide semiconductor field effect transistor (MOSFET) based on 3C-SiC has the highest channel mobility ever presented on any SiC polytype, 

3 

which produces a large reduction in the power consumption of power switching devices.<sup>5</sup> A longlasting puzzle about the κ of 3C-SiC is that the measured value in the literature is perplexingly lower than that of the structurally more complex 6H phase.<sup>1</sup> This contradicts theoretical calculations that structural complexity and κ are inversely correlated.<sup>17</sup> To explain the abnormally low κ of 3C-SiC in the literature, A. Katre, _et al._ attributed the low κ to exceptionally strong boron defect-phonon scatterings in 3C-SiC, which are even stronger than vacancies.<sup>1</sup> 0.1% boron creates a factor of 2 decrease in κ while the same reduction is created by 2% substitutional nitrogen.<sup>1</sup> However, experimental validation is still lacking partly due to the challenges in growing highquality crystals.<sup>5,18</sup> 

The potentially high κ of 3C-SiC not only facilitates applications which use 3C-SiC as active electronic materials, but also enables 3C-SiC to be a thermal management material which cools devices made of other semiconductors. In terms of thermal management materials, diamond has the highest isotropic κ among all bulk materials but is limited by its high cost, small wafer size, and difficulty in heterogeneous integration with other semiconductors with high thermal boundary conductance (TBC).<sup>10,19,20</sup> Graphite has extremely strong intrinsic anisotropy in κ due to weak cross-plane van der Waals bonding.<sup>21</sup> For other carbon-based nanomaterials such as graphene and carbon nanotubes, their κ decrease significantly when assembling together or with other materials.<sup>7</sup> Recently, great progress has been achieved in the discovery of isotropic high κ in high-purity boron-based crystals, such as cubic BAs,<sup>22-24</sup> natural and isotope-enriched cubic BN,<sup>25</sup> natural and isotope-enriched cubic BP,<sup>25-27</sup> but all the crystal sizes are millimeter-scale or smaller. The technical difficulties in growth of high-purity large crystals prevent these high κ thermal 

4 

management materials from scalable applications. Further heterogeneous integration of these high κ thermal management materials with other semiconductors with high TBC is also challenging.<sup>28,29</sup> 

Here, we report an isotropic high κ over 500 W m<sup>-1</sup> K<sup>-1</sup> at room temperature in a high-purity waferscale free-standing 3C-SiC bulk crystal grown by low-temperature chemical vapor deposition (LTCVD), which agrees well with the first-principle predicted intrinsic κ of perfect single-crystal 3CSiC. Moreover, 3C-SiC can be heterogeneously integrated with Si and AlN by epitaxial growth. The in-plane and cross-plane κ of corresponding 3C-SiC thin films are measured by beam-offset time-domain thermoreflectance (BO-TDTR). Further structural analysis such as Raman spectroscopy, X-ray diffraction (XRD), high-resolution transmission electron microscopy (HRTEM), electron backscatter diffraction (EBSD), and second ion mass spectroscopy (SIMS) are performed to understand the structure-κ relation. Additionally, the TBC of 3C-SiC epitaxial interfaces with Si and AlN are studied by TDTR. 

# **RESULTS** 

3C-SiC has a less complex crystal structure than 6H-SiC (Fig. 1a). Higher κ than 6H phase is predicted for 3C-SiC single crystal.<sup>1</sup> We synthesize a free-standing 3C-SiC wafer (Fig. 1b) by growing 3C-SiC on a silicon substrate at 1000  C in a customized reactor and then etching away the Si substrate. More details about growth techniques can be found in Methods section and Supplementary Information (SI). Peaks (795 cm<sup>-1</sup> for TO and 969 cm<sup>-1</sup> for LO) in Raman spectrum measured on the 3C-SiC crystal (Fig. 1c) agree well with the Raman peaks of 3C-SiC in the literature (796 cm<sup>-1</sup> for TO and 970 cm<sup>-1</sup> for LO).<sup>30</sup> Fig. 1d shows rocking curve of the X-ray diffraction of the 3C-SiC crystal. The full width at half magnitude (FWHM) of the (111) peak is 

5 

158 arcsec, showing the high crystal quality of the 3C-SiC crystal. To probe the crystal structure of the 3C-SiC, we obtained an annular dark field scanning transmission electron microscopy (STEM) image (Fig. 1e) with atomically resolved lattices. The Fast Fourier transform of the STEM image is shown in the inset of Fig. 1e. Fig. 1f shows the selected area electron diffraction (SAED) pattern in a TEM, further confirming the SiC crystal is the cubic phase. More details about Raman measurements, STEM, and SAED can be found in Methods section and SI. The density of stacking faults of the growth surface is low (about 1000 cm<sup>-2</sup> ). We performed electron backscatter diffraction (EBSD) measurements on the freestanding bulk 3C-SiC to figure out the crystal orientation. The EBSD data of both the face close to Si substrate and the growth face shows single orientation (111) over the entire scanned area (2.4 mm × 0.8 mm). More details can be found in the SI. To figure out the impurity concentrations in 3C-SiC, secondary ion mass spectrometry (SIMS) was used to measure the concentrations of boron, nitrogen, and oxygen. The concentrations measured from the growth face are 6.6×10<sup>17</sup> atoms cm<sup>-3</sup> for oxygen and 5.8×10<sup>15</sup> atoms cm<sup>-3</sup> for nitrogen. The concentrations measured from the carbon face (adjacent to the Si substrate before etching away Si) are 2.3×10<sup>18</sup> atoms cm<sup>-3</sup> for oxygen and 1.4×10<sup>16</sup> atoms cm<sup>-3</sup> for nitrogen. The concentrations of boron impurity are too low to be detectable for SIMS measurements from both faces. The measured low concentrations of impurities further confirm the high quality of the 3C-SiC crystals in this work and high κ is expected.<sup>1</sup> 

6 



**Fig. 1. Wafer-scale free-standing 3C-SiC bulk crystals. a** Atomic structure of 3C-SiC and 6H- 

SiC. **b** Picture of a 3C-SiC 2-inch wafer. The unit of the rule is cm. **c** Raman spectrum of 3C-SiC crystal. **d** X-ray diffraction (XRD) of 3C-SiC. **e** High-resolution STEM image of 3C-SiC taken along the [1̅10] zone axis. The inset: Fast Fourier transform of the STEM image. **f** Selected area electron diffraction pattern of 3C-SiC taken in the [1̅10] zone axis. 

7 

We performed TDTR measurements on the free-standing 3C-SiC bulk crystal to obtain its thermal conductivity. Figure 2a shows an example of the TDTR ratio data (circles) and model fitting (solid line) for the bulk 3C-SiC sample with 5X objective and 9.3 MHz modulation frequency. The dash lines are model curves using κ 10% larger or 10% smaller than the best-fit κ to illustrate the measurement sensitivity. More details about the TDTR measurements can be found in the Methods section and SI. To evaluate the effect of ballistic thermal transport on TDTR measurements of high κ samples, we did multiple TDTR measurements with different spot sizes (10.7 μm for 5X objective, 5.5 μm for 10X objective, and 2.7μm for 20X objective) and different modulation frequencies (1.9-9.3 MHz). We observed weak dependence of measured κ on the used modulation frequency (Fig. 2b) while strong reduction in the measured κ for 20X compared to 5X and 10X (Fig. 2b). This reduction is due to the ballistic thermal transport in the sample and the mismatch in the distributions of phonons that carry heat across the metal transducer-sample interface and in the sample.<sup>31</sup> We used 9.3 MHz and 5X objective for the rest measurements on the κ of bulk 3C-SiC (Fig. 2c and Fig. 3). 

The measured κ of 3C-SiC at room temperature is compared with other high κ crystals as a function of wafer size (Fig. 2c).<sup>11,12,15,16,20,22,25,26</sup> The recently reported boron-based crystals have high κ but the achievable crystal sizes are millimeter-scale or smaller due to the limits of growth techniques or thermodynamics. The small crystal sizes prevent them from scalable thermal management applications for electronics and optoelectronics. Single crystal diamond has a larger wafer size, up to 1 inch, but the wide-range adoptions are limited by the high cost and difficulty in heterogeneous integration with other semiconductors.<sup>19,20,29</sup> Because of the large lattice mismatch with other 

8 

semiconductors such as Si and GaN, heterogeneous epitaxial growth of single crystal diamond is challenging.<sup>29</sup> Current chemical vapor deposited (CVD) polycrystalline diamond results in significantly reduced and anisotropic κ.<sup>32,33</sup> 

It is notable that the 3C-SiC wafer reported in this work can reach up to 6-inch in size with an isotropic high κ of over 500 W m<sup>-1</sup> K<sup>-1</sup> . The measured κ of 3C-SiC is higher than all metals and the second highest among all large crystals (only surpassed by single crystal diamond). The κ of 3CSiC at room temperature is ~ 50% higher than the c-axis κ of 6H-SiC and AlN, ~ 40% higher than the c-axis κ of 4H-SiC. 

9 



**Fig. 2. High κ of 3C-SiC bulk crystals near room temperature. a** TDTR ratio data (circles) and model fitting (solid line) for 3C-SiC sample. The dash lines are model curves using κ 10% larger or 10% smaller than the best-fit κ to illustrate the measurement sensitivity. **b** Dependence of modulation frequency and laser spot size on the measured κ of 3C-SiC near room temperature. **c** The measured κ of 3C-SiC at room temperature is compared with other high κ crystals as a function of wafer size.<sup>11,12,15,16,20,22,25,26</sup> 

10 

We further measured the κ of bulk 3C-SiC crystal at high temperatures. The measured temperature dependent κ of bulk 3C-SiC is compared with previously measured κ values in the literature, κ values of perfect single crystal predicted by DFT, and that of other high κ crystals (See Fig. 3a and 3b). The measured κ agrees excellently with DFT-calculated κ of perfect single crystal 3C-SiC at all measured temperatures. The measured κ in this work is more than 50% higher than the literature values of 3C-SiC at room temperature, and surpasses that of the structurally more complex 6HSiC. These results are consistent with the theoretical calculations that structural complexity and κ are inversely related.<sup>17</sup> The measured high κ resolves a long-lasting puzzle about the abnormally low κ values in the literature which was attributed to the extrinsic defect-phonon scatterings in 3CSiC.<sup>1</sup> Boron defects in 3C-SiC cause exceptionally strong phonon scatterings which results from the resonant phonon scattering around the boron impurity.<sup>1</sup> The measured boron impurity concentration is negligible in our 3C-SiC crystals according to the SIMS measurements. The rocking curve of XRD measurements shows a full-width at half magnitude (FWHM) of 158 arcsec. The high-purity and good crystal quality of our 3C-SiC crystals results in the observed high κ, which validates the theory proposed in the literature.<sup>1</sup> 

We also compare the measured temperature dependent κ of bulk 3C-SiC crystals with that of AlN, 6H-SiC, and GaN. We include both the in-plane κ and cross-plane κ of 6H-SiC since the κ of 6HSiC is anisotropic. The DFT-calculated κ values of perfect single crystals agree well with the measured κ values and both are proportional to the inverse of temperature due to the dominant phonon-phonon scatterings in these crystals at high temperatures. The measured κ values of 3CSiC are 2.5 times as high as that of GaN, making 3C-SiC a potential candidate as substrates of GaN-based power electronics. The high κ of 3C-SiC will motivate the study of power electronics 

11 

which use 3C-SiC as active device material as a more advanced addition to currently wide-adopted 

4H-SiC and 6H-SiC. 



**Fig. 3. Temperature dependent κ of bulk 3C-SiC crystals. a** Comparison of the measured κ in this work with previous measured κ in the literature.<sup>1,34,35</sup> The κ value (red line) predicted by density functional theory (DFT) is also included.<sup>1,36</sup> **b** Comparison of temperature dependent κ of 3C-SiC with c-axis κ of bulk 6H-SiC, AlN, and GaN.<sup>1,11,12</sup> The symbols are experimentally measured values while the lines are DFT-calculated values of perfect single crystals.<sup>1,11</sup> We include both the cross-plane κ and the in-plane κ of 6H-SiC since its κ is anisotropic. 

We performed beam-offset time-domain thermoreflectance (BO-TDTR) on 3C-SiC thin films grown on Si substrates to obtain the in-plane κ of 3C-SiC films.<sup>37,38</sup> During BO-TDTR measurements, the pump beam is offset relative to the probe beam, as shown in Fig. 4a. An example of the out-of-phase TDTR signal on a 2.52-μm-thick SiC film on Si sample is shown as 

12 

a function of the beam offset distance. The full width at half magnitude (FWHM) is a measure of the heat spreading capability which is used to fit for the in-plane κ of the 3C-SiC thin film. More details about the BO-TDTR can be found in the Methods section and SI. The measured in-plane κ values of 3C-SiC thin films at room temperature are compared with that of other close-to-isotropic thin films such AlN, diamond, and GaN (see Fig. 4b). Please note that strongly anisotropic materials graphite and h-BN have high in-plane κ values but we do not include them here. The inplane κ of 3C-SiC thin films show record-high values, even higher than that of diamond thin films with equivalent thickness. We attribute this high in-plane κ values to the high-quality of the 3CSiC thin films. This high in-plane κ values of 3C-SiC thin films facilitate heat spreading of localized Joule-heating in power electronics. 

13 



**Fig. 4. High in-plane and cross-plane κ of 3C-SiC thin films. a** Beam-offset TDTR technique for in-plane κ measurements. The out-of-phase TDTR signal on the 2.52 μm SiC on Si sample is shown as a function of beam offset distance. **b** In-plane κ of 3C-SiC thin films. The in-plane κ of other close-to-isotropic high κ thin films are also included for comparison.<sup>32,39-45</sup> **c** Cross-plane κ of 3C-SiC thin films. The cross-plane κ of other high κ thin films are also included for 

14 

comparison.<sup>20,32,39,40,42,45-49</sup> **d** Temperature dependent cross-plane κ of a 1.75-μm-thick 3C-SiC thin film. The temperature dependent cross-plane κ of AlN and GaN thin films are also included.<sup>20,48</sup> 

The cross-plane κ of the 3C-SiC thin films are measured by TDTR. The dependence of cross-plane κ on film thickness and temperature are shown in Fig. 4c and 4d. The cross-plane κ of 3C-SiC thin films are among the highest values, even higher than or comparable to that of diamond thin films with equivalent thickness. The cross-plane κ of 1.75-μm-thick 3C-SiC reaches ~80% of the κ of bulk 3C-SiC, up to twice as high as the κ of bulk GaN. Even the 0.93- μm-thick 3C-SiC has a cross-plane κ close to that of bulk GaN, which further confirming the high-quality of our 3C-SiC thin films. Fig. 4d compares the temperature dependent cross-plane κ of some wide bandgap semiconductor thin films. In the measured temperature range, all the cross-plane κ values of 3CSiC are higher than that of AlN and GaN with even thicker films. The high cross-plane κ, combined 

with the high in-plane κ, of these 3C-SiC thin films make them the best candidate for thermal management applications which use thin films. 

15 



**Fig. 5. High thermal boundary conductance of 3C-SiC epitaxial interfaces. a** TEM crosssection image of Si-SiC interfaces. **b** TEM cross-section image of AlN-SiC interfaces. **c** Thermal boundary conductance of Si-SiC interfaces and AlN-SiC interfaces. The TBC values of other semiconductor interfaces are included for comparison.<sup>28,46,49-52</sup> 

The epitaxial growth of 3C-SiC not only produces high-quality thin films which have high in-plane and cross-plane κ, but also creates high-quality heterogeneous interfaces which are potentially thermally conductance. The cross-section TEM images of the epitaxial 3C-SiC-Si and 3C-SiCAlN interfaces are shown in Figs. 5a and 5b to study the interfacial structure. Their thermal boundary conductance (TBC) are measured by TDTR and compared with that of other 

16 

semiconductor interfaces (see Fig. 5c). The measured 3C-SiC-Si TBC (~600 MW m<sup>-2</sup> K<sup>-1</sup> ) is among the highest values for all interfaces making up of semiconductors,<sup>51</sup> about ten times as high as that of the diamond-Si interfaces,<sup>46</sup> about 2.5 times as high as that of epitaxial Si-Ge interfaces.<sup>52</sup> It also approaches the maximum TBC of any interface involving Si, which is only limited by the rate that thermal energy in the Si can impinge on the crystallographic plane.<sup>53</sup> The measured 3C-SiCAlN TBC is higher than the GaN-BAs TBC and 4H-SiC-GaN TBC.<sup>28,49,50</sup> These high TBC values of 3C-SiC related interfaces facilitate heat dissipation of electronics and optoelectronics which use 3C-SiC, especially for the cases with an increasing number of interfaces as the minimization of devices. 

# **CONCLUSIONS** 

This work reported an isotropic high thermal conductivity over 500 W m<sup>-1</sup> K<sup>-1</sup> at room temperature in high-purity wafer-scale free-standing 3C-SiC bulk crystals, which is ~50% higher than commercially-available 6H-SiC and AlN. It is more than 50% higher than the previously measured κ of 3C-SiC in the literature, and is the second highest among large crystals (only surpassed by single crystal diamond). We also studied the κ of corresponding 3C-SiC thin films and found record-high in-plane and cross-plane κ, even higher than diamond thin films with equivalent thickness. The measured higher κ of 3C-SiC than that of the structurally more complex 6H-SiC validates that structural complexity and κ are inversely related, resolving a long-lasting puzzle about the perplexingly low κ of 3C-SiC in the literature. Impurity concentrations measured by SIMS revealed the high-purity of our 3C-SiC crystals and the XRD measurements revealed the good crystal quality of our 3C-SiC crystals. Both contribute to the observed high κ. Furthermore, high TBC values were observed across epitaxial 3C-SiC-Si and 3C-SiC-AlN interfaces. The 

17 

measured 3C-SiC-Si TBC is among the highest for semiconductor interfaces, about ten time as large as that of diamond-Si interfaces. The high κ observed in 3C-SiC bulk crystals and thin films, combined with the high TBC of epitaxial 3C-SiC interfaces, suggest 3C-SiC an excellent candidate for applications of power electronics and optoelectronics. 

# **METHODS** 

**Sample growth** . The 3C-SiC crystals are grown on (111) Si substrates by low-temperature chemical vapor deposition (LT-CVD) in a custom-built CVD reactor at 1300 K. Because of the relatively low temperature growth, the strain in 3C-SiC layer caused by mismatch of thermal expansion coefficient is small, which enables the growth of large-diameter substrate without cracks. Since both Si and 3C-SiC have equal rotational symmetry (120º) with respect to the [111] axis, 3C-SiC crystals with less double positioning boundary (DPB) can be grown on Si. The freestanding bulk 3C-SiC crystal is obtained by growing 100-μm-thick 3C-SiC on Si substrates and then etching away the Si substrates by HNA (HF: HNO3: H2O). The stacking faults density observed on the growth face is about 1000 cm<sup>-2</sup> . 

**Thermal characterizations.** The κ and TBC are measured by time-domain thermoreflectance (TDTR). We usually coat 100-nm-thick Al on the to-be-measured sample as TDTR transducer before TDTR measurements. TDTR is an ultra-fast laser based pump-probe technique which can measure thermal properties of both bulk and nanostructured materials.<sup>33,54</sup> A modulated pump laser beam heats the sample surface periodically while a delayed probe laser beam detects the temperature variations of the sample surface via thermoreflectance. The signal picked up by a photodetector and a Lock-in amplifier is fitted with the analytical heat transfer solution of the 

18 

sample structure to infer the unknown parameters (for example, κ of 3C-SiC and TBC of the metal transducer-SiC interface when measuring the 3C-SiC bulk crystals). We used 5X objective (spot size 10.7 μm) and 9.3 MHz when measuring the κ of the 3C-SiC bulk crystals and the cross-plane κ of 3C-SiC thin films. When measuring the 3C-SiC thin films, the thicknesses of Al transducer and 3C-SiC thin films are measured by picosecond acoustic technique.<sup>55</sup> More details about the thickness measurements and used literature values of heat capacity can be found in SI. The inplane κ of 3C-SiC thin films are measured by BO-TDTR with a modulation frequency of 1.9 MHz and an objective of 10X.<sup>37,38</sup> We also used the 5X objective to repeat the BO-TDTR measurements and obtained consistent results. 

**Raman spectroscopy** : Raman measurements were performed on the 3C-SiC bulk crystal with a Horiba LabRAM confocal Raman spectroscopy imaging system. The used laser wavelength is 532 nm. The acquisition time is 600 s and the objective is 50X. 

**SIMS characterizations** : Secondary Ion Mass Spectrometry (SIMS) equipment (Cameca) was used to analyze the depth profile of the O, N, and B atomic densities on the C and Si faces of the 3C-SiC. 

**TEM and SAED measurements:** Transmission electron microscopy (TEM) and Selected area electron diffraction (SAED) (JEM-2200FS; JEOL) were used to analyze the crystal quality of the 3C-SiC and the interface characteristics at an acceleration voltage of 200 kV. TEM samples were prepared by using a focused ion beam (FIB) system (Helios NanoLab 600i DualBeam; Thermo 

19 

Fisher Scientific) by depositing a protective layer and milling using a 30 kV accelerating voltage, and final etching step using a 2 kV accelerating voltage at room temperature. 

**XRD measurements:** The crystal quality of the 3C-SiC crystals was characterized by the fullwidth of the half-maximum on the X-ray rocking curve of the 3C-SiC (111) peak using an X-ray diffraction system (D8 Discover; Bruker). A Cu-Kα X-ray source accelerating at 40 kV with a current of 40 mA was applied to record the XRD patterns in the range of 17.2-18.4 `º` with a step of 0.015º.  An incident slit with a width of 2 mm and a collimator with a diameter of 0.1 mm were used. 

**EBSD measurements:** The crystal direction of the 3C-SiC crystals was analyzed by an Electron Backscatter diffraction (EBSD) system (FE-SEM JSM-6500F; JEOL) with a high-resolution scanning electron microscope (SEM) and a TSL orientation imaging microscopy (OIM) analyzer. The SEM was operated at 20 kV, and a scan area of 2.4 mm × 0.8 mm was performed using a 

hexagonal grid with a step size of 2 μm. 

# **DATA AVAILABILITY** 

The datasets generated during and/or analyzed during the current study are available from the corresponding authors upon reasonable request. 

# **CODE AVAILABILITY** 

The code used for calculations, simulations, and data analysis is available from the corresponding authors upon reasonable request. 

20 

# **ACKNOWLEDGEMENTS** 

Z.C. S.G. and D.C. would like to acknowledge the financial support from U.S. Office of Naval Research under a MURI program (Grant N00014-18-1-2429). Z.C. and D.C. would like to Guangxin Lyu for help of Raman measurements. The fabrication of the TEM samples was performed at The Oarai Center and at the Laboratory of Alpha-Ray Emitters in IMR under the Inter-University Cooperative Research in IMR of Tohoku University (NO. 202112-IRKMA0016). The observation of the TEM samples was supported by Kyoto University Nano Technology Hub in the "Nanotechnology Platform Project" sponsored by the Ministry of Education, Culture, Sports, Science and Technology (MEXT), Japan. 

# **AUTHOR CONTRIBUTIONS** 

Z.C. initialized this project and finished all the thermal measurements. Z.C. and J.L. coordinated the project. J.L. polished the bulk 3C-SiC samples and performed TEM studies. K.K., H.A., and H.U. grew the 3C-SiC samples and did XRD, EBSD, and SIMS measurements. Y.O. and Y.N. prepared the TEM samples. Z.C. wrote the manuscript with inputs from all authors. J.L. assisted with manuscript preparation and reviewed the manuscript. S.G. and N.S. commented on the manuscript. D.C. provided overall guidance to the project and reviewed the manuscript. 

# **COMPETING INTERESTS** 

The authors declare no competing interest. 

# **SUPPLEMENTARY INFORMATION** 

21 

Additional details are provided in the SI, including details about sample characterizations, details about TDTR measurements, and details about BO-TDTR measurements. 

22 

# **REFERENCES** 

- 1 Katre, A., Carrete, J., Dongre, B., Madsen, G. K. & Mingo, N. Exceptionally strong phonon scattering by B substitution in cubic SiC. _Physical review letters_ **119** , 075902 (2017). 

- 2 Nakamura, D. _et al._ Ultrahigh-quality silicon carbide single crystals. _Nature_ **430** , 1009-1012 (2004). 

- 3 Koehl, W. F., Buckley, B. B., Heremans, F. J., Calusine, G. & Awschalom, D. D. Room temperature coherent control of defect spin qubits in silicon carbide. _Nature_ **479** , 84-87 (2011). 

- 4 Eddy Jr, C. & Gaskill, D. Silicon carbide as a platform for power electronics. _Science_ **324** , 1398-1400 (2009). 

- 5 La Via, F. _et al._ New Approaches and Understandings in the Growth of Cubic Silicon Carbide. _Materials_ **14** , 5348 (2021). 

- 6 Moore, A. L. & Shi, L. Emerging challenges and materials for thermal management of electronics. _Materials Today_ **17** , 163-174 (2014). 

- 7 Cahill, D. G. _et al._ Nanoscale thermal transport. II. 2003–2012. _Applied Physics Reviews_ **1** , 011305 (2014). 

- 8 Green, A. J. _et al._ β-Gallium oxide power electronics. _APL Materials_ **10** , 029201 (2022). 

- 9 Qian, X., Zhou, J. & Chen, G. Phonon-engineered extreme thermal conductivity materials. _Nature Materials_ **20** , 1188-1202 (2021). 

- 10 Cheng, Z., Graham, S., Amano, H. & Cahill, D. G. Perspective on thermal conductance across heterogeneously integrated interfaces for wide and ultrawide bandgap electronics. _Applied Physics Letters_ **120** , 030501 (2022). 

- 11 Zheng, Q. _et al._ Thermal conductivity of GaN, GaN 71, and SiC from 150 K to 850 K. _Physical Review Materials_ **3** , 014601 (2019). 

- 12 Cheng, Z. _et al._ Experimental observation of high intrinsic thermal conductivity of AlN. _Physical Review Materials_ **4** , 044602 (2020). 

- 13 Slack, G. A. Thermal conductivity of pure and impure silicon, silicon carbide, and diamond. _Journal of Applied physics_ **35** , 3460-3466 (1964). 

- 14 Slack, G. A. Nonmetallic crystals with high thermal conductivity. _Journal of Physics and Chemistry of Solids_ **34** , 321-335 (1973). 

23 

- 15 Cheng, Z. _et al._ Quasi-Ballistic Thermal Conduction in 6H-SiC. _Materials Today Physics_ **20** (2021). 

- 16 Qian, X., Jiang, P. & Yang, R. Anisotropic thermal conductivity of 4H and 6H silicon carbide measured using time-domain thermoreflectance. _Materials Today Physics_ **3** , 70-75 (2017). 

- 17 Protik, N. H. _et al._ Phonon thermal transport in 2H, 4H and 6H silicon carbide from first principles. _Materials Today Physics_ **1** , 31-38 (2017). 

- 18 Schuh, P., La Via, F., Mauceri, M., Zielinski, M. & Wellmann, P. J. Growth of large-area, stress-free, and bulk-like 3C-SiC (100) using 3C-SiC-on-Si in vapor phase growth. _Materials_ **12** , 2179 (2019). 

- 19 Tsao, J. _et al._ Ultrawide‐Bandgap Semiconductors: Research Opportunities and Challenges. _Advanced Electronic Materials_ **4** , 1600501 (2018). 

- 20 Cheng, Z., Mu, F., Yates, L., Suga, T. & Graham, S. Interfacial Thermal Conductance across Room-Temperature-Bonded GaN/Diamond Interfaces for GaN-on-Diamond Devices. _ACS Applied Materials & Interfaces_ **12** , 8376-8384 (2020). 

- 21 Kim, S. E. _et al._ Extremely anisotropic van der Waals thermal conductors. _Nature_ **597** , 660665 (2021). 

- 22 Li, S. _et al._ High thermal conductivity in cubic boron arsenide crystals. _Science_ **361** , 579-581 (2018). 

- 23 Kang, J. S., Li, M., Wu, H., Nguyen, H. & Hu, Y. Experimental observation of high thermal conductivity in boron arsenide. _Science_ **361** , 575-578 (2018). 

- 24 Tian, F. _et al._ Unusual high thermal conductivity in boron arsenide bulk crystals. _Science_ **361** , 582-585 (2018). 

- 25 Chen, K. _et al._ Ultrahigh thermal conductivity in isotope-enriched cubic boron nitride. _Science_ **367** , 555-559 (2020). 

- 26 Zheng, Q. _et al._ High thermal conductivity in isotopically enriched cubic boron phosphide. _Advanced Functional Materials_ **28** , 1805116 (2018). 

- 27 Kang, J. S., Wu, H. & Hu, Y. Thermal properties and phonon spectral characterization of synthetic boron phosphide for high thermal conductivity applications. _Nano letters_ **17** , 75077514 (2017). 

- 28 Kang, J. S. _et al._ Integration of boron arsenide cooling substrates into gallium nitride devices. _Nature Electronics_ , 1-8 (2021). 

24 

- 29 Jianbo Liang _et al._ Fabrication of GaN/Diamond Heterointerface and Interfacial Chemical Bonding State for Highly Efficient Device Design. _Advanced Materials_ , 13 (2021). 

- 30 Zhuravlev, K., Goncharov, A. F., Tkachev, S., Dera, P. & Prakapenka, V. Vibrational, elastic, and structural properties of cubic silicon carbide under pressure up to 75 GPa: Implication for a primary pressure scale. _Journal of Applied Physics_ **113** , 113503 (2013). 

- 31 Wilson, R. & Cahill, D. G. Anisotropic failure of Fourier theory in time-domain thermoreflectance experiments. _Nature communications_ **5** , 5075 (2014). 

- 32 Sood, A. _et al._ Anisotropic and inhomogeneous thermal conduction in suspended thin-film polycrystalline diamond. _Journal of Applied Physics_ **119** , 175103 (2016). 

- 33 Cheng, Z. _et al._ Probing Growth-Induced Anisotropic Thermal Transport in High-Quality CVD Diamond Membranes by Multi-frequency and Multi-spot-size Time-Domain Thermoreflectance. _ACS applied materials & interfaces_ (2018). 

- 34 Morelli, D. _et al._ in _Institute of Physics Conference Series._ 313-316 (Bristol [England]; Boston: Adam Hilger, Ltd., c1985-). 

- 35 Ivanova, L., Aleksandrov, P. & Demakov, K. Thermoelectric properties of vapor-grown polycrystalline cubic SiC. _Inorganic materials_ **42** , 1205-1209 (2006). 

- 36 Lindsay, L., Broido, D. & Reinecke, T. Ab initio thermal transport in compound semiconductors. _Physical Review B_ **87** , 165201 (2013). 

- 37 Feser, J. P. & Cahill, D. G. Probing anisotropic heat transport using time-domain thermoreflectance with offset laser spots. _Review of Scientific Instruments_ **83** , 104901 (2012). 

- 38 Feser, J. P., Liu, J. & Cahill, D. G. Pump-probe measurements of the thermal conductivity tensor for materials lacking in-plane symmetry. _Review of Scientific Instruments_ **85** , 104903 (2014). 

- 39 Hoque, M. S. B. _et al._ High in-plane thermal conductivity of aluminum nitride thin films. _ACS nano_ **15** , 9588-9599 (2021). 

- 40 Li, H. _et al._ GaN thermal transport limited by the interplay of dislocations and size effects. _Physical Review B_ **102** , 014313 (2020). 

- 41 Hines, N. J. _et al._ Steady-state methods for measuring in-plane thermal conductivity of thin films for heat spreading applications. _Review of Scientific Instruments_ **92** , 044907 (2021). 

- 42 Anaya, J. _et al._ Simultaneous determination of the lattice thermal conductivity and grain/grain thermal resistance in polycrystalline diamond. _Acta Materialia_ (2017). 

25 

- 43 Yates, L. _et al._ Simultaneous Evaluation of Heat Capacity and In-plane Thermal Conductivity of Nanocrystalline Diamond Thin Films. _Nanoscale and Microscale Thermophysical Engineering_ **25** , 166-178 (2021). 

- 44 Anaya, J. _et al._ Control of the in-plane thermal conductivity of ultra-thin nanocrystalline diamond films through the grain and grain boundary properties. _Acta Materialia_ **103** , 141-152 (2016). 

- 45 Cheaito, R. _et al._ in _Thermal and Thermomechanical Phenomena in Electronic Systems (ITherm), 2017 16th IEEE Intersociety Conference on._ 706-710 (IEEE). 

- 46 Cheng, Z. _et al._ Tunable Thermal Energy Transport across Diamond Membranes and Diamond-Si Interfaces by Nanoscale Graphoepitaxy. _ACS applied materials & interfaces_ (2019). 

- 47 Yates, L. _et al._ in _Compound Semiconductor Integrated Circuit Symposium (CSICS), 2016 IEEE._ 1-4 (IEEE). 

- 48 Koh, Y. R. _et al._ Bulk-like Intrinsic Phonon Thermal Conductivity of Micrometer-Thick AlN Films. _ACS Applied Materials & Interfaces_ **12** , 29443-29450 (2020). 

- 49 Mu, F. _et al._ High Thermal Boundary Conductance across Bonded Heterogeneous GaN-SiC Interfaces. _ACS Applied Materials & Interfaces_ **11** , 7 (2019). 

- 50 Ziade, E. _et al._ Thermal transport through GaN–SiC interfaces from 300 to 600 K. _Applied Physics Letters_ **107** , 091605 (2015). 

- 51 Gaskins, J. T. _et al._ Thermal Boundary Conductance Across Heteroepitaxial ZnO/GaN Interfaces: Assessment of the Phonon Gas Model. _Nano letters_ **18** , 7469-7477 (2018). 

- 52 Cheng, Z. _et al._ Experimental observation of localized interfacial phonon modes. _Nature communications_ **12** , 1-10 (2021). 

- 53 Wilson, R., Apgar, B. A., Hsieh, W.-P., Martin, L. W. & Cahill, D. G. Thermal conductance of strongly bonded metal-oxide interfaces. _Physical Review B_ **91** , 115414 (2015). 

- 54 Cahill, D. G. Analysis of heat flow in layered structures for time-domain thermoreflectance. _Review of scientific instruments_ **75** , 5119-5122 (2004). 

- 55 Cheng, Z. _et al._ Thermal conductance across β-Ga2O3-diamond van der Waals heterogeneous interfaces. _APL Materials_ **7** , 031118 (2019). 

26 

