# Rational Design of Multi-color-emitting Chiral Carbonized Polymer Dots for Full-color and White Circularly Polarized Luminescence.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Angewandte Chemie |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 187 |
| 作者 | Yi Ru, Lai-Zhi Sui, Hao-Qiang Song, Xing-Jiang Liu, Zhi-Yong Tang, Shuang-Quan Zang, Bai Yang, Si-Yu Lu |
| DOI | 10.1002/anie.202103336 |
| 源文件 | 056_Ru_2021_Rational-Design-of-Multi-color-emitting-Chiral-C.pdf |

---
**_Angewandte Chemie_** 

Research Articles 





## Nanomaterials 

How to cite: Angew. Chem. Int. Ed. 2021, 60, 14091–14099 International Edition: doi.org/10.1002/anie.202103336 German Edition: doi.org/10.1002/ange.202103336 

# Rational Design of Multicolor-Emitting Chiral Carbonized Polymer Dots for Full-Color and White Circularly Polarized Luminescence 

Yi Ru, Laizhi Sui, Haoqiang Song, Xingjiang Liu, Zhiyong Tang, Shuang-Quan Zang, Bai Yang, and Siyu Lu* 

Abstract: Light-emitting chiral carbonized polymer dots (ChCPDs) are attracting great interest because of their extraordinary photonic properties, but modulating their band-gap emission, especially at long wavelength, and maintaining their chiral structure to achieve multicolor, high-emission Ch-CPDs remains challenging. Reported here for the first time is the synthesis of red- and multicolor-emitting Ch-CPDs using the common precursors l-/d-tryptophan and o-phenylenediamine, and a solvothermal approach at one temperature. The quantum yield of the Ch-CPDs was between 31% and 54%. Supramolecular self-assembly provided multicolor-emitting ChCPDs showing novel circularly polarized luminescence, with the highest dissymmetric factor (glum) of 1 �10<sup>�2</sup> . Importantly, circularly polarized white-emitting CPDs were fabricated for the first time by tuning the mixing ratio of the three colored ChCPDs in a gel. This strategy affords exciting opportunities for designing functional chiroptical materials. 

### Introduction 

Chirality is one of the most fundamental characteristics of nature. It has played a vital role in DNA, RNA, and proteins during the evolution of living organisms, and thus is an important factor in biology, chemistry, medicine, and pharmacology.<sup>[1]</sup> Chirality also plays a central role in the application of chiral recognition, chiral detection, chiral separation, and asymmetric catalysis.<sup>[2]</sup> The first report of inorganic chiral nanoparticles, chiral gold nanoclusters,<sup>[3]</sup> nearly two decades ago commenced the study of chiral nanomaterials and led to a large number of subsequent reports on chiral noble-metal 

[*] Dr. Y. Ru, Dr. H. Song, Prof. X. Liu, Prof. S.-Q. Zang, Prof. S. Lu Green Catalysis Center, and College of Chemistry, Zhengzhou University, Zhengzhou 450000 (China) E-mail: sylu2013@zzu.edu.cn Prof. B. Yang State Key Laboratory of Supramolecular Structure and Materials, College of Chemistry, Jilin University, Changchun 130012 (China) Dr. L. Sui State Key Lab of Molecular Reaction Dynamics, Dalian Institute of Chemical Physics, Chinese Academy of Sciences Dalian, 116023 (China) Prof. Z. Tang CAS Key Laboratory of Nanosystem and Hierarchical Fabrication, CAS Center for Excellence in Nanoscience, National Center for Nanoscience and Technology, Beijing 100190 (China) Supporting information and the ORCID identification number(s) for the author(s) of this article can be found under: https://doi.org/10.1002/anie.202103336. 

nanostructures, semiconductor quantum dots, and their chirality-dependent performance.<sup>[4]</sup> Carbonized polymer dots (CPDs) are a novel class of luminescent nanomaterials that combine the optical and electronic characteristics of semiconductor quantum dots while largely avoiding their limitations, such as requiring scarce elements or highly toxic heavy metals in their preparation.<sup>[5]</sup> These outstanding properties and potential applications of CPDs in a wide range of fields make them have bright prospects as chiral nanomaterials. Recent research on chiral CPDs (Ch-CPDs) has resulted in several breakthroughs.<sup>[2a]</sup> For instance, �ord¯evic´ et al.<sup>[6]</sup> used microwave-assisted synthesis to prepare Ch-CPDs with an emission peak at 510 nm and with quantum yield (QY) of about 20%. Chirality was transferred from the Ch-CPDs to tetra-anionic porphyrins through electrostatic interactions, thereby inducing the formation of chiral aggregates. This discovery opened possibilities for the development of ChCPDs composites. Li et al.<sup>[7]</sup> demonstrated for the first time the different effects of N-S-doped Ch-CPDs on cell energy metabolism. The Ch-CPDs were based on the hydrothermal treatment of L-/D-cysteine; their emission peak was at 510 nm, and the QY was about 41.26%. Kang et al.<sup>[8]</sup> prepared Ch-CPDs with optical rotations opposite to that of the precursor through electrochemical polymerization. Their emission peak was at 405 nm, and their chirality could be regulated by adjusting the reaction time. However, despite such encouraging progress, there are few reports regarding, for example, the challenging preparation of red-emitting and wavelength-tunable Ch-CPDs.<sup>[2a,9]</sup> Three factors are key for the synthesis of red-emitting CPDs: (1) precursors, (2) reaction temperature, and (3) reaction solvents.<sup>[10]</sup> Precursors with appropriate aromatic structures provide the basis for the generation of large sp<sup>2</sup> domains.<sup>[11]</sup> A relatively high reaction temperature will result in a higher degree of carbonization. A highly acidic environment and low-polarity solvents aid dehydration and carbonization of the precursors, allowing the formation of CPDs with large conjugated domains and narrow energy gaps.<sup>[12]</sup> The greatest difficulty in synthesizing red-emitting Ch-CPDs is that most precursors with chiral structures are water-soluble, non-conjugated amino acid molecules.<sup>[2a,13]</sup> Raising the reaction temperature (up to the melting point of the chiral precursor) usually results in excessive carbonization, which is not conducive to the preservation of the chiral structure on the surface of the carbon core.<sup>[14]</sup> The above limiting factors also make it difficult to produce photoluminescence tunable Ch-CPDs. Practical applications of Ch-CPDs, such as photoelectric devices and in vivo imaging, require CPDs with bright 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 



�2021 Wiley-VCH GmbH 

14091 

**_Angewandte Chemie_** 

Research Articles 



multicolor emission from blue to red. [15] There is therefore the need to develop a facile preparation method for high QY red-emitting Ch-CPDs and Ch-CPDs that emit across the whole visible spectrum. 

Many reports have confirmed that CPDs prepared from chiral precursors readily exhibit significant circular dichroism (CD) due to retention of the chiral structure, but circularly polarized luminescence (CPL) cannot be directly achieved.<sup>[16]</sup> Chiral functional materials exhibiting CPL are receiving increasing attention for their promising potential applications, including stereopsis, the encrypted transmission and storage of information, biological sensors, photoelectric devices, and catalysts for asymmetric photochemical synthesis.<sup>[1b,17]</sup> In order to realize CPL, phosphors and asymmetrical environment are essential elements.<sup>[18]</sup> A cellulose matrix has previously been used to achieve CPDs emitting circularly polarized multi-color light, but the lack of white light emission greatly limits their potential applications applications.<sup>[14b,18a]</sup> 

Herein, we report a solvent-controlled synthetic route for the preparation of multicolor luminescent Ch-CPDs, and of red-emitting Ch-CPDs with the emission peak at 602 nm has the highest QY (53.62%). This is not only the first report of the preparation of multicolour-emitting Ch-CPDs that does not require changing precursors and reaction temperature, but also the first report of red-emitting Ch-CPDs. Furthermore, we combined the organic lipid gel N,N-bis(octadecyl)d-glutamic diamide (DGAm) and its enantiomer N,N-bis(octadecyl)-l-glutamic diamide (LGAm) with multicolor ChCPDs by supramolecular self-assembly, thus giving multicolor Ch-CPDs corresponding CPL. This allowed the generation of unprecedented white CPL by tuning the ratio of blue-, yellow, and red-emitting Ch-CPDs. And the highest dissymmetric factor (glum) of monochromatic CPL is up to 1 �10<sup>�2</sup> , and the glum of the circularly polarized white-emitting Ch-CPDs is also considerable (2.5 �10<sup>�3</sup> ). 

### Results and Discussion 

Our multicolor Ch-CPDs, including l-CPDs and d-CPDs, are prepared solvothermally by heating an appropriate ratio of l-/d-tryptophan (l-/d-Trp) and o-phenylenediamine in three different solvents (alcoholic HCl solution, aqueous, and aqueous H2SO4 solution; Scheme 1). We use l-/d-Trp chiral precursors containing conjugated structures and o- phenylenediamine achiral precursors, guaranteeing the large sp<sup>2</sup> domain required to generate red-emitting Ch-CPDs. Compared with most amino acids, Trp has a higher melting point (281 8 C), allowing use of a reaction temperature of 160 8 C. The chiral structure on the surface of the CPDs is well preserved at temperatures far below the melting point of the chiral precursor. After solvothermal treatment at 160 8 C for 7 h, the samples were filtered through a membrane filter with 0.22 mm pores, then dialyzed and lyophilized. Three sets of samples were prepared and dispersed in ethanol for characterization: B-Ch-CPDs (B-L-CPDs and B-D-CPDs), Y-ChCPDs (Y-L-CPDs and Y-D-CPDs), and R-Ch-CPDs (R-LCPDs and R-D-CPDs). Since the difference between l-CPDs and d-CPDs is only apparent in their chiral optical properties, most of the characterizations described below use l-CPDs as an example. As shown in Figure 1a–c, the ethanol solutions of the l-CPDs show different colors in the daylight and tunable photoluminescence (PL) emission from blue to red under a 365 nm UV light. The PL emission maxima of the B, Y, and R-L-CPDs are 441, 546 and 604 nm, respectively. Note the extremely narrow (23.16 nm) full width at half maximum (FWHM) of R-L-CPDs. The UV-vis absorption spectra of the three samples in Figure 1a–c show analogous absorption peaks in the UV region but different behavior in the visible region. The UV region of each spectrum shows two peaks, near 215 and 280 nm, corresponding to the p-p* transitions of the C<sup>=</sup> C and C<sup>=</sup> N bonds in aromatic sp<sup>2</sup> domains.<sup>[19]</sup> Progressing from B-L-CPDs to R-L-CPDs, the transitions at 



Scheme 1. Schematic of the preparation procedure for multicolor-emitting chiral carbonized polymer dots with full-color circularly polarized luminescence. 

�2021 Wiley-VCH GmbH 

14092 www.angewandte.org 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

**_Angewandte Chemie_** 

Research Articles 





Figure 1. Absorption spectra and PL spectra of a) B-L-CPDs, b) Y-L-CPDs, c) R-L-CPDs ethanol solutions. The insets show corresponding photographs under daylight (left) and 365 nm UV light (right). PL emission spectra of d) B-L-CPDs, e) Y-L-CPDs, f) R-L-CPDs ethanol solutions at different excitation wavelengths. CD spectra of g) B-Ch-CPDs, h) Y-Ch-CPDs, i) R-Ch-CPDs ethanol solutions. 

280 nm are sequentially enhanced due in part to the increasing nitrogen-doped aromatic rings in the carbon cores.<sup>[20]</sup> 

However, in the visible region, the absorption curves of B- L-CPDs, Y-L-CPDs, and R-L-CPDs show distinct absorption peaks at 354 (see Figure S1 in the Supporting Information), 425 and 535 nm, indicating different surface state transitions on the surfaces of the three samples.<sup>[21]</sup> Similar to many other reported Ch-CPDs, the PL emission peaks of our Ch-CPDs remained stationary upon change in excitation wavelength (Figure 1d–f). The maximum QY for B-, Y-, and R-L-CPDs was 53.62% (ultrapure water), 31.65% (ethanol), and 46.38% (ethanol), respectively, using an integrating sphere at their optimal excitation wavelengths (see Table S1). The optical behavior of each sample was further examined by time-resolved PL spectroscopy. The results (Supporting Information, Figure S2 and Table S2) can be fitted by a two- 

component exponential. The lifetime of the short-lived component was about 2 ns (t1), and that of the long-lived component about 6 ns (t2), and were assigned to the recombination pathways of the core states and surface functional groups, respectively. The time constants and relative amplitudes show that progressing from B-L-CPDs to R-L-CPDs, as the average lifetime decreases from 11.39 to 2.58 ns, the t1 proportion increases from 26.18% to 77.13%, indicating that the core states in the radiative lifetime of the three Ch-CPDs play an increasing role in the red shift of the emission wavelength. In order to further explored the luminescence mechanism and the carrier relaxation dynamics of these Ch-CPDs, femtosecond transient absorption measurement was carried out under excitation at 360 nm. The spectra of l-CPDs probed at 450–700 nm show clear transient absorption at various time delays with negative and positive 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

www.angewandte.org 14093 

�2021 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

Research Articles 



absorption band (see Figure S3). The negative band corresponds to the absorption promoting the l-CPDs ground electronic state to the excited electronic state. The positive band corresponds to the absorption of the charge separation state formed by the excited state after light excitation. The above results demonstrate that our Ch-CPDs exhibit relatively uniform fluorescence radiative processes, and their multicolor emission can be attributed to changes in the carbon cores regulated by the different reaction solvents. 

The chiroptical properties of the three CPDs were studied by circular dichroism (CD) spectra. Interestingly, l-Trp and D-Trp resulted in the generation of B-/Y-/R-L-CPDs and B-/ Y-/R-D-CPDs with corresponding mirror image CD scans, as shown in Figure 1g–i. The chiralities of the three Ch-CPDs are similar, but differ from that of the precursor Trp. The CD spectra of precursor l-/d-Trp (see Figure S4) show that the signals of l-Trp and d-Trp are symmetrical around 200– 246 nm, while the CD signals of the three Ch-CPDs extend from 200 to 300 nm, indicating that the precursors undergo carbonization and polymerization, providing a new CD signal at 245–300 nm. Obviously, the CD signal of the three ChCPDs near 200–246 nm is inherited from the intrinsic chiral chromophore of the precursor l-/d-Trp. The CD signals from 245 to 300 nm are generated by the p-p* transitions of aromatic sp<sup>2</sup> domains in a chiral environment.<sup>[6]</sup> Ch-CPDs are generally believed to be composed of a carbon core with attached chiral functional group, and both affect the CD signal.<sup>[2d]</sup> Therefore, progressing from B-Ch-CPDs to R-ChCPDs, changes in the carbon cores and surface chiral functional group result in slight differences in their CD signals. In R-Ch-CPDs, the proportion of carbon cores increases and that of the surface chiral functional groups decreases, leading to weaker chiral signals compared to B- and Y-Ch-CPDs. Moreover, under the same reaction conditions, several products were obtained using only a single l-/d-Trp precursor, and their chiral signals were different from those of the corresponding multicolor Ch-CPDs under the same conditions (see Figure S5). These results indicate that chiral precursors and achiral precursors combine specifically in the solvothermal process, and the chirality of the multicolor CPDs stems from the structure of the product itself rather than from unreacted chiral precursors or a combination of chiral precursors. 

The morphology, dimensions, and crystallographic characteristics of the three Ch-CPDs were studied by transmission electron microscopy (TEM). The TEM images in Figure 2a–c show homogeneous size distributions of approximately 2.5 � 0.5, 3.0 � 0.4, and 4.6 � 0.6 nm for B-, Y-, and R-L-CPDs, respectively, and high-resolution TEM (HRTEM) images of all the L-CPDs show typical lattice fringes of 0.21 nm, attributed to the in-plane lattice distance of graphene (100 facet).<sup>[22]</sup> The morphologies of the three L-CPDs were further examined by atomic force microscopy (AFM). The images (Figure 2d–f) show monodisperse B-, Y-, and R-L-CPDs with topographic heights below 3.3, 3.6, and 5.5 nm, respectively. This result agrees well with the TEM characterization, indicating that the Ch-CPDs have similar core structures, and the emission redshifts with increasing particle size. 

Fourier transform infrared spectroscopy (FT-IR) analysis of three l-CPDs (Figure 2g) shows their abundant polar functional groups (e.g., O<sup>�</sup> H, N<sup>�</sup> H, C<sup>�</sup> O, C<sup>=</sup> O, and COOH), thereby ensuring their outstanding solubility in polar solvents. The vibrational absorption signal at 3414 cm<sup>�1</sup> is likely due to -OH/-NH vibrations of carboxylic acid and amine groups. This peak is wider in the CPDs compared with precursor l-/dTrp, possibly due to association among hydrogen bonds.<sup>[16c]</sup> New bands at 1315 cm<sup>�1</sup> represent the stretching of -C<sup>=</sup> ONH.<sup>[16c]</sup> Moreover, progressing from B-L-CPDs to R-LCPDs, the stretching vibration intensity of C<sup>=</sup> O at 1630 cm<sup>�1</sup> decreases significantly, while the stretching vibration intensities of C<sup>=</sup> C at 1529 cm<sup>�1</sup> gradually increase, demonstrating that the content of polyaromatic structures improves progressively through dehydration polymerization.<sup>[23]</sup> The thermostability of these l-CPDs were investigated by thermogravimetric analysis (TGA). As shown in Figure 2h, the first component lost is likely water of crystallization. The mass loss below 300 8 C is likely attributed to pyrolysis of chemical moieties associated with the l-CPDs, whereas that at 300– 450 8 C is ascribed to species that are linked strongly to the L- CPDs via covalent bonds or some active parts of the carbon cores. The remaining components are polyaromatic structures with high thermal stability.<sup>[24]</sup> Progressing from B-L-CPDs to R-L-CPDs, the mass of the highly thermostable polyaromatic structures gradually increases, consistent with the FT-IR results. The hybridization states of the carbon atoms were characterized by 1H and 13C nuclear magnetic resonance (NMR) spectroscopy (see Figure S6). The<sup>1</sup> H NMR spectra of the l-CPDs show sp<sup>2</sup> -hybridized carbon atoms. The H<sup>a’</sup> and H<sup>b’</sup> atoms exhibit homologous chemical shifts to the H<sup>a</sup> and H<sup>b</sup> atoms of Trp, demonstrating the presence of L-Trp residues on the surface of the B-, Y-, and R-L-CPDs. The retention of these chiral structures on the CPDs provides the chirality of the multicolor Ch-CPDs. The<sup>13</sup> C NMR spectra show signals at 10–70 ppm and 100–145 ppm, attributed to nonconjugated aliphatic sp<sup>3</sup> carbon atoms and conjugated sp<sup>2</sup> carbon atoms, respectively. New signals near 171 ppm reveal the presence of amide groups in the l-CPDs.<sup>[25]</sup> The appearance of signals characteristic of new amide groups in both the FT-IR and NMR spectra indicate that the precursor underwent dehydration polymerization during the hydrothermal process. Furthermore, the<sup>1</sup> H and<sup>13</sup> C NMR data clearly show an increase in conjugated sp<sup>2</sup> structures progressing from B-LCPDs to R-L-CPDs and a decrease in non-conjugated sp<sup>3</sup> structures, consistent with the above FT-IR and TGA results. 

The full X-ray surface photoelectron spectra (XPS) results show that the B-, Y-, and R-L-CPDs are mainly composed of carbon, nitrogen, and oxygen (Figure 2i), indicating that they all comprise the same elements. Deconvoluted XPS spectra for C 1s, N 1s, and O 1s (Figure 3) show a C 1s band containing four main peaks at 284.4, 285.2, 286.1, and 288.7 eV, attributed to C<sup>�</sup> C/C<sup>=</sup> C, C<sup>�</sup> N, C<sup>�</sup> O, and C<sup>=</sup> O, respectively. The N 1 s spectra show three peaks near 398.1, 399.3, and 400.2 eV, attributed to pyridinic N, pyrrolic N, and graphitic N, respectively. The O 1s spectra exhibit two peaks at 531.5 and 532.4 eV for C<sup>=</sup> O and C<sup>�</sup> O bands, respectively. Furthermore, the sp<sup>2</sup> carbon content increases gradually from 0.26 in B-L-CPDs to 0.44 in R-L-CPDs, and the content of 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

14094 www.angewandte.org 

�2021 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

Research Articles 





Figure 2. TEM and HRTEM images (inset) of a) B-L-CPDs, b) Y-L-CPDs, c) R-L-CPDs. AFM images of d) B-L-CPDs, e) Y-L-CPDs, f) R-L-CPDs. g) FT-IR spectra of the three L-CPDs. h) TGA spectra of the three l-CPDs. i) XPS spectra of the three l-CPDs. 

graphitic N also increases from 0.12 in B-L-CPDs to 0.41 in R- L-CPDs (see Table S3). An increase in graphitic nitrogen content has been reported to reduce nonradiative relaxation.<sup>[15b]</sup> Therefore, the QY of R-L-CPDs does not decrease significantly as the particle size increases, consistent with previous reports. This result also implies that the content of sp<sup>2</sup> -conjugated domains in these CPDs increases after the dehydration reaction, consistent with their increased particle size. The chemical compositions and variation tendencies of the B-, Y-, and R-D-CPDs are similar to those of the B-, Y-, and R-L-CPDs, indicating that the chemical compositions of l-CPDs and d-CPDs are basically the same and that they are perfect enantiomers. In brief, all the above characteristics, 

including the FTIR, TGA, NMR, and XPS results, clearly indicate that our multicolor Ch-CPDs have abundant oxygen/ nitrogen-containing functional groups, and when their emission shifts from blue to red, the conjugated sp<sup>2</sup> structure and particle sizes increase, but the nonconjugated sp<sup>3</sup> structure decreases. 

Introducing chirality into CPDs is facile, but CPL, which has important applications in 3D display, optical storage, optical anti-counterfeiting, and asymmetric synthesis, is usually difficult to achieve. Our Ch-CPDs have unique multicolor-emission properties, excellent optical properties, are easy to prepare, and are environmentally friendly, making them highly suitable for preparing multicolor CPL materials. 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

�2021 Wiley-VCH GmbH 

www.angewandte.org 14095 

**_Angewandte Chemie_** 

Research Articles 





Figure 3. High-resolution XPS C 1s spectra of a) B-L-CPDs, d) Y-L-CPDs, and g) R-CPDs. High-resolution XPS N 1s spectra of b) B-L-CPDs, e) Y-LCPDs, and h) R-L-CPDs. High-resolution XPS O 1s spectra of c) B-L-CPDs, f) Y-L-CPDs, and i) R-L-CPDs. 

We therefore mixed our CPDs with the well-studied organic lipid DGAm and its enantiomer LGAm, which are reported to form chiral organogels in various solvents.<sup>[27]</sup> We found that cogels formed when either lipid was mixed with the Ch-CPDs, inducing circularly polarized emission. Interestingly, the PL spectra of the co-assemblies had almost identical shapes to that of the Ch-CPDs (Figure 4a), demonstrating that the fundamental emission properties of the multicolor Ch-CPDs in co-assemblies were well preserved. Furthermore, the red emission co-assemblies (DGAm/R-L-CPDs) showed a slight redshift (about 6 nm) whereas the blue and yellow emission co-assemblies did not shift, perhaps due to the large differences between the surface states of the R-L-CPDs and the B-/ Y-L-CPDs. Compared with pure Ch-CPDs, the UV-vis absorption spectra of co-assemblies have changed to a certain extent (see Figure S6). Doping the Ch-CPDs into the chiral organogel altered some chiroptical properties of organogel. The chiral characteristics of the ground state of the coassemblies were checked by CD spectroscopy (Figure 4b). 

DGAm and LGAm alone showed a chiral signal around 219 nm (see Figure S7). Measurement of the CD signal of DGAm/l-CPDs and LGAm/d-CPDs showed various degrees of changes in the co-assembly chiral signals. In the DGAm/BL-CPDs and LGAm/B-D-CPDs, the symmetrical CD signals appear at 210 nm and 253 nm, whereas in the DGAm/Y-LCPDs and LGAm/Y-D-CPDs, the CD signals redshifted to 310 nm and were broader. The CD signals of the DGAm/R-LCPDs and LGAm/R-D-CPDs redshifted to 400 nm and were broader. These results indicate that the incorporation of ChCPDs into the organogel, chirality regulation of the organogel can be achieved. CPL spectra was used to study the excitedstate chiralities of the co-assemblies and showed that all cogels exhibited simultaneous CPL. Left-handed signals were observed in cogels of DGAm/l-CPDs and right-handed signals were obtained in LGAm/d-CPDs cogels (Figure 4c). CPL spectra of the three cogels showed mirror-image signals at 450, 550 and 610 nm. The luminescence dissymmetry factor (glum) is used to evaluate the level of CPL and is defined as 

�2021 Wiley-VCH GmbH 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

14096 www.angewandte.org 

**_Angewandte Chemie_** 

Research Articles 





Figure 4. a) PL spectra of the three L-CPDs-doped cogels at their optimum excitation wavelength. The insets show corresponding photographs under 365 nm UV light. b) CD spectra of three Ch-CPDs doped cogels. c) Mirror image CPL spectra of the three Ch-CPDs-doped cogels. SEM image (d) and AFM image (e) of Y-L-CPDs-doped DGAm. f) FT-IR spectra of pure DGAm gel and the three L-CPDs doped cogels. g) PL spectra of the white-emitting cogel, excitation source: lex = 365 nm. The insets are a photograph of the gel under 365 nm UV light (top right) and the CIE coordinate value of the white-emitting cogel (bottom left). h) CPL dissymmetry factor glum of DGAm/L-CPDs (black) and LGAm/D-CPDs (red), excitation source: lex = 365 nm. i) Laser scanning confocal microscopy images of the white-emitting cogel, excitation source: lex = 405 nm. All the above gel samples were prepared in absolute ethanol solvent, DGAm/LGAm = 20 mgmL<sup>�1</sup> , Ch-CPDs = 0.25 mgmL<sup>�1</sup> . 

glum = 2 �(IL�IR)/(IL + IR). Among them, IL and IR are related to the intensity of the left- and right-handed CPL, respectively.<sup>[1c]</sup> Experimentally, CPL was measured using a JASCO CPL-300 spectrometer, and glum was defined as glum = 2 �[ellipticity/(32980/ln10)]/total fluorescence intensity at the CPL extremum. The calculated value of glum of the CPL signal was about � 10<sup>�2</sup> , while a maximum value of �1 �10<sup>�2</sup> was observed for LGAm/Y-D-CPDs (Supporting Information, Table S5), which is considerably larger than that of other inorganic quantum dot co-assembly systems such as CdSe/ ZnS core–shell quantum dots co-assembly systems (maximum + 2.5 �10<sup>�3</sup> )<sup>[18c]</sup> and perovskite nanocrystals co-assembly systems (maximum + 7.3 �10<sup>�3</sup> ).<sup>[28]</sup> More importantly, the 

synthesis of our phosphors is simpler and environmentally friendly. 

DGAm (see Figure S9a) exhibited several-hundred micrometer-long tubular nanostructures formed in ethanol solution. The TEM images (see Figure S9b) indicate that the nanotubes have an outer-sphere diameter of about 117 nm and an inner-sphere diameter of about 25 nm. The aspect ratio of the nanotubes is greater than 1000. After mixing with the l-CPDs, the morphologies of the nanotubes are unchanged and show similar uniform structures, as shown in Figure 4d and e. The contrast of l-CPDs is similar to that of DGAm, making them difficult to distinguish. However, the l- CPDs are aggregated on the surface of the nanotubes can still 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

�2021 Wiley-VCH GmbH 

www.angewandte.org 14097 

**_Angewandte Chemie_** 

Research Articles 



be observed in the magnified image (see Figure S9c). Powder X-ray diffraction patterns of DGAm/l-CPDs mixtures show patterns identical to that of pure DGAm in the xerogel state (see Figure S10). All these results indicate that the addition of Ch-CPDs does not destroy the gel structure. The FT-IR spectra show the formation of typical electrostatic interactions between Ch-CPDs and the organogel. The -NH2 bending vibration in DGAm slightly shifted from 1471 cm<sup>�1</sup> to 1469 cm<sup>�1</sup> after mixing with the l-CPDs. These results clearly indicate that the addition of Ch-CPDs would not affect the formation of the nanotubes, and that Ch-CPDs assemble well along the chiral nanotubes through electrostatic interaction, possibly giving rise to the induced CPL of ChCPDs.<sup>[18c]</sup> 

Microscope optical and laser scanning confocal microscope images of the three sets of cogels are shown in Figure S10. The optical microscopy images show that all the l-CPDs-doped cogels contain long straight tubular structures essentially identical to undoped DGAm samples. The laser scanning confocal microscopy images show many blue, yellow, and red fluorescent long tubules. All the Ch-CPDs-doped cogels exhibited similar morphologies (see Figure S11a–c). Together, these observations demonstrate that the host nanotubes can integrate extraneous guest Ch-CPDs, allowing outstanding chirality regulation. The mechanism underlying the induced CPL of this cogel system was investigated using the disassembled state of the Ch-CPDs and gelator. The gelator was previously reported to have good solubility in tetrahydrofuran at concentrations below 10 mM.<sup>[18c]</sup> A transparent solution was obtained by blending Y-L-CPDs (0.25 mgmL<sup>�1</sup> ) and DGAm (10 mM) in tetrahydrofuran. Due to the solvent effect, the mixture showed strong green emission under 365 nm UV excitation, but no CPL was detected (see Figure S12), indicating that a uniform organization of Ch-CPDs along the chiral nanotube is key for the induced CPL of Ch-CPDs. 

Materials that emit white light have potential applications in displays, lighting equipment and probes, and are an ongoing important topic in the field of luminescent materials research.<sup>[14b,28]</sup> There are many reports of white emission materials obtained by mixing different chemical components of fluorescent colors, but there has never been mention of circular polarized white emission CPDs. Here, the blending of three kinds of Ch-CPDs with different fluorescent colors at a mass ratio of 4.63:15.75:1 (blue:yellow:red) provided excellent white emission, with a CIE chromaticity diagram coordinate value of (0.334, 0.329) in absolute ethanol solvent (see Figure S13). This white-emission Ch-CPDs solution was used to prepare a uniform gel exhibiting bright white emission (Figure 4g) with a CIE chromaticity diagram coordinate value of (0.334, 0.328), as shown in Figure 4g. This Ch-CPDs cogel system emitted circularly polarized white light (Figure 4h) with a dissymmetry factor glum of approximately 2.5 � 10<sup>�3</sup> , which is smaller than that of the individual Ch-CPDs cogels. The laser scanning confocal microscope image (Figure 4i) shows the morphology of the white- emitting cogel to be similar to that of the individual Ch-CPDs cogel samples, with many long tubules emitting white light, conclusively 

demonstrating for the first time the generation of circularly polarized white emission CPDs. 

### Conclusion 

In conclusion, we have developed a facile and controllable approach to the synthesis of highly efficient excitationindependent multicolor Ch-CPDs emitting over the entire visible range for the first time. The dehydration and carbonization processes of the chiral precursors and achiral precursors controlled by different reaction solvents determine the content of sp<sup>2</sup> -conjugated domains and sp<sup>3</sup> -nonconjugated domains, and of different particle sizes in the different color Ch-CPDs, ultimately providing different Ch-CPDs emission colors from blue to red. This is not only the first realization of multicolor Ch-CPDs, but also the first of red-emitting ChCPDs. More importantly, our Ch-CPDs can be doped into chiral organogel (DGAm/LGAm) to allow circularly polarized multicolor emission, and this is the first report of circularly polarized white emission Ch-CPDs (CIE = 0.334, 0.328). This work provides a facile route to Ch-CPDs with excellent optical properties by controlling the formation processes, affording a general approach and new insights for obtaining CPL-active emissive carbon-based materials. 

### Acknowledgements 

This work was financially supported by the National Natural Science Foundation of China (21905253, 51973200, 92061201) and the China Postdoctoral Science Foundation (2018M640681, 2019T120632). 

### Conflict of interest 

The authors declare no conflict of interest. 

Keywords: carbonized polymer dots · chirality · luminescence · nanomaterials · self-assembly 

- [1] a) M. Liu, L. Zhang, T. Wang, Chem. Rev. 2015, 115, 7304 – 7397; b) Y. Sang, J. Han, T. Zhao, P. Duan, M. Liu, Adv. Mater. 2020, 32, 1900110; c) C. Zhang, Z.-P. Yan, X.-Y. Dong, Z. Han, S. Li, T. Fu, Y.-Y. Zhu, Y.-X. Zheng, Y.-Y. Niu, S.-Q. Zang, Adv. Mater. 2020, 32, 2002914. 

- [2] a) Y. Ru, L. Ai, T. Jia, X. Liu, S. Lu, Z. Tang, B. Yang, Nano Today 2020, 34, 100953; b) C. Wang, E. Wu, X. Wu, X. Xu, G. Zhang, L. Pu, J. Am. Chem. Soc. 2015, 137, 3747 – 3750; c) T. Yasukawa, H. Miyamura, S. Kobayashi, Chem. Soc. Rev. 2014, 43, 1450 – 1461; d) F. Li, S. Li, X. Guo, Y. Dong, C. Yao, Y. Liu, Y. Song, X. Tan, L. Gao, D. Yang, Angew. Chem. Int. Ed. 2020, 59, 11087 – 11092; Angew. Chem. 2020, 132, 11180 – 11185. 

- [3] T. G. Schaaff, R. L. Whetten, J. Phys. Chem. B 2000, 104, 2630 – 2641. 

- [4] a) C. Noguez, I. L. Garz�n, Chem. Soc. Rev. 2009, 38, 757 – 771; b) W. Ma, L. Xu, A. F. de Moura, X. Wu, H. Kuang, C. Xu, N. A. Kotov, Chem. Rev. 2017, 117, 8041 – 8093; c) Y. Dong, Y. Zhang, X. Li, Y. Feng, H. Zhang, J. Xu, Small 2019, 15, 1902237; d) K. 

�2021 Wiley-VCH GmbH 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

14098 www.angewandte.org 

**_Angewandte Chemie_** 

Research Articles 



Hou, J. Zhao, H. Wang, B. Li, K. Li, X. Shi, K. Wan, J. Ai, J. Lv, D. Wang, Q. Huang, H. Wang, Q. Cao, S. Liu, Z. Tang, Nat. Commun. 2020, 11, 4790. 

- [5] a) H. Song, Y. Li, L. Shang, Z. Tang, T. Zhang, S. Lu, Nano Energy 2020, 72, 104730; b) Y. Liu, X. Li, Q. Zhang, W. Li, Y. Xie, H. Liu, L. Shang, Z. Liu, Z. Chen, L. Gu, Z. Tang, T. Zhang, S. Lu, Angew. Chem. Int. Ed. 2020, 59, 1718 – 1726; Angew. Chem. 2020, 132, 1735 – 1743; c) S. Lu, G. Xiao, L. Sui, T. Feng, X. Yong, S. Zhu, B. Li, Z. Liu, B. Zou, M. Jin, J. S. Tse, H. Yan, B. Yang, Angew. Chem. Int. Ed. 2017, 56, 6187 – 6191; Angew. Chem. 2017, 129, 6283 – 6287. 

- [6] L. �ord¯evic´, F. Arcudi, A. D�Urso, M. Cacioppo, N. Micali, T. B�rgi, R. Purrello, M. Prato, Nat. Commun. 2018, 9, 3442. 

- [7] F. Li, Y. Li, X. Yang, X. Han, Y. Jiao, T. Wei, D. Yang, H. Xu, G. Nie, Angew. Chem. Int. Ed. 2018, 57, 2377 – 2382; Angew. Chem. 2018, 130, 2401 – 2406. 

- [8] M. Zhang, H. Wang, B. Wang, Y. Ma, H. Huang, Y. Liu, M. Shao, B. Yao, Z. Kang, Small 2019, 15, 1901512. 

- [9] G. Ragazzon, A. Cadranel, E. V. Ushakova, Y. Wang, D. M. Guldi, A. L. Rogach, N. A. Kotov, M. Prato, Chem 2021, 7, 606 – 628. 

- [10] a) Z. Zhu, Y. Zhai, Z. Li, P. Zhu, S. Mao, C. Zhu, D. Du, L. A. Belfiore, J. Tang, Y. Lin, Mater. Today 2019, 30, 52 – 79; b) B. Wang, J. Li, Z. Tang, B. Yang, S. Lu, Sci. Bull. 2019, 64, 1285 – 1292. 

- [11] J. Zhang, S.-H. Yu, Mater. Today 2016, 19, 382 – 393. 

- [12] L. Li, T. Dong, J. Mater. Chem. C 2018, 6, 7944 – 7970. 

- [13] F. Ostadhossein, G. Vulugundam, S. K. Misra, I. Srivastava, D. Pan, Bioconjugate Chem. 2018, 29, 3913 – 3922. 

- [14] a) S. Tao, T. Feng, C. Zheng, S. Zhu, B. Yang, J. Phys. Chem. Lett. 2019, 10, 5182 – 5188; b) M. Chekini, E. Prince, L. Zhao, H. Mundoor, I. I. Smalyukh, E. Kumacheva, Adv. Opt. Mater. 2020, 8, 1901911. 

- [15] a) B. Wang, J. Yu, L. Sui, S. Zhu, Z. Tang, B. Yang, S. Lu, Adv. Sci. 2021, 8, 2001453; b) H. Ding, J.-S. Wei, P. Zhang, Z.-Y. Zhou, Q.-Y. Gao, H.-M. Xiong, Small 2018, 14, 1800612; c) Z. Tian, X. Zhang, D. Li, D. Zhou, P. Jing, D. Shen, S. Qu, R. Zboril, A. L. Rogach, Adv. Opt. Mater. 2017, 5, 1700416. 

- [16] a) L. Zhou, D. Zheng, B. Wu, Y. Zhu, L. Zhu, ACS Appl. Nano Mater. 2020, 3, 946 – 952; b) A. Ghosh, B. Parasar, T. Bhattacharyya, J. Dash, Chem. Commun. 2016, 52, 11159 – 11162; c) Y. Wei, L. Chen, J. Wang, X. Liu, Y. Yang, S. Yu, RSC Adv. 2019, 9, 3208 – 3214. 

- [17] a) H. Jiang, Y. Jiang, J. Han, L. Zhang, M. Liu, Angew. Chem. Int. Ed. 2019, 58, 785 – 790; Angew. Chem. 2019, 131, 795 – 800; b) C. Hao, Y. Gao, D. Wu, S. Li, L. Xu, X. Wu, J. Guo, M. Sun, X. Li, C. Xu, H. Kuang, Adv. Mater. 2019, 31, 1903200. 

- [18] a) H. Zheng, B. Ju, X. Wang, W. Wang, M. Li, Z. Tang, S. X.-A. Zhang, Y. Xu, Adv. Opt. Mater. 2018, 6, 1801246; b) A. Li, D. Zheng, M. Zhang, B. Wu, L. Zhu, Langmuir 2020, 36, 8965 – 8970; c) S. Huo, P. Duan, T. Jiao, Q. Peng, M. Liu, Angew. Chem. Int. Ed. 2017, 56, 12174 – 12178; Angew. Chem. 2017, 129, 12342 – 12346. 

- [19] S. Lu, L. Sui, J. Liu, S. Zhu, A. Chen, M. Jin, B. Yang, Adv. Mater. 2017, 29, 1603443. 

- [20] H. Ding, J.-S. Wei, H.-M. Xiong, Nanoscale 2014, 6, 13817 – 13823. 

- [21] a) S. Sun, L. Zhang, K. Jiang, A. Wu, H. Lin, Chem. Mater. 2016, 28, 8659 – 8668; b) L. Wang, W. Li, L. Yin, Y. Liu, H. Guo, J. Lai, Y. Han, G. Li, M. Li, J. Zhang, R. Vajtai, P. M. Ajayan, M. Wu, Sci. Adv. 2020, 6, eabb6772. 

- [22] W. Li, Y. Liu, M. Wu, X. Feng, S. A. T. Redfern, Y. Shang, X. Yong, T. Feng, K. Wu, Z. Liu, B. Li, Z. Chen, J. S. Tse, S. Lu, B. Yang, Adv. Mater. 2018, 30, 1800676. 

- [23] F. Yuan, T. Yuan, L. Sui, Z. Wang, Z. Xi, Y. Li, X. Li, L. Fan, Z. Tan, A. Chen, M. Jin, S. Yang, Nat. Commun. 2018, 9, 2249. 

- [24] A. Mewada, S. Pandey, S. Shinde, N. Mishra, G. Oza, M. Thakur, M. Sharon, M. Sharon, Mater. Sci. Eng. C 2013, 33, 2914 – 2917. 

- [25] S. Zhu, Q. Meng, L. Wang, J. Zhang, Y. Song, H. Jin, K. Zhang, H. Sun, H. Wang, B. Yang, Angew. Chem. Int. Ed. 2013, 52, 3953 – 3957; Angew. Chem. 2013, 125, 4045 – 4049. 

- [26] X. Zhu, Y. Li, P. Duan, M. Liu, Chem. Eur. J. 2010, 16, 8034 – 8040. 

- [27] Y. Shi, P. Duan, S. Huo, Y. Li, M. Liu, Adv. Mater. 2018, 30, 1705011. 

- [28] a) M. Fujiki, Y. Kawamoto, M. Kato, Y. Fujimoto, T. Saito, S.-i. Hososhima, G. Kwak, Chem. Mater. 2009, 21, 2459 – 2466; b) C.Y. Sun, X.-L. Wang, X. Zhang, C. Qin, P. Li, Z.-M. Su, D.-X. Zhu, G.-G. Shan, K.-Z. Shao, H. Wu, J. Li, Nat. Commun. 2013, 4, 2717; c) Z. Han, X.-Y. Dong, P. Luo, S. Li, Z.-Y. Wang, S.-Q. Zang, T. C. W. Mak, Sci. Adv. 2020, 6, eaay0107. 

- Manuscript received: March 7, 2021 Revised manuscript received: April 1, 2021 Accepted manuscript online: April 8, 2021 Version of record online: May 10, 2021 

www.angewandte.org 

Angew. Chem. Int. Ed. 2021, 60, 14091 – 14099 

�2021 Wiley-VCH GmbH 

14099 

