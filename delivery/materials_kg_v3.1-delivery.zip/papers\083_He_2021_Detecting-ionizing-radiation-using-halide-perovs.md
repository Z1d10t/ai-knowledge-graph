# Detecting ionizing radiation using halide perovskite semiconductors processed through solution and alternative methods

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Photonics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 250 |
| 作者 | Yi-Hui He, I. Hadar, M. Kanatzidis |
| DOI | 10.1038/s41566-021-00909-5 |
| 源文件 | 083_He_2021_Detecting-ionizing-radiation-using-halide-perovs.pdf |

---
# **Detecting Ionizing Radiation Using Halide Perovskites Semiconductors Processed through Solution and Alternative Methods** 

Yihui He<sup>1,2†</sup> , Ido Hadar<sup>4†</sup> , Mercouri G. Kanatzidis<sup>2,3*</sup> 

_1State Key Laboratory of Radiation Medicine and Protection, Collaborative Innovation Center of Radiological Medicine of Jiangsu Higher Education Institutions, and School for Radiological and Interdisciplinary Sciences (RAD-X), Soochow University, Suzhou 215123, China_ 

_2Department of Chemistry, Northwestern University, Evanston, Illinois 60208, USA_ 

_3Materials Science Division, Argonne National Laboratory, Argonne, IL 60439, USA_ 

_4Institute of Chemistry and the Center for Nanoscience and Nanotechnology, The Hebrew University, Jerusalem 91904, Israel._ 

*Correspondence to: m-kanatzidis@northwestern.edu 

†These authors contributed equally to this work. 

## **Abstract** 

The direct detection of high-energy radiation such as X- and γ-rays by semiconductors at room temperature is a challenging proposition that requires remarkably pure and nearly perfect crystals. The emergence of metal halide perovskites, defect-tolerant, semiconductors is reviving the hope for new materials in this field after nearly a twenty-year hiatus. Metal halide perovskites, which combine exceptional optoelectronic properties, versatile chemistry, and simple synthesis, are challenging the traditional approaches for the development of novel semiconductors for hard radiation detection. We discuss the relevant physical properties, promising materials, fabrication techniques, and device architectures for high-performance, low-cost detectors by targeting next- 

1 

generation semiconductors for radiation detection. In addition, we present a perspective on the impact of such advances in future medical imaging applications. 

## **Introduction** 

X- and γ-rays with energies ranging from tens of kilo-electron volts (keV) to mega-electron volts (MeV) are used in various photonics applications, such as medical imaging, industrial inspection, astronomy, nuclear energy industry, high-energy physics, and radioisotope identification in homeland security.<sup>1-4</sup> Direct detection of X- and γ-rays by semiconductor materials at room temperature is of significant interest, as such devices are anticipated to offer unparalleled performance in terms of high image quality, high energy resolution (ER), and compact system volume. However, till date, semiconductor detectors have been deployed commercially only in a few specific fields and applications. 

These applications are primarily based on two semiconductor materials: amorphous Se ( _a_ -Se) films in large-area radiography imaging and bulk 𝐶𝑑1−𝑥𝑍𝑛𝑥𝑇𝑒 (CZT, 𝑥≈0.1) single crystals in homeland security and nuclear medicine imaging.<sup>5,6</sup> These materials are limited by either their sensitivity (for _a_ -Se) or processability (for CZT). The increasing requirements in precision medicine and nuclear threat reduction have posed higher standards for the ongoing development of room-temperature radiation detectors. Hence, additional semiconductor materials capable of achieving superior performance but at a substantially lower cost are in demand and have been chased for decades. 

Solution-processed metal halide perovskites (MHPs), with the general formula AMX3 (A = CH3NH3<sup>+</sup> (MA), HC(NH2)2<sup>+</sup> (FA), Cs<sup>+</sup> ; M = Ge<sup>2+</sup> , Sn<sup>2+</sup> , Pb<sup>2+</sup> ; X = Cl<sup>-</sup> , Br<sup>-</sup> , I<sup>-</sup> ), have emerged in recent years as a promising class of semiconductor materials for optoelectronic applications.<sup>7-12</sup> 

2 

Initially, MHPs were utilized as absorbers in photovoltaic devices and quickly achieved high efficiency, which is comparable to that of the state-of-the-art traditional semiconductors such as Si and CdTe.<sup>12-15</sup> These advances have ignited a massive effort in the research of MHPs, which has clarified their unique and desirable characteristics and quickly led to their implementation in additional applications such as light emission and detection.<sup>16</sup> 

Based on these studies, MHPs were also considered for the challenging task of X- and γ-ray photon detection. The superior carrier transport properties of MHPs, based on a special type of defect tolerance that derives from the idiosyncrasies of their chemical bonding and electronic structure, together with their high effective atomic number that enables high stopping power, suitable bandgap energies to achieve low dark current, and versatile synthesis routes, make MHPs ideal candidates for these applications. The first example of MHP-based X- and γ-ray radiation detection was introduced in 2013 using a melt-grown CsPbBr3 semiconductor.<sup>17</sup> The discovery of CsPbBr3 for radiation detection has brought other counterparts to the forefront, as they were substantiated both as direct detectors (semiconductors) and indirect detectors (scintillators).<sup>3,18,19</sup> 

This review focuses on the application of MHPs as semiconductor detectors for high-energy X- and <mark>γ-ray d</mark> etection. We present the primary application-oriented material requirements, discuss the two detection schemes (charge-integration and single-photon modes), and present the current approaches for defining and obtaining these criteria. We discuss the unique features of the family of MHPs, specifically in dimensionality reduction (DR) and their influence on charge-integration mode detection. Versatile fabrication routes are also discussed for achieving different device geometries. We also review the MHP semiconductors used for X- and <mark>γ-ray s</mark> pectroscopy in the single-photon mode. Finally, we present an outlook on the unresolved issues and future approaches for detectors and applications based on MHP semiconductors. We anticipate that this review will 

3 

focus attention of additional members in the MHP community towards the materials development for X- and γ-ray detection and encourage researchers focused on detectors to explore and further develop advanced devices based on MHPs. We believe that such collaborations will expose and enable the full potential of MHPs as radiation detectors, similar to their implementation in other applications such as solar cells and light-emitting devices. 

## **Application-oriented criteria for material properties** 

The common ionizing radiation types include X-rays generated based on bremsstrahlung and characteristic radiation emitted by accelerated electron sources and γ-radiation emitted by radionuclides.<sup>20</sup> The broad range of energies for the X- and γ-ray photons (tens of keV to MeV) can result in various types of interaction mechanisms with semiconductors.<sup>20</sup> Hence, depending on the exact application, photon energy range and flux, different material requirements are desired, which cannot be translated into a single figure of merit. Rather, it is important to understand the different considerations for each application and the relevant physical properties of the materials themselves as well as the devices. This section surveys the important characteristics for efficient detection and their relation to the basic physical properties in practical applications. 

The first important property is the **attenuation coefficient** , which describes the interaction probability of a photon with a defined energy in a specific material. Semiconductors with high Z elements, such as MHPs and CdTe, have higher attenuation than semiconductors with low Z elements, such as Si and _a_ -Se, as shown in **Figure 1a** . The attenuation coefficient changes significantly with photon energy and decreases as the photon energy increases. This implies that 

the choice of the semiconductor and thickness of the detector should be adjusted based on the energy of the photons to achieve efficient absorption. The characteristic energies for different applications are highlighted in **Figure 1a** ; moreover, the typical detector thicknesses for these 

4 

applications can range from a few tens to hundreds of micrometers (for 20-80 keV) to a few millimeters and up to centimeters (for 0.5-3.0 MeV). 

The interaction of the high-energy photons with the semiconductor can involve a few mechanisms, including photoelectric effect, Rayleigh (coherent) and Compton (incoherent) scattering, and pair production.<sup>20</sup> For the photoelectric effect, which is dominant for photons with energies up to few hundreds of keV (depending on the specific semiconductor), the interaction cross-section in a material depends on its atomic number Z, which varies as Z<sup>n</sup> (4 < n < 5).<sup>21</sup> This interaction begins with the primary excitation of an electron, followed by the formation of high-energy electrons and holes. These energetic charge carriers interact with the semiconductor through inelastic scattering mechanisms, leading to secondary excitations and the formation of multiple electron-hole pairs. This mechanism leads to the formation of several excited charges after an interaction with a single high-energy photon, which can be detected. The number of excited charges depends on the **electron-hole formation energy (** 𝜺𝒑𝒂𝒊𝒓 **)** , which is the mean energy required for the formation of a single electron-hole pair. Empirically, 𝜀𝑝𝑎𝑖𝑟 was determined to be approximately 2-3 times the bandgap energy.<sup>22</sup> Hence, for a specific semiconductor, the number of charges (𝑛𝑒−ℎ) generated by a photon with an energy of 𝐸𝑝ℎ, is 𝑛𝑒−ℎ = 𝐸𝑝ℎ/𝜀𝑝𝑎𝑖𝑟. When 𝜀𝑝𝑎𝑖𝑟 gets smaller, more charges can be formed by a single interaction, which may increase the sensitivity and improve the ER; however, a lower bandgap can also result in higher dark current causing additional electrical noise. MHPs with 𝐸𝑔𝑎𝑝 between 1.5 and 3.0 eV are within the appropriate range that can balance between these two effects. The 𝜀𝑝𝑎𝑖𝑟 of a few representative MHPs and other semiconductors is illustrated in **Figure 1b** . 

5 

The detection of high-energy photons can be divided into two primary motifs: charge-integration and single-photon modes. The charge-integration mode is primarily applied for conventional X- ray imaging and other high-flux radiation conditions. In this mode, the integrated X-ray induced charge per unit time or photocurrent serves as the metric to generate the contrast in the X-ray image; however, measuring the spectral information of incident photons is not possible in this mode. Specifically, the total cumulative charge of each unit time (per exposure window) is stored and subsequently extracted by an electronic circuit. The integrated signal is proportional to the incident radiation flux. The continuous flux can be as high as 10<sup>7</sup> -10<sup>8</sup> photons·cm<sup>-2</sup> ·s<sup>-1</sup> .<sup>23</sup> **X-ray sensitivity** is defined by the quantity of collected charge per unit area per unit radiation exposure.<sup>24</sup> Thus, the X-ray sensitivity _S_ is evaluated as 𝑺 = 𝑱𝒏𝒆𝒕 / Ḋ, where _J_ net is the net photocurrent density and Ḋ is the dose rate to air. The typical units for S are 𝜇𝐶 𝐺𝑦𝑎𝑖𝑟−1 𝑐𝑚−2. For a specific semiconductor, the theoretical sensitivity based on the generated charges (without additional processes), 𝑆0, is 

5.45×10<sup>13</sup> 𝑒 𝛼𝑒𝑛 determined by 𝜀𝑝𝑎𝑖𝑟.<sup>24</sup> Under monoenergetic radiation, 𝑆0 = [(𝛼𝑎𝑖𝑟/𝜌𝑎𝑖𝑟)𝜀𝑝𝑎𝑖𝑟 ~~]~~ ( 𝛼 ~~)~~ , where α and 

αen are the mass and mass energy-absorption coefficients, respectively, and 𝛼𝑎𝑖𝑟/𝜌𝑎𝑖𝑟 is the ratio of the energy-absorption coefficient of air to its density.<sup>25</sup> As indicated, regardless of the charge collection deficiency, the photocurrent response behavior remains consistent across the thickness of the device, as illustrated in **Figure 1c** . For a 100 keV monoenergetic source and CsPbBr3 with 𝜀𝑝𝑎𝑖𝑟 = 5.3 𝑒𝑉,<sup>18</sup> the theoretical maximum _S_ 0 can be estimated as ~8030 μC·Gyair<sup>-1</sup> ·cm<sup>-2</sup> when 𝛼𝑒𝑛 assuming equals unity as this value is always less than unity.<sup>26</sup> Sensitivity values higher than 𝛼 the predicted 𝑆0 are presumably associated with multiplication and enhancement processes;<sup>27,28</sup> however, the involved physical processes in MHPs still need to be clarified. In the chargeintegration mode, the level of dark current possesses a critical role in determining the threshold of the detection limit and the dynamic range of the X-ray response. In a thin-film transistor-based X- 

6 

ray imager that is operated in the charge-integration mode,<sup>29</sup> a dark current is inevitably added to the signal, resulting in an increase in electronic noise and a reduction in the signal-to-noise ratio (SNR). 

The single-photon mode can register the energy and quantity of individual high-energy photons when the incident flux is low or intermediate,<sup>30</sup> i.e., as low as ~1 γphoton·cm<sup>-2</sup> ·s<sup>-1</sup> or even less.<sup>30</sup> Consequently, it is suitable for functional nuclear medical imaging techniques, as well as for homeland security and remote detection applications. In this scheme, the threshold for the highest incident rate should be sufficiently less than the inverse of the maximum carrier drift time in the detector to avoid pile-up events. The shape of the transient pulses for each event in the singlephoton mode is a function of the interaction depth ( _x_ ) across the detector thickness ( **Figure 1c** ), regardless of the charge collection deficiency. As indicated, the electron and hole drift times (pulse rise time), _t_ e and _t_ h, respectively, are calculated as _x_ /(μe · _U/d_ ) and (d- _x_ )/(μh · _U/d_ ), respectively, when assuming a uniform electric field applied with voltage _U_ . The pulse amplitude is proportional to 

the induced charge per event and the pulse shape is described by the weighting potential _ϕ_ distribution according to the Shockley–Ramo theorem.<sup>31-33</sup> The quantity of induced charge _Q_ is determined by the **charge collection efficiency (CCE)** with the dependence of the electric field _E_ , 



<!-- Start of picture text -->
𝜇𝜏𝑒𝐸 − 𝑥 𝜇𝜏ℎ𝐸 − 𝑑−𝑥<br>𝜇𝜏𝑒𝐸 𝜇𝜏ℎ𝐸<br>𝑑 (1 −𝑒 ) + 𝑑<br>i.e.,  𝑄= 𝑄0𝐶𝐶𝐸= 𝑄0 [ (1 −𝑒 )],  where  Q0  is the theoretical<br><!-- End of picture text -->

charge (q _E_ γ/εpair) generated by a single γ-ray photon with an energy _E_ γ. This equation is applicable when the electric field _E_ and traps are uniformly distributed. Dark current can also be a main source of shot noise in this detection scheme, however, it usually appears in the lower edge of the energy spectrum.<sup>34</sup> Therefore, the influence of dark current can be effectively eliminated by modifying the discrimination level without compromising detection efficiency. The trapping of charges also 

7 

has a profound effect on the pulse shape and amplitude. Especially in MHP semiconductors, we notice significant electron carrier trapping at room temperature and possible hole carrier trapping at low temperatures.<sup>35</sup> Major applications based on the charge-integration and single-photon modes are presented in **Box 1** . 

As mentioned above, **CCE** defines the collection of the excited charges upon interaction with highenergy photons. Efficient charge collection is crucial for high sensitivity and ER. It depends on the ability to separate the excited charge carriers and subsequently transport them to the electrodes efficiently. In this sense, a 3D MHP with low exciton binding energy, on the order of a few meV,<sup>36</sup> enables efficient charge separation even under a small bias. Additional factors affecting the CCE are crystal defects, grain boundaries, and impurities that may serve as recombination, scattering or trapping centers. A MHP with defect tolerance minimizes the influence of such defects without the necessity for the significantly high purity levels that are required for traditional semiconductors. These characteristics can be summarized as an important physical property, which is referred to as **mobility-lifetime product (** 𝝁𝝉). When the value of 𝜇𝜏 is higher, the excited charges can drift over longer distances under the same bias and are collected more efficiently. Although the carrier mobility in MHPs is moderate, the value of 𝜇𝜏 is large because of the long lifetime of the carriers, which aids in achieving a high CCE using MHP devices. An additional advantage of MHPs is the balanced values of 𝜇𝜏 for electrons and holes, which assist in extracting both charge carriers efficiently.<sup>10</sup> 

Finally, as the **dark current** of a device performs a significant role in several applications, the **electrical resistivity** of a specific compound is another important parameter. It depends on the basic structure and composition of the semiconductor, as well as on other characteristics such as morphology, defects, and dopants. Low resistivity may result in a significant dark current, 

8 

especially under strong bias conditions, adding significant noise that cannot be easily filtered, thereby limiting the SNR. MHPs have a relatively high resistivity at room temperature. This is especially important as several laboratory devices can show promising sensitivity even with a high dark current; however, reducing the dark current is crucial for practical applications.<sup>37,38</sup> In general, resistivity values of approximately 10<sup>9</sup> −10<sup>11</sup> Ω ⋅𝑐𝑚, are considered suitable for ensuring a sufficiently low dark current. These values can be obtained for MHP single crystals or by the careful design and fabrication of MHP polycrystalline devices. 

These properties are summarized in the radar chart shown in **Figure 1d** , demonstrating the critical parameters of the representative perovskite semiconductor CsPbBr3 among conventional semiconductors ( _a_ -Se, CZT, TlBr, GaAs), indicating its well-balanced overall properties. 

After considering the specific application and the physical parameters discussed above, the sensitivity or ER depending on the relevant detection mode can be determined. When measuring the sensitivity, it is essential to carefully define the incident and absorbed doses (based on the sample thickness and attenuation), bias, sample size; moreover, when specifically normalizing to size, it is important to consider that high-energy photons can penetrate through the electrodes. Considering these parameters improperly can lead to unacceptably overestimated sensitivity values. It is also essential to examine the detector under the relevant energy range and dose rate in which it will be applicable. 

9 

**FIGURE 1. Basic physical processes and characteristics of semiconductor X-ray detectors.** (a) Attenuation versus photon energy for various semiconductors and MHPs, which determines the required thickness of the device. Relevant energies are marked for projectional radiography (green, 20-100 keV), nuclear medicine imaging (purple, 50-511 keV), industrial inspection (orange, 80-450 keV), and homeland security (blue, 0.1-3 MeV). (b) Electron-hole formation energy (𝜀𝑝𝑎𝑖𝑟) versus bandgap for typical semiconductors and MHPs.<sup>39</sup> Inset: photoelectric interaction of a highenergy photon with a semiconductor material and the formation of multiple excited charge carriers. (c) Illustration of the physical interaction of high-energy radiation with a semiconductor device and the detection at different depths for charge-integration (left) and single-photon (right) detection modes based on ref<sup>20</sup> . For charge-integration mode, only the intensity can be resolved; hence, the signal is the same regardless of the interaction depth. For single-photon mode, the temporal information can be resolved and the shape of the detection pulse changes with interaction depth. (d) Radar plot of the desired properties for semiconductor devices, a larger radius is desired for an efficient detector. 1/ _T_ m, 1/purity, 1/𝜀𝑝𝑎𝑖𝑟 represent the inverse melting point, purity levels, and 𝜀𝑝𝑎𝑖𝑟, respectively. 

### **Box 1 – Two principles of medical imaging application** 

In medical X- or γ-ray imaging applications, two principles are commonly used and shown as projectional radiography (a) and nuclear medicine imaging (b). 

As illustrated in (a), a flood X-ray source is used to penetrate the object, and a large-area flat-panel detector generates a static image with anatomical information per exposure time. Bremsstrahlung 

X-rays are commonly used here with energies of approximately 20-100 keV for medical applications and possibly higher energies for <mark>industrial inspection. The detector usually operates</mark> in charge-integration mode under a relatively high flux (10<sup>7</sup> -10<sup>8</sup> photons·cm<sup>-2</sup> ·s<sup>-1</sup> ).<sup>23</sup> Currently, the dominant semiconductor detectors are based on _a_ -Se and a thin-film transistor panel for imaging with energies up to tens of keV. <mark>The basic performance characteristics of the detectors include dark current, X-ray sensitivity</mark> , and detection <mark>limit. A summary of the recent developments in MHPs for this application is listed in Table 1 of reference</mark><sup>29</sup> <mark>. M</mark> HPs aiming for these applications are required to show improved optoelectronic properties, specifically in X-ray sensitivity and dark 

10 

current density, when compared to _a_ -Se, and an outlook for the simple and scalable fabrication of large, thick films. 

<mark>Nuclear</mark> medicine <mark>imaging in (b) includes</mark> positron emission tomography (PET) and single-photon emission computed tomography (SPECT) techniques. A <mark>low c</mark> oncentration of tracer, at the picomolar level, is injected and radiolabeled accurately to the specific biological processes for disease diagnosis.<sup>40</sup> Imaging techniques are then applied to produce images of the tracer distribution. <mark>Volumetric single-crystal/polycrystalline detectors up to</mark> few centimeters of <mark>thickness are required. The ra</mark> dionuclides<sup>131</sup> <mark>I,</mark><sup>99m</sup> <mark>Tc,</mark><sup>201</sup> <mark>Tl, and</mark><sup>133</sup> <mark>Xe used for SPECT emit individual γ-ray photons ranging from 70 keV to over 300 keV.</mark><sup>40</sup> <mark>The</mark><sup>18</sup> <mark>F used in PET generates a pair of 511 keV γ-ray photons.</mark><sup>40</sup> <mark>For PET ultrahigh temporal resolution (around hundreds of ps)</mark><sup>41</sup> <mark>is needed for positional detection of the creation of a pair of γ ray photons which is challenging for semiconductor detectors. The basic performance characteristics of a γ</mark> -ray camera system used in SPECT <mark>include i</mark> ntrinsic spatial resolution, ER <mark>, and detection efficiency. The count rate here is several orders of magnitude lower than the count rates used in projectional radiography imaging.</mark> A <mark>higher ER of the detectors is desirable to reject the scattered events in a preselected energy window, to improve the final contrast of the image.</mark><sup>40</sup> <mark>It should be noted that ER depends not only the detector metrics but also the specific readout electronics performing the spectral correction for charge-sharing and depth-of-interaction. CZT detectors show a greater promise in SPECT systems by achieving ER of ~6% at 140 keV against ER of ~10% in conventional scintillator systems</mark> , <mark>leading to higher spatial resolution and lower dead space,</mark><sup>42,43</sup> <mark>as well as in emerging photoncounting CT applications, allowing spectral imaging, improved resolution and reduced exposure.</mark><sup>44</sup> <mark>A summary of the recent developments in MHP detectors operating in single-photon mode is presented in</mark> **<mark>Table 1</mark>** <mark>. MHP detectors aiming for these applications should be based on</mark> 

11 

<mark>high-quality semiconductors that could show superior optoelectronic properties including exceptional ER when compared to CZT and inorganic scintillators.</mark> 

**<mark>Schematic illustration of devices used for two common medical imaging modes</mark>** <mark>. (a) Projectional radiography with a perovskite thick film detector. (b) Nuclear medical imaging with a perovskite bulk crystal detector.</mark> 

## **Relationship between crystal structure and detector performance in MHPs** 

The crystal structure of MHPs is formed by a 3D framework of corner-sharing MX6 octahedra supported by A-site cations ( **Figure 2a** ). An important aspect of the MHP structures is their soft crystal lattice associated with dynamic tilting distortions of the MX6 octahedra and off-centering of the A-site cations,<sup>45</sup> which produces anharmonic and liquid-like fluctuation behavior.<sup>46</sup> Thorough studies have led to the proposal of polarons, in which carrier scattering could be screened by dynamic lattice distortions induced by strong electron-phonon interactions.<sup>47,48</sup> The polarons impact a scale that is several times larger than the unit cell; for example, in MAPbI3, the predicted equilibrium polaron radius is ~60 Å.<sup>49</sup> Such lattice dynamics are unique among semiconductors and are believed to perform a crucial role in defining the remarkable optoelectronic properties of 3D MHPs. 

By varying the A-site cations, the MX6 octahedral connectivity can be modified, and the incorporation of different larger cations (spacers) can alter the connectivity of the MX6 octahedral network. Lower-dimensionality structures (2D, 1D, and 0D) are formed effectively based on the MX6 octahedral connectivity through DR, as illustrated in **Figure 2a** .<sup>50-52</sup> The MX6 framework in these low-dimensional MHPs may be considered as naturally formed quantum wells, quantum 

12 

wires, and quantum dots for 2D, 1D, and 0D structures, respectively. The potential barriers due to quantum confinement are likely to hinder the transition of carriers across the barriers defined by the spacers. This results in substantially higher binding energies and trapped excitons.<sup>53</sup> Thus, the dimensionality of the MX6 octahedra connectivity performs a decisive role in determining the key physical properties of MHPs. 

The carrier mobilities of MHPs with various structures are illustrated in **Figure 2b** . In 3D MHPs that are free of spacers, the carrier mobility was determined to range from approximately 10 to several 100 cm<sup>2</sup> · V<sup>-1</sup> · s<sup>-1</sup> . It is worth mentioning that balanced electron and hole mobilities are revealed in 3D MHPs, which is consistent with their electronic band structures, indicating comparable effective masses for electrons and holes.<sup>10</sup> The 2D MHPs possess lower carrier mobility, in the range of 0.1-10 cm<sup>2</sup> · V<sup>-1</sup> · s<sup>-1</sup> . In particular, the carrier mobility values in the direction perpendicular to the layers (through the spacers) are significantly low. This, together with the strong preference of the crystals to grow as plates, implying the possible disadvantage of 2D MHPs in terms of building high-performance detectors. Additional studies conducted on DR compounds (primarily 0D) showed comparable low mobility values for the same reasons. Therefore, for the application of hard radiation detection, 3D materials are the most promising. 

X-ray sensitivity is one of the figures of merit for projection radiography in the charge-integration mode ( **Box 1** ). The dark current is also chosen as one of the metrics because it has to be matched with the requirements of thin-film transistors, as the accumulation of excessive dark current shortens the integration time of the storage capacitance and degrades the dynamic detection range.<sup>54</sup> In the majority of published works, X-ray sensitivity was determined by directly measuring the X-ray photocurrent under various dose rates. **Figure 2c** shows a summary of the reported X-ray sensitivity values. For diagnostic X-ray imaging, dark current is the primary source 

13 

of noise, and dark currents in the range of 1 −100 𝑛𝐴/𝑐𝑚<sup>2</sup> pose practical difficulties.<sup>55</sup> Specifically, for X-ray flat-panel imagers composed of _a_ -Se or other semiconductors with the thinfilm transistors, the dark current should be less than 100 𝑝𝐴/𝑐𝑚<sup>2</sup> .<sup>56,57</sup> 

As seen in **Figure 2c** , currently 3D MHP detectors provide the highest attainable X-ray sensitivity values, up to several tens of thousands of μC·Gyair<sup>-1</sup> ·cm<sup>-2</sup> , which is at least two orders of magnitude higher than that of the _a_ -Se detector of ~25 μC·Gyair<sup>-1</sup> ·cm<sup>-2</sup> .<sup>24</sup> For the 3D MHPs a plausible inverse correlation is observed between the dark current and X-ray sensitivity; for all cases, the dark current in 3D MHPs is still in the order of 1 𝑛𝐴/𝑐𝑚<sup>2</sup> or above owing to the limited resistivity in the order of 10<sup>9</sup> Ω · cm. In contrast, 2D MHPs with a higher resistivity of up to 10<sup>11</sup> Ω · cm showed a dramatically reduced dark current, approaching the order of 100 𝑝𝐴/𝑐𝑚<sup>2</sup> , which may satisfy the current requirement for projection radiography. The limited carrier mobility in 2D MHPs may require a stronger electric field during device operation to ensure the device temporal response speed between each exposure. Interestingly, despite the apparent 3D connectivity in double perovskite Cs2AgBiBr6, its physical behavior resembles low-dimensional MHPs featuring dark current that is comparable to 2D counterparts, which is close to 100 𝑝𝐴/𝑐𝑚<sup>2</sup> , and moderate X-ray sensitivity.<sup>58-61</sup> Therefore, it appears that the dimensionality of the MHP is important for tuning the properties of the materials and should be considered to satisfy alternative criteria. 

**FIGURE 2. Effects of dimensionality reduction (DR) on material and device properties.** (a) Illustration of DR of the MX6 octahedral connectivity in semiconducting compounds with perovskite-relevant structures. Typical semiconductors with different dimensionalities are listed, the color font of each semiconductor in (a) correspond to the data points shown in (b) and (c). (b) Bandgap versus carrier mobility in various single-crystalline semiconductors with perovskiterelevant structures. The carrier mobility was measured using the space-charge-limited current (SCLC) method,<sup>62</sup> time-of-flight (ToF) method using pulse laser or single-photon sources,<sup>18,63</sup> or ultrafast terahertz spectroscopy (THz) method.<sup>61</sup> (c) X-ray sensitivity versus dark current in 

14 

various polycrystalline and single-crystalline devices operating in charge-integration mode. The semiconducting X-ray performance values, including are based on published results for 3D,<sup>27,28,63-</sup> 77 2D,78-86 1D,87,88 0D,89-94, and double perovskite variants.58-61 X-ray detectors based on a-Se24 and CZT<sup>95</sup> are also indicated here for comparison. The plotted color shades are for visual guidance. 

## **Synthesis of perovskite semiconductor detectors, solution processing and** 

## **alternative methods** 

A key feature of MHPs that is not available in other competing materials in this field is the fact that they can be processed from a solution in both single-crystal and film forms. Yakunin et al.<sup>64</sup> demonstrated the first example of using a solution-processed MAPbI3 film with a thickness of 600 nm for X-ray detection. As the standard spin-coating process used for photovoltaic and lightemitting devices usually yield MHP films with thickness of only a few hundred nanometers of thickness,<sup>96</sup> alternative fabrication processes are being pursed to grow significantly thicker films that are required for efficient X-ray detection. Advances were recently made in tackling the major challenge in developing detectors with larger thicknesses (100 micrometer to a few millimeter). 

The first process we discuss is the solution growth of large MHP single crystals such as MAPbBr3, MAPbI3, and FAPbI3 in aqueous<sup>62</sup> and non-aqueous solutions,<sup>97</sup> as illustrated in **Figure 3a** . These large semiconductors show superior 𝜇𝜏 values, in the order of 1.0 × 10<sup>−2</sup> 𝑐𝑚<sup>2</sup> 𝑉<sup>−1</sup> , primarily owing to their long lifetime of up to 100 𝜇𝑠. The X-ray sensitivity of these devices was determined to be 80 𝜇𝐶 𝐺𝑦𝑎𝑖𝑟−1 𝑐𝑚−2 for a 2 mm thick MAPbBr3 semiconductor (50 kVp)63 and 650 𝜇𝐶 𝐺𝑦𝑎𝑖𝑟−1 𝑐𝑚−2 for MAPbI3 semiconductor with similar thickness (8 kVp).23 

Despite the impressive results of these semiconductor detectors, their dark current is still fairly high, in the order of a few tens of nanoamperes per square centimeter. One traditional approach to decrease the dark current is to fabricate an intrinsic positive-intrinsic-negative-type device; however, the “doping” mechanism is still not clear in MHPs and its stability is still debatable. An 

15 

alternative approach is to introduce electron- and hole-blocking layers. The common choice for blocking layers is to adopt structures that are commonly used in the photovoltaic field. In solar cells, these layers are well optimized in terms of electronic band alignment, and they reduce the 

dark current and improve the sensitivity; however, they are not suitable for a specific device architecture where a significantly higher electric field is applied. Another approach is to utilize asymmetric electrodes, each with a different work function energy, which can effectively reduce the dark current on the reverse side.<sup>18</sup> 

Additional attempts to improve the sensitivity and limit the dark current of semiconductor MHP detectors have focused on improved control over solution synthesis. An impressive recent result is the growth of triple cations, mixed halide MHP (FA0.85MA0.1Cs0.05PbI2.55Br0.45), single crystals with size over few centimeters.<sup>98</sup> Such complex compositions are common for thin films but are not easily achievable in the crystal form.<sup>98</sup> 

An alternative approach to limit the dark current is DR, as discussed above. The 2D structures are specifically desired as they enable the suppression of dark currents while maintaining reasonably high diffusion lengths and high X-ray sensitivity when measured along the 2D layers. Although it is intrinsically challenging to grow thick 2D perovskite semiconductors because crystallization in the form of thin plates is preferable, researchers have recently been able to grow well-shaped and thick 2D semiconductors by utilizing the appropriate solvent and growth processes.<sup>99</sup> Examples of 2D MHPs that can serve as high-energy radiation detectors include the organic-inorganic hybrids (F-PEA)2PbI4<sup>80</sup> and (NH4)3Bi2I9,<sup>78</sup> and the all-inorganic Rb3Bi2I9.<sup>79</sup> Similar synthetic approaches have also been utilized for the fabrication of devices based on large sized semiconductors with 0D structures, such as MA3Bi2I9,<sup>93</sup> Cs3Bi2I9,<sup>91</sup> or double perovskite compounds such as Cs2AgBiBr6.<sup>58</sup> 

16 

For these structures, the mobility is significantly lower; however, the resistivity is increased, enabling the application of higher electric fields while maintaining low dark currents. 

In recent years, significant efforts were invested in developing processes to increase the lateral size of MHP semiconductors. **Figure 3b** shows the monolithic growth of large-lateral-size MAPbBr3 semiconductors on a Si substrate. These monolithic devices allow both large size and simple integration on top of the well-established Si technology.<sup>27</sup> The Si substrate also serves as an asymmetric electrode for the readout, and these devices show a significantly high sensitivity of approximately 2.1 × 10<sup>4</sup> 𝜇𝐶 𝐺𝑦𝑎𝑖𝑟−1 𝑐𝑚−2 (8 kVp) and a low detection limit of <0.1 μGyair/s. **Figure 3i** shows the ability to resolve the thickness of the test sample as well as in the imaging of an encapsulated object. 

In parallel, there has been an effort to grow thick MHP films with increased sizes. **Figure 3c** indicates the fabrication of large-size MHP-based detectors by printing or painting a concentrated ink based on MHP precursors or crystallites, followed by low-temperature curing to form a thick polycrystalline MAPbI3 layer.<sup>38</sup> Utilizing this technique, an MHP-based digital flat-panel detector was fabricated on a thin-film transistor substrate to function as a highly sensitive X-ray imager. In this device, a strategy with multiple composite-layered structures was adopted for dark-current control by fine-tuning the charge injection at the interfaces; however, the dark-current level was still approximately two orders of magnitude higher than that in _a_ -Se devices, thereby limiting the dynamic range of the detector. An X-ray image of a hand phantom that was captured using this device is shown in **Figure 3j** . 

**FIGURE 3. Different approaches for the fabrication of MHP X- and γ-ray detectors.** (a) Solution growth of MHP semiconductor (MAPbI3<sup>23</sup> ). (b) Monolithic growth of MHP 

17 

semiconductor on a treated substrate (MAPbBr3 on Si substrate<sup>27</sup> ). (c) Printed thick film of MHP crystallites (MAPbI3<sup>38</sup> ). (d) MHP crystallites deposited on a flexible porous nylon matrix (MAPbI2.7Cl0.3<sup>100</sup> ). (e) Electrospray deposited MHP films (1D Cs2TeI6<sup>89</sup> ). (f) Pressed and sintered pellet of MHP crystallites (Cs2AgBiBr6<sup>60</sup> ). (g) Large-area all-inorganic MHP crystals fabricated by melt growth under limited thin space (CsPbBr3<sup>74</sup> ) (h) Melt growth of all-inorganic MHP semiconductors using the Bridgman method (CsPbBr3<sup>18</sup> ). (i) Optical and X-ray image of stacked glass coverslips (left) and encapsulated metallic spring (right), showing the dynamic range and the sensitivity of a MHP detector.<sup>27</sup> (j) Hand phantom X-ray image measured by a printed thick-film MHP detector.<sup>38</sup> (k) Steel pipe measured by a flexible MHP X-ray detector from inside the pipe (top) and from outside (bottom).<sup>100</sup> Detection of single γ-ray photons generated by<sup>18</sup> F radiotracers.<sup>23</sup> 

The fabrication of flexible X-ray detectors based on sheets of polycrystalline MHP-filled nylon membranes is illustrated in **Figure 3d** .<sup>100</sup> This approach is easily scalable, and the thickness of the film can be modified by laminating a few sheets one over the other. The flexibility of these devices allows their utilization for imaging the interior of a steel pipe with significantly better resolution when compared to imaging the same pipe from outside, as shown in **Figure 3k** . This ability is important for various industrial inspection applications. 

The electrospray technique can be used to achieve consecutive deposition without dissolving the printed layers to fabricate thick films, as demonstrated in **Figure 3e** , which was also utilized for the fabrication of the all-inorganic Cs2TeI6 thick-film X-ray detectors.<sup>50</sup> In the electrospray technique, a strong electric field is applied during the printing process, resulting in small ink droplets that instantly dry upon deposition and do not dissolve the printed film. The duration of the spray determines the thickness of the film, and this technique is compatible with industrial processes. 

Post-processing of MHP crystallites into a device has been explored where prefabricated MHP crystallites are pressed into pellets and sintered at temperatures below the melting point. This 

18 

results in a dense polycrystalline MHP wafer with controlled dimensions, as shown in **Figure 3f** . The primary advantage of this method is the flexibility in choosing the synthesis method for the crystallites and ability to precisely control the size and thickness of the device. Such devices based on 3D MAPbI3 and Cs2AgBiBr6 double perovskites have shown promising results in terms of sensitivity. However, because of the polycrystalline nature of the wafer, both suffer from relatively low resistivity, resulting in a high dark current, which must be resolved to ensure the applicability of this method.<sup>60,72</sup> 

An interesting melt process was applied directly on a defined substrate using CsPbBr3. In this process, presynthesized crystals are heated above their melting temperature on top of a conductive glass substrate that serves as the electrode, as shown in **Figure 3g** . Upon melting, CsPbBr3 wets the substrate and adopts its lateral dimensions. An additional substrate can be introduced from the top to define the thickness and assist with the recrystallization process upon cooling. This results in centimeter-sized grains with a thickness of a few hundred microns. Although the film is polycrystalline, the top and bottom electrodes are connected through a single grain. This process was demonstrated for CsPbBr3 all-inorganic MHPs, and the obtained sensitivity values are considerably promising.<sup>28,74</sup> Although the dark-current values for these devices were still fairly high, the ability to effectively form single crystals between the electrodes should enable to improve this property by a more careful and controlled fabrication. 

The ultimate example for well-controlled fabrication resulting in significantly high-quality and large single crystals is the traditional melt process illustrated in **Figure 3h** . This method is well established in the traditional semiconductor industry (Si, Ge, CZT), and was utilized for allinorganic MHP semiconductors, such as CsPbBr3 and CsPbCl3. Melt grown MHP single crystals 

exhibit superior physical properties such as high 𝜇𝜏 and resistivity, making them ideal for 

19 

challenging detection applications such as those with low flux and high energy up to hundreds of keV, which is discussed in the subsequent section.<sup>17,18</sup> In contrast, hybrid perovskites do not lend themselves to this melt growth procedure because the more volatile organic components decompose at high temperatures. 

## **Perovskite semiconductor detectors in single-photon mode** 

The development of semiconductor compounds for X- and γ-ray detection in single-photon mode, from the first examples (AgI and TlBr) in the 1940s till now, which were used as solid-state ionization chambers, is shown **Figure 4a** .<sup>101,102</sup> The state-of-the-art semiconductors for X- and γ- ray detection with energies ranging from tens of keV to MeV are composed of high-purity Ge (HPGe), which is expensive and only works at cryogenic temperatures, and CZT, which works at room temperature but suffers from intrinsic complexity in the growth process.<sup>103</sup> Despite the longterm demand and development, the discovery of promising semiconductor materials was almost stagnated for a few decades, until the introduction of MHPs. Overall, a twenty-year development cycle of the novel materials is presented, from Si to HPGe, to CZT, and finally to current MHPs, such as CsPbBr3. 

Till date, only 3D MHP semiconductor detectors have demonstrated spectroscopic responses under X- and γ-rays, as listed in **Table 1** . However, 2D Cs2PbI2Cl2<sup>104</sup> and 0D Cs3Bi2I9<sup>92,105</sup> have demonstrated reasonable counting responses under alpha particles exposure, indicating a significant potential for future development. 

Based on the charge collection scheme, the MHP semiconductor devices can be classified into two types in terms of ambipolar and unipolar configurations ( **Figure 4b** ).<sup>31-33</sup> According to the Shockley–Ramo theorem, in ambipolar configuration, both carriers contribute equally to the 

20 

induced signal on both electrodes, as illustrated in **Figure 1c** . In the unipolar configuration, only the carrier with selected polarity (electron or hole) contributes to the induced signal, and the carrier with the other polarity is omitted from the selected electrode. For materials with apparent transport deficiencies for either electron or hole carriers, the unipolar configuration is preferred to mitigate its manifestation. The weighting potential serves as a metric to quantify the induced signal on the readout electrode upon the interaction depth ( **Figure 4b** ).<sup>31-33</sup> 

Solution-grown α-FAPbI3 detectors have already demonstrated the first spectroscopic-grade response of γ-rays in the single-photon mode.<sup>23</sup> Solution-grown CsPbBr3 single crystal detector demonstrated a similar spectroscopic response at low temperatures (-53 °C).<sup>106</sup> An ambipolar Clalloyed MAPbBr2.94Cl0.06 single crystal detector that is operated under a low electric field of 1.8 V · mm<sup>-1</sup> shows a typical ER of 12% under<sup>137</sup> Cs γ-ray, as shown in **Figure 4c** . In addition, after improvements in interfacial and surface conditions, a similar Cl-alloyed compound (MAPbBr2.85Cl0.15) demonstrated a spectroscopic alpha particle response in a single-photon mode.<sup>107,108</sup> A modified approach employing a surface alkylamine treatment for MAPbI3 single crystals was utilized to passivate the trap states to achieve ER of 15% for 81 keV<sup>133</sup> Ba γ ray.<sup>109</sup> 

A specific electrode design that enables low dark current and high detector performance is essential. A significant improvement in ER was achieved by a simple asymmetric electrode configuration (such as Ga and Au), forming sufficient Schottky barriers to prevent charge injection from the electrode.<sup>18</sup> In **Figure 4c** , ambipolar MAPbI3 devices with asymmetric electrodes showed an ER of 6.5% at 122 keV,<sup>110</sup> while an ambipolar CsPbBr3 detector with optimized asymmetric electrodes showed an ER of 3.2% at 122 keV under an electric field of 376 V · mm<sup>-1</sup> , which is comparable to the ER of 3.0% of a commercial CZT planar detector.<sup>35</sup> 

21 

Because of the presence of polar organic molecules, a significant concern is the stability of the hybrid MHP devices under intense radiation and high electric field conditions. In the MAPbBr2.94Cl0.06 detector, good radiation hardness was observed with a total dose of 35 krad under 60Co irradiation;111 however, it exhibited degradation in the lower channel number range of the γ- ray spectrum. In **Figure 4d** , the MAPbI3 single crystal detector suffered from notable deterioration in the count rate within one hour.<sup>110</sup> This phenomenon is a sign of detector polarization possibly stemming from the electromigration of cations or vacancy defects.<sup>110</sup> In contrast, the all-inorganic CsPbBr3 semiconductor detector showed a stable count rate after continuous operation of over 120 h. This observation is an important advantage of the all-inorganic perovskites when compared to hybrid perovskites, particularly for applications requiring high electric fields and fast charge collection. 

In 3D halide perovskite semiconductors, holes have been experimentally proven to have better transport properties than electrons through time-of-flight techniques.<sup>18,39,110-113</sup> The μτh listed in **Table 1** is almost in the order of 10<sup>-2</sup> cm<sup>2</sup> · V<sup>-1</sup> , which is comparable to the μτe in current CZT detectors. In addition, the MHPs have impressively long (>10 μs) carrier lifetimes, possibly because of the aforementioned special lattice dynamics. An exceptionally long τh of approximately 0.3 ms was measured in CsPbBr3, which is most notable in this sense ( **Table 1)** . In comparison with holes, excessive electron trapping was identified when the detector operated in electroncollecting conditions,<sup>35</sup> with μτe being approximately half of μτh.<sup>113</sup> 

To overcome this issue, a unipolar detector configuration in the form of quasi-hemispherical and pixelated types have been used in CsPbBr3 detectors.<sup>35</sup> An excellent ER (~1.4%) and higher peakCompton ratio (~4) was demonstrated through depth correction with a crystal volume of 295 mm<sup>3</sup> ( **Figure 4e** ). The photopeak efficiency was substantially improved when compared to that of the 

22 

smaller planar detector. The current detector performance of CsPbBr3 detectors is comparable to that of commercial CZT devices and superior to that of conventional scintillation materials in terms of ER (as seen in **Figure 4f** ); however, the detector volume is still limited. 

Finally, in addition to Pb-based MHPs, other perovskite-relevant semiconductors based on other heavy metals (Hg and Tl) also demonstrated promising hard radiation detection performance in single-photon detection mode, such as defect antiperovskite Hg3Q2X2 (Q=S, Se, Te; X=Cl, Br, I)<sup>114</sup> and 2D antiperovskites TlSn2I5<sup>115</sup> . These Hg and Tl based semiconductors showed reasonable electron mobility reaching around 100 cm<sup>2</sup> · V<sup>-1</sup> · s<sup>-1</sup> , and demonstrated γ ray response distinguishable from the background. Particularly, Hg3Se2I2 demonstrated spectral response under alpha particles source.<sup>114</sup> 

**FIGURE 4** . **Halide perovskite semiconductors for X- and γ-ray spectroscopy in single-photon mode.** (a) Historic development timeline of “crystal counter” since the 1940s. (b) Ambipolar and unipolar detectors developed for MHP semiconductors. The devices shown at the bottom (left to right) are planar MAPbI3,<sup>110</sup> planar CsPbBr3,<sup>18</sup> and planar CsPbCl3;<sup>39</sup> planar MAPbBr2.94Cl0.06 with guard ring;<sup>111</sup> quasi-hemispherical CsPbBr3;<sup>35</sup> pixelated CsPbBr3<sup>35</sup> . The weighting potential _ϕ_ is illustrated for ambipolar (planar) and unipolar (quasi-hemispherical) devices.<sup>35</sup> (c)<sup>137</sup> Cs γ-ray spectrum obtained by MAPbBr2.94Cl0.06 detector.<sup>111</sup> Inset: energy spectrum from α-FAPbI3 detector under<sup>241</sup> Am 59.5 keV γ-ray source.<sup>23</sup> (d) Comparison between planar hybrid perovskite MAPbI3<sup>110</sup> and all-inorganic perovskite CsPbBr3<sup>18,35</sup> under<sup>57</sup> Co γ-ray source, CZT is shown as reference. Inset: Stability of MAPbI3<sup>110</sup> and CsPbBr3 planar detectors under constant irradiation.<sup>18</sup> (e) Comparison between the ambipolar (planar) and unipolar (pixelated) CsPbBr3 detector under 137Cs γ ray source.35 Inset: as-grow 1-inch diameter CsPbBr3 ingot grown from melt method.35 (f) Spectroscopic response under<sup>133</sup> Ba X- and γ-ray sources of typical scintillators and semiconductors.<sup>30,35</sup> 

23 

## **Perspective and outlook** 

In summary, MHP semiconductors are currently noticeable as the only materials that promise to reform the conventional X- and γ-ray detectors with lower cost and higher performance. Although these materials have emerged only since 2013, at which time MHPs had already exhibited superior photovoltaic performance exceeding 15%,<sup>116</sup> the ensuing advances in X- and  -ray detection have been rapid and impressive. Taking advantage of their simple chemical processing routes, such as solution or melt growth techniques, and the advanced semiconductor processing and characterization techniques available, there is considerable hope that the development and implementation of MHPs semiconductor detectors will be quicker, compared to their previous counterparts. Nevertheless, substantial research efforts are still required to better understand the properties of materials and device physics. 

As a plethora of MHPs have materialized with different dimensionalities, the structureperformance relationships discussed here can serve as a guide for the rational selection of new candidate materials. Depending on the two detection schemes for X- and γ-ray detection, the optimization of the material properties should fit specific application criteria. 

Currently, the detection limit of MHPs has been revealed to be as low as tens of nGyair/s, which is significantly lower than the 5500 nGyair/s in the _a_ -Se detector.<sup>29</sup> This is considerably promising when translated into applications. However, when coupled to a thin-film transistor flat panel, a lagging issue was observed, which was attributed to charge trapping in the thick perovskite film or charge-injection region through the electrodes.<sup>38</sup> Several structural defects in multiple scales,<sup>117</sup> including twin domains, misfit dislocations, impurities, point defects, grain boundaries, exist in MHPs; however, only a few studies have focused on their influence on the detector performance. Because this may be the key to achieving even higher performance, we address this issue to inspire 

24 

future efforts in defect engineering. <mark>Additional technical challenges, such as the optimization of the functional and self-sticking interfacial layer between the MHPs and</mark> thin-film transistor <mark>, must be developed for future devices.</mark> 

<mark>For projection radiography, it is preferable to follow the standard procedures for characterizing the detectors to obtain the m</mark> odulation transfer function and detector quantum efficiency <mark>. The detailed measurement procedures for such medical X-ray imagers are specified in the international standards specified by the International Electrotechnical Commission (IEC), such as IEC 62220-1 and IEC 61674:2012. These standards are essential to obtain a reliable detector characterization for commercial applications; however, strictly following these procedures might not be practical as a routine approach in research laboratories. Hence, a standard protocol for measuring and reporting X-ray detectors that is suitable for research laboratories is required.</mark> 

We also notice that the significantly high X-ray sensitivity in halide perovskites is mostly attributed to the poorly understood large photoconductive gain effects. The reported photoconductive gain factors range from several thousand to even higher values and this effect is only observed in the forward bias direction of asymmetric devices where the dark current is very high. It is worth mentioning that the photoconductive gain is different from the gain obtained in Si avalanche photodiodes or Si photomultipliers, where a sufficiently high electric field enables the migration of photogenerated carriers multiplied by creating secondary ionization. The origin of the photoconductive gain in halide perovskite is speculated to arise from the shallow level defects assisting charge injection at the interfaces.<sup>27</sup> Thus, it is important to determine if this defectassisted process influences the imaging quality or other metrics. 

In the single-photon mode, charge trapping also profoundly affects the pulse shape and amplitude, particularly in thick detectors. It was noted that significant electron carrier trapping occurred near 

25 

room temperature and possible hole carrier trapping at low temperature.<sup>35</sup> By applying unipolar charge collection, the electrode pattern used must be further optimized based on the crystal geometry and charge transport properties. Specific electrode patterning and digital signal readout techniques are also required to develop γ-ray cameras for applications such as nuclear medical imaging. Besides, the detector efficiency is barely studied now which is also important in SPECT and security applications. 

The device stability of the MHP detector under high dose radiation and high electric field must be clarified, which is particularly important for commercialization. The soft lattice and defect tolerance, suggest that MHPs may exhibit superior radiation hardness comparing to defectintolerant semiconductors.<sup>118</sup> However, spectrum degradation was observed in alloyed hybrid MHPs (MAPbBr3-xClx) after a high dose of radiation<sup>111</sup> . The possible radiation damage within the crystals or near the electrode interfaces must be investigated and understood. 

Although the impressive progress, the new MHP semiconductor detectors are still in the early stages of development as the aforementioned outstanding scientific and technical issues are being tackled by a growing number of researchers. Their success will ensure the positive impact of MHPs in reshaping the field of radiation detection at room temperature. 

## **Reference** 

- 1 Heiss, W. & Brabec, C. X-ray imaging: Perovskites target X-ray detection. _Nat. Photonics._ **10** , 288-289, (2016). 

- 2 Davros, W. Medical Imaging Principles, Detectors, and Electronics. _Med. phys._ **36** , 5374-5375, (2009). 

- 3 Wei, H. & Huang, J. Halide lead perovskites for ionizing radiation detection. _Nat. Commun._ **10** , 1066, (2019). 

- 4 Hoheisel, M. & Batz, L. Requirements on amorphous semiconductors for medical X-ray detectors. _Thin Solid Films_ **383** , 132-136, (2001). 

- 5 Huang, H. & Abbaszadeh, S. Recent Developments of Amorphous Selenium-Based X-Ray Detectors: A Review. _IEEE Sens. J._ **20** , 1694-1704, (2020). 

26 

- 6 Chen, Z., Zhu, Y. & He, Z. Intrinsic photopeak efficiency measurement and simulation for pixelated CdZnTe detector. _Nucl. Instr. Meth. Phys. Res. A_ **980** , 164501, (2020). 

- 7 Yamada, K., Kawaguchi, H., Matsui, T., Okuda, T. & Ichiba, S. Structural Phase Transition and Electrical Conductivity of the Perovskite CH3NH3Sn1-xPbxBr3 and CsSnBr3. _Bull. Chem. Soc. Jpn._ **63** , 2521-2525, (1990). 

- 8 Stoumpos, C. C., Malliakas, C. D. & Kanatzidis, M. G. Semiconducting Tin and Lead Iodide Perovskites with Organic Cations: Phase Transitions, High Mobilities, and Near-Infrared Photoluminescent Properties. _Inorg. Chem._ **52** , 9019-9038, (2013). 

- 9 Jena, A. K., Kulkarni, A. & Miyasaka, T. Halide Perovskite Photovoltaics: Background, Status, and Future Prospects. _Chem. Rev._ **119** , 3036-3103, (2019). 

- 10 Brenner, T. M., Egger, D. A., Kronik, L., Hodes, G. & Cahen, D. Hybrid organic—inorganic perovskites: low-cost semiconductors with intriguing charge-transport properties. _Nat. Rev. Mater._ **1** , 15007, (2016). 

- 11 Stoumpos, C. C. & Kanatzidis, M. G. Halide Perovskites: Poor Man's High-Performance Semiconductors. _Adv. Mater._ **28** , 5778-5793, (2016). 

- 12 Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal Halide Perovskites as VisibleLight Sensitizers for Photovoltaic Cells. _J. Am. Chem. Soc._ **131** , 6050-6051, (2009). 

- 13 Chung, I., Lee, B., He, J., Chang, R. P. H. & Kanatzidis, M. G. All-solid-state dye-sensitized solar cells with high efficiency. _Nature_ **485** , 486, (2012). 

- 14 Lee, M. M., Teuscher, J., Miyasaka, T., Murakami, T. N. & Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. _Science_ **338** , 643-647, (2012). 

- 15 Kim, H.-S. _et al._ Lead Iodide Perovskite Sensitized All-Solid-State Submicron Thin Film Mesoscopic Solar Cell with Efficiency Exceeding 9%. _Sci. Rep._ **2** , 591, (2012). 

- 16 Kovalenko, M. V., Protesescu, L. & Bodnarchuk, M. I. Properties and potential optoelectronic applications of lead halide perovskite nanocrystals. _Science_ **358** , 745-750, (2017). 

- 17 Stoumpos, C. C. _et al._ Crystal Growth of the Perovskite Semiconductor CsPbBr3: A New Material for High-Energy Radiation Detection. _Cryst. Growth Des._ **13** , 2722-2727, (2013). 

- 18 He, Y. _et al._ High spectral resolution of gamma-rays at room temperature by perovskite CsPbBr3 single crystals. _Nat. Commun._ **9** , 1609, (2018). 

- 19 Chen, Q. _et al._ All-inorganic perovskite nanocrystal scintillators. _Nature_ **561** , 88-93, (2018). 20 Knoll, G. F. _Radiation Detection and Measurement_ .  415 (John Wiley & Sons, Inc., 2010). 21 Schlesinger, T. E. _et al._ Cadmium zinc telluride and its use as a nuclear radiation detector material. _Mater. Sci. Eng. R Rep._ **32** , 103-189, (2001). 

- 22 Klein, C. A. Bandgap Dependence and Related Features of Radiation Ionization Energies in Semiconductors. _J. Appl. Phys._ **39** , 2029-2038, (1968). 

- 23 Yakunin, S. _et al._ Detection of gamma photons using solution-grown single crystals of hybrid lead halide perovskites. _Nat. Photonics_ **10** , 585-589, (2016). 

- 24 Kasap, S. O. X-ray sensitivity of photoconductors: application to stabilized a-Se. _J. Phys. D: Appl. Phys._ **33** , 2853-2865, (2000). 

- 25 Kabir, M. Z. & Kasap, S. O. Sensitivity of x-ray photoconductors: Charge trapping and absorption-limited universal sensitivity curves. _J. Vac. Sci. Technol. A_ **20** , 1082-1086, (2002). 

- 26 Hubbell, J. H. Photon mass attenuation and energy-absorption coefficients. _Int. J. Appl. Radiat. Isot._ **33** , 1269-1290, (1982). 

- 27 Wei, W. _et al._ Monolithic integration of hybrid perovskite single crystals with heterogenous substrate for highly sensitive X-ray imaging. _Nat. Photonics_ **11** , 315, (2017). 

- 28 Pan, W. _et al._ Hot-Pressed CsPbBr3 Quasi-Monocrystalline Film for Sensitive Direct X-ray Detection. _Adv. Mater._ **31** , 1904405, (2019). 

- 29 Wu, H., Ge, Y., Niu, G. & Tang, J. Metal Halide Perovskites for X-Ray Detection and Imaging. _Matter_ **4** , 144-163, (2021). 

27 

- 30 Johns, P. M. & Nino, J. C. Room temperature semiconductor detectors for nuclear security. _J. Appl. Phys._ **126** , 040902, (2019). 

- 31 Shockley, W. Currents to Conductors Induced by a Moving Point Charge. _J. Appl. Phys._ **9** , 635636, (1938). 

- 32 Ramo, S. Currents Induced by Electron Motion. _Proc. IRE_ **27** , 584-585, (1939). 

- 33 Zhong, H. Review of the Shockley–Ramo theorem and its application in semiconductor gammaray detectors. _Nucl. Instr. Meth. Phys. Res. A_ **463** , 250-267, (2001). 

- 34 Liu, Z. _et al._ Noise sources and their limitations on the performance of compound semiconductor hard radiation detectors. _Nucl. Instr. Meth. Phys. Res. A_ **916** , 133-140, (2019). 

- 35 He, Y. _et al._ CsPbBr3 perovskite detectors with 1.4% energy resolution for high-energy γ-rays. _Nat. Photonics_ **15** , 36-42, (2021). 

- 36 Miyata, A. _et al._ Direct measurement of the exciton binding energy and effective masses for charge carriers in organic–inorganic tri-halide perovskites. _Nat. Phys._ **11** , 582-587, (2015). 

- 37 Kasap, S. O. _et al._ Progress in the science and technology of direct conversion a-Se X-ray sensors. _J. Non-Cryst. Solids_ **299-302** , 988-992, (2002). 

- 38 Kim, Y. C. _et al._ Printable organometallic perovskite enables large-area, low-dose X-ray imaging. _Nature_ **550** , 87, (2017). 

- 39 He, Y. _et al._ Demonstration of Energy-Resolved γ-Ray Detection at Room Temperature by the CsPbCl3 Perovskite Semiconductor. _J. Am. Chem. Soc._ **143** , 2068–2077, (2021). 

- 40 Cherry, S. R., Sorenson, J. & Phelps, M. _Physics in Nuclear Medicine_ .  (Elsevier Inc., 2012). 

- 41 Cates, J. & Levin, C. Realizing PET systems with 100 ps FWHM coincidence timing resolution (Conference Presentation). _Proceedings of SPIE_ **9969** , 99690H-99690H-99691, (2016). 

- 42 Ito, T. _et al._ Experimental evaluation of the GE NM/CT 870 CZT clinical SPECT system equipped with WEHR and MEHRS collimator. _J Appl Clin Med Phys_ **22** , 165-177, (2021). 

- 43 <u>https://www.gehealthcare.com/products/molecular-imaging/nuclear-medicine/nm-ct-870-czt.</u> 44 Willemink, M. J., Persson, M., Pourmorteza, A., Pelc, N. J. & Fleischmann, D. Photon-counting CT: Technical Principles and Clinical Prospects. _Radiology_ **289** , 293-312, (2018). 

- 45 Fabini, D. H., Seshadri, R. & Kanatzidis, M. G. The underappreciated lone pair in halide perovskites underpins their unusual properties. _MRS Bull._ **45** , 467-477, (2020). 

- 46 Yaffe, O. _et al._ Local Polar Fluctuations in Lead Halide Perovskite Crystals. _Phys. Rev. Lett._ **118** , 136001, (2017). 

- 47 Srimath Kandada, A. R. & Silva, C. Exciton Polarons in Two-Dimensional Hybrid Metal-Halide Perovskites. _J. Phys. Chem. Lett._ **11** , 3173-3184, (2020). 

- 48 Miyata, K. & Zhu, X. Y. Ferroelectric large polarons. _Nat. Mater._ **17** , 379-381, (2018). 

- 49 Meggiolaro, D., Ambrosio, F., Mosconi, E., Mahata, A. & De Angelis, F. Polarons in Metal Halide Perovskites. _Adv. Energy Mater._ **10** , 1902748, (2020). 

- 50 Gao, P., Bin Mohd Yusoff, A. R. & Nazeeruddin, M. K. Dimensionality engineering of hybrid halide perovskite light absorbers. _Nat. Commun._ **9** , 5028, (2018). 

- 51 Cao, D. H., Stoumpos, C. C., Farha, O. K., Hupp, J. T. & Kanatzidis, M. G. 2D Homologous Perovskites as Light-Absorbing Materials for Solar Cell Applications. _J. Am. Chem. Soc._ **137** , 7843-7850, (2015). 

- 52 Yin, J. _et al._ Molecular behavior of zero-dimensional perovskites. _Sci. Adv._ **3** , (2017). 53 McCall, K. M., Stoumpos, C. C., Kostina, S. S., Kanatzidis, M. G. & Wessels, B. W. Strong Electron–Phonon Coupling and Self-Trapped Excitons in the Defect Halide Perovskites A3M2I9 (A = Cs, Rb; M = Bi, Sb). _Chem. Mater._ **29** , 4129-4145, (2017). 

- 54 Zentai, G. in _2011 IEEE International Conference on Imaging Systems and Techniques._ 194-200. 55 Belev, G., Kasap, S., Rowlands, J. A., Hunter, D. & Yaffe, M. Dependence of the electrical properties of stabilized a-Se on the preparation conditions and the development of a double layer X-ray detector structure. _Curr. Appl Phys._ **8** , 383-387, (2008). 

- 56 Kasap, S. _et al._ Amorphous and Polycrystalline Photoconductors for Direct Conversion Flat Panel X-Ray Image Sensors. _Sensors_ **11** , 5112, (2011). 

28 

- 57 Kasap, S. _et al._ Amorphous selenium and its alloys from early xeroradiography to high resolution X-ray image detectors and ultrasensitive imaging tubes. _Phys. Status Solidi B_ **246** , 1794-1805, (2009). 

- 58 Pan, W. _et al._ Cs2AgBiBr6 single-crystal X-ray detectors with a low detection limit. _Nat. Photonics_ **11** , 726-732, (2017). 

- 59 Yin, L. _et al._ Controlled Cooling for Synthesis of Cs2AgBiBr6 Single Crystals and Its Application for X-Ray Detection. _Adv. Opt. Mater._ **7** , 1900491, (2019). 

- 60 Yang, B. _et al._ Heteroepitaxial passivation of Cs2AgBiBr6 wafers with suppressed ionic migration for X-ray imaging. _Nat. Commun._ **10** , 1989, (2019). 

- 61 Keshavarz, M. _et al._ Tuning the Structural and Optoelectronic Properties of Cs2AgBiBr6 DoublePerovskite Single Crystals through Alkali-Metal Substitution. _Adv. Mater._ **32** , 2001878, (2020). 

- 62 Dong, Q. _et al._ Electron-hole diffusion lengths 175 μm in solution-grown CH3NH3PbI3 single crystals. _Science_ **347** , 967-970, (2015). 

- 63 Wei, H. _et al._ Sensitive X-ray detectors made of methylammonium lead tribromide perovskite single crystals. _Nat. Photonics_ **10** , 333-339, (2016). 

- 64 Yakunin, S. _et al._ Detection of X-ray photons by solution-processed lead halide perovskites. _Nat Photonics_ **9** , 444-449, (2015). 

- 65 Wang, X. _et al._ PIN Diodes Array Made of Perovskite Single Crystal for X-Ray Imaging. _Phys. Status Solidi RRL_ **12** , 1800380, (2018). 

- 66 Song, J. _et al._ Facile Strategy for Facet Competition Management to Improve the Performance of Perovskite Single-Crystal X-ray Detectors. _J. Phys. Chem. Lett._ **11** , 3529-3535, (2020). 

- 67 Tian, S. _et al._ Co-axial silicon/perovskite heterojunction arrays for high-performance directconversion pixelated X-ray detectors. _Nano Energy_ **78** , 105335, (2020). 

- 68 Wang, X. _et al._ Ultrafast Ionizing Radiation Detection by p–n Junctions Made with Single Crystals of Solution-Processed Perovskite. _Advanced Electronic Materials_ **4** , 1800237, (2018). 

- 69 Li, L. _et al._ Enhanced X-ray Sensitivity of MAPbBr3 Detector by Tailoring the Interface-States Density. _ACS Appl. Mater. Interfaces_ **11** , 7522-7528, (2019). 

- 70 Liu, X. _et al._ Charge Transport Behavior in Solution-Grown Methylammonium Lead Tribromide Perovskite Single Crystal Using α Particles. _J. Phys. Chem. C_ **122** , 14355-14361, (2018). 

- 71 Ye, F. _et al._ High-Quality Cuboid CH3NH3PbI3 Single Crystals for High Performance X-Ray and Photon Detectors. _Adv. Funct. Mater._ **29** , 1806984, (2019). 

- 72 Shrestha, S. _et al._ High-performance direct conversion X-ray detectors based on sintered hybrid lead triiodide perovskite wafers. _Nat. Photonics_ **11** , 436-440, (2017). 

- 73 Li, J. _et al._ Rubidium Doping to Enhance Carrier Transport in CsPbBr3 Single Crystals for HighPerformance X-Ray Detection. _ACS Appl. Mater. Interfaces_ **12** , 989-996, (2020). 

- 74 Matt, G. J. _et al._ Sensitive Direct Converting X-Ray Detectors Utilizing Crystalline CsPbBr3 Perovskite Films Fabricated via Scalable Melt Processing. _Adv. Mater. Inter._ **7** , 1901575, (2020). 

- 75 Peng, J. _et al._ Crystallization of CsPbBr3 single crystals in water for X-ray detection. _Nat. Commun._ **12** , 1531, (2021). 

- 76 Huang, Y. _et al._ A-site Cation Engineering for Highly Efficient MAPbI3 Single-Crystal X-ray Detector. _Angew. Chem. Int. Ed._ **58** , 17834-17842, (2019). 

- 77 Li, X. _et al._ Three-Dimensional Lead Iodide Perovskitoid Hybrids with High X-ray Photoresponse. _J. Am. Chem. Soc._ **142** , 6625-6637, (2020). 

- 78 Zhuang, R. _et al._ Highly sensitive X-ray detector made of layered perovskite-like (NH4)3Bi2I9 single crystal with anisotropic response. _Nat. Photonics_ **13** , 602-608, (2019). 

- 79 Xia, M. _et al._ Unveiling the Structural Descriptor of A3B2X9 Perovskite Derivatives toward X- Ray Detectors with Low Detection Limit and High Stability. _Adv. Funct. Mater._ **30** , 1910648, (2020). 

- 80 Li, H. _et al._ Sensitive and Stable 2D Perovskite Single-Crystal X-ray Detectors Enabled by a Supramolecular Anchor. _Adv. Mater._ **32** , 2003790, (2020). 

29 

- 81 Tsai, H. _et al._ A sensitive and robust thin-film x-ray detector using 2D layered perovskite diodes. _Sci Adv._ **6** , eaay0815, (2020). 

- 82 Lin, Y. _et al._ Unveiling the operation mechanism of layered perovskite solar cells. _Nat. Commun._ **10** , 1008, (2019). 

- 83 Ji, C. _et al._ 2D Hybrid Perovskite Ferroelectric Enables Highly Sensitive X-Ray Detection with Low Driving Voltage. _Adv. Funct. Mater._ **30** , 1905529, (2020). 

- 84 Shen, Y. _et al._ Centimeter-Sized Single Crystal of Two-Dimensional Halide Perovskites Incorporating Straight-Chain Symmetric Diammonium Ion for X-Ray Detection. _Angew. Chem. Int. Ed._ **59** , 14896-14902, (2020). 

- 85 Xu, Z. _et al._ Exploring Lead-Free Hybrid Double Perovskite Crystals of (BA)2CsAgBiBr7 with Large Mobility-Lifetime Product toward X-Ray Detection. _Angew. Chem. Int. Ed._ **58** , 1575715761, (2019). 

- 86 Li, X. _et al._ Lead-free halide perovskite Cs3Bi2Br9 single crystals for high-performance X-ray detection. _Sci. China Mater._ , (2021). 

- 87 Zhang, B.-B. _et al._ High-Performance X-ray Detection Based on One-Dimensional Inorganic Halide Perovskite CsPbI3. _J. Phys. Chem. Lett._ **11** , 432-437, (2020). 

- 88 Yao, L. _et al._ Bismuth halide perovskite derivatives for direct X-ray detection. _J. Mater. Chem. C_ **8** , 1239-1243, (2020). 

- 89 Xu, Y. _et al._ Zero-Dimensional Cs2TeI6 Perovskite: Solution-Processed Thick Films with High X-ray Sensitivity. _ACS Photonics_ **6** , 196-203, (2019). 

- 90 Xiao, B. _et al._ Melt-grown large-sized Cs2TeI6 crystals for X-ray detection. _Crystengcomm_ **22** , 5130-5136, (2020). 

- 91 Zhang, Y. _et al._ Nucleation-controlled growth of superior lead-free perovskite Cs3Bi2I9 singlecrystals for high-performance X-ray detection. _Nat. Commun._ **11** , 2304, (2020). 

- 92 Sun, Q. _et al._ Optical and electronic anisotropies in perovskitoid crystals of Cs3Bi2I9 studies of nuclear radiation detection. _J. Mater. Chem. A_ **6** , 23388-23395, (2018). 

- 93 Liu, Y. _et al._ Inch-Size 0D-Structured Lead-Free Perovskite Single Crystals for Highly Sensitive Stable X-Ray Imaging. _Matter_ **3** , 180-196, (2020). 

- 94 Zheng, X. _et al._ Ultrasensitive and stable X-ray detection using zero-dimensional lead-free perovskites. _J. Energy Chem._ **49** , 299-306, (2020). 

- 95 Schieber, M. _et al._ Thick films of X-ray polycrystalline mercuric iodide detectors. _J. Cryst. Growth_ **225** , 118-123, (2001). 

- 96 Stranks, S. D. & Snaith, H. J. Metal-halide perovskites for photovoltaic and light-emitting devices. _Nat. Nanotechnol._ **10** , 391-402, (2015). 

- 97 Saidaminov, M. I. _et al._ High-quality bulk hybrid perovskite single crystals within minutes by inverse temperature crystallization. _Nat. Commun._ **6** , 7586, (2015). 

- 98 Liu, Y. _et al._ Triple-Cation and Mixed-Halide Perovskite Single Crystal for High-Performance X- ray Imaging. _Adv. Mater._ **33** , 2006010, (2021). 

- 99 Liu, Y. _et al._ Multi-inch single-crystalline perovskite membrane for high-detectivity flexible photosensors. _Nat. Commun._ **9** , 5302, (2018). 

- 100 Zhao, J. _et al._ Perovskite-filled membranes for flexible and large-area direct-conversion X-ray detector arrays. _Nat. Photonics_ **14** , 612-617, (2020). 

- 101 Hofstadter, R. Thallium Halide Crystal Counter. _Phy. Rev._ **72** , 1120-1121, (1947). 

- 102 Hofstadter, R. Alkali Halide Scintillation Counters. _Phy. Rev._ **74** , 100-101, (1948). 103 Owens, A. Semiconductor materials and radiation detection. _J. Synchrotron Rad._ **13** , 143-150, (2006). 

- 104 Li, J. _et al._ Cs2PbI2Cl2, All-Inorganic Two-Dimensional Ruddlesden–Popper Mixed Halide Perovskite with Optoelectronic Response. _J. Am. Chem. Soc._ **140** , 11085-11090, (2018). 

- 105 McCall, K. M. _et al._ α-Particle Detection and Charge Transport Characteristics in the A3M2I9 Defect Perovskites (A = Cs, Rb; M = Bi, Sb). _ACS Photonics_ **5** , 3748-3762, (2018). 

30 

- 106 Dirin, D. N., Cherniukh, I., Yakunin, S., Shynkarenko, Y. & Kovalenko, M. V. Solution-Grown CsPbBr3 Perovskite Single Crystals for Photon Detection. _Chem. Mater._ **28** , 8470-8474, (2016). 

- 107 Tan, R. _et al._ Improved Radiation Sensing with Methylammonium Lead Tribromide Perovskite Semiconductors. _Nucl. Instr. Meth. Phys. Res. A_ **986** , 164710, (2021). 

- 108 Xu, Q. _et al._ Detection of charged particles with a methylammonium lead tribromide perovskite single crystal. _Nucl. Instr. Meth. Phys. Res. A_ **848** , 106-108, (2017). 

- 109 Joglekar, S. G., Hammig, M. D. & Guo, L. J. High-Energy Photon Spectroscopy Using All Solution-Processed Heterojunctioned Surface-Modified Perovskite Single Crystals. _ACS Appl. Mater. Interfaces_ **11** , 33399-33408, (2019). 

- 110 He, Y. _et al._ Resolving the Energy of γ-Ray Photons with MAPbI3 Single Crystals. _ACS Photonics_ **5** , 4132-4138, (2018). 

- 111 Wei, H. _et al._ Dopant compensation in alloyed CH3NH3PbBr3-xClx perovskite single crystals for gamma-ray spectroscopy. _Nat. Mater._ **16** , 826-833, (2017). 

- 112 Liu, X. _et al._ Solution-Grown Formamidinium Hybrid Perovskite (FAPbBr3) Single Crystals for α-Particle and γ-Ray Detection at Room Temperature. _ACS Appl. Mater. Interfaces_ (2021). 

- 113 He, Y. _et al._ Perovskite CsPbBr3 single crystal detector for alpha-particle spectroscopy. _Nucl. Instr. Meth. Phys. Res. A_ **922** , 217-221, (2019). 

- 114 He, Y. _et al._ Defect Antiperovskite Compounds Hg3Q2I2 (Q = S, Se, and Te) for RoomTemperature Hard Radiation Detection. _J. Am. Chem. Soc._ , (2017). 

- 115 Lin, W. _et al._ TlSn2I5, a Robust Halide Antiperovskite Semiconductor for γ-Ray Detection at Room Temperature. _ACS Photonics_ **4** , 1805-1813, (2017). 

- 116 Liu, M., Johnston, M. B. & Snaith, H. J. Efficient planar heterojunction perovskite solar cells by vapour deposition. _Nature_ **501** , 395-398, (2013). 

- 117 Tennyson, E. M., Doherty, T. A. S. & Stranks, S. D. Heterogeneity at multiple length scales in halide perovskite semiconductors. _Nat. Rev. Mater._ **4** , 573-587, (2019). 

- 118 Boldyreva, A. G. _et al._ Unravelling the Material Composition Effects on the Gamma Ray Stability of Lead Halide Perovskite Solar Cells: MAPbI3 Breaks the Records. _J. Phys. Chem. Lett._ **11** , 2630-2636, (2020). 

- 119 Pan, L., Feng, Y., Kandlakunta, P., Huang, J. & Cao, L. R. Performance of Perovskite CsPbBr3 Single Crystal Detector for Gamma-Ray Detection. _IEEE Trans. Nucl. Sci._ **67** , 443-449, (2020). 

- 120 Capper, P. _Properties of Narrow Gap Cadmium-based Compounds_ .  (1994). 

- 121 Triboulet, R. & Siffert, P. _CdTe and Related Compounds; Physics, Defects, Hetero- and Nanostructures, Crystal Growth, Surfaces and Applications_ .  550 (ELSEVIER, 2009). 

- 122 Ishii, M. & Kobayashi, M. Single crystals for radiation detectors. _Prog. Cryst. Growth Charact. Mater._ **23** , 245-311, (1992). 

## **Competing Interest** 

YH and MGK disclose financial interest in Actinia Inc. 

#### **Acknowledgments** 

Y.H. acknowledges support from the Research Fund from the Soochow University (NH12800621) and State Key Laboratory of Radiation Medicine and Protection (MZ12800121). MGK acknowledges support from the Defense 

31 

Threat Reduction Agency (DTRA) as part of the Interaction of Ionizing Radiation with Matter University Research Alliance (IIRM-URA) under contract number HDTRA1-20-2-0002. 

32 

Table 1. Best performing − ray detection results till date from different metal halide perovskite semiconductors grown using solution and melt methods. The energies in the for<sup>241</sup> Am,<sup>122</sup> Co,<sup>137</sup> Cs are 59.5, 122 and 662 keV, respectively. 

|**Compounds**|**_dimensi_**<br>**_ality_**|**_on_**<br>**_E_g (eV)**|**_Z_eff**|**ρ(Ω·cm)**|γ-**ray**<br>**source**|**ER (%)**|**Device**<br>**thickness**<br>**(mm)**|**μτh (cm**<sup>**2**</sup>**·V**<sup>**-1**</sup>**)**<br>**μτe (cm**<sup>**2**</sup>**·V**<sup>**-1**</sup>**)**|**μh (cm**<sup>**2**</sup>**·V**<sup>**-1**</sup>**·s**<sup>**-1**</sup>**)**<br>**μe (cm**<sup>**2**</sup>**·V**<sup>**-1**</sup>**·s**<sup>**-1**</sup>**)**|**τh (μs)**<br>**τe (μs)**|**Year**<br>**(reference)**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Solution grown||||||||||||
|FAPbI3|3D|1.43|66.5|N/A|241Am|35%|3|1.8×10<sup>-2</sup>|N/A|N/A|2016<sup>23</sup>|
|FAPbBr3|3D|2.21|66.7|2.8×10<sup>9</sup>|241Am|40.1%|1.08|h: 1.1×10<sup>-3</sup><br>e: 8.0×10<sup>-4</sup>|66.1<br>22.2|16<br>36|2021<sup>112</sup>|
|MAPbBr2.94Cl0.06|3D|~2.2|67.2|3.6×10<sup>9</sup>|137Cs|6.5%|~5|1.8×10<sup>-2*</sup>|h: 560<br>e: 340|N/A|2017<sup>111</sup>|
|MAPbI3|3D|1.54|66.8|~10<sup>8</sup>-10<sup>9</sup>|241Am<br>57Co|12%<br>6.8%|1.52|h: 8.1×10<sup>-4</sup><br>e: 7.4×10<sup>-4</sup>|48<br>70|17<br>10|2018<sup>110</sup>|
|CsPbBr3|3D|2.29|65.9|N/A|137Cs<br>57Co<br>241Am|5.5%<br>13.1%<br>28.3%|2.53|h: 4.0×10<sup>-4</sup>|22|18|2020<sup>119</sup>|
|Melt grown||||||||||||
|CsPbBr3|3D|2.29|65.9|~10<sup>9</sup>|137Cs<br>57Co<br>241Am|1.4%<br>3.2%<br>5.5%|1.33, 3.03,<br>4.64|h: 1-8.0×10<sup>-3</sup><br>e: 4.5-8.8×10<sup>-4</sup>|24-52<br>63|33-296<br>7-14|2021<sup>35</sup><br>2019<sup>113</sup>|
|CsPbCl3|3D|3.03|69.8|1.7×10<sup>9</sup>|57Co|16%|1.77|h: 3.2×10<sup>-4</sup><br>e: N/A|20<br>28|16<br>N/A|2021<sup>39</sup>|
|Cd1-xZnxTe (x≈0.1)|3D|1.57|50|~10<sup>10</sup>|137Cs|0.5%|10-15|h: ~10<sup>-4</sup><br>e: ~10<sup>-2</sup>|~100<br>~1000|~1<br>~10|6,103,120,121|



The _Z_ eff was calculated according to reference<sup>122</sup> . 'N/A' represents that the information is not mentioned. *The μτ are estimated based on the photocurrent measurement. The τ was calculated according to μτ/μ directly. 

33 

