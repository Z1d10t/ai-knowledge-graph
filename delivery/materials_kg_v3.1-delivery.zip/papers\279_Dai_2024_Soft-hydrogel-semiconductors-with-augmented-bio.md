# Soft hydrogel semiconductors with augmented bio-interactive functions

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 173 |
| 作者 | Ya-Hao Dai, Shinya Wai, Peng-Ju Li, Naisong Shan, Zhi-Qiang Cao, Yang Li, Yun-Fei Wang, You-Di Liu et al. |
| DOI | 10.1126/science.adp9314 |
| 源文件 | 063_Dai_2024_Soft-hydrogel-semiconductors-with-augmented-bio.pdf |

---
RESEARCH 



are only soluble in organic solvents. Although certain physical processing (22, 23) and chemical modification (24, 25) approaches have been used to enable aqueous processability, they typically either sacrifice the electrical performance or limit the accessibility of different electronic structures for diverse optoelectronic functions. As a result, the reported hydrogel semiconductors exhibited charge-carrier mobility no higher than 0.25 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , with the functionality primarily limited to transistors (25). 



### HYDROGELS 

# Soft hydrogel semiconductors with augmented biointeractive functions 

Yahao Dai<sup>1</sup> , Shinya Wai<sup>1</sup> , Pengju Li<sup>1</sup> , Naisong Shan<sup>1</sup> , Zhiqiang Cao<sup>2</sup> , Yang Li<sup>1</sup> , Yunfei Wang<sup>2,3</sup> , Youdi Liu<sup>1</sup> , Wei Liu<sup>1</sup> , Kan Tang<sup>2</sup> , Yuzi Liu<sup>4</sup> , Muchuan Hua<sup>4</sup> , Songsong Li<sup>1</sup> , Nan Li<sup>1</sup> , Shivani Chatterji<sup>1</sup> , H. Christopher Fry<sup>4</sup> , Sean Lee<sup>5</sup> , Cheng Zhang<sup>1</sup> , Max Weires<sup>1</sup> , Sean Sutyak<sup>1</sup> , Jiuyun Shi<sup>5</sup> , Chenhui Zhu<sup>3</sup> , Jie Xu<sup>1,4</sup> , Xiaodan Gu<sup>2</sup> , Bozhi Tian<sup>5</sup> , Sihong Wang<sup>1,6,7</sup> * 

Hydrogels, known for their mechanical and chemical similarity to biological tissues, are widely used in biotechnologies, whereas semiconductors provide advanced electronic and optoelectronic functionalities such as signal amplification, sensing, and photomodulation. Combining semiconducting properties with hydrogel designs can enhance biointeractive functions and intimacy at biointerfaces, but this is challenging owing to the low hydrophilicity of polymer semiconductors. We developed a solvent affinity–induced assembly method that incorporates water-insoluble polymer semiconductors into double-network hydrogels. These semiconductors exhibited tissue-level moduli as soft as 81 kilopascals, stretchability of 150% strain, and charge-carrier mobility up to 1.4 square centimeters per volt per second. When they are interfaced with biological tissues, their tissue-level modulus enables alleviated immune reactions. The hydrogel’s high porosity enhances molecular interactions at semiconductor-biofluid interfaces, resulting in <mark>p</mark> hotomodulation with hi <mark>g</mark> her res <mark>p</mark> onse and volumetric biosensin <mark>g</mark> with hi <mark>g</mark> her sensitivit <mark>y</mark> . 

We realized hydrogel semiconductors (hydroSCs) by devising a processing method that decouples 3D network formation and water swelling into separate steps (Fig. 1B), which allows the processing of common types of polymer semiconductors to form gels in organic solvents. This processing method produces a morphology with a well-percolated network of polymer semiconductors embedded in a porous hydrogel framework. 

### Design and preparation method for hydro-SCs 

ydrogels, featuring water-swollen threedimensional(3D)polymernetworks, have asoft,elastic, and water-abundant nature that emulates the mechanical and chemH ical environment of biological tissues (hereafter, biotissues), making them one of the optimal types of materials for interfacing with biotissues (1, 2). With their great chemical tunability and controllable porous framework, hydrogels serve as a versatile platform for supporting, treating, and communicating with biotissues, enabling a broad range of biointerfaced applications including cell culture (3), tissue engineering (4), drug delivery (5), wound dressing (6), biostimulation (7), and biomonitoring (8). 

electronic functions need to be embodied in hydrogel designs. Conductive hydrogels have been reported, and these are based on the design strategies of either swelled networks of conductive polymer (15) [mostly poly(3,4ethylenedioxythiophene) polystyrene sulfonate, or PEDOT:PSS (11, 16, 17)] or hydrogel composites with conductive fillers such as metallic nanofillers (18) or 2D materials (19). However, the bioelectronic functions of such conductive hydrogels are limited to electrode-based stimulation and passive sensing with moderate sensitivity. In contrast, semiconductors, which feature electronic band structures with bandgaps, can enable much richer electronic and optoelectronic functions, including chargetransport modulation, amplification, photoexcitation, photo- and electroluminescence, and photocatalysis (Fig. 1A). Therefore, imparting hydrogels with semiconducting properties is a highly desirable but unmet need for enabling seamless biointerfaces to access a much broader range of advanced functions in sensing, stimulation, and imaging. 

The design of a hydro-SC with an interpenetrated network morphology comprises two main components: a polymer semiconductor with hydrophilic side chains, and a hydrogelforming polymer (Fig. 1B). Our method to generate a hydro-SC (Fig. 1B) starts with the preparation of a mixed solution of a polymer semiconductor and a hydrogel monomer in dimethyl sulfoxide (DMSO), together with the hydrogel cross-linker and photoinitiator. After spin coating or casting the mixed solution into the desired form factor, ultraviolet (UV) crosslinking is carried out to form the 3D network of the hydrogel polymer, thereby inducing gelation in DMSO. Finally, the gel is immersed in water to fully exchange DMSO with water, which turns the DMSO organogel into a hydrogel. During this process, as the polymer semiconductor is not soluble in water, we hypothesize that the semiconductor polymer will rapidly precipitate out and assemble into a percolated network inside the porous 3D hydrogel framework (Fig. 1B). 

An emerging technology is bioelectronics (9–11), which leverages the sophisticated and diverse functions of electronics to probe and program biology with high accuracy and resolution. The development of bioelectronics centers around the realization of seamless, dynamic, and lasting interfaces between tissue and electronics, for which hydrogels are an alternative to conventional electronic materials (e.g., conductors, semiconductors) for forming conformable tissue attachment (12), suppressing immune reactions (13), and facilitating mass transport (14). To fully exploit these capabilities of hydrogels, electronic and opto- 

To realize semiconducting hydrogels with high electronic performance, polymer semiconductors (20, 21) are arguably the most feasible choices for forming percolated 3D networks to achieve efficient charge transport. However, the main challenge comes from the incompatibility of the existing polymer semiconductors with the hydrogel preparation methods. Typically, hydrogels, including conductive hydrogels, are formed through chemically or physically crosslinking hydrogel precursors (i.e., either monomers or polymers) in water and remain in a highly water-swelled state. Such a process requires the aqueous processability of hydrogel precursors. However, for polymer semiconductors, the vast majority of existing designs 

To implement this strategy, we chose poly (3,3′-bis{2-[2-(2-methoxyethoxy)ethoxy]ethoxy} 2,2′:5′,2′′-terthiophene), or p(g2T-T), as the polymer semiconductor (fig. S1) and acrylic acid (AAc) as the hydrogel-forming monomer for its high reactivity in DMSO (Fig. 1C). With initial concentrations of 20 and 200 mg/ml for p(g2T-T) and AAc, respectively, we successfully prepared hydro-SCs (figs. S2 to S5) that are very soft with Young’s modulus as low as 81.8 kPa, exhibiting conformability on skin (Fig. 1D). When functioning as the channel layer in organic electrochemical transistors (OECTs) (Fig. 1E), the percolation of the semiconducting phase gives ideal OECT performance. Compared with soft and stretchable 

1Pritzker School of Molecular Engineering, University of Chicago, Chicago, IL 60637, USA.<sup>2</sup> School of Polymer Science and Engineering, Center for Optoelectronic Materials and Devices, University of Southern Mississippi, Hattiesburg, MS 39406, USA. 3Advanced Light Source, Lawrence Berkeley National Laboratory, Berkeley, CA 94720, USA.<sup>4</sup> Center for Nanoscale Materials, Argonne National Laboratory, Lemont, IL 60439, USA.<sup>5</sup> Department of Chemistry, University of Chicago, Chicago, IL 60637, USA. 6Nanoscience and Technology Division and Center for Molecular Engineering, Argonne National Laboratory, Lemont, IL 60439, USA. 7CZ Biohub Chicago, LLC, Chicago, IL 60642, USA. *Corresponding author. Email: sihongwang@uchicago.edu 

1 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A<br>B C<br>D E F<br>Polymer semiconductor/elastomer<br>composite<br>Hydrogel semiconductor<br>(This work) So  & stretchable<br>polymer semiconductor<br>Young’s modulus<br>Brain Heart Intes ne Skin Car lage Nerve Tendon<br><!-- End of picture text -->

used: PAAc and p(g2T-T), respectively. (D) Photograph showing a prepared hydro-SC conforming on the skin. (E) Hydro-SC film serving as the channel layer in an OECT, giving normal transfer behavior (Vds = −0.8 V). The blue and gray curves refer to Id and Ig, respectively. (F) Comparisons of Young’s modulus and charge-carrier mobility from the hydro-SCs (dark red) with other reported soft and stretchable semiconductors (with the reference information shown in fig. S6 and table S1). 

Fig. 1. Hydro-SC for biointerfaced multimodal applications. (A) Design of a hydro-SC based on an interpenetrated double network of a polymer semiconductor and a hydrogel-forming polymer. CB, conduction band; VB, valence band; hn, photon; Ox, oxidant; Red, reductant. (B) Preparation method of the hydro-SC, which decouples the gelation step and water swelling step through the solvent exchange. (C) Chemical structures of the hydrogel-forming polymer and polymer semiconductor 

polymer semiconductor p(g2T-T) during the gelation and solvent exchange steps. To trace the morphological evolution, we characterized three stages during the preparation process: the initial DMSO-based solution as stage 1, the UV cross-linked gel in DMSO as stage 2, and the final hydro-SC after the solvent exchange as stage 3 (Fig. 2A). The hydro-SC was prepared with a weight ratio of 10/100 between p(g2T-T) and AAc, and the added cross-linker of 0.2 wt % to the AAc monomer. For stage 1, cryo–electron microscopy (cryo-EM) imaging of the rapidly frozen DMSO-based solution shows that p(g2T-T) already formed high- 

density nano-aggregates (Fig. 2B, stage 1), likely because of the limited solvation effect of DMSO only on the polar side chains and not the hydrophobic backbones of p(g2T-T) (26) (fig. S9). These preformed nanoaggregates could help to seed the further assembly of p(g2T-T) into larger networks. For stage 2, scanning electron microscopy (SEM) and scanning transmission electron microscopy (STEM) imaging on a DMSO gel reveals that p(g2T-T) particles mostly maintain their size (Fig. 2B, stage 2, and fig. S10). Finally, water solvent exchange induces the assembly of p(g2T-T) into an interconnected network that is interpenetrated 

polymer semiconductors, this hydro-SC realizes a modulus decrease of more than two to three orders of magnitude while keeping the mobility (m) at a similar level (Fig. 1F, fig. S6, and table S1). Moreover, such a strategy can be applied to a number of polymer semiconductors with polar side chains (fig. S7) and can enable direct photopatterning for highdensity device fabrication (fig. S8). 

Characterization of the morphological evolution during hydro-SC preparation 

The key part of the design and preparation of the hydro-SC is the assembly process of the 

2 of 9 

Dai et al., Science 386, 431–439 (2024) 

25 October 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A<br>B<br>aggregates<br>clusters<br>fibers<br>solu on aggregates<br>C D<br>in DMSO/Ch + Cl - in DMSO/Ch + Cl - in H O/Ch + Cl -<br>E F G<br>In-plane<br>Hydro-SC<br>Out-of-plane<br>q  (Å - ) q  (Å - )<br><!-- End of picture text -->

Fig. 2. Morphological evolution during the formation of a hydro-SC. (A) Schematics showing the morphology evolvement during the three stages of the hydro-SC preparation, highlighting the aggregation and network-formation process of p(g2T-T). (B) Cryo-EM (stage 1 but without AAc monomers) and SEM images (stages 2 and 3) of the preparation process for hydro-SC at different stages (scale bars, 2 mm), showing the existence of p(g2T-T) aggregates in the initial DMSO solution and DMSO gel, and the formation of the interconnected network after solvent exchange in water. The image of stage 3 was colored with green and blue representing the p(g2T-T) and PAAc network, which were 

identified on the basis of the mass ratio and porosity. (C and D) OECT tests in two types of electrolytes (i.e., Ch<sup>+</sup> Cl<sup>−</sup> in DMSO, and Ch<sup>+</sup> Cl<sup>−</sup> in water) (C), and electrical performance of hydro-SC at each of the preparation stages (D), revealing the molecular-level percolation of p(g2T-T) (n = 3 independent measurements). (E) 2D GIXD images of a neat p(g2T-T) film and a hydro-SC film. (F) 1D linecuts in the in-plane and out-of-plane directions of the neat p(g2T-T) and hydro-SC film. a.u., arbitrary units. (G) Normalized UV-vis spectra of a neat p(g2T-T) film and a hydro-SC film. Both films were electrochemically dedoped to −0.2 V versus Ag/AgCl during the measurement. Abs., absorbance. 

3 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 



with the porous hydrogel (i.e., PAAc) framework. Such a morphology is shown by SEM (Fig. 2B, stage 3, and fig. S11) on a freeze-dried sample and also validated by other microscopic imaging in different length scales, including darkfield microscopy (fig. S12), conductive atomic force microscopy (C-AFM) (fig. S13), and STEM (fig. S14) on the wet or dried gel samples. This morphological evolution process validated our hypothesis that the exchange to a nonsolvent (i.e., water) drives the assembly of polymer semiconductor chains into a percolated network for enabling long-range charge transport. 

floating-on-water (FOW) tensile test (28) (Fig. 3E and movie S1). We used two types of supporting liquid, a 100 mM NaCl aqueous solution and phosphate-buffered saline (PBS), for the films to reach the same swelling states with the OECT tests and the physiological environment, respectively. Such an electrolyte environment will lead to less swelling and slightly higher modulus compared with water. Asshown in Fig. 3F and figs. S29 and S30, the gradual increase of the cross-linking density first leads to a decrease and then an increase of the modulus, which should come from the combined effect of a denser network and higher swellability. The increased weight ratio of p(g2T-T) consistently gives a high modulus simply because of the increased fraction of the more rigid component (Fig. 3G and fig. S31). For the lowest modulus of 81 kPa achieved from hydroSCs, it is a decrease by more than three orders of magnitude than the neat p(g2T-T) (Fig. 3G). The hydro-SC also exhibits much higher stretchability than p(g2T-T) (fig. S32). Supported on polystyrene-block-poly(ethylene-ranbutylene)-block-polystyrene (SEBS) substrates, hydro-SC (0.5% cross-linking, 10/100 ratio) films can be stretched up to 150% strain without crack formation or OECT performance degradation (Fig. 3H and fig. S33). Such mechanical and electrical stability also extends to repeated bending (fig. S34) and physiological conditions (fig. S35). 

stronger aggregation of p(g2T-T) in DMSO compared with the dissolution in chloroform. Overall, such a packing morphology could be an optimal balance for the hydro-SC with dual design goals: On the one hand, the enhanced local aggregation and the microstructure-level percolation can ensure efficient interchain charge transport, and on the other hand, the lack of crystallization can help to achieve softer mechanical properties. For the electronic structures, we also used cyclic voltammetry (fig. S18) and UV-vis absorption to confirm that the HOMO (highest occupied molecular orbital) and LUMO (lowest unoccupied molecular orbital) levels of the hydro-SC are almost identical to those of the neat p(g2T-T), which give similar redox activities under electrochemical biasing (fig. S19). 



We further measured the charge-transport and LUMO (lowest unoccupied molecular orperformance by using each stage of the solubital) levels of the hydro-SC are almost idention or gel to make OECT devices. By pertical to those of the neat p(g2T-T), which give forming our hydrogel preparation process on similar redox activities under electrochemical substrates with predeposited gold electrodes, biasing (fig. S19). the semiconductor solution and gel at each stage can serve as the OECT channel (Fig. 2C). Electrical and mechanical properties of For stages 1 and 2, we use an electrolyte with hydro-SCs with varied compositions DMSO solvent and organic choline chloride For the hydro-SC design, there are two main (Ch<sup>+</sup> Cl<sup>−</sup> ) salt, which was added on top of the compositional factors that can influence both DMSO solution and gel in these two stages to electrical and mechanical properties: (i) the enable sufficient ion penetration into the semicross-linking density of the PAAc network and conducting channel layers (fig. S15). Stage 1 al(ii) the weight ratio between p(g2T-T) and ready gave high electrical performance with a PAAc. We first compared the electrical pertransconductance (Gm) of 8.54 mS (Fig. 2D formance in OECT devices (Fig. 3A). The inand fig. S16A), indicating that molecular-level fluence of cross-linking density was tested by percolation of p(g2T-T) occurs in the solution varying the cross-linker weight percentage state in DMSO. After the UV cross-linking of among 0.2, 0.5, and 2% of the AAc monomer, AAc monomers in DMSO (stage 2), the elecwith the p(g2T-T)-to-AAc weight ratio kept at trical performance decreased by about two 10/100. With all three compositions showing orders of magnitude (Fig. 2D and fig. S16B), ideal OECT transfer and output behaviors suggesting that the formation of the PAAc 3D (Fig. 3B and fig. S20), the lowest cross-linking network breaks the molecular-level percolaratio gives the highest m of 1.22 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> tion of p(g2T-T). After the solvent exchange, the (Fig. 3C and fig. S21), which could be attriformation of the microscopic p(g2T-T) fiber buted to the more ordered assembly of p(g2T-T) network in the final hydro-SC reverted the ina looser PAAc network. The slightly higher electrical performance to a similar level with m from 2% cross-linking than from 0.5% could stage 1, as shown by the OECT measurement come from the lower swellability of the hydro(Fig. 2D and fig. S16C) using an aqueous chogel with a higher cross-linking ratio (fig. S22). line chloride electrolyte. Such a performance This is evidenced by the comparison of the evolution also aligns with the transition of OECT performance from the hydro-SC in the short-range ordering during the hydro-SC prepdry state, using ion-exchange gel as the elecaration, which is evidenced by UV-vis (visible) trolyte (27) (fig. S23). On the other hand, when spectra (fig. S17). we increase the p(g2T-T)-to-PAAc weight ratio For the hydro-SC thin film, we further studied from 5/100 to 13.3/100 while the cross-linker the polymer packing of p(g2T-T). Grazingconcentration is kept at 0.2% (fig. S24 and incidence x-ray diffraction (GIXD) (Fig. 2E) table S2), we see a substantial increase of the m shows that, in contrast to a neat p(g2T-T) film from a nonmeasurable level to 1.43 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> deposited from a chloroform solution, the (Fig. 3D and fig. S25), which should come from hydro-SC film does not have observable crysa better percolation of the p(g2T-T) network. talline features (Fig. 2, E and F). This suggests Further increase of the p(g2T-T) ratio gives that the formation of long-range ordering is higher m toward the neat p(g2T-T) (fig. S26). suppressed during the rapid polymer chain Overall, these trends in m are consistent with the precipitation from the solvent exchange prochanges in aggregation levels with the varied cess, together with the inhibition effect of the compositional factors, as revealed by the UVPAAc network. On the other hand, UV-vis abvis absorption spectra (fig. S27). The volumesorption spectroscopy reveals enhanced shorttric capacitance (C*) of the p(g2T-T) within range aggregation in hydro-SC films (Fig. 2G), the hydro-SC is similar to that of the pristine as evidenced by the higher (0-0)/(0-1) ratio p(g2T-T) film (fig. S28). 

### Hydro-SCs for biointerfacing: Higher conformability and lower immune reactions 

The first advantage of using hydro-SCs to interface with biotissues or skin is the higher conformability from the ultralow modulus (29). As demonstrated by adhering a 10-mm-thick hydro-SC film (10/100 and 0.5% cross-linking hydro-SC was used unless specified) to a tendon replica with a rough and irregular surface (fig. S36A), the film adapted to the surface morphology (figs. S36B and S37A), showing a clear improvement compared with a neat p(g2T-T) film, which is much thinner (~650-nmthick) (figs. S36C and S37B). 

The second advantage of the tissue-level modulus of hydro-SC thin films is the alleviated foreign body response (FBR) (30). This was tested by coating different films on both sides of SEBS substrates and implanting subcutaneously in mice for 4 weeks. From the explanted tissues around the implants (figs. S38 and S39), Masson’s trichrome staining (Fig. 4A and fig. S38) shows that the hydro-SC films with 2.0% cross-linker and a modulus of 239 kPa had reduced collagen densities (Fig. 4B) compared with both the bare SEBS implants and the p(g2T-T) films. The level of collagen density is already comparable to that of PAAc hydrogel, which has a modulus of 12.8 kPa (fig. S40A). Such an effect of Young’s modulus on the FBR was further validated by hydro-SC films 

For the hydro-SC thin film, we further studied the polymer packing of p(g2T-T). Grazingincidence x-ray diffraction (GIXD) (Fig. 2E) shows that, in contrast to a neat p(g2T-T) film deposited from a chloroform solution, the hydro-SC film does not have observable crystalline features (Fig. 2, E and F). This suggests that the formation of long-range ordering is suppressed during the rapid polymer chain precipitation from the solvent exchange process, together with the inhibition effect of the PAAc network. On the other hand, UV-vis absorption spectroscopy reveals enhanced shortrange aggregation in hydro-SC films (Fig. 2G), as evidenced by the higher (0-0)/(0-1) ratio than that from p(g2T-T) films. We reason that the higher aggregation level comes from the 

We studied the mechanical properties of the hydro-SC thin film (table S3) through a 

4 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B C D<br>NA<br>E F G H<br>Increasing Increasing<br>crosslinking p( -T) loading<br>Hydro-SC film<br>Hydro-SC<br>film<br><!-- End of picture text -->

cross-linking ratios measured in 100 mM NaCl solution. (G) Young’s modulus of p(g2T-T) and hydro-SC films with different p(g2T-T)-to-AAc weight ratios (n = 4 independent measurements). (H) Stretchability test of hydro-SC films on a SEBS substrate with source-drain electrodes (top), with the optical microscopy image showing the morphology under 100% strain (scale bar, 20 mm), and normalized mC* from OECT measurements during the stretching to 150% strain (in parallel to the charge-transport direction) and release (n = 9 independent measurements). 

Fig. 3. Electrical and mechanical properties of hydro-SC films. (A) OECT tests using swelled hydro-SC films. (B and C) OECT transfer curves (B), extracted m, and peak Gm (C) from hydro-SCs with three different cross-linking ratios (Vds = −0.8 V) (n = 9 independent measurements). (D) Extracted m from hydro-SCs with different p(g2T-T)-to-AAc weight ratios (n = 9 independent measurements). (E) Schematic (top) and picture (bottom) showing the FOW test for the mechanical properties of hydro-SC films. (F) Stress-strain curves of hydro-SC films with different 

rent level is substantially higher than that of a neat p(g2T-T) film [of the same weight as the p(g2T-T) component in the hydro-SC film] tested under the same conditions (Fig. 4E). We reason that this is mostly attributable to the porous nature of the hydrogel design, which substantially increases the semiconductorelectrolyte interfaces for more-efficient use of electrons and holes by redox reactions (33). 

(Fig. 4I and fig. S46), under a radiation power of 318 mW cm<sup>−2</sup> (movie S2). As such, for therapeutic applications, our hydro-SC could serve as a dressing layer for wound healing processes, combining efficient photothermal treatment, soft modulus, oxygen permeability, and moisturization of wound surfaces (6). 

with much higher cross-linking ratios (10%) and thereby a higher modulus of 4.76 MPa (fig. S40B). The collagen density level is higher than in the softer hydro-SC and actually stays on a similar level with the neat p(g2T-T) films (Fig. 4B). This trend is also observed from the comparison of myofibroblast deposition shown by immunofluorescence imaging (fig. S41). Such an influencing behavior of surface modulus on the FBR level is consistent with previous studies on hydrogels and elastomers (31, 32). 

### Bulk diffusion–enabled volumetric biosensing 

Another key biointerfaced application for the hydro-SC is biochemical sensing, for example, through OECT devices. Biochemical sensing can particularly benefit from the bulk mass transport properties of hydrogels. For existing polymer semiconductors, the dense nature and limited hydrophilicity can hardly allow the transport of biomolecules into the bulk volume. As a result, both the functionalization of bioreceptors and the sensing of bioanalytes can only happen at the surfaces (Fig. 5A). This has been the sensing mode for all the transistortype biosensors (34–37). For our hydro-SC, the mass transport properties for biomolecules now can open up the possibility for volumetric sensing (Fig. 5A) throughout the entire thickness of the semiconducting layer. We reason 

We next studied the photothermal properties that come from the nonradiative decay after photoexcitation (Fig. 4F). Upon a laser radiation power of 290 mW cm<sup>−2</sup> , a hydro-SC film reached 78°C within 30 s (fig. S43A). Under the same radiation condition of 178 mW cm<sup>−2</sup> , the hydro-SC film achieved more-efficient heat accumulation (Fig. 4G and fig. S43B), giving a higher photothermal conversion efficiency (PCE) (see supplementary text in the supplementary materials) than a neat p(g2T-T) film (Fig. 4H, figs. S44 and S45, and table S4). When applied on biotissue (e.g., pig skin) surfaces covered with biofluids, the hydro-SC in the fully swelled state can conformally adhere to the tissue and also generate rapid heating with the temperature reaching 50°C in 60 s 

### Hydro-SCs display enhanced photomodulation effects 

Semiconductors have been demonstrated with photomodulation functions for biointerface applications, through photoelectrochemical or photothermal effects. We first studied the photoelectrochemical behavior (Fig. 4C) of our hydro-SC using an electrochemical cell setup under physiological conditions (Fig. 4D). When irradiated by a 625-nm laser, the hydro-SC film showed a lasting and stable faradaic current, which indicates the charge transfer happening between the semiconductor and the electrolyte (Fig. 4E and fig. S42). The stabilized cur- 

5 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 



<!-- Start of picture text -->
A<br>PAAc hydrogel Hydro-SC- SEBS P( -T) Hydro-SC-<br>B<br>C D E<br>Off On<br>F G H I<br>Skin<br>Skin<br>Hydro-SC<br>Hydro-SC<br><!-- End of picture text -->

Fig. 4. Hydro-SCs for alleviated FBR and enhanced photomodulation effects. (A) Masson’s trichrome staining results of tissues around five types of implants after 4 weeks of subcutaneous implantation in mice. Scale bars, 50 mm. (B) Normalized collagen density of different implants as a function of distance (n = 6 independent measurements). Statistical significance and P values were determined by twosided Student’s t test; P values were calculated between hydro-SC 2.0% and p(g2T-T) samples. *P < 0.05. (C) Mechanism of the photoelectrochemical effect from semiconductors. (D) Schematic showing the test setup for photoelectrochemical measurement. CE, counter electrode; WE, working electrode; RE, reference electrode. (E) Photoelectrochemical response of hydro-SC and p(g2T-T) films under a radiation power of 114.3 mW cm<sup>−2</sup> (left), and comparison of photofaradaic current density (right). The amount of p(g2T-T) was kept the same in both films. Tests were conducted with a 0 V bias applied versus the Ag/AgCl electrode. The positive photocurrent values stand for the electrons flowing out of the tested films, and the baseline current was subtracted. (F) Mechanism of the photothermal effect from semiconductors. (G) Accumulated heat on the hydro-SC or neat p(g2T-T) films and the surrounding substrates, upon a radiation power of 178 mW cm<sup>−2</sup> . The amount of p(g2T-T) was kept the same in both films. (H) Calculated PCE of the two films (n = 3 independent measurements). (I) Photograph showing a hydro-SC film conformably adhered to a piece of wet pig skin (top), and thermal heating from the hydro-SC film applied on the skin (bottom). Radiation power, 318 mW cm<sup>−2</sup> . Scale bar, 5 mm. 

In comparison, for a membrane made from a neat p(g2T-T) film, although much thinner (~500-nm-thick), such diffusion was not observed (Fig. 5C and fig. S49). 

ular fluorescent probe PEG-FITC (polyethylene glycol–fluorescein isothiocyanate) [numberaverage molecular weight (Mn) = 20 kDa; fig. S47], which emulates the molecular sizes of proteins and nucleic acids. As shown in Fig. 5C and fig. S48, the fluorescent probes, initially on one side of the hydro-SC membrane (~5-mmthick), diffused to the other side after 24 hours. 

that such volumetric sensing can enable many more interaction sites between bioreceptors and analyte molecules and thereby higher sensitivity. To test this possibility, we first used fluorescent imaging to directly visualize the diffusion ability of large-sized molecules through a hydro-SC film–based membrane (Fig. 5B). This experiment was carried out using a macromolec- 

To further realize volumetric biosensing, a key requirement is to have a method to functionalize bioreceptors throughout the bulk of hydro-SC. We designed an approach that 

6 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B<br>Surface-limited biosensing<br>Fluorescent macromolecule PBS buffer<br>Adhesive PET frame<br>Semiconductor film<br>Adhesive PET frame<br>C<br>Diffuse through hydro-SC<br>Volumetric biosensing<br>D E F G<br>Hydro-SC<br>Hydro-SC<br>w/GOx w/GOx<br>GOx GOx<br>H I J K<br>Hydro-SC<br>L M N O<br><!-- End of picture text -->

Fig. 5. Biosensing using hydro-SC films: Volumetric sensing with higher sensitivity and hydrogel-based OECT devices with tissue-like moduli. (A) Schematics comparing the mechanism of conventional surface-limited biosensing (top) and volumetric biosensing (bottom), showing that volumetric biosensing provides more interaction sites with analytes. (B) Setup for qualitatively testing the diffusion ability of semiconductor films by large molecules, in which a semiconductor film serves as the membrane with fluorescent probe molecules initially only on one side of the membrane. (C) Diffusion of fluorescent probes through hydro-SC (left) and neat p(g2T-T) (right) films in 24 hours. (D) C1s spectra of XPS characterizations on GOx alone, a hydro-SC film without 

GOx immobilization, and a hydro-SC film with GOx immobilization. (E) C1s spectra of XPS depth profiling through the thickness of a hydro-SC film after GOx immobilization. (F) N1s spectra of XPS characterizations on GOx alone, a neat p(g2T-T) film without GOx immobilization, and a neat p(g2T-T) film with GOx immobilization. (G) N1s spectra of XPS depth profiling through the thickness of a neat p(g2T-T) film after GOx immobilization. The GOx was immobilized with a surface coverage of 58% (fig. S57), through noncovalent interactions between GOx and PEG side chains. (H) Sensing response mechanism in hydro-SC during volumetric sensing of glucose. (I) Volumetric sensing performance for glucose from a hydro-SC as the channel layer in an 

7 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
as<br><!-- End of picture text -->



<!-- Start of picture text -->
(M)M))<br>on<br>V.<br><!-- End of picture text -->

from the whole device. (M)M)) Device structure of a hydro-OECT. (N) Photographs of a hydro-OECT device on a bending finger joint, showing highly conformable contact. (O) Modulus measurement (inset) and electrical performance of a hydro-OECT. Vds = −0.8 V. The transfer curve was acquired with a scan speed of 10 mV s<sup>−1</sup> . 

OECT device. (J) Correlation between the threshold voltage (Vth) shift and glucose concentration (n = 3 independent measurements). (K) Surface sensing performance for glucose from a neat p(g2T-T) film as the channel layer in an OECT device. (L) Schematic showing a hydrogel-based OECT (hydro-OECT) for interfacing with biotissues with tissue-like moduli both on the device surface and 

more-realistic biological fluids such as serum and sweat (fig. S56), showing promise for in vivo sensing applications. 

functions that need different band structures and optoelectronic properties. We envision that hydrogel semiconductors that blur the mechanical and chemical interfaces between semiconductors and biotissues can play a central role in bridging electronics technologies with hydrogel-based biomedical technologies. 

uses cross-linking to immobilize the penetrated bioreceptor molecules in the hydro-SC layer (fig. S50). Specifically, one possible chemistry to realize such cross-linking is by using glutaraldehyde as the cross-linker to react with amines that universally exist in proteins (38). To demonstrate this approach, we used glucose oxidase (GOx) as an enzymatic bioreceptor (fig. S51). The hydro-SC used in this experiment was prepared with poly(acrylamide) (PAAm) as the hydrogel-forming polymer because of its electrical neutrality (fig. S52). After 24 hours of incubation in GOx solution with the crosslinker, the successful immobilization of GOx throughout the thickness of the hydro-SC film could be confirmed through x-ray photoelectron spectroscopy (XPS) depth profiling (Fig. 5, D and E) on samples after washing and drying. In this analysis, the C1s peak from GOx was used instead of the stronger N1s peak, as PAAm also has the nitrogen element (Fig. 5D and fig. S53). The GOx density is determined as 782 nmol cm<sup>−3</sup> by the quartz-crystal microbalance (QCM) (table S5). In contrast, the same functionalization process performed on a neat p(g2T-T) only leads to the immobilization of GOx on the surface (Fig. 5, F and G), which is due to the limited infiltration of GOx into the p(g2T-T) film. 

### Hydrogel-based OECTs 

For the application of such OECT-based biosensing with direct interfacing with biotissues, the requirement on tissue-level softness is mainly composed of two aspects: the surface modulus that is in direct contact with the tissue, and the effective modulus of the full device (Fig. 5L). The hydro-SC as the sensing surface can satisfy the former requirement. To fulfill the latter part, we used the hydro-SC to create stretchable OECT devices on a hydrogel substrate (Fig. 5M and fig. S58). The stretchable electrodes were served by microcracked gold films (40), which were deposited on a thin layer of SEBS sitting on top of the hydrogel substrate. The SEBS layer not only forms an interpenetrated interface with the gold films to enable the stretching-induced microcrack morphology but also prevents shorting of the electrodes by water in the hydrogel. The obtained hydrogel-based OECT gives high conformability even on a highly wrinkled part of the skin (Fig. 5N), which benefits from the ultralow modulus of ~30.9 kPa (Fig. 5O, inset). The OECT shows transistor performance (Fig. 5O), with a high on-current of 2 mA, on-off ratio of 10<sup>2</sup> , and decent operation speed (fig. S59). In contrast, when a neat p(g2T-T) film was used as the channel layer to make a hydrogel-based OECT, the substantial modulus mismatch with the hydrogel substrate led to very low mechanical robustness (fig. S60). 

#### REFERENCES AND NOTES 

1. H. Yuk, B. Lu, X. Zhao, Chem. Soc. Rev. 48, 1642–1667 (2019). 

2. A. C. Daly, L. Riley, T. Segura, J. A. Burdick, Nat. Rev. Mater. 5, 20–43 (2020). 

3. J. Lou, D. J. Mooney, Nat. Rev. Chem. 6, 726–744 (2022). 4. K. Y. Lee, D. J. Mooney, Chem. Rev. 101, 1869–1879 (2001). 5. J. Shi et al., Nat. Chem. Eng. 1, 73–86 (2024). 6. Y. Liang, J. He, B. Guo, ACS Nano 15, 12687–12722 (2021). 7. J. Deng et al., Nat. Mater. 20, 229–236 (2021). 8. J. Ma et al., Chem. Eng. J. 481, 148317 (2024). 9. P. Li et al., Nature 626, 990–998 (2024). 

10. J. Liu et al., Science 383, 1096–1103 (2024). 

11. X. Strakosas et al., Science 379, 795–802 (2023). 

12. H. Yuk, J. Wu, X. Zhao, Nat. Rev. Mater. 7, 935–952 (2022). 

13. S. Naahidi et al., Biotechnol. Adv. 35, 530–544 (2017). 

14. E. Axpe et al., Macromolecules 52, 6889–6897 (2019). 

15. D. Liu et al., Mater. Horiz. 10, 2800–2823 (2023). 

16. B. Lu et al., Nat. Commun. 10, 1043 (2019). 

17. T. Zhou et al., Nat. Mater. 22, 895–902 (2023). 

18. T. Dvir et al., Nat. Nanotechnol. 6, 720–725 (2011). 

19. Y. Lu et al., Nat. Electron. 7, 51–65 (2024). 

20. Y. Zheng, S. Zhang, J. B.-H. Tok, Z. Bao, J. Am. Chem. Soc. 144, 4699–4715 (2022). 

21. L. Ding et al., Chem. Rev. 123, 7421–7497 (2023). 

22. K. M. Sim et al., ACS Nano 14, 415–421 (2020). 

23. J. Cho et al., Energy Environ. Sci. 10, 2324–2333 (2017). 

We further tested the volumetric sensing performance of the bulk-functionalized hydro-SC in OECT devices, which was compared with surface-functionalized p(g2T-T) films. For glucose analyte, the sensing can happen through glucose oxidation at the active site of GOx, which leads to the reduction of oxygen to hydrogen peroxide that further oxidizes the p(g2T-T) (Fig. 5H). For hydro-SC, the gradual increase of the drain current (Id) can be observed during the increase of the glucose concentration from 100 nM to 2 mM (Fig. 5I). By analyzing the relationship between the shift of threshold voltage (Vth) with the glucose concentration (Fig. 5J), the detection limit can be determined as 500 nM. In comparison, the surfacefunctionalized p(g2T-T) only shows a current decrease when the glucose concentration is >100 mM (Fig. 5K), which could come from the electrooxidation of glucose (39) (fig. S54). This indicates that surface-immobilized GOx might be insufficient to achieve considerable enzymatic reactions (fig. S55). Overall, this comparison validated that the volumetric biosensing achieved on the hydro-SC can be an effective strategy for increasing sensitivity. The glucose sensor also generated a response in 

24. B. Kang, Z. Wu, M. J. Kim, H. Y. Woo, J. H. Cho, Chem. Mater. 32, 1111–1119 (2020). 

25. P. Li et al., Science 384, 557–563 (2024). 

26. Z. Xu et al., Adv. Mater. 34, e2203055 (2022). 

27. C. G. Bischak, L. Q. Flagg, D. S. Ginger, Adv. Mater. 32, e2002610 (2020). 

28. L. A. Galuska et al., Nat. Commun. 12, 2347 (2021). 

29. Z. Yan et al., Science 375, 852–859 (2022). 

30. S. Capuani, G. Malgir, C. Y. X. Chua, A. Grattoni, Bioeng. Transl. Med. 7, e10300 (2022). 

Our interpenetrated double-network design for hydrogel semiconductors unites highperformance semiconducting properties with tissue-like softness, high porosity, and efficient transport of biomolecules. The hydrogel properties improve the conformability and immune compatibility for the use of semiconductors on tissue surfaces. The highly porous morphology, with a high surface aspect ratio, also enhances the bioelectronic functions, such as stronger photoelectrochemical and photothermal effects forphotomodulation, and biosensingwith higher sensitivity through volumetric sensing. All these are enabled by our solvent-exchange processing method, which circumvents the need for water processability for polymer semiconductors. This method offers broad applicability to different designs of redox-active semiconducting polymers, so that hydrogel designs can be achieved on different semiconductor-based 

31. N. Li et al., Science 381, 686–693 (2023). 

32. R. Sridharan, B. Cavanagh, A. R. Cameron, D. J. Kelly, F. J. O’Brien, Acta Biomater. 89, 47–59 (2019). 

33. C.-L. Chang et al., Nat. Commun. 13, 5460 (2022). 

34. N. Wang, A. Yang, Y. Fu, Y. Li, F. Yan, Acc. Chem. Res. 52, 277–287 (2019). 

35. X. Ji, X. Lin, J. Rivnay, Nat. Commun. 14, 1665 (2023). 

36. G. E. Fenoy et al., ACS Appl. Mater. Interfaces 15, 10885–10896 (2023). 

37. D. Ohayon et al., Nat. Mater. 19, 456–463 (2020). 

38. I. Migneault, C. Dartiguenave, M. J. Bertrand, K. C. Waldron, Biotechniques 37, 790–802 (2004). 

39. M. Pasta, F. La Mantia, Y. Cui, Electrochim. Acta 55, 5561–5568 (2010). 

40. Y. Jiang et al., Nature 614, 456–462 (2023). 

#### ACKNOWLEDGMENTS 

We thank the University of Chicago Animal Resources Center (RRID: SCR_021806) for animal housing and use of their facility and equipment. All the animal experiments performed in this research were approved by the Institutional Animal Care and Use Committee of the University of Chicago under the protocol ACUP 72702. This work used the Soft Matter Characterization Facility (SMCF) and the Materials Research Science and 

8 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 

RESEARCH | RESEARCH ARTICLE 







application no. UCHI 25-T-008 submitted by the University of Chicago. Data and materials availability: All data are available in the manuscript or the supplementary materials. License information: Copyright © 2024 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www. science.org/about/science-licenses-journal-article-reuse 

Engineering Center (MRSEC) at the University of Chicago. Parts of the diagrams were created with BioRender.com. Funding: This work was supported by the US National Institutes of Health Director’s New Innovator Award (1DP2EB034563) and the US Office of Naval Research (N00014-21-1-2266). This work was partially supported by the start-up fund from the University of Chicago. This research used beamline 7.3.3 of the Advanced Light Source, which is a US Department of Energy (DOE) Office of Science User Facility under contract no. DE-AC02-05CH11231. Y.W. was supported in part by an ALS Doctoral Fellowship in Residence. Z.C., Y.W., and X.G. acknowledge financial aid from an NSF grant (DMR-2047689) that enabled the thin-film tensile testing of the samples. B.T. acknowledges grant support from the US Army Research Office (W911NF-24-1-0053). P.L. acknowledges the Grier Prize for Innovation Research in the Biophysical Sciences. Work performed at the Center for Nanoscale Materials, a US DOE Office of Science User Facility, was supported by the US DOE, Office of Basic Energy Sciences, under contract no. DE-AC02-06CH11357. S. Wang is a CZ Biohub Investigator. Author contributions: S. Wang supervised this work. Y.D. and 

S. Wang designed the experiments. Y.D. synthesized the polymers and hydro-SCs. N.L. and N.S. performed and analyzed NMR. Y.D., Y. Li, S. Li, and S.C. fabricated and tested the OECT. Y.D. and Yo.Liu performed the conformability test. S. Wai performed biocompatibility study. Yu.Liu, J.X., and H.C.F. performed and analyzed the cryo-EM results. M.H. performed the STEM-EDS (energy dispersive spectroscopy) imaging and elemental mapping. Y. Li performed SEM imaging. Y.D. and H.C.F. performed the liquid AFM for swelling ratio measurement. Y.W. and C. Zhu performed the GIXD characterizations. Z.C., Y.W., K.T., and X.G. performed the FOW measurements. W.L. measured the fluorescent spectroscopy. Y.D., P.L., J.S., S. Lee, and B.T. performed the measurements for studying the photoelectrochemical and photothermal effect. Y.D. and M.W. carried out the thickness measurement. Y.D. and N.S. performed the diffusion test on semiconductor. Y.D., N.S., and N.L. carried out the enzyme immobilization and sensing test. N.S. performed the QCM and infrared measurements. C. Zhang and S.S. helped analyze the results. Y.D. and S. Wang wrote the paper. All authors reviewed and commented on the manuscript. Competing interests: S. Wang and Y.D. are inventors on patent 

SUPPLEMENTARY MATERIALS science.org/doi/10.1126/science.adp9314 Materials and Methods Supplementary Text Figs. S1 to S60 Tables S1 to S5 References (41–73) MDAR Reproducibility Checklist Movies S1 and S2 Submitted 18 April 2024; accepted 13 September 2024 10.1126/science.adp9314 

9 of 9 

Dai et al., Science 386, 431–439 (2024) 25 October 2024 



## **Soft hydrogel semiconductors with augmented biointeractive functions** 

Yahao Dai, Shinya Wai, Pengju Li, Naisong Shan, Zhiqiang Cao, Yang Li, Yunfei Wang, Youdi Liu, Wei Liu, Kan Tang, Yuzi Liu, Muchuan Hua, Songsong Li, Nan Li, Shivani Chatterji, H. Christopher Fry, Sean Lee, Cheng Zhang, Max Weires, Sean Sutyak, Jiuyun Shi, Chenhui Zhu, Jie Xu, Xiaodan Gu, Bozhi Tian, and Sihong Wang 

_Science_ **386** (6720), .  DOI: 10.1126/science.adp9314 

### **Editor’s summary** 

Water-laden hydrogels are increasingly finding use in biomedical applications because of their inherent softness, which matches that of biological tissue, and their ability to maintain hydration and oxygen permeation. However, it is difficult to give them semiconducting functionality, as most polymer semiconductors are not soluble in water. Dai _et al_ . report the design, synthesis, characterization, and applications of hydrogel–semiconducting polymer composites through a process of solvent exchange. They combined the polymer semiconductor p(g2T-T) with the hydrogel-forming monomer acrylic acid in dimethyl sulfoxide to form a double-network structure upon cross-linking with ultraviolet light. After solvent exchange with water, the semiconducting hydrogel had a low modulus while maintaining high charge carrier transport properties, as well as organ conformability and reduced foreign body response. —Marc S. Lavine 

**View the article online** https://www.science.org/doi/10.1126/science.adp9314 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2024 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

