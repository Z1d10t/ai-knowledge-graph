# Ultrathin ferroic HfO2–ZrO2 superlattice gate stack for advanced transistors

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 358 |
| 作者 | S. Cheema, N. Shanker, Li-Chen Wang, Cheng-Hsiang Hsu, Shang-Lin Hsu, Yu-Hung Liao, Matthew San Jose, Jorge Gomez et al. |
| DOI | 10.1038/s41586-022-04425-6 |
| 源文件 | 043_Cheema_2022_Ultrathin-ferroic-HfO2ZrO2-superlattice-gate-sta.pdf |

---




<!-- Start of picture text -->
Atomic -s cale ferroic HfO2 -Z rO2 superlattice gate<br>stack for advanced transistors<br><!-- End of picture text -->

Suraj Cheema  (  s.cheema@berkeley.edu ) 

University of California, Berkeley https://orcid.org/0000-0001-5878-3624 

University of California, Berkeley https://orcid.org/0000-0002-4102-9665 

UC Berkeley https://orcid.org/0000-0003-0703-5030 

University of California, Berkeley https://orcid.org/0000-0002-6863-5606 

University of california, Berkeley 

University of California, Berkeley 

University of Notre Dame 

University of Notre Dame 

University of California, Berkeley 

University of California, Berkeley 

University of California, Berkeley 

University of California, Berkeley 

University of California Berkeley 

Lincoln Laboratory 

Lincoln Laboratory 

Lincoln Laboratory 

Lincoln Laboratory 

Lincoln Laboratory Brian Tyrrell Lincoln Laboratory Vladimir Stoica Pennsylvania State University https://orcid.org/0000-0002-2734-7819 Zhan Zhang Argonne National Lab https://orcid.org/0000-0002-7618-6134 John Freeland Argonne National Laboratory https://orcid.org/0000-0003-4814-5308 Christopher Tassone SLAC National Accelerator Laboratory Apurva Mehta SLAC National Accelerator Laboratory https://orcid.org/0000-0003-0870-6932 Ghazal Soheli Applied Materials David Thompson Applied Materials Dong Ik Suh SK Hynix Inc. Won ~~-T~~ ae Koo SK Hynix Inc. Kab ~~-J~~ in Nam Samsung Electronics Dong Jin Jung Samsung Electronics Woo ~~-B~~ in Song Samsung Electronics Chung ~~-H~~ sun Lin Intel Corporation Seunggeol Nam Samsung Advanced Institute of Technology (SAIT) 

Samsung Advanced Institute of Technology (SAIT) 

University of California, Berkeley https://orcid.org/0000-0002-8505-4037 

Lawrence Berkeley National Laboratory https://orcid.org/0000-0001-9363-2557 

University of Notre Dame 

University of California, Berkeley https://orcid.org/0000-0003-0524-1332 

Lawrence Berkeley National Laboratory 

University of Notre Dame 

Lincoln Laboratories 

Department of Electrical Engineering and Computer Science, University of California, Berkeley Sayeef Salahuddin UC Berkeley 

Keywords: transistors, HfO2-ZrO2 superlattice 

Posted Date: April 16th, 2021 

DOI: https://doi.org/10.21203/rs.3.rs-413053/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Version of Record: A version of this preprint was published at Nature on April 6th, 2022. See the published version at https://doi.org/10.1038/s41586-022-04425-6. 

- 1 **Atomic-scale ferroic HfO** 2 **-ZrO** 2 **superlattice gate stack for** 

- 2 **advanced transistors** 

- 3 Suraj S. Cheema,<sup>1∗†</sup> Nirmaan Shanker,<sup>2∗</sup> Li-Chen Wang,<sup>1</sup> Cheng-Hsiang Hsu,<sup>2</sup> Shang-Lin Hsu,<sup>2</sup> 

- 4 Yu-Hung Liao,<sup>2</sup> Matthew San Jose,<sup>3</sup> Jorge Gomez,<sup>3</sup> Wenshen Li,<sup>2</sup> Jong-Ho Bae,<sup>2</sup> Steve Volkman,<sup>4</sup> 

- 5 Daewoong Kwon,<sup>2</sup> Yoonsoo Rho,<sup>5</sup> Gianni Pinelli,<sup>6</sup> Ravi Rastogi,<sup>6</sup> Dominick Pipitone,<sup>6</sup> Corey 

- 6 Stull,<sup>6</sup> Matthew Cook,<sup>6</sup> Brian Tyrrell,<sup>6</sup> Vladimir A. Stoica,<sup>7</sup> Zhan Zhang,<sup>8</sup> John W. Freeland,<sup>8</sup> 

- 7 Christopher J. Tassone,<sup>9</sup> Apurva Mehta,<sup>9</sup> Ghazal Soheli,<sup>10</sup> David Thompson,<sup>10</sup> Dong Ik Suh,<sup>11</sup> 

- 8 Won-Tae Koo,<sup>11</sup> Kab-Jin Nam,<sup>12</sup> Dong Jin Jung,<sup>12</sup> Woo-Bin Song,<sup>12</sup> Chung-Hsun Lin,<sup>13</sup> Seunggeol 

- 9 Nam,<sup>14</sup> Jinseong Heo,<sup>14</sup> Costas P. Grigoropoulos,<sup>5</sup> Padraic Shafer,<sup>15</sup> Patrick Fay,<sup>3</sup> Ramamoor- 

- 10 thy Ramesh,<sup>1,16,17</sup> Jim Ciston,<sup>18</sup> Suman Datta,<sup>3</sup> Mohamed Mohamed,<sup>6</sup> Chenming Hu,<sup>2</sup> Sayeef 11 Salahuddin<sup>2,17†</sup> 

- 12 1Department of Materials Science and Engineering, University of California, Berkeley, CA, USA 

- 13 2Department of Electrical Engineering and Computer Sciences, University of California, Berkeley, 14 CA, USA 

- 15 3Department of Electrical Engineering, University of Notre Dame, Notre Dame, IN, USA 

- 16 4Applied Science & Technology, University of California, Berkeley, CA, USA 

- 17 5Laser Thermal Laboratory, Department of Mechanical Engineering, University of California, 18 Berkeley, CA, USA 

- 19 6Lincoln Laboratory, Massachusetts Institute of Technology, Lexington, MA, USA 

- 20 7Department of Materials Science and Engineering, Pennsylvania State University, University 21 Park, PA, USA 

- 22 8Advanced Photon Source, Argonne National Laboratory, Lemont, IL, USA 

- 23 9Stanford Synchrotron Radiation Lightsource, SLAC National Accelerator Laboratory, Menlo 24 Park, CA, USA 

- 25 10Applied Materials, Santa Clara, CA, USA 

- 26 11SK Hynix Inc., Icheon, Gyeonggi-do 17336, Korea 

- 27 12Semiconductor R&D Center, Samsung Electronics, Gyeonggi-do, 445-330, Korea 

1 

- 28 13Logic Technology Development, Intel Corporation, Hillsboro, Oregon 97124, USA 

- 29 14Samsung Advanced Institute of Technology, Samsung Electronics, Gyeonggi-do, 445-330, Korea 

- 30 15Advanced Light Source, Lawrence Berkeley National Laboratory, Berkeley, CA, USA 

- 31 16Department of Physics, University of California, Berkeley, CA, USA 

- 32 17Materials Sciences Division, Lawrence Berkeley National Laboratory, Berkeley, CA, USA 

- 33 18National Center for Electron Microscopy, Molecular Foundry, Lawrence Berkeley National Lab- 

- 34 oratory, Berkeley, CA, USA 

- 35 ∗These authors contributed equally to this work 

- 36 †Correspondence to: s.cheema@berkeley.edu (S.S.C), sayeef@berkeley.edu (S.S.) 

2 

- 37 With the scaling of lateral dimensions in advanced transistors, an increased gate capacitance 

- 38 is desirable both to retain the control of the gate electrode over the channel and to reduce 

- 39 the operating voltage<sup>1</sup> . This led to the adoption of high-κ dielectric HfO2 in the gate stack in 

- 40 2008<sup>2</sup> , which remains as the material of choice to date. Here, we report HfO2-ZrO2 super- 

- 41 lattice heterostructures as a gate stack, stabilized with mixed ferroelectric-antiferroelectric 

- 42 order, directly integrated onto Si transistors and scaled down to ∼ 20 Å, the same gate ox- 

- 43 ide thickness required for high performance transistors. The overall EOT (equivalent oxide 

- 44 thickness) in metal-oxide-semiconductor capacitors is equivalent to ∼ 6.5 Å effective SiO2 

- 45 thickness, which is, counterintuitively, even smaller than the interfacial SiO2 thickness (8.0- 

- 46 8.5 Å) itself. Such a low effective oxide thickness and the resulting large capacitance cannot 

- 47 be achieved in conventional HfO2-based high-κ dielectric gate stacks without scavenging the 

- 48 interfacial SiO2, which has adverse effects on the electron transport and gate leakage cur- 

- 49 rent<sup>3</sup> . Accordingly, our gate stacks, which do not require such scavenging, provide substan- 

- 50 tially lower leakage current and no mobility degradation. Therefore, our work demonstrates 

- 51 that HfO2-ZrO2 multilayers with competing ferroelectric-antiferroelectric order, stabilized 

- 52 in the 2 nm thickness regime, provides a new path towards advanced gate oxide stacks in 

- 53 electronic devices beyond the conventional HfO2-based high-κ dielectrics. 

3 

- 54 With the two-dimensional scaling of silicon field-effect transistors reaching fundamental lim- 

- 55 its<sup>1</sup> , new functional improvements to transistors<sup>4</sup> , as well as novel computing paradigms and verti56 cal device integration at the architecture-level<sup>5</sup> , are currently under intense study<sup>1,4,6</sup> . Gate oxides 57 play a critical role in this endeavor, as it’s a common performance booster for all devices, includ58 ing silicon<sup>2</sup> , new channel materials with potential for higher performance<sup>7,8</sup> , and even materials 59 suitable for three-dimensional integrated transistors<sup>9,10</sup> . Indeed, the gate oxide transition from 60 SiO2 to high-κ dielectric (DE) is considered a paradigm shift in computing technology. In this 61 context, ferroelectric oxides offer new functionalities<sup>11</sup> considered promising for energy-efficient 62 electronics<sup>4,9</sup> . The advent of atomic layer deposition (ALD) grown ferroelectric doped-HfO2<sup>12</sup> 63 has overcome much of the material compatibility issues that plague traditional perovskite-based 64 ferroelectric materials<sup>2</sup> . In addition, considering ferroic order persists down to a thickness of 1 nm 65 in this system<sup>13–15</sup> allows for integration of these oxides in the most aggressively-scaled devices in 66 which the state-of-the-art high-κ oxide thickness is less than 2 nm. 

67 In an advanced silicon transistor, the gate oxide is a combination of two distinct layers. The 68 first is an interfacial SiO2 formed with a self-limiting process, resulting in ∼ 8.0-8.5 Å thickness<sup>16</sup> . 69 The next is the high-κ (HK) dielectric HfO2 layer that is typically ∼ 2 nm in thickness. Higher ca70 pacitance of this series combination is desirable to suppress short channel effects. The capacitance 71 is conventionally represented by effective oxide thickness (EOT), EOT = tSiO2 + tHK/(ǫHK/ǫSiO2), 72 where lower EOT represents higher capacitance. Therefore, the EOT minimum value is limited 73 by the interfacial SiO2 thickness. Indeed, even integrating HfO2 as the high-κ layer, the EOT is 74 typically ∼ 9 Å. To go below this value<sup>17</sup> , the semiconductor industry has implemented sophisti75 cated scavenging techniques<sup>16,18</sup> to reduce the SiO2 thickness after the full gate stack is formed. 76 Although this technique is very effective in scaling EOT, the thinner SiO2 results in undesirable 77 leakage<sup>19</sup> and mobility degradation<sup>2,16,20,21</sup> . 

78 In this work, we present an ultrathin HfO2-ZrO2 superlattice gate stack that exploits mixed 79 ferroelectric-antiferroelectric (FE-AFE) order (Fig. 1a,b). Our films demonstrate mixed ferroic 80 order down to 2 nm thickness – the same thickness of high-κ oxide used in advanced transis- 

4 

- 81 tors. Moreover, when integrated with silicon, it shows an overall EOT of <6.5 Å, despite the fact 

- 82 that both transmission electron microscopy (TEM) and electrical characterization reveal 8.0-8.5 83 Å interfacial SiO2 thickness, as is typically expected. The larger capacitance than its constituent 84 layers is a signature of the charge boost stemming from the negative capacitance effect, possible 85 in materials with ferroic order<sup>11</sup> . The EOT shows a clear dependence on the specific sequence and 86 layering, underlying atomic-level control of the gate oxide behavior. The fact that sub-8 Å EOT 87 is achieved without any interfacial SiO2 scavenging results in substantially lower leakage current 88 for the same EOT compared to benchmarks established by major semiconductor industries<sup>3</sup> . In 89 addition, no mobility degradation is observed as EOT is scaled with these HfO2-ZrO2 ferroic gate 90 stacks. Furthermore, large ON current (> 1mA/µm) obtained in LG = 90 nm transistors indicate 91 that there is no adverse effect on the carrier velocity. Therefore, ultrathin HfO2-ZrO2 multilayers 92 exploiting ferroic order provide a new pathway toward energy-efficient gate stacks for advanced 93 transistors. 

94 Thin films of HfO2-ZrO2 are grown using ALD in which the nanolaminate periodicity is 95 dictated by the sequence of Hf:Zr (4:12) ALD cycles before the Hf-Zr superstructure is repeated 96 various times (Figure 1c, Methods). After top metal deposition, the entire gate stack undergoes 97 a low-temperature post-metal anneal (200 C, 60s, N2) which does not interfere with the HfO298 ZrO2 multilayer structure, as various characterization techniques – synchrotron x-ray reflectivity 99 (XRR), layer-resolved electron energy loss spectroscopy (EELS) and angle-resolved X-ray photo100 electric spectroscopy (XPS) – confirm the expected Hf 4 Å - Zr 12 Å periodicity (Extended Data 101 Fig. 1). The underlying mixed ferroic order in these HfO2-ZrO2 heterostructure is established by 102 high-resolution transmission electron microscopy (TEM) (Fig. 1d, Extended Data Fig. 2e,f) and 103 in-plane grazing incidence diffraction (Fig. 1e and Extended Data Fig. 2a,b). Both techniques 104 indicate the presence of the tetragonal (P42/nmc, T -) and orthorhombic (Pca21, O-) phase, which 105 correspond to antiferroelctric and ferroelectric order in fluorite-structure films, respectively. Syn106 chrotron X-ray spectroscopy and optical spectroscopy further confirm the presence of inversion 107 symmetry breaking in the 2 nm HfO2-ZrO2-HfO2 heterostructure (Extended Data Fig. 2c,d). 

5 

108 Mixed-ferroic atomic-scale HfO2-ZrO2 multilayers were designed considering FE-AFE or109 der can tune the free energy landscape in a similar manner to the FE-DE model systems originally 110 studied for negative capacitance stabilization<sup>11,22</sup> (Fig. 1a). From the free energy landscape pic111 ture within a Landau formalism (Methods), the competition between the negative curvature (i.e. 112 negative capacitance) of the FE and the positive curvature (i.e. positive capacitance) of the AFE 113 can flatten the overall energy landscape, thereby substantially increasing the system’s susceptibil114 ity. To confirm the higher susceptibility in the mixed AFE-FE system directly, we have performed 115 capacitance-voltage (C-V) hysteresis loops in metal-insulator-metal (MIM) capacitor structures on 116 thicker films with the same superlattice periodicity (Fig. 2a). Besides features indicative of mixed 117 FE-AFE order, the total capacitance for the superlattice is larger than both conventional AFE ZrO2 118 and FE Zr:HfO2 of the same thickness (Fig. 2a), demonstrating enhanced susceptibility. To quan119 tify the permittivity, capacitance measurements were performed across the superlattice thickness 120 series. These measurements yield an extracted permittivity of ∼ 52 (Fig. 2b, Methods), which is 121 larger than both FE orthorhombic Zr:HfO2 and AFE tetragonal ZrO2 values<sup>23</sup> . 

122 To further understand the ferroic evolution in these HfO2-ZrO2 superlattices, we performed 123 low temperature measurements where enhanced FE phase stabilization is expected. Indeed, temperature124 dependent C-V loops for thicker HfO2-ZrO2 multilayers demonstrate an evolution from mixed125 ferroic to FE-like hysteresis upon cooling slightly below room temperature (∼ 240 K, Fig. 2c), con126 sistent with temperature-dependent X-ray spectroscopy indicating transition from mixed tetragonal127 orthorhombic phase to predominately orthorhombic structure at similar temperatures (Extended 128 Data Fig. 3). The capacitance decrease upon cooling as the system moves away from the highly129 susceptible mixed ferroic phase is consistent with previous work on negative capacitance in FE-DE 130 systems<sup>22</sup> which establishes the energy landscape link between enhanced capacitance and suscep131 tibility near phase transitions. Notably, the intertwined FE-AFE phases within the superlattice and 132 resulting enhancement in susceptibility from the competition of FE and AFE phases is concep133 tually similar to negative stiffness composites of ferroelastics within a metal matrix<sup>24,25</sup> , i.e. the 134 mechanical analog to negative capacitance. 

6 

135 Next, the superlattices were grown on Si substrates in metal-oxide-semiconductor (MOS) 136 capacitor structures. A self-limiting chemical oxide SiO2 was grown first, resulting in ∼ 8.0-8.5 137 Å thickness<sup>3</sup> , following the standard practice in advanced Si devices (Methods). Next, a 20-cycle 138 thick multilayer was grown with ALD following the same stacking as before i.e. Hf:Zr:Hf 4:12:4. 139 Accumulation C-V curves of the superlattice stack results in significantly larger capacitance in 140 comparison to other conventional stacks – DE HfO2, AFE ZrO2, FE Zr:HfO2 – of the same 20 Å 141 thickness (Fig. 2d). Furthermore, the Hf:Zr:Hf 4:12:4 trilayer demonstrates enhanced capacitance 142 compared to a bilayer (Hf:Zr 8:12) and solid solution (Hf:Zr [2:3]4) of the same thickness and 143 Hf:Zr composition (Fig. 2e). Notably, the composition in our films is close to where several previ144 ous reports have postulated a possible morphotropic phase boundary (MPB) in thicker HfO2-ZrO2 145 solid solution films<sup>26–30</sup> . In our ultrathin HfO2-ZrO2 multilayers, the negative free energy curva146 ture of the FE O-phase compensates the positive curvature of the AFE T-phase (Fig. 1a), leading 147 to a flattened energy landscape. Indeed, energy landscape flattening is the thermodynamic origin 148 of the MPB in the canonical perovskite ferroelectrics<sup>31,32</sup> , in which multiple crystal symmetries 149 are nearly degenerate across a composition phase boundary<sup>33</sup> . However, a critical distinction is 150 that here, the overall energy landscape flattening, and corresponding increase in capacitance, is 151 determined by the stacking of the atomic-scale HfO2-ZrO2 layers, and not the volume fraction of 152 the constituent elements<sup>34</sup> . For example, compared to HfO2-ZrO2 solid solutions across a range of 153 typically-reported Zr-rich "MPB"-like compositions<sup>26–30</sup> , the HfO2-ZrO2 multilayer demonstrates 154 larger capacitance (Extended Data Fig. 4). This indicates the enhanced capacitance in HfO2-ZrO2 155 films is not simply driven by doping<sup>23,35</sup> , but can instead be tuned by the configuration of the 156 multilayer structure (Extended Data Fig. 4, 5). In the ultrathin regime, surface energies become 157 a more dominant consideration for determining polymorphic phase stability<sup>36,37</sup> ; accordingly, the 158 importance of stacking is amplified. Overall, these capacitor studies suggest that the exact stack159 ing sequence plays a crucial role in stabilizing the fluorite-structure FE-AFE phase competition 160 that leads to enhanced capacitance, akin to previous reports in perovskite-based FE-DE superlat161 tices<sup>38–42</sup> . 

162 To quantify the observed capacitance, we have performed EOT simulations of MOS capac- 

7 

163 itors using the industry standard model Synopsys simulation platform (Methods). The Hf:Zr:Hf 164 4:12:4 trilayer stacks vary between 6.5-7.0 Å EOT (Fig. 2f), consistent over many measured ca165 pacitors. Notably, this EOT is smaller than the expected thickness of the interfacial SiO2 layer 166 (8.0-8.5 Å), as mentioned above. To investigate further, we performed high-resolution TEM of 167 our gate stacks (Extended Data Fig. 6), which illustrates the SiO2 thickness is indeed ∼8.5 Å. To 168 supplement this physical characterization, we next implemented electrical characterization of the 169 interfacial layer via standard inverse capacitance vs thickness analysis of conventional dielectric 170 HfO2 and Al2O3 thickness series grown on the same SiO2 (Methods, Extended Data Fig. 6). All 171 thermal processing is kept exactly the same as the superlattice gate stack. The extracted HfO2 and 172 Al2O3 permittivity – 19 and 9, respectively – is consistent with the typical dielectric phases of these 173 two materials. Therefore, one can reliably extract the SiO2 layer thickness, yielding 8 Å (Extended 174 Data Fig. 6), consistent with the HR-TEM results and similar to previously studies established 175 by the semiconductor industry<sup>3</sup> . Moreover, the consistent interlayer thickness extracted from both 176 material systems indicates that neither Hf nor Al encroaches into the interfacial SiO2 which would 177 reduce its thickness and/or increase its permittivity. This is consistent with the fact all our stacks 178 are processed at much lower temperature as compared to that needed for silicate formation<sup>43</sup> . So 179 considering the interfacial layer thickness as 8 Å, the Hf:Zr:Hf 4:12:4 gate stack demonstrates an 180 overall EOT 1.0-1.5 Å lower than the constituent SiO2 thickness. In other words, capacitance en181 hancement is observed in this 20 Å mixed ferroic gate oxide integrated on Si. Therefore, the mixed 182 FE-AFE order not only improves the permittivity of the multilayer stack itself, but also couples to 183 the SiO2 in MOS capacitor structures, yielding improved overall capacitance. 

184 The practical implication of this capacitance enhancement can be clearly seen in Fig. 3a, 185 which shows leakage current vs EOT behavior. The leakage current is measured at VG - Vfb = -1 186 V, where Vfb is the flatband voltage of the semiconductor. All other data points on this plot are 187 taken from reported industrial gate stacks<sup>3</sup> . The leakage current for the Hf:Zr:Hf 4:12:4 stack is 188 substantially lower at the same EOT. Note that below 9 Å, the other gate stacks need sophisticated 189 scavenging techniques to reduce the thickness of the interfacial SiO2<sup>3</sup> . On the other hand, we 190 can reach ∼ 6.5 Å without any scavenging. This leads to the fact that the leakage current for our 

8 

191 stacks is lower (Fig. 3a). Notably, the scavenging the interfacial SiO2 leads to a loss of mobility 192 due to increase in remote phonon scattering. As it has been shown<sup>3,16</sup> , the mobility drops off with 193 a slope of ∼ 20 cm<sup>2</sup> /V-s per every Å of scavenged SiO2. To test how mobility is affected by 194 the superlattice gate stack, we fabricated long channel bulk transistors with two different repeats 195 of the superlattice, together with another sample that has thick (60 Å) HfO2 as the gate stack 196 (Methods). To extract mobility, a careful fitting of the measured C-V from the transistor structures 197 is performed. In addition, series resistance is modeled from the data and de-embedded to reveal 198 the intrinsic behavior. Next, the mobility is extracted using the peak transconductance method 199 (Methods, Extended Data Fig. 8). It is found that the mobility remains essentially the same for all 200 three stacks despite the difference in materials and EOT (from 2 nm EOT for HfO2 down to sub-8 201 Å for the superlattice gate stack). First, this shows that there is no fundamental change in electron 202 transport due to the use of the superlattice gate stack compared to standard HfO2. In addition, 203 it shows that there is no penalty in mobility even below an EOT of 9 Å where conventional gate 204 stacks show a degradation due to the need for scavenging (Fig. 3b). Because the absolute value of 205 mobility depends on the specific processing technique, mobility numbers have been normalized in 206 Fig. 3b. This clearly shows the flat mobility-EOT behavior for the superlattice gate stack compared 207 to the falling of trend for conventional gate stacks due to scavenging in the low EOT range. 

208 To examine how the capacitance enhancement behaves at high frequency, radio frequency 209 (RF) measurements were performed on the same long channel (LG = 1 µm) devices (Methods, 210 Extracted Data Fig. 9). This allows one to extract device parameters up to ∼ 800 MHz for our 211 devices (close to the cut-off frequency). Of particular interest is the transconductance (gm) which 212 is proportional to the product of capacitance and electron velocity (mobility). From Y -parameter 213 measurements one can find AC transconductance as Re(Y21) = gm +af<sup>2</sup> , where f is the frequency 214 (Methods). This yields an AC transconductance as a function of applied gate voltage (VG). This 215 dependence is plotted together with DC transconductance (∂ID/∂VG from DC ID-VG) (Fig. 3c). 216 We find that DC and AC transconductance are similar with AC transconductance roughly 15% 217 larger at the peak value. We hypothesize that this slightly large AC transconductance results from 218 the fact that certain interface traps, which affect the DC behavior, cannot respond at frequencies 

9 

219 larger than 100 MHz, leading to better gate control. More importantly, these results show that the 220 capacitance enhancement is not limited to the low frequency regime<sup>44–46</sup> . 

221 Finally, to test the ON current capability, a LG = 90 nm device was fabricated on a SOI 222 transistor with 18 nm SOI thickness and the superlattice gate stack. The transfer and output char223 acteristic of a typical transistor are shown in Fig. 3d,e. Note that the threshold voltage of this 224 device is 0.55 V which is consistent with the workfunction of W used as the gate metal. Because 225 of this, the transistors have been driven up to 1.6 V gate voltage so that an overdrive voltage (Vov 226 = VG - VT ) of ∼1 V can be applied. It is found that at a drain voltage (VD) and Vov of 1 V, the 227 drain current exceeds 1 mA/µm. In addition, as shown in Fig. 3f, the measured extrinsic transcon228 ductance is ∼1.1 mS/µm which gives an intrinsic transconductance of ∼1.75 mS/µm (Methods, 229 Extended Data Fig. 10). These values of ON current and transconductance are substantially larger 230 than a conventional 90 nm transistor and is a result of the large capacitance provided by the super231 lattice gate stack and the fact that the low EOT resulting from the stack does not adversely affect 232 the electron transport. 

233 With the superlattice gate stack demonstrated in integrated Si devices, we now come back to 234 the capacitance enhancement observed in this gate stack. We have already discussed how the mixed 235 FE-AFE order facilitates a flatter energy landscape where the negative curvature of the FE phase is 236 compensated by the positive curvature of the AFE phase (Fig. 1a). Notably when the mixed ferroic 237 oxide is grown on an SiO2 interlayer, it can lead to similar compensation again. As we have seen 238 from thicker FE-AFE superlattice MIM capacitors, some hysteresis still remains, which manifests 239 at large voltages, indicative of a negative curvature regime still persisting in the superlattices. The 240 interfacial DE SiO2 can flatten out that energy landscape even further, thus leading to enhanced 241 capacitance. This is similar to the negative capacitance and resultant capacitance enhancement 242 observed in FE-DE series combinations<sup>22</sup> . To supplement the C-V evidence of capacitance en243 hancement (Fig. 2f), pulsed electrical measurements of the superlattice gate stack MOS capacitors 244 – which can quantify the amount of stored charge as a function of voltage<sup>47</sup> (Methods) – demon245 strate larger stored charge than if just interfacial SiO2 was sitting on top of Si, providing further 

10 

246 evidence of negative capacitance<sup>47</sup> in the gate stack (Extended Data Fig. 10). Note that previous 247 studies have shown that negative capacitance stabilization is favored under states of high suscep248 tibility<sup>39,40,48</sup> . Here, the competing ferroic order in HfO2-ZrO2 multilayers substantially increases 249 its susceptibility and is thus expected to facilitate negative capacitance behavior when placed on 250 top of the interfacial SiO2. 

251 Capacitance enhancement has been demonstrated in single-crystalline, perovskite-structure 252 ferroelectric-dielectric superlattices by many groups<sup>38–41</sup> . This work demonstrates that the same 253 enhancement is possible in HfO2-ZrO2 fluorite-structure superlattices exhibiting mixed ferroelectric254 antiferroelectric order in films as thin as just ∼ 2 nm. The ability to control ferroic order in 255 such ultrathin films is of critical importance for advanced electronic devices considering previous 256 studies have shown that negative capacitance can be stabilized under states of high susceptibil257 ity<sup>39,40</sup> . Furthermore, this work establishes the critical role of atomic-layer stacking – as opposed 258 to conventional doping techniques<sup>23,35</sup> – in controlling the ferroic phase space and permittivity of 259 fluorite-structure oxides down to ultrathin limits, leveraging its unique size effects<sup>13–15,49</sup> and rich 260 antiferroelectric-ferroelectric polymorphs<sup>36,50</sup> . When this mixed phase HfO2-ZrO2 multilayer is 261 integrated on Si, the gate stack exhibits a capacitance enhancement, lowering the EOT below the 262 thickness of SiO2 itself, which would not be possible with a conventional dielectric. Notably, the 263 lowest EOT achieved (6.5 Å) for the gate stack and interfacial SiO2 together is lower than that 264 used in the most advanced Si transistors today. Therefore, this work demonstrates that harnessing 265 atomic-scale layering in ultrathin HfO2-ZrO2 ferroic gate oxides presents a promising materials de266 sign platform for future Si transistors beyond conventional high-κ dielectrics<sup>3</sup> which have enabled 267 the semiconductor industry over the past two decades. 

11 

- 269 1. Theis, T. N. & Wong, H.-S. P. The End of Moore’s Law: A New Beginning for Information 268 270 Technology. Computing in Science & Engineering 19, 41–50 (2017). 

- 271 2. Schlom, D. G., Guha, S. & Datta, S. Gate Oxides Beyond SiO2. MRS Bulletin 33, 1017–1025 272 (2008). 

- 273 3. Ando, T. Ultimate Scaling of High-κ Gate Dielectrics: Higher-κ or Interfacial Layer Scaveng274 ing? Materials 5, 478–500 (2012). 

- 275 4. Salahuddin, S., Ni, K. & Datta, S. The era of hyper-scaling in electronics. Nature Electronics 276 1, 442–450 (2018). 

- 277 5. Shulaker, M. M. et al. Three-dimensional integration of nanotechnologies for computing and 278 data storage on a single chip. Nature 547, 74–78 (2017). 

- 279 6. Wong, H.-S. & Salahuddin, S. Memory leads the way to better computing. Nature Nanotech280 nology 10, 191–194 (2015). 

- 281 7. Del Alamo, J. A. Nanometre-scale electronics with III–V compound semiconductors. Nature 282 479, 317–323 (2011). 

- 283 8. Butler, S. Z. et al. Progress, challenges, and opportunities in two-dimensional materials be284 yond graphene. ACS Nano 7, 2898–2926 (2013). 

- 285 9. Khan, A. I., Keshavarzi, A. & Datta, S. The future of ferroelectric field-effect transistor 286 technology. Nature Electronics 3, 588–597 (2020). 

- 287 10. Dutta, S. et al. Monolithic 3D Integration of High Endurance Multi-Bit Ferroelectric FET 288 for Accelerating Compute-In-Memory. In 2020 IEEE International Electron Devices Meeting 289 (IEDM), 36.4.1–36.4.4 (IEEE, 2020). 

- 290 11. Salahuddin, S. & Datta, S. Use of Negative Capacitance to Provide Voltage Amplification for 291 Low Power Nanoscale Devices. Nano Letters 8, 405–410 (2008). 

- 292 12. Böscke, T. S., Müller, J., Bräuhaus, D., Schröder, U. & Böttger, U. Ferroelectricity in hafnium 293 oxide thin films. Applied Physics Letters 99, 102903 (2011). 

12 

- 294 13. Cheema, S. S. et al. Enhanced ferroelectricity in ultrathin films grown directly on silicon. 295 Nature 580, 478–482 (2020). 

- 296 14. Lee, H.-J. et al. Scale-free ferroelectricity induced by flat phonon bands in HfO2. Science 369, 297 1343–1347 (2020). 

- 298 15. Noheda, B. & Iniguez, J. A key piece of the ferroelectric hafnia puzzle. Science 369, 1300– 299 1301 (2020). 

- 300 16. Ando, T. et al. Understanding mobility mechanisms in extremely scaled HfO2 (EOT 0.42 301 nm) using remote interfacial layer scavenging technique and Vt-tuning dipoles with gate-first 302 process. In 2009 IEEE International Electron Devices Meeting (IEDM), 1–4 (IEEE, 2009). 

- 303 17. Wong, H. & Iwai, H. On the scaling of subnanometer EOT gate dielectrics for ultimate nano 304 CMOS technology. Microelectronic Engineering 138, 57–76 (2015). 

- 305 18. Huang, J. Gate first high-k/metal gate stacks with zero SiOx interface achieving EOT=0.59nm 306 for 16nm application. In 2009 Symposium on VLSI Technology (2009). 

- 307 19. Yeo, Y.-C., King, T.-J. & Hu, C. Direct tunneling leakage current and scalability of alternative 308 gate dielectrics. Applied Physics Letters 81, 2091–2093 (2002). 

- 309 20. Barraud, S., Thevenod, L., Cassé, M., Bonno, O. & Mouis, M. Modeling of remote Coulomb 310 scattering limited mobility in MOSFET with HfO2/SiO2 gate stacks. Microelectronic Engi311 neering 84, 2404–2407 (2007). 

- 312 21. Ota, H. et al. Intrinsic Origin of Electron Mobility Reduction in High-k MOSFETs - From 313 Remote Phonon to Bottom Interface Dipole Scattering. In 2007 IEEE International Electron 314 Devices Meeting, 65–68 (IEEE, 2007). 

- 315 22. Khan, A. et al. Experimental evidence of ferroelectric negative capacitance in nanoscale het316 erostructures. Applied Physics Letters 99, 113501 (2011). 

- 317 23. Müller, J. et al. Ferroelectricity in Simple Binary ZrO2 and HfO2. Nano Letters 12, 4318–4323 318 (2012). 

13 

- 319 24. Lakes, R. S., Lee, T., Bersie, A. & Wang, Y. C. Extreme damping in composite materials with 320 negative-stiffness inclusions. Nature 410, 565–567 (2001). 

- 321 25. Jaglinski, T., Kochmann, D., Stone, D. & Lakes, R. S. Composite Materials with Viscoelastic 322 Stiffness Greater Than Diamond. Science 315, 620–622 (2007). 

- 323 26. Park, M. H. et al. Morphotropic Phase Boundary of Hf1˘xZrxO2 Thin Films for Dynamic 324 Random Access Memories. ACS Applied Materials & Interfaces 10, 42666–42673 (2018). 

- 325 27. Ni, K. et al. Equivalent Oxide Thickness (EOT) Scaling With Hafnium Zirconium Oxide 326 High-κ Dielectric Near Morphotropic Phase Boundary. In 2019 IEEE International Electron 327 Devices Meeting (IEDM), 7.4.1–7.4.4 (IEEE, 2019). 

- 328 28. Mehmood, F., Mikolajick, T. & Schroeder, U. Lanthanum doping induced structural changes 329 and their implications on ferroelectric properties of Hf1˘xZrxO2 thin film. Applied Physics 330 Letters 117, 092902 (2020). 

- 331 29. Das, D. & Jeon, S. High-κ HfxZr1−xO2 Ferroelectric Insulator by Utilizing High Pressure 332 Anneal. IEEE Transactions on Electron Devices 67, 2489–2494 (2020). 

- 333 30. Kim, S. et al. Method to Achieve the Morphotropic Phase Boundary in HfxZr1−xO2 by Electric 334 Field Cycling for DRAM Cell Capacitor Applications. IEEE Electron Device Letters 42, 517– 335 520 (2021). 

- 336 31. Budimir, M., Damjanovic, D. & Setter, N. Piezoelectric response and free-energy instability 337 in the perovskite crystals BaTiO3, PbTiO3, and Pb(Zr, Ti)O3. Physical Review B 73, 174106 338 (2006). 

- 339 32. Fu, H. & Cohen, R. E. Polarization rotation mechanism for ultrahigh electromechanical re340 sponse in single-crystal piezoelectrics. Nature 403, 281–283 (2000). 

- 341 33. Ahart, M. et al. Origin of morphotropic phase boundaries in ferroelectrics. Nature 451, 545– 342 548 (2008). 

14 

- 343 34. Noheda, B. et al. A monoclinic ferroelectric phase in the Pb(Zr1−xTix)O3 solid solution. 344 Applied Physics Letters 74, 2059–2061 (1999). 

- 345 35. Schroeder, U. et al. Recent progress for obtaining the ferroelectric phase in hafnium ox346 ide based films: impact of oxygen and zirconium. Japanese Journal of Applied Physics 58, 347 SL0801 (2019). 

- 348 36. Materlik, R., Künneth, C. & Kersch, A. The origin of ferroelectricity in Hf1−xZrxO2: A 349 computational investigation and a surface energy model. Journal of Applied Physics 117, 350 134109 (2015). 

- 351 37. Bergeron, H., Lebedev, D. & Hersam, M. C. Polymorphism in Post-Dichalcogenide Two352 Dimensional Materials. Chemical Reviews 121, 2713–2775 (2021). 

- 353 38. Gao, W. et al. Room-Temperature Negative Capacitance in a Ferroelectric–Dielectric Super354 lattice Heterostructure. Nano Letters 14, 5814–5819 (2014). 

- 355 39. Zubko, P. et al. Negative capacitance in multidomain ferroelectric superlattices. Nature 534, 356 524–528 (2016). 

- 357 40. Yadav, A. K. et al. Spatially resolved steady-state negative capacitance. Nature 565, 468–471 358 (2019). 

- 359 41. Das, S. et al. Local negative permittivity and topological phase transition in polar skyrmions. 360 Nature Materials 20, 194–201 (2021). 

- 361 42. Íñiguez, J., Zubko, P., Luk’yanchuk, I. & Cano, A. Ferroelectric negative capacitance. Nature 362 Reviews Materials 4, 243–256 (2019). 

- 363 43. Schlom, D. G. & Haeni, J. H. A Thermodynamic Approach to Selecting Alternative Gate 364 Dielectrics. MRS Bulletin 27, 198–204 (2002). 

- 365 44. Chatterjee, K., Rosner, A. J. & Salahuddin, S. Intrinsic speed limit of negative capacitance 366 transistors. IEEE Electron Device Letters 38, 1328–1330 (2017). 

15 

- 367 45. Kwon, D. et al. Response Speed of Negative Capacitance FinFETs. 2018 IEEE Symposium 368 on VLSI Technology 49–50 (2018). 

- 369 46. Alam, M. A., Si, M. & Ye, P. D. A critical review of recent progress on negative capacitance 370 field-effect transistors. Applied Physics Letters 114, 090401 (2019). 

- 371 47. Hoffmann, M. et al. Unveiling the double-well energy landscape in a ferroelectric layer. 372 Nature 565, 464–467 (2019). 

- 373 48. Wong, J. C. & Salahuddin, S. Negative Capacitance Transistors. Proceedings of the IEEE 374 107, 49–62 (2019). 

- 375 49. Wei, Y. et al. A rhombohedral ferroelectric phase in epitaxially strained Hf0.5Zr0.5O2 thin 376 films. Nature Materials 17, 1095–1100 (2018). 

- 377 50. Reyes-Lillo, S. E., Garrity, K. F. & Rabe, K. M. Antiferroelectricity in thin-film ZrO2 from 378 first principles. Physical Review B 90, 140103 (2014). 

16 

379 



380 Fig. 1. Atomic-scale design of negative capacitance in ultrathin HfO2-ZrO2. (a) Phenomeno- 

381 logical model of negative capacitance (NC) in a mixed ferroic system. Landau free energy land382 scapes for a FE, AFE, and mixed FE-AFE system (Methods). Mixed FE-AFE phase competition 383 should suppress polarization<sup>48</sup> and enhance electric susceptibility<sup>22,40</sup> via proximity to a phase 384 boundary, and flattens the energy landscape, desirable traits for NC stabilization. The stable en385 ergy minimum of the composite free energy landscape, corresponding to the negative curvature 386 (NC) regime of the ferroelectric energy landscape, is highlighted. (b) Engineering ferroic phase 387 competition in the HfO2-ZrO2 fluorite-structure system. Beyond the conventionally-studied tuning 388 parameters – composition, electric field, temperature<sup>23,35</sup> – here we introduce dimensional confine389 ment via superlattice layering to tailor ferroic phase competition at the atomic-scale. (c) Schematic 390 of the HfO2-ZrO2 fluorite-structure multilayer on Si; the heterostructures maintain distinct layers 391 (i.e. not solid solution alloys) based on EELS, XRR, and depth-resolved XPS (Extended Data Fig. 392 1). The role of the layering on the underlying ferroic order and capacitance is studied by electrical 

17 

393 measurements as a function of HfO2-ZrO2 stacking structure and annealing temperature (Extended 394 Data Fig. 4 and 5, respectively). (d) HR-TEM image of the atomic-scale HfO2-ZrO2-HfO2 trilayer 395 (top) and extracted d-lattice spacings (bottom) corresponding to the fluorite-structure AFE tetrago396 nal (P42/nmc, red) and FE orthorhombic (Pca21, blue) phases, respectively. The layer delineations 397 are approximate, as the HfO2-ZrO2 and SiO2 interlayer thicknesses are more rigorously deter398 mined by XRR and TEM analysis (Extended Data Fig. 1 and 6, respectively). Note imaging the 399 crystallinity of the HfO2-ZrO2 layers requires mistilt with respect to the Si lattice (Methods). (e) 400 Synchrotron IP-GiD demonstrating the presence of both the AFE T -phase (101)t and FE O-phase 401 (111)o reflections whose d-lattice spacings are consistent with those extracted from TEM. Detailed 402 indexing to higher-order reflections for structural identification of the ferroic phases is provided 403 by wide-angle synchrotron diffraction (Extended Data Fig. 2a). Further evidence of inversion 404 symmetry breaking is provided by second harmonic generation and synchrotron linear dichroism 405 (Extended Data Fig. 2c,d). Additionally, the evolution between these two ferroic phases are also 406 studied as a function of temperature (Extended Data Fig. 3). 

18 

407 



408 Fig. 2. Enhanced capacitance in ultrathin HfO2-ZrO2 mixed-ferroic heterostructures. (a) 

409 MIM C-V hysteresis loops for a mixed FE-AFE HfO2-ZrO2 multilayer demonstrating higher ca410 pacitance compared against its AFE (ZrO2) and FE (Zr:HfO2) counterparts of the same thickness. 411 (b) Inverse capacitance versus thickness of the MIM HfO2-ZrO2 multilayers up to 5 superlattice 412 repeats (10 nm), with an extracted permittivity of 52 (Methods), extremely large for HfO2-based 413 oxides. (c) MIM C-V hysteresis loops for HfO2-ZrO2 multilayers of the same periodicity demon414 strating an evolution from mixed-ferroic to FE-like hysteresis upon cooling slightly below room 415 temperature. The proximity to the temperature-dependent phase transition (Extended Data Fig. 416 3) suggests the HfO2-ZrO2 heterostructures lies near its maximum electric susceptibility position, 417 ideal for negative capacitance stabilization<sup>40,48</sup> . (d) MOS accumulation C-V of HfO2-ZrO2-HfO2 418 trilayer compared to AFE ZrO2, FE Zr:HfO2, and DE HfO2, all of the same thickness (20 Å), indi419 cating mixed-ferroic behavior is optimal for enhancing capacitance rather than purely FE or AFE 420 behavior. (e) Accumulation C-V of the HfO2-ZrO2-HfO2 trilayer compared to bilayer and solid so421 lutions films of the same thickness (ALD cycles) and composition (Hf:Zr cycles). Inset: Schematic 422 of multilayer (Hf and Zr cations vertically separated) versus solid solution (Hf and Zr cations inter- 

19 

- 423 mixed). These results suggest the capacitance enhancement in multilayer films is not simply driven 424 by Hf:Zr composition<sup>23,35</sup> , but instead the atomic-scale stacking (Extended Data Fig. 4, 5). (f) Ac425 cumulation C-V curves for a 2 nm HfO2-ZrO2-HfO2 trilayer grown on sub-nm SiO2 fit to effective 426 oxide thickness (EOT) simulations (Methods). Inset: Externally verified MOS accumulation C- 427 V of the same trilayer stack (Methods), demonstrating 6.5 Å EOT. The 2 nm trilayer on top of 428 SiO2 demonstrates lower EOT than the thickness of SiO2 interlayer alone, carefully extracted via 429 physical (8.5 Å) and electrical (8.0 Å) methodologies (Extended Data Fig. 6), providing evidence 430 of capacitance enhancement. Furthermore, these 2 nm ferroic gate stacks demonstrate amplified 431 charge from pulsed I-V measurements relative to the SiO2 interlayer (Extended Data Fig. 10). 432 Notably, this 2 nm HfO2-ZrO2 multilayer on sub-nm SiO2 provides the most scaled demonstration 433 of charge and capacitance enhancement at the capacitor-level (Extended Data Fig. 10). 

20 

434 



435 Fig. 3. Device performance benefits utilizing ultrathin mixed-ferroic HfO2-ZrO2 gate stacks. 436 (a) Leakage-effective oxide thickness (JG-EOT) scaling of the multilayer gate stacks (black) bench437 marked against reported HKMG literature<sup>3</sup> , including interlayer-scavenged 2 nm HfO2 (red), high438 κ doped HfO2 (blue), and SiO2/poly-Si (gray). The leakage is the lowest reported for a 6.5-7.0 Å 439 EOT MOS capacitor on silicon<sup>3</sup> , due to the EOT reduction without requiring interlayer SiO2 thick440 ness reduction. (b) Normalized mobility versus EOT scaling of the multilayer gate stacks (black) 441 benchmarked against reported HKMG literature<sup>3</sup> , including interlayer-scavenged 2 nm HfO2 (red) 442 and hybrid silicate-scavenged interlayer (magenta). For EOT scaling in conventional HKMG sys443 tems, the SiO2 interlayer has to be reduced to lower EOT, which leads to degraded mobility<sup>3</sup> . In 444 this case, enhanced capacitance in HfO2-ZrO2 multilayers achieves scaled EOT without having 445 to thin the SiO2 interlayer; therefore, mobility is not degraded. Inset: SiO2 interlayer thickness 446 versus EOT scaling comparing the 7.0 Å EOT HfO2-ZrO2-HfO2 trilayer against notable HKMG 447 literature which employ interlayer scavenging to reduce EOT<sup>3</sup> . This scatter plot highlights the un448 derlying reason for the enhanced leakage-EOT and mobility-EOT behavior in the ultrathin trilayer 449 gate stacks: low EOT without reduced SiO2 interlayer thickness. (c) Transconductance (gm) versus 

21 

- 450 gate voltage (VG) for long-channel bulk transistors (LG = 1 µm) obtained from both DC (derivative 451 of ID-VG) and RF (Re[Y21]) measurements (Methods) at VDS = 1 V. Inset: De-embedded Re[Y21] 452 (open circles) as a function of squared frequency at different DC VGS bias points extrapolated to 453 the zero frequency limit (dotted lines) to extract the RF gm (Extended Data Fig. 8). The high454 frequency measurements help suppress defect contributions which would otherwise dampen the 455 intrinsic gm. (d, e, f) DC I-V transfer characteristics (ID-VG, d), DC output characteristics (ID-VD, 456 e), and DC transconductance (gm-VG, f) for short-channel (LG = 90 nm) SOI transistors. Notably, 457 the maximum on-current and gm at VDS = 1 V exceeds 1 mA/µm and 1 mS/µm. DC mobility 458 and transconductance values are carefully extracted after de-embedding the series resistance from 459 double-swept I-V measurements (Extended Data Fig. 7 and 9, respectively). 

22 

# 460 Methods 

# 461 Gate stack 

462 Gate oxide Thin films of HfO2-ZrO2 were grown by atomic layer deposition (ALD) in a 463 Fiji Ultratech/Cambridge Nanotech tool (U.C. Berkeley) at 270°C in which tetrakis (ethylmethy464 lamino) hafnium and tetrakis (ethylmethylamino) zirconium precursors are heated to 75°C and 465 water vapor is used as the oxidant. For metal-ferroelectric-insulator-semiconductor (MFIS) capac466 itor structures, sub-nm chemically-grown SiO2 on lightly-doped Si (10<sup>15</sup> cm<sup>−3</sup> ) was prepared by 467 the standard clean (SC-1) solution (5:1:1 H2O:H2O2:NH4OH at 80°C for 10 minutes) after the Si 468 wafer was cleaned in Piranha (120°C for 10 minutes) to remove organics and HF (50:1 H2O:HF 469 at room temperature for 30 s) to remove any native oxide. Subsequently, HfO2-ZrO2 multilayers 470 are deposited at 270°C by ALD. After ALD deposition, post-deposition annealing (PDA) was per471 formed at 175°C (20 min, forming gas N2/H2 background) to help cure the SiO2-oxide interface. 472 For confirmation and reproducibility, HfO2-ZrO2 multilayers of the same ALD cycling were also 473 deposited at MIT Lincoln Laboratory (MIT LL); after ALD deposition, PDA was performed at 474 250°C (1 min, N2 background). 

475 Gate metal For UC Berkeley capacitors, the first layer of the gate metal, TiN, is deposited 476 by ALD (250°C, 20 cycles, 15 Å) in N2 and H2 plasma. Subsequently, W is deposited by sputtering 477 (room temperature, 60 nm). For MIT LL capacitors, the gate metal, TiN, is deposited by PVD 478 (room temperature). 

479 Annealing The entire gate stack undergoes a low-temperature post-metal anneal (200 C, 480 1 min, N2) to cure interface defects. This low temperature does not interfere with the HfO2481 ZrO2 multilayer structure, as confirmed by various characterization techniques (Extended Data 482 Fig. 1), and maintains the mixed ferroic behavior, as high-temperature annealing would induce 483 purely ferroelectric behavior (Extended Data Fig. 5). X-ray diffraction and TEM confirm the 

23 

484 presence of crystalline ultrathin films despite the low deposition temperature, afforded by the low 485 crystallization temperature of ZrO2<sup>51</sup> . In fact, non-post-annealed ALD-grown ZrO2 has previously 486 demonstrated crystallization into the ferroelectric orthorhombic phase on Si<sup>52</sup> . 

## 487 

# Device fabrication 

488 MOS and MIM capacitors, Bare Structures For MOS capacitor structures, after gate 489 stack deposition, top electrodes are defined by photolithography and dry etching. For bare struc490 tures (structural studies), the top metal is removed by chemical etching to expose the gate oxide 491 surface. For metal-insulator-metal (MIM) capacitors, W is deposited by sputtering (room temper492 ature, 30 nm) on a lightly-doped Si substrate as the bottom metal electrode. After ferroic film 493 deposition by ALD, 60 nm of W is deposited by sputtering. The top electrodes are then again 494 defined by photolithography and dry etching. 

495 Bulk transistors The n-type bulk transistors were fabricated by a non-self-aligned gate496 last process on bulk silicon wafers (10<sup>17</sup> cm<sup>−3</sup> ) with local oxidation of silicon (LOCOS) as device 497 isolation technique. First, a 10 nm of SiO2 thermal oxide and a 30 nm of low-pressure chemical 498 vapor deposition (LPCVD) Si3N4 were grown on the Si substrates. After the active region was 499 defined by photolithography and Si3N4/SiO2 etching, dry oxidation was performed to form the 500 LOCOS isolation. Next, the source/drain regions were defined by photolithography and ion im501 plantation with an ion dose of 3×10<sup>15</sup> ions/cm<sup>2</sup> . The dopants were then activated by a rapid thermal 502 anneal (RTA) at 900°C for 7 min in N2 ambient. The gate stacks with the sub-nm chemically-grown 503 SiO2, 2 nm HfO2-ZrO2 heterostructure, and 100 nm of sputtered W gate were then deposited. Af504 ter the gate fingers (from 500 nm to 50 µm) were patterned by photolithography and etched by 505 inductively-coupled plasma (ICP) metal etching, the 400 nm thick interlayer dielectric (ILD) SiO2 506 was deposited using plasma-enhanced CVD (PECVD). Last, after the contact hole opening, the 507 Ti/TiN contact metal was deposited by sputtering, defined by photolithography, and then etched by 508 ICP metal etching. 

24 

509 Short-channel SOI Transistors The n-type short-channel transistors were fabricated by a 510 non-self-aligned gate-last process on SOI substrates with a gate length (LG) down to 90 nm. First, 511 the device layer was thinned down to 20 nm and the active regions were defined by photolithogra512 phy with expose regions etched slightly into the buried oxide. The hydrogen silsequioxane (HSQ) 513 negative resist were written by e-beam lithography as a hard mask for the ion implantation with a 514 dose of 5×10<sup>15</sup> ions/cm<sup>2</sup> . The dopant activation was conducted in an RTA at 900°C for 15 seconds 515 in N2 ambient. The gate stacks with the sub-nm chemically-grown SiO2, 2 nm HfO2-ZrO2 het516 erostructure, 1.5 nm of PEALD TiN, and 100 nm of sputtered W were sequentially deposited. The 517 gate region (250 nm) was then patterned by photolithography. Like the back-end process for the 518 bulk transistors, a 400 nm of ILD and a sputtered Ti/TiN contact metal were deposited and defined 519 by photolithography and ICP etching. 

## 520 

# Microscopy 

521 Transmission electron microscopy Electron microscopy was performed at the National 522 Center for Electron Microscopy (NCEM) facility of the Molecular Foundry at Lawrence Berkeley 523 National Laboratory (LBNL). The high-resolution bright field TEM images of HfO2-ZrO2 thin 524 films were performed by FEI ThemIS 60-300 microscope with image aberration corrector operated 525 at 300 kV (Fig. 1d, Extended Data Fig. 2e,f). To prepare cross-sectional TEM samples of HfO2526 ZrO2 thin films, mechanical polishing was employed by using an Allied High Tech Multiprep at 527 a 0.5° wedge to thin down the total thickness of samples down to 10 µm. Later, Ar ion milling 528 of the Gatan Precision Ion Milling System was utilized to make an electron-transparent sample, 529 starting from 4 keV down to 200 eV as final cleaning energy. For high-resolution imaging, in order 530 to capture the crystallinity of the HfO2-ZrO2 layers, the zone axis alignment required varying 531 degrees of mistilt with respect to the Si lattice, explaining the slightly obscured Si atomic columns 532 (Fig. 1d, Extended Data Fig. 2e,f). 

533 The local interplanar d-spacing in the ultrathin HfO2-ZrO2 films (Extended Data Fig. 2e,f) 534 was measured by DigitalMicrograph software using its line profile plus integration width analy- 

25 

535 sis. For the 2 nm HfO2-ZrO2-HfO2 multilayer film, the extracted interplanar lattice spacings were 536 averaged over multiple lattice periodicities and confirmed across various local regions of the film 537 (Extended Data Fig. 2e,f). The SiO2 interlayer thickness from low-magnification wide field-of538 view (FoV) imaging was determined by the same method (Extended Data Fig. 6a). In particular, 539 the intensity line scan from the wide FoV image (Extended Data Foig. 6a) is obtained from averag540 ing across the entire FoV specified by the teal-colored box (∼ 150 nm). Next, the inflection points 541 of the intensity peak were used as the criteria to set the boundaries of the SiO2 interlayer (Extended 542 Data Fig. 6a). This methodology was also utilized to determine the boundaries of the HfO2-ZrO2 543 layers from the EELS spectrum (Extended Data Fig. 1c). Regarding the wide FoV cross-sectional 544 TEM (Extended Data Fig. 6a), both the low atomic weight and lack of crystallinity of the SiO2 545 layer contribute to its weak scattering (bright color), which aids in the visual delineation of the 546 layer boundaries and the thickness extraction from the corresponding averaged intensity line scan. 

547 Optical microscopy Second harmonic generation (SHG) measurements (Extended Data 548 Fig. 2d) were performed with a Ti:sapphire femtosecond laser (Tsunami, Spectra Physics, λ ∼ 800 549 nm, frequency ∼ 80 MHz). The linearly polarized femtosecond laser beam was focused through 550 50X objective lens (NA ∼ 0.42) which results in a focal spot size of 2 µm. The generated SHG 551 signal was collected through the same objective lens and separated from the fundamental beam by 552 the harmonic separator. After passing through the optical bandpass filter, the SHG signals were 553 registered to the photon multiplier tube (PMT) without a polarizer. The fundamental beam was 554 mechanically chopped, and the signal collected by the PMT was filtered by a lock-in amplifier 555 to reduce the background noise. For SHG spatial mapping, a two-axis piezo stage was utilized 556 and the coordinate was synchronized with the PMT signal. The SHG intensity was obtained by 557 averaging the mapping signals across a 100 µm × 100 µm sample area. 

558 

# X-ray characterization 

26 

559 X-ray reflectivity Synchrotron X-ray reflectivity (XRR) – performed at Sector 33-BM-C 560 beamline of the Advanced Photon Source, Argonne National Laboratory and at Beamline 2-1 of the 561 Stanford Synchrotron Radiation Lightsource, SLAC National Accelerator Laboratory – confirmed 562 the thickness of HfO2-ZrO2 heterostructures (Extended Data Fig. 1b). The overall thickness of 563 the HfO2-ZrO2 heterostructures is consistent with the growth rate (∼ 1 Å/cycle) of ALD-grown 564 Zr:HfO2 as demonstrated in our previous work<sup>13</sup> . Furthermore, the presence of irregularly spaced 565 fringes in the thicker HfO2-ZrO2 heterostructures suggests the presence of well-separated HfO2566 ZrO2 layers, i.e. not a solid solution. This is confirmed by XRR fitting (Extended Data Fig. 1b) 567 performed with the python package GenX<sup>53</sup> which considers factors such as density, roughness, 568 and thickness. 

569 Grazing incidence diffraction: in-plane Synchrotron in-plane grazing-incidence diffrac570 tion (GID) (Fig. 1e and Extended Data Fig. 2a) was performed at Sector 33-ID-D beamline of 571 the Advanced Photon Source, Argonne National Laboratory. A Pilatus-II 100K Area Detector 572 mounted on the del-arm was used to collect diffraction signal with a grazing incidence geometry. 573 The region-of-interest on the detector was set such that the ring-like signal was fully integrated. In574 plane GID was collected by sweeping the in-plane angle ν (8-50°) with a fixed out-of-plane grazing 575 angle δ (δ = 0.9°); the corrected Bragg angle (2θ) over which the data is plotted and indexed is de576 termined from the relationship cos 2θ = cos ν · cos δ set by the geometry of the diffractometer. 577 The X-ray source was fixed at 16 keV (λ = 0.775 Å). In-plane diffraction yields more diffraction 578 peaks with better defined width, likely due to the preferred orientation and disc-shape domains in 579 the film. Therefore, in-plane GID enables clear indexing to the ferroelectric orthorhombic (Pca21) 580 and antiferroelectric tetragonal (P42/nmc) fluorite structure in the ultrathin HfO2-ZrO2 films, as 581 the presence of many reflections from the in-plane GID spectra (Fig. 1e, Extended Data Fig. 2a) 582 allow for clear distinction from other nonpolar fluorite-structure polymorphs. Such diffraction 583 spectra would be otherwise prohibited in typical out-of-plane geometry due to the lack of vertical 584 diffraction planes and the large linewidth inherent to ultrathin films. 

27 

585 Two-dimensional diffraction Two-dimensional reciprocal space maps (Extended Data Fig. 586 2b) were measured at Beamline 11-3 of the Stanford Synchrotron Radiation Lightsource, SLAC 587 National Accelerator Laboratory. Rayonix MX225 CCD area detector collected diffraction flux in 588 gazing incidence (< 0.20°) geometry; the X-ray source (50 microns vertical x 150 microns hor589 izontal beam size) was fixed at 12.7 keV. The sample-detector work distance was set to 80 mm 590 to enable detection of a wide region of reciprocal space (Q-range 0.2 to 5 Å−1) at the expense of 591 reciprocal space resolution, set by the pixel size. The two-dimensional diffraction scans – in which 592 a wide portion of the entire reciprocal space was collected simultaneously, rather than at discrete 593 regions in Qx-Qy space – were averaged over data collection time and for repeated scans. These 594 measurement features, in tandem with the high X-ray flux afforded by the synchrotron source, en595 abled sufficient diffraction signal detection and contrast in films just two nanometers in thickness. 596 Data analysis was performed Nika, an Igor Pro package for correction, calibration and reduction of 597 two-dimensional areal maps into one-dimensional data<sup>54</sup> . Two-dimensional reciprocal space maps 598 on bare HfO2-ZrO2 heterostructures confirm the presence of crystalline ultrathin films despite the 599 low deposition temperature, afforded by the low crystallization temperature of ZrO2 on Si<sup>51</sup> . 

600 Ferroic phase identification from diffraction For fluorite-structure thin films, the main 601 phases to consider are the dielectric monoclinic (P21/c), antiferroelectric tetragonal (P42/nmc), 602 and ferroelectric orthorhombic (Pca21) phases. Various diffraction reflections from the wide-angle 603 IP-GiD spectra enable indexing to the orthorhombic Pca21 phase. Lattice parameters (a, b, c) 604 – determined via Bragg’s law from the d200 family of reflections – are self-consistently checked <mark>1 1</mark> 605 against the (111) lattice spacing d<sup>2</sup> 111<sup>=</sup> a<sup>2</sup><sup><mark>+</mark></sup> b<sup><mark>1</mark>2</sup><sup><mark>+</mark></sup> c<sup><mark>1</mark>2as well as other higher-order reflections present</sup> 606 in the in-plane diffraction spectra (Extended Data Fig. 2a). For example, the lattice parameters 607 extracted from the {200} peaks were a = 5.36 Å, b = 5.23 Å, and c = 5.47 Å. This corresponds to a 608 d211 lattice spacing of 2.209 Å, which agrees well with the lattice spacing (2.205 Å) obtained from 609 Bragg’s law based on the peak position (Extended Data Fig. 2a) 

610 The monoclinic phase was ruled out due to a lack of two {111} peaks in the diffraction spec611 tra and the (111)o and (101)t reflections being significantly offset from its expected peak position 

28 

612 in the monoclinic phase. With regards to the indexing of tetragonal (101)−t peak (Extended Data 613 Fig. 2a), it is always reported that the tetragonal (101)t reflection has a smaller d-spacing<sup>55</sup> in 614 thicker HfO2-based films<sup>28</sup> , and is therefore expected to be present at a higher angle compared to 615 the orthorhombic (111)0 reflection, which is the case in the indexed diffraction spectra (Extended 616 Data Fig. 2a) based on the self-consistent indexing methodology outlined above provides. 

617 In terms of extracting the phase fraction of the tetragonal and orthorhombic phases, while 618 Rietveld refinement has been applied to grazing incidence x-ray diffraction of thick (10 nm) 619 Zr:HfO2<sup>56</sup> to determine the orthorhombic phase fraction, that methodology cannot be applied in 620 the ultrathin regime, as the films are highly oriented, as opposed to fully polycrystalline (Extended 621 Data Fig. 2b), which is a requirement to apply Rietveld refinement. 

622 X-ray absorption spectroscopy Hard and soft synchrotron X-ray spectroscopy (Extended 623 Data Fig. 2c) was measured at beamline 4-ID-D of the Advanced Photon Source, Argonne Na624 tional Laboratory and Beamline 4.0.2. of the Advanced Light Source, Lawrence Berkeley National 625 Laboratory, respectively. Spectroscopy measurements were taken at the oxygen K-edge (520-550 626 eV), zirconium M3,2-edge (325-355 eV), hafnium M3-edge (2090-2150 eV), and zirconium L3,2627 edge (2200-2350 eV). X-rays were incident at 20° off grazing. XAS (XLD) was obtained from the 628 average (difference) of horizontal and vertical linearly polarized X-rays. To eliminate systematic 629 artifacts in the signal that drift with time, spectra measured at ALS were captured with the order 630 of polarization rotation reversed (e.g., horizontal, vertical, vertical, and horizontal) in successive 631 scans, in which an elliptically polarizing undulator tuned the polarization and photon energy of the 632 synchrotron X-ray source<sup>57</sup> . Spectra measured at ALS were recorded under total electron yield 633 (TEY) mode<sup>57</sup> from room temperature down to 100 K. Spectra measured at APS were recorded 634 under various modes: total electron yield (TEY), fluorescence yield (FY), and reflectivity (REF). 

635 Ferroic phase identification from spectroscopy X-ray spectroscopy provides various sig636 natures to distinguish the competing ferroelectric orthorhombic (Pca21) and antiferroelectric tetrag- 

29 

637 onal (P42/nmc) phase. Simulated XAS spectra at the oxygen K-edge (Extended Data Fig. 3d) for 638 ZrO2 in the various fluorite-structure polymorphs (orthorhombic Pca21 and tetragonal P42/nmc) 639 were computed through the Materials Project<sup>58</sup> open-source database for XAS spectrum<sup>59</sup> . The 640 T -phase (P42/nmc) nonpolar distortion (D4h, 4-fold prismatic symmetry) from regular tetrahe641 dral (Td, full tetrahedral symmetry) fluorite-structure symmetry does not split the degenerate e- 642 bands (dx2−y2, d3z2−r2), as confirmed by experiment<sup>60</sup> and the aforementioned XAS simulations<sup>13</sup> . 643 Meanwhile, the O-phase (Pca21) polar rhombic pyramidal distortion (C2v, 2-fold pyramidal sym644 metry) does split the e-manifold based on crystal field symmetry, providing a spectroscopic means 645 to distinguish the T - and O-phases. The additional spectroscopic feature present between the 646 main e- and t2- absorption features due to orthorhombic symmetry-lowering distortion is illus647 trated by its crystal field diagram (Extended Data Fig. 3b). This provides a spectroscopic finger648 print for phase identification beyond diffraction which can often be ambiguous due to the nearly 649 identical T - and O-phase lattice parameters. For the 2 nm HfO2-ZrO2-HfO2 trilayer, the exper650 imental O K-edge XAS spectra demonstrates tetrahedral and rhombic splitting features closely 651 matching the polar O-phase (Pca21) emerge slightly below room temperature, indicative of the 652 mixed tetragonal-orthorhombic to orthorhombic phase transition upon cooling. This temperature653 dependent tetragonal-orthorhombic structural evolution is expected for fluorite-structure thin films<sup>61</sup> 654 and is consistent with temperature-dependent capacitance measurements (Extended Data Fig. 3f). 655 Further XAS phase identification details are provided in previous work on ultrathin Zr:HfO2 656 films<sup>13</sup> . 

657 X-ray photoelectron spectroscopy Angle-resolved photoelectron spectroscopy (ARPES) 658 was performed using a Phi Versaprobe III at the Stanford Nano Shared Facilities (Extended Data 659 Fig. 1d). A monochromated aluminum source was used to give a photon energy of 1486.6 eV. Data 660 was fit and analyzed using CasaXPS. Angle-dependent XPS at various incident grazing angles 661 enabled depth-resolved composition analysis to help confirm the HfO2-ZrO2 multilayer structure. 

662 Dielectric measurements 

30 

# 663 Metal-oxide-semiconductor (MOS) capacitance Capacitance-voltage (C-V) measurements 

664 were performed using a commercial Semiconductor Device Analyzer (Agilent B1500) with a 665 multi-frequency capacitance measuring unit (MFCMU). 19 micron W tips (d.c.P-HTR 154-001, 666 FormFactor) made electrical contact within a commercial probe station (Cascade Microtech); volt667 age was applied to the W top electrode and the lightly-doped Si bottom electrode was grounded. 668 To eliminate contributions from series and parasitic resistances, frequency-dependent C-V mea669 surements were performed. In particular, C-V data was analyzed at two frequencies (100-500 kHz 670 regime) to allow for the extraction of accurate frequency-independent C-V via a three-element 671 circuit model consisting of the capacitor and the parasitic series and parallel resistors<sup>62</sup> . The 672 frequency-independent capacitance is given by 



<!-- Start of picture text -->
C = f  2 1 C1 ( 1 + D 1 2 )  − f  2 2 C2 ( 1 + D 2 2 ) (1)<br>f1 2 − f 2 2<br><!-- End of picture text -->

673 where Ci and Di refer to the measured capacitance in parallel mode (Cp-Rp) and dissipation values 674 at frequency fi. The dissipation factor is given by D = − cot θ, where θ is the phase. In order to 675 maximize the accuracy of this method, it is important the the dissipation factors are small (≪ 1) at 676 the frequencies chosen; therefore, high frequencies were selected. 

677 Permittivity extraction The permittivity of Al2O3 and HfO2 dielectric layers was ex678 tracted from thickness-dependent MOS C-V measurements on lightly-doped p substrates (Ex679 tended Data Fig. 6). In the accumulation region of the MOS C-V measurements, the MOS ca680 pacitor can be modeled as three capacitors (Al2O3 or HfO2 dielectric layer, SiO2 interlayer, and Si 681 space charge layer) in series using the following equation, 



<!-- Start of picture text -->
1 1 t Hκ + 1 t phys SiO2 + tC L ǫSiO2 , (2)<br>C = ǫ0ǫHκ ǫ0ǫSiO2 � ǫSi �<br><!-- End of picture text -->

682 where tHκ is the thickness of the high-κ (Al2O3 or HfO2) layer, t<sup>phys</sup> SiO2<sup>is the physical SiO2 thickness,</sup> 683 and tCL is the charge layer thickness in silicon. The physical SiO2 thickness is constant across all 684 of the thickness series (Al2O3 and HfO2 single layers). Additionally, the capacitance values were 685 extracted at various values of fixed charge (Q = 0 to -3 µC/cm<sup>2</sup> ) which ensures that the charge686 layer thickness is constant across all thicknesses and in the accumulation region. Therefore, from 

31 

687 Equation 2, the inverse capacitance at a fixed charge as a function of film thickness should result 688 in a line and the permittivity can be extracted from the slope. This yielded extracted permittivities 689 of 9 and 19 for the Al2O3 and HfO2 thickness series, respectively, as expected for these systems. 690 Note that for the HfO2 thickness series, thicknesses of 6 nm and higher were used to ensure HfO2 691 stabilizes in the dielectric monoclinic phase (κ ∼ 18)<sup>36</sup> . 

692 Similarly, the permittivity of the HfO2-ZrO2 heterostructures was extracted from thickness693 dependent MIM C-V measurements (Fig. 2b). The inverse capacitance is a linear function of the 694 film thickness, and the permittivity can be extracted from the slope. 

695 Electrical interlayer thickness extraction The thickness of the SiO2 interlayer was de696 termined not only by TEM (Extended Data Fig. 6a), but also electrically via C-V measurements 697 of both dielectric HfO2 and Al2O3 thickness series on SiO2-buffered Si (Extended Data Fig. 6f). 698 From Equation 2, the inverse capacitance at a fixed charge as a function of dielectric thickness 699 should result in a line and the capacitance-equivalent thickness (CET) of the SiO2 interlayer and 700 Si charge layer can be extracted from the y-intercept. By extracting the CET at different charge 701 values, the Q-V relation of the SiO2 interlayer and Si charge layer can be calculated through the 702 following equation 



<!-- Start of picture text -->
t phys ǫSiO 2<br>V − Vfb = SiO2 + tC L ǫSi dQ, (3)<br>�0 Q ǫ0ǫSiO2<br><!-- End of picture text -->

703 where Vfb is the flatband voltage (Extended Data Fig. 6b,d). To confirm this methodology, another 704 method for determining the Q-V relation of the SiO2 interlayer and Si charge layer was extracted 705 from the Q-V relations of both the dielectric HfO2 and Al2O3 thickness series. At a fixed charge, 706 the corresponding voltage values of each thickness were fit to a line and the y-intercept corresponds 707 to the voltage value for the SiO2 interlayer and Si charge layer Q-V relation (Extended Data Fig. 708 6c,e). As expected, both methods lead to the same extracted Q-V relation (Extended Data Fig. 709 6c,e), corresponding to 8 Å EOT (Extended Data Fig. 6f) – close to the SiO2 physical thickness 710 of 8.5 Å obtained via TEM (Extended Data Fig. 6a) – based on simulated TCAD Q-V relations of 711 different SiO2 thicknesses on lightly-doped Si. 

32 

712 Hysteretic C-V measurements Capacitance-voltage (C-V) measurements on MIM capac713 itors were performed using a commercial Semiconductor Device Analyzer (Agilent B1500) with 714 a multi-frequency capacitance measuring unit. 19 micron W tips (d.c.P-HTR 154-001, FormFac715 tor) made electrical contact within a commercial probe station (Cascade Microtech); voltage was 716 applied to the W top electrode and the W bottom electrode was grounded. 

717 

# Electrical characterization 

718 Bechmarking to HKMG literature In Figure 3a, the leakage-effective oxide thickness 719 (JG-EOT) scaling of negative capacitance multilayer gate stack benchmarked against reported 720 HKMG literature includes references taken from interlayer-scavenged 2 nm HfO2<sup>16,18, 63</sup> (red), 721 high-κ doped HfO2<sup>18</sup> (blue), and SiO2/poly-Si<sup>3</sup> (gray). In Figure 3b, the normalized mobility ver722 sus EOT scaling of the negative capacitance multilayer gate stack benchmarked against reported 723 HKMG literature includes references taken from interlayer-scavenged 2 nm HfO2<sup>16,18, 64</sup> (red) and 724 hybrid silicate-scavenged interlayer<sup>16</sup> (magenta). In the Figure 3b inset, the SiO2 interlayer thick725 ness versus EOT scaling scatter plot considers the 7.0 Å EOT HfO2-ZrO2-HfO2 trilayer to HKMG 726 references which employ interlayer scavenging to reduce EOT<sup>16,18, 63,65</sup> . 

727 Transistor transfer and output characteristics Transistor Id-Vg and Id-Vd characteriza728 tion of short-channel and long-channel transistors were performed using a commercial Semicon729 ductor Device Analyzer (Agilent B1500). 19 micron W tips (d.c.P-HTR 154-001, FormFactor) 730 made electrical contact within a commercial probe station (Cascade Microtech); voltage was ap731 plied to the gate and drain contacts, while the source and Si substrate were grounded. 

732 Mobility extraction The low-field transistor mobility is calculated based on the channel 733 resistance (Rch) and inversion sheet charge density (Qinv), which are extracted respectively from 734 transfer characteristics (ID − VGS) and from the gate-to-channel capacitance-voltage (Cgc − VGS) 735 measurements. Given the the device aspect ratio of channel length (L) and channel width (W), we 

33 

736 

have 



<!-- Start of picture text -->
1<br>Rch(VGS) = L (4)<br>W ×<br>µeff (VGS)Qinv(VGS)<br><!-- End of picture text -->

737 Firstly, the channel resistance is extracted at 50 mV drain-to-source bias (VDS) by subtracting the 738 parasitic resistance (Rp) from the measured drain-to-source resistance (RDS). 



<!-- Start of picture text -->
VDS<br>RDS(VGS) = ID(VGS) = Rch(VGS) + Rp (5)<br><!-- End of picture text -->

739 where Rp is ascribed to the resistance of the source and the drain contacts and the n+ extension 740 regions that are extrinsic to the channel region. When the overdrive voltage (Vov = VGS − Vt, 741 where Vt is the threshold voltage) is sufficiently large, Rch is known to be inversely proportional to 742 Vov according to 4. Therefore, Rp can be extracted using a linear extrapolation of the RDS − 1/Vov 743 relationship (Extended Data Fig. 7e), which is derived from the ID −VGS from which the threshold 744 voltage (Vt) can be characterized with the max-gm method. Secondly, the Cgc − VGS of a large 745 (W=L=50µm) device (Extended Data Fig. 7a) is integrated and normalized to the channel area 746 (A=2500µm<sup>2</sup> ) to estimate the inversion charge. 



<!-- Start of picture text -->
C g c ( v g s )<br>Qinv(VGS) ≈ d vgs (6)<br>�−∞VGS A<br><!-- End of picture text -->

747 The large device dimensions minimizes the parasitic capacitance contribution to ensure Cgc is 748 representative of the inversion electron responses. Finally, we combine the above characterizations 749 to obtain the effective mobility using Equation 4 (Extended Data Fig. 7f). 

750 Transconductance extraction The measured transconductance (gm = ∂ID/∂VGS) and the 751 output conductance (gds = ∂ID/∂VDS) are affected by the series resistance on the source (RS) and 752 the drain sides (RD), as they reduce the voltage drops on the channel region, 

750 



<!-- Start of picture text -->
VGSi = VGS − IDRS (7)<br><!-- End of picture text -->



<!-- Start of picture text -->
VDSi = VDS − ID(RS + RD) (8)<br><!-- End of picture text -->

753 where VGSi and VDSi are the gate-to-source and the drain-to-source voltages intrinsic to the chan754 nel, respectively. RS ≈ RD ≈ Rp/2 because the transistor is symmetric. 

34 

755 Rp can be extracted from the RDS − 1/Vov relationships as discussed in the "Mobility Ex756 traction" Methods section (Extended Data Fig. 9b). Besides, devices with different gate length 757 (Lg) series are fabricated on the Silicon-On-Insulator (SOI) wafer, which enables another extrac758 tion method with RSD − Lg relations. At low VD and a given Vov, Qinv and µeff are unchanged 759 across different Lg if short-channel effect is not significant, making Rch proportional to the channel 760 length. Such condition is confirmed by the consistency of Vt across measured Lg (Extended Data 761 Fig. 9a). Therefore, the Lg offset as well as the Rp can be found at the intersect of the linear rela762 tions of the RSD − Lg with different Vov (Extended Data Fig. 9c). The two Rp extraction methods 763 yield consistent results. 

764 The following equation is solved to extract the intrinsic gmi = ∂ID/∂VGSi and gdsi = 765 ∂ID/∂VDSi without the degradation due to RS and RD. 



<!-- Start of picture text -->
−gm(RS + RD)<br>     <br>(9)<br>−gdsRS 1 − gds(RS + RD) gdsi gds<br> 1 − gmRS   gmi  =  gm <br><!-- End of picture text -->

766 where gm and gds are measured, and RS ≈ RD ≈ Rp/2 from the above discussed characterizations. 767 Using this methodology, the intrinsic gmi and intrinsic gdsi are extracted (Fig. 3f, Extended Data 768 Fig. 9d,e). 

769 RF measurements Scattering-parameters (S parameters) for LG = 1 µm bulk transistors 770 (henceforth referred to as the device under test, DUT) at various DC biases as well as open and 771 short structures (Extended Data Fig. 8a) are measured using a Keysight E8361C Network An772 alyzer in conjunction with a Keysight 4155C Semiconductor Parameter Analyzer. The devices 773 were measured using low contact resistance Infinity Series probes. To calibrate the measurement 774 setup, a line-reflect-reflect-match (LRRM) calibration was performed with a Cascade Microtech 775 Impedance Standard. Following calibration, S-parameters were measured for each of the DUT, 776 open, and short structures. These measured S-parameters were converted to admittance param777 eters (Y -parameters), YDUT , Yopen, and Yshort. In order to remove the effects of parasitic shunt 778 parasitic pad capacitance and series pad resistance and inductance of the DUT, the following de779 embedding process was followed. First, to decouple the effect of shunt parasitic capacitances, the 

35 

780 Y parameters of the open structure (Yopen) are subtracted from the Y parameters of the DUT and 

781 short structure, and then are converted to impedance parameters (Z parameters): 



<!-- Start of picture text -->
Z1 = (YDUT − Yopen) −1 (10)<br><!-- End of picture text -->



<!-- Start of picture text -->
Z2 = (Yshort − Yopen) −1 (11)<br><!-- End of picture text -->

782 Next, to decouple the effect of series pad resistance and inductance of DUT, Z2 is subtracted from 783 Z1 and the resulting difference is converted back to admittance parameters, Ycorr: 



<!-- Start of picture text -->
Ycorr = (Z1 − Z2) −1 (12)<br><!-- End of picture text -->

784 Ycorr represents the de-embedded admittance parameters of the DUT. This de-embedding proce785 dure is schematically represented in Extended Data Fig. 8a. 

786 To extract the total gate capacitance (Cgg) and transconductance (gm) from the de-embedded 787 admittance parameters, a small-signal model of the transistor was assumed (Extended Data Fig. 788 8b). Under this small-signal model, the Y -parameters can be written in terms model parameters 789 and frequency (assuming Rs = Rd = 0, Cgg = Cgs + Cgd, and 4π<sup>2</sup> Cgg<sup>2R</sup> g<sup>2f 2≪1)</sup> 



<!-- Start of picture text -->
Y11 = 4π 2 Cgg 2 Rgf 2 + 2πfCggj (13)<br><!-- End of picture text -->



<!-- Start of picture text -->
Y12 = −4π 2 CgdCggRgf 2 − 2πfCgdj (14)<br><!-- End of picture text -->



<!-- Start of picture text -->
Y21 = gm − 4π 2 CgdCggRgf 2 + 2πf (Cgd + gmRgCgg)j (15)<br><!-- End of picture text -->



<!-- Start of picture text -->
Y22 = gds + 4π 2 CgdRg(Cgd + CgggmRg)f 2 + 2πf (Cds + Cgd + CgdgmRg)j. (16)<br><!-- End of picture text -->

790 The transconductance (gm) can therefore be extracted at a fixed DC bias via the following relation 791 (Fig. 3c, Extended Data Fig. 9c). 



<!-- Start of picture text -->
gm = Re(Y21) (17)<br>���f 2 =0<br><!-- End of picture text -->

792 Charge boost measurements Pulsed charge-voltage measurements (Extended Data Fig. 793 10) were conducted on p- Si/SiO2/HfO2-ZrO2 (2 nm)/TiN/W capacitor structures to extract the 794 energy landscape of the ferroic HfO2-ZrO2 heterostructure, following the measurement scheme 

36 

795 detailed in previous works<sup>47, 66–68</sup> . The capacitor structures were connected to an Agilent 81150A 796 Pulse Function Arbitrary Noise Generator and the current and voltage was measured through an 797 InfiniiVision DSOX3024A oscilloscope with a 50 Ω and 1 MΩ input impedance, respectively. 798 Short voltage pulses (500 ns) with increasing amplitudes were applied to the capacitor (Extended 799 Data Fig. 10c). From the integration of the measured discharging current, a charge vs voltage 800 relationship was extracted (Extended Data Fig. 10d). The voltage was calculated by max(V −IR), 801 where V is the applied voltage pulse, I is the measured current, and R is a combination of the 802 oscilloscope resistance (50 Ω) and parasitic resistances associated with the setup and lightly-doped 803 substrate (220 Ω). Fast voltage pulses were applied in order to minimize charge injection into 804 the ferroelectric-dielectric interface, which could mask the observation of the negative capacitance 805 regime<sup>47, 67</sup> . Additionally, short voltage pulses help prevent electrical breakdown of the SiO2 layer. 806 In order to determine the P-EF relation of the 2 nm HfO2-ZrO2 heterostructure, the electric field 807 across the ferroic HfO2-ZrO2 heterostructure was calculated by subtracting the voltage across the 808 series capacitance of the SiO2 interlayer and Si charge layer (VD) at a fixed charge value, 



<!-- Start of picture text -->
E = 1 t (V − VD) , (18)<br><!-- End of picture text -->

809 where t is the thickness of the HfO2-ZrO2 heterostructure. The Q-V relation of the series ca810 pacitance of the SiO2 interlayer and Si charge layer was determined via thickness-dependent C-V 811 measurements of Al2O3 and HfO2 (Extended Data Fig. 6, Methods, Electrical interlayer thickness 812 extraction), which corresponded to 8 Å SiO2 on lightly-doped Si. The charge boost due to neg813 ative capacitance was calculated by integrating the difference between the Q-V relations of the 2 814 nm HfO2-ZrO2 heterostructure and the series combination of the SiO2 interlayer and the Si charge 815 layer (Extended Data Fig. 10e). 

# 816 Modeling 

817 Landau phenomenology of antiferroelectric-ferroelectric system The qualitative en818 ergy landscape for a mixed ferroelectric-antiferroelectric material (Fig. 1a) was calculated by 819 assuming a series combination of antiferroelectric and ferroelectric layers connected to a voltage 

37 

