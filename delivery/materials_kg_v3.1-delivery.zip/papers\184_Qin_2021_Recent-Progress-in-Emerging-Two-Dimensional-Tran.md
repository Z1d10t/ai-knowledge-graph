# Recent Progress in Emerging Two-Dimensional Transition Metal Carbides

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nano-Micro Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 169 |
| 作者 | Tianchen Qin, Ze-Gao Wang, Yuqing Wang, F. Besenbacher, M. Otyepka, M. Dong |
| DOI | 10.1007/s40820-021-00710-7 |
| 源文件 | 084_Qin_2021_Recent-Progress-in-Emerging-Two-Dimensional-Tran.pdf |

---
ISSN 2311-6706 e-ISSN 2150-5551 CN 31-2103/TB 

https://doi.org/10.1007/s40820-021-00710-7 

## **<mark>REVIEW</mark>** 



# **Recent Progress in Emerging Two‑Dimensional Transition Metal Carbides** 

###### **Cite as** 

Nano-Micro Lett. (2021) 13:183 Tianchen Qin<sup>1</sup> , Zegao Wang<sup>1*</sup> , Yuqing Wang<sup>2</sup> , Flemming Besenbacher<sup>2</sup> , Michal Otyepka<sup>3</sup> , Mingdong Dong<sup>2*</sup> 

Received: 12 April 2021 Accepted: 25 July 2021 Published online: 20 August 2021 © The Author(s) 2021 

#### **HIGHLIGHTS** 

- The phase diagram of transition metal carbides (TMCs) is discussed. 

- The physical and chemical property of TMCs is systematically summarized. 

- The potential application and controllable synthesis of TMCs is discussed. 

- A summary is provided to afford the principle to further investigation. 

**ABSTRACT** As a new member in two-dimensional materials family, transition metal carbides (TMCs) have many excellent properties, such as chemical stability, in-plane anisotropy, high conductivity and flexibility, and remarkable energy conversation efficiency, which predispose them for promising applications as transparent electrode, flexible electronics, broadband photodetectors and battery electrodes. However, up to now, their device applications are in the early stage, especially because their controllable synthesis is still a great challenge. This review systematically summarized the state-of-the-art research in this rapidly developing field with particular focus on structure, property, synthesis and applicability of TMCs. Finally, the current challenges and future perspectives are outlined for the application of 2D TMCs. 

**KEYWORDS** Two-dimensional transition metal carbides; Phase diagram; Superconductivity; Energy conversation and storage; Largescale synthesis 



<!-- Start of picture text -->
Catalysts<br>Niobium Vanadium<br>carbide carbide<br>2D TMCs<br>Titanium Molybdenum<br>carbide carbide<br>Superconductor<br>tion C<br>deposi hemic<br>r al<br>o e<br>ap xf<br>v ol<br>al ia<br>ti<br>Medical treatment<br>Supercapacitor<br>Optoelectronic devices<br>Battery<br>mic on<br>e<br>h<br>C<br>T<br>e<br>g m<br>nir pp.-<br>e r<br>tt o<br>u r<br>p o<br>s .g<br>c R<br>it e<br>e d<br>n u<br>g c<br>a it<br>M no<br><!-- End of picture text -->

> * Zegao Wang, zegao@scu.edu.cn; Mingdong Dong, dong@inano.au.dk 

> 1 College of Materials Science and Engineering, Sichuan University, Chengdu 610065, People’s Republic of China 

> 2 Interdisciplinary Nanoscience Center, Aarhus University, 8000 Aarhus, Denmark 

> 3 Regional Centre of Advanced Technologies and Materials, Department of Physical Chemistry, Faculty of Science, Palacký University, 77146 Olomouc, Czech Republic 

1 3 

**183** Page 2 of 34 

Nano-Micro Lett. (2021) 13:183 

### **1 Introduction** 

Ultra-thin two-dimensional (2D) nanomaterials, as a new kind of nanomaterials, have been widely concerned for a long time. This is because they have a special planar structure, where the horizontal size is beyond sub-micrometer; however, the vertical size limits in nanometer or even atomic level. As early as 200 years ago, it was found that there were some special layered minerals in nature, which can be peeled off to obtain a new lamellar structure [1]. In 2004, K. S. Novoselov, A. K. Geim and other collaborators reported the fabrication of graphite single layer named graphene by using a special scotch micromechanical stripping [2]. The graphene shows many unique properties, namely extraordinary carrier mobility of up to 200,000  cm<sup>2</sup> (V s)<sup>−1</sup> , the large specific surface area of 2630  m<sup>2</sup> g<sup>−1</sup> , the transmittance of 97.7%, the Young’s modulus of 1 TPa and the thermal conductivity of 3000 W (m K)<sup>−1</sup> [3, 4]. Ultra-thin 2D nanomaterials, as a representative of graphene, exhibit unique physical and chemical properties because the electrons are confined in 2D space. These excellent properties make ultrathin 2D nanomaterials enter the field of vision of researchers, ushering in the golden age of rapid development [5–11]. Since the discovery of graphene, more and more ultra-thin 2D materials have been found and synthesized, including hexagonal boron nitride (h-BN), carbon nitride (g-C3N4), transition metal chalcogenides (TMDs), transition metal oxides (TMOs), transition metal carbides (TMCs), layered double hydroxides (LDHs), metal − organic frameworks (MOFs), phosphorene and other elemental 2D materials [12–15]. These materials not only enrich the types of ultrathin 2D nanomaterials, but also show a variety of properties due to the differences in composition and structure, which provide sufficient impetus for the follow-up research of ultrathin 2D nanomaterials. 

In 2011, Gogotsi and Barsoum reported the synthesis of MXene, as a new member of 2D transition metal carbides (TMCs) [16]. The general chemical formula of MXene is Mn+1XnTz ( _n_ = 1, 2, 3), where M is transition metal element, such as Ti, Sr, V and Ta, X is C or N, and T stands for F-, OH- and other functional groups. So far, there are more than 70 members of the MXenes family reported. The MXene materials are typically prepared by selective etching the A layer (also named Al layer) with a high concentration of hydrofluoric acid using the MAX with layered hexagonal 



<!-- Start of picture text -->
structure of ternary ceramic phase as the precursor [16].<br>Catalysts<br>Niobium Vanadium<br>carbide carbide<br>2D TMCs<br>Titanium Molybdenum<br>carbide carbide<br>Superconductor<br>tion C<br>deposi hemic<br>r al<br>o e<br>ap xf<br>v ol<br>al ia<br>ti<br>Medical treatment<br>Supercapacitor<br>Optoelectronic devices<br>Battery<br>mic on<br>e<br>h<br>C<br>T<br>e<br>g m<br>nir pp.-<br>e r<br>tt o<br>u r<br>p o<br>s .g<br>c R<br>it e<br>e d<br>n u<br>g c<br>a it<br>M no<br><!-- End of picture text -->

**Fig. 1** The scope of this review 

Due to their 2D layered structure, good conductivity, stability, hydrophilicity and unique in-plane anisotropic structure, MXene materials have attracted many attentions in recent years. However, the fundamental properties, potential applications and even the controllably synthesis of TMCs are still in their early stage. Previous review progresses are mainly focused on the energy storage, especially on Ti-based TMCs (also called MXenes). The phase diagram, property and synthesis strategy of TMCs including Ti-based and other transition metal-based TMCs have rarely been overviewed. The scope of this review is shown in Fig. 1. We will introduce the structure, physical and chemical properties, the potential applications and finally, the preparation methods of typical TMCs including niobium carbide, vanadium carbide, molybdenum carbide and titanium carbide. 

### **2  Structure and Property of Transition Metal Carbides** 

In 1973, Levy and Boudart found that the carbon atoms in tungsten carbide would change the electron distribution of tungsten atoms resulting in the catalytic property similar with that of platinum and other precious metals [17]. This discovery led to extensive research on other early transition metal carbides, nitrides and carbonitrides. With the 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 3 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

development of layered materials since 2004, the transition metal carbides (TMCs) recall its hot spot due to their many excellent dimensionality and structure-dependent properties. TMCs are mostly interstitial alloys formed by transition metal atoms and carbon atoms. Taking Mo-based TMCs as the example, the β-Mo2C and η-Mo3C2 of molybdenum carbide are orthogonal and the arrangement of Mo atoms in units is slightly different from that of hexagonal closepacked (hcp). The crystal structure can be described as that Mo atoms occupy the lattice site with the formation of hcp, while carbon atoms occupy half of the octahedral interstitial positions. However, the α-MoC1-x has a face-centered cubic close-packed ( _fcc_ ) crystal structure. In addition, Ti, Nb, V and Ta atoms in their TMCs all form _fcc_ crystal structure [18]. These carbides are composed of two nested _fcc_ lattices, one contains metal atoms and the other contains carbon atoms, which is similar to the NaCl crystal structure. The bonding configuration is usually formed through the hybridization between the 2 s and 2p orbitals of carbon atoms with the d orbitals of transition metals. With the increase in _sp_ electrons, the parent metal structure gradually transfers from _bcc_ crystal structure to hcp crystal structure, and then to _fcc_ crystal structure. The lattice constant and bulk modulus of carbides have been calculated theoretically by Murnaghan 

equation, showing that the theoretical calculated values are in good agreement with the experimental values [19]. Recently, Frey et al. adopted a new model based on density functional theory-PU learning model, and studied 66 kinds 2D single transition metal atoms-based TMCs and there are more than 800 kinds of MAX with different phases through high-throughput calculation. The results predicted that about 111 kinds of MAX and 18 kinds of TMCs could be synthesized with the high possibility (Table 1) [20]. Specially, 14 of the 18 TMCs have the formation energies lower than 200 meV  atom<sup>−1</sup> , which is below the threshold value, and the stability of 4 unstable TMCs  (W4C3,  Ta2C,  W3C2 and Mo4C3) can also be improved by surface functionalization [21]. However, due to the low chemical activity and complex synthesis condition of these TMCs, until now, only the niobium carbide, vanadium carbide, molybdenum carbide and titanium carbide have get a reasonable investigated. Besides the existence of the TMCs, Table 2 exhibits the property of the typical layered materials, including the TMCs. One can see that the new layered TMCs have many excellent property, which would facilitate the development of the materials science. In the following, we introduce mainly the structure, synthesis, properties and applications of these four TMCs, which would inspire future studies. 

**Table 1** 18 kinds of MXenes with high synthesis possibility [20] 

MXene predicted to be stable 

|Hf4C3|Ta4N3|Sc3C2|
|---|---|---|
|Nb3C2|Ta2C|Ti2N|
|Zr2C|Hf4N3|Sc2C|
|Ta3C2|Ti4C3|W3C2|
|W4C3|Hf2C|Nb2N|
|Zr4C3|Sc4C3|Mo4C3|



##### **2.1  Niobium Carbide** 

Among TMCs, niobium carbide has attracted much attention due to its excellent properties, such as high melting point (3610 °C), excellent chemical stability, high toughness, high Young’s modulus and higher hardness than other TMCs [22, 23]. Niobium carbide also exhibits better electrical properties, where its resistivity is as low as 4.6 μΩ cm at room temperature and will show superconductivity at 12 K 

**Table 2** Basic parameters of the typical layered materials 

|Materials|TMCs|Graphene|TMDs|BP|h-BN|
|---|---|---|---|---|---|
|Band gap (eV)|0 (Metallic)<br>i|0 (Metallic)|1.2 ~ 1.8  (MoS2)|0.3 ~ 1.5|6.07|
|Conductance (S/m)|~  10<sup>6</sup>(MXene fiber)|~  10<sup>6</sup>|/|300|/|
|Critical temperature of Superconductor (K)|2 ~ 10 (Nb or Mo-based TMCs)|1.7 (Twist<br>bilayer gra-<br>phene)|12  (MoS2@130 GPa)|7.5 (@5 GPa)|/|
|Thermal conductance  (Wm<sup>−1</sup>K<sup>−1</sup>)|48.4  (Mo2C)|3000|52|4.3–5.5|300|
|Young’s modules (GPa)|14.0 (MXene)|1000|230  (MoS2)|20 ~ 100|1160|
|Stability in ambient|No|Yes|Yes|No|Yes|



1 3 

**183** Page 4 of 34 

Nano-Micro Lett. (2021) 13:183 

[24]. Niobium carbide has a B1 type crystal structure (as shown in Fig. 2), and the vacancies only appear in the carbon sublattice. The composition of the ordered atom-vacancy crystal structure is close to  NbC0.38 [25]. There are different solid single-phase zones in the NbC system: solid solution of carbon in niobium(bcc), γ-Nb2C, β-Nb2C,  NbC1-x,  Nb6C5, NbC and  Nb4C3-x [26, 27]. γ-Nb2C has a hexagonal structure and can be transformed into ordered hexagonal β-Nb2C at a lower temperature.  NbC1-x has a NaCl-type crystal structure and can be transformed into  Nb6C5 with an ordered crystal structure at 1050 °C. NbC also has a NaCl-type crystal structure, which can be regarded as two _fcc_ lattice structures interspersed with each other. The atoms in NbC have octahedral coordination, and carbon atoms occupy half of the octahedral gap.  Nb4C3-x is very similar to the ordered  V6C5 crystal structure, but whether there is a stable  Nb4C3-x is still controversial. This phase may be produced by the peritectic reaction between NbC and  Nb2C [27]. 

##### **2.2  Vanadium Carbide** 

The vanadium carbide with stoichiometric composition (VC) cannot be obtained under equilibrium conditions. It usually has extensive homology disordered δ-VC1-x  (VC0.65-VC0.90) crystallizes with a NaCl cubic structure. Carbon atoms in NaCl-type vanadium carbides can only fill the octahedral 

vacancies of the metal _fcc_ sublattice partially, that is, there are structural defects. Under certain conditions, their presence may lead to atomic ordering, which is caused by the redistribution of nonmetallic atoms and structural vacancies at interstitial lattice positions. Due to its high concentration of structural vacancies, this non-stoichiometric interstitial compound can be used in the field of electronic materials. It is found that the ordering of carbon atoms and the formation of structural vacancies in vanadium carbide are accompanied by the increase in micro-hardness and electrical conductivity [28]. Shacklete et al. studied the effect of ordered-disordered phase transition on the resistivity of vanadium carbide single crystal. The results show that the resistivity of vanadium carbide in disordered phase is significantly higher than that in ordered phase. There are 6 solid single-phase zones in the VC system: VC, α-V2C, β-V2C,  V4C3,  V6C5 and  V8C7, as shown in Fig. 3 [29]. Chong et al. systematically studied the stability, electronic structure and anisotropic mechanical properties of VC binary compounds by first-principles calculation, demonstrating their potential applications [30]. 

In the crystal structure of VC, each unit cell contains 8 atoms (4 V atoms and 4 C atoms).  V4C3 is similar to VC, but each cell has one C atom vacancy and 7 atoms, including 4 V atoms and 3 C atoms. The appearance of natural carbon vacancy in  V8C7 makes the space group become P4332, and the maximum number of atoms in a unit cell is 60 (32 V atoms and 28 C atoms). But the structure of 



<!-- Start of picture text -->
4000<br>(a) (d) 3600±25 °C<br>Liquid 3300±25 °C<br>γ-Nb2C 3080±20 °C 60<br>c 3000 33.3<br>2530 °C<br>a b 2469 2340±10 °C 2450°C NbC1-x<br>(Nb) 5.7 10.5<br>2000 β-Nb2C NbC1-x+(C)<br>(b) [010] B 1 (c) c [010] B 1<br>c<br>1050 °C<br>1000<br>b<br>[010] B 1 Nb4C3-x<br>b [010] B 1 a Nb6C5<br>[010] B 1<br>[010] B 1 a Nb C Vacancy 10 20 30 40 50 60<br>C/Nb atom ratio<br>C)<br>°(<br>terareu<br>p<br>m<br>e<br>T<br><!-- End of picture text -->

**Fig. 2** Structure of Nb-based TMCs. **a** Schematic diagram of the B1 type crystal structure of NbC. Reproduced with permission from Ref. [27]. Copyright 2016, MDPI. **b** NbC0.38 unit cell structure with C2 space group. **c** NbC0.38 unit cell structure with C2/m space group. Reproduced with permission from Ref. [25]. Copyright 2021, Springer Nature. **d** Phase diagram of C-Nb system. Reproduced with permission from Ref. [27]. Copyright 2016, MDPI 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 5 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(c)<br>VCx<br>(a) 3500 1500 1485 K VCx+C<br>Liquid<br>1400 1331 K 1380 K V8C7+C<br>3000<br>1300 V6C5 2940 K<br>0.75 0.8 0.85 0.9<br>2500 V6C5+V8C7<br>2438 K VCx<br>2000 V2Cx+VCx<br>(b) 1925 K V2Cx VCx+C<br>V+V2Cx ζ-V4C3<br>2500 ~1600 K 1485 K 1380 K<br>V2Cx+V6C5<br>1155 K 1331 K<br>V+α-V2C V6C5<br>V6C5+V8C7<br>1000 V2Cx<br>V<br>+ V8C7+C<br>V3C2 V3C2 640 K<br>500 α-V2C V3C2 V+6C5 V6C5+C<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>C/V atom ratio<br>Liq+V2Cx<br>Liq+VCx<br>)K<br>(<br>terareu<br>p<br>m<br>e<br>T<br><!-- End of picture text -->

**Fig. 3** Crystal structure of V-based TMCs. **a** VC, **b** α-V2C. Reproduced with permission from Ref. [30]. Copyright 2011, The Royal Society of Chemistry. **c** Phase diagram of C-V system. Reproduced with permission from Ref. [31]. Copyright 1989, IOP Publishing 

V8C7 is still cubic. The lattice parameters of  V4C3,  V8C7 and VC are 8.219, 8.315 and 8.305 Å, respectively. The lattice constant of  V4C3 is less than VC, which should be due to the doping of carbon vacancies. On the other hand, the formation of natural carbon vacancies will change the space group in the actual  V8C7 lattice, resulting in a slightly larger lattice constant [30]. The cohesive energy of VC binary phase increases in the following order: V6C5 <  V8C7 < VC < α-V2C <  V4C3 < β-V2C [30]. All vanadium carbides exhibit metallic property because of their narrow band gap at Fermi level. Near the Fermi level, the shape of the energy density curve of all VC compounds is similar to that of the V-d state, indicating that the d band of V atom dominates the Fermi level. The chemical bond of VC binary compound is mainly VC covalent bond, but it also has ionic and metallic properties, which makes vanadium carbide have a high melting point, high mechanical modulus, high hardness and good electrical conductivity [30]. Due to its high hardness, high melting point, excellent wear resistance, low friction coefficient and good corrosion resistance, vanadium carbide is often used to improve the life of mechanical components in tribological applications [32]. 

##### **2.3  Molybdenum Carbide** 

Molybdenum carbide has five different crystal structures: α-MoC1−x, α-Mo2C, β-Mo2C, γ-MoC and η-MoC [33]. For α-Mo2C, as shown in Fig. 4, two layers of Mo atoms are arranged in an AB structure, and a layer of carbon atoms is sandwiched in the middle, occupying octahedral center [34]. It is equivalent to that the Mo atoms are closely arranged in the hexagonal form and the carbon atoms are distributed in the octahedral gap with a Z-shaped structure. The lattice of Mo atoms is deformed because the carbon atoms deviate from the center of the gap, thus forming an orthogonal crystal structure. For β-Mo2C, the Mo atoms are arranged in a strict close-packed hexagonal form, and the carbon atoms still occupy 50% of the octahedral gap. Thus, the distribution of carbon atoms has a certain randomness [35]. The α phase is stable at room temperature, while the β phase is stable at high temperature and metastable at room temperature and can only exist stably above 1960 °C. Recently, Liu et al. reported that under the irradiation of electron beams, the carbon atoms in  Mo2C would migrate resulting in that  Mo2C change from α phase to β phase [35]. As regarding to the 

1 3 

**183** Page 6 of 34 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(e) 3000<br>(a) (b) 2623 Liquid 36.32605±9 °C 43 2589±9 °C<br>2500 34 45<br>2205±9 °C δ-MoC1-x<br>1.1 17 27 η-MoC<br>2000 1956±15 °C<br>β-Mo2C 40.4<br>1647±15 °C<br>39<br>1500<br>(c) (d) β'-Mo2C 1220±15 °C<br>1278±8 °C<br>1000<br>Mo<br>500 γ-MoC<br>C<br>β"-Mo2C<br>0 10 20 30 40 50 60 70 80 90 100<br>C/Mo atom ratio<br>C)<br>°(<br>terareu<br>p<br>m<br>e<br>T<br><!-- End of picture text -->

**Fig. 4** Bulk crystallographic structures of Mo-based TMCs. **a** fcc α-MoC1−x, **b** hexagonal γ-MoC and η-MoC, **c** orthorhombic β-Mo2C, **d** orthorhombic α-Mo2C. Reproduced with permission from Ref. [36]. Copyright 2018, Elsevier. **e** Phase diagram of C-Mo system. Reproduced with permission from Ref. [39]. Copyright 2001, American Physical Society 

density of states of β-Mo2C and α-Mo2C [36], the total density of states is mainly composed of s, p orbitals of C and d orbital of Mo. Furthermore, there is no band gap near Fermi level indicating the metallicity of molybdenum carbide [36]. Molybdenum carbide has strong absorption for a large range of light, where the molybdenum carbide thin films have a uniform absorption in the range of 500–2000 nm [37]. Molybdenum carbide is a kind of saturated absorber. The absorptivity of molybdenum carbide to a certain wavelength decreases with the increase in light intensity. When the light intensity increases to a certain value, it is transparent to that wavelength. In this case, when molybdenum carbide is made into a grid with various periodic widths, and the grid is made into a transistor with  MoS2 channels and electrodes, the device has a good response rate and a high light–dark current ratio in the range of 400–1400 nm [38]. 

##### **2.4  Titanium Carbide** 

Titanium carbide is a carbide with a wide homogeneity (from  TiC0.48 to  TiC1.00). The synthesis conditions will affect the ordered arrangement of vacancies in the carbon sublattice, leading to the appearance of non-stoichiometric  TiCx, thereby resulting in the redistribution of carbon atoms and structural vacancies, and forming various ordered structures [40]. When the carbon vacancies are randomly distributed, 

the disordered TiC compound forms a cubic NaCl crystal structure. When the carbon vacancies are distributed in an orderly manner, there are two stable ordered titanium carbide phases, one is the cubic phase and the other is the triangular phase [41]. TiC with NaCl cubic crystal structure (as shown in Fig. 5) is the most common phase of titanium carbide and has been widely studied. The results show that the lattice spacing of ordered cubic phase  Ti2C (space group Fd3m) is twice as large as that of disordered titanium carbide [42, 43]. The  Ti6C5 phase is a stable ordered phase, and also a non-stoichiometric ordered phase of all IV and V group transition metal carbides [40]. Khaenko et al. demonstrated the existence of rhombohedral  Ti8C5 [44]. Through grinding and polishing of titanium carbide, Dzhalabadze et al. found that 6H-type ordered titanium carbide with _fcc_ lattice was formed on the surface [45]. In the process of the deposition of diamond films on titanium alloy substrate, Li et al. also found 6H-type titanium carbide at the interface [41]. 

In 2011, MXene, represented by  Ti3C2Tx, entered the field of vision of researchers, and the research on titanium carbide rose again and expanded to various fields. The structural study of titanium carbide based on  Ti3C2Tx and  Ti2CTx MXene is also carried out gradually (as shown in Fig. 5). Through the heating treatment of  Ti3C2Tx MXene, it was found that  Ti3C2Tx has been significantly transformed into cubic TiC at 1100 °C. As the temperature increases, free C 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 7 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(d)<br>(a) (c) 3500 Liquid<br>TiCx+Liq<br>A 3000<br>3050 K<br>B<br>2500<br>TiCx<br>2000 Liq+TiCx<br>1918 K<br>Ti C<br>B β-Ti<br>A 1500 β-Ti+TiCx Ti3C2+Ti6C5 TiCx+C<br>(b) Ti2C+Ti3C2 Ti6C5+TiCx<br>1193 K<br>1000 α-Ti+TiCx<br>919 K<br>α-Ti Ti2C Ti3C2<br>500 Ti6C5<br>α-Ti+Ti2C<br>A<br>Ti C T 0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>B<br>C/Ti atom ratio<br>)K<br>(<br>terareu<br>p<br>m<br>e<br>T<br><!-- End of picture text -->

**Fig. 5** Structure of titanium carbide. **a** Ordered structures of cubic TiC. **b** Molecular structure model of single layer  Ti3C2Tx. Reproduced with permission from Ref. [46]. Copyright 2016, WILEY–VCH. **c** Molecular structure model of single layer  Ti2CTx. Reproduced with permission from Ref. [47]. Copyright 2013, The Royal Society of Chemistry. **d** Phase diagram of C-Ti system. Reproduced with permission from Ref. [40]. Copyright 1997, Elsevier 

is lost due to the conversion of  CO2/CO, and holes appear in the accordion layered structure. When the heat treatment temperature reaches 1250 °C,  Ti3C2Tx MXene completely transforms into cubic TiC [44]. 

### **3  Synthesis of Transition Metal Carbides** 

Although TMCs exhibit many excellent properties, the controlling synthesis is still in its infant. There are a few issues that need further investigation. During the synthesis of TMCs, the production of surface pollutants will block the active sites and cavities, resulting in a suppressed electrocatalytic activity. Normally, the traditional preparation methods of TMCs are usually based on solid–solid reaction or gas–solid reaction, that is, the directly pyrolysis of metal carbonyl compounds or the reaction of metal/metal oxides with C source. However, at relatively high temperature, the aggregation or overgrowth of TMCs during pyrolysis leads to the decrease in electrochemical reaction active sites and electrocatalytic activity. So far, researchers have been committed to enhance the electrocatalytic activity through the engineering of structures and interfaces, including nanostructures, doping, morphology controlling 

and the introduction of various carbon-based materials. To sum up, the reasonable design of the preparation process is essential to maximize the exposure of the active sites of TMCs in the process of efficient electrochemical reaction [48]. 

Besides the particle-like TMCs utilizing in catalytic and energy storage fields, film is another fashion of TMCs, where the solid materials have tiny dimensions in one dimension. Because the thickness is small, the proportion of surface particles is large, and the continuity of the structure is restricted by the surface interface, the properties of the thin films are quite different from those of the bulk materials including [49]: the decreases of melting point [32]; the selective projection and reflection of light [50]; the generation of surface energy level and surface magnetic anisotropy [51]; the varied critical temperature of superconductivity [52]; and the generated tunnel current in the direction of the thickness [53]. With the dimensionality decrease from three-dimensional to two-dimensional, the few-layered graphene and  MoS2 display many unique properties, which are quite different with their bulk states, such as higher carrier mobility and field modulated effect [53, 54]. Due to the high melting point of most carbides, the TMCs materials can be hardly prepared by directly thermal evaporation, while 

1 3 

**183** Page 8 of 34 

Nano-Micro Lett. (2021) 13:183 

electron beam evaporation has been used in the preparation of TiC/TiB2 films [49]. Up to now, some typical methods have been used to prepare the TMCs. 

##### **3.1  Chemical Exfoliation** 

Chemical exfoliation is that it uses HF and LiF to selectively etch the A layer of the parent phase MAX with threedimensional layered structure to realize the preparation of carbides, nitrides and carbonitrides, where M is transition metal (Cr, Ti, V, Cr, Zr, Nb, Mo, Hf or Ta), A is mostly IIIA or IVA group elements (Al, Si, etc.), and X is C or N [55]. In order to highlight the similarity between the product and graphene, Naguib et al. named it with MXene. At present, the general process of synthesizing MXene by chemical exfoliation mainly includes: Max precursor synthesis, etching and exfoliation. The schematic diagram of the process of preparing MXene by chemical exfoliation is shown in Fig. 6 [16]. Taking  Ti3AlC2 as an example, Naguib et al. reported a method to remove Al layer from  Ti3AlC2 

without destroying the layered morphology. It was found that the exfoliated  Ti3C2 with large interlayer distance can be obtained by treating  Ti3AlC2 powder with 50% HF aqueous, and then, few-layered  Ti3C2 flakes can be prepared through ultrasonic treatment in methanol [16] (Fig. 7). 

Many aluminum-based MAX phases are synthesized at a temperature above 1300 °C [60]. Most of the M-A bonds in the layered MAX precursor phase are metal bonds or covalent bonds, which rules out the possibility of producing MXenes by mechanically shearing their parent phase MAX. Element A can be selectively etched using electrochemical reactions which take place in an acidic solution or an alkaline solution [61]. Recently, another type of layered solids has also been used as precursors, which is (MC)nAl3C2 and (MC)n(Al, Si)4C3; for example,  Al3C3 and (Al, Si)4C4 were etched to obtain  Zr3C2Tx and  Hf3C2Tx [62]. However, except for  Ti3SiC2, only the Al-containing MAX phase was successfully etched to synthesize MXene. The experiments also show that the MAX phase with larger n atom and larger M atom mass often requires longer etching time and more corrosive solution, which 



<!-- Start of picture text -->
Etching Intercalation Exfoliation<br>(a) HF DMSO Sonication<br>or NH4HF2 or TBAOH Shaking<br>or NaOH or TMAOH<br>or HF/H2O2 or choline hydroxide<br>or molten salt or n-butylamine<br>or isopropylamine<br>Exfoliation<br>Etching Sonication<br>HCl+LiF Li + Li + Li + Li + Shaking<br>Li + Li + Li + Li +<br>Li + Li + Li + Li +<br>(b) (c) (d)<br>Trinity Colle<br>Coláiste na Tríonóide<br>1 µm 300 nm The University of Dub<br>1 cm<br><!-- End of picture text -->

**Fig. 6** MXene preparation by chemical exfoliation. **a** Mechanism of chemical exfoliation. Reproduced with permission from Ref. [56]. Copyright 2019, Elsevier. **b** SEM image of intercalated procure. Reproduced with permission from Ref. [57]. Copyright 2013, The American Association for the Advancement of Science. **c** TEM image of few-layer MXene. Reproduced with permission from Ref. [58]. Copyright 2014, Royal Society of Chemistry. **d** Digital image of MXene-based transparent electrode. Reproduced with permission from Ref. [59]. Copyright 2017, WILEY–VCH 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 9 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
CH4 CH4<br>(a)<br>1070° C 1090° C<br>Solid Cu/Mo Graphene/Solid Cu/Mo Graphene/2D Mo2C/Liquid Cu/Mo<br>(b) (c) (d) a 1 atm<br>50 µm<br>5 µm 2 nm<br>77 µm<br><!-- End of picture text -->

**Fig. 7** Preparation of TMCs by chemical vapor deposition. **a** Mechanism of  Mo2C growth, where the Cu foil is located on the surface of Mo foil. Reproduced with permission from Ref. [95]. Copyright 2017, American Chemical Society. **b** Formation of  Mo2C flakes under graphene under high temperature. Reproduced with permission from Ref. [95]. Copyright 2017, American Chemical Society. **c** Atomic pattern of  Mo2C by high resolution TEM. Reproduced with permission from Ref. [90]. Copyright 2015, Springer Nature. **d** SEM image of VC flakes. Reproduced with permission from Ref. [96]. Copyright 2020, Elsevier 

may be due to the large number of M valence electrons [63]. Etching conditions usually depend on the chemical structure of the parent phase. For example, if 50 wt% HF is used for etching  Ti2AlC and  Cr2AlC, the sample will complete dissolute. Although  Ti2CTx can be obtained by reducing the concentration of HF to 10 wt%, it still not works on  Cr2AlC [64]. 

In order to avoid or minimize the use of concentrated HF due to its very strong corrosive, a few other synthetic pathways have been proposed. One of the most widely methods uses a mixture of hydrochloric acid (HCl) and fluoride salts. Using fluorides (LiF, NaF, KF and  NH4F) and HCl solution, it was found that the  Ti3AlC2 can be effectively etched and exfoliated to produce layered  Ti3C2 MXene [64–67]. Alhabeb studied the etching effect under different molar ratio of HCl to LiF/HCl, and found that the MXene obtained by chemical exfoliation includes  Ti2CTx,  Ti3C2Tx,  V2CTx, etc., where  Tx is a surface atom or atomic group, such as O, OH and F [68]. The surface hydrophilicity, conductivity and other physical and chemical properties of MXene prepared by etching method have a great relationship with the choice of etchant and the process. For example, etching with HF will make the surface of MXene mainly contain fluoride 

functional groups, but LiF-HCl etching will make MXene surface with oxygen-containing functional groups [69]. 

Similar to titanium-based TMCs, vanadium-based TMCs can also been prepared through this chemical exfoliation [70, 71]. He et al. used the mixture of NaF and HCl as an etchant to chemically strip  V2AlC. The obtained layered  V2C MXene has a high specific surface area of 19.3  m<sup>2</sup> g<sup>−1</sup> [72]. Zada et al. proposed a new chemical stripping method for large-scale preparation of MXene, which proves that the algae extract can effectively intercalate and strip  V2AlC, avoiding the use of traditional HF and other dangerous etchants, and has the advantages of environment friendly and low cost [50]. Up to now, the main method to prepare  V2C MXene is chemically etching. However, the formation energy of  V2C from  V2AlC is relatively high, the complete removal of Al layer in  V2AlC is difficult, and thus, the final  V2C MXene usually contains a certain amount of unreacted  V2AlC. Therefore, the conversion efficiency of  V2AlC to  V2C needs to be improved, which is of great significance for the further application of  V2C MXene [73]. Guan reported that the purity of  V2C MXene can be up to 90% when using the mixed solution of LiF and HCl to treat  V2AlC [74]. The Zr- and Nb-based 

1 3 

**183** Page 10 of 34 

Nano-Micro Lett. (2021) 13:183 

TMCs have also been synthesized. Zhou synthesized twodimensional  Zr3C2 MXene by the similar chemical exfoliation using layered  Zr3Al3C5 as parent phase MAX. It was found that  Zr3C2 MXene has better structural stability at high temperature, compared with that of  Ti3C2 MXene, suggesting its potential advanced application [62]. Xin studied the effect of surface functional groups on the work function of  Nbn+1Cn MXene through density functional theory. The results show that the terminated F and O atoms will increase the work function of  Nbn+1Cn MXene, while the OH and  OCH3 groups will decrease its work function, indicating its widely potential application in electronics [75, 76]. Pang used a new, fluorine-free, concise and rapid synthesis method to prepare one-dimensional Nb2CTx nanowires. The synthesis process includes a twostep etching process: the first is hydrolysis, and the second is 3D electrode thermally assisted electrical etching. With strong stirring, the parent phase MAX creates gaps on the TiC surface and splits into small pieces, the lateral size of which is reduced from 10 ~ 30 to 1 ~ 5 μm. Under ultrasonic treatment, a shorter etching time can make the MAX-MXene composite produce nanowire “shred effect” [77]. 

The chemically exfoliation has also been used to synthesize the multi transition metal-based TMCs. Pinto et al. prepared the two-dimensional bimetallic TMCs  (MoxV4-xC3 MXene) by selectively etching Al from the  MoxV4-xAlC3 precursor. Unlike the reported ordered bimetallic carbides Mo2TiC2 MXene and  Mo2Ti2C3 MXene, the Mo and V layers in this  MoxV4-xC3 MXene exist in the form of solid solution. By changing the precursor composition, four different types of  MoxV4-xC3 MXene with x = 1, 1.5, 2 and 2.7 have been obtained [78]. However, due to the difficult synthesis of stable MAX precursors, many predicted TMCs MXenes have not been successfully synthesized. For example, MAX precursors for  Cr3N2,  Mo3N2,  Hf3N2 and  Cr3C2have not been reported. On the other hand, even some MAX phase can be synthesized; the chemically exfoliation also faces challenge because the as-prepared TMCs MXenes also can be destroyed and solved in the hydrofluoric acid aqueous. For example, although the MAX phase of  Cr2AlC was synthesized long time before, the  Cr2C MXenes was yet well prepared [79]. It was found that the samples can be dissolved after a few hours even the etchant concentration has been greatly diluted [80]. 

Except the etchant, the used dispersion solution is also important, which can affect the size and the stability of the exfoliation flakes. It was found that the yield is quite low when directly stripped by ultrasound in etchant [81, 82]. Recently, it was reported that  Ti3C2 MXene and (Mo2/3Ti1/3)3C2 MXenes can be stripped by polar organic molecule dimethyl sulfoxide (DMSO) [83, 84], but it has no obvious effect on other TMCs-based MXene. Tetrabutylammonium hydroxide (TBAOH), which is commonly used for stripping other two-dimensional materials [85], has also been successful in stripping  V2C MXene and  Ti3CN MXene with good exfoliation and stability [86].  Nb2C MXene can also be stripped in isopropylamine [87]. 

In summary, the etchant solution and the dispersion solution play the key role in the chemical exfoliation. Although using the fluoride salts can somehow decrease the dangerous of the protocol, the yield and the size of the MXene flakes are still need further improve. The dispersion solution is another important factor, which not only affects the exfoliation rate, but also affects the stability of the as-prepared MXene, indicating that more efforts are still needed. 

##### **3.2  Chemical Vapor Deposition** 

Chemical vapor deposition (CVD) is another method which can grow film with large scale and high quality, thus has been widely used in industry. To grow film by CVD, the sources are usually supplied with the formation of gas, which can be easily controlled. However, recently, considering the rare and expensive gas source of transition metal, the traditional CVD has been modified; for example, the gas source of transitional metal was supplied by pre-heating its corresponding transition metal oxide. By this modified CVD method, the high crystallinity  MoS2 films have been grown [88, 89]. The products obtained by this method are very different from those obtained by chemical exfoliation, where the source molecular would react and deposited on the growth substrate. Under high temperature, the molecular or cluster of the samples would migrate and re-organized to form film with high quality, such as singe-crystal-like film or flakes. Therefore, its fashion is quite different from the sample prepared by chemical exfoliation and has yet named with MXene. 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 11 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

In 2015, Xu et al. reported for the first time the growth of high-quality ultra-thin TMCs crystals  (Mo2C superconducting crystals) by CVD method using double-layer metal foils (copper, copper/transition metal) as substrates; By these methods, Xu et al. also grown TaC and WC thin films [90]. Firstly, the Cu/Mo foil laminate was heated to above 1085 °C (Cu melting point) in hydrogen, and then, the Cu metal would melt and form a uniform liquid Cu film on the Mo substrate. Methane was introduced at a low flow rate to form  Mo2C crystals on the surface of the liquid Cu. The top liquid copper layer plays an important role in the growth process. On the one hand, it acts as a catalyst to decompose methane into carbon atoms. On the other hand, it acts as a channel to control the diffusion of Mo atoms from the Mo foil to the surface of the liquid Cu. The results show that ultra-thin  Mo2C crystals are formed on the surface of Cu by the reaction of C atoms and Mo atoms. Once the growth is finished,  Mo2C can be further transferred to any target substrate by etching Cu, which is similar with the transferring of graphene [91]. However, it should be noted that the thinnest  Mo2C film is composed of at least six layers of  Mo2C rather than a monolayer film, suggesting that the growth of monolayer film needs further optimization [90]. 

Geng et al. reported an one-step directly growth of  Mo2C where its size can be grown as large as centimeter [92]. Through controlling investigation, it was found that there is no graphene layer formed with low methane flax. However, at higher methane flax, the graphene would firstly form on the surface of liquid Cu, and the migrated Mo atoms would go through the graphene layer and form the  Mo2C cluster on the surface of graphene. Thus, the underlayer graphene would work as a buffer layer during the growth and guild the further growth of  Mo2C crystal with its preferable morphology. Furthermore, the graphene layer would also block the migration of Mo atoms, resulting in the thin of  Mo2C crystal (about 8.32 nm). If there is no graphene layer, the as-grown  Mo2C crystal can be as thick as 237 nm. In addition, the thickness of  Mo2C crystal can be tuned by varying the thickness of cooper layer, where the kinetics of Mo diffusion across the Cu layer can be modulated. The thinnest  Mo2C crystals with thickness of 9.5 nm corresponding to 20 layers were obtained [93]. With the similar method, Zhang et al. placed the V foil, Cu foil and W foil in order. At higher temperature, the Cu foil would be melted on the surface of W foil; however, the V foil is still solid state. By 

controlling the temperature and methane flax, the VC flakes can be obtained on the surface of Cu foil and its thickness is about 12 nm [94]. By increasing the flux of hydrogen flax, it was found that the morphology of VC crystal would evaluate from continue film to branch shape, suggesting the etching role of hydrogen. Interestingly, although the W foil was employed as the substrate, there was no WC crystal formed. As a comparison, the researchers also found that there are no crystal-like VC flaks but only dense VC polycrystalline film formed when using Cu foil/V foil as the source, due to the large amount of migrated V ions on the Cu surface. 

Ikenoue et al. prepared the uniform  WC1-x film on the substrate surface by mist CVD method, where the  WCl6 acetonitrile solution was carried into the furnace by Ar/H2 mixture gas. When the temperature is higher than 650 °C, WC1-x begins to form, and with the increase in preparation temperature, the element ratio of C/W is gradually close to 1. Mechanical characterization shows that the hardness and Young’s modulus of  WC1-x films grown at 750 °C are 25 and 409 GPa, respectively [97]. Atomic layer deposition has also been used to prepare NbC thin films by employing  NbF5 and NbCl5 as the raw materials, TMA as a carbon source and reducing agent. The NbC film is amorphous with a thickness of about 60 ~ 70 nm. If the film is thicker, NbC nanocrystals with a diameter of 15 nm will be formed. SQUID magnetometer measurements show that the 75-nm-thickness NbC film displays superconducting behavior where its transition temperature is about 1.8 K [52]. 

Carbide films with different compositions which synthesized by CVD, such as Ti  (CxNy), TiC/TiN, TiC/Al2O3, TiC/ TiB2 and TiC/Al2O3/TiN multilayer films, have been developed and applied [98]. However, some problems have been found in the process of gas-phase synthesis: the synthesized carbides are usually polluted by the pollutant produced by the pyrolysis of carbonaceous gases. The pollutants block the pores, wrap the active sites on the surface of the carbides, which are difficult to be eliminated. In addition, most gasphase synthesis processes are not only tedious and complex, but also involve the use of expensive and toxic reagents, such as gaseous molybdenum precursors, which are harmful to organisms and the environment. Thirdly, the current reaction toward single-crystal TMCs film is usually carried out under the assistant of Cu and high temperature. Considering the plasma or laser treatments may help to improve the activity of transition metal or the carbon source, the growth temperature may decrease such as growing by plasma-assisted 

1 3 

**183** Page 12 of 34 

Nano-Micro Lett. (2021) 13:183 

chemical deposition or laser-assisted chemical deposition. In addition, the development of the transition metal-based organic gaseous precursor may help to grow the TMCs film by metal–organic chemical vapor deposition, which can further optimize the growth condition. 

##### **3.3  Temperature‑programmed Reduction** 

To improve the catalytic property of TMCs, one of the strategies is that synthesize TMCs with high surface area. With the developing, some methods have gradually developed, including gas-phase reactions that occur using gaseous precursors of metal compounds, reactions between gaseous reactants and solid metal compounds, and thermal decomposition of metal precursors. Among them, the temperatureprogrammed reduction (TPR) developed by Boudart et al. has a broad prospect [99]. So far, almost all the work has been focused on the synthesis of molybdenum and tungsten based carbides, and few other transition metal carbides have been studied. However, TPR has broad research space in the synthesis of binary and ternary early transition metal carbides used in the field of catalysis, due to its easily synthesis condition [100]. It was found that below 1500 K, the mixture of Mo and C has the four phases: Mo, β-Mo2C, α-MoC1-X and C, which depends on the relative content of the two components [101]. Through the study of Teixeira, the synthesis temperatures are 1170 K for both NbC and vanadium carbide [102–104]. However, to synthesize the TaC, the temperature should increase to 1220 K [105]. Directly carbonizing metal has also been studied, where a W/C (10 nm/20 nm) planar heterostructure was pre-prepared by magnetron sputtering. Then, the original crystallization of W/C heterostructure was studied in the temperature range of 300 to 1200 °C. It is found that the nucleation process of reactive synthesis of metal carbides is realized by twostep mechanism. Firstly, the amorphous intermediate with spinodal structure is formed by an amorphous precursor, and then, nucleation of amorphous intermediate occurs [106]. 

Besides the transition metal was used as the source, John et al. demonstrated that the TMCs can also be synthesized by employing vanadium, niobium, tantalum, molybdenum, tungsten and other binary or ternary oxides as transition metal raw materials. During the TPR process, it seems that it is easier to synthesize carbides for the ternary oxides of V group and VI group, because either the reaction rate is faster 

or the synthesis temperature is lower [100]. Post-annealing treatment has also been carried out. After post-annealing at 1500, 1600, 1700 and 1800 °C for 2 h, it was found that the lattice constant and average grain size of ZrC increased. The crystal grain orientation changed and the crystallinity of ZrC increased with the annealing temperature; at the same time, the structural defects decreased and the hardness decreased slightly [107]. Sun et al. have synthesized high-quality and high-density TaC through the high-pressure high-temperature (HPHT) sintering method. Under a pressure of 5.5 GPa, the pre-compressed TaC powder is heated to 1400 °C with a temperature increase rate of 150 °C  min<sup>−1</sup> . After holding for 20 min, the sample was quenched to room temperature at a cooling rate of 150 °C min<sup>−1</sup> . The Vickers indentation test shows that the TaC sample has a mechanical strength of 20.9 ± 0.5 GPa, which is about 35% higher than the reported data [108]. 

To prepare the TMCs film by the TRP, polymer-assisted deposition (PAD) has been employed where the transition metal ion would first bind with polymer. Zou et al. prepared the Ti, V or Ta precursor by binding these ions with EDTA and PEI polymer, as shown in Fig. 8 [109]. Through annealing the spin-coated precursor, the TiC, VC and TaC films have been prepared. Especially, it was found that the asprepared TMCs film has high quality and epitaxial on the sapphire substrate, where its grain size and roughness are 50 and 3.5 nm, respectively. Further studying shows that the hardness and Young’s modulus of TiC films are 21.27 and 413 GPa. The TiC film shows a semiconducting behavior, where its resistivity at room temperature is about 372 μΩ cm. By the similar method, the uranium dicarbide films have also been epitaxially grown on yttria-stabilized zirconia substrate [110]. The investigation exhibits that by controlling the precursor and the annealing progress, it was able to prepare TMCs film with high quality. Considering the low cost and high yield of spin-coating technology, this method can grow TMCs with large scale. However, controlling binding the transition metal ions with polymer is still a challenge, the binding rate needs further optimization. 

##### **3.4  Magnetic Sputtering** 

Magnetic sputtering is another kind method to grow film with large scale, which has also been utilized to grow TMCs films. Due to the high wear resistance, 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 13 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(a) (b) (c)<br> 60°<br>FWHM = 0.4°<br> 30°<br>30 35 40 45 17.0 17.5 18.0 18.5 19.0 19.5 0 50 100 150 200 250 300 350<br>2θ( degree) ω( degree) Φ( degree)<br>(d) (e)<br>C<br>Å<br>120.0<br>4.28 MeV 4He +<br>µm<br>80.0 0.31 2<br>0.15<br>1.5<br>0.00 O<br>40.0 2 1 Al Ti<br>1.5<br>1 0.5<br>0.0 0.5<br>0 0 100 200 300 400 500 600 700<br>Channel<br>Al2O3<br>TiC<br>µm<br>µm<br>)1<br>1<br>1<br>(<br>CTi<br>Intensity (a.u.) Intensity (a.u.) Intensity (a.u.)<br>Intensity (a.u.)<br>)6<br>0<br>0<br>(<br>l<br>OA32<br><!-- End of picture text -->

**Fig. 8** Preparation of TiC by temperature-programmed reduction. **a** - **c** XRD analysis of TiC film. **d** AFM morphology of TiC film. **e** Element analysis of TiC film. Reproduced with permission from Ref. [109]. Copyright 2010, American Chemical Society 

conductivity, hardness and oxidation resistance, niobium carbide has been well studied than other TMC materials [23, 111–113]. By DC reactive magnetron sputtering using pure Nb target, the effects of deposition rate, chemical bonding, phase composition, microstructure and internal stress on the properties of the  NbCx films have been studied [23, 114]. The results show that the hexagonal  Nb2C phase would form when the carbon content is 32.7 at%. However, cubic NbC phase with a mixed orientation of (111) and (200) would form when the carbon content is higher than 32.7 at%. Thus, by tuning the carbon content, the phase can be varied between hexagonal  Nb2C and cubic NbC. Considering the hexagonal  Nb2C phase has higher hardness than that of cubic NbC phase [115, 116], the Nb-based TMCs film with tunable hardness can be prepared by tuning the carbon content. In addition, when the carbon content is varied from 41.8% to 68.7%, the grain 

size would decrease monotonically from 40.6 to 3.9 nm [114]. Molybdenum carbide film has also been grown by radio frequency magnetron sputtering by using  Mo2C target, and its application in the generation of solid-state passive Q-switched pulsed lasers has been studied [117]. At 1064 and 1342 nm, the  Mo2C films show a large nonlinear saturated absorption, and the modulation depth is 10.39% and 8.89%, respectively, suggesting a well broadband nonlinear optical application. 

By magnetic sputtering, the TMC film with large scale can be grown facilitating its potential application; however, the technology has not well investigated. More efforts may input to study its crystallization and texture; the additional carbon sources also need to be considered to improve the carbon vacancy. 

1 3 

**183** Page 14 of 34 

Nano-Micro Lett. (2021) 13:183 

### **4  Application of Transition Metal Carbides** 

##### **4.1  Electrocatalysis and Photocatalysis** 

At present, precious metals such as platinum (Pt), palladium (Pd) and rhodium (Ru) have shown favorable activity toward hydrogen evolution reaction (HER). However, the application of these precious metals is greatly hindered because of their low abundance and high cost. TMCs with high abundance in the earth, such as  Ni3C,  Mo2C and VC, have been proved to be excellent catalysts for HER both theoretically and experimentally. Most of the previous studies on TMCs were conducted on low surface area materials. However, the key to the preparation of high efficiency catalyst lies in the synthesis of high surface area materials [118]. Theoretical calculation shows that TMCs meet the basic requirements of hydrogen evolution reaction (HER). In fact, TMCs (such as  Ti2C,  V2C and  Ti3C2) with -OH and -O on their surface are the basis of their metallicity, which causes charge transfer and transport. In addition, oxygen atoms which on the surface of TMCs provide active sites for HER, because the interaction between O atoms and H atoms on the surface of TMCs promotes the removal of hydrogen [119–121]. The volcano curve reflects the ability of various TMCs for HER in Fig. 9. TMCs at the top of the volcano have the highest catalytic activity, such as  Ti2CO2,  W2CO2,  TiVCO2 and  Nb2CO2. In addition, bimetallic TMCs  (M1M2CO2) are also potential candidates because they have moderate H2 adsorption free energy catalysts for HER, thus showing higher activity. For these reasons, TMCs-based systems have become a hot spot in the design of electrocatalysts and solarpowered photocatalysts [122]. 



<!-- Start of picture text -->
0 Ti2CO2<br>(C-side)Ti3CN Pt Zr4C3S2<br>Ti3C2O2 Nb2CO2<br>V2CO2 Mo2VC2<br>−5 WC Fe3C Mo2CCo3C MoS2 Nb4C3O2 Mo2TiC2<br>Nb3CN Nb3CN<br>(C-side) (N-side) Ag<br>−10<br>Nb4C3<br>Nb2C V2C<br>−15<br>Ti3C2<br>−20<br>−1.0 −0.5 0.0 0.5 1.0<br>∆GH (eV)<br>2))−<br>m<br>(/(A i Lc go0<br><!-- End of picture text -->

**Fig. 9** Exchange current as the function of Gibbs free energy of hydrogen adsorption of TMCs 

Using the adsorption of atomic hydrogen as a probe, the chemical properties of the surfaces of different carbide can be studied. Due to the tensile strain generated on the carbide surface when carbon is bonded to the crystal lattice, the adsorption of hydrogen to the carbides surface which at the end of metal is stronger than that to the tightly filled pure metal surface. John et al. found that the adsorption of hydrogen atoms on the Mo terminated surface of molybdenum carbide is much stronger than that on the surface of pure metal Mo (110) [19]. Compared to the ground-state pure metal surface, the metal terminated surface of the carbide has the lower hydrogen bonding energy (HBE) values. It can be seen that for other carbides except VC, the adsorption of H on the terminated surface of TMCs is stronger than that on the surface of pure metal. One of the reasons for the strong adsorption energy of the TMCs surface may be that the carbide surface is in a state of tensile strain compared with the pure metal surface. The distance between metal atoms in TMCs is farther than the distance between metal atoms in pure metal [19]. 

Wan et al. have systematically analyzed the crystal structure, electronic properties, free energy, surface energy and crystal formation energy of  V4C3,  V8C7 and  VC3 during HER and OER processes by using the first-principles calculation method [123]. The results show that the vanadium carbide has excellent HER performance but poor OER activity. In particular,  V8C7 has the best HER activity in these vanadium carbide phases. Compared with other phases,  V8C7 has excellent catalytic activity, which can be attributed to the following factors: (i) larger surface energy is easier to capture ionized hydrogen/oxygen; (ii) more moderate hydrogen adsorption energy can accelerate HER rate; (iii) lower crystal formation energy and easier formation of C defects increase the specific surface area and active center of HER, and provide faster charge transport for HER; (iv) larger VC bond length and weaker bond strength contribute to the formation of suitable hydrogen absorption energy and smaller free energy ΔG (H*). In addition, there is a significant similarity in the density of d-band states between VC/V8C7 and Pt on the (110) and (111) crystal planes, indicating that the HER mechanism of VC/V8C7 is similar to Pt [123]. 

Experimentally, Tian et al. found that the combination of vanadium carbide and  TiO2 can be used as an effective and stable co-catalyst for photocatalytic hydrogen evolution [124]. As a co-catalyst, VC can not only effectively capture the photogenerated electrons from  TiO2, greatly improve 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 15 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

the separation efficiency of photogenerated charges, but also significantly reduce its overpotential, thus enhancing the catalytic activity of  TiO2/VC. Besides, the vanadium carbide has also be hybridized with active metal nanoparticle, where Pt nanoparticles with an average particle size of 3 nm are evenly distributed on the surface of carbon and cubic vanadium carbide (Pt/VC-C), which can be used as an electrocatalyst for oxygen reduction reaction (ORR) [125]. The combination of Pt nanoparticles and cubic vanadium carbide nanoparticles is beneficial to enhance the synergistic effect. Compared with the reversible hydrogen electrode (RHE), the mass activity of ORR on the surface of Pt/VC-C can reach 230 mA  mg<sup>−1</sup> Pt<sup>at 0.9 V, which is 2.4 times higher than that</sup> of Pt/C electrocatalyst (97 mA  mg<sup>−1</sup> Pt<sup>). Furthermore, the</sup> vanadium carbide has also been demonstrated to effectively encapsulate on carbon-based skeleton, delivering a great 

HER activity such as a current density of 100 mA  cm<sup>−2</sup> and an overpotential of 238 mV [126]. Yoon et al. successfully doped  V2CTx with controllable concentration of phosphorus. The experimental results are in good agreement with the theoretical calculation that the P–C bond in P-V2CTx works as active sites promoting the weakening of the hydrogen bond strength and leads to the desorption of  Hads during the HER process.  V2CTx with the highest P–C bond concentration exhibits a Tafel slope of 74 mV  dec<sup>−1</sup> and an overpotential of 163 mV at 10 mA  cm<sup>−2</sup> [127, 128]. 

Molybdenum carbide has been widely employed as electrocatalyst to split water, as shown in Table 3. Chen et al. studied the formation of molybdenum carbide from ammonium molybdate in inert environment. It was found that the coupling effect caused by the covalent bond between  Mo2C and carbon carrier has a unique effect on the electrochemical 

**Table 3** Electrocatalytic performance of transition metal carbides 

|Sample|Prepare method|Morphology|HER or OER|Tafel slope (mV  dec<sup>−1</sup>)|Overpotential<br>at 10 mA  cm<sup>−2</sup><br>(mV)|Refs|
|---|---|---|---|---|---|---|
|Ti3C2|Chemical exfoliation|Nanofibers|HER|97  (H2SO4)|169|[7]|
|Ti2CTx|Chemical exfoliation|i<br>Nanosheets|HER|100  (H2SO4)|75|[138]|
|W2C|Microwave combustion|Nanodots|HER|45  (H2SO4)|71|[139]|
|Mo2C|Microwave combustion|Nanodots|HER|46  (H2SO4)|77|[139]|
|Mo2C|Precipitation and calcine|Nanoporous|HER|54  (H2SO4)|200|[140]|
|α-Mo2C|Urea-glass route|Nanoparticles|HER|57 (KOH)|176|[141]|
|Mo2CTx|Chemical exfoliation|Nanosheets|HER|189  (H2SO4)|75|[142]|
|Mo2TiC2Tx|Chemical exfoliation|Nanosheets|HER|248  (H2SO4)|74|[142]|
|Mo2Ti2C3Tx|Chemical exfoliation|Nanosheets|HER|275  (H2SO4)|99|[142]|
|TaC NCs@C|Micro-cutting-fragmen-<br>tation|Nanocrystals|HER|143  (H2SO4)|146|[143]|
|Ta-Hf-C|Magnetron sputtering|Films|HER|129  (H2SO4)|198|[144]|
|Co3W3C|TPR|Nanoparticles|OER|59 (KOH)|238|[145]|
|Ni0.7Fe0.3PS3@MXene|Solid-state reaction|Nanohybrid|OER|36.5(KOH)|282|[146]|
|Ni-MoxC|Thermal conversion|Graphene/nanotube<br>hybrid|OER|74(KOH)|328|[147]|
|Fe-Ni3C|Carburizing treatment<br>f|Nanosheets|OER|62(KOH)|275|[148]|
|Ti3C2Tx− CoBDC|Interdiffusion reaction|Nanosheets|OER|48.2(KOH)|410|[149]|
|Co3Mo3C|f<br>TPR|Micrometers particles|HER|93 (KOH)|169|[150]|
|N-Ti2CTx|Chemical exfoliation|Nanosheets|HER|67  (H2SO4)|215|[151]|
|Co-Mo2C|Carbonization|Nanosheets|HER|39  (H2SO4)|48|[152]|
|Mo2C-C|spray drying and calcina-<br>tion|Flake structure|HER|69  (H2SO4)|110|[153]|
|Ti3C2Ox|Chemical exfoliation|2D flakes|HER|60.7  (H2SO4)|190|[154]|
|W2C@GL|Heat treatment|l<br>Nanoparticles|HER|68  (H2SO4)|135|[155]|
|Mo-WC@NCS|TPR|Nanosheet|HER|81 (KOH)|179|[156]|
|VC@NC/C|TPR|3D network|HER|165 (KOH)|238|[126]|



1 3 

**183** Page 16 of 34 

Nano-Micro Lett. (2021) 13:183 

performance. First of all, the conjugation with high bond strength can promote the close combination of  Mo2C catalyst and carbon carrier, and provide a low resistance path suitable for rapid electron transfer. Secondly, this binding hinders the aggregation of  Mo2C nanoparticles, thus promoting the production of highly active sites on the surface. Third, anchoring induces the transfer of charge from molybdenum to carbon, which further reduces the d-band center of molybdenum, thus reducing the hydrogen bonding energy of molybdenum. This, in turn, is beneficial to the electrochemical adsorption of  Hads, resulting in a relatively moderate Mo-H bond binding strength, which enhances the HER performance. Molybdenum itself is considered to be a strong hydrogen-bonded metal due to its unique d-band position [129, 130]. To further improve the activity and the amount of active sites, doping heteroatoms has been considered. After boron doping [131], the HER activity of  Mo2C catalyst is significantly improved, where the slope of Tafel downs to 78 mV  dec<sup>−1</sup> , which is much smaller than that of the blank control (134 mV  dec<sup>−1</sup> ). In addition, the nitrogendoped WC nano-arrays also show excellent HER activity, where overpotentials were 89 and 190 mV corresponding to the current density of 10 and 200 mA  cm<sup>−2</sup> , respectively. Furthermore, the initial potential of the water splitting is 1.4 V when employing N-WC nano-array as both the cathode and anode, suggesting its high activity [132]. This is mainly due to the increase in the number of active sites, the turnover frequency increases, and the resistance to electron transfer decreases. 

Metallic alloy effect has also been studied such as MoW–C [133–135]. When the Mo/W ratio of this bimetal hollow sphere is adjusted to 1.26/0.74, the overpotentials are 106, 127, and 152 mV corresponding to use 1 M KOH, 0.5 M  H2SO4 and 1 M phosphate buffer as the medium, respectively, indicating its board activity. Specially, the overpotential of the  Mo1.26W0.74C@C in alkaline and acid electrolytes is only 237 and 250 mV at the current density of 300 mA  cm<sup>−2</sup> , which is obviously better than most reported electrocatalysts. Chen et al. used a new metal–organic framework derivatization method to synthesize a vertically arranged pure phase porous bimetallic carbide with N-doped carbon as a matrix on a flexible carbon cloth  (Co6W6C@NC/ CC). It exhibits excellent OER activity with an overpotential of 286 mV at 10 mA  cm<sup>−2</sup> . At the same time, it exhibits an enhanced HER activity with an overpotential of 59 mV at 10 mA  cm<sup>−2</sup> . The unique HER activity of bimetallic alloy 

based TMCs can be mainly attributed to the synergistic effect which not only modulated the electronic structure, activity of the active site, but also tuned its conductivity [134]. Except the Mo- and W-based TMCs, other TMCs have not been well studied. Kou et al. prepared the tantalum carbide nanocrystals (TaC NCs@C) adhered to carbon, which have high refractive index (222) crystal planes. Due to the formation of a transition zone between the carbon layer and the (222) crystal planes of TaC, its stability in the process of preparation and electrochemical reaction is enhanced. TaC nanocrystals have a low overpotential of 146 mV at 10 mA  cm<sup>−2</sup> , a large exchange current density of 9.69 ×  10<sup>–2</sup> mA  cm<sup>−2</sup> and excellent cycle stability, which is far superior to other reported group-V metal carbide catalysts [136]. 

Besides employing as the electrocatalysts, the TMCs have also been used in photocatalysts; however, it is still in infant. Huang et al. used tungsten carbide to degrade organic pollutants by near-infrared photocatalysis. The experimental results are well consisted with the three-dimensional finite element simulation, which prove that plasmon resonance responding from WC nanoparticles can occur on the local surface of the near-infrared light, thereby showing high UV–Visible-NIR full-spectrum absorption and high nearinfrared triggered photocurrent response. It has near-infrared photocatalytic degradation performance and the catalytic degradation rate of methylene blue (MB) by WC nanoparticles under near-infrared radiation is up to 50% [137]. 

##### **4.2  Gas Catalysis and Sensing** 

The gas molecular conversation would greatly increase the utilization of production in petrochemical industry. The physical and chemical properties of molybdenum carbide with different phases have a significant difference, especially in the field of catalysis. It is known that the catalytic performance of fcc-MoC1-x is different from that of hcp-Mo2C in ethane hydrogenation, methanol reforming to hydrogen production, toluene hydrogenation and CO hydrogenation [81]. For example, the CO hydrogenation activity of cubic phase fcc-MoC1-x is twice as high as that of hcp-Mo2C hexagonal phase, while hcp-Mo2C is more active than fcc-MoC1-x in ethane hydrolysis. In addition, hcp-Mo2C nanoribbons with unsaturated Mo sites on surface have higher activity than fcc-Mo2C nanoribbons in the dehydrogenation of benzyl 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 17 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

alcohol. The different catalytic activities of different phases in molybdenum carbides may be attributed to the influence of surface structure [157]. Dudari et al. prepared molybdenum carbide by Pechini method and  CH4/H2 carburizing gas temperature-programmed reduction method. It was found that the molybdenum carbide prepared by Pechini method mainly contains face-centered cubic  MoC1-x phase, while the  Mo2C phase prepared by TPR method has hexagonal compact packing structure. And the defect phase can be produced by changing the flow rate of Carburizing gas [157]. In addition, the molybdenum carbide has also been demonstrated showing the well catalytic performance in butane 

dehydrogenation and  CO2 hydrogenation [158]. Theoretical investigation proves that a rectifying contact is formed at the interface between MoC nanoparticles and nitrogen-doped carbon, which can promote the adsorption and activation of gas molecules, thereby selectively forming formic acid (FA). Molybdenum carbide with different phase structure show different activity and stability for WGS catalytic reaction. The layered  Mo2CTx had better catalytic activity and stability than other molybdenum carbide structures (as shown in Fig. 7f), and had high selectivity for  CO2 and  H2 [159]. The doped molybdenum carbide samples (MoC/N5.6C) with significant electron enrichment obtained in the experiment 



<!-- Start of picture text -->
(a) Acetone Ti C O H F<br>W18O49 NRs<br>Ti3C2Tx sheet<br>(b) (c) 15<br>Methane Acetone<br>V 11.16<br>10 9.399<br>5<br>3.504<br>1.375<br>V2CTx MXene<br>Electrode 0<br>(d) State-of-the-art: V2CTx MXene (e) State-of-the-art: V2CTx MXene (f) 150 CO+H2O CO2+H2 100<br>Hydrogen Carbon-based Methane Carbon-based Mo2CTx<br>80<br>TMDs VOx 120 Mo2CTx-500<br>β-Mo2C<br>V2CTx V2CTx V2CTx V2CTx 90 60<br>Pd-CNW [62] Pd-GO-PS [7] Graphene/PANI [66] G-SnO2[68] GO [6]<br>Pd-WS2[54] rGO-GaNPd-MoS [63] 2[37] MWCNT-V2O5[67] RGO-SnO2[6] 60 conversionEquilbrium 40<br>Pd-SnO2/MoS2[38] UV-MoS2[65] VO2[69] Au-VOPt-VOx2[70][71] 30 20<br>1 10 100 1 10 100 1000 10000<br>0 0<br>Limit of Detection (ppm) Limit of Detection (ppm) 400 500 600 700 800<br>T  (°C)<br>{Theoretical}{Empirical}<br>{Theoretical} {Empirical}<br>%)<br>(<br>n<br>oiser<br>v<br>n<br>o<br>c<br>O<br>C<br>SH2<br>e<br>n<br>toe<br>c<br>A H2<br>)o<br>(Mg<br> )<br>O<br>C<br>( lo<br>m<br>µ<br>−1−1 s<br>Methane<br><!-- End of picture text -->

**Fig. 10** Gas catalytic property of TMCs. **a** Schematic of the reaction between acetone and  W18O49/Ti3C2Tx composite. Reproduced with permission from Ref. [163]. Copyright 2020, Elsevier. **b** Schematic diagram of the sensing mechanism of the  V2CTx gas sensor. **c** Theoretical LoD of  V2CTx film toward acetone, methane, hydrogen and hydrogen sulfide at room temperature. Comparison of LoD of **d** hydrogen and **e** methane for room temperature gas sensor. Reproduced with permission from Ref. [161]. Copyright 2019, American Chemical Society. **f** WGS catalytic activity of  Mo2CTx,  Mo2CTx-500, and β-Mo2C. Reproduced with permission from Ref. [159]. Copyright 2019, American Chemical Society 

1 3 

**183** Page 18 of 34 

Nano-Micro Lett. (2021) 13:183 

can be used as a stable catalyst to efficiently produce FA through  CO2 hydrogenation, which is superior to the existing non-precious metals based catalysts. In this study, a durable Schottky heterojunction catalyst with low cost and high performance was designed, which opened up a new way for the application of doped molybdenum carbide in the field of hydrogenation reaction, and further promoted the research on carbon dioxide emission reduction. Except the Mo-based catalysts, Pajares et al. studied the property of  VCx with different phases: stoichiometric VC phase and C-deficient V8C7 phase. On the reverse water gas shift reaction,  V8C7 showed higher  CO2 conversion rate, CO selectivity, lower apparent activation energy and good chemical stability [160]. Besides as catalysts in gas molecular conversion, the TMCs can also be employed to sense dangerous gas. Sun et al. prepared a composite of one-dimensional  Ti3C2Tx and one-dimensional  W18O49 nanorods (as shown in Fig. 10a) [161]. Based on the special interface effect, the composite exhibits high responsiveness to acetone, and has ideal selectivity and long-term stability. Lee prepared layered  V2CTx MXene on polyimide substrate by chemical exfoliation. The two-dimensional  V2CTx MXene gas sensor shows ultra-low detection limit (2 ppm) for  H2 at room temperature, which is better than other two-dimensional gas sensor materials reported at present (as shown in Fig. 10c-e) [161]. In a word, in both catalysis gas conversion and sensing gas, the interface of TMCs and gas molecular plays an important role [162], which could occupy the gas molecular and materials. More efforts should be focused on the interface and improve its occupied mechanism, thus enhancing the interaction. 

##### **4.3  Energy Storage** 

With the environmental crisis, developing energy storage such as battery and supercapacitor has been considered as an environment-friendly strategy. Different with black phosphorene, which has ultra-high diffusivity of Li along the zigzag direction and enhanced electrical conductivity after Li- intercalation [164, 165], TMCs with large specific surface area, good electrical conductivity and excellent cationic intercalation properties have been widely used as electrode materials in energy storage [166].  Nb2C and  V2C show good reversible capacity, high cycle rate and stability, indicating that the rapid diffusion of Li between MXene layers has application prospects in the field of high power [167]. Pang 

et al. introduced a fluorine-free, simple and rapid method for synthesizing one-dimensional metal carbide nanowires based on three-dimensional  Nb2CT MXene. The method can synthesize one-dimensional metal carbide nanowires in HCl electrolyte within 4 h. It was found that MXene-based Nb2CT nanowires can maintain high stability at a fairly low overpotential (236 mV), and as a water-based zinc-ion battery exhibiting the high power density (420 W  kg<sup>−1</sup> ) after 150 cycles [77]. V-based TMCs have better performance than many other TMCs and attracted much attention.  V4C3 was used as the anode material of lithium-ion battery, demonstrating that  V4C3 has high capacity, good rate performance and cycle performance. In the case of current density of 0.1 A  g<sup>−1</sup> ,  V4C3 can still provide a high specific capacity of 225 mAh  g<sup>−1</sup> after 300 charge–discharge cycles [168, 169]. Wang et al. prepared high purity  V2CTx by a simple hydrothermal assistant method using the mixed solution of NaF and HCl as etchant, and studied the effects of reaction conditions, reaction time and reaction temperature on the reaction yield [137]. It was found that the reaction rate of this system is much faster than that of HF system, and the MAX phase can be etched in three days. At the same time, the electrochemical performance of lithium-ion battery as anode was studied, and it showed a high specific capacitance. When the current was 0.1 A  g<sup>−1</sup> , the capacity of lithium-ion battery was 233 mAh  g<sup>−1</sup> . 

Through chemically etching and exfoliation, the asprepared  Nb2CTx nanosheets can provide a high discharge capacity of 354 mAh  g<sup>−1</sup> at a current density of 0.05 A  g<sup>−1</sup> . In addition,  Nb2CTx has good cycle stability, where after 800 cycles at a high current density of 1.0  Ag<sup>−1</sup> , the specific capacity is stable at 225 mAh  g<sup>−1</sup> , indicating that  Nb2CTx can be used as an anode material for LIBs [170]. Nano-NbC decorated N&P-codoped trichoderma spore carbon was synthesized and exhibited an ultra-high rate performance (810 mAhg<sup>−1</sup> at 5 C) and good cycle stability (937.9 mAh  g<sup>−1</sup> at 0.1 C after 500 cycles) due to the high conductivity attributing to the synergistic effect [171]. Besides, nanocrystalline niobium carbide (NbC) was used as an advanced intermediate layer material for Li–S batteries. The NbC coating combines the anchoring effect of polysulfide (PS) with the advantages of high conductivity, which can effectively inhibit the electrochemical reaction of sulfur and the shuttle of PS. The NbC coating also has excellent cycling stability, the capacity decay rate after 1500 cycles is only 0.037% cycle<sup>−1</sup> , and it has an ultra-high rate capability of up to 5 C, 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 19 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

**Table 4** Energy storage performance of transition metal carbides 

|Sample|Prepare method|Structure|Application|Charge density|Performance|Retention rate|Refs|
|---|---|---|---|---|---|---|---|
|Ti3C2Tx|Chemical exfoliation|Nanosheets|Na-ion battery|0.5 C|103 mAh  g<sup>−1</sup>|85.8% after 500<br>cycles|[181]|
|Titanium carbide|Chemical exfoliation|Nanorods|Li-ion battery|1 C|843 mAh  g<sup>−1</sup>|98.78% after 250<br>cycles|[182]|
|Porous-  Ti3C2Tx|Chemical exfoliation|Nanosheets|Li-ion battery|0.1 C|1250 mAh  g<sup>−1 </sup>|N/A|[183]|
|V2CTx|Chemical exfoliation|Few-layer nanosheets|Al-ion battery|0.5 C|76 mAh  g<sup>−1</sup>|96.6% after 100<br>cycles|[173]|
|Nb4C3Tx|Chemical exfoliation|Layered structure|Li-ion battery|5 C|380 mAh  g<sup>−1</sup>|84.2% after 1000<br>cycles|[184]|
|Co3ZnC|TPR|Microspheres|Li-ion battery|0.5 C|908 mAh  g<sup>−1</sup>|67.0% after 300<br>cycles|[185]|
|TiO2/  Ti3C2Tx|Self-assembly|2D heterostructures|Li-ion battery|0.25 C|277 mAh  g<sup>−1</sup>|75.5% after 200<br>cycles|[186]|
|Nb2O5@Nb4C3Tx|Chemical exfoliation|Layered architecture|Li-ion battery|0.25 C|208 mAh  g<sup>−1</sup>|94% after 400 cycles|[187]|
|Fe3C@N–C|Calcinate|Frogspawn-like<br>architecture|Li–S battery|0.5 C|586 mAh  g<sup>−1</sup>|99.92% after 400<br>cycles|[188]|
|W2C NPs-CNFs|TPR|Nanoparticles<br>l|Li–S battery|1 C|605 mAh  g<sup>−1</sup>|99.4% after 500<br>cycles|[189]|
|TiC|Biotemplate method|Nanoflakes|Supercapacitor|5 mV  s<sup>−1</sup>|276.1 F  g<sup>−1</sup>|94% after 1000<br>cycles|[190]|
|Ti3C2Tx|Directly annealing|Nanosheets|Supercapacitor|0.5 A  g<sup>−1</sup>|442 F  g<sup>−1</sup>|95.4% after 5000<br>cycles|[191]|
|TaC/C|Laser ablation|Nanospheres|Supercapacitor|1 A  g<sup>−1</sup>|223 F  g<sup>−1</sup>|94% after 5000<br>cycles|[192]|
|MoS2/Ti3C2|Hydrothermal syn-<br>thesis|2D heterostructures<br>l|Supercapacitor|1 A  g<sup>−1</sup>|386.7 F  g<sup>−1</sup>|91.1% after 20,000<br>cycles|[193]|
|MnO2-Mo2C NFs|Electrospinning|Nanoflakes|Supercapacitor|0.1 A  g<sup>−1</sup>|430 F  g<sup>−1</sup>|96.1% after 3000<br>cycles|[194]|



and the area capacity under high sulfur load is as high as 3.6 mAh  cm<sup>−2</sup> [172]. 

Compared with commercial lithium-ion batteries, rechargeable aluminum batteries have the advantages of safety, cheaper and higher energy density. Table 4 summarizes the recent TMCs-based energy storage development. However, due to the high charge density of  Al<sup>3+</sup> ions and their strong interaction with the host lattice, few  Al<sup>3+</sup> ions can reversibly intercalate these cathode materials. Vahid et al. reported a rechargeable Al-battery based on 2D vanadium carbide  (V2CTx) cathode. The mechanism of charge storage is the reversible intercalation of  Al<sup>3+</sup> ions between V2CTx layers. The results show that the electrochemical performance can be significantly improved by converting V2CTx particles into multilayer films. The specific capacity of  V2CTx electrode is more than 300  mAg<sup>−1</sup> Pt<sup>, and it has</sup> higher discharge rate and higher discharge potential, which 

is one of the best cathode materials for aluminum battery reported at present [173]. 

Like the  MnO2, etc., metal oxides which have shown high electrochemical property resulting in high performance electrochemical capacitors [174, 175], the TMCs have also been used as electrode in supercapacitor, which has high power density [176–179]. Xin et al. predicted the application in supercapacitors through ab initio density functional theory considering its quantum capacitance and work function of Nbn+1CnTx. It was found that the niobium carbide with free functional group is suitable for positive electrode, while niobium carbide with functional group has better performance as negative electrode in supercapacitor, showing its broad application prospects in the field of supercapacitor electrode materials. The theoretical quantum capacitances of the positive and negative electrodes are 1828.4 and 1091.1 F  g<sup>−1</sup> , respectively [75]. Guan et al. demonstrated that the 

1 3 

**183** Page 20 of 34 

Nano-Micro Lett. (2021) 13:183 

specific capacitance of chemically exfoliated  V2CTx MXene can reach up to 164 F  g<sup>−1</sup> and its specific capacitance retention rate can reach 90% after 10,000 cycles at 5  Ag<sup>−1</sup> [74]. Wang et al. prepared  V2C layered by carbon nanotubes and studied its electrochemical performance as the electrode of Zn ion supercapacitor, which has a high capacity of 190.2 F g<sup>−1</sup> at 0.5  Ag<sup>−1</sup> and excellent cycle stability [139]. Besides, the used electrolyte also significantly affects its supercapacitance; the maximum specific capacitances of  V2CTx MXene in 1 M  H2SO4, 1 M KOH and 1 M  MgSO4 solutions are 487, 184 and 225 F  g<sup>−1</sup> , respectively, which are the highest among similar micron TMCs electrodes reported [180]. Using seawater as the electrolyte, the supercapacitor based on  V2CTx MXene has a volume specific capacitance of 317.8 F  cm<sup>−3</sup> at 0.2 A  g<sup>−1</sup> and its capacitance retention rate is 8.1% after 5000 cycles [72]. The supercapacitance of bimetallic TMCs has also been studied. Through studying the influence of ratio of Mo and V in bimetallic MXene, it was found that  Mo2.7V1.3C3 has the highest volume capacitance (860 F  cm<sup>−3</sup> ) and high conductivity (830 S  cm<sup>−1</sup> ) at room temperature, suggesting that it was able to further optimize the performance by adjusting the element [78]. 

##### **4.4  Optoelectronic Devices** 

The unique electronic structure and properties of TMCs, such as the high carrier concentration and high transmittance, would lead an enhanced interaction between phonon and matter, resulting in high photoresponse. Comparatively, the Ti-based MTCs photodetectors have got more investigated not only being employed as transparent electrode, but also being employed as reasonable materials in junctionbased photodetector. Significantly, due to the tunable work function by modulating its surface terminated group, the efficiency of junction-based photodetector could be easily improved. It was found that the MXene coated leaf vein network has a high transmittance (about 90%) and low square resistance (3 Ω  sq<sup>−1</sup> ). The results show that the work function of the MXene electrode can be adjusted by changing the terminal atoms. The MXene electrode and electrospun TiO2 film were integrated to construct a translucent UV photodetector, which has high UV detection performance, excellent flexibility and stability, and can withstand 1000 bending cycles [195, 196]. Yang et al. fabricated an InSe photodetector using  Ti2CTx as the electrodes, as shown in 



<!-- Start of picture text -->
(a) 1-2: InSe/Ti2CTx (b) (c) electron<br>2-3: InSe/patterned-Ti2CTx Power density: 224 625 hole<br>10 -7 0.17-625 W m −2 X Si E VAC<br>80.6 W M<br>10.4 29 Φ bq( V 0− V bi) E C<br>10 -8 0.17 0.48 1.34 q V bi E FSi<br>E g<br>Ti2CTx 10 -9 E V<br>InSe 0 10 20 30 40 50 C T Ti X D n-Si<br>Time (s)<br>(d) (e) 10 4 MoS2/p-Mo2C (P = 1000 nm) (f) 0<br>10 3 −5<br>p-Mo2C<br>(Source) 10 2 −10<br>MoS2<br>10 1 −15 40.4 mW cm56.0 mW cm −2−2<br>71.8 mW cm −2<br>89.4 mW cm −2<br>Ti/Au MoS2 10 0 −20 106.4 mW cm −2<br>Electrode (Channel) 400 600 800 1000 1200 −0.4 −0.2 0 0.2 0.4<br>(Drain) SiO2/Si Wavelength (nm) Voltage (V)<br>Laser<br>1<br>2<br>3<br>)A<br>( t<br>n<br>e<br>rr<br>u<br>C<br>m<br>c<br>A<br>m<br>( J<br>−2)<br>oit<br>a<br>R<br> t<br>n<br>e<br>rr<br>u<br>c kar<br>Do-<br>t-t<br>h<br>giL<br><!-- End of picture text -->

**Fig. 11** Photoelectrical property of TMCs. **a** Schematic of unpatterned and patterned InSe/Ti2CTxphotodetectors. **b** Photoresponse curves of patterned InSe/Ti2CTx avalanche photodetector under different illumination densities. Reproduced with permission from Ref. [197]. Copyright 2019, American Chemical Society. **c** Energy band diagram of  Ti3C2Tx/n-Si Schottky junction upon illumination [199]. **d** Schematic figure of photodetector device with  MoS2/p-Mo2C hybrid structure under illumination. **e** ID–VG curves of photodetector device with  MoS2/p-Mo2C hybrid structure under illumination with various wavelengths. Reproduced with permission from Ref. [201]. Copyright 2019, WILEY–VCH. **f** J–V curves of  Ti3C2Tx/n-Si heterostructure device under various energy density illuminations. Reproduced with permission from Ref. [199]. Copyright 2017, WILEY–VCH 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 21 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

Fig. 11a, b. Because the  Ti2CTx electrode produces avalanche carrier multiplication effect, the photodetector has excellent photoelectric performance. In addition, the pattern of the  Ti2CTx electrode into a plasmonic grating structure can further enhance the light absorption, achieving a dark current as low as 3 nA, a responsivity as high as 1 ×  10<sup>5</sup> A W<sup>−1</sup> , a high detection rate (7.3 ×  10<sup>12</sup> Jones) and a shorter light response time (0.5 ms) [197]. 

Combining 2D  Ti3C2Tx with perovskite through top-down technology, it was able to design a large-scale image sensor array consisting of 25 groups of 50 pixels. Due to the good work function matching between the  Ti3C2Tx layer and the perovskite active layer, it is helpful to form an effective interfacial charge transfer. The energy level alignment and resonance enhancement of the composite system can optimize the near-infrared absorption of the composite system. The results show that the device has excellent broadband spectral response, a response rate of 84.77 A  W<sup>−1</sup> , a specific detection rate of 3.22 ×  10<sup>12</sup> Jones, a linear dynamic range up to 82 dB and a near-infrared image capture capability [198]. Kang prepared the vertically  Ti3C2Tx/n-Si Schottky heterojunction (as shown in Fig. 11c, f) and demonstrated that it has an open-circuit voltage of 0.34 V and a shortcircuit current density of 12.9 mA  cm<sup>−2</sup> under 100 mW  cm<sup>−2</sup> illumination, an  Iph/Idark ratio of about  10<sup>5</sup> , a responsivity of 26.95 mA  W<sup>−1</sup> , a response time of 0.84 ms and a recovery time of 1.67 ms [199]. 

Other TMCs-based photoelectronic effects have also been studied. It is found that the relaxation time of  Nb2C nanosheets can be tunable in the range from 37.43 fs to 0.57 ps by optimizing its size. The layered  Nb2C nanosheets have promising potential applications in broadband ultrafast photonics and near-infrared photonic devices [200]. Jeon et al. demonstrated that the chemical vapor deposition grown  MoS2 film can be chemical converted to  Mo2C film, as shown in Fig. 11d, e. Using the interface characteristics of  MoS2 and  Mo2C, that is, effective hot carrier injection from  Mo2C to  MoS2, the photodetector has high sensitivity and spectral response performance. By adjusting the grating period (400 ~ 1000 nm) of  Mo2C, a broad-spectrum response of light (655 ~ 1200 nm) can be achieved. The results show that the photodetector has high responsivity (R >  10<sup>3</sup> A  W<sup>−1</sup> ) and bright-dark current ratio (>  10<sup>2</sup> ) in a wide spectral range (405 ~ 1310 nm), which is similar with that of transition metal dichalcogenides [201–203]. 

##### **4.5  Medical Treatment** 

Due to the well photoelectronic and photothermal property, the TMCs have also been well used in medical treatment. Jastrzebska et al. proved for the first time that the highly negative surface charge of niobium carbide can be basically transformed into a high positive charge by surface modification with poly L-lysine (PLL). The conversion of surface charge will enable niobium carbide to obtain important biological effects, such as targeting tumors and inducing programmed cell death in G0/G1 phase, which are the most ideal effects for the design of tumor targeting drugs. Significantly, the biocompatibility of PLL modified niobium carbide  (Nb2C and  Nb4C3) is better than that of unmodified niobium carbide [51]. Furthermore,  Nb2C modified by PVP has been proofed effectively eliminate mouse tumor xenografts in NIR-I and NIR-II bio-windows, as shown in Fig. 12. Two-dimensional  Nb2C nanosheets have excellent photothermal conversion efficiency (36.4% for NIRI, 45.65% for NIR-II), and good photothermal stability. In addition,  Nb2C nanosheets also have unique enzyme-responsive biodegradability to human myeloperoxidase [204]. 2D Nb2C nanosheets have been demonstrated with excellent antioxidant properties and can effectively scavenge hydrogen peroxide, hydroxyl radicals and superoxide radicals. The polyvinylpyrrolidone (PVP) modifying would significantly improve its biocompatibility, resulting in an effective protective effect on the hematopoietic system, testis, small intestine and lung of γ-ray irradiated mice, in particular, the hematopoietic system. Experiments show that  Nb2C-PVP can be effectively eliminated by the liver and kidneys in mice after 14 days [205]. 

V2C, as a photothermal agent with excellent photothermal conversion efficiency, has a great application prospects in the field of photothermal therapy. Zada et al. reported a new exfoliation method, that is, the parent phase MAX is intercalated and delaminated by algae extract, and  V2C nanowires with complete structure and high NIR absorption capacity are obtained. Through characterization, the photothermal conversion efficiency of the prepared  V2C nanosheets is as high as 48% [50]. Lin et al. used HF as an etchant to synthesize two-dimensional  Ta4C3 by chemical exfoliation, and explored its application in the photothermal ablation of tumors in vivo. It was proved that the soybean phospholipid-modified  Ta4C3 has good biocompatibility, excellent 

1 3 

**183** Page 22 of 34 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(a) (b) 2.0 20 µg mL −1 (c) 65 λex=808 nm<br>60 1.5 W cm −2<br>1.5 10 µg mL5 µg mL2.5 µg mL −1−1−1 5550 ρ=40 µg mL −1 1.25 W cm1.0 W cm −2−2<br>1.0 45 0.75 W cm −2<br>Nb2C-PVP 40 0.5 W cm −2<br>35<br>0.5<br>First near infrared light 30<br>Hyperthermia bio-window (NIR-I) 25<br>Second near infrared lightbio-window (NIR-II) 0.0 300 450 600 750 900 1050 1200 1350 0 1 2 3 4 5 6 7 8 9 10<br>Tumor tissue Nb2C-PVP Wavelength (nm) Time (min)<br>(d) 120 ExpDec2 Fit of Concentration (e) 70 (f) 1400 Control<br>1008060 y = 56.6582*exp(−x/0.075)      +42.9675*exp(−x/3.3376) + 19.9676RT1/2  2  = 0.99243= 1.31 h 65605550 NbNb22C-PVP+NIR-IC-PVP+NIR-II 12001000800600 NbNIR-INIR-IINbNb222C-PVPC-PVP+NIR-IC-PVP+NIR-II<br>45 NIR-I<br>40 40 NIR-II 400<br>20 35 200<br>30 0<br>0<br>0 4 8 12 16 20 24 0 2 4 6 8 10 0 2 4 6 8 10 12 14 16<br>Time (h) iTme( mni) iTme( day)<br>Blood vessel<br>NIR-I laser<br>C)<br>°(<br>terareu<br>p<br>m<br>Te<br>C)<br>°(<br>terareu<br>p<br>m<br>Te<br>iidonoww- Biidonoww-<br>FriB ts Sdecon<br>−1Concentration (µg mL)<br>).<br>au.<br>(<br>e<br>c<br>n<br>a<br>bro<br>s<br>b<br>A<br>3)<br>m<br>m<br>(<br>e<br>m<br>ulo<br>V<br> r<br>o<br>m<br>u<br>T<br>NIR-II laser<br><!-- End of picture text -->

**Fig. 12** Medical treatment based on  Nb2C. **a** Schematic diagram of two-dimensional  Nb2C used in photothermal treatment of tumors. **b** S-NIR absorption spectra of different concentrations of  Nb2C NSs aqueous suspension. **c** Photothermal curve of  Nb2C NSs aqueous suspension irradiated by 808 nm near-infrared light irradiation at different power densities. **d** Blood circulation lifetime of  Nb2C − PVP after intravenous injection into mice. **e** Temperature elevations at the tumor sites of 4T1-tumor-bearing mice in groups of NIR-I, NIR-II,  Nb2C − PVP + NIR-I and Nb2C − PVP + NIR-II during laser irradiation. **f** Time-dependent tumor growth curves after different treatments (control,  Nb2C − PVP only, NIRI, NIR-II,  Nb2C − PVP + NIR-I and  Nb2C − PVP + NIR-II). Reproduced with permission from Ref. [204]. Copyright 2017, American Chemical Society 

performance of photothermal conversion (efficiency η of 44.7%) and in vitro/in vivo photothermal ablation of tumors [206]. The ionizing radiation generated by radiation accident will has a serious impact on exposed individuals. In addition, by functionalizing with  MnOx, the  Ta4C3 is expected to be widely used in the field of tumor synergistic therapy based on its photothermal conversion performance, tumor microenvironment (TME)-responsive  T1-weighted MR imaging capability and as the desirable contrast agents for PA imaging [35]. 

##### **4.6  Superconductor** 

Due to the high carrier concentration and strong correlation system, the TMCs have been proved as a new superconductor member obtaining great attention. Using CVD-grown  Mo2C as the model, Xu et al. demonstrated that the superconducting properties are consistent with the Berezinskii–Kosterlitz–Thouless behavior, and the superconducting properties depend on the crystal thickness, as shown in Fig. 13. Significantly, 2D  Mo2C crystals also show strong magnetic anisotropy [90]. Furthermore, 

the graphene/2D α-Mo2C structure has a superconducting transition phase diagram with multiple voltage steps in the transition zone, which is expected to be widely used in the field of highly transparent Josephson junction devices [95]. In addition, the influence of grain boundaries on the electron transport and superconductivity properties of 2D Mo2C were explored. In the normal state, with the increase in grain boundary inclination angle, the critical current decreases by 1 to 2 orders of magnitude during the transition from superconducting state to resistive state. In the superconducting state, crossing the grain boundary will lead to the critical current to decrease significantly [207]. Jin et al. prepared double-layer  Mo2Ga2C by vacuum hot pressing. It was found that the RT thermal conductivity of  Mo2Ga2C is 14.8 ± 1.0 W (m K)<sup>−1</sup> , the RT resistivity is 0.525 ± 0.052 μΩ m, and the Lorenz number is 2.22 ×  10<sup>−8</sup> WΩ  K<sup>−2</sup> . Importantly,  Mo2Ga2C has superconductivity, and the superconducting transition temperature is 5.1 K [208]. Porrati used Nb(NMe2)3(N-t-Bu) as the precursor to prepare two-dimensional nanowires and self-supporting three-dimensional nanowires through focused electron beam-induced deposition (FEBID) and focused ion 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 23 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 



<!-- Start of picture text -->
(a) 1.2<br>(b)<br>100 graphene V I<br>Mo2C<br>50 SiO2<br>1.0 Si<br>0<br>−50 100 mK<br>400 mK<br>0.8<br>500 mK<br>−100 600 mK<br>−1.0 −0.5 0.0 0.5 1.0<br>I  (μA)<br>0.6<br>(c)<br>15<br>0.4<br>8<br>10<br>6<br>T c1<br>0.2<br>8.3 nm 5 4 T c2<br>7.5 nm 2<br>2 4 6 8 10<br>5.1 nm T  (K)<br>0.0 0 50 100 150 200 250 300<br>3.4 nm<br>T  (K)<br>2 3 4 5<br>T  (K)<br>)V<br>μ<br> ( V<br>/RR10 Ks<br>)Ω<br>(<br>R )Ω<br>(<br>R<br><!-- End of picture text -->

**Fig. 13** Superconductivity characteristic of metal carbides. **a** Superconductivity characteristic of  Mo2C flakes with different thickness. Reproduced with permission from Ref. [90]. Copyright 2015, Springer Nature. **b** Typical dc Josephson response of  Mo2C/graphene/Mo2C junction taken at different temperatures. Reproduced with permission from Ref. [95]. Copyright 2017, American Chemical Society. **c** Superconductivity characteristic of NbC flakes. Reproduced with permission from Ref. [211]. Copyright 2020, American Physical Society 

beam-induced deposition (FIBID). Electrical transmission measurements show that FEBID nanowires are insulated, FIBID two-dimensional nanowires have superconductivity at  Tc≈5 K, and the critical superconducting temperature of self-supporting FIBID three-dimensional nanowires reaches  Tc≈11 K. The results show that FIBID-NbC has broad application prospects in the preparation of superconducting nanowire single-photon detectors and quantum information processing, suggesting that the property is dependent on its dimensionality [209, 210]. 

##### **4.7  Other Potential Applications** 

Similar with other 2D materials, such as graphene, phosphorene and transition metal dichalcogenides (e.g.,  MoS2 and  WS2), which has shown great potential for thermal management and thermoelectric energy generation [212, 213], the thermal and thermoelectric properties of the TMCs, 

especially the MXene  (Ti3C2Tx), have been studied. Due to its high electrical conductivity, TMCs have been usually composited in thermoelectric materials-based matrix. It was reported that compositing MXene  (Ti3C2Tx) into (Bi,Sb)2Te3 matrix can simultaneously improve power factor and reduce thermal conductivity. Under a temperature gradient of 237 K, the thermoelectric conversion efficiency reached a record of 7.8% [214]. Hong et al. reported the sub-nano ion channel based on 2D-TMCs, which can convert external temperature changes into electrical signals through the preferential diffusion of cations under a thermal gradient. Based on the photothermal conversion of MXenes, the  Ti3C2Tx ion channel can capture the diffusion potential across the nanochannel under the axial temperature gradient of the light drive and exhibit the photothermoelectric ionic response of 1 mV  K<sup>–1</sup> [215]. 

Recently, TMCs have also been used to fabricate nanofiltration membranes due to its uniform nanopores. The TMCs-based nanofiltration membranes show extraordinary 

1 3 

**183** Page 24 of 34 

Nano-Micro Lett. (2021) 13:183 

molecular separation performance. Kim et al. reported a slot-die coating method to prepare large-area  Ti3C2Tx MXene. The  Ti3C2Tx membrane exhibits excellent nanofiltration performance, which deliver a water permeability of 190 LMH/bar and a molecular weight cutoff rate of 269 Da [216]. Stable interlayer space is the key factor to improve ion selectivity. Wang et al. proposed a strategy to stabilize  Ti3C2Tx layered structure through alginate hydrogel pillars. The membrane has good permeation cutoff and screening performance for valence cations. Moreover, its excellent  H<sup>+</sup> /Fe<sup>2+</sup> selectivity makes this membrane promising as an ion-exchange membrane. Recently, the  Ti3C2Tx stabilized by the alginate hydrogel pillars with the same d-spacing has 100%  Na2SO4 rejection and high water permeability [217]. Xu et al. developed a new way to use MXene nanosheets to overcome the trade-off limitation of membrane permeability and salt selectivity. The thin-film composite nanofiltration membranes have a permeability of 45.7 L m<sup>−2</sup> h<sup>−1</sup> bar<sup>−1</sup> , and a  Na2SO4 removal rate of 96% [218]. 

Due to its high electrical conductivity and high light adsorption, TMCs have also been used in electromagnetic shielding. Rajavel et al. prepared a flexible few-layer  Ti3C2Tx film. At a thickness of 6 μm, the X-band conductivity is about 3669 ± 33 S  m<sup>−1</sup> , and the electromagnetic interference shielding efficiency is 31.97 dB. It has also been demonstrated that through controlling the inherent defects, it was able to adjust the electromagnetic shielding performance of few-layer  Ti3C2Tx [219]. Aïssa et al. prepared a twodimensional  Ti3C2Tx MXene/GNPs composite film using electrohydrodynamic atomization deposition technique. The Ti3C2Tx MXene/GNP film with the thickness of 1.75 mm shows excellent electromagnetic shielding performance, with an electromagnetic interference absorbance of about 64 dB [220]. Further optimizing the fabrication of TMCs and designing the device could improve its performance. 

Hydrogen energy is one of the most promising clean energy sources. However, the current hydrogen storage materials still not very well satisfy the industrial requirement. Due to the higher surface activity and larger surface area, recently, the hydrogen storage performance of the incomplete etched  Ti2CTx MXene film has been investigated, and the hydrogen storage mechanism has been discussed [221]. It was found that the  Ti2CTx film has excellent hydrogen storage efficiency, where 8.8 wt% hydrogen is completely absorbed at room temperature under the environment of 

60 bar  H2. The small interlayer distance of  Ti2CTx MXene and the F functional group brought by etching are the key to its hydrogen storage, which will induce weak chemical adsorption assisted by nano-effects. Noh et al. used a twostep method to synthesize palladium nanoparticle-decorated multilayer  Ti3C2Tx MXene (Pd-Ti3C2Tx) [222]. It was found that Pd-Ti3C2Tx exhibits typical hydrogen storage capacity at room temperature and 77 K. Zhu et al. self-assembled Ni nanoparticles on  Ti3C2 MXene obtained by etching and then composited with  MgH2 by ball milling. The  MgH2 + Ni@ Ti-MX composite material can absorb 5.4 wt%  H2 at 125 ℃ for 25 s, and release 5.2 wt%  H2 at 250 ℃ for 15 min [223]. Although the TMCs materials already exhibit the potential application in the hydrogen storage, further study including the correlation between the materials structure and its performance is still unclear and more efforts still need. 

### **5  Conclusions and Perspectives** 

This article reviews the progress in the structure, properties, applications and synthesis methods of transition metal carbides represented by niobium carbide, vanadium carbide, molybdenum carbide and titanium carbide. Firstly, the different phase structures of four typical transition metal carbides are introduced. Different TMCs have the basic phase of NaCl-type cubic phase, and all group IV and V TCMs have  M6C5 phase. Under different synthesis processes, carbon atoms and vacancies are rearranged to varying degrees, resulting in a variety of stable phase structures of transition metal carbides. Because the existence of different phase compositions gives transition metal carbides rich and diverse properties, they have been researched and developed in different fields. Based on their outstanding electronic, mechanical, magnetic, electrochemical, optical properties and atomic-level thickness, TMCs films have been applied in the fields of catalysis, energy storage, optoelectronics, biomedicine and superconductivity. The hydrogen adsorption on the surface of transition metal end carbides is significantly enhanced, which makes it good catalyst for electrocatalytic and photocatalytic hydrogen evolution. Due to the large specific surface area, good conductivity and excellent cation intercalation performance, TMCs have potential application in LIBs anode materials. Due to the rectifying electric shock with Schottky barrier height and internal electric field, 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 25 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

and higher responsivity and quantum efficiency than Au, Ti3C2Tx photodetector has better dynamic range and detection rate. The surface charge of  Nb2C and  Nb4C3 is transformed into high positive charge by surface modification, which has important biological effect on tumor targeting. TMC films such as α-Mo2C and NbC have superconducting properties, and the critical superconducting temperature can be further increased by changing the synthesis process and adjusting the surface functional groups. 

At present, the main ways to synthesize TMCs films include chemical exfoliation, chemical vapor deposition, temperatureprogrammed reduction and magnetic sputtering. In recent years, MXenes prepared by chemical exfoliation have been developed rapidly, and its layer structure similar to accordion has brought a wealth of applications. The TMCs synthesized by chemical vapor deposition have high purity and are easy to be uniformly doped. Temperature-programmed reduction provides a way for the synthesis of carbides with high synthesis temperature. Magnetic sputtering synthetic carbide film has the characteristics of high film formation rate, low substrate temperature and good film adhesion. 

Although TMCs films have shown great potential in different fields, there are still some challenges in future applications. First of all, the current synthesis methods of TMC films still face some limitations. For example, it is difficult to synthesize the parent phase MAX of MXene, and many MXenes have not been successfully prepared by chemical exfoliation because of the inability to synthesize the stable MAX phase. Chemical vapor deposition has limitations in the preparation of large-size carbide films. Therefore, new methods for synthesizing TMCs have yet to be explored. Secondly, the theoretical mechanism of some characteristics of TMC films in the application field is still unclear. For example, in the field of energy storage, the ion dynamics and charge storage mechanism between carbide films are unclear. Thirdly, the improvement of electrochemical, mechanical and thermal stability of TMCs remains a topic of future research. It is worth mentioning that the research fields of TMCs films are full of opportunities and challenges, and there is still great application potential to be tapped in different fields. In the foreseeable future, transition metal carbide materials will play an increasingly important role in solving various global challenges. 

**Acknowledgements** This research was supported by grants from by the National Natural Science Foundation of China (52002254), 

Sichuan Science and Technology Program (2020YJ0262, 2021YFH0127), Chunhui plan of Ministry of Education of China, Fundamental Research Funds for the Central Universities, China (YJ201893), State Key Lab of Advanced Metals and Materials, China (Grant No. 2019-Z03), the Danish National Research Foundation and EU H2020RISE 2016-MNR4S Cell project. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creat iveco mmons. org/ licen ses/ by/4. 0/. 

### **References** 

1. V. Nicolosi, M. Chhowalla, M.G. Kanatzidis, M.S. Strano, J.N. Coleman, Liquid exfoliation of layered materials. Science **340** , 1226419 (2013). https:// doi. org/ 10. 1126/ scien ce. 12264 19 

2. A.K.G.K.S. Novoselov, S.V. Morozov, D. Jiang, Y. Zhang, S.V. Dubonos et al., Electric field effect in atomically thin carbon films. Science **306** , 666–669 (2004). https:// doi. org/ 10. 1126/ scien ce. 11028 96 

3. L. Lin, B. Deng, J. Sun, H. Peng, Z. Liu, Bridging the gap between reality and ideal in chemical vapor deposition growth of graphene. Chem. Rev. **118** , 9281–9343 (2018). https:// doi. org/ 10. 1021/ acs. chemr ev. 8b003 25 

4. Z.-G. Wang, Y.-F. Chen, P.-J. Li, X. Hao, J.-B. Liu et al., Flexible graphene-based electroluminescent devices. ACS Nano **5** , 7149–7154 (2011). https:// doi. org/ 10. 1021/ nn201 8649 

5. X. Wang, A. Jones, K. Seyler, V. Tran, Y. Jia et al., Highly anisotropic and robust excitons in monolayer black phosphorus. Nat. Nanotech. **10** , 517–521 (2014). https:// doi. org/ 10. 1038/ nnano. 2015. 71 

6. Z.W. Seh, K.D. Fredrickson, B. Anasori, J. Kibsgaard, A.L. Strickler et al., Two-dimensional molybdenum Carbide (MXene) as an efficient electrocatalyst for hydrogen evolution. ACS Energy Lett. **1** , 589–594 (2016). https:// doi. org/ 10. 1021/ acsen ergyl ett. 6b002 47 

7. W. Yuan, L. Cheng, Y. An, H. Wu, N. Yao et al., MXene nanofibers as highly active catalysts for hydrogen evolution reaction. ACS Sustain. Chem. Eng. **6** , 8976–8982 (2018). https:// doi. org/ 10. 1021/ acssu schem eng. 8b013 48 

8. P. Zhang, F. Wang, M. Yu, X. Zhuang, X. Feng, Two-dimensional materials for miniaturized energy storage devices: 

1 3 

**183** Page 26 of 34 

Nano-Micro Lett. (2021) 13:183 

from individual devices to smart integrated systems. Chem. Soc. Rev. **47** , 7426–7451 (2018). https:// doi. org/ 10. 1039/ C8CS0 0561C 

9. P. Miró, M. Audiffred, T. Heine, An atlas of two-dimensional materials. Chem. Soc. Rev. **43** , 6537–6554 (2014). https:// doi. org/ 10. 1039/ C4CS0 0102H 

10. Z. Wang, J. Liu, X. Hao, Y. Wang, Y. Chen et al., Investigating the stability of molecule doped graphene field effect transistors. New J. Chem. **43** , 15275–15279 (2019). https:// doi. org/ 10. 1039/ C9NJ0 3537K 

11. Z. Wang, X. Xiong, J. Li, M. Dong, Screening fermi-level pinning effect through van der waals contacts to monolayer MoS2. Mater. Today Phys. **16** , 100290 (2021). https:// doi. org/ 10. 1016/j. mtphys. 2020. 100290 

12. A. Ayari, E. Cobas, O. Ogundadegbe, M.S. Fuhrer, Realization and electrical characterization of ultrathin crystals of layered transition-metal dichalcogenides. J. Appl. Phys. **101** , 014507 (2007). https:// doi. org/ 10. 1063/1. 24073 88 

13. L.H. Li, Y. Chen, G. Behan, H. Zhang, M. Petravic et al., Large-scale mechanical peeling of boron nitride nanosheets by low-energy ball milling. J. Mater. Chem. **21** , 11862–11866 (2011). https:// doi. org/ 10. 1039/ C1JM1 1192B 

14. M. Özdemir, C. Çekil, Ö. Atasever, B. Ozdemir, Z. Yarar et al., Electron transport properties of silicene: Intrinsic and dirty cases with screening effects. J. Mol. Struct. **1199** , 126878 (2019). https:// doi. org/ 10. 1016/j. molst ruc. 2019. 126878 

15. Z. Wang, Q. Li, F. Besenbacher, M. Dong, Facile synthesis of single crystal  PtSe2 nanosheets for nanoscale electronics. Adv. Mater. **28** , 10224–10229 (2016). https:// doi. org/ 10. 1002/ adma. 20160 2889 

16. M. Naguib, M. Kurtoglu, V. Presser, J. Lu, J. Niu et al., Two-dimensional nanocrystals produced by exfoliation of Ti3AlC2. Adv. Mater. **23** , 4248–4253 (2011). https:// doi. org/ 10. 1002/ adma. 20110 2306 

17. R.B. Levy, M. Boudart, Platinum-like behavior of tungsten carbide in surface catalysis. Science **181** , 547 (1973). https:// doi. org/ 10. 1126/ scien ce. 181. 4099. 547 

18. J. Claridge, A. York, A. Brungs, C. Márquez-Alvarez, J. Sloan et al., New catalysts for the conversion of methane to synthesis gas: molybdenum and tungsten carbide. J. Catal. **180** , 85–100 (1998). https:// doi. org/ 10. 1006/ jcat. 1998. 2260 

19. J. Kitchin, J. Nørskov, M. Barteau, J. Chen, Trends in the chemical properties of early transition metal carbide surfaces: A density functional study. Catal. Today **105** , 66–73 (2005). https:// doi. org/ 10. 1016/j. cattod. 2005. 04. 008 

20. N.C. Frey, A. Bandyopadhyay, H. Kumar, B. Anasori, Y. Gogotsi et al., Surface-engineered MXenes: Electric field control of magnetism and enhanced magnetic anisotropy. ACS Nano **13** , 2831–2839 (2019). https:// doi. org/ 10. 1021/ acsna no. 8b092 01 

21. M. Ashton, K. Mathew, R.G. Hennig, S.B. Sinnott, Predicted surface composition and thermodynamic stability of mxenes in solution. J. Phys. Chem. C **120** , 3550–3556 (2016). https:// doi. org/ 10. 1021/ acs. jpcc. 5b118 87 

22. Z. Kan, M. Wen, Q. Meng, C. Hu, X. Li et al., Effects of substrate bias voltage on the microstructure, mechanical properties and tribological behavior of reactive sputtered niobium carbide films. Surf. Coat. Tech. **212** , 185–191 (2012). https:// doi. org/ 10. 1016/j. surfc oat. 2012. 09. 046 

23. N. Nedfors, O. Tengstrand, E. Lewin, A. Furlan, P. Eklund et al., Structural, mechanical and electrical-contact properties of nanocrystalline-NbC/amorphous-C coatings deposited by magnetron sputtering. Surf. Coat. Tech. **206** , 354–359 (2011). https:// doi. org/ 10. 1016/j. surfc oat. 2011. 07. 021 

24. E.V. Pechen, S.I. Krasnosvobodtsev, N.P. Shabanova, E.V. Ekimov, A.V. Varlashkin et al., Tunneling and criticalmagnetic-field study of superconducting NbC thin films. Physica C **235–240** , 2511–2512 (1994). https:// doi. org/ 10. 1016/ 0921- 4534(94) 92476-7 

25. M.G. Kostenko, A.V. Lukoyanov, A.A. Valeeva, Vacancy ordered structures in a nonstoichiometric niobium carbide NbC0.83. Mendeleev Commun. **29** , 707–709 (2019). https:// doi. org/ 10. 1016/j. mencom. 2019. 11. 037 

26. J. Smith, O. Carlson, R. de Avillez, ChemInform abstract: The niobium-carbon system. ChemInform (1987). https:// doi. org/ 10. 1002/ chin. 19873 6371 

27. M. Cuppari, S. Santos, Physical properties of the NbC carbide. Metals **6** , 250 (2016). https:// doi. org/ 10. 3390/ met61 00250 

28. V. Lipatnikov, W. Lengauer, P. Ettmayer, E. Keil, G. Groboth et al., Effects of vacancy ordering on structure and properties of vanadium carbide. J. Alloys Compounds **261** , 192–197 (1997). https:// doi. org/ 10. 1016/ S0925- 8388(97) 00224-7 

29. L.W. Shacklette, W.S. Williams, Influence of order–disorder on the electrical resistivity of vanadium carbide. Phys. Rev. B (1973). https:// doi. org/ 10. 1103/ PhysR evB.7. 5041 

30. X. Chong, Y. Jiang, R. Zhou, J. Feng, Electronic structure, mechanical and thermal properties of V-C binary compounds. RSC Adv. **4** , 44959–44971 (2014). https:// doi. org/ 10. 1039/ C4RA0 7543A 

31. V.N. Lipatnikov, A.I. Gusev, P. Ettmayer, W. Lengauer, Phase transformations in non-stoichiometric vanadium carbide. J. Phys. Condensed Matter **11** , 163–184 (1999). https:// doi. org/ 10. 1088/ 0953- 8984/ 11/1/ 014 

32. X.S. Fan, Z. Yang, Z. Yuduo, H. Che, Evaluation of vanadium carbide coatings on AISI H13 obtained by thermoreactive deposition/diffusion technique. Surf. Coat. Tech. **205** , 641–646 (2010). https:// doi. org/ 10. 1016/j. surfc oat. 2010. 07. 065 

33. Y. Zhong, X. Xia, F. Shi, J. Zhan, J. Tu et al., Transition metal carbides and nitrides in energy storage and conversion. Adv. Sci. **3** , 1500286 (2016). https:// doi. org/ 10. 1002/ advs. 20150 0286 

34. X. Zhao, W. Sun, D. Geng, W. Fu, J. Dan et al., Edge segregated polymorphism in 2D molybdenum carbide. Adv. Mater. **31** , 1808343 (2019). https:// doi. org/ 10. 1002/ adma. 20180 8343 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 27 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

35. C. Dai, Y. Chen, X. Jing, L. Xiang, D. Yang et al., Twodimensional tantalum carbide (MXenes) composite nanosheets for multiple imaging-guided photothermal tumor ablation. ACS Nano **11** , 12696–12712 (2017). https:// doi. org/ 10. 1021/ acsna no. 7b072 41 

36. H. Liu, J. Zhu, Z. Lai, R. Zhao, D. He, A first-principles study on structural and electronic properties of  Mo2C. Scripta Mater. **60** , 949–952 (2009). https:// doi. org/ 10. 1016/j. scrip tamat. 2009. 02. 010 

37. M. Tuo, C. Xu, H. Mu, X. Bao, Y. Wang et al., Ultrathin 2D Transition metal carbides for ultrafast pulsed fiber lasers. ACS Photonics **5** , 1808–1816 (2018). https:// doi. org/ 10. 1021/ acsph otoni cs. 7b014 28 

38. J. Jeon, H. Choi, S. Choi, J.-H. Park, B.H. Lee et al., Hybrid photodetectors: transition-metal-carbide  (Mo2C) multiperiod gratings for realization of high-sensitivity and broad-spectrum photodetection. Adv. Funct. Mater. **29** , 1970329 (2019). https:// doi. org/ 10. 1002/ adfm. 20197 0329 

39. H.W. Hugosson, O. Eriksson, U. Jansson, B. Johansson, Phase stabilities and homogeneity ranges in 4d-transitionmetal carbides: A theoretical study. Phys. Rev. B **63** , 134108 (2001). https:// doi. org/ 10. 1103/ PhysR evB. 63. 134108 

40. V.N. Lipatnikov, A.A. Rempel, A.I. Gusev, Atomic ordering and hardness of nonstoichiometric titanium carbide. Int. J. Refract. Met. Hard Mater. **15** , 61–64 (1997). https:// doi. org/ 10. 1016/ S0263- 4368(96) 00020-0 

41. X.J. Li, L.L. He, Y.S. Li, Q. Yang, A. Hirose, Strain-induced ordered structure of titanium carbide during depositing diamond on Ti alloy substrate. Mater. Charact. **123** , 227–232 (2017). https:// doi. org/ 10. 1016/j. match ar. 2016. 11. 035 

42. B. Yu, A. Huang, D. Chen, K. Srinivas, X. Zhang et al., In situ construction of  Mo2C quantum dots-decorated cnt networks as a multifunctional electrocatalyst for advanced lithium–sulfur batteries. Small **17** , 2100460 (2021). https:// doi. org/ 10. 1002/ smll. 20210 0460 

43. H. Goretzki, Neutron diffraction studies on titanium-carbon and zirconium-carbon alloys. Phys. Status Solidi B **20** , K141– K143 (1967). https:// doi. org/ 10. 1002/ pssb. 19670 200260 

44. B. Ji, S. Fan, X. Ma, K. Hu, L. Wang et al., Electromagnetic shielding behavior of heat-treated  Ti3C2TX MXene accompanied by structural and phase changes. Carbon **165** , 150–162 (2020). https:// doi. org/ 10. 1016/j. carbon. 2020. 04. 041 

45. N.V. Dzhalabadze, B.G. Éristavi, N.I. Maisuradze, K.K. Tskhovrebashvili, É.R. Kuteliya, Structural transformations in titanium carbide during diamond grinding. Powder Metall. Metal Ceram. **38** , 292–296 (1999). https:// doi. org/ 10. 1007/ BF026 75778 

46. A.D. Dillon, M.J. Ghidiu, A.L. Krick, J. Griggs, S.J. May et al., Highly conductive optical quality solution-processed films of 2D titanium carbide. Adv. Funct. Mater. **26** , 4162– 4168 (2016). https:// doi. org/ 10. 1002/ adfm. 20160 0357 

47. M. Khazaei, A. Ranjbar, M. Arai, T. Sasaki, S. Yunoki, Electronic properties and applications of MXenes: a theoretical review. J. Mater. Chem. C **5** , 2488–2503 (2017). https:// doi. org/ 10. 1039/ C7TC0 0140A 

48. M. Kuang, W. Huang, C. Hegde, W. Fang, X. Tan et al., Interface engineering in transition metal carbides for electrocatalytic hydrogen generation and nitrogen fixation. Mater. Horizons **7** , 32–53 (2020). https:// doi. org/ 10. 1039/ C9MH0 1094G 

49. G. Fiori, F. Bonaccorso, G. Iannaccone, T. Palacios, D. Neumaier et al., Electronics based on two-dimensional materials. Nat. Nanotechnol. **9** , 768–779 (2014). https:// doi. org/ 10. 1038/ nnano. 2014. 207 

50. S. Zada, W. Dai, Z. Kai, H. Lu, X. Meng et al., Algae extraction controllable delamination of vanadium carbide nanosheets with enhanced near-infrared photothermal performance. Angew. Chem. Int. Ed. **59** , 6601–6606 (2020). https:// doi. org/ 10. 1002/ anie. 20191 6748 

51. A. Jastrzebska, A. Szuplewska, A. RozmysłowskaWojciechowska, J. Mitrzak, T. Wojciechowski et al., Juggling surface charges of 2D niobium carbide MXenes for a reactive oxygen species scavenging and effective targeting of the malignant melanoma cell cycle into programmed cell death. ACS Sustain. Chem. Eng. **8** , 7942–7951 (2020). https:// doi. org/ 10. 1021/ acssu schem eng. 0c016 09 

52. J.A. Klug, T. Proslier, J.W. Elam, R.E. Cook, J.M. Hiller et al., Atomic layer deposition of amorphous niobium carbide-based thin film superconductors. J. Phys. Chem. C **115** , 25063–25071 (2011). https:// doi. org/ 10. 1021/ jp207 612r 

53. S. Pisana, P.M. Braganca, E.E. Marinero, B.A. Gurney, Tunable nanoscale graphene magnetometers. Nano Lett. **10** , 341–346 (2010). https:// doi. org/ 10. 1021/ nl903 690y 

54. A.P.M. Barboza, H. Chacham, C.K. Oliveira, T.F.D. Fernandes, E.H.M. Ferreira et al., Dynamic negative compressibility of few-layer graphene, h-BN, and  MoS2. Nano Lett. **12** , 2313–2317 (2012). https:// doi. org/ 10. 1021/ nl300 183e 

55. J. Yang, M. Naguib, M. Ghidiu, L.-M. Pan, J. Gu et al., Twodimensional nb-based  M4C3 solid solutions (MXenes). J. Am. Ceram. Soc. **99** , 660–666 (2016). https:// doi. org/ 10. 1111/ jace. 13922 

56. L. Verger, C. Xu, V. Natu, H.-M. Cheng, W. Ren et al., Overview of the synthesis of MXenes and other ultrathin 2D transition metal carbides and nitrides. Curr. Opin. Solid St. Mater. Sci. **23** , 149–163 (2019). https:// doi. org/ 10. 1016/j. cossms. 2019. 02. 001 

57. M.R. Lukatskaya, O. Mashtalir, C.E. Ren, Y. Dall’Agnese, P. Rozier et al., Cation intercalation and high volumetric capacitance of two-dimensional titanium carbide. Science **341** , 1502 (2013). https:// doi. org/ 10. 1126/ scien ce. 12414 88 

58. A. Ren, J. Zou, H. Lai, Y. Huang, L. Yuan et al., Direct laser-patterned MXene–perovskite image sensor arrays for visible-near infrared photodetection. Mater. Horiz. **7** , 1901–1911 (2020). https:// doi. org/ 10. 1039/ D0MH0 0537A 

59. C. Zhang, B. Anasori, A. Seral-Ascaso, S.-H. Park, N. McEvoy et al., Transparent, Flexible, and conductive 2d titanium carbide (MXene) films with high volumetric capacitance. Adv. Mater. **29** , 1702678 (2017). https:// doi. org/ 10. 1002/ adma. 20170 2678 

1 3 

**183** Page 28 of 34 

Nano-Micro Lett. (2021) 13:183 

60. M. Radovic, M. Barsoum, M.A.X. Phases, Bridging the gap between metals and ceramics. Am. Ceram. Soc. Bull. **92** , 20–27 (2013) 

61. S. Yang, P. Zhang, F. Wang, A.G. Ricciardulli, M.R. Lohe et al., Fluoride-free synthesis of two-dimensional titanium carbide (MXene) using a binary aqueous system. Angew. Chem. Inter. Ed. **57** , 15491–15495 (2018). https:// doi. org/ 10. 1002/ anie. 20180 9662 

62. J. Zhou, X. Zha, F.Y. Chen, Q. Ye, P. Eklund et al., A two-dimensional zirconium carbide by selective etching of Al3C3 from nanolaminated  Zr3Al3C5. Angew. Chem. Inter. Ed. **55** , 5008–5013 (2016). https:// doi. org/ 10. 1002/ anie. 20151 0432 

63. M. Naguib, V.N. Mochalin, M.W. Barsoum, Y. Gogotsi, Twodimensional materials: 25th anniversary article: MXenes: a new family of two-dimensional materials. Adv. Mater. **26** , 982–982 (2014). https:// doi. org/ 10. 1002/ adma. 20147 0041 

64. M. Ghidiu, M. Lukatskaya, M.-Q. Zhao, Y. Gogotsi, M. Barsoum, Conductive two-dimensional titanium carbide ‘clay’ with high volumetric capacitance. Nature **516** , 78–81 (2014). https:// doi. org/ 10. 1038/ natur e13970 

65. F. Liu, A. Zhou, J. Chen, J. Jia, W. Zhou et al., Preparation of Ti3C2 and  Ti2C MXenes by fluoride salts etching and methane adsorptive properties. Appl. Surf. Sci. **416** , 781–789 (2017). https:// doi. org/ 10. 1016/j. apsusc. 2017. 04. 239 

66. F. Liu, J. Zhou, S. Wang, B. Wang, C. Shen et al., Preparation of high-purity  V2C MXene and electrochemical properties as Li-Ion batteries. J. Electrochem. Soc. **164** , A709–A713 (2017). https:// doi. org/ 10. 1149/2. 06417 04jes 

67. J. Halim, M.R. Lukatskaya, K.M. Cook, J. Lu, C.R. Smith et al., Transparent conductive two-dimensional titanium carbide epitaxial thin films. Chem. Mater. **26** , 2374–2381 (2014). https:// doi. org/ 10. 1021/ cm500 641a 

68. M. Alhabeb, K. Maleski, B. Anasori, P. Lelyukh, L. Clark et al., Guidelines for synthesis and processing of two-dimensional titanium carbide  (Ti3C2Tx MXene). Chem. Mater. **29** , 7633–7644 (2017). https:// doi. org/ 10. 1021/ acs. chemm ater. 7b028 47 

69. A. Lipatov, M. Alhabeb, M.R. Lukatskaya, A. Boson, Y. Gogotsi et al., MXene materials: effect of synthesis on quality, electronic properties and environmental stability of individual monolayer  Ti3C2 MXene flakes. Adv. Electron. Mater. **2** , 1600255 (2016). https:// doi. org/ 10. 1002/ aelm. 20167 0068 

70. J. Yi, J. Li, S. Huang, L. Hu, L. Miao et al.,  Ti2CTx MXenebased all-optical modulator. InfoMat **2** , 601–609 (2020). https:// doi. org/ 10. 1002/ inf2. 12052 

71. C. Zhang, L. Cui, S. Abdolhosseinzadeh, J. Heier, Twodimensional MXenes for lithium-sulfur batteries. InfoMat **2** , 613–638 (2020). https:// doi. org/ 10. 1002/ inf2. 12080 

72. Q.X. He, B. Wang, L. Wang, Q. Hu, A. Zhou, Two-dimensional vanadium carbide (V2CTx) MXene as supercapacitor electrode in seawater electrolyte. Chin. Chem. Lett. **31** , 984–987 (2020). https:// doi. org/ 10. 1016/j. cclet. 2019. 08. 025 

73. E. Pomerantseva, Y. Gogotsi, Two-dimensional heterostructures for energy storage. Nat. Energy **2** , 17089 (2017). https:// doi. org/ 10. 1038/ nener gy. 2017. 89 

74. Y. Guan, S. Jiang, Y. Cong, J. Wang, Z. Dong et al., A hydrofluoric acid-free synthesis of 2D vanadium carbide  (V2C) MXene for supercapacitor electrodes. 2D Mater. **7** , 025010 (2020). https:// doi. org/ 10. 1088/ 2053- 1583/ ab6706 

75. Y. Xin, Y.-X. Yu, Possibility of bare and functionalized niobium carbide MXenes for electrode materials of supercapacitors and field emitters. Mater. Design **130** , 512–520 (2017). https:// doi. org/ 10. 1016/j. matdes. 2017. 05. 052 

76. Z. Wang, Q. Li, Y. Chen, B. Cui, Y. Li et al., The ambipolar transport behavior of  WSe2 transistors and its analogue circuits. NPG Asia Mater. **10** , 703–712 (2018). https:// doi. org/ 10. 1038/ s41427- 018- 0062-1 

77. S.-Y. Pang, W.-F. Io, L.-W. Wong, J. Zhao, J. Hao, Efficient energy conversion and storage based on robust fluoride-free self-assembled 1D niobium carbide in 3D nanowire network. Adv. Sci. **7** , 1903680 (2020). https:// doi. org/ 10. 1002/ advs. 20190 3680 

78. D. Pinto, B. Anasori, H. Avireddy, C.E. Shuck, K. Hantanasirisakul et al., Synthesis and electrochemical properties of 2D molybdenum vanadium carbides – solid solution MXenes. J. Mater. Chem. A **8** , 8957–8968 (2020). https:// doi. org/ 10. 1039/ D0TA0 1798A 

79. D. Bloom, N. Grant, The system chromium-carbon. JOM **2** , 41–46 (1950). https:// doi. org/ 10. 1007/ BF033 98977 

80. M. Naguib, MXenes: A new family of two-dimensional materials and its application as electrodes for Li-ion batteries. Dissertations Theses Gradworks **45** , 787–799 (2015) 

81. C. Wan, Y.N. Regmi, B.M. Leonard, Multiple phases of molybdenum carbide as electrocatalysts for the hydrogen evolution reaction. Angew. Chem. Int. Ed. **53** , 6407–6410 (2014). https:// doi. org/ 10. 1002/ anie. 20140 2998 

82. J. Luo, E. Matios, H. Wang, X. Tao, W. Li, Interfacial structure design of MXene-based nanomaterials for electrochemical energy storage and conversion. InfoMat **2** , 1057–1076 (2020). https:// doi. org/ 10. 1002/ inf2. 12118 

83. O. Mashtalir, M. Naguib, V. Mochalin, Y. Dall’Agnese, M. Heon et al., Intercalation and delamination of layered carbides and carbonitrides. Nat. Commun. **4** , 1716 (2013). https:// doi. org/ 10. 1038/ ncomm s2664 

84. B. Anasori, Y. Xie, M. Beidaghi, J. Lu, B.C. Hosler et al., Two-dimensional, ordered, double transition metals carbides (MXenes). ACS Nano **9** , 9507–9516 (2015). https:// doi. org/ 10. 1021/ acsna no. 5b035 91 

85. Y. Omomo, T. Sasaki, L. Wang, M. Watanabe, Redoxable nanosheet crystallites of  MnO2 derived via delamination of a layered manganese oxide. ChemInform (2003). https:// doi. org/ 10. 1002/ chin. 20032 4215 

86. M. Naguib, R. Unocic, B. Armstrong, J. Nanda, Large-scale delamination of multi-layers transition metal carbides and carbonitrides “MXenes.” Dalton Trans. **44** , 9353 (2015). https:// doi. org/ 10. 1039/ C5DT0 1247C 

87. O. Mashtalir, M.R. Lukatskaya, M.-Q. Zhao, M.W. Barsoum, Y. Gogotsi, Amine-assisted delamination of  Nb2C MXene for Li-Ion energy storage devices. Adv. Mater. **27** , 3501–3506 (2015). https:// doi. org/ 10. 1002/ adma. 20150 0604 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 29 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

88. A. Reina, X. Jia, J. Ho, D. Nezich, H. Son et al., Few-Layer graphene films on arbitrary substrates by chemical vapor deposition. Nano Lett. **9** , 30–35 (2009). https:// doi. org/ 10. 1021/ nl901 829a 

89. X. Wang, H. Feng, Y. Wu, L. Jiao, Controlled synthesis of highly crystalline  MoS2 flakes by chemical vapor deposition. J. Am. Chem. Soc. **135** , 5304–5307 (2013). https:// doi. org/ 10. 1021/ ja401 3485 

90. C. Xu, L. Wang, Z. Liu, L. Chen, J. Guo et al., Large-area high-quality 2D ultrathin  Mo2C superconducting crystals. Nat. Mater. **14** , 1135–1141 (2015). https:// doi. org/ 10. 1038/ nmat4 374 

91. C. Xu, L. Chen, Z. Liu, H.-M. Cheng, W. Ren, Bottom-Up synthesis of 2D transition metal carbides and nitrides. 2D Metal Carbides and Nitrides (MXenes) (2019), pp. 89–109 

92. D. Geng, X. Zhao, Z. Chen, W. Sun, W. Fu et al., Direct synthesis of large-area 2D  Mo2C on In situ grown graphene. Adv. Mater. **29** , 1700072 (2017). https:// doi. org/ 10. 1002/ adma. 20170 0072 

93. D. Geng, X. Zhao, L. Li, P. Song, B. Tian et al., Controlled growth of ultrathin  Mo2C superconducting crystals on liquid Cu surface. 2D Mater. **4** , 011012 (2016). https:// doi. org/ 10. 1088/ 2053- 1583/ aa51b7 

94. C. Zhang, Z. Wang, R. Tu, M. Dong, J. Li et al., Growth of self-aligned single-crystal vanadium carbide nanosheets with a controllable thickness on a unique staked metal substrate. Appl. Surf. Sci. **499** , 143998 (2019). https:// doi. org/ 10. 1016/j. apsusc. 2019. 143998 

95. C. Xu, S. Song, Z. Liu, L. Chen, L. Wang et al., Strongly coupled high-quality graphene/2D superconducting  Mo2C vertical heterostructures with aligned orientation. ACS Nano **11** , 5906–5914 (2017). https:// doi. org/ 10. 1021/ acsna no. 7b016 38 

96. C. Zhang, Z. Wang, R. Tu, M. Dong, J. Li et al., Growth of self-aligned single-crystal vanadium carbide nanosheets with a controllable thickness on a unique staked metal substrate. Appl. Surf. Sci. **499** , 143998 (2020). https:// doi. org/ 10. 1016/j. apsusc. 2019. 143998 

97. T. Ikenoue, T. Yoshida, M. Miyake, R. Kasada, T. Hirato, Fabrication and mechanical properties of tungsten carbide thin films via mist chemical vapor deposition. J. Alloys Compounds **829** , 154567 (2020). https:// doi. org/ 10. 1016/j. jallc om. 2020. 154567 

98. H.E. Rebenne, D.G. Bhat, Review of CVD TiN coatings for wear-resistant applications: deposition processes, properties and performance. Surf. Coat. Tech. **63** , 1–13 (1994). https:// doi. org/ 10. 1016/ S0257- 8972(05) 80002-7 

99. L. Volpe, M. Boudart, Compounds of molybdenum and tungsten with high specific surface area: I. Nitrides. J. Solid State Chem. **59** , 332–347 (1985). https:// doi. org/ 10. 1016/ 00224596(85) 90301-9 

100. J.B. Claridge, A.P.E. York, A.J. Brungs, M.L.H. Green, Study of the temperature-programmed reaction synthesis of early transition metal carbide and nitride catalyst materials from oxide precursors. Chem. Mater. **12** , 132–142 (2000). https:// doi. org/ 10. 1021/ cm991 1060 

101. A.T. Peters, Ullmann’s encyclopedia of industrial chemistry: vols A5–A7. VCH Verlagsgesellschaft, Weinheim, FRG, 1986. vols A5 (ISBN 3-527-20105-X; xv + 556 pp). Dyes Pigm. **9** , 165–166 (1988). https:// doi. org/ 10. 1016/ 01437208(88) 80015-9 

102. V.L.S. Teixeira da Silva, E.I. Ko, M. Schmal, S.T. Oyama, Synthesis of niobium carbide from niobium oxide aerogels. Chem. Mater. **7** , 179–184 (1995). https:// doi. org/ 10. 1021/ cm000 49a027 

103. V.L.S. Teixeira da Silva, M. Schmal, S.T. Oyama, Niobium carbide synthesis from niobium oxide: study of the synthesis conditions, kinetics, and solid-state transformation mechanism. J. Solid State Chem. **123** , 168–182 (1996). https:// doi. org/ 10. 1006/ jssc. 1996. 0165 

104. R. Kapoor, S.T. Oyama, Synthesis of high surface area vanadium nitride. J. Solid State Chem. **99** , 303–312 (1992). https:// doi. org/ 10. 1016/ 0022- 4596(92) 90318-P 

105. J.G. Choi, H.G. Oh, Y.S. Baek, Tantalum carbide hydrodenitrogenation catalysts. J. Ind. Eng. Chem. **4** , 94–98 (1998) 

106. L. Fei, X. Gan, S.M. Ng, H. Wang, M. Xu et al., Observable two-step nucleation mechanism in solid-state formation of tungsten carbide. ACS Nano **13** , 681–688 (2019). https:// doi. org/ 10. 1021/ acsna no. 8b078 64 

107. S. Biira, T. Thabethe, H. Bissett, T. Ntsoane, J.B. Malherbe, Investigating the thermal stability of the chemical vapour deposited zirconium carbide layers. J. Alloys Compounds **834** , 155003 (2020). https:// doi. org/ 10. 1016/j. jallc om. 2020. 155003 

108. W. Sun, X. Kuang, H. Liang, X. Xia, Z. Zhang et al., Mechanical properties of tantalum carbide from high-pressure/hightemperature synthesis and first-principles calculations. Phys. Chem. Chem. Phys. **22** , 5018–5023 (2020). https:// doi. org/ 10. 1039/ C9CP0 6819H 

109. G. Zou, H. Wang, N. Mara, H. Luo, N. Li et al., Chemical solution deposition of epitaxial carbide films. J. Am. Chem. Soc. **132** , 2516–2517 (2010). https:// doi. org/ 10. 1021/ ja910 2315 

110. R.E. Jilek, E. Bauer, A.K. Burrell, T.M. McCleskey, Q. Jia et al., Preparation of epitaxial uranium dicarbide thin films by polymer-assisted deposition. Chem. Mater. **25** , 4373–4377 (2013). https:// doi. org/ 10. 1021/ cm402 655p 

111. M. Backhaus-Ricoult, Oxidation behavior of SiC-whiskerreinforced alumina-zirconia composites. J. Am. Ceram. Soc. **74** , 1793–1802 (1991). https:// doi. org/ 10. 1111/j. 1151- 2916. 1991. tb077 90.x 

112. E. Lewin, M. Råsander, M. Klintenberg, A. Bergman, O. Eriksson et al., Design of the lattice parameter of embedded nanoparticles. Chem. Phys. Lett. **496** , 95–99 (2010). https:// doi. org/ 10. 1016/j. cplett. 2010. 07. 013 

113. D.V. Shtansky, E.A. Levashov, A.N. Sheveiko, J.J. Moore, Synthesis and characterization of Ti-Si-C-N films. Metall. Mater. Trans. A **30** , 2439–2447 (1999). https:// doi. org/ 10. 1007/ s11661- 999- 0252-0 

114. Z. Kan, M. Wena, G. Chengb, X. Lia, Q. Meng et al., Reactive magnetron sputtering deposition and characterization of 

1 3 

**183** Page 30 of 34 

Nano-Micro Lett. (2021) 13:183 

niobium carbide films. Vacuum **99** , 233–241 (2014). https:// doi. org/ 10. 1016/j. vacuum. 2013. 06. 012 

115. S.A. Shiryaev, M. Atamanov, M. Guseva, Y. Martynenko, A. Mitin et al., Production and properties of metal-carbon composite coatings with a nanocrystalline structure. Tech. Phys. **47** , 238–243 (2002). https:// doi. org/ 10. 1134/1. 14519 74 

116. D. Yang, Z. Su, Y. Chen, K. Srinivas, J. Gao et al., Electronic modulation of hierarchical spongy nanosheets toward efficient and stable water electrolysis. Small **17** , 2006881 (2021). https:// doi. org/ 10. 1002/ smll. 20200 6881 

117. J. Wang, S. Liu, Y. Wang, T. Wang, S. Shang et al., Magnetron-sputtering deposited molybdenum carbide MXene thin films as a saturable absorber for passively Q-switched lasers. J. Mater. Chem. C **8** , 1608–1613 (2020). https:// doi. org/ 10. 1039/ C9TC0 6117G 

118. R.W. Chorley, P.W. Lednor, Synthetic routes to high surface area non-oxide materials. Adv. Mater. **3** , 474–485 (1991). https:// doi. org/ 10. 1002/ adma. 19910 031004 

119. T.P. Nguyen, D.M. Tuan Nguyen, D.L. Tran, H.K. Le, D.V.N. Vo et al., MXenes: Applications in electrocatalytic, photocatalytic hydrogen evolution reaction and  CO2 reduction. Mol. Catal. **486** , 110850 (2020). https:// doi. org/ 10. 1016/j. mcat. 2020. 110850 

120. Z. Wang, H.-H. Wu, Q. Li, F. Besenbacher, Y. Li et al., Reversing interfacial catalysis of ambipolar  WSe2 single crystal. Adv. Sci. **7** , 1901382 (2020). https:// doi. org/ 10. 1002/ advs. 20190 1382 

121. Z. Wang, Q. Li, H. Xu, C. Dahl-Petersen, Q. Yang et al., Controllable etching of MoS2 basal planes for enhanced hydrogen evolution through the formation of active edge sites. Nano Energy **49** , 634–643 (2018). https:// doi. org/ 10. 1016/j. nanoen. 2018. 04. 067 

122. G. Gao, A.P. O’Mullane, A. Du, 2D MXenes: A new family of promising catalysts for the hydrogen evolution reaction. ACS Catal. **7** , 494–500 (2017). https:// doi. org/ 10. 1021/ acsca tal. 6b027 54 

123. J. Wan, C. Wang, T. Qian, X. Gu, M. He, First-principles study of vanadium carbides as electrocatalysts for hydrogen and oxygen evolution reactions. RSC Adv. **9** , 37467–37473 (2019). https:// doi. org/ 10. 1039/ c9ra0 6539c 

124. L. Tian, S. Min, F. Wang, Z. Zhang, Enhanced photocatalytic hydrogen evolution on TiO2 employing vanadium carbide as an efficient and stable cocatalyst. Int. J. Hydrogen Energy **45** , 1878–1889 (2020). https:// doi. org/ 10. 1016/j. ijhyd ene. 2019. 11. 094 

125. Z. Hu, C. Chen, H. Meng, R. Wang, P. Shen et al., Oxygen reduction electrocatalysis enhanced by nanosized cubic vanadium carbide. Electrochem. Commun. **13** , 763–765 (2011). https:// doi. org/ 10. 1016/j. elecom. 2011. 03. 004 

126. L. Guo, Y. Liu, X. Teng, Y. Niu, S. Gong et al., Self-supported vanadium carbide by an electropolymerizationassisted method for efficient hydrogen production. Chemsuschem **13** , 3671–3678 (2020). https:// doi. org/ 10. 1002/ cssc. 20200 0769 

127. Y. Yoon, A.P. Tiwari, M. Choi, T.G. Novak, W. Song et al., Precious-metal-free electrocatalysts for activation of hydrogen evolution with nonmetallic electron donor: chemical composition controllable phosphorous doped vanadium carbide MXene. Adv. Funct. Mater. **29** , 1903443 (2019). https:// doi. org/ 10. 1002/ adfm. 20190 3443 

128. C.-F. Du, X. Sun, H. Yu, W. Fang, Y. Jing et al.,  V4C3Tx MXene: A promising active substrate for reactive surface modification and the enhanced electrocatalytic oxygen evolution activity. InfoMat **2** , 950–959 (2020). https:// doi. org/ 10. 1002/ inf2. 12078 

129. U. Jansson, E. Lewin, Sputter deposition of transition-metal carbide films — a critical review from a chemical perspective. Thin Solid Films **536** , 1–24 (2013). https:// doi. org/ 10. 1016/j. tsf. 2013. 02. 019 

130. W.-F. Chen, C.-H. Wang, K. Sasaki, N. Marinkovic, W. Xu et al., Highly active, durable, and nanostructured molybdenum carbide electrocatalysts for hydrogen production. Energy Environ. Sci. **6** , 943 (2013). https:// doi. org/ 10. 1039/ C2EE2 3891H 

131. Z. Chen, T. Guo, Z. Wu, D. Wang, Boron triggers the phase transformation of MoxC (α-MoC1-x/β-Mo2C) for enhanced hydrogen production. Nanotechnology. (2019). https:// doi. org/ 10. 1088/ 1361- 6528/ ab5a25 

132. N. Han, K.R. Yang, Z. Lu, Y. Li, W. Xu et al., Nitrogen-doped tungsten carbide nanoarray as an efficient bifunctional electrocatalyst for water splitting in acid. Nat. Commun. **9** , 924 (2018). https:// doi. org/ 10. 1038/ s41467- 018- 03429-z 

133. L. Lin, M. Chen, L. Wu, Synthesis of molybdenum–tungsten bimetallic carbide hollow spheres as pH-Universal electrocatalysts for efficient hydrogen evolution reaction. Adv. Mater. Interfaces **5** , 1801302 (2018). https:// doi. org/ 10. 1002/ admi. 20180 1302 

134. J. Chen, B. Ren, H. Cui, C. Wang, Constructing pure phase tungsten-based bimetallic carbide nanosheet as an efficient bifunctional electrocatalyst for overall water splitting. Small **16** , 1907556 (2020). https:// doi. org/ 10. 1002/ smll. 20190 7556 

135. L. Wang, Z. Liu, S. Zhu, M. Shao, B. Yang et al., Tungsten carbide and cobalt modified nickel nanoparticles supported on multiwall carbon nanotubes as highly efficient electrocatalysts for urea oxidation in alkaline electrolyte. ACS Appl. Mater. Interfaces **10** , 41338–41343 (2018). https:// doi. org/ 10. 1021/ acsami. 8b143 97 

136. K. Kui, K. Xi, Z. Pu, S. Mu, Constructing carbon-cohered high-index (222) faceted tantalum carbide nanocrystals as a robust hydrogen evolution catalyst. Nano Energy **36** , 374–380 (2017). https:// doi. org/ 10. 1016/j. nanoen. 2017. 04. 057 

137. W. Huang, H. Meng, Y. Gao, J. Wang, C. Yang et al., Metallic tungsten carbide nanoparticles as a near-infrared-driven photocatalyst. J. Mater. Chem. A **7** , 18538–18546 (2019). https:// doi. org/ 10. 1039/ C9TA0 3151K 

138. S. Li, P. Tuo, J. Xie, X. Zhang, J. Xu et al., Ultrathin MXene nanosheets with rich fluorine termination groups realizing efficient electrocatalytic hydrogen evolution. Nano Energy 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 31 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

**47** , 512–518 (2018). https:// doi. org/ 10. 1016/j. nanoen. 2018. 03. 022 

139. C. Wang, S. Wei, S. Chen, D. Cao, L. Song, Delaminating vanadium carbides for Zinc-ion storage: hydrate precipitation and  H<sup>+</sup> /Zn<sup>2+</sup> Co-action mechanism. Small Methods **3** , 1900495 (2019). https:// doi. org/ 10. 1002/ smtd. 20190 0495 

140. L. Liao, S. Wang, J. Xiao, X. Bian, Y. Zhang et al., A nanoporous molybdenum carbide nanowire as an electrocatalyst for hydrogen evolution reaction. Energy Environ. Sci. **7** , 387–392 (2014). https:// doi. org/ 10. 1039/ C3EE4 2441C 

141. L. Ma, L.R.L. Ting, V. Molinari, C. Giordano, B.S. Yeo, Efficient hydrogen evolution reaction catalyzed by molybdenum carbide and molybdenum nitride nanocatalysts synthesized via the urea glass route. J. Mater. Chem. A **3** , 8361–8368 (2015). https:// doi. org/ 10. 1039/ C5TA0 0139K 

142. A.D. Handoko, K.D. Fredrickson, B. Anasori, K.W. Convey, L.R. Johnson et al., Tuning the basal plane functionalization of two-dimensional metal carbides (MXenes) to control hydrogen evolution activity. ACS Appl. Energy Mater. **1** , 173–180 (2018). https:// doi. org/ 10. 1021/ acsaem. 7b000 54 

143. Z. Kou, K. Xi, Z. Pu, S. Mu, Constructing carbon-cohered high-index (222) faceted tantalum carbide nanocrystals as a robust hydrogen evolution catalyst. Nano Energy **36** , 374–380 (2017). https:// doi. org/ 10. 1016/j. nanoen. 2017. 04. 057 

144. D.P. Valencia, L. Yate, W. Aperador, Y. Li, E. Coy, High electrocatalytic response of ultra-refractory ternary alloys of Ta-Hf-C carbide toward hydrogen evolution reaction in acidic media. J. Phys. Chem. C **122** , 25433–25440 (2018). https:// doi. org/ 10. 1021/ acs. jpcc. 8b081 23 

145. L. Qiao, A. Zhu, W. Zeng, R. Dong, P. Tan et al., Achieving electronic structure reconfiguration in metallic carbides for robust electrochemical water splitting. J. Mater. Chem. A **8** , 2453–2462 (2020). https:// doi. org/ 10. 1039/ C9TA1 0682K 

146. C.-F. Du, K.N. Dinh, Q. Liang, Y. Zheng, Y. Luo et al., Selfassemble and in situ formation of Ni1−xFexPS3 nanomosaicdecorated MXene hybrids for overall water splitting. Adv. Energy Mater. **8** , 1801127 (2018). https:// doi. org/ 10. 1002/ aenm. 20180 1127 

147. D. Das, S. Santra, K.K. Nanda, In situ fabrication of a Nickel/Molybdenum carbide-anchored N-doped graphene/ CNT hybrid: an efficient (pre)catalyst for OER and HER. ACS Appl. Mater. Interf. **10** , 35025–35038 (2018). https:// doi. org/ 10. 1021/ acsami. 8b099 41 

148. H. Fan, H. Yu, Y. Zhang, Y. Zheng, Y. Luo et al., Fe-doped Ni3C nanodots in N-doped carbon nanosheets for efficient hydrogen-evolution and oxygen-evolution electrocatalysis. Angew. Chem. Int. Ed. **56** , 12566–12570 (2017). https:// doi. org/ 10. 1002/ anie. 20170 6610 

149. L. Zhao, B. Dong, S. Li, L. Zhou, L. Lai et al., Interdiffusion reaction-assisted hybridization of two-dimensional metal–organic frameworks and  Ti3C2Tx nanosheets for electrocatalytic oxygen evolution. ACS Nano **11** , 5800– 5807 (2017). https:// doi. org/ 10. 1021/ acsna no. 7b014 09 

150. S. Gao, H. Chen, Y. Liu, G.-D. Li, R. Gao et al., Surfaceclean, phase-pure multi-metallic carbides for efficient electrocatalytic hydrogen evolution reaction. Inorg. Chem. 

Front. **6** , 940–947 (2019). https:// doi. org/ 10. 1039/ C8QI0 1360H 

151. Y. Yoon, A.P. Tiwari, M. Lee, M. Choi, W. Song et al., Enhanced electrocatalytic activity by chemical nitridation of two-dimensional titanium carbide MXene for hydrogen evolution. J. Mater. Chem. A **6** , 20869–20877 (2018). https:// doi. org/ 10. 1039/ C8TA0 8197B 

152. X. Zang, W. Chen, X. Zou, J.N. Hohman, L. Yang et al., Self-assembly of large-area 2D polycrystalline transition metal carbides for hydrogen electrocatalysis. Adv. Mater. **30** , 1805188 (2018). https:// doi. org/ 10. 1002/ adma. 20180 5188 

153. A. Mondal, K. Sinha, A. Paul, D.N. Srivastava, A.B. Panda, Large scale synthesis of  Mo2C nanoparticle incorporated carbon nanosheet  (Mo2C–C) for enhanced hydrogen evolution reaction. Int. J. Hydrogen Energy **45** , 18623–18634 (2020). https:// doi. org/ 10. 1016/j. ijhyd ene. 2019. 09. 051 

154. Y. Jiang, T. Sun, X. Xie, W. Jiang, J. Li et al., Oxygen-functionalized ultrathin  Ti3C2Tx MXene for enhanced electrocatalytic hydrogen evolution. Chemsuschem **12** , 1368–1373 (2019). https:// doi. org/ 10. 1002/ cssc. 20180 3032 

155. Y. Zhou, R. Ma, P. Li, Y. Chen, Q. Liu et al., Ditungsten carbide nanoparticles encapsulated by ultrathin graphitic layers with excellent hydrogen-evolution electrocatalytic properties. J. Mater. Chem. A **4** , 8204–8210 (2016). https:// doi. org/ 10. 1039/ C6TA0 1601D 

156. L. Wang, Z. Li, K. Wang, Q. Dai, C. Lei et al., Tuning d-band center of tungsten carbide via Mo doping for efficient hydrogen evolution and Zn–H2O cell over a wide pH range. Nano Energy **74** , 104850 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2020. 104850 

157. D.B. Burueva, A.A. Smirnov, O.A. Bulavchenko, I.P. Prosvirin, E.Y. Gerasimov et al., Pairwise parahydrogen addition over molybdenum carbide catalysts. Top. Catal. **63** , 2–11 (2020). https:// doi. org/ 10. 1007/ s11244- 019- 01211-z 

158. T. Xiao, A. York, V. Williams, H. Almegren, A. Hanif et al., Preparation of molybdenum carbides using butane and their catalytic performance. Chem. Mater. (2000). https:// doi. org/ 10. 1021/ cm001 157t 

159. E.B. Deeva, A. Kurlov, P.M. Abdala, D. Lebedev, S.M. Kim et al., In Situ XANES/XRD study of the structural stability of two-dimensional molybdenum carbide  Mo2CTx: implications for the catalytic activity in the water–gas shift reaction. Chem. Mater. **31** , 4505–4513 (2019). https:// doi. org/ 10. 1021/ acs. chemm ater. 9b011 05 

160. A. Pajares, H. Prats, A. Romero, F. Viñes, P.R. de la Piscina et al., Critical effect of carbon vacancies on the reverse water gas shift reaction over vanadium carbide catalysts. App. Catal. B-Environ. **267** , 118719 (2020). https:// doi. org/ 10. 1016/j. apcatb. 2020. 118719 

161. E. Lee, A. VahidMohammadi, Y.S. Yoon, M. Beidaghi, D.-J. Kim, Two-dimensional vanadium carbide MXene for gas sensors with ultrahigh sensitivity toward nonpolar gases. ACS Sensors **4** , 1603–1611 (2019). https:// doi. org/ 10. 1021/ acsse nsors. 9b003 03 

162. L. Zhao, K. Wang, W. Wei, L. Wang, W. Han, High-performance flexible sensing devices based on polyaniline/MXene 

1 3 

**183** Page 32 of 34 

Nano-Micro Lett. (2021) 13:183 

   - nanocomposites. InfoMat **1** , 407–416 (2019). https:// doi. org/ 10. 1002/ inf2. 12032 

163. S. Sun, M. Wang, X. Chang, Y. Jiang, D. Zhang et al., W18O49/Ti3C2Tx Mxene nanocomposites for highly sensitive acetone gas sensor with low detection limit. Sens. Actuators B Chem. **304** , 127274 (2020). https:// doi. org/ 10. 1016/j. snb. 2019. 127274 

164. W. Li, Y. Yang, G. Zhang, Y.-W. Zhang, Ultrafast and directional diffusion of lithium in phosphorene for high-performance lithium-ion battery. Nano Lett. **15** , 1691–1697 (2015). https:// doi. org/ 10. 1021/ nl504 336h 

165. H. Jin, S. Xin, C. Chuang, W. Li, H. Wang et al., Black phosphorus composites with engineered interfaces for high-rate high-capacity lithium storage. Science **370** , 192 (2020). https:// doi. org/ 10. 1126/ scien ce. aav58 42 

166. P. Ma, D. Fang, Y. Liu, Y. Shang, Y. Shi et al., MXene-Based materials for electrochemical sodium-ion storage. Adv. Sci. (2021). https:// doi. org/ 10. 1002/ advs. 20200 3185 

167. M. Naguib, J. Halim, J. Lu, K.M. Cook, L. Hultman et al., New two-dimensional niobium and vanadium carbides as promising materials for Li-Ion batteries. J. Am. Chem. Soc. **135** , 15966–15969 (2013). https:// doi. org/ 10. 1021/ ja405 735d 

168. Z. Lin, P. Rozier, B. Duployer, P.-L. Taberna, B. Anasori et al., Electrochemical and In-situ X-ray diffraction Studies of  Ti3C2Tx MXene in Ionic liquid Electrolyte. Electrochem. Commun. (2016). https:// doi. org/ 10. 1016/j. elecom. 2016. 08. 023 

169. J. Zhou, S. Lin, Y. Huang, P. Tong, B. Zhao et al., Synthesis and lithium ion storage performance of two-dimensional V4C3 MXene. Chem. Eng. J. **373** , 203–212 (2019). https:// doi. org/ 10. 1016/j. cej. 2019. 05. 037 

170. J. Zhao, J. Wen, L. Bai, J. Xiao, R. Zheng et al., One-step synthesis of few-layer niobium carbide MXene as a promising anode material for high-rate lithium ion batteries. Dalton Trans. **48** , 14433–14439 (2019). https:// doi. org/ 10. 1039/ C9DT0 3260F 

171. S. Shen, X. Xia, Y. Zhong, S. Deng, D. Xie et al., Implanting niobium carbide into trichoderma spore carbon: a new advanced host for sulfur cathodes. Adv. Mater. **31** , 1900009 (2019). https:// doi. org/ 10. 1002/ adma. 20190 0009 

172. C. Wenlong, G. Li, K. Zhang, G. Xiao, C. Wang et al., Conductive nanocrystalline niobium carbide as high-efficiency polysulfides tamer for lithium-sulfur batteries. Adv. Funct. Mater. **28** , 1704865 (2017). https:// doi. org/ 10. 1002/ adfm. 20170 4865 

173. A. VahidMohammadi, A. Hadjikhani, S. Shahbazmohamadi, M. Beidaghi, Two-dimensional vanadium carbide (MXene) as a high-capacity cathode material for rechargeable aluminum batteries. ACS Nano **11** , 11135–11144 (2017). https:// doi. org/ 10. 1021/ acsna no. 7b053 50 

174. J. Yu, M. Li, X. Wang, Z. Yang, Promising high-performance supercapacitor electrode materials from  MnO2 Nanosheets@ Bamboo leaf carbon. ACS Omega **5** , 16299–16306 (2020). https:// doi. org/ 10. 1021/ acsom ega. 0c021 69 

175. Y. Zhao, Q. Fang, X. Zhu, L. Xue, M. Ni et al., Structure reinforced birnessite with an extended potential window for 

   - supercapacitors. J. Mater. Chem. A **8** , 8969–8978 (2020). https:// doi. org/ 10. 1039/ D0TA0 1480J 

176. Z. Wang, J. Liu, X. Hao, Y. Wang, Y. Chen et al., Enhanced power density of a supercapacitor by introducing 3D-interfacial graphene. New J. Chem. **44** , 13377–13381 (2020). https:// doi. org/ 10. 1039/ D0NJ0 2105A 

177. J. Xiao, H. Zhan, X. Wang, Z.-Q. Xu, Z. Xiong et al., Electrolyte gating in graphene-based supercapacitors and its use for probing nanoconfined charging dynamics. Nat. Nanotech. **15** , 683–689 (2020). https:// doi. org/ 10. 1038/ s41565- 020- 0704-7 

178. H. Dong, P. Xiao, N. Jin, B. Wang, Y. Liu et al., Molten salt derived  Nb2CTx MXene anode for Li-ion batteries. ChemElectroChem **8** , 957–962 (2021). https:// doi. org/ 10. 1002/ celc. 20210 0142 

179. Y. Li, H. Shao, Z. Lin, J. Lu, L. Liu et al., A general Lewis acidic etching route for preparing MXenes with enhanced electrochemical performance in non-aqueous electrolyte. Nat. Mater. **19** , 894–899 (2020). https:// doi. org/ 10. 1038/ s41563- 020- 0657-0 

180. Q. Shan, X. Mu, M. Alhabeb, C.E. Shuck, D. Pang et al., Two-dimensional vanadium carbide  (V2C) MXene as electrode for supercapacitors with aqueous electrolytes. Electrochem. Commun. **96** , 103–107 (2018). https:// doi. org/ 10. 1016/j. elecom. 2018. 10. 012 

181. G. Lv, J. Wang, Z. Shi, L. Fan, Intercalation and delamination of two-dimensional MXene  (Ti3C2Tx) and application in sodium-ion batteries. Mater. Lett. **219** , 45–50 (2018). https:// doi. org/ 10. 1016/j. matlet. 2018. 02. 016 

182. S. Nam, S. Umrao, S. Oh, K.H. Shin, H.S. Park et al., Sonochemical self-growth of functionalized titanium carbide nanorods on  Ti3C2 nanosheets for high capacity anode for lithium-ion batteries. Compos. Part B-Eng. **181** , 107583 (2020). https:// doi. org/ 10. 1016/j. compo sitesb. 2019. 107583 

183. C.E. Ren, M.-Q. Zhao, T. Makaryan, J. Halim, M. Boota et al., Porous two-dimensional transition metal carbide (MXene) flakes for high-performance Li-Ion storage. ChemElectroChem **3** , 689–693 (2016). https:// doi. org/ 10. 1002/ celc. 20160 0059 

184. S. Zhao, X. Meng, K. Zhu, F. Du, G. Chen et al., Li-ion uptake and increase in interlayer spacing of  Nb4C3 MXene. Energy Storage Mater. **8** , 42–48 (2017). https:// doi. org/ 10. 1016/j. ensm. 2017. 03. 012 

185. L. Ma, T. Chen, G. Zhu, Y. Hu, H. Lu et al., Pitaya-like microspheres derived from Prussian blue analogues as ultralong-life anodes for lithium storage. J. Mater. Chem. A **4** , 15041–15048 (2016). https:// doi. org/ 10. 1039/ C6TA0 6692E 

186. Y.-T. Liu, P. Zhang, N. Sun, B. Anasori, Q.-Z. Zhu et al., Self-Assembly of Transition metal oxide nanostructures on MXene nanosheets for fast and stable lithium storage. Adv. Mater. **30** , 1707334 (2018). https:// doi. org/ 10. 1002/ adma. 20170 7334 

187. C. Zhang, S.J. Kim, M. Ghidiu, M.-Q. Zhao, M.W. Barsoum et al., Layered orthorhombic  Nb2O5@Nb4C3Tx and  TiO2@ Ti3C2Tx hierarchical composites for high performance Li-ion batteries. Adv. Funct. Mater. **26** , 4143–4151 (2016). https:// doi. org/ 10. 1002/ adfm. 20160 0682 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

Page 33 of 34 **183** 

Nano-Micro Lett. (2021) 13:183 

188. H. Zhang, H. Cui, J. Li, Y. Liu, Y. Yang et al., Frogspawn inspired hollow  Fe3C@N–C as an efficient sulfur host for high-rate lithium–sulfur batteries. Nanoscale **11** , 21532– 21541 (2019). https:// doi. org/ 10. 1039/ C9NR0 7388D 

189. F. Zhou, Z. Li, X. Luo, T. Wu, B. Jiang et al., Low cost metal carbide nanocrystals as binding and electrocatalytic sites for high performance Li–S batteries. Nano Lett. **18** , 1035–1043 (2018). https:// doi. org/ 10. 1021/ acs. nanol ett. 7b045 05 

190. T. Chen, M. Li, S. Song, P. Kim, J. Bae, Biotemplate preparation of multilayered TiC nanoflakes for high performance symmetric supercapacitor. Nano Energy **71** , 104549 (2020). https:// doi. org/ 10. 1016/j. nanoen. 2020. 104549 

191. X. Zhao, Z. Wang, J. Dong, T. Huang, Q. Zhang et al., Annealing modification of MXene films with mechanically strong structures and high electrochemical performance for supercapacitor applications. J. Power Sources **470** , 228356 (2020). https:// doi. org/ 10. 1016/j. jpows our. 2020. 228356 

192. H. Zhang, J. Liu, Z. Tian, Y. Ye, Y. Cai et al., A general strategy toward transition metal carbide/carbon core/shell nanospheres and their application for supercapacitor electrode. Carbon **100** , 590–599 (2016). https:// doi. org/ 10. 1016/j. carbon. 2016. 01. 047 

193. X. Wang, H. Li, H. Li, S. Lin, W. Ding et al., 2D/2D 1T-MoS2/Ti3C2 MXene heterostructure with excellent supercapacitor performance. Adv. Funct. Mater. **30** , 0190302 (2020). https:// doi. org/ 10. 1002/ adfm. 20191 0302 

194. M. Shi, L. Zhao, X. Song, J. Liu, P. Zhang et al., Highly conductive Mo2C nanofibers encapsulated in ultrathin  MnO2 nanosheets as a self-supported electrode for high-performance capacitive energy storage. ACS Appl. Mater. Interf. **8** , 32460–32467 (2016). https:// doi. org/ 10. 1021/ acsami. 6b106 37 

195. J. Chen, Z. Li, F. Ni, W. Ouyang, X. Fang, Bio-inspired transparent MXene electrodes for flexible UV photodetectors. Mater. Horizons **7** , 1828–1833 (2020). https:// doi. org/ 10. 1039/ D0MH0 0394H 

196. K. Montazeri, M. Currie, L. Verger, P. Dianat, M.W. Barsoum et al., Beyond gold: Spin-Coated  Ti3C2-based MXene photodetectors. Adv. Mater. **31** , 1903271 (2019). https:// doi. org/ 10. 1002/ adma. 20190 3271 

197. Y. Yang, J. Jeon, J.-H. Park, M.S. Jeong, B.H. Lee et al., Plasmonic transition metal carbide electrodes for high-performance inse photodetectors. ACS Nano **13** , 8804–8810 (2019). https:// doi. org/ 10. 1021/ acsna no. 9b019 41 

198. A. Ren, J. Zou, H. Lai, Y. Huang, L. Yuan et al., Direct laser-patterned MXene–perovskite image sensor arrays for visible-near infrared photodetection. Mater. Horizons **7** , 1901–1911 (2020). https:// doi. org/ 10. 1039/ D0MH0 0537A 

199. Z. Kang, Y. Ma, X. Tan, M. Zhu, Z. Zheng et al., MXene– Silicon van der waals heterostructures for high-speed selfdriven photodetectors. Adv. Electron. Mater. **3** , 1700165 (2017). https:// doi. org/ 10. 1002/ aelm. 20170 0165 

200. L. Gao, H. Chen, F. Zhang, S. Mei, Y. Zhang et al., Ultrafast relaxation dynamics and nonlinear response of fewlayer niobium carbide MXene. Small Methods (2020). https:// doi. org/ 10. 1002/ smtd. 20200 0250 

201. J. Jeon, H. Choi, S. Choi, J.-H. Park, B.H. Lee et al., Transition-metal-carbide  (Mo2C) multiperiod gratings for realization of high-sensitivity and broad-spectrum photodetection. Adv. Electron. Mater. **29** , 1905384 (2019). https:// doi. org/ 10. 1002/ adfm. 20190 5384 

202. L. Hao, Y. Du, Z. Wang, Y. Wu, H. Xu et al., Wafer-size growth of 2D layered SnSe films for UV-Visible-NIR photodetector arrays with high responsitivity. Nanoscale **12** , 7358–7365 (2020). https:// doi. org/ 10. 1039/ D0NR0 0319K 

203. H. Xu, L. Hao, H. Liu, S. Dong, Y. Wu et al., Flexible SnSe Photodetectors with ultrabroad spectral response up to 10.6 μm enabled by photobolometric effect. ACS Appl. Mater. Interfaces **12** , 35250–35258 (2020). https:// doi. org/ 10. 1021/ acsami. 0c095 61 

204. H. Lin, S. Gao, C. Dai, Y. Chen, J. Shi, A two-dimensional biodegradable niobium carbide (MXene) for photothermal tumor eradication in NIR-I and NIR-II biowindows. J. Am. Chem. Soc. **139** , 16235–16247 (2017). https:// doi. org/ 10. 1021/ jacs. 7b078 18 

205. X. Ren, M. Huo, M. Wang, H. Lin, X. Zhang et al., Highly catalytic niobium carbide (MXene) promotes hematopoietic recovery after radiation by free radical scavenging. ACS Nano **13** , 6438–6454 (2019). https:// doi. org/ 10. 1021/ acsna no. 8b093 27 

206. H. Lin, Y. Wang, S. Gao, Y. Chen, J. Shi, Theranostic 2D tantalum carbide (MXene). Adv. Mater. **30** , 1703284 (2018). https:// doi. org/ 10. 1002/ adma. 20170 3284 

207. W. Ren, Z. Liu, C. Xu, C. Wang, S. Song et al., Grain boundaries and tilt angle-dependent transport properties of 2D  Mo2C superconductor. Nano Lett. **19** , 857–865 (2019). https:// doi. org/ 10. 1021/ acs. nanol ett. 8b040 65 

208. S. Jin, T. Su, Q. Hu, A. Zhou, Thermal conductivity and electrical transport properties of double-A-layer MAX phase  Mo2Ga2C. Mater. Res. Lett. **8** , 158–164 (2020). https:// doi. org/ 10. 1080/ 21663 831. 2020. 17242 04 

209. F. Porrati, S. Barth, R. Sachser, O.V. Dobrovolskiy, A. Seybert et al., Crystalline niobium carbide superconducting nanowires prepared by focused ion beam direct writing. ACS Nano **13** , 6287–6296 (2019). https:// doi. org/ 10. 1021/ acsna no. 9b000 59 

210. Z. Wang, H.-H. Wu, Q. Li, F. Besenbacher, X.C. Zeng et al., Self-scrolling  MoS2 metallic wires. Nanoscale **10** , 18178–18185 (2018). https:// doi. org/ 10. 1039/ C8NR0 4611E 

211. M. Hao, C. Xu, Z. Liu, C. Wang, Z. Liu et al., Transport through a network of two-dimensional NbC superconducting crystals connected via weak links. Phys. Rev. B **101** , 115422 (2020). https:// doi. org/ 10. 1103/ PhysR evB. 101. 115422 

212. Y. Cheng, X. Wu, Z. Zhang, Y. Sun, Y. Zhao et al., Thermomechanical correlation in two-dimensional materials. Nanoscale **13** , 1425–1442 (2021). https:// doi. org/ 10. 1039/ D0NR0 6824A 

213. G. Zhang, Y.-W. Zhang, Thermal properties of two-dimensional materials. Chin. Phys. B **26** , 034401 (2017). https:// doi. org/ 10. 1088/ 1674- 1056/ 26/3/ 034401 

1 3 

**183** Page 34 of 34 

Nano-Micro Lett. (2021) 13:183 

214. X. Lu, Q. Zhang, J. Liao, H. Chen, Y. Fan et al., High-efficiency thermoelectric power generation enabled by homogeneous incorporation of MXene in (Bi,  Sb)2Te3 Matrix. Adv. Energy Mater. **10** , 1902986 (2020). https:// doi. org/ 10. 1002/ aenm. 20190 2986 

215. S. Hong, G. Zou, H. Kim, D. Huang, P. Wang et al., Photothermoelectric response of  Ti3C2Tx MXene confined ion channels. ACS Nano **14** , 9042–9049 (2020). https:// doi. org/ 10. 1021/ acsna no. 0c040 99 

216. J.H. Kim, G.S. Park, Y.-J. Kim, E. Choi, J. Kang et al., Large-area  Ti3C2Tx-MXene coating: toward industrialscale fabrication and molecular separation. ACS Nano **15** , 8860–8869 (2021). https:// doi. org/ 10. 1021/ acsna no. 1c014 48 

217. J. Wang, Z. Zhang, J. Zhu, M. Tian, S. Zheng et al., Ion sieving by a two-dimensional  Ti3C2Tx alginate lamellar membrane with stable interlayer spacing. Nat. Commun. **11** , 3540 (2020). https:// doi. org/ 10. 1038/ s41467- 020- 17373-4 

218. D. Xu, X. Zhu, X. Luo, Y. Guo, Y. Liu et al., MXene nanosheet templated nanofiltration membranes toward ultrahigh water transport. Environ. Sci. Technol. **55** , 1270– 1278 (2021). https:// doi. org/ 10. 1021/ acs. est. 0c068 35 

      - Ti3C2Tx for electromagnetic interference shielding coatings. ACS Appl. Mater. Interfaces **12** , 49737–49747 (2020). https:// doi. org/ 10. 1021/ acsami. 0c128 35 

   220. B. Aïssa, A. Sinopoli, A. Ali, Y. Zakaria, A. Zekri et al., Nanoelectromagnetic of a highly conductive 2D transition metal carbide (MXene)/Graphene nanoplatelets composite in the EHF M-band frequency. Carbon **173** , 528–539 (2021). https:// doi. org/ 10. 1016/j. carbon. 2020. 11. 024 

   221. S. Liu, J. Liu, X. Liu, J. Shang, L. Xu et al., Hydrogen storage in incompletely etched multilayer  Ti2CTx at room temperature. Nat. Nanotechnol. **16** , 331–336 (2021). https:// doi. org/ 10. 1038/ s41565- 020- 00818-8 

   222. T.H. Phuong Doan, W.G. Hong, J.-S. Noh, Palladium nanoparticle-decorated multi-layer  Ti3C2Tx dual-functioning as a highly sensitive hydrogen gas sensor and hydrogen storage. RSC Adv. **11** , 7492–7501 (2021). https:// doi. org/ 10. 1039/ D0RA1 0879K 

   223. W. Zhu, S. Panda, C. Lu, Z. Ma, D. Khan et al., Using a selfassembled two-dimensional MXene-based catalyst (2D-Ni@ Ti3C2) to enhance hydrogen storage properties of  MgH2. ACS Appl. Mater. Interfaces **12** , 50333–50343 (2020). https:// doi. org/ 10. 1021/ acsami. 0c127 67 

219. K. Rajavel, X. Yu, P. Zhu, Y. Hu, R. Sun et al., Exfoliation and defect control of two-dimensional few-layer MXene 

© The authors 

https://doi.org/10.1007/s40820-021-00710-7 

