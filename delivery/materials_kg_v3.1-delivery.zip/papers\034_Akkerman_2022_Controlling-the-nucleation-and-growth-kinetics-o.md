# Controlling the nucleation and growth kinetics of lead halide perovskite quantum dots

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 381 |
| 作者 | Q. Akkerman, Tan P. T. Nguyen, S. Boehme, F. Montanarella, D. Dirin, Philipp Wechsler, Finn Beiglböck, G. Rainò et al. |
| DOI | 10.1126/science.abq3616 |
| 源文件 | 034_Akkerman_2022_Controlling-the-nucleation-and-growth-kinetics-o.pdf |

---




<!-- Start of picture text -->
Taming the nucleation and growth kinetics of lead<br>halide perovskite quantum dots<br><!-- End of picture text -->

Maksym Kovalenko  (  mvkovalenko@ethz.ch ) Swiss Federal Institute of Technology in Zurich https://orcid.org/0000-0002-6396-8938 

ETH Zurich Tan Nguyen University Rennes 

ETH Zurich https://orcid.org/0000-0002-8399-5773 

ETH Zurich Dmitry Dirin ETH Zurich Philipp Wechsler ETH Zurich 

ETH Zurich 

Swiss Federal Laboratories for Materials Science and Technology https://orcid.org/0000-0003-23915943 

Univ Rennes, CNRS, https://orcid.org/0000-0002-2017-5823 

Institut FOTON UMR CNRS 6082 https://orcid.org/0000-0002-4607-3390 



<!-- Start of picture text -->
Physical Sciences  -  Article<br>Keywords:<br><!-- End of picture text -->

Posted Date: February 25th, 2022 

DOI: https://doi.org/10.21203/rs.3.rs-1236393/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

# **Taming the nucleation and growth kinetics of lead halide perovskite quantum** 

# **dots** 

_Quinten A. Akkerman,_<sup>_1,2,*_</sup> _Tan P. T. Nguyen,_<sup>_3_</sup> _Simon C. Boehme,_<sup>_1,2_</sup> _Federico Montanarella,_<sup>_1,2_</sup> _Dmitry N. Dirin,_<sup>_1,2_</sup> _Philipp Wechsler,_<sup>_1_</sup> _Finn Beiglböck,_<sup>_2_</sup> _Rolf Erni,_<sup>_4_</sup> _Claudine Katan,_<sup>_3_</sup> _Jacky Even_<sup>_5_</sup> _and Maksym V. Kovalenko_<sup>_1,2_</sup> 

1Department of Chemistry and Applied Biosciences, ETH Zürich, Zürich CH-8093, Switzerland 

2Empa-Swiss Federal Laboratories for Materials Science and Technology, Dübendorf, CH-8600, Switzerland 

3Univ Rennes, ENSCR, INSA Rennes, CNRS, ISCR - UMR 6226, F-35000 Rennes, France 

4Electron Microscopy Center, Empa – Swiss Federal Laboratories for Materials Science and Technology, Dübendorf, Switzerland. 

> 5 <mark>Univ Rennes, INSA Rennes, CNRS, Institut FOTON - UMR 6082, F-35000 Rennes, France</mark> 

*Current address: Lehrstuhl für Photonik und Optoelektronik, Nano-Institut München und Fakultät für Physik, Ludwig-Maximilians-Universität (LMU), Königinstr. 10, D-80539 München, Germany 

Correspondence: mvkovalenko@ethz.ch 



1 

**Colloidal lead halide perovskite (LHP) nanocrystals (NCs)**<sup>**1-6**</sup> **, with bright and spectrally narrow photoluminescence (PL) tunable over the entire visible spectral range, are the latest generation of semiconductor quantum dots (QDs) of immense interest as classical and quantum light sources**<sup>**7-9**</sup> **. LHP NCs form by sub-second fast and hence hard-to-control ionic metathesis reactions, which severely limits the access to size-uniform and shape-regular NCs in the sub-10 nm range. We posit that a synthesis path comprising an intricate equilibrium between the precursor (PbBr2) and the Cs[PbBr3] solute  for the QD nucleation may circumvent this challenge. Here, we report a roomtemperature synthesis of monodisperse, isolable spheroidal CsPbBr3 QDs, size-tunable in the 3-13 nm range. The kinetics of both nucleation and therefrom temporally separated growth are drastically slowed down by the formation of transient Cs[PbBr3], resulting in total reaction times of up to 30 minutes. The methodology is then extended to FAPbBr3 (FA = formamidinium) and MAPbBr3 (MA = methylammonium), allowing for thorough experimental comparison and modelling of their physical properties under intermediate quantum confinement. In particular, QDs of all these compositions exhibit up to four excitonic transitions in their linear absorption spectra and we demonstrate that the size-dependent confinement energy for all transitions is independent of the A-site cation.** 



2 

Colloidal LHP NCs have recently become popular light-emissive materials<sup>4-6</sup> , of practical interest for LEDs<sup>10-13</sup> , LCD displays<sup>14-16</sup> , lasers<sup>17-20</sup> , scintillators<sup>21,22</sup> and luminescent solar concentrators<sup>23-25</sup> . They are much praised for simultaneously exhibiting near-unity PL quantum yields (QYs), a PL peak tailorable across the 410-800 nm spectral range with small PL full widths at half maximum (FWHM, ˂100 meV), largeabsorption cross-sections<sup>26</sup> , long exciton coherence times and sub-ns fast radiative rates at low temperatures<sup>27-29</sup> . Much scientific interest revolves around single-photon emission from LHP NCs<sup>7,8,29-31</sup> and collective phenomena in LHP NC assemblies such as superfluorescence<sup>9,32-34</sup> . 

Until now, and owing to their synthetic availability, most studies on colloidal LHP NCs focused on relatively large NC sizes, i.e. with diameters of around or exceeding 10 nm. In this weak excitonic confinement regime, tunability of the bandgap energy is predominantly achieved via mixed-halide compositions. Structurally soft, with rather ionic chemical bonding, LHP NCs vastly, rather orthogonally, differ to more conventional QD materials such as CdSe and InP having covalent and rigid crystal structure. One such difference is the difficulty in producing small LHP QDs, down to few nanometers in diameter, thus hindering the studies into the diverse expressions of the strong size-quantization of excitons in LHPs (and practical use thereof) as well as understanding of the mechanism of LHP QD formation. High lattice ionicity and low lattice formation energy of LHP NCs is a mixed blessing when it comes to the synthesis of small QDs: they form too quickly as ionic co-precipitation, with sub-second formation kinetics. In this regard also the surface capping ligands – crucially important for the controlled nucleation and growth as well as for the structural integrity of the resulting QDs and their stability against solvents and environment – bind in a noncovalent and dynamic manner<sup>35</sup> , thus contributing to the difficulty of arresting the QD formation and stabilizing them at small sizes. 

Monodispersity and shape-uniformity, as well as precise size-tunability in the sub-10 nm regime must be realized through the scalable synthesis that yields isolable, pure and robust QD samples. Thus far no synthesis method fulfilling the entirety of these requirements has been reported for small LHP QDs. Limited success had been reached for CsPbX3 (X Cl, Br, I) compositions<sup>34,36,37</sup> , wherein QD fractions down to 3-4 nm are obtained post-synthetically, albeit with small synthesis yield for a specific QD size fraction, foremost due to broad size dispersion or very lossy isolation. Noteworthy is the use of long-chain zwitterionic capping 

3 

ligands that exhibit improved surface adhesion relative to more conventional single-binding-head molecules, rendering the small CsPbBr3 QDs sufficiently robust to sustain multiple steps of size-selective precipitation leading to monodisperse fractions<sup>34</sup> . Small colloidal FAPbX3 and MAPbX3 NCs, however, remained elusive as they are even more labile structurally. 

We reasoned that the slower formation of small monodisperse LHP QDs at full reaction yield cannot be accomplished only by mere adjustments of typical reaction parameters, such as lowering of the reaction temperature and concentration of reagents. We hypothesized that precursor-monomer-QD nuclei conversion path must be characterized by the mutual chemical equilibrium between these moieties governed by the common complexing agent, thus having a self-limiting character as well. Importantly, this equilibrium shall not be obscured by any competing process, such as binding of a stronger capping ligand to the QD surface, which is somewhat contradictory to the previous efforts on stabilizing the perovskite NC surfaces by stronger binding ligands. We find that trioctylphosphine oxide (TOPO) serves this three-fold mission as it complexes (solubilizes) the PbBr2 precursor, binds to the Cs[PbBr3] monomer (solute) and then weakly coordinates to the QD nuclei surface. The issue of isolation and subsequent robustness of the obtained QDs is then mitigated by adding a stronger binding ligand – lecithin as a long-chain zwitterion – at the end of the QD formation step. We thus present a room-temperature synthesis, wherein the overall QD formation occurs on the scale of up to 30 minutes, hereby allowing also the live _in-situ_ observation of the reaction by optical absorption and emission spectroscopy. After the isolation, monodisperse rhombicuboctahedral CsPbBr3 QDs, with mean size tunable in 3-13 nm range, are obtained at 100% precursor-to-QD conversion rate. These CsPbBr3 QDs, as well as FAPbBr3 and MAPbBr3 QDs obtained analogously, exhibit up to four well-resolved excitonic transitions and the size-dependent confinement energies for all transitions is independent of the A-site cations. The obtained energies of these transitions, utilizing the statistics from over 25.000 individual spectra, are then found to agree with those calculated using effective mass/ **kꞏp** model. 

## **Synthesis of monodisperse CsPbBr3 QDs.** 

We sought to tame the nucleation and growth of LHP QDs while ensuring a facile one-pot synthesis methodology that uses off-the-shelf chemicals and that is suited for _in-situ_ monitoring with optical and 

4 

structural methods, as well as for _ex-situ_ characterization ( **Fig.1** ). We hypothesized that the conventional approach – referred to as oleylamine - oleic acid (OLAM/OA) path<sup>1</sup> – suffers from the immediate conversion of the PbBr2 into haloplumbate ionic solute (PbBr3<sup>-</sup> ) upon the action of OLAM/OA<sup>38,39</sup> . The subsequent reaction with injected Cs-ions is thus quantitative and fast, and hence nucleation and growth are not temporally separated. We thus aimed at establishing the mechanism, in which the formation of PbBr3<sup>-</sup> anions is activated to the introduction of Cs-cations by having the latter as the only available cation in the system throughout the synthesis, and wherein the equilibrium is retained with the non-reactive PbBr2 precursor reservoir through a common coordinating agent. We therefore took an approach of using a neutral molecule TOPO as a sole coordinating agent for solubilizing PbBr2 precursor<sup>40</sup> . Into this PbBr2:TOPO solution, Cesium <mark>-diisooctylphosphinate</mark> (Cs-DOPA) solution was injected at room temperature (both in hexane; see **Methods** , **Supplementary Note 1 and Supplementary Figs. 1-5)** . Since TOPO and DOPA are weakly binding ligands for LHP QDs<sup>40,41</sup> , they were displaced with lecithin as a strongly binding zwitterionic ligand<sup>42</sup> for subsequent isolation and purification steps, as well as _ex-situ_ characterization (see detailed comparison of _in-situ_ and _ex-situ_ data analysis, as well as the _in-situ_ set up in **Extended Data Fig.1** , **Supplementary Note 1.2 and Supplementary Figs. 6-12** ). _In-situ_ recorded absorption spectra ( **Supplementary Video 1,** 6 nm CsPbBr3 QDs) exemplify the slow growth lasting for 30 minutes and narrow size-dispersion seen as sharp excitonic absorption peaks. Purified lecithin-coated QDs exhibit the same sharp absorption features when measured _ex-situ_ and can be prepared in a size range from 3-13 nm ( **Fig.1d and Supplementary Fig. 13** ). _In-situ_ synchrotron SAXS measurement (6.2 nm QDs, **Fig. 1e** ) yielded narrow size-dispersion (8.1%) and rather isotropic spheroidal shape. The latter is in stark contrast to previous _ex-situ_ SAXS measurements on cuboidal shaped CsPbBr3 QDs, where on average a 20% offset between the shortest and longest edge length of the cuboid was reported<sup>34,42</sup> . The findings hold also for 12 nm-large QDs ( **Supplementary Fig. 14** ). TEM and scanning TEM (STEM) images of purified 8 nm QDs ( **Fig. 1f and Supplementary Figs. 15-16)** showing tendency to hexagonal packing, indicating spheroidal QDs, rather than the commonly observed nanocubes.<sup>1,9,34,36,37</sup> . High-resolution STEM (HR-STEM) of 12 nm QDs evidences truncation along the {110} and {111} facets, hence rhombicuboctahedral shape of QDs ( **Extended Data Fig.2** ), in good-agreement with the spheroidal shape in _in-situ_ SAXS. CsPbBr3 QDs crystallize in a phase-pure orthorhombic phase as seen from _in-situ_ WAXS of crude solutions as well as 

5 

powder X-ray diffraction (XRD, **Fig. 1g** ). CsPb(Cl:Br)3 QDs, which exhibit larger bandgaps compared to CsPbBr3, and therefore of interest for blue LEDs, could also be obtained using this method by applying an _in-situ_ anion exchange<sup>43,44</sup> , using ZnCl2-TOPO solution added dropwise before lecithin ligand.  Here, the sharp excitonic features ( **Extended Data Fig. 3a and b** ) and narrow size-dispersion and spheroidal shape 

( **Extended Data Fig. 3c, d and Supplementary Fig. 17** ), were fully preserved. 

_In-situ_ optical measurements allow for thorough and fast parametric screening **.** The overall dilution and the concentration of the TOPO ligands were found most effective for controlling the QD size in our room-temperature synthesis, contrary to conventional size control by varying the reaction temperature<sup>1,34,36,42,45,46</sup> . For instance, dilution of the reaction by an order of magnitude leads to a decrease in size from 9 nm to 3 nm ( **Fig. 1h, i and Extended Data Fig. 4a** ). Similar effects come from adjusting concentrations of PbBr2 or Cs-DOPA precursors individually ( **Supplementary Note 1.1 and Supplementary Figs. 1-4** ). Alternatively, a four-fold raise in TOPO concentration translates in the QD size increase from _ca_ . 3 to 9 nm ( **Fig. 1j, k and Extended Data Fig. 4b** ). A combined effect of dilution and larger TOPO concentration translates into drastically slower QD growth ( **Fig. 1l, Supplementary Fig. 18 and Supplementary Video 2** ). 

6 





**Fig. 1 | Room-temperature, controlled-rate synthesis of monodisperse CsPbBr3 QDs. a,** A reaction scheme and overview of _in-situ_ monitoring techniques. **b,** Overview of used _ex-situ_ techniques on ligand exchanged and washed QDs which are complementary with the used _in-situ_ techniques. **c,** Example of _insitu_ recorded absorption spectra of 6 nm QD during 30 min reaction with solid line being the final recorded absorption spectrum, demonstrating clear and sharp first and higher order absorption peaks. **d,** Absorption spectra of series of washed CsPbBr3 QDs ranging from roughly 3 to 13 nm. **e,** SAXS scattering curve of 6 nm QD recorded at the end of a reaction, resulting in a size dispersion of roughly 8%, and a fitted pseudo spherical shape with one axis being slightly shorter compared to the other two. **f,** STEM image of washed 7.8 nm QDs and HRSTEM image of a single QD showing the pseudo spherical shape due to truncation. **g,** Diffractograms of 6.2 nm QD recorded both _in-situ_ in a crude solution using WAXS as well as from a washed dispersion using XRD on a film, both exhibiting a match with the orthorhombic crystal structure of CsPbBr3. **h,** _in-situ_ recorded size of CsPbBr3 QDs at various concentrations (concentration of Cs-DOPA) showing both the decrease in size and reaction speed upon dilution. **i,** Respective final absorption spectra of reactions shown in panel h, indicating all final samples are highly monodisperse. **j,** _in-situ_ recorded size of CsPbBr3 QDs at various PbBr2:TOPO ratios (with a fixed PbBr2 concentration) showing the increase in size with increasing TOPO concentration, whilst the reaction speed remains relatively unchanged. **k,** Respective final absorption spectra of reactions shown in panel c, indicating all final samples are highly monodisperse. **l,** Comparison of reaction speeds of three different reactions resulting in roughly the same QDs size, 

7 

showing how controlling both the overall dilution and the TOPO concentration can slow down the reaction by two orders of magnitude. 

## **Spheroidal vs cuboidal QDs.** 

Next, we elucidated the origin of the exceptionally well-resolved excitonic transitions in the spheroidal QDs, as compared to conventional cuboidal NCs studied since 2015<sup>1</sup> . The difference cannot be merely attributed to the size-dispersion. For instance, **Fig. 2a and b** compare our spheroidal CsPbBr3 QDs with several own examples of cuboidal CsPbBr3 QDs with same or better size-dispersion ( **Supplementary Fig. 19** ). The latter include NCs capped with didodecyldimethylammonium bromide (DDAB) or OLAM/OA as used recently for NC superlattices<sup>9</sup> , as well as those capped with long-chain sulfobetaine zwitterionic ligands (3-(N,N-dimethyloctadecylammonio)propanesulfonate, ASC18) after size-selective precipitation<sup>47</sup> . Similarity of PL FWHM across these different shapes also evidences that the inhomogeneous broadening is not the cause for the "blurred" higher order absorption transitions in cuboidal QDs either. We thus turned to analyze the effect of the shape itself by computing a one-photon absorption cross-section ( **Fig. 2c, 2d and Supplementary Fig. 20** ). For this, the effective mass Approximation (EMA) was employed with the use of the energy-dependent effective mass to emulate the effect of full two-band coupling<sup>48</sup> . Beyond this, the electron-hole Coulomb interaction was included in a single-shot calculation ( _i.e_ . without self-consistency iteration, see details in **Supplementary note 2** ) **.** Compared to a perfect sphere, the cubic symmetry introduces perturbation that couples the spherical states of different angular momenta. This coupling leads to mixing between and splitting of the higher order absorption states, which results in the smoothing out of the absorption spectra, as observed experimentally. Furthermore, recent SAXS studies on cuboidal CsPbBr3 NCs revealed up to 20% reduction in length along one of the cuboid edges (oblation), which further contributes to the splitting of higher order absorption states<sup>34,42</sup> . Particularly, going from the spherical shape to such an oblate cuboidal shape leads to the nearly complete flatting of the second and third absorption transitions. 

8 



**Fig. 2 | The effect of QD shape on the absorption spectral features. a-b,** Experimental absorption and PL spectra of 5 nm and 9 nm cuboidal and spheroidal QDs. Monodisperse cuboidal QDs coated with DDAB<sup>9</sup> , OLAM/OA<sup>9</sup> , ACS18<sup>34</sup> . **c-d,** Calculated absorption spectra of both 5 and 9 nm QDs with different shapes using the effective mass approximation (EMA) with the inclusion of electron-hole Coulomb interaction in a single-shot calculation. For the cuboidal QD, an oblate shape was chosen with 20% shortening along one of the cube's edge (parameter b = 1.2). 

## **Reaction mechanism.** 

We used _in-situ_ optical absorption spectra to shed light onto the underlying chemical reactions and test reasoning on using solely neutral coordinating agent (TOPO) to prevent premature and uncontrolled conversion of PbBr2 into the PbBr3<sup>-</sup> solute. PbBr2 dissolves in TOPO forming a PbBr2[TOPO] complex<sup>40</sup> that has a broad absorption peak around 4.4 eV ( **Fig. 3a** ), and its intensity change allows for monitoring the depletion of PbBr2 during the reaction. Only upon the injection of Cs-DOPA, does the PbBr3<sup>-</sup> appear on the course of 100 ms, evidenced as an additional peak emerging at lower energies (3.85 eV) ( **Supplementary Fig. 21** ), owing to the formation of a PbBr3<sup>-</sup> complex<sup>39,49</sup> .Once the accumulation of PbBr3<sup>-</sup> surpasses a nucleation threshold (supersaturation), CsPbBr3 QDs form (on the order of seconds, **Fig. 3b** ). Whereas more conventional ligands for CsPbBr3 QDs, such as OA or OLAM, react with the PbBr2[TOPO] complex<sup>40</sup> , free DOPA on its own does not  ( **Supplementary Fig. 22)** . As the only counter-ion available to PbBr3<sup>-</sup> is 

9 

Cs<sup>+</sup> , we assume the formation of a Cs[PbBr3] complex (tight ionic pair) as the concentration of PbBr3<sup>-</sup> species scales with Cs-DOPA concentration ( **Supplementary Fig. 23a** ). A Cs[PbBr3] complex might be additionally coordinated by TOPO.  Importantly, a higher TOPO concentration suppresses the formation of Cs[PbBr3], indicating that its formation is in equilibrium ( **Supplementary Fig. 23b)** with more stable PbBr2[TOPO] species. Particularly, an injection of additional TOPO after the initial Cs-DOPA injection decomposes Cs[PbBr3] complex back into PbBr2 species **(Supplementary Fig. 24)** . 

An overall precursor-to-QDs path is depicted in **Fig. 3c** . We illustrate the effect of TOPO-driven PbBr2:Cs[PbBr3] equilibrium on the formation of CsPbBr3 QDs for a stoichiometric PbBr2:Cs-DOPA = 3:2 reaction by plotting _in-situ_ monitored PbBr2, Cs[PbBr3] and CsPbBr3 concentrations ( **Fig. 3d** ) **.** An immediate decrease of PbBr2 concentration upon injection of Cs-DOPA is accompanied by the formation of Cs[PbBr3]. As the reaction progresses, Cs[PbBr3] complexes are converted into CsPbBr3 QDs nuclei, and both PbBr2 and Cs[PbBr3] species are proportionally consumed, but remain present, in line with the PbBr2:Cs[PbBr3] equilibrium. The stoichiometric conversion 3PbBr2  2PbBr3<sup>-</sup> + Pb<sup>2+</sup> is confirmed by subtracting Cs[PbBr3] and CsPbBr3 concentrations yielding the PbDOPA2 concentration. The reaction is eventually reaching a close to 100% yield **(Supplementary Fig. 25)** . The rate-limiting step in this reaction is the conversion of the Cs[PbBr3] intermediate into CsPbBr3. A reaction with a four-fold excess of PbBr2 compared to Cs-DOPA ( **Supplementary Fig. 26** ) shows that the Cs[PbBr3] complex solely acts as an intermediate for the CsPbBr3 QDs and is not stable on its own. The PbBr2:Cs[PbBr3] equilibrium self-limits the available amount Cs[PbBr3] for both the nucleation, as well as the subsequent growth of CsPbBr3 QDs. The separation of nucleation and growth – a prerequisite for the narrow size dispersion - can be seen by comparing the QD concentration vs. the CsPbBr3 molar concentration evolution ( **Fig. 3e and SI video 3** ). The self-limiting equilibrium mechanism also explains the larger QD size and lower reaction speed with increasing TOPO concentration. The equilibrium shifts towards PbBr2, reducing the available quantity of Cs[PbBr3] for the nucleation and hence decreasing the number of nuclei (and the final QD concentration, **Fig. 3f),** whilst the overall yield remains relatively unchanged **(Supplementary Fig. 27)** . For instance, a four-fold increase in TOPO concentration translates into the size increase from 3.5 to 8.7 nm, corresponding to a 14-fold increase in QD volume. The QD concentration correspondingly drops 15 times. Additional experiments confirming the self-limiting equilibrium mechanism are described in **Supplementary note 3** . 

10 



**Fig. 3 | In-situ observation of the precursors-to-CsPbBr3 QDs conversion. a,** PbBr2-TOPO solution before and within 5 seconds after the injection of Cs-DOPA. **b,c** Typical evolution of the absorption spectra from PbBr2 through Cs[PbBr3] monomer and CsPbBr3 QDs and the corresponding reaction path. **d,** Temporal evolution of precursors' and reaction products' concentrations for a stochiometric reaction (2:3 Cs-DOPA:PbBr2), wherein both the PbBr2 precursor and the Cs[PbBr]3 intermediate are consumed upon the formation of CsPbBr3 QDs. PbBr2 and Cs[PbBr]3 exist in equilibrium, as both are present until PbBr2 is consumed. **e,** Effective separation of nucleation and growth, as well as absence of QD coalescence or Ostwald ripening is apparent from the QD concentration evolution and the respective reaction yield. **f,** QD concentration vs. time dependence at different TOPO concentrations. Higher TOPO quantities suppress the available Cs[PbBr3] monomer and hence the number of nuclei. 

## **Optical properties of CsPbBr3 QDs.** 

Contrasting the many investigations of higher-order excitonic transitions and their size- and shapedependencies in CdSe and PbS QDs<sup>50,51</sup> , the assignment of corresponding datasets for CsPbBr3 QDs remains very limited as, typically, only the lowest two transitions (1s-1s and 1p-1p) are reported<sup>34,52</sup> . In the present study, the first four excitonic transitions are readily resolved both _in-situ_ (see **Fig. 4a and Supplementary Video 4** as well as **Extended Data Fig. 5** for various final QD sizes) and _ex-situ_ linear absorption spectra ( **Fig. 4b** ). Size dependencies captured by 25'000 _in-situ_ experimental spectra recorded for 2.5-11 nm QDs ( **Fig. 4c** exemplifies) are retained also in the purified QDs ( **Fig. 4d** ). To assign the absorption features, the specific excitonic transitions were calculated using a two-band 𝑘. 𝑝 model<sup>34,52</sup> . The 

11 

Coulomb interaction was included under the self-consistent  Hartree-Fock approximation. More details on the theoretical formalism are discussed in the **Supplementary Note 2** . For the 1s-1s, 1p-1p, 1d-1d and 1f1f transitions, we find a good agreement of the theoretical and experimental transition energies, plotted relative to the first excited state (1s-1s) as a function of their first excited state energies ( **Fig. 4f** )<sup>50</sup> . The spheroidal CsPbBr3 QDs optically behave as confined model systems with symmetrical electron and hole manifolds, owing to their approximately equal effective masses. The theoretical absorption spectrum is then obtained from calculations of the oscillator strength for all allowed transitions using second-order manybody perturbation theory, which allows partial incorporation of correlation effects in the electron-photon interaction<sup>48,53</sup> . Each transition was broadened with a normalized Voigt line-shape and the results for all transitions were added to obtain the final absorption spectra shown, for instance, for 7.0 nm ( **Fig. 4g and Extended Data Fig. 5** ) **.** This model was further extended for a broad range of temperatures between 14 K and 300 K, as shown in **Extended Data Fig. 6** . More discussion on the broadening mechanisms is found in **Supplementary Note 4** and **Supplementary Fig. 28** . The calculated low-temperature absorption spectrum was compared to the PL excitation (PLE) spectrum at 14 K ( **Fig. 4h** ). Whereas only one 1p-1p state transition is expected and observed at room-temperature, the narrowing of the absorption features upon cooling to 14 K reveals two 1p-1p contributions, separated by _ca_ . 70 meV. This splitting is observed in temperature-dependent absorption spectra for various QD sizes ( **Extended Data Fig. 7b and 7c** ) and was previously ascribed to the shape-asymmetry in cuboidal QDs (oblation in one direction)<sup>34,52</sup> . A likewise observation in isotropic spheroidal QDs calls for other considerations such as anisotropies of the effective mass of electrons or holes, stemming from the orthorhombic crystal structure of the CsPbBr3<sup>54,55</sup> . Such anisotropic effects were already inferred from electrical characteristics<sup>56</sup> . Inclusion of 10-15% of anisotropy in the electron hole mass gives rise to the experimentally found splitting of the 1p-1p transition of the magnitude found experimentally **(Extended Data Fig. 8 and Supplementary Fig. 29 and 30** ). The splitting of the 1p states potentially experiences a fairly complex dependence on the QD size and temperature; see further discussion in **Supplementary Note 5** . 

Simultaneous _in-situ_ acquisition of both absorption and PL spectra allowed us to study the inherent sizedependent Stokes shift ( **Extended Data Fig. 1 and Supporting Videos 1 and 5)** with excellent energy accuracy (standard deviation of only about 2% in the range of 4-10 nm **, Extended Data Fig. 9,** 

12 

**Supplementary Fig. 31** ). The measured Stokes shift agrees with recent calculations that assume an intrinsic confined hole state with size-dependent alignment above the valence band maximum<sup>57</sup> . 





**Fig. 4 | Excitonic transitions in CsPbBr3 QDs seen with** **_in- and ex-situ_ spectroscopy corroborated with theoretical calculations. a,** Typical second derivative of the absorption during the growth of CsPbBr3 QDs, featuring up to four transitions that can be extracted using a peak finding algorithm. **b,** Second derivative absorption spectra for purified QDs. **c,** A compilation of the extracted _in-situ_ transition energy values across several syntheses (n ~ 25000 individual absorption spectra). **d,** Similar data set obtained _exsitu_ from 15 different QD sizes. **e** , Energy level diagram used for the two-band _k.p_ theory with Hartree-Fock level description of the Coulomb interaction<sup>48,53</sup> . **f,** Comparison of experimental relative absorption transitions and theoretical calculated states. **g** , Theoretical absorption spectrum in which the electronphoton interaction is considered within the framework of second-order many-body perturbation theory with the corresponding peak assignment. **h** , 14 K PLE spectra revealing splitting of the 1p-1ptransition due to slight anisotropy in effective masses. 

## **Extension to FAPbBr3 and MAPbBr3 QDs.** 

We then sought to extend the synthesis methodology to hybrid small organic-inorganic LHP QDs ( **Fig. 5** ). FAPbBr3 QDs were synthesized by replacing Cs2CO3 with FA-acetate and DOPA with a mixture of DOPA and OA. FAPbBr3 QDs were observed to form an order of magnitude faster compared to CsPbBr3 QDs (minute-scale, see **Fig. 5a** for _in-situ_ absorption in the synthesis of 7 nm FAPbBr3 QDs). Analogous experiments with MA-acetate gave ~~rise~~ to a size-series of monodisperse MAPbBr3 NCs, albeit with further 

13 

reduction of the synthesis time to _ca_ . 10s **(Fig. 5e).** Such a pronounced effect of the A-site cation on the reaction rate agrees with the proposed reaction mechanism ( **Fig. 3c** ), wherein coordination of A-cation to 



**Fig. 5 | Monodisperse FAPbBr3 and MAPbBr3 QDs and comparison with CsPbBr3 QDs. a,e** _In-situ_ spectra during the formation of 7-nm QDs. **b,f** Absorption spectra of isolated series. **c,g** STEM images of _ca_ . 7 nm QDs. **d,h** _In-situ, ex-situ_ and calculated excitonic transition energies plotted with respect to their first excitonic transition energy.. **i,** Absorption spectra of ca. 7-nm CsPbBr3, FAPbBr3 and MAPbBr3 QDs with matched at the 1s-1s transition energy. **j,** Experimental size-dependent relative peak position of CsPbBr3, FAPbBr3 and MAPbBr3 QDs. 

14 

PbBr3<sup>-</sup> was hypothesized to govern the stability and hence reactivity of these transient species. Size series of 6-11 nm lecithin-capped FAPbBr3 and MAPbBr3 QDs ( **Fig. 5b and 5f** ), which are found to be quasispherical in shape ( **Fig. 5c and 5g** ), are analogous to CsPbBr3 QDs. These hybrid LHP NCs feature narrow size dispersion of under 10% and well-resolved, machine-readable excitonic peaks in both in-situ and _exsitu_ measurements (see **Fig 5d and 5h** ). See further examples in **Extended Data Fig. 10a and b** and additional TEM images in **in Supplementary Fig. 32.** Notably, the faster formation kinetics does not jeopardize the utility of the synthesis, as the QD size control is accomplished at a full reaction yield by adjusting the concentrations, not growth time. 

We then sought to compare all three LHP homologues as they feature an analogous Pb-halide octahedral framework. As illustrated in **Fig. 5i,** the 7-nm CsPbBr3, FAPbBr3 and MAPbBr3 QDs exhibit nearly identical absorption spectra, when matching the positions of their first excitonic transition. Moreover, across the experimental and theoretical size-series, all three materials exhibit the same effect of quantum-confinement on higher-order excitonic transitions ( **Fig. 5j and Supplementary Fig. 33** ). 

In sum, we have introduced a synthesis methodology that (i) can conveniently handle the precursormonomer equilibrium and hence the formation kinetics of small LHP QDs at room temperature, inherently separating the nucleation and growth, and (ii) yields scalable quantities of such QDs at full reaction yield. The slower overall reaction rate allows for convenient _in-situ_ optical parametric screening and, in future, also structural characterization. This work provides avenues for studying strongly quantum confined LHP QDs with inherently conspicuous excitonic features. 

## **References** 

1. Protesescu, L. _et al._ Nanocrystals of Cesium Lead Halide Perovskites (CsPbX3, X = Cl, Br, and I): Novel Optoelectronic Materials Showing Bright Emission with Wide Color Gamut. _Nano Lett._ **15** , 3692-3696 (2015). 

2. Zhang, F. _et al._ Brightly Luminescent and Color-Tunable Colloidal CH3NH3PbX3 (X = Br, I, Cl) Quantum Dots: Potential Alternatives for Display Technology. _ACS Nano_ **9** , 4533-4542 (2015). 

3. Protesescu, L. _et al._ Monodisperse Formamidinium Lead Bromide Nanocrystals with Bright and Stable Green Photoluminescence. _J. Am. Chem. Soc._ **138** , 14202-14205 (2016). 

4. Kovalenko, M. V., Protesescu, L. & Bodnarchuk, M. I. Properties and Potential Optoelectronic Applications of Lead Halide Perovskite Nanocrystals. _Science_ **358** , 745-750 (2017). 

5. Akkerman, Q. A., Rainò, G., Kovalenko, M. V. & Manna, L. Genesis, Challenges and Opportunities for Colloidal Lead Halide Perovskite Nanocrystals. _Nat. Mater._ **17** , 394-405 (2018). 

6. Dey, A. _et al._ State of the Art and Prospects for Halide Perovskite Nanocrystals. _ACS Nano_ **15** , 10775-10981 (2021). 

15 

7. Tamarat, P. _et al._ The Ground Exciton State of Formamidinium Lead Bromide Perovskite Nanocrystals Is a Singlet Dark State. _Nat. Mater._ **18** , 717-724 (2019). 

8. Park, Y.-S., Guo, S., Makarov, N. S. & Klimov, V. I. Room Temperature Single-Photon Emission from Individual Perovskite Quantum Dots. _ACS Nano_ **9** , 10386-10393 (2015). 

9. Cherniukh, I. _et al._ Perovskite-Type Superlattices from Lead Halide Perovskite Nanocubes. _Nature_ **593** , 535-542 (2021). 

10. Dong, Y. _et al._ Bipolar-Shell Resurfacing for Blue LEDs Based on Strongly Confined Perovskite Quantum Dots. _Nat. Nanotechnol._ **15** , 668-674 (2020). 

11. Kim, Y.-H. _et al._ Comprehensive Defect Suppression in Perovskite Nanocrystals for HighEfficiency Light-Emitting Diodes. _Nat. Photonics_ **15** , 148-155 (2021). 

12. Hassan, Y. _et al._ Ligand-Engineered Bandgap Stability in Mixed-Halide Perovskite LEDs. _Nature_ **591** , 72-77 (2021). 

13. Wang, Y.-K. _et al._ All-Inorganic Quantum-Dot LEDs Based on a Phase-Stabilized α-CsPbI3 Perovskite. _Angew. Chem. Int._ **60** , 16164-16170 (2021). 

14. Yoon, H. C. _et al._ Highly Efficient Wide-Color-Gamut QD-Emissive LCDs Using Red and Green Perovskite Core/Shell QDs. _J. Mater. Chem. C_ **6** , 13023-13033 (2018). 

15. Ko, Y.-H., Jalalah, M., Lee, S.-J. & Park, J.-G. Super Ultra-High Resolution Liquid-Crystal-Display Using Perovskite Quantum-Dot Functional Color-Filters. _Sci. Rep._ **8** , 12881 (2018). 

16. He, Z., Zhang, C., Dong, Y. & Wu, S.-T. Emerging Perovskite Nanocrystals-Enhanced Solid-State Lighting and Liquid-Crystal Displays. _Cryst._ **9** , 59 (2019). 

17. Su, R. _et al._ Room-Temperature Polariton Lasing in All-Inorganic Perovskite Nanoplatelets. _Nano Lett._ **17** , 3982-3988 (2017). 

18. Schlaus, A. P. _et al._ How Lasing Happens in CsPbBr3 Perovskite Nanowires. _Nat. Commun._ **10** , 265 (2019). 

19. Li, S. _et al._ Water-Resistant Perovskite Nanodots Enable Robust Two-Photon Lasing in Aqueous Environment. _Nat. Commun._ **11** , 1192 (2020). 

20. Zhang, Q. _et al._ Halide Perovskite Semiconductor Lasers: Materials, Cavity Design, and Low Threshold. _Nano Lett._ **21** , 1903-1914 (2021). 

21. Chen, Q. _et al._ All-Inorganic Perovskite Nanocrystal Scintillators. _Nature_ **561** , 88-93 (2018). 22. Gandini, M. _et al._ Efficient, Fast and Reabsorption-Free Perovskite Nanocrystal-Based Sensitized Plastic Scintillators. _Nat. Nanotechnol._ **15** , 462-468 (2020). 

23. Meinardi, F. _et al._ Doped Halide Perovskite Nanocrystals for Reabsorption-Free Luminescent Solar Concentrators. _ACS Energy Lett._ **2** , 2368-2377 (2017). 

24. Wei, M. _et al._ Ultrafast Narrowband Exciton Routing within Layered Perovskite Nanoplatelets Enables Low-Loss Luminescent Solar Concentrators. _Nat. Energy_ **4** , 197-205 (2019). 

25. Wu, J. _et al._ Efficient and Stable Thin-Film Luminescent Solar Concentrators Enabled by nearInfrared Emission Perovskite Nanocrystals. _Angew. Chem. Int._ **59** , 7738-7742 (2020). 

26. Chen, W. _et al._ Giant Five-Photon Absorption from Multidimensional Core-Shell Halide Perovskite Colloidal Nanocrystals. _Nat. Commun._ **8** , 15198 (2017). 

27. Becker, M. A. _et al._ Long Exciton Dephasing Time and Coherent Phonon Coupling in CsPbBr2Cl Perovskite Nanocrystals. _Nano Lett._ **18** , 7546-7551 (2018). 

28. Rainò, G. _et al._ Single Cesium Lead Halide Perovskite Nanocrystals at Low Temperature: Fast Single-Photon Emission, Reduced Blinking, and Exciton Fine Structure. _ACS Nano_ **10** , 24852490 (2016). 

29. Utzat, H. _et al._ Coherent Single-Photon Emission from Colloidal Lead Halide Perovskite Quantum Dots. _Science_ **363** , eaau7392 (2019). 

30. Yin, C. _et al._ Bright-Exciton Fine-Structure Splittings in Single Perovskite Nanocrystals. _Phys. Rev. Lett._ **119** , 026401 (2017). 

31. Cho, K. _et al._ Luminescence Fine Structures in Single Lead Halide Perovskite Nanocrystals: Size Dependence of the Exciton–Phonon Coupling. _Nano Lett._ **21** , 7206-7212 (2021). 

32. Rainò, G. _et al._ Superfluorescence from Lead Halide Perovskite Quantum Dot Superlattices. _Nature_ **563** , 671-675 (2018). 

33. Mattiotti, F. _et al._ Thermal Decoherence of Superradiance in Lead Halide Perovskite Nanocrystal Superlattices. _Nano Lett._ **20** , 7382-7388 (2020). 

34. Krieg, F. _et al._ Monodisperse Long-Chain Sulfobetaine-Capped CsPbBr3 Nanocrystals and Their Superfluorescent Assemblies. _ACS Cent. Sci._ **7** , 135-144 (2021). 

16 

35. De Roo, J. _et al._ Highly Dynamic Ligand Binding and Light Absorption Coefficient of Cesium Lead Bromide Perovskite Nanocrystals. _ACS Nano_ **10** , 2071-2081 (2016). 

36. Dong, Y. _et al._ Precise Control of Quantum Confinement in Cesium Lead Halide Perovskite Quantum Dots Via Thermodynamic Equilibrium. _Nano Lett._ **18** , 3716-3722 (2018). 

37. Imran, M. _et al._ Shape-Pure, Nearly Monodispersed CsPbBr3 Nanocubes Prepared Using Secondary Aliphatic Amines. _Nano Lett._ **18** , 7822-7831 (2018). 

38. Almeida, G. _et al._ Role of Acid–Base Equilibria in the Size, Shape, and Phase Control of Cesium Lead Bromide Nanocrystals. _ACS Nano_ **12** , 1704-1711 (2018). 

39. Hui, J. _et al._ Unveiling the Two-Step Formation Pathway of Cs4PbBr6 Nanocrystals. _Chem. Mater._ **32** , 4574-4583 (2020). 

40. Almeida, G. _et al._ The Phosphine Oxide Route toward Lead Halide Perovskite Nanocrystals. _J. Am. Chem. Soc._ **140** , 14878-14886 (2018). 

41. Shynkarenko, Y. _et al._ Direct Synthesis of Quaternary Alkylammonium-Capped Perovskite Nanocrystals for Efficient Blue and Green Light-Emitting Diodes. _ACS Energy Lett._ **4** , 2703-2711 (2019). 

42. Krieg, F. _et al._ Stable Ultraconcentrated and Ultradilute Colloids of CsPbX3 (X = Cl, Br) Nanocrystals Using Natural Lecithin as a Capping Ligand. _J. Am. Chem. Soc._ **141** , 19839-19849 (2019). 

43. Akkerman, Q. A. _et al._ Tuning the Optical Properties of Cesium Lead Halide Perovskite Nanocrystals by Anion Exchange Reactions. _J. Am. Chem. Soc._ **137** , 10276-10281 (2015). 

44. Nedelcu, G. _et al._ Fast Anion-Exchange in Highly Luminescent Nanocrystals of Cesium Lead Halide Perovskites (Cspbx3ls, X = Cl, Br, I). _Nano Lett._ **15** , 5635-5640 (2015). 

45. Imran, M. _et al._ Benzoyl Halides as Alternative Precursors for the Colloidal Synthesis of LeadBased Halide Perovskite Nanocrystals. _J. Am. Chem. Soc._ **140** , 2656-2664 (2018). 

46. Zhang, B. _et al._ Stable and Size Tunable CsPbBr3 Nanocrystals Synthesized with Oleylphosphonic Acid. _Nano Lett._ **20** , 8847-8853 (2020). 

47. Krieg, F. _et al._ Colloidal CsPbX3 (X = Cl, Br, I) Nanocrystals 2.0: Zwitterionic Capping Ligands for Improved Durability and Stability. _ACS Energy Lett._ **3** , 641-646 (2018). 

48. Sercel, P. C., Lyons, J. L., Bernstein, N. & Efros, A. L. Quasicubic Model for Metal Halide Perovskite Nanocrystals. _J. Chem. Phys._ **151** , 234106 (2019). 

49. Yoon, S. J., Stamplecoskie, K. G. & Kamat, P. V. How Lead Halide Complex Chemistry Dictates the Composition of Mixed Halide Perovskites. _J. Phys. Chem. Lett._ **7** , 1368-1373 (2016). 

50. Norris, D. J. & Bawendi, M. G. Measurement and Assignment of the Size-Dependent Optical Spectrum in CdSe Quantum Dots. _Phys. Rev. B_ **53** , 16338-16346 (1996). 

51. Andreev, A. D. & Lipovskii, A. A. Anisotropy-Induced Optical Transitions in PbSe and PbS Spherical Quantum Dots. _Phys. Rev. B_ **59** , 15402-15404 (1999). 

52. Shcherbakov-Wu, W. _et al._ Temperature-Independent Dielectric Constant in CsPbBr3 Nanocrystals Revealed by Linear Absorption Spectroscopy. _J. Phys. Chem. Lett._ **12** , 8088-8095 (2021). 

53. Nguyen, T. P. T., Blundell, S. A. & Guet, C. One-Photon Absorption by Inorganic Perovskite Nanocrystals: A Theoretical Study. _Phys. Rev. B_ **101** , 195414 (2020). 

54. Sakuma, T. _et al._ Low-Energy Excitation in CsPbX3 (X=Cl, Br). _Solid State Ion._ **154-155** , 237-242 (2002). 

55. Traoré, B. _et al._ Efficient and Accurate Calculation of Band Gaps of Halide Perovskites with the Tran-Blaha Modified Becke-Johnson Potential. _Phys. Rev. B_ **99** , 035139 (2019). 

56. Zhang, P. _et al._ Anisotropic Optoelectronic Properties of Melt-Grown Bulk CsPbBr3 Single Crystal. _J. Phys. Chem. Lett._ **9** , 5040-5046 (2018). 

57. Brennan, M. C. _et al._ Origin of the Size-Dependent Stokes Shift in CsPbBr3 Perovskite Nanocrystals. _J. Am. Chem. Soc._ **139** , 12201-12208 (2017). 

58. Chao, L. _et al._ Room-Temperature Molten Salt for Facile Fabrication of Efficient and Stable Perovskite Solar Cells in Ambient Air. _Chem_ **5** , 995-1006 (2019). 

59. Maes, J. _et al._ Light Absorption Coefficient of CsPbBr3 Perovskite Nanocrystals. _J. Phys. Chem. Lett._ **9** , 3093-3097 (2018). 

60. Jones, L. _et al._ Smart Align—a New Tool for Robust Non-Rigid Registration of Scanning Microscope Data. _Adv. Struct. Chem. Imaging._ **1** , 8 (2015). 

17 

61. Shibata, K. _et al._ Exciton Localization and Enhancement of the Exciton–LO Phonon Interaction in a CsPbBr3 Single Crystal. _J. Phys. Chem. C_ **124** , 18257-18263 (2020). 

62. Ramade, J. _et al._ Exciton-Phonon Coupling in a CsPbBr3 Single Nanocrystal. _Appl. Phys. Lett._ **112** , 072104 (2018). 

63. Yang, Z. _et al._ Impact of the Halide Cage on the Electronic Properties of Fully Inorganic Cesium Lead Halide Perovskites. _ACS Energy Lett._ **2** , 1621-1627 (2017). 

64. Wang, X., Wang, Q., Chai, Z. & Wu, W. The Thermal Stability of FAPbBr3 Nanocrystals from Temperature-Dependent Photoluminescence and First-Principles Calculations. _RSC Adv._ **10** , 44373-44381 (2020). 

## **Methods** 

**Chemicals.** Lead(II) bromide (PbBr2, 99.999%), zinc chloride (ZnCl2, 98%), cesium carbonate (Cs2CO3, 99.9%), formamidinium acetate (99%), methylamine (33 wt% in ethanol), acetic acid (99.5%), hexane (≥99%), diisooctylphosphinic acid (DOPA, 90%), oleic acid (OA, 90%) and acetone (ACE, ≥99.5%) were purchased from Sigma Aldrich. n-Octane (min. 99%) and lecithin (>97% from soy) were purchased from Carl Roth. Trioctylphosphine oxide (TOPO, min. 90%) was purchased from Strem Chemicals. All chemicals were used as received. Methyl ammonium acetate was synthesized by reacting methylamine with acetic acid as described in Ref<sup>58</sup> . 

**Stock solutions.** PbBr2 stock solution (0.04 M), as well as ZnCl2 solution used for anion exchange, was prepared by dissolving PbBr2 or ZnCl2 (1 mmol) and TOPO (5 mmol) in octane (5 mL) at 120 ⁰C, followed by dilution with hexane (20 mL). The Cs-DOPA solution (0.02 M) was prepared by mixing Cs2CO3 (100 mg) with DOPA (1 mL) and octane (2 mL) at 120 ⁰C, followed by dilution with hexane (27 mL). The FA-DOPA stock solution (0.02 M) was prepared by was prepared by loading formamidinium acetate (64 mg), DOPA (3 mL), OA (3 mL) and octane (5 mL) at 120 ⁰C, followed by dilution with hexane (20 mL). This solution was diluted further five times prior to the synthesis. The MA-DOPA stock solutions was prepared analogously to FA-DOPA solution using methylammonium acetate. The lecithin stock solution (~0.13 M) was prepared by dissolving 0.5 gram of lecithin in hexane (10 mL). This solution was diluted 10 times in the case of FAPbBr3 and MAPbBr3 QDs. The TOPO stock solution (0.2 M) was prepared by dissolving TOPO (4 mmol) in hexane (20 mL). The DOPA stock solution was prepared by diluting DOPA 40 times in hexane. The ZnCl2 solutions used for anion solution was prepared in the same way as the PbBr2 solutions, with the replaced of PbBr2 with ZnCl2. All stock solutions were filtered through 0.2 µL PTFE filter prior to use. 

18 

**Synthesis of CsPbBr3, FAPbBr3 and MAPbBr3 QDs.** In an 8 ml vial, PbBr2 and TOPO stock solutions were combined along with additional hexane. Under vigorous stirring, a desired volume of Cs/MA/FA-DOPA stock solution was injected. Specific volumes of solutions are tabulated in Supplementary Tables 1 and 2 for all reactions presented in this work. 

**Ligand exchange and QD purification.** Once the spectral evolution is plateaued at a final bandgap value, a stock solution of lecithin is added (the volume being equivalent to the A-cation stock solution used in the respective QD synthesis). After half a minute, a _ca_ . 3-fold excess of an antisolvent (acetone for CsPbBr3; ethyl acetate:acetonitrile 2:1 for FAPbBr3, and MAPbBr3) was added and the QDs were isolated by centrifuging at 19970 g for 2 minutes and redispersed in hexane. 

**_In-situ_ absorption and photoluminescence (PL) setup.** The reactions were carried out in a modified Thorlabs CVH100 cuvette holder. The absorption spectra were recorded with an Ocean Optics deuteriumtungsten light source (DH-2000-BAL-TTL-24V) and a Thorlabs CCS200/M spectrometer. For collecting PL spectra, a bifurcated optical fiber was used in a front-face configuration, minimizing the PL reabsorption. PL was excited with a Convoy 53 UV flashlight and recorded with a Thorlabs CCS200/M spectrometer. The time resolution in these measurements was set to 50 µs. 

**_In-situ_ absorption in the UV range.** For the higher-energy absorption studies (precursor formation and higher-order absorption transitions), covering both the UV range down to 200 nm, the reaction was carried out in a Jasco V670 spectrometer using a 2MAG cuvetteMIXdrive 1 cuvette stirring plate equipped with a cuvette magnetic stirrer This allowed for a time resolution of about 20 seconds per spectrum. 

**_Ex-situ_ absorption and photoluminescence (PL) spectroscopy.** Room-temperature PL spectra of purified QDs were recorded with a Fluorolog iHR 320 Horiba Jobin Yvon with an excitation at 350 nm. Absorption spectra were recorded on a Jasco V670 spectrometer. 

**Low-temperature PLE and absorption setup.** PLE spectra were acquired with a Picoquant FluoTime300 fluorescence spectrometer equipped with a Xe lamp for excitation and a photomultiplier tube for detection. Monochromators, in both the excitation and detection path, serve to select and scan the excitation and emission wavelength. An ARS closed-cycle He cryostat in combination with a Lakeshore temperature controller were employed to control the sample temperature. The QD samples were spin-coated as thin films on Si/SiO2 substrates and measured in vacuum. PLE spectra were recorded for an emission 

19 

wavelength set to 35 meV with respect to the PL peak; qualitatively similar spectra were observed also when the emission wavelength was set to the PL peak. The low-temperature absorption was recorded in the same cryostat system, but with an Ocean Optics deuterium-tungsten lamp (DH-2000-BAL-TTL-24V) as white light source and a Thorlabs CCS200/M spectrometer as detector. 

**Data analysis and fitting.** Custom-developed batch analysis scripts (written in Python) were employed. Here, the low-energy portion of both the absorption and PL spectra were fitted with a partial Gaussian to extract the first absorption and PL peak positions. The first absorption peak position was used to calculate the size<sup>34</sup> . The molar concentration of CsPbBr3 was calculated from the absorbance at 3.1 eV<sup>59</sup> . The precursor concentrations were calculated by fitting the absorption data with Gaussians at 4.4 eV (PbBr2) and 3.85 eV (PbBr3<sup>-</sup> ) after a CsPbBr3 background subtraction. The concentration of Pb(DOPA)2 was determined by subtracting the PbBr2, PbBr3<sup>-</sup> and CsPbBr3 concentration from the starting PbBr2 concentration. The higher-order absorption transitions were determined via a peak finding function on the negative second derivative of the absorption spectra. Further details are given in the Supplementary note 1.2. 

**Small and wide-angle X-ray scattering (SAXS/WAXS) measurements.** The SAXS/WAXS experiment was performed at beamline P21.2 at Petra III (DESY) synchrotron in Hamburg. X-ray photon energies of 37.5 keV (0.0331 nm) with VAREX XRD4343CT detector and a sample-to-detector distance of 1.5 m (for WAXS) and 15 m (SAXS) were employed. These distances allowed us to probe a q-range between 16 nm<sup>-</sup> 1 and 58 nm-1 for the WAXS and between 0.15 nm-1 and 2.2 nm-1 for the SAXS. The q-range and the scattering intensity were calibrated with LaF6, while absolute intensities were obtained by calibrating with glassy carbon. 

**Transmission electron microscopy measurements (TEM).** TEM images were obtained using a JEOL JEM-1400 Plus microscope operating at 120 kV. Bright-field and dark-field scanning TEM (STEM) imaging was performed on a JEOL JEM2200FS microscope equipped with a Schottky field emission electron gun. High-angle annular dark-field scanning TEM (HAADF-STEM) images were collected at cryo-conditions (holder cooled with liquid nitrogen) on an aberration-corrected HD2700CS (Hitachi) operated at 200 kV with a point resolution of ca. 1 Å. HR ADF-STEM was carried out using a probe-aberration-corrected FEI Titan Themis operated at 300 kV employing a beam semi-convergence angle of 18 mrad and a beam current of 

20 

1 pA. Under the high-resolution acquisition conditions used, the dose per frame was about 50 electrons/Å<sup>2</sup> . Series of images of each particle were recorded and 8-10 frames were averaged for noise-reduction, warranting that the nanoparticles remained unchanged in the averaged frames. The frames were aligned using the non-rigid algorithm as implemented in SmartAlign<sup>60</sup> . 

**Empirical modelling.** For the comparison between a sphere and a cube, EMA was employed together with a single-shot computation of Coulomb interaction. The correspondence 𝐿�√3 𝑅 was made where 𝐿 and 𝑅 are the cube edge length and sphere radius, respectively. For the peak assignment and the absorption cross-section, assuming spherical symmetry, the two-band 𝑘. 𝑝 model was used and the Coulomb interaction was treated using the Hartree-Fock approximation. Electron-photon interaction was computed within second-order many-body perturbation theory. The QD size is taken to be √3 𝑅��� where 𝑅��� is the effective sphere radius. More details can be found in **Supplementary Notes 2 and 4.** 

## **Acknowledgements** 

This work was financially supported by the European Union's through Horizon 2020 Research and innovation Programme through European Research Commission (ERC-CoG, agreement number 819740, project SCALE-HALO) and FET Open research and innovation action (grant agreement no. 899141, project PoLLoC) and US Air Force Office of Scientific Research (award number FA8655-21-1-7013). SAXS and WAXS measurements were carried out at beamline P21.2 at PETRA III at DESY, a member of the Helmholtz Association (HGF); we thank M. Blankenburg and U. Lienert for assistance during the measurements. The research leading to this result has been supported by the project CALIPSOplus under the Grant Agreement 730872 from the EU Framework Programme for Research and Innovation HORIZON 2020.  We thank F. Krumeich and I. Cherniukh for HAADF-STEM measurements and F. Krieg and I. Cherniukh for providing reference cuboidal CsPbBr3 NCs. 

## **Author contributions** 

Q.A.A. performed the synthesis and optical characterization, with the contributions from P.W., F.B and D.N.D. T.P.T.N, C.K. and J.E. carried out theoretical calculations. S.C.B performed the low-temperature PLE measurements. F.M. carried out the WAXS and SAXS experiments. R.E. conducted electron 

21 

microscopy. Q.A.A and M.V.K. wrote the manuscript, with input from all authors. M.V.K, C.K. and J.E. supervised the project. 

**Competing financial interests:** The authors declare no competing financial interest. 

## **Additional Information** 

**Supplementary Information** is available for this paper. 

**<mark>Materials & Correspondence</mark>** <mark>Maksym V. Kovalenko (mvkovalenko@ethz.ch)</mark> 

**Correspondence and requests for materials** should be addressed to M.V.K. 

## **Extended Data Figures** 



**Extended Data Fig. 1 | Comparison between** **_in-situ_ and** **_ex-situ_ data analysis and overview of** **_in-situ_ measurements. a,** Schematic showing conventional _ex-situ_ data acquisition and analysis. **b,** Schematic of _in-situ_ acquisition and _in-situ_ analysis. **c,** Setup for _in-situ_ absorption and PL measurements. **d,** Example of _in-situ_ absorption measurement with simultaneous **e,** _in-situ_ PL measurement. **f,** Schematic overview of data analysis of _in-situ_ absorption and PL data. 

22 



**Extended Data Fig. 2 | HR-STEM analysis of 12 nm CsPbBr3 QDs and their rhombicuboctahedral shape. a,** HR-STEM image of a single 12 nm QD in [100] orientation, showing truncation along {110} facets. **b,** Overlap of HR-STEM image and crystal lattice of CsPbBr3 along [100] axis. **c,** Graphic representation of 20x20x20 unit cell QD truncated along {110} and {111} facets shown along [100] axis. **d,** Simple graphical representation of rhombicuboctahedron shown along [100] axis. **e,** Single QD in [110] orientation, showing truncation along {111} facets. **f,** Overlap of HR-STEM image and crystal lattice of CsPbBr3 along [100] axis. **g,** graphic representation of 20x20x20 unit cell QD truncated along {110} and {111} facets shown along [110] axis. **h,** Graphical representation of rhombicuboctahedron shown along [110] axis. 

23 



**Extended Data Fig. 3 | CsPbBr3 to CsPbCl3 QDs by anion-exchange. a,** _In-situ_ recorded absorption spectra of 5 nm CsPbBr3 QDs undergoing controlled Cl<sup>-</sup> anion exchange via dropwise addition of Cl<sup>-</sup> precursor, with respective second derivative shown in **b. c,** Absorption spectra of a series of purified 8 nm CsPb(Br:Cl)3 QDs with well-resolved higher-order absorption peaks, which remain preserved after the anion-exchange reaction and purification. **d,** Respective PL spectra of QD sample shown in panel c. 

24 





**Extended Data Fig. 4 |** **_In-situ_ measurements of CsPbBr3 QDs synthesized under different growth conditions. a,** CsPbBr3 QD size-control by adjusting the overall concentrations. **b,** Size-tuning of CsPbBr3 QDs by increasing the TOPO:PbBr2 ratio. All absorption spectra are normalized at 3 eV for better visual guide of the spectral evolution. 

25 





**Extended Data Fig. 5 | Theoretical one-photon absorption cross-section** 𝝈<sup>�𝟏�</sup> � **10**<sup>**-14**</sup> **cm**<sup>**2**</sup> � **versus energy (eV) for different sizes using spherical k.p model.** The direction of increasing size, where 𝐿� 3.0 �8.0 nm with size step equal to 0.5 nm, is indicated by a black arrow. **a** and **b,** CsPbBr3, **c** and **d** , FAPbBr3. The absorption spectra were calculated at 14 K (panels **a** and **c** ) and at 300 K (panels **b** and **d** ). The broadening parameters used for CsPbBr3 and FAPbBr3 QDs are discussed in **Supplementary Note 4** . 

26 



**Extended Data Fig. 6 | Temperature dependence of one-photon absorption cross-section spectrum** 𝝈<sup>�𝟏�</sup> � **10**<sup>**-14**</sup> **cm**<sup>**2**</sup> � **versus energy (eV) in spherical k.p model. a-d** , CsPbBr3, **e-h** , FAPbBr3. QD size is 𝐿� 7.0 nm for both cations. The arrows denote direction of increasing temperature. Each calculated spectrum corresponds to the temperature represented by each dot on the leftmost panels. The size dispersion 𝛿���� is 8%, 10% and 15% from left to right (panels **b** to **d** for CsPbBr3, panels **f** to **h** for FAPbBr3). For CsPbBr3, the temperature-dependent electronic band gap is modelled as in Ref<sup>61</sup> . Using 𝐴linear �0.339 meV/𝐾,<sup>61</sup> and 𝐸�� �16 meV,<sup>62</sup> the choice of 𝐴�� �30 meV correctly reproduces the absorption band gap of CsPbBr3 as measured by Yang _et al_<sup>_63_</sup> _._ The change of 𝐸gap of FAPbBr3 versus temperature was fitted using linear function for the data from Wang _et al_<sup>64</sup> . The modelling of line shape can be found in **Supplementary Note 4** . 

27 





**Extended Data Fig. 7 | Additional low-temperature absorption and PLE data. a,** 14 K absorption and PLE spectra with their respective multigaussian fit, demonstrating splitting of 1p-1p states. The higherenergy 1p-1p has been marked with*. **b,** Temperature-dependent absorption spectra of 7.3 nm CsPbBr3 QD from room temperature to 14 K, showing the appearance of the second high-energy p-p peak around 2.65-2.70 eV. **b,** 14 K PLE measurements of CsPbBr3 QDs in the range of 6-9 nm, all showing a second 1p-1p transition. 

28 



**Extended Data Fig. 8| Energy splitting** 𝜟𝑬 **1p** �𝐦𝐞𝐕� **between the 1p-1p transitions versus the first absorption peak** 𝑬 **1s-1s** � **eV** � **.** Experimental data points were extracted using second derivative (green square) or multi-Gaussian fit (red diamond) from the low-temperature absorption spectra. The theoretical lines in panels a to c were done using the dimensionless mass variation 𝛿𝑚/𝑚� 10%, 12% and 15%, respectively. Aspect ratio 𝑏� 1.03. 𝛥𝐸1pU (light blue, dash dotted line): upper bound; 𝛥𝐸1p��/� (solid blue): without shape anisotropy, i.e. 𝑏� 1.00; 𝛥𝐸1pL (dark blue, dotted line): lower bound. For panel a, 𝛥𝐸1p� (purple dash line) was computed without mass anisotropy, i.e. 𝛿𝑚/𝑚�0, 𝑏� 1.03, to demonstrate the effect of only shape anisotropy. 

29 



**Extended Data Fig. 9 | Overview of** **_in-situ_ Stokes shift measurements. a,** Normalized absorption spectra of 6.2 nm CsPbBr3 QD and **b,** corresponding PL spectra. Here, the spectra are normalized at 3 eV to better demonstrate the growth. **c,** _In-situ_ absorption and PL peak positions and the respective calculated Stokes shift as a function of size during the measurement shown in **a** - **b** . **d,** Size-dependent Stokes shift study of over 25.000 different spectra from 12 different reactions, compared to Brennan _et al_<sup>_57_</sup> _._ 

30 





**Extended Data Fig. 10 |** **_In-situ_ absorption measurements of FAPbBr3 and MAPbBr3 QDs for different final sizes.** The synthesis conditions are found in **Supplementary Tables 1 and 2. a,** Absorption spectra of FAPbBr3 QDs and their respective negative second derivative, showing the evolution of multiple excitonic absorption transitions. **b,** Analogous study for MAPBr3 QDs. All spectra are normalized at 3 eV for a better visual guide of the spectral changes. 

31 

This is a list of supplementary �les associated with this preprint. Click to download. 

- SIVideo4.mov 

- SIVideo3.mov 

- SIVideo1.mov 

- SIVideo5.mov 

- KovalenkoetalSupplementaryTamingthegrowthofperovskiteQDs.pdf 

- SIvideo2.mp4 

