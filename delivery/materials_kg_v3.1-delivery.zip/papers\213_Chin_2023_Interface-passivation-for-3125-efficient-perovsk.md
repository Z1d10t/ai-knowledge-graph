# Interface passivation for 31.25%-efficient perovskite/silicon tandem solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 441 |
| 作者 | Xin Y. Chin, D. Turkay, J. Steele, S. Tabean, S. Eswara, M. Mensi, Peter Fiala, C. Wolff et al. |
| DOI | 10.1126/science.adg0091 |
| 源文件 | 013_Chin_2023_Interface-passivation-for-3125-efficient-perovsk.pdf |

---
RESEARCH 



the perovskite layer on micrometric Si pyramids, resulting in perovskite/c-Si tandems in which both rear and front sides were textured (16). Although these tandem cells had a high photocurrent thanks to the front-side pyramidal texture, nonradiative recombination losses were substantial. One challenge is that most top-surface passivation approaches reported to date are not directly applicable to micrometric textures because they involve depositing nanometric organic layers from liquid solutions (17–19). These processing routes usually yield nonconformal (incomplete) coatings on such surface textures. Building on our previous work (16), we demonstrate enhanced tandem performance using phosphonic acids in two different roles to passivate interfacial defects: first, as a hole-transport layer (HTL), [4-(3,6dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid (Me-4PACz) (9) and second, as a perovskite additive in the form of 2,3,4,5,6-pentafluorobenzylphosphonic acid (FBPAc) (20). Together with a micrometric texture standard in the c-Si PV industry and an optimization of the layers located at the front of the tandem for further optical gains, these passivation strategies mitigate voltage losses and result in tandem device efficiencies >30%, with an accredited value of 31.25%. 



### SOLAR CELLS 

# Interface passivation for 31.25%-efficient perovskite/silicon tandem solar cells 

Xin Yu Chin<sup>1,2</sup> *, Deniz Turkay<sup>1</sup> , Julian A. Steele<sup>3,4,5</sup> , Saba Tabean<sup>6,7</sup> , Santhana Eswara<sup>6</sup> , Mounir Mensi<sup>8</sup> , Peter Fiala<sup>1</sup> , Christian M. Wolff<sup>1</sup> , Adriana Paracchino<sup>2</sup> , Kerem Artuk<sup>1</sup> , Daniel Jacobs<sup>1</sup> , Quentin Guesnay<sup>1</sup> , Florent Sahli<sup>2</sup> , Gaëlle Andreatta<sup>2</sup> , Mathieu Boccard<sup>1</sup> , Quentin Jeangros<sup>1,2</sup> , Christophe Ballif<sup>1,2</sup> 

Silicon solar cells are approaching their theoretical efficiency limit of 29%. This limitation can be exceeded with advanced device architectures, where two or more solar cells are stacked to improve the harvesting of solar energy. In this work, we devise a tandem device with a perovskite layer conformally coated on a silicon bottom cell featuring micrometric pyramids—the industry standard—to improve its photocurrent. Using an additive in the processing sequence, we regulate the perovskite crystallization process and alleviate recombination losses occurring at the perovskite top surface interfacing the electron-selective contact [buckminsterfullerene (C60)]. We demonstrate a device with an active area of 1.17 s <mark>q</mark> uare centimeters <mark>,</mark> reachin <mark>g</mark> a certified <mark>p</mark> ower conversion efficienc <mark>y</mark> of 31.25%. 

he deployment of photovoltaics (PV) can be accelerated by maximizing the electrical power produced per unit area because the cost distribution of a PV system T is now dominated by the balance of system components (such as the mounting system, wiring, manpower, and inverters) rather than by the cost of the PV panels. This balance of system costs scales roughly with the installed area and favors PV technologies with a high power-to–panel area ratio. However, the record power conversion efficiency (PCE) of crystalline silicon (c-Si) solar cells of 26.8% (1) is approaching the theoretical limit of 29.5% (2). The only experimentally validated approach to overcome this PCE limitation under 1-sun illumination conditions consists of combining several complementary photoactive materials (meaning multiple junctions) in a single device (3). Among the different types of multijunction designs reported to date, the combination of c-Si with a metal halide perovskite in a tandem solar cell has been the focus of intense research efforts given the potential for both high PCE and low manufacturing costs (4). 

Metal halide perovskites combine several key properties for effective multijunction PV, including a high absorption coefficient with a sharp absorption edge (5), ambipolar charge transport with long diffusion lengths (6, 7), and a compositionally tunable bandgap energy (Eg) (8). A thin-film perovskite solar cell can be deposited directly on the front side of a c-Si cell to lower thermalization losses and extend the range of achievable PCE to >30% (3). The performance potential of monolithic two-terminal tandem architectures is illustrated by reported PCEs as high as 33.7% for 1-cm<sup>2</sup> illuminated areas (1). Most of the highefficiency tandem cells reported to date use a Si wafer in which the front surface is mechanically or chemically polished (9) or features an adapted submicrometric texture smaller than the perovskite layer thickness (typically from 500 nm to 1 mm) (10–13). This planar or nanotextured front-side topography—wafers used in the PV industry are usually etched to form pyramids of a few micrometers in height— enables the deposition of pinhole-free perovskite films by standard solution-based processes. However, this modification comes at the expense of optical performance because the front side of the tandem is flat, and also when using a submicrometric Si texture, because the latter is planarized by the nonconformal solution-processed perovskite film. Consequently, these cell designs exhibit more reflection losses at the front of the tandem because of an absence of double-bounce effects (14). Overall, a pyramidal texture at the front of the tandem device limits reflection losses because it enables the absorption of reflected light in neighboring pyramids, whereas the presence of texture on both sides of the Si wafer improves the trapping of infrared light (15). 

### Identification and mitigation of voltage losses in perovskite top cells 

To assess loss pathways triggered by nonradiative recombination, we measured the photoluminescence quantum yield of different layer stacks representative of our p-i-n perovskite solar cells used in tandem cells. We quantified the internal voltage potential (in relative terms), or quasi–Fermi-level splitting (QFLS), created within the cesium formamidinium lead iodide bromide [Cs0.18FA0.82Pb(I, Br)3] absorber under light excitation (Fig. 1A). Flat glass/indium tin oxide (ITO) substrates were first coated with a HTL, either 2,2′,7,7′tetra(N,N-di-tolyl)amino-9,9-spiro-bifluorene (spiro-TTB), N4,N4,N4’’,N4’’-tetra([1,1’-biphenyl]4-yl)-[1,1’:4’,1’’-terphenyl]-4,400-diamine (TaTM), or Me-4PACz (fig. S1). These three materials were selected on the basis of their compatibility with textured surfaces. The first two can be thermally evaporated, and the latter can self-assemble on ITO to yield a conformal coating on textured surfaces (21). We then deposited a perovskite thin film using a hybrid two-step deposition method (16). Specifically, aCsBr/PbI2 templatewascoevaporatedoneither flat glass substrates or glass/ITO/HTL stacks before spin coating an organo-halide solution consisting of FABr and FAI and, in some cases, with FBPAc. A thermal annealing step in an ambient atmosphere at 150°C converted the films into a perovskite phase (see the experimental section for details). In view of making tandems, a perovskite composition with an 

> 1Photovoltaics and Thin-Film Electronics Laboratory (PVLab), Institute of Microengineering (IMT), Ecole Polytechnique Fédérale de Lausanne (EPFL), Neuchâtel, Switzerland.<sup>2</sup> Centre Suisse d'Électronique et de Microtechnique (CSEM), Neuchâtel, Switzerland.<sup>3</sup> cMACS, Department of Microbial and Molecular Systems, KU Leuven, 3001 Leuven, Belgium.<sup>4</sup> Australian Institute for Bioengineering and Nanotechnology, The University of Queensland, Brisbane, QLD 4072, Australia.<sup>5</sup> School of Mathematics and Physics, The University of Queensland, Brisbane, QLD 4072, Australia.<sup>6</sup> Advanced Instrumentation for Nano-Analytics (AINA), Luxembourg Institute of Science and Technology (LIST), Materials Research and Technology Department, 41, Rue du Brill, L-4422 Belvaux, Luxembourg. 

> 7University of Luxembourg, 2 Avenue de l’Université, L-4365 Esch-sur-Alzette, Luxembourg.<sup>8</sup> Institute of Chemical Sciences and Engineering (ISIC), École Polytechnique Fédérale de Lausanne, Sion, Switzerland. *Corresponding author. Email: xinyu.chin@csem.ch 

We previously reported a hybrid two-step deposition method combining thermal evaporation and spin coating to conformally coat 

1 of 4 

Chin et al., Science 381, 59–63 (2023) 7 July 2023 

RESEARCH | RESEARCH ARTICLE 



optical Eg of ~1.70 eV was selected (fig. S2). Some of these stacks were then completed by a C60 electron-transport layer (ETL) thermally evaporated in high-vacuum conditions. 



The QFLS of bare perovskite layers deposited on glass (left column) remains constant when incorporating FBPAc (Fig. 1A). When inserting the HTL (Fig. 1A, hollow diamond), the addition of FBPAc increases the QFLS slightly with all three HTLs (+20 meV). Overall, QFLS losses relative to the glass/perovskite reference are highest on spiro-TTB (−80 and −45 meV compared with the glass/perovskite reference, without and with FBPAc, respectively), followed by TaTm (−65 and −40 meV), and lowest on Me-4PACz (−25 and −10 meV). These differences suggest improved surface passivation with Me-4PACz (9). Without FBPAc, the addition of the C60 ETL (Fig. 1A, filled diamond) on the perovskite leads to substantial losses in QFLS (−100 to −50 meV in addition to the HTL-induced losses) caused by the formation of trap states in the first monolayer of C60 (22). On the other hand, the incorporation of FBPAc in the perovskite film synthesis mitigates some of these ETLinduced losses, resulting in a +100-meV QFLS gain compared with FBPAc-free films. 

Overall, FBPAc suppresses Pb<sup>2+</sup> /Pb<sup>0</sup> surface defects, as shown by x-ray photoelectron spectroscopy (XPS) in Fig. 1B and figs. S3 to S5. The phosphonic group of FBPAc coordinates with Pb-related defects as also demonstrated elsewhere (20, 23, 24), effectively lowering the population of top-surface nonradiative recombination states (25). Furthermore, the positive impact of FBPAc is mainly observed when C60 is present: FBPAc likely separates the perovskite from the C60 layer, reducing the population of deep trap states forming in C60 when it is in direct contact with the perovskite (11, 22). It is important to note that some effects may affect the QFLS data presented in this work. First, the presence of oxygen and humidity during the annealing step and subsequent photoluminescence measurements may lead to a passivation of Pb-related defects (26). Second, x-ray diffraction (XRD) patterns show that the addition of FBPAc decreases the fraction of PbI2 crystalline phases remaining at the end of the crystallization process (Fig. 1C and fig. S8)—an effect that should lower the photoluminescence quantum yield and hence the QFLS of films featuring the additive (27). Other effects are less likely to explain the QFLS trends we observed. For example, FBPAc and C60 do not appear to chemically interact based on additional XPS data (fig. S6). Also, the electronic band structure of uncoated perovskite films treated with the additive shifts by ~0.5 eV because of the strong dipole moment of FBPAc (fig. S7), in line with literature (28). However, FBPAc is unlikely to lead to such a conduction band level offset in full devices considering the 

Fig. 1. Reduced nonradiative recombination losses and improved crystallographic properties when adding FBPAc. (A) QFLS loss of perovskite films (without and with FBPAc) extracted from photoluminescence quantum yield data relative to the glass/perovskite reference. Hollow diamond data points correspond to the QFLS of perovskite films deposited on different HTLs (spiro-TTB, TaTm, and Me-4PACz), and filled diamonds relate to films sandwiched by one of these HTLs and a C60 ETL. (B and C) High-resolution XPS spectra of the Pb 4f orbital (B) and XRD patterns of perovskite films with and without FBPAc (C). a.u., arbitrary units. 

improved solar cell performance achieved with FBPAc (see below). 

using FBPAc. Overall, this two-step and globally slower crystallization kinetics with the additive likely originates from the interaction between Pb<sup>2+</sup> and FBPAc (20, 23, 24). FBPAc slows down the conversion of the CsBr/PbI2 template to the perovskite phase because of competition between FBPAc and other perovskite precursors (namely FAI and FABr) for a coordination with Pb<sup>2+</sup> (25, 30). Advantageously, this difference in formation kinetics results in films with apparently larger and more clearly defined perovskite domains because FBPAc may inhibit the nucleation of new perovskite grains or domains, as shown by top-view scanning electron microscopy (SEM) images (Fig. 2B). 

### Modification of the perovskite crystallization kinetics and resulting microstructure 

To understand the impact of FBPAc on the perovskite crystallization process, grazingincidence wide-angle x-ray scattering (GIWAXS) was performed in situ at 150°C starting from a CsBr/PbI2 template freshly spin-coated with FAI/FABr (Fig. 2A and fig. S8). Although the crystallization onset of the perovskite (110) and (002) planes (q ~ 10.1 nm<sup>−1</sup> ) (29) is similar with or without the additive, FBPAc slows down the perovskite crystallization rate 100 s into the experiment (Fig. 2A). The intensity of these perovskite reflections then continues to increasethroughouttheexperimentupto~400 s— an effect not observed without the additive. Without FBPAc, the peak intensity stabilizes after 150 s and remains at a lower value. This modification of the crystallization pathway by FBPAc is also observed when analyzing PbI2 peaks (Fig. 2A). As in Fig. 1C, their evolution confirms a more-complete conversion of the CsBr/PbI2 template to a perovskite phase when 

Submicrometer dark regions are observed on perovskite films featuring FBPAc (Fig. 2B). From gas-field ion-source helium and neon ion microscopy coupled with secondary-ion mass spectrometry (SIMS) (Fig. 2C and fig. S9) (31), these clusters are found to be rich in F and C, which is indicative of the clustering of the FBPAc excess on the perovskite surface. Films processed without FBPAc do not show any clustering and feature a lower amount of F and C on their surface (Fig. 2, C and D, and 

2 of 4 

Chin et al., Science 381, 59–63 (2023) 7 July 2023 

RESEARCH | RESEARCH ARTICLE 



port across the perovskite/C60 interface. Washing away the FBPAc with an orthogonal solvent mixture results in perovskite cells with a similar Voc to that of untreated films, which confirmsthatFBPAcaffectsprimarilyrecombination at the perovskite top surface (fig. S16). 







We then adapted the perovskite deposition conditions to produce 1-cm<sup>2</sup> tandem cells on silicon heterojunction bottom cells that had pyramids of 2 to 3 mm on both sides of the wafer (Fig. 3A) (32, 33). Compared with our previous tandem baseline (16), the perovskite layer was made thicker (from ~650 nm to ~1 mm) to reach current matching conditions with an Eg of ~1.7 eV (1.63 eV previously; Fig. 3B). For that purpose, we deposited a CsBr/ PbI2 template of 660 nm and adapted the spin-coating parameters to convert the template into a perovskite phase. The front electrode was made transparent by switching to a stack made of C60, SnOx, indium zinc oxide (IZO), an Ag grid, and a MgF2 antireflective coating (see materials and methods and supplementary text for details). 





A Voc of 1.9 V is obtained with either TaTM or Me-4PACz (fig. S17), which is consistent with single-junction cell results (perovskite top cells in fig. S14; c-Si bottom cell in fig. S18). The FF of TaTm-based tandems is lower than with Me-4PACz (<70% compared with >75%), likely because of the low hole mobility in undoped TaTm (34). We also investigated the impact of a slight change in the perovskite Eg by changing the FABr:FAI molar ratio from 2 to 1.75 and 1.5 (corresponding to a Eg of 1.69, 1.68, and 1.67 eV, respectively). A PCE >30% could be achieved with several of these perovskite compositions, with slight variations in Jsc and FF values depending on the top cell Eg and the current-limiting subcell (figs. S17 and S19). These tandems remained stable for >360 days when stored at room temperature in N2 (fig. S20). A selection of these unencapsulated cells were then operated in ambient at their maximum power point at 65°C under a 1-sun illumination (~20 to 30% relative humidity; ISOS-L2 protocol). The most stable device reaches a t80 of ~66 hours until 80% of its initial PCE is measured (figs. S21 and S22). The degradation rate at 25°C of the FBPActreated tandem stack is similar to that achieved without FBPAc in our previous study (ISOS-L1 conditions; figs. S21 and S22) (16). 

Fig. 2. Impact of FBPAc on the perovskite crystallization and resulting microstructure. (A) GIWAXS data showing the evolutions of the (110) and (002) planes of the perovskite phase (indicated as PK in the figure) and of the (001) planes of the PbI2 phase during the perovskite crystallization process at 150°C. (B) Secondary-electron SEM images highlighting the difference in surface morphologies when adding FBPAc, with arrows showing FBPAc clusters. (C) SIMS maps of the<sup>19</sup> F<sup>−</sup> and<sup>12</sup> C2− signals. The bright and dark regions represent higher and lower, respectively, signal counts. (D) Corresponding histograms of the<sup>19</sup> F<sup>−</sup> and<sup>12</sup> C2− SIMS signals shown in (C). 

### Perovskite single junctions and perovskite/c-Si tandem solar cells 

fig. S9). Depth profiling combined with XPS reveals that FBPAc is confined to the top perovskite surface (figs. S10 to S13). The bulky FBPAc molecules are expelled toward the top surface during the perovskite crystallization process. 

These perovskite films were incorporated into ~0.49-cm<sup>2</sup> glass/ITO/HTL/perovskite/ C60/bathocuproine (BCP) (or SnOx)/Cu (or Ag) single junctions to validate the improvements induced by FBPAc with current-voltage (J-V) measurements (1000 W/m<sup>2</sup> , AM1.5G spectrum, masked with a 0.25-cm<sup>2</sup> aperture; fig. S14). The open-circuit voltage (Voc) of the devices improves by 20 to 30 mV when switching from spiro-TTB to TaTm and Me-4PACz and by an extra 40 to 50 mV when adding FBPAc, in line with the QFLS results of Fig. 1A. The corresponding fill factor (FF) also increases on average from ~69 to ~76% when changing the HTL and then to ~78 to 81% with the additive, confirming that the molecule does not lead to the formation of a barrier impeding electron extraction. Overall, the combination of Me-4PACz and FBPAc results in a PCE of up to 19.5%. Varying the concentration of FBPAc from 2.5 to 7.5 mM in the FABr:FAI solution does not affect the performance substantially (fig. S15), which suggests that the excess of FBPAc (Fig. 2B) does not hinder charge trans- 

The large reduction in QFLS losses suggests that FBPAc is also present in between the surface clusters. This hypothesis stems from the logarithmic dependency between QFLS and surface recombination current (and hence nonpassivated surface fraction, presuming that FBPAc is reducing the surface recombination current by a few orders of magnitude). If FBPAc was present only at the position of the clusters detected by SIMS, meaning that ~90% of the film surface would be free of FBPAc, the difference in QFLS would be limited to ~3 meV [DQFLS = 25.7 meV × ln(1/0.9) ≅ 3 meV]. We observe a gain in QFLS of >50 meV when C60 is present (Fig. 1A), highlighting that regions between the clusters also feature FBPAc. Overall, FBPAc passivates Pb-related defects and mitigates the formation of trap states in the C60 layer by segregating on the perovskite top surface, with the excess forming clusters on the surface. 

A tandem cell featuring Me-4PACz and FBPAc was sent to the National Renewable Energy Laboratory (NREL) for certification. The certified relative external quantum efficiency (EQE) shown in Fig. 3C indicates that the tandem was slightly top cell limited and that both subcells produced a Jsc > 20 mA/cm<sup>2</sup> . The stabilized J-V properties of the device were measured using the asymptotic maximum power (Pmax) scan method in standard test conditions (STC) (25°C, 1000 W/m<sup>2</sup> , AM1.5G 

3 of 4 

Chin et al., Science 381, 59–63 (2023) 7 July 2023 

RESEARCH | RESEARCH ARTICLE 





10. B. Chen et al., Joule 4, 850–864 (2020). 

11. J. Liu et al., Science 377, 302–306 (2022). 

12. P. Tockhorn et al., Nat. Nanotechnol. 17, 1214–1221 (2022). 

13. Y. Hou et al., Science 367, 1135–1140 (2020). 

14. F. Gota, R. Schmager, A. Farag, U. W. Paetzold, Opt. Express 30, 14172–14188 (2022). 

15. D. A. Jacobs et al., J. Phys. Chem. Lett. 10, 3159–3170 (2019). 

16. F. Sahli et al., Nat. Mater. 17, 820–826 (2018). 

17. C. M. Wolff, P. Caprioglio, M. Stolterfoht, D. Neher, Adv. Mater. 31, e1902762 (2019). 

18. J. Peng et al., Adv. Energy Mater. 8, 1801208 (2018). 

19. R. Azmi et al., Science 376, 73–77 (2022). 

20. E. Akman, A. E. Shalan, F. Sadegh, S. Akin, ChemSusChem 14, 1176–1183 (2021). 

21. M. Roß et al., Adv. Energy Mater. 11, 2101460 (2021). 

22. J. Warby et al., Adv. Energy Mater. 12, 2103567 (2022). 

23. A. A. M. Brown et al., Nanoscale 11, 12370–12380 (2019). 

24. J. S. Kim et al., Nature 611, 688–694 (2022). 

25. T. Wang, J. D. A. Ng, E. W. Y. Ong, K. H. Khoo, Z. K. Tan, Adv. Opt. Mater. 10, 2101914 (2021). 

26. J. F. Galisteo-López, M. Anaya, M. E. Calvo, H. Míguez, J. Phys. Chem. Lett. 6, 2200–2205 (2015). 

27. J. Euvrard, O. Gunawan, D. B. Mitzi, Adv. Energy Mater. 9, 1902706 (2019). 

28. I. Lange et al., Adv. Funct. Mater. 24, 7014–7024 (2014). 

29. L. Oesinghaus et al., Adv. Mater. Interfaces 3, 1600403 (2016). 

30. T. Jeon et al., Adv. Energy Mater. 7, 1602596 (2017). 

31. T. Wirtz, O. De Castro, J.-N. Audinot, P. Philipp, Annu. Rev. Anal. Chem. 12, 523–543 (2019). 

32. F. Sahli et al., Adv. Energy Mater. 8, 1701609 (2018). 

33. L. Antognini et al., IEEE J. Photovolt. 11, 944–956 (2021). 

34. C. Momblona et al., Energy Environ. Sci. 9, 3456–3463 (2016). 

35. T. Song, D. J. Friedman, N. Kopidakis, Adv. Energy Mater. 11, 2100728 (2021). 

Fig. 3. 31.25%-efficient perovskite/c-Si thanks to the combined action of Me-4PACz and FBPAc and a pyramidal texture on the front side of the tandem. (A) Schematic view of the perovskite/c-Si tandem stack and corresponding picture of the perovskite top cell on textured Si. The acronyms a-Si:H and nc-Si:H stand for amorphous and nanocrystalline hydrogenated Si, respectively, and (i/n/p) indicates the doping of the layers. (B) Secondary-electron SEM images of the front side of the tandem. (C to E) Independently certified EQE (C), asymptotic maximum power (Pmax) scan (D), and current density and power density tracking around Pmax (E). 

#### ACKNOWLEDGMENTS 

The authors thank P. Wyss and C. Allebé for SHJ wet-chemical processing and V. Paratte, B. Kamino, T. Wirtz, J. Hofkens, and M. B. J. Roeffaers for their valuable scientific and technical discussion. The authors also thank the staff of the BL11 NCDSWEET beamline at ALBA Synchrotron for their assistance in recording the GIWAXS data. Funding: This study was supported by Swiss National Science Foundation grant 200021_197006 (PAPET); Swiss Federal Office of Energy grant SI/501804 (INTENT); Swiss Federal Office of Energy grant SI/502209 (PRESTO); Luxembourg National Research Fund (FNR) grant PRIDE17/12246511 (PACE); and Research Foundation - Flanders FWO, grant no. 12Y7221N, V400622N. C.M.W. thanks the European Commission for funding through a Marie Skłodowska-Curie Fellowship (no. 101033077). Author contributions: Conceptualization: X.Y.C. and Q.J. Experiments: X.Y.C., D.T., J.A.S., S.T., S.E., M.M., P.F., C.M.W., A.P., K.A., D.J., Q.G., F.S., G.A., M.B., and Q.J. Project administration: X.Y.C., C.M.W., G.A., M.B., Q.J., and C.B. Supervision: X.Y.C., C.M. W., Q.J., and C.B. Writing – original draft: X.Y.C. and Q.J. Writing – review & editing: X.Y.C., D.T., C.M.W., J.A.S., S.T., S.E., M.M., P.F., A.P., K.A., D.J., Q.G., F.S., G.A., M.B., Q.J., and C.B. Competing interests: X.Y.C. and Q.J. are inventors on a provisional patent related to the subject matter of this manuscript (EP22210577.7). The authors declare no other competing interests. Data and materials availability: All data are available in the main text or the supplementary materials. License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/sciencelicenses-journal-article-reuse 

spectrum; Fig. 3, D and E, and figs. S23 to S26) (35). In agreement with data measured inhouse, the cell reaches a Voc of 1.91 V, a Jsc of 20.47 mA/cm<sup>2</sup> , and a FF of 79.8%, which results in a certified PCE of 31.25% (with an aperture area of 1.1677 cm<sup>2</sup> ). 

metric texture to improve optical properties, a high-quality 1-mm-thick perovskite absorber deposited conformally on this texture using a hybrid two-step method, and phosphonic groups at both sides of the absorber for improved interface passivation resulted in a tandem with an independently certified PCE of 31.25%. These results demonstrate how c-Si solar cells with a standard industrial micrometric texture can be upgraded to increase their PCE to >30%. 

### Conclusions 

We identified and mitigated nonradiative recombination losses occurring at the interfaces of perovskite/c-Si tandems featuring Si wafers with a micrometric texture—the standard used in the c-Si PV industry. The use of Me-4PACz reduces voltage losses at the perovskite/HTL interface, whereas the inclusion of FBPAc in the perovskite deposition sequence reduces the voltage losses at the perovskite/C60 ETL interface and leads to more favorable perovskite microstructures with larger domains. From XPS and SIMS imaging, FBPAc is present on the perovskite top surface and coordinates with perovskite Pb-related defects through its phosphonic acid group. Overall, the combination of a c-Si micro- 

#### REFERENCES AND NOTES 

1. “Best Research-Cell Efficiency Chart” (NREL, 2023); https://www.nrel.gov/pv/cell-efficiency.html. 

2. S. Schäfer, R. Brendel, IEEE J. Photovolt. 8, 1156–1158 (2018). 

3. L. C. Hirst, N. J. Ekins-Daukes, Prog. Photovolt. Res. Appl. 19, 286–293 (2011). 

#### SUPPLEMENTARY MATERIALS 

science.org/doi/10.1126/science.adg0091 Materials and Methods Supplementary Text Figs. S1 to S28 Tables S1 to S4 References (36–45) 

4. F. Fu et al., Adv. Mater. 34, e2106540 (2022). 

5. S. De Wolf et al., J. Phys. Chem. Lett. 5, 1035–1039 (2014). 

6. X. Y. Chin, D. Cortecchia, J. Yin, A. Bruno, C. Soci, Nat. Commun. 6, 7383 (2015). 

7. S. D. Stranks et al., Science 342, 341–344 (2013). 

8. T. Jesper Jacobsson et al., Energy Environ. Sci. 9, 1706–1724 (2016). 

Submitted 27 November 2022; accepted 5 May 2023 10.1126/science.adg0091 

9. A. Al-Ashouri et al., Science 370, 1300–1309 (2020). 

4 of 4 

Chin et al., Science 381, 59–63 (2023) 7 July 2023 



## **Interface passivation for 31.25%-efficient perovskite/silicon tandem solar cells** 

Xin Yu Chin, Deniz Turkay, Julian A. Steele, Saba Tabean, Santhana Eswara, Mounir Mensi, Peter Fiala, Christian M. Wolff, Adriana Paracchino, Kerem Artuk, Daniel Jacobs, Quentin Guesnay, Florent Sahli, Gaëlle Andreatta, Mathieu Boccard, Quentin Jeangros, and Christophe Ballif 

_Science_ **381** (6653), .  DOI: 10.1126/science.adg0091 

### **Editor’s summary** 

Two studies show how interfaces between perovskite layers and silicon cells in tandem solar cells can be modified to improve performance (see the Perspective by De Wolf and Aydin). Mariotti _et al_ . showed that an ionic liquid, piperazinium iodide, improved band alignment and enhanced charge extraction at the interface of a trihalide perovskite and a C60 electron-transporting layer by creating a positive dipole. With these modifications, a 2.0-volt open circuit voltage was achieved in a silicon tandem cell. Chin _et al_ . report the uniform deposition of the perovskite top cell on the micropyramids of crystalline silicon cells to achieve high photocurrents in tandem solar cells. Two different phosphonic acids improved the perovskite crystallization process and also minimized recombination losses. These modifications yielded perovskite/silicon tandem cells with certified power conversion efficiencies of more than 31% for active areas of at least 1 square centimeter. —PDS 

### **View the article online** https://www.science.org/doi/10.1126/science.adg0091 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2023 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

