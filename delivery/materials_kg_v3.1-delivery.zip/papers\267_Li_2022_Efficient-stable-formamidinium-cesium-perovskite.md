# Efficient, stable formamidinium-cesium perovskite solar cells and minimodules enabled by crystallization regulation

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 190 |
| 作者 | Yiming Li, Zijing Chen, Bingcheng Yu, Shannon J. Tan, Yuqi Cui, Hui-Jue Wu, Yan-Hong Luo, Jiang-Jian Shi et al. |
| DOI | 10.1016/j.joule.2022.02.003 |
| 源文件 | 053_Li_2022_Efficient-stable-formamidinium-cesium-perovskite.pdf |

---
**ll** 

### Article 

# Efficient, stable formamidinium-cesium perovskite solar cells and minimodules enabled by crystallization regulation 



Yiming Li, Zijing Chen, Bingcheng Yu, ..., Jiangjian Shi, Dongmei Li, Qingbo Meng 

shijj@iphy.ac.cn (J.S.) dmli@iphy.ac.cn (D.L.) qbmeng@iphy.ac.cn (Q.M.) 

Highlights 

A dual-functional strategy is developed to regulate crystallization and defects 

24.25% efficiency is achieved for a single PSC cell with excellent stability 

>20.5% efficiency is realized from a 10.4 cm<sup>2</sup> minimodule 

A dual-functional material comprising organic ammonium cation and dithiocarbamate anion is developed to regulate the crystallization and defects of the formamidinium-cesium perovskite. 24.25% efficiency in a single cell and >20.5% efficiency from a 10.4 cm<sup>2</sup> minimodule have been realized with excellent operational stability. Briefly, this exploitation of cation-anion synergistic effect from dual-functional additives provides more feasible technique routes for promoting the perovskite photovoltaic development and commercialization. 

Li et al., Joule 6, 676–689 March 16, 2022 ª 2022 Elsevier Inc. https://doi.org/10.1016/j.joule.2022.02.003 



**ll** 

##### Article 

## Efficient, stable formamidinium-cesium perovskite solar cells and minimodules enabled by crystallization regulation 

Yiming Li,<sup>1,3</sup> Zijing Chen,<sup>1,5</sup> Bingcheng Yu,<sup>1,3</sup> Shan Tan,<sup>1,5</sup> Yuqi Cui,<sup>1,5</sup> Huijue Wu,<sup>1</sup> Yanhong Luo,<sup>1,4</sup> Jiangjian Shi,<sup>1,</sup> * Dongmei Li,<sup>1,4,</sup> * and Qingbo Meng<sup>1,2,4,6,</sup> * 

###### SUMMARY 

Formamidinium-cesium (FA-Cs) lead halide has attracted wide interest for enhancing the stability of perovskite solar cells; however, the crystallization of FA-Cs perovskite usually suffers from more complicated intermediate phase transition processes. Herein, we have developed a dual-functional additive consisting of organic ammonium cation and dithiocarbamate anion to regulate the crystallization and defects of the FA-Cs perovskite film. With a synergistic contribution of the cationic and anionic groups, 24.25% efficiency has been achieved in a single cell with excellent operational stability. Under steady-state light illumination and bias voltage, 90% power output of its initial state can still be obtained after 500 h of continuous operation. After enlarging the device from single cell to module, >20.5% efficiency has been realized from a 10.4 cm<sup>2</sup> minimodule by using only an ultralow-cost laser scribing technology. Briefly, this exploitation of cation-anion synergistic effect from dual-functional additives provides more opportunities for promoting the development of perovskite solar cells. 

###### INTRODUCTION 

Hybrid organic-inorganic perovskite materials have emerged as promising candidates for photovoltaics applications due to their outstanding optoelectronic properties and low-cost solution processing technique. Power conversion efficiency (PCE) of the perovskite solar cell (PSC) has rapidly risen over the last decade, from 3.8% to 25.5%, comparable with the crystal-Si technology.<sup>1,2</sup> At present, the low stability and the efficiency loss under a cell area enlargement are two key issues that need to be overcome in the commercialization of PSCs.<sup>3–7</sup> Recently, formamidinium-cesium (FA-Cs) lead halide perovskite has attracted wide interest because of its high thermal and operational stabilities.<sup>8,9</sup> However, compared with the methylammonium perovskite, the crystallization of FA-Cs perovskite suffers from more complicated intermediate phase transition processes because the FA<sup>+</sup> and Cs<sup>+</sup> ion sizes mismatch, leading to smaller dipole moment and weaker interaction with the Pb-I framework.<sup>10</sup> This has increased the difficulty of forming uniform perovskites, thus leading to the large lattice distortion, element segregation, and defect centers. 

###### Context & scale 

Formamidinium-cesium (FA-Cs) lead halide has attracted a wide interest for stable perovskite solar cells (PSCs); however, the crystallization of FA-Cs perovskite usually suffers from complicated intermediate phase transition processes. Crystallization regulation using active coordination group to modify Pb-I frameworks has been demonstrated as an effective approach to improve the film quality and device performance. Surface, interface, and grain boundary defect passivation with organic long-chain ammonium halides is another necessary route for enhancing the cell performance and stability. Herein, a dual-functional material comprising organic ammonium cation and dithiocarbamate anion with the synergistic contribution of cationic passivation and anionic coordination effects is developed. This dual-functional strategy helps realize efficient and stable PSCs and minimodules and thus provides more opportunities for promoting the PSC development and commercialization. 

Crystallization regulation has been demonstrated as an effective approach to improve film quality and device performance of the PSC.<sup>11</sup> Perovskite crystallization usually starts from the Pb-I frameworks because they have already formed micronano nucleation centers in precursor solutions.<sup>12,13</sup> As such, the regulation is mainly 



676 Joule 6, 676–689, March 16, 2022 ª 2022 Elsevier Inc. 

**ll** 

##### Article 

realized through introducing additives or different solvent with more active coordination groups, which can modify the Pb-I cluster structure.<sup>14,15</sup> Among them, the solvents having -S=O (i.e., dimethyl sulfoxide [DMSO]) or -C=O (i.e., N-methylpyrrolidinone [NMP]) have been widely exploited via forming solvent-PbI2 adduct cluster to optimize the phase transition and crystallization of the perovskite.<sup>16,17</sup> PbI2$NMP-templated crystallization of FA-Cs perovskite has recently achieved a high PCE of 23% for small-area single cell and of over 20% for minimodule.<sup>18</sup> Electron-donor anions such as COO<sup>�</sup> and SCN<sup>�</sup> have strong coordination ability with the Pb<sup>2+</sup> and also played impressive roles in promoting the FA perovskite phase formation and device performance.<sup>19–21</sup> With using MAHCOO (MA: methylammonium) ionic liquid solvent, black-phase FA perovskite has been stabilized at room temperature and high humidity with over 23% PCE.<sup>19</sup> The small-area single-cell PCE has been further enhanced to over 25% by using FAHCOO additive.<sup>20</sup> Compared with the oxygen in HCOO<sup>�</sup> , sulfur has a much larger atom (or ion) radius and electron delocalization, which should be able to have more effective coordination with the Pb<sup>2+</sup> .<sup>22</sup> 

Besides coordination-induced crystallization regulation, surface, interface, and grain boundary defect passivation is another necessary route for enhancing the cell PCE and stability.<sup>23,24</sup> Perovskite post-treatment with organic long-chain ammonium halides such as phenethylammonium iodide (PEAI), butylammonium iodide (BAI) or octylammonium iodide (OAI) has made a great contribution to the PCE enhancement of the cells.<sup>25–27</sup> If the passivation effect of the long-chain ammonium cation and the coordination effect of the active anion can be synergistically realized, it will be a giant progress in simplifying processing complexity for highly efficient and stable PSCs. 

Herein, we report efficient, stable PSCs and minimodules realized by using a dualfunctional isobutylammonium isobutyldithiocarbamate (iBA-iBDTC) as an additive. CSS<sup>�</sup> group of the iBA-iBDTC can effectively coordinate with the Pb<sup>2+</sup> to improve the Pb-I nucleation and FA-Cs perovskite crystal growth. Additionally, the long-chain iBA<sup>+</sup> cation group is distributed on the film surface and grain boundaries, passivating defects, reducing surface energy, and stabilizing surface structure. With the synergistic contribution of the cationic and anionic groups, the PCE of the smallarea single cell has been improved to 24.25%, superior to the cell only using conventional isobutylammonium iodide (iBAI) passivation. The cell also exhibits excellent operational stability. Under steady-state light illumination and bias voltage (maximum power point [MPP] of the initial state), the cell can sustain 90% of its initial power output after 500 h of continuous operation. This dual-functional additive has also significantly enhanced the uniformity of the perovskite film to ensure high device performance when enlarging the cell area. Over 20.5% PCE has been achieved from a 10.4 cm<sup>2</sup> minimodule. Overall, the cation-anion synergistic effect of our dualfunctional additive provides more feasible technique routes for promoting the PSC development and commercialization. 

###### RESULTS 

###### Device performance 

The synthesized iBA-iBDTC comprises cation (CH3)2CHCH2NH3+ and anion (CH3)2CHCH2NHCSS<sup>�</sup> , as shown in Figure 1A. The CSS<sup>�</sup> is a dithiocarboxylate group obtained by the reaction of carbon disulfide with isobutylamine. The material product is confirmed by the<sup>13</sup> C nuclear magnetic resonance (chemical shift peak at 212.81 ppm) and mass spectrometry (mass-to-charge ratio [m/z] peaks at about 

> 1Key Laboratory for Renewable Energy, Institute of Physics, Chinese Academy of Sciences, Beijing Key Laboratory for New Energy Materials and Devices, Beijing 100190, China 

> 2Center of Materials Science and Optoelectronics Engineering, University of Chinese Academy of Sciences, Beijing 100049, China 

3Huairou Division, Institute of Physics, Chinese Academy of Sciences, Beijing 101400, China 4Songshan Lake Materials Laboratory, Dongguan 523808, Guangdong, China 5School of Physics Science, University of Chinese Academy of Sciences, Beijing 100049, China 6Lead contact *Correspondence: shijj@iphy.ac.cn (J.S.), dmli@iphy.ac.cn (D.L.), qbmeng@iphy.ac.cn (Q.M.) https://doi.org/10.1016/j.joule.2022.02.003 

Joule 6, 676–689, March 16, 2022 677 

**ll** 

Article 



Figure 1. Device efficiency characterization (A) Molecular structure of iBAI, BA-BDTC, and iBA-iBDTC. 

(B) PCE distribution histograms of the cells with different modifications. 

(C) Detailed performance parameters statistics. 

(D) Current-voltage characteristic curves of the typical cells with or without the iBA-iBDTC modification. (E) Steady-state power output of the control and modified cells for 200 s. 

(F) Quasi-steady-state (QSS) measurement of the champion modified cell. 

221.0, 149.0, and 73.9), as shown in Figures S1 and S2. For comparison, n-butylammonium butyldithiocarbamate (BA-BDTC) and conventional organic ammonium halide iBAI have also been synthesized and used here. 

PSCs with a device configuration of FTO (F: SnO2)/compact TiO2/fullerene derivative/perovskite/spiro-OMeTAD/Au (Figure S3) have been fabricated using these additives. Detailed experimental results regarding the additive concentration optimization and the additive introduction way are given in the supplemental information (Figures S4–S6). The PCE statistic histograms of these cells are shown in Figure 1B. The control cell exhibits an average PCE of 22.2%. When the iBAI was used, the average PCE is increased to 23.2%. Impressively, the introduction of BA-BDTC increases the average PCE to over 23.7% and the average PCE further reaches >24.0% when iBA-iBDTC is used. It is thus demonstrated the -CSS<sup>�</sup> anion has played an important role in improving the cell performance. The statistical distributions of short-circuit current density (JSC), open-circuit voltage (VOC), and fill factor (FF) of the cells are given in Figure 1C. It can be clearly seen that the higher PCE mainly benefits from VOC and FF improvement, implying a significant enhancement in the perovskite quality. 

Current-voltage (I-V) characteristics of the typical cells with or without the iBA-iBDTC modification are presented in Figure 1D. The modified cell exhibits a high PCE of 24.25% (forward scanned PCE: 23.41%) with JSC of 25.73 mA cm<sup>�2</sup> , VOC of 1.141 V, and FF of 0.826, whereas the control cell has a PCE of 22.39% (forward scanned PCE: 20.30%) with JSC of 25.76 mA cm<sup>�2</sup> , VOC of 1.113 V, and FF of 0.781 (Figure S7). 

678 Joule 6, 676–689, March 16, 2022 

**ll** 

##### Article 



Figure 2. Defect characterization of perovskite films and devices (A and B) (A) Time-resolved photoluminescence and (B) derived carrier diffusion length of perovskite films. (C and D) Space charge limited current curves for electron-only devices (C. control perovskite and D. modified perovskite). (E) Voltage-dependent charge collection efficiency (hC) of the cells measured from modulated electrical transient measurements. Error bar: the standard deviation of measured samples. 

(F) Interface defect extraction of the cells by using admittance measurement. 

One of the modified cells has achieved a certified PCE of 23.7% (Figure S8). This cell performance has been among the highest results of the FA-Cs-based PSCs (Tables S1 and S2). Power output measurement of the modified cell for 200 s demonstrates a steady-state PCE of 23.9%; comparatively, the control cell only gives a maximum PCE of 21.4%. We also conducted quasi-steady-state (QSS) I-V measurement of the champion cell after the I-V scanning, and the result is shown in Figures 1F and S11. The current of the cell under a fixed voltage was recorded when the current fluctuation is <0.1%. The QSS-IV gives a PCE of 23.93% with JSC of 25.72 mA cm<sup>�2</sup> , VOC of 1.139 V and FF of 0.817. External quantum efficiency (EQE) spectrum of the modified cell has also been measured (see Figures S9 and S10). EQE of >90% can be achieved over a wide wavelength range from 410 to 740 nm, which finally gives an integral JSC of about 25.15 mA cm<sup>�2</sup> , agreeing well with the I-V result. 

We use optical and electrical characterization to study defect of the perovskite films with and without the iBA-iBDTC modification because it is the most important physics properties that influence the cell performance. From time-resolved photoluminescence (Figure S14), it is found that the charge non-radiative recombination lifetime of the modified film exhibits a three-fold enhancement (Figure 2A). This helps to improve carrier diffusion length of the perovskite film by about two times (Figure 2B), indicating the defect induced charge loss is suppressed when the cell works.<sup>28</sup> Defect density of the film is further measured by using the space charge limited current (SCLC) method on an electron-only device, as depicted in Figures 2C and 2D).<sup>29</sup> With modification, the trap filled limit voltage (VTFL) of the device 

Joule 6, 676–689, March 16, 2022 679 

**ll** 

##### Article 



Figure 3. Interaction between -CSS- anionic group and Pb-I framework (A) Tyndall effect of PbI2 solutions in N,N-Dimethylformamide with different additives. (B) Fourier transform infrared spectra of the iBA-iBDTC and BA-BDTC before and after mixing with PbI2, respectively. (C) Scanning electron microscopy images of perovskite films. Scale bar: 1 mm. The inset presents corresponding grain size distribution. (D and E) X-ray photoelectron spectroscopy (XPS) results of S 2p (D), N 1s, and C 1s (E) for perovskite films. The inset in (D) is the ratio between the two XPS spectra. (F and G) X-ray diffraction (XRD) patterns of PbI2 when reacted with iBA-iBDTC, BA-BDTC, and iBAI under different conditions. 

has been decreased from 2 to <0.6 V, indicating a 3.5-fold reduction in the defect density, from 1.49 3 10<sup>16</sup> to 4.22 3 10<sup>15</sup> cm<sup>�3</sup> . Charge loss of the cell that directly correlates to the photoelectrical conversion process, has been studied by using an electrical transient method.<sup>30</sup> Modulated transient photocurrent and photovoltage of these cells are measured and their decay time is used for calculating the charge collection efficiency (hC). As in Figure 2E, at a voltage of >0.8 V, hC of the modified cell is obviously higher than that of the control cell. This improvement in the hC is the direct reason for the VOC increase of the cell. Interface defect density (NSS) is particularly characterized by using an admittance method, as in Figure 2F,<sup>31</sup> and an eight-fold reduction in the NSS has been observed for the modified device, indicating an obvious interface modification effect exists in the iBA-iBDTC device. 

###### Mechanism discussion 

To uncover the role of the iBA-iBDTC, we have further conducted material and chemistry mechanism studies. Tyndall effect experiment based on light-colloid scattering has been firstly carried out to evaluate possible interactions between CSS<sup>�</sup> 

680 Joule 6, 676–689, March 16, 2022 

**ll** 

##### Article 

and Pb-I clusters (Figures 3A and S15). As in Figure 3A, dissolving 1 M PbI2 in N,Ndimethylformamide (DMF) results in a turbid solution with strong but disordered light scattering, indicating the existence of numerous Pb-I clusters with varied sizes.<sup>12,13</sup> These clusters usually perform as initial nucleation centers in the perovskite deposition process and will influence uniformity of the final film.<sup>32</sup> Currently, it has been widely recognized that decreasing the Pb-I cluster size and disordering degree is necessary for optimizing the perovskite nucleation to facilitate the uniform incorporation of FA and Cs into the Pb-I framework during the nucleation and crystal growth process.<sup>18</sup> This purpose has been well realized by adding iBA-iBDTC or BABDTC into the PbI2 solution, as indicated by the clear solution and much weaker light scattering. In contrast, no such effect can be achieved by using the iBAI additive. This means that long-chain organic ammonium, such as iBA<sup>+</sup> , cannot modify the Pb-I framework in solution, and moreover, CSS<sup>-</sup> anion has a much stronger interaction with the Pb<sup>2+</sup> compared with the I<sup>�</sup> anion. 

This interaction has been further verified by using Fourier transform infrared spectroscopy (FTIR), as presented in Figure 3B. Symmetrical and asymmetric stretching vibrations of CSS<sup>�</sup> (nCSS) in iBA-iBDTC can be seen at 972 and 1,046 cm<sup>�1</sup> , respectively. N–H bending vibration of the NH3+ [dN-H (NH3+)] appears at 1,591 cm�1 and the N-CSS stretching vibration (nN-CSS) can be seen at 1,491 cm<sup>�1</sup> . When mixing with the PbI2, this peak is shifted due to the interaction between CSS<sup>�</sup> and Pb<sup>2+</sup> . dN-H (NH3+) peak is red-shifted by �22 cm�1, indicating that the initial interaction between NH3+ and CSS� in the iBA-iBDTC disappears. nCSS peak is shifted to a lower wavenumber position by �9 cm<sup>�1</sup> , implying that a stronger coordination interaction between the CSS<sup>�</sup> and Pb<sup>2+</sup> group has formed. nN-CSS peak is also shifted to higher wavenumber position. Similar FTIR peak signatures are found for the interaction between BA-BDTC and PbI2. With the iBA-iBDTC modification, nucleation and crystal growth of the perovskite film have been improved with larger grains and denser smoother surface (Figures 3C and S16). X-ray photoemission spectroscopy (XPS) has been employed to study the surface chemistry properties of the perovskite film (Figures 3D, 3E, and S17). It is interesting to find that no sulfur element exists on the modified film surface (Figure 3D), and similar conclusion is also obtained in the bulk film by using Ar<sup>+</sup> -assisted XPS measurement (Figure S18), implying that the iBDTC<sup>-</sup> anion is completely removed after the annealing process. Differently, C/N elemental ratio on the film surface has been obviously increased after the iBA-iBDTC modification (Figure 3E), confirming that some iBA<sup>+</sup> cation has been retained. Besides, only one N 1s peak centered at �400.5 eV assigned to FA<sup>+</sup> is found, whereas no extra shoulder peak at �402.5 eV corresponding to the MA<sup>+</sup> can be detectable although methylammonium chloride (MACl) was used as an additive. Even so, we need to note that, it is really difficult to completely rule out the possibility that a little MA may insert into the perovskite lattice through the FA/MA cation exchange. The MA may have played an important role in helping to remove the iBDTC<sup>�</sup> while retaining the iBA<sup>+</sup> . In high-temperature annealing process, MA<sup>+</sup> and iBDTC<sup>-</sup> can synergistically volatilize by forming volatile CH3NH2 and (CH3)2CHCH2NHCSSH. This process has been further tracking by X-ray diffraction (XRD) of the reaction between iBA-iBDTC and PbI2 under different conditions (Figures 3F, 3G, S19, and S20). At low annealing temperature, the reaction between PbI2 and iBA-iBDTC (or BABDTC) can form a two-dimensional perovskite structure, similar to the iBAI/PbI2 reaction. At relatively high temperature of 150<sup>�</sup> C, no iBA-iBDTC can be retained in the iBA-iBDTC/PbI2 mixed system because of thermal decomposition of iBAiBDTC. However, when MAI is introduced, two-dimensional type perovskite structure can still be formed, implying that the synergistic volatilization of MA-iBDTC 

Joule 6, 676–689, March 16, 2022 681 

**ll** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



Figure 4. Spatial distribution of the iBA+ cationic passivation layer in the perovskite film (A) Surface tension measurement of perovskite films with and without the iBA-iBDTC modification using the OWRK method. (B) Surface contacting potential difference (CPD) distribution of perovskite films measured by Kelvin probe force microscopy (KPFM). (C) Schematic illustration of the film lift-off process for atomic force microscopy (AFM) measurement of both the top and bottom surfaces. (D–G) AFM morphology and corresponding phase images of top and bottom surfaces (D. top surface of control film, E. top surface of modified film, F. bottom surface of control film, and G. bottom surface of modified film). Scale bar: 1 mm. 

could help to stabilize the iBA<sup>+</sup> at the high temperature. Stabilizing the iBA<sup>+</sup> in the film is the key to realize surface passivation. 

We performed surface tension measurement to investigate the influence of iBA<sup>+</sup> cation on the perovskite film, which was realized by using the Owens-Wendt-Rabel-Kaelble (OWRK) method.<sup>33</sup> Contacting angles (q) of four types of liquids on the perovskite film surface were measured; the relationship between the q and the tension properties of these liquid gives the surface tension of the perovskite film (Figures S22 and S23; Table S3). As shown in Figure 4A, the polar component (s<sup>p</sup> ) of the surface tension has been obviously decreased from 36.4 to 22.6 mN m<sup>�1</sup> . Notably, s<sup>p</sup> of the control perovskite has a similar value to that of a FA-MA-based perovskite measured in our previous work.<sup>34</sup> This implies that unmodified perovskite is usually terminated with Pb-I surface and the +1 valent cations, such as FA, MA, and Cs, are deficient there and thus have little influence on the surface properties. The s<sup>p</sup> reduction here means that the perovskite surface dipole polarity has been effectively decreased by the introduction of the -CH(CH3)2 terminal group. Decreasing the surface tension is beneficial for stabilizing the surface atomic or molecular structure, as also indicated by the in-situ contacting angle characterization. Contacting potential difference (CPD) obtained from the Kelvin probe force microscopy (KPFM) also demonstrates that the surface electrical properties of the perovskite has been changed by the iBA<sup>+</sup> incorporation, with higher CPD and more uniform potential distribution (Figures 4B and S21). 

To further probe the iBA<sup>+</sup> , we use atomic force microscopy (AFM) to characterize phase distribution properties of both the top and bottom surfaces of the perovskite film. A film lift-off process was applied to expose and uncover the buried 

682 Joule 6, 676–689, March 16, 2022 

**ll** 

##### Article 



Figure 5. Schematic illustration of the material and chemistry mechanism for regulating the crystallization and defect of the perovskite film by using iBA-iBDTC (A) Interaction between -CSS<sup>�</sup> group and Pb-I framework and the influence on nucleation and crystal growth of perovskite film. (B) Spatial distribution of the iBA<sup>+</sup> passivation layer in the perovskite film. 

bottom surface (Figure 4C, scheme).<sup>35</sup> For these two surfaces, besides the morphology, difference in the AFM phase distribution can be clearly seen (Figures 4D–4G). AFM phase distribution of the top surface of the control film is mainly located at �33<sup>�</sup> ; for the modified film, the AFM phase has been significantly increased to 30<sup>�</sup> and no signatures of the grain boundary can be observed. This indicates that the film surface has been uniformly covered with an iBA<sup>+</sup> layer that has different mechanical properties to the Pb-I-terminated perovskite. For the bottom surface of the control film, the AFM phase is slightly increased to �25<sup>�</sup> with negligible grain boundary signatures, implying that both the top and bottom surface of the pristine perovskite has similar composition and mechanical properties; for the modified film, its internal grains have similar AFM phase to the control perovskite, whereas its grain boundaries have AFM phase at about 27<sup>�</sup> , almost the same as that of the top surface. This result means that the iBA<sup>+</sup> was deeply inserted into the grain boundaries of the perovskite film, reaching the bottom surface and distributing around the grain boundaries. As such, high defective area of the perovskite film, that is, the surface and grain boundary, has been fully passivated by using the iBA-iBDTC additive. 

Material and chemistry mechanism for regulating the perovskite crystallization and defect by using iBA-iBDTC is schematically illustrated in Figure 5. Through interaction between -CSS<sup>�</sup> group and Pb-I framework, large-size Pb-I structures in the precursor film are broken down. The resulting low-density nucleation centers will facilitate the crystal growth of the perovskite film. After that, the iBDTC<sup>�</sup> anion is removed through thermal decomposition and synergistic volatilization with MA. For the retained iBA<sup>+</sup> cation, the -NH3+ terminal group will incorporate into the interval of surface Pb-I octahedrons and uniformly distribute on the film surface and grain boundaries for realizing passivation effect. 

Joule 6, 676–689, March 16, 2022 683 

**ll** 

Article 



Figure 6. Stability and large-area device performance 

(A) PCE tracking of non-encapsulated cells stored in ambient conditions (temperature: 25<sup>�</sup> C, relative humidity: 20%�30%) for 1000 h. 

(B) Operational stability tracking of cells under steady-state light illumination and bias voltage for 500 h (N2 atmosphere, white LED, and uncontrolled temperature). 

(C) Schematic diagram of fabrication of a minimodule comprising four series-connected sub-cells. The P1-P3 scribing is realized using a supercheap fiber laser (1,064 nm). 

(D) Photograph of a minimodule fabricated on 4.5 3 4.5 cm<sup>2</sup> glass substrate. 

(E and F) I-V characteristics of best performed 2.7 cm<sup>2</sup> (E) and 10.4 cm<sup>2</sup> minimodules (F). 

###### Stability and minimodules 

Stability performance of the cells are investigated under different aging conditions. When stored in ambient conditions (temperature: 25<sup>�</sup> C, relative humidity: 20%�30%) after 1,000 h, the iBA-iBDTC modification helped the non-encapsulated cell to retain >95% of its initial PCE (Figure 6A). Detailed parameter variation of these cells is shown in Figures S24–S26. Operational stability is further evaluated by keeping the cell working under continuous light illumination and steady-state bias voltage (MPP of the initial state) without controlling the cell temperature. After 500 h operation, the modified cell can still provide 90% power output of its initial state (Figure 6B). Comparatively, PCE of the control cell has already exhibited fast decline in the first 100 h. This demonstrates that besides efficiency, the iBA-iBDTC modification makes a considerable contribution in enhancing the cell stability. 

Based on the excellent single-cell performance, we have further attempted to enlarge the device area by fabricating minimodules on large-size substrate. Using a conventional series-connected structure, 4.5 3 4.5 cm<sup>2</sup> minimodules comprising four sub-cells were fabricated based on the spin coating method. The fabrication process is schematically shown in Figure 6C. Here, inspired by previous work,<sup>36</sup> the P1-P3 is realized using a supercheap fiber laser (1,064 nm) with galvo scanning. In P2 and P3 steps, laser focus point is set several millimeters beneath the scribed surface (i.e., perovskite and Au film) to eliminate the damage to the FTO layer that is ultrasensitive to the 1,064 nm laser. Photograph of the minimodule is shown in 

684 Joule 6, 676–689, March 16, 2022 

**ll** 

##### Article 

Figure 6D, which has an active area of 10.4 cm<sup>2</sup> . Figure 6E firstly shows the I-V characteristics of a two sub-cell minimodule with an active area of 2.7 cm<sup>2</sup> , which gives a backward scanned PCE of 21.52% (forward PCE: 19.92%). In the four sub-cell minimodule (Figures 6F and S27), a champion backward scanned PCE of 20.64% can be achieved (forward PCE: 19.47%). This indicates that iBA-iBDTC-modified perovskite films indeed exhibit excellent photovoltaic performance. However, compared with the single cell, FF reduction is the main factor to influence the module PCE. If the laser scribing process could be further improved, we believe higher device performance will be obtained in the future. Nevertheless, the PCE of >20.5% has been among the highest results of the perovskite minimodule (>10 cm<sup>2</sup> ), and thus brings more technique opportunities for achieve high performance PSC with low-cost processes. 

###### DISCUSSION 

In this work, we have realized efficient and stable PSC and minimodule by using the iBA-iBDTC to regulate the crystallization and defect of the perovskite film. With the synergistic contribution of the cationic and anionic groups from the iBA-iBDTC, 24.25% PCE (certified PCE: 23.7%) has been achieved in the single PSCs. This has been among the highest results of FA-Cs based PSCs, much superior to the cell only using conventional iBAI passivation. The cell also exhibits excellent operational stability. Under steady-state light illumination and bias voltage, the cell can still provide 90% power output of its initial state after 500 h of continuous operation. After enlarging the device from single cell to module, >20.5% PCE has been achieved from a 10.4 cm<sup>2</sup> minimodule when only using an ultralow-cost laser scribing process technology. Overall, the exploitation of cation-anion synergistic effect of these dualfunctional additives provides more opportunities for promoting the PSC development and commercialization. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources and materials should be directed to and will be fulfilled by the lead contact, Qingbo Meng (qbmeng@iphy.ac.cn). 

###### Materials availability 

This study did not generate new unique materials. 

###### Data and code availability 

This study did not generate or analyze (datasets or code). 

###### Reagents and materials 

PbI2 (99.99%), formamidinium iodide (FAI, 99.5%), formamidinium bromide (FABr, 99.5%) and methylammonium chloride (MACl, 99.5%) were purchased from Xi’an Polymer Light Technology Corp. CsI (99.9%) was obtained from Aldrich. N,N-dimethylformamide (DMF, 99.8%), dimethyl sulphoxide (DMSO, 99.8%), chlorobenzene (CB, 99.9%), and polystyrene (PS) were from Alfa Aesar. Trimethylphenylammonium iodide (TPAI, 99%), n-butylamine (BA, 99.5%), isobutylamine (iBA, 99.5%) and carbon disulfide (CS2, 99.9%) were purchased from Aladdin. n-hexane (98%) was from Innochem. Ethanol (AR) and chloroform (AR) were from Beijing Tong Guang Fine Chemicals Company. 4-tert-butylpyridine (TBP) and bis(trifluoromethane) sulfonimide lithium salt (LiTFSI) were purchased from Sigma-Aldrich, and spiro-OMeTAD was obtained from Luminescence Technology Corp. Tris(2-(1H-pyrazol-1-yl)-4-tertbutylpyridine)-cobalt(III) tris(bis(trifluorom-ethylsulfonyl)imide) (FK209) was from 

Joule 6, 676–689, March 16, 2022 685 

**ll** 

Article 

Dyesol. All the chemicals were directly used without further purification. Laserpatterned FTO glass (sheet resistance of 8.5 U sq<sup>�1</sup> ) was sequentially cleaned with a mild detergent, alkali liquor, distilled water, and ethanol in an ultrasonic bath. The substrate was treated with ozone for 30 min prior to use. 

###### Synthesis of isobutylammonium dithiocarbamate salt (iBA-iBDTC) 

500 mL CS2 and 1,700 mL iBA were put into a round bottom flask and mixed in 5 mL ethanol. The mixture was stirred in ace bath for 2 days. Then, 1 mL n-hexane was added, then centrifugated to afford white solid product. The crude product was recrystallized in ethanol/n-hexane for three times. The final product is white powder with �85% yield. 

iBA-iBDTC:<sup>1</sup> H NMR (500 MHz, CD3OD): 0.96 (d, 6H), 1.04 (d, 6H), 2.04 (m, 2H), 2.86 (d, 1H), 3.33 (s, 1H), 3.39 (d, 2H), 4.96 (s, 4H); 13C NMR (600 MHz, CD3OD): 212.81 (s, 1C), 55.01 (s, 2C-N), 47.25–47.98 (m, 2CH), 27.67 (s, 1CH2), 26.93 (s, 1CH2), 19.25 (s, 2CH3), 18.74 (s, 2CH3). HRMS-MALDI-TOF calcd for C5H10NS2and C4H12N+: 148.1917 and 74.0507, respectively. Found: 149.03285 and 73.92001. 

###### Perovskite film deposition and device fabrication 

Precursor solution for perovskite films was prepared by dissolving 1.736 M PbI2, 1.600 M FAI, 0.048 M FABr, 0.048 M CsI and 0.533 M MACl in DMF/DMSO mixed solvent (v: v = 8.5: 1.5). The precursor solution was stirred for 5 h at room temperature and was filtered before use. The compact TiO2 layer was deposited on the FTO glass with a 0.125 M titanium isopropoxide sol-gel precursor solution by spin coating at 3,000 rpm for 30 s, then sintered at 500<sup>�</sup> C for 1 h. The TiO2 film was subsequently treated with 0.025 M TiCl4 aqueous solution for 35 min, and sintered at 500<sup>�</sup> C for 1 h. [6,6]-phenyl-C61-butyric acid (PCBA, 0.2 mg/mL) and 1.5 mg/mL PS in CB was spin-coated on the top of TiO2 films. Perovskite films were fabricated by anti-solvent single-step spin-coating method. In details, the perovskite precursor solution was spin-coated at 1,000 rpm for 10 s and 5,000 rpm for 30 s, CB (120 mL) was poured onto the substrate at 15 s during the high speed stage. For iBA-iBDTC, iBAI and BA-BDTC treated perovskite films, different concentrations of iBA-iBDTC, iBAI and BA-BDTC were dissolved in perovskite precursor solution, anti-solvent CB, or post-treatment chloroform, respectively. The half-crystallization film was heated at 150<sup>�</sup> C for 10 min in dry air (RH: 20%�30%). After cooling down, 1.3 mg/mL of TPAI in chloroform was spin-coated at 3,000 rpm to passivate the surface of perovskite films. A 200 nm-thick spiroOMeTAD layer was deposited on the top of perovskite films by spin-coating at 3,000 rpm for 30 s, then heated at 60<sup>�</sup> C for 10 min. Spiro-OMeTAD solution was prepared by following the literature. For SCLC devices, 20 mg/mL PCBM in CB was spin-coated on the top of perovskite films at 1,000 rpm for 30 s and then heated at 60<sup>�</sup> C for 10 min. Finally, 80 nm thick Au electrodes were deposited via thermal evaporation at an atmospheric pressure of 10<sup>�7</sup> Torr (Kurt J. Lesker). In all the cell fabrication processes, strictly controlling the quality of perovskite raw materials and carefully optimizing the experimental environments of TiO2, PCBA/PS interface layer and perovskite layer depositions are always necessary for obtaining low-hysteresis solar cells. 

###### Characterizations 

If without special noting, all the measurements were carried in ambient conditions (temperature: 25<sup>�</sup> C, relative humidity: 20%�30%). Current-voltage (I-V) characteristics were measured under AM 1.5 simulated sunlight (100 mW cm<sup>�2</sup> ) from Zolix 

686 Joule 6, 676–689, March 16, 2022 

**ll** 

##### Article 

SS150A after spectral mismatch correction, which was recorded by a digital source meter (Keithley model 2602). The light intensity for the I-V measurements was calibrated (see Figure S12) with a reference silicon cell (provided and certified by the National Institute of Metrology, China (NIM, China) at September 3<sup>th</sup> , 2019). The small-area solar cells were masked with a black mask to determine an aperture of 0.08912 cm<sup>2</sup> (certified by National Institute of Metrology, China) and the area with Au back contact is 0.162 cm<sup>2</sup> . The scanning speed was 50 mV s<sup>�1</sup> with a delay time of 0.3 s (Figure S13). The scanning range is from �50 to 1,200 mV (forward) or from 1,200 to �50 mV (backward). To reduce the hysteresis, the relative humidity of the I-V measurement environment has been reduced to below 15%. The QSS-IV measurement is conducted with the same instrument. Voltage at the cell is fixed by the source meter and the QSS current is continuously traced. The QSS VOC is recorded by a digital voltage meter (fluke 8808A) when it reaches a stabilized value. The EQE spectra were performed by using Enli Technology (Taiwan) EQE system, which was calibrated with a crystalline silicon photovoltaic cell before use. Antireflection coating was used for device performance characterizations, and the corresponding transmittance spectra were given in Figure S10. Steady state and time-resolved transient photoluminescence (PL) spectra were conducted on an Edinburgh fluorescence spectrometer (FLS 920). A 638.2 nm pulsed diode laser (EPL-640, �4 mW cm<sup>�2</sup> , 62 ps, 20 MHz) was used as the excitation source. Modulated transient photocurrent and photovoltage (m-TPC/TPV) measurements were obtained by a tunable nanosecond laser (Opotek, RADIANT 532 LD) pumped at 532 nm and recorded by a sub-nanosecond resolved digital oscilloscope (Tektronix, MDO3034) with input impedances of 50 U or 1 MU, respectively. A signal generator (Tektronix, AFG3052C) together with a low-pass filter was applied to give steadystate bias voltages over the cell. The admittance spectroscopy was conducted on VersaSTAT 3 Electrochemical Workstation of Princeton Applied Research in the dark from 0.1 to 10<sup>6</sup> Hz with 10 mV amplitude and the DC bias was kept at zero. Fourier transform infrared spectra (FTIR) were performed on TENSOR 27 spectrometer, Bruker. The morphology of the samples was observed by using a scanning electron microscope (SEM) from Zeiss Sigma 300. XPS measurement was carried out on an ESCALAB 250Xi (Thermo Fisher) instrument. XRD patterns were measured on a Bruker X-ray diffractometer using Cu Ka as the radiation source. Contact angles were obtained by OCA25, DataPhysics. AFM images and KPFM image were carried out on MultiMode 8 SPM. UV-vis absorption spectra were measured on Shimadzu UV-2550. HRMS-MALDI-TOF was obtained on APEX II FT-ICR-MS.<sup>1</sup> H NMR data (CD3OD) was obtained on Bruker Avance III 500WB and<sup>13</sup> C NMR data were from Bruker Neo 600. 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.02.003. 

###### ACKNOWLEDGMENTS 

This work was supported by Natural Science Foundation of China (No. 51872321, 11874402, 52172260, 52072402, 52102332, 51627803). The authors would like to thank Dr. Jiangyang Shao for his kind help for MS measurement. 

###### AUTHOR CONTRIBUTIONS 

Y. Li, J.S., D.L., and Q.M. conceived the idea. Y. Li did experimental designs, device fabrication, and data analysis. Z.C., B.Y., S.T., and Y.C. participated in the device fabrications and some material and device characterizations. 

Joule 6, 676–689, March 16, 2022 687 

#### **ll** 

Article 

D.L., Y. Luo, and H.W. supported the measurement system construction, device fabrication, characterization, and discussions. Y. Li, J.S., D.L., and Q.M. participated in manuscript writing and revising. J.S. and D.L. polished the manuscript language. All authors were involved in the discussions and approved the manuscript. 

###### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: August 27, 2021 Revised: October 18, 2021 Accepted: February 4, 2022 Published: March 1, 2022 

###### REFERENCES 

1. Kojima, A., Teshima, K., Shirai, Y., and Miyasaka, T. (2009). Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051. 

2. NREL National Center for Photovoltaics (2021). Best research-cell efficiency chart. https:// www.nrel.gov/pv/cell-efficiency.html. 

3. Li, N., Niu, X., Chen, Q., and Zhou, H. (2020). Towards commercialization: the operational stability of perovskite solar cells. Chem. Soc. Rev. 49, 8235–8286. 

4. Shi, J., Li, Y., Li, Y., Li, D., Luo, Y., Wu, H., and Meng, Q. (2018). From ultrafast to ultraslow: Charge-Carrier dynamics of perovskite solar cells. Joule 2, 879–901. 

5. Davies, M.L. (2020). Addressing the stability of lead halide perovskites. Joule 4, 1626– 1627. 

6. Ono, L.K., Qi, Y., and Liu, S.F. (2018). Progress toward stable lead halide perovskite solar cells. Joule 2, 1961–1990. 

7. Meng, L., You, J., and Yang, Y. (2018). Addressing the stability issue of perovskite solar cells for commercial applications. Nat. Commun. 9, 5265. 

8. Turren-Cruz, S.H., Hagfeldt, A., and Saliba, M. (2018). Methylammonium-free, highperformance, and stable perovskite solar cells on a planar architecture. Science 362, 449–453. 

9. Kim, G., Min, H., Lee, K.S., Lee, D.Y., Yoon, S.M., and Seok, S.I. (2020). Impact of strain relaxation on performance of a-formamidinium lead iodide perovskite solar cells. Science 370, 108–112. 

10. Li, N., Luo, Y., Chen, Z., Niu, X., Zhang, X., Lu, J., Kumar, R., Jiang, J., Liu, H., Guo, X., et al. (2020). Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under operational stressors. Joule 4, 1743–1758. 

11. Zhang, F., and Zhu, K. (2020). Additive engineering for efficient and stable perovskite solar cells. Adv. Energy Mater. 10, 1902579. 

12. Yan, K., Long, M., Zhang, T., Wei, Z., Chen, H., Yang, S., and Xu, J. (2015). Hybrid halide perovskite solar cell precursors: colloidal chemistry and coordination engineering behind device processing for high efficiency. J. Am. Chem. Soc. 137, 4460– 4468. 

20. Jeong, J., Kim, M., Seo, J., Lu, H., Ahlawat, P., Mishra, A., Yang, Y., Hope, M.A., Eickemeyer, F.T., Kim, M., et al. (2021). Pseudo-halide anion engineering for a-FAPbI3 perovskite solar cells. Nature 592, 381–385. 

   21. Lu, H., Liu, Y., Ahlawat, P., Mishra, A., Tress, W.R., Eickemeyer, F.T., Yang, Y., Fu, F., Wang, Z., Avalos, C.E., et al. (2020). Vapor-assisted deposition of highly efficient, stable blackphase FAPbI3 perovskite solar cells. Science 370, eabb8985. 

13. Zhang, Y., Liu, Y., Xu, Z., Ye, H., Yang, Z., You, J., Liu, M., He, Y., Kanatzidis, M.G., and Liu, S.F. (2020). Nucleation-controlled growth of superior lead-free perovskite Cs3Bi2I9 singlecrystals for high-performance X-ray detection. Nat. Commun. 11, 2304. 

   22. Lee, J.-W., Kim, H.-S., and Park, N.-G. (2016). Lewis acid�base adduct approach for high efficiency perovskite solar cells. Acc. Chem. Res. 49, 311–319. 

14. Li, Y., Wu, H., Qi, W., Zhou, X., Li, J., Cheng, J., Zhao, Y., Li, Y., and Zhang, X. (2020). Passivation of defects in perovskite solar cell: From a chemistry point of view. Nano Energy 77, 105237. 

   23. Luo, D., Li, X., Dumont, A., Yu, H., and Lu, Z.H. (2021). Recent progress on perovskite surfaces and interfaces in optoelectronic devices. Adv. Mater. 33, e2006004. 

15. Mohd Yusoff, A.R.b., Vasilopoulou, M., Georgiadou, D.G., Palilis, L.C., Abate, A., and Nazeeruddin, M.K. (2021). Passivation and process engineering approaches of halide perovskite films for high efficiency and stability perovskite solar cells. Energy Environ. Sci. 14, 2906–2953.. 

   24. Xue, J., Wang, R., and Yang, Y. (2020). The surface of halide perovskites from Nano to bulk. Nat. Rev. Mater. 5, 809–827. 

- 2906–2953.. 25. Jiang, Q., Zhao, Y., Zhang, X., Yang, X., Chen, Y., Chu, Z., Ye, Q., Li, X., Yin, Z., and 

- 16. Yang, W.S., Noh, J.H., Jeon, N.J., Kim, Y.C., You, J. (2019). Surface passivation of Ryu, S., Seo, J., and Seok, S.I. (2015). SOLAR perovskite film for efficient solar cells. Nat. CELLS. High-performance photovoltaic Photonics 13, 460–466. perovskite layers fabricated through intramolecular exchange. Science 348, 1234– 348, 1234–, 1234– 26. Liu, Y., Akin, S., Hinderhofer, A., Eickemeyer, 1237.. F.T., Zhu, H., Seo, J.-Y., Zhang, J., Schreiber, F., 

- intramolecular exchange. Science 348, 1234– 348, 1234–, 1234– 26. Liu, Y., Akin, S., Hinderhofer, A., Eickemeyer, 1237.. F.T., Zhu, H., Seo, J.-Y., Zhang, J., Schreiber, F., Zhang, H., Zakeeruddin, S.M., et al. (2020). 

- 17. Lee, J.-W., Dai, Z., Lee, C., Lee, H.M., Han, Stabilization of highly efficient and stable T.-H., De Marco, N., Lin, O., Choi, C.S., Dunn, phase-pure FAPbI3 perovskite solar cells by B., Koh, J., et al. (2018). Tuning molecular molecularly tailored 2D-overlayers. Angew. interactions for highly reproducible and Chem. Int. Ed. Engl. 59, 15688–15694. efficient formamidinium perovskite solar cells via adduct approach. J. Am. Chem. Soc. 140, 27. Jeong, M., Choi, I.W., Go, E.M., Cho, Y., Kim, 6317–6324. M., Lee, B., Jeong, S., Jo, Y., Choi, H.W., Lee, J., 

   27. Jeong, M., Choi, I.W., Go, E.M., Cho, Y., Kim, M., Lee, B., Jeong, S., Jo, Y., Choi, H.W., Lee, J., et al. (2020). Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. Science 369, 1615–1620. 

18. Bu, T., Li, J., Li, H., Tian, C., Su, J., Tong, G., Ono, L.K., Wang, C., Lin, Z., Chai, N., et al. (2021). Lead halide–templated crystallization of methylamine-free perovskite for efficient photovoltaic modules. Science 372, 1327– 1332. 

28. Li, Y., Li, Y., Shi, J., Zhang, H., Wu, J., Li, D., Luo, Y., Wu, H., and Meng, Q. (2018). High quality perovskite crystals for efficient film photodetectors induced by hydrolytic insulating oxide substrates. Adv. Funct. Mater. 28, 1705220. 

19. Hui, W., Chao, L., Lu, H., Xia, F., Wei, Q., Su, Z., Niu, T., Tao, L., Du, B., Li, D., et al. (2021). Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. Science 371, 1359–1364. 

29. Liu, Y., Sun, J., Yang, Z., Yang, D., Ren, X., Xu, H., Yang, Z., and Liu, S.F. (2016). 20-mm-large single-crystalline formamidinium-perovskite 

688 Joule 6, 676–689, March 16, 2022 

#### **ll** 

##### Article 

wafer for mass production of integrated photodetectors. Adv. Opt. Mater. 4, 1829– 1837. 

30. Li, Y., Shi, J., Yu, B., Duan, B., Wu, J., Li, H., Li, D., Luo, Y., Wu, H., and Meng, Q. (2020). Exploiting electrical transients to quantify charge loss in solar cells. Joule 4, 472–489. 

31. Wu, J., Shi, J., Li, Y., Li, H., Wu, H., Luo, Y., Li, D., and Meng, Q. (2019). Quantifying the interface defect for the stability origin of perovskite solar cells. Adv. Energy Mater. 9, 1901352. 

32. Tan, S., Shi, J., Yu, B., Zhao, W., Li, Y., Li, Y., Wu, H., Luo, Y., Li, D., and Meng, Q. (2021). Inorganic 

ammonium halide additive strategy for highly efficient and stable CsPbI3 perovskite solar cells. Adv. Funct. Mater. 31, 2010813. 

33. Zhumekenov, A.A., Burlakov, V.M., Saidaminov, M.I., Alofi, A., Haque, M.A., Turedi, B., Davaasuren, B., Dursun, I., Cho, N., El-Zohry, A.M., et al. (2017). The role of surface tension in the crystallization of metal halide perovskites. ACS Energy Lett 2, 1782– 1788. 

34. Li, H., Shi, J., Deng, J., Chen, Z., Li, Y., Zhao, W., Wu, J., Wu, H., Luo, Y., Li, D., and Meng, Q. (2020). Intermolecular p–p Conjugation Self- 

Assembly to Stabilize Surface Passivation of Highly Efficient perovskite Solar Cells. Adv. Mater. 32, e1907396. 

35. Yang, X., Luo, D., Xiang, Y., Zhao, L., Anaya, M., Shen, Y., Wu, J., Yang, W., Chiang, Y.-H., Tu, Y., et al. (2021). Buried interfaces in halide perovskite photovoltaics. Adv. Mater. 33, e2006435. 

36. Rolston, N., Scheideler, W.J., Flick, A.C., Chen, J.P., Elmaraghi, H., Sleugh, A., Zhao, O., Woodhouse, M., and Dauskardt, R.H. (2020). Rapid open-air fabrication of perovskite solar modules. Joule 4, 2675–2692. 

Joule 6, 676–689, March 16, 2022 689 

