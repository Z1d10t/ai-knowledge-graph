# Highly stretchable van der Waals thin films for adaptable and breathable electronic membranes

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 211 |
| 作者 | Zhuo-Cheng Yan, Dong Xu, Zhaoyang Lin, Peiqi Wang, Bocheng Cao, Hua-Ying Ren, F. Song, Cheng-Zhang Wan et al. |
| DOI | 10.1126/science.abl8941 |
| 源文件 | 042_Yan_2022_Highly-stretchable-van-der-Waals-thin-films-for.pdf |

---
RESEARCH 



a percolating network of nanochannels for permeability or breathability. 

### NANOMATERIALS 



# Highly stretchable van der Waals thin films for adaptable and breathable electronic membranes 

### Topological and mechanical limitations of a conformal interface 

Although the flexibility of intrinsically stiff materials (e.g., a silicon wafer or hard cardboard) can be increased in the ultrathin membrane format (e.g., a silicon membrane or paper) (28), stretchability is fundamentally limited by the covalent chemical bonds and barely changes with reduced thickness (29). Owing to intrinsic topological limitations, it is impossible to use such flexible yet unstretchable membranes to make a conformal interface with local topographies with nonzero Gaussian curvatures (e.g., wrapping a piece of paper around a pen; Fig. 1A) (30). To achieve a conformal interface with irregular geometries, stretchability is essential to allow necessary deformation to adapt to the local surface topographies. Specific polymeric materials with intermolecular slippages between polymer chains can be made stretchable (31, 32) and adaptable to local topographies under sufficient tensile stress (e.g., wrapping parafilm around a pen; Fig. 1B) (29). 

Zhuocheng Yan<sup>1</sup> , Dong Xu<sup>2</sup> , Zhaoyang Lin<sup>1</sup> , Peiqi Wang<sup>1</sup> , Bocheng Cao<sup>1</sup> , Huaying Ren<sup>1</sup> , Frank Song<sup>1</sup> , Chengzhang Wan<sup>1</sup> , Laiyuan Wang<sup>2</sup> , Jingxuan Zhou<sup>2</sup> , Xun Zhao<sup>3</sup> , Jun Chen<sup>3</sup> , Yu Huang<sup>2,4</sup> *, Xiangfeng Duan<sup>1,4</sup> * 

The conformal integration of electronic systems with irregular, soft objects is essential for many emerging technologies. We report the design of van der Waals thin films consisting of staggered two-dimensional nanosheets with bond-free van der Waals interfaces. The films feature sliding and rotation degrees of freedom among the staggered nanosheets to ensure mechanical stretchability and malleability, as well as a percolating network of nanochannels to endow permeability and breathability. With an excellent mechanical match to soft biological tissues, the freestanding films can naturally adapt to local surface topographies and seamlessly merge with living organisms with highly conformal interfaces, rendering living organisms with electronic functions, including leaf-gate and skin-gate transistors. On-skin transistors allow high-fidelity monitoring and local amplification of skin potentials and electrophysiological signals. 

he integration of electronic systems with irregular, soft objects is of increasing importance for many emerging technologies, including electronics for the T Internet of Things and bioelectronics for monitoring dynamic living organisms and for diagnosing and treating human diseases in the context of personalized medicine and telehealth (1). A robust bioelectronic system requires intimate interaction with biological structures to perform specific operations, such as biological signal recording (2–4), amplification (5–7), and extraction (8), as well as delivering electrical (9, 10) or chemical stimulation (11). Thus, the implementation of bioelectronics hinges on a number of unusual material and device characteristics, including electronic performance; mechanical flexibility, stretchability, or malleability to ensure conformal and adaptable interfaces with dynamically evolving microscopic surface topographies; and permeability or breathability for gas and/or nutrient exchange between living organisms and their surroundings to lessen perturbation of natural biofunctions. 

irregular geometries with nonzero Gaussian curvatures owing to their fundamental topological limitations (12). The development of specifically designed deformation-tolerant structures, such as wrinkled (13), buckled (14), waved (15), or serpentine structures (16–18), bring macroscopic stretchability but not microscopic conformability, because of the intrinsic microscopic structural undulation. Organic or composite semiconductor thin films can be made stretchable or conformal (19) but usually exhibit insufficient electronic performance (12, 20) or limited stability in a typical wet biological environment. 

To achieve a conformal interface with a stretchable membrane, external pressure is needed to induce sufficient deformation to match the local surface topography, which results in a contact pressure that can cause tissue deformation or damage (e.g., tightly wrapping parafilm around a fingertip). A 3D geometric model is constructed to visualize the conformal adapting process of a stretchable membrane on spherical topographies and to explore the evolution of the local deformation with the contact pressure (Fig. 1C). With increasing load, the membrane gradually adapts to the spherical indentations, with the membrane grid stretched and expanded to accommodate the local strain and deformation during the conformal adapting process. 

Additionally,traditionalinorganicmembranes or organic thin films typically exhibit limited mechanical robustness in the ultrathin freestanding format and require a polymer [e.g., polydimethylsiloxane (PDMS) and polyimide (PI)] substrate support to retain structural integrity (12) and specific porous architecture design to achieve breathability (21). The polymer substrate is typically much thicker (≫1 mm) than a cell membrane (~10 nm), with a large bending stiffness (22) and poor conformability and adaptability to the dynamically evolving biological structures (23). 

We use a simplified spherical indentation model to evaluate the maximum contact pressure needed for forming a conformal interface with a surface topography of a given curvature. The indentation strain, e, is given by 

Conventional hard electronic materials exhibit an intrinsic mismatch with soft biological tissues in terms of electrical conductivity, mechanical response, permeability, and environmental adaptability. Hard inorganic semiconductors can be made flexible in an ultrathin membrane format but are barely stretchable and cannot form a conformal interface with 

Inspired by van der Waals (VDW) interactions in biological assemblies, we exploited these interactions to assemble two-dimensional (2D) nanosheets (24–27) into freestanding VDW 



<!-- Start of picture text -->
rcontact<br>e ¼ k ð1Þ<br>rcurve<br><!-- End of picture text -->

thin films (VDWTFs) with an excellent mechanical match to soft biological tissues that can directly adapt to and merge with living organisms with ultraconformal and breathable membrane–tissue interfaces. The VDWTFs feature bond-free VDW interfaces between the staggered 2D nanosheets, opening sliding and rotation degrees of freedom between neighboring nanosheets to endow unusual mechanical flexibility, stretchability, and malleability. The staggered VDWTFs also feature 

where rcontact and rcurve are the contact radius and the topography radius, respectively (Fig. 1D), and k is a constant associated with indentation strain (33). Overall, the contact radius and indentation strain increase with increasing load until a conformal interface between the membrane and the hemisphere is achieved. The maximum contact pressure needed for achieving a conformal interface is determined 

> 1Department of Chemistry and Biochemistry, University of California, Los Angeles, CA 90095, USA.<sup>2</sup> Department of Materials Science and Engineering, University of California, Los Angeles, CA 90095, USA.<sup>3</sup> Department of Bioengineering, University of California, Los Angeles, CA 90095, USA.<sup>4</sup> California NanoSystems Institute, University of California, Los Angeles, CA 90095, USA. *Corresponding author. Email: xduan@chem.ucla.edu (X.D.); yhuang@seas.ucla.edu (Y.H.) 

1 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B C<br>D E F<br>G H<br>1. Conceptual comparison of unstretchable and stretchable membranes. F) Contour maps showing the relationship between plane-strain modulus, film) Contour maps showing the relationship between plane-strain modulus, film<br>and B)) Illustrations showing the wrapping of a piece of (A) unstretchable and thickness, and (E) contact radius at a contact pressure of 1 kPa or (F) maximum<br>stretchable membrane around a pen. (C) Illustrations showing stretchableC) Illustrations showing stretchable) Illustrations showing stretchable contact pressure for a contact radius of 5 mm, highlighting that reducing thickness and mm, highlighting that reducing thickness andm, highlighting that reducing thickness and<br>membranes with grid lines gradually conforming to a curved surface topography. plane-strain modulus favors a conformal interface. (G and H) Schematic diagramG and H) Schematic diagram and H) Schematic diagram H) Schematic diagram) Schematic diagram<br>) Diagram of a spherical indentation model and relevant parameters. (E andE and and of (G) VDWTFs and (H) CVDTFs before and after stretching.<br>by the Young’s modulus and the membrane’s modulus and the membranes modulus and the membrane PDMS (37), and 2.8 GPa for polyimide (22). interface with a given rcurve of 5 mm for mate- rcurve of 5 mm for mate-curve of 5 mm for mate- of 5 mm for mate- mm for mate-m for mate-<br>thickness following the relationship The difference in plane-strain modulus illus- rials with a different plane-strain modulus<br>trates the large mechanical mismatch between and thickness (Fig. 1F).<br>human skin and the soft polymeric elastomer These analyses highlight that the contact<br>p 2 0 1 � v 2 1 þ 1 � v 2 2 þ or typical plastics. pressure needed to achieve a conformal inter-<br>" 4 P2 � E1 E2 �2#1=3 Using Eqs. 1 and 2, we can calculate the face is proportional to the Young’s modulus’s moduluss modulus<br>maximum film thickness allowed to achieve a and thickness of the membrane and inversely<br>p 2 1 � v 2 1 rcurve 3 ¼ 1 ð2Þ conformal interface with a topography of a giv- proportional to the curvature of the radius of<br>8 P0 � E1 � t 3 en rcurve under a certain contact pressure for rcurve under a certain contact pressure forcurve under a certain contact pressure for under a certain contact pressure for the surface topography. Although, in principle,<br><!-- End of picture text -->

F) Contour maps showing the relationship between plane-strain modulus, film) Contour maps showing the relationship between plane-strain modulus, film thickness, and (E) contact radius at a contact pressure of 1 kPa or (F) maximum contact pressure for a contact radius of 5 mm, highlighting that reducing thickness and mm, highlighting that reducing thickness andm, highlighting that reducing thickness and plane-strain modulus favors a conformal interface. (G and H) Schematic diagramG and H) Schematic diagram and H) Schematic diagram H) Schematic diagram) Schematic diagram of (G) VDWTFs and (H) CVDTFs before and after stretching. 

Fig. 1. Conceptual comparison of unstretchable and stretchable membranes. (A and B)) Illustrations showing the wrapping of a piece of (A) unstretchable and (B) stretchable membrane around a pen. (C) Illustrations showing stretchableC) Illustrations showing stretchable) Illustrations showing stretchable membranes with grid lines gradually conforming to a curved surface topography. (D) Diagram of a spherical indentation model and relevant parameters. (E andE and and 

by the Young’s modulus and the membrane’s modulus and the membranes modulus and the membrane thickness following the relationship 

interface with a given rcurve of 5 mm for mate- rcurve of 5 mm for mate-curve of 5 mm for mate- of 5 mm for mate- mm for mate-m for materials with a different plane-strain modulus and thickness (Fig. 1F). 

These analyses highlight that the contact pressure needed to achieve a conformal interface is proportional to the Young’s modulus’s moduluss modulus and thickness of the membrane and inversely proportional to the curvature of the radius of the surface topography. Although, in principle, the contact pressure on biological tissue can be minimized by reducing membrane thickness, the thickness cannot be reduced indefinitely for most polymeric materials owing to the limitation of the characteristic size of individual polymer chains and a precipitous decrease in mechanical properties below a critical thickness (e.g., 25 nm) (23). Conducting polymers that are suitable for electronic 

Using Eqs. 1 and 2, we can calculate the maximum film thickness allowed to achieve a conformal interface with a topography of a given rcurve under a certain contact pressure for rcurve under a certain contact pressure forcurve under a certain contact pressure for under a certain contact pressure for materials with a different plane-strain modulus (Fig. 1E). For example, to achieve a conformal interface with a skin topography of rcurve ~ 5 mm under a maximum contact pressure P0 of 1 kPa (the gentlest touch that a human can feel is 1 kPa) (38), the maximum allowed thickness is 0.3 mm for PDMS and 39 nm for polyimide. Similarly, we can also calculate the maximum contact pressure needed to form a conformal 

where P0 is the maximum contact pressure; E1 and v1 are the Young’s modulus and Poisson’s ratio of the membrane, respectively; t is the membrane thickness; and E2 and v2 are the Young’s modulus and Poisson’s ratio of the sphere, respectively (34, 35). The E/(1 − v<sup>2</sup> ) is regarded as the plane-strain modulus, which is 130 kPa for human skin (36), 4 MPa for 

2 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 



freestanding format. The mechanical deformation of VDWTFs is readily transformed into intersheet sliding or rotation to accommodate local strains and deformations and overcome topological limitations, thus endowing exceptional malleability and adaptability to irregular and dynamically changing surface topographies. Lastly, the VDWTFs feature a percolating network of nanochannels (dictated by nanosheet thickness: ~3 nm) winding around the staggered nanosheets for gas and/or nutrient permeation, which is critical for the breathability of bioelectronics (movie S2). 

applications usually show worse mechanical properties owing to their specific structural properties, such as chain length, regioregularity, and degree of polymerization. 

covalent bonding within the grains and disordered bonds at the grain boundaries of the CVDTFs (marked with red arrows in Fig. 1H) can result in the formation of cracks and ruptures that propagate along the grain boundaries when they are deformed, thereby causing mechanical fragmentation and electronic disintegration under minimal strain (movie S1). 

### Adaptable and breathable VDWTFs 

In our design of VDWTFs (Fig. 1G), the dangling bond–free nanosheets are staggered butted up against each other to establish broad-area plane-to-plane VDW contacts with minimum interfacial trapping states to ensure excellent charge transport across the intersheet grain boundaries. With the bond-free VDW interactions between the nanosheets, the VDWTFs offer a natural mechanical match to soft biological assemblies typically characterized by VDW interactions. When deformed, the bonding-free VDW interfaces allow nanosheets to slide or rotate against each other to accommodate the local tension or compression without breaking the broad-area VDW interfaces and conductive pathways (movie S1), which is essential for achieving unusual stretchability and structural stability in the ultrathin 

### Structural and mechanical properties of VDWTFs 

Molybdenum disulfide (MoS2) nanosheet ink was prepared using an intercalation-exfoliation process and assembled into VDWTFs using a spin coating process (see supplementary materials). Scanning electron microscopy (SEM) and transmission electron microscopy (TEM) studies show a staggered nanosheet thin film (Fig. 2, A and B) with an overall film thickness of ~10 nm (fig. S1A). The MoS2 nanosheets, with a thickness of ~3 nm and lateral dimensions ranging from less than one to several micrometers, are staggered butted up against each 

This combination of electronic and mechanical properties originates from the VDW interactions among the staggered 2D nanosheets and is difficult to achieve in typical chemical vapor deposition–grown thin films (CVDTFs) (Fig. 1H). The electrical and mechanical properties of CVDTFs—with their typical polycrystalline structure consisting of laterally stitched domains—are strongly influenced by the grain size, grain orientation, shape, and density of grain boundary defects. The stiff and strong 



<!-- Start of picture text -->
A B C D<br>E F G<br>H I J K<br>L M N<br>Downloaded from https://www.science.org at Xi'an Jiaotong University on November 22, 2026<br><!-- End of picture text -->

Fig. 2. Material characteristics of VDWTFs and CVDTFs. (A) SEM and (B) TEM images showing VDWTFs assembled from staggered 2D nanosheets. (C and D) Photograph of the (C) VDWTFs and (D) CVDTFs floating on water. (E) Stress–strain curve of a freestanding VDWTF. Tensile loads cause 2D nanosheets in VDWTFs to slide or rotate against each other, resulting in unusual stretchability. (F) Photographs of the VDWTF at different tensile strains. (G) Resistance–strain curve of the VDWTF and CVDTF on a PDMS substrate. (H to K) SEM images showing the contact interface between the 4.3-mm-diameter silica microspheres of different configurations with [(H) and (I)] VDWTFs or [(J) and (K)] CVDTFs. Scale bars, 2 mm. (L) Water contact angles of a VDWTF (top) and a CVDTF (bottom). (M) Optical micrographs of a VDWTF suspended over a polyimide substrate with circular holes, confirming structural robustness of the freestanding VDWTFs. (N) Water vapor transmission through VDWTFs of different thickness versus transepidermal water loss (TEWL). See the supplementary materials for a description of the “open bottle” and “closed bottle” conditions. 

3 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 



other to form broad-area plane-to-plane VDW interfaces with an average of ~3 to 4 nanosheets staggered in a crisscross manner in the vertical direction. The broad-area bond-free VDW interfaces allow adjacent nanosheets to slide or rotate against each other to accommodate local structural perturbation and reduce the strain-induced cracks and fractures, thus ensuring structural integrity even in the freestanding format. For example, the continuous freestanding VDWTFs can be readily floated on water (Fig. 2C and movie S3), completely folded repeatedly without tearing (movie S4), and suspended over open holes without rupturing (Fig. 2M). In comparison, the freestanding polycrystalline CVDTFs (fig. S1B) easily fragment on water (Fig. 2D and movie S3) and are too fragile to suspend over open holes (fig. S2). 

complete compliance, as confirmed by the optical microscopy (Fig. 3D) and SEM studies (Fig. 3E). 

(4.3-mm-diameter) arrays (Fig. 2H) but also the isolated single microspheres, two- or threemicrosphere clusters (Fig. 2I), conformally wrapping around the microspheres without tearing. By comparison, the CVDTFs on the same surface topography are much less conformal and show abundant microcracks (Fig. 2, J and K), particularly at the high strain or stress concentration region (e.g., the foot of the microspheres or the space between two adjacent microspheres). 





The function of the leaf-gate transistor relies on the ionic gating effect (in the electrolyte of the leaf gate) to modulate the electronic properties of the VDWTFs, for which the microscopically conformal interface is essential for efficient gating. The leaf-gate transistor shows a typical n-channel transfer curve with an on/off ratio of ~100 (Fig. 3, F to H). The relatively low on/off ratio is limited by the direct leakage into the transistor channel from the leaf gate through direct resistive coupling. With a highly conformal interface and efficient gate coupling, the leaf-gate transistor can operate at a low operating voltage amenable to biological systems. 

Surface wettability is essential for ensuring proper adhesion between electronic membranes and living organisms (Fig. 2L). With abundant edge structures in individual nanosheet building blocks, the VDWTFs exhibit better wettability (with a water contact angle of 40.2°) than CVDTFs (water contact angle of 76.3°), which is desirable for intimately interfacing with wet biological tissues. 

### Skin-gate VDWTF transistors 

The stress–strain curve of the freestanding VDWTFs shows a well-behaved linear relationship up to a tensile strain of 43% (Fig. 2E), with a Young’s modulus (~47.3 MPa) about three orders of magnitude smaller than that of bulk MoS2 (~200 GPa). The greatly reduced modulus indicates that the film deformation is transformed into interlayer sliding or rotation among nanosheets rather than an intrinsic lattice expansion (Fig. 2F). Beyond the linear regime, the stress shows little increase with further increasing of the tensile strain to ~62%, indicating that interlayer sliding or rotation gradually reaches the limit and begins to initiate local rupture, which further aggravates at higher tensile strain and leads to complete rupture at a tensile strain of >120%. 

VDWTFs can be transferred onto human skin with a highly conformal interface to form skingate transistors (fig. S4). In the skin, electrolytes help conduct electricity, regulate pH levels, and keep the body’s hydration system in check. The conformal integration of VDWTFs with the skin textures (fig. S5, A to C) results in skin-gate transistors in which the electrolyte in human skin effectively modulates the conduction in VDWTFs (Fig. 4, A and B). Proper skin-gate transistor function requires a conformal interface with an intimate interaction between the VDWTF channel and the epidermis, in which the epidermis can be modeled by a parallel circuit consisting of a capacitor and a resistor, and the dermis and underlying subcutaneous tissues modeled by a resistor (Fig. 4B). 

Lastly, membrane permeability or breathability is required for gas or nutrient exchange with the environment in bioelectronic applications. Water vapor transmission studies (see supplementary materials) reveal water vapor transmission rates of 34 and 26 mg cm<sup>−2</sup> hour<sup>−1</sup> for the 10-nm-thick and 30-nm-thick freestanding VDWTFs, respectively, suspended over an open hole (Fig. 2, M and N), about six to eight times higher than the typical transepidermal water loss (TEWL) rate (4.4 mg cm<sup>−2</sup> hour<sup>−1</sup> ) (39). Such permeability of the continuous VDWTFs is attributed to the staggered nanosheet structures, with a highly interconnected network of nanochannels (with the channel thickness dictated by the nanosheet thickness: ~3 nm) winding around the staggered nanosheets (movie S2). 

We compared the electronic properties of the VDWTFs and CVDTFs as a function of the applied strain (Fig. 2G). Because CVDTFs cannot maintain macroscopic structural integrity in the freestanding form, the measurement was done on films supported on PDMS substrates to ensure a robust comparison. For CVDTFs, the relative resistance exhibits a gradual linear increase at a tensile strain of <2.5%, followed by a steep increase beyond 2.5%, indicating that the CVDTFs start to macroscopically break apart. In contrast, the VDWTFs do not exhibit a rapid resistance increase until a tensile strain of >55%, with a stable recoverable resistance under repeated strain cycles (fig. S3). When the tensile strain is >55%, the resistance increases sharply, indicating the formation of microscopic cracks and substantially reduced conductive pathways. 

We investigated the conformability of the freestanding VDWTFs on a forearm skin replica made of Ecoflex silicone rubber and compared it with the same VDWTF supported on a 1.6-mm-thick PI substrate (Fig. 4C). The freestanding VDWTF adapts to the skin textures and makes an excellent conformal interface without apparent cracking or tearing. In contrast, the 1.6-mm-thick PI substrate and the VDWTF with the PI substrate show much less conformal contact, with most of the fine skin textures, such as the surface wrinkles and pits, hidden (Fig. 4C, right side). A profilometry height profile analysis shows that surface topography of the skin replica covered with the freestanding VDWTF is essentially the same as that without the VDWTF (Fig. 4, D and E), suggesting a fully conformal interface. In contrast, for the area covered with the VDWTF supported by the 1.6-mm-thick PI substrate (Fig. 4, F and G), the surface topography is largely flattened, suggesting that the 1.6-mm-thick PI substrate is already too thick to naturally adapt to the skin textures to form microscopically conformal interfaces. 

### Leaf-gate VDWTF transistors 

Given their exceptional stretchability, conformability, and breathability, the VDWTFs can directly merge with living organisms to form seamless electronic-bio hybrids. Whereas previous attempts sought to augment plant function with electroactive materials or to simply use the plant as an unconventional supporting substrate, our approach was to transfer the VDWTFs onto a leaf to form a leaf-gate transistor, in which the plant leaf functions as a modulating gate and constitutes an active part of the device. We chose the Senecio mandraliscae leaf (Fig. 3A), which contains abundant electrolyte in mesophyll, as a model system to study the leaf-gate transistors. For the leaf-gate transistor operations (Fig. 3B), the VDWTF channel is contacted with serpentine-mesh Au electrodes (Fig. 3C, top) to prevent breaking of the Au thin-film electrodes by local strain on the rough leaf surface, while an inserted tungsten probe establishes electrical contact to the electrolyte within the leaf to form the gate electrode. The transferred VDWTFs form a highly conformal interface with 

### Adaptability, wettability, and permeability of VDWTFs 

We evaluated the adaptability and conformability of the VDWTFs to microscopic surface topographies. SEM studies revealed that the VDWTFs exhibit highly conformal interfaces with not only the microsphere 

4 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B<br>C D E<br>F G H<br>The ability of a membrane to make a con- The VDWTFs transferred onto human skin 100% surface<br>formal interface with the surface topography show excellent natural adaptability to changing<br>can be determined by bending stiffness (22).22).). skin textures and retain conformal contact<br>The effective bending stiffness (EI) for a multi-EI) for a multi-) for a multi- without apparent fracturing or flaking through-<br>layer membrane can be described as out stretching, squeezing, and relaxing cycles transistor<br>(Fig. 4H), highlighting the highly adaptable<br>EI ¼ XiN¼1 1 �Eiv 2 i h i( 31 h i 2 þ " Xj¼i 1 hj! � nature of the VDWTFs to dynamically evolvingbiological substrates. In contrast, the CVDTFs<br>transferred onto human skin easily fracture<br>i and flake off when the skin is subjected to<br>hneutral � hi X hj � hneutral ð3Þ similar deformation. Figure 4I shows the re-<br>#2 " j¼1 ! #) maining area of both films on the skin replica physiological<br>versus the number of squeezing-and-stretching<br>cycles. Because the freestanding CVDTFs are<br>Ei � 1 not strong enough for processing and transfer-<br>hneutral ¼ XNi¼1 1 � v 2 i hi��Xij¼1 hj � 2 hi � ring, they are transferred onto the skin replica<br>Ei with methyl methacrylate (MMA) support.<br>X Ni¼1 1 � v 2 i hi After the transfer process, the CVDTFs quickly<br><!-- End of picture text -->

Fig. 3. Leaf-gate VDWTF transistors. (A) Diagram of a Senecio mandraliscae leaf. (B) Cross-sectional view of the leaf-gate transistor with Au source and drain electrodes (“S” and “D,” respectively) and an inserted tungsten gate electrode (“G”). (C) Schematic illustration (top; leaf, light green; VDWTF, dark green; Au electrodes, yellow; tungsten probe, black dot) and photograph of the leaf-gate transistor (bottom). (D) Optical image of a VDWTF with serpentine Au electrodes transferred onto the plant leaf. (E) Colorized SEM image of the VDWTF on the leaf. (F) Output characteristics of a leaf-gate transistor. Vds, drainsource voltage; Ids, drain-source current. (G and H) Transfer curves with (G) linear and (H) logarithmic axis. Vg, gate voltage. 

The ability of a membrane to make a conformal interface with the surface topography can be determined by bending stiffness (22).22).). The effective bending stiffness (EI) for a multi-EI) for a multi-) for a multilayer membrane can be described as 

The VDWTFs transferred onto human skin show excellent natural adaptability to changing skin textures and retain conformal contact without apparent fracturing or flaking throughout stretching, squeezing, and relaxing cycles (Fig. 4H), highlighting the highly adaptable nature of the VDWTFs to dynamically evolvingbiological substrates. In contrast, the CVDTFs biological substrates. In contrast, the CVDTFs transferred onto human skin easily fracture and flake off when the skin is subjected to similar deformation. Figure 4I shows the remaining area of both films on the skin replica versus the number of squeezing-and-stretching cycles. Because the freestanding CVDTFs are not strong enough for processing and transferring, they are transferred onto the skin replica with methyl methacrylate (MMA) support. After the transfer process, the CVDTFs quickly flake off once the MMA is dissolved away with acetone vapor. The remaining area instantly decreases to ~50% of the original area and, after 100 stretching cycles, further decreases to 40% of the original area, with mostly fractured domains. The fracturing and flaking are attributed to the unstable membrane–skin interface, which is associated with their limited stretchability, conformability, and poor wettability. In contrast, the VDWTFs show superior stretchability and conformability to the dynamically changing skin replica with no apparent fracturing or flaking, retaining essentially 

100% surface coverage after the repeated squeezing-and-stretching cycles. 

The output and transfer curves of the skingate VDWTF transistor demonstrate expected transistor functions (Fig. 4, J and K) with a low operating voltage suitable for biological systems. Furthermore, the skin-gate VDWTF transistor can maintain stable operation while undergoing various mechanical deformations (Fig. 4L), establishing a foundation for applications in probing and amplifying electrophysiological signals. 

### Monitoring electrophysiological signals with skin-gate VDWTF transistors 

Given that many biopotential signals show transient responses, we have evaluated the frequency response of the skin-gate transistors. The response times, t, of the skin-gate transistors are probed by measuring the current response under a 20-ms pulse of 100-mV gate voltage (Fig. 5A). A response time of 7 ms is achieved by fitting experimental data with an exponential function (Fig. 5B). Furthermore, the skin-gate transistors show a cut-off frequency (at which the transconductance drops by 3 dB from its plateau value) of ~100 kHz (Fig. 5C), which is sufficient for monitoring most electrophysiological signals from the human body. 



<!-- Start of picture text -->
ð4Þ<br><!-- End of picture text -->

where hneutral denotes the neutral mechanical plane; i represents the ith layer of the film; hi, Ei, and vi represent the thickness, the elastic modulus, and Poisson’s ratio, respectively; and N is the number of layers (40). Notably, with its ultrasmall thickness and low elastic modulus, the freestanding 10-nm-thick VDWTF exhibits a bending stiffness of 4.2 × 10<sup>−9</sup> GPa·mm<sup>3</sup> , which is about eight orders of magnitude smaller than that of the 1.6-mmthick VDWTF/PI film (0.97 GPa·mm<sup>3</sup> ). 

We explored the skin-gate VDWTF transistors for monitoring electrocardiography (ECG). 

5 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B<br>C D F<br>E G<br>H I<br>J K L<br><!-- End of picture text -->

Fig. 4. Skin-gate VDWTF 

transistors. (A) The structure of human skin. (B) Schematic of a skin-gate VDWTF transistor with Au source and drain electrodes and an iron rod gate electrode held by a human subject. (C) Photograph of the freestanding VDWTF on a replica of human skin (left) and the VDWTF supported by a 1.6-mm-thick polyimide substrate on a replica of human skin (right). (D to G) Height profiles corresponding to the line scan in different areas of (C). (H) Skingate VDWTF transistor on human skin under different types of mechanical deformation. (I) Remaining area of VDWTFs and CVDTFs on skin replicas as a function of stretching cycles (10% tensile strain). Scale bars, 2 mm. (J) Output and (K) transfer curves of a skin-gate VDWTF transistor. (L) Transfer curves under different types of deformation. 

during human motion (Fig. 5, F and G). With reduced motion artifacts, the ECG signals recorded by the skin-gate transistors (red line) show clear P, QRS, and T waves, with no abnormal deviations and relatively stable baseline during human motion (Fig. 5, F and G). In contrast, such fine signals are less resolvable by the Ag/AgCl electrodes (Fig. 5G). 

In this measurement, the VDWTF pad is placed on the left forearm and the gate electrode is adhered on the symmetrical position (right forearm) (Fig. 5D), and each VDWTF pad works with an Ag/AgCl electrode nearby for comparison. Among the common challenges in measuring ECG with conventional Ag/AgCl electrodes are the motion artifacts due to sliding, inconsistent adhesion, and a mechanical mismatch at the electrode–skin interface induced by skin deformation, leading to a greatly reduced signal-to-noise ratio (SNR), from 44.3 dB before motion (Fig. 5E) down to 28.5 dB during motion (Fig. 5, F and G). With the conformal skin-gate transistors, motion artifacts are mitigated, achieving an essentially comparable SNR of 49.8 dB before human motion (Fig. 5E and fig. S6) and 49.2 dB 

the ability to acquire high-quality neurophysiological signals, we placed the VDWTF transistor over the left side of the forehead (Fp1) according to the international 10-20 system of EEG electrode placement (17) and recorded voltage differences relative to a reference electrode placed over the left occipital region (O1) (Fig. 5H). When the human subject is relaxed with eyes closed, the EEG background is usually characterized by the posteriorly dominant alpha rhythm (posterior dominant rhythm) with a prominent 8- to 12-Hz (alpha) oscillation (Fig. 5, I and J), corresponding to brain activities such as meditation and mindfulness that can reduce stress levels. The alpha rhythm typically attenuates considerably upon eye opening, as clearly seen in the spectrogram of the EEG 

High-fidelity, real-time electroencephalogram (EEG) recording is important for monitoring cerebral activities, studying cognitive behaviors, and developing insights into various neurological disorders. Cerebral activities can be divided into five frequency bands: delta wave (0 to 4 Hz), theta wave (4 to 8 Hz), alpha wave (8 to 12 Hz), beta wave (12 to 30 Hz), and gamma wave (>30 Hz), with each frequency band associated with different mental states. To test 

6 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B C<br>D E G<br>F<br>H I K<br>J<br><!-- End of picture text -->

in (F), showing clear P, QRS, and T waves from the skin-gate transistor but only a QRS wave and motion artifacts from the Ag/AgCl electrodes. (H) Schematic diagram of the EEG measurement. (I) Recorded EEG signals using a skin-gate transistor when a human subject was engaged in two mental states (closed eyes and open eyes). Eye blink artifacts are also visible. (J) Fast Fourier transform (FFT)–processed frequency distributions of the EEG signals in (I). (K) Time-frequency spectrograms of the EEG signals recorded during cyclic eye closing and opening, showing dynamic activity of the alpha rhythm at ~10 Hz. 

Fig. 5. Skin-gate VDWTF transistors for monitoring transient skin potentials. (A) Relative drain current (DIds) of a skin-gate VDWTF transistor stimulated by 5 kHz 0.1-V 20-ms-wide gate pulses at a Vds of 0.1 V. (B) The response time of the skin-gate VDWTF transistor to a square gate pulse (blue dashed line). (C) Normalized transconductance at various frequencies. (D) Schematic diagram of the ECG measurement with a Vds of 0.5 V and a Vg of 0.5 V. (E and F) The ECG signals measured by the skin-gate transistor (red line) and Ag/AgCl electrode (black line) (E) before and (F) during human exercise. a.u., arbitrary units. (G) Zoomed-in view of boxed portion 

signal measured by the skin-gate transistor (Fig. 5K), showing the dynamic activity of the alpha rhythm coupled with cyclic eye closing and opening. 

and directly integrating with living organisms through highly conformal interfaces, endowing living organisms with electronic functions. The VDWTFs can thus function as versatile electronic membranes that actively adapt to the environment while retaining sufficient electronic performance for sensing, signal amplification, processing, and communication. 

12. J. A. Rogers, R. Ghaffari, D.-H. Kim, Eds., Stretchable Bioelectronics for Medical Devices and Systems (Springer, 2016). 13. S. H. Chae et al., Nat. Mater. 12, 403–409 (2013). 

14. J. Yoon et al., Nat. Mater. 7, 907–915 (2008). 

15. D.-Y. Khang, H. Jiang, Y. Huang, J. A. Rogers, Science 311, 208–212 (2006). 

### Conclusions 

16. D.-H. Kim et al., Science 333, 838–843 (2011). 

17. L. Tian et al., Nat. Biomed. Eng. 3, 194–205 (2019). 

Here, we report on mechanically robust freestanding VDWTFs assembled from 2D nanosheets for highly stretchable, adaptable, conformal, and breathable membrane electronics. The bond-free VDW interfaces among the nanosheets enable sliding and rotating degrees of freedom to render extraordinary mechanical flexibility, stretchability, and malleability. The staggered nanosheet architecture also features a percolation network of nanochannels for excellent permeability or breathability. The ultrathin freestanding VDWTFs are structurally robust with an excellent mechanical match to soft biological tissues, naturally adapting to microscopic topographies 

18. Z. Huang et al., Nat. Electron. 1, 473–480 (2018). 

19. J. Rivnay et al., Nat. Rev. Mater. 3, 17086 (2018). 

20. Y. Fang, X. Li, Y. Fang, J. Mater. Chem. C 3, 6424–6430 (2015). 

21. L. Cai et al., Nat. Commun. 8, 496 (2017). 

22. Z. Yan et al., Adv. Sci. 4, 1700251 (2017). 

##### REFERENCES AND NOTES 

   23. Y. Liu et al., Macromolecules 48, 6534–6540 (2015). 

   24. J. N. Coleman et al., Science 331, 568–571 (2011). 

1. G. D. Spyropoulos, J. N. Gelinas, D. Khodagholy, Sci. Adv. 5, eaau7378 (2019). 

25. Z. Lin et al., Nature 562, 254–258 (2018). 

26. Z. Lin, Y. Huang, X. Duan, Nat. Electron. 2, 378–388 (2019). 27. D. McManus et al., Nat. Nanotechnol. 12, 343–350 (2017). 28. J. W. Jeong et al., Adv. Mater. 25, 6839–6846 (2013). 29. J. A. Rogers, T. Someya, Y. Huang, Science 327, 1603–1607 (2010). 30. Y.-K. Lee et al., Sci. Adv. 6, eaax6212 (2020). 

2. I. You et al., Science 370, 961–965 (2020). 

3. F. Ershad et al., Nat. Commun. 11, 3823 (2020). 

4. Q. Li et al., Nano Lett. 19, 5781–5789 (2019). 

5. S. Wang et al., Nature 555, 83–88 (2018). 

6. K. Sim et al., Sci. Adv. 5, eaav5749 (2019). 

   31. C. E. Carraher Jr., Giant Molecules: Essential Materials for Everyday Living and Problem Solving (Wiley, ed. 2, 2003). 

7. E. Stavrinidou et al., Sci. Adv. 1, e1501136 (2015). 

8. K. Kwon et al., Nat. Electron. 4, 302–312 (2021). 

   32. Y.-Q. Zheng et al., Science 373, 88–94 (2021). 

9. J. Koo et al., Nat. Med. 24, 1830–1836 (2018). 

   33. B. Xu, X. Chen, J. Mater. Res. 25, 2297–2307 (2010). 34. O. Scott, M. Begley, U. Komaragiri, T. Mackin, Acta Mater. 52, 4877–4885 (2004). 

10. M. Han et al., Nat. Biomed. Eng. 4, 997–1009 (2020). 

11. M. Bariya, H. Y. Y. Nyein, A. Javey, Nat. Electron. 1, 160–171 (2018). 

7 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 

#### RESEARCH | RESEARCH ARTICLE 







provisional patent application (no. 63/308,028) has been filed on the stretchable van der Waals thin films. The authors declare no other competing interests. Data and materials availability: All data are available in the manuscript or the supplementary materials. 

acknowledges the UCLA Physical Sciences Entrepreneurship and Innovation Fund and partial support from CNSI Noble Family Innovation Fund. Author contributions: X.D. and Y.H. conceived of the research. X.D. and Z.Y. designed all experiments. Z.Y. fabricated the electronic devices and analyzed the results. Z.Y., Z.L., D.X., and F.S. fabricated the solutionprocessable VDWTFs. D.X. and P.W. assisted with the electronic device fabrication. Z.Y. and P.W. performed the electronic measurements. Z.Y., J.Z., and D.X. conducted the mechanical measurements. Z.Y., B.C., Z.L., and C.W. performed the electron microscopy analyses on VDWTFs. Z.Y. and D.X. conducted the test of water vapor transmission rate for VDWTFs. Z.Y. and H.R. took optical images for organism-gated electronic devices. Z.Y., D.X., P.W., X.Z., and J.C. conducted and participated in the on-body measurements. L.W., H.R., and P.W. assisted with e-beam evaporation. X.D. and Z.Y. co-wrote the paper. X.D. and Y.H. supervised the research. All authors discussed the results and commented on the manuscript. Competing interests: A 

35. X. Fang, C. Zhang, X. Chen, Y. Wang, Y. Tan, Acta Mech. 226, 1657–1672 (2015). 

36. S. Wang et al., J. Appl. Mech. 79, 031022 (2012). 

37. Y. Yu, D. Sanchez, N. Lu, J. Mater. Res. 30, 2702–2712 (2015). 

38. J. J. Boland, Nat. Mater. 9, 790–792 (2010). 

39. J. Kottner, A. Lichterfeld, U. Blume-Peytavi, Arch. Dermatol. Res. 305, 315–323 (2013). 

##### SUPPLEMENTARY MATERIALS 

science.org/doi/10.1126/science.abl8941 Materials and Methods Supplementary Text Figs. S1 to S7 References Movies S1 to S4 12 August 2021; accepted 20 January 2022 10.1126/science.abl8941 

40. T. Pan et al., Adv. Funct. Mater. 27, 1702589 (2017). 

##### ACKNOWLEDGMENTS 

We acknowledge the Electron Imaging Center at UCLA for STEM and TEM technical support, as well as the Nanoelectronics Research Facility at UCLA for device fabrication technical support. We thank M. Liu for chemical vapor deposition thin-film samples and Sphere Studio for assistance with animations in movies S1 and S2. Funding: X.D. 

8 of 8 

Yan et al., Science 375, 852–859 (2022) 25 February 2022 



## **Highly stretchable van der Waals thin films for adaptable and breathable electronic membranes** 

Zhuocheng Yan, Dong Xu, Zhaoyang Lin, Peiqi Wang, Bocheng Cao, Huaying Ren, Frank Song, Chengzhang Wan, Laiyuan Wang, Jingxuan Zhou, Xun Zhao, Jun Chen, Yu Huang, and Xiangfeng Duan 

_Science_ **375** (6583), .  DOI: 10.1126/science.abl8941 

### **Weaker interfaces enable conformal films** 

Rigid materials become more flexible when cast as thin sheets, but they will still bump and buckle when subjected to in-plane rotation or twisting motions and thus cannot conformally cover a curved and mobile surface. Yan _et al_ . formed roughly 10-nanometer-thick freestanding sheets by spin coating films containing flakes of semiconducting materials. The flakes attract each other through bond-free van der Waals interfaces to enable mechanical stretchability and malleability as well as permeability and breathability. These properties make them suitable for bioelectronic membranes that can monitor and amplify a range of electrophysiological signals, including demonstrations of electrocardiography and electroencephalography. —MSL 

### **View the article online** https://www.science.org/doi/10.1126/science.abl8941 **Permissions** 

https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2022 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

