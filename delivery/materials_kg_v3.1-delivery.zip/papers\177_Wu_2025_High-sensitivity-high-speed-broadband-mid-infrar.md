# High-sensitivity, high-speed, broadband mid-infrared photodetector enabled by a van der Waals heterostructure with a vertical transport channel

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2025 |
| 引用量（Semantic Scholar） | 172 |
| 作者 | Jian-Feng Wu, Jia-Lin Zhang, Ruiqi Jiang, Hao Wu, Shou-Heng Chen, Xin-Lei Zhang, Wen-Hui Wang, Yuan-Fang Yu et al. |
| DOI | 10.1038/s41467-025-55887-x |
| 源文件 | 077_Wu_2025_High-sensitivity-high-speed-broadband-mid-infrar.pdf |

---


Article 

https://doi.org/10.1038/s41467-025-55887-x 

# High-sensitivity, high-speed, broadband midinfrared photodetector enabled by a van der Waals heterostructure with a vertical transport channel 

|Received: 2 September 2024<br>Accepted: 3 January 2025|Jianfeng Wu<br>1,2,8, Jialin Zhang<br>1,8<br>, Ruiqi Jiang<sup>3</sup>, Hao Wu<sup>1</sup>, Shouheng Chen<sup>4</sup>,<br>Xinlei Zhang<sup>1</sup>, Wenhui Wang<sup>1</sup>, Yuanfang Yu<sup>5</sup>, Qiang Fu<br>1, Rui Lin1, Yueying Cui<br>1,<br>Tao Zhou<br>1, Zhenliang Hu1, Dongyang Wan<br>1, Xiaolong Chen<br>4, Weida Hu<br>3,<br>Hongwei Liu<br>6<br>, Junpeng Lu<br>1,7<br>& Zhenhua Ni<br>1,7|
|---|---|
|Check for updates||
||The realization of room-temperature-operated, high-performance, miniatur-<br>ized, low-power-consumption and Complementary Metal-Oxide-Semiconductor<br>(CMOS)-compatible mid-infrared photodetectors is highly desirable for next-<br>generation optoelectronic applications, but has thus far remained an out-<br>standing challenge using conventional materials. Two-dimensional (2D) het-<br>erostructures provide an alternative path toward this goal, yet despite<br>continued efforts, their performance has not matched that of low-temperature<br>HgCdTe photodetectors. Here, we push the detectivity and response speed of a<br>2D heterostructure-based mid-infrared photodetector to be comparable to, and<br>even superior to, commercial cooled HgCdTe photodetectors by utilizing a<br>vertical transport channel (graphene/black phosphorus/molybdenum disulfide/<br>graphene). The minimized carrier transit path of tens of nanometers facilitates<br>efficient and fast carrier transport, leading to significantly improved perfor-<br>mance, with a mid-infrared detectivity reaching 2.38 × 10<sup>11 </sup>cmHz<sup>1/2</sup>W<sup>−1</sup><br>(approaching the theoretical limit), a fast response time of 10.4 ns at 1550 nm,<br>and an ultrabroadband detection range spanning from the ultraviolet to mid-<br>infrared wavelengths. Our study provides design guidelines for next-generation<br>high-performance room-temperature-operated mid-infrared photodetectors.|



Mid-infrared photodetection has long been central to various technological applications, including military and defense, environmental monitoring, astronomy, and astrophysics<sup>1,2</sup> . At the same time, with the emergence of new frontiers such as autonomous driving<sup>3,4</sup> , smart 

cities<sup>5</sup> , artificial intelligence<sup>6</sup> , and others, there are greater demands for mid-infrared photodetectors in terms of high sensitivity, high speed, miniaturization, low power consumption, and integration. However, developments in this field using conventional semiconductors such as 

> 1School of Physics, Key Laboratory of Quantum Materials and Devices of Ministry of Education, and Key Laboratory of MEMS of Ministry of Education, Southeast University, Nanjing, China.<sup>2</sup> School of Integrated Circuits, Southeast University, Nanjing, China.<sup>3</sup> State Key Laboratory of Infrared Physics, Shanghai Institute of Technical Physics, Chinese Academy of Sciences, Shanghai, China.<sup>4</sup> Department of Electronic and Electrical Engineering, Southern University of Science and Technology, 1088 Xueyuan Avenue, Shenzhen, China.<sup>5</sup> State Key Laboratory for Organic Electronics and Information Displays, School of Materials Science and Engineering, Nanjing University of Posts and Telecommunications, Nanjing, China.<sup>6</sup> Jiangsu Key Lab on Opto-Electronic Technology, School of Physics and Technology, Nanjing Normal University, 1 Wenyuan Road, Nanjing, China.<sup>7</sup> School of Electronic Science and Engineering, Southeast University, Nanjing, China. 

> 8These authors contributed equally: Jianfeng Wu, Jialin Zhang. e-mail: phyzjl@seu.edu.cn; phylhw@njnu.edu.cn; phyljp@seu.edu.cn; zhni@seu.edu.cn 

Nature Communications |  (2025) 16:564 

1 

Article 

https://doi.org/10.1038/s41467-025-55887-x 

II-IV HgCdTe<sup>7,8</sup> and III–V superlattices<sup>9,10</sup> are greatly limited by the requirements for low-temperature cooling operation, bulky module size, high power consumption, complex fabrication processes, and limited compatibility with Complementary Metal-OxideSemiconductor (CMOS) technology. Two-dimensional (2D) van der Waals heterostructures are promising for reducing the dark current and achieving high-performance room-temperature-operated midinfrared photodetectors<sup>11–17</sup> . However, despite continued advancements, simultaneously achieving high sensitivity, fast response speed, and ultrabroadband mid-infrared photodetection remains a persistent challenge. 

The first problem is posed by the specific detectivity (D<sup>*</sup> ). For a photodetector operated in photovoltaic mode, there exists a theoretical limit for the detectivity, which is known as the background-limited infrared photodetector (BLIP) limit<sup>18</sup> : 



<!-- Start of picture text -->
D * BLIP = hcλ �2Φη B�1=2 ð1Þ<br><!-- End of picture text -->

where ΦB is the total background photon flux density reaching the photodetector. Such ideal mid-infrared photodetectors have, however, rarely been experimentally realized. This is primarily attributed to the challenge of achieving devices with extremely low dark noise current and high external quantum efficiency, which is particularly difficult for mid-infrared materials with narrow bandgaps<sup>11,19–21</sup> . A second problem relates to the limited response speed<sup>22</sup> . The reported fastest response time of a 2D heterostructure-based mid-infrared photodetector is on the order of microseconds, which is more than two orders of magnitude slower than that of commercial HgCdTe photodetectors<sup>11,12,15</sup> . An often overlooked issue in response time optimization is the carrier transit time<sup>23</sup> , which may extend to microseconds or even longer for photovoltaic devices with low carrier mobility and long channel lengths. To further push the detectivity and response speed to their theoretical limits, an approach that can synergistically reduce the noise current, enhance the external quantum efficiency, and shorten the carrier transit time is highly needed. 

Here, we demonstrate the construction of a room-temperatureoperated, self-powered, high-sensitivity, high-speed, and ultrabroadband mid-infrared photodetector utilizing graphene/black phosphorus/molybdenum disulfide/graphene (Gr/BP/MoS2/Gr) heterostructures with a vertical transport channel. The embedded BP/ MoS2 p-n junction effectively reduces the room temperature noise current. The minimized vertical channel length of tens of nanometers prevents recombination-induced charge carrier losses during transport, leading to a high external quantum efficiency. Moreover, the shortened transit path results in a substantial reduction in the carrier transit time, overcoming potential limitations on response speed that may otherwise be imposed by an extended carrier transit time. As a result, the fabricated vertical channel device exhibits a roomtemperature mid-infrared detectivity reaching up to 2.38 × 10<sup>11</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> , approaching the BLIP limit; a fast response time of 10.4 ns at 1550 nm, reaching or even surpassing the response speed of commercial cooled HgCdTe photodetectors in mid-infrared wavelength range; and an ultra-broadband photodetection range spanning ultraviolet, visible, near-infrared and mid-infrared wavelengths. Our findings represent an essential step toward the realization of nextgeneration high-performance, low-power-consumption, and CMOScompatible mid-infrared photodetectors. 

## Results 

#### Design and optimization of the photodetector structure 

Figure 1a illustrates the design concept of the vertical photodetector, and its advantages can be manifested in the following aspects: (i) Vertical transport channel. The steady-state spatial distribution of the 

photogenerated excess charge carrier concentration is presented in Fig. 1b. Assuming the generation of photoexcited excess charge carriers at the pn junction without external bias, the carrier concentration undergoes an exponential decay with increasing distance from the junction (Supplementary Note 1 and Supplementary Fig. 1). In 2D material-based photodetectors featuring lateral transport channels, photogenerated charge carriers must diffuse over distances typically on the order of tens of micrometers before reaching the electrodes, resulting in a significant loss of carrier concentration due to recombination. For instance, in a material with a carrier diffusion length of 500 nm, the excess carrier concentration drops from 100% at the junction region to approximately 13.53% and 2.06 × 10<sup>−9</sup> at distances of 1 µm and 10 µm from the junction, respectively, leading to a substantial reduction in the external quantum efficiency. The implementation of a vertical channel reduces the transit path length of charge carriers to tens of nanometers, enabling highly efficient carrier transport and, consequently, achieving high quantum efficiency and shorter transit time. (ii) Graphene electrodes. The use of transparent graphene electrodes enables spatial overlap of the junction region with the electrodes, establishing a vertical channel without impeding the transmission of incident light. Leveraging the high carrier mobility of graphene ensures swift extraction of charge carriers to the external circuit, resulting in both high quantum efficiency and rapid response time. Furthermore, encapsulating the BP/MoS2 heterojunction between two parallel graphene layers serves as a protective measure, mitigating the common issue of ambient degradation in BP-based devices. (iii) BP/MoS2 heterojunction. At the interface of BP and MoS2, a type II energy level alignment is established (Fig. 1c, d), which enables the photodetector to operate in photovoltaic mode with remarkably low levels of dark noise current and minimal power consumption. The uniform built-in electric field is precisely oriented along the vertical transit path, ensuring the efficient separation and rapid extraction of photogenerated charge carriers toward the top and bottom electrodes. Furthermore, the synergistic combination of the narrow-gap material BP (0.3 eV) and the wide-gap material MoS2 (1.2 eV) as absorbers enhances the broadband detection capability of our device. (iv) Au electrodes. The finger electrodes located on the top and the Au pad on the bottom play a crucial role in facilitating the extraction of charge carriers to the external circuit. In addition, the bottom Au pad also serves as a back reflector to amplify the absorption of incident light. Our vertical design allows simultaneous optimization of the response speed, external quantum efficiency, noise current, and detection range, thereby enhancing the overall performance of the photodetector. 

#### Optoelectronic characterization of vertical channel device 

Figure 2a, b shows the schematic structure and optical image of the Gr/ BP/MoS2/Gr vertical channel photodetector. The detailed fabrication procedures are described in the methods section. The exfoliation and transfer processes were conducted in an argon-purged glovebox to prevent BP from oxidation, as confirmed by the Micro-area XPS measurement (Supplementary Fig. 2). The device consists of a BP/MoS2 heterojunction sandwiched between two graphene layers. Atomic force microscopy (AFM) revealed that the thicknesses of the BP and MoS2 layers were 27 nm and 14 nm, respectively (Supplementary Fig. 3). High-resolution transmission electron microscopy (HRTEM) and selected area electron diffraction (SAED) measurements confirm the high crystallinity of both BP and MoS2 (Supplementary Fig. 4). Energy-dispersive X-ray spectroscopy (EDX) mapping and crosssectional HRTEM image reveal the formation of a high-quality heterostructure interface (Supplementary Fig. 5). The transfer characteristics of BP and MoS2 field-effect transistors exhibit typical p-type and n-type behaviors at zero gate voltage (Supplementary Fig. 6). The Raman spectra measured in the overlapped junction region consist of peaks corresponding to individual BP and MoS2 layers with negligible 

Nature Communications |  (2025) 16:564 

2 

Article 

https://doi.org/10.1038/s41467-025-55887-x 



<!-- Start of picture text -->
a<br><!-- End of picture text -->

### Lateral channel (tens of micrometers) 



<!-- Start of picture text -->
Vertical channel<br>BP Graphene<br>(tens of nanometers)<br>MoS2<br>Graphene<br>b<br>1.0 1.0<br>0.8 0.8<br>0.6 0.6<br>p-n junction<br>0.4 0.4<br>Ld  500 nm<br>0.2 Ld  5 ûm 0.2<br>Ld  50 ûm<br>0.0 0.0<br>100 10 1 0.1 0.01 0.01 0.1 1 10 100<br>distance (ûm) distance (ûm)<br>c d<br>depletion neutral depletion neutral<br>recombination<br>recombination<br>carrier concentration () n �0 carrier concentration () n �0<br>electrode electrode electrode electrode<br><!-- End of picture text -->

Fig. 1 | Photogenerated charge carrier transport in 2D heterostructures with vertical and lateral transport channels. a Schematic diagram illustrating the diffusion process of photogenerated charge carriers in both vertical and lateral channel devices, with incident light directed from above onto the overlapped heterojunction region. The red and blue spheres represent holes and electrons, respectively. b Steady-state photogenerated charge carrier distribution as a function of distance from the p-n junction when excess electrons and holes are exclusively generated at the p-n junction region. Ld represents the diffusion length of the 

charge carriers. n0 refers to the photogenerated carrier concentration at the p-n junction region. c, d Schematic energy band diagram showing the electron-hole pair generation, separation, diffusion, and recombination processes in both vertical (c) and lateral channel devices (d). The red and blue dashed arrows indicate the transport directions of photogenerated holes and electrons, respectively. The blue and orange shaded areas correspond to the depletion and neutral regions, respectively. 

peak shifts<sup>12</sup> (Supplementary Fig. 7), indicating the formation of a highquality, strain-free vdW heterostructure. To elucidate the underlying working mechanism of this vertical photodetector, we performed scanning photocurrent measurements with a confocal optical microscope at Vds = 0 V under the illumination of a 633 nm laser. The scanning photocurrent image, as shown in the inset of Fig. 2b, clearly illustrates that the photocurrent is exclusively generated within the BP/ 

MoS2 overlapping region, delineated by the white dotted line. This indicates that the built-in electric field formed at the p-n junction dominates the separation of the charge carrier and, consequently, the generation of a photocurrent. 

Figure 2c shows the I–V characteristics of the vertical device in the dark and under 1550 nm laser excitation at different light powers. Notably, both the open-circuit voltage (Voc) and short-circuit current 

Nature Communications |  (2025) 16:564 

3 

Article 

https://doi.org/10.1038/s41467-025-55887-x 



<!-- Start of picture text -->
Top electrode Au<br>a b<br>Vds<br>Graphene 10 μm<br>BP<br>B-Gr T-Gr<br>Graphene MoS2<br>Bottom electrode Au 30 μm<br>SiO2<br>Si<br>c d<br>0.0<br>0.13 0.26<br>0.78<br>10 -6 1.56<br>-1.0 3.07<br>10 -8 P  (ûW) -2.0 P  (ûW)<br>Dark 0.78 7.49<br>0.004 1.56<br>0.074 3.07 -3.0<br>10 -10 0.13 7.49 = 1550 nm V ds = 0 V<br>0.26 14.97 = 1550 nm<br>-4.0<br>14.97<br>10 -12<br>-0.10 -0.05 0.00 0.05 0.10 0 5 10 15<br>V ds (V) Time (s)<br>e f 10 -5<br>0.0<br>I  � P Ü<br>10 -6<br>-1.0<br>800 3800<br>325<br>1000 10 -7<br>-2.0 532 633 1200 1550<br>1400<br>3000 10 -8<br>-3.0 V ds = 0 V<br>3200 O 325 nm, Ü O 64EB<br>3400 10 -9 O 633 nm, Ü O =46><br>-4.0 (nm) 3600<br>O 1550 nm, Ü O 64ED<br>UV VIS NIR MIR O 3200 nm, Ü O =46?<br>10 -10<br>-5.0<br>0 5 10 15 0.001 0.01 0.1 1 10<br>Time (s) P (ûW)<br> (A) I ds<br>Photocurrent (A)û<br>Photocurrent (A)û Photocurrent (A)<br><!-- End of picture text -->

Fig. 2 | Optoelectronic characterization of the vertical channel photodetector. a Schematic illustrating the experimental setup of the Gr/BP/MoS2/Gr vertical channel photodetector. The photocurrent was measured through the top and bottom Au electrodes. A high-resistivity silicon substrate is used to avoid the parasitic capacitance effects caused by the heavily doped silicon substrate. Here, BP and Gr represent black phosphorus and graphene, respectively. Vds indicate the bias applied between the source and drain. b Optical image of the fabricated vertical device, with the BP, MoS2, and graphene layers outlined by yellow, blue, and white lines, respectively, for clarity. Inset: Photocurrent map of the device obtained by scanning a focused laser beam with a wavelength of 633 nm and Vds = 0 V. The area enclosed by the dotted line represents the overlapping region of 

the BP/MoS2 heterojunction. c Output characteristics of the vertical photodetector in the dark and under 1550 nm laser illumination at different light powers. d Timeresolved photoresponse at different light powers at a wavelength of 1550 nm with Vds = 0 V. e Wavelength-dependent time-resolved photoresponse measured at Vds = 0 V with an incident light power of 7.5 µW. f Power dependence of the photocurrent extracted at Vds = 0 V for four characteristic spectral bands, namely, the ultraviolet (325 nm), visible (633 nm), near-infrared (1550 nm), and mid-infrared (3200 nm) bands. Here, the dots represent the experiment data, and the lines are the result of fitting the data to a power function. α is an exponent of the power function. 

Nature Communications |  (2025) 16:564 

4 

Article 

https://doi.org/10.1038/s41467-025-55887-x 

(Isc) increase with increasing light power and do not saturate within the investigated power range. To further explore the power-dependent photoresponse in self-powered mode, we measured the time-resolved photoresponse at zero bias under various light powers with a 1550 nm laser. As shown in Fig. 2d, the photocurrent gradually increases with increasing incident light power from 132 nW to 14.97 µW. A sharp increase or decrease in the photocurrent is observed upon switching the incident light on or off, indicating the rapid response of the device. Similar output characteristics and time-resolved photocurrent responses have also been observed for visible and mid-infrared light sources (Supplementary Figs. 8, 9). The wavelength-dependent temporal photoresponse measured at zero bias with an incident light power of 7.5 µW is presented in Fig. 2e, revealing an ultra-broadband photodetection capability spanning from 325 nm to 3800 nm. This extensive range covers wavelengths from the ultraviolet to the visible region and extends into the short-wavelength infrared (SWIR) and midwavelength infrared (MWIR) regions. The photocurrent, plotted as a function of light power for these four distinct bands, is fitted with the power law Iph / P<sup>α</sup> (Fig. 2f), where the extracted α values range from 0.96 to 1.03. The nearly linear dependence of Iph on light power suggests the high quality of our device, as the presence of deep trap centers typically results in a sublinear relationship<sup>24,25</sup> between Iph and P. The vertical device exhibited negligible degradation after one month, revealing the effective protection effect of the graphene layers (Supplementary Fig. 10). 

Comparative analysis of vertical and lateral channel device 

To elucidate the superiority of vertical channels over lateral channels, we conducted a comparative analysis of their figure-of-merits performance metrics, including the external quantum efficiency (EQE), responsivity (R), specific detectivity (D<sup>*</sup> ), noise equivalent power (NEP) and response speed. All the measurements were performed at room temperature under zero bias voltage. The EQE is defined as the ratio of the number of collected charge carriers to the number of incident photons and can be calculated using the equation EQE = Rhc=eλ, where R represents the responsivity (defined as R = Iph=P). In Fig. 3a, the wavelength-dependent EQE is presented for both the vertical Gr/BP/ MoS2/Gr and lateral BP/MoS2 photodetectors (Supplementary Fig. 11). The EQE of the vertical device is approximately one order of magnitude greater than that of the lateral channel device, exceeding 15% across a broad investigated wavelength range from 325 nm to 3600 nm. The higher charge carrier separation efficiency of the vertical heterostructure is also confirmed by the mid-infrared photoluminescence measurement (Supplementary Fig. 12). The responsivity of the vertical device once again demonstrates an order of magnitude improvement over that of the lateral channel device (Fig. 3b). In photovoltaic mode operation, where there is no photoconductive gain, the maximum achievable EQE is 100%. As a result, the maximum attainable R for a self-powered photodetector can be expressed as R = eλ=hc = λ=1240 (the unit for wavelength here is nanometers). Notably, for our vertical device, a peak responsivity of 0.66 A/W is attained at a mid-infrared wavelength of 3600 nm (consistently surpassing 0.1 A/W across the investigated wavelength range), representing a remarkably high responsivity for a device operating in photovoltaic mode. 

The specific detectivity D<sup>*</sup> of a photodetector can be calculated f **f** i f **f** i f **f** using the formula D<sup>*</sup> = pAB � R=In. To extract D<sup>*</sup> values, we measured the frequency-dependent noise spectral density for both the vertical and lateral channel devices. Various sources may contribute to the overall noise in photodetectors, including 1/f noise, shot noise, and thermal noise<sup>26</sup> . As shown in Supplementary Fig. 13a, b, the noise power density spectra for both vertical and lateral devices exhibit a linear dependence on frequency in the low-frequency regime (f < 1 kHz), attributed to 1/f noise. Beyond 1 kHz, the noise power density remains nearly constant irrespective of the frequency, which is 

indicative of white noise. At higher frequencies, two types of white noise, shot noise, and thermal noise, may contribute. The shot noise power density can be calculated by <in2> = 2eId, where Id is the dark current. In our device operating in photovoltaic mode with zero bias, the measured Id is remarkably low, with a value of 6.36 × 10<sup>−12</sup> A. Consequently, the <in2> induced by the shot noise is calculated to be 2.04 × 10<sup>−30</sup> A<sup>2</sup> /Hz, two orders of magnitude lower than our measured noise level of 10<sup>−28</sup> A<sup>2</sup> /Hz. This indicates the negligible impact of shot noise in our device, with thermal noise dominating at high frequencies. From the measured noise power density spectra, we calculated the overallf **f** i f **f** i f **f** i fnoise **f** i f **f** i f **f** i f **f** i f **f** i f **f** i f **f** i **f** current across the bandwidth of 10<sup>5</sup> Hz by In = qR B1<sup>Snðf Þdf</sup> . The calculated In values are 3.58 × 10<sup>−12</sup> A and 3.40 × 10<sup>−12</sup> A for the vertical and lateral channel devices, respectively. This indicates that vertical devices operating at zero bias present a dark current similar to that of their lateral counterparts, coupled with the higher quantum efficiency of vertical devices, rendering them more suitable for high-performance photodetectors. As shown in Fig. 3c, the D<sup>*</sup> of the vertical channel device consistently exceeds 3.88 × 10<sup>10</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> across the wavelength range from 325 nm to 3800 nm and reaches a peak value of 2.38 × 10<sup>11</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> at 3600 nm. The D<sup>*</sup> of the vertical device also demonstrated an order of magnitude improvement over that of the lateral channel device. Moreover, an ultralow noise equivalent power NEP of 1.72 × 10<sup>−14</sup> WHz<sup>−1/2</sup> is achieved for the vertical device at 3600 nm (Supplementary Fig. 14). 

Response speed is another crucial figure of merit for a photodetector. In general, the response time of a photodetector is limited by the RC time constant, carrier lifetime, and carrier transit time<sup>27,28</sup> . By utilizing a highly resistive silicon substrate covered with silicon dioxide, the parasitic capacitance of the device can be effectively reduced. To further exclude the added capacitance induced by the chip carrier, high-frequency probes are designed for the vertical channel device (Supplementary Figs. 15, 16). Figure 3d shows the time-resolved photoresponse spectra measured with an oscilloscope under 1550 nm laser illumination modulated by an electro-optic modulator for the vertical device. The rise time (τr) and decay time (τd) for the vertical device are approximately 10.4 ns and 15.6 ns, respectively. We have fabricated three more vertical channel devices and measured their response speed using the high-frequency probes. All these devices exhibit response times below 20 ns, which are comparable to or even faster than the commercial mid-infrared HgCdTe photodetectors (Supplementary Fig. 17 and Supplementary Table 1). To reveal the response speed of the device in the mid-infrared region, we performed the pulsed laser measurements.As shown in Supplementary Fig. 18, the device’s response speed is nearly identical in the visible, near-infrared, and mid-infrared ranges. Therefore, we can assume that the device’s response speed measured at 1550 nm using an electro-optic modulator is representative of its response speed in the mid-infrared region. For the lateral device, τr and τd are approximately 3.6 µs and 3.9 µs, respectively, indicating a response time two orders of magnitude slower than that of the vertical device. Furthermore, the − 3 dB cutoff frequency, a modulation frequency at which the photocurrent signal attenuates to 70.7% of its initial value, was determined from the frequency-dependent photoresponse. As shown in Fig. 3f, the − 3 dB cutoff frequencies are 12 MHz and 40 kHz for the vertical and lateral devices, respectively. The response time τ can be extracted from the **f f f f f f f f f f f** 

**f f f f f f f f f f f** equation Rðf Þ=R0 = 1=q1 + ð2πf τÞ<sup>2</sup> , where R(f) and R0 are the photoresponsivity under modulated and static light illumination, respectively<sup>29</sup> . At the − 3 dB cutoff frequency, R(f)/R0 equals 0.707. Consequently, the corresponding response times τ are determined to be 13 ns and 3.98 µs for the vertical and lateral devices, respectively, consistent with the response times extracted from time-resolved photoresponse spectra. For our vertical photodetector, both the carrier transit time and the RC time are estimated to be less than 1 ns 

Nature Communications |  (2025) 16:564 

5 

Article 

https://doi.org/10.1038/s41467-025-55887-x 



<!-- Start of picture text -->
a b c 10 12<br>10 0<br>100%<br>10 11<br>10 -1<br>10%<br>10 10<br>10 -2<br>1%<br>Vertical 10 9 Vertical<br>Vertical<br>0.1% Lateral 10 -3 Lateral Lateral<br>10 8<br>600 1200 3000 3600 600 1200 3000 3600 600 1200 3000 3600<br>Wavelength (nm) Wavelength (nm) Wavelength (nm)<br>d 5 e f<br>0<br>0<br>Vertical Lateral<br>0<br>-1 -3<br>f  = 40 kHz f  = 12 MHz<br>-5<br>-2 -6<br>r d r d<br>-10<br>10.4 ns 15.6 ns 3.6 ûs 3.9 ûs<br>-3<br>-9<br>Vertical<br>-15<br>-4 Lateral<br>-12<br>-20<br>0.0 0.2 0.4 0.6 0.8 1.0 0 20 40 60 80 100 10 3 10 4 10 5 10 6 10 7<br>Time (ûs) Time (ûs) Frequency (Hz)<br>g h i 5.0<br>793 K<br>10 -6 0 893 K<br>4.0 993 K<br>1093 K<br>-40<br>1193 K<br>10 -8 3.0<br>793 K<br>-80 893 K<br>2.0<br>993 K<br>10 -10 Dark 1093 K<br>1193 K -120 1193 K 1.0<br>10 -12 -160 0.0<br>-0.04 -0.02 0.00 0.02 0.04 0 20 40 60 80 100 1.0 1.5 2.0 2.5 3.0 3.5 4.0<br>V ds (V) Time (s) Wavelength (ûm)<br>EQE<br> (A/W) R<br>*1/2-1 (cm Hz) D  W<br>）Photocurrent (arb. units Photocurrent (arb. units)<br>Normalized response (dB)<br> (A) I ds<br>Photocurrent (nA)<br>*1/210-1 (10) D  cm Hz W<br><!-- End of picture text -->

Fig. 3 | Room-temperature performance comparison of photodetectors with vertical and lateral transport channels. a–c Comparison of broadband wavelength-dependent external quantum efficiency (a), responsivity (b), and detectivity (c) between vertical and lateral channel devices, with all measurements performed at Vds = 0 V. d, e Rise and decay times for vertical (d) and lateral channel devices (e) measured at Vds = 0 V under 1550 nm laser illumination. A digital oscilloscope was used to record the fast-varying photocurrent signals. f Normalized 

photoresponse as a function of modulation frequency extracted at Vds = 0 V under 1550 nm laser illumination for vertical and lateral channel devices. g Output characteristics of the vertical photodetector in the dark and under illumination with 1193 K blackbody radiation. h Time-resolved photoresponse at different blackbody temperatures measured at Vds = 0 V. i Wavelength-dependent D* of the vertical device at different blackbody temperatures measured at Vds = 0 V. 

(Supplementary Notes 2, 3 and Supplementary Figs. 19, 20). Therefore, the response time of a vertical photodetector is governed primarily by the material-specific carrier de-trap time. We anticipate that further improvements in response time could be achieved through the optimization of BP crystal growth conditions and device fabrication procedures. In contrast, the operational speed of the lateral device is 

limited by the carrier transit time, which is estimated to be in the microsecond range (Supplementary Notes 2, 3 and Supplementary Fig. 21). It is important to note that the highly resistive silicon substrate plays a critical role in achieving the ultrafast response speed. For vertical devices fabricated on low-resistance silicon, the response speed is on the order of microseconds (Supplementary Fig. 22). 

Nature Communications |  (2025) 16:564 

6 

Article 

https://doi.org/10.1038/s41467-025-55887-x 

In practical applications of infrared photodetectors, a key figure of merit is their blackbody detection capability. Compared to that from lasers, the radiation from a blackbody source more accurately represents the actual radiation of the detected object. However, the characterization of most photodetectors based on 2D materials relies on lasers as the light source. Only a limited number of studies have explored the blackbody detection ability of these photodetectors<sup>11,12</sup> . Figure 3g shows the I–V curves of the vertical device measured in the dark and under illumination by an 1193 K blackbody source. Notably, at zero bias voltage, a significant increase in the current is observed upon exposure to blackbody radiation, indicating the excellent blackbody responsivity of our vertical photodetector. Figure 3h shows the timeresolved photoresponse spectra measured at different blackbody temperatures. The photocurrent gradually increases with increasing blackbody temperature. This can be attributed to the combined effects of temperature-dependent spectral radiance and wavelengthdependent photoresponse. The overall photocurrent at different blackbody temperatures should be proportional to R 10<sup>SðλÞ �Mðλ, TÞdλ,</sup> where S(λ) is the relative spectral response of the photodetector, and M(λ,T) is the spectral radiant exitance of a blackbody following Plank’s Law Mðλ, TÞ = 2πhc<sup>2</sup> =ðλ<sup>5</sup> �ðexp ~~ð~~ λhckT<sup>Þ �1ÞÞ(SupplementaryFig.23).To</sup> elucidate the underlying physics of the temperature-dependent photoresponse, we measured the S(λ) of the vertical photodetector using a Fourier transform infrared spectrometer (Supplementary Fig. 24) and calculated R 10<sup>SðλÞ �Mðλ, TÞdλatdifferenttemperatures.Theinte-</sup> grated value indeed increases with increasing temperature (Supplementary Fig. 25), which is consistent with our experimental observations. The blackbody detectivityf **f** i f **f** i f **f** D<sup>*</sup> b<sup>is calculated according to</sup> D<sup>*</sup> b<sup>=</sup> pAB � Iph=ðIn � PÞ, where P represents the blackbody radiation power incident on the device; the calculation details are presented in the methods section. The temperature dependence D<sup>*</sup> b<sup>of the vertical</sup> device is shown in Supplementary Fig. 26. Notably, D<sup>*</sup> b<sup>gradually</sup> increases with increasing temperature (Supplementary Note 4), and a D<sup>*</sup> b<sup>value of 2.96 × 1010 cmHz1/2W−1is obtained at 1193 K radiation. The</sup> peak blackbody detectivity D<sup>*</sup> p<sup>canbeextractedusingthefollowing</sup> formula<sup>12</sup> : 



<!-- Start of picture text -->
D * p = D b * � MðT, λÞdλ= SðλÞ � MðT, λÞdλ ð2Þ<br>Z 10 Z 10<br><!-- End of picture text -->

The wavelength-dependent D<sup>*</sup> values at different blackbody temperatures are extracted and plotted in Fig. 3i, where a D<sup>*</sup> p<sup>of</sup> 4.61 × 10<sup>10</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> is achieved at 3500 nm at 1193 K. The relatively lower detectivity of the blackbody measurement compared with the laser measurement can be attributed to the anisotropy of black phosphorus (Supplementary Fig. 27). We also characterized the blackbody detection capability of the lateral channel device, which has a D<sup>*</sup> value one order of magnitude lower than that of the vertical device across the measured wavelength (Supplementary Fig. 28). 

#### Impact of channel length scaling on device performance 

To directly elucidate the influence of the channel length on the photoelectric conversion process of the device, we fabricated six pairs of electrodes on a single BP/MoS2 heterojunction. In each electrode pair, one is deposited on BP, and the other is deposited on MoS2, effectively creating six devices with different lateral channel lengths. As shown in Fig. 4a, BP and MoS2 are highlighted by yellow and blue lines, respectively. The overlapping region in the middle represents the heterojunction area. Moreover, AFM measurements revealed that the thicknesses of the BP and MoS2 layers were 34 nm and 24 nm, respectively (Supplementary Fig. 29). This device exhibits a low noise power density under zero bias (Supplementary Fig. 30). We compared the output curves of all sets of devices with different channel lengths varying from 13.7 µm to 112.3 µm. Clear rectifying characteristics are observed for all the devices, indicating the formation of an effective 

p-n junction. Under forward bias, Ids gradually decrease with increasing channel length, which is attributed to the increased channel resistance (Supplementary Fig. 31). For the photoresponse measurements, all the devices were operated in zero-bias photovoltaic mode. The incident light is focused onto the overlapped heterojunction without irradiating the surrounding regions. This measurement setup ensures that, for the six different devices, the generation and separation processes of photogenerated charge carriers remain consistent, with the only distinction lying in the carrier diffusion processes within channels of different lengths. Figure 4b shows the time-resolved photoresponse under 1550 nm focused laser illumination. The photocurrent gradually decreases with increasing channel length. Consequently, the extracted R and EQE also decrease fourfold as the channel length increases from 13.7 µm to 112.3 µm (Fig. 4c). This result clearly reveals the issue of diffusion loss of photogenerated charge carriers for long-channel devices, where electrons and holes recombine before reaching the electrodes. The response time is also extracted for six devices with varying channel lengths. Notably, both the rise time and decay time increase with channel length, showing a variation of more than one order of magnitude: from 1.74 µs and 1.92 µs for a 13.7 µm channel to 19.86 µs and 42.2 µs for a 112.3 µm channel (Fig. 4d and Supplementary Fig. 32). By further decreasing the channel length of the lateral channel device to ~ 1 µm, the response speed can be improved to as fast as 436 ns (Supplementary Fig. 33). 

#### Benchmarking against other room temperature MWIR photodetectors 

Figure 5a shows a comparison of the wavelength-dependent D<sup>*</sup> of the Gr/BP/MoS2/Gr vertical channel photodetector with those of other room-temperature-operated MWIR photodetectors utilizing both 2D materials with lateral transport channels<sup>11–13,15,16</sup> and conventional bulk materials. It is clear that the vertical device demonstrates superior performance in terms of both high detectivity and ultrabroadband detection range. The D<sup>*</sup> of the vertical device measured over the entire investigated wavelength range (325 nm to 3800 nm) exceeded 3.88 × 10<sup>10</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> . Notably, at 3600 nm, a detectivity of 2.38 × 10<sup>11</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> is achieved, approaching the theoretical limit constrained by BLIP. Fast and sensitive photodetection is a critical benchmark for high-performance photodetectors. Figure 5b compares the performance of the vertical device with that of other reported 2D material photodetectors with MWIR responses in terms of both detectivity and response speed<sup>11–13,15,16,30–35</sup> . Our device response speed and detectivity are among the highest of those reported for comparable 2D material devices, reaching or even surpassing the response speed of commercial cooled HgCdTe photodetectors. Comprehensive comparisons of the mid-infrared performance of our device with commercial HgCdTe photodetectors and various narrow-gap 2D materials are provided in Supplementary Tables 1 and 2, respectively. It is worth mentioning that the response speed of our device is directly extracted from a complete periodic cycle by modulating the light onoff with an electro-optic and acousto-optic modulator, which allows the photocurrent to rise and fall to a stable value in each cycle. Several reported works use a pulsed laser to characterize the response speed, where the maximum photocurrent is limited by the pulse width of the laser and does not rise to a stable value, leading to an overestimation of the response speed. The response speed of our device surpassed that of other devices in the microsecond range, reaching the nanosecond range, leading to significant advancements in 2D material-based MWIR photodetectors. 

## Discussion 

In summary, we have simultaneously achieved high-sensitivity, highspeed, and ultrabroadband mid-infrared detection within a single photodetector by implementing a 2D heterostructure with a vertical transport channel. The impact of channel length scaling on both the 

Nature Communications |  (2025) 16:564 

7 

Article 

https://doi.org/10.1038/s41467-025-55887-x 



<!-- Start of picture text -->
a b<br>0.0<br>5 4 3 2 1 1 2 3 4 5<br>6 6 -0.3<br>MoS2 -0.6 = 1550 nm<br>BP<br>Channel Length<br>-0.9<br>13.7 ûm 33.3 ûm<br>53.0 ûm 72.6 ûm<br>30 μm -1.2 92.5 ûm 112.3 ûm<br>0 1 2 3 4 5 6<br>c d Time (s)<br>0.05 5% 50<br>R •r<br>40<br>0.04 EQE 4%<br>•d<br>30<br>0.03 3%<br>20<br>0.02 2%<br>10<br>0.01 1%<br>= 1550 nm 0<br>0.00 0%<br>0 20 40 60 80 100 120 0 20 40 60 80 100 120<br>Channel Length (ûm) Channel Length (ûm)<br>Photocurrent (A)û<br>EQE<br> (A/W) R<br>Response time (s)û<br><!-- End of picture text -->

Fig. 4 | Effect of channel length scaling on the photoresponse properties of lateral channel devices. a Optical image of a BP/MoS2 heterojunction with six pairs of electrodes of different channel lengths varying from 13.7 µm to 112.3 µm. b Timeresolved photoresponse for lateral devices with different channel lengths 

measured at Vds = 0 V under 1550 nm laser illumination. c Responsivity and external quantum efficiency as a function of lateral channel length under 1550 nm laser illumination at Vds = 0 V. d Extracted rising time and decay time as a function of lateral channel length under 633 nm laser illumination at Vds = 0 V. 

external quantum efficiency and response speed is clearly elucidated, demonstrating the superiority of vertical 2D photodetectors over commonly used lateral counterparts. Our Gr/BP/MoS2/Gr vertical photodetector is a new benchmark with a high MWIR of 2.38 × 10<sup>11</sup> cmHz<sup>1/2</sup> W<sup>−1</sup> approaching the theoretical limit, a fast response speed of 10.4 ns at 1550 nm, and an ultrabroadband detection range spanning from the ultraviolet to mid-infrared region. The overall room-temperature performance of our vertical device is comparable or even superior to the commercial cooled mid-infrared HgCdTe photodetectors. We anticipate that our findings will significantly propel the advancement of next-generation high-performance infrared photodetectors operating at room temperature. 

## Methods 

#### Device fabrication 

For the fabrication of the vertical channel device, the bottom electrode (5 nm Ti and 30 nm Au) was prepared through laser lithography patterning and subsequent thermal evaporation on a high-resistance (4000 Ω·cm) silicon substrate coated with 300 nm SiO2. A top finger electrode (30 nm Au) was initially fabricated on an intrinsic silicon substrate. The finger electrode was then coated with PMMA resist by spin coating and subsequently lifted off from the substrate using polydimethylsiloxane (PDMS), which served as a transfer electrode for later use. The bottom graphene, MoS2 flakes, BP flakes and top graphene were mechanically exfoliated from bulk crystals and sequentially stacked layer by layer on the prepared bottom electrode by a dry transfer method. All 2D materials used in this work were purchased from HQ Graphene. To prevent BP from undergoing ambient 

oxidation, both the exfoliation and transfer processes were conducted in an argon-purged glovebox with oxygen and moisture concentrations lower than 0.1 ppm. Finally, the prepared top electrode was transferred onto the heterostructures to complete the fabrication of the vertical device. For the fabrication of lateral channel devices, both the source and drain electrodes (30 nm Au) were initially fabricated on an intrinsic silicon substrate and then lifted off as the transfer electrodes for the BP/MoS2 heterojunction. 

#### Device characterization 

The thicknesses of the MoS2 and BP flakes were determined using atomic force microscopy (AFM, Bruker Dimension Icon). Raman spectroscopy and photocurrent mapping were conducted on a WITec Alpha300R system equipped with a 633 nm diode-pumped solid-state laser. Electrical and optoelectrical characterizations of the devices were carried out using a semiconductor parameter analyzer (FS-Pro, PRIMARIUS) at room temperature under ambient conditions. Various light sources, ranging from ultraviolet to mid-infrared, were employed to assess device performance. These sources include monochromatic lasers at wavelengths of 325, 532, and 633 nm, a Ti:sapphire femtosecond laser (680–1600 nm, 80 MHz, Chameleon Compact OPO), and a tunable mid-infrared laser (2.8–4 µm, Cati-T-3-4, BEST RAY). For the high-frequency probe measurement, a 1550 nm laser was modulated by an electro-optic modulator (MXAN-LN-40). For the chip carrier measurement, a 633 nm laser was modulated by an acousto-optic modulator (R21080-1DS). A digital oscilloscope (MDO3032, Tektronix) was used to record the transient photocurrent signal. The relative response spectrum was measured by a Fourier transform infrared 

Nature Communications |  (2025) 16:564 

8 

Article 

https://doi.org/10.1038/s41467-025-55887-x 



<!-- Start of picture text -->
a 10 13<br>BLIP (PV) b-AsP<br>BLIP (PC) PdSe2 Gr/BP/MoS2/Gr (this work)<br>10 12 BLIP (Thermal)PbSPbSe BP/MoSPdSe2-MoS2 2 TFOV = 2bg = 300 K°<br>InGaAs BP/MoS2/Gr<br>HgCdTe MoS2-BP-MoS2<br>10 11<br>10 10<br>10 9<br>10 8<br>1 2 3 4 5<br>Wavelength (µm)<br>b<br>10 12<br>Gr-BP-MoS2-Gr (this work)<br>10 11 MoS2-BP-MoS2<br>BP-MoS2-Gr<br>10 10 BP-MoS2 b-AsP-MoS2 PdSe2<br>PtTe2<br>10 9 Gr-Bi2Se3<br>G-BP PtSe2<br>10 8<br>Gr-PtSe2<br>10 7 Td-MoTe2<br>10 -8 10 -7 10 -6 10 -5 10 -4 10 -3 10 -2 10 -1 10 0<br>Reponse time (s)<br>*1/2-1 (cm Hz) D  W<br>*1/2-1 (cm Hz) D W<br><!-- End of picture text -->

Fig. 5 | Comparison of the room temperature performances of the vertical channel photodetector and other reported photodetectors. a Comparison of the detectivity and detection range among reported room temperature-operated mid-wave infrared (MWIR) photodetectors based on 2D materials and conventional materials<sup>11–13,15,16</sup> . The theoretical limits of D<sup>*</sup> calculated for the photodetectors operating under background-limited infrared performance (BLIP) in photovoltaic (PV) mode, photoconductive (PC) mode, and thermal infrared (TIR) mode are shown as black, red, and blue dotted lines, respectively. Tbg and FOV represent background temperature and field of review. b Comparison of the detectivity and response speed among reported room temperature-operated photodetectors based on 2D materials with MWIR (3–6 µm) responses<sup>11–13,15,16,30–35</sup> . 

spectrometer (Nicolet 8700) at room temperature. For the pulsed laser measurement, the pulses with 800 nm central wavelength and 35fs pulse width at 1 kHz repetition rate was provided by Ti:sapphire regenerative amplifier laser system (Astrella, Coherent). Optical parametric amplifier (OPA) extended the wavelength to 633, 1550, and 3000 nm (OPerA Solo, Coherent). A chopped laser with a 429 Hz chopper frequency, 532 nm wavelength, ~ 25 μm spot radius, and laser power density of 90 Wcm<sup>–2</sup> was used as an excitation source for the PL measurement. The PL signal was collected via 15 × objective and further analyzed by FTIR spectrometer. 

#### Blackbody measurements 

Blackbody response measurements were performed at room temperature under ambient conditions with a calibrated commercial blackbody source (HFY-200C). The power incident on the effective area of the device can be calculated by P = αεσðT b4 � T 04ÞAdR2=L2, where α is the modulation factor (1.0), ε is the average emissivity of the blackbody radiation source (0.9), σ is the Stefan–Boltzmann constant, Tb is the blackbody source temperature (793 K – 1193 K), T0 is the room temperature (300 K), Ad is the effective device area, R is the selected aperture radius of the blackbody radiation source (0.5 cm), and L is the distance between the aperture and the device surface (5 cm). It is 

noteworthy that the modulation factor in our measurement setup is 1.0, rather than the usually reported 0.35 for lock-in measurements. This is because our time-resolved blackbody response was directly measured by the semiconductor parameter analyzer without highfrequency light modulation. However, the blackbody response measured by a lock-in amplifier usually requires the incident light to be modulated, which results in a photocurrent amplitude modulation of 0.35 of its maximum value. 

## Data availability 

Relevant data supporting the key findings of this study are available within the article and the Supplementary Information file. All raw data generated during the current study are available from the corresponding authors upon request. 

## References 

1. Rogalski, A., Martyniuk, P., Kopytko, M. & Hu, W. Trends in performance limits of the HOT infrared photodetectors. App. Sci. 11, 501 (2021). 

2. Rogalski, A. Infrared detectors: status and trends. Prog. Quantum Electron. 27, 59–210 (2003). 

3. Wu, H., Li, Y., Xu, W., Kong, F. & Zhang, F. Moving event detection from LiDAR point streams. Nat. Commun. 15, 345 (2024). 

4. Kim, I. et al. Nanophotonics for light detection and ranging technology. Nat. Nanotechnol. 16, 508–524 (2021). 

5. Napolitano, R., Reinhart, W. & Gevaudan, J. P. Smart cities built with smart materials. Science 371, 1200–1201 (2021). 

6. Finn, E. Envisioning artificial intelligence. Science 383, 156–156 (2024). 

7. Lei, W., Antoszewski, J. & Faraone, L. Progress, challenges, and opportunities for HgCdTe infrared materials and detectors. Appl. Phys. Rev. 2, 041303 (2015). 

8. Rogalski, A. HgCdTe infrared detector material: history, status and outlook. Rep. Prog. Phys. 68, 2267 (2005). 

9. Rogalski, A., Martyniuk, P. & Kopytko, M. InAs/GaSb type-II superlattice infrared detectors: Future prospect. Appl. Phys. Rev. 4, 031304 (2017). 

10. Rogalski, A., Martyniuk, P. & Kopytko, M. Type-II superlattice photodetectors versus HgCdTe photodiodes. Prog. Quantum Electron. 68, 100228 (2019). 

11. Chen, Y. et al. Unipolar barrier photodetectors based on van der Waals heterostructures. Nat. Electron. 4, 357–363 (2021). 

12. Wang, F. et al. Fully depleted self-aligned heterosandwiched van der Waals photodetectors. Adv. Mater. 34, 2203283 (2022). 

13. Long, M. et al. Room temperature high-detectivity mid-infrared photodetectors based on black arsenic phosphorus. Sci. Adv. 3, e1700589 (2017). 

14. Lukman, S. et al. High oscillator strength interlayer excitons in twodimensional heterostructures for mid-infrared photodetection. Nat. Nanotechnol. 15, 675–682 (2020). 

15. Bullock, J. et al. Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. Nat. Photonics 12, 601–607 (2018). 

16. Long, M. et al. Palladium diselenide long-wavelength infrared photodetector with high sensitivity and stability. ACS Nano 13, 2511–2519 (2019). 

17. Wang, F. et al. Next-generation photodetectors beyond van der Waals junctions. Adv. Mater. 36, 2301197 (2024). 

18. Rogalski, A. Infrared Photodetector. (CRC Press, 2010). 

19. Li, H. & Yang, Z. Recent progress in mid-infrared photodetection devices using 2D/nD (n=0, 1, 2, 3) heterostructures. Mater. Des. 225, 111446 (2023). 

20. Savich, G. R., Pedrazzani, J. R., Sidor, D. E., Maimon, S. & Wicks, G. W. Dark current filtering in unipolar barrier infrared detectors. Appl. Phys. Lett. 99, 121112 (2011). 

Nature Communications |  (2025) 16:564 

9 

Article 

https://doi.org/10.1038/s41467-025-55887-x 

21. Gopal, V., Singh, S. K. & Mehra, R. M. Analysis of dark current contributions in mercury cadmium telluride junction diodes. Infrared Phys. Technol. 43, 317–326 (2002). 

22. Morteza Najarian, A. et al. Photophysical properties of materials for high-speed photodetection. Nat. Rev. Phys. 6, 219–230 (2024). 

23. Massicotte, M. et al. Picosecond photoresponse in van der Waals heterostructures. Nat. Nanotechnol. 11, 42–46 (2016). 

24. Zhao, Q. et al. The role of traps in the photocurrent generation mechanism in thin InSe photodetectors. Mater. Horiz. 7, 252–262 (2020). 

25. Ghosh, S., Varghese, A., Thakar, K., Dhara, S. & Lodha, S. Enhanced responsivity and detectivity of fast WSe2 phototransistor using electrostatically tunable in-plane lateral p-n homojunction. Nat. Commun. 12, 3336 (2021). 

26. Wang, F., Zhang, T., Xie, R., Wang, Z. & Hu, W. How to characterize figures of merit of two-dimensional photodetectors. Nat. Commun. 14, 2224 (2023). 

27. Long, M., Wang, P., Fang, H. & Hu, W. Progress, challenges, and opportunities for 2D material based photodetectors. Adv. Funct. Mater. 29, 1803807 (2019). 

28. Kato, K., Susumu, H., Kawano, K. & Kozen, A. J. I. T. o. E. Design of ultrawide-band, high-sensitivity p-i-n protodetectors. IEICE Trans. Electron. E76, 214–221 (1993). 

29. Liu, E. et al. High responsivity phototransistors based on few-layer ReS2 for weak signal detection. Adv. Funct. Mater. 26, 1938–1944 (2016). 

30. Zeng, L. et al. Van der Waals epitaxial growth of Mosaic-Like 2D platinum ditelluride layers for room-temperature mid-infrared photodetection up to 10.6 µm. Adv. Mater. 32, 2004412 (2020). 

31. Long, M. et al. Scalable fabrication of long-wave infrared PtSe2-G heterostructure array photodetectors. Appl. Phys. Lett. 117, 231104 (2020). 

32. Yu, X. et al. Atomically thin noble metal dichalcogenide: a broadband mid-infrared semiconductor. Nat. Commun. 9, 1545 (2018). 

33. Lai, J. et al. Anisotropic broadband photoresponse of layered TypeII Weyl semimetal MoTe2. Adv. Mater. 30, 1707152 (2018). 

34. Zhang, X. et al. High performance mid-wave infrared photodetector based on graphene/black phosphorus heterojunction. Mater. Res. Express 8, 035602 (2021). 

35. Kim, J. et al. Highly sensitive, gate-tunable, room-temperature midinfrared photodetection based on graphene–Bi2Se3 heterostructure. ACS Photonics 4, 482–488 (2017). 

## Acknowledgements 

This work was supported by the National Key Research and Development Program of China (2021YFA1200700, 2023YFB3611400, 2022YFB4400100), the National Natural Science Foundation of China (T2222011, 62225404, 62375052, 12304481, 62174027, and T2321002), the Natural Science Foundation of Jiangsu Province (BK20210199, BK20240643), Jiangsu Province Key Research and Development Program (BK20232044), the Natural Science Foundation of Jiangsu Province, and the Major Project (BK20222007), the Natural Science Foundation of the Jiangsu Higher Education Institutions of China (24KJB510027). 

## Author contributions 

Z.N., J.L., and J.Z. conceived the idea and designed the experiments. J.W. fabricated all the devices. J.W. and J.Z. carried out the optoelectronic measurements with the help of W.W., Z.H., and Y.Y. J.W., H.L., D.W., H.W., T.Z., and Y.C. performed the response time measurement. J.W., W.W., Q.F., and R.L. performed the Raman measurements. J.W. and X.Z. conducted the AFM measurements. R.J. and W.H. performed the FTIR measurements. H.L., X.C., and S.C. performed the PL measurements. J.W., J.Z., J.L., and Z.N. co-wrote the manuscript. All the authors discussed the results and reviewed the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-025-55887-x. 

Correspondence and requests for materials should be addressed to Jialin Zhang, Hongwei Liu, Junpeng Lu or Zhenhua Ni. 

Peer review information Nature Communications thanks Munkhbayar Batmunkh, Sang Hoon Chae and the other anonymous reviewer for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence toshare adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creativecommons.org/licenses/by-nc-nd/4.0/. 

##### © The Author(s) 2025 

Nature Communications |  (2025) 16:564 

10 

