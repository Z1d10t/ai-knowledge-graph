# Van der Waals integration of high-κ perovskite oxides and two-dimensional semiconductors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 198 |
| 作者 | Allen Jian Yang, Kun Han, Ke Huang, Chen Ye, Wen Wen, Ruixue Zhu, R. Zhu, Jun Xu et al. |
| DOI | 10.1038/s41928-022-00753-7 |
| 源文件 | 036_Yang_2022_Van-der-Waals-integration-of-high-κ-perovskite-o.pdf |

---
Articles **https://doi.org/10.1038/s41928-022-00753-7** 





# **Van der Waals integration of high-** **_κ_ perovskite oxides and two-dimensional semiconductors** 

**Allen Jian Yang**<sup>**1**✉</sup> **, Kun Han**<sup>**1**</sup> **, Ke Huang**<sup>**1**</sup> **, Chen Ye**<sup>**1**</sup> **, Wen Wen**<sup>**1**</sup> **, Ruixue Zhu**<sup>**2,3**</sup> **, Rui Zhu**<sup>**3**</sup> **, Jun Xu**<sup>**3**</sup> **, Ting Yu**<sup>**1**</sup> **, Peng Gao**<sup>**2,3**</sup> **, Qihua Xiong**<sup>**4,5**</sup> **and X. Renshaw Wang**<sup>**1,6**✉</sup> 

**Two-dimensional semiconductors can be used to build next-generation electronic devices with ultrascaled channel lengths. However, semiconductors need to be integrated with high-quality dielectrics—which are challenging to deposit. Here we show that single-crystal strontium titanate—a high-** **_κ_ perovskite oxide—can be integrated with two-dimensional semiconductors using van der Waals forces. Strontium titanate thin films are grown on a sacrificial layer, lifted off and then transferred onto molybdenum disulfide and tungsten diselenide to make n-type and p-type transistors, respectively. The molybdenum disulfide transistors exhibit an on/off current ratio of 10**<sup>**8**</sup> **at a supply voltage of 1 V and a minimum subthreshold swing of 66 mV dec**<sup>**−1**</sup> **. We also show that the devices can be used to create low-power complementary metal–oxide–semiconductor inverter circuits.** 

ielectric layers with a high dielectric constant ( _κ_ ), minimal leakage current and reduced thickness are essential for creatDing low-power electronic devices and circuits. High- _κ_ dielectrics such as hafnium oxide (HfO2) have, for instance, been used in silicon electronics for over a decade<sup>1–4</sup> . Similar approaches to grow high- _κ_ dielectric layers have been attempted on two-dimensional (2D) layered materials including graphene, transition metal dichalcogenides and black phosphorus<sup>5–11</sup> . However, unlike conventional semiconductors, the surfaces of 2D materials are free of dangling bonds and thus a seeding layer or surface functionalization is typically required to provide nucleation sites before the growth of a high- _κ_ dielectric<sup>12–14</sup> . These additional treatments increase the processing complexity and degrade the interface between the dielectric and 2D material<sup>15</sup> . 

Surface oxidation of semiconducting Bi2O2Se into Bi2SeO5—a high- _κ_ dielectric material—can avoid such pretreatment, but this method faces challenges to become more generally applicable<sup>16,17</sup> . Pretreatment can also be avoided if the dielectric can be integrated on the 2D material using only van der Waals forces, instead of chemical bonding during in situ growth. Various van der Waals heterostructures have been fabricated by creating layers on another substrate and then transferring them onto a 2D material as a freestanding thin film<sup>18,19</sup> , but using such methods with dielectrics is challenging due to the difficulties in preparing and handling freestanding high- _κ_ dielectric thin films. Single-crystal strontium titanate, SrTiO3 (STO), is a complex oxide with a high dielectric constant of over 300 at room temperature<sup>20,21</sup> . These properties make it attractive for exploring the emergent transport properties of 2D materials in an ultrahigh- _κ_ dielectric environment<sup>21,22</sup> , as well as for fabricating 2D-material-based electronic devices with scaled supply voltage. However, it is challenging to integrate STO on 2D materials, which is required for independent gate control in practical applications, due to structure mismatch and processing incompatibility common for oxide materials<sup>23–25</sup> . 

In this Article, we report high-performance n-type molybdenum disulfide (MoS2) and p-type tungsten diselenide (WSe2) field-effect 

transistors (FETs) on silicon substrates with single-crystal STO as the top-gate dielectric. The STO is epitaxially grown on a sacrificial layer and subsequently transferred with the help of van der Waals forces. The MoS2 FETs exhibit an on/off current ratio ( _I_ on/ _I_ off) of over 10<sup>8</sup> within the top-gate voltage ( _V_ TG) range of ±1.0 V and a minimum subthreshold swing (SS) of 66 mV dec<sup>−1</sup> . The WSe2 FETs exhibit an on/off ratio of 10<sup>7</sup> within a _V_ TG value of ±1.0 V. The near-ideal SS and negligible residual doping illustrate the high quality of the STO–2D material interfaces. Double-gate and Hall-effect measurements on graphene devices yield an effective dielectric constant of 17–20, which is higher than that of HfO2 ( _κ_ ≈ 13–17)<sup>26,27</sup> , when grown by atomic layer deposition on 2D materials. We also create a low-power complementary metal–oxide–semiconductor (CMOS) inverter that has a static power consumption of only several picowatts by combining STO-gated n-type MoS2 and p-type WSe2 transistors. 

#### **Fabrication of STO–2D material heterostructures** 

Our integration of STO on 2D layered materials begins with the sequential pulsed laser deposition (PLD) of Sr3Al2O6 (SAO) and STO layers on STO substrates<sup>28–31</sup> (Methods provides details of growth) (Fig. 1a). Next, the surface of the as-grown STO thin film was covered with a thin polydimethylsiloxane (PDMS) sheet. The stack was then floated in a deionized (DI) water bath to etch the sacrificial SAO layer and produce an STO membrane adhering to the PDMS sheets due to van der Waals forces (Supplementary Fig. 1 shows the optical images of the STO membrane on PDMS). This membrane was then deliberately ruptured and transferred onto multiple PDMS sheets by repetitive laminating and peeling the PDMS sheets to produce scattered micrometre-sized STO flakes. In this way, we could choose STO flakes with lateral sizes similar to those of mechanically exfoliated 2D materials, facilitating subsequent device fabrication. The STO flakes on PDMS were accurately aligned and brought into contact with target 2D flakes on SiO2/Si substrates and being monitored under a microscope. 

> 1Division of Physics and Applied Physics, School of Physical and Mathematical Sciences, Nanyang Technological University, Singapore, Singapore. 

> 2International Center for Quantum Materials, School of Physics, Peking University, Beijing, People’s Republic of China. 3Electron Microscopy Laboratory, School of Physics, Peking University, Beijing, People’s Republic of China.<sup>4</sup> State Key Laboratory of Low-Dimensional Quantum Physics and Department of Physics, Tsinghua University, Beijing, People’s Republic of China.<sup>5</sup> Beijing Academy of Quantum Information Sciences, Beijing, People’s Republic of China.<sup>6</sup> School of Electrical and Electronic Engineering, Nanyang Technological University, Singapore, Singapore.<sup>✉</sup> e-mail: yangjian@ntu.edu.sg; renshaw@ntu.edu.sg 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**233** 

<mark>Articles</mark> 



<!-- Start of picture text -->
Articles Nature electroNics<br>a b c<br>PDMS STO<br>(i) (ii)<br>STO MoS2<br>SAO<br>STO 40<br>Water 20<br>0<br>0 2 4 6 8<br>Distance (µm)<br>(iii) (iv)<br>Objective d e<br>PDMS lens<br>PDMS<br>STO<br>O<br>Ti<br>2D material Sr<br>S<br>SiO2 Mo<br>STO Si<br>Height (nm)<br><!-- End of picture text -->

**Fig. 1 | STO–2D material heterostructures on SiO2/Si. a** , Schematic of the fabrication process: (i) sequential PLD growth of SAO and STO on a bulk STO substrate; (ii) the surface of the STO thin film is covered with a PDMS sheet and the stack is then floated in a DI water bath to dissolve the sacrificial SAO layer; (iii) the PDMS sheet supporting the STO membrane is laminated with another PDMS sheet and peeled off slowly, yielding micrometre-sized STO flakes on both PDMS sheets; (iv) a micrometre-sized STO flake is aligned and laminated, under a microscope, onto a 2D material on SiO2/Si. The PDMS sheet is then peeled off, leaving STO on SiO2/Si. **b** , Optical image of a representative STO–MoS2 heterostructure on SiO2/Si. The inset displays the optical image of the original MoS2 flake. Scale bars, 10 µm. **c** , AFM height image of the heterostructure shown in **b** . Scale bar, 5 µm. The inset shows the height profile along the marked line, from which the thicknesses of MoS2 (3.4 nm) and STO (45.9 nm) were extracted. **d** , Schematic of three-dimensional cubic and 2D layered crystal structures of STO and MoS2. **e** , Cross-sectional HAADF-STEM image of an STO–MoS2 heterointerface. Scale bar, 2 nm. 

Last, the PDMS was peeled off slowly, leaving the STO flakes on SiO2/Si substrates because of a stronger interaction between STO and SiO2 than that between STO and PDMS<sup>32</sup> . The freestanding STO film can be transferred, in principle, onto any 2D material, which is crucial for fabricating complex electronic circuits involving 2D materials with different electronic properties. 

A representative STO–MoS2 heterostructure on SiO2/Si is shown in Fig. 1b. Transferring STO on MoS2 did not induce noticeable contamination. The morphology of this heterostructure was further examined by atomic force microscopy (AFM) imaging (Fig. 1c). Both STO and MoS2 flakes exhibited uniform thicknesses and clean surfaces. Conformal contact was formed at the heterointerface, although STO has a distinctively different crystal structure compared with MoS2 (Fig. 1d). Figure 1e shows the high-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) image of an STO–MoS2 interface. Individual atoms of STO arranged in a cubic lattice can be clearly identified in the STEM image and the X-ray diffraction peaks of STO film transferred on the SiO2/Si substrate can be clearly identified (Supplementary Fig. 1). Both these results confirm the excellent crystallinity of STO even after transfer. The intact layered structure of MoS2 demonstrates that the van der Waals integration process is non-invasive to the underlying 2D materials. 

#### **Dielectric properties of transferred STO** 

The quantitative evaluation of the effective dielectric constant of transferred STO flakes, which includes contributions from the van der Waals gap and interfacial impurities, is not currently available experimentally. Therefore, to ensure the accuracy of the extracted value, we employed two methods: double-gate<sup>33</sup> and Hall-effect<sup>34</sup> measurements. Figure 2a shows a graphene Hall bar device on a p-Si substrate with a 285 nm SiO2 capping layer. SiO2 and STO act as the bottom- and top-gate dielectric layers, respectively. 

The graphene sheet was patterned by electron-beam lithography and etched into a Hall bar using oxygen plasma before being covered with STO (Supplementary Fig. 2). The thicknesses of STO (44.2 nm) and graphene (double layer) were determined by AFM and Raman spectroscopy, respectively (Supplementary Fig. 3). The charge carrier concentration in graphene can be simultaneously modulated by the top and bottom gates. As a result, the top-gate transfer curves shift with a varying back-gate voltage ( _V_ BG) (Fig. 2b). The slope of the top-gate Dirac point voltage ( _V_ DIRAC,TG), which marks charge neutrality, versus _V_ BG is equal to the ratio of the bottom-gate to top-gate capacitance (CSiO2 /CSTO), if the parallel-plate capacitor model is assumed for both top and bottom gates<sup>27,33</sup> . Substituting the fitted value (0.03) in Fig. 2c into 



<!-- Start of picture text -->
CSiO2 = ε SiO2 tSTO , (1)<br>CSTO ε STOtSiO2<br><!-- End of picture text -->

where _ε_ STO and _ε_ SiO2 (3.9) are the dielectric constants of STO and SiO2, respectively, and _t_ STO and tSiO2 are the thicknesses of STO and SiO2, respectively, we derived _ε_ STO of 20.2 from this device, which corresponds to a capacitance of 0.4 µF cm<sup>−2</sup> . 

Carrier concentrations, from which the dielectric constant of STO can also be derived, were directly extracted by Hall-effect measurements. Figure 2d shows that the Hall resistance ( _Rxy_ ) linearly depends on the magnetic field ( _B_ ) at different _V_ TG values. The _Rxy_ – _B_ slope is equal to 1/( _en_ 2D) or 1/( _ep_ 2D) depending on the carrier type, where _e_ , _n_ 2D and _p_ 2D are the elementary charge, electron concentration and hole concentration, respectively. At _V_ TG away from the Dirac point, one type of carrier dominates in graphene and their concentration changes linearly with _V_ TG (ref.<sup>35</sup> ). From the linear fit of _p_ 2D– _V_ TG (Fig. 2e), the top-gate capacitance _C_ STO is calculated to be 0.34 µF cm<sup>−2</sup> according to d _p_ 2D/d _V_ TG = _C_ STO/ _e_ . The accuracy of the Hall-effect measurements was further verified by its application in 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**234** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a b c<br>Gr 1.2<br>Au V T GG<br>STO 6 V BG = 0 to 50 V; step = 10 V<br>SiO2 0.8 Slope = −0.03<br>p-Si V B GG<br>4 0.4<br>0<br>2<br>–0.4<br>0 –0.8<br>–1.0 –0.5 0 0.5 1.0 10 20 30 40 50<br>V TG (V) V BG (V)<br>d e f<br>0.6 5 10 0<br>0.4 V TG = −1.0 to 0.6 V Slope =<br>Step = 0.4 V 4 −2.13 × 10 12  cm −2  V −1 10 –2<br>0.2 V BG = 0 V<br>0 3 10 –4<br>–0.2<br>2 10 –6<br>–0.4<br>–0.6 1 10 –8<br>–1.0 –0.5 0 0.5 1.0 –1.2 –0.8 –0.4 0 0.4 –10 –5 0 5 10<br>B  (T) V TG (V) V TG (V)<br>–1 (k) R Ω sqS  (V) V DIRAC,TG<br> (k)  R Ω xy<br>−2 (A cm) J TG<br>−212 (10) cm p 2D<br><!-- End of picture text -->

**Fig. 2 | Dielectric constant and strength of STO top-gate dielectrics. a** , Optical image of a graphene Hall bar device with STO top-gate dielectrics. The boundary of the double-layer graphene is indicated by the dashed line. Scale bar, 10 µm. The inset illustrates the device geometry. **b** , Sheet resistance ( _R_ S) of graphene (Gr) as a function of top-gate voltages ( _V_ TG) at different back-gate voltages ( _V_ BG). **c** , _V_ BG-dependent top-gate Dirac voltages ( _V_ DIRAC,TG). The linear fitting, represented by the solid line, yields a slope of −0.03. **d** , Hall resistance ( _Rxy_ ) as a function of magnetic field ( _B_ ) at different _V_ TG values. **e** , Hole concentration ( _p_ 2D) versus _V_ TG, extracted from the linear fitting of _Rxy_ – _B_ relations in **d** . The solid line indicates the linear fitting of _p_ 2D– _V_ TG. **f** , Leakage current density ( _J_ TG) versus _V_ TG of three representative devices. 

back gating. They yield _ε_ SiO2 of 4.0 (Supplementary Fig. 4), which matches the theoretical value of SiO2 (3.9–4.0). It is worth noting that the extracted _ε_ STO from double-gate (20.2) and Hall-effect (17.2) measurements includes contributions from polymethyl methacrylate (PMMA) residues between STO and graphene, which reduce the effective capacitance and dielectric constant. Nonetheless, these values are already greater than that of atomic-layer-deposited HfO2 on 2D materials, demonstrating the feasibility of using STO for practical devices<sup>27</sup> . 

The dielectric strength of STO was also investigated. Leakage currents through Au–STO–graphene stacks ( _J_ TG) display similar attributes (Fig. 2f). The leakage current is very small and below the detection limit of our measurement setup (~10<sup>−13</sup> A) when _V_ TG is within the range of roughly −4 to 2 V. Beyond this range, _J_ TG increases rapidly but no catastrophic failure is observed within ±10 V, which corresponds to a nominal electric field of around 2.5 MV cm<sup>−1</sup> . These results prove the electrical robustness of the transferred STO. In addition, the forward-biased _J_ TG is substantially larger than the reverse-biased _J_ TG, which can be explained by the band alignment of the heterostructures (Supplementary Fig. 5). STO is an insulator with a bandgap of 3.3 eV (ref.<sup>36</sup> ), and the Fermi level of graphene, which can be tuned by _V_ TG, aligns closer to the conduction band edge of STO. As a result, electrons (holes) can be injected into STO at a large positive (negative) _V_ TG, and electron injection starts at a smaller bias. Such leakage behaviour does not deter the operation of 2D transistors because the large dielectric constant of STO, compared with more commonly used dielectric materials for 2D electronics such as hexagonal boron nitride (hBN), Al2O3 and HfO2 (Supplementary Table 1), provides sufficient 

electrostatic modulation to 2D semiconductors at small gate voltages, as demonstrated in the following sections. 

#### **MoS2 transistors with STO top-gate dielectrics** 

As the most studied 2D semiconductor for field-effect transistors, few-layer (FL) MoS2 was selected to prove the feasibility of STO as the dielectric layer in high-performance transistors. To fully explore the potential of STO-gated MoS2 transistors, we employed FL graphene as the drain/source electrodes for the following reasons. First, its gate-tuneable Fermi level facilitates barrier-free injection of charge carriers into 2D semiconductors<sup>37,38</sup> . Second, its atomically flat and ultrathin nature allows the fabrication of multilayer van der Waals heterostructures with clean and flat interfaces<sup>39–41</sup> . Third, the mechanical flexibility and optical transparency of graphene are desirable for potential flexible and transparent electronics based on 2D semiconductors<sup>42</sup> . To fabricate graphene-contacted MoS2 transistors, we sequentially transferred graphene, MoS2 and STO on SiO2/Si substrates (Supplementary Fig. 6). The device structure is sketched in Fig. 3a. The channel length and width of the fabricated device based on an FL MoS2 flake and 38.1 nm STO (Fig. 3b, inset) are 5.4 µm and 4.8 µm, respectively. The graphene electrodes are beneath MoS2 and overlap with the top gate so that the whole MoS2 channel as well as the graphene–MoS2 contact regions are simultaneously modulated by the top gate. Thus, the transistor is effectively turned on and off by applying _V_ TG within the range of ±1 V. As shown in Fig. 3c and Supplementary Fig. 7, the output curves are linear when _V_ DS is small, indicating ohmic contacts. When _V_ DS further increases, _I_ DS gradually saturates, signalling pinch-off of the MoS2 channel at larger _V_ DS. The transfer curves in Fig. 3b, measured 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**235** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a b 10 –4 c 15<br>V DS = V TG = 0 to 1.0 V<br>V DS 10 –6 0.5 V 12 Step = 0.1 V<br>50 mV<br>10 –8 9<br>V TG<br>66 mV dec–1 S STO MoS2<br>Top gate 10 –10 6<br>TG<br>STO Gr<br>V BG S MoS2 D 10 –12 3<br>Gr SiO2 Gr<br>D<br>p-Si 10 –14 0<br>–1.0 –0.5 0 0.5 1.0 0 0.2 0.4 0.6 0.8 1.0<br>V TG (V) V DS (V)<br>d 0.20 e f<br>70<br>Without STO 10 9 2.5 V<br>(ref.  51 )<br>0.15 60 With STO (ref.  49 ) This work<br>1.7 V<br>0.10 50 10 8 (ref. −2.0 V 13 ) 1 V (ref. −4.0 V 10 )<br>40<br>10 7 0.8 V −3.0 V 2.0 V<br>0.05 60 mV dec–1 30 (ref.  27 ) (ref.  48 ) (ref.  11 )<br>20 10 6 −3.0 V 2.0 V<br>0 (ref.  50 ) (ref.  39 )<br>10 –12 10 –11 10 –10 10 –9 10 –8 10 –7 1 2 3 4 5 6 7 60 70 80 90<br>I DS (A) Device number SS (mV dec −1 )<br> (A) I DS  (A) I µDS<br>/ II offon<br>−1SS (V dec) 2−1−1)(cm V s µ<br><!-- End of picture text -->

**Fig. 3 | High-performance Gr-contacted MoS2 transistors with STO top-gate dielectrics. a** , Schematic of the double-gated transistor together with the electrical measurement configuration. S, source; D, drain. **b** , Double-sweep _I_ DS– _V_ TG characteristics of the device with the back gate grounded. The gate sweeping directions are indicated by the arrows. The inset shows the optical image of the device. The boundaries of graphene and MoS2 are outlined by dashed lines. Scale bar, 10 µm. **c** , Output curves ( _I_ DS– _V_ DS) with _V_ TG varying from 0 to 1.0 V at steps of 0.1 V. **d** , Subthreshold swing (SS) as a function of _I_ DS. **e** , Mobility ( _µ_ ) of MoS2 measured by four-probe (device numbers 1–4) and two-probe (device numbers 5–7) method before and after the deposition of STO. **f** , A comparison of the current on/off ratio ( _I_ on/ _I_ off) and SS of our transistor with state-of-the-art MoS2 transistors with hBN or high- _κ_ dielectrics in the literature<sup>10,11,13,27,39,48–51</sup> . The required gate voltages for the corresponding _I_ on/ _I_ off and SS are also labelled. 

with the back gate grounded ( _V_ BG = 0 V), display characteristics of a typical n-type transistor with a current on/off ratio ( _I_ on/ _I_ off) of over 10<sup>8</sup> at a drain–source bias ( _V_ DS) of 0.5 V and an SS value as small as 66 mV dec<sup>−1</sup> , close to the thermionic limit at room temperature (60 mV dec<sup>−1</sup> ). The SS remains low for _I_ DS of several orders of magnitude (Fig. 3d). Little hysteresis in the _I_ DS– _V_ TG or SS– _I_ DS curves is observed between the forward and reverse top-gate sweeping, indicating a low interfacial trap density. The reproducibility of these performance metrics was verified by the measurements of nine devices (Supplementary Table 2). 

The high _I_ on/ _I_ off at small operation voltages of our STO-gated MoS2 transistors can be attributed to the following three reasons. First, the top-gate electrode and high- _κ_ STO covers both MoS2 channel and graphene–MoS2 contacts and simultaneously exerts strong electrostatic modulation to them. Thus, the on current is not limited by the access resistance (Supplementary Fig. 8), which exists in many locally top-gated MoS2 transistors<sup>10,27</sup> . Second, the near-ideal SS value permits turning the transistor on and off within a narrow gate-voltage span. It originates from a relatively small capacitance related to the interfacial traps compared with the dielectric capacitance of STO according to 



<!-- Start of picture text -->
SS = (ln10) , (2)<br>( kBqT ) ( CSTOCSTO + Cit )<br><!-- End of picture text -->

where _k_ B, _T_ , _q_ , _C_ STO and _C_ it are the Boltzmann constant, absolute temperature, elementary charge, areal capacitance of STO and areal capacitance related to interfacial traps, respectively<sup>13,43</sup> . Third, the deposition of STO has a trivial effect on the doping level and mobility 

of MoS2. In recent reports, it was shown that the atomic layer deposition of high- _κ_ dielectrics tends to exert a considerable n-doping effect on MoS2 to the extent that a large negative top-gate voltage is required to turn off the transistors<sup>13,15,44</sup> . Such a doping effect has been frequently attributed to the unbalanced positive charges in the dielectric layer<sup>15,45</sup> . In contrast, the van der Waals integration of STO has a negligible doping effect on MoS2, indicating little net charges in STO. This phenomenon is proved by the very similar back-gate transfer characteristics of MoS2 transistors before and after the deposition of STO (Supplementary Fig. 9c). The _I_ DS– _V_ BG curves show little horizontal shift and the transistor without and with the STO coverage is switched off at almost the same _V_ BG. The high- _κ_ dielectric environment has been proposed as a booster for the mobility of MoS2 because it benefits the screening of charged impurity scattering<sup>34,46</sup> . However, the extra high- _κ_ dielectrics also bring additional scattering sources, such as trapped charges in high- _κ_ dielectrics and at the interfaces, which deteriorate the mobility<sup>44,46,47</sup> . The mobility of MoS2 before and after the deposition of STO was investigated by both twoand four-probe field-effect measurements (Supplementary Fig. 9 and Supplementary Table 3). As shown in Fig. 3e, the mobility exhibits varied behaviours for the seven devices, but the change after STO deposition is generally small. The relatively unchanged mobility compared with that before covering with STO is probably due to counteraction from the previously mentioned opposed effects. Nonetheless, the retained value of mobility allowed the STO-gated MoS2 transistors to exhibit sufficient on-state conductance leading to _I_ on/ _I_ off over 10<sup>8</sup> within the _V_ TG range of ±1 V. 

Figure 3f shows that the performance of our MoS2 transistors is competitive compared with the state-of-the-art MoS2 transistors 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**236** 

<mark>Articles</mark> 

**Nature electroNics** 



<!-- Start of picture text -->
a 10 –5 b<br>p-FET<br>V BG = −40 to 40 V 10 –6<br>n-FET<br>Step = 10 V<br>10 –7<br>10 –8 V DD<br>p-FET<br>10 –9<br>10 –10 V IN<br>V OUT<br>10 –11 n-FET<br>10 –12<br>V DS = 50 mV<br>10 –13 10 –14<br>–1.0 –0.5 0 0.5 1.0 –1.0 –0.5 0 0.5 1.0<br>V TG (V) V TG (V)<br>c 1.0 d<br>15 V DD =<br>10 –7<br>V DD = 1.0 V<br>1.0 V 0.5 V<br>10 10 –9<br>0.5 V<br>0.5<br>5 10 –11<br>10 –13<br>0<br>0 0.5 1.0 1.5<br>V IN (V)<br>0 10 –15<br>0 0.5 1.0 1.5 0 0.5 1.0 1.5<br>V IN (V) V IN (V)<br> (A) I DS  (A) I DS<br> (V) V OUT Voltage gain<br>Power (W)<br><!-- End of picture text -->

**Fig. 4 | low-power CMOS inverter based on WSe2 p-type and MoS2 n-type transistors. a** , Transfer curves ( _I_ DS– _V_ TG) of the MoS2 transistor at different back-gate voltages. **b** , _I_ DS– _V_ TG of the WSe2 transistor (p-FET) and MoS2 transistor (n-FET) at _V_ BG = −40 V. They were measured at _V_ DS = 1 V (n-FET) and _V_ DS = −1 V (p-FET). The inset shows the circuit diagram of the CMOS inverter. _V_ DD, _V_ IN and _V_ OUT stand for the supply voltage, input voltage and output voltage, respectively. **c** , Voltage transfer curves of a CMOS inverter built on a WSe2 p-type and MoS2 n-type transistor. The inset shows the voltage gain (−d _V_ OUT/d _V_ IN) of the inverter. **d** , Instantaneous power consumed by the inverter against _V_ IN. 

employing hBN or high- _κ_ dielectrics, such as HfO2 and Al2O3, in terms of _I_ on/ _I_ off and SS. A large _I_ on/ _I_ off is indispensable for the explicit recognition of the on and off states for practical digital electronics. A smaller SS means more abrupt switching of the transistor between the on and off states because SS represents the minimum required change in the gate voltage for a tenfold increase in _I_ DS. In addition, the magnitude of the required gate voltage also depends on the initial doping level of MoS2, which shifts the _I_ DS– _V_ BG curves close to or away from the zero gate voltage (as explained above). The required gate voltages for the corresponding _I_ on/ _I_ off and SS are labelled in Fig. 3f for comparison. As can be seen, the magnitude of the required gate voltages of our STO-gated MoS2 transistors is also among the lowest. 

#### **low-power CMOS inverter** 

The top-gate transfer characteristics of our MoS2 transistors can be tuned by _V_ BG (Fig. 4a). As _V_ BG decreases, the _I_ DS– _V_ TG curves shift monotonously in the positive direction. At a large negative _V_ BG, the transistor transforms into the enhancement mode, which means the threshold voltage ( _V_ TH) becomes positive, and a positive _V_ TG is required to switch on the transistor. In particular, with a back-gate biasing of −30 V, _I_ DS is below 1 pA at _V_ TG = 0 V. However, due to the preserved low SS, _I_ DS reaches over 1 µA at _V_ TG of only 1 V, dis- 

playing an _I_ on/ _I_ off of over 10<sup>7</sup> (Fig. 4b). These merits demonstrate that our top-gated transistor can operate with a very low standby power consumption. It is worth noting that both dynamic and static power consumed by back-gate biasing are negligible since _V_ BG is fixed and the d.c. current through the relatively thick SiO2 is negligible. Tuning _V_ TH by back-gate biasing in this work is analogous to the back-gate biasing strategy in advanced silicon-on-insulator and FinFET technologies<sup>52,53</sup> . Properly scaling the thickness of the bottom SiO2 may reduce the required _V_ BG to a value comparable to _V_ TG. The combination of near-ideal subthreshold slope, large _I_ on/ _I_ off and small operation voltage of our transistors is especially useful for low-power electronic applications. 

Low-power digital circuits are critical to extend the service time of ubiquitous portable devices that rely on batteries, as well as to avoid overheating that leads to the malfunction of processors. As usually implemented for emerging materials and technologies<sup>54,55</sup> , the potential of our STO-gated transistors for low-power digital circuits was verified by fabricating and testing inverters (or ‘NOT’ logic gates), the basic functional unit in CMOS digital circuits. A CMOS inverter (circuit diagram shown in Fig. 4b, inset) consists of a p-type and n-type transistor in series and their conductance is simultaneously controlled by a single gate voltage ( _V_ IN). It outputs a logic state that opposes the input and these logic states are represented by 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**237** 

<mark>Articles</mark> 

**Nature electroNics** 

the respective voltage levels. To fabricate the CMOS inverter, we realized p-type transistors with a local STO top gate through chemical doping and back-gate biasing of WSe2 (Supplementary Fig. 10). The transfer characteristic of the WSe2 transistor (Fig. 4b) reveals _I_ on/ _I_ off of ~10<sup>7</sup> within the _V_ TG range of ±1 V. Connecting the WSe2 and MoS2 transistors in the inverter configuration, we obtained an excellent inversion action (voltage transfer characteristics are shown in Fig. 4c). When the input voltage ( _V_ IN) is zero (corresponding to logic ‘0’), the output voltage ( _V_ OUT) approaches the supply voltage ( _V_ DD), corresponding to logic ‘1’. On the contrary, when _V_ IN is increased to a higher value (logic ‘1’), _V_ OUT is close to zero (logic ‘0’). Benefitting from the gate-tuneable _I_ DS– _V_ TG characteristics of our MoS2 transistors, the inverter functions well at totally positive voltages, a requirement for practical applications. The peak values of voltage gain (10.5 at _V_ DD = 0.5 V and 14.2 at _V_ DD = 1.0 V), defined as −d _V_ OUT/d _V_ IN, are far greater than unity, demonstrating that our inverter is robust to errors and suitable for multistage logic circuits. 

The total power consumed by an inverter in practical CMOS digital circuits include dynamic, static and short-circuit power<sup>56</sup> . The dynamic power results from the charging and discharging of the next-stage metal–oxide–semiconductor capacitor during switching and is proportional to the square of the operation voltages. Therefore, the minimized operation voltages of our transistors should be highly beneficial for a reduction in dynamic power. To analyse the static and short-circuit power consumed by our inverter, we plotted the instantaneous power against _V_ IN (Fig. 4d). The instantaneous power is equal to _V_ DD × _I_ DD, where _I_ DD is the current flowing from supply to ground. The static power, that is, the power consumed at idle ‘0’ or ‘1’ states, comes mainly from subthreshold conduction. The static power consumed by our inverter is shown to be at the picowatt level, which is difficult to achieve with typical 2D semiconductor-based CMOS inverters due to subthreshold current still consuming considerable power at _V_ IN = 0 V. The short-circuit power, which is the instantaneous power at _V_ IN other than the ‘0’ and ‘1’ states, has peak values of 21 nW at _V_ DD = 0.5 V and 0.34 µW at _V_ DD = 1.0 V. Although these values are not outstanding, the short-circuit power makes up a very small portion of the total power because the inverter stays at the ‘0’ and ‘1’ states for most of the time during each functioning cycle of digital circuits<sup>56</sup> . It is also worth mentioning that our locally gated WSe2 transistors operate in the depletion mode. This fact limits the voltage gain, increases the required _V_ IN (higher than the respective _V_ DD) to switch off the p-type WSe2 transistor of the inverter and deteriorates the short-circuit power. The realization of enhancement-mode p-type transistors, whose performance matches the MoS2 n-type transistors, should improve the gain and power consumption further. 

#### **Conclusions** 

We have shown that thin films of high- _κ_ STO can be integrated with 2D materials using a van der Waals approach. Using stacked STO as the top dielectric material, we created a MoS2 n-type transistor that, due to the large dielectric constant of STO and excellent interfacial quality, exhibits an _I_ on/ _I_ off value of over 10<sup>8</sup> at a supply voltage of 1 V and minimum SS of 66 mV dec<sup>−1</sup> . We also created a CMOS inverter with picowatt standby power consumption by combining the n-type MoS2 transistors with p-type WSe2 transistors. Our van der Waals integration strategy circumvents many technical problems of established methods, which tend to deteriorate the interface quality or restrict material combinations during fabrication, and other complex oxides and 2D materials may be able to adopt this strategy to construct high-performance devices and circuits. Our approach provides a potential route to a wide range of hybrid oxide–oxide and oxide–2D material heterostructures, which could be used to create advanced forms of electronics such as hybrid spintronics and oxide-based twistronics. 

#### **Methods** 

**Material preparation.** STO/SAO bilayer films were sequentially grown by PLD on TiO2-terminated STO(001) substrates with sintered SAO and STO ceramic targets. Before the deposition, the STO substrates were buffered HF etched and then annealed at 950 °C to achieve a TiO2-terminated atomically flat surface<sup>57</sup> . During growth, the target materials were vapourized by irradiation of an excimer laser (wavelength _λ_ = 248 nm) operated with a repetition rate of 2 Hz and a laser fluence of 1.8 J cm<sup>−2</sup> , whereas the STO substrates were kept at 760 °C. The partial pressures of oxygen ( _P_ O2) for the growth of SAO and STO were 1 × 10<sup>−6</sup> and 1 × 10<sup>−2</sup> torr, respectively. After deposition, all the samples were cooled down to room temperature at the rate of 10 °C min<sup>–1</sup> under a _P_ O2 value of 1 × 10<sup>−2</sup> torr. 

SiO2/Si substrates were treated with oxygen plasma (CUTE-1MPR dual-mode plasma processing system, Femto Science) for 5 min at a power of 50 W before mechanical exfoliation and transfer of graphene (Gr), MoS2 and WSe2. To transfer MoS2 on Gr, MoS2 flakes on SiO2/Si were lifted off by PDMS sheets using a wedging transfer method<sup>58</sup> . Briefly, the surface of the SiO2/Si substrate supporting the target MoS2 flake was covered with a PDMS sheet. Then, DI water was added to the surrounding of the PDMS sheet, and it slowly penetrated into the gap between PDMS and SiO2 because the SiO2 surface is hydrophilic after oxygen plasma treatment. The PDMS sheet with the target MoS2 flake finally floated up on the surface of DI water. The PDMS/MoS2 stack was then picked up, dried and transferred onto graphene on another SiO2/Si substrate using the method described earlier. 

**Material characterization.** HAADF-STEM images were obtained at 300 kV using an aberration-corrected FEI Titan Themis G2 instrument. The AFM images were measured in the tapping mode using a Cypher ES Environmental AFM (Asylum Research). Raman spectra were measured on a WITec alpha300 confocal Raman system with an excitation wavelength of 532 nm. 

**Device fabrication.** Drain, source and top-gate electrodes were defined by electron-beam lithography followed by thermal deposition of 5 nm Cr and 60–100 nm Au. 

**Electrical measurements.** The transistors were bonded to chip carriers and measured using a Keithley 2635b sourcemeter and two Keithley 2450 sourcemeters in a shielded vacuum chamber (0.1 mbar) at room temperature. The CMOS inverters were measured with an additional Keithley 2230G power supply. Two-terminal _I_ – _V_ measurements were performed using the Keithley 2635b sourcemeter. Hall-effect measurements were carried out in a helium atmosphere (~0.1 torr) in an Oxford TeslatronPT cryostation equipped with a magnetic field of up to 8 T. 

#### **Data availability** 

The data that support the conclusions in this paper are available from the corresponding authors upon reasonable request. 

Received: 29 March 2021; Accepted: 21 March 2022; Published online: 25 April 2022 

#### **References** 

1. Kingon, A. I., Maria, J.-P. & Streiffer, S. Alternative dielectrics to silicon dioxide for memory and logic devices. _Nature_ **406** , 1032–1038 (2000). 

2. Gusev, E. et al. Ultrathin high- _K_ gate stacks for advanced CMOS devices. In _International Electron Devices Meeting. Technical Digest (Cat. No.01CH37224)_ 20.1.1–20.1.4 (IEEE, 2001). 

3. Bohr, M. T., Chau, R. S., Ghani, T. & Mistry, K. The high- _k_ solution. _IEEE Spectr._ **44** , 29–35 (2007). 

4. Packan, P. et al. High performance 32nm logic technology featuring 2nd generation high- _k_ + metal gate transistors. In _2009 IEEE International Electron Devices Meeting (IEDM)_ 1–4 (IEEE, 2009). 

5. Franklin, A. D. Nanomaterials in transistors: from high-performance to thin-film applications. _Science_ **349** , aab2750 (2015). 

6. Chhowalla, M., Jena, D. & Zhang, H. Two-dimensional semiconductors for transistors. _Nat. Rev. Mater._ **1** , 16052 (2016). 

7. Liu, Y., Duan, X., Huang, Y. & Duan, X. Two-dimensional transistors beyond graphene and TMDCs. _Chem. Soc. Rev._ **47** , 6388–6409 (2018). 

8. Akinwande, D. et al. Graphene and two-dimensional materials for silicon technology. _Nature_ **573** , 507–518 (2019). 

9. Resta, G. V. et al. Devices and circuits using novel 2-D materials: a perspective for future VLSI systems. _IEEE Trans. Very Large Scale Integr. (VLSI) Syst._ **27** , 1486–1503 (2019). 

10. Radisavljevic, B., Radenovic, A., Brivio, J., Giacometti, V. & Kis, A. Single-layer MoS2 transistors. _Nat. Nanotechnol._ **6** , 147–150 (2011). 

11. Wang, H. et al. Integrated circuits based on bilayer MoS2 transistors. _Nano Lett._ **12** , 4674–4680 (2012). 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**238** 

### **Nature electroNics** 

12. McDonnell, S. et al. HfO2 on MoS2 by atomic layer deposition: adsorption mechanisms and thickness scalability. _ACS Nano_ **7** , 10354–10361 (2013). 

13. Zou, X. et al. Interface engineering for high‐performance top‐gated MoS2 field‐effect transistors. _Adv. Mater._ **26** , 6255–6261 (2014). 

14. Kim, H. G. & Lee, H.-B.-R. Atomic layer deposition on 2D materials. _Chem. Mater._ **29** , 3809–3826 (2017). 

15. Sheng, Y. et al. Gate stack engineering in MoS2 field‐effect transistor for reduced channel doping and hysteresis effect. _Adv. Electron. Mater_ . **7** , 2000395 (2020). 

16. Li, T. et al. A native oxide high- _κ_ gate dielectric for two-dimensional electronics. _Nat. Electron._ **3** , 473–478 (2020). 

17. Tu, T. et al. Uniform high- _k_ amorphous native oxide synthesized by oxygen plasma for top-gated transistors. _Nano Lett._ **20** , 7469–7475 (2020). 

18. Liang, S. J., Cheng, B., Cui, X. & Miao, F. Van der Waals heterostructures for high‐performance device applications: challenges and opportunities. _Adv. Mater_ . **32** , 1903800 (2019). 

19. Liu, Y., Huang, Y. & Duan, X. Van der Waals integration before and beyond two-dimensional materials. _Nature_ **567** , 323–333 (2019). 

20. Sakudo, T. & Unoki, H. Dielectric properties of SrTiO3 at low temperatures. _Phys. Rev. Lett._ **26** , 851 (1971). 

21. Couto, N. J., Sacépé, B. & Morpurgo, A. F. Transport through graphene on SrTiO3. _Phys. Rev. Lett._ **107** , 225501 (2011). 

22. Veyrat, L. et al. Helical quantum Hall phase in graphene on SrTiO3. _Science_ **367** , 781–786 (2020). 

23. Liu, Y. et al. Thermal oxidation of WSe2 nanosheets adhered on SiO2/Si substrates. _Nano Lett._ **15** , 4979–4984 (2015). 

24. Liu, X., Wood, J. D., Chen, K.-S., Cho, E. & Hersam, M. C. In situ thermal decomposition of exfoliated two-dimensional black phosphorus. _J. Phys. Chem. Lett._ **6** , 773–778 (2015). 

25. Rao, R., Islam, A. E., Campbell, P. M., Vogel, E. M. & Maruyama, B. In situ thermal oxidation kinetics in few layer MoS2. _2D Mater._ **4** , 025058 (2017). 

26. Sangwan, V. K. et al. Quantitatively enhanced reliability and uniformity of high- _κ_ dielectrics on graphene enabled by self-assembled seeding layers. _Nano Lett._ **13** , 1162–1167 (2013). 

27. Li, W. et al. Uniform and ultrathin high- _κ_ gate dielectrics for two-dimensional electronic devices. _Nat. Electron._ **2** , 563–571 (2019). 

28. Lu, D. et al. Synthesis of freestanding single-crystal perovskite films and heterostructures by etching of sacrificial water-soluble layers. _Nat. Mater._ **15** , 1255–1260 (2016). 

29. Ji, D. et al. Freestanding crystalline oxide perovskites down to the monolayer limit. _Nature_ **570** , 87–90 (2019). 

30. Dong, G. et al. Super-elastic ferroelectric single-crystal membrane with continuous electric dipole rotation. _Science_ **366** , 475–479 (2019). 

31. Hong, S. S. et al. Extreme tensile strain states in La0.7Ca0.3MnO3 membranes. _Science_ **368** , 71–76 (2020). 

32. Castellanos-Gomez, A. et al. Deterministic transfer of two-dimensional materials by all-dry viscoelastic stamping. _2D Mater._ **1** , 011002 (2014). 

33. Xu, H. et al. Quantum capacitance limited vertical scaling of graphene field-effect transistor. _ACS Nano_ **5** , 2340–2347 (2011). 

34. Radisavljevic, B. & Kis, A. Mobility engineering and a metal–insulator transition in monolayer MoS2. _Nat. Mater._ **12** , 815–820 (2013). 

35. Xia, J., Chen, F., Wiktor, P., Ferry, D. & Tao, N. Effect of top dielectric medium on gate capacitance of graphene field effect transistors: implications in mobility measurements and sensor applications. _Nano Lett._ **10** , 5060–5064 (2010). 

36. Van Benthem, K., Elsässer, C. & French, R. Bulk electronic structure of SrTiO3: experiment and theory. _J. Appl. Phys._ **90** , 6156–6164 (2001). 

37. Yu, L. et al. Graphene/MoS2 hybrid technology for large-scale two-dimensional electronics. _Nano Lett._ **14** , 3055–3063 (2014). 

38. Liu, Y. et al. Toward barrier free contact to molybdenum disulfide using graphene electrodes. _Nano Lett._ **15** , 3030–3034 (2015). 

39. Lee, G.-H. et al. Highly stable, dual-gated MoS2 transistors encapsulated by hexagonal boron nitride with gate-controllable contact, resistance, and threshold voltage. _ACS Nano_ **9** , 7019–7026 (2015). 

40. Cui, X. et al. Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. _Nat. Nanotechnol._ **10** , 534–540 (2015). 

41. Avsar, A. et al. Air-stable transport in graphene-contacted, fully encapsulated ultrathin black phosphorus-based field-effect transistors. _ACS Nano_ **9** , 4138–4145 (2015). 

42. Yoon, J. et al. Highly flexible and transparent multilayer MoS2 transistors with graphene electrodes. _Small_ **9** , 3295–3300 (2013). 

43. Sze, S. M. & Ng, K. K. _Physics of Semiconductor Devices_ (John Wiley & Sons, 2006). 

44. Zou, X. et al. Dielectric engineering of a boron nitride/hafnium oxide heterostructure for high‐performance 2D field effect transistors. _Adv. Mater._ **28** , 2062–2069 (2016). 

## <mark>Articles</mark> 

45. Xu, J.-P. et al. Effects of trapped charges in gate dielectric and high- _κ_ encapsulation on performance of MoS2 transistor. _IEEE Trans. Electron Devices_ **66** , 1107–1112 (2019). 

46. Ma, N. & Jena, D. Charge scattering and mobility in atomically thin semiconductors. _Phys. Rev._ **4** , 011043 (2014). 

47. Konar, A., Fang, T. & Jena, D. Effect of high- _κ_ gate dielectrics on charge transport in graphene-based field effect transistors. _Phys. Rev. B_ **82** , 115452 (2010). 

48. Wang, J. et al. Integration of high‐ _k_ oxide on MoS2 by using ozone pretreatment for high‐performance MoS2 top‐gated transistor with thickness‐dependent carrier scattering investigation. _Small_ **11** , 5932–5938 (2015). 

49. Zhu, Y. et al. Monolayer molybdenum disulfide transistors with single-atom-thick gates. _Nano Lett._ **18** , 3807–3813 (2018). 

50. Desai, S. B. et al. MoS2 transistors with 1-nanometer gate lengths. _Science_ **354** , 99–102 (2016). 

51. Wang, X. et al. Improved integration of ultra-thin high- _k_ dielectrics in few-layer MoS2 FET by remote forming gas plasma pretreatment. _Appl. Phys. Lett._ **110** , 053110 (2017). 

52. Liu, Q. et al. Impact of back bias on ultra-thin body and BOX (UTBB) devices. In _2011 Symposium on VLSI Technology—Digest of Technical Papers_ 160–161 (IEEE, 2011). 

53. Jha, N. K. & Chen, D. _Nanoelectronic Circuit Design_ (Springer Science & Business Media, 2010). 

54. Qiu, C. et al. Scaling carbon nanotube complementary transistors to 5-nm gate lengths. _Science_ **355** , 271–276 (2017). 

55. Kong, L. et al. Doping-free complementary WSe2 circuit via van der Waals metal integration. _Nat. Commun._ **11** , 1866 (2020). 

56. Henzler, S. _Power Management of Digital Circuits in Deep Sub-Micron CMOS Technologies_ Vol. 25 (Springer Science & Business Media, 2006). 

57. Kawasaki, M. et al. Atomic control of the SrTiO3 crystal surface. _Science_ **266** , 1540–1542 (1994). 

58. Schneider, G. F., Calado, V. E., Zandbergen, H., Vandersypen, L. M. & Dekker, C. Wedging transfer of nanostructures. _Nano Lett._ **10** , 1912–1916 (2010). 

#### **Acknowledgements** 

We are grateful to S. Zeng and D. Wan for fruitful discussion regarding the PLD growth, as well as G. Chen for her help regarding the device fabrication. X.R.W. acknowledges support from the Nanyang Assistant Professorship grant from Nanyang Technological University; Academic Research Fund Tier 2 (grant nos. MOE-T2EP50120-0006 and MOE-T2EP50220-0016) and Tier 3 (grant no. MOE2018-T3-1-002) from the Singapore Ministry of Education; the Singapore National Research Foundation (NRF) under the Competitive Research Programs (CRP grant no. NRF-CRP21-2018-0003); and Agency for Science, Technology and Research (A*STAR) under its AME IRG grant (project no. A20E5c0094). Q.X. gratefully acknowledges funding support from the State Key Laboratory of Low-Dimensional Quantum Physics and start-up grant from Tsinghua University. P.G. acknowledges the support from the National Natural Science Foundation of China (grant nos. 51672007 and 11974023), the National Key R&D Program of China (grant no. 2016YFA0300804), Key Area R&D Program of Guangdong Province (2018B010109009), the Key R&D Program of Guangdong Province (2018B030327001), the National Equipment Program of China (ZDYZ2015-1), the ‘2011 Program’ Peking-Tsinghua-IOP Collaborative Innovation Center for Quantum Matter and Electron Microscopy Laboratory in Peking University for the use of the Cs-corrected electron microscope. 

#### **Author contributions** 

A.J.Y. and X.R.W. conceived the idea and designed the experiments. A.J.Y. fabricated the heterostructures and devices. A.J.Y., assisted by K. Huang and C.Y., performed the electrical measurements and analysis. K. Han grew the oxides. W.W. performed the Raman characterization. Rui Zhu, Ruixue Zhu, J.X. and P.G. performed the STEM characterization and analysis. A.J.Y. and X.R.W. wrote the manuscript. All the authors contributed to the scientific discussion and commented on the manuscript. 

#### **Competing interests** 

The authors declare no competing interests. 

#### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41928-022-00753-7. 

**Correspondence and requests for materials** should be addressed to Allen Jian Yang or X. Renshaw Wang. 

**Peer review information** _Nature Electronics_ thanks Jianping Shi and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**239** 

**Nature electroNics** 

## <mark>Articles</mark> 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other 

third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2022 

**NATuRe eleCTRONiCS** | VOL 5 | APRIL 2022 | 233–240 | www.nature.com/natureelectronics 

**240** 

