# Two-dimensional perovskite templates for durable, efficient formamidinium perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 187 |
| 作者 | S. Sidhik, Isaac Metcalf, Wenbin Li, Tim Kodalle, Connor J. Dolan, M. Khalili, Jin-Yu Hou, F. Mandani et al. |
| DOI | 10.1126/science.abq6993 |
| 源文件 | 054_Sidhik_2024_Two-dimensional-perovskite-templates-for-durable.pdf |

---
## **UC San Diego UC San Diego Previously Published Works** 

### **Title** 

Two-dimensional perovskite templates for durable, efficient formamidinium perovskite solar cells 

### **Permalink** 

<u>https://escholarship.org/uc/item/05d359b4</u> 

### **Journal** 

Science, 384(6701) 

### **ISSN** 

0036-8075 

### **Authors** 

Sidhik, Siraj Metcalf, Isaac Li, Wenbin <u>et al.</u> 

### **Publication Date** 

2024-06-14 

### **DOI** 

10.1126/science.abq6993 

### **Copyright Information** 

This work is made available under the terms of a Creative Commons Attribution License, available at https://creativecommons.org/licenses/by/4.0/ 

Peer reviewed 

<u>eScholarship.org</u> 

Powered by the California Digital Library University of California 

27 

28 29 

- 1 

2 

# **Two-dimensional perovskite templates for durable, efficient formamidinium perovskite solar cells** 

- 3 Siraj Sidhik<sup>1,2#</sup> , Isaac Metcalf<sup>1#</sup> , Wenbin Li<sup>3</sup> , Tim Kodalle<sup>4</sup> , Connor Dolan<sup>5</sup> , Mohammad Khalili<sup>2</sup> , 4 Jin Hou<sup>1</sup> , Faiz Mandani<sup>2</sup> , Andrew Torma<sup>3</sup> , Hao Zhang<sup>3</sup> , Rabindranath Garai<sup>2</sup> , Jessica Persaud<sup>2</sup> , 5 Amanda Marciel<sup>2</sup> , Itzel Alejandra Muro Puente<sup>6</sup> , G. N. Manjunatha Reddy<sup>6</sup> , Adam Balvanz<sup>7</sup> , 6 Mohamad A. Alam<sup>8</sup> , Claudine Katan<sup>9</sup> , Esther Tsai<sup>10</sup> , David Ginger<sup>11</sup> , David Fenning<sup>5</sup> , Mercouri 7 G. Kanatzidis<sup>12</sup> , Carolin M. Sutter-Fella<sup>4</sup> , Jacky Even<sup>13</sup> * and Aditya D. Mohite<sup>1,2</sup> * 

- 8 

- 9 

- 10 

- 11 

- 12 

- 13 

- 14 

15 

- 16 

17 

18 

19 

20 

21 

22 

23 

24 

25 

26 

- **1Material Science and Nanoengineering, Rice University, Houston, TX 77005, USA.** 

- **2Department of Chemical and Biomolecular Engineering, Rice University, Houston, TX 77005, USA.** 

- **3Applied Physics Graduate Program, Smalley‐Curl Institute, Rice University, Houston, TX, 77005, USA.** 

- **4Molecular Foundry, Lawrence Berkeley National Laboratory, Berkeley, CA 94720, USA** 

- **5Department of Nanoengineering, University of California, San Diego, La Jolla, CA 92093, USA.** 

- **6University of Lille, CNRS, Centrale Lille Institut, Univ. Artois, UMR 8181-UCCS-Unité de Catalyse et Chimie du Solide, F-59000 Lille, France** 

- **7Department of Chemistry, Northwestern University, Evanston, IL 60208, USA.** 

- **8School of Electrical and Computer Engineering, Purdue University, West Lafayette, IN, USA.** 

- **9Univ Rennes, ENSCR, CNRS, ISCR-UMR 6226, Rennes F-35000, France.** 

- **10Center for Functional Nanomaterials, Brookhaven National Laboratory, Upton, NY, USA** 

- **11Department of Chemistry, University of Washington, Seattle 98195.** 

- **12Department of Chemistry and Department of Materials Science and Engineering, Northwestern University, Evanston, IL 60208, USA.** 

- **13 Univ Rennes, INSA Rennes, CNRS, Institut FOTON - UMR 6082, Rennes F-35000, France.** 

***Correspondence to: jacky.even@insa-rennes.fr; adm4@rice.edu** 

30 

1 

42 

### 31 **Abstract** 

32 **We present a design strategy for fabricating ultra-stable, phase pure films of formamidinium** 33 **lead iodide (FAPbI3) by lattice templating using specific two-dimensional (2D) perovskites** 34 **with FA as the cage cation.  When a pure FAPbI3 precursor solution is brought in contact** 35 **with the 2D perovskite, the black phase forms preferentially at 100 °C, much lower than the** 36 **standard FAPbI3 annealing temperature of 150 °C. X-ray diffraction and optical** 37 **spectroscopy suggest that the resulting FAPbI3 film compresses slightly to acquire the (011)** 38 **interplanar distances of the 2D perovskite seed. The 2D templated bulk FAPbI3 films** 39 **exhibited an efficiency of 24.1% in a p-i-n architecture with 0.5 cm**<sup>**2**</sup> **active area, and an** 40 **exceptional durability with T97 of 1000 hours under 85 °C and maximum power point** 41 **tracking.** 

43 

44 Perovskite light absorbers with the chemical formula APbI3 (where A is a monovalent cation) have 45 been extensively studied in photovoltaic devices. Among the commonly used A-site cations, such 46 as formamidinium (FA), methylammonium (MA), and caesium (Cs<sup>+</sup> ), FA has shown promising 47 performance because of its lower bandgap ( _Eg_ ), improved optoelectronic properties, and higher 48 thermal stability compared to MA _(1)._ The larger size of the FA cation yields the Pm3m cubic 49 perovskite lattice through close packing, rather than the lower-symmetry tetragonal (I4/mcm) 50 lattice of MAPbI3 _(2,3)._ The lower _Eg_ value of FAPbI3 results from a high degree of Pb 6s - I 5p 51 orbital overlap and reduction of octahedral tilts.  The FAPbI3 lattice appears to be a polymorphous 52 network where the average high symmetry structure results from a random distribution of local 53 lower-symmetry (distorted) structural motifs _(4)_ . The complexity of the α- (black) phase of 3D 54 bulk FAPbI3 is also reflected by the distribution of the reported average lattice parameter values 

- 55 ranging at room temperature (RT) from _a_ ranging from 6.352 to 6.365 Å _(5,6)_ . 

2 

- 56 Moreover, the high symmetry of the FAPbI3 lattice comes at the expense of phase stability. 

57 The Goldschmidt tolerance factor of the black α-phase of three-dimensional (3D) FAPbI3 (0.987) 58 is at the edge of the stable range for the perovskite structure (0.8 to 1.0) because the FA cation is 59 almost too large for the A-site _(7)_ . As a result, the room temperature (RT) strain-free α-phase of 60 FAPbI3 presents vanishing shear and bulk elastic moduli, and a metastability against the 61 reconstructive phase conversion to the yellow, photoinactive non perovskite δ-phase _(5,8)_ . 62 Alloying FA with Cs, MA, or both at the A-site can reduce the effective A-site radius of the 63 perovskite structure and lower the tolerance factor, which improves phase stability at RT but comes 64 at the expense of a widened bandgap _(9-11)_ . 

65 Kinetically trapping the α-phase of FAPbI3 is one of the key steps to achieve stable solar 66 cell operation at RT _(12)_ . Recently, there have been several reports on FA-based perovskites which 67 with certified power conversion efficiencies (PCEs) exceeding 25% (record 26.2%) for n-i-p _(13-_ 68 _20),_ and 24% for p-i-n device architectures _(21-24)_ , often by incorporating high concentrations of 69 methylammonium chloride (MACl) _(25)_ , formamidinium formate _(16)_ , methylene diammonium 70 dichloride _(26),_ isopropyl ammonium chloride _(27)_ , and methylammonium formate _(28)_ , to 71 stabilize the black phase with a _Eg_ of 1.52 eV or higher. The large _Eg_ (compared to the lowest72 reported FAPbI3 value of 1.45 eV obtained on single crystals _(5,29)_ ) is indicative of alloying 73 between FA and MA at the A-site of the perovskite lattices. Other cations, such as Cs<sup>+</sup> _(9,30)_ , and 74 Rb<sup>+</sup> _(20,31)_ , have also been studied for their potential to improve stability. 

75 Nonetheless, the stability of these FA-based solar cells is still limited, specifically under 76 temperatures exceeding 60<sup>o</sup> C and AM1.5G light illumination under operation at maximum-power77 point tracking (MPPT). Recently, multiple studies have used bulky amine salts with FAPbI3 to 78 stabilize the α-phase through the formation of a metastable two-dimensional (2D) perovskite phase 

3 

- 79 _(19,27,32-40)_ . These 2D perovskites have the chemical formula A’2An-1PbnI3n+1, where A’ is a 

- 80 bulky monoammonium cation and n controls the thickness of the perovskite layers. Inspired by 

81 this success, we opted to combine in-plane lattice matched 2D perovskites with FAPbI3, to create 82 lattice-matched interfaces using our newly introduced 2D memory seeds method, instead of 83 employing amine salts _(41-43)_ . 

84 Here, we show that bulk FAPbI3 forms a highly stable black phase at a temperature well 85 below the δ-FAPbI3 to α-FAPbI3 transition temperature by templating the (001) interplanar spacing 86 of 3D FAPbI3 to the (011) interplanar spacing of a judiciously selected 2D phase (the respective 87 Pb-Pb interatomic spacing for each structure). The FAPbI3 precursors, when drop-cast over a film 

88 of Ruddlesden-Popper (RP) phase 2D perovskite A’2FAPb2I7, where the A’ cation can be 89 butylammonium (BA), or pentylammonium (PA), converted into black phase FAPbI3 at 90 temperatures as low as 100 °C, which is well below the 150 °C temperature at which additive-free 91 control films underwent a yellow-to-black phase transition. 

92 From our studies of film formation using correlated wide-angle x-ray scattering (WAXS), 93 optical absorbance, and photoluminescence (PL), we hypothesized that the resulting black FAPbI3 94 phase exhibited a lattice constant corresponding to the d(011) interplanar spacing of the underlying 95 2D perovskite.  We could also translate the 2D-templated stabilization of FAPbI3 to scalable 96 solution-processed methods by adding the pre-synthesized 2D perovskites powders (0.5-1.0 97 mol%) into the FAPbI3 precursor solutions. In a heterophase 3D-2D FA-based film, the phase98 stable 2D perovskite nucleated first because had a lower enthalpy of formation and was the phase 99 stable at RT.  The 2D structure presented a perovskite surface on which the 3D perovskite can 100 form by distorting to adopt the underlying 2D lattice periodicity, allowing for the preferential 101 templating of the 3D perovskite on the 2D phase during subsequent film annealing. The obtained 

4 

- 102 bulk films of FAPbI3 exhibit a bandgap ( _Eg_ ) of 1.48 eV and demonstrate exceptional durability 

- 103 under aggressive ISOS-L-2 conditions of 85<sup>o</sup> C/AM1.5G illumination and a PCE of 24.1% in a p- 104 i-n device architecture on a 0.5 cm<sup>2</sup> device area.  We believe that these results validate a novel 

- 105 design strategy for the templated growth of 3D perovskites using designer 2D perovskites, which 

- 106 share a nearly identical lattice constant. 

- 107 **Black phase stabilization of FAPbI3 with 2D perovskite template** 

- 108 The general design principle, the selection criteria, and proof-of-concept for the 2D perovskite- 

109 based templating of FAPbI3 are shown in **Fig. 1** . **Fig. 1A** shows the in-plane lattice parameter 110 corresponding to the Pb-I-Pb distance, along directions perpendicular to the (011) plane for the 2D 

111 BA2FAPb2I7 perovskite and the (001) plane for the 3D FAPbI3 perovskite, as a function of layer 112 thickness (n-value) for 2D perovskites formed with a variety of A’ site cations. The grey horizontal 

113 bar represents the range of reported lattice parameters for bulk FAPbI3 taken single-crystal 114 structural studies _(5,6)_ . The (011)<sup>2D</sup> interplanar spacings were calculated from crystal structures 115 obtained with single-crystal diffraction of each 2D perovskite. Based on the lattice parameters, we 116 hypothesized that the lattice mismatch between the 2D and 3D perovskites must be kept low to 117 minimize the 2D-3D interfacial energy and encourage growth through templating. 

- 118 We searched for FA-based 2D perovskites with an in-plane lattice parameter close to 

119 FAPbI3. As a result, we identified that 2D n=2 FA-based perovskites with the bulky cations 120 butylammonium (BA) and pentylammonium (PA), with lattice constants of 6.359 Å and 6.364 Å 121 respectively, were almost perfectly lattice matched with that of 3D FAPbI3 lattice parameters. 

- 122 However, our crystal structure analysis revealed that the phenylethylammonium (PEA) and 

- 123 octylammonium (OA) n=2 Pb-I-Pb distance was too small (6.265 Å and 6.336 Å, lattice mismatch 

- 124 of 1.5% and 0.5%, respectively) to match the 3D FAPbI3 structure. Notably, all the n=1 2D 

5 

- 125 perovskites considered were lattice mismatched with FAPbI3 and were not viable options for 126 templating the 3D phase. 

- 127 **Fig. 1B** illustrates the crystal structure of α-FAPbI3 and BA2FAPb2I7 (BA n=2) 2D 

- 128 perovskite, with a focus on the (001) and (011) planes. The typical 2D perovskite structure of 

- 129 BA2FAPb2I7 is shown, displaying the in-plane (001) and (011), and out-of-plane (200) lattice 

- 130 planes. **Fig. 1C** to **1F,** describes a preliminary experiment on the growth of a layer of FAPbI3 on a 

- 131 crystal of BA2FAPb2I7. **Fig. 1C** (schematic) and **Fig. 1D** (optical images) shows the experiment at 

- 132 different stages in time. We first partially covered a substrate with a film of red coloured, 133 millimeter-scale BA2FAPb2I7 monocrystals that were fabricated with the air-liquid interface 134 method and spread on an indium tin oxide (ITO) glass substrate. Once these crystals were dried 

- 135 on a hotplate at 100<sup>o</sup> C, we wiped away half the glass slide to create a bare glass region on about 

- 136 half of the glass area. We then added a few drops of FAPbI3 precursor solution (composed of an 

- 137 equimolar ratio of FAI and PbI2) onto the blank surface and annealed the substrate at a temperature 

- 138 of 100°, 125°, or 150°C (experiments shown in **Fig. 1** were performed at a substrate temperature 

- 139 of 100°C). The solution flowed over and react with the BA2FAPb2I7 2D perovskite crystal film. 

- 140 Upon contact with the 2D crystals, the solution spontaneously (within 10 to 15 s) transformed into 

- 141 a shiny black film. The same transformation was obtained for annealing temperatures of 125° and 

- 142 150°C. After letting the film equilibrate for 5 min, we obtained three distinct regions on the 

- 143 substrate ( **Fig. 1D)** . 

6 

144 145 **Fig. 1. Design principle and proof-of-concept for 2D perovskite lattice templating of FAPbI3.** 146 **A)** The d(011) interplanar spacing for n=1 and FA-based n=2 2D perovskites with various A’ 147 cations: PA, BA, OA, and PEA. The range of reported values for FAPbI3 d(001) interplanar spacing 

7 

148 is plotted as gray horizontal bar. Both BA2FAPb2I7 and PA2FAPb2I7 exhibit a d(011) nearly identical 149 to the d(001) of FAPbI3, as shown in the inset. **B)** Diagram of the unit cells of FAPbI3 (left) and 150 BA2FAPb2I7 (right). The (001) and (011) planes are drawn for each structure. The Pb-I-Pb distance 151 corresponds to the (001) interplanar spacing of FAPbI3 and to the (011) spacing of BA2FAPb2I7. 152 **C** ) Schematics of the templated FAPbI3 drop-coating experiment. First FAPbI3 precursor solution 153 was dropped onto a glass substrate and allowed to flow over crystals of BA2FAPb2I7. When heated, 154 the δ-FAPbI3 on top of the BA2FAPb2I7 transformed to α-FAPbI3 before the δ-FAPbI3 on top of 155 the bare substrate. Left in ambient air, the α-FAPbI3 on top of the bare substrate transformed to δ- 156 FAPbI3 before the α-FAPbI3 on top of the BA2FAPb2I7. **D)** Corresponding photographs of the 157 experiment in **(C)** showing the three distinct regions of the substrate. i: BA2FAPb2I7 without 158 FAPbI3 solution, ii: BA2FAPb2I7 below FAPbI3 solution, and iii: FAPbI3 solution on bare glass. 159 **E)** PL, and **(F)** XRD of regions i, ii, and iii after 1 hour of exposure to ambient air, showing that 160 the α-FAPbI3 was stabilized when deposited above BA2FAPb2I7. 161 162 The lower region of the substrate, which was originally bare, changed to a black color with 

The lower region of the substrate, which was originally bare, changed to a black color with 

163 partially converted α-FAPbI3, at 100 °C. The middle region where the solution touched the 2D 164 perovskite consisted of the black phase FAPbI3 on the surface and BA2FAPb2I7 below that. Finally, 165 the top part of the substrate where the solvent did not flow remained as BA2FAPb2I7 of millimeter166 sized monocrystal film. We then left the film for 1 hour under ambient conditions. As the 167 temperature decreased, the bottom region (originally the bare glass region) converted to the yellow 168 phase of FAPbI3 while the intermediate region remained black, suggesting the successful phase 169 stabilization of the FAPbI3. The BA2FAPb2I7 crystal film remained unchanged over this time 170 because of its inherent stability compared to its 3D counterpart. 

171 We characterized the three regions of the final film using both PL and XRD measurements. 172 **Fig. 1C** shows the PL spectra of the film obtained at the three specific regions, labelled (i), (ii), 173 and (iii). The dominant PL of region (i) at 2.15 eV corresponded to the ground-state excitonic 

- 174 emission of BA2FAPb2I7 film, accompanied by a small shoulder around 2.0 eV. The intermediate 

- 175 region (ii) showed strong emission at 1.48 eV corresponding to the intrinsic bandgap of the α- 

- 176 FAPbI3 phase, with very weak emission at around 2.15 eV from BA2FAPb2I7. These results 

- 177 indicated the coexistence of the bulk black phase FAPbI3 3D perovskite atop the 2D perovskite 

8 

- 178 crystal film. The presence of the 2D perovskite at the bottom was confirmed by PL measurements 

- 179 taken from the back of the film in region (ii), which exhibited emission solely from the 2D 

- 180 perovskite. As anticipated, no emission was observed from region (iii) that contained the 

- 181 photoinactive yellow phase of the FAPbI3. Additional PL analysis for the drop-coating experiment 

182 is shown in **Fig. S1** . The detection of n=3 (BA2FA2Pb3I10) in the photoluminescence (PL) 183 measurement acquired from the rear side provides clear evidence of the intercalation process, a 184 phenomenon previously reported by our group (refer to **Fig. S1** ) ( _44_ ). We emphasize that the phase 185 stabilization of FAPbI3 occurred also at 100° and 125°C, which are well below the standard 186 annealing temperatures of 150° to 160°C. 

187 The XRD measurements presented in **Fig. 1F** validated the findings from the 188 measurements in **Fig. 1, C to E** . Region (i) showed a pure 2D BA2FAPb2I7 perovskite as evidenced 189 by the strong interlayer (h00) XRD plane originating from the inorganic layer stacking. From 190 region (ii), we found a similar XRD pattern but with the (001) and (002) diffraction planes from 191 the 𝛼-phase FAPbI3 perovskite that indicates the presence of a mixture of 2D and 3D perovskites. 192 In region (iii), XRD showed only the presence of the δ-phase FAPbI3. 

193 The results shown in **Fig. 1** suggest that the incorporation of BA2FAPb2I7 into FAPbI3 194 during film formation could stabilize the perovskite phase through templating between the two 195 structures’ Pb-I-Pb interatomic distances. To test this hypothesis in FAPbI3 films, 2D perovskites 196 were added as templating agents to precursor solutions of 1:1 FAI: PbI2 in mixed 4:1 DMF: DMSO 197 solvent. We compared the effect of 2D perovskites with four different A’-site cations: BA, PA, 198 OA, and PEA. Using a technique previously developed by our group _(41)_ , pre-synthesized 2D 

199 crystals were added instead of the more conventional choice of A’ cation halide salts. Rather than 200 dissolving completely into constituent ions, 2D crystals in a DMF: DMSO solvent formed sub- 

9 

- 201 micrometer sized crystallites (termed as memory seeds) that preserved their perovskite structure 

- 202 and served as nucleation sites during film formation. These memory seeds could transfer their 

- 203 initial n-value to solution-processed films. However, when dissolved in a FAPbI3 precursor 

- 204 solution rather than pure DMF: DMSO, 2D perovskite crystallites were surrounded by a high 

- 205 concentration of mobile A-site cations, which tended to intercalate into the seeds and increase their 206 n-value. As a result, a 2D additive with a given A’-site cation will grow from a FAPbI3 solution at 

- 207 its thermodynamically preferred n-value in such an environment. With this in mind, only 2D 

- 208 perovskites of the n-value that will precipitate from a FAPbI3 solution were considered as 209 candidates for α-phase stabilization. Through solution processing experiments summarized in **Fig.** 

- 210 **S2** , we found that each of the four RP 2D perovskites considered here grew in their n=2 phase 211 from FAPbI3 solution. 

- 212 **Crystallization dynamics of 2D templated FAPbI3 thin films** 

- 213 We used our selectively designed 2D perovskites BA2FAPb2I7 and PA2FAPb2I7 to grow stabilized 

- 214 FAPbI3 perovskite thin films. **Fig. 2A** visually illustrates the film formation process of FAPbI3 

- 215 with 2D perovskite additive, offering insight into the visible alterations that occur during the 

- 216 process. Perovskite films were synthesized by spin-coating with precursors of FAI: PbI2:2D 

- 217 perovskite with a molar ratio of 1:1:x mol%. After antisolvent washing with diethyl ether, the thin 

- 218 film underwent a series of intermediate stages, which can be seen visually as changes in colour 

- 219 from pale red (before annealing) to dark brown, and finally to a black film when annealed at 

- 220 temperatures ranging from 100° to 150°C for 20 minutes. 

- 221 

10 

222 



11 

223 **Fig. 2. 2D-stabilized FAPbI3 film formation mechanism. A)** Fabrication steps of a 2D crystal 224 templated FAPbI3 thin film, **B)** Integrated peak areas for the (100)<sup>δ</sup> (orange, left axis) and (001)<sup>3D</sup> 225 (black, right axis) peaks over time for control FAPbI3 (bottom), FAPbI3 with 0.5 mol% PEA n=2 226 added (middle), and FAPbI3 with 0.5 mol% BA n=2 added (top). The (001)<sup>3D</sup> peak area as 227 indicated on the right vertical axis is normalized to the maximum of the (100)<sup>δ</sup> peak area. The 228 regions between the emergence of the (001)<sup>3D</sup> peak and the full conversion to α-FAPbI3 are 229 highlighted in blue. **C)** Azimuthally integrated WAXS patterns averaged across the first 90 230 seconds of annealing after reaching 150<sup>o</sup> C for each FAPbI3 additive tested (2D concentration is 1 231 mol%). **D)** The α-FAPbI3 (001) lattice parameter for films with 1 mol% of each 2D additive, as 232 measured on separately fabricated samples at RT. Error bars indicate standard deviation based on 233 data from 3 to 5 samples. **E)** Schematic diagram illustrating the mechanism of lattice-matched 2D 234 templated FAPbI3 perovskite formation. 235 236 To elucidate the mechanism that produces a RT phase-stable FAPbI3 film, we measured 3 film, we measured  film, we measured 

To elucidate the mechanism that produces a RT phase-stable FAPbI3 film, we measured 3 film, we measured  film, we measured 

237 the structural dynamics of the perovskite during thin-film formation using synchrotron-based 238 WAXS. The perovskite thin-films were deposited from solution onto a bare ITO substrate by using 239 a robotic antisolvent pipette and a resistive-heating spin-coater in a WAXS chamber under a 240 nitrogen atmosphere ( **Fig. S3** ). We first investigated the crystallization kinetics of a FAPbI3 film 241 with 1 mol% BA2FAPb2I7 incorporated. A WAXS pattern taken during thin-film formation ( **Fig.** 242 **S4)** showed concentric diffraction rings corresponding to the Bragg reflections of the stacking axis 243 diffraction planes of BA2FAPb2I7 and α- and δ- phases of 3D-FAPbI3. The diffraction peaks 244 correspond to crystallographic planes in the 2D, α-FAPbI3, and δ-FAPbI3 crystal structures. 

245 The WAXS pattern was azimuthally integrated and plotted as a function of time along with 246 spin speed and temperature to observe the film’s structural evolution ( **Fig. S4** ). In this in-situ 247 experiment can be divided into four stages: (i) antisolvent dropping during spin-coating; (ii) after 248 spin-coating but before annealing; (iii) slow annealing ramping from RT to 150°C; and (iv) 

- 249 constant annealing at 150°C. The δ- phase FAPbI3 immediately formed after depositing antisolvent 250 (10 s), as indicated by the strong (100)<sup>δ</sup> ( _q_ , <mark>the length of the reciprocal lattice vector, is</mark> 0.84 Å<sup>−1</sup> ), 

- 251 (101)<sup>δ</sup> , and (110)<sup>δ</sup> diffraction planes (drawn in **Fig. S5** ). Once the spin-coating is completed (30 s), 

12 

- 252 the δ-phase persisted as 2D BA2FAPb2I7 seeds began to crystallize at RT, illustrated by the out- 

- 253 of-plane (400)<sup>2D</sup> (q = 0.65Å<sup>−1</sup> ) and (600)<sup>2D</sup> (q = 0.96Å<sup>−1</sup> ) diffraction peaks ( **Fig. S4** ). 

- 254 Next, a nonlinear stepwise annealing sequence was applied, in which the substrate 

255 temperature was increased by steps of 20°C in 20 second intervals up to 100°C and then increased 256 by steps of 25°C up to 150°C (stage iii). Slow ramping to 150<sup>o</sup> C allowed us to observe the onset 257 temperature of the FAPbI3 α-phase. In this stage, for annealing at low temperatures (<100<sup>o</sup> C), the 258 diffraction intensity of the 2D increased and a new peak emerged near q = 1Å<sup>−1</sup> corresponding to 259 the (001)<sup>3D</sup> plane from α-phase FAPbI3. **Fig. 2B, top** shows the integrated peak area for the (100)<sup>δ</sup> 260 and (001)<sup>3D</sup> peaks as a function of time for FAPbI3 with 0.5 mol% BA n=2 incorporated. The 261 (001)<sup>3D</sup> peak emerged after 75 s and slowly increases in intensity as the (100)<sup>δ</sup> peak simultaneously 262 decreases. Around after 130 s (T = 130<sup>o</sup> C), the remaining δ-phase abruptly converted into α-phase. 263 As the film continued to anneal at 150°C for the remainder of the experiment (stage iv), the 2D 264 diffraction peaks slowly faded and the α-phase FAPbI3 peaks slowly grew more intense. 

265 We repeated this experiment for four other types of precursor solutions.  For additive-free 266 FAPbI3: **Fig. S6A** shows the in-situ contour WAXS plot for a 1:1 FAI:PbI2 solution. In contrast to 267 the FAPbI3-2D sample, which exhibited a gradual emergence of α-phase between 100<sup>o</sup> and 150<sup>o</sup> C 268 followed by a complete δ → α transformation at 130<sup>o</sup> C, the additive-free (control) FAPbI3 showed 269 a much more abrupt transition from δ-phase to α-phase near 150<sup>o</sup> C ( **Fig. 2B, bottom** ) consistent 270 with previous reports. The (001)<sup>3D</sup> peak emerged later with a shorter tail in control FAPbI3, and 271 the (100)<sup>δ</sup> peak did not prematurely decrease as in the film that incorporated BA n=2 We observed 

272 a much lower (001)<sup>3D</sup> peak intensity (relative to the (100)<sup>δ</sup> peak intensity) for control pristine 273 FAPbI3 compared to FAPbI3 with BA n=2 additive, suggesting a lowered crystallinity. Unlike the 

13 

- 274 film with added BA n=2, the (001)<sup>3D</sup> peak of control FAPbI3 did not grow more intense as 275 annealing at 150<sup>o</sup> C continued. 

276 For a precursor solution of 1:1:35 mol% FAI: PbI2: MACl in 4:1 DMF: DMSO, which is 277 commonly used to grow phase stabilized FAPbI3 _(25)_ , the introduction of MA into the A-site of 278 FAPbI3 lowered the effective tolerance factor and stabilized the α-phase at a lower temperature 279 compared to additive-free FAPbI3. As a result, the abrupt  δ → α  transformation occurred at 75<sup>o</sup> C 280 for the FAPbI3-MACl sample ( **Fig. S6B and S10A)** . However, like the control sample and in 281 contrast to the 2D-templated sample, no region of gradual δ → α transformation was observed. 

282 

Next, BA n=2 was added to 1:1 PbI2: FAI with concentrations of 0.25, 0.5, and 1.0 mol%. 

283 **Fig. S7** shows contour plots of the in-situ WAXS experiment for additive concentrations of 0.25 284 mol% (top) and 1.0 mol% (bottom). In all cases, the incorporation of BA n=2 increased the (001)<sup>3D</sup> 285 peak intensity relative to the control, suggesting that even minute amounts of BA n=2 could 286 improve α-phase crystallinity. The 0.5 mol% BA n=2 incorporated FAPbI3 showed a similar film 287 formation process to the 1.0 mol% sample discussed above, that is, a decrease in the (100)<sup>δ</sup> peak 288 and a slow emergence of the (001)<sup>3D</sup> peak at a lowered temperature. However, 0.25 mol% BA n=2 289 incorporation did not lower the onset temperature of the (001)<sup>3D</sup> peak relative to the control, and 290 did not cause the same characteristic decrease in (100)<sup>δ</sup> intensity below 150<sup>o</sup> C. The phase291 stabilization appeared to be concentration invariant down to a certain minimum 2D concentration, 292 below which the templating effect was lost but the film crystallinity was still improved. 

293 We then examined a series of 2D additives including PA n=2, OA n=2, and PEA n=2. We 

294 note that the effect PA n=2 was similar to that of BA n=2, lowering the onset temperature of the 295 α-phase peak and causing a decrease in the δ-phase below 150<sup>o</sup> C ( **Fig. S8 and S10B** ). In contrast, 296 OA n=2 and PEA n=2 have markedly different effects ( **Fig. S9 and S10B)** .  For OA n=2, the 2D 

14 

- 297 peaks formed weakly and the α-phase emerged earlier than for the control sample, but no δ → α 

- 298 transformation was observed. Instead, the δ-phase persisted throughout annealing, suggesting that 

299 OA2FAPb2I7 seeds could serve as nucleation sites for FAPbI3 to a limited extent but slowed the δ 300 → α transformation. FAPbI3 with 0.5 mol% PEA n=2 additive showed no 2D peaks and no early 301 α-phase emergence ( **Fig. 2B, middle** ). Moreover, FAPbI3 with 1 mol% PEA n=2 also retained δ- 302 phase peaks throughout the measurement, suggesting that the PEA2FAPb2I7 not only failed to form 303 seeds for templating FAPbI3 but also suppressed δ → α transformation kinetics. **Fig. 2C** shows the 304 azimuthally integrated WAXS patterns of FAPbI3 samples with 1 mol% 2D, averaged across the 305 first 90 s of annealing at 150<sup>o</sup> C. This plot revealed the incomplete δ → α transformation for the 306 films incorporating 1 mol% OA and PEA n=2, contrasting with the complete transformation for 1 307 mol% BA and PA n=2 (also visible in **Fig. S10** ). Interestingly, all 2D films showed a slow decrease 308 in the 2D peak intensities and a slow increase in the (001)<sup>3D</sup> peak intensity during annealing at 309 150<sup>o</sup> C that was not observed for the control film ( **Fig. 2B and Fig. S10** ). Although gradual 310 volatilization of the A’ cation in A’2FAPb2I7, leaving behind FAPbI3 could account for these 311 changes, as discussed below, optical and nuclear magnetic resonance (NMR) results suggest that 312 the 2D phase was not completely lost to volatilization, and that there may be a competing 313 mechanism of 2D restructuring within the lattice. 

- 314 The in-situ WAXS results suggested that BA2FAPb2I7 and PA2FAPb2I7 could template α- 

315 phase FAPbI3, but OA2FAPb2I7 and PEA2FAPb2I7 could not. Ex-situ 1D XRD was performed on 316 separate 1 mol% 2D-incorporated FAPbI3 films ( **Fig. 2D** ) and showed that FAPbI3 films with 317 added OA n=2 or PEA n=2 had an identical (001)<sup>3D</sup> interplanar spacing as control FAPbI3, but that 

- 318 PA n=2 and BA n=2 caused a small but noticeable compression of the (001)<sup>3D</sup> interplanar spacing 319 by -0.03% and -0.07%, respectively. Because the (011)<sup>2D</sup> interplanar spacing was lightly smaller 

15 

320 for BA n=2 than for PA n=2 ( **Fig. 1A)** , a higher compressive strain for FAPbI3 with added BA 321 n=2 compared to PA n=2 also supports the (011) lattice templating hypothesis. 

- 322 To verify our structural results, we performed similar in-situ optical spectroscopy 

323 measurements on the BA2FAPb2I7-templated FAPbI3 samples. During the initial stages of 324 annealing, the film exhibited a strong excitonic absorption peak at 2.15 eV corresponding to 325 BA2FAPb2I7, which with progressive annealing transformed into α-FAPbI3, characterized by a 3D 326 perovskite absorption band edge ( **Fig. S11** ). Similarly, a strong emission of the BA2FAPb2I7 327 perovskite was observed at 2.15 eV in the in-situ PL measurement, accompanied by a broad 328 emission at lower energies ( **Fig. S12** ). We hypothesized that the lower energy emissions were from 329 a combination of effects, including edge state emission _(45, 46)_ , the formation of higher n-value 330 2D phases (e.g. n=3 BA2FA2Pb3I10) _(47,48)_ , and quantum confinement effects of the 2D and 331 FAPbI3 crystallites _(49-52)._ Sub-bandgap edge state emission in BA2FAPb2I7 was verified by 332 spatially resolved PL, which showed a 1.8 eV PL emission peak only at the edges of an exfoliated 333 BA2FAPb2I7 single crystal. Additionally, the presence of a PL emission peak at 1.85eV and the 334 observation of n=3 excitons in power-dependent PL indicate that FA intercalation increases the 335 layer thickness from n=2 to n=3 during annealing. A similar broad emission below the n=2 336 bandgap was observed during film formation for FAPbI3 with PA2FAPb2I7 additive ( **Fig. S12)** , 337 consistent with the structural results for PA2FAPb2I7 shown in **Fig. S8** . However, no sub-bandgap 338 emission was observed for the control FAPbI3 or for FAPbI3 incorporating MACl, OA2FAPb2I7, 339 or PEA2FAPb2I7 ( **Fig. S13** ). 

340 Based on the in-situ WAXS and PL measurements in **Fig. 2** and **Fig. S2 to S10** , we propose 341 the following film formation process mediated by 2D templating. The film first forms grains of 𝛿- 342 phase FAPbI3 and 2D seeds at RT. The 2D likely formed initially because of its more negative 

16 

- 343 formation enthalpy, its RT phase-stability, and the presence of 2D seeds in the precursor solution 

- 344 as confirmed through dynamic light scattering (DLS) measurements shown in **Fig. S14** . During 

345 annealing, the 𝛿-phase restructured itself beginning at the low-energy surfaces of the 2D seed 346 crystals to form 𝛼-phase FAPbI3. At the interface with FAPbI3, the arrangement of PbI6 octahedra 347 in a 2D perovskite may facilitate nucleation of a stable α-phase FAPbI3, with subsequent phase 348 transformation toward the bulk _(53)_ . Indeed, from **Fig. 2D** , we deduced that the growth mechanism 349 favoured the formation of a compressively strained α-phase (001) plane templated by the 2D (011) 350 interplanar spacing. The low-temperature α-phase formation being only observed for films with 351 added PA and BA n=2, and these films being also the only ones to exhibit lattice strain, is strong 352 evidence for a templating effect off the (011)<sup>2D</sup> spacing. 

353 The (011) interplanar spacings of BA2FAPb2I7 (6.359 Å) and PA2FAPb2I7 (6.364 Å) are 354 almost perfectly lattice matched with the (001)<sup>3D</sup> interplanar spacing of FAPbI3, both falling within 355 the range of reported FAPbI3 lattice constants from 6.352 Å to 6.365 Å _(5,6)_ , whereas the (011) 356 interplanar spacings of OA2FAPb2I7 (6.336 Å) and PEA2FAPb2I7 (6.265 Å) were not well matched. 357 This structural difference explains why OA-2D and PEA-2D did not show the same δ → α 358 conversion process as BA-2D and PA-2D. The templating process and the resulting FAPbI3 strain 359 appeared 2D concentration-independent down to some minimum threshold, which for BA 2D 360 perovskites was between 0.25 and 0.5 mol%. As the temperature was raised to 150<sup>o</sup> C and the 361 sample continued to anneal, we hypothesize that the 2D perovskite simultaneously volatilized its 362 A’ cation and underwent a slow FA intercalation process, which increased its n-value. 

363 Other reports have suggested that the A’ cation of 2D perovskites incorporated into FAPbI3 

364 volatilized completely during annealing except for a small fraction left at grain boundaries,<sup>19,37,38</sup> 365 which would also explain the disappearance of our 2D signal over time and the slow increase in 

17 

- 366 the (001)<sup>3D</sup> peak intensity during annealing at 150<sup>o</sup> C. Solid-state<sup>1</sup> H NMR on scraped films of 

- 367 FAPbI3 with added 2D before and after annealing did reveal a partial volatilization of the spacer 368 cation during film formation, but also confirmed appreciable fractions of BA and PA even after 

369 annealing at 150<sup>o</sup> C for 20 min ( **Fig. S15** and **S16** ). Time-of-flight secondary-ion mass 370 spectrometry (ToF-SIMS) results suggested that the remaining 2D spacer cations were 371 homogenously distributed up to 1 mol% and for higher concentrations, appeared more pronounced 372 toward the film interface with the substrate ( **Fig. S17** ). 

373 The BA and PA cations lead to the formation of a mixed 2D/3D phase that was challenging 374 to characterize with the aforementioned long-range techniques. Instead, we applied high-field (21 375 T) solid-state NMR spectroscopy to resolve the local structures of the organic cations in the mixed 376 phase ( **Fig. S16** ). The<sup>1</sup> H NMR peaks associated with the large (BA and PA) and small (FA) 377 cations were well resolved so the amount of 2D phase present in the templated FAPbI3 materials 378 could be identified and quantified. In addition, the local structures of the mixed phases, elucidated 379 by analysing 2D<sup>1</sup> H-<sup>1</sup> H correlation NMR spectra ( **Fig. S16, C to F** ), showed the presence of 380 through-space intermolecular interactions between the large cations (BA or PA) in the 2D phase 381 and the small cations (FA) in the 3D FAPbI3 phase. Based on the data presented above, we 382 illustrate a comprehensive schematic diagram capturing the different stages of film formation in a 

- 383 2D templated FAPbI3 ( **Fig. 2E and discussion in SI 1.18** ). 

384 

385 

386 

- 387 

18 

388 

389 **Fig. 3. Ex-situ structural characterization of phase stabilized FAPbI3 films. A** ) A 390 representative azimuthally integrated nano-XRD pattern for a film of BA2FAPb2I7-templated 391 FAPbI3. **B** ) The (210), and **C** ) the (211) peaks of BA2FAPb2I7-templated FAPbI3 which can be 392 seen after integrating several nano-XRD patterns obtained for different pixels within the testing 393 region. These peaks are forbidden in a cubic crystal structure and confirm the existence of 394 tetragonal FAPbI3. **D** ) A histogram of nano-XRD peak FWHM values for different pixels of a 395 BA2FAPb2I7-stabilized FAPbI3 film (red) and a MACl-stabilized FAPbI3 film (black). 2D396 stabilized FAPbI3 shows a significantly lower FWHM. **E** – **F** ) Representative GIWAXS patterns 397 for **E** ) MACl-stabilized FAPbI3 and **F** ) BA2FAPb2I7-stabilized FAPbI3. 398 



#### 399 

### **Structural and optical characteristics of Phase stabilized FAPbI3** 

- 400 We hypothesized that the observed compressive lattice strain applied by the templating 2D phase 

- 401 can result in the formation of a locally segregated tetragonal structure _(54,55)_ . To investigate the 

- 402 impact of 2D stabilization on nanoscale structural properties of FAPbI3, we performed nanoscale 

- 403 XRD with a 25-nm spot size x-ray probe on MACl-stabilized FAPbI3 and 2D-stabilized FAPbI3. 

- 404 The high brilliance of a synchrotron light source enabled resolution of diffraction from minority 

19 

- 405 phases _(56,57)_ . As shown in **Fig. S18** , both films showed sufficient x-ray stability to accommodate 

- 406 the measurement. Localized x-ray scattering from both cubic (i.e., α) and tetragonal phases was 407 observed. A representative summed diffraction CCD image from a map of 2D-stabilized FAPbI3 

- 408 is shown in **Fig. S19** , and an azimuthally integrated pattern is shown in **Fig. 3A** . In addition to 409 intense scattering from the cubic perovskite lattice, we observed two subtle peaks that we indexed 410 to the tetragonal phase, the (210)t (t=tetragonal) at 1.57 A<sup>-1</sup> and (211)t at 1.866 A<sup>-1</sup> ( **Fig. 3, B and** 411 **C** ). The (211)t peak could not be definitively indexed as tetragonal because of the overlapping 412 (210)h (h=hexagonal, δ-phase) peak at virtually the same scattering vector, but the (210)t was 413 unambiguously identified ( _58_ ). Furthermore, because we observed no additional scattering peaks 414 from the hexagonal phase in this sample, we also attribute the (211)t  peak to the tetragonal phase. 415 The diffraction from tetragonal phase was far less intense than diffraction from the cubic phase, 416 with total summed diffraction intensity from the (211)t peak amounting to 0.8% of the intensity of 417 the (200)c (c=cubic) peak (see **Fig. S19** ). 

- 418 To investigate the impacts of 2D stabilization on the quality of the perovskite crystallites 

- 419 in the thin film, we performed five-dimensional rocking curves (rocking curves with a two420 dimensional detector and two-dimensional spatial mapping) on the sample where the angle of the 421 incident x-ray was varied and spatial maps in the plane of the sample were repeated over the same 

- 422 area to precisely analyze the width of the diffraction peak. The 2D-stabilized FAPbI3 exhibited 

- 423 substantially narrower diffraction full-width at half-maximum (FWHM) than the MACl-doped 

- 424 FAPbI3 ( **Fig. 3D** ). The narrower diffraction peak could be a result of an increase in domain size or 

- 425 reduced microstructural disorder (microstrain) _(59)_ . However, the well-established increase in 

- 426 domain size seen when MACl was included in perovskite precursors suggested that a smaller 

- 427 domain size in MACl-doped FAPbI3 was not the cause _(25,60,61)_ . We concluded that the 2D- 

20 

- 428 stabilization resulted in a reduced structural disorder within the crystallites of the thin film, which 

- 429 is consistent with previous reports _(53)_ . Halder-Wagner analysis summarized in **Fig. S20** and **S21** 430 further revealed that microstrain in 2D-stabilized FAPbI3 decreased with increasing 2D 431 concentration. 

- 432 The grazing-incidence WAXS (GIWAXS) patterns of the MACl-doped FAPbI3 perovskite 

- 433 thin films ( **Fig. 3E** ) and FAPbI3 with BA2FAPb2I7 additive revealed two different characteristics 434 of the thin films. The MACl-doped FAPbI3 films exhibited Bragg intensities extended along arc 

- 435 segments, indicating a random orientation of crystal domains or grains within a polycrystalline 436 film (high mosaicity). Furthermore, these films showed PbI2 diffraction peaks. In contrast, the 2D- 

- 437 stabilized FAPbI3 films reveal well-defined Bragg diffraction spots along the (001) plane, observed 

- 438 along the Debye–Scherrer ring near q = 1 Å<sup>−1</sup> . This distinct observation implied smaller mosaicity 

- 439 and improved grain orientation in the out-of-plane direction, perpendicular to the substrate. 440 Furthermore, mosaicity appeared to be reduced with increasing 2D concentration ( **Fig. S22)** . 

- 441 Atomic force microscopy (AFM) likewise showed an increase in FAPbI3 grain size when 2D 

- 442 concentration was increased from 0.25 mol% to 0.5 mol%, although a further increase caused the 

- 443 grain size to decrease ( **Fig. S23)** . These results were consistent with the observation in **Fig. S7** of 444 improved crystallinity for FAPbI3 films incorporating even small amounts of BA n=2. 



445 

21 

446 F **ig. 4. Optical characterization of the phase stabilized FAPbI3 films. A** ) Absorption spectra of 447 MACl-stabilized FAPbI3 (grey) and BA2FAPb2I7-stabilized FAPbI3 (red) with their band gaps 448 indicated. **B** ) PL spectra of MACl-stabilized FAPbI3 (gray) and BA2FAPb2I7-stabilized FAPbI3 449 (red). **C** ) TRPL spectra of MACl-stabilized FAPbI3 (gray) and BA2FAPb2I7-stabilized FAPbI3 450 (red). 

- 451 We observed an increase in the absorption of the 2D stabilized FAPbI3 compared to the 

452 MACl-doped FAPbI3. ( **Fig. 4A** ). Using the Tauc plot calculated from the absorption spectrum 453 ( **Fig. S24** ), we derived a bandgap of 1.48 eV for the 2D stabilized FAPbI3 (versus the 1.52 eV band 454 gap of the MACl-doped films) that was much closer to the smallest reported (1.45 eV) bandgap of 455 FAPbI3 _(5)_ . This band gap reduction ( **Fig. 4A-B** ) was consistent with experimental signatures 456 pointing toward a reduction of the lattice disorder ( **Fig. 3E-F** ) _(53)_ . In a polymorphous picture of 457 the cubic phase of FAPbI3, the reduction of polymorphism also leads to reduced tilt amplitudes 458 _(4,62)_ . As 2D concentration increased, the valence band maximum (VBM) was lowered ( **Fig. S25)** 459 and the band gap widened. 

460 We also observed an order of magnitude increase in the PL intensity of the 2D-stabilized 461 FAPbI3 compared to the MACl-doped FAPbI3 indicating reduced nonradiative recombination 462 ( **Fig. 4B** ). The PL peak positions aligned with the absorption thresholds for both the films. In time463 resolved PL measurements ( **Fig. 4C** ), the 2D stabilized FAPbI3 film exhibited a slower PL decay 464 rate compared to the reference, implying a decrease in nonradiative recombination attributable to 465 a reduction in trap-mediated bulk or surface recombination processes. 

466 **Photovoltaic studies** 

- 467 We used 2D stabilized FAPbI3 to fabricate perovskite solar cells using an inverted architecture 468 with MeO-2PACz as the hole transport layer and C60 as the electron transport layer. To construct 

- 469 a band diagram of the device architecture ( **Fig. 5A** ), we measured the valence band maxima and 

- 470 conduction band minima of the MACl-doped FAPbI3 and 2D stabilized FAPbI3 by combining 

- 471 photoemission yield spectroscopy (PES) and absorption measurements. The details of the 

22 

- 472 measurements are discussed in the methods section of the SI. The 2D stabilized FAPbI3 although 

- 473 slightly shifted toward higher energy compared to the MACl-doped FAPbI3 had an appropriate 474 band alignment for charge carrier separation and extraction. 

475 The current density-voltage ( _J_ – _V_ ) characteristics of the best-performing 2D stabilized 476 FAPbI3 device in reverse and forward bias sweeps are illustrated in **Fig. 5B** . We achieved a power 477 conversion efficiency (PCE) of 24.1% for an active area of 0.5 cm<sup>2</sup> under AM1.5G illumination 478 ( **Fig. 5E** ) with a short circuit current density (JSC) of 25.5 mA.cm<sup>-2</sup> , open circuit voltage (VOC) of 479 1.12 V, and fill factor of 82%. These metrics compare favourably with the corresponding 480 thermodynamic limits of 31.1 mA·cm<sup>-2</sup> , 1.21 V, and 89%, respectively _(63)_ . **Fig. 5C** shows the 481 external quantum efficiency (EQE) for the same device as that of the _J_ – _V_ curve. Solar cells under 482 identical conditions using different 2D perovskite concentration were fabricated to confirm the 483 impact of concentration on performance. The statistical distributions of _J_ SC, _V_ OC, fill factor (FF), 484 and PCE for 40 devices of each condition are shown in **Fig. S26** . The _J_ SC obtained by integrating 485 the EQE over the wavelength is 24.3 mA cm<sup>−2</sup> , which was in good agreement with that of the 486 device’s _J_ – _V_ curve measured using a solar simulator. For comparison, we fabricated FAPbI3 487 devices stabilized using PA2FAPb2I7, OA2FAPb2I7 and PEA2FAPb2I7 (see **Fig. S27)** . The PA488 templated FAPbI3 device exhibited a PCE of 21%, with a Jsc of 25.2 mA.cm-2, VOC of 1.06V, and 489 FF of 78.1%. In the case of optimized OA- and PEA-templated FAPbI3, we achieved PCEs of 490 16.54% (Jsc of 23.93 mA.cm-2, VOC of 0.97V, and FF of 71%) and 14.65% (Jsc of 23.15 mA.cm<sup>-</sup> 491 2, VOC of 0.96V, and FF of 65%), respectively. 

- 492 Finally, we compared the intrinsic and operational stability of undoped, BA2FAPb2I7493 templated, and MACl-doped FAPbI3 films and devices. The 2D-templated FAPbI3 was 494 exceptionally stable under a variety of conditions compared to both undoped and MACl-doped 

23 

- 495 FAPbI3. The shelf stability of 2D-stabilized FAPbI3 films showed a significant improvement 

- 496 compared to undoped FAPbI3 ( **Fig. S28** ). We also performed in-situ GIWAXS measurements ( **Fig.** 

- 497 **S29)** to compare the stability of MACl-doped and BA2FAPb2I7-incorporated FAPbI3 devices in a 

- 498 >90%RH environment at 65<sup>o</sup> C with 1-Sun illumination. The 2D-templated FAPbI3 device showed 

- 499 minimal α → δ conversion over 170 min in the degrading environment. In contrast, the δ-phase 

- 500 became dominant in the MACl-doped FAPbI3 device within the first 15 min of measurement. The 

- 501 much higher stability of the 2D-templated FAPbI3 device in this experiment corroborated the 

- 502 maximum power point tracking (MPPT) device stability tests shown in **Fig. 5D** for 2D-templated 

- 503 FAPbI3 and MACl-doped FAPbI3. 

24 

504 



505 **Figure 5: 2D-stabilized FAPbI3 device performance. A** ) Device architecture of best-performing 506 device showing band alignment of each layer. **B** ) The J-V curve of the champion device shows 

25 

507 both a forward sweep (solid line) and reverse sweep (dashed line). The inset shows a real image 508 of the device. **C** ) The EQE of the champion 2D-stabilized FAPbI3 device compared to the 509 champion MACl-stabilized FAPbI3 device. **D-F** ) Stability tests on 2D stabilized FAPbI3. **D** ) 510 Unencapsulated 2D-FAPbI3 (red) and MACl-FAPbI3 (black) cell under 1-sun illumination at 60<sup>o</sup> C 511 with MPP tracking, in ambient air. **E** ) Encapsulated cell under 1-sun illumination at 60<sup>o</sup> C with 512 MPP tracking. **F** ) Encapsulated cell under 1-sun illumination at 85<sup>o</sup> C with MPP tracking. 

513 

514 We evaluated the device stability with standard interfaces. We first performed 515 measurements on unencapsulated p-i-n solar cells in ambient air under 1-Sun illumination (no UV 516 filter) with MPPT. As shown in **Fig. 5D** , the 2D-templated devices showed almost no PCE drop 517 during the first 500 hours of operation with _T99_ >500 h. In contrast, the unencapsulated MACl518 doped FAPbI3 sample degraded within the first 50 hr of operation showing a _T40_ =50 h. Further, as 519 shown in **Fig. 5E** , an encapsulated 2D-templated FAPbI3 device showed almost no efficiency drop 520 from an initial 21% PCE for more than 1000 hours ( _T99_ >1000 hr) of continuous 1-Sun illumination 521 at MPPT in ambient air (ISOS-L-1 protocol). This stability is among the best reported for FAPbI3522 based perovskite devices, which in recent reports _(26,27,36)_ have been measured under inert 523 conditions. 

524 The encapsulated solar cells were additionally measured under 1-sun illumination at MPPT 525 at 85°C on a hot plate in the ambient atmosphere (ISOS-L-2 protocol), as shown in **Fig. 5F** . The 526 2D-stabilized FAPbI3 devices retained 99% of their initial PCE after 620 hours, and more than 527 97% of their initial PCE after 1000 hours. Using the rule of thumb from Si photovoltaics that a 

- 528 10<sup>o</sup> C increase in temperature translates to a 2x increase in degradation rate _(64)_ , a _T97_ = 1000 hours 

- 529 at 85<sup>o</sup> C corresponds to a _T97_ = 16000 hours (1.8 years) at 45<sup>o</sup> C. This result is a critical step towards 

- 530 a FAPbI3-based device with commercially-relevant stability. 

- 531 

532 

26 

533 **Discussion** 

- 534 In summary, our investigation unveils a unique approach to achieve a highly stable black phase of 

- 535 FAPbI3, even at temperatures considerably lower than the δ-FAPbI3 to α-FAPbI3 transition 

- 536 temperature. This method involves templating the (001) interplanar spacing of 3D FAPbI3 to the 

- 537 (011) interplanar spacing of carefully selected 2D perovskites with FA as the cage cation, 

- 538 considering the respective Pb-Pb interatomic spacing for each structure.  Detailed characterization, 

- 539 incorporating correlated WAXS, optical absorbance, and PL, indicates that the resulting black 

- 540 FAPbI3 phase exhibits a lattice constant corresponding to the d(011) interplanar spacing of the 

- 541 underlying 2D perovskite. We extend this templating strategy to scalable solution-processed 

- 542 methods by introducing pre-synthesized 2D perovskite seeds to FAPbI3 precursor solutions. 

- 543 During the film formation, the phase-stable 2D perovskite nucleates first due to its lower enthalpy 

- 544 of formation and stability at room temperature. The 2D structure acts as a seed on which the 3D 

- 545 perovskite to adopt the underlying 2D lattice periodicity, allowing for the preferential templating 546 of the 3D perovskite on the 2D phase during subsequent film annealing. The resulting bulk FAPbI3 547 films exhibit an energy gap (Eg) of 1.48 eV and demonstrate exceptional durability under 548 aggressive conditions, achieving a remarkable PCE of 24.1% in a p-i-n device architecture on a 

- 549 0.5 cm<sup>2</sup> device area. These outcomes validate a novel design strategy for the templated growth of 

- 550 3D perovskites using 2D perovskites and will enable new physical behaviours and properties and 

- 551 functionalities relevant for optoelectronic devices. We anticipate that such strategies might extend 

- 552 beyond perovskites, potentially using other molecular and organic systems with comparable lattice 

- 553 constants to produce epitaxial kinetically stabilized materials. 

- 554 

555 

556 

557 

27 

- 558 REFERENCES 

- 559 

- 560 1. Masi, S., Gualdrón-Reyes, A. F. & Mora-Seró, I. Stabilization of Black Perovskite Phase in FAPbI3 

- 561 and CsPbI3. _ACS Energy Lett._ **5** , 1974–1985 (2020). 

- 562 2. Huang, Y. _et al._ The intrinsic properties of FA(1−x)MAxPbI3 perovskite single crystals. _J. Mater._ 563 _Chem. A_ **5** , 8537–8544 (2017). 

- 564 3. Tao, S. _et al._ Absolute energy level positions in tin-and lead-based halide perovskites. _Nature_ 565 _communications_ **10** , 2560 (2019). 

- 566 4. Zhao, X.-G., Dalpian, G. M., Wang, Z. & Zunger, A. Polymorphous nature of cubic halide perovskites. 567 _Phys. Rev. B_ **101** , 155137 (2020). 

- 568 5. Stoumpos, C. C., Malliakas, C. D. & Kanatzidis, M. G. Semiconducting Tin and Lead Iodide 569 Perovskites with Organic Cations: Phase Transitions, High Mobilities, and Near-Infrared 570 Photoluminescent Properties. _Inorg. Chem._ **52** , 9019–9038 (2013). 

- 571 6. Kawachi, S. _et al._ Structural and Thermal Properties in Formamidinium and Cs-Mixed Lead Halides. 572 _J. Phys. Chem. Lett._ **10** , 6967–6972 (2019). 

- 573 7. Kieslich, G., Sun, S. & Cheetham, A. K. An extended tolerance factor approach for organic–inorganic 574 perovskites. _Chemical science_ **6** , 3430–3433 (2015). 

- 575 8. Ferreira, A. C. _et al._ Elastic softness of hybrid lead halide perovskites. _Physical Review Letters_ **121** , 576 085502 (2018). 

- 577 9. Li, Z. _et al._ Stabilizing perovskite structures by tuning tolerance factor: formation of formamidinium 

- 578 and cesium lead iodide solid-state alloys. _Chemistry of Materials_ **28** , 284–292 (2016). 

- 579 10. Saliba, M. _et al._ Cesium-containing triple cation perovskite solar cells: improved stability, 

- 580 reproducibility and high efficiency. _Energy & environmental science_ **9** , 1989–1997 (2016). 

- 581 11. Jeon, N. J. _et al._ Compositional engineering of perovskite materials for high-performance solar cells. 582 _Nature_ **517** , 476–480 (2015). 

28 

- 583 12. Entropy-driven structural transition and kinetic trapping in formamidinium lead iodide perovskite | 

- 584 Science Advances. https://www.science.org/doi/10.1126/sciadv.1601650. 

- 585 13. Green, M. A. _et al._ Solar cell efficiency tables (version 62). _Progress in Photovoltaics: Research and_ 586 _Applications_ **31** , 651–663 (2023). 

- 587 14. Min, H. _et al._ Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. _Nature_ 

- 588 **598** , 444–450 (2021). 

- 589 15. Yoo, J. J. _et al._ Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 590 (2021). 

- 591 16. Jeong, J. _et al._ Pseudo-halide anion engineering for α-FAPbI3 perovskite solar cells. _Nature_ **592** , 381– 592 385 (2021). 

- 593 17. Kim, M. _et al._ Conformal quantum dot–SnO2 layers as electron transporters for efficient perovskite 594 solar cells. _Science_ **375** , 302–306 (2022). 

- 595 18. Jeong, M. J. _et al._ Boosting radiation of stacked halide layer for perovskite solar cells with efficiency 596 over 25%. _Joule_ **7** , 112–127 (2023). 

- 597 19. Park, J. _et al._ Controlled growth of perovskite layers with volatile alkylammonium chlorides. _Nature_ 598 1–3 (2023) doi:10.1038/s41586-023-05825-y. 

- 599 20. Zhao, Y. _et al._ Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 600 531–534 (2022). 

- 601 21. Jiang, Q. _et al._ Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 602 278–283 (2022). 

- 603 22. Li, Z. _et al._ Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. 604 _Science_ **376** , 416–420 (2022). 

- 605 23. Zhu, Z. _et al._ Correlating the perovskite/polymer multi-mode reactions with deep-level traps in 606 perovskite solar cells. _Joule_ **6** , 2849–2868 (2022). 

- 607 24. Li, G. _et al._ Highly efficient p-i-n perovskite solar cells that endure temperature variations. _Science_ 

- 608 **379** , 399–403 (2023). 

29 

- 609 25. Kim, M. _et al._ Methylammonium Chloride Induces Intermediate Phase Stabilization for Efficient 

- 610 Perovskite Solar Cells. _Joule_ **3** , 2179–2192 (2019). 

- 611 26. Min, H. _et al._ Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead 612 iodide. _Science_ **366** , 749–753 (2019). 

- 613 27. Park, B. _et al._ Stabilization of formamidinium lead triiodide α-phase with isopropylammonium chloride 614 for perovskite solar cells. _Nat Energy_ **6** , 419–428 (2021). 

- 615 28. Hui, W. _et al._ Stabilizing black-phase formamidinium perovskite formation at room temperature and 616 high humidity. _Science_ **371** , 1359–1364 (2021). 

- 617 29. Lee, J.-W., Seol, D.-J., Cho, A.-N. & Park, N.-G. High-Efficiency Perovskite Solar Cells Based on the 618 Black Polymorph of HC(NH2)2PbI3. _Advanced Materials_ **26** , 4991–4998 (2014). 

- 619 30. Kim, G. _et al._ Impact of strain relaxation on performance of α-formamidinium lead iodide perovskite 620 solar cells. _Science_ **370** , 108–112 (2020). 

- 621 31. Park, Y. H. _et al._ Inorganic Rubidium Cation as an Enhancer for Photovoltaic Performance and 

- 622 Moisture Stability of HC(NH2)2PbI3 Perovskite Solar Cells. _Advanced Functional Materials_ **27** , 623 1605988 (2017). 

- 624 32. Alanazi, A. Q. _et al._ Benzylammonium-Mediated Formamidinium Lead Iodide Perovskite Phase 

- 625 Stabilization for Photovoltaics. _Advanced Functional Materials_ **31** , 2101163 (2021). 

- 626 33. Alanazi, A. Q. _et al._ Atomic-Level Microstructure of Efficient Formamidinium-Based Perovskite Solar 

- 627 Cells Stabilized by 5-Ammonium Valeric Acid Iodide Revealed by Multinuclear and Two628 Dimensional Solid-State NMR. _J. Am. Chem. Soc._ **141** , 17659–17669 (2019). 

- 629 34. Hu, R. _et al._ Enhanced stability of α-phase FAPbI 3 perovskite solar cells by insertion of 2D (PEA) 2 

- 630 PbI 4 nanosheets. _Journal of Materials Chemistry A_ **8** , 8058–8064 (2020). 

- 631 35. Huang, Y. _et al._ Low-Temperature Phase-Transition for Compositional-Pure α-FAPbI3 Solar Cells 

- 632 with Low Residual-Stress and High Crystal-Orientation. _Small Methods_ **6** , 2200933 (2022). 

- 633 36. Lee, J.-W. _et al._ 2D perovskite stabilized phase-pure formamidinium perovskite solar cells. _Nat_ 

- 634 _Commun_ **9** , 3021 (2018). 

30 

- 635 37. Liang, J. _et al._ Volatile 2-Thiophenemethylammonium and Its Strongly Bonded Condensation Product 

- 636 for Stabilizing α-FAPbI3 in Sequential-Deposited Solar Cells. _ACS Materials Lett._ **5** , 1395–1400 637 (2023). 

- 638 38. Liang, J. _et al._ Volatile 2D Ruddlesden‐Popper Perovskite: A Gift for α‐Formamidinium Lead 639 Triiodide Solar Cells. _Advanced Functional Materials_ 2207177 (2022). 

- 640 39. Shen, C. _et al._ Stabilizing Formamidinium Lead Iodide Perovskite by Sulfonyl-Functionalized 

- 641 Phenethylammonium Salt via Crystallization Control and Surface Passivation. _Solar RRL_ **4** , 2000069 642 (2020). 

- 643 40. Shi, P. _et al._ Oriented nucleation in formamidinium perovskite for photovoltaics. _Nature_ 1–5 (2023) 

- 644 doi:10.1038/s41586-023-06208-z. 

- 645 41. Sidhik, S. _et al._ Memory Seeds Enable High Structural Phase Purity in 2D Perovskite Films for High‐ 

- 646 Efficiency Devices. _Adv. Mater._ **33** , 2007176 (2021). 

- 647 42. Sidhik, S. _et al._ High-phase purity two-dimensional perovskites with 17.3% efficiency enabled by 

- 648 interface engineering of hole transport layer. _Cell Reports Physical Science_ **2** , 100601 (2021). 

- 649 43. Metcalf, I. _et al._ Synergy of 3D and 2D Perovskites for Durable, Efficient Solar Cells and Beyond. 650 _Chem. Rev._ **123** , 9565–9652 (2023). 

- 651 44. Hou, J., Li, W., Zhang, H., Sidhik, S., Fletcher, J., Metcalf, I., Anantharaman, S.B., Shuai, X., Mishra, 

- 652 A., Blancon, J.C. and Katan, C. Synthesis of 2D perovskite crystals via progressive transformation of 

- 653 quantum well thickness. _Nature Synthesis_ , **pp.1-11,** (2023). 

- 654 45. Blancon, J.-C., Even, J., Stoumpos, Costas. C., Kanatzidis, Mercouri. G. & Mohite, A. D. 

- 655 Semiconductor physics of organic–inorganic 2D halide perovskites. _Nat. Nanotechnol._ **15** , 969–985 656 (2020). 

- 657 46. Blancon, J.-C. _et al._ Extremely efficient internal exciton dissociation through edge states in layered 2D 

- 658 perovskites. _Science_ **355** , 1288–1292 (2017). 

- 659 47. Blancon, J.-C. _et al._ Scaling law for excitons in 2D perovskite quantum wells. _Nat Commun_ **9** , 2254 660 (2018). 

31 

- 661 48. Stoumpos, C. C. _et al._ Ruddlesden–Popper Hybrid Lead Iodide Perovskite 2D Homologous 662 Semiconductors. _Chem. Mater._ **28** , 2852–2867 (2016). 

- 663 49. Even, J., Pedesseau, L. & Katan, C. Understanding quantum confinement of charge carriers in layered 664 2D hybrid perovskites. _ChemPhysChem_ **15** , 3733–3741 (2014). 

- 665 50. Tamarat, P. _et al._ Universal scaling laws for charge-carrier interactions with quantum confinement in 666 lead-halide perovskites. _Nature Communications_ **14** , 229 (2023). 

- 667 51. Sapori, D., Kepenekian, M., Pedesseau, L., Katan, C. & Even, J. Quantum confinement and dielectric 668 profiles of colloidal nanoplatelets of halide inorganic and hybrid organic–inorganic perovskites. 669 _Nanoscale_ **8** , 6369–6378 (2016). 

- 670 52. Katan, C., Mercier, N. & Even, J. Quantum and dielectric confinement effects in lower-dimensional 671 hybrid perovskite semiconductors. _Chemical reviews_ **119** , 3140–3192 (2019). 

- 672 53. Song, S. _et al._ Molecular Engineering of Organic Spacer Cations for Efficient and Stable 673 Formamidinium Perovskite Solar Cell. _Advanced Energy Materials_ **10** , 2001759 (2020). 

- 674 54. Doherty, T. A. S. _et al._ Stabilized tilted-octahedra halide perovskites inhibit local formation of 675 performance-limiting phases. _Science_ **374** , 1598–1605 (2021). 

- 676 55. Beal, R. E. _et al._ Structural Origins of Light-Induced Phase Segregation in Organic-Inorganic Halide 677 Perovskite Photovoltaic Materials. _Matter_ **2** , 207–219 (2020). 

- 678 56. Winarski, R. P. _et al._ A hard X-ray nanoprobe beamline for nanoscale microscopy. _J Synchrotron Rad_ 679 **19** , 1056–1060 (2012). 

- 680 57. Li, N. _et al._ Microscopic degradation in formamidinium-cesium lead iodide perovskite solar cells under 

- 681 operational stressors. _Joule_ **4** , 1743–1758 (2020). 

- 682 58. Weber, O. J. _et al._ Phase Behavior and Polymorphism of Formamidinium Lead Iodide. _Chem. Mater._ 683 **30** , 3768–3778 (2018). 

- 684 59. Ungár, T. Microstructural parameters from X-ray diffraction peak broadening. _Scripta Materialia_ **51** , 685 777–781 (2004). 

32 

- 686 60. Li, Y. _et al._ CH3NH3Cl Assisted Solvent Engineering for Highly Crystallized and Large Grain Size 

- 687 Mixed-Composition (FAPbI3)0.85(MAPbBr3)0.15 Perovskites. _Crystals_ **7** , 272 (2017). 

- 688 61. Ye, F. _et al._ Roles of MACl in Sequentially Deposited Bromine-Free Perovskite Absorbers for Efficient 689 Solar Cells. _Advanced Materials_ **33** , 2007126 (2021). 

- 690 62. Zacharias, M., Volonakis, G., Giustino, F. & Even, J. Anharmonic electron-phonon coupling in 691 ultrasoft and locally disordered perovskites. _npj Comput Mater_ **9** , 1–13 (2023). 

- 692 63. Alam, M. A. & Khan, M. R. _Principles of solar cells: connecting perspectives on device, system,_ 693 _reliability, and data science_ . (World Scientific Publishing Co. Pte. Ltd, 2022). 

- 694 64. Boyd, C. C., Cheacharoen, R., Leijtens, T. & McGehee, M. D. Understanding Degradation 695 Mechanisms and Improving Stability of Perovskite Photovoltaics. _Chem. Rev._ **119** , 3418–3451 (2019). 

- 696 

697 

#### 698 

### **<u>Acknowledgements</u>** 

699 In situ diffraction experiments were conducted at the Advanced Light Source, beamline 12.3.2 700 supported by Nobumichi Tamura, which is a US Department of Energy Office of Science User 701 Facility under contract no. DE-AC02-05CH11231. The authors thank Jonathan Slack from the 702 ALS for development and maintenance of the in-situ spin coater. The authors are grateful to 703 Tanguy Terlier for the measurement and analysis of ToF-SIMS data. 

- 704 

### **Funding:** 

705 The work Rice University was supported by the DOE-EERE DE-EE0010738 program. I.M. 706 acknowledges the financial support from the Hertz Foundation and the National Science 707 Foundation Graduate Research Fellowship Program (This material is based upon work supported 708 by the National Science Foundation Graduate Research Fellowship Program under grant no. NSF 709 20-587. Any opinions, findings and conclusions or recommendations expressed in this material 710 are those of the author and do not necessarily reflect the views of the National Science Foundation). 711 A.B. was supported by a fellowship through the National Science and Engineering Graduate 712 Fellowship Program (NDSEG) sponsored by the Air Force Research Laboratory (AFRL), the 713 Office of Naval Research (ONR), and the Army Research Office (ARO).  J.H. acknowledges the 714 financial support from the China Scholarship Council (No. 202107990007). J.E. acknowledges the 715 financial support from the Institut Universitaire de France. Work at the Molecular Foundry was 716 supported by the Office of Science, Office of Basic Energy Sciences, of the U.S. Department of 717 Energy under Contract No. DE-AC02-05CH11231. T. K. acknowledges funding by the German 718 Science Foundation (DFG, fellowship number KO6414). 

719 

720 

### **Authors contributions:** 

33 

- 721 A.D.M., and J.E. conceived the idea, designed the experiments, analyzed the data, and cowrote 722 the manuscript. S.S., W.L., and I.M., designed experiments, analyzed the data and co-wrote the 723 manuscript. S.S. Fabricated devices, tested devices, performed templating experiments, 724 performed WAXS measurements, performed in-situ PL measurements, performed stability 725 experiments. I.M. Fabricated devices, tested devices, synthesized 2D crystals, performed WAXS 726 measurements, performed GIWAXS measurements, performed in-situ PL measurements. W.L. 727 and E.T. performed and analyzed the GIWAXS measurements. T.K. performed WAXS 728 measurements, performed in-situ PL measurements under the guidance of C.M.S-F. C.D. and 729 A.T. performed nano-XRD measurements and analyzed the data under the guidance from D.F. 730 M.K. performed the Dynamic Light Scattering of FAPbI3 solutions under the guidance from 731 A.B.M. J. H. synthesized the 2D perovskite crystals. F.M., R.P., and R.G. fabricated devices, 732 tested devices and helped in performing the stability experiments. H.Z. Performed ex-situ optical 733 measurements with the help from A.T. I.A.M.P. performed and analyzed the ss-NMR 

- 734 measurements under the guidance of G.N.M.R. A.B. performed the PES measurements for the 735 perovskite thin films under the guidance of M.G.K. M.A.A. analyzed device performance. C.K. 736 analyzed the structural properties of 2D and lattice mismatch between the 2D and 3D. D.G. 737 analyzed the optical spectroscopy measurements and contributed to editing the paper. 

- 738 

- 739 

- 740 

**Competing interests:** The authors declare no competing interests. 

741 **Data and Materials Availability:** All (other) data needed to evaluate the conclusions in the 742 paper are present in the paper or the Supplementary Materials. 

- 743 

34 

744 Supplementary Information 

# 745 **Two-dimensional perovskite templates for durable** 746 **and efficient formamidinium perovskite solar cells** 

747 Siraj Sidhik<sup>1,2#</sup> , Isaac Metcalf<sup>1#</sup> , Wenbin Li<sup>3</sup> , Tim Kodalle<sup>4</sup> , Connor Dolan<sup>5</sup> , Mohammad 748 Khalili<sup>2</sup> , Jin Hou<sup>1</sup> , Faiz Mandani<sup>2</sup> , Andrew Torma<sup>3</sup> , Hao Zhang<sup>3</sup> , Jessica Persaud<sup>2</sup> , Amanda 749 Marciel<sup>2</sup> , Itzel Alejandra Muro Puente<sup>6</sup> , G. N. Manjunatha Reddy<sup>6</sup> , Adam Balvanz<sup>7</sup> , Mohamad 750 A. Alam<sup>8</sup> , Claudine Katan<sup>9</sup> , Esther Tsai<sup>10</sup> , David Ginger<sup>11</sup> , David Fenning<sup>5</sup> , Mercouri G. 751 Kanatzidis<sup>12</sup> , Carolin M. Sutter-Fella<sup>4</sup> , Jacky Even<sup>13</sup> * and Aditya D. Mohite<sup>1,2</sup> * 

751 752 753 

### **1. Methods and Characterization** 

754 

### **1.1 High purity 2D perovskite powder synthesis** 

755 We synthesized the 2D Ruddlesden-Popper perovskite parent crystals, BA2FAPb2I7 by combining 756 the lead oxide (PbO, Sigma Aldrich, 99%), formamidine hydrochloride (FACl, Sigma Aldrich, 757 ≥98%), and butylamine (BA, Sigma Aldrich, 99.5%) in precise stoichiometric ratios. This mixture 758 was dissolved in a solution of hydroiodic acid (HI, 57 wt% in H2O) and hypophosphorous acid 759 (H3PO2, 50% in H2O) and stirred at a temperature of 240°C until complete dissolution of the 760 precursor materials and boiling of the solution occurred. Subsequently, the precursor solution was 761 allowed to cool down to room temperature, resulting in the crystallization of flat single crystals 

762 with sizes ranging from micrometres to millimetres. To ensure the quality and phase purity of the 763 synthesized crystals, we performed a comprehensive analysis using a combination of X-ray 764 diffraction and absorbance measurements. 

765 

### 1 **.2 Air-liquid interface method for single crystal growth of BA2FAPb2I7** 

766 To synthesize large-area 2D Ruddlesden-Popper perovskite crystals, BA2FAPb2I7, we combine 767 lead oxide (PbO, Sigma Aldrich, 99%), formamidine hydrochloride (FACl, Sigma Aldrich, ≥98%), 

768 and butylamine (BA, Sigma Aldrich, 99.5%) in precise stoichiometric ratios. This mixture is 769 dissolved in a solution of hydroiodic acid (HI, 57 wt% in H2O) and hypophosphorous acid (H3PO2, 

35 

- 770 50% in H2O), and stirred at a temperature of 240°C until the precursor materials completely 

- 771 dissolve and the solution begins to boil. Subsequently, the solution is kept at a temperature of 

- 772 100˚C without stirring. A clean glass is introduced at the bottom of the vial, allowing the large- 

- 773 area crystals to form at the air-liquid interface. Once the crystal has formed, the glass is carefully 

- 774 extracted from the vial using forceps, with the slightest movement aiding in scooping up the 

- 775 formed crystals. The resulting film on the glass is washed with ether and annealed at a temperature 776 of 125°C to remove any trapped solvents in the crystals. 

- 777 

### **1.3 Solar cell fabrication** 

778 _Inverted planar perovskite solar cells:_ The patterned glass/ITO substrates underwent a sequential 779 cleaning process involving ultrasonication in soap water, followed by deionized water, acetone, 780 and a mixture of acetone and ethanol (1:1), each for 15 minutes. After drying the substrates and 781 subjecting them to 30 minutes of UV-ozone cleaning, they were transferred to a glove box. Inside 782 the glove box, a hole-transporting layer (HTL) with a thickness of approximately 10 nm was 783 created using the SAMs layer (MeO-2PACz, TCI, America) at a concentration of 0.8 mg/ml in 784 Ethanol. The HTL was deposited by spin coating at 5000 rpm for 30 seconds, followed by 785 annealing at 100 ˚C for 10 minutes. 

786 To prepare the FAPbI3 perovskite precursor solution with a concentration of 1.0 M, the 787 PbI2, and FAI, were mixed in a solvent mixture of DMF and DMSO (6:1). The solution was 788 continuously stirred for 4 h, following which various mol% of the formamidinium based 2D 789 perovskite, A<sup>’</sup> 2FAn-1PbnI3n+1, where A<sup>’</sup> stands for different bulky organic cations such as 790 butylammonium, and pentylammonium etc, was introduced and left for aging on the hot plate at 791 70<sup>o</sup> C for 30 min. A single-step spin coating process was employed to achieve a uniform coverage 

792 of the perovskite film by spin coating the solution at 5000 rpm for 30 seconds with an acceleration 

36 

- 793 of 2500 rpm/s.  The samples were subsequently annealed at 150 ˚C for 20 minutes.  Lastly, the 

- 794 devices were completed by thermal evaporation of C60 (30 nm), BCP (1 nm), and Copper (100 

- 795 nm) under a vacuum of less than 2x10<sup>-6</sup> torr. The active area selected for the devices was 0.5 cm<sup>2</sup> . 

- 796 **1.4 Optical absorbance and photoluminescence measurements** 

- 797 _Thin film absorbance measurements:_ Film absorbance measurements were carried out using a 

- 798 setup that involved illuminating the samples with modulated monochromatic light at a frequency 

- 799 of 2 kHz. The light was generated by a quartz-tungsten-halogen light source and passed through a 

- 800 monochromator (SpectraPro HRS 300, Princeton Instruments). To detect the transmitted light, 

801 synchronous detection was employed using a silicon photodiode connected to an SR865 lock-in 

- 802 amplifier. The measurements were conducted in the spectral range of 400 – 800 nm, with a dwell 

- 803 time of 0.1 s for each data point. Throughout the experiment, the samples were maintained under 

- 804 vacuum conditions of approximately 10<sup>-4</sup> torr and kept at room temperature. 

- 805 _Steady-state photoluminescence measurements:_ Thin-film photoluminescence (PL) measurements 

- 806 were performed using a lab-built confocal microscopy system to acquire steady-state 807 photoluminescence (SS-PL) data. Spectra were collected using an Andor Kymera 329i 808 spectrometer and an Andor iDus 416 CCD detector. The acquired spectra were then processed 

- 809 using Savitzky-Golay filtering for optimal signal-to-noise ratio. For photoexcitation, the samples 

- 810 were illuminated with a monochromatic pulsed laser emitting at 2.58 eV (480 nm). The laser, with 

- 811 a pulse duration of 6 ps and a repetition rate of 78.1 MHz, was focused near the diffraction limit, 

- 812 achieving a resolution of approximately 0.5 µm. The excitation intensity was carefully adjusted to 

- 813 360 W/cm<sup>2</sup> . PL measurements were conducted in the spectral range of 450 - 900 nm with a dwell 

- 814 time of 0.1 s. The experiments were performed under vacuum conditions (10<sup>-5</sup> torr) at room 

- 815 temperature. PL maps were acquired by scanning a region of either 40 µm x 40 µm or 100 µm x 

37 

- 816 100 µm, using a step size of 1 µm. At each step, the peak position of the photoluminescence signal 

- 817 was extracted and recorded for further analysis. 

- 818 **1.5 Time-resolved photoluminescence (TRPL) measurements** 

- 819 Time resolved photoluminescence (TRPL) measurements were performed by exciting the samples 

- 820 with various fluence laser pulse (420 nm, 40 fs pulse duration and 100 kHz repetition rate). These 

- 821 laser pulses are generated by frequency doubling the laser pulse from diode-pumped Yb:KGW 

- 822 femtosecond laser system (PHAROS) using barium-beta-borate crystal. This laser pulse (beam 

- 823 spot size of 20 µm) was then focused onto sample with a 3.8 mm focal length lens. The emitted 

- 824 light was then collected using a Mitutoyo objective lens (numerical aperture = 0.7, magnification 

- 825 = 100×) from the transmission side and subsequently spatially filtered using a mechanical iris 

- 826 located at the conjugate plane. Elastically scattered light was rejected by using a long pass filter 

- 827 (wavelength 650 nm, optical density = 6.0). Additionally, bandpass filter centred at 800 nm 828 (wavelength = 800±20 nm, optical density = 4.0) was employed to filter the emitted light. The 

- 829 emitted light was then focused onto the Micro Photon Device (MPD) PDM series single-photon 

- 830 avalanche photodiode with an active area of 50 µm. The temporal resolution was set at a binning 

- 831 size of 64 ps. Photoluminescence spectra were collected by directing the emitted light towards a 

- 832 spectrometer using a flippable mirror. 

- 833 **1.6 Ultrafast Transient absorption spectroscopy** 

- 834 Time-resolved absorption (TA) data of the samples were obtained using transient femtosecond 

- 835 pump-probe spectroscopy. The samples were excited by 420 nm laser pulse generated by using an 

- 836 optical parametric amplifier having a pulse duration of 40 fs and a beam spot size of 120 µm. 

- 837 Diode-pumped Yb: KGW femtosecond laser system based on the principle of chirped-pulse 

- 838 amplification (PHAROS) produces light pulses centred at 840 nm. These laser pulses were then 

38 

- 839 passed through 0.5 mm thick barium-beta-borate crystal where the frequency will be doubled to 

- 840 produce laser pulses centred at 420 nm acting as pump pulse. These laser pulses are focused on 841 the sample with a spot size of 120 µm in diameter (1/e<sup>2</sup> ). Another laser pulse from the amplifier is 

- 842 focused onto a sapphire crystal to produce white-light supercontinuum that acts as a probe pulse. 

- 843 The optical path length between pump and probe is manipulated by passing the probe beam 

- 844 through a retroreflector mounted on high precision motorized translational stage. Probe pulse 845 (beam diameter 35 µm) was then focused and spatially overlapped with the pump pulse onto the 

- 846 sample. It is then re-collimated and directed onto a multi-mode fibre for wavelength-sensitive 

- 847 detection. 

- 848 

### **1.7 X-ray diffraction measurements** 

- 849 1D X-ray diffraction of the 3D perovskite thin films were measured in the 2𝜃 between 2˚ and 30˚, 

- 850 with a step of 0.01˚ and a speed of 2<sup>o</sup> /min, using a Rigaku SmartLab X-Ray diffractometer with 

- 851 Cu(K **α** ) radiation (𝜆 = 1.5406 Å). For lattice parameter determination shown in **Figure 2E** , thin 

- 852 films were scraped with a blade and wiped onto a glass slide to remove any residual strain from 

- 853 the substrate. The scraped films were then coated with a thin film of PMMA to prevent α → δ 854 conversion during XRD measurement in air. 

- 855 Single crystal X-Ray diffraction of the 2D perovskite crystals was taken with a Rigaku Synergy-S 

- 856 diffractometer using a Mo target. The temperature was held at 300K. 

- 857 **1.8 Differential Scanning Calorimetry (DSC) measurements** 

- 858 FAPbI3 powders for DSC were prepared by spin-coating 300µL of FAPbI3 precursor solution onto 

- 859 a large-area (25cm<sup>2</sup> ) substrate, drying at room temperature under vacuum, and scraping with a 

- 860 blade. DSC was performed using a TA DSC 250 with a scan rate of 1<sup>o</sup> C/min. 

- 861 **1.9 Nuclear Magnetic Resonance (NMR) measurements** 

39 

