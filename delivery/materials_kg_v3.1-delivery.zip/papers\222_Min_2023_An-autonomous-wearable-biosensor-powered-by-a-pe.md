# An autonomous wearable biosensor powered by a perovskite solar cell

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Electronics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 338 |
| 作者 | Ji-Hong Min, Stepan Demchyshyn, J. Sempionatto, Yu Song, Bekele Hailegnaw, Changhao Xu, Yi-Ran Yang, S. Solomon et al. |
| DOI | 10.1038/s41928-023-00996-y |
| 源文件 | 022_Min_2023_An-autonomous-wearable-biosensor-powered-by-a-pe.pdf |

---
#### **nature electronics** 

###### **Article** 

https://doi.org/10.1038/s41928-023-00996-y 

# **An autonomous wearable biosensor powered by a perovskite solar cell** 

|Received: 22 August 2022<br>Accepted: 15 June 2023|**Jihong Min**<br> <sup>**1,6**</sup>**, Stepan Demchyshyn**<br> <sup>**2,3,6**</sup>**, Juliane R. Sempionatto**<br> <sup>**1**</sup>**,**<br>**Yu Song**<br> <sup>**1**</sup>**, Bekele Hailegnaw**<sup>**2,3**</sup>**, Changhao Xu**<br> <sup>**1**</sup>**, Yiran Yang**<sup>**1**</sup>**,**<br>**Samuel Solomon**<sup>**1**</sup>**, Christoph Putz**<br> <sup>**2,3**</sup>**, Lukas E. Lehner**<br> <sup>**2,3**</sup>**,**|
|---|---|
|Published online: 20 July 2023|**Julia Felicitas Schwarz**<sup>**4**</sup>**, Clemens Schwarzinger**<br> <sup>**4**</sup>**, Markus Clark Scharber**<br> <sup>**5**</sup>**,**|
|Check for updates|**Ehsan Shirzaei Sani**<sup>**1**</sup>**, Martin Kaltenbrunner**<br> <sup>**2,3**</sup><br>**& Wei Gao**<br> <sup>**1**</sup>|



Wearable sweat sensors can potentially be used to continuously and non-invasively monitor physicochemical biomarkers that contain information related to disease diagnostics and fitness tracking. However, the development of such autonomous sensors faces a number of challenges including achieving steady sweat extraction for continuous and prolonged monitoring and addressing the high power demands of multifunctional and complex analysis. Here we report an autonomous wearable biosensor that is powered by a perovskite solar cell and can provide continuous and non-invasive metabolic monitoring. The device uses a flexible quasi-two-dimensional perovskite solar cell module that provides ample power under outdoor and indoor illumination conditions (power conversion efficiency exceeding 31% under indoor light illumination). We show that the wearable device can continuously collect multimodal physicochemical data—glucose, pH, sodium ion, sweat rate and skin temperature—across indoor and outdoor physical activities for over 12 h. 

The recent shift towards personalized and remote healthcare has accelerated the development and adoption of wearable devices that can continuously monitor physical vital signs as well as biochemical markers<sup>1–15</sup> . Wearable biosensors can potentially be used to continuously and non-invasively analyse body fluids such as sweat, which contains a wealth of information pertinent to disease diagnostics and fitness tracking<sup>1,8,13,16,17</sup> . A variety of electrochemical sensing strategies, including amperometry, potentiometry, voltammetry and impedance spectroscopy, have been used to detect sweat biomarkers (such as electrolytes, metabolites, nutrients, drugs and hormones)<sup>1–3,8,17–19</sup> and sweat rate (which may have a close link to the secreted biomarker levels)<sup>11,12,20</sup> . For practical health monitoring beyond that during vigorous exercise, wearable biosensors can also benefit from steady sweat extraction via iontophoresis—a localized sedentary sweat stimulation technique<sup>21,22</sup> . 

However, due to challenges related to multimodal system miniaturization and integration, the development of wearable systems capable of autonomous sweat induction and sampling, real-time sweat rate monitoring and continuous multiplexed biomarker analysis remain limited. 

High power demand also impedes the development of such multifunctional wearable sensing systems. Wearable sensors typically rely on the use of batteries: a bulky and unsustainable power source that requires an external source of electricity to recharge. Various energy-harvesting strategies—including biofuel cells and triboelectric nanogenerators—have been explored for powering battery-free wearables<sup>23–29</sup> . However, biofuel cells typically suffer from limited long-term stability due to biofouling in human sweat<sup>23</sup> , and triboelectric nanogenerators require extensive physical activity to generate electricity<sup>24</sup> . Furthermore, the power densities produced by biofuel 

> 1Andrew and Peggy Cherng Department of Medical Engineering, Division of Engineering and Applied Science, California Institute of Technology, Pasadena, CA, USA.<sup>2</sup> Division of Soft Matter Physics, Institute of Experimental Physics, Johannes Kepler University Linz, Linz, Austria.<sup>3</sup> Soft Materials Lab, Linz Institute of Technology, Johannes Kepler University Linz, Linz, Austria.<sup>4</sup> Institute for Chemical Technology of Organic Materials, Johannes Kepler University Linz, Linz, Austria.<sup>5</sup> Linz Institute for Organic Solar Cells, Johannes Kepler University Linz, Linz, Austria.<sup>6</sup> These authors contributed equally: Jihong Min, Stepan Demchyshyn. e-mail: martin.kaltenbrunner@jku.at; weigao@caltech.edu 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**630** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

cells and triboelectric nanogenerators from casual daily activities are limited<sup>24,25</sup> . 

Ambient light, including natural sunlight and artificial indoor light, is an abundant form of energy that is readily available during daily activities. The commercially dominant photovoltaic technologies, which are based on silicon, work well for large-scale solar energy harvesting, but struggle to address the power needs of wearable devices. In particular, silicon cells are often fragile, bulky and rigid. They also provide insufficient power conversion efficiency (PCE) under low or indoor illumination, due to their narrow bandgap and preferentially trap-assisted recombination, limiting their range of applications<sup>30</sup> . Light-harvesting technologies based on the III–V family of semiconductors can address some of the limitations of silicon, but their fabrication often requires complex processing conditions, which is reflected in their price/energy payback time and thus their potential areas of application<sup>31,32</sup> . 

Perovskite solar cells offer a number of favourable intrinsic properties including long charge carrier diffusion lengths, high absorption coefficients, solution processability, small exciton binding energies, high structural defect tolerance, tunable bandgap and high photoluminescence quantum yields<sup>33,34</sup> . Such solar cells have developed quickly in the last decade due to their evolving fabrication protocols and the adaptability of the material compositions<sup>35</sup> . Perovskites also offer strong defect tolerance that leads to high parallel resistance ( _R_ p), which is the key parameter of solar cell performance under low-light conditions. This results in increased fill factor (FF) and reduced open-circuit voltage ( _V_ oc) losses at low-light conditions, which—in combination with the matching of perovskite solar cell spectral response to common indoor lighting emission spectrum—yields high PCE under indoor illumination<sup>30,36–38</sup> . 

In this Article, we report an autonomous wearable biosensor that is powered by a flexible perovskite solar cell (FPSC) and can provide continuous and non-invasive metabolic monitoring (Fig. 1a). Our multifunctional wearable device offers autonomous sweat extraction via iontophoresis, dynamic microfluidic sweat sampling, multiplexed monitoring of sweat biomarkers using different electrochemical detection techniques, impedance-based sweat rate analysis and Bluetooth-based wireless data transmission. The wearable device operates under a wide range of illumination conditions ranging from full sunlight to indoor lighting. It is powered by an efficient 2-cm<sup>2</sup> -active-area lightweight quasi-two-dimensional (2D) FPSC energy-harvesting module with a PCE of 14.00% under air mass global 1.5 (AM1.5G) illumination, and 29.64% under 600 lx indoor illumination with a white-light light-emitting diode (LED) light bulb. The sensing platform can be used to continuously collect multimodal physicochemical data (glucose, pH, sodium ion (Na<sup>+</sup> ), sweat rate and temperature) across indoor and outdoor physical activities for over 12 h, and without the need for batteries or vigorous exercise. 

###### **Wearable device design for autonomous biomarker analysis** 

The wearable device consists of disposable and reusable modules assembled in an origami-like fashion (Fig. 1b and Supplementary Figs. 1 and 2). Among the reusable parts is the highly efficient quasi-2D FPSC module that converts ambient light into electrical power and the energy-efficient flexible printed circuit board for electrochemical instrumentation, signal processing and Bluetooth wireless communication. A daily disposable flexible patch contains a pair of carbachol hydrogel (carbagel)-coated iontophoresis electrodes for sweat stimulation, a laser-engraved microfluidic module integrated with interdigitated electrodes for sweat sampling and sweat rate monitoring and a multiplexed electrochemical sweat biosensor array for molecular analysis (Fig. 1c). Compared with traditionally used pilocarpine gels, carbachol gels were selected for iontophoresis as they allow for efficient and long-lasting sudomotor axon reflex sweat secretion 

from the surrounding sweat glands, ideally suitable for microfluidic sweat sampling<sup>21</sup> . Inkjet printing was used to fabricate all the flexible biosensing electrodes and interconnects at a large scale and low cost. Considering that chemical sensors usually suffer from signal drift during long-term use, their capacity for mass production allows disposable use on a daily or multiday basis for reliable wearable health monitoring. Potentiometric, amperometric, voltammetric and impedimetric techniques can be performed using the wearable device to analyse a broad spectrum of sweat biomarkers ranging from metabolites, electrolytes and nutrients to substances and drugs. The fully assembled wearable device is 20 mm × 27 mm × 4 mm in size and can comfortably adhere to the skin (Fig. 1d,e). The custom-embedded algorithm and mobile application enable an energy-saving adaptive power consumption scheme such that the wearable device can extract and analyse sweat across various activities and illumination conditions in a prolonged and efficient fashion. All the calibrated biomarker information can be wirelessly transmitted and displayed on a custom mobile app (Fig. 1e, Supplementary Fig. 3 and Supplementary Video 1). 

###### **FPSC design and characterization for wearable use** 

To effectively and sustainably power the wearable device, an FPSC module (Fig. 2a) is designed to have a high power density and PCE for energy harvesting under diverse lighting conditions, flexibility to endure the mechanical stresses common for on-body wear and stable performance with reliable encapsulation against sweat exposure. The FPSC device utilizes a p–i–n architecture and comprises flexible polyethylene terephthalate (PET) coated with indium tin oxide (ITO), Cr/Au busbars, a poly(3,4-ethylenedioxythiophene)-poly(styrenesulfo nate) (PEDOT:PSS) hole transport layer, quasi-2D perovskite photoactive layer, [6,6]−phenyl-C61-butyric acid methyl ester (PCBM) electron transport layer, TiO _x_ interlayer, Cr/Au contacts and an epoxy/polyvinyl chloride (PVC)/polychlorotrifluoroethylene encapsulation (Fig. 2b). The perovskite absorber layer (~450 nm thick) with an empirical formula of (MBA)2(Cs0.12MA0.88)6Pb7(I _x_ Cl1– _x_ )22 is at the heart of the device (Fig. 2c). A large organic spacer, namely, α-methylbenzylamine (MBA), facilitates the formation of a quasi-2D perovskite structure with a large grain size and improved defect passivation, resulting in an excellent device performance (Supplementary Fig. 4). Under simulated solar illumination (AM1.5G) a quasi-2D FPSC with a small active area (0.165 cm<sup>2</sup> ) achieves a PCE of up to 18.1%, which remains as high as 16.5% for large-area devices (1.000 cm<sup>2</sup> ) and 14.0% for modules consisting of two large cells joined in series (total active area, 2.000 cm<sup>2</sup> ) (Supplementary Fig. 5 and Supplementary Table 1). 

The main advantage of our quasi-2D FPSC energy-harvesting module is its ability to operate at high efficiency even under indoor and low-light illumination conditions. Common indoor lighting sources, like LEDs, have a narrower emission spectrum that closely matches the external quantum efficiency of our quasi-2D FPSC, and a lower photon flux density compared with sunlight (Fig. 2d). This results in an increased PCE due to reduced sub-bandgap relaxation and recombination losses, as well as the passivation of trap states and grain boundaries via MBA incorporation. Thus, a quasi-2D FPSC practically doubles its efficiency under 600 lx (215 μW cm<sup>−2</sup> ) LED indoor illumination, achieving a PCE as high as 31.2% in small-area devices, scaling up efficiently to large area with a PCE of up to 29.9% and reaching 29.6% in the module configuration (Fig. 2e and Supplementary Table 2). These are some of the highest reported PCE values among indoor flexible solar cells, outperforming not only perovskite but also other PV technologies in this field (Supplementary Table 3). Furthermore, the power output of the quasi-2D FPSC module reliably extends over a broad range of indoor illuminance ranging from very bright (10,000 lx), common for special environments like surgery rooms, down to dimly lit surroundings (20 lx) (Fig. 2f and Supplementary Figs. 6 and 7). 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**631** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 



<!-- Start of picture text -->
a b<br>Sunlight Indoor light<br>FPSC<br>FPSC<br>FPCB<br>Patterned<br>contacts<br>Sensor array<br>Quasi-2D<br>perovskite Battery-free autonomous Carbagel<br>wearable biosensor<br>Microfluidic<br>layers<br>Accumulation<br>PI Biosensors Carbagel layer<br>PET/M-tape Skin Sweat Skin<br>c d e<br>Microfluidic sensor patch<br>Sweat<br>stimulation<br>Sweat<br>biosensors<br>Sweat<br>rate FPCB FPSC<br>sensor<br>LumiStat<br><!-- End of picture text -->

**Fig. 1 | Schematic and images of the ambient-light-powered battery-free lab on the skin. a** , Illustration of the energy autonomous wearable device that is powered under both outdoor and indoor illumination via a quasi-2D FPSC and performs multiplexed wireless biomolecular analysis across a wide range of activities. Carbagel, carbachol hydrogel; M-tape, medical tape; PET, polyethylene terephthalate; PI, polyimide; FPCB, flexible printed circuit board. **b** , Exploded three-dimensional model of the layer assembly of the wearable 

device. **c** , Photograph of an inkjet-printed disposable microfluidic sensor patch that contains an iontophoretic module for autonomous sweat stimulation, microfluidics for sweat sampling, multiplexed electrochemical biosensors for perspiration analysis and an impedimetric sweat rate sensor. Scale bar, 0.5 cm. **d** , Photograph of the wearable device assembled in origami style. Scale bar, 1 cm. **e** , Photograph of the wearable device worn on the ventral forearm and wirelessly connected to a custom-developed mobile app over BLE. Scale bar, 2 cm. 

To acquire light-source-independent performance values, we also measured PCE using a monochromatic light source (continuous laser, _λ_ = 637 nm) over a range of indoor and low-light irradiances (0.07 < _P_ in < 18.00 mW cm<sup>−2</sup> ) (Supplementary Fig. 8). We achieved a record-breaking PCE of 41.4 ± 0.1% measured at _P_ in = 12.23 mW cm<sup>−2</sup> for small-area devices and a PCE of 30.4 ± 0.2% at _P_ in = 6.08 mW cm<sup>−2</sup> for large-area devices (Supplementary Table 4 and Supplementary Note 1). 

The quasi-2D FPSC modules show a steady power output with no loss in performance after continuous 24 h operation under both AM1.5G and indoor illumination conditions (Fig. 2g and Supplementary Fig. 9). Additionally, the mechanical stability of the module was confirmed to withstand 2,000 bending cycles (bending radius, 5 cm) with only negligible reduction in performance that can be attributed to the decrease in ITO electrode resistance (Fig. 2h and Supplementary Figs. 10 and 11). 

Considering the concern of possible Pb leakage when using perovskite solar cells, a set of Pb release tests were performed in deionized (DI) water (Supplementary Fig. 12), as well as in a standard synthetic sweat solution<sup>39,40</sup> on a fully encapsulated quasi-2D FPSC module (Fig. 2i). Continuous operation of the FPSC module under AM1.5G for 24 h and 

fully immersed in a simulated sweat solution resulted in a Pb concentration that remained more than one order of magnitude below the maximum allowable level in drinking water as per the Joint Food and Agriculture Organization/World Health Organization (FAO/WHO) Expert Committee on Food Additives<sup>41</sup> (Fig. 2i), indicating the encapsulation robustness and module safety even under conditions that far exceed the expected operational conditions of the wearable device. Furthermore, the encapsulated FPSC maintained high biocompatibility even after vigorous mechanical bending tests as evidenced by low Pb leakage as well as high cell viability and metabolic activity of the cells seeded on the FPSCs (Supplementary Figs. 13 and 14). 

###### **System-level integration and operation of wearable device** 

Composed of off-the-shelf electronic components, the judiciously designed wearable electrochemical instrumentation system of the wearable device is more powerful in functionality and power efficient than any other reported wearable sweat analyser, to the best of our knowledge. The battery-free electronic system interfaces with the skin via an inkjet-printed disposable sweat patch that contains two 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**632** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 



<!-- Start of picture text -->
a b c<br>Front Back Ambient light<br>PET<br>PET<br>ITO<br>ITO<br>+ Busbar PEDOT<br>PEDOT<br>Perovskite<br>Perovskite<br>PCBM/TiO x<br>PCBM/TiO x<br>Bottom contact<br>Bottom contact<br>Encapsulant Encapsulation<br>d e f<br>120 100<br>EQE Small Large Module<br>AM1.5G2700 K LED 80 103<br>90<br>60<br>102<br>60<br>40<br>30 20 101<br>0 0 100<br>300 500 700 900 0 0.5 1.0 1.5 2.0 101 102 103 104<br>Wavelength (nm) Voltage (V) Illuminance (lux)<br>g h i<br>40 1.05<br>30 AM1.5G 1.00 101 [Pb] limit in drinking water<br>20<br>0.95 100<br>200<br>600 Ix LED<br>0.90<br>160 10–1<br>0.85<br>120<br>80 0.80 10–2<br>0 6 12 18 24 0 500 1,000 1,500 2,000 0 5 10 15 20 25<br>Time (h) Bending cycles Time (h)<br>EQE (%)<br>Current (µA) Power (µW)<br>Dark  surroundings Stairways, elevators Regular rooms,offices Laboratories, workbenches, art studios Special bright rooms, eratinopg rooms<br>Power (mW)<br> (µg l–1) C Pb<br>Normalized PCE<br>Power (µW)<br><!-- End of picture text -->

**Fig. 2 | Design and characterization of the FPSC. a** , Photograph of an FPSC. Scale bar, 1 cm. **b** , Three-dimensional model of the FPSC module architecture consisting of two individual 1-cm<sup>2</sup> -active-area solar cells connected in series. **c** , Cross-sectional SEM image of the FPSC. Scale bar, 400 nm. Experiments were independently repeated five times with similar results. **d** , External quantum efficiency (EQE) of the FPSC superimposed with the normalized emission spectrum of a standard reference AM1.5G tilt sun illumination and roomlight (2,700 K) LED light bulb spectrum. **e** , Current–voltage curves of small 

(0.165 cm<sup>2</sup> ), large (1.000 cm<sup>2</sup> ) and module (2.000 cm<sup>2</sup> ) FPSCs recorded under room-light LED light bulb illumination (2,700 K, 600 lx). **f** , Power output of an FPSC module as a function of illuminance. _R_<sup>2</sup> , coefficient of determination of linear regression. **g** , Maximum power point tracking of the FPSC module under full sunlight AM1.5G and indoor warm-light LED (600 lx) illumination over 24 h. **h** , Normalized PCE of the FPSC module as a function of 2,000 bending cycles (5 cm bending radius). **i** , Results of Pb release test from FPSC module when submerged in a synthetic sweat solution and operated for 24 h. 

gel-loaded iontophoretic electrodes, three electrochemical sweat biosensors and one sweat rate sensor embedded in the microfluidics (Fig. 3a). The system performs constant-current iontophoresis for sweat induction; amperometry, potentiometry and voltammetry for continuous analysis of a variety of sweat biomolecular markers; impedance measurements for sweat rate monitoring; and Bluetooth data communication with the user interface (Fig. 3b,c and Supplementary Figs. 15 and 16). 

More specifically, the wearable device’s electronic system consists of (1) an energy-harvesting power management integrated circuit (PMIC) that efficiently boosts, converts and manages the output from the quasi-2D FPSC, (2) a compact programmable system-on-chip (PSoC) Bluetooth low-energy (BLE) module that integrates a microcontroller (MCU) and BLE radio, (3) an electrochemical analogue front end (AFE) that integrates various configurable blocks necessary for electrochemical detection and (4) a high-compliance-voltage current source with an overcurrent protection switch for iontophoresis (Fig. 3b and 

Supplementary Fig. 17a,b). Under illumination, the PMIC charges the 5 mF solar energy storage capacitor up to ~5 V to continuously power the wearable device. Our custom-developed embedded algorithm ensures that each block of the system operates at its lowest viable power mode, enabling ultralow-power multiplexed electrochemical measurements consuming below 60 μW (Supplementary Fig. 17). During operation, the wearable device stays in the deep-sleep (33 μW during standby) or sleep (47 μW during potentiostat operations) modes and intermittently wakes up to either wirelessly communicate with the host software, perform an electrochemical measurement or process the measurement data (Supplementary Fig. 19). Depending on the illumination conditions and the quasi-2D FPSC’s power output, the wearable device adapts its operation mode (for example, parameters such as BLE communication interval and sensor data acquisition interval to mediate the power consumption) (Supplementary Note 2). The power consumption profiles for each electrochemical operation and the corresponding capacitor charging–discharging curves of the solar 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**633** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 



<!-- Start of picture text -->
a b c<br>Electrochemical AFE IC<br>CE IMP – High-speed  Control unit INT PSoC<br>IMP + impedance  SPI BLE<br>IMP RE engine Memory module<br>WE1 Temperature  ADC<br>WE2 sensor Voltage<br>regulator<br>WE3 Timers<br>Low-power<br>RE CE potentiostat<br>IP – loop Filters Energy-<br>harvesting<br>Sweat stimulation Sweat rate IP + Current source Boost converter PMIC<br>d<br>5.4<br>Iontophoresis Potentiometry Amperometry Differential pulse voltammetry Impedance analysis<br>5.1<br>4.8<br>(Bright light)<br>18,000 lx 14,000 lx 12,000 lx 8,000 lx 4,000 lx 2,000 lx<br>200<br>Initialization BLE Measurement Process Sleep Iontophoresis<br>180<br>80<br>40<br>0<br>0 5 10 15 20 0 5 10 15 20 0 5 10 15 20 0 5 10 15 20 0 5 10 15 20<br>Time (s)<br>e f g 3.00 1.00 0.25 0.12 µl min–1<br>350 240 5.4 –10<br>4 pH Multiplexed + impendance Multiplexed<br>6 Na+ –30<br>150 160 mM 8 200 4.7 120<br>80 mM<br>–50 40 mM 10 160 4.0 80<br>20 mM (Lab light) (Room light) 220<br>1,600 lux 1,300 lux 1,000 lux 700 lux 400 lux<br>10 16 105 180<br>0 µM Glu Initialization BLE Measurement Process Sleep<br>50 µM SR 40<br>–25 10 70<br>36 µl 150 µM 25<br>24 µl<br>–60 12 µl 200 µM 4 35 20<br>0 µl 10<br>–95 –2 0 0<br>0 30 60 90 120 0 200 400 600 0 200 400 600 0 5 10 15 20<br>Time (s) Time (s) Time (s) Time (min)<br>IP + WEs IP –<br>Multiplexer<br>Switch matrix<br>Voltage (V)<br>Power (mW)<br>Glu (nA)<br>pH (mV)<br>Potential (mV) Voltage (V)<br>Potential (mV)<br>+Na (mV)<br>Temp (°C)<br>Current (nA) Admittance (mS) Power (mW) SR (mS)<br><!-- End of picture text -->

**Fig. 3 | System design and characterization of the wearable device for energy harvesting and autonomous multimodal biosensing. a** , Schematic of the disposable microfluidic sweat patch for sweat induction and sampling. IMP, impedance; CE, counter electrode; WE, working electrode; RE, reference electrode; IP, iontophoresis. **b** , System-level block diagram of the wearable device. **c** , Custom mobile application for the wearable device. ADC, analogueto-digital converter; AFE IC, analogue front-end integrated circuit; PSoC, programmable system on chip; INT, interrupt; SPI, serial peripheral interface. **d** , Power consumption profile (bottom) and corresponding capacitor 

charging–discharging curves (top) of various operation modes under varying light intensities. **e** , Responses of the Na<sup>+</sup> , pH, glucose (Glu) and sweat rate (SR) sensors obtained by the wearable device. **f** , Power consumption profile (bottom) and corresponding capacitor charging–discharging curves (top) during multiplexed measurements under indoor lab-light (left) and room-light (right) illumination conditions. **g** , Multiplexed and multimodal sensing response under varying flow rates (0.12–3.00 μl min<sup>−1</sup> ) and lab-light illumination (1,200 lx). Temp, temperature. 

energy storage capacitor when powered by a quasi-2D FPSC module under various illumination conditions (2,000–18,000 lx) are highlighted in Fig. 3d, Supplementary Fig. 20 and Supplementary Table 5. The electrochemical instrumentation performance of the wearable device was successfully validated by comparing its potentiometric, amperometric and voltammetric responses with those of a commercial potentiostat (Supplementary Fig. 21). 

###### **Characterization of device for multimodal biosensing** 

An iontophoretic sweat induction microfluidic module was carefully designed and optimized for minimal power consumption and prolonged use. Unlike standard pilocarpine gels that can only stimulate 

local sweat glands directly beneath the agonist gel for a short duration and lead to low sensing accuracy due to the mixing of sweat and gel fluid<sup>15,16</sup> , carbagels steadily stimulate local and neighbouring sweat glands for extended durations<sup>21,22</sup> . This property enables the use of miniaturized carbagels for prolonged sweat induction and microfluidic neighbouring sweat collection on a single patch design. The dimensions and layout of the carbagels with respect to the sweat accumulation reservoir were optimized for minimal size, applied current and maximal sweat extraction efficiency (Supplementary Note 3). The reusable carbagel—capable of continuously stimulating sweat throughout the day—is a part of the mass-producible and disposable microfluidic sensor patch that can be replaced for daily use. To demonstrate the device’s wearable use, the sweat-processing system was paired with a sensor 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**634** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

array consisting of an amperometric enzymatic glucose sensor, potentiometric ion-selective pH and Na<sup>+</sup> sensors and an impedimetric sweat rate sensor. The individual current, potential and admittance responses of each sensor were recorded by the wearable device under physiologically relevant target analyte concentrations and/or sweat rates (Fig. 3e and Supplementary Fig. 22); linear responses were observed between the measured electrochemical signals and target concentrations (for glucose sensor), logarithm target concentrations (for pH and Na<sup>+</sup> sensors) and reciprocal flow rates (for sweat rate sensor). Although sweat Na<sup>+</sup> and pH levels can individually serve as potent biomarkers for various health conditions, they could synergistically aid in calibrating the sweat rate and glucose sensors, respectively (Supplementary Fig. 23). In addition, temperature information recorded by the built-in temperature sensor in the AFE of the wearable device aids in more accurate sensor calibrations during wearable use (Supplementary Fig. 24). Moreover, the sweat rate sensor can be reconfigured with different volumetric capacities for the desired operation duration (Supplementary Fig. 25). 

When powered by the quasi-2D FPSC module, the wearable device performs multiplexed on-body measurement sequences under a wide range of indoor illumination conditions. Under indoor LED illumination with a brightness as low as 1,000 lx, the wearable device simultaneously monitors glucose, pH, Na<sup>+</sup> and temperature, along with the periodic impedimetric measurement of sweat rate; when less light (as low as 400 lx) is available, the wearable device’s custom algorithm adapts to decrease the multiplexed measurement frequency and transmits data over BLE advertisements (Fig. 3f). With a larger-area wearable solar cell (8.9 cm × 7.4 cm), the wearable device performs the same multiplexed on-body measurement sequences under even darker illumination conditions (100–300 lx) (Supplementary Fig. 26). 

The in vitro multimodal analyses of glucose, pH, Na<sup>+</sup> , temperature and flow rate through the assembled microfluidic sensor patch were performed in a phosphate-buffered saline (PBS) solution containing 100 μM glucose under varying flow rates (0.12–3.00 μl min<sup>−1</sup> ) and under lab-light illumination (1,200 lx) (Fig. 3g). The glucose, pH and Na<sup>+</sup> biosensors maintained stable and accurate responses even at a flow rate as low as 0.12 μl min<sup>−1</sup> , whereas the sweat rate sensor accurately responded according to the increasing volume. This indicates that although the integrated biosensors respond to physiologically induced analyte-level changes during the on-body tests, their performance is not substantially affected by changes in the sweat rates. The long-term stability of the wearable device for continuous energy harvesting and multiplexed biosensing was further validated in a long-term study with a constant flow rate of 1 μl min<sup>−1</sup> for 100 min under varying indoor illumination conditions (Supplementary Fig. 27). 

###### **On-body device evaluation for multimodal sweat monitoring** 

The compact design of the wearable device enables the comfortable and strong adhesion of the device to different body parts with access to ambient light (Fig. 4a). When worn on body under various outdoor and indoor illumination conditions, the wearable device harvests energy sufficient to enable iontophoresis and multiplexed sweat biosensing sequences; additionally, light-powered iontophoresis results in efficient and prolonged sweat extraction to allow dynamic sweat biomarker analysis (Fig. 4b, Supplementary Fig. 28 and Supplementary Video 2). The accuracy of the device’s interdigitated electrode-enabled sweat rate sensor during wearable use was successfully validated with image-based colorimetric sweat rate analysis (enabled by filling a colour dye in the microfluidic sweat inlet before the on-body test) (Supplementary Fig. 29a). Autonomous periodical sweat induction allows prolonged continuous sweat extraction: our pilot studies show that a single sweat induction event was, on average, able to extract ~52 μl over a duration of 3 h, sustaining a steady sweat rate over 0.1 μl min<sup>−1</sup> (Supplementary Fig. 29b,c). 

The wearable device’s efficient light-energy-harvesting capability and powerful sweat-processing system enable continuous and non-invasive physiochemical monitoring under lab-light illumination conditions. The evaluation of the wearable device for cardiometabolic monitoring was performed by continuously monitoring sweat glucose, pH, Na<sup>+</sup> and sweat rate levels along with the skin temperature of human subjects in both sedentary and exercise trials (Fig. 4c–f and Supplementary Figs. 30 and 31). In sedentary studies, light-powered iontophoretic sweat extraction was followed by the continuous monitoring of key biomarkers. In fasting studies, sweat glucose, pH, Na<sup>+</sup> and skin temperature remained stable, whereas sweat rate rapidly increased in the first 30 min and then gradually decreased (Fig. 4c). In oral glucose intake studies, a substantial increase in sweat glucose was observed through the first hour (Fig. 4d). Sedentary fasting and glucose intake studies were repeated twice for two additional subjects (Supplementary Figs. 30 and 31). From the sedentary oral glucose intake studies performed across three subjects, a high correlation was observed between blood glucose levels and sweat glucose levels (Supplementary Fig. 32). Similarly, in the exercise studies, sweat glucose remained relatively stable or slightly decreased during fasting, whereas clearly elevated glucose levels were observed after oral glucose intake followed by a quick decrease after 30 min (Fig. 4e,f). We also noticed a conspicuous discrepancy between the pH levels of carbachol iontophoresis-induced sweat (~pH 9) and exercise-induced sweat (~pH 5), indicating the importance of sweat induction approaches and pH calibrations on personalized metabolic monitoring (Supplementary Fig. 33). In all the sedentary and exercise studies, positive correlations between the real-time calibrated sweat glucose and blood glucose levels were obtained, indicating the high potential of realizing non-invasive glucose monitoring using the wearable device. Potential noise due to motion artifacts during on-body sensing was mitigated by tightly packing and adhering the miniaturized wearable system onto the skin, where electrochemical sensing was performed in a bound microfluidic reservoir to prevent direct skin–sensor contact. Noise was further reduced by hardware filters integrated onboard as well as smoothing algorithms implemented in the custom app. 

Prolonged cross-activity multimodal monitoring of sweat biomarkers in real-life scenarios was enabled by the wearable device (Fig. 4g). Throughout the day, over a 12 h time span, the subject performed various physical activities under various lighting environments. During this time, the wearable device intermittently performed iontophoresis to ensure that a sufficient sweat rate could be maintained for sweat refreshing and continuous sensor measurements throughout the day. Depending on the available illumination, the wearable device switched its on-body measurement sequence to adjust its power consumption and trading off for measurement intervals. Although the multiplexed data interval varied from 8 to 60 s throughout the day, the wearable device was able to continuously collect, process and calibrate the sensor data in all the scenarios. The glucose trend throughout the day shows that a larger meal during dinner results in a higher and longer sweat glucose spike than a lighter lunch. In addition, the average sweat rate during outdoor sedentary activities was higher than the average sweat rate during indoor sedentary activities, whereas vigorous exercise leads to a substantial increase in the sweat rate. Considering that the battery-free version of the wearable device requires access to light for long-term operation, integrating a small battery into the wearable device could realize 24 h operation (even during sleep) (Supplementary Figs. 34 and 35). 

###### **Conclusions** 

We have reported a wearable biosensor platform that is powered by a quasi-2D FPSC. The wearable device can persistently extract sweat and simultaneously monitor physicochemical markers (glucose, pH, Na<sup>+</sup> , sweat rate and skin temperature) via a spectrum of electrochemical techniques (potentiometry, amperometry, voltammetry and 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**635** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 



<!-- Start of picture text -->
a b<br>0.9<br>1,200 lux 1,000 lux 600 lux  P output<br>0.6 (overcast day) (lab light) (room light) P consumption<br>0.3<br>0<br>0 0.5 1.0 1.5 2.0 2.5 3.0<br>Time (h)<br>Outdoor Indoor<br>15 min 45 min 75 min 105 min 135 min 165 min<br>c d e f<br>200 220 200 220 120 118 120 118<br>150 IP 180 150 IP intake 180 90 Exercise 106 90 Intake Exercise 106<br>100 140 100 140 60 94 60 94<br>50 100 50 100 30 82 30 82<br>11 60 11 60 11 60 11 60<br>9 45 9 45 9 45 9 45<br>7 30 7 30 7 30 7 30<br>5 15 5 15 5 15 5 15<br>40 2.0 40 2.0 40 4 40 4<br>36 1.5 36 1.5 36 3 36 3<br>32 1.0 32 1.0 32 2 32 2<br>28 0.5 28 0.5 28 1 28 1<br>24 0 24 0 24 0 24 0<br>0 50 100 150 0 100 150 0 20 40 60 0 20 40 60<br>Time (min) Time (min) Time (min) Time (min)<br>g Outdoor resting Picnic and casual activities Office work Exercise Indoor resting Dinner and evening entertainment<br>Sunlight Lab light Room light<br>200<br>100 Lunch Dinne r<br>IP IP IP IP<br>10<br>7<br>60<br>30<br>40<br>32<br>2<br>1<br>0<br>9:00 10:00 11:00 12:00 13:00 14:00 15:00 16:00 17:00 18:00 19:00 20:00 21:00<br>Time<br>Power (mW)<br>[Glu] (µM) [Glu] (µM) [Glu] (µM) [Glu] (µM)<br>pH pH pH pH<br>[BG] (mg dl[Na] (mM))–1+ [BG] (mg dl[Na] (mM))–1+ [BG] (mg dl[Na] (mM))–1+ [BG] (mg dl[Na] (mM))–1+<br>Temp (°C) Temp (°C) Temp (°C) Temp (°C)<br>SR (µl min)–1 SR (µl min)–1 SR (µl min)–1 SR (µl min)–1<br>Activity<br>[Glu] (µM)<br>pH<br>+[Na] (mM)<br>Temp (°C)<br>SR<br>–1)(µl min<br><!-- End of picture text -->

**Fig. 4 | On-body evaluation of the wearable device for prolonged and cross-activity perspiration analysis. a** , Photograph of a wearable device worn on body. **b** , Power output of the wearable device’s quasi-2D FPSC module and power consumption of the wearable device electronics when performing multiplexed sweat biosensing under various illumination conditions. The photographs in the inset show the corresponding microfluidic sweat sampling after a single iontophoresis sweat induction event. Scale bar, 

3 mm. **c** , **d** , Wearable device-enabled autonomous multiplexed physiological monitoring in the fasting state ( **c** ) and after a glucose tolerance test ( **d** ) on a healthy subject under lab-light illumination. IP, iontophoresis. **e** , **f** , Wearable device-enabled multiplexed physiological monitoring during vigorous exercise in the fasting state ( **e** ) and after a dietary intake ( **f** ) under lab-light illumination. **g** , Full-day cross-activity physicochemical monitoring with the wearable device under different light conditions. 

impedimetry). It can achieve this under various illumination conditions (strong outdoor sunlight to dim indoor LED light) and across various activities (sleep to vigorous exercise). 

Our quasi-2D FPSC is uniquely suitable for powering wearable technologies. The solar-energy-harvesting technology offers high efficiency under indoor and low-light illumination conditions, maintains high PCE and power output across a wide range of illumination conditions, withstands mechanical stress common for on-body wear during vigorous exercise and remains safe through proper encapsulation. The wearable solar cell is paired with a compact, wireless and 

low-power wearable multichannel electrochemical workstation that dynamically adjusts its power consumption to continuously operate without a battery under varying illumination conditions. The modular design of the wearable device is readily scalable; if required, additional energy-harvesting modules can be incorporated. 

The microfluidic iontophoretic sweat-processing module enables prolonged flow-rate-monitored sweat extraction. This allows sweat biosensing to be applied beyond situations where vigorous exercise is required—that is, normal everyday activity—as well as use for patients with mobility impairments. The rate-monitored persistent sweat flow 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**636** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

continuously refreshes the sensor reservoir for accurate biomarker measurements; the sensor responses are calibrated in real time by personalized factors such as skin temperature, sweat pH and sweat Na<sup>+</sup> to further improve the measurement accuracy. 

Future work for this technology will involve improving the long-term stability of the sensor patch and investigating the correlation between sweat/blood biomarker levels in large-scale human trials. The wearable device can also be paired with different biosensors based on a wide array of electrochemical detection mechanisms (potentiometry, amperometry, voltammetry and impedimetry) for the identification of an endless number of target biomarkers. Potential fields of application include sport science and daily tracking, as well as care for people with health conditions or impairments. 

###### **Methods** 

###### **Materials and reagents** 

All the chemicals and solvents were purchased from commercial suppliers and used as received, if not stated otherwise. 

Agarose, carbachol, potassium chloride (KCl), nickel chloride, potassium (iii) ferricyanide (K3[Fe(CN)6]), potassium (iv) ferrocyanide (K4[Fe(CN)6]), glucose oxidase, glutaraldehyde, bovine serum albumin, 10× PBS, 3,4-ethylenedioxythiophene, poly(sodium 4-styrenesulfonate) (PSS), sodium ionophore X, bis(2-ethylehexyl) sebacate, polyvinyl butyral resin BUTVAR B-98 (PVB), PVC, sodium tetr akis[3,5-bis(trifluoromethyl)phenyl] borate, aniline, iron (iii) chloride, sodium hydroxide, citric acid, ITO-covered 125 μm PET foil, lead iodide, lead chloride, methylamine, ( _R_ )-(+)-α-methylbenzylamine, caesium iodide, hydroiodic acid, _N_ , _N_ -dimethylformamide, acetylacetone, titanium (iv) isopropoxide, 2-methoxyethanol, sodium chloride (NaCl), lactic acid, urea, ammonia and ethanolamine were purchased from Sigma-Aldrich. NaCl, methanol, ethanol, acetone, hydrogen peroxide (30% (w/v)), dextrose (d-glucose) anhydrous, tetrahydrofuran, hydrochloric acid (HCl), tetrachloroauric acid and disodium phosphate were purchased from Thermo Fisher Scientific. Diethyl ether, chlorobenzene, hexane, dimethyl sulfoxide, PEDOT:PSS aqueous dispersion (Clevios PH1000) and chloroform were purchased from VWR. PCBM was purchased from Solenne BV. Hellmanex III detergent was purchased from Hellma Analytics. Zonyl FS-300 fluorosurfactant was purchased from Fluka. Ultraviolet-curable flexible epoxy (LP4115) was purchased from DELO Photobond. Liveo Aclar DX 2000 encapsulating polymer (PVC/polychlorotrifluoroethylene) was purchased from Liveo Research. PDMS (SYLGARD 184) was purchased from Dow Corning. Medical adhesives were purchased from 3M. Polyimide films (~12–75 μm thick) were purchased from DuPont. PET films (~12–250 μm thick) were purchased from McMaster-Carr. 

###### **Solar cell fabrication and characterization** 

Glass substrates (one inch by one inch, 1 mm thick) were cut and cleaned in an ultrasonic bath for 30 min each in 2 v/v% Hellmanex in DI water solution, 2× DI water solution, acetone and isopropanol, and dried using nitrogen stream. Flexible ITO-covered PET substrates were patterned using insulating tape for masking and etched using concentrated HCl for 10 min. After that, they were also cut to one inch by one inch size and washed using the same procedure as that done for glass. The PDMS solution was spin coated onto glass at 4,000 r.p.m. for 30 s and placed on a hot plate at 105 °C for 1 min. After that, flexible substrates were placed onto the PDMS-covered glass, carefully avoiding any trapped air underneath. Finally, the whole substrate was annealed for 15–20 min at 105 °C. Cr–Au busbars were deposited via thermal evaporation using a shadow mask (base pressure, 3 × 10<sup>−6</sup> mbar). 

The PEDOT:PSS solution was prepared by mixing Clevios PH1000 stock solution with 7.0 vol% dimethyl sulfoxide and 0.7 vol% Zonyl FS-300. The PEDOT:PSS solution was stirred at room temperature for an hour and then kept at 4 °C overnight. Right after filtering through Minisart RC25 syringe filter with 0.45 μm regenerated cellulose, the 

PEDOT:PSS solution was spin coated on the substrates with busbars at 1,500 r.p.m. for 45 s (ramp, 2 s) followed by 1,000 r.p.m. for 2 s (ramp, 1 s) and annealed at 120 °C for 15 min. Then, the film was washed by the spin coating of isopropanol at 1,000 r.p.m. for 4 s followed by 4,000 r.p.m. for 12 s and annealed again at 120 °C for 15 min. 

Perovskite solution ((MBA)2(Cs0.12MA0.88)6Pb7(I _x_ Cl1– _x_ )22) was prepared by mixing lead iodide (322.4 mg), lead chloride (83.5 mg), ( _R_ )- (+)-α-methylbenzylamine iodide (74.7 mg) and methylammonium iodide (187.7 mg) in _N_ , _N_ -dimethylformamide containing 10 vol% acetylacetone and stirred for 1 h at 55 °C. Then, ( _R_ )-(+)-α-methylbenzylamine iodide was synthesized from ( _R_ )-(+)-α-methylbenzylamine and hydroiodic acid and purified using diethyl ether (VWR) and absolute ethanol (Merck Millipore) using a procedure described previously<sup>42</sup> . Methylammonium iodide was synthesized using an analogous procedure. Afterwards, caesium iodide (~0.12 mmol, from 1.5 M stock solution in dimethyl sulfoxide) was added to the mixture and stirred overnight. The solution was filtered using polytetrafluoroethylene syringe filters (0.45 μm; Whatman) before spin coating. The perovskite solution was then deposited using an anti-solvent procedure inside the nitrogen glovebox. The solution was spin coated in two steps at 1,000 r.p.m. for 5 s with a ramp of 200 r.p.m. s<sup>−1</sup> followed by 4,000 r.p.m. for 25 s with a ramp of 2,000 r.p.m. s<sup>−1</sup> . Approximately 0.2 ml of chlorobenzene (anti-solvent) was dropped at the fifteenth second for about 3 s. Then, the film was annealed at 100 °C for 1 h. 

After the film cooled down to room temperature, the PCBM solution was spin coated onto the sample at 1,500 r.p.m. for 16 s (ramp, 2 s) followed by 2,000 r.p.m. for 15 s (ramp, 2 s). The PCBM solution was prepared by dissolving 2 wt% PCBM in chlorobenzene and chloroform (1:1 volume ratio). TiO _x_ sol–gel was prepared based on the procedure reported elsewhere<sup>42</sup> . TiO _x_ was spin coated at 4,000 r.p.m. for 30 s (ramp, 2 s) and annealed at 110 °C for about 5 min in an ambient atmosphere. Cr/Au contacts were evaporated at the rate of 0.01–0.50 nm s<sup>−1</sup> and a base pressure of 3 × 10<sup>−6</sup> mbar. Finally, the devices were encapsulated using ultraviolet-curable flexible epoxy and PVC/polychlorotrifluoroethylene protective films. The absorbance spectra were recorded using LAMBDA 1050 ultraviolet–visible spectrophotometer (PerkinElmer). The photoluminescence spectra were recorded on a photomultiplier-tube-equipped double-grating input and output fluorometer (Photon Technology International). 

The current density–voltage characteristics of solar cells under sunlight illumination were recorded under simulated AM1.5G spectrum irradiation from a 150 W xenon light source using a Keithley 2400 source meter and a custom LabView 2018 SP1 program. The intensity of the solar simulator was adjusted using a commercial Si reference diode (Si-01TC, Ingenieurbüro Mencke & Tegtmeyer). The performance of the solar cells under indoor lighting was tested using a set of commercial off-the-shelf warm-light LED light bulbs (Philips, 2,700 K, 4.3 W, 470 lm; Philips, 2,700 K, 7.0 W, 806 lm; Osram, 2,700 K, 21.0 W, 2,451 lm). The measurement was performed inside a light-tight black-cloth-covered characterization chamber with the cell tightly wrapped with black tape, allowing only the active area to be exposed to the light, thus reducing the influence of reflections or stray light. A broad range of intermediate illuminance levels were achieved by utilizing a set of neutral density filters placed directly on the device. The emission spectrum of the light bulbs was measured using a fibre spectrometer (Avantes, AvaSpec2048-USB2) (Supplementary Fig. 6). The illuminance of the LED light sources was measured using an ISO-calibrated lux meter (Voltcraft MS-1300). The spectral incident power intensity of the LED light bulbs was calculated as reported in the literature<sup>43</sup> . Additionally, the reference PCE under low-light conditions was calculated from the current density–voltage curve measured under a monochromatic light source (637 nm laser, Coherent OBIS 637 nm, 140 mW), with the incident power intensity calculated using a calibrated Si diode (Hamamatsu S2281). 

Surface scanning electron microscopy (SEM) measurements were performed using the ZEISS CrossBeam XB 1540 instrument 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**637** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

(acceleration voltage, 5 keV). A cross-section image was prepared by using a standard focused-ion-beam cutting approach. The images of the cross section were obtained under the same conditions as the surface SEM measurements. 

The maximum power point tracking was performed using an in-house-written Python 3.10.11 script utilizing a common perturb-and-observe algorithm. The starting voltage for the measurements was _V_ oc × FF, with a step size of 50 mV and 15 s waiting time between voltage perturbations. 

The Pb release test was performed using standard artificial sweat solution (containing sodium chloride (0.5% w/w), lactic acid (0.1% w/w) and urea (0.1% w/w) in DI water), as described in the European Standard EN 1811:1998. Encapsulated solar cell modules were immersed into 100 ml freshly prepared synthetic sweat buffer and placed at about 20 cm under a xenon lamp solar simulator with AM1.5G spectrum (distance adjusted to achieve approximately 1 sun illumination). The buffer was continuously stirred with a magnetic stirrer and 1 ml extracted samples were periodically collected and stored in the fridge at 4 °C until the next day when they were analysed using inductively coupled plasma–mass spectrometry. Alternatively, the Pb tests were also performed with just DI water, following the same procedure described above. 

Each inductively coupled plasma–mass spectrometry sample was extracted with 18.2 MΩ water. The extracts were measured without further dilution on an XSERIES 2 inductively coupled plasma–mass spectrometry instrument (Thermo Scientific) equipped with a Mira Mist nebulizer. The calibration was performed with a Certipur multielement standard solution XXI. 

###### **In vitro cell studies** 

Normal adult human dermal fibroblast cells (Lonza) were cultured in the manufacturer’s recommended media (FGM-2 growth media) under 37 °C and 5% CO2. The cells were then passaged at 80% confluency (passage number 5) and were used for all the cell studies. For in vitro cytocompatibility tests, two groups of FPSCs (before and after bending) were placed in the media during the course of the study to release the possible undesired toxic residuals. The human dermal fibroblast cells were seeded into 24-well plates (1 × 10<sup>5</sup> cells per well) and were treated with appropriate media and incubated under 37 °C and 5% CO2 for up to 7 days. For the control, the cells were treated with fresh media without contact with the FPSCs. The cell viability was evaluated by using a commercial calcein AM/ethidium homodimer-1 live/dead kit (Invitrogen) on days 1 and 7 post-culture. The samples were then visualized by using an Axio Observer inverted microscope (ZEISS) and cell viability was calculated using the ImageJ 1.44 software and reported as the ratio of live cells to the total number of cells (live + dead). A commercial PrestoBlue assay (Thermo Fisher) was also used to evaluate the cell metabolic activity according to the manufacturer’s protocol. 

###### **Electronic system design and characterization** 

The electronic system consists of four main blocks: power management, data processing and wireless communication, electrochemical instrumentation and iontophoretic induction (Supplementary Fig. 8). The power management block consists of an energy-harvesting PMIC (BQ25504, Texas Instruments) and a voltage regulator (ADP162, Analog Devices). The PMIC utilizes maximum point power tracking to efficiently boost charge the solar cell output of 5 V and charge the 5 mF energy storage capacitor. The threshold control unit of the PMIC enables the capacitor to power the rest of the system, whereas the capacitor voltage stays within a threshold voltage between ~3 and 5 V. The voltage regulator then regulates the capacitor voltage to a stable 2.8 V to supply the data processing, wireless communication and electrochemical instrumentation blocks. 

Data processing and wireless communication are performed by a compact PSoC BLE module (CYBLE-222014, Cypress Semiconductor) 

that integrates an MCU and BLE radio, and electrochemical instrumentation is emulated by an electrochemical front end (AD5941, Analog Devices) and voltage buffers (MAX40018, Analog Devices) that integrate various configurable blocks necessary for electrochemical detection. The PSoC BLE module communicates with the host software via BLE and controls the electrochemical AFE via the serial peripheral interface. The electrochemical AFE is the core of the platform. The electrochemical AFE’s configurable amplifiers can be configured for various electrochemical measurements at multiple modes of measurement ranges and resolutions. For high-bandwidth impedance measurements, the high-speed loop can be configured, and for lower-bandwidth measurements such as potentiometry, amperometry and voltammetry, the low-power loop can be configured. The AFE contains multiple elements such as a sequencer, memory block, waveform generator and density functional theory hardware accelerator that enables the independent operation of complex electrochemical procedures, thereby minimizing the workload of the MCU and the overall power consumption. Furthermore, a switch matrix and multiplexer flexibly connect the sensors and analogue signals to the appropriate channels. 

The iontophoresis induction block generates a high-compliancevoltage constant current with current monitoring to safely deliver current across the skin through a gel. A boost converter (TPS61096, Texas Instruments) boosts the voltage of the energy storage capacitor from the PMIC to a high compliance voltage, and a bipolar junction transistor array (BCV62C, Nexperia) is configured as a current mirror to supply a steady current through the analogue switch (DG468, Vishay Intertechnology) as the iontophoresis block is actuated. Furthermore, the electrochemical AFE’s switch matrix enables the iontophoresis block to flexibly connect to the electrochemical AFE’s low-power current measurement channel for iontophoresis current monitoring overcurrent protection during iontophoresis. 

The wearable device was powered by a custom-developed quasi-2D FPSC in most experiments. The power consumption of the system was characterized using a power profiler (PPK2, Nordic Semiconductor), and the energy storage capacitor’s charging–discharging curves were collected using an electrochemical workstation (CHI660E). For experiments under bright to room-light illumination conditions (>400 lx), a custom-developed quasi-2D FPSC was used to power the wearable device; for experiments under dim-light illumination conditions (<300 lx), a commercial flexible solar cell was used (LL200-2.4-75, PowerFilm). To validate the performance of the wearable device for electrochemical measurements, we compared the potentiometric, amperometric and voltammetric responses collected by the wearable device under lab-light mode with those collected by an electrochemical workstation (CHI660E). 

###### **Microfluidic sensor patch fabrication and assembly** 

The polyimide (PI) substrates were cleaned before inkjet printing via O2 plasma surface treatment (Plasma Etch PE-25, 10–20 cm<sup>3</sup> min<sup>−1</sup> O2, 100 W, 150–200 mtorr) to remove debris and improve surface hydrophilicity. Next, an inkjet printer (DMP-2850, Fujifilm) was used for the sequential printing of silver (interconnects and connection pads, interdigitated sweat rate sensor and reference electrode), carbon (iontophoresis, counter and working electrodes) and PI (encapsulation). The reference and working electrodes were further modified via electrochemical deposition (CHI660E) and drop-casting methods for selective electrochemical sensing. Meanwhile, a 50 W CO2 laser cutter (Universal Laser System) was used to pattern M-tape (3M 468MP) and PET layers to be further assembled onto the sensor patch for microfluidic sweat processing. A _Z_ -axis conductive tape (3M 9703) was used to electrically connect the encapsulated printed circuit boards, solar cells and microfluidic sensor patch through the connection pads and interconnects printed on the PI substrate. 

Both anode and cathode carbagels were prepared by heating DI water containing 3% w/w agarose to 250 °C under constant stirring until 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**638** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

the mixture became homogeneous. After cooling down the mixture to 165 °C, 1% w/w carbachol was added to the anode mixture, and 1% w/w KCl was added to the cathode mixture. Then, the mixtures were poured into the assembled microfluidic sensor patches’ carbagel cutouts, where the hydrogels solidified. 

###### **Biosensor preparation and characterization** 

An electrochemical workstation (CHI660E) was used for electrochemical deposition, and both electrochemical workstation and wearable device were used for sensor characterization. 

**Reference electrode.** To form Ag/AgCl, 0.1 M iron (iii) chloride was drop casted onto the inkjet-printed Ag reference electrode for 30 s. A PVB reference cocktail was prepared by dissolving 79.1 mg PVB, 50.0 mg NaCl, 1.0 mg F127 and 0.2 mg multiwalled carbon nanotubes into 1 ml methanol. Then, 1.66 μl of the PVB reference cocktail was drop casted onto the Ag/AgCl reference electrode and left to dry overnight such that the reference electrode could maintain a steady potential regardless of the ionic strength of the solution. 

**Glucose sensor.** Au nanodendrites were modified on a carbon working electrode by applying a pulsed voltage from −0.9 to 0.9 V at a frequency of 50 Hz in a solution containing 50 mM tetrachloroauric acid and 50 mM HCl. A Prussian blue layer was electrochemically deposited on the modified working electrode by performing cyclic voltammetry from −0.2 to 0.6 V at a scan rate of 50 mV s<sup>−1</sup> for 20 cycles in a solution containing 2.0 mM iron (iii) chloride, 2.5 mM K3[Fe(CN)6], 0.1 M KCl and 0.1 M HCl. Then, the electrode was further modified by performing cyclic voltammetry from 0 to 0.8 V at a scan rate of 100 mV s<sup>−1</sup> for 8 cycles in a solution containing 5.0 mM nickel chloride, 2.5 mM K3[Fe(CN)6], 0.1 M KCl and 0.1 M HCl. A glucose oxidase enzyme cocktail was prepared by mixing 99.00 μl of 1.0% bovine serum albumin, 1.00 μl of 2.5% glutaraldehyde and 0.25 μl of 10 mg ml<sup>–1</sup> glucose oxidase. Then, 1.66 μl of the enzyme cocktail was drop casted onto the modified working electrode and left overnight to dry. 

**Na**<sup>**+**</sup> **sensor.** A carbon working electrode was modified in a solution containing 30.0 mg K4[Fe(CN)6] 3H2O, 206.1 mg NaPSS and 10.7 μl 3,4-ethylenedioxythiophene in 10 ml DI water by applying a constant potential of 0.865 V for 10 min. A Na<sup>+</sup> -selective membrane cocktail was prepared by dissolving 1.00 mg of Na ionophore X, 0.55 mg sodium tetrakis[3,5-bis(trifluoromethyl)phenyl] borate, 33.00 mg PVC and 65.45 mg bis(2-ethylehexyl) sebacate into 660 μl tetrahydrofuran. Then, 1.66 μl of the Na<sup>+</sup> -selective membrane cocktail was drop casted onto the modified carbon working electrode and left to dry overnight. 

**pH sensor.** Au was deposited on a carbon working electrode by applying a constant potential of 0 V for 30 s in a solution containing 50 mM tetrachloroauric acid and 50 mM HCl. A polyaniline layer was electropolymerized on the Au-modified working electrode by performing cyclic voltammetry from −0.2 to 1.0 V at a scan rate of 50 mV s<sup>−1</sup> for 50 cycles. 

**Biosensor characterization.** For in vitro characterizations for the Na<sup>+</sup> and sweat rate sensors, NaCl solutions (12.5–200.0 mM) were prepared in DI water. For characterization of the pH sensors, McIlvaine buffers with pH values ranging from 4 to 8, and HCl-mediated McIlvaine buffer with a pH of 10 were used. For characterization of the glucose sensors, glucose solutions (0–200 μM) were prepared in PBS buffer with pH ranging from 4 to 10. For the characterization of the sensors’ dependence on temperature, a ceramic hot plate (Thermo Fisher Scientific) was used. For in vitro flow tests, a syringe pump (78-01001, Thermo Fisher Scientific) was used to inject various fluids through the microfluidic sensor patch at different flow rates (0.12–3.00 μl min<sup>−1</sup> ). 

###### **On-body evaluation of the wearable device** 

The validation and evaluation of the wearable device were performed using human subjects in compliance with the ethical regulations under different protocols (ID 19-0892 and 21-1079) that were approved by the Institutional Review Board at the California Institute of Technology. The participating subjects between ages of 18 and 65 years were recruited from the California Institute of Technology campus and neighbouring communities through advertisement by posted notices, word of mouth and email distribution. All the subjects gave written informed consent before participation in the study. For all the human studies, the subjects cleaned their skin with water and alcohol swabs before applying the wearable device on the skin. 

**System evaluation conditions.** For chemical sweat induction, the subjects were illuminated under bright-light conditions for 10 min to enable light-powered iontophoresis (55 μA, 10 min). Following iontophoretic stimulation, the subjects were illuminated under either bright-light (14,000 lx), lab-light (1,200 lx) or room-light (600 lx) illumination conditions to enable continuous biomarker detection for the remainder of the study. The sweat rate was periodically measured either with the impedimetric sweat rate sensor, visually or both. 

**System evaluation with sugar intake.** For fasting and intake studies, the subjects reported to the lab after fasting overnight. For the iontophoresis-based studies, the wearable device was applied to the ventral forearm region and the subject was illuminated under bright-light (14,000 lx) conditions for the first 10 min to power iontophoresis. For the remainder of the study, the subject was illuminated under lab-light (1,200 lx) conditions at rest, whereas the wearable device performed wireless multimodal monitoring of sweat biomarkers with multiplexed glucose, pH, Na<sup>+</sup> and temperature measurements occurring at 8 s intervals and sweat rate measurements occurring at 5 min intervals. The data were wirelessly transmitted in real time via BLE indications. For the iontophoresis intake study, the subject was provided a soft drink containing 55 g of sugar. For the exercise-based studies, the wearable device was applied to the forehead region, and the subject was illuminated under lab-light (1,200 lx) conditions throughout the study, where the subjects performed constant-load cycling (50 r.p.m.) on a stationary exercise bike (KETTLER AXOS CYCLE M-LA) for 60 min. For the exercise intake study, the subject was provided a soft drink containing 55 g sugar. 

**System evaluation during daily activities.** For the full-day study spanning from 9 a.m. to 9 p.m., the subject was iontophoretically stimulated via the wearable device for 10 min at 9 a.m., 12 p.m., 3 p.m. and 6 p.m. The microfluidics were reset before each iontophoresis section to obtain continuous sweat rate reading. From 9 a.m. to 1 p.m., the subject was outdoors under the sun (100,000 lx); from 1 p.m. to 6 p.m., the subject was under lab-light (1,200 lx) conditions; and from 6 p.m. to 9 p.m., the subject was in room-light (600 lx) conditions. From 9 a.m. to 6 p.m., the wearable device performed multiplexed glucose, pH, Na<sup>+</sup> and temperature measurements occurring at 8 s intervals and sweat rate measurements occurring at 5 min intervals. The data were wirelessly transmitted via BLE indications. From 6 p.m. to 9 p.m., the wearable device performed multiplexed glucose, pH, Na<sup>+</sup> and temperature measurements occurring at 60 s intervals and transmitted the data wirelessly via BLE advertisements, whereas the sweat rate was optically evaluated every 10 min. 

###### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

###### **Data availability** 

All the raw and analysed datasets generated during the study are available from the corresponding authors on request. Source data are provided with this paper. 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**639** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

###### **References** 

1. Kim, J., Campbell, A. S., de Ávila, B. E.-F. & Wang, J. Wearable biosensors for healthcare monitoring. _Nat. Biotechnol._ **37** , 389–406 (2019). 

2. Ray, T. R. et al. Bio-integrated wearable systems: a comprehensive review. _Chem. Rev._ **119** , 5461–5533 (2019). 

3. Yang, Y. & Gao, W. Wearable and flexible electronics for continuous molecular monitoring. _Chem. Soc. Rev._ **48** , 1465–1491 (2019). 

4. Heikenfeld, J. et al. Accessing analytes in biofluids for peripheral biochemical monitoring. _Nat. Biotechnol._ **37** , 407–419 (2019). 

5. Libanori, A., Chen, G., Zhao, X., Zhou, Y. & Chen, J. Smart textiles for personalized healthcare. _Nat. Electron._ **5** , 142–156 (2022). 

6. Someya, T., Bao, Z. & Malliaras, G. G. The rise of plastic bioelectronics. _Nature_ **540** , 379–385 (2016). 

7. Bariya, M., Nyein, H. Y. Y. & Javey, A. Wearable sweat sensors. _Nat. Electron._ **1** , 160–171 (2018). 

8. Gao, W. et al. Fully integrated wearable sensor arrays for multiplexed in situ perspiration analysis. _Nature_ **529** , 509–514 (2016). 

9. Choi, J., Ghaffari, R., Baker, L. B. & Rogers, J. A. Skin-interfaced systems for sweat collection and analytics. _Sci. Adv._ **4** , eaar3921 (2018). 

10. Bandodkar, A. J. et al. Battery-free, skin-interfaced microfluidic/ electronic systems for simultaneous electrochemical, colorimetric, and volumetric analysis of sweat. _Sci. Adv._ **5** , eaav3294 (2019). 

11. Nyein, H. Y. Y. et al. Regional and correlative sweat analysis using high-throughput microfluidic sensing patches toward decoding sweat. _Sci. Adv._ **5** , eaaw9906 (2019). 

12. Kim, S. et al. Soft, skin-interfaced microfluidic systems with integrated immunoassays, fluorometric sensors, and impedance measurement capabilities. _Proc. Natl Acad. Sci. USA_ **117** , 27906–27915 (2020). 

13. Son, D. et al. Multifunctional wearable devices for diagnosis and therapy of movement disorders. _Nat. Nanotechnol._ **9** , 397–404 (2014). 

14. Niu, S. et al. A wireless body area sensor network based on stretchable passive tags. _Nat. Electron._ **2** , 361–368 (2019). 

15. Sempionatto, J. R. et al. An epidermal patch for the simultaneous monitoring of haemodynamic and metabolic biomarkers. _Nat. Biomed. Eng._ **5** , 737–748 (2021). 

16. Emaminejad, S. et al. Autonomous sweat extraction and analysis applied to cystic fibrosis and glucose monitoring using a fully integrated wearable platform. _Proc. Natl Acad. Sci. USA_ **114** , 4625–4630 (2017). 

17. Lee, H. et al. Wearable/disposable sweat-based glucose monitoring device with multistage transdermal drug delivery module. _Sci. Adv._ **3** , e1601314 (2017). 

18. Yang, Y. et al. A laser-engraved wearable sensor for sensitive detection of uric acid and tyrosine in sweat. _Nat. Biotechnol._ **38** , 217–224 (2020). 

19. Torrente-Rodríguez, R. M. et al. Investigation of cortisol dynamics in human sweat using a graphene-based wireless mHealth system. _Matter_ **2** , 921–937 (2020). 

20. Kwon, K. et al. An on-skin platform for wireless monitoring of flow rate, cumulative loss and temperature of sweat in real time. _Nat. Electron._ **4** , 302–312 (2021). 

21. Sonner, Z., Wilder, E., Gaillard, T., Kasting, G. & Heikenfeld, J. Integrated sudomotor axon reflex sweat stimulation for continuous sweat analyte analysis with individuals at rest. _Lab Chip_ **17** , 2550–2560 (2017). 

22. Simmers, P., Li, S. K., Kasting, G. & Heikenfeld, J. Prolonged and localized sweat stimulation by iontophoretic delivery of the slowly-metabolized cholinergic agent carbachol. _J. Dermatol. Sci._ **89** , 40–51 (2018). 

23. Yu, Y. et al. Biofuel-powered soft electronic skin with multiplexed and wireless sensing for human-machine interfaces. _Sci. Robot._ **5** , eaaz7946 (2020). 

24. Song, Y. et al. Wireless battery-free wearable sweat sensor powered by human motion. _Sci. Adv._ **6** , eaay9842 (2020). 

25. Yin, L. et al. A passive perspiration biofuel cell: high energy return on investment. _Joule_ **5** , 1888–1904 (2021). 

26. Yin, L. et al. A self-sustainable wearable multi-modular E-textile bioenergy microgrid system. _Nat. Commun._ **12** , 1542 (2021). 

27. Xu, F. et al. Scalable fabrication of stretchable and washable textile triboelectric nanogenerators as constant power sources for wearable electronics. _Nano Energy_ **88** , 106247 (2021). 

28. Park, S. et al. Self-powered ultra-flexible electronics via nano-grating-patterned organic photovoltaics. _Nature_ **561** , 516–521 (2018). 

29. Meng, K. et al. A wireless textile-based sensor system for self-powered personalized health care. _Matter_ **2** , 896–907 (2020). 

30. Polyzoidis, C., Rogdakis, K. & Kymakis, E. Indoor perovskite photovoltaics for the internet of things—challenges and opportunities toward market uptake. _Adv. Energy Mater._ **11** , 2101854 (2021). 

31. Mathews, I., King, P. J., Stafford, F. & Frizzell, R. Performance of III–V solar cells as indoor light energy harvesters. _IEEE J. Photovolt._ **6** , 230–235 (2016). 

32. Espinosa, N., Hösel, M., Angmo, D. & Krebs, F. C. Solar cells with one-day energy payback for the factories of the future. _Energy Environ. Sci._ **5** , 5117–5132 (2012). 

33. Roy, P., Kumar Sinha, N., Tiwari, S. & Khare, A. A review on perovskite solar cells: evolution of architecture, fabrication techniques, commercialization issues and status. _Sol. Energy_ **198** , 665–688 (2020). 

34. Gao, F., Zhao, Y., Zhang, X. & You, J. Recent progresses on defect passivation toward efficient perovskite solar cells. _Adv. Energy Mater._ **10** , 1902650 (2020). 

35. Green, M. A. et al. Solar cell efficiency tables (version 58). _Prog. Photovolt. Res. Appl._ **29** , 657–667 (2021). 

36. Zheng, H. et al. Emerging organic/hybrid photovoltaic cells for indoor applications: recent advances and perspectives. _Sol. RRL_ **5** , 2100042 (2021). 

37. Hashemi, S. A., Ramakrishna, S. & Aberle, A. G. Recent progress in flexible–wearable solar cells for self-powered electronic devices. _Energy Environ. Sci._ **13** , 685–743 (2020). 

38. Zhao, J. et al. A fully integrated and self-powered smartwatch for continuous sweat glucose monitoring. _ACS Sens._ **4** , 1925–1933 (2019). 

39. Mallick, A. & Visoly-Fisher, I. Pb in halide perovskites for photovoltaics: reasons for optimism. _Mater. Adv._ **2** , 6125–6135 (2021). 

40. Hamann, D. et al. Jewellery: alloy composition and release of nickel, cobalt and lead assessed with the EU synthetic sweat method. _Contact Derm._ **73** , 231–238 (2015). 

41. World Health Organization. Regional Office for Europe (2000). Air quality guidelines for Europe, 2nd ed. World Health Organization. Regional Office for Europe; https://apps.who.int/iris/ handle/10665/107335 

42. Hailegnaw, B. et al. Inverted (p–i–n) perovskite solar cells using a low temperature processed TiO _x_ interlayer. _RSC Adv._ **8** , 24836–24846 (2018). 

43. Venkateswararao, A., Ho, J. K. W., So, S. K., Liu, S.-W. & Wong, K.-T. Device characteristics and material developments of indoor photovoltaic devices. _Mater. Sci. Eng. R Rep._ **139** , 100517 (2020). 

###### **Acknowledgements** 

This project was supported by the National Institutes of Health grants R01HL155815 and R21DK13266, Office of Naval Research grants 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**640** 

**Article** 

https://doi.org/10.1038/s41928-023-00996-y 

N00014-21-1-2483 and N00014-21-1-2845, the Translational Research Institute for Space Health through NASA NNX16AO69A, National Science Foundation grant 2145802 (to W.G.) and the European Research Council Starting Grant ‘GEL-SYS’ under grant agreement no. 757931 (to M.K.). S.D. would like to acknowledge the Marshall Plan Foundation that provided financial support for the three months of research visit to California Institute of Technology that initiated this work. 

###### **Author contributions** 

W.G., J.M., M.K. and S.D. initiated the concept and designed the studies. J.M. and S.D. led the experiments and collected the overall data. J.R.S., Y.S., B.H., C.X., Y.Y. and S.S. contributed to the wearable device characterization, validation and sample analysis. B.H., C.P., L.L., M.S. and S.S. contributed to the solar module development, fabrication and characterization. S.D., B.H., J.F.S. and C.S. contributed to the experimental design and characterization of Pb leakage test for the solar cell module. E.S.S. contributed to the cell viability and metabolic activity characterization. J.M., S.D., W.G. and M.K. co-wrote the paper. All authors contributed to the data analysis and provided feedback on the manuscript. 

###### **Competing interests** 

The authors declare no competing interests. 

###### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41928-023-00996-y. 

**Correspondence and requests for materials** should be addressed to Martin Kaltenbrunner or Wei Gao. 

**Peer review information** _Nature Electronics_ thanks Roozbeh Ghaffari, Norbert Radacsi and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

Nature Electronics | Volume 6 | August 2023 | 630–641 

**641** 

Corresponding author(s): Wei Gao 

Last updated by author(s): May 26, 2023 



## <u>Reporting Summary</u> 

Nature Research wishes to improve the reproducibility of the work that we publish. This form provides structure for consistency and transparency in reporting. For further information on Nature Research policies, see our <u>Editorial Policies</u> and the <u>Editorial Policy Checklist.</u> 

##### <u>Statistics</u> 

For all statistical analyses, confirm that the following items are present in the figure legend, table legend, main text, or Methods section. 

- n/a Confirmed 

The exact sample size ( _n_ ) for each experimental group/condition, given as a discrete number and unit of measurement 

A statement on whether measurements were taken from distinct samples or whether the same sample was measured repeatedly 

- The statistical test(s) used AND whether they are one- or two-sided 

_Only common tests should be described solely by name; describe more complex techniques in the Methods section._ 

A description of all covariates tested 

A description of any assumptions or corrections, such as tests of normality and adjustment for multiple comparisons 

- A full description of the statistical parameters including central tendency (e.g. means) or other basic estimates (e.g. regression coefficient) AND variation (e.g. standard deviation) or associated estimates of uncertainty (e.g. confidence intervals) 

For null hypothesis testing, the test statistic (e.g. _F_ , _t_ , _r_ ) with confidence intervals, effect sizes, degrees of freedom and _P_ value noted _Give P values as exact values whenever suitable._ 

For Bayesian analysis, information on the choice of priors and Markov chain Monte Carlo settings 

For hierarchical and complex designs, identification of the appropriate level for tests and full reporting of outcomes 

- Estimates of effect sizes (e.g. Cohen's _d_ , Pearson's _r_ ), indicating how they were calculated 

_Our web collection on_ _<u>statistics for biologists</u> contains articles on many of the points above._ 

##### <u>Software and code</u> 

###### Policy information about <u>availability of computer code</u> 

Data collection PSoC Creator 4.3 was used to program the microcontroller. Flutter was used to program the mobile application. CH Instrument was used for off-body sensor data collection. 

Data analysis Python 3.9 was used to analyze all data, plot the data and calculate the statistical parameters. 

For manuscripts utilizing custom algorithms or software that are central to the research but not yet described in published literature, software must be made available to editors and reviewers. We strongly encourage code deposition in a community repository (e.g. GitHub). See the Nature Research <u>guidelines for submitting code & software</u> for further information. 

##### <u>Data</u> 

###### Policy information about <u>availability of data</u> 

All manuscripts must include a <u>data availability statement. This statement should provide the following information, where applicable:</u> 

- Accession codes, unique identifiers, or web links for publicly available datasets 

- A list of figures that have associated raw data 

- A description of any restrictions on data availability 

The data that support the plots within this paper and other findings of this study are available from the corresponding author upon request. 

1 

### <u>Field-specific reporting</u> 

Please select the one below that is the best fit for your research. If you are not sure, read the appropriate sections before making your selection. Life sciences Behavioural & social sciences Ecological, evolutionary & environmental sciences 

Behavioural & social sciences Ecological, evolutionary & environmental sciences 

For a reference copy of the document with all sections, see <u>nature.com/documents/nr-reporting-summary-flat.pdf</u> 

### <u>Life sciences study design</u> 

All studies must disclose on these points even when the disclosure is negative. 

Sample size For on body evaluation of the complete wearable sensor patch, 5 healthy subjects were recruited. For on body validation of the iontophoresis and sweat rate monitoring system, 6 healthy subjects were recruited. For studying the relationship between the sweat induction location/ method and sweat pH, 5 subjects were recruited. Data exclusions No data exclusion. Replication All attempts at replication were successful when following the device fabrication process described in the paper. Randomization The device was fabricated with same process and was tested in all participants under same conditions. Randomization was therefore not relevant to the study. Blinding Not relevant, because a blinding process wouldn't influence the sampling result. 

### <u>Reporting for specific materials, systems and methods</u> 

We require information from authors about some types of materials, experimental systems and methods used in many studies. Here, indicate whether each material, system or method listed is relevant to your study. If you are not sure if a list item applies to your research, read the appropriate section before selecting a response. 

|Materials & experimental systems|Methods|
|---|---|
|n/a<br>Involved in the study|n/a<br>Involved in the study|
|Antibodies|ChIP-seq|
|Eukaryotic cell lines|Flow cytometry|
|Palaeontology and archaeology|MRI-based neuroimaging|
|Animals and other organisms||
|Human research participants||
|Clinical data||
|Dual use research of concern||



##### <u>Human research participants</u> 

Policy information about <u>studies involving human research participants</u> 

|Population characteristics|Normal weight healthy individuals with a body mass index (BMI) of 18.5 to 24.9 kg m-2 with fasting serum glucose <100 mg<br>dL-1 (Healthy)|
|---|---|
|Recruitment|The participating subjects were recruited from Caltech campus and the neighboring communities through advertisement by<br>posted notices, word of mouth, and email distribution.  There were no self-selection biases or other biases.|
|Ethics oversight|California Institute of Technology|



Note that full information on the approval of the study protocol must also be provided in the manuscript. 

2 

