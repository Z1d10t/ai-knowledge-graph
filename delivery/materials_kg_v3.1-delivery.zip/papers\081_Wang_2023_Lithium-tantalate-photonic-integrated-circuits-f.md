# Lithium tantalate photonic integrated circuits for volume manufacturing

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 252 |
| 作者 | Cheng-Li Wang, Zi-Han Li, J. Riemensberger, G. Lihachev, M. Churaev, Wil Kao, Xin-Ru Ji, Jun-Yin Zhang et al. |
| DOI | 10.1038/s41586-024-07369-1 |
| 源文件 | 081_Wang_2023_Lithium-tantalate-photonic-integrated-circuits-f.pdf |

---
# **Lithium tantalate electro-optical photonic integrated circuits for high volume manufacturing** 

Chengli Wang,<sup>1, 2, 3, 4</sup> Zihan Li,<sup>2, 3, 4</sup> Johann Riemensberger,<sup>2, 3</sup> Grigory Lihachev,<sup>2, 3</sup> Mikhail Churaev,<sup>2, 3</sup> Wil Kao,<sup>2, 3</sup> Xinru Ji,<sup>2, 3</sup> Terence Blesin,<sup>2, 3</sup> Alisa Davydova,<sup>2, 3</sup> Yang Chen,<sup>1</sup> Kai Huang,<sup>1</sup> Xi Wang,<sup>1</sup> Xin Ou,<sup>1,</sup><sup>_∗_</sup> and Tobias J. Kippenberg<sup>2, 3,</sup><sup>_†_</sup> 

> 1 _National Key Laboratory of Materials for Integrated Circuits, Shanghai Institute of Microsystem and Information Technology, Chinese Academy of Sciences, 200050 Shanghai, China_ 

> 2 _Institute of Physics, Swiss Federal Institute of Technology Lausanne (EPFL), CH-1015 Lausanne, Switzerland_ 

> 3 _Center of Quantum Science and Engineering (EPFL), CH-1015 Lausanne, Switzerland_ 

> 4 _These authors contributed equally to this work._ 

### **Abstract** 

**Electro-optical photonic integrated circuits based on Lithium Niobate have demonstrated the vast capabilities afforded by material with a high Pockels coefficient [1, 2], allowing linear and high-speed modulators operating at CMOS voltage levels [3] for applications ranging from data-center communications [4], high-performance computing to photonic accelerators for AI [5]. However despite major progress, the industrial adoption of this technology is compounded by the high cost per wafer, and limited wafer size – that result from the lack of existing high-volume applications in other domains, as is evidenced in the rapid adoption of silicon-on-insulator photonics driven by the vast investments into microelectronics. Here we overcome this challenge and demonstrate a photonic platform that satisfies the dichotomy of allowing scalable manufacturing at low cost – based on today’s existing infrastructure – while at the same time exhibiting equal, and superior properties to those of Lithium Niobate. We demonstrate that it is possible to manufacture low loss photonic integrated circuits using Lithium Tantalate (** LiTaO3 **), a material that is already commercially adopted for acoustic filters in 5G and 6G [6]. We show that** LiTaO3 **posses equally attractive optical properties and can be etched with high precision and negligible residues using DUV lithography, diamond like carbon (DLC) as a hard mask [7] and alkaline wet etching. Using this approach we demonstrate microresonators with an intrinsic cavity linewidth of** 26 _._ 8 MHz **, corresponding to a linear loss of** 5 _._ 6 dB m<sup>_−_1</sup> **and demonstrate a Mach Zehnder modulator with** _VπL_ = 4 _._ 2 **V cm half-wave voltage length product. In comparison to Lithium Niobate, the photonic integrated circuits based on** LiTaO3 **exhibit a much lower birefringence, allowing high-density circuits and broadband operation over all telecommunication bands (O to L band), exhibit higher photorefractive damage threshold, and lower microwave loss tangent. Moreover, we show that the platform supports generation of soliton microcombs in X-Cut** LiTaO3 **racetrack microresonator with electronically detectable repetition** 

> _∗_ ouxin@mail.sim.ac.cn 

> _†_ tobias.kippenberg@epfl.ch 

**rate, i.e.** 30 _._ 1 GHz **. Our work paves the way for scalable manufacturing of low-cost and large-volume highperformance electro-optical photonic integrated circuits for next-generation ultra high-speed modulators and devices for energy-efficient communication, computation or interconnects.** 

### **INTRODUCTION** 

Next-generation ultra-high-speed photonic integrated circuits (PICs) based on electro-optical materials are poised to play a role in energy-efficient data centers, optical communications, 5G/6G, or high-performance computing – granted that scalable low-cost manufacturing becomes possible. In the past two decades, photonic integrated circuits based on silicon (silicon photonics) have rapidly transitioned from academic research to widespread use in telecommunications [8] and data centers [9]. One crucial factor driving the commercial feasibility of this technological revolution is the high-volume availability and cost-effectiveness of silicon-on-insulator (SOI) wafers. These SOI wafers, prepared using the ’smart-cut’, i.e. ion slicing techniques [10], enable the manufacturing of silicon photonic integrated circuits but crucially have a significantly larger magnitude of usage in consumer microelectronics. Today, globally more than 3 million wafers are produced per year in SOI, as large as 300 mm in diameter [8]. Using the similar technique lithium niobate (LiNbO3) has been fabricated into lithium niobate on insulator (LNOI) structures, offering an entirely new class of ultra high-speed, low voltage electro-optical photonic integrated circuits [11–13] that can become key components in future energy-efficient communication systems. Despite the tremendous scientific progress and the increased application range of LiNbO3 photonic integrated circuits, the path to commercialization remains challenging, and commercial products do not exist to date. Unlike SOI technology, LNOI lacks a larger volume of consumer electronics driving its demand, resulting in economic limitations in its commercialization. In comparison, another ferroelectric material, lithium tantalate, which shares similar structural properties with LiNbO3, has entered a large-volume production stage driven by its applications in 5G filters [14, 15] and is projected to achieve a production capacity of 750k LTOI wafers per year by 2024 [16]. The substantial volume enables significant benefits in terms of low-cost production when adopting LTOI as a platform for photonic integrated cir- 

2 

cuits - yet photonic integrated circuits based on this material have never been demonstrated to date. LiTaO3, in addition to the advantage in production volume, exhibits comparable or superior properties to LiNbO3. LiTaO3 is a traditional ferroelectric crystal with a nearly identical crystal structure as LiNbO3 replacing Nb atoms in the crystal structure with heavier Ta atoms (cf. Figure 1(a)). The stronger chemical bonds induce a higher electron density in LiTaO3 [17], which makes LiTaO3 exhibit not only higher density but also increased stiffness and chemical stability. The optical bandgap of LiTaO3 (3.93 eV) is larger than LiNbO3 (3.63 eV) [18], allowing e.g. nonlinear optical conversion to the visible and even ultraviolet [19] wavelength range, with much decreased optical anisotropy, i.e. one order of magnitude reduced optical birefringence compared to LiNbO3. The latter is particularly important as it allows manufacturing of tightly confining waveguides with strong bends without mode mixing, that can operate across all telecommunication bands simultaneously (from O to L band). Moreover, LiTaO3 features a comparable Pockels coefficient ( _r_ 33 = 30 _._ 5 pm V<sup>_−_1</sup> ) to the well-established LiNbO3 with a moderately larger electrical permittivity _ϵ_ 33 = 43. In particular relevant for applications in the realm of microwave quantum transduction [20] the much lower microwave loss tangent of LiTaO3 is a promising avenue to improve device performance to unity conversion efficiency, which has so far eluded efforts in LiNbO3 due to limited quality factors of microwave resonators [21]. Historically, despite the beneficial optical material properties, the use of LiTaO3 for photonic devices in optical communication networks or scientific research has been limited. One of the reasons is that the Curie temperature of LiTaO3 (610<sup>_◦_</sup> C - 700<sup>_◦_</sup> C) is much lower than the temperatures needed for the fabrication of optical waveguides by ion diffusion (typically above 1000<sup>_◦_</sup> C), which compounded the use of LiTaO3 for bulk modulators based on ion diffused waveguide [22]. For this reason, legacy bulk modulator technology has employed LiNbO3. Given the commercial adoption of LTOI in wireless applications due to its suitable acoustic properties, combined with the above optical properties, make it an ideal platform for scalable manufactured electro-optical photonic integrated circuits - yet the latter has to date never been demonstrated nor pursued. Although free standing whispering gallery mode resonators have been fabricated from LiTaO3 single crystals [23], that utilize femtosecond laser direct writing [24] or focused ion beam milling [25], scalable manufactured photonic integrated circuits have remained an outstanding challenge. 

Here, we overcome this challenge and implement the first photonic integrated circuit platform using LiTaO3-oninsulator platform based on the direct etching [7] and demonstrate ultra-low optical loss, electro-optical tuning, switching via the Pockels effect, and soliton microcomb generation via the optical Kerr effect of LiTaO3. We achieve this by transferring the DLC-based masking, etching process originally developed for LiNbO3 to LiTaO3 and proposing a new solution to remove LiTaO3 redeposition, which highlights the flexibility of our process for the fabrication of a variety of ferroelectric photonics platforms. Equally, we demonstrate a DUV approach to electrode manufacturing. Taken together our work 

establishes a basis for scalable volume manufacturing of ultrahigh speed electro-optical photonic integrated circuits. 

### **LOW LOSS LITHIUM TANTALATE-BASED PHOTONIC INTEGRATED CIRCUITS** 

The fabrication process for LTOI wafers and optical waveguides is depicted in Figure 1 and closely resembles recent efforts for LNOI [7]. We fabricated devices such as optical ring resonators (cf. Figure 1(b)), racetrack resonators, and waveguide spirals (cf. Supplementary Figure 3). Figures 1 (b,c) show the etched waveguide sidewalls and cleaved cross-section featuring low sidewall roughness and steep sidewall angles close to 70<sup>_◦_</sup> with respect to the surface. The LTOI wafer was fabricated by the smart-cut technique [15]. The process flow is schematically illustrated in Figure 1(f). In contrast to the well-established LNOI preparation process that utilizes helium ion implantation, hydrogen ions are preferred for the fabrication of LTOI. The fabrication recipes of LTOI are more closely aligned with the high-volume commercial production of SOI wafers, resulting in higher efficiency and lower costs in the production of LTOI compared to LNOI. We implanted the hydrogen ion into an X-Cut bulk LiTaO3 wafer with an energy of 100 keV and a dose of 3 _._ 2 _×_ 10<sup>16</sup> /cm<sup>2</sup> . After that, we flipped the implanted wafer and bonded it to a blank 525 µm thick high resistivity silicon carrier wafer covered with 2 µm thermal silicon dioxide followed by a thermal annealing step to separate the residual bulk wafer and the smart-cut LiTaO3 thin film. We perform edge removal of the LiTaO3 thin film and chemical mechanical polishing to remove the rough and defect-rich layer of LiTaO3 that was strongly affected by H-ion implantation and thin the LiTaO3 film to the desired thickness of 600 nm. After chemical-mechanical polishing, the surface roughness is decreased to 0 _._ 25 nm and the non-uniformity is less than 30 nm over the full wafer and less than 10 nm in the center area (cf. Figure 1(h)). LTOI wafers with good uniformity and smooth surface roughness are the prerequisites for highyield and low-loss PICs. The crystallinity of LiTaO3 and the LiTaO3-SiO2 interface remain of high quality after the completion of the whole process, as well as the sharpness of the bonding interface, as is visible from the high-resolution scanning transmission electron microscopy (HRSTEM) image (cf. Figure 1(j)). 

We fabricate LiTaO3 photonic integrated circuits based on the process we recently demonstrated for deeply etched and tightly confining LNOI PICs [7]. First, we deposit a 30 nm thick Si3N4, 480 nm thick layer of diamond-like-carbon (DLC) and 60 nm thick Si3N4 by plasma-enhanced chemical vapor deposition (PECVD) as the main hard mask for subsequent ion beam etching (IBE). Then, we define the photonic waveguides and components by deep ultra-violet stepper photolithography and transfer the pattern first into a thin Si3N4 layer by fluorine-based dry etching and subsequently into the DLC hard mask layer by oxygen-based dry etching in a reactive ion etcher. The main etch of the photonic device layer is performed by IBE removing 500 nm of LiTaO3 and 

3 



<!-- Start of picture text -->
a c b c d<br>Ta<br>Li<br>O<br>b<br>100 μm 2 μm 1 μm<br>a<br>e 1. DLC deposition 2. DLC etching 3. Lithium tantalate etching 4. Redeposition cleaning<br>and mask stripping<br>Ar +<br>DLC<br>LT LT<br>WOX WOX<br>Si Si Si Si<br>f H  ions + g h 630 i Height<br>40<br>625<br>Implantation<br>20<br>620<br>500 nm<br>Wafer bonding 0 615 j<br>x<br>610<br>-20 LiTaO3<br>605<br>Annealing -40 600 2 nm SiO2<br>-40 -20 0 20 40<br>CMP x (mm)<br>2.4 nm<br>y (mm)<br>Thickness (nm)<br><!-- End of picture text -->

**Figure 1: Lithium-tantalate-on-insulator (LTOI) substrates and optical waveguides.** (a) Crystallographic unit cell of LiTaO3. (b) Colorized SEM of LTOI ring resonator. (c) Colorized scanning electron micrograph (SEM) of etched LTOI (blue) waveguide and sidewall. (d) Colorized SEM cross-section of etched LTOI waveguide on top of SiO2 bottom cladding (purple). (e) Schematic of fabrication workflow for LTOI optical waveguides including diamond-like carbon (DLC) hard mask deposition via plasma enhanced chemical vapor deposition (PECVD) from methane precursor, DLC dry etching via oxygen plasma, LiTaO3 etching via argon ion beam etching (IBE), followed by redeposition and mask removal. LiTaO3 is illustrated in blue, SiO2 in purple, DLC in black, and Si in grey. (f) Schematic of LTOI wafer bonding workflow with H-ion implantation, bonding, annealing, and CMP. (g) Photograph of bonded wafer demonstrating uniform and defect-free bonding. (h) Thickness map of LiTaO3 thin film on the wafer. (i) Atomic force micrograph of the LiTaO3 thin film surface. (j) High resolution STEM image of the LiTaO3-SiO2 bonding interface. 

leaving a 100 nm thick continuous LiTaO3 slab across the wafer. We remove the LiTaO3 redeposition on the waveguide sidewalls with an additional wet etching step and anneal the wafer at 500<sup>_◦_</sup> C in an oxygen atmosphere. We deposit a 2 µm thick upper cladding with PECVD based on a hydrogen-free precursor to avoid overtone absorption from optical phonons of the Si-OH stretch vibration around 1 _._ 5 µm. 

Next, we optically characterize the LiTaO3 PICs using frequency-comb calibrated tunable diode laser spectroscopy [26] to determine the optical loss and absorption of optical microresonators with waveguide width of 2 _._ 0 µm across the 4-inch wafers (cf. Figure 2(a)). We find mean intrinsic loss rates _κ_ 0 _/_ 2 _π_ between 35 _._ 2 MHz and 72 _._ 9 MHz with eight out of nine fields performing better than 50 _._ 8 MHz. The microresonator device loss of 35 _._ 2 MHz corresponds to a propagation loss of _α_ = 7 _._ 3 dB m<sup>_−_1</sup> for the unreduced LiTaO3 wafer 

that is specially used for optical applications. We also characterize the optical loss of the LTOI platform fabricated from the cheaper and more readily available acoustic grade LiTaO3 bulk wafers. The acoustic LTOI exhibits slightly higher loss compared to the unreduced wafers. The best field features a loss rate of 42 MHz with a mean loss rate of 82 MHz across the whole wafer (see Supplementary Figure 1). This corresponds to losses of 8 _._ 8 dB m<sup>_−_1</sup> and 17 _._ 1 dB m<sup>_−_1</sup> , which is substantially below published losses in wafer-scale fabrication of LNOI PIC [27], making our process therefore directly applicable to widely used mass manufactured LTOI wafer substrates. Figure 2(b) depicts an optical resonance transmission spectrum and fit which indicates an intrinsic loss rate of 26 _._ 8 MHz, which corresponds to a propagation loss of _α_ = 5 _._ 6 dB m<sup>_−_1</sup> . We also fabricated optical waveguide spirals with a waveguide cross-section of 1 _._ 75 µm _×_ 0 _._ 6 µm and 

4 



<!-- Start of picture text -->
a b c d<br>12 0 10 4<br>1 10 0 Mean: 40.4 MHz Median: 36.4 MHz Max: 25 MHz  102 Probe  abs /2   = 1545 nm  = 2.0 MHz<br>8 0<br>0. 5 6 0 100<br>4 0<br>0 /2  = 26.8MHz 2 0 10-2<br>0 -500 0 500 00 20 40 60 80 100 103 104 105 106 107 108<br>Frequency (MHz) Frequency (THz) Modulation frequency (Hz)<br>e f g<br>Z (eo) (eo) 2.05 LLL iTaOiNbOiTaO333 TE TM TE000000<br>∆nLT  = 0.004 L iNbO3 TM00<br>(o) (o) 2<br>Y Birefingent<br>TM00 Mode Mixing<br>1.95<br>∆nLN  = -0.07 TE00 0 30 60 90 120 150 180<br>Angle  θ  (deg)<br>h i<br>15 LiTaO3 racetrack resonator 15 LiNbO3 racetrack resonator Birefingent<br>D ispersion fit D ispersion fit Mode Mixing<br>10 D1/2  = 82.234 GHz 10 D1/2  = 80.83 GHz<br>D2/2  = 197.88 kHz D2/2  = 105.72 kHz<br>5 5<br>0 0<br>L - Band C - Band S - Band E - Band O - Band L - Band C - Band S - Band E - Band O - Band<br>-5 -5<br>180 190 200 210 220 230 240 180 190 200 210 220 230 240<br>Frequency (THz) Frequency (THz)<br>39.3 MHz 38.5 MHz<br>48.8 MHz<br>50.8 MHz<br>43.6 MHz 41.2 MHz<br>72.9 MHz 48.2 MHz<br>35.2 MHz<br>z<br>y<br>Kerr<br>/<br>Occurence<br>Transmission (norm.)  Response |            (0)| 2<br>Effective index<br> (GHz)  (GHz)<br>/2Dint /2Dint<br>θ<br>θ<br><!-- End of picture text -->

**Figure 2: Optical characterization of** LiTaO3 **photonic integrated circuits.** (a) Wafer-scale map of mean intrinsic loss _κ_ 0 _/_ 2 _π_ for similar resonators fabricated using DUV stepper lithography. (b) Normalized resonance transmission spectrum of optical racetrack microresonator at 209.358 THz. (c) Statistical distribution of intrinsic loss _κ_ 0 _/_ 2 _π_ of optical racetrack microresonator. (d) Nonlinear optical response measurement (solid red) and fit (solid black) of thermo-optical (red dashed) and Kerr (blue dashed) nonlinear response of optical microresonator demonstrating ultra-low optical absorption loss. (e) Illustration of LiNbO3 (red) strongly negative uniaxial and LiTaO3 (blue) weakly positive uniaxial crystal birefringence. (f) Illustration of curve angle and fundamental TE00 and TM00 mode profiles in LTOI. (g) Numerical simulation of fundamental TE00 and TM00 optical mode effective refractive indices of LNOI (blue) and LTOI (red) as a function of the angle between the waveguide and the Y-axis of the x-cut LN(T)OI film. The reduced birefringence of LTOI precludes unwanted birefringent mixing between fundamental TE00/TM00 modes in thick waveguides. (h) Dispersion profile of LTOI racetrack microresonator with cross-section 2 µm _×_ 0 _._ 5 µm and an 100 nm thick slab. (i) Dispersion profile of LNOI racetrack microresonator with similar cross-section and strong mode mixing at frequencies above 215 THz, which occupies the E-band and O-band in the optical communication. 

found a propagation loss around 9 dB m<sup>_−_1</sup> (see Supplementary Figure 3). Figure 3(c) depicts the histogram of fitted intrinsic loss rates for the microresonator. The contributions of optical absorption and scattering from bulk and sidewall imperfections can be separated using thermal response spectroscopy [28] (cf. Figure 2(d)). An intensity-modulated pump laser is tuned to the center of the optical resonance and the frequency modulation response of the optical microresonator due to the thermo-optical and Kerr effects is read out with a second laser tuned to the side of another resonance. We model the frequency dependence of the thermal effect due to the optical absorption and the optical Kerr effect using finiteelement simulations and fit the combined response [28, 29]. We find that the absorption limit of our LTOI microresonator is 2 _._ 0 MHz, corresponding to an absorption-limited propagation loss of 0 _._ 4 dB m<sup>_−_1</sup> which is close to recent results obtained for LNOI [29]. Therefore, the main source of loss in our tightly confining LiTaO3 waveguides is dominated by 

## scattering losses. 

The optical birefringence of LiTaO3 is more than one order of magnitude lower than in the case of LiNbO3 (cf. Figure 2(e)), which allows the fabrication of thick waveguides without incurring mode mixing between the fundamental modes in waveguide bends [7, 30]. Mode mixing occurs in x-cut LiNbO3 waveguide bends when the TE mode transitions from the extraordinary (eo) to the ordinary (o) axes above a critical LiNbO3 thickness that at wavelength 1 _._ 55 µm lies around 700 nm and for wavelength 1 _._ 3 µm lies around 600 nm, largely independent of the slab thickness, strongly constraining the design space for optical waveguides. In contrast, the low and positive uniaxial birefringence of LiTaO3 precludes mode mixing in x-cut waveguides with a horizontal-to-vertical aspect ratio greater than one. We simulate the effective mode indices of the fundamental polarization modes of LNOI and LTOI for a waveguide thickness of 600 nm, waveguide width of 2 µm and wavelength of 1 _._ 25 µm 

5 

as a function of angle between the propagation and the eo crystal axes (cf. Figure 2(g)). For LiNbO3, we find a crossing of the fundamental TE and TM modes at an angle of 25<sup>_◦_</sup> , while no mode crossing is found for an LTOI waveguide with the same dimension. This observation is in excellent agreement with the results from our optical dispersion measurement _D_ int = _ωµ − ω_ 0 _− D_ 1 _· µ_ , where _µ_ indicates the azimuthal mode index and _ω_ 0 _/_ 2 _π_ = 205 THz, for LTOI and LNOI waveguides, which are depicted in Figure 2(h) and (i), respectively. Both optical microresonators have comparable anomalous dispersion, however, the dispersion profile of the LTOI microresonator remains smooth over the full measurement span from 185 THz to 240 THz, whereas the LNOI microresonator exhibits striking mode mixing at frequencies above 215 THz. Adjustments to the waveguide geometry and working wavelength can weaken the mode mixing caused by strong birefringence in LNOI [7, 31], however, such adjustments require sacrificing optical confinement and chip compactness. In comparison, LTOI offers much lower birefringence thereby providing greater flexibility in waveguide design and manufacturing and mode-mixing-free operation over all telecommunications bands from 1260 to 1625 nm, encompassing from O to L band. 

### **ELECTRO-OPTICAL MODULATION** 

To demonstrate the utility of the LTOI platform for electrooptics, we demonstrate a tunable high Q microresonator. The resonator has a racetrack design with apex radius 100 µm and straight section length 400 µm (cf. Figure 3(a)) with a uniform waveguide width of 2 µm and pulley-style coupling sections (cf. Figure 3(b)). We applied a voltage across two of the four electrodes to measure the voltage tuning coefficient and measure the resonance position using an external cavity diode laser (ECDL) (cf. Figure 3(c)). We calibrated the laser frequency with a 250 MHz phase modulation by detecting the sidebands around the resonance. We find a voltage tuning efficiency of 255 MHz/V using a single electrode pair, which corresponds to 510 MHz/V if both phase shifter sections are modulated. We also fabricated a 2 _×_ 2 electro-optical switch based on a Mach Zehnder interferometer (MZI) composed of two 2 _×_ 2 multimode interference (MMI) beam splitters at either end and a push-pull optical waveguide phase shifter pair with a length of 7 mm((cf. Figure 3(d))). The waveguide width is 1 _._ 5 µm and the gap between the LiTaO3 waveguide sidewalls and the gold electrode is 2 µm on each side. Metal electrodes are fabricated using a DUV-lithography-based liftoff process that allows us to manufacture electrodes with a thickness of 800 nm and with an alignment tolerance below 100 nm to the optical waveguide. The transmission through the switch is plotted in Figure 3(g). The switching contrast is 10 dB, which is commensurate with an imbalance of 5% for the 2 _×_ 2 MMI beam splitters. We further find _Vπ_ = 6 _._ 1 V (cf. Figure 3(g)), which corresponds a voltage modulation efficiency of _VπL_ = 4 _._ 2 V cm for the push-pull MZI. The larger dielectric constant of LiTaO3 ( _ϵLT_ = 43) is generally considered unfavourable for phase matching between optical and 

microwave fields [32]. However, in our LTOI platform, as the optical fields is tightly localized in the sub-micrometre waveguide region while the electrical field primarily resides in the low dielectric silica layer ( _ϵsilica_ = 3.9), it is convenience to engineer the RF and optical group velocities independently. Simulation results demonstrate that a conventional design can maintain velocity matching between the optical and the microwave signals at very high microwave frequencies without compromising the electro-optic efficiency (cf. Figure 3(e)). By combining the demonstrated low propagation loss and high electro-optical efficiency in our LTOI platform with a phasematched electrode transmission line could lead to a competitive bandwidth comparable to the well-researched LNOI platform. 

### **SOLITON MICROCOMB GENERATION** 

Finally, we investigate the LiTaO3 platform for nonlinear microcomb generation. The strong optical confinement, high Q-factor, anomalous dispersion, and substantial Kerr nonlinearity of our LTOI microresonators make them naturally suitable for dissipative Kerr soliton (DKS) generation [33, 34]. We achieved single soliton generation at pulse repetition rates 81 GHz (cf. Figure 4(a)) and 30 _._ 1 GHz (cf. Figure 4(b)). The optical setup for single soliton generation is depicted in Figure 4(c). We utilized a rapid single sideband tuning scheme pioneered in ref. [35] to overcome thermal nonlinearities and initiate solitons at a pump power of 90 mW on-chip using an external cavity diode laser (ECDL) and an erbium-doped fiber amplifier for pumping. The FWHM spectral bandwidth of the 81 GHz single soliton is 4 _._ 9 THz, corresponding to a compressed pulse duration of 63 fs. The 30.1 GHz single soliton state features a bandwidth of 4 _._ 0 THz and supports a pulse duration of 71 fs. Various multisoliton states were also achieved and we depict an example state with three solitons in Figure 4(d). The low repetition rate of our 30 _._ 1 GHz solitons allows the direct detection of the microwave repetition beat note on a fast photodiode. We measure the phase noise of the microwave beat note using an electrical spectrum analyzer (ESA) and find a phase noise level of _−_ 86 dBc Hz<sup>_−_1</sup> at an offset frequency of 10 kHz and _−_ 114 dBc Hz<sup>_−_1</sup> at an offset frequency of 1 MHz, higher than earlier measurements using Si3N4 optical microresonators [36] and in z-cut LiNbO3 [37]. It is notable that here DKS generation was achieved in an x- cut ferroelectric crystal sample for the first time. 

### **CONCLUSION** 

In summary, we have developed lithium tantalate photonic integrated circuits that are low loss, exhibit low birefringence and have comparable properties to Lithium Niobate, but crucially employ a material that is already used today commercially in large volumes for wireless filters, thereby providing a path to scalable manufacturing at low cost. LTOI PICs achieve comparable loss and electro-optical performance to well-established LNOI that have major potential for penetrat- 

6 



<!-- Start of picture text -->
a b c 10<br>20 MHz Z<br>8 PD 255 MHz/V<br>PM OSC<br>6 ECDL<br>1.2<br>4 AFG 1<br>0.8<br>2 0.6<br>0.4<br>300 μm  5 μm  0 0 Frequency detuning (GHz)2 4 6 8<br>0 10 20 30 40<br>DC offset (V)<br>d<br>7 mm<br>500 µm<br>e f g<br>2.6 RF 1 6.1 V<br>Optical<br>2.4<br>2.2 5 μm 35 μm 0.5<br>Au LT 0.1 μm<br>2 WOX 2 μm<br>1.8 Si 10 μm 0 V π ∙L = 4.2 V∙cm<br>0 20 40 60 80 100 -6 -4 -2 0 2 4 6<br>Frequency (GHz) Drive Voltage (V)<br>Resonance shift (GHz)<br>Norm. transmission<br>Effective index<br>Transmission (norm.)<br><!-- End of picture text -->

**Figure 3: Electro-optical tuning and switching in LTOI.** (a) Colorized scanning electron micrograph (SEM) of LTOI (blue) racetrack optical microresonator with gold electrodes (yellow). (b) Colorized SEM of pulley resonator and bus waveguide coupling section. (c) Measured resonance shift as a result of tuning voltage. The linear fit indicates a voltage tuning response of 255 MHz/V. Inset left: Schematic of measurement setup for microresonator tuning measurement with phase modulation sideband calibration. Inset right: Electro-optical tuning of LTOI microresonator. Each color step corresponds to an increase in DC tuning voltage of 5 V. (d) Optical micrograph of 7 mm long Mach-Zehnder modulator (MZM). (e) Simulation of phase matching between the optical and microwave waves. Inset: schematic cross-section of waveguides and electrodes of the simulated structure. (f) Colorized SEM of MZM waveguides and electrodes. (g) Tuning curve of 7 mm long MZM switch indicating a operation voltage of _Vπ_ = 6 _._ 1 V and voltage-length product _VπL_ = 4 _._ 2 V cm. 

ing datacenter interconnects [3], long-haul optical communications [4], and quantum photonics [38, 39] to name just a few applications. The use of low cost substrates is of central importance for adoption in applications such as data center interconnects, where the die size is large due to the requirements of low modulator voltage and the length of travelling wave modulator devices. In our work, we do not only establish a smart-cut process for the manufacturing of LTOI wafer substrates, but also demonstrate a complete manufacturing process including the etching of LiTaO3, the removal of the redeposition of etch products on the waveguide sidewall, and the manufacturing of thick metal electrodes for functional electro-optic devices and demonstrate key performance metrics such as low propagation losses of 5 _._ 6 dB m<sup>_−_1</sup> . Our process is fully wafer-scale and based on deep ultraviolet photolithography and lays the foundation to scalable manufacturing of high performance electro-optical PICs that can harness the scale of LTOI wafer fabrication for RF filters, which is ongoing both on 150 mm and 200 mm wafer size. Our LTOI platform is, in particular, promising for applications that can directly exploit the superior properties of the material such as the reduced birefringence, where our platform is capable of processing signals across all optical communications bands 

(1260-1620 nm) in a single PIC due to the successful suppression of fundamental mode mixing and does support soliton microcomb generation also in the X-Cut, in contrast to LiNbO3 where soliton microcomb generation has only been observed in Z-Cut so far [37, 40], which has compounded the combination of electro-optical and Kerr nonlinearities [41]. LTOI is also equally promising for quantum transduction of single microwave photons [20, 21] that has recently garnered attention to overcome the thermal bottlenecks of interfacing with superconducting quantum computers [42], because of the fact that the dielectric loss tangent of LiTaO3 [43] is much lower than LiNbO3 [44]. 

### **AUTHOR CONTRIBUTIONS** 

C.W., Y.C., and K.H. fabricated the LTOI wafers. Z.L. fabricated the LTOI PICs. J.R. and Z.L. designed the PICs. C.W. and Z.L. characterized the samples. C.W., Z.L., M.C., X.J., G.L., T.B., and W.K. performed optical experiments. J.R., C.W, Z.L. analyzed the data, prepared the figures and wrote the manuscript with input from all authors. T.J.K. and X.Ou supervised the project. 

7 



<!-- Start of picture text -->
a Wavelength (nm)<br>1650 1600 1550 1500<br>-30 frep = 81 GHz 1<br>-40 ΔτFWHM = 63 fs 0.5<br>-50 0<br>0 0.2 0.4 0.6 0.8 1<br>-60 Time ( s)<br>-70<br>180 185 190 195 200 205<br>Frequency (THz) PD<br>b 1650 1600 Wavelength (nm) 1500 c OSC<br>-30 0° AFG VCO Z PD<br>-40 90° 270° ESA<br>-50 180° SSB<br>-60 CW pump EDFA OSA<br>-70<br>d e<br>-30 0°<br>0 -80<br>-40 90° 270° -120<br>-50 180° -50 -160<br>-60 -200 -100 0 100 200<br>f - 30.103 GHz (kHz)<br>-100<br>-70<br>180 185 190 195 200 205 10 1 10 2 10 3 10 4 10 5 10 6<br>Frequency (THz) Frequency (Hz)<br>Power (dBm)  (arb.u.)IPD<br>Power (dBm)<br>Power (dbc/Hz)<br>Power (dBm) 2S (Hz/Hz)ff<br><!-- End of picture text -->

**Figure 4: Dissipative Kerr soliton (DKS) generation in** LiTaO3 **photonic integrated circuit based microresonators** (a) Optical spectrum of a single soliton microcomb featuring a _sech_<sup>2</sup> -spectral profile with a 3 dB bandwidth of 4.9 THz corresponding to an FWHM pulse duration of 63 fs at a pulse repetition rate _f_ rep of 81 GHz. The inset shows the generated light during the rapid laser scan measured by filtering out the pump light. (b) Optical spectrum of a single soliton with repetition rate 30.1 GHz. (c) Optical setup for soliton generation in LTOI. Rapid laser scans are generated using a single-sideband modulator (SSB) and an erbium-doped fiber amplifier. The soliton microcombs are analyzed using an optical spectrum analyzer (OSA) and the nonlinearly generated light and microwave beat notes are recorded with a fast photodiode (PD) and analyzed with an oscilloscope (OSC) and electrical spectrum analyzer (ESA), respectively. (d) Optical spectrum of three-soliton state with repetition rate 30.1 GHz. (e) Single-side band phase noise power spectral density of 30.1 GHz microwave beat note generated from the multi-soliton state of the panel (d). Inset: Spectrum of microwave beat note with resolution bandwidth 30 Hz. 

### **FUNDING INFORMATION** 

upon publication of this preprint. 

T.J.K. acknowledges funding from the European Research Council grant no. 835329 (ExCOM-cCEO) and from the EU Horizon Europe research and innovation program through grant no. 101113260 (HDLN). J.R. acknowledges funding from the SNSF through an Ambizione Fellowship no. 201923. C.W. acknowledges financial support from China Scholarship Council (No.202104910464). X.O. acknowledges the National Key R&D Program (No.2022YFA-1404601) from the Ministry of Science and Technology of China. 

### **ACKNOWLEDGEMENTS** 

The samples were fabricated in the EPFL Center of MicroNanoTechnology (CMi) and the Institute of Physics (IPHYS) cleanroom. The LTOI wafers were fabricated in Shanghai Novel Si Integration Technology (NSIT) Co., Ltd. and the SIMIT-CAS. 

### **DATA AVAILABILITY** 

### **COMPETING INTERESTS** 

The code, data, and micrographs used to produce the plots within this work will be released on the repository Zenodo 

The authors declare no competing financial interests. 

- [1] Zhu, D. _et al._ Integrated photonics on thin-film lithium niobate. _Advances in Optics and Photonics_ **13** , 242–352 (2021). 

- [2] Boes, A. _et al._ Lithium niobate photonics: Unlocking the electromagnetic spectrum. _Science_ **379** , eabj4396 (2023). 

8 

- [3] Wang, C. _et al._ Integrated lithium niobate electro-optic modulators operating at CMOS-compatible voltages. _Nature_ **562** , 101–104 (2018). 

- [4] Xu, M. _et al._ Dual-polarization thin-film lithium niobate inphase quadrature modulators for terabit-per-second transmission. _Optica_ **9** , 61–62 (2022). 

- [5] Shen, Y. _et al._ Deep learning with coherent nanophotonic circuits. _Nature photonics_ **11** , 441–446 (2017). 

- [6] Butaud, E. _et al._ Innovative smart cut™piezo on insulator (poi) substrates for 5g acoustic filters. In _2020 IEEE International Electron Devices Meeting (IEDM)_ , 34–6 (IEEE, 2020). 

- [7] Li, Z. _et al._ Tightly confining lithium niobate photonic integrated circuits and lasers. _arXiv preprint arXiv:2208.05556_ (2022). 

- [8] Thomson, D. _et al._ Roadmap on silicon photonics. _Journal of Optics_ **18** , 073003 (2016). 

- [9] Xiang, C., Bowers, S. M., Bjorlin, A., Blum, R. & Bowers, J. E. Perspective on the future of silicon photonics and electronics. _Applied Physics Letters_ **118** (2021). 

- [10] Bruel, M. & Auberton-Hervé, B. A. Smart-cut: A new silicon on insulator material technology based on hydrogen implantation and wafer bonding. _Japanese Journal of Applied Physics_ **36** , 1636 (1997). 

- [11] Wang, C. _et al._ Integrated lithium niobate electro-optic modulators operating at CMOS-compatible voltages. _Nature_ **562** , 101–104 (2018). 

- [12] He, M. _et al._ High-performance hybrid silicon and lithium niobate mach–zehnder modulators for 100 gbit s-1 and beyond. _Nature Photonics_ **13** , 359–364 (2019). 

- [13] Zhang, M. _et al._ Broadband electro-optic frequency comb generation in a lithium niobate microring resonator. _Nature_ **568** , 373–377 (2019). 

- [14] Ballandras, S. _et al._ New generation of saw devices on advanced engineered substrates combining piezoelectric single crystals and silicon. In _2019 Joint Conference of the IEEE International Frequency Control Symposium and European Frequency and Time Forum (EFTF/IFC)_ , 1–6 (IEEE, 2019). 

- [15] Yan, Y. _et al._ Wafer-scale fabrication of 42° rotated y-cut litao3on-insulator (ltoi) substrate for a saw resonator. _ACS Applied Electronic Materials_ **1** , 1660–1666 (2019). 

- [16] SOITEC. Capital markets day 2021 (2021). https://www. soitec.com/en/capital-markets-day-2021. 

- [17] Gruber, M. _et al._ Atomistic origins of the differences in anisotropic fracture behaviour of litao3 and linbo3 single crystals. _Acta Materialia_ **150** , 373–380 (2018). 

- [18] Çabuk, S. & Mamedov, A. Urbach rule and optical properties of the linbo3 and litao3. _Journal of Optics A: Pure and Applied Optics_ **1** , 424 (1999). 

- [19] Meyn, J.-P. & Fejer, M. Tunable ultraviolet radiation by secondharmonic generation in periodically poled lithium tantalate. _Optics letters_ **22** , 1214–1216 (1997). 

- [20] Javerzac-Galy, C. _et al._ On-chip microwave-to-optical quantum coherent converter based on a superconducting resonator coupled to an electro-optic microresonator. _Physical Review A_ **94** , 053815 (2016). 

- [21] Han, X., Fu, W., Zou, C.-L., Jiang, L. & Tang, H. X. Microwave-optical quantum frequency conversion. _Optica_ **8** , 1050–1064 (2021). 

- [22] Tormo-Marquez, V., Díaz-Hijar, M., Carrascosa, M., Shur, V. Y. & Olivares, J. Low loss optical waveguides fabricated in litao 3 by swift heavy ion irradiation. _Optics Express_ **27** , 8696–8708 (2019). 

4378 (2016). 

   - [24] Lu, Y., Johnston, B., Dekker, P., Withford, M. J. & Dawes, J. M. Channel waveguides in lithium niobate and lithium tantalate. _Molecules_ **25** , 3925 (2020). 

   - [25] Yan, X. _et al._ High optical damage threshold on-chip lithium tantalate microdisk resonator. _Optics Letters_ **45** , 4100–4103 (2020). 

   - [26] Del’Haye, P., Arcizet, O., Gorodetsky, M. L., Holzwarth, R. & Kippenberg, T. J. Frequency comb assisted diode laser spectroscopy for measurement of microcavity dispersion. _Nature Photonics_ **3** , 529–533 (2009). 

   - [27] Luke, K. _et al._ Wafer-scale low-loss lithium niobate photonic integrated circuits. _Optics Express_ **28** , 24452–24458 (2020). 

   - [28] Liu, J. _et al._ High-yield, wafer-scale fabrication of ultralowloss, dispersion-engineered silicon nitride photonic circuits. _Nature Communications_ **12** , 2236 (2021). 

   - [29] Shams-Ansari, A. _et al._ Reduced material loss in thin-film lithium niobate waveguides. _Apl Photonics_ **7** , 081301 (2022). 

   - [30] Pan, A., Hu, C., Zeng, C. & Xia, J. Fundamental mode hybridization in a thin film lithium niobate ridge waveguide. _Optics express_ **27** , 35659–35669 (2019). 

   - [31] Wang, J., Chen, P., Dai, D. & Liu, L. Polarization coupling of _x_ - cut thin film lithium niobate based waveguides. _IEEE Photonics Journal_ **12** , 1–10 (2020). 

   - [32] Wooten, E. L. _et al._ A review of lithium niobate modulators for fiber-optic communications systems. _IEEE Journal of selected topics in Quantum Electronics_ **6** , 69–82 (2000). 

   - [33] Herr, T. _et al._ Temporal solitons in optical microresonators. _Nature Photonics_ **8** , 145–152 (2014). 

   - [34] Kippenberg, T. J., Gaeta, A. L., Lipson, M. & Gorodetsky, M. L. Dissipative kerr solitons in optical microresonators. _Science_ **361** , eaan8083 (2018). 

   - [35] Stone, J. R. _et al._ Thermal and nonlinear dissipative-soliton dynamics in kerr-microresonator frequency combs. _Physical review letters_ **121** , 063902 (2018). 

   - [36] Liu, J. _et al._ Photonic microwave generation in the x-and k- band using integrated soliton microcombs. _Nature Photonics_ **14** , 486–491 (2020). 

   - [37] He, Y. _et al._ High-speed tunable microwave-rate soliton microcomb. _Nature Communications_ **14** , 3467 (2023). 

   - [38] Zhao, J., Ma, C., Rüsing, M. & Mookherjea, S. High quality entangled photon pair generation in periodically poled thinfilm lithium niobate waveguides. _Physical review letters_ **124** , 163603 (2020). 

   - [39] Nehra, R. _et al._ Few-cycle vacuum squeezing in nanophotonics. _Science_ **377** , 1333–1337 (2022). 

   - [40] He, Y. _et al._ Self-starting bi-chromatic linbo 3 soliton microcomb. _Optica_ **6** , 1138–1144 (2019). 

   - [41] Gong, Z., Shen, M., Lu, J., Surya, J. B. & Tang, H. X. Monolithic kerr and electro-optic hybrid microcombs. _Optica_ **9** , 1060–1065 (2022). 

   - [42] Youssefi, A. _et al._ A cryogenic electro-optic interconnect for superconducting devices. _Nature Electronics_ **4** , 326–332 (2021). 

   - [43] Jacob, M. V. _et al._ Temperature dependence of permittivity and loss tangent of lithium tantalate at microwave frequencies. _IEEE transactions on microwave theory and techniques_ **52** , 536–541 (2004). 

   - [44] Yang, R.-Y., Su, Y.-K., Weng, M.-H., Hung, C.-Y. & Wu, H.W. Characteristics of coplanar waveguide on lithium niobate crystals as a microwave substrate. _Journal of applied physics_ **101** , 014101 (2007). 

- [23] Soltani, M. _et al._ Ultrahigh q whispering gallery mode electrooptic resonators on a silicon photonic chip. _Opt. Lett._ **41** , 4375– 

