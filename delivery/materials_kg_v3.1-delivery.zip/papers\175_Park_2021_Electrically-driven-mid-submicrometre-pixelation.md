# Electrically driven mid-submicrometre pixelation of InGaN micro-light-emitting diode displays for augmented-reality glasses

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Photonics |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 174 |
| 作者 | Jinjoo Park, Jun-Hee Choi, Kiho Kong, J. Han, Junghwan Park, N. Kim, Eunsung Lee, Dongho Kim et al. |
| DOI | 10.1038/s41566-021-00783-1 |
| 源文件 | 075_Park_2021_Electrically-driven-mid-submicrometre-pixelation.pdf |

---




<!-- Start of picture text -->
Electrically driven mid -s ubmicron pixelation of<br>InGaN micro -L ED displays for AR glasses<br>Jinjoo Park<br><!-- End of picture text -->

Samsung Advanced Institute of Technology Jun Hee Choi  (  joonie.choi@samsung.com ) Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology 

Seoul National University 

Seoul National University https://orcid.org/0000-0002-1802-0320 

Samsung Advanced Institute of Technology 

Samsung Advanced Institute of Technology https://orcid.org/0000-0003-0151-791X 

Keywords: Blue Light-emitting Diodes, Display Industry, Augmented Reality, Tailored Ion Implantation, Thin-�lm Transistor Pixel Circuits 

Posted Date: November 14th, 2020 

https://doi.org/10.21203/rs.3.rs-101057/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Version of Record: A version of this preprint was published at Nature Photonics on March 25th, 2021. See the published version at https://doi.org/10.1038/s41566-021-00783-1. 

# **Electrically driven mid-submicron pixelation of InGaN micro-LED displays for AR glasses** 

**Jinjoo Park**<sup>**1†**</sup> **, Jun Hee Choi**<sup>**1†***</sup> **, Kiho Kong**<sup>**1**</sup> **, Joo Hun Han**<sup>**1**</sup> **, Jung Hun Park**<sup>**1**</sup> **, Nakhyun Kim**<sup>**1**</sup> **, Eunsung Lee**<sup>**1**</sup> **, Dongho Kim**<sup>**1**</sup> **, Joosung Kim**<sup>**1**</sup> **, Deukseok Chung**<sup>**1**</sup> **, Miyoung Kim**<sup>**2**</sup> **, Euijoon Yoon**<sup>**2**</sup> **, Jaikwang Shin**<sup>**1**</sup> **, Sungwoo Hwang**<sup>**1**</sup> 

1 Samsung Advanced Institute of Technology, Suwon 443-803, Republic of Korea 

2Department of Materials Science and Engineering, Seoul National University, Seoul 151–744, Republic of Korea 



## **<mark>ABSTRACT</mark>** 

<mark>InGaN-based blue light-emitting diodes (LEDs), with their high efficiency and brightness, are entering the display industry. However, a significant gap remains between the expectation of highly efficient light sources and their experimental realization into tiny pixels for ultrahighdensity displays for augmented reality (AR).</mark> 

<mark>Herein, we report using tailored ion implantation (TIIP) to fabricate highly-efficient, electrically-driven pixelated InGaN microLEDs (μLEDs) at the mid-submicron scale (line/space of 0.5/0.5 μm), corresponding to 8500ppi (RGB). Creating a laterally confined nonradiative region around each pixel with controlled amount of mobile vacancies, TIIP pixelation materializes relatively invariant luminance, and high pixel distinctiveness, at submicron-sized pixels. Moreover, with incomparable integration capability of TIIP pixelation owing to its planar geometry, we demonstrate 2000 ppi μLED displays with monolithically integrated thin-film transistor pixel circuits, and 5000 ppi compatible core technologies. We expect that the demonstrated method will pave the way toward highperformance μLED displays for seamless AR glasses in the near future.</mark> 



> * <mark>e-mail:joonie.choi@samsung.com</mark> 

> **†** These authors contributed equally. 

## **INTRODUCTION** 

<mark>Due to their inherent high efficiency, brightness, and stability, inorganic Group III–V microLEDs (μLEDs) are being evaluated in next-generation displays for a wide variety of applications, including high-dynamic-range wall displays/TVs/tablets,</mark><sup>1–3</sup> <mark>long-use smartwatches,</mark><sup>4</sup> <mark>high-brightness heads-up displays (HUDs),</mark><sup>5</sup> <mark>and high-brightness/resolution augmented reality (AR) glasses.</mark><sup>6,7</sup> <mark>Notably, with the assistance of the pick-and-place technologies of RGB chips (R: AlGaInP; G and B: InGaN), μLED TVs are the first appealing application with their superior image quality. The μLEDs also have applications in the AR glasses industry, although this market is just developing. To fully experience seamless (indoor/outdoor) and realistic (field of view ± 20°) merging of virtual and physical information, high dynamic brightness range (from 1 to > 10</mark><sup>4</sup> <mark>nit) and high resolution (> full high definition: 1920 × 1080 pixels) are required while maintaining small form-factor (0.5in diagonal or less) microdisplays. Only inorganic μLEDs can fulfill these severe requirements, given the lower brightness of organic LEDs (OLEDs)</mark><sup>8</sup> <mark>and lower contrast of liquid-crystal-on-silicon (LCoS) technology.</mark><sup>9</sup> <mark>For their realization into microdisplays, the key challenge is efficient small-sized pixelation at the submicron dimension.</mark> 

<mark>Pixelation refers to forming an array of light emitters (pixels) that can be distinctively controlled without crosstalk between neighbors. Mesa etching, which physically removes p-GaN and multiple quantum wells (MQWs) for electrical contact at the n-GaN surface, has long been used for single LED devices and is commonly regarded as a pixelation technique for next-generation μLEDs. However, mesa etching inevitably exposes surface in the active region, which leads to much greater nonradiative surface recombination with decreasing pixel size (< 10 μm including submicron),</mark><sup>10,11</sup> <mark>thus significantly reducing efficiency. Surface passivation techniques or core-shell structures have been used to reduce surface recombination. Particularly, core-shell structures (n-GaN inner core/MQW outer core/p-GaN shell) based on selective area growth can achieve small-sized, efficient pixelation,</mark><sup>12,13</sup> <mark>yielding high internal quantum efficiency (IQE) of ~30% for blue at the diameter of ~1 μm.</mark><sup>14</sup> <mark>However, core-shell structures are formed by a bottom-up approach, which inevitably introduces compositional variation and challenges in controlling wafer-scale uniformity; these issues result in electroluminescence spectral broadening. Moreover, integration into driving pixel thin-film transistors (TFTs) is difficult because of threedimensional (3D) geometry-related process issues, such as poor step coverage. Therefore, a new pixelation strategy is needed to achieve both high efficiency of submicron-scale devices and easy integration into pixel-driving circuitry.</mark> 

<mark>Herein, we report using tailored ion implantation (TIIP) to fabricate highly-efficient, electrically-driven pixelated InGaN microLEDs (μLEDs) at the mid-submicron scale (line/space of 0.5/0.5 μm), corresponding to 8500ppi (RGB). Precisely, this technique exploits ion implantation (IIP) of a small-thickness pixelation mask at ~100°C using heavy ionic species with a tilt angle of 0° and with low energy and dose, with their pixelation mechanism revealed. Furthermore, we describe the monolithic integration of TIIP pixelation with low-temperature polysilicon (LTPS) pixel circuits to demonstrate 2000-ppi (pentile) display prototypes and 5000-ppi compatible core technologies including quantum dot color converters (QD C/Cs).</mark> 

## **1. Submicron pixelation by IIP: suppressing lateral straggling** 

<mark>Figure</mark> **<mark>1</mark>** <mark>illustrates two different pixelation schemes, i.e., mesa etching and IIP on InGaN-based μLEDs formed on Si substrates (Fig.</mark> **<mark>S1a</mark>** <mark>). Mesa etching is typically used in the μLED industry, but a number of etched surfaces at light-emitting quantum wells are exposed. This inevitably creates substantial nonradiative recombination centers that significantly decrease efficiency, particularly at the submicron size because of increased surface-to-volume ratio (Fig.</mark> **<mark>1a</mark>** <mark>). In contrast, IIP can achieve the planar-geometry pixelation without needing to expose any surfaces (Fig.</mark> **<mark>1b</mark>** <mark>,</mark> **<mark>c</mark>** <mark>). Despite these advantages, micron-sized pixelation by ion implantation is highly challenging. We investigated the TIIP conditions for a number of implantation conditions and pixel sizes using fluorescence photoluminescence (PL) microscopy (Fig.</mark> **<mark>S2a-z</mark>** <mark>and Table</mark> **<mark>S1</mark>** <mark>). The non-TIIP condition causes significant lateral spreading of As</mark><sup>+</sup> <mark>under the implantation mask, called undermask penetration (Figs.</mark> **<mark>1b</mark>** <mark>and</mark> **<mark>2a</mark>** <mark>), whereby an unintentionally produced shallow As</mark><sup>+</sup> <mark>profile exists near the surface of GaN LEDs below the implantation mask. This undermask penetration can be significantly reduced by adjusting the TIIP parameters (Figs.</mark> **<mark>1c</mark>** <mark>and</mark> **<mark>2b</mark>** <mark>). TIIP spatially confines the implanted region precisely, with minimal lateral spreading (Fig.</mark> **<mark>1c</mark>** <mark>). Thin implantation mask thickness is the critical parameter for optimal TIIP (Fig.</mark> **<mark>S2</mark>** <mark>). Using a 0° tilt angle and heavier ions, including Ar</mark><sup>+</sup> <mark>or Kr</mark><sup>+</sup> <mark>, is also beneficial. Minimal ion energy and dose should be used because high values degrade pixelation contrast. Ion energy is more influential than fluence. Lateral spreading with non-TIIP and TIIP is supported by high-resolution two-dimensional (2D) secondary ion mass spectrometry (SIMS) analyses of As</mark><sup>+</sup> <mark>-implanted InGaN LEDs (Fig.</mark> **<mark>2a</mark>** <mark>and</mark> **<mark>b</mark>** <mark>, respectively). Both shallow and deep ion profiles contribute to luminescence</mark> quenching of MQWs. Similar As<sup>+</sup> profiles were observed using time-of-flight SIMS (Fig. **S3** ). 

<mark>Lateral spreading of implanted ions can be explained by ion scattering</mark><sup>15-17</sup> <mark>and lateral channeling</mark><sup>18-21</sup> <mark>effects (Fig.</mark> **<mark>1d)</mark>** <mark>. When incident ions (projectiles) strike the implantation mask, they experience elastic nuclear scattering and inelastic electron scattering. In the low-energy regime (5−50 keV) used in this research, the former is the dominant scattering mechanism, causing significant angular deflections of the projectiles from their original pathways after collision. Most projectiles are backscattered near the top of the mask by nuclear stopping, and some ions are scattered from the mask edge. Once an ion is scattered from the mask into air, it should travel in a straight line until it reenters the GaN LED structure (Fig.</mark> **<mark>1d</mark>** <mark>). This scattering by uncontrolled particles is known as the well-proximity effect in the complementary metal-oxide–semiconductor (CMOS) industry, and results in an undesired threshold voltage shift of transistors.</mark><sup>15-17</sup> <mark>The exact entry point depends on the position at which the ion exits the mask and its direction of motion. The former can be solved by reducing the mask thickness, while the latter can be solved by using vertically incident, heavy-mass ions in the optimal ranges of energy and fluence. We believe that ions reentering the LEDs are easily coupled to lateral channeling (Fig.</mark> **<mark>1d</mark>** <mark>), which finally results in significant lateral spreading in the shallow (near-surface) region. Note that abnormal lateral spread for 4H-SiC was predicted due to lateral channeling through <11−20> axial channels.</mark><sup>20,21</sup> <mark>Due to the structural similarity between GaN and 4H-SiC, and the wide angular distribution of scattered ions, significant lateral channeling is expected. This can be</mark> 

<mark>minimized by using a thin mask and non-tilted projectile incidence (tilt angle of 0°) while maintaining energies and fluences as low as possible, i.e., about 1−50 keV and 10</mark><sup>12</sup> <mark>−10</mark><sup>13</sup> cm<sup>−2</sup> , respectively. 

<mark>Finally, mobile vacancies generated by implanted ions can cause further spatial luminescence quenching, which should be minimized for accurate spatial pixelation. The amount of mobile vacancies for a given implantation energy and dose are minimized at an implantation temperature of ~100°C (Fig.</mark> **<mark>1e</mark>** <mark>), as discussed in detail below.</mark> 

**2. Implanted region: Model for high electrical resistivity and luminescence quenching** In this section, we build a model to explain high electrical resistivity and luminescence quenching in the implanted region. Gallium nitride is a mechanically strong material. Therefore, it is very difficult to induce structural damage by ion bombardment, unlike other semiconductor materials, such as Si. We use X-ray diffraction (XRD) and transmission electron microscopy (TEM) to examine microstructures. Ar<sup>+</sup> IIP at 1 × 10<sup>15</sup> at cm<sup>–2</sup> on our GaN LED epi structures did not generate any serious structural changes, such as stacking faults or dislocations, as revealed by dark-field TEM images (Fig. **S1b** ). With As<sup>+</sup> implantation at 1 × 10<sup>14</sup> at cm<sup>2</sup> , only slight peak broadening was observed in the XRD (Fig. **2c** ), having neither any peak shift of AlGaN and InGaN satellite peaks nor any shoulder peaks<sup>22</sup> . These results suggest that typical fluence would generate mostly point defects, including single-point defects and their defect complexes, forming deep-trap levels in the bandgap. Our deep-level transient spectroscopy (DLTS) measurements reveal two important features. First, the peaks (Ec −0.13 and −0.07, and Ev +0.09 eV) observed for the nonimplanted LEDs attributed to activated donors and acceptors (inset of Fig. **2d** ) disappeared with increasing As<sup>+</sup> dose (center and right panels of Figs. **2d** and **S4** ). We assume that IIP deactivated Mg dopants in p-GaN, possibly by compensation, and some Si dopants in n-GaN while generating deep traps, thereby forming an undoped, high electrical resistivity region. We measured significant enhancement of resistivity after N<sup>+</sup> IIP (Fig. **S1** (c)). Second, the generated deep traps are only assigned to Ec −0.7 eV. 

<mark>Luminescence quenching of ion-implanted GaN MQWs was previously studied using depth-profiled cathodoluminescence (CL).</mark><sup>23</sup> <mark>Both band-edge emission and the yellow luminescence band were strongly quenched even at relatively low-dose (10</mark><sup>12</sup> <mark>−10</mark><sup>14</sup> <mark>cm</mark><sup>−2</sup> <mark>) ion bombardment, suggesting that enough vacancies (~5 × 10</mark><sup>19</sup> <mark>cm</mark><sup>−3</sup> <mark>) were created with the low dose. Importantly, the CL quenching depth of ~700 nm was well beyond the depth of ion bombardment (</mark> _<mark>Rp</mark>_ <mark>+ 3Δ</mark> _<mark>Rp</mark>_ <mark>, ~450 nm) estimated by collision simulation. This was attributed to the high mobility of created vacancies to diffuse downward to yield further quenching.</mark><sup>23.24</sup> <mark>These observations on the quenching of GaN cathodoluminescence are in good agreement with our experiments. In Fig.</mark> **<mark>S2</mark>** <mark>, apparent luminescence quenching is evident at relatively low doses (> 2 × 10</mark><sup>12</sup> <mark>cm</mark><sup>−2</sup> <mark>) even though all of the detectable implanted ions appear to locate above the MQWs (Fig.</mark> **<mark>2b</mark>** <mark>,</mark> **<mark>c</mark>** <mark>). Notably, even near-surface implantation can affect luminescence, which explains the low-contrast and high-contrast pixelation in non-TIIP and TIIP (Fig. 1</mark> **<mark>b</mark>** <mark>-</mark> **<mark>c</mark>** <mark>).</mark> 

<mark>The amount of IIP-induced vacancies is correlated with the implantation temperature. It is reasonable that lattice damage monotonically decreases with increasing implantation temperature. However, positron annihilation spectroscopy (PAS) studies have revealed that the amount of induced vacancies in 4H-SiC is minimal at an implantation temperature of ~100°C.</mark><sup>25</sup> <mark>This might occur via a dynamic or in situ annealing process at this temperature. We observe a similar temperature dependence for TIIP: the PL intensity of submicron-sized pixels is dramatically improved at the implantation temperature of ~100°C (Fig.</mark> **<mark>S2y,z</mark>** <mark>). Mobile vacancies induced in the InGaN/GaN LEDs likely have the same temperature dependence. Therefore, the implantation temperature of 100°C might be essential for accurate spatial pixelation, especially at the submicron scale (Fig. 1</mark> **<mark>b</mark>** <mark>-</mark> **<mark>c</mark>** <mark>).</mark> 

## **<mark>3. Experimental verification of TIIP superiority</mark>** 

<mark>We verify the superiority of TIIP pixelation over mesa pixelation by experiment and by simulation (section 4). A 200-nm-thick Ti mask is formed under the TIIP conditions of Ar</mark><sup>+</sup> <mark>implantation at 100°C, a tilt angle of 0°, energy of 5 keV, and dose of 2 × 10</mark><sup>12</sup> <mark>cm</mark><sup>−2</sup> <mark>. Photoluminescence microscope images are compared side-by-side between TIIP and mesa pixelation for various pixel densities (300-8500 ppi) in Figs.</mark> **<mark>3a</mark>** <mark>and</mark> **<mark>S5</mark>** <mark>. Both pixel contrast and intrapixel uniformity are clearly much higher for TIIP pixelation than mesa pixelation. Notably, for mesa pixelation, each subpixel becomes significantly blurred at or above 4800 ppi, making it difficult to prevent pixel crosstalk, thus requiring a special light-guiding structure at high pixel densities. In contrast, TIIP pixelation yields four distinctive differently sized subpixels corresponding to 2400, 4800, 6600, and 8500 ppi (marked by dotted pink rectangles of Fig.</mark> **<mark>3b</mark>** <mark>)</mark> **<mark>.</mark>** <mark>Spectral data confirm the preservation of CL intensity by TIIP pixelation compared with mesa pixelation (Fig.</mark> **<mark>3c</mark>** <mark>). The integrated I</mark> 8500 ppi <mark>/I</mark> 300 ppi <mark>CL intensity ratio for mesa and IIP pixelation is 6 and 20%, respectively. The relatively high CL intensity ratio for various resolutions verifies the superiority of IIP pixelation and its potential application to high-density devices. The CL spectra also exhibit a single peak at 390 nm originating from superlattices included for film stress optimization in our LED epilayer.</mark> 

<mark>We compared the EL characteristics between mesa and TIIP pixelation for various pixel densities (Fig.</mark> **<mark>3d</mark>** <mark>) under flipped architecture (FA) (Fig.</mark> **<mark>S6a</mark>** <mark>,</mark> **<mark>S7a</mark>** <mark>, and</mark> **<mark>S8</mark>** <mark>). Figure</mark> **<mark>3d</mark>** <mark>clearly shows that TIIP pixelation luminance is well-maintained with decreasing pixel size compared with mesa pixelation. The EL luminance for mesa pixelation is 3590 and 28,980 nit at 4800 and 300 ppi, respectively, under the current density of 4.9 A/cm</mark><sup>2</sup> <mark>; the corresponding values are 14,290 and 55,835 nit for TIIP pixelation. More importantly, at pixel densities above 4800 ppi, we do not observe any mesa-pixelated EL emission due to leakage. The yellow circle in Fig.</mark> **<mark>S9a</mark>** <mark>indicates where slight misalignment or poor step coverage of a CBL with small-sized opening results in unprotected mesa sidewalls, which induces severe current leakage. In contrast, in the case of TIIP pixelation, the misalignment issue is not critical and a thinner (~30 nm) CBL can be used (Fig.</mark> **<mark>S9b</mark>** <mark>). This enables the fabrication of EL devices up to 8500 ppi with luminance of 7440 nit at 4.9A cm</mark><sup>−2</sup> <mark>. Therefore, only the PL pattern in Fig.</mark> **<mark>3b</mark>** <mark>can be reproduced with EL TIIP pixelation (inset of right panel of Fig.</mark> **<mark>3d</mark>** <mark>). This is a very important practical advantage of TIIP pixelation for fabricating high-pixel-density devices.</mark> 

## **<mark>4. Numerical comparison of quantum efficiency between TIIP and mesa pixelation</mark>** 

<mark>To explain superiority of TIIP over mesa pixelation, we numerically compare mesa and IIP pixelation. In the mesa structure, there is typically high current at the surface (Fig.</mark> **<mark>4a</mark>** <mark>) and its main radiative recombination rate is significantly affected by the SRV</mark> 

<mark>(Figs.</mark> **<mark>4b</mark>** <mark>and</mark> **<mark>S6d</mark>** <mark>), described in Methods. Dependence of IQE on SRV becomes significant with decreasing subpixel size. Various SRVs ranging from 5 × 10</mark><sup>4</sup> <mark>to 3.2 × 10</mark><sup>6</sup> <mark>cm s</mark><sup>−1</sup> <mark>are used to match the reported experimental efficiency. The best agreement was achieved at 4 × 10</mark><sup>5</sup> <mark>cm s</mark><sup>−1</sup> <mark>, where the I</mark> 12000 ppi <mark>/I</mark> 300 ppi <mark>IQE ratio is ~21 % (Fig.</mark> **<mark>4c</mark>** <mark>).</mark><sup>26</sup> <mark>This is about an order of magnitude greater than that reported in the literature (5 × 10</mark><sup>4</sup> <mark>cm s</mark><sup>−1</sup> <mark>). Such a large recombination velocity might be attributed to the fact that a mesa surface typically fabricated by plasma etching has additional etch damage that has more defects than a normal cleaved surface consisting of simple dangling bonds.</mark> 

<mark>As discussed in Section 2, for TIIP pixelation, we use the deep-trap model in which the SRH recombination time in equation (2) includes deep-trap terms generated by the IIP as follows:</mark> **𝑝 𝑆** 



<!-- Start of picture text -->
IIP as follows:<br>(1)<br>𝑝 𝑝 −𝑝𝑝𝑖𝑖 2 )�<br>1 1<br>𝑅𝑅𝑆 𝑆 𝑆𝑆 = 𝜏𝜏𝑝𝑝0�𝑝𝑝+𝑝𝑝𝑖𝑖𝑒 𝑒 𝑝𝑝 ( −𝐸𝐸 𝑘𝑘𝑇𝑇 𝑇 )�+𝜏𝜏𝑛𝑛0�𝑝𝑝+𝑝𝑝𝑖𝑖𝑒 𝑒 𝑝𝑝 ( −𝐸𝐸 𝑘𝑘𝑇𝑇 𝑇  (1-2)<br>and  where σ n  𝜏𝜏 ,  σ 𝑝𝑝0 p, v = n ,  𝜎𝜎 v 𝑝𝑝 p 𝑣𝑣 , 𝑝𝑝  N 𝑁𝑁𝑝𝑝 n , and   (1-1)  and  N p  are the respective capture cross-sections, thermal  𝜏𝜏𝑝𝑝0 = 𝜎𝜎𝑝𝑝𝑣𝑣𝑝𝑝𝑁𝑁𝑝𝑝<br><!-- End of picture text -->

<mark>and</mark> _<mark>σ</mark> n_ <mark>,</mark> _<mark>σ</mark> p,_ _<mark>v</mark> n_ <mark>,</mark> _<mark>v</mark> p_ <mark>,</mark> _<mark>N</mark> n_ <mark>, and</mark> _<mark>N</mark> p_ <mark>are the respective capture cross-sections, thermal velocities, and peak defect densities for electrons and holes</mark><sup>34</sup> <mark>. Based on our DLTS data (Figs.</mark> **<mark>2c</mark>** <mark>and</mark> **<mark>S4d</mark>** <mark>), we include single trap level (E</mark> T <mark>) of E</mark> C <mark>−0.7 eV with estimated</mark> _<mark>σ</mark> n_ <mark>or</mark> _<mark>σ</mark> p_ <mark>ranging from 1 × 10</mark><sup>−18</sup> <mark>to ~8 × 10</mark><sup>−14</sup> <mark>cm</mark><sup>2</sup> <mark>. Considering the band diagram of QWs designed for high carrier concentration, a certain amount of injected carriers should spread into the implanted region despite the high-density deep-level states (lower panels of Figs.</mark> **<mark>4d</mark>** <mark>and</mark> **<mark>S7 b</mark>** <mark>,</mark> **<mark>c</mark>** <mark>). At</mark> _<mark>N</mark> n_ <mark>and</mark> _<mark>N</mark> p_ <mark>of 6 × 10</mark><sup>14</sup> <mark>cm</mark><sup>–3</sup> <mark>, the spread carriers in QWs results in incomplete turn-off of the implanted region (upper right panel of Fig.</mark> **<mark>4d</mark>** <mark>). With increased</mark> _<mark>N</mark> n_ <mark>and</mark> _<mark>N</mark> p_ <mark>to 4 × 10</mark><sup>17</sup> <mark>cm</mark><sup>–3</sup> <mark>, the radiative recombination rate drops quickly to nearly zero from the boundary into the implanted region (upper left panel of Fig.</mark> **<mark>4d</mark>** <mark>). This results in off-luminance of the implanted region and the achievement of distinct pixelation. Nonetheless, Figures</mark> **<mark>4e</mark>** <mark>and</mark> **<mark>S7d,e</mark>** <mark>show that the I</mark> 12000 ppi <mark>/I</mark> 300 ppi <mark>IQE ratio is 79.2 and 89.6% at the current density of 8 A cm</mark><sup>−2</sup> <mark>for deep-level densities of 6 × 10</mark><sup>14</sup> <mark>and 4 × 10</mark><sup>17</sup> <mark>cm</mark><sup>−3</sup> <mark>, respectively. This means that the ideal TIIP, with much smaller effective defect density (see supplementary information), can potentially achieve very high IQE pixelation even at very small subpixel size.</mark> 

## **<mark>5. Integration of TIIP pixelation into TFT pixel circuits and QD C/C</mark>** 

<mark>Owing to the planar geometry, TIIP pixelation is readily incorporated via monolithic or bonding integration into any high-resolution pixel-driving circuits in high-ppi μLED displays. For example, 2-transistor/1-capacitor (2T1C) pixel circuits based on LTPS are fabricated monolithically on the TIIP/CBL structure, as described in the Methods section and illustrated in Fig.</mark> **<mark>S8</mark>** <mark>. Figure</mark> **<mark>5a,b</mark>** <mark>presents IIP/CBL-pixelated LEDs operated by 300/600/2000 ppi LTPS-TFTs. The 2000 ppi (pentile) LTPS-TFTs have width/length (W/L) of 2 μm/2 μm (Fig.</mark> **<mark>S10a</mark>** <mark>). Furthermore, we verify the transfer (I</mark> ds <mark>–V</mark> ds <mark>) characteristics of p-Si</mark> 

<mark>TFT even at W/L of 1 μm/1 μm (Fig.</mark> **<mark>S10b</mark>** <mark>). However, at W/L of 0.5 μm/0.5 μm, the LTPSTFT completely loses transistor characteristics at V</mark> ds <mark>of –10 V (Fig.</mark> **<mark>S10c</mark>** <mark>) due to punchthrough or short-channel effects whereas normal transfer curves are maintained at V</mark> ds <mark>of −3 V (Fig.</mark> **<mark>S10d</mark>** <mark>). We believe that the W/L of 0.5 μm/0.5 μm might be the lower limit of LTPSTFTs. This means that LTPS-TFTs can be potentially used as 5000 ppi-compatible pixel circuits in AR glasses, which far exceeds the previous estimate of 1500 ppi.</mark><sup>27</sup> <mark>As a potential candidate for high-density, monolithic pixel circuits, we are also investigating GaN-based, normally off high-electron-mobility transistors (HEMTs) on InGaN LEDs, stacks of which are epitaxially grown in a single MOCVD run.</mark><sup>28,29</sup> 

<mark>For efficient light extraction, the FA of monolithically integrated LED/TFTs is fabricated using the series of processes illustrated in Fig.</mark> **<mark>S8c</mark>** <mark>,</mark> **<mark>d</mark>** <mark>. With the 300 ppi (RGB) pixel TFTs, we demonstrated bright and uniform moving images with brightness of 25,600 cd m</mark><sup>−2</sup> <mark>and external quantum efficiency (EQE) of 12% (Figs.</mark> **<mark>5b</mark>** <mark>and</mark> **<mark>S11</mark>** <mark>, and Supplementary Movies</mark> **<mark>S1</mark>** <mark>and</mark> **<mark>S2</mark>** <mark>). Moreover, our recent monolithic integration of LTPS-TFTs into the 2000 ppi (pentile) FA also vividly shows a moving black-and-white (BW) checker pattern free of flickering (Supplementary Movie</mark> **<mark>S3</mark>** <mark>). To the best of our knowledge, this is the highest ppi moving image ever reported. Next, by simply modifying the FA (Fig.</mark> **<mark>5c</mark>** <mark>), we further demonstrate a resonant-cavity flipped architecture (RCFA) structure. This type of structure should provide reduced full-width at half-maximum (FWHM), which is especially required to reduce loss in the diffraction gratings in waveguide-type AR glasses</mark> ~~<mark>.</mark>~~ <mark>(Fig.</mark> **<mark>S13</mark>** <mark>and Table</mark> **<mark>S3</mark>** <mark>). Finally, our TIIP/CBL LEDs can also be assembled onto a CMOS backplane using a special bonding process as described in Methods.</mark> 

<mark>Finally, the TIIP/CBL LEDs are readily assembled with a QD color converter (C/C) pattern to realize RGB displays (top panels of Figs.</mark> **<mark>5d</mark>** <mark>and</mark> **<mark>S8e</mark>** <mark>) and high-resolution patterning of QD C/C, called backside-exposure technique, as described in Methods.</mark> 



## **<mark>CONCLUSIONS</mark>** 

<mark>To our best knowledge, we demonstrate TIIP as smallest-sized, electrically-driven pixelation method of InGaN materials, maintaining high efficiency. We reveal that minimization of lateral pathways of implanted ions by scattering-guided lateral ion channeling and the amount of induced mobile vacancies are the key factors affecting TIIP. PL/CL microscopy of submicron-sized pixels clearly reveals that luminance, intra pixel uniformity, and pixel distinctiveness in TIIP pixelation are superior to that in mesa pixelation. Only TIIP pixelation can achieve stable, leakage-free EL luminance of 7440 nit at 4.9 A cm</mark><sup>−2</sup> <mark>even at midsubmicron sizes (W/L = 0.5 μm/0.5 μm, 8500 ppi). Furthermore, owing to planar geometry, the TIIP-pixelated LEDs have excellent integration capability with small-sized TFT pixel circuits and QD C/Cs. We strongly believe that TIIP pixelation is the ideal solution for fullcolor ultrahigh definition microdisplays for AR glasses.</mark> 



## **<mark>METHODS</mark>** 

## **<mark>Submicron ion implantation and two-dimensional SIMS analysis</mark>** 

<mark>As</mark><sup>+</sup> <mark>is used for 2D SIMS analysis to reveal the implanted profiles of TIIP and non-TIIP conditions. The tilt angle/ion energy for TIIP and non-TIIP were 0°/5 keV and 7°/8 keV, respectively, with the dose fixed at 1 × 10</mark><sup>16</sup> <mark>at cm</mark><sup>−2</sup> <mark>. After implantation, the PR mask is removed by O</mark> 2 <mark>ashing, and the samples are measured by SIMS using a CAMECA IMS 7f instrument. The projected range of As</mark><sup>+</sup> <mark>penetration is ~50 nm under the beam sputtering time calibration of 2 eV, −40 nA Cs</mark><sup>+</sup> <mark>. We analyze the p-GaN/AlGaN electron blocking layer (EBL)/MQWs and some n-GaN near the MQWs. Using the 30 keV, −1 pA Bi</mark><sup>+</sup> <mark>probe beam, the data detected in image mode are summed along a particular strip, i.e., they are projected onto the particular plane, to improve counting statistics. Two-dimensional concentration profiles are finally obtained by respective data analysis, where a deconvolution algorithm (Lucy−Richardson) is used to account for the Gaussian distribution of the beam density.</mark> 

## **<mark>Integration of TIIP/CBL-pixelated LEDs and LTPS-TFTs</mark>** 

<mark>Our InGaN LED epilayers are formed on 8-in-diameter Si (111) wafers (Fig.</mark> **<mark>S1</mark>** <mark>). The epilayer consists of a 150-nm-thick AlN nucleation layer, AlGaN multilayer buffer, 3-μmthick undoped-GaN layer, 3-μm-thick Si-doped n-GaN layer (n ~9× 10</mark><sup>18</sup> <mark>cm</mark><sup>−3</sup> <mark>), 2.1 nm/2.4 nm 50-period InGaN/GaN superlattice underlayer (n-SL), five pairs of 3 nm/5 nm InGaN/GaN multiquantum wells (MQWs), 10-nm-thick Mg-doped AlGaN EBL, and 100nm-thick Mg-doped p-GaN layer. The p-GaN activation was performed by annealing in a furnace under a nitrogen atmosphere for 30 min at 700°C. After forming the alignment key, the pixel region is closed by a rectangular PR pattern that is subjected to IIP under TIIP conditions. Then, a 200-nm-thick SiO</mark> x <mark>layer pattern is formed as a CBL with opening into the pixel region, followed by a rectangular Al/Mo p-electrode pattern in the CBL opening region. Figure</mark> **<mark>8b</mark>** <mark>shows that 500-nm-thick-SiO</mark> 2 <mark>:H is used as a buffer layer; a-Si:H was deposited by plasma-enhanced CVD, thermally annealed for 1 h at 450°C for dehydrogenation, and ELA was subsequently used for conversion into a p-Si active pattern. We observe that the dehydrogenation step of a-Si:H just prior to excimer-laser annealing (ELA) is critical to EL performance. Above a dehydrogenation temperature of 500°C, we observe only spotty EL emission after TFT integration. We attribute this to rehydrogenation of activated Mg-doped p-GaN during the dehydrogenation step, where the evolved hydrogen from a-Si:H can be used for hydrogenating, thereby deactivating the activated p-GaN. A gate insulator (40-nmthick SiO</mark> 2 <mark>/80-nm-thick SiN</mark> x <mark>) and gate (80-nm-thick) were deposited, with gate linepatterning followed by source/drain (S/D) boron implantation, interdielectric (400-nm-thick SiN</mark> x <mark>) deposition, and subsequent thermal annealing for activation and hydrogenation via patterning to metallize the S/D and p-electrode of the LED, and finally S/D (Mo/Al/Mo) deposition.</mark> 

<mark>Next, the bonding provides a one-to-one electrical connection between the p-electrodes of pixelated LEDs and drain electrodes of the driving CMOS transistors. This option has the advantages of low power consumption, controllability of brightness uniformity, selection of peak current for high efficiency by high-speed operation (pulse-width modulation), small form-factor by integrating many peripheral circuits such as TCONs, and is bezel-less due to</mark> 

<mark>its vertical stacking. Regarding high-resolution bonding, conventional metal-to-metal bonding, such as eutectic bonding, has clear limits. The minimum pad dimension is ~5 μm with a pitch of ~10 μm, which is not suitable for microdisplays for AR glasses. New Cu-toCu (C2C) hybrid bonding, currently being developed for CMOS image sensors, are under development with a pad size of 1.0 μm with a pitch of 2.0 μm. Hybrid bonding is a method that connects two plasma-treated substrates by Cu–Cu metal bonding and by interlayer dielectric (ILD)–ILD oxide bonding simultaneously.</mark><sup>30</sup> <mark>However, the strict requirement of ultrahigh surface smoothness (~2 nm) across the wafer makes it very difficult to use hybrid bonding in typical LEDs having 3D structures, such as mesa-etched or microrod ones. In contrast, a TIIP/CBL LED is easily modified to have the required smoothness by simply applying standard chemical mechanical polishing (CMP).</mark> 



## **<mark>FA fabrication with or without resonant cavity</mark>** 

<mark>After fabricating the TFTs, the TFT + LED structure is adhesively bonded to a carrier substrate, and the growth substrate is removed to apply the light-flipping (upside down) procedure (Fig.</mark> **<mark>S8</mark>** <mark>). First, the monolithically integrated LED + TFT structure is attached to the carrier substrate using a special adhesive resin such as benzocyclobutene (BCB; DOW), and the Si growth wafer is removed via wafer grinding and high-speed Si deep etching of the substrate until the GaN buffer is revealed. Consecutively, the complete buffer/u-GaN/n-GaN layer area is etched to various thicknesses of the LED layer using flood-area inductively coupled plasma etching with a Cl</mark> 2 <mark>/Ar mixture. Next, the n-common electrode (Ti/Ni) is formed via a lift-off process, and GaN roughening is performed via treatment with 20% tetramethylammonium hydroxide (TMAH) solution at 60°C for 5 min. For RCFA structures, instead of TMAH roughening, an n-pair DBR (TiO</mark> 2 <mark>/SiO</mark> 2 <mark>) is deposited on top of the n- common electrode. Opening of the pad was achieved by etching the n-GaN/buffer/400-nmthick-SiO</mark> 2 <mark>/gate insulator (40-nm-thick SiO</mark> 2 <mark>+ 80-nm-thick SiN) to facilitate access of data, clock signals, and dc biases to data lines, shift registers, and V</mark> dd <mark>lines, respectively.</mark> 

<mark>The resonant cavity consists of a medium gain InGaN MQW placed between an Al p-electrode mirror and TiO</mark> 2 <mark>/SiO</mark> 2 <mark>distributed reflector (DBR), each of which is λ</mark> 0 <mark>/(4</mark> _<mark>n</mark> eff_ <mark>) thick (Fig.</mark> **<mark>S12</mark>** <mark>). Five or three DBR pairs (</mark> _<mark>R</mark>_ <mark>of 95 and 80%, respectively) should be chosen to obtain the optimal resonant light output considering the low reflectance of Al (</mark> _<mark>R</mark>_ <mark>= 90%). With 10 DBR pairs (</mark> _<mark>R</mark>_ <mark>> 99.9%), resonant light barely penetrates the DBR to obtain meaningful light output; the loss term in the Al electrode is too large even without considering cavity loss. At the cavity physical thickness (𝐿</mark> 𝑐𝐿 **𝑐** 𝑣𝑣𝑐 **𝑐** 𝑐𝑐 <mark>= 𝑡</mark> 𝑝𝑝−𝐺𝐺𝑐𝑐𝑁𝑁𝑡 <mark>+ spacing (Δλ</mark> mode <mark>) of 14 nm between the peaks at 456 and 442 nm. This measured value is 𝑡</mark> 𝑀𝑡 **𝑀** 𝑀𝑀 <mark>+𝑡</mark> 𝑝𝑝−𝐺𝐺𝑐𝑐𝑁𝑁𝑡 <mark>+ 𝑡</mark> 𝐼𝑡 **𝐼** 𝐼𝐼 <mark>) of 2.45 μm, the RCFA exhibits multimode resonance with mode consistent with the calculated value (14.8 nm) according to the following formulas:</mark><sup>~~39~~31</sup> 2 (a1) 𝜆𝜆0 𝛥 **𝛥** 𝑚 **𝑚** 𝑚𝑚𝑒𝑒 = 2𝑝𝑝𝑐 **𝑐** 𝑐𝑐𝑖𝑖𝑐 **𝑐** 𝐿𝐿𝑒 **𝑒** 𝑒𝑒 <mark>(a2)</mark> 1 + ) (a3) <mark>𝐿</mark> 𝑒𝐿 **𝑒** 𝑒𝑒 <mark>= 𝐿</mark> 4𝑐𝐿 � **𝑐** 𝑣𝑣𝑐 **𝑐** 𝑐𝑐 <mark>+ 𝐿</mark> 𝑝𝑝𝑒𝑒𝑝𝑝𝐿 � ~~�~~ 𝜆𝜆0 𝜆𝜆0 𝑝𝑝𝑇𝑇𝑖𝑖𝑇𝑇2+𝑝𝑝𝑆𝑆𝑖𝑖𝑇𝑇2 𝑝𝑝𝑇𝑇𝑖𝑖𝑇𝑇2+𝑝𝑝𝑆𝑆𝑖𝑖𝑇𝑇2 𝐿𝐿𝑝𝑝𝑒𝑒𝑝𝑝 = 4𝑝𝑝𝑇𝑇𝑖𝑖𝑇𝑇2 4𝑝𝑝𝑆𝑆𝑖𝑖𝑇𝑇2 𝑝𝑝𝑇𝑇𝑖𝑖𝑇𝑇2−𝑝𝑝𝑆𝑆𝑖𝑖𝑇𝑇2�× 𝑡 **𝑡** 𝑡𝑡ℎ(2𝑚𝑚 𝑝𝑝𝑇𝑇𝑖𝑖𝑇𝑇2−𝑝𝑝𝑆𝑆𝑖𝑖𝑇𝑇2 

<mark>where n</mark> cavity <mark>, n</mark> SiO2 <mark>, and n</mark> TiO2 <mark>are the effective refractive indices of the cavity, SiO</mark> 2 <mark>, and TiO</mark> 2 <mark>, respectively, and m is the number of pairs of DBR layers. Each mode has FWHM of ~4.8 nm, which is much smaller than the conventional value of ~20 nm. To achieve a single mode, we reduce L</mark> cavity <mark>below 0.5 μm in equation (a2), and hence increase Δλ</mark> mode <mark>above the gain emission width in equation (a3).</mark> 



## **<mark>Quantum dot color converter fabrication</mark>** 

<mark>An RGB color filter (C/F) pattern is defined by conventional photolithography using negative-type QD-containing and QD-free PRs (Fig.</mark> **<mark>S8e</mark>** <mark>).</mark><sup>32</sup> <mark>The former consists of red and green QDs with appropriate resin, solvent, TiO</mark> 2 <mark>nanoparticles (light scatterer), and photosensitizer, and the latter has the same components except QDs. The fabrication process for a QD C/C pattern begins with the polymer rib pattern, followed by three photolithography processes for red/green QD and QD-free PR patterns. Each photolithography process consists of coating, exposure, and developing steps. Then, an overcoat based on an acrylate polymer is applied for planarization followed by a SiO</mark> x <mark>N</mark> y <mark>thin film for encapsulation. A yellow PR, which cuts off unconverted blue light from InGaN LEDs, is formed on the red/green QD C/C pattern. Finally, a black matrix is formed on the yellow PR to minimize reflection and maximize the black level. An organic dielectric layer, such as SiO</mark> x <mark>N</mark> y <mark>, should be coated prior to patterning of negative photopolymers, such as QDs or a black matrix, to promote perfect patterning. Otherwise, pattern residues become serious even after harsh development. A cutoff filter for blue light should be applied in case the absorption of pixelated blue light in the QD PR is insufficient. Backside exposure of the QD PR is performed by patterned InGaN LEDs having an EL peak at 450 nm.</mark> 

<mark>The fine-patterning technique of QD C/C is essential for full-color microdisplays in AR glasses. We recently reported special backside-exposure techniques, with which a spin- or spray-coated negative QD PR layer is selectively self-exposed and crosslinked from the back side by TFT-driven blue LED arrays located beneath the QD PR layer. Our FA is suitable for the backside-exposure process because the TFT driver can be integrated prior to QD patterning (Fig.</mark> **<mark>S14a−d</mark>** <mark>). In the case of conventional front-side exposure, the QD PR is crosslinked from the top side while the bottom side is not fully crosslinked; this often results in removal of the exposed pattern during the developing process, leading to poor quality or yield in fine patterning of QD PRs thinner than 5 μm. In contrast, the backside-exposed QD layer begins crosslinking from the bottom side, which enables fine patterning with controlled PR thickness. Regardless of the initial coating thickness, the patterned thickness can be accurately modulated by the exposure dose. Screenprinted CNT paste can be patterned down to 2 μm using the backside-exposure technique while the minimum pattern size is larger than 50 μm in case of the front-exposure technique. Although patterning by exposure is in its early development stage, 2.5-μm-wide and 6.5-μmhigh QD patterns can be realized (upper panel of Fig.</mark> **<mark>S14e</mark>** <mark>). Furthermore, the pattern thickness can be modulated by the amount of exposure (lower panel of Fig.</mark> **<mark>S14e</mark>** <mark>). This indicates the feasibility of high-aspect-ratio patterning even at high resolution. The QD C/C thickness is important for complete conversion of blue into green or red light. Optimizing the</mark> 

<mark>QD content of the PR established that more than 95% color conversion can be achieved at the QD PR thickness of ~6 μm. Such a high PR thickness for light conversion is due to limited QD concentration in the PR, which is again limited by quenching among neighboring QDs via Förster resonance energy transfer (FRET). In FRET, energy transfer rapidly diminishes with increasing distance (</mark> _<mark>r</mark>_ <mark>) and is proportional to 1/</mark> _<mark>r</mark>_<sup>6</sup> <mark>. We believe the backside exposure technique is a candidate for high-resolution QD patterning above 5000 ppi.</mark> 



## **<mark>References</mark>** 

<mark>1. Choi, J. H., Zoulkarneev, A., Kim, S. I., Baik, C. W., Yang, M. H., Park, S. S., Suh, H., Kim, U. J., Son, H. B., Lee, J. S., Kim, M., Kim J. M. & Kim, K. Nearly single-crystalline GaN light-emitting diodes on amorphous glass substrates.</mark> _<mark>Nat. Photon</mark>_ <mark>. 5, 763–769 (2011).</mark> 

<mark>2. Choi, J. H., Cho, E. H., Lee, Y. S., Shim, M.- B., Ahn, H. Y., Baik, C.- W., Lee, E. H., Kim, K, Kim, T.- H., Kim, S., Cho, K.-S., Yoon, J. & Hwang, S. Fully flexible GaN light‐emitting diodes through nanovoid‐mediated transfer.</mark> _<mark>Adv. Opt. Mater</mark>_ <mark>. 2, 267-274 (2014).</mark> 

<mark>3. Ding, K., Avrutin, V., Izyumskaya, N., Özgür, Ü. & Morkoç, H. Micro-LEDs, a manufacturability perspective.</mark> _<mark>Appl. Sci</mark>_ <mark>. 9, 1206 (2019).</mark> 

<mark>4. Kang, C., Kang, S., Mun, S. et al. Monolithic integration of AlGaInP-based red and InGaN-based green LEDs via adhesive bonding for multicolor emission.</mark> _<mark>Sci</mark>_ <mark>.</mark> _<mark>Rep</mark>_ <mark>. 7, 10333 (2017).</mark> 

<mark>5. Kang, C.-M., Kong, D.-J., Shim, J.-P., Kim, S., Choi, S.-B., Lee, J.-Y., Min, J.-H., Seo, D.-J., Choi, S.-Y. & Lee, D.-S. Fabrication of a vertically-stacked passive-matrix micro-LED array structure for a dual color display.</mark> _<mark>Opt. Express</mark>_ <mark>25, 2489-2495 (2017).</mark> 

<mark>6. Yadavalli, K., Chuang, C.-L. & El-Ghoroury, H. S. Monolithic and heterogeneous integration of RGB micro-LED arrays with pixel-level optics array and CMOS image processor to enable small form-factor display applications.</mark> _<mark>Proc. SPIE 11310, Optical Architectures for Displays and Sensing in Augmented, Virtual, and Mixed Reality (AR, VR, MR)</mark>_ <mark>, 113100Z (2020).</mark> 

7. Gou, F., Hsiang E.‐L., Tan, G., Lan, Y.‐F., Tsai C.‐Y. & Wu, S.‐T. High performance color‐ <mark>converted micro‐LED displays.</mark> _<mark>J. Soc. Inf. Display</mark>_ <mark>. 27, 199–206 (2019).</mark> 

<mark>8. Na, J.-S., Hong, S.-K. & Kwon, O.-K. A 4410-ppi resolution pixel circuit for high luminance uniformity of OLEDOS microdisplays.</mark> _<mark>IEEE J. Electron Devi</mark>_ <mark>. 7, 1026 – 1032 (2019).</mark> 

<mark>9. Huang Y., Liao E., Chen R. & Wu, S.-T. Liquid-crystal-on-silicon for augmented reality displays.</mark> _<mark>Appl. Sci</mark>_ <mark>. 8, 2366 (2018).</mark> 

<mark>10. Olivier, F., Daami, A., Licitra, C. & Templier, F. Shockley-Read-Hall and Auger non-radiative recombination in GaN based LEDs: A size effect study.</mark> _<mark>Appl. Phys. Lett</mark>_ <mark>. 111, 022104 (2017). 11. Kou, J., Shen, C.-C., Shao, H., Che, J., Hou, X., Chu, C., Tian, K., Zhang, Y., Zhang, Z-H. & Kuo, H.-C. Impact of the surface recombination on InGaN/GaN-based blue micro-light emitting diodes.</mark> _<mark>Opt. Express</mark>_ <mark>27, A643-A653 (2019).</mark> 

<mark>12. Qian, F., Li, Y., Gradečak, S. et al. Multi-quantum-well nanowire heterostructures for wavelengthcontrolled lasers.</mark> _<mark>Nature Mater.</mark>_ <mark>7, 701–706 (2008).</mark> 

<mark>13. Lim, W. et al. SiO</mark> 2 <mark>nanohole arrays with high aspect ratio for InGaN/GaN nanorod-based phosphor-free white light-emitting-diodes.</mark> _<mark>J. Vac. Sci. Technol. B Nanotechnol. Microelectron. Mater. Process. Meas. Phenom</mark>_ <mark>. 34, 42204 (2016).</mark> 

<mark>14. Kum, H., Seong, H., Lim, W. et al. Wafer-scale Thermodynamically Stable GaN Nanorods via Two-Step Self-Limiting Epitaxy for Optoelectronic Applications.</mark> _<mark>Sci. Rep</mark>_ <mark>. 7, 40893 (2017).</mark> 

<mark>15. Hook, T.B., Brown, J., Cottrell, P., Adler, E., Hoyniak, D., Johnson, J. & Mann, R. Lateral ion implant straggle and mask proximity effect.</mark> _<mark>IEEE Trans. Electron Devices</mark>_ <mark>50, 1946 – 1951 (2003).</mark> 

<mark>16. Sheu,Y.-M., Su, K.-W., Yang, S.-J., Chen, H.-T., Wang, C.-C., Chen, M.-J. & Liu, S. Modeling the well-edge proximity effect in highly scaled MOSFETs.</mark> _<mark>Proceedings of the IEEE 2005 Custom Integrated Circuits Conference, San Jose, CA, USA</mark>_ <mark>(2005). DOI: 10.1109/CICC.2005.1568798</mark> 

<mark>17. I. Polishchuk, N. Mathur, C. Sandstrom, P. Manos, O. Pohland . Minimization of well-proximity effect by means of 2D and 3D Monte Carlo simulation of retrograde well implantation.</mark> _<mark>ISSM 2005, IEEE International Symposium on Semiconductor Manufacturing, San Jose, CA, USA</mark>_ <mark>(2005). DOI: 10.1109/ISSM.2005.151333320.</mark> 

<mark>18. Lulli, G. Two-dimensional simulation of undermask penetration in 4H-SiC implanted with Al+ ions. IEEE T Electron Dev. 58, 190-194 (2011).</mark> 

<mark>19. Lazar, M., Laariedh, F., Cremillieu, P., Planson, D. & Leclercq, J.-L. The channeling effect of Al and N ion implantation in 4H–SiC during JFET integrated device processing.</mark> _<mark>Nuclear Instruments and Methods in Physics Research Section B: Beam Interactions with Materials and Atoms</mark>_ <mark>. 365, 256259 (2015).</mark> 

<mark>20. Müting, J., Bobal,V., Azarov, A., Svensson, B. G. & Grossner, U. Lateral straggling of ion implantation distributions in 4H-SiC investigated by SIMS.</mark> _<mark>Materials Science Forum</mark>_ <mark>, 963, 437, (2019).</mark> 

<mark>21. Müting, J., Bobal, V., Sky, T. N., Vines, L. & Grossner, U. Lateral straggling of implanted aluminum in 4H-SiC.</mark> _<mark>Appl. Phys. Lett</mark>_ <mark>. 116, 012101 (2020).</mark> 

<mark>22. Majid, A., Zhu, J. J., Rana, U. A. & Khan, S. U.-D. Resonant Raman scattering study of V, Cr and Co ions implanted into GaN.</mark> _<mark>RSC Adv</mark>_ <mark>. 6, 73589-73594 (2016).</mark> 

<mark>23. Kucheyev, S. O., Toth, M., Phillips, M. R., Williams, J. S., Jagadish, C. & Li, G. Cathodoluminescence depth profiling of ion-implanted GaN.</mark> _<mark>Appl. Phys. Lett</mark>_ <mark>. 78, 34-36 (2001).</mark> 

<mark>24. Slotte, J., Saarinen, K., Janson, M. S., Hallén, A., Kuznetsov, A. Y., Svensson, B. G., WongLeung, J. & Jagadish, C. Fluence, flux, and implantation temperature dependence of ion-implantationinduced defect production in 4H–SiC.</mark> _<mark>J. Appl. Phys.</mark>_ <mark>97, 033513 (2005).</mark> 

<mark>25. Kucheyev, O. J., Williams, S., Jagadish, C., Zou, J. & Li, G. Surface disordering and nitrogen loss in GaN under ion bombardment.</mark> _<mark>Phys. Rev</mark>_ <mark>.</mark> _<mark>B</mark>_ <mark>62, 7510-7522 (2000).</mark> 

<mark>26. Tan, W. S., The future of microled displays using next-generation technologies. Idtechex USA, Santa Clara Convention Center, CA, USA (2019).</mark> 

<mark>27. Yole Development, yearly report, http://www.yole.fr/Reports.aspx (2017).</mark> 

<mark>28. Liu, Z., Ma, J., Huang, T., Liu, C. & Lau, K. M., Selective epitaxial growth of monolithically integrated GaN-based light emitting diodes with AlGaN/GaN driving transistors.</mark> _<mark>Appl. Phys. Lett.</mark>_ <mark>104, 091103 (2014).</mark> 

<mark>29. Hwang, I., Kim, J., Choi, H. S., Choi. H. et al. p-gan gate HEMTS with tungsten gate metal for high threshold voltage and low gate current. IEEE Electron Dev. Lett. 34, 202-204 (2013).</mark> 

<mark>30. Ramm, P., Lu, J. J.-Q. & Taklo, M. M. V. Handbook of Wafer Bonding (2012).</mark> 

<mark>31. Kim, J.-H., Lee, S.-J. & Park, S.-H. InGaN-based resonant-cavity light-emitting diodes with a ZrO</mark> 2 <mark>/SiO</mark> 2 <mark>distributed bragg reflector and metal reflector.</mark> _<mark>Jpn. J Appl Phys</mark>_ <mark>. 49, 12R (2010).</mark> 

<mark>32. Won, Y., Cho, O., Kim, T. et al. Highly efficient and stable InP/ZnSe/ZnS quantum dot lightemitting diodes.</mark> _<mark>Nature</mark>_ <mark>575, 634–638 (2019).</mark> 

## **<mark>Acknowledgements</mark>** 

<mark>We thank J. L. for the 2D SIMS analysis of implanted profiles and useful discussions. This work was supported by the National Research Foundation of Korea (NRF) grant funded by the Korea government (MSIT) (No. 2017R1A2B3011629 and No. 2020R1A5A6017701).</mark> 

## **<mark>Author contributions</mark>** 

<mark>J. P. performed the main IIP experiment and characterization. J. H. C. designed the experiment and wrote the manuscript. K. K. designed the pixel-driving circuitry. J. H. H., J. H. P, N. K., E. L., D. K., J. K., and D. C. fabricated and characterized the EL devices. M. K. guided the theoretical investigations and edited the manuscript. E. Y. guided the experimental investigations. J. S. and S. H. designed the project. All authors provided feedback.</mark> 

## **<mark>Competing interests</mark>** 

<mark>The authors declare no competing interests.</mark> 

## **<mark>Additional information</mark>** 

<mark>Supplementary information is available for this paper at https://doi.org/10.1038/sxxx. Correspondence and requests for materials should be addressed to J. H. C.</mark> 

## **<mark>Author notes</mark>** 

<mark>J. P. and J. H. C. contributed equally to this work.</mark> 



## **<mark>Figure captions</mark>** 

**<mark>Fig. 1. Schematic illustrations of submicron pixelation of InGaN LEDs by mesa etching and ion implantation. a</mark>** <mark>, (left) Mesa-etched three-dimensional structure. Inset: corresponding atomic arrangement of multiple quantum wells (MQWs) with sidewall surface defects working as abundant nonradiative recombination centers. (right) Luminance weakens with decreasing pixel size.</mark> **<mark>b</mark>** <mark>and</mark> **<mark>c</mark>** <mark>, Ion-implanted two-dimensional structure.</mark> **<mark>b</mark>** <mark>, (left) Imperfect pixelation (non-TIIP) parameters resulting in significant ion scattering and lateral channeling to create some point defects at MQWs below the photoresist (PR) mask. (right) Luminance is also weak at small-sized pixels.</mark> **<mark>c</mark>** <mark>, (left) Tailored or optimized pixelation parameters yielding minimized lateral damage below the PR mask. (right) Luminance is strong even at the submicron pixel size.</mark> **<mark>d</mark>** <mark>, Lateral penetration of implanted ions below the mask via ion scattering at the edge of implantation mask and lateral channeling.</mark> **<mark>e</mark>** <mark>, Generation of vacancies depending on the implantation temperature; fewer vacancies lead to luminance quenching of MQWs.</mark> 

**<mark>Fig. 2. Characterization of defects induced by ion implantation.</mark>** <mark>Spatial two-dimensional secondary ion mass spectrometry profiles of As</mark><sup>+</sup> <mark>under the non-TIIP condition (</mark> **<mark>a</mark>** <mark>) and TIIP condition (</mark> **<mark>b</mark>** <mark>).</mark> **<mark>c</mark>** <mark>, X-ray diffraction 2θ peaks and</mark> **<mark>d</mark>** <mark>, deep-level transient spectroscopy data from –2.5 to 3 V. Implantation conditions (ion/tilt angle/ion energy/dose):</mark> **<mark>a</mark>** <mark>, As</mark><sup>+</sup> <mark>/7°/11 keV/1 × 10</mark><sup>16</sup> <mark>at cm</mark><sup>–2</sup> <mark>;</mark> **<mark>b</mark>** <mark>, As</mark><sup>+</sup> <mark>/0°/8 keV/1 × 10</mark><sup>16</sup> <mark>at cm</mark><sup>–2</sup> <mark>;</mark> **<mark>c</mark>** <mark>and</mark> **<mark>d</mark>** <mark>, As</mark><sup>+</sup> <mark>/0°/8 keV/2 × 10</mark><sup>12</sup> <mark>at cm</mark><sup>–2</sup> <mark>;</mark> **<mark>e</mark>** <mark>, As</mark><sup>+</sup> <mark>/0°/8 keV/1 × 10</mark><sup>14</sup> <mark>at cm</mark><sup>–2</sup> <mark>.</mark> 

**Fig. 3. Detailed comparison between TIIP and mesa pixelation. a** , Photoluminescence (PL) microscopy images of different high-density pixel sizes (4800, 6600, and 8500 ppi). **b** , The special PL pattern including eight subpixel sizes ranging from 300 to 8500 ppi. (inset) Magnified images of the dotted rectangles. **c** , Cathodoluminescence spectra of (left) mesa and (right) TIIP pixelation at 300 and 8500 ppi. **d** , Current density–luminescence curves of (left) mesa and (right) TIIP pixelation. Inset: The electroluminescence (EL) pattern of the special PL pattern in **a** is reproduced to the EL pattern only in TIIP pixelation. 



**<mark>Fig. 4. TCAD simulation results of mesa (a–c) and IIP pixelation (d, e)</mark>** **~~<mark>.</mark>~~** **<mark>a</mark>** <mark>, Total current density contours at 12,000 ppi. Lower panel is a magnified view of the dotted rectangle in the upper panel.</mark> **<mark>b</mark>** <mark>, Radiative recombination rates of the first quantum well in the right panel of Fig.</mark> **<mark>S5a</mark>** <mark>at (upper) 300 ppi and (lower) 12,000 ppi. In</mark> **<mark>a</mark>** <mark>, the 12,000 ppi contour is marked for comparison.</mark> **<mark>c</mark>** <mark>, Internal quantum efficiency (IQE) as a function of current density for various pixel densities with Auger recombination coefficients of (upper) 10</mark><sup>–30</sup> <mark>cm</mark><sup>6</sup> <mark>s</mark><sup>–1</sup> <mark>and (lower) 10</mark><sup>–</sup> 29 <mark>cm</mark> 6 <mark>s</mark> –1 <mark>.</mark> **<mark>d</mark>** <mark>, Contours of (upper) radiative recombination rate and (lower) total current density at the deep-level trap density of (left) 4 × 10</mark><sup>17</sup> <mark>cm</mark><sup>–3</sup> <mark>and (right) 6 × 10</mark><sup>14</sup> <mark>cm</mark><sup>–3</sup> <mark>.</mark> **<mark>e</mark>** <mark>, IQE as a function of current density for various pixel densities at the deep-level trap densities of (upper) 4 ×10</mark><sup>17</sup> <mark>cm</mark><sup>–3</sup> <mark>and (lower) 6 × 10</mark><sup>14</sup> <mark>cm</mark><sup>–3</sup> <mark>.</mark> 

**Fig. 5. Monolithic integration of TIIP-pixelated LEDs with TFTs and quantum dots. a** , Electroluminescence (EL) pixel images of the unflipped structure: 300 ppi (left) and 600 ppi RGB (right). **b** , EL of the flipped architecture: (top left) fully-on image, (top right) moving image, (bottom left) 300 ppi RGB pixel image, and (bottom right) 2000 ppi (pentile) pixel image. **c** , (left) Resonant-cavity architecture and (right) its EL spectra. **d** , Quantum dot (QD) integration of barrier rib onto 300 ppi RGB LEDs (top left), QD color converter (top-center and right) and corresponding full-color images including separate R, G, B, and moving images (bottom). 





<mark>Fig. 1.</mark> 



<mark>Fig. 2.</mark> 



<mark>Fig. 3</mark> 



<mark>Fig. 4.</mark> 



<mark>Fig. 5.</mark> 



Schematic illustrations of submicron pixelation of InGaN LEDs by mesa etching and ion implantation. a, (left) Mesa-etched three-dimensional structure. Inset: corresponding atomic arrangement of multiple quantum wells (MQWs) with sidewall surface defects working as abundant nonradiative recombination 

centers. (right) Luminance weakens with decreasing pixel size. b and c, Ion-implanted two-dimensional structure. b, (left) Imperfect pixelation (non-TIIP) parameters resulting in signi�cant ion scattering and lateral channeling to create some point defects at MQWs below the photoresist (PR) mask. (right) Luminance is also weak at small-sized pixels. c, (left) Tailored or optimized pixelation parameters yielding minimized lateral damage below the PR mask. (right) Luminance is strong even at the submicron pixel size. d, Lateral penetration of implanted ions below the mask via ion scattering at the edge of implantation mask and lateral channeling. e, Generation of vacancies depending on the implantation temperature; fewer vacancies lead to luminance quenching of MQWs. 



Characterization of defects induced by ion implantation. Spatial two-dimensional secondary ion mass spectrometry pro�les of As+ under the non-TIIP condition (a) and TIIP condition (b). c, X-ray diffraction 2θ peaks and d, deep-level transient spectroscopy data from –2.5 to 3 V. Implantation conditions (ion/tilt 

angle/ion energy/dose): a, As+/7°/11 keV/1×10^16 at cm–2; b, As+/0°/8 keV/1×10^16 at cm–2; c and d, As+/0°/8 keV/2×10^12 at cm–2; e, As+/0°/8 keV/1×10^14 at cm–2. 



Detailed comparison between TIIP and mesa pixelation. a, Photoluminescence (PL) microscopy images of different high-density pixel sizes (4800, 6600, and 8500 ppi). b, The special PL pattern including eight subpixel sizes ranging from 300 to 8500 ppi. (inset) Magni�ed images of the dotted rectangles. c, Cathodoluminescence spectra of (left) mesa and (right) TIIP pixelation at 300 and 8500 ppi. d, Current density–luminescence curves of (left) mesa and (right) TIIP pixelation. Inset: The electroluminescence (EL) pattern of the special PL pattern in a is reproduced to the EL pattern only in TIIP pixelation. 



TCAD simulation results of mesa (a–c) and IIP pixelation (d, e). a, Total current density contours at 12,000 ppi. Lower panel is a magni�ed view of the dotted rectangle in the upper panel. b, Radiative recombination rates of the �rst quantum well in the right panel of Fig. S5a at (upper) 300 ppi and (lower) 12,000 ppi. In a, the 12,000 ppi contour is marked for comparison. c, Internal quantum e�ciency (IQE) as a function of current density for various pixel densities with Auger recombination coe�cients of (upper) 10–30 cm6 s–1 and (lower) 10–29 cm6 s–1. d, Contours of (upper) radiative recombination rate and (lower) total current density at the deep-level trap density of (left) 4 × 1017 cm–3 and (right) 6 × 1014 cm–3. e, IQE as a function of current density for various pixel densities at the deep-level trap densities of (upper) 4 ×1017 cm–3 and (lower) 6 × 1014 cm–3. 



Monolithic integration of TIIP-pixelated LEDs with TFTs and quantum dots. a, Electroluminescence (EL) pixel images of the un�ipped structure: 300 ppi (left) and 600 ppi RGB (right). b, EL of the �ipped architecture: (top left) fully-on image, (top right) moving image, (bottom left) 300 ppi RGB pixel image, and (bottom right) 2000 ppi (pentile) pixel image. c, (left) Resonant-cavity architecture and (right) its EL spectra. d, Quantum dot (QD) integration of barrier rib onto 300 ppi RGB LEDs (top left), QD color converter (top-center and right) and corresponding full-color images including separate R, G, B, and moving images (bottom). 

This is a list of supplementary �les associated with this preprint. Click to download. 

mov1300ppimono.mp4 mov2300ppimono.mp4 mov32000ppimono1.mp4 

SITIIP.docx 

