# Functional Carbon Nitride Materials in Photo‐Fenton‐Like Catalysis for Environmental Remediation

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 267 |
| 作者 | Jing-Kai Lin, Wen-Jie Tian, Zhe-Yu Guan, Huayang Zhang, Xiao-Guang Duan, Hao Wang, Hong-Qi Sun, Yan-Feng Fang et al. |
| DOI | 10.1002/adfm.202201743 |
| 源文件 | 028_Lin_2022_Functional-Carbon-Nitride-Materials-in-PhotoFent.pdf |

---
**Review** 

**www.afm-journal.de** 



# **Functional Carbon Nitride Materials in Photo-Fenton-Like Catalysis for Environmental Remediation** 

_Jingkai Lin, Wenjie Tian, Zheyu Guan, Huayang Zhang,* Xiaoguang Duan, Hao Wang, Hongqi Sun, Yanfen Fang, Yingping Huang, and Shaobin Wang*_ 

Advanced oxidation processes (AOPs) are appealing treatment options for oxidation and mineralization of recalcitrant and toxic organic pollutants under ambient conditions.<sup>[4,5]</sup> AOPs, including ozone-, Fenton-, and persulfate-based systems, yield highly reactive oxygen species (ROS) through the activation of stable precursors, such as O3, H2O2, and peroxymonosulfate/peroxydisulfate.<sup>[6,7]</sup> Since Henry J. Fenton first introduced the Fenton process in 1894,<sup>[8]</sup> this technique has been developed to treat target POPs in water. A traditional Fenton reaction involves H2O2 and iron salt as the reagents to produce oxidizing hydroxyl radical (<sup>•</sup> OH) for decomposition of various POPs into nontoxic compounds.<sup>[1,8]</sup> However, low activation efficiency and high usage of H2O2 remain challenging in practical applications. Recent advances have been achieved to improve the conventional Fenton process by maximizing the activation efficiency of H2O2, including additional inputs of light,<sup>[9]</sup> electricity,<sup>[10]</sup> and ultrasound.<sup>[11]</sup> Applying light irradiation to the Fenton reaction system establishes a promising photo-Fenton method with enhanced efficiency.<sup>[12]</sup> However, homo- 

**Among various advanced oxidation processes, coupled photocatalysis and heterogeneous Fenton-like catalysis (known as photo-Fenton-like catalysis) to generate highly reactive species for environmental remediation has attracted wide interests. As an emerging metal-free photocatalyst, graphitic carbon nitride (g-C3N4, CN) has been recently recognized as a promising candidate to catalyze robustly heterogeneous photo-Fenton-like reactions for wastewater remediation. This review summarizes recent progress in fabricating various types of CN-based catalysts for the photo-Fenton-like reaction process. Innovative engineering strategies on the CN matrix are outlined, ranging from morphology control, defect engineering, nonmetal atom doping, organic molecule doping to modification by metal-containing species. The photo-Fenton-like catalytic activities of CN loaded with auxiliary sub-nanoscale (e.g., quantum dots, organometallic molecules, metal cations, and single atom metals) and nanoscale metal-based materials are critically evaluated. Hybridization of CN with bandgap-matching semiconductors for the construction of type-II and Z-scheme heterojunctions are also examined. The critical factors (e.g., morphology, dimensionality, light absorption, charge excitation/migration, catalytic sites, H2O2 generation and activation) that determine the performance of CN-based photocatalysts in Fenton-like catalysis are systematically discussed. After examining the structure–activity relationship, research perspectives are proposed for further development of CN-based photocatalysts toward more efficient photoFenton-like reactions and their application in practical water treatment.** 

geneous Fenton processes possess inherent drawbacks due to the harsh acidic condition and generation of iron waste.<sup>[13]</sup> Modified techniques, known as Fenton-like processes, then emerged using heterogeneous catalysts other than iron salt and H2O2 (external addition or in situ generation).<sup>[14,15]</sup> In particular, heterogeneous photo-Fenton-like systems based on a 

## **1. Introduction** 

In recent decades, water contamination has raised increasing public concerns due to associated health and safety issues posed by persistent organic pollutants (POPs) (like pesticides, chemicals, and pharmaceuticals) and heavy metals in wastewaters.<sup>[1–3]</sup> 

J. Lin, W. Tian, Z. Guan, H. Zhang, X. Duan, S. Wang School of Chemical Engineering and Advanced Materials The University of Adelaide North Terrace, Adelaide, SA 5005, Australia E-mail: huayang.zhang@adelaide.edu.au; shaobin.wang@adelaide.edu.au 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202201743. 

© 2022 The Authors. Advanced Functional Materials published by WileyVCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

H. Wang Center for Future Materials University of Southern Queensland Toowoomba 4350, Australia H. Sun School of Science Edith Cowan University 270 Joondalup Drive, Joondalup, WA 6027, Australia Y. Fang, Y. Huang College of Biological and Pharmaceutical Sciences Three Gorges University Hubei 443002, P. R. China 

**DOI: 10.1002/adfm.202201743** 

**2201743 (1 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

photocatalysts/H2O2 configuration have drawn a considerable interest for environmental remediation. 

For efficient photo-Fenton-like catalysis, semiconductor (SC)-based photocatalysts have been widely studied, including metal oxides (TiO2,<sup>[16–18]</sup> ZnO,<sup>[19]</sup> WO3,<sup>[20,21]</sup> etc.), metal sulfides (CdS,<sup>[22]</sup> ZnS,<sup>[23]</sup> ), metal-organic frameworks (MOFs),<sup>[24]</sup> and graphitic carbon nitride (g-C3N4, CN).<sup>[25–27]</sup> Among them, metal-free CN has attracted an increasing focus due to its low price, chemical stability, light-harvesting ability, nontoxicity, and easily accessible synthesis,<sup>[28–30]</sup> demonstrating new possibilities of combining interfacial heterogeneous Fenton catalysis and photocatalysis. Specifically, CN is a layered polymer semiconductor with the layers packed together via the van der Waals forces.<sup>[31]</sup> It is generally recognized that a tri- _s_ -triazine unit is the typical building block of CN, constructing the _π_ -conjugated structure with sp<sup>2</sup> -hybridization of C and N.<sup>[32]</sup> With a moderate bandgap of 2.7 – 2.8 eV, CN can absorb visible light of around 450 – 460 nm.<sup>[33]</sup> In addition, CN exhibits high thermal stability (<600°C).<sup>[34]</sup> Moreover, CN shows remarkable chemical stability in organic solvents and under acidic/basic conditions, rendering it a robust photocatalyst.<sup>[35]</sup> Up till now, functional carbon nitride has been employed in wide solar-driven applications, such as air purification,<sup>[36,37]</sup> energy conversion<sup>[38–40]</sup> and storage.<sup>[41,42]</sup> For examples, CN nanosheets were used for efficient photocatalytic NO removal<sup>[36]</sup> and perovskite solar cells.<sup>[42]</sup> In addition, CN-based heterostructures, such as van der Waals<sup>[43]</sup> and Z-scheme<sup>[44]</sup> heterojunctions, were widely developed for photocatalytic water splitting. 

In principle, a CN-driven photo-Fenton system mainly involves three steps ( **Figure 1** a,b): i) absorption of solar energy to generate photoexcited electron-hole pairs (Equation (1)), ii) separation and migration of charge carriers to the surface of CN, and iii) surface redox reactions to produce highly oxidizing ROS. The photogenerated electrons could decompose H2O2 into<sup>•</sup> OH directly (Equation (2)). Besides, since the conduction band (CB) position of CN is more negative than the standard potential of O2/superoxide ion radical (O2<sup>•−</sup> , −0.33 eV vs NHE), electrons that migrate to the CB of CN can reduce O2 to produce O2<sup>•−</sup> (Equation (3)). Meanwhile, singlet oxygen (<sup>1</sup> O2) can be generated from O2<sup>•−</sup> and<sup>•</sup> OH (Equation (4)).<sup>[45]</sup> The valence band (VB) of CN is not sufficiently positive than that of •OH/H2O (2.73 eV vs NHE) and •OH/OH− (1.99 eV vs NHE). Therefore, holes (h<sup>+</sup> ) left on the VB of pristine CN are hard to participate in the direct oxidation of H2O or OH<sup>−</sup> to generate •OH (Equation (5)), while the electronic structure and bandgap of CN can be tuned to obtain a more favorable VB band position to enable this pathway.<sup>[20]</sup> Finally, the produced ROS (<sup>•</sup> OH, O2<sup>•−</sup> ,<sup>1</sup> O2) and h<sup>+</sup> can contribute to the efficient oxidative decomposition of POPs 



<!-- Start of picture text -->
CN + hv → CN ( h + + e − ) (1)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − + H2O2 → 2 •OH (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − + O2 → O2•− (3)<br><!-- End of picture text -->



<!-- Start of picture text -->
•OH + O•−2 → 1O2 + OH− (4)<br><!-- End of picture text -->



<!-- Start of picture text -->
h + + 2H2O/OH− → •OH (5)<br><!-- End of picture text -->

Importantly, CN is by far considered as a promising candidate for in situ generation of H2O2 for photo-Fenton-like reactions. The CB potential of CN (−1.27 V vs NHE) facilitates the reduction of O2 (−0.28 V vs NHE) to produce H2O2, while the low VB (1.4 V vs NHE) could prevent H2O2 oxidation under irradiation.<sup>[46,47]</sup> The overall H2O2 production process can be described as a photocatalytic reaction between O2 and H2O with a standard Gibbs free energy change of 117 kJ mol<sup>−1</sup> (Equation (6)) 



<!-- Start of picture text -->
O2 + 2H2O + hv → 2H2O2 (6)<br><!-- End of picture text -->

In specific, it is well accepted that H2O2 can be generated via either a two-step single-electron reduction reaction (O2 → O2<sup>•−</sup> → H2O2) or a single-step two-electron one (O2 → H2O2).<sup>[46]</sup> The two-step single-electron reduction reaction occurs where photoinduced electrons on the CB of a SC could react with the surface adsorbed O2 to generate O2<sup>•−</sup> (Equation (3)). Meanwhile, O2 could also react with H<sup>+</sup> to produce HO2<sup>•−</sup> (Equation (7)). According to Equation (8), HO2<sup>•−</sup> can be readily reduced to produce HO2<sup>−</sup> via another single-electron reduction process. Finally, H2O2 can be generated via the reaction between HO2<sup>−</sup> and H<sup>+</sup> (Equation (9)). In another photocatalytic H2O2 production route, H2O2 can be generated through a two-electron O2 reduction pathway (Equation (10)) 



<!-- Start of picture text -->
O2 + H+ → HO2•− (7)<br><!-- End of picture text -->



<!-- Start of picture text -->
HO•2− + e − → HO2− (8)<br><!-- End of picture text -->



<!-- Start of picture text -->
HO2− + H+ → H2O2 (9)<br><!-- End of picture text -->



<!-- Start of picture text -->
O2 + 2 e − + 2H+ → H2O2 (10)<br><!-- End of picture text -->

Thus, in a photo-Fenton-like process, CN allows for in situ H2O2 generation. Compared with the traditional Fenton process, the H2O2 utilization efficiency in an in situ generated H2O2-based photo-Fenton process is significantly improved.<sup>[48]</sup> Although the yield of H2O2 might be low,<sup>[49]</sup> it helps address the practical limitation of high H2O2 usage in large-scale applications. However, pristine CN still suffers from several drawbacks in practical photo-Fenton-like catalysis due to rapid charge recombination, poor electrical conductivity, a low specific surface area (SSA), and inadequate light absorption. In addressing these limitations, various chemical and physical modifications have been made on CN to improve visible-light harvesting, photoexcitation/separation of electron-hole pairs, and photoFenton-like catalysis (Figure 1b). 

In this review, engineering strategies of CN for photoFenton-like catalytic decomposition of POPs and heavy metal removal in water, ranging from morphology control, defect engineering, nonmetal atom doping, and organic molecule doping to metal-containing modifications, including subnanoscale species (organometallic molecules, doped metal atoms, single-atom catalysts (SACs)), nanoscale materials (zero dimension (0D), 1D, 2D, 3D) and bandgap-matching semiconductors (SCs) (Figure 1c, **Tables 1** and **2** ), were comprehen- 

**2201743 (2 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 1.** a) CN-driven photo-Fenton-like process. b) Rational design of CN-based catalysts for three photo-Fenton-catalytic stages. c) Engineering strategies for CN-based catalysts for improved photo-Fenton-like catalysis. 

sively summarized. These strategies will make CN a more competitive light-harvesting platform for the photo-Fenton-like process by well addressing three photocatalytic stages, as outlined in Figure 1b. Critical factors that determine the catalytic performance are emphasized, such as visible-light harvesting, charge photo excitation/transfer, catalytic active sites on CNbased photocatalysts, and H2O2 generation and activation. Incisive insights are provided to understand the structure–activity relationships, which will be beneficial to advancing efficient CN-based photo-Fenton-like catalysis. Ultimately, conclusive remarks and perspectives on the current research and further development directions in this field are proposed. 

## **2. Morphology Engineering** 

Effective morphology control of CN can elevate the SSA, provide more exposed active sites, improve harvesting ability of visible-light, and promote photoinduced charge separation/transfer.<sup>[32]</sup> Currently, morphology modulations of CN have been achieved in various synthetic approaches like templating,<sup>[50,51]</sup> supramolecular preorganization,<sup>[52]</sup> and exfoliation.<sup>[53]</sup> As heterogeneous catalysis occurs only on the surface of catalysts,<sup>[54–56]</sup> the enlarged SSA of CN by morphology engineering also enables an effective interface contact with POPs to benefit their degradation.<sup>[57–60]</sup> Indeed, morphology modifications of CN, such as high-dimensional porous engineering and low-dimensional nanostructure controlling, have been exhaustively explored through templating and exfoliation approaches for photo-Fenton-like catalysis ( **Figure 2** ).<sup>[61,62]</sup> 

High-dimensional porous structure engineering is a valid approach for morphology control of CN, by contributing to an 

increased SSA, facilitating light absorption and creating defects to benefit the migration of photogenerated carriers.<sup>[65,69,70]</sup> The porosity, morphology, structure, and SSA of CN can be facilely tuned using appropriate templates. Among them, silica hard templates were commonly used to control the structure and geometry of CN at nano- and micro-scales, constructing hierarchical pore architectures.<sup>[72]</sup> For example, mesoporous CN with an SSA of ≈176 m<sup>2</sup> g<sup>−1</sup> was prepared using a silica hard template method.<sup>[61]</sup> The porous structure and enlarged SSA could enhance light absorption and offer more active sites, thereby improving the photodegradation activity of POPs. Under visible light irradiation, the mesoporous CN could catalyze the photoinduced electron transfer reactions with dissolved O2 to produce O2<sup>•−</sup> . Meanwhile, H2O2 could be in situ generated as an intermediate to enable the production of<sup>•</sup> OH for visiblelight-driven degradation of 4-chlorophenol (4-CP). By comparison, nonporous CN did not yield such reactions. In another work, mesoporous CN nanospheres were fabricated using monodisperse SiO2 as a hard template.<sup>[63]</sup> The as-synthesized mesoporous CN nanospheres possessed a larger SSA and more cyano groups compared with bulk CN. The enlarged SSA exposed more catalytic active sites. The formed cyano groups due to the incomplete thermal polycondensation of cyanamide could narrow the bandgap of CN and function as the defect site to trap the photoinduced electrons, promoting the charge carriers separation. Consequently, the CN nanospheres showed enhanced BPA degradation, which is 14.7-time higher than that of bulk CN without externally added H2O2. 

Hard templating has uncovered opportunities for modifying CN morphology and introducing porosity.<sup>[73]</sup> However, this approach is time-consuming and troubled by the complex removal of inorganic templates. Other synthesis methods, 

**2201743 (3 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

|Degradation<br>efficiency<br>Ref.||100%<br>[61]|100%<br>[63]|100%<br>[62]|99.8%<br>[64]|83.23%<br>[65]||99.7%<br>[66]|100%<br>[67]||100%<br>[68]|97.4%<br>[69]|≈40%<br>[48]|81%<br>[70]||99%<br>[71]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|]<br>Main active<br>species||1<br>•OH, O2•−|•OH, O2•−|•OH, O2•−, h+|•OH|•OH, O2•−, h+||•OH, O2•−, h+|•OH, O2•−, h+||1<br>n.m. (not<br>mentioned)|•OH, O2•−,<br>1O2, h+|•OH|•OH, O2•−, h+||•OH, O2•−|
|Pollution<br>dose [mg L−1||0.12 mmol L−|10|125|2|10||100µmol L−1|50||0.02 mmol L−|10|20|10||10|
|H2O2dose||–|–|–|–|–||–|–||–|–|67µmol L−1|–||–|
|<br>Metal ions<br>(salts)||–|–|FeCl3|–|–||–|–||FeCl3|–|FeSO4•7H2O|–||–|
|Catalysts dose<br>[g L−1]||0.5|0.2|1|0.3|0.02||0.5|3||0.6|1|1|1||0.5|
|Targeted<br>reactants||4-CP|BPA|RhB|BPA|SDZ||SMZ|AMX||RhB|-mercaptoben-<br>zothiazole|2,4-DCP|SMZ||SMZ|
|Irradiation time<br>[min]||60|60|120|90|90||60|2880||50|20<br>2|60|60||60|
|Light source||300 W xenon lamp<br>(_λ_ >420 nm)|xenon lamp<br>(_λ_ >400 nm)|300 W xenon lamp|300 W xenon lam|300 W xenon lamp<br>(_λ_ >420 nm)||300 W xenon lamp<br>(_λ_ >420 nm)|150 W LED||300 W xenon lamp<br>(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)|500 W xenon lamp<br>(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)||300 W xenon lamp<br>(_λ_ >420 nm)|
|Synthesis method||Silica template method|Silica template method|H2SO4inserted thermal<br>decomposition|Calcination, acid, and<br>ultrasonication|Two-step thermal treatment||Copolymerization|Thermal polymerization of<br>thiourea and/or melamine||Photo-Fenton assisted<br>Thermal polymerization|Acylation method|Two-step thermal<br>polymerization|One-step copolymerization|g|Thermal-induced exfoliation<br>and polymerization|
|Photocatalyst|Morphology control|Mesoporous CN|Mesoporous CN<br>nanospheres|Layered CN|Oxygen rich exfoliated<br>CN|Cv-CNNs|Defect engineering|LCN|Structural defect-<br>polymeric CN|Nonmetal atom doping|O-doped holey CN|O-bridge porous<br>defect-CN|P-doped CN|ACCN|Organic molecule dopin|PCN-DP|



**2201743 (4 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

|Ref.|[106]|[107]|[108]|[109]||[110]||[111]|[112]||[113]|[114]|[115]||[116]|[117]||[118]|[119]||[104]|[120]|[45]||[121]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Performance<br>(Efficiency)|90%|100%|96.95%|95.5%||≈100%||99.90%|95.00%||80%|≈100%|98.90%||98.80%|≈100%||100%|88%||100%|≈100%|96.50%||99%|
|Main active<br>species|•OH|•OH|•OH|•OH, O2•−||•OH||•OH, O2•−|•OH||•OH,1O2|•OH, h+|•OH||•OH|•OH, O2•−||•OH, O2•−, h+|•OH, O2•−, h+||•OH|•OH|•OH, O2•−,1O2||•OH, O2•−, h+|
|Pollution dose<br>[mg L−1]|10|50|20|10||50||10|10||100|10|200||10|50||20|20||10|40|20||–|
|e<br>H2O2dose|3 g L−1|0.2 mL (30 wt%) in<br>50 mL|50 mmol L−1|1.5 mmol L−1||150µL (30 wt%) in<br>|30 mL|–|196 mmol L−1||50 mmol L−1|80 mmol L−1|400µL (30 wt%) in<br>|50 mL|0.5 mL (30 wt%) in<br>50 mL|0.4 mmol mL−1||15 mmol L−1|50 mmol L−1||30 mmol L−1|5 mmol|<br>50µL (30 wt%) in|50 mL|–|
|Catalysts dos<br>[g L−1]|0.5|0.5|0.5|0.2||2||1|0.4||0.4|0.4|0.5||0.2|4||0.5|0.2||–|50 mg|<br>1||0.3|
|Targeted<br>reactants|RhB|MB|MB|RhB||RhB||RhB|RhB||Aniline|MB|MB||BPA|MO||PNP|TC||MB|SSA|TCH||RhB|
|Irradiation time<br>[min]|60|50|30|45||100||200|10||360|60|11||70|60||10|60||–|35|18||80|
|Light source|150 W xenon lamp<br>(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)|150 W xenon lamp|300 W xenon lamp<br>|(_λ_ >420 nm)|500 W xenon lamp<br>|(_λ_ >420 nm)|500 W xenon lamp<br>(_λ_ >420 nm)|Halogen tungsten lamp|(_λ_ >410 nm)|48 W LED|400 W xenon-HID lamp<br>(_λ_>420 nm)|300 W xenon lamp<br>|(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)|500 W xenon lamp|(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)|<br>300 W xenon lamp<br>|(780 nm>_λ_ >420 nm)|Solar light|300 W xenon lamp|<br>500 W xenon lamp|(_λ_ >420 nm)|100 W (_λ_ >400 nm)|
|Synthesis method<br>oping|Schiff base reaction|Annealing|Annealing|Two-step calcination thermal<br>|polymerization|Bottom-up synthesis method||Thermal condensation method|One-step thermal polycondensation|and impregnation method|Annealing|Pyrolysis|ing<br>Pyrolysis||Self-assembly and calcination|aterials loading<br>Thermal polymerization method|and ultrasonic dispersion method|Low-temperature calcination|Revised coprecipitation method||Self-assembly method|Thermal-polymerization|Self-assembly method||In situ hydrothermal method|
|Photocatalyst<br>Organometallic molecule d|Ferrocene-functionalized<br>CN|Metal cations doping<br>Fe-doped CN|Fe-doped CN|Fe-doped CN||Fe-doped layered and<br>|porous CN|Fe-doped alkalized CN|Cu-doped alkalized CN<br>||Fe, Cu-codoped g- CN|Fe doped CN/CF|Single metal atoms anchor<br>I-FeN_x_/CN||SA-Cr/PN-CN|Nanoscale metal-based m<br>0D/2D FeOOH/CN||0D/2D Fe2O3/CN|0D/2D FeOOH/CN||0D/2D Fe-POMs/U- CN|0D/2D Fe-POMs/O-CN -U|<br>0D/2D Fe-POMs/|CNNS-Nvac|1D/2D ZnWO4/CN|



**2201743 (5 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

|Ref.|[122]|[123]|[124]|[125]|[126]|[127]|[128]|[129]|[20]|[130]||[131]||[132]||[133]|[134]||[135]||[136]||[137]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Performance<br>(Efficiency)|90.4%|90%|97%|98%|>90%|≈100%|–|≈100%|90%|97%||90%||94%||93.40%|LED: 90%; Sun-|light: 99.5%|97%||85.80%||≈99%|
|Main active<br>species|O2•−, h+|•OH, O2•−|•OH, h+|1O2, O2•−, h+|•OH|•OH|•OH|•OH, O2•−, h+|•OH|•OH, O2•−, h||•OH, O2•−, h||•OH||•OH, h|•OH||•OH||•OH, O2•−, h+||•OH, h+|
|Pollution dose<br>[mg L−1]|–|30|–|0.03 mmol L−1|10|10|4 uL|50|10|10||0.028 mmol L−1||0.4 mmol L−1||10|20||10||<br>10||L<br>10|
|H2O2dose|–|–|–|1 mL in 50 mL|11.4 mmol L−1|1.6 mmol L−1|1.6 mmol L−1|0.1 mL|0.005 mol L−1|0.1 mol L−1||0.01 mol L−1||15 mmol L−1||0.1 mol L−1|1 mL (30 wt%)|in 50 mL|1 mL (30 wt%)<br>|in 50 mL|0.5 mL (30 wt%)|in 70 mL|1 mL H2O2<br>(30 wt%) in 50 m|
|Catalysts dose<br>[g L−1]|0.1|0.4|0.4|1|0.5|0.75|6.67|–|0.17|0.5||0.1||0.5||0.2|0.5||0.5||1||0.4|
|Targeted<br>reactants|OFX|TC|RhB|Amaranth dye|RhB|Dicamba|pUC18 and<br>pBR322|Orange II|PNP|Orange II||Orange II||Guaiacol||RhB|MB||TC||RhB||RhB|
|rradiation time<br>[min]|70|60|180|10|60|180|45|60|240|240||180||60||30|60||60||40||40|
|Light source<br>I|150 mW cm–2tungsten lamp|300 W xenon lamp<br>(_λ_ >420 nm)|2×45 W LED|300 W xenon lamp<br>(_λ_ >420 nm)|_Λ_ >400 nm|3D printed photon concen-<br>trator with 2×100 W LED|100 W LED|500 W xenon lamp<br>(_λ_ >420 nm)|300 W xenon lamp<br>(_λ_ >420 nm)|<br>500 W xenon lamp<br>|(_λ_ >420 nm)|500 W xenon lamp|(_λ_ >420 nm)|500 W halogen lamp<br>|(_λ_ >420 nm)|9 W LED lamp|LED and Sunlight||40 W LED (_λ_ >400 nm)||Vis||500 W xenon lamp<br>(_λ_ >410 nm)|
|Synthesis method|Hydrothermal and ultrasonication<br>method|Solvothermal method|Thermal polymerization and<br>hydrothermal method|Solvothermal method<br>ction|Electrostatic self-assembly method|Calcination|Calcination|Hydrothermal method|Calcination|Reflux treatment||Self-assembly method||Hydrothermal method||Template free chemical co-precipita-<br>tion method|Sol–gel followed calcination method||Hydrothermal method||Calcination||Hydrothermal method.|
|Photocatalyst|1D/2D MnWO4/CN|2D/2D_δ_-Bi2O3/CN|2D/2D N-ZnO/CN|3D/2D Fe2O3/CN<br>Heterojunctions constru|Type-II heterojunctions<br>Fe3O4/CN|Fe-CN|Iron oxide/rGO/CN|CN/_α_-Fe2O3/Fe3O4|Fe-doped CN/WO3|ZnFe2O4/CN||CuFe2O4/CN||BiFeO3/CN||ZnFe2O4/CN|ZnFe2O4/CN||NiFe2O4/CN||BaFe12O19/CN||Cu2(OH)PO4/CN|



**2201743 (6 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

|Performance<br>(Efficiency)<br>Ref.|96.00%<br>[138]|2,6-DCP: 98.7;<br>2,4,5-TCP: 97.3%<br>[139]||92%<br>[140]|96%<br>[49]|100%<br>[141]|99%<br>[142]|90%<br>[143]|≈100%<br>[144]||97.40%<br>[145]|MB: 100%;<br>RhB: 92%<br>[146]|100%<br>[147]|Cr: 85%;<br>2,4-D: 50%<br>[148]|≈90%<br>[149]|RhB: 99%;<br>TCN:93%<br>[150]|100%<br>[151]||RhB: 99.85%<br>[152]|and TCH: 83.68%<br>|<br>98%<br>[153]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|<br>Main active<br>species|•OH, O2•−, h+|•OH||•OH, O2•−, h+|•OH, O2•−, h+|•OH, O2•−|•OH, O2•−, h+|•OH, O2•−, h+|•OH, O2•−, h+|•|OH|•OH, O2•−|•OH, O2•−|•OH, O2•−, h+|•OH, O2•−|•OH, O2•−|•OH||•OH, O2•−, h+||•OH, O2•−|
|Pollution dose<br>[mg L−1]|10|10||40|10|10|0.1 mmol L−1|10|10||10|<br>20|60µmol L−1|10 and 100|5|<br>20|30||10||10|
|<br>H2O2dose|1 mmol L−1|–||10 mmol L−1|–|1 mmol L−1|0.1 mmol L−1|200µL in 100 mL|0.1 mol L−1||0.5 mL in 100 mL|1 mL (30 wt%) in<br>100 mL|–|–|–|1 mL (30 wt%) in<br>100 mL|100µL in 50 mL||8 mol L−1||1 mmol L−1|
|Catalysts dose<br>[g L−1]|0.8|1||0.5|1|1.4|0.4|0.2|0.1||0.5|0.5|1|0.4|0.5|0.5|1||0.1||0.3|
|e<br>Targeted<br>reactants<br>|PNP|2,6-DCP and<br>2,4,5-TCP||TC|RhB|MB|DMP|RhB|RhB|h|RB|MB and RhB|Cr(VI) and<br>As(III)|Cr(VI) and 2,4-D|AO-7|RhB and TCN|MB||RhB and TCH||RhB|
|Irradiation tim<br>[min]|120|180||60|90|75|120|60|210||120|35|100 and 80|180|180|120|120||30 and 45||40|
|Light source|500 W xenon lamp|300 W xenon lamp||100 W xenon lamp<br>(_λ_ =420 nm)|300 W xenon lamp|UV lamp (254 nm, 6 W)|Vis|300 W xenon lamp (_λ_ ><br>400 nm)|36 W||200 W|Sunlight|Vis|500 W xenon lamp|300 W xenon lamp|40 W LED|500 W xenon lamp (_λ_ >|420 nm)|500 W xenon lamp||500 W xenon lamp (_λ_ ><br>420 nm)|
|Synthesis method|Microwave hydro- thermal method.|Self-assembly method|unctions|Calcination|Impregnation–solvothermal<br>method|Hydrothermal and chemical vapor<br>deposition on FTO glass|<br>Calcination|Calcination|Self-assembly method|l h|Mixing–cacining metod|Sol–gel followed calcination method|Hydrothermal method|Hydrothermal method|ojunctions<br>Hydrothermal method|Wet chemical method|Solvothermal method||Hydrothermal method||Electrostatic self-assembly method|
|Photocatalyst|Zn0.94Fe0.04S/CN|M101-U6|Direct Z-scheme heteroj|_α_-Fe2O3/CN|_α_-Fe2O3/CN|_α_-Fe2O3/CN|CN/CuO|CN/FeOCl|CoFe2O4/CN||CN/LaFeO3|ZnFe2O4/CN|ZnFe2O4/CN|Co9S8/CN|Indirect Z-scheme heter<br>CN/CNT/Bi2Fe4O9|NiFe2O4/CD/CN|Other heterojunctions<br>NH2-MIL-88B(Fe)/CN||Bi2WO6/BiFeO3/CN||Fe3O4/diatomite/CN|



**2201743 (7 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 2.** Morphology and dimensionality control techniques of CN for photo-Fenton-like catalysis. 

such as soft templating,<sup>[74,75]</sup> could be an alternative strategy to enlarge the SSA and achieve porous CN. Compared with the hard template method, the soft-templating method is a relatively straightforward preparation process, and the templates can be self-removed during the synthesis process, while its formation is highly sensitive to the reaction conditions.<sup>[76]</sup> For both hard- and soft-templating methods, the ratio of a precursor to the template, surface properties of the template and precursor (e.g., surface electronegativity, hydrophilic, and viscosity) are critical for developing well-controlled porous nanomaterials.<sup>[77]</sup> For the hard-templating method, insufficient immersion of the precursor in the template interspace may directly cause the discontinuity of the ordered structure and eventually lead to partial collapse of the ordered structure after removing the template.<sup>[76]</sup> 

Engineering low-dimensional morphology can help increase SSA, shorten the diffusion length of light-induced charge carriers, and reduce their recombination.<sup>[28,78]</sup> Thermal exfoliation can tune the physicochemical properties of CN and produce thin-layer nanosheets.<sup>[62,79]</sup> Li et al.<sup>[62]</sup> reported thermally exfoliated (TE) CN for photo-Fenton-like degradation of Rhodamine B (RhB) with in situ H2O2 generation. By treating a CN precursor with H2SO4 before thermo-decomposition, layered CN was produced with an SSA of 59.1 m<sup>2</sup> g<sup>−1</sup> and pore volume of 0.3 cm<sup>3</sup> g<sup>−1</sup> . This structural benefit provided CN with abundant reaction sites, enhanced light-harvesting capability, and better charge separation efficiency. Under visible light irradiation, O2 was reduced via a two-electron reduction process to generate H2O2, which can be activated to produce<sup>•</sup> OH. It is noteworthy that the enhanced photo-Fenton performance was mainly attributed to the intrinsic photocatalytic activity of TE-CN and that the photoexcited holes play a dominant role in the photo-Fenton-like RhB degradation. In another exfoliation route, bulk CN can be treated with an acid and ultrasonication to produce separated thin layers of CN.<sup>[64]</sup> In this situation, van der Waals interactions between CN layers are broken. The infiltration of oxygen within the layers reached 2.5%, and the SSA was increased to 34.06 m<sup>2</sup> g<sup>−1</sup> against the original CN sample (3.06 m<sup>2</sup> g<sup>−1</sup> ), leading to enhanced absorption of visible light and exposure of more surface active sites for bisphenol A (BPA) degradation without external H2O2. However, engineering low dimensional CN by thermal, ultrasonic, and chemical exfoliation could damage the CN structure and the synthesis process could be harmful to the environment. In addition, these top-down synthetic routes also have drawbacks of using high-quality bulk CN as a precursor, complicated and 

time-consuming fabrication process. In comparison, a bottomup strategy such as molecular self-assembly synthesis could be an alternative green route to achieve low-dimensional CN.<sup>[80]</sup> 

Combining porous structure and low-dimensional morphology design can further improve the catalytic ability of CN.<sup>[81]</sup> Liu et al.<sup>[65]</sup> developed porous ultrathin CN nanosheets with rich in-plane holes and carbon vacancies (Cv-CNNs) via a thermal treatment by NH4Cl under NH3 ( **Figure 3** a). Owing to the rich in-plane holes and ultrathin structure (0.434–0.562 nm, theoretical 0.325 nm) from deep exfoliation (Figure 3b), Cv-CNNs possessed an SSA of 77.72 m<sup>2</sup> g<sup>−1</sup> compared with bulk CN (10.05 m<sup>2</sup> g<sup>−1</sup> ). The enlarged SSA can increase the number of reactive sites, enhance the adsorption capability of reactants, and accelerate mass transfer. Sulfadiazine (SDZ) was removed by 83.23% using Cv-CNNs in 90 min under visible-light-driven photodegradation (Figure 3c). In this system, H2O2 was selfgenerated via a two-step single-electron pathway. O2<sup>•−</sup> served as the critical ROS for SDZ degradation, while a limited amount of •OH was also generated from in situ formed H2O2. Meanwhile, photogenerated holes also contributed to the SDZ degradation. 

## **3. Defect Engineering** 

Defect engineering (structural defects, carbon and nitrogen vacancies) provides an effective way to optimize the photocatalytic activity of CN by regulating the C/N ratio on the periodic heptazine units, offering more reactive sites and modifying the electronic and bandgap structure to enhance optical absorption and boost charge carrier separation/transfer.<sup>[28,81,82]</sup> 

For example, CNs with a varied degree of defects were fabricated via thermal polymerization of several precursors, i.e., melamine (M), thiourea (T), and their mixture, producing CN-M, CN-T, and CN-1M:1T, respectively.<sup>[67]</sup> CN-T possessed more defects than CN-M, as indicated in TEM images (Figure 3d,e). These structural defects were formed due to the incomplete condensation of amine groups in the CN framework.<sup>[83]</sup> By controlling the degree of structure defects, the morphological, chemical, and electronic properties of CN were tuned. With the highest number of structure defects and the improved charge separation efficiency, CN-T exhibited the highest photoactivity by removing 100% amoxicillin (AMX) in 48 h under visible light irradiation (Figure 3f). However, raising the number of defects has potential drawbacks, e.g., reducing the graphitized structures in CN and therefore lowering its thermal stability.<sup>[32]</sup> 

**2201743 (8 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 3.** a) Synthesis of Cv-CNNs. b) TEM image of Cv-CNNs (inset image: pore size distribution). c) SDZ photodegradation performance (inset: first-order kinetics). Reproduced with permission.<sup>[65]</sup> Copyright 2020, Elsevier B.V. TEM images of d) CN-M and e) CN-T. f) AMX degradation under white LED lamp irradiation. Reproduced with permission.<sup>[67]</sup> Copyright 2021, Elsevier B.V. g) TEM image of LCN. h) Band structures of DCN and LCN. i) SMZ photodegradation mechanism by LCN. j) SMZ photodegradation kinetics. Reproduced with permission.<sup>[66]</sup> Copyright 2020, Elsevier B.V. 

For intrinsic defect modulation of pristine CN, engineering carbon and nitrogen vacancies on the CN framework has been commonly used.<sup>[65,66]</sup> The aforementioned example in porous structure and low-dimensional morphology engineering of CN also involved creating carbon vacancies,<sup>[65]</sup> which enhanced the SDZ adsorption and altered the band energy level for promoted degradation efficiency. The formation of carbon vacancies changed CN’s planar structure, improving SDZ adsorption capability. Moreover, the –NH2 groups around carbon vacancies could act as hole stabilizers to prolong the lifetime of photoinduced holes. Zhou et al.<sup>[66]</sup> conducted copolymerization of dicyandiamide and L-cysteine to fabricate CN (LCN) (Figure 3g). When calcining the complex precursors, L-cysteine was decomposed to NH3, CO2, and SO2 to accelerate the 

morphology change and structure distortion, inducing the formation of nitrogen vacancies and disordered CN structures. Compared with dicyandiamide derived CN (DCN), the incorporation of L-cysteine in the precursors created edge nitrogen vacancies, disordered structure defects, and n- _π_ * electronic transition in LCN, leading to a narrowed bandgap (Figure 3h), modified optical absorption and electronic structure, as well as more efficient charge excitation/separation/transfer. Besides, nitrogen vacancies offered surface adsorption sites for molecular O2 and facilitated photoinduced electron transfer from LCN to adsorbed O2 to generate O2<sup>•−</sup> (Figure 3i). LCN could also activate molecular O2 in producing H2O2 and decomposing to<sup>•</sup> OH. The optimized LCN exhibited visible-light-driven sulfamethazine (SMZ) degradation of 99.7% in 1 h (Figure 3j), 

**2201743 (9 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

with the degradation rate 12 times higher than that by DCN. O2<sup>•−</sup> and holes are identified as the reactive species for SMZ photodegradation. Noticeably, the addition of excess L-cysteine would damage the intrinsic structure units of CN and cause pore collapse, affecting its photo-Fenton-like catalytic ability. 

The computational calculation revealed that defect engineering CN by introducing C or N vacancies are equally alluring as they not only enhance the visible-light absorption ability by generating defective electronic states, but also enable efficient spatial separation of photoinduced charge carriers along with superior reaction kinetics.<sup>[84,85]</sup> However, engineering vacancy defects precisely on CN remains a challenge. The modified sites and concentration of vacancy defects on CN are important factors affecting its photocatalytic performance. In most instances, the introduction of vacancies is a double-edged sword, i.e., it can potentially facilitate one step of photocatalysis but hinder the other. For example, creating defect vacancies could narrow the bandgap of CN by reducing the CB and increasing the VB levels, resulting in a lower redox capacity.<sup>[85]</sup> Therefore, a balance in critical steps in photocatalysis, such as light absorption, charge separation and surface reaction, is important to improve the photo-Fenton-like catalytic activity of CN. 

## **4. Nonmetal Element Doping** 

Defect generation by removing C and N sites always poses demanding protocols. For maintaining the metal-free nature of CN, doping external heteroatom represents another alternative to generating structural incomplete-bonding defects by transforming chemical bonds, i.e., reorganizing and accompanying chemical bonds.<sup>[86–88]</sup> Doping nonmetal atoms (e.g., B, O, F, P, S) into the CN framework offers a great potential to alter the textural, band structure and electronic properties of CN, leading to improved conductivity, a narrowed bandgap, and enhanced light-harvesting ability.<sup>[28,89–92]</sup> 

Guo and co-workers fabricated edge oxygen-doped holey structured CN (HS CN-O) via a photo-Fenton-like process with H2O2 and FeCl3.<sup>[68]</sup> The bandgap (2.43 eV) of HS CN-O was narrower than that of unmodified CN and thin-sheet CN, leading to an enhanced visible light-harvesting capability. In addition, HS CN-O had a high SSA of 348 m<sup>2</sup> g<sup>−1</sup> and pore size of 1 – 5 nm, which allowed the exposure of more active sites on the surface. Improved photoinduced charge carrier separation efficiency was observed on HS CN-O, which realized 100% RhB degradation within 50 min under visible irradiation without H2O2 addition. In another work, co-modification of O bridges and porous defects was found to enhance the photodegradation activity of CN (CY-CN) ( **Figure 4** a).<sup>[69]</sup> The computation results indicated that the O bridge could modify the energy band position, where the COC structure can shorten the energy level difference. Compared with pristine CN, the presence of O bridges and porous defects in CY-CN can offer more reactive sites, accelerate electron migration, reduce charge recombination rate, and maintain a longer life of charge carriers (Figure 4b). As a result, the optimized CY-CN exhibited enhanced visible-light-driven degradation efficiencies of BPA and 2-mercaptobenzothiazole, which were 17.94 and 3.85 folds higher than those of pure CN, respectively (Figure 4c). 

Ma et al.<sup>[48]</sup> used P-doped CN for 2, 4-dichlorophenol (2, 4-DCP) degradation with the help of FeSO4 (Figure 4d). P doping could benefit the _π_ delocalization of CN, improving electron transfer.<sup>[28]</sup> P doing was also revealed to promote the catalytic H2O2 generation process, thereby enhancing overall photo-Fenton efficiency. Under light irradiation, P-doped CN in situ generated H2O2, which could be activated by Fe<sup>3+</sup> to produce<sup>•</sup> OH continuously. Compared with the traditional Fenton process, H2O2 utilization efficiency is 10.5-time higher in this system, leading to the improved 2, 4-DCP degradation and mineralization performances. Under visible light irradiation, 2, 4-DCP and total organic carbon (TOC) degradation rates of P-doped CN were 20.5- and 22.5-fold of those of bulk CN, respectively (Figure 4e). The effect of Fe<sup>3+</sup> on the photo-Fenton-like degradation performance was also studied. The degradation ability was improved with the FeSO4 amount increased to 10 mg (in 30 mL 2, 4-DCP). However, further increasing the FeSO4 dosage will reduce the degradation due to the decreased light penetrability. 

Additionally, Li et al.<sup>[70]</sup> synthesized carbon-doped CN (ACCN) via one-step calcination of ammonium citrate and dicyandiamide. Compared with pure CN, ACCN had a narrower bandgap, facilitating broader visible light utilization. The bridging nitrogen atoms in the CN framework were substituted by carbon atoms, improving the conductivity and charge separation. Meanwhile, nitrogen defects and carbon atoms connected to carbon dopants could act as electron sinks to enhance charge separation. Consequently, ACCN was endowed with the improved ability for visible-light-driven SMZ degradation, showing a reaction rate of 6.6 times higher than pristine CN. The greater SMZ degradation performance was attributed to the synergistic effect of the<sup>•</sup> OH evolved from the in situ generated H2O2, O2<sup>•−</sup> from the single-electron reduction of dissolved O2, and the photoexcited holes, among which the O2<sup>•−</sup> and holes play the dominant role. 

As discussed above, both vacancy engineering and nonmetal could be easily introduced in the CN framework without changing its structure to a large content ( **Figure 5** ) while the mechanism is different. For C/N vacancies on CN, i) because of the weaker binding at the defect site, the splitting between bonding and antibonding orbitals was reduced, introducing additional energy levels under the CB edge. Following that, the bandgap of CN was narrowed, and the light absorption edge was red-shifted, therefore extending the visible light absorption range. ii) The defective mid-gap state created between the bandgap can boost the isolation of photogenerated charge carriers by capturing photocarriers and inhibiting their recombination. iii) Inducing C/N vacancies results in the formation of coordinately unsaturated sites to function as the adsorption and active sites, thus optimizing the photo-Fenton-like reaction kinetics. Nonmetal doping makes the replacement of the carbon or nitrogen atoms in the CN skeleton by other nonmetal heteroatoms. Similar to defect engineering, CN’s physicochemical properties and electronic structure could be significantly changed by nonmetal atom doping to: I) improve the delocalization of _π_ electrons and then enhance charge transfer; II) tailor the energy band position and narrow the bandgap of CN for extended light absorption; III) induce structure defects for more active sites. Owing to the element diversity of nonmetal doping, it seems to be a more promising strategy to promote 

**2201743 (10 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



<!-- Start of picture text -->
www.afm-journal.de<br><!-- End of picture text -->



**Figure 4.** a) Simulated structure of CY-CN. b) Photoluminescence tests of CY-CN and CN. c) BPA photodegradation kinetics. Reproduced with permission.<sup>[69]</sup> Copyright 2021, Elsevier B.V. d) Charge transfer pathway of P-doped CN for photocatalysis-self-Fenton catalysis. e) Apparent reaction rate constants and TOC removal rates of photocatalysis-self-Fenton and photocatalytic processes using bulk-CN, CN nanosheet, and P-doped CN. Reproduced with permission.<sup>[48]</sup> Copyright 2020, Elsevier B.V. f) TEM image of PCN-DP. g) Charge transfer pathway of PCN-DP for SMZ photodegradation. h) SMZ photodegradation kinetics. Reproduced with permission.<sup>[71]</sup> Copyright 2020, Elsevier B.V. 



**Figure 5.** The effects of C/N vacancies inducing and nonmetal doping on CN for photo-Fenton-like catalysis. 

**2201743 (11 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

the photoactivity of CN by altering its physical/chemical properties and optical/electronic structures. On the other hand, it is difficult to control the doping concentration and position precisely. Excess heteroatom doping could lead to the formation of a recombination center, which is unfavorable for photoFenton-like reactions. Considering the merits of both defect engineering and nonmetal doping, defects/nonmetal atoms coengineering could be an effective strategy.<sup>[93]</sup> Inducing defects in the CN framework could provide the dopants with a specific site. Compared with other in-plane carbon or nitrogen atoms, edge atoms around defective sites are more likely to be doped or functionalized.<sup>[94,95]</sup> 

## **5. Organic Molecule Doping** 

Organic molecule doping of CN has been demonstrated as an effective route to obtain high photocatalytic activity by modulating the bandgap structure, electronic structure, physical and chemical properties of CN.<sup>[32]</sup> In view of the advantages of molecular-level doping, Zhou et al.<sup>[71]</sup> introduced 2,5-dibromopyrazine into a CN framework (PCN-DP) for SMZ removal under visible light irradiation. The nanosheet-like and pore structure of PCN-DP (Figure 4f) could refine the visible light harnessing and offer more reaction active sites. Importantly, the modification of pyrazine molecules on CN could expand the visible light absorption range, inhibit the recombination of electron-hole pairs, and act as a hyperchannel to ameliorate the charge transfer, thereby enhancing its photocatalytic activity (Figure 4g). As a result, PCN-DP attained an SMZ degradation rate at 4 times higher than unmodified CN (PCN) (Figure 4h). O2<sup>•−</sup> and h<sup>+</sup> were essential in removing SMZ, while the in situ generated H2O2 could also be converted into<sup>•</sup> OH for SMZ degradation. 

Modifying CN with oxygen-containing functional groups, such as aromatic diimides, was revealed to be effective for H2O2 production. Shiraishi’s group incorporated pyromellitic diimide (PDI) on CN to boost H2O2 generation.<sup>[96]</sup> The production of 1,4-endoperoxide species on PDI-CN significantly suppressed one- and four-electron reduction of O2, but promoted the selective two-electron reduction of O2 to H2O2. Besides, mellitic triimide (MTI)<sup>[97]</sup> and biphenyl diimide (BDI)<sup>[98]</sup> were loaded on CN to shift O2 reduction from a two-step one-electron to a single-step two-electron transfer channel, achieving millimolar level production of H2O2. The generated H2O2 could be further activated by photoexcited electrons or metal-containing species 

on CN to generate ROS for enhanced photo-Fenton-like catalytic performance. 

For maintaining the metal-free nature of CN and improving its photo-Fenton-like catalytic ability, morphology control, defect engineering, nonmetal atom doping and organic molecule doping were developed (as summarized in Table 1). Morphological evolution of bulk CN into porous architecture could introduce porous channels for efficient mass transfer and light absorption. Exfoliation of bulk CN crystals into ultrathin nanosheets enabled high photoactivity due to the increased SSA and shortened diffusion length of charge carriers. Defect, nonmetal atom and organic molecule engineering can effectively tune the electronic and optical structure of CN to enhance conductivity, narrow bandgap and promote charge migration/ separation, leading to an improved photo-Fenton-like catalytic activity. As discussed above, inducing defects on the CN framework always poses demanding protocols. Nonmetal doping represents an alternative strategy to generate structural incompletebonding defects. However, nonmetal atom doping still suffers from the limitation of precisely controlling the concentration and location of dopants. Defects/nonmetal atoms co-engineering could anchor nonmetal heteroatoms at a specific defect site, which helps quantify the doping effect for photo-Fentonlike catalysis. Compared with the recent progress in energy conversion, there are still substantial research possibilities for developing metal-free CN-based organic heterojunction or homojunction for environmental remediation.<sup>[99,100]</sup> Contrast to the interlayer junction, constructing intralayer heterojunction or homojunction could possess a wide distribution of internal electric field, facilitating the charge transfer and separation, therefore improving the photoactivity.<sup>[101–103]</sup> Our group have reported the rational synthesis of intralayer homojunction by inducing vacancies on CN<sup>[102]</sup> and intralayer heterojunction by connecting the graphene carbon rings with the tri- _s_ -triazine units of CN<sup>[103]</sup> for improved electrical field and promoted charge transfer/separation efficiency for an enhanced photocatalytic activity. 

## **6. Metal-Based Species Loading** 

Loading metal (M)-containing species on CN serves as another effective strategy to introduce active sites to activate H2O2 in photo-Fenton-like catalysis by triggering the metal redox cycle (M<sup>(</sup><sup>_n_+1)+</sup> ↔ M<sup>n+</sup> ) in a series of chain reactions ( **Figure 6** ). Specifically, metal species (M<sup>n+</sup> ) and H2O2 can react to generate 



**Figure 6.** The metal (M) redox cycle with valence state ( _n_ / _n_ +1) changes introduced by metal-containing species on CN for photo-Fenton-like catalysis. 

**2201743 (12 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 7.** Loading metal species on CN for photo-Fenton-like catalysis. 

•OH, HO2•, and M( _n_ +1)+. The M( _n_ +1)+ can then be reduced to M<sup>n+</sup> by accepting photoinduced electrons from CN and thus accelerating the metal redox cycle to ensure efficient H2O2 activation. By comparison, the metal redox cycle might be insufficient without the assistance of photoinduced electrons from CN.<sup>[12]</sup> As a typical example, the involvement of a Fe<sup>3+</sup> ↔ Fe<sup>2+</sup> redox cycle in Fe-loaded CN for H2O2 activation is illustrated by Eqs. 11 – 13. The continuous reduction of Fe<sup>3+</sup> to Fe<sup>2+</sup> ensures efficient H2O2 activation, which is the prerequisite to facilitate ROS (<sup>•</sup> OH, O2<sup>•−</sup> , 1O2) generation and h+ separation for POP degradation 



<!-- Start of picture text -->
Fe2+ + H2O2 → Fe3+ +• OH (11)<br><!-- End of picture text -->



<!-- Start of picture text -->
Fe3+ + H2O2 → Fe2+ + HO•2 (12)<br><!-- End of picture text -->



<!-- Start of picture text -->
Fe3+ + e − → Fe2+ (13)<br><!-- End of picture text -->

Apart from providing catalytic active sites, loading metal-containing species to CN can potentially enhance light absorption, accelerate charge separation, and thus significantly improve the photo-Fenton-like catalytic ability of CN.<sup>[104,105]</sup> As summarized in **Figure 7** and Table 2, extensive research efforts have been made to modify CN by loading sub-nanoscale (metallic heteroatoms, single-atom metals and organometallic molecules) and low-dimensional (zero-dimensional (0D), 1D, 2D, 3D) metalcontaining species. Covalent or noncovalent interactions can tightly connect CN and metal-containing species via hydrogen bonds, _π_ – _π_ , electrostatic, and hydrophobic interactions,<sup>[32]</sup> which could avoid metal leaching. 

### **6.1. Loading Sub-Nanoscale Materials** 

Owing to its aromatic _π_ -conjugated system, CN generally encounters several limitations, including insufficient 

absorption of visible light and utilization, rapid recombination of charge carriers, and a low SSA, which significantly limit its practical applications.<sup>[28,32]</sup> As summarized in Figure 7, loading sub-nanoscale metal-containing species, namely organometallic molecules, metal cations and single atom metals, on CN could enhance _π_ delocalization of electrons, suppress charge recombination, provide catalytic active sites and improve photocatalytic reaction kinetics for photon-Fenton-like catalysis. 

### _6.1.1. Organometallic Molecule Loading_ 

Doping organometallic molecules on CN is a typically appealing approach to extend the delocalization of the _π_ electrons and endow a broadened visible-light response range.<sup>[32,154]</sup> Benefiting from the synergistic donor-acceptor interaction between CN and the doped organometallic molecule, the recombination rate of photogenerated electron-hole pairs can be inhibited,<sup>[155]</sup> which is essential for the enhanced photo-Fenton-like catalytic performance. Ferrocene (Fc)-functionalization of CN (Fc-CN) was achieved through constructing the CN covalent bond via a Schiff base reaction.<sup>[106]</sup> This covalent bond significantly enhanced the _π_ -conjugation between CN and Fc, which promoted bulk-to-surface charge transfer/separation and the reversible photoredox processes during photocatalysis. Herein, photoinduced electrons from CN could activate H2O2 and help sustain the bivalence state of Fe in central Fc for H2O2 activation ( **Figure 8** a). Compared with pure CN, the as-synthesized Fc-CN could activate H2O2 to produce<sup>•</sup> OH for RhB degradation with much faster kinetics (Figure 8b,c). The effects of organic molecules and salts on RhB degradation were studied, showing that both humic acid and NaCl could reduce the degradation rate by consuming<sup>•</sup> OH for RhB degradation. Humic acid significantly inhibited the degradation efficiency due to the huge consumption of<sup>•</sup> OH. NaCl could also reduce the degradation rate to some extent because Na<sup>+</sup> cations could reside on the surface of Fc-CN to cover the active sites and Cl<sup>−</sup> ions could react with<sup>•</sup> OH to form Cl<sup>•−</sup> and Cl2<sup>•−</sup> , lowering the oxidizing capability. This may impede the application of Fc-CN in practical wastewater treatment. 

### _6.1.2. Metal Heteroatom Doping_ 

Metal atom doping is another effective route in modifying the electronic and optical properties of CN, leading to modified band structure, improved conductivity, and increased the number of active sites for enhanced photocatalytic H2O2 activation.<sup>[156,157]</sup> Fe doping is most commonly studied to provide a dynamic Fe<sup>2+</sup> ↔ Fe<sup>3+</sup> redox cycle for H2O2 activation.<sup>[107–109]</sup> Fe-doped CN has been used to activate H2O2 and produce •OH toward excellent methylene blue (MB) degradation at a wide range of initial pH values (3 – 9).<sup>[108]</sup> Fe<sup>3+</sup> was bonded to N in CN via FeN(III) coordination, which served as the main active site for catalysis. Fe doping also suppressed the charge recombination and accelerated charge transfer. The effects of inorganic cations (e.g., Al<sup>3+</sup> , Mg<sup>2+</sup> , Ca<sup>2+</sup> ) and anions (e.g., Cl<sup>−</sup> , NO3<sup>−</sup> , HCO3<sup>−</sup> ) on degradation were studied. It was claimed that Cl<sup>−</sup> , NO3<sup>−</sup> and HCO3<sup>−</sup> could act as a<sup>•</sup> OH scavenger, inhibiting 

**2201743 (13 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 8.** a) RhB photodegradation mechanism by Fc-CN. b) RhB photodegradation kinetics. c) EPR analysis. Reproduced with permission.<sup>[106]</sup> Copyright 2017, Elsevier B.V. d) Synthesis procedure and photo-Fenton process of Fe-CN-6h. e) TEM image of Fe-CN-6h. Inset: HRTEM image. f) RhB photodegradation kinetics. Reproduced with permission.<sup>[110]</sup> Copyright 2020, Elsevier B.V. 

the photo-Fenton-like performance. Al<sup>3+</sup> , Mg<sup>2+</sup> , and Ca<sup>2+</sup> could be adsorbed on the surface of Fe-doped CN, covering the active sites and shielding light absorption, restraining the photocatalytic activity of Fe-doped CN. 

In addition, morphology engineering and Fe doping were achieved to obtain Fe-doped CN (Fe-CN) with multilayer and mesoporous structure by controlled pyrolysis (Figure 8d).<sup>[110]</sup> As shown in Figure 8e, attributed to the enlarged SSA, layered and 

**2201743 (14 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

porous structure, light-harvesting ability, accessible active sites, and band structure of Fe-CN can be engineered for an enhanced activity. Importantly, the induced Fe species mainly contributed to the H2O2 activation, accelerating the heterogeneous Fenton catalytic reaction. In the photo-Fenton-like reaction by Fe-CN, visible light could facilitate the Fe-mediated cycle and produce •OH as the predominant oxidants for ≈100% RhB degradation within 100 min (Figure 8f). The RhB degradation performance was associated with the concentration of the oxidants, and the degradation efficiency increased with the increasing H2O2 concentration. In addition, pH significantly affected the speciation of Fe and the decomposition of H2O2. Acidic pH conditions highly favored the photo-Fenton-like degradation. 

Cu-doped CN also has attracted a wide interest for photoFenton-like reaction, with the practical applicability over a wide pH range.<sup>[13,158,159]</sup> Cu can be embedded in alkalinized CN (Cu-CNK-OH) mainly via CuN bonds.<sup>[112]</sup> Suitable Cu<sup>2+</sup> loading can effectively promote<sup>•</sup> OH generation and electronhole separation, leading to an increased degradation rate of RhB. Under the irradiation of visible light, the photoinduced holes in Cu-CNK-OH rapidly converted the surface OH<sup>−</sup> to<sup>•</sup> OH, while the holes and<sup>•</sup> OH could degrade RhB. Meanwhile, with the addition of H2O2, the Cu<sup>2+</sup> /Cu<sup>+</sup> redox pair could activate H2O2 to generate more<sup>•</sup> OH, while this process was accelerated by the photogenerated electrons generated from CN. The optimum catalyst realized visible-light-driven RhB degradation by 95.0% in 10 min. 

Compared to single metallic doping, bimetallic doping to CN was proven to show elevated performance due to the synergistic effect between two metal atoms. A visible-light-driven Fe, Cu co-doped CN/Fe2O3 (FeCu-CN@Fe2O3) composite was reported,<sup>[113]</sup> which could induce H2O2 decomposition for 80% aniline degradation in 6 h, insusceptible to environmental parameters like anions and pH values. Fe was mainly distributed in CN via Fe(III)-N coordination and partly in the lattice of Fe2O3, while Cu was inserted into the interstices of CN via Cu(I)N bond. The bimetallic synergistic effect between Fe and Cu atoms promoted H2O2 activation to generate ROS, including<sup>•</sup> OH and<sup>1</sup> O2 for aniline degradation. 

### _6.1.3. Single-Atom Metal Anchoring_ 

With the rapid growth of nanoscience and the development of atomic-resolution characterization technology and computational modelling, we gradually achieve the goal of arranging metal atoms with a tunable coordination environment.<sup>[160]</sup> The typical outcome is the emergence of SACs and single-atom catalysis. Downsizing metal-based catalysts to SACs have arisen an extensive interest by allowing maximum metal-atom-utilization efficiency for catalysis with high conversion efficiency, selectivity, and stability.<sup>[161,162]</sup> Due to abundant multidentate coordination sites, CN offered the unique potential for uniformly stabilizing isolated metal atoms via strong interactions.<sup>[163]</sup> CN-based SACs have become attractive candidates in photo-Fenton-like reactions with their environmental friendliness.<sup>[164,165]</sup> Anchoring single atom metals on CN can introduce abundant and highly catalytic active sites, lower the bandgap energy, improve light absorption capability, 

and accelerate charge separation and transfer by strong metalligand interaction.<sup>[115,165]</sup> Importantly, SACs offer an excellent opportunity to understand the structure–activity relationship for CN-based photo-Fenton-like catalysis at the atomic scale.<sup>[116]</sup> 

Recently, highly active Fe species dispersed on CN (I-FeN _x_ / CN-X) was fabricated via single-step pyrolysis using melamine and Fe-imidazole coordination compounds ( **Figure 9** a).<sup>[115]</sup> The Fe species were anchored on CN in the forms of nanoclusters and single atoms with high loading of 18.2 wt% (Figure 9b). Benefited by the high density of Fe(II)−N _x_ active centers, the external added H2O2 can be rapidly activated to generate •OH for efficient visible-light-driven degradation of POPs (Figure 9c) with good stability and low Fe leaching. The ratio of single metal sites could be elevated by increasing the mass ratio of melamine/Fe-precursor. Figure 9d shows the relationship between catalytic performance and cluster/single-atom ratios (increasing X represented a decreased ratio). For catalysts with a high single atom/cluster ratio, the photo-Fentonlike reaction was led by single Fe sites, while ultra-small Fe clusters were critical for low ratio counterparts. Under visible light irradiation, I-FeN _x_ /CN-5 with the coexisting ultra-small clusters and single atoms of Fe exhibited the highest degradation efficiency of MB, reaching 98.9% within 11 min with the addition of H2O2. 

More recently, CN-based SACs with single-atom sites (Cr, Mn, Fe, Co, or Cu) were synthesized by the calcination of self-assembled melamine/cyanuric acid/xanthine and adsorbed metal ions (Figure 9e).<sup>[116]</sup> As a model of these SACs, the singleatom Cr/pyrrolic N-rich CN (SA-Cr/PN-CN) sample featured the uniform distribution of Cr single-atoms (Figure 9f). The presence of single atom Cr slightly enhanced the light absorption ability of PN-CN and accelerated the separation and migration of photoexcited charge carriers. Besides, the metalloporphyrin-like Cr−N4 sites are reactive sites for trapping electrons from CN, boosting the redox circulation of Cr<sup>3+</sup> /Cr<sup>2+</sup> pairs for H2O2 activation. As a result, SA-Cr/PN-CN/H2O2 showed efficient visible-light-driven oxidation of BPA (Figure 9g,h), with excellent cyclic stability over a wide pH range (3.0 – 11.0). 

In short, the manifold merits of anchoring CN with organometallic molecules, metal cations, and single atom metals have been comprehensively discussed. Deposition of these sub-nanoscale materials on CN can efficiently enhance the photocatalytic activity by offering catalytic active sites for H2O2 activation, improving charge separation/transfer, and accelerating photocatalytic reaction kinetics. An increased research interest has been devoted to developing CN-based SACs for various photocatalytic reactions due to their well-defined active sites, maximum utilization of metal atoms, and superior photoactivity. However, increasing the loading concentration (>10 wt%) of single atom metals while preventing them from aggregation still remains a great challenge. This is because metal atoms tend to migrate and aggregate due to the high surface energy.<sup>[165,166]</sup> Achieving a high loading amount of single atom metals is believed to be highly dependent on the nature of supports and the synthetic methods. For instance, Ji et al. synthesized single atom erbium (Er) decorated CN nanotubes via an atom-confinement and coordination strategy, achieving ultrahigh metal loading up to 20.1 wt%.<sup>[167]</sup> The addition of Er 

**2201743 (15 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 9.** a) Synthesis procedure of a FeN _x_ /CN composite. b) HAADF-STEM image of the FeN _x_ /CN composite. c) Photo-Fenton-like POP (MB, RhB, methyl orange, phenol) removal performance. d) The removal performance of MB using I-FeN _x_ /CN. Reproduced with permission.<sup>[115]</sup> Copyright 2018, American Chemical Society. e) The synthesis procedure of a SA-Cr/PN-CN composite. f) HAADF-STEM image of the SA-Cr/PN-CN. g) BPA degradation performance using the SA-Cr/PN-CN at various H2O2 dosage. h) BPA degradation stability tests by the SA-Cr/PN-CN. Reproduced with permission.<sup>[116]</sup> Copyright 2021, Wiley. 

**2201743 (16 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

species changed the carbon nitride property, forming a disordered structure with many defective sites. Maintaining the strong interaction between the single atom metals and the coordination host is vital during the synthesis process.<sup>[168,169]</sup> Not only that, the development of a cost-effective, time-saving, and large-scale accessible approach for the fabrication of highly active and stable CN-based SACs is essential for practical environmental applications. 

### **6.2. Loading Nanoscale Metal-Containing Species on CN** 

Coupling low dimensional nanomaterials (0D, 1D, 2D, 3D) with CN via an interface engineering strategy have been extensively studied to improve the photocatalytic degradation of POPs by CN in photo-Fenton-like reaction.<sup>[27,115,138]</sup> CN can be facilely exfoliated into 2D nanosheets (NSs), which is beneficial for loading SCs with various dimensional structures. 

### _6.2.1. 0D Nanomaterials_ 

Modifying and anchoring CN with 0D nanomaterials (clusters, quantum dots (QDs), nanoparticles (NPs)) has been suggested as an effective technique for improved photo-Fenton-like catalytic reactions due to the enhanced charge separation and light absorption, as well as an increased number of catalytic active sites. Polyoxometalate (POM), a type of 0D metal-oxygen cluster, has received much attention owing to its structural stability and reversibility in a multielectron redox reaction.<sup>[170,171]</sup> Recent advances have focused on developing Fe-POMs/CN nanocomposites for photo-Fenton-like oxidation by combining photocatalysis of CN and H2O2 activation over Fe-POMs. Lan et al.<sup>[104]</sup> prepared Fe-containing polyoxometalates (Fe-POMs)/ CN nanoclusters membrane via a two-step process, where the CN sol was first fabricated with remarkable homogeneity, a high yield, and excellent stability. Then, the Fe-POMs/CN membrane was synthesized via a soft self-assembly method ( **Figure 10** a). Introducing amino and hydroxyl functional groups on CN could provide abundant active sites for Fe-POMs nucleation. Due to the intermolecular hydrogen bonds and the polymeric matrix’s soft nature, hydrolyzed CN sol molecules can be re-polymerized into dense and solid membranes after extracting H2O under vacuum (Figure 10b). Fe-POMs nanoclusters could act as a molecular linker to strengthen the hydrogen-bond interactions and contribute to the formation of CN skeletons. Moreover, loading Fe-POM on CN could provide more active sites and improve charge separation, which are favorable for generating highly oxidative species, thus significantly enhancing photodegradation performance. As shown in Figure 10c, the photo-Fenton-like performance of the CN/Fe-POMs filtration membrane was studied by pumping practical textile wastewater into the membrane. This work also revealed that the rejection ability and stability of the membrane is affected by the microstructure of CN. The membrane (U-CN/Fe-POMs) prepared from urea-derived CN exhibited a better performance (Figure 10d) than that prepared from melamine (M-CN/Fe-POMs). Moreover, CN/Fe-POMs presented more efficient rejection ability and stability than the CN 

membrane. With the increasing content of Fe-POMs, the pollution rejection rate was increased, and water permeation flux was decreased. Consequently, U-CN/1% Fe-POMs exhibited a great removal performance of chemical oxygen demand (COD) with high stability. 

The surface defect engineering strategy can be involved in a Fe-POM/CN composite to improve photocatalytic performance, as defects are often considered charge trapping sites. For instance, a facile self-assembly method was used to introduce N vacancies into ultrathin and porous CN nanosheets and couple with 0D Fe-POM.<sup>[45]</sup> The co-modification of N vacancies and Fe-POM extended the photoabsorption ranges of CN. Surface N vacancies improved the photoinduced charge separation and transferability and accelerated the cycling of Fe<sup>3+</sup> /Fe<sup>2+</sup> to activate H2O2 for the generation of<sup>•</sup> OH and<sup>1</sup> O2. Under visiblelight irradiation, the optimal 45 wt% Fe-POM/H2O2 exhibited tetracycline hydrochloride (TCH) degradation efficiency of 96.5% in 18 min. As another example, Fe-POMs coupled O-doped CN was synthesized via a polymerization process.<sup>[120]</sup> O doping induced a strong chemical interaction between Fe-POMs and CN, ensuring the intimate interfacial interaction for the charge transfer from CN to Fe-POMs. In addition, strong coupling between them created more unpaired spin density in the heptazine unit, leading to the formation of rich defects as reaction active sites. The as-obtained Fe-POMs/O-CN-U/H2O2 system displayed ≈100% degradation of 5-sulfosalicylic acid within 35 min, which is 6.2 folds higher than that of pure CN under simulated solar light irradiation. 

QDs are well-known 0D nanomaterials with unique physicochemical, electronic, and optical properties, such as nanoscale size effect (below 10 nm), aqueous solubility, excellent luminescent property, high quantum efficiency, and photochemical stability.<sup>[172–174]</sup> Loading metal-based QDs on CN can inhibit the photogenerated carrier recombination, broaden the visible light absorption range, and provide more surface active sites and metal redox cycle (M<sup>(</sup><sup>_n_+1)+</sup> /M<sup>(</sup><sup>_n_)+</sup> ) for efficient H2O2 activation.<sup>[117,118,175,176]</sup> For example, Fe2O3 QDs were stably and uniformly anchored on CN nanosheets as catalytic active sites (Figure 10e),<sup>[118]</sup> forming a heterojunction interface. The strong coupling 0D/2D Fe2O3/CN interface facilitated charge separation, allowing fast photogenerated electron transfer to maintain the Fe<sup>3+</sup> /Fe<sup>2+</sup> redox cycle (Figure 10f) efficiently. This ensured a sufficient amount of Fe<sup>2+</sup> for efficient H2O2 activation to produce<sup>•</sup> OH for Fenton-like degradation. Under visible light irradiation, Fe2O3/CN/H2O2 degraded _p_ -nitrophenol (PNP) entirely in 10 min (Figure 10g), with<sup>•</sup> OH as the dominant reactive species. To a certain extent, the PNP degradation efficiency was improved with the increase of H2O2 dosage and more generation of<sup>•</sup> OH. However, excess H2O2 will inhibit the photo-Fenton-like degradation because the superfluous H2O2 could react with<sup>•</sup> OH to produce HO2<sup>•</sup> with lower oxidizing capability. Moreover, 0D FeOOH QDs were coupled with carbon species-CN.<sup>[117]</sup> The photogenerated electrons transferred from the CB of CN to the interfacial Fe<sup>3+</sup> via extraneous carbon species to generate the Fe<sup>3+</sup> /Fe<sup>2+</sup> redox cycle for H2O2 activation. The 1 wt% FeOOH/CN composite efficiently activated H2O2 for ≈100% visible-light-driven oxidation of methylene orange (MO) in 60 min, with mineralization efficiency of 74% in 2 h. 

**2201743 (17 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

#### **www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 10.** a) Synthesis procedure of CN/Fe-POMs. b) SEM image of U-CN/Fe-POMs. c) Textile wastewater treatment. d) Dye rejection performance. Reproduced with permission.<sup>[104]</sup> Copyright 2019, American Chemical Society. e) HRTEM image of a Fe2O3/CN composite. f) PNP photodegradation mechanism by Fe2O3/CN/H2O2. g) PNP photodegradation kinetics. Reproduced with permission.<sup>[118]</sup> Copyright 2019, Wiley. h) STEM image of a FeOOH/CN composite. i) TC photodegradation mechanism by the FeOOH/CN composite. j) TC photodegradation kinetics. Reproduced with permission.<sup>[119]</sup> Copyright 2020, Elsevier B.V. 

Loading 0D NPs on CN is another way to improve its photoFenton-like catalytic ability by enhancing visible-light absorption, accelerating charge separation and transfer, and offering efficient metal redox cycles. In a goethite FeOOH NPs/CN composite, Fe<sup>3+</sup> ions can be readily adsorbed on the surface of CN by electrostatic interaction (Figure 10h), which significantly suppressed the agglomeration of FeOOH NPs.<sup>[119]</sup> The strong electronic interaction can achieve an accelerated migration 

of photoinduced charge carriers and efficiently improve the conversion of surface Fe<sup>3+</sup> to Fe<sup>2+</sup> for H2O2 activation (Figure 10i). The optimal FeOOH NPs (2 wt%) loaded CN served as a visible-light-responsive photocatalyst for efficient tetracycline (TC) degradation (88% within 60 min) with external H2O2 adding (Figure 10j). 

To an extent, we would like to highlight the significance of the size effect by anchoring CN with nanoscale and 

**2201743 (18 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 11.** Size effects of metal loading on CN, ranging from 0D nanoscale, sub-nanoscale to atomic level. 

sub-nanoscale metal-containing species in varying sizes ( **Figure 11** ). 0D nanomaterials (e.g., clusters, QDs, NPs) with a relatively small size benefit effective charge transfer. The growth of 0D nanomaterials is substantially affected by the CN nanosheets, which act as a 2D platform to disperse 0D nanomaterials and restrain them from agglomeration. The wellformed heterointerfaces between 0D nanomaterials and CN could ameliorate the separation of electron-hole pairs, leading to the improvement of photoactivity. By considering the merits of offering more metal active sites with the maximum utilization for photo-Fenton-like catalysis, loading sub-nanoscale metal-containing species (including organometallic molecules, metal cations and single atom metals) on CN can effectively modulate its electronic structures and physicochemical properties, leading to an enhanced photo-Fenton-like catalytic performance. Owing to the polymeric _π_ -conjugated structures of CN, the _π_ delocalization of electrons can be extended by grafting organometallic molecules on CN during the copolymerization process. Taking the merits of the unique tri-s-triazine structure of CN, abundant N-rich cavities are provided as binding sites for metal cations/atoms with empty or partial empty orbitals. Doping metal cations on CN is a typical engineering strategy to enhance charge separation efficiency and optical absorption as well as offer metallic active sites for photocatalytic H2O2 activation. However, it has long been a challenge to dope metallic cations on CN with a specific number of heterometal atoms at specific positions. Current work has shifted to the development of CN-based SACs, in which relatively fewer examples have been reported for photo-Fenton-like catalysis. It is envisaged that the rational design of CN-based SACs with the maximum metal atom utilization efficiency can greatly enhance catalytic activity and stability. Also, due to the stabilization of single 

atom metals on CN supports via strong interaction, metal ion leaching is largely reduced and secondary pollution is avoided, making CN-based SACs highly desired for water treatment. The in-depth understanding of structure–activity correlations at the atomic scale would be conducive to developing state-ofthe-art CN-based SACs for photo-Fenton-like reactions in water remediation. 

### _6.2.2. 1D Nanomaterials_ 

1D nanomaterials (e.g., nanotubes, nanorods, and nanowires) have been extensively studied in photocatalysis due to their advantages in fast charge transfer and a high length-to-diameter ratio.<sup>[177,178]</sup> Incorporating CN with 1D nanomaterials could enhance carriers transfer along the 1D nanomaterial axes and inhibit the recombination of photogenerated electron-hole pairs.<sup>[179–181]</sup> A ZnWO4/CN heterojunction was constructed by growing 1D ZnWO4 nanorods on CN nanosheets via an in situ hydrothermal treatment.<sup>[121]</sup> ZnWO4 nanorods were uniformly dispersed on the CN surface as electron conductive channels to facilitate electron transfer, leading to effective charge separation ( **Figure 12** a,b). It was suggested that ZnWO4 and CN were tightly connected via ZnOC and NZn bonds at the interface. Besides, the successful construction of heterojunction enhanced the visible light absorption and hindered the charge carrier recombination. Under visible light irradiation, the optimized ZnWO4/CN photocatalyst displayed a RhB degradation efficiency of 99% in 80 min without external H2O2 adding. 

Most of the degradation tests were carried out in a clear water matrix. However, the removal efficiency in actual wastewater containing diverse inorganic ions may possess a huge 

**2201743 (19 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 12.** a) HRTEM image and b) lattice fringe pattern of a ZnWO4/CN composite. Reproduced with permission.<sup>[121]</sup> Copyright 2019, Springer. c) PL spectra of CN and MnWO4/CN. d) OFX photodegradation kinetics. Reproduced with permission.<sup>[122]</sup> Copyright 2019, Elsevier B.V. e) Synthesis procedure of a _δ_ -Bi2O3/CN composite. f) TEM and g) HRTEM image of the _δ_ -Bi2O3/CN composite. h) Band structure of the _δ_ -Bi2O3/CN composite. Reproduced with permission.<sup>[123]</sup> Copyright 2022, Elsevier B.V. i) SEM image of Fe2O3/CN. j) HRTEM image of Fe2O3/CN. k) Amaranth azo dye photodegradation kinetics. l) Stability test. Reproduced with permission.<sup>[125]</sup> Copyright 2021, Elsevier B.V. 

difference. For instance, 1D MnWO4 nanorods were anchored on CN nanosheets for visible-light-driven ofloxacin (OFX) degradation.<sup>[122]</sup> The strong coupled MnWO4/CN enabled a heterojunction formation at the interface, promoting charge carrier transfer and separation (Figure 12c) and improving visible light utilization, thereby enhancing the OFX photodegradation performance (Figure 12d). The effect of inorganic ions on OFX degradation was studied. Owing to their<sup>•</sup> OH scavenging abilities, the presence of Cl<sup>−</sup> , SO4<sup>2−</sup> and CO3<sup>2−</sup> lowered the degradation efficiency of OFX. Also, the divalent anions (e.g., SO4<sup>2−</sup> and CO3<sup>2−</sup> ) could be adsorbed on the catalyst surface to cover the active sites and shield light absorption, further inhibiting the degradation performance. 

### _6.2.3. 2D Nanomaterials_ 

2D/2D heterostructures possess a large contact interface and short charge transport distance, benefiting charge migration and separation.<sup>[182–184]</sup> A reduced graphene oxide (rGO)/CN hybrid is a typical 2D/2D nanomaterial, in which the _π_ -conjugated structure of rGO resembles the CN’s layer stacking.<sup>[185]</sup> The 2D/2D rGO/CN heterostructure could be easily formed through the electrostatic adsorption of the _π_ – _π_ stacking NSs. Apart from that, 2D metallic nanomaterials can also be loaded on CN for the construction of 2D/2D nanostructure. A 2D/2D _δ_ -Bi2O3/CN 

hybrid was prepared via a solvothermal method for TC photodegradation (Figure 12e).<sup>[123]</sup> The morphology of the thin _δ_ -Bi2O3 and CN NSs provided a large contact area between the two components, shortening the migration distance of charge carriers (Figure 12f,g). A Z-scheme heterojunction was formed as the contact interface, which could enhance the transfer and separation of photoexcited electron-hole pairs (Figure 12h). Compared to 0D/2D and 1D/2D nanostructures, the 2D/2D structure with a relatively large contact surface ensures better structural stability.<sup>[186,187]</sup> Besides, CN NSs were coupled with nitrogen-doped ZnO (N-ZnO) NSs to form a type-II heterojunction for RhB photodegradation.<sup>[124]</sup> The 2D/2D face-to-face heterojunction benefited the exposure of abundant active sites and fast charge migration across the interface, leading to an enhanced photo-Fenton-like catalytic activity. Under light irradiation, electrons could migrate from the CB of CN to the CB of N-ZnO, reacting with O2 to generate H2O2 via a single-step two-electron production process. H2O2 was rapidly reduced into •OH for pollutant degradation. As a result, N-ZnO/CN achieved efficient RhB photodegradation efficiency of 96% in 180 min. 

### _6.2.4. 3D Nanomaterials_ 

The configuration of CN with 3D hierarchical nanomaterials possesses a relatively higher SSA, improved visible light absorption 

**2201743 (20 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 13.** Dimensionality effects of nanomaterials loading on 2D CN NSs. 

ability and effective charge migration/separation.<sup>[188,189]</sup> A 3D/2D Fe2O3 nanoflowers/CN nanosheet system was prepared for photo-Fenton degradation of azo dyes (Figure 12i,j).<sup>[125]</sup> The 3D flower-shaped Fe2O3 facilitated the construction of the Z-scheme interface and promoted the electron-hole pairs’ migration and separation. The well-match band position made visible light absorption be enhanced. Driven by Z-scheme charge transfer, electrons accumulated on the CB of CN could either react with O2 to produce O2<sup>•−</sup> or reduce Fe<sup>3+</sup> on Fe2O3 surface to Fe<sup>2+</sup> . The as-produced Fe<sup>2+</sup> could react with H2O2 to generate<sup>•</sup> OH. As a result, the Fe2O3/CN hybrid showed an enhanced amaranth azo dye photo-Fenton-like degradation efficiency of 97.6% within 10 min (Figure 12k) and great stability (Figure 12l). Another 3D/2D nanostructure sample was fabricated by loading 3D CoS nanoflowers on 2D CN nanocrystals via a hydrothermal method.<sup>[190]</sup> This 3D/2D configuration induced the surface scattering and reflection effects to extend the light absorption ability. Besides, the 3D floral CoS nanostructure could increase the SSA and provide abundant active sites. In this composite, CoS acted as a cocatalyst to capture photoexcited electrons from the CB of CN, improving the charge separation efficiency. Meanwhile, these electrons can react with O2 to produce H2O2 and convert to<sup>•</sup> OH. Consequently, the composite exhibited enhanced RhB degradation efficiency of 93% in 105 min and reaction kinetics of 0.0265 min<sup>−1</sup> , 2.35 times higher than that of 2D CN (0.0113 min<sup>−1</sup> ). 

Dimensionality control of metal-containing species (0D to 3D) induces the formation of a heterojunction interface that promotes the charge transfer and separation ( **Figure 13** ). Coupling 2D CN NSs with metal-containing species in different dimensions (0D to 3D) can well integrate both of their advantages: i) 0D nanomaterials possess typical properties of a high surface-to-volume ratio, effective charge transfer, manageable size tunability, and excellent dispersion. 0D nanomaterials can be stably and uniformly dispersed on a 2D CN platform due to the large accessible surface area of CN NS. The 0D/2D hybrids afford abundant active sites for pollutant adsorption and surface catalytic reactions. ii) 1D nanotubes/nanorods possess a high length-to-dimeter ratio, mechanical deformability, and long-term photostability. The construction of 1D/2D configuration could enable the fast and long-distance charge migration 

along the 1D axis. iii) Against 0D/2D and 1D/2D structures, coupling 2D CN NSs with other NSs can provide an extensive and tight contact surface for better interfacial charge transfer and separation. iv) The well-defined 3D hierarchical nanostructures offer abundant active sites and improve light absorption ability due to their relatively high SSA. 

### **6.3. Constructing CN/Metal-Based Semiconductor Heterojunctions** 

Building heterostructure has attracted much attention for improving the separation of photogenerated electron-hole pairs and overcoming the charge recombination problem of pristine CN, thereby improving its photocatalytic ability.<sup>[191,192]</sup> In CN-based heterojunction composites, CN is hybridized with another semiconductor (SC) material with dissimilar electronic structure (Fermi level), especially metal-based CN such as metal oxides,<sup>[175,193,194]</sup> multicomponent metal oxides,<sup>[130,195]</sup> metal chalcogenides,<sup>[196,197]</sup> metal phosphates,<sup>[137,198]</sup> and MOFs,<sup>[139,199]</sup> to construct a band-matching semiconductor junction. The intimate CN/SC interface is essential for improving the charge carrier mobility.<sup>[35,200]</sup> Due to the band potential differences between CN and the other SC, band bending could be formed near the interface, generating an internal electric field within the space charge region.<sup>[201,202]</sup> This can accelerate charge carrier transfer, inhibit their recombination, and prolong their lifetime. CN-based heterojunctions can be classified into several types according to different charge transfer mechanisms, including type-I (straddling gap), type-II (staggered gap), p-n and Z-scheme heterojunctions. Type-II and Z-scheme systems have been mostly investigated for CN-based photo-Fenton-like catalysis ( **Figure 14** ). 

### _6.3.1. Constructing CN/Metal-Containing SC Type-II Heterojunctions_ 

CN-based type-II heterojunction nanohybrids have been fabricated via hydrothermal methods,<sup>[129]</sup> electrostatic selfassembly,<sup>[126]</sup> calcination,<sup>[20]</sup> or other approaches<sup>[105,138]</sup> to 

**2201743 (21 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 14.** CN/metal-based semiconductor (SC) heterojunctions for photo-Fenton-like catalysis. 

improve the photocatalytic ability of CN. In such a system, the band edge potentials of CN and the other coupled SC (e.g., Fe3O4,<sup>[126]</sup> Fe2O3,<sup>[129]</sup> WO3,<sup>[20]</sup> ZnFe2O4<sup>[130]</sup> ) are staggered. The typical type-II heterojunction is constructed, provided that the CB position of one SC (SC-I) is more negative than that of the other one (SC-II) while the VB is opposite. As shown in Figure 14, photogenerated electrons in SC-I can transfer to the CB of SC-II due to band alignment, while holes in the VB can migrate oppositely. CN can serve as either SC-I or SC-II, depending on the VB and CB positions of CN and the other coupled SC. As a result, photogenerated electrons and holes are spatially separated and accumulated respectively on CN and the other SC for oxidation and reduction reactions. Evidently, the type-II heterojunction can effectively prevent the rapid recombination of electron-hole pairs, thereby improving the photocatalytic ability of CN/SC composites. 

Many reports showed that metal oxides (e.g., Fe2O3,<sup>[129]</sup> Fe3O4,<sup>[126]</sup> WO3<sup>[20]</sup> ) could be coupled with CN to form a typeII heterostructure, which exhibited an excellent catalytic activity and stability toward photo-Fenton-like catalysis. For instance, an iron oxide/CN (Fe-CN) hybrid was developed for dicamba photodegradation using a three-dimensional (3D) printed photon concentrator.<sup>[127]</sup> The iron oxide and CN (Fe-CN) heterojunction suppressed the recombination of photoinduced electron-hole pairs via the effective separation of charges across the heterointerface. Under LED light irradiation, Fe-CN-3/ H2O2 completely removed dicamba within 3 h. Furthermore, conductive reduced graphene oxide (rGO) can be introduced to the iron oxide/CN heterostructure to benefit additional electron flow from CB of CN to rGO, thus further retarding recombination of electron-hole pairs.<sup>[128]</sup> WO3 with a bandgap of 2.6 – 2.9 eV is also suitable to construct type-II heterojunction 

with CN.<sup>[203,204]</sup> For example, Fe (II) or Fe (III)-doped CN/WO3 composites were synthesized, showing an enhanced photoactivity toward visible-light-driven PNP degradation ( **Figure 15** a,b).<sup>[20]</sup> The tight interfacial coupling of WO3 with Fe-doped CN formed a type II heterojunction (Figure 15c), which was beneficial for the separation of photogenerated electron-hole pairs. Because the consumption rate of Fe(II) was relatively higher than the conversion rate of Fe(III) to Fe(II), the Fe(II) doped CN/WO3 composite can react faster at the beginning of the process, which was evidenced by the higher amount of<sup>•</sup> OH generated compared to Fe(III) doped samples (Figure 15d). Under visible light irradiation, photogenerated electrons in the CB of CN migrated to the CB of WO3 and reacted with Fe(III) to generate Fe(II). Therefore, Fe(II) and Fe(III) co-doped CN/WO3/H2O2 exhibited a similar PNP conversion efficiency of 90% in 4 h, 9-fold as high as that of pure CN. This enhancement was mainly attributed to the synergistic effect of Fe doping and the built intimate heterojunction. 

Besides, semiconductive MFe _x_ Oy (M = Zn, Cu, Mn, and Ba) with multicomponent metal elements have been reported to construct type-II CN/MFe _x_ Oy heterostructure composites, which are magnetically separable and allow for an excellent photocatalytic activity.<sup>[105,130–136]</sup> For instance, a magnetic core-shell CuFe2O4@ CN composite was prepared via a self-assembly method (Figure 15e,f).<sup>[131]</sup> The composite possessed a narrowed bandgap and increased visible-light absorption ability. The enhanced charge separation across the CuFe2O4@CN interface further promoted photocatalytic activity (Figure 15g). O2<sup>•−</sup> ,<sup>•</sup> OH, and h<sup>+</sup> contributed to orange II decolorization. With the presence of H2O2, the optimal CuFe2O4@CN composite removed 98% orange II in 210 min under visible-light irradiation (Figure 15h). Other than this, similar synergistic enhancement effects can 

**2201743 (22 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 15.** TEM images of a) Fe (II)-doped CN/WO3 and b) Fe (III)-doped CN/WO3. c) Reaction mechanism of photo-Fenton-like catalytic reaction by Fe-doped CN/WO3. d)<sup>•</sup> OH radicals trapping PL spectra. e,f) HRTEM images of CuFe2O4@CN. Reproduced with permission.<sup>[20]</sup> Copyright 2017, Elsevier B.V. g) Reaction mechanism of Orange II photodegradation by CuFe2O4@CN/H2O2/vis system. h) UV-vis spectral changes for Orange II photodegradation with CuFe2O4@CN/H2O2/vis system. Reproduced with permission.<sup>[131]</sup> Copyright 2015, Elsevier B.V. i) TEM image (inset: HRTEM image) of Zn0.94Fe0.04S/CN. j) Photodegradation performance of PNP. Reproduced with permission.<sup>[138]</sup> Copyright 2020, Elsevier B.V. k) TEM image of NFO/5g-CN/7.5CD composite. l) Reaction mechanism of NFO/5g-CN/7.5CD indirect Z-scheme heterojunction. Reproduced under the terms of the CC-BY-NC-ND license.<sup>[150]</sup> Copyright 2020, American Chemical Society. 

also be observed in other magnetic M-Fe _x_ Oy oxides, such as ZnFe2O4,<sup>[130,133]</sup> BiFeO3,<sup>[132]</sup> BaFe12O19,<sup>[136]</sup> and NiFe2O4.<sup>[135]</sup> 

Apart from metal oxides, CN can construct type II heterojunctions with other SCs, including Cu2(OH)PO4,<sup>[137]</sup> ZnS,<sup>[205,206]</sup> and metal-organic frameworks (MOFs).<sup>[139]</sup> Wang et al.<sup>[138]</sup> synthesized a Zn0.94Fe0.04S/CN binary composite via a rapid microwave hydrothermal method (Figure 15i). Successful Fe atom doping in ZnS decreased its bandgap and enabled visible-light absorption. The deposition of Zn0.94Fe0.04S on CN increased the exposed SSA and improved the light-harvesting capacity. Under simulated solar light irradiation, Zn0.94Fe0.04S/CN/H2O2 exhibited PNP degradation efficiency of 96.0% in 60 min (Figure 15j). 

Coupling CN with Fe-containing MOFs (Fe-MOFs) can serve as heterogeneous catalysts in Fenton-like catalysis, where the mixed Fe valences in Fe-MOFs can accelerate the regeneration of Fe<sup>2+</sup> for H2O2 activation.<sup>[207–209]</sup> The intimate interface between CN and Fe-MOFs benefits charge transfer, thereby improving the reaction efficiency.<sup>[139,210]</sup> Very recently, an ultrathin mesoporous CN/NH2-MIL−101(Fe) (M101-U) 

octahedron composite was prepared through a solvothermal method.<sup>[139]</sup> A close contact interface between CN and M101-U was revealed to form an effective heterojunction. The interfacial resistance between CN and M101-U was low, which promoted rapid transfer and separation of photoinduced charges. Under visible-light irradiation, the CN/M101-U composite degraded 2,6-dichlorophen and 2,4,5-trichlorophenol by 98.7 and 97.3% in 3 h, respectively, with self-generated H2O2. 

To sum up, constructing CN-based type-II heterojunction is a promising strategy to improve charge transfer and separation, reduce the recombination of charge carriers, and couple the respective advantages of CN and another SC component, leading to an enhanced photocatalytic activity. 

### _6.3.2. Constructing CN/Metal-Based SC Z-Scheme Heterojunctions_ 

Generally, type-II heterojunction is beneficial for accelerated charge separation, while it may weaken the redox ability and 

**2201743 (23 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

cannot maximize the redox capability of the individual SC components.<sup>[83,192]</sup> In a type-II heterojunction system, photogenerated electrons accumulate on a SC with less-negative CB, and holes accumulate on the other SC with less-positive VB, limiting the reduction and oxidation abilities of electrons and holes, respectively.<sup>[211]</sup> It may impair the driving force toward photocatalytic reaction.<sup>[212]</sup> Therefore, it is highly desired to delve into more efficient photocatalytic heterojunction systems. Interestingly, developing advanced synthetic routes, creating surface defects to generate band bending, or introducing electron mediators could change the charge migration pathway and turn a type-II heterojunction into a more efficient Z-scheme system.<sup>[150,213]</sup> Compared to the type-II system, a CN-based Z-scheme heterojunction processes a similar band structure configuration but with a completely different charge transfer route (Figure 14). Specifically, the migration pathway of photogenerated charge carriers resembles the letter “Z” in Z-scheme heterojunction.<sup>[214–216]</sup> Under light irradiation, photoinduced electrons on the CB of SC-II will migrate to the VB of SC-I for recombination, preserving electrons in the CB of SC-I and holes in the VB of SC-II with a strong redox ability in a Z-scheme heterojunction.<sup>[217]</sup> In addition, reductive and oxidative active sites are spatially separated. There are direct and indirect CN-based Z-scheme heterojunctions, depending on the existence of external electron mediators. 

_Constructing CN/Metal-Containing SC Direct Z-Scheme Heterojunctions_ : No external mediator is involved in a direct Z-scheme heterostructure, and photoexcited electrons in SC-I will combine holes in SC-II directly through the interface. CN has been coupled with various SCs like metal oxides,<sup>[49,140–142]</sup> multicomponent metal oxides,<sup>[144–147]</sup> and metal oxychlorides<sup>[143]</sup> to construct direct Z-scheme heterostructures for enhanced photo-Fenton-like catalysis. 

For examples, a Z-scheme _α_ -Fe2O3@CN photocatalyst was fabricated through a co-calcination process of a Fe-based MOF and melamine.<sup>[140]</sup> Under visible light irradiation, the _α_ -Fe2O3@ CN/H2O2 degraded tetracycline (TC) by 92% in 60 min with robust stability in a wide pH range. In addition, Wang et al.<sup>[49]</sup> reported a self-H2O2-supplying _α_ -Fe2O3/CN Z-scheme composite to degrade RhB and TCH. Importantly, the constructed _α_ -Fe2O3/CN Z-scheme heterojunction improved charge separation and transfer. Also, the introduction of _α_ -Fe2O3 enlarged the SSA and created meso/macropores on CN, resulting in the exposure of more surface-active sites. Under solar light irradiation, the as-obtained _α_ -Fe2O3/CN composite realized 96% RhB degradation in 90 min and 95% TCH degradation in 150 min with reliable stability. 

The Z-scheme heterojunction is highly effective for heavy metal removal, producing ROS (e.g., O2<sup>•−</sup> and<sup>•</sup> OH) and electron/hole pairs for oxidation or reduction of harmful metal ions, such as low-valence-state As(III) and high-valence-state Cr(VI). As an example, a Co9S8/CN Z-scheme heterojunction was constructed to simultaneously remove 2,4-dichlorophenoxyacet (2, 4-D) and Cr(VI) under simulated solar light irradiation.<sup>[148]</sup> The direct contact between CN and Co9S8 induced the formation of a Co-N _x_ intermediate medium. The accumulated electrons on the CB of Co9S8 could reduce dissolved O2 into O2<sup>•−</sup> . H2O2 was in situ formed from the reduction of partial O2<sup>•−</sup> and was further decomposed to produce<sup>•</sup> OH. The enhanced 

photo-Fenton-like performance for simultaneous removal of Cr(VI) and 2, 4-D can be attributed to the synergistic effect of the ROS (O2<sup>•−</sup> from O2 reduction and<sup>•</sup> OH from H2O2) and holes that were separated/migrated to the surface CN. Specifically, for the treatment of Cr(VI), it can be directly reduced by the photoexcited electrons to Cr(III). Also, Cr(VI) can react with O2<sup>•−</sup> to produce Cr(V) and O2. Meanwhile, 2, 4-D can be oxidized by holes and<sup>•</sup> OH. With the aid of simulated solar light, the removal efficiencies of Cr(VI) and 2, 4-D reached 85% and 50%, respectively, in 180 min without an external H2O2 addition. 

Also, CN can couple with some magnetic MFe _x_ Oy-type (M = Co, Zn, La) SCs (e.g., ZnFe2O4<sup>[146]</sup> ) and metal oxychlorides (e.g., FeOCl<sup>[143]</sup> ) to obtain Z-scheme heterojunction composites.<sup>[144–147]</sup> The hybridization of CN and ZnFe2O4 (ZFO) to construct a Z-scheme composite for the removal of MB and RhB mixed dyes under sunlight illumination.<sup>[146]</sup> The intercalation of magnetic ZFO with CN formed a type-II p-n heterojunction via a sol–gel calcination method. The surface defect presented in the heterojunction produced bending upwards of the ZFO band and the bending downwards of g-CN, forming a direct Z-scheme heterojunction. The enhanced photodegradation was largely attributed to the efficient separation and migration of photoinduced electron-hole pairs at the interfaces. ZFO/CN Z-scheme can also be employed to remove Cr(VI) and As(III) via photo-Fenton-like catalytic reactions.<sup>[147]</sup> Driven by Z-scheme charge transfer, the accumulated electrons on the CB of ZFO directly reduced Cr(VI) to Cr(III). H2O2 was generated via a two-step single-electron reduction process. With the assistance of oxalate, more O2<sup>•−</sup> was produced, which can be further converted to H2O2, improving the in situ H2O2 generation efficiency. The ample Fe<sup>2+</sup> /Fe<sup>3+</sup> redox pairs in ZFO activated H2O2 to produce O2<sup>•−</sup> and<sup>•</sup> OH. As(III) can be then oxidized by O2<sup>•−</sup> and<sup>•</sup> OH to As(IV). Interestingly, the reduced Cr cations, such as Cr(III), could also react with H2O2 to generate<sup>•</sup> OH to oxidize As(III). The ZFO/CN Z-scheme system exhibited great photoFenton-like catalytic and recycling ability to completely remove Cr(VI) and As(III). 

_Constructing CN/Metal-Containing SC Indirect Z-Scheme_ : Typically, for an indirect Z-scheme composite, two SCs are linked together, using solid conductive materials (e.g., carbon dot, carbon nanotube, graphene) as a mediator to tune the electron transfer pathway. Similar to direct Z-scheme heterojunction, building CN-based indirect Z-scheme nanohybrids can improve the photocatalytic ability of CN by adjusting band structure, extending the visible light absorption region, facilitating charge transfer, and exposing more active sites. In addition, the introduction of solid mediators provides a low-resistance electron transfer pathway and improves the stability and photoactivity of the composite.<sup>[218]</sup> Palanivel et al.<sup>[150]</sup> reported a carbon dot-intercalated NiFe2O4/CN (NFO/5g-CN/7.5CD) Z-scheme visible-light photocatalyst for RhB and tetracycline (TCN) degradation (Figure 15k). As such, carbon dots (CD) served as an electron mediator to convert type-II to Z-scheme heterojunction (Figure 15l). The as-prepared ternary Z-scheme composite showed an enhanced photocatalytic ability due to its enhanced light absorption ability and charge separation efficiency. Under visible-light irradiation, the Z-scheme composite activated H2O2 to remove RhB and TCN by 99% and 93%, 

**2201743 (24 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

respectively, in 120 min. Thereafter, carbon nanotube (CNT) has also been employed as an electron mediator to facilitate the separation and migration of photoinduced electron-hole pairs due to its superior optical and electrical properties. A ternary CN/CNT/Bi2Fe4O9 Z-scheme hybrid was reported for acid orange 7 (AO-7) photodegradation.<sup>[149]</sup> With the increasing amount of CNT content, the light absorbance of the ternary composites was gradually increased due to the strong visible light absorption capability of CNT. Bridging by CNT, the transfer of photoinduced electrons from Bi2Fe4O9 to CN can be improved, which boosts charge carrier separation. As expected, CN/CNT/Bi2Fe4O9 composite/H2O2 exhibited an enhanced AO-7 degradation efficiency of ≈90% in 3 h under simulated sunlight irradiation. 

In summary, type II and Z-scheme heterojunctions have both been considered as an effective engineering approach to obtain enhanced performance in photo-Fenton-like catalysis ( **Figure 16** ). CN-based Z-scheme heterojunction systems have their superiority in photo-Fenton-like catalysis due to the preservation of separated electrons and holes with strong redox ability and the combined advantages of different components. However, compared to the progress in constructing type-II heterojunction, there is still much room for developing CN-based Z-scheme heterostructures for photo-Fenton-like catalysis. Moreover, a critical issue frequently neglected in both type-II and Z-scheme heterojunctions is that the charge-transfer route is debatable. Thus, better understanding of the photoexcitation, trapping and migration mechanism of electrons and holes is essential for the rational design of CN-based heterojunction. Optimization of interfacial properties and geometry architecture of heterojunction is of importance to ensure excellent photocatalytic performance. Recently, step-scheme (S-scheme), 

which consists of oxidation- and reduction-type photocatalysts with staggered band structures, was introduced.<sup>[211]</sup> Thus, developing novel CN-based S-scheme photocatalysts could be a future direction for enhanced photo-Fenton-like catalytic performance. Moreover, opportunities exist in combining different modified CN species to form a self-junction. For example, band alignment between CN and heteroatoms (e.g., B, K)-doped CN NSs could lead to the establishment of the CN-based self van der Waals (vdW) type-II homojunction.<sup>[100]</sup> The synergistic effect of an enlarged SSA, narrowed bandgap, improved light absorption and “face to face” vdW charge interaction contributed to the enhanced photocatalytic activity. 

As stated above, modifications of CN with metal-containing species are comprehensively discussed, ranging from sub-nanoscale (e.g., organometallic molecules, doped metal atoms and single atoms) to nanoscale (e.g., 0–3D) materials, with emphasis on their structure-performance relationships (Table 2). These strategies were developed to improve the H2O2 activation efficiency of CN by offering a metal redox cycle (M<sup>(</sup><sup>_n_+1)+</sup> ↔ M<sup>n+</sup> ). Moreover, they offer great potential in altering the optical and electronic properties of CN to optimize its photoFenton-like catalytic activity. Molecular and elemental doping could improve the _π_ -electron delocalization, accelerate charge migration/separation and endow a broad visible-light absorption range. However, excess doping could lead to the formation of recombination centers of charge carriers, lowering its photocatalytic activity. Therefore, it is significant to precisely control the doping concentration and position. Over the past decade, decreasing the active metal sizes to the atomic level could elevate the atom utilization for efficient photocatalytic activity. CN-based SACs possessed well-defined active sites and coordination environment, which could facilitate the insightful exploration 



**Figure 16.** Comparison of different CN-based heterojunctions for photo-Fenton-like catalysis. 

**2201743 (25 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

of structure–activity relationships. Moreover, exfoliating CN into 2D NSs renders it with a large interface contact area for coupling with 0D, 1D, 2D, 3D nanomaterials, exhibiting unique dimensionality-dependent advantages. Interface engineering for heterojunction (e.g., type-II and Z-scheme) construction has been proved to be efficient for promoted charge migration, extended light adsorption and improved reaction kinetics. Compared with type-II heterojunction, Z-scheme is recognized as a more efficient heterogenization as it can not only improve the transfer and separation efficiency of photocarriers, but also retain a strong redox ability. It is believed that using a single modification method only possesses limited merits. Rational design of functional CN nanocomposites by combing different engineering strategies could integrate their advantages for efficient photo-Fenton-like catalysis. 

## **7. Concluding Remarks and Future Prospects** 

To conclude, substantial progress has been made on structure modification of CN for enhanced POP and heavy metal removal from polluted water via photo-Fenton-like reactions. Here, we reviewed the recent advances in engineering strategies, including morphology control, defect engineering, nonmetal atom doping, and organic molecule doping as well as coupling CN with metal-containing species. In addition, we focused on some critical parameters for enhancing the CN-based photo-Fenton-like catalysis, such as visible-light harvesting and utilization, charge excitation, separation and transfer, active sites, and H2O2 activation efficiency. To this end, this review discussed different engineering strategies and mechanisms in improving the photo-Fenton-like catalytic performance based on current literature, with emphasis on the relationship between their structure and catalytic performance. 

Functional carbon nitride provides great potential in photoFenton-like catalysis. Morphology control on CN can enlarge its SSA for more active site exposure and improved light absorption for enhanced photocatalytic activity. Defect control and nonmetal atom doping can modulate the physicochemical properties and photoelectronic structural features of CN for enhanced photo-Fenton-like catalysis. Defect and nonmetal co-engineering could provide the dopants with a specific site to precisely control the doping concentration and position. Loading sub-nanoscale (including organometallic molecules, doped metal atoms and single atoms) and nanoscale metal-containing species can introduce active sites for H2O2 activation by triggering the metal redox cycle (M<sup>(</sup><sup>_n_+1)+</sup> ↔ M<sup>n+</sup> ). Besides, these engineering strategies could modulate the internal/surface structure and photo/electrochemical properties of CN to promote the charge transfer, enhance the reactant adsorption/absorption and improve visible-light harvesting. Current work has shifted to developing CN-based SACs, which could maximize the utilization efficiency of metal atoms and exhibit excellent catalytic performance. Hybridization of CN with other band-matching SCs to construct a Z-scheme or type-II heterojunction has been well studied. Compared to the latter heterojunction, whose charge transfer is realized by sacrificing electrons and holes with more robust redox 

capabilities, the Z-scheme structure has excellent charge separation/transfer efficiency and superior redox potential. Although some encouraging results in the development of CN for photo-Fenton-like catalysis have been achieved, there still exist some critical challenges and attractive opportunities in rational catalyst design, insightful mechanism study, and practical large-scale application. Based on the recent progress, some points and suggestions are listed as follows. 

- 1) It is still a great challenge to develop highly active and stable CN-based catalysts for photo-Fenton-like reactions. Although many research works have demonstrated that the CN-based catalysts exhibited great performances in the photodegradation of POPs, the mineralization efficiency of POPs is still low, seriously retarding its extensive application. Furthermore, metal species introduced in CN catalysts may suffer from metal leaching, especially over a long-term operation. The loss of metal-containing active species will restrict its photocatalytic activity. It is of great significance to optimize the synthetic method of CN-based catalysts and develop new systems to improve not only the photodegradation activity, but also mineralization efficiency and stability in future research. 

- 2) Most research work typically focuses on applying a single engineering strategy, which could only have limited merits. Integrating merits and maximizing the synergistic effect between different engineering strategies is important. For instance, many research works have reported coupling CN with other SCs to construct heterojunctions. However, ingenious fabrication techniques on CN and the coupled SC should be further investigated. These research efforts may include heterojunction construction with other engineering strategies, such as morphology control for maximum interface, vacancies/defects introduction, atom/molecule doping, to harness the synergistic effect for enhanced photo-Fenton-like performance. Precisely modulating physicochemical properties of CN and coupled SC, including surface property, molecular and electronic structure configuration, is essential while implementing these strategies. 

- 3) Compared with the progress in other photocatalytic reactions (e.g., H2 evolution, CO2 reduction, and N2 fixation), the functionalization of CN for photo-Fenton-like catalysis has been less investigated thus far, especially some new systems like SACs are still at the infancy stage, and there is much room for investigation. So far, most CN-supported metal materials for photo-Fenton-like applications showed a large size and wide distribution of the particles. This is because metal species naturally tend to agglomerate, especially under harsh operating conditions. Making the atomic metal dispersion while keeping the metal content at a reasonable loading level is important for photo-Fenton-like reactions toward POPs degradation. Furthermore, strong metal-carrier interactions arising from interfacial bonding can hamper iron leaching and avoid secondary pollution. At present, controllable, scaleup, and simple synthesis of SACs-CN-based catalysts with reasonably high single atom loading also remains challenging. Industrial practical applications may demand high coverage of single atoms on supports to achieve desirable degradation efficiency per catalyst volume. Thus, developing a 

**2201743 (26 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

high diversity of atomical metal dispersion on CN supports is important to achieve highly efficient activation of H2O2 to meet the industrial application requirements. 

- 4) In situ production of H2O2 in the photo-Fenton-like process is considered as an effective way to minimize the cost and risk of H2O2 synthesis, storage and transport. Although some advances have been achieved thus far, in situ photocatalytic H2O2 production using CN-based catalysts still suffers from a relatively low yield. It is crucial to promote the generation of H2O2 while inhibiting its decomposition. Specifically, low selectivity of the O2 reduction pathway and the rapid H2O2 self-decomposition are considered as the main drawbacks affecting the photocatalytic H2O2 production efficiency. To improve the selectivity of O2 reduction pathway, creating vacancies on CN could lead to the formation of amino groups to alter the H2O2 production route from a two-step single-electron O2 reduction reaction to a direct two-electron O2 reduction process, improving the H2O2 production efficiency.<sup>[219]</sup> The before-mentioned energy band tuning strategies, such as heterojunction construction, could successfully alter the band redox potentials for photocatalytic H2O2 evolution via O2 reduction while inhibiting the subsequent decomposition of H2O2. However, only a few catalysts have been reported for photo-Fenton-like catalysis with in situ generated H2O2 toward POP degradation. We encourage to investigate more suitable SCs for the electronic structure modulation of CN and the combination of other modification strategies. 

- 5) Fundamentally, we still face challenges in understanding the in-depth mechanism of reaction intermediates, electron transfer routes, and H2O2 generation and activation pathways. State-of-the-art in situ characterization techniques and theoretical calculations can be used as tools to reveal the potential reaction intermediates, structure-performance relationship, and catalytic mechanism.<sup>[220]</sup> The photo-Fenton reaction, especially for the system with in situ H2O2 generation, involves complex reaction pathways with multiactivated species: O2<sup>•−</sup> can be produced from the one-electron reduction of O2;<sup>•</sup> OH can be generated from the activation of selfproduced H2O2; photoexcited holes can be separated and transferred to the surface of catalyst for the direct oxidation of pollutants. Therefore, for in-depth understanding of the reaction mechanism, it is essential to distinguish the specific roles of different activated species. This can be achieved by measuring the in situ H2O2 production rate and tracing ROS using in situ EPR. 

- 6) Despite the successful applications of CN-based photo-Fenton-like catalysis at the laboratory scale, many hurdles must be overcome before transferring it to an industrially practical scale. Several attractive aspects such as long-term stability, high solar energy utilization efficiency, operating flexibility, easy separability and recyclability are critically important to satisfy the requirements of practical applications. 

Open access publishing facilitated by The University of Adelaide, as part of the Wiley - The University of Adelaide agreement via the Council of Australian University Librarians. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Keywords** 

Fenton-like reaction, graphitic carbon nitride, photocatalysis, water treatment 

Received: February 13, 2022 Revised: March 13, 2022 Published online: May 12, 2022 

- [1] W. G. Barb, J. H. Baxendale, P. George, K. R. Hargrave, _Nature_ **1949** , _163_ , 692. 

- [2] E. Brillas, I. Sirés, M. A. Oturan, _Chem. Rev._ **2009** , _109_ , 6570. 

- [3] A. Shimizu, M. Tokumura, K. Nakajima, Y. Kawase, _J. Hazard. Mater._ **2012** , _201_ , 60. 

- [4] D. B. Miklos, C. Remy, M. Jekel, K. G. Linden, J. E. Drewes, U. Hübner, _Water Res._ **2018** , _139_ , 118. 

- [5] K. Wang, C. Han, Z. Shao, J. Qiu, S. Wang, S. Liu, _Adv. Funct. Mater._ **2021** , _31_ , 2102089. 

- [6] J. Lee, U. Von Gunten, J. H. Kim, _Environ. Sci. Technol._ **2020** , _54_ , 3064. 

- [7] Y. H. Guan, J. Chen, L. J. Chen, X. X. Jiang, Q. Fu, _Front. Chem._ **2020** , _8_ , 581198. 

- [8] H. J. H. Fenton, _J. Chem. Soc., Trans._ **1894** , _65_ , 899. 

- [9] J. Feng, X. Hu, P. L. Yue, _Water Res._ **2006** , _40_ , 641. 

- [10] K. V. Plakas, S. D. Sklari, D. A. Yiankakis, G. T. Sideropoulos, V. T. Zaspalis, A. J. Karabelas, _Water Res._ **2016** , _91_ , 183. 

- [11] H. B. Ammar, _Ultrason. Sonochem._ **2016** , _33_ , 164. 

- [12] X. Wang, X. Zhang, Y. Zhang, Y. Wang, S.-P. Sun, W. D. Wu, Z. Wu, _J. Mater. Chem. A_ **2020** , _8_ , 15513. 

- [13] A. D. Bokare, W. Choi, _J. Hazard. Mater._ **2014** , _275_ , 121. [14] O. M. Rodríguez-Narváez, L. S. Pérez, N. G. Yee, J. M. Peralta-Hernández, E. R. Bandala, _Int. J. Environ. Sci. Technol._ **2019** , _16_ , 1515. 

- [15] Y. Liu, Y. Zhao, J. Wang, _J. Hazard. Mater._ **2021** , _404_ , 124191. 

- [16] N. Banić, B. Abramović, J. Krstić, D. Šojić, D. Lončarević, Z. Cherkezova-Zheleva, V. Guzsvány, _Appl. Catal., B_ **2011** , _107_ , 363. 

- [17] Y. Deng, M. Xing, J. Zhang, _Appl. Catal., B_ **2017** , _211_ , 157. 

- [18] J. Wang, R. Dong, Q. Yang, H. Wu, Z. Bi, Q. Liang, Q. Wang, C. Wang, Y. Mei, Y. Cai, _Nanoscale_ **2019** , _11_ , 16592. 

- [19] M. Ahmad, S. Chen, F. Ye, X. Quan, S. Afzal, H. Yu, X. Zhao, _Appl. Catal., B_ **2019** , _245_ , 428. 

- [20] M. Yoon, Y. Oh, S. Hong, J. S. Lee, R. Boppella, S. H. Kim, F. Marques Mota, S. O. Kim, D. H. Kim, _Appl. Catal., B_ **2017** , _206_ , 263. 

- [21] G. hee Moon, S. Kim, Y. J. Cho, J. Lim, D. hyo Kim, W. Choi, _Appl. Catal., B_ **2017** , _218_ , 819. 

- [22] W. Shi, D. Du, B. Shen, C. Cui, L. Lu, L. Wang, J. Zhang, _ACS Appl. Mater. Interfaces_ **2016** , _8_ , 20831. 

## **Acknowledgements** 

The authors acknowledge the financial support by the Australian Research Council (Grant Nos. DP190103548, DP200103206, and DE210100253) and the 111 Project (Grant No. D20015). 

- [23] Q. Wang, P. Xu, G. Zhang, W. Zhang, L. Hu, P. Wang, _Phys. Chem. Chem. Phys._ **2018** , _20_ , 18601. 

- [24] D. Wang, M. Wang, Z. Li, _ACS Catal._ **2015** , _5_ , 6852. 

- [25] J. Xu, G. Dai, B. Chen, D. He, Y. Situ, H. Huang, _Chemosphere_ **2020** , _241_ , 125022. 

**2201743 (27 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

- [26] D. Yue, X. Qian, M. Kan, M. Fang, J. Jia, X. Yang, Y. Zhao, _Appl. Catal., B_ **2018** , _229_ , 211. 

- [27] Y. Li, S. Ouyang, H. Xu, X. Wang, Y. Bi, Y. Zhang, J. Ye, _J. Am. Chem. Soc._ **2016** , _138_ , 13289. 

- [28] H. Zhang, W. Tian, X. Duan, H. Sun, Y. Shen, G. Shao, S. Wang, _Nanoscale_ **2020** , _12_ , 6937. 

- [29] M. S. Nasir, G. Yang, I. Ayub, S. Wang, L. Wang, X. Wang, W. Yan, S. Peng, S. Ramakarishna, _Appl. Catal., B_ **2019** , _257_ , 117855. 

- [30] L. Zhou, H. Zhang, H. Sun, S. Liu, M. O. Tade, S. Wang, W. Jin, _Catal. Sci. Technol._ **2016** , _6_ , 7002. 

- [31] J. Lin, W. Tian, H. Zhang, X. Duan, H. Sun, S. Wang, _Energy Fuels_ **2021** , _35_ , 7. 

- [32] W.-J. Ong, L.-L. Tan, Y. H. Ng, S.-T. Yong, S.-P. Chai, _Chem. Rev._ **2016** , _116_ , 7159. 

- [33] F. Dong, Z. Zhao, T. Xiong, Z. Ni, W. Zhang, Y. Sun, W. K. Ho, _ACS Appl. Mater. Interfaces_ **2013** , _5_ , 11392. 

- [34] X. Wang, S. Blechert, M. Antonietti, _ACS Catal._ **2012** , _2_ , 1596. 

- [35] M. S. Khan, F. Zhang, M. Osada, S. S. Mao, S. Shen, _Sol. RRL_ **2020** , _4_ , 1900435. 

- [36] G. Dong, D. Chen, J. Luo, Y. Zhu, Y. Zeng, C. Wang, _J. Hazard. Mater._ **2017** , _335_ , 66. 

- [37] M. Zhou, H. Ou, S. Li, X. Qin, Y. Fang, S. Lee, X. Wang, W. Ho, _Adv. Sci._ **2021** , _8_ , 2001801. 

- [38] L. Lin, Z. Yu, X. Wang, _Angew. Chem., Int. Ed._ **2019** , _58_ , 6164. 

- [39] J. Xu, K. Li, S. Wu, W. Shi, T. Peng, _J. Mater. Chem. A_ **2015** , _3_ , 7453. 

- [40] P. Huang, J. Huang, S. A. Pantovich, A. D. Carl, T. G. Fenton, C. A. Caputo, R. L. Grimm, A. I. Frenkel, G. Li, _J. Am. Chem. Soc._ **2018** , _140_ , 16042. 

- [41] W. Niu, Y. Yang, _ACS Energy Lett._ **2018** , _3_ , 2796. 

- [42] D. W. Kim, J. Choi, J. Byun, J. T. Kim, G. S. Lee, J. G. Kim, D. Kim, P. Boonmongkolras, P. F. McMillan, H. M. Lee, A. J. Clancy, B. Shin, S. O. Kim, _ACS Appl. Mater. Interfaces_ **2021** , _13_ , 61215. 

- [43] J. Zhang, X. Zhao, L. Chen, S. Li, H. Chen, Y. Zhu, S. Wang, Y. Liu, H. Zhang, X. Duan, M. Wu, S. Wang, H. Sun, _Energy Environ. Mater._ **2022** . https://doi.org/10.1002/eem2.12365. 

- [44] D. Zhao, Y. Wang, C. L. Dong, Y. C. Huang, J. Chen, F. Xue, S. Shen, L. Guo, _Nat. Energy_ **2021** , _6_ , 388. 

- [45] J. Jiang, X. Wang, Y. Liu, Y. Ma, T. Li, Y. Lin, T. Xie, S. Dong, _Appl. Catal., B_ **2020** , _278_ , 119349. 

- [46] H. Hou, X. Zeng, X. Zhang, _Angew. Chem., Int. Ed._ **2020** , _59_ , 17356. [47] Y. Shiraishi, S. Kanazawa, Y. Sugano, D. Tsukamoto, H. Sakamoto, S. Ichikawa, T. Hirai, _ACS Catal._ **2014** , _4_ , 774. 

- [48] J. Ma, K. Wang, C. Wang, X. Chen, W. Zhu, G. Zhu, W. Yao, Y. Zhu, _Appl. Catal., B_ **2020** , _276_ , 119150. 

- [49] Y. Wang, H. Song, J. Chen, S. Chai, L. Shi, C. Chen, Y. Wang, C. He, _Appl. Surf. Sci._ **2020** , _512_ , 145650. 

- [50] Z. Yang, Y. Zhang, Z. Schnepp, _J. Mater. Chem. A_ **2015** , _3_ , 14081. [51] K. Kaya, B. Kiskan, B. Kumru, B. V. K. J. Schmidt, Y. Yagci, _Eur. Polym. J._ **2020** , _122_ , 109410. 

- [52] J. Xu, S. Cao, T. Brenner, X. Yang, J. Yu, M. Antonietti, M. Shalom, _Adv. Funct. Mater._ **2015** , _25_ , 6265. 

- [53] G. Lei, Y. Cao, W. Zhao, Z. Dai, L. Shen, Y. Xiao, L. Jiang, _ACS Sustainable Chem. Eng._ **2019** , _7_ , 4941. 

- [54] S. Navalon, A. Dhakshinamoorthy, M. Alvaro, H. Garcia, _ChemSusChem_ **2011** , _4_ , 1712. 

- [55] S. Navalon, M. Alvaro, H. Garcia, _Appl. Catal., B_ **2010** , _99_ , 1. 

- [56] Y. Yin, L. Shi, W. Li, X. Li, H. Wu, Z. Ao, W. Tian, S. Liu, S. Wang, H. Sun, _Environ. Sci. Technol._ **2019** , _53_ , 11391. 

- [57] A. Rossner, S. A. Snyder, D. R. U. Knappe, _Water Res._ **2009** , _43_ , 3787. 

- [58] X. Huo, H. Yi, Y. Fu, Z. An, L. Qin, X. Liu, B. Li, S. Liu, L. Li, M. Zhang, F. Xu, G. Zeng, C. Lai, _Environ. Sci. Nano_ **2021** , _8_ , 1835. 

- [59] W. Tian, H. Zhang, X. Duan, H. Sun, G. Shao, S. Wang, _Adv. Funct. Mater._ **2020** , _30_ , 1909265. 

- [60] W. Tian, J. Lin, H. Zhang, X. Duan, H. Wang, H. Sun, S. Wang, _J. Hazard. Mater._ **2022** , _423_ , 127083. 

- [61] Y. Cui, J. Huang, X. Fu, X. Wang, _Catal. Sci. Technol._ **2012** , _2_ , 1396. 

- [62] Y. Li, N. Luo, Z. Tian, H. Li, M. Yang, W. Shang, S. Yifeng, M. Qu, A. Zhou, _Colloids Surf., A_ **2020** , _586_ , 124190. 

- [63] C. Bin Chen, C. X. Li, Y. J. Zhang, Y. J. Wang, J. Y. Lu, H. Q. Liu, W. W. Li, _Environ. Sci.: Nano_ **2018** , _5_ , 2966. 

- [64] R. S. Sahu, Y.-h. Shih, W.-L. Chen, _J. Hazard. Mater._ **2021** , _402_ , 123509. 

- [65] M. Liu, D. Zhang, J. Han, C. Liu, Y. Ding, Z. Wang, A. Wang, _Chem. Eng. J._ **2020** , _382_ , 123017. 

- [66] C. Zhou, Z. Zeng, G. Zeng, D. Huang, R. Xiao, M. Cheng, C. Zhang, W. Xiong, C. Lai, Y. Yang, W. Wang, H. Yi, B. Li, _J. Hazard. Mater._ **2019** , _380_ , 120815. 

- [67] I. F. Silva, I. F. Teixeira, R. D. F. Rios, G. M. do Nascimento, I. Binatti, H. F. V. Victória, K. Krambrock, L. A. Cury, A. P. C. Teixeira, H. O. Stumpf, _J. Hazard. Mater._ **2021** , _401_ , 123713. 

- [68] S. N. Guo, Y. Zhu, Y. Y. Yan, Y. L. Min, J. C. Fan, Q. J. Xu, _Appl. Catal. B_ **2016** , _185_ , 315. 

- [69] L. Jing, M. He, M. Xie, Y. Song, W. Wei, Y. Xu, H. Xu, H. Li, _J. Colloid Interface Sci._ **2021** , _583_ , 113. 

- [70] Z. Li, D. Huang, C. Zhou, W. Xue, L. Lei, R. Deng, Y. Yang, S. Chen, W. Wang, Z. Wang, _Chem. Eng. J._ **2020** , _382_ , 122657. 

- [71] C. Zhou, G. Zeng, D. Huang, Y. Luo, M. Cheng, Y. Liu, W. Xiong, Y. Yang, B. Song, W. Wang, B. Shao, Z. Li, _J. Hazard. Mater._ **2020** , _386_ , 121947. 

- [72] K. Kailasam, J. D. Epping, A. Thomas, S. Losse, H. Junge, _Energy Environ. Sci._ **2011** , _4_ , 4668. 

- [73] F. K. Kessler, Y. Zheng, D. Schwarz, C. Merschjann, W. Schnick, X. Wang, M. J. Bojdys, _Nat. Rev. Mater._ **2017** , _2_ , 17030. 

- [74] H. Yan, _Chem. Commun._ **2012** , _48_ , 3430. 

- [75] Z. Liang, X. Zhuang, Z. Tang, H. Li, L. Liu, W. Kang, _J. Mater. Chem. A_ **2021** , _9_ , 6805. 

- [76] W. Li, J. Liu, D. Zhao, _Nat. Rev. Mater._ **2016** , _1_ , 16023. 

- [77] N. D. Petkovich, A. Stein, _Chem. Soc. Rev._ **2013** , _42_ , 3721. 

- [78] X. Chen, C. Li, M. Grätzel, R. Kostecki, S. S. Mao, _Chem. Soc. Rev._ **2012** , _41_ , 7909. 

- [79] S. Yang, Y. Gong, J. Zhang, L. Zhan, L. Ma, Z. Fang, R. Vajtai, X. Wang, P. M. Ajayan, _Adv. Mater._ **2013** , _25_ , 2452. 

- [80] Y. Xiao, G. Tian, W. Li, Y. Xie, B. Jiang, C. Tian, D. Zhao, H. Fu, _J. Am. Chem. Soc._ **2019** , _141_ , 2508. 

- [81] Q. Liang, Z. Li, Z. H. Huang, F. Kang, Q. H. Yang, _Adv. Funct. Mater._ **2015** , _25_ , 6885. 

- [82] P. Niu, L.-C. Yin, Y.-Q. Yang, G. Liu, H.-M. Cheng, _Adv. Mater._ **2014** , _26_ , 8046. 

- [83] S. Cao, J. Low, J. Yu, M. Jaroniec, _Adv. Mater._ **2015** , _27_ , 2150. 

- [84] X. Wang, L. Wu, Z. Wang, H. Wu, X. Zhou, H. Ma, H. Zhong, Z. Xing, G. Cai, C. Jiang, F. Ren, _Sol. RRL_ **2019** , _3_ , 1800298. 

- [85] A. Kumar, P. Raizada, A. Hosseini-Bandegharaei, V. K. Thakur, V.-H. Nguyen, P. Singh, _J. Mater. Chem. A_ **2021** , _9_ , 111. 

- [86] W. J. Lee, J. Lim, S. O. Kim, _Small Methods_ **2017** , _1_ , 1600014. 

- [87] Q. Liu, H. Cao, W. Xu, J. Li, Q. Zhou, W. Tao, H. Zhu, X. Cao, L. Zhong, J. Lu, X. Peng, J. Wu, _Cell Rep. Phys. Sci._ **2021** , _2_ , 100491. 

- [88] H. Li, F. Ning, X. Chen, A. Shi, _Catal. Sci. Technol._ **2021** , _11_ , 3270. 

- [89] G. Liu, P. Niu, C. Sun, S. C. Smith, Z. Chen, G. Q. Lu, H. M. Cheng, _J. Am. Chem. Soc._ **2010** , _132_ , 11642. 

- [90] J. Ran, T. Y. Ma, G. Gao, X. W. Du, S. Z. Qiao, _Energy Environ. Sci._ **2015** , _8_ , 3708. 

- [91] G. Zhang, M. Zhang, X. Ye, X. Qiu, S. Lin, X. Wang, _Adv. Mater._ **2014** , _26_ , 805. 

- [92] S. Guo, Z. Deng, M. Li, B. Jiang, C. Tian, Q. Pan, H. Fu, _Angew. Chem., Int. Ed._ **2016** , _55_ , 1830. 

- [93] J. Zhang, J. Zhang, F. He, Y. Chen, J. Zhu, D. Wang, S. Mu, H. Y. Yang, _Nano-Micro Lett._ **2021** , _13_ , 65. 

**2201743 (28 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [94] S. Wu, H. Yu, S. Chen, X. Quan, _ACS Catal._ **2020** , _10_ , 14380. [95] Z. Zhao, Y. Long, Y. Chen, F. Zhang, J. Ma, _Chem. Eng. J._ **2022** , _430_ , 132682. 

- [96] Y. Shiraishi, S. Kanazawa, Y. Kofuji, H. Sakamoto, S. Ichikawa, S. Tanaka, T. Hirai, _Angew. Chem., Int. Ed._ **2014** , _53_ , 13454. 

- [97] Y. Kofuji, S. Ohkita, Y. Shiraishi, H. Sakamoto, S. Ichikawa, S. Tanaka, T. Hirai, _ACS Sustainable Chem. Eng._ **2017** , _5_ , 6478. 

- [98] Y. Kofuji, S. Ohkita, Y. Shiraishi, H. Sakamoto, S. Tanaka, S. Ichikawa, T. Hirai, _ACS Catal._ **2016** , _6_ , 7021. 

- [99] J. Ran, W. Guo, H. Wang, B. Zhu, J. Yu, S. Z. Qiao, _Adv. Mater._ **2018** , _30_ , 1800128. 

- [100] X. Li, P. Zhang, H. Zhang, W. Tian, Y. Yang, K. Hu, D. Chen, Q. Li, X. Duan, H. Sun, S. Wang, _Nano Res._ **2021** . https://doi. org/10.1007/s12274-021-3744-x. 

- [101] Z. Fang, Y. Bai, L. Li, D. Li, Y. Huang, R. Chen, W. Fan, W. Shi, _Nano Energy_ **2020** , _75_ , 104865. 

- [102] J. Zhang, Y. Li, X. Zhao, L. Wang, H. Chen, S. Wang, X. Xu, L. Shi, L. C. Zhang, Y. Zhu, H. Zhang, Y. Liu, G. Nealon, S. Zhang, M. Wu, S. Wang, H. Sun, _Nano Energy_ **2021** , _89_ , 106357. 

- [103] J. Zhang, Y. Li, X. Zhao, H. Zhang, L. Wang, H. Chen, S. Wang, X. Xu, L. Shi, L. C. Zhang, J. P. Veder, S. Zhao, G. Nealon, M. Wu, S. Wang, H. Sun, _ACS Nano_ **2020** , _14_ , 17505. 

- [104] H. Lan, F. Wang, M. Lan, X. An, H. Liu, J. Qu, _Environ. Sci. Technol._ **2019** , _53_ , 6264. 

- [105] X. Wang, A. Wang, J. Ma, _J. Hazard. Mater._ **2017** , _336_ , 81. 

- [106] K. Y. A. Lin, J. T. Lin, _Chemosphere_ **2017** , _182_ , 54. 

- [107] K. Li, Y. Liang, H. Yang, S. An, H. Shi, C. Song, X. Guo, _Catal. Today_ **2021** , _371_ , 58. 

- [108] W. Luo, W. Huang, X. Feng, Y. Huang, X. Song, H. Lin, S. Wang, G. Mailhot, _RSC Adv._ **2020** , _10_ , 21876. 

- [109] S. Ji, Y. Yang, Z. Zhou, X. Li, Y. Liu, _J. Water Process Eng._ **2020** , _40_ , 101804. 

- [110] W. Miao, Y. Liu, X. Chen, Y. Zhao, S. Mao, _Carbon_ **2020** , _159_ , 461. [111] Y. Gao, J. Duan, X. Zhai, F. Guan, X. Wang, J. Zhang, B. Hou, _Nanomaterials_ **2020** , _10_ , 1751. 

- [112] Q. Dong, Y. Chen, L. Wang, S. Ai, H. Ding, _Appl. Surf. Sci._ **2017** , _426_ , 1133. 

- [113] L. Li, M. Liang, J. Huang, S. Zhang, Y. Liu, F. Li, _Environ. Sci. Pollut. Res._ **2020** , _27_ , 29391. 

- [114] N. Salimiyan Rizi, A. Shahzeydi, M. Ghiaci, L. Zhang, _J. Environ. Chem. Eng._ **2020** , _8_ , 104219. 

- [115] S. An, G. Zhang, T. Wang, W. Zhang, K. Li, C. Song, J. T. Miller, S. Miao, J. Wang, X. Guo, _ACS Nano_ **2018** , _12_ , 9441. 

- [116] F. Chen, X. Wu, C. Shi, H. Lin, J. Chen, Y. Shi, S. Wang, X. Duan, _Adv. Funct. Mater._ **2021** , _31_ , 2007877. 

- [117] X. Qian, Y. Wu, M. Kan, M. Fang, D. Yue, J. Zeng, Y. Zhao, _Appl. Catal. B_ **2018** , _237_ , 513. 

- [118] J. Xi, H. Xia, X. Ning, Z. Zhang, J. Liu, Z. Mu, S. Zhang, P. Du, X. Lu, _Small_ **2019** , _15_ , 1902744. 

- [119] H. Zhao, C. Tian, J. Mei, S. Yang, P. K. Wong, _Chem. Eng. J._ **2020** , _390_ , 124551. 

- [120] X. An, S. Wu, Q. Tang, H. Lan, Y. Tang, H. Liu, J. Qu, _Catal. Commun._ **2018** , _112_ , 63. 

- [121] R. Koutavarapu, B. Babu, C. V. Reddy, K. Yoo, M. Cho, J. Shim, _J. Mater. Sci._ **2020** , _55_ , 1170. 

- [122] S. L. Prabavathi, K. Saravanakumar, G. Mamba, V. Muthuraj, _Colloids Surf., A_ **2019** , _581_ , 123845. 

- [123] Z. Xu, Y. Shi, L. Li, H. Sun, M. S. Amin, F. Guo, H. Wen, W. Shi, _J. Alloys Compd._ **2022** , _895_ , 162667. 

- [124] S. Kumar, A. Kumar, A. Kumar, R. Balaji, V. Krishnan, _ChemistrySelect_ **2018** , _3_ , 1919. 

- [125] L. Wang, Y. Wang, X. Li, T. He, R. Wang, Y. Zhao, H. Song, H. Wang, _J. Environ. Chem. Eng._ **2021** , _9_ , 105907. 

- [126] S. Sahar, A. Zeb, Y. Liu, N. Ullah, A. Xu, _Chin. J. Catal._ **2017** , _38_ , 2110. 

- [127] M. M. Desipio, S. E. Van Bramer, R. Thorpe, D. Saha, _J. Hazard. Mater._ **2019** , _376_ , 178. 

- [128] D. Saha, M. C. Visconti, M. M. Desipio, R. Thorpe, _Chem. Eng. J._ **2020** , _382_ , 122857. 

- [129] Z. Wang, Y. Fan, R. Wu, Y. Huo, H. Wu, F. Wang, X. Xu, _RSC Adv._ **2018** , _8_ , 5180. 

- [130] Y. Yao, Y. Cai, F. Lu, J. Qin, F. Wei, C. Xu, S. Wang, _Ind. Eng. Chem. Res._ **2014** , _53_ , 17294. 

- [131] Y. Yao, F. Lu, Y. Zhu, F. Wei, X. Liu, C. Lian, S. Wang, _J. Hazard. Mater._ **2015** , _297_ , 224. 

- [132] J. An, G. Zhang, R. Zheng, P. Wang, _J. Environ. Sci._ **2016** , _48_ , 218. 

- [133] S. Borthakur, L. Saikia, _J. Environ. Chem. Eng._ **2019** , _7_ , 103035. 

- [134] B. Palanivel, S. devi Mudisoodum perumal, T. Maiyalagan, V. Jayarman, C. Ayyappan, M. Alagiri, _Appl. Surf. Sci._ **2019** , _498_ , 143807. 

- [135] B. Palanivel, M. Shkir, T. Alshahrani, A. Mani, _Diamond Relat. Mater._ **2021** , _112_ , 108148. 

- [136] H. Wang, Y. Xu, L. Jing, S. Huang, Y. Zhao, M. He, H. Xu, H. Li, _J. Alloys Compd._ **2017** , _710_ , 510. 

- [137] C. Chen, Y. Zhou, N. Wang, L. Cheng, H. Ding, _RSC Adv._ **2015** , _5_ , 95523. 

- [138] Q. Wang, P. Wang, P. Xu, Y. Li, J. Duan, G. Zhang, L. Hu, X. Wang, W. Zhang, _Appl. Catal., B_ **2020** , _266_ , 118653. 

- [139] S. Su, Z. Xing, S. Zhang, M. Du, Y. Wang, Z. Li, P. Chen, Q. Zhu, W. Zhou, _Appl. Surf. Sci._ **2021** , _537_ , 147890. 

- [140] T. Guo, K. Wang, G. Zhang, X. Wu, _Appl. Surf. Sci._ **2019** , _469_ , 331. 

- [141] S. Lee, J.-W. Park, _Sustainability_ **2020** , _12_ , 2866. 

- [142] K. Sharma, P. Raizada, A. Hosseini-Bandegharaei, P. Thakur, R. Kumar, V. K. Thakur, V. H. Nguyen, S. Pardeep, _Process Saf. Environ. Prot._ **2020** , _142_ , 63. 

- [143] J. Zhao, M. Ji, J. Di, Y. Zhang, M. He, H. Li, J. Xia, _J. Photochem. Photobiol., A_ **2020** , _391_ , 112343. 

- [144] Y. Yao, G. Wu, F. Lu, S. Wang, Y. Hu, J. Zhang, W. Huang, F. Wei, _Environ. Sci. Pollut. Res._ **2016** , _23_ , 21833. 

- [145] Y. Ye, H. Yang, X. Wang, W. Feng, _Mater. Sci. Semicond. Process._ **2018** , _82_ , 14. 

- [146] B. Palanivel, V. Jayaraman, C. Ayyappan, M. Alagiri, _J. Water Process Eng._ **2019** , _32_ , 100968. 

- [147] D. Lei, J. Xue, X. Peng, S. Li, Q. Bi, C. Tang, L. Zhang, _Appl. Catal., B_ **2021** , _282_ , 119578. 

- [148] J. Gu, H. Chen, F. Jiang, X. Wang, L. Li, _Chem. Eng. J._ **2019** , _360_ , 1188. 

- [149] L. Di, H. Yang, T. Xian, X. Chen, _Micromachines_ **2018** , _9_ , 613. 

- [150] B. Palanivel, A. Mani, _ACS Omega_ **2020** , _5_ , 19747. 

- [151] X. Li, Y. Pi, L. Wu, Q. Xia, J. Wu, Z. Li, J. Xiao, _Appl. Catal. B_ **2017** , _202_ , 653. 

- [152] T. Wang, Y. Bai, W. Si, W. Mao, Y. Gao, S. Liu, _J. Photochem. Photobiol., A_ **2021** , _404_ , 112856. 

- [153] C. Xiong, Q. Ren, X. Liu, Z. Jin, Y. Ding, H. Zhu, J. Li, R. Chen, _Appl. Surf. Sci._ **2021** , _543_ , 148844. 

- [154] S. Chu, Y. Wang, Y. Guo, J. Feng, C. Wang, W. Luo, X. Fan, Z. Zou, _ACS Catal._ **2013** , _3_ , 912. 

- [155] X. Fan, L. Zhang, R. Cheng, M. Wang, M. Li, Y. Zhou, J. Shi, _ACS Catal._ **2015** , _5_ , 5008. 

- [156] Z. Lin, X. Wang, _Angew. Chem., Int. Ed._ **2013** , _52_ , 1735. 

- [157] J. Y. Bai, L. J. Wang, Y. J. Zhang, C. F. Wen, X. L. Wang, H. G. Yang, _Appl. Catal., B_ **2020** , _266_ , 118590. 

- [158] D. A. Nichela, A. M. Berkovic, M. R. Costante, M. P. Juliarena, F. S. García Einschlag, _Chem. Eng. J._ **2013** , _228_ , 1148. 

- [159] J. N. Zhu, X. Q. Zhu, F. F. Cheng, P. Li, F. Wang, Y. W. Xiao, W. W. Xiong, _Appl. Catal., B_ **2019** , _256_ , 117830. 

- [160] S. Ji, Y. Chen, X. Wang, Z. Zhang, D. Wang, Y. Li, _Chem. Rev._ **2020** , _120_ , 11900. 

- [161] Z. Guo, Y. Xie, J. Xiao, Z. J. Zhao, Y. Wang, Z. Xu, Y. Zhang, L. Yin, H. Cao, J. Gong, _J. Am. Chem. Soc._ **2019** , _141_ , 12005. 

**2201743 (29 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [162] H. Zhang, W. Tian, X. Duan, H. Sun, S. Liu, S. Wang, _Adv. Mater._ **2020** , _32_ , 1904037. 

- [163] X. Li, S. Zhao, X. Duan, H. Zhang, S. ze Yang, P. Zhang, S. P. Jiang, S. Liu, H. Sun, S. Wang, _Appl. Catal., B_ **2021** , _283_ , 119660. 

- [164] J. Fu, S. Wang, Z. Wang, K. Liu, H. Li, H. Liu, J. Hu, X. Xu, H. Li, M. Liu, _Front. Phys._ **2020** , _15_ , 28. 

- [165] Y. Shang, X. Xu, B. Gao, S. Wang, X. Duan, _Chem. Soc. Rev._ **2021** , _50_ , 5281. 

- [166] S. Mitchell, E. Vorobyeva, J. Pérez-Ramírez, _Angew. Chem., Int. Ed._ **2018** , _59_ , 10651. 

- [167] S. Ji, Y. Qu, T. Wang, Y. Chen, G. Wang, X. Li, J. Dong, Q. Chen, W. Zhang, Z. Zhang, S. Liang, R. Yu, Y. Wang, D. Wang, Y. Li, _Angew. Chem., Int. Ed._ **2020** , _132_ , 10738. 

- [168] Y. Oh, J. O. Hwang, E. S. Lee, M. Yoon, V. D. Le, Y. H. Kim, D. H. Kim, S. O. Kim, _ACS Appl. Mater. Interfaces_ **2016** , _8_ , 25438. 

- [169] Y. Chen, S. Ji, C. Chen, Q. Peng, D. Wang, Y. Li, _Joule_ **2018** , _2_ , 1242. 

- [170] H. Lv, Y. V. Geletii, C. Zhao, J. W. Vickers, G. Zhu, Z. Luo, J. Song, T. Lian, D. G. Musaev, C. L. Hill, _Chem. Soc. Rev._ **2012** , _41_ , 7572. 

- [171] Y. F. Song, R. Tsunashima, _Chem. Soc. Rev._ **2012** , _41_ , 7384. 

- [172] Y. Chen, X. Bai, _Catalysts_ **2020** , _10_ , 142. 

- [173] L. Hu, C. Zhang, G. Zeng, G. Chen, J. Wan, Z. Guo, H. Wu, Z. Yu, Y. Zhou, J. Liu, _RSC Adv._ **2016** , _6_ , 78595. 

- [174] R. Wang, K. Q. Lu, Z. R. Tang, Y. J. Xu, _J. Mater. Chem. A_ **2017** , _5_ , 3717. 

- [175] H. Zhang, W. Tian, L. Zhou, H. Sun, M. Tade, S. Wang, _Appl. Catal., B_ **2018** , _223_ , 2. 

- [176] S. S. Yi, J. M. Yan, Q. Jiang, _J. Mater. Chem. A_ **2018** , _6_ , 9839. 

- [177] Z. He, J. Zhang, X. Li, S. Guan, M. Dai, S. Wang, _Small_ **2020** , _16_ , 2005051. 

- [178] F. X. Xiao, J. Miao, H. B. Tao, S. F. Hung, H. Y. Wang, H. Bin Yang, J. Chen, R. Chen, B. Liu, _Small_ **2015** , _11_ , 2115. 

- [179] W. K. Jo, T. S. Natarajan, _Chem. Eng. J._ **2015** , _281_ , 549. 

- [180] R. Dadigala, R. Bandi, B. R. Gangapuram, A. Dasari, H. H. Belay, V. Guttena, _J. Environ. Chem. Eng._ **2019** , _7_ , 102822. 

- [181] D. Zhou, Z. Chen, Q. Yang, X. Dong, J. Zhang, L. Qin, _Sol. Energy Mater. Sol. Cells_ **2016** , _157_ , 399. 

- [182] Y. Wang, Y. Xie, H. Sun, J. Xiao, H. Cao, S. Wang, _J. Hazard. Mater._ **2016** , _301_ , 56. 

- [183] H. Zhang, W. Tian, Y. Li, H. Sun, M. O. Tadé, S. Wang, _J. Mater. Chem. A_ **2018** , _6_ , 6265. 

- [184] M. Wang, C. Jin, J. Kang, J. Liu, Y. Tang, Z. Li, S. Li, _Chem. Eng. J._ **2021** , _416_ , 128118. 

- [185] Z. Pan, G. Zhang, X. Wang, _Angew. Chem., Int. Ed._ **2019** , _58_ , 7102. 

- [186] Q. Xiang, B. Cheng, J. Yu, _Angew. Chem., Int. Ed._ **2015** , _54_ , 11350. [187] S. Cao, B. Shen, T. Tong, J. Fu, J. Yu, _Adv. Funct. Mater._ **2018** , _28_ , 18001361. 

- [188] Y. Liu, X. Xu, J. Zhang, H. Zhang, W. Tian, X. Li, M. O. Tade, H. Sun, S. Wang, _Appl. Catal., B_ **2018** , _239_ , 334. 

- [189] N. Li, Y. Tian, J. Zhao, J. Zhang, W. Zuo, L. Kong, H. Cui, _Chem. Eng. J._ **2018** , _352_ , 412. 

- [190] Y. Song, Z. Mo, J. Fu, X. Zhang, X. She, J. Yuan, H. Chen, J. Qian, C. Zhou, Y. Wu, W. Yang, H. Li, H. Xu, _Colloids Surf., A_ **2021** , _617_ , 126151. 

- [191] H. Zhang, W. Tian, X. Guo, L. Zhou, H. Sun, M. O. Tadé, S. Wang, _ACS Appl. Mater. Interfaces_ **2016** , _8_ , 35203. 

- [192] J. Low, J. Yu, M. Jaroniec, S. Wageh, A. A. Al-Ghamdi, _Adv. Mater._ **2017** , _29_ , 1601694. 

- [193] Z. Jiang, W. Wan, H. Li, S. Yuan, H. Zhao, P. K. Wong, _Adv. Mater._ **2018** , _30_ , 1706108. 

- [194] Y. Li, K. Lv, W. Ho, F. Dong, X. Wu, Y. Xia, _Appl. Catal., B_ **2017** , _202_ , 611. 

- [195] G. Zhang, X. Zhu, D. Chen, N. Li, Q. Xu, H. Li, J. He, H. Xu, J. Lu, _Environ. Sci.: Nano_ **2020** , _7_ , 676. 

- [196] D. Ren, W. Zhang, Y. Ding, R. Shen, Z. Jiang, X. Lu, X. Li, _Sol. RRL_ **2020** , _4_ , 1900423. 

- [197] F. Guo, W. Shi, M. Li, Y. Shi, H. Wen, _Sep. Purif. Technol._ **2019** , _210_ , 608. 

- [198] X. Yang, H. Tang, J. Xu, M. Antonietti, M. Shalom, _ChemSusChem_ **2015** , _8_ , 1350. 

- [199] H. Wang, X. Yuan, Y. Wu, G. Zeng, X. Chen, L. Leng, H. Li, _Appl. Catal. B_ **2015** , _174_ , 445. 

- [200] W. K. Jo, N. Clament Sagaya Selvam, _J. Hazard. Mater._ **2015** , _299_ , 462. 

- [201] Y. Wang, Q. Wang, X. Zhan, F. Wang, M. Safdar, J. He, _Nanoscale_ **2013** , _5_ , 8326. 

- [202] H. Wang, L. Zhang, Z. Chen, J. Hu, S. Li, Z. Wang, J. Liu, X. Wang, _Chem. Soc. Rev._ **2014** , _43_ , 5234. 

- [203] S. Huang, Y. Long, S. Ruan, Y. J. Zeng, _ACS Omega_ **2019** , _4_ , 15593. 

- [204] H. Li, Y. Gao, Y. Zhou, F. Fan, Q. Han, Q. Xu, X. Wang, M. Xiao, C. Li, Z. Zou, _Nano Lett._ **2016** , _16_ , 5547. 

- [205] L. Shao, D. Jiang, P. Xiao, L. Zhu, S. Meng, M. Chen, _Appl. Catal., B_ **2016** , _198_ , 200. 

- [206] W. J. Kim, E. Jang, T. J. Park, _Appl. Surf. Sci._ **2017** , _419_ , 159. 

- [207] D. Chen, S. Chen, Y. Jiang, S. Xie, H. Quan, L. Hua, X. Luo, L. Guo, _RSC Adv._ **2017** , _7_ , 49024. 

- [208] X. Tao, X. Yuan, L. Huang, S. Shang, D. Xu, _RSC Adv._ **2020** , _10_ , 36363. 

- [209] N. Geng, W. Chen, H. Xu, M. Ding, T. Lin, Q. Wu, L. Zhang, _Ultrason. Sonochem._ **2021** , _72_ , 105411. 

- [210] X. Y. Dao, X. F. Xie, J. H. Guo, X. Y. Zhang, Y. S. Kang, W. Y. Sun, _ACS Appl. Energy Mater._ **2020** , _3_ , 3946. 

- [211] Q. Xu, L. Zhang, B. Cheng, J. Fan, J. Yu, _Chem_ **2020** , _6_ , 1543. 

- [212] J. Low, C. Jiang, B. Cheng, S. Wageh, A. A. Al-Ghamdi, J. Yu, _Small Methods_ **2017** , _1_ , 1700080. 

- [213] C. H. Wang, D. D. Qin, D. L. Shan, J. Gu, Y. Yan, J. Chen, Q. H. Wang, C. H. He, Y. Li, J. J. Quan, X. Q. Lu, _Phys. Chem. Chem. Phys._ **2017** , _19_ , 4507. 

- [214] Y. Liu, H. Zhang, J. Ke, J. Zhang, W. Tian, X. Xu, X. Duan, H. Sun, M. O Tade, S. Wang, _Appl. Catal. B_ **2018** , _228_ , 64. 

- [215] D. Huang, S. Chen, G. Zeng, X. Gong, C. Zhou, M. Cheng, W. Xue, X. Yan, J. Li, _Coord. Chem. Rev._ **2019** , _385_ , 44. 

- [216] H. Zhang, W. Tian, J. Zhang, X. Duan, S. Liu, H. Sun, S. Wang, _Mater. Today Energy_ **2021** , _23_ , 100915. 

- [217] J. Lin, W. Tian, H. Zhang, X. Duan, H. Sun, H. Wang, Y. Fang, Y. Huang, S. Wang, _J. Hazard. Mater._ **2022** , _434_ , 128866. 

- [218] A. Iwase, Y. H. Ng, Y. Ishiguro, A. Kudo, R. Amal, _J. Am. Chem. Soc._ **2011** , _133_ , 11054. 

- [219] S. Li, G. Dong, R. Hailili, L. Yang, Y. Li, F. Wang, Y. Zeng, C. Wang, _Appl. Catal., B_ **2016** , _190_ , 26. 

- [220] P. Zhang, Y. Yang, X. Duan, Y. Liu, S. Wang, _ACS Catal._ **2021** , _11_ , 11129. 

**2201743 (30 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 







**Jingkai Lin** is currently a Ph.D. student at the School of Chemical Engineering and Advanced Materials, The University of Adelaide, Australia. His current research focuses on the development of novel photocatalysts for solar-light-driven energy and environmental applications 

**Huayang Zhang** is currently a research fellow at the School of Chemical Engineering and Advanced Materials, The University of Adelaide, Australia. In 2018, he received his Ph.D. degree in chemical engineering from Curtin University, Australia. His current research focuses on the design and synthesis of novel artificial and semiartificial nanostructured materials for solar-lightdriven energy and environmental applications 

**Shaobin Wang** obtained the degrees of B.Sc. and M.Sc. in Chemistry from Peking University and Ph.D. in Chemical Engineering from the University of Queensland. He has been a John Curtin Distinguished Professor at Curtin University and is now a professor at the School of Chemical Engineering and Advanced Materials, the University of Adelaide. His research interests focus on nanomaterial synthesis and application for adsorption and catalysis, fuel and energy conversion and environmental remediation. 

**2201743 (31 of 31)** 

_Adv. Funct. Mater._ **2022** , _32_ , 2201743 

© 2022 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

