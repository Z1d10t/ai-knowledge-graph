# Compositional texture engineering for highly stable wide-bandgap perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 348 |
| 作者 | Qi Jiang, Jinhui Tong, Rebecca A. Scheidt, Xiao-Ming Wang, Amy E. Louks, Yeming Xian, R. Tirawat, A. Palmstrom et al. |
| DOI | 10.1126/science.adf0194 |
| 源文件 | 045_Jiang_2022_Compositional-texture-engineering-for-highly-sta.pdf |

---
# **Compositional texture engineering for highly stable wide-bandgap perovskite** 

# **solar cells** 

Qi Jiang,<sup>1</sup> Jinhui Tong,<sup>1*</sup> Rebecca A. Scheidt,<sup>1</sup> Xiaoming Wang,<sup>2</sup> Amy E. Louks,<sup>3</sup> Yeming Xian,<sup>2</sup> Robert Tirawat,<sup>1</sup> Axel F. Palmstrom,<sup>3</sup> Matthew P. Hautzinger,<sup>1</sup> Steven P. Harvey,<sup>3</sup> Steve Johnston,<sup>3</sup> Laura <mark>T. Schelhas</mark> ,<sup>1</sup> Bryon W. Larson,<sup>1</sup> Emily L. Warren,<sup>1</sup> Matthew C. Beard,<sup>1,4</sup> Joseph J. Berry,<sup>3,4,5</sup> Yanfa Yan,<sup>2</sup> and Kai Zhu<sup>1*</sup> 

- 1 Chemistry and Nanoscience Center, National Renewable Energy Laboratory, Golden, CO 80401, USA 

- 2 Department of Physics and Astronomy and Wright Center for Photovoltaics Innovation and Commercialization, University of Toledo, Toledo, OH 43606, USA 

- 3 Materials Science Center, National Renewable Energy Laboratory, Golden, CO 80401, USA 

- 4 Renewable and Sustainable Energy Institute, University of Colorado Boulder, Boulder, CO 

- 80309, USA 

- 5 Department of Physics, University of Colorado Boulder, Boulder, CO 80309, USA 

- Corresponding authors: tongjinhui1@gmail.com (J.T.); Kai.Zhu@nrel.gov (K.Z.) 

1 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **<mark>Abstract</mark>** 

<mark>Developing highly stable and efficient wide-bandgap (WBG) perovskite solar cells (PSCs) based on Br-I mixed halide perovskite (with Br >20%) is critical to create tandem solar cells. However, issues with B</mark> r-I phase segregation under solar cell operational conditions (such as light and heat) limit the device voltage and operational stability. This challenge is often exacerbated by the ready defect formation associated with the rapid crystallization of Br-rich perovskite chemistry with antisolvent processes. <mark>Here, we combine the rapid Br crystallization with a gentle gas-quench method to prepare highly textured columnar 1.75-electron volt (eV) Br-I mixed WBG perovskite films with reduced defect density. With this approach, we obtained 1.75-eV WBG PSCs with >20% power conversion efficiency, ~1.33-volt open-circuit voltage (V</mark> oc <mark>), and excellent operational stability (<5% degradation over 1100-hours operation under 1.2-sun at 65 Celsius). When further integrated with 1.25-eV narrow-bandgap PSC, we obtained a 27.1%-efficient all-perovskite twoterminal tandem device with a high V</mark> oc <mark>of 2.2 volts.</mark> 

## **One-Sentence Summary** 

<mark>Compositional engineering of textured growth of Br-I mixed wide-bandgap perovskite ⎯ enabled by gas quench and high Br content ⎯ produced highly stable and efficient 1.75-eV perovskite solar cells, leading to perovskite tandem solar cells with ultrahigh photovoltages.</mark> 

2 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

The bandgap tunability of organic-inorganic hybrid perovskites makes them a suitable candidate for applications in both single-junction and multijunction solar cells ( _1-3_ ). Perovskite-based tandem solar cells have demonstrated rapid improvements in power conversion efficiencies (PCEs) for multiple tandem configurations ( _4-6_ ). As the top subcell for an efficient tandem device, the wide-bandgap (WBG) perovskite (about 1.7 eV or higher) harvests high-energy photons, contributes to high open-circuit voltage (Voc), and enables stable operation of the tandem stack by filtering harmful ultraviolet radiation from reaching the bottom cell ( _7_ ). 

For state-of-the-art perovskite tandem devices, WBG perovskites are normally based on Br-I mixed halides with a range of high Br contents ( _4, 5_ ). In principle, adding more Br should make the perovskite absorber more stable, given <mark>the strength of the Pb-Br bond relative to the PbI bond. This effect is associated with the smaller radius of Br</mark><sup>−</sup> <mark>(1.96 Å) compared to I</mark><sup>−</sup> <mark>(2.20 Å) and the higher electronegativity of Br (</mark> _<mark>3, 8, 9</mark>_ <mark>).</mark> However, perovskites with mixed halides are prone to phase segregation under operating conditions (exposure to light and heat) and limit WBG <mark>perovskite solar cell (</mark> PSC) performance ( _10-12_ ) by creating a large Voc deficit and poor operational stability in comparison to mid-bandgap (~1.5 to 1.6 eV) perovskites ( _13, 14_ ). 

A high Br content causes more rapid crystallization of the perovskite film that often creates defects associated with structure and composition nonuniformity, and high density of grain boundaries (GBs) ( _15-17_ ). Various strategies <mark>have been proposed to mitigate these issues, such as composition engineering (</mark> _<mark>18-22</mark>_ <mark>), additive engineering (</mark> _<mark>23-29</mark>_ <mark>), and interface engineering (</mark> _<mark>30-34</mark>_ <mark>). Despite these efforts, the stability of WBG PSCs is still inadequate, especially for devices under illumination or operation at elevated temperatures (</mark> **<mark>Table S1</mark>** <mark>).</mark> 

<mark>Here, we report a rational strategy to drastically enhance 1.75-eV Br-I-mixed WBG PSC operational stability with high PCE and low V</mark> oc <mark>deficit. Our design strategy is based on a few principles for Br-I mixed WBG perovskite thin films: (i) Br-I phase segregation is the main limitation on Br-rich WBG PSC performance (that is, operational stability and efficiency); (ii) BrI phase segregation is facilitated by defective sites; and (iii) reducing the density of defective sites can suppress Br-I phase segregation. We hypothesized that a high-quality WBG perovskite thin</mark> 

3 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>film in which the bulk and surface defects are minimized could suppress Br-I phase segregation in a device under operational conditions.</mark> 

<mark>We leveraged the rapid crystallization characteristics of Br</mark><sup>−</sup> <mark>(relative to I</mark><sup>−</sup> <mark>) by using a gasquenching process that was amenable to the Br-rich WBG perovskite precursors. In comparison to the conventional antisolvent approach, the gentler gas-quench method first produced a Br-rich surface layer that then induced top-down columnar growth to form a gradient structure, which had less Br in the bulk than in the near-surface region. The resulting WBG perovskite film had improved structural and optoelectronic properties, such as larger grain size, fewer GBs, longer diffusion length, and reduced defect density. We achieved 1.75-eV WBG PSCs with >20% PCE, ~1.33-V V</mark> oc <mark>, and excellent operational stability (retaining >95% maximum PCE over 1100-h operation under 1.2-sun at 65  C). When coupling the 1.75-eV WBG PSC with the 1.25-eV Sn-Pb PSC, we obtained a 27.1% all-perovskite two-terminal tandem cell with a high V</mark> oc <mark>of 2.2 V.</mark> 

## **<mark>Wide-bandgap perovskite solar cell characteristics</mark>** 

4 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**<mark>Fig. 1. Device characteristics of 1.75-eV wide-bandgap (WBG) perovskite solar cells (PSCs) made by gas-quench processing.</mark>** <mark>(</mark> **<mark>A</mark>** <mark>and</mark> **<mark>B</mark>** <mark>) Current density-voltage</mark> **<mark>(</mark>** <mark>J-V) curves of a WBG PSC under reverse and forward scans, with the inset showing the stable power output (SPO) efficiency (A), and the corresponding external quantum efficiency (EQE) with determination of the bandgap (B). (</mark> **<mark>C</mark>** <mark>and</mark> **<mark>D</mark>** <mark>) Long-term device operational stability under continuous light illumination in N</mark> 2 <mark>at different temperatures: a cell aged under 0.8-sun for 2560 hours at 25  C followed by 890 hours at 55  C (C), and a cell aged under 1.2-sun at 65  C for 1100 hours with a linear extrapolation to estimate T90 (purple dashed line) (D).</mark> 

<mark>We first illustrate the value of the gas-quench method for processing the high-Br-content perovskite to simultaneously achieve high power conversion efficiency (PCE) ⎯ especially high V</mark> oc <mark>⎯ and excellent operational device stability. In this study, the WBG perovskite is based on Cs</mark> 0.3 <mark>FA</mark> 0.6 <mark>DMA</mark> 0.1 <mark>Pb(I</mark> 0.7 <mark>Br</mark> 0.3 <mark>)</mark> 3 <mark>. We highlight the gas-quench method by comparing it with the conventional antisolvent approach (details in Materials and Methods). Note that we used N</mark> 2 <mark>gas for most gas-quench studies unless otherwise stated. In comparison to the antisolvent sample, the</mark> 

5 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>gas-quench sample exhibited a slight redshift of the absorption onset, corresponding to a 10- to 20-meV decrease in bandgap (</mark> **<mark>Fig. S1</mark>** <mark>). We used a typical inverted (or p-i-n) device structure: glass/ITO/SAM/perovskite/LiF/C</mark> 60 <mark>/bathocuproine (BCP)/Ag, where ITO is indium tin oxide and SAM denotes a self-assembled monolayer. The SAM layer consists of mixed MeO-2PACz and Me-4PACz, where MeO-2PACz is (2-(3,6-Dimethoxy-9H-carbazol-9-yl)ethyl)phosphonic acid and Me-4PACz is (4-(3,6-Dimethyl-9H-carbazol-9-yl)butyl)phosphonic acid.</mark> 

<mark>The device characteristics of gas-quench-based WBG PSCs are examined (</mark> **<mark>Fig. 1</mark>** <mark>). The current density-voltage (J-V) curves under reverse and forward voltage scans exhibited negligible hysteresis (</mark> **<mark>Fig. 1A</mark>** <mark>), with reverse- and forward-scan PCEs of 20.3% and 20.0%, respectively; the detailed photovoltaic (PV) characteristics are tabulated in</mark> **<mark>Table S2</mark>** <mark>. The highest V</mark> oc <mark>values reached ~1.33 V, and fill factor (FF) reached 85% (</mark> **<mark>Fig. S2</mark>** <mark>), both of which are among the best reported for 1.75-eV WBG PSCs (</mark> _<mark>35</mark>_ <mark>). The stable power output (SPO) efficiency reached 20.1% (</mark> **<mark>Fig. 1B</mark>** <mark>). The corresponding external quantum efficiency (EQE) spectrum (</mark> **<mark>Fig. 1C</mark>** <mark>) yielded an integrated current density of 18.2 mA/cm</mark><sup>2</sup> <mark>, consistent with the J-V curves.</mark> 

<mark>Compared to the antisolvent method, the gas-quench-based WBG PSCs displayed enhancements in all PV parameters, especially in V</mark> oc <mark>(by ~30 mV) and short-circuit photocurrent density (J</mark> sc <mark>) (by ~1 mA/cm</mark><sup>2</sup> <mark>), as shown in</mark> **<mark>Figs. S2 and S3</mark>** <mark>. The enhanced J</mark> sc <mark>was partially attributed to the slightly reduced bandgap produced by the gas-quench method (</mark> **<mark>Figs. S1 and S4</mark>** <mark>). The gas-quench method was also statistically more reproducible than the antisolvent approach (</mark> **<mark>Fig. S2</mark>** <mark>), which is consistent with the</mark> wider perovskite active layer processing window associated with the gas-quench approach <mark>(</mark> **<mark>Fig. S5)</mark>** <mark>.</mark> Note that we found that the gas-quench method also worked when Ar or air was used as the drying gas, indicating that the gas-quench method is a general way for improving the performance of WBG PSCs ( **Fig. S6** ). 

<mark>In addition to the PCE enhancement, the gas-quench method led to excellent operational stability from 25  to 65  C. The gas-quench-based WBG PSC exhibited minimal changes in device efficiency, retaining ~99% of the maximum PCE under continuous 0.8-sun light-soaking from a sulfur plasma lamp near the maximum power point (MPP) at ~25  C over 2560 hours in an N</mark> 2 

6 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>atmosphere (</mark> **<mark>Fig. 1D</mark>** <mark>). In contrast, the antisolvent-based control device showed a dramatic PCE drop when tested under the same operation condition (</mark> **<mark>Fig. S7</mark>** <mark>). For the same gas-quench-based device, we further tested the stability at 55  C (second half of</mark> **<mark>Fig. 1D</mark>** <mark>, separated by a vertical dashed line). The same cell retained about 96% of its maximum PCE during aging under 0.8-sun illumination at 55  C over 890 hours.</mark> 

<mark>We also examined another gas-quench device under 1.2-sun light-soaking illuminated by white light emitting diodes near MPP at 65  C in N</mark> 2 <mark>(</mark> **<mark>Fig. 1E</mark>** <mark>). This device retained >95% of its maximum PCE over 1100 h of aging, with a linear extrapolation to a T90 > 2200 h (T90 means the time for a solar cell to degrade to 90% of its maximum efficiency). These stability results substantially surpassed other reports for Br-I mixed WBG PSCs (</mark> **<mark>Table S1</mark>** <mark>), and this level of performance exceeds our previously reported state-of-the-art 1.53-eV p-i-n PSCs (</mark> _<mark>14</mark>_ <mark>).</mark> 

## **<mark>Structural and optoelectronic properties</mark>** 



**<mark>Fig. 2. Structural properties of WBG perovskite.</mark>** <mark>(</mark> **<mark>A–C</mark>** <mark>) Top-view scanning electron microscopy (SEM) images of FA</mark> 0.6 <mark>Cs</mark> 0.3 <mark>DMA</mark> 0.1 <mark>Pb(I</mark> 0.7 <mark>Br</mark> 0.3 <mark>)</mark> 3 <mark>perovskite thin films made by antisolvent (A) and gas-quench (B and C) methods. (C) shows the magnified image of the selected region in (B). (</mark> **<mark>D–E</mark>** <mark>) Cross-section SEM images of WBG perovskite films made by antisolvent (D) and gas-quench (E) methods. (</mark> **<mark>F</mark>** <mark>) X-ray diffraction (XRD) patterns of WBG perovskite films made</mark> 

7 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>by anti-solvent and gas-quench methods. The peak labeled with * denotes PbI</mark> 2, <mark>and the peak labeled with # denotes ITO. (</mark> **<mark>G</mark>** <mark>) Calculated cleavage energies of common surfaces, as indicated.</mark> 

<mark>In the next several sections, we discuss the key features leading to our highly stable and efficient WBG PSCs. First, we compared the structural properties of WBG perovskite films prepared by antisolvent and gas-quench methods. The surface and cross-section scanning electron microscopy (SEM) images showed several differences between these two methods. For the antisolvent approach, the grain morphology appeared rough and the apparent perovskite grain size was small (150 to 200 nm)</mark> **<mark>(Fig. 2A)</mark>** <mark>, which is common for Br-rich perovskite thin films because of the rapid crystallization rate associated with Br</mark><sup>−</sup> <mark>(</mark> _<mark>36, 37</mark>_ <mark>). In general, this Br</mark><sup>−</sup> <mark>-related challenge (relative to the I</mark><sup>−</sup> <mark>counterpart) can be attributed to two factors: (i) the l</mark> ower solubility of <mark>Br</mark><sup>−</sup> <mark>,</mark> which leads to rapid nucleation; and (ii) the smaller ionic radius of Br<sup>−</sup> , which leads to faster ion diffusion and grain coarsening ( _38_ ). These issues are further exacerbated by the rapid solvent extraction during the antisolvent process. Thus, Br-rich perovskite thin films tend to grow with a disordered and nonuniform morphology in comparison to I-rich ones. 

Gas quench ⎯ often based on N2 or air ⎯ is generally regarded as a gentler process than the antisolvent quench. The gas-quench approach was initially reported around the same time as the antisolvent method ( _39_ ), but has only recently received more attention given its advantages for scalable deposition ( _40-44_ ). For gas quench, the structure and morphology data indicated that the perovskite nucleation and grain growth dynamics were distinct from what occurs during the antisolvent approach. <mark>The gas-quench film exhibited dense,</mark> closely packed morphology with a flat, smooth surface and nearly invisible grain boundaries ( **Fi** **<mark>g. 2, B and C</mark>** <mark>). The morphology difference between the two methods was also evident in the corresponding cross-section SEM images (</mark> **<mark>Fig. 2, D and E</mark>** <mark>).</mark> 

<mark>Gas quenching also led to an enhanced (by 50×) main x-ray diffraction (XRD) diffraction peak (2𝜃 = 14.2  ) and a reduced full-width-half-maximum (FWHM) (from 0.29  to 0.17  ) (</mark> **<mark>Fig. 2F</mark>** <mark>), suggesting enhanced ordering in the perovskite film. The gas-quench sample exhibited much stronger texturing (</mark> **<mark>Fig. S8</mark>** <mark>). The textured columnar grains suggest that the vertical GBs are mostly</mark> 

8 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>low-angle GBs, which in general have much lower densities of defects than normal GBs (</mark> _<mark>45</mark>_ <mark>). The</mark> morphology contrast was more pronounced for higher concentrations of the Br-rich perovskite precursor ( **Fig. S9** ). In contrast, when a pure I-based perovskite precursor was used, the morphology difference was substantially reduced, with both gas-quench and antisolvent samples showing multiple apparent grains across the film thickness ( **Fig. S10** ). These results support the rationale for coupling the gas-quench process with a high-Br-content precursor for generating highly textured, top-down columnar growth of WBG perovskite films. 

<mark>Our density functional theory (DFT) calculation revealed that the top-down growth with high texturing was governed by the surface energy difference caused by the high Br concentration in the surface region. During film growth, surfaces with smaller surface energies are expected to form with a higher preference. For ionic crystals such as halides, surface energy is dominated by the cleavage energy that do not undergo surface reconstruction. We calculated the cleavage energies of the most common surfaces, including (001)/(002), (011), (111), (012), and (112). The cleavage energy is the same for the (001) and (002) surfaces because they have the same atomic structure. Incorporating Br promoted the preferred growth along the (001)/(002) surface (</mark> **<mark>Fig. 2G</mark>** <mark>). As discussed above, the gas-quench method results in a surface region that is more Br-rich. Thus, gas quench of mixed halide perovskites can be anticipated to promote enhanced textured growth in the surface region. We expected the highly preferred (001)/(002) and top-down growth to form perovskite films with textured columnar grains that have fewer GBs and a low density of defects.</mark> 

9 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 



**<mark>Fig. 3. Transient absorption (TA) measurements.</mark>** <mark>Pseudocolor representation of the TA results (</mark> **<mark>A</mark>** <mark>and</mark> **<mark>B</mark>** <mark>) and the TA spectra at various post-pump delay times (</mark> **<mark>C</mark>** <mark>and</mark> **<mark>D</mark>** <mark>) of WBG perovskite thin films prepared by anti-solvent (A and C) and gas-quench (B and D) methods. The pump excitation energy is 3.1 eV (400 nm) incident from the top of the perovskite samples.</mark> 

<mark>For the high-Br-content perovskite composition in this study, gas-quench and antisolvent methods were also expected to produce different composition profiles along the vertical growth direction. Crystallization and growth take place simultaneously across the film thickness in the antisolvent approach, and consistent with a rapid uniform quench, we expected to see a relatively uniform distribution of the perovskite composition along the vertical direction. In contrast, the gasquench approach appears to act more slowly and induces Br-rich nucleation in the surface layer, followed by a gradient structure along the vertical direction, resulting in columnar growth. Transient absorption (TA) measurements of the antisolvent sample showed a single ground-state bleach peak during the carrier’s lifetime indicating a uniform composition within the sample as carriers diffuse across the film and sample the energetic landscape prior to relaxing back to their ground state (</mark> **<mark>Fig. 3, A and C</mark>** <mark>).</mark> 

<mark>However, the gas-quench sample showed a distinct shifting of the ground-state bleach as a function of time after excitation. At early times, the bleach occurred at a higher energy</mark> 

10 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>corresponding to carriers residing in a Br-rich (higher energy) region and then the bleach slowly shifted to a lower energy, corresponding to carriers moving toward the region with reduced Br content. The ground state bleach shifted by ~0.1 eV, over a time scale of hundreds of picoseconds (</mark> **<mark>Fig. 3, B and D</mark>** <mark>). When the gas-quench sample was excited from the back side, no evolution of the TA spectrum was observed (</mark> **<mark>Fig. S11</mark>** <mark>). Thus, the evolution in the TA spectrum for the gasquench sample indicates that there is a gradient in the Br-content, where the higher bandgap (more Br) lies at the surface of the film and the lower bandgap (less Br) is deeper into the film. The gradient structure is consistent with the time-of-flight secondary-ion mass spectroscopy results (</mark> **<mark>Fig. S12</mark>** <mark>). At the early pump-probe times, only the high-bandgap, Br-rich perovskite at the surface of the film was excited because of Beer’s law absorbance of the pump pulse into the film-surface, and the TA spectrum showed its spectral signature. After hundreds of picoseconds, the photoexcited charge carriers that initially resided near the top surface diffused into the perovskite film, and thus the TA-spectrum evolved to the spectral signature of the lower-bandgap, more I-rich perovskite. The gradient composition created an energy cascade structure that is beneficial for solar cell operation as it repels carriers away from defective surfaces (</mark> _<mark>46-50</mark>_ <mark>).</mark> 



11 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

**Fig. 4. Optoelectronic properties and calculation of defect-assisted diffusion barriers.** <mark>(</mark> **<mark>A</mark>** <mark>) Photoconductivity (</mark> _<mark>ϕ</mark>_ <mark>Σ</mark> _<mark>µ</mark>_ <mark>) transients for the lowest absorbed pump fluence, obtained via timeresolved microwave conductivity (TRMC) measurement. Pulsed (10-Hz) optical excitation at 1.93 eV (643 nm) was used, with an absorbed fluence range over about two orders of magnitude. (</mark> **<mark>B</mark>** <mark>) Excitation intensity dependence of photoconductivity as a function of excitation intensity. (</mark> **<mark>C</mark>** <mark>) Dark J-V curves for PSCs based on perovskite films prepared with antisolvent and gas-quench methods. (</mark> **<mark>D</mark>** <mark>to</mark> **<mark>G</mark>** <mark>) Calculations of diffusion energy barriers for several common defects: iodine vacancy, V</mark> I <mark>(D); bromine vacancy, V</mark> Br <mark>(E); iodine interstitial, I</mark> i <mark>(F); and bromine interstitial, Br</mark> i <mark>(G).</mark> 

<mark>We conducted time-resolved microwave conductivity (TRMC) and dark J-V measurements to examine the impact of growth methods on optoelectronic properties. Analysis of typical TRMC transients revealed that the yield-mobility product</mark> _<mark>ϕ</mark>_ <mark>Σ</mark> _<mark>µ</mark>_ <mark>value (where</mark> _<mark>ϕ</mark>_ <mark>is free-carrier generation yield and Σ</mark> _<mark>µ</mark>_ <mark>is the sum of carrier mobilities of holes and electrons) and free carrier lifetime were 4.9 cm</mark><sup>2</sup> <mark>V</mark><sup>−1</sup> <mark>s</mark><sup>−1</sup> <mark>and 426 ns for antisolvent samples but 20.8 cm</mark><sup>2</sup> <mark>V</mark><sup>−1</sup> <mark>s</mark><sup>−1</sup> <mark>and 355 ns for gas-quench samples, respectively (</mark> **<mark>Fig. 4A</mark>** <mark>). The relative change in</mark> _<mark>ϕ</mark>_ <mark>Σ</mark> _<mark>µ</mark>_ <mark>is observed over a wide range of excitation intensities (</mark> **<mark>Fig. 4B</mark>** <mark>). The carrier diffusion lengths, determined by the product of carrier mobility and lifetime, were 2.3  m for the antisolvent sample and 4.4  m for the gas-quench sample.</mark> 

<mark>The suppressed gigahertz mobility value for the antisolvent sample was consistent with greater structural disorder indicated in the XRD data and the morphology and apparent-grain nonuniformities observed in the SEM images (</mark> _<mark>51</mark>_ <mark>). For the gas-quench sample, the longer carrier diffusion length, which is often associated with enhanced material quality (degree of crystallinity) and reduced defect density, was consistent with the improved device characteristics. The comparison of the dark J-V curves (</mark> **<mark>Fig. 4C</mark>** <mark>) showed a greater than two-orders of magnitude increase in shunt resistance that reduced leakage current and was suggestive of a lower defect density for gas-quench-based PSCs (</mark> _<mark>52</mark>_ <mark>), which is consistent with the deep level transient spectroscopy (DLTS) results (</mark> **<mark>Fig. S13</mark>** <mark>).</mark> 

<mark>We attributed the improved structural and optoelectronic properties and enhanced</mark> 

12 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>operational stability with gas quench to suppression of halide phase separation, which involves halide exchange. Our DFT calculations revealed that halide exchange requires the assistance of a halide vacancy. The energy needed to diffuse a halide atom from its lattice to a nearby interstitial site was as high as 1.4 eV for I and 1.3 eV for Br (</mark> **<mark>Figs. S14 and S15</mark>** <mark>). However, these energies were reduced to 0.33 eV and 0.28 eV for I and Br (</mark> **<mark>Fig. 4, D and E,</mark>** <mark>and</mark> **<mark>Figs. S16 and S17</mark>** <mark>), respectively, when a halide vacancy is nearby. Additionally, I and Br interstitials diffuse easily, with energy barriers of 0.27 eV and 0.30 eV, respectively (</mark> **<mark>Fig. 4, F and G,</mark>** <mark>and</mark> **<mark>Figs. S18 and S19</mark>** <mark>). Our calculation confirmed that reducing the density of defects (halide vacancies and interstitials) helped suppress halide phase separation.</mark> 

**<mark>All-perovskite tandem solar cell characteristics</mark>** 



**<mark>Fig. 5. Tandem device.</mark>** <mark>(</mark> **<mark>A</mark>** <mark>) J-V curves of an all-perovskite tandem solar cell incorporating the gas-quench-based 1.75-eV WBG PSC. The device area was 0.059 cm</mark><sup>2</sup> <mark>as defined by a metal aperture. (</mark> **<mark>B</mark>** <mark>) The corresponding SPO efficiency near the MPP. The narrow-bandgap bottom cell is based on 1.25-eV Sn-Pb perovskite (FA</mark> 0.6 <mark>MA</mark> 0.4 <mark>Sn</mark> 0.6 <mark>Pb</mark> 0.4 <mark>I</mark> 3 <mark>), as detailed in a previous report (</mark> _<mark>53</mark>_ <mark>). (</mark> **<mark>C</mark>** <mark>) Long-term stability of the tandem device under continuous ~0.8-sun illumination at ~35  C in N</mark> 2 <mark>. The tandem device retained ~81% of its maximum efficiency after 1825 hours.</mark> 

<mark>To exploit the effectiveness of our optimized WBG perovskites, we fabricated monolithic</mark> 

13 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

<mark>all-perovskite tandem solar cells by integrating 1.25-eV FA</mark> 0.6 <mark>MA</mark> 0.4 <mark>Sn</mark> 0.6 <mark>Pb</mark> 0.4 <mark>I</mark> 3 <mark>narrow-bandgap PSC with our optimized 1.75-eV WBG PSC. The tandem device stack consisted of glass/ITO/SAM/1.75-eV perovskite/LiF/C</mark> 60 <mark>/33-nm SnO</mark> _x_ <mark>/1-nm Au/PEDOT:PSS/1.25-eV perovskite/C</mark> 60 <mark>/BCP/Ag, where PEDOT:PSS is poly(3,4-ethylenedioxythiophene):polystyrene sulfonate. The fabrication of the Sn-Pb perovskite and the tandem structure is detailed in (</mark> _<mark>53</mark>_ <mark>). The J-V curves of the tandem device (</mark> **<mark>Fig. 5A</mark>** <mark>) showed negligible hysteresis between reverse and forward scans. The reverse scan yielded a PCE of 27.1%, with a J</mark> sc <mark>of 15.3 mA/cm</mark><sup>2</sup> <mark>, V</mark> oc <mark>of 2.20 V, and FF of 80.8%; the forward scan showed a PCE of 27.2%, with a J</mark> sc <mark>of 15.1 mA/cm</mark><sup>2</sup> <mark>, V</mark> oc <mark>of 2.20 V, and FF of 81.6%. The corresponding SPO efficiency reached 27.1% (</mark> **<mark>Fig. 5B</mark>** <mark>). The tandem V</mark> oc <mark>of 2.2 V is the highest reported (</mark> _<mark>53</mark>_ <mark>). The external quantum efficiency (EQE) spectra for the corresponding top and bottom subcells are shown in</mark> **<mark>Fig. S20</mark>** <mark>. We also examined the operational stability of the tandem devices. The unencapsulated tandem cell retained ~81% of its maximum PCE after 1825 hours under continuous ~0.8-sun illumination from a sulfur plasma lamp at ~35  C in N</mark> 2 <mark>(</mark> **<mark>Fig. 5C</mark>** <mark>). The encapsulated tandem cell exhibited a T84 of 763 hours when tested at ~50  C in air (</mark> **<mark>Fig. S21</mark>** <mark>).</mark> 

## **<mark>Discussion</mark>** 

<mark>Here, we report a simple strategy to control the growth of WBG perovskite thin films by applying a gentle gas-quench method to high-Br-content perovskite. With this approach, the WBG perovskite films showed improved structural and optoelectronic properties with longer diffusion length and reduced defect density. As a result, we obtained efficient and stable WBG PSCs and all-perovskite tandem solar cells. This study not only demonstrates the exciting potential of highperformance all-perovskite tandem devices, but is also a valuable advance for the development of other perovskite-based tandem architectures, such as perovskite/Si tandems that employ mixed halide WBG perovskites (</mark> _<mark>54-56</mark>_ <mark>). The conversion efficiency and long-term stability of these devices support our hypothesis that suppression of Br-I phase segregation by enhancing perovskite crystallization quality and minimizing defects can improve WBG perovskite PV performance.</mark> 

14 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

## **<mark>References</mark>** 

1. Y. Zhao, K. Zhu, Organic–inorganic hybrid lead halide perovskites for optoelectronic and electronic applications. _Chem. Soc. Rev._ **45** , 655-689 (2016). 

2. G. E. Eperon, M. T. Hörantner, H. J. Snaith, Metal halide perovskite tandem and multiplejunction photovoltaics. _Nat. Rev. Chem._ **1** , 0095 (2017). 

3. J. H. Noh, S. H. Im, J. H. Heo, T. N. Mandal, S. I. Seok, Chemical Management for Colorful, Efficient, and Stable Inorganic–Organic Hybrid Nanostructured Solar Cells. _Nano Lett._ **13** , 1764-1769 (2013). 

4. R. Lin, J. Xu, M. Wei, Y. Wang, Z. Qin, Z. Liu, J. Wu, K. Xiao, B. Chen, S. M. Park, G. Chen, H. R. Atapattu, K. R. Graham, J. Xu, J. Zhu, L. Li, C. Zhang, E. H. Sargent, H. Tan, All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 7378 (2022). 

5. A. Al-Ashouri, E. Köhnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Márquez, A. B. Morales Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jošt, G. Matič, B. Rech, R. Schlatmann, M. Topič, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300-1309 (2020). 

6. M. Jošt, E. Köhnen, A. Al-Ashouri, T. Bertram, Š. Tomšič, A. Magomedov, E. Kasparavicius, T. Kodalle, B. Lipovšek, V. Getautis, R. Schlatmann, C. A. Kaufmann, S. Albrecht, M. Topič, Perovskite/CIGS Tandem Solar Cells: From Certified 24.2% toward 30% and Beyond. _ACS Energy Lett._ **7** , 1298-1307 (2022). 

7. J. Tong, Q. Jiang, F. Zhang, S. B. Kang, D. H. Kim, K. Zhu, Wide-Bandgap Metal Halide Perovskites for Tandem Solar Cells. _ACS Energy Lett._ **6** , 232-248 (2021). 

8. J. Wang, W. Li, W.-J. Yin, Passivating detrimental DX centers in CH3NH3PbI3 for reducing nonradiative recombination and elongating carrier lifetime. _Adv. Mater._ **32** , 1906115 (2020). 

9. K. Li, L.-Y. Dong, H.-X. Xu, Y. Qin, Z.-G. Li, M. Azeem, W. Li, X.-H. Bu, Electronic structures and elastic properties of a family of metal-free perovskites. _Mater. Chem. Front._ **3** , 1678-1685 (2019). 

10. E. T. Hoke, D. J. Slotcavage, E. R. Dohner, A. R. Bowring, H. I. Karunadasa, M. D. McGehee, Reversible photo-induced trap formation in mixed-halide hybrid perovskites for photovoltaics. _Chem. Sci._ **6** , 613-617 (2015). 

11. R. A. Kerner, Z. Xu, B. W. Larson, B. P. Rand, The role of halide oxidation in perovskite halide phase separation. _Joule_ **5** , 2273-2295 (2021). 

12. M. C. Brennan, S. Draguta, P. V. Kamat, M. Kuno, Light-Induced Anion Phase Segregation in Mixed Halide Perovskites. _ACS Energy Lett._ **3** , 204-213 (2018). 

13. Y. Zhao, F. Ma, Z. Qu, S. Yu, T. Shen, H.-X. Deng, X. Chu, X. Peng, Y. Yuan, X. Zhang, J. You, Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. _Science_ **377** , 531-534 (2022). 

15 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

14. Q. Jiang, J. Tong, Y. Xian, R. A. Kerner, S. P. Dunfield, C. Xiao, R. A. Scheidt, D. Kuciauskas, X. Wang, M. P. Hautzinger, R. Tirawat, M. C. Beard, D. P. Fenning, J. J. Berry, B. W. Larson, Y. Yan, K. Zhu, Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278-283 (2022). 

15. S. J. Yoon, M. Kuno, P. V. Kamat, Shift Happens. How Halide Ion Defects Influence Photoinduced Segregation in Mixed Halide Perovskites. _ACS Energy Lett._ **2** , 1507-1514 (2017). 

16. P. S. Mathew, G. F. Samu, C. Janáky, P. V. Kamat, Iodine (I) Expulsion at Photoirradiated Mixed Halide Perovskite Interface. Should I Stay or Should I Go? _ACS Energy Lett._ **5** , 1872-1880 (2020). 

17. A. J. Barker, A. Sadhanala, F. Deschler, M. Gandini, S. P. Senanayak, P. M. Pearce, E. Mosconi, A. J. Pearson, Y. Wu, A. R. Srimath Kandada, T. Leijtens, F. De Angelis, S. E. Dutton, A. Petrozza, R. H. Friend, Defect-Assisted Photoinduced Halide Segregation in Mixed-Halide Perovskite Thin Films. _ACS Energy Lett._ **2** , 1416-1424 (2017). 

18. R. J. Stoddard, A. Rajagopal, R. L. Palmer, I. L. Braly, A. K. Y. Jen, H. W. Hillhouse, Enhancing Defect Tolerance and Phase Stability of High-Bandgap Perovskites via Guanidinium Alloying. _ACS Energy Lett._ **3** , 1261-1268 (2018). 

19. H. Tan, F. Che, M. Wei, Y. Zhao, M. I. Saidaminov, P. Todorović, D. Broberg, G. Walters, F. Tan, T. Zhuang, B. Sun, Z. Liang, H. Yuan, E. Fron, J. Kim, Z. Yang, O. Voznyy, M. Asta, E. H. Sargent, Dipolar cations confer defect tolerance in wide-bandgap metal halide perovskites. _Nat. Commun._ **9** , 3100 (2018). 

20. G. E. Eperon, K. H. Stone, L. E. Mundt, T. H. Schloemer, S. N. Habisreutinger, S. P. Dunfield, L. T. Schelhas, J. J. Berry, D. T. Moore, The Role of Dimethylammonium in Bandgap Modulation for Stable Halide Perovskites. _ACS Energy Lett._ **5** , 1856-1864 (2020). 

21. S. Gholipour, A. M. Ali, J.-P. Correa-Baena, S.-H. Turren-Cruz, F. Tajabadi, W. Tress, N. Taghavinia, M. Grätzel, A. Abate, F. De Angelis, C. A. Gaggioli, E. Mosconi, A. Hagfeldt, M. Saliba, Globularity-Selected Large Molecules for a New Generation of Multication Perovskites. _Adv. Mater._ **29** , 1702005 (2017). 

22. D. P. McMeekin, G. Sadoughi, W. Rehman, G. E. Eperon, M. Saliba, M. T. Hörantner, A. Haghighirad, N. Sakai, L. Korte, B. Rech, M. B. Johnston, L. M. Herz, H. J. Snaith, A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151-155 (2016). 

23. Y. Zhou, Y.-H. Jia, H.-H. Fang, M. A. Loi, F.-Y. Xie, L. Gong, M.-C. Qin, X.-H. Lu, C.-P. Wong, N. Zhao, Composition-Tuned Wide Bandgap Perovskites: From Grain Engineering to Stability and Performance Improvement. _Adv. Funct. Mater._ **28** , 1803130 (2018). 

24. J. Kim, M. I. Saidaminov, H. Tan, Y. Zhao, Y. Kim, J. Choi, J. W. Jo, J. Fan, R. QuinteroBermudez, Z. Yang, L. N. Quan, M. Wei, O. Voznyy, E. H. Sargent, Amide-Catalyzed Phase-Selective Crystallization Reduces Defect Density in Wide-Bandgap Perovskites. _Adv. Mater._ **30** , 1706275 (2018). 

25. M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J. M. Richter, M. Alsari, E. P. Booker, E. M. Hutter, A. J. Pearson, S. Lilliu, T. J. Savenije, H. 

16 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

Rensmo, G. Divitini, C. Ducati, R. H. Friend, S. D. Stranks, Maximizing and stabilizing luminescence from halide perovskites with potassium passivation. _Nature_ **555** , 497-501 (2018). 

26. D. Kim, H. J. Jung, I. J. Park, B. W. Larson, S. P. Dunfield, C. Xiao, J. Kim, J. Tong, P. Boonmongkolras, S. G. Ji, F. Zhang, S. R. Pae, M. Kim, S. B. Kang, V. Dravid, J. J. Berry, J. Y. Kim, K. Zhu, D. H. Kim, B. Shin, Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. _Science_ **368** , 155-160 (2020). 

27. D. H. Kim, C. P. Muzzillo, J. Tong, A. F. Palmstrom, B. W. Larson, C. Choi, S. P. Harvey, S. Glynn, J. B. Whitaker, F. Zhang, Z. Li, H. Lu, M. F. A. M. van Hest, J. J. Berry, L. M. Mansfield, Y. Huang, Y. Yan, K. Zhu, Bimolecular Additives Improve Wide-Band-Gap Perovskites for Efficient Tandem Solar Cells with CIGS. _Joule_ **3** , 1734-1745 (2019). 

28. Y. Yu, C. Wang, C. R. Grice, N. Shrestha, D. Zhao, W. Liao, L. Guan, R. A. Awni, W. Meng, A. J. Cimaroli, K. Zhu, R. J. Ellingson, Y. Yan, Synergistic Effects of Lead Thiocyanate Additive and Solvent Annealing on the Performance of Wide-Bandgap Perovskite Solar Cells. _ACS Energy Lett._ **2** , 1177-1182 (2017). 

29. F. Yu, J. Liu, J. Huang, P. Xu, C.-H. Li, Y.-X. Zheng, H. Tan, J.-L. Zuo, Efficient and Stable Wide-Bandgap Perovskite Solar Cells Derived from a Thermodynamic Phase-Pure Intermediate. _Solar RRL_ **6** , 2100906 (2022). 

30. C. Chen, Z. Song, C. Xiao, R. A. Awni, C. Yao, N. Shrestha, C. Li, S. S. Bista, Y. Zhang, L. Chen, R. J. Ellingson, C.-S. Jiang, M. Al-Jassim, G. Fang, Y. Yan, ArylammoniumAssisted Reduction of the Open-Circuit Voltage Deficit in Wide-Bandgap Perovskite Solar Cells: The Role of Suppressed Ion Migration. _ACS Energy Lett._ **5** , 2560-2568 (2020). 

31. T. Bu, J. Li, Q. Lin, D. P. McMeekin, J. Sun, M. Wang, W. Chen, X. Wen, W. Mao, C. R. McNeill, W. Huang, X.-L. Zhang, J. Zhong, Y.-B. Cheng, U. Bach, F. Huang, Structure engineering of hierarchical layered perovskite interface for efficient and stable wide bandgap photovoltaics. _Nano Energy_ **75** , 104917 (2020). 

32. S. Gharibzadeh, B. Abdollahi Nejand, M. Jakoby, T. Abzieher, D. Hauschild, S. Moghadamzadeh, J. A. Schwenzer, P. Brenner, R. Schmager, A. A. Haghighirad, L. Weinhardt, U. Lemmer, B. S. Richards, I. A. Howard, U. W. Paetzold, Record Open-Circuit Voltage Wide-Bandgap Perovskite Solar Cells Utilizing 2D/3D Perovskite Heterostructure. _Adv. Energy Mater._ **9** , 1803699 (2019). 

33. Z. Liu, J. Siekmann, B. Klingebiel, U. Rau, T. Kirchartz, Interface Optimization via Fullerene Blends Enables Open-Circuit Voltages of 1.35 V in CH3NH3Pb(I0.8Br0.2)3 Solar Cells. _Adv. Energy Mater._ **11** , 2003386 (2021). 

34. C. Chen, Z. Song, C. Xiao, D. Zhao, N. Shrestha, C. Li, G. Yang, F. Yao, X. Zheng, R. J. Ellingson, C.-S. Jiang, M. Al-Jassim, K. Zhu, G. Fang, Y. Yan, Achieving a high opencircuit voltage in inverted wide-bandgap perovskite solar cells with a graded perovskite homojunction. _Nano Energy_ **61** , 141-147 (2019). 

35. Y. Tong, A. Najar, L. Wang, L. Liu, M. Du, J. Yang, J. Li, K. Wang, S. Liu, Wide-Bandgap Organic–Inorganic Lead Halide Perovskite Solar Cells. _Adv. Sci._ **9** , 2105085 (2022). 

36. M. I. Saidaminov, K. Williams, M. Wei, A. Johnston, R. Quintero-Bermudez, M. Vafaie, J. 

17 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

M. Pina, A. H. Proppe, Y. Hou, G. Walters, S. O. Kelley, W. A. Tisdale, E. H. Sargent, Multi-cation perovskites prevent carrier reflection from grain surfaces. _Nat. Mater._ **19** , 412418 (2020). 

37. H. S. Jung, N.-G. Park, Perovskite solar cells: from materials to devices. _Small_ **11** , 10-25 (2015). 

38. Y. Tidhar, E. Edri, H. Weissman, D. Zohar, G. Hodes, D. Cahen, B. Rybtchinski, S. Kirmayer, Crystallization of Methyl Ammonium Lead Halide Perovskites: Implications for Photovoltaic Applications. _J. Am. Chem. Soc._ **136** , 13249-13256 (2014). 

39. F. Huang, Y. Dkhissi, W. Huang, M. Xiao, I. Benesperi, S. Rubanov, Y. Zhu, X. Lin, L. Jiang, Y. Zhou, A. Gray-Weale, J. Etheridge, C. R. McNeill, R. A. Caruso, U. Bach, L. Spiccia, Y.-B. Cheng, Gas-assisted preparation of lead iodide perovskite films consisting of a monolayer of single crystalline grains for high efficiency planar solar cells. _Nano Energy_ **10** , 10-18 (2014). 

40. Y. Deng, C. H. Van Brackle, X. Dai, J. Zhao, B. Chen, J. Huang, Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. _Sci. Adv._ **5** , eaax7537 (2019). 

41. Y. Deng, Z. Ni, A. F. Palmstrom, J. Zhao, S. Xu, C. H. Van Brackle, X. Xiao, K. Zhu, J. Huang, Reduced Self-Doping of Perovskites Induced by Short Annealing for Efficient Solar Modules. _Joule_ **4** , 1949-1960 (2020). 

42. X. Dai, Y. Deng, C. H. Van Brackle, S. Chen, P. N. Rudd, X. Xiao, Y. Lin, B. Chen, J. Huang, Scalable Fabrication of Efficient Perovskite Solar Modules on Flexible Glass Substrates. _Adv. Energy Mater._ **10** , 1903108 (2020). 

43. A. S. Subbiah, F. H. Isikgor, C. T. Howells, M. De Bastiani, J. Liu, E. Aydin, F. Furlan, T. G. Allen, F. Xu, S. Zhumagali, S. Hoogland, E. H. Sargent, I. McCulloch, S. De Wolf, High-Performance Perovskite Single-Junction and Textured Perovskite/Silicon Tandem Solar Cells via Slot-Die-Coating. _ACS Energy Lett._ **5** , 3034-3040 (2020). 

44. J. Ding, Q. Han, Q.-Q. Ge, D.-J. Xue, J.-Y. Ma, B.-Y. Zhao, Y.-X. Chen, J. Liu, D. B. Mitzi, J.-S. Hu, Fully Air-Bladed High-Efficiency Perovskite Photovoltaics. _Joule_ **3** , 402-416 (2019). 

45. S. Pouladi, M. Asadirad, S. K. Oh, S. Shervin, J. Chen, W. Wang, C.-N. Manh, R. Choi, J. Kim, D. Khatiwada, M. Rathi, P. Dutta, V. Selvamanickam, J.-H. Ryou, Effects of grain boundaries on conversion efficiencies of single-crystal-like GaAs thin-film solar cells on flexible metal tapes. _Sol. Energy Mater. Sol. Cells_ **199** , 122-128 (2019). 

46. Z. Yu, X. Chen, S. P. Harvey, Z. Ni, B. Chen, S. Chen, C. Yao, X. Xiao, S. Xu, G. Yang, Y. Yan, J. J. Berry, M. C. Beard, J. Huang, Gradient Doping in Sn–Pb Perovskites by Barium Ions for Efficient Single-Junction and Tandem Solar Cells. _Adv. Mater._ **34** , 2110351 (2022). 

47. Y. Wu, X. Yang, W. Chen, Y. Yue, M. Cai, F. Xie, E. Bi, A. Islam, L. Han, Perovskite solar cells with 18.21% efficiency and area over 1 cm2 fabricated by heterojunction engineering. _Nat. Energy_ **1** , 16148 (2016). 

48. Q. Zhao, A. Hazarika, X. Chen, S. P. Harvey, B. W. Larson, G. R. Teeter, J. Liu, T. Song, C. Xiao, L. Shaw, M. Zhang, G. Li, M. C. Beard, J. M. Luther, High efficiency perovskite 

18 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

   - quantum dot solar cells with charge separating heterostructure. _Nat. Commun._ **10** , 2842 (2019). 

49. G. Tong, T. Chen, H. Li, W. Song, Y. Chang, J. Liu, L. Yu, J. Xu, Y. Qi, Y. Jiang, High Efficient Hole Extraction and Stable All-Bromide Inorganic Perovskite Solar Cells via Derivative-Phase Gradient Bandgap Architecture. _Solar RRL_ **3** , 1900030 (2019). 

50. K. T. Cho, S. Paek, G. Grancini, C. Roldán-Carmona, P. Gao, Y. Lee, M. K. Nazeeruddin, Highly efficient perovskite solar cells with a compositionally engineered perovskite/hole transporting material interface. _Energy Environ. Sci._ **10** , 621-627 (2017). 

51. O. G. Reid, M. Yang, N. Kopidakis, K. Zhu, G. Rumbles, Grain-Size-Limited Mobility in Methylammonium Lead Iodide Perovskite Thin Films. _ACS Energy Lett._ **1** , 561-565 (2016). 

52. C. Li, Z. Song, D. Zhao, C. Xiao, B. Subedi, N. Shrestha, M. M. Junda, C. Wang, C.-S. Jiang, M. Al-Jassim, R. J. Ellingson, N. J. Podraza, K. Zhu, Y. Yan, Reducing SaturationCurrent Density to Realize High-Efficiency Low-Bandgap Mixed Tin–Lead Halide Perovskite Solar Cells. _Adv. Energy Mater._ **9** , 1803135 (2019). 

53. J. Tong, Q. Jiang, A. J. Ferguson, A. F. Palmstrom, X. Wang, J. Hao, S. P. Dunfield, A. E. Louks, S. P. Harvey, C. Li, H. Lu, R. M. France, S. A. Johnson, F. Zhang, M. Yang, J. F. Geisz, M. D. McGehee, M. C. Beard, Y. Yan, D. Kuciauskas, J. J. Berry, K. Zhu, Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642-651 (2022). 

54. J. Wang, H. Liu, Y. Zhao, X. Zhang, Perovskite-based tandem solar cells gallop ahead. _Joule_ **6** , 509-511 (2022). 

55. Y. Li, Y. Peng, F. Hou, S. Ren, H. Tan, D. Zhao, in _Perovskite Materials and Devices_ . (2022), pp. 303-334. 

56. R. Wang, T. Huang, J. Xue, J. Tong, K. Zhu, Y. Yang, Prospects for metal halide perovskitebased tandem solar cells. _Nat. Photon._ **15** , 411-425 (2021). 

57. A. F. Palmstrom, G. E. Eperon, T. Leijtens, R. Prasanna, S. N. Habisreutinger, W. Nemeth, E. A. Gaulding, S. P. Dunfield, M. Reese, S. Nanayakkara, T. Moot, J. Werner, J. Liu, B. To, S. T. Christensen, M. D. McGehee, M. F. A. M. van Hest, J. M. Luther, J. J. Berry, D. T. Moore, Enabling Flexible All-Perovskite Tandem Solar Cells. _Joule_ **3** , 2193-2204 (2019). 

58. X. Chen, H. Lu, Z. Li, Y. Zhai, P. F. Ndione, J. J. Berry, K. Zhu, Y. Yang, M. C. Beard, Impact of Layer Thickness on the Charge Carrier and Spin Coherence Lifetime in TwoDimensional Layered Perovskite Single Crystals. _ACS Energy Lett._ **3** , 2273-2279 (2018). 

59. O. G. Reid, D. T. Moore, Z. Li, D. Zhao, Y. Yan, K. Zhu, G. Rumbles, Quantitative analysis of time-resolved microwave conductivity data. _J. Phys. D: Appl. Phys._ **50** , 493002 (2017). 

60. J. Hutter, M. Iannuzzi, F. Schiffmann, J. VandeVondele, cp2k: atomistic simulations of condensed matter systems. _Wiley Interdiscip. Rev. Comput. Mol. Sci._ **4** , 15-25 (2014). 

61. J. VandeVondele, J. Hutter, Gaussian basis sets for accurate calculations on molecular systems in gas and condensed phases. _J. Chem. Phys._ **127** , 114105 (2007). 

62. J. P. Perdew, K. Burke, M. Ernzerhof, Generalized Gradient Approximation Made Simple. _Phys. Rev. Lett._ **77** , 3865-3868 (1996). 

63. S. Goedecker, M. Teter, J. Hutter, Separable dual-space Gaussian pseudopotentials. _Phys._ 

19 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

_Rev. B_ **54** , 1703-1710 (1996). 

64. S. Grimme, J. Antony, S. Ehrlich, H. Krieg, A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

65. G. Henkelman, B. P. Uberuaga, H. Jónsson, A climbing image nudged elastic band method for finding saddle points and minimum energy paths. _J. Chem. Phys._ **113** , 9901-9904 (2000). 

66. G. Kresse, J. Hafner, Ab initio molecular dynamics for liquid metals. _Phys. Rev. B_ **47** , 558561 (1993). 

67. H. J. Monkhorst, J. D. Pack, Special points for Brillouin-zone integrations. _Phys. Rev. B_ **13** , 5188-5192 (1976). 

68. P. Blood, J. W. Orton, The electrical characterization of semiconductors: majority carriers and electron states. _Tech. phys._ i-xxiii (1992). 

69. S. Weiss, R. Kassing, Deep Level Transient Fourier Spectroscopy (DLTFS)—A technique for the analysis of deep level properties. _Solid-State Electron._ **31** , 1733-1742 (1988). 

## **<mark>Acknowledgements</mark>** 

**Funding:** The work was partially supported by the U.S. Department of Energy under Contract No. DE-AC36-08GO28308 with Alliance for Sustainable Energy, Limited Liability Company (LLC), the Manager and Operator of the National Renewable Energy Laboratory. The authors acknowledge the support on first-principle calculations and optoelectronic characterizations (e.g., TA and TRMC), from the Center for Hybrid Organic-Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science within the U.S. Department of Energy. The first-principles calculations were performed using computational resources sponsored by the Department of Energy's Office of Energy Efficiency and Renewable Energy and located at the National Renewable Energy Laboratory. The authors also acknowledge the support on wide-bandgap perovskite device fabrication and characterizations from Tandem Photovoltaics DE-00038266, and the support on the all-perovskite tandem device fabrication and characterization and general stability evaluation from the Advanced Perovskite Cells and Modules program of the National Center for Photovoltaics, funded by the U.S. Department of Energy, Office of Energy Efficiency and Renewable Energy, Solar Energy Technologies Office. Y.Y. acknowledges the support from U.S. Department of 

20 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under the Hydrogen and Fuel Cell Technologies Office Award Number DE-EE0008837. The views expressed in the article do not necessarily represent the views of the DOE or the U.S. Government. **<mark>Author Contributions:</mark>** Q.J. and K.Z. conceived the idea. K.Z. and J.T. supervised the projects. Q.J. fabricated perovskite films and devices, conducted scanning electron microscopy, theta-2theta X-ray diffraction, and ultraviolet-visible measurements. J.T. and Q.J. fabricated and characterized tandem solar cells and contributed to device design and analysis. R.A.S. conducted TA measurements and analysis, under the guidance of M.C.B. X.W. and Y.X. carried out the DFT calculations, under the supervision of Y.Y. A.E.L. and R.T. worked on device stability test and analysis, under the supervision of J.J.B. B.W.L. conducted the TRMC measurements and analysis. A.F.P. conducted atomic layer deposition. M.P.H. helped crystallographic analysis of perovskite structures. S.P.H. conducted the time-of-flight secondary-ion mass spectrometry study and analysis. S.J. conducted the deep-level transient spectroscopy measurement and analysis. L.T.S. and J.J.B conducted 2D XRD measurements and analysis. E.L.W. contributed to helpful discussions on wide-bandgap perovskite development for tandem applications. Q.J. and K.Z. wrote the first draft of the manuscript. All authors discussed the results and contributed to the revisions of the manuscript. **Competing interests:** Q.J., J.T., and K.Z. are inventors on a provisional patent (US patent application number 63/315,834) related to the subject matter of this manuscript. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper or the Supplementary Materials. 

## **<mark>Supplementary Materials</mark>** 

<mark>Materials and Methods Figs S1 to S21 Tables S1 to S2</mark> 

21 

Pursuant to the DOE Public Access Plan, this document represents the authors' peer-reviewed, accepted manuscript. The published version of the article is available from the relevant publisher. 

