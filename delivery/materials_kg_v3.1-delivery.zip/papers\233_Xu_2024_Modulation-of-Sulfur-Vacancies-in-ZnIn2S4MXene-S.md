# Modulation of Sulfur Vacancies in ZnIn2S4/MXene Schottky Heterojunction Photocatalyst Promotes Hydrogen Evolution

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 279 |
| 作者 | Ming-Hua Xu, Xiao-Wen Ruan, De-Peng Meng, Guozhen Fang, Dong-Xu Jiao, Sheng-Li Zhao, Zhe-Yang Liu, Zhifeng Jiang et al. |
| DOI | 10.1002/adfm.202402330 |
| 源文件 | 024_Xu_2024_Modulation-of-Sulfur-Vacancies-in-ZnIn2S4MXene-S.pdf |

---
**RESEARCH ARTICLE** 

**www.afm-journal.de** 



# **Modulation of Sulfur Vacancies in ZnIn2S4/MXene Schottky Heterojunction Photocatalyst Promotes Hydrogen Evolution** 

_Minghua Xu, Xiaowen Ruan,* Depeng Meng, Guozhen Fang, Dongxu Jiao, Shengli Zhao, Zheyang Liu, Zhifeng Jiang, Kaikai Ba, Tengfeng Xie, Wei Zhang, Jing Leng, Shengye Jin, Sai Kishore Ravi,* and Xiaoqiang Cui*_ 

## **1. Introduction** 

**The sustainable production of hydrogen utilizing solar energy is a pivotal strategy for reducing reliance on fossil fuels. ZnIn2S4 (ZIS), as a typical metal sulfide semiconductor, has received extensive attention in photocatalysis. Although the introduction of sulfur (S) vacancies in ZIS to enhance photocatalytic hydrogen production by creating defect energy levels has been explored, detailed studies on the control and modulation of S-vacancies in ZIS are sparce. This study demonstrates that while moderate levels of S-vacancies can enhance hydrogen evolution, excessive vacancies may hinder the process, underscoring the importance of S-vacancy modulation. Guided by theoretical calculations, We have designed and synthesized ZIS with modulated S-vacancies to realize favorable hydrogen adsorption-free energy and integrated in a Schottky-heterojunction with MXene co-catalysts for enhanced hydrogen evolution. The optimized hydrogen evolution performance of ZnIn2S4/MXene (ZMX) reaches 14.82 mmol g**<sup>**−1**</sup> **h**<sup>**−1**</sup> **under visible light irradiation, surpassing many reported ZnIn2S4-based photocatalysts. The enhanced performance is ascribed to widened light absorption and enhanced carrier transportation realized by S-vacancy modulation and the co-catalytic effect. Femtosecond ultrafast absorption (fs-TA) spectra and other in-situ/ex-situ characterizations further prove an efficient separation and transfer in an as-prepared ZMX catalyst. These findings open up new perspectives for designing catalysts with vacancy modulation.** 

Photocatalytic water splitting is a promising technology for generating hydrogen, a high-energy-density fuel, from water.<sup>[1,2]</sup> Given that the combustion of hydrogen results solely in water as its byproduct, its adoption not only addresses the energy crisis by providing a clean and efficient energy source but also significantly mitigates environmental pollution concerns.<sup>[3]</sup> Despite its potential, the practical application of photocatalytic water splitting is hampered by inherent limitations in existing photocatalysts. These include inadequate light absorption, inefficient separation of photogenerated charge carriers, and sluggish surface reaction kinetics.<sup>[4–6]</sup> To overcome these challenges, research has focused on developing modified photocatalysts characterized by enhanced photocatalytic activity and higher apparent quantum efficiency.<sup>[7]</sup> This research has led to a variety of approaches aimed at improving photocatalyst performance, such as heterostructure construction,<sup>[8–10]</sup> 

M. Xu, D. Meng, G. Fang, D. Jiao, W. Zhang, X. Cui State Key Laboratory of Automotive Simulation and Control School of Materials Science and Engineering Key Laboratory of Automobile Materials of MOE Electron Microscopy Center Jilin University Changchun 130012, P. R. China E-mail: xqcui@jlu.edu.cn 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202402330 © 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution-NonCommercial License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited and is not used for commercial purposes. 

X. Ruan, S. K. Ravi School of Energy and Environment City University of Hong Kong Tat Chee Avenue, Kowloon, Hong Kong P. R. China E-mail: xiaoruan@cityu.edu.hk; skravi@cityu.edu.hk S.Zhao, J.Leng, S.Jin StateKey Laboratory of MolecularReaction Dynamics Dalian Instituteof Chemical Physics ChineseAcademy of Sciences Dalian 116023, P.R.China Z.Liu, Z.Jiang InstituteforEnergy Research Jiangsu University Zhenjiang 212013, P.R.China K.Ba, T.Xie Collegeof Chemistry Jilin University 2699 Qianjin Street, Changchun 130012, P.R.China 

**DOI: 10.1002/adfm.202402330** 

**2402330 (1 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

heteroatom doping,<sup>[11–13]</sup> co-catalyst loading,<sup>[14,15]</sup> vacancy engineering,<sup>[16,17]</sup> and morphology modulation,<sup>[18–20]</sup> etc. 

ZnIn2S4 (denoted as: ZIS), a typical sulfide photocatalyst, exhibits a two-dimensional layered structure and has garnered considerable attention in photocatalysis research.<sup>[21]</sup> Its large specific surface area, good visible light response, and tunable electronic structure position it as a promising candidate for enhanced photocatalytic performance.<sup>[22,23]</sup> However, the application of ZIS is constrained by its suboptimal surface reaction activity and the slow migration rate of charge carriers. It is commonly known that pristine ZIS has the intrinsic vacancy and the S vacancies in ZnIn2S4 are demonstrated to act as electron traps to enrich electrons which is favorable for electron transfer using density functional theory (DFT).<sup>[24]</sup> However, a detailed study on modulating the S-vacancy in ZIS has so far not been reported. Considering the intrinsic vacancy of ZIS and our previous research works,<sup>[25,26]</sup> we hypothesize that coupling vacancy-ZIS with MXene cocatalyst can promote the separation of photogenerated carriers and efficiently transfer the photogenerated electrons from bulk to the surface, thus enhancing the photocatalytic performance. 

In this work, we first investigate the different S vacancy (Sv) content of pristine ZIS through altering the ratio of reactive precursors-Thioacetamide (TAA). Our investigations reveal that ZIS with a moderate level of Sv displays remarkably improved hydrogen evolution performance compared to other variants. Building on this finding, we selected ZIS with an optimized moderate level of Sv (denoted as ZIS-M) for further experiments. ZIS-M is then coupled with MXene co-catalysts using an electrostatic self-assembly method to form a novel MXene/ZIS Schottky heterojunction, referred to as ZMX. The incorporation of Sv, known for introducing sites for electron trap, alongside MXene, known for its high conductivity, synergistically enhances the transport of photogenerated carriers. The Schottky barrier, formed at the MXene/ZIS interface, plays a crucial role in preventing the dispersion of electrons from MXene to ZIS. This barrier establishes efficient photoelectron transfer channels effectively maintaining MXene as an active reaction center. The optimized as-prepared ZMX catalyst achieved a superior hydrogen evolution rate of 14.82 mmol g<sup>−1</sup> h<sup>−1</sup> , far exceeding the majority of previous reports on ZnIn2S4-based photocatalysts. 

## **2. Results and Discussion** 

### **2.1. Morphology and Structure of ZIS and ZMX** 

**Figure 1** a illustrates the schematic representation of our catalyst design and the hydrogen evolution mechanism. Initially, we investigated various sulfur vacancy (Sv) levels in pristine ZnIn2S4 (denoted as ZIS-X). Our hypothesis posits that ZIS with a moderate level of Sv (referred to as ZIS-M) exhibits optimal photocatalytic performance. Subsequently, this optimal ZIS-M is coupled with different ratios of MXene co-catalyst to form the MXene/ZIS Schottky heterojunction (ZMX). In this system, the moderate Sv levels are theorized to offer favorable electron traps. The cocatalyst MXene is anticipated to effectively conduct photogenerated electrons to the surface, thus promoting the efficient separation and transfer of photogenerated carriers. This synergistic interaction between Sv and MXene co-catalysis is expected to 

### **www.afm-journal.de** 

generate and transport abundant carriers contributing to the enhanced photocatalytic hydrogen evolution performance. To validate our catalyst design hypothesis, we constructed four distinct crystal structure models of ZIS, each with varying levels of Sv (as depicted in Figure 1b–e). Theoretical calculations indicate that ZIS-M possesses the most favorable hydrogen adsorption-free energy. This finding is in line with the results from electron paramagnetic resonance (EPR) tests, further substantiating the superior hydrogen evolution performance of ZIS-M (as shown in Figure 1f,g; Figure S1, Supporting Information). The subsequent synthesis of the ZMX catalyst is based on the ZIS-M variant. 

The morphology and structure of ZMX is characterized by high-resolution transmission electron microscope (HRTEM) images and transmission electron microscope (TEM) (Figure 1h; Figure S2 Supporting Information). The observed lattice spacing of 0.23 nm corresponds to the MXene component, while the 0.32 nm spacing is attributed to ZIS.<sup>[27,28]</sup> Energy dispersive spectroscopy (EDS) mapping images provide further insights, revealing a uniform distribution of elements such as zinc (Zn), indium (In), sulfur (S), and titanium (Ti). This uniformity indicates the successful synthesis of the ZMX catalyst, as shown in Figure 1 i–m. Furthermore, despite the alteration in sulfur vacancy (Sv) levels, the crystal structure and the characteristic sheetstacked morphology of the ZMX catalyst are well preserved, as evidenced in Figures S3 and S4 (Supporting Information). The asprepared ZMX catalysts also retain morphology and X-ray diffraction (XRD) patterns similar to those of ZIS-M. This similarity likely results from the relatively low loading of MXene<sup>[29]</sup> (Figures S5 and S6 Supporting Information). The integration of MXene into the ZIS structure without significant morphological or structural disruption underscores the effective co-catalyst loading. 

### **2.2. Photocatalytic Hydrogen Evolution Performance of the As-Prepared Photocatalyst** 

The photocatalytic hydrogen evolution performance of the synthesized catalysts was evaluated, as presented in **Figures 2** a and S7 (Supporting Information). In this study, both pristine ZIS and various ZIS-X samples were tested for their hydrogen evolution capabilities. Notably, ZIS with moderate sulfur vacancies (ZIS-M) demonstrated the highest rate of hydrogen evolution. This finding aligns with our theoretical predictions and confirms the effectiveness of our catalyst design strategy, where moderate levels of sulfur vacancies are hypothesized to enhance photocatalytic performance. Subsequently, we focused on the optimized ZIS-M catalyst, integrating it with different proportions of MXene co-catalyst to further evaluate hydrogen evolution performance. The resulting ZMX-M catalyst, incorporating ZIS-M with MXene, exhibited an exceptional photocatalytic hydrogen evolution rate of 14.82 mmol g<sup>−1</sup> h<sup>−1</sup> , which is 3.52 times that of pristine ZIS (Figure 2b). This obtained performance exceeds that of most previously reported ZnIn2S4-based photocatalysts<sup>[30–41]</sup> (Figure 2c; Table S1 Supporting Information). The durability and stability of the ZMX-M catalyst were also assessed through cycling experiments. The results confirmed its superior stability, further corroborated by SEM images and XRD patterns taken after the photocatalytic reaction (Figure 2d; Figures S8 and S9, Supporting Information). Additionally, to optimize performance, 

**2402330 (2 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 1.** a) The schematic diagram of the synergistic effect of S-vacancies regulation and MXene co-catalytic effect in ZMX photocatalyst. b–e) ZIS models with poor, moderate, and rich content of Sv and without Sv. f) Calculated Gibbs free energies of hydrogen adsorption for ZIS with different levels of Sv (P, M, and R represent poor, moderate, and rich Sv content respectively). g) EPR spectra of ZIS and ZIS-X. h) HRTEM images of ZMX. i-m) EDS-elemental mapping images of ZMX. 

**2402330 (3 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 2.** a) Photocatalytic hydrogen evolution over time for pristine ZIS and ZIS-X. b) Photocatalytic H2 evolution rates of ZIS-M and ZMX-X. c) Photocatalytic hydrogen evolution rate of ZMX-M compared with previous ZIS-based photocatalysts. d) Cycling tests of ZMX-M. e) ZMX-M with different Pt loading. 

various loadings of platinum (Pt) on the ZMX-M catalyst and TEOA solution concentration were investigated, respectively. It was observed that 0.5 wt.% Pt loading and 10% TEOA on ZMXM yielded the best hydrogen evolution performance (Figure 2e; Figure S7b, Supporting Information). 

nation of photogenerated carriers. The detailed band structure between ZIS and MXene is provided as follows. Additionally, we also provide the work function of the pristine ZIS without vacancy (4.73 eV) (Figure S11, Supporting Information). This suggests that the introduction of vacancy can lead to a higher Fermi energy level, which increases the conductivity of photogenerated electrons and enhances the reduction ability of ZIS.<sup>[45]</sup> 

### **2.3. Catalyst Composition and Photogenerated Carrier Dynamics** 

The elemental composition and surface chemical states of the synthesized samples were analyzed using X-ray photoelectron spectroscopy (XPS) ( **Figure 3** a–d; Figure S10 a,b, Supporting Information). The XPS results reveal no discernible shift in the binding energies for Zn and In in the ZIS-X samples. However, a notable shift is observed in the binding energy of sulfur (S), indicating the presence of sulfur vacancies, Sv.<sup>[42,43]</sup> 

For ZMX-X catalyst, it is observed that the binding energy of Zn and S elements shifts to higher energy with the increased amount of MXene (Figure 3c,d). Meanwhile, the binding energy of element C shifts toward a lower binding energy (Figure S10c, Supporting Information). This suggests the decreased electron density around ZIS and increased electron density on MXene, respectively, providing the evidence that photogenerated electrons will transfer from ZIS to MXene.<sup>[44]</sup> 

Based on the electrostatic potential, the energy difference between the vacuum and Fermi levels can be estimated. The calculated theoretical work functions of ZIS-M and MXene are 4.14 and 6.56 eV, respectively, suggesting that ZIS-M has a higher Fermi level than MXene (Figure 3e,f). This means that the photogenerated electrons will transfer from the conduction band position of ZIS to MXene, thus efficiently inhibiting the recombi- 

### **2.4. Charge Transportation Property** 

The efficiency of separation and migration of photogenerated carriers is crucial for achieving exceptional photocatalytic performance. To evaluate this aspect, we conducted photoelectrochemical analyses along with steady-state and transient surface photovoltage (SPV/TPV) tests on the catalysts. Notably, the ZMX-M catalyst demonstrated the highest photocurrent intensity and the smallest impedance radius, indicative of enhanced charge separation efficiency, as shown in **Figure 4** a,b. Additionally, SPV and TPV tests were employed to assess carrier transportation dynamics. The results from these tests revealed that the as-prepared ZMX-M catalyst exhibited the most substantial photovoltage intensity in both SPV and TPV measurements. This observation provides strong evidence of the efficient separation and transportation of photogenerated carriers in the ZMX-M catalyst, reinforcing its effectiveness, as depicted in Figure 4c,d. 

Ex-situ and in-situ electron spin resonance (ESR) spintrapping experiments were conducted to further investigate the behavior of photogenerated carriers, with results presented in Figure 4e,f. When comparing the as-prepared ZMX-M catalyst 

**2402330 (4 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 3.** XPS spectra of a) Zn 2p, b) S 2p of ZIS-X, and c) Zn 2p, d) S 2p of ZMX-X. e,f) The work functions of MXene and ZIS-M, respectively. 

with pristine ZIS-M, a notable increase in peak intensity for both superoxide and hydroxyl radicals was observed in ZMXM. This enhancement indicates a greater generation of photogenerated carriers under light illumination, while no active radicals were detected in dark conditions, as shown in Figure 4e,f, and Figure S12 (Supporting Information). Furthermore, the intensity of both superoxide and hydroxyl radicals incrementally increased with extended light irradiation times (5, 10, 15, and 30 min). This progressive increase in radical intensity suggests that active radicals are generated through light exposure and that a significant number of photogenerated electrons are involved in the redox reactions, as demonstrated in Figure 4g,h. These findings underscore the enhanced photocatalytic activity of ZMX-M, attributed to its efficient generation and transport of carriers. 

### **2.5. Band Structure and Carrier Mobility** 

The ultraviolet-visible (UV–vis) absorption spectra of all synthesized catalysts display a broad light absorption range, effectively capturing visible light ( **Figure 5** a). The bandgap energies for the ZIS-X catalyst series are measured to be 2.18, 2.14, and 2.17 eV, respectively, as shown in Figure 5b. Notably, ZIS with moderate sulfur vacancy (ZIS-M) exhibits the narrowest bandgap, indicating that moderate Sv levels can enhance visible light absorption efficiency. 

It can be found that the Mott–Schottky (M–S) tests possess a positive slope at different frequencies (500 and 1000 Hz), indicating that ZIS-X is a typical n-type semiconductor. It reveals the flat band potentials of the as-prepared ZIS-X cat- 

alysts are approximately −0.42, −0.32, and −0.39 V (versus RHE, pH 7), respectively, according to the formula ( _E_ RHE = _E_ Ag/AgCl+0.197+0.059 pH) (Figure 5c).<sup>[46]</sup> By analyzing the bandgap and M-S curves, along with valence band spectra, we deduce the energy band structure of these catalysts, as presented in Figure 5d and Figure S13 (Supporting Information). For instance, Taking ZIS-M as an example, we can derive EVB as 1.41 V according to the formula ( _E_ VB = _E_ CB + _E_ g and _E_ NHE = _E_ RHE - 0.059 pH). 

The differing Fermi energy levels (Ef) of ZIS and MXene result in electron transfer from ZIS to MXene upon light irradiation.<sup>[47]</sup> This interaction causes an energy band bending in ZIS and forms a Schottky barrier at the ZIS-MXene interface, effectively inhibiting electron backflow. The high conductivity of MXene facilitates the attraction and accumulation of photogenerated electrons from the conduction band of ZIS. These electrons participate in the photocatalytic hydrogen evolution reaction, highlighting the synergistic effect of the ZIS-MXene heterostructure in enhancing photocatalytic performance. 

To gain deeper insights into the charge separation dynamics within the Schottky junction, we examined the femtosecond ultrafast absorption (fs-TA) spectra of ZIS-M and ZMX-M, as depicted in Figure 5e–j. The excitation wavelengths for all catalysts were set below 400 nm, aligning with their respective band structures. Upon photoexcitation, ZMX-M exhibits broadband absorption in the 450–570 nm probe light range, while ZIS-M absorbs light in the 520–630 nm range (Figure 5e,h), indicating ZMX-M’s superior light absorption capabilities. Over time, a gradual decrease in the intensity of the TA spectra was observed (Figure 5f,i). The decay kinetics of these spectra were probed at 

**2402330 (5 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 4.** a) Transient photocurrent curves. b) EIS plots. c) Steady surface photovoltage, and d) Transient photovoltage. ESR signals of ZIS-M and ZMX-M. e) in aqueous dispersion for DMPO-hydroxyl radical under UV–vis light for 5 min and f) in methanol dispersion for DMPO-superoxide radical, respectively. In situ ESR spectra of ZMX-M g) aqueous dispersion and h) in methanol dispersion under 0, 5, 10, 15, and 30 min of light irradiation, respectively. 

583 and 550 nm, respectively, and analyzed using two exponential decays (Figure 5g,j). The calculated average carrier lifetimes ( _𝜏_ av) were found to be 4233.5 ps for ZIS-M and 1203.5 ps for ZMX-M. The results are consistent with time-resolved photoluminescence (TRPL) spectra (Figure S14, Supporting Information). The shorter carrier lifetime in ZMX-M attributed to the additional emerged channel for the interfacial charge transfer at the interface between ZIS and MXene can promote the separation efficiency, corroborating the findings from the SPV/TPV and photoelectrochemical tests.<sup>[48]</sup> This efficient electron transfer is a key factor contributing to the enhanced photocatalytic activity of the ZMX-M catalyst. 

## **3. Conclusion** 

In summary, this study focused on modulating sulfur vacancies (Sv) in ZnIn2S4 (ZIS) and demonstrated that introducing a moderate level of Sv enhances visible light absorption and improves carrier transport. Given the compatible Fermi energy level (Ef) of ZIS with MXene, the combination of ZIS with MXene as a co-catalyst leads to the formation of the ZMX heterojunction. This heterojunction notably boosts the separation and transfer of photogenerated carriers, resulting in the ZMX catalyst achieving exceptional photocatalytic hydrogen evolution performance. The synergistic effect of the sulfur vacancies and the co-catalysis by 

**2402330 (6 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 5.** a) UV-vis spectra. b) Tauc plots. c) Mott–Schottky plots of ZIS-X catalysts. d) Schematic diagram of band structure. Transient absorption spectra of e,f) ZIS-M, h,i) ZMX-M catalyst. Normalized transient absorption kinetics for g) ZIS-M, j) ZMX-M catalyst after 400 nm laser excitation. 

**2402330 (7 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

MXene contributes to the formation of a Schottky barrier, which effectively facilitates MXene as the primary active site for the photocatalytic hydrogen evolution reaction. This research paves the way for future advancements in photocatalyst development, highlighting the potential of combining vacancy engineering with cocatalysis to enhance photocatalytic efficiency significantly. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

**www.afm-journal.de** 

- [10] C. Yang, X. Wang, Y. Wu, Z. Jin, _Chem. Eng. J._ **2023** , _470_ , 144424. 

- [11] C. Bie, H. Yu, B. Cheng, W. Ho, J. Fan, J. Yu, _Adv. Mater._ **2021** , _33_ , 2003521. 

- [12] R. Wang, G. Che, C. Wang, C. Liu, B. Liu, B. Ohtani, Y. Liu, X. Zhang, _ACS Catal._ **2022** , _12_ , 12206. 

- [13] J. Xu, Q. Li, X. Liu, Q. Yang, _Surf. Interfaces_ **2023** , _43_ , 103593. 

- [14] N. Denisov, S. Qin, J. Will, B. N. Vasiljevic, N. V. Skorodumova, I. A. Pašti, B. B. Sarma, B. Osuagwu, T. Yokosawa, J. Voss, J. Wirth, E. Spiecker, P. Schmuki, _Adv. Mater._ **2023** , _35_ , 2206569. 

- [15] W. Bi, X. Li, L. Zhang, T. Jin, L. Zhang, Q. Zhang, Y. Luo, C. Wu, Y. Xie, _Nat. Commun._ **2015** , _6_ , 8647. 

- [16] H. Li, J. Li, Z. Ai, F. Jia, L. Zhang, _Angew. Chem., Int. Ed._ **2018** , _57_ , 122. 

- [17] T. Hou, Y. Xiao, P. Cui, Y. Huang, X. Tan, X. Zheng, Y. Zou, C. Liu, W. Zhu, S. Liang, L. Wang, _Adv. Energy Mater._ **2019** , _9_ , 1970170. 

## **Acknowledgements** 

This study was supported by the National Natural Science Foundation of China (51872116, 12034002, and 22279044), the Jilin Province Science and Technology Development Program (20210301009GX), project for Selfinnovation Capability Construction of Jilin Province Development and Reform Commission (2021C026) and the Fundamental Research Funds for the Central Universities, and City University of Hong Kong (CityU 9610577) 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Data Availability Statement** 

Research data are not shared. 

## **Keywords** 

hydrogen, MXene, photocatalyst, Vacancy regulation, ZnIn2S4 

Received: February 6, 2024 Revised: March 3, 2024 Published online: April 15, 2024 

   - [18] J. Kröger, A. Jiménez-Solano, G. Savasci, V. W. h. Lau, V. Duppel, I. Moudrakovski, K. Küster, T. Scholz, A. Gouder, M.-L. Schreiber, F. Podjaski, C. Ochsenfeld, B. V. Lotsch, _Adv. Funct. Mater._ **2021** , _31_ , 2102468. 

   - [19] Y. Shang, J. Xu, Y. Ma, Z. Li, Q. Li, _Int. J. Hydrogen Energy_ **2024** , _51_ , 945. 

   - [20] J. Xu, Z. Li, Z. Liu, S. Xu, X. Liu, _J. Ind. Eng. Chem._ **2023** , _126_ , 557. 

   - [21] Y. Song, X. Zheng, Y. Yang, Y. Liu, J. Li, D. Wu, W. Liu, Y. Shen, X. Tian, _Adv. Mater._ **2023** , _36_ , 2305835. 

   - [22] Y. Chao, P. Zhou, J. Lai, W. Zhang, H. Yang, S. Lu, H. Chen, K. Yin, M. Li, L. Tao, C. Shang, M. Tong, S. Guo, _Adv. Funct. Mater._ **2021** , _31_ , 2100923. 

   - [23] J. Wan, L. Liu, Y. Wu, J. Song, J. Liu, R. Song, J. Low, X. Chen, J. Wang, F. Fu, Y. Xiong, _Adv. Funct. Mater._ **2022** , _32_ , 2203252. 

   - [24] S. Zhang, X. Liu, C. Liu, S. Luo, L. Wang, T. Cai, Y. Zeng, J. Yuan, W. Dong, Y. Pei, Y. Liu, _ACS Nano_ **2017** , _12_ , 751. 

   - [25] X. Ruan, D. Meng, C. Huang, M. Xu, X. Wen, K. Ba, D. J. Singh, H. Zhang, L. Zhang, T. Xie, W. Zhang, W. Zheng, S. K. Ravi, X. Cui, _Small Methods_ **2023** , _7_ , 2300627. 

   - [26] Q. Wu, N. Li, Y. Wang, Y. Xu, J. Wu, G. Jia, F. Ji, X. Fang, F. Chen, X. Cui, _Anal. Chem._ **2020** , _92_ , 3354. 

   - [27] X. Liang, X. Wang, X. Zhang, S. Lin, M. Ji, M. Wang, _ACS Catal._ **2023** , _13_ , 6214. 

   - [28] C. Wu, W. Huang, H. Liu, K. Lv, Q. Li, _Appl. Catal. B_ **2023** , _330_ , 122653. 

   - [29] Q. Xi, F. Xie, J. Liu, X. Zhang, J. Wang, Y. Wang, Y. Wang, H. Li, Z. Yu, Z. Sun, X. Jian, X. Gao, J. Ren, C. Fan, R. Li, _Small_ **2023** , _19_ , 2300717. 

   - [30] S. Wang, B. Y. Guan, X. Wang, X. W. D. Lou, _J. Am. Chem. Soc._ **2018** , _140_ , 15145. 

   - [31] C. Du, Q. Zhang, Z. Lin, B. Yan, C. Xia, G. Yang, _Appl. Catal. B_ **2019** , _248_ , 193. 

- [1] J. Ran, H. Zhang, S. Fu, M. Jaroniec, J. Shan, B. Xia, Y. Qu, J. Qu, S. Chen, L. Song, J. M. Cairney, L. Jing, S.-Z. Qiao, _Nat. Commun._ **2022** , _13_ , 4600. 

- [2] W.-K. Chong, B.-J. Ng, Y. J. Lee, L.-L. Tan, L. K. Putri, J. Low, A. R. Mohamed, S.-P. Chai, _Nat. Commun._ **2023** , _14_ , 7676. 

- [3] W. H. Lee, C. W. Lee, G. D. Cha, B.-H. Lee, J. H. Jeong, H. Park, J. Heo, M. S. Bootharaju, S.-H. Sunwoo, J. H. Kim, K. H. Ahn, D.-H. Kim, T. Hyeon, _Nat. Nanotechnol._ **2023** , _18_ , 754. 

- [4] Y. Miao, Y. Zhao, S. Zhang, R. Shi, T. Zhang, _Adv. Mater._ **2022** , _34_ , 2200868. 

- [5] G. Jia, Y. Wang, X. Cui, H. Zhang, J. Zhao, L. H. Li, L. Gu, Q. Zhang, L. Zheng, J. Wu, Q. Wu, D. J. Singh, W. Li, L. Zhang, W. Zheng, _Matter_ **2022** , _5_ , 206. 

- [6] J. Xu, Q. Li, Y. Shang, Z. Liu, Z. Jin, _Sol. RRL_ **2024** , _8_ , 2301006. 

- [7] R. Chen, S. Chen, L. Wang, D. Wang, _Adv. Mater._ **2023** , _36_ , 2304713. 

- [8] X. Ruan, C. Huang, H. Cheng, Z. Zhang, Y. Cui, Z. Li, T. Xie, K. Ba, H. Zhang, L. Zhang, X. Zhao, J. Leng, S. Jin, W. Zhang, W. Zheng, S. K. Ravi, Z. Jiang, X. Cui, J. Yu, _Adv. Mater._ **2023** , _35_ , 2209141. 

- [9] X. Ruan, D. Meng, C. Huang, M. Xu, D. Jiao, H. Cheng, Y. Cui, Z. Li, K. Ba, T. Xie, L. Zhang, W. Zhang, J. Leng, S. Jin, S. K. Ravi, Z. Jiang, W. Zheng, X. Cui, J. Yu, _Adv. Mater._ **2023** , _36_ , 2309199. 

- [32] Q. Zhu, S. Xu, W. Wu, Y. Qi, Z. Lin, Y. Li, Y. Qin, _Angew. Chem., Int. Ed._ **2022** , _61_ , e202205312. 

- [33] Y. Wang, M. Liu, C. Wu, J. Gao, M. Li, Z. Xing, Z. Li, W. Zhou, _Small_ **2022** , _18_ , 2202544. 

- [34] W. Yang, X.-L. Wang, N. Kong, C. Liu, P. Sun, Z. Wang, Y. Ding, H. Lin, D. Li, T. Wu, _Appl. Catal. B_ **2021** , _295_ , 120266. 

- [35] H. Fan, Y. Jin, K. Liu, W. Liu, _Adv. Sci._ **2022** , _9_ , 2104579. 

- [36] B. Lin, H. Li, H. An, W. Hao, J. Wei, Y. Dai, C. Ma, G. Yang, _Appl. Catal. B_ **2018** , _220_ , 542. 

- [37] L. Su, P. Wang, J. Wang, D. Zhang, H. Wang, Y. Li, S. Zhan, J. Gong, _Adv. Funct. Mater._ **2021** , _31_ , 2104343. 

- [38] J. Hu, C. Chen, Y. Zheng, G. Zhang, C. Guo, C. M. Li, _Small_ **2020** , _16_ , 2002988. 

- [39] S. Wang, Y. Wang, S. L. Zhang, S.-Q. Zang, X. W. Lou, _Adv. Mater._ **2019** , _31_ , 1903404. 

- [40] F. Xing, C. Cheng, J. Zhang, Q. Liu, C. Chen, C. Huang, _Appl. Catal. B_ **2021** , _285_ , 119818. 

- [41] Y. Zhong, M. Li, X. Luan, F. Gao, H. Wu, J. Zi, Z. Lian, _Appl. Catal. B_ **2023** , _335_ , 122859. 

- [42] X. Shi, W. Dai, X. a. Dong, Q. Ren, J. Sheng, F. Dong, _Appl. Catal. B_ **2023** , _339_ , 123147. 

**2402330 (8 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 



**www.advancedsciencenews.com** 

- [43] C. Tang, T. Bao, S. Li, X. Wang, H. Rao, P. She, J.-s. Qin, _Appl. Catal. B_ **2024** , _342_ , 123384. 

- [44] G. Zuo, Y. Wang, W. L. Teo, A. Xie, Y. Guo, Y. Dai, W. Zhou, D. Jana, Q. Xian, W. Dong, Y. Zhao, _Angew. Chem., Int. Ed._ **2020** , _59_ , 11287. 

- [45] T. Su, C. Men, L. Chen, B. Chu, X. Luo, H. Ji, J. Chen, Z. Qin, _Adv. Sci._ **2022** , _9_ , 2103715. 

- [46] X. Song, W. Li, X. Liu, Y. Wu, D. He, Z. Ke, L. Cheng, C. Jiang, G. Wang, X. Xiao, Y. Li, _J. Energy Chem._ **2021** , _55_ , 154. 

- [47] X. Ruan, X. Cui, Y. Cui, X. Fan, Z. Li, T. Xie, K. Ba, G. Jia, H. Zhang, L. Zhang, W. Zhang, X. Zhao, J. Leng, S. Jin, D. J. Singh, W. Zheng, _Adv. Energy Mater._ **2022** , _12_ , 2200298. 

- [48] C. Yuan, H. Yin, H. Lv, Y. Zhang, J. Li, D. Xiao, X. Yang, Y. Zhang, P. Zhang, _JACS Au_ **2023** , _3_ , 3127. 

**2402330 (9 of 9)** 

_Adv. Funct. Mater._ **2024** , _34_ , 2402330 

© 2024 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

