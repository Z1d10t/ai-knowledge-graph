# Dopant-additive synergism enhances perovskite solar modules

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 248 |
| 作者 | Bin Ding, Yong Ding, Jun Peng, Jan Romano-deGea, Lindsey E. K. Frederiksen, Hiroyuki Kanda, O. Syzgantseva, M. A. Syzgantseva et al. |
| DOI | 10.1038/s41586-024-07228-z |
| 源文件 | 086_Ding_2024_Dopant-additive-synergism-enhances-perovskite-so.pdf |

---
Article 

# **Dopant-additive synergism enhances perovskite solar modules** 

|https://doi.org/10.1038/s41586-024-07228-z<br>Received: 17 July 2023<br>Accepted: 22 February 2024<br>Published online: 4 March 2024|**Bin Ding**<sup>**1,13**</sup>**, Yong Ding**<sup>**1,2,13** ✉</sup>**, Jun Peng**<sup>**3,13**</sup>**, Jan Romano-deGea**<sup>**1,13**</sup>**, Lindsey E. K. Frederiksen**<sup>**1,13**</sup>**,**<br>**Hiroyuki Kanda**<sup>**1**</sup>**, Olga A. Syzgantseva**<sup>**4**</sup>**, Maria A. Syzgantseva**<sup>**4**</sup>**, Jean-Nicolas Audinot**<sup>**5**</sup>**,**<br>**Jerome Bour**<sup>**5**</sup>**, Song Zhang**<sup>**6**</sup>**, Tom Wirtz**<sup>**5**</sup>**, Zhaofu Fei**<sup>**1** ✉</sup>**, Patrick Dörflinger**<sup>**7**</sup>**, Naoyuki Shibayama**<sup>**8**</sup>**,**<br>**Yunjuan Niu**<sup>**9**</sup>**, Sixia Hu**<sup>**10**</sup>**, Shunlin Zhang**<sup>**1**</sup>**, Farzaneh Fadaei Tirani**<sup>**1**</sup>**, Yan Liu**<sup>**11**</sup>**, Guan-Jun Yang**<sup>**11**</sup>**,**<br>**Keith Brooks**<sup>**1**</sup>**, Linhua Hu**<sup>**9**</sup>**, Sachin Kinge**<sup>**12**</sup>**, Vladimir Dyakonov**<sup>**7**</sup>**, Xiaohong Zhang**<sup>**3** ✉</sup>**,**<br>**Songyuan Dai**<sup>**2**</sup>**, Paul J. Dyson**<sup>**1** ✉</sup>**& Mohammad Khaja Nazeeruddin**<sup>**1** ✉</sup>|
|---|---|
|Open access||
|Check for updates|Perovskite solar cells (PSCs) are among the most promising photovoltaic technologies<br>owing to their exceptional optoelectronic properties<sup>1,2</sup>. However, the lower efficiency,<br>poor stability and reproducibility issues of large-area PSCs compared with laboratory-<br>scale PSCs are notable drawbacks that hinder their commercialization<sup>3</sup>. Here we report<br>a synergistic dopant-additive combination strategy using methylammonium chloride<br>(MACl) as the dopant and a Lewis-basic ionic-liquid additive, 1,3-bis(cyanomethyl)<br>imidazolium chloride ([Bcmim]Cl). This strategy effectively inhibits the degradation<br>of the perovskite precursor solution (PPS), suppresses the aggregation of MACl and<br>results in phase-homogeneous and stable perovskite films with high crystallinity and<br>fewer defects. This approach enabled the fabrication of perovskite solar modules<br>(PSMs) that achieved a certified efficiency of 23.30% and ultimately stabilized at<br>22.97% over a 27.22-cm<sup>2</sup>aperture area, marking the highest certified PSM performance.<br>Furthermore, the PSMs showed long-term operational stability, maintaining 94.66%<br>of the initial efficiency after 1,000 h under continuous one-sun illumination at room<br>temperature. The interaction between [Bcmim]Cl and MACl was extensively studied<br>to unravel the mechanism leading to an enhancement of device properties. Our<br>approach holds substantial promise for bridging the benchtop-to-rooftop gap<br>and advancing the production and commercialization of large-area perovskite<br>photovoltaics.|



Formamidinium-based lead perovskites (FAPbI3) show optimal bandgap absorption, but the formation of their photoactive ‘black phase’ (or α phase) is energetically unfavourable and the resulting perovskite thin films (PTFs) suffer from low stability owing to low crystallinity<sup>4</sup> . Dopants that are incorporated into the perovskite structure<sup>5–8</sup> modulate the optical and thermodynamic properties of FAPbI3. Among these dopants, MACl reduces perovskite formation energy, stabilizes the black-phase perovskite and favours crystal growth in preferential orientations<sup>9</sup> . However, unfavourable intermediate phases that negatively affect crystallinity, phase purity and performance are not suppressed simply by doping with MACl. Further tuning of perovskite fabrication by incorporating additives such as ionic liquids results in perovskites with improved device efficiency and stability through 

passivation of defects, enhancement of crystallinity and phase purity or suppression of film decomposition<sup>10–14</sup> . Our previous work on ionic liquids has demonstrated that imidazolium-based cations with Lewis-basic nitrile functional groups with highly electronegative Cl<sup>−</sup> anions can greatly enhance PTF stability and efficiency<sup>14</sup> . In this work, the structurally optimized ionic liquid [Bcmim]Cl was combined with MACl for the formation of high-quality Cs0.05MA0.05FA0.90Pb(I1− _x_ Cl _x_ )3 perovskite films with uniform, well-oriented grains and improved phase purity, resulting in the fabrication of extremely efficient and stable PSCs and PSMs. The interaction between [Bcmim]Cl and MACl and their respective roles was systematically investigated to explain the underlying mechanisms inducing their positive effects. 

> 1Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), Lausanne, Switzerland. 2State Key Laboratory of Alternate Electrical Power System with Renewable Energy Sources, North China Electric Power University, Beijing, P. R. China.<sup>3</sup> Institute of Functional Nano & Soft Materials (FUNSOM), Jiangsu Key Laboratory of Advanced Negative Carbon Technologies, Joint International Research Laboratory of Carbon-Based Functional Materials and Devices, Soochow University, Suzhou, P. R. China.<sup>4</sup> Department of Chemistry, Lomonosov Moscow State University, Moscow, Russia.<sup>5</sup> Advanced Instrumentation for Nano-Analytics (AINA), Materials Research and Technology (MRT) Department, Luxembourg Institute of Science and Technology (LIST), Belvaux, Luxembourg.<sup>6</sup> State Key Laboratory of Magnetic Resonance and Atomic and Molecular Physics, Innovation Academy for Precision Measurement Science and Technology, Chinese Academy of Sciences, Wuhan, P. R. China.<sup>7</sup> Institute of Physics, Julius Maximilian University of Würzburg, Würzburg, Germany.<sup>8</sup> Faculty of Biomedical Engineering, Graduate School of Engineering, Toin University of Yokohama, Yokohama, Japan.<sup>9</sup> Key Laboratory of Photovoltaic and Energy Conservation Materials, CAS, Institute of Solid-State Physics, Hefei Institutes of Physical Science, Chinese Academy of Sciences, Hefei, P. R. China.<sup>10</sup> Materials Characterization and Preparation Center, Southern University of Science and Technology, Shenzhen, P. R. China.<sup>11</sup> State Key Laboratory for Mechanical Behavior of Materials, School of Materials Science and Engineering, Xi’an Jiaotong University, Xi’an, P. R. China. 12Materials Engineering Division, Toyota Technical Centre, Toyota Motor Europe, Zaventem, Belgium. 13These authors contributed equally: Bin Ding, Yong Ding, Jun Peng, Jan Romano-deGea, Lindsey E. K. Frederiksen.<sup>✉</sup> e-mail: dingy@ncepu.edu.cn; zhaofu.fei@epfl.ch; xiaohong_zhang@suda.edu.cn; paul.dyson@epfl.ch; mdkhaja.nazeeruddin@epfl.ch 

Nature | Vol 628 | 11 April 2024 | **299** 

## Article 



<!-- Start of picture text -->
a b c<br>Au 81.64 82.24 8.91 9.35 75.22 80.53 20.11 22.78<br>ITO/MoO3 ±1.31 ±0.81 10 ±0.24  ±0.81 84 ±1.75  ±0.81 24 ±0.74 ±0.42<br>Spiro-OMeTAD<br>PEAI  84<br>Perovskite<br>9 78 21<br>81<br>PMMA:PCBM/SnO2@TiO2<br>FTO<br>78 8 72 18<br>Control  Target Control  Target Control  Target Control  Target<br>d e<br>80 Aperture area: 27.22 cm 2 24 Certified: 22.97%<br>10<br>16<br>60 5<br> First (reverse) 8<br> First (forward)<br>40  Second (reverse) � average,reverse = 23.30% 0 0<br> Second (forward) � average,forward = 21.20% 3 30<br> Third (reverse)<br>20 6<br> Third (forward) 60<br>Certified 9<br>0 90<br>0 2 4 6 8 10 0 50 100 150 200 250 300 350<br>Voltage (V) Time (s)<br> (mA) I SC  (V) V OC FF (%) PCE (%)<br>SPO (%)  (W) P max<br>Current (mA)<br> (V) V mpp  (mA) I mpp<br><!-- End of picture text -->

**Fig. 1 | PSM structure and photovoltaic performance of the control and target PSMs. a** , Cross-sectional SEM image of the target device. Scale bar, 1 μm. **b** , Picture of one PSM. **c** , Distribution of short-circuit current ( _I_ SC), _V_ OC, FF and 

PCE. **d** , Current–voltage ( _I–V_ ) curves of three consecutive tests from forward and reverse scans for the certified PSM. **e** , Stabilized power output (SPO) performance of the certified PSM. 

#### **[Bcmim]Cl/MACl-containing PSC performance** 

N-i-p-structured PSCs were fabricated using Cs0.05MA0.05FA0.90Pb(I1− _x_ Cl _x_ )3 PTFs (Fig. 1a). We evaluated the effects on PSC efficiency of an imidazolium-based ionic liquid series with Cl<sup>−</sup> anions as perovskite additives in combination with MACl. Among the investigated ionic liquids, only [Bcmim]Cl markedly enhanced the efficiency of PSCs (Supplementary Fig. 1). Subsequently, we explored a series of ionic liquids pairing [Bcmim]<sup>+</sup> with different anions, including BF−4, PF−6, I− and SCN<sup>−</sup> . Our findings revealed that all of the [Bcmim]<sup>+</sup> -based ionic liquids substantially increased the efficiency of PSCs (Supplementary Fig. 2), but [Bcmim]Cl still yielded the highest efficiency. Consequently, we focused our research on the [Bcmim]Cl/MACl system. The concentrations of MACl and [Bcmim]Cl were optimized (0–60 mol% and 0–1.4 mol%, respectively (Supplementary Figs. 3 and 4)). The PSCs containing 20 mol% MACl and 0.6 mol% [Bcmim]Cl (‘target’) achieved an average power conversion efficiency (PCE) of 25.21 ± 0.16% with a short-circuit current density ( _J_ SC) of 25.71 ± 0.06 mA cm<sup>−2</sup> , an opencircuit voltage ( _V_ OC) of 1.17 ± 0.01 V and a fill factor (FF) of 83.97 ± 0.37%. These values are much higher than those of the devices with 20 mol% MACl but without [Bcmim]Cl (‘control’). The improvement in PCE was primarily attributed to enhanced FF and _V_ OC, whereas the _J_ SC exhibited little difference across the groups (Supplementary Fig. 4). 

PSMs consisting of eight subcells connected in series were prepared (Fig. 1b). The target PSMs exhibited greatly improved performance, achieving an average PCE of 22.78 ± 0.42% over the control PSMs (average PCE of 20.11 ± 0.74%; Fig. 1c) on a 27.22-cm<sup>2</sup> aperture area. Independent testing conducted by the Chinese National PV Industry Measurement and Testing Center (NPVM), a reputable certification body<sup>15</sup> , showed the highest certified PSM performance (Supplementary Table 1). The certified efficiencies of the target PSM were 23.30% ± 0.01% (reverse) and 21.20% ± 0.14% (forward; Fig. 1d and Supplementary Fig. 5). After about 300 s of maximum power point (MPP) tracking, the target PSM demonstrated an average stabilized power output efficiency of 22.50%, eventually stabilizing at 22.97% (Fig. 1e and Supplementary Fig. 6). To address issues associated with 

scalability and transferability inherent to the spin-coating fabrication method, a blade-coating approach was used, showing that the [Bcmim]Cl/MACl-based PSM still achieves high efficiencies (21.56 ± 0.442%) (Supplementary Fig. 7) and demonstrating its viability for large-scale manufacturing. 

#### **[Bcmim]Cl-mediated PPS stabilization** 

The PPSs used for PSM fabrication suffer from short shelf lives<sup>16,17</sup> and their decomposition detrimentally affects both PTF crystallinity and device repeatability<sup>18</sup> . The decomposition of both mixed MA<sup>+</sup> / FA<sup>+</sup> perovskites and their constituent PPSs has been previously studied<sup>19–21</sup> (Supplementary Fig. 8). The interaction between [Bcmim]Cl and MACl, as well as its impact on PPS stability, were investigated by examining species present in the PPS as a function of temperature and time using in operando nuclear magnetic resonance (NMR) spectroscopy. Mixed FA<sup>+</sup> /MA<sup>+</sup> PPSs decompose by means of a previously reported condensation reaction, with singly methylated FAI ( _N_ -methylformamidinium iodide, MFAI) and doubly methylated FAI ( _N,N_ -dimethylformamidinium iodide, DMFAI) as the primary products, giving rise to peaks at 2.78 ppm and 2.94 ppm, respectively, in the<sup>1</sup> H NMR spectra of the studied system<sup>22,23</sup> (Supplementary Fig. 9). PPS stability was determined by monitoring the appearance of these species in<sup>1</sup> H NMR spectra of the PPSs at varying temperatures. The 1H NMR peaks corresponding to MFAI and DMFAI first appear at 30 °C and 60 °C, respectively, for the control PPS. However, in the presence of 0.6 mol% [Bcmim]Cl (target PPS), condensation reaction products are only observed at higher temperatures, that is, 55 °C for MFAI and 75 °C for DMFAI (Supplementary Fig. 10). Further kinetic studies of PPS stability were conducted at 25 °C and 60 °C over a period of 24 h, showing the increased stability of MA<sup>+</sup> in the target PPS (Fig. 2 and Supplementary Fig. 11). Slower decomposition of MA<sup>+</sup> in the presence of [Bcmim]Cl is also supported by a smaller downfield (to higher δ values) peak shift in the<sup>207</sup> Pb NMR spectra of the target PPS both before and after 24 h (Supplementary Fig. 12a,b) compared with the control PPS (Supplementary Fig. 12c,d). In this system, changes in 

**300** | Nature | Vol 628 | 11 April 2024 



<!-- Start of picture text -->
a b<br>Control PPS MFAI Target PPS<br>24 h DMFAI * 24 h DMFAI MFAI *<br>0 h 0 h<br>3.0 2.9 2.8 2.7 3.0 2.9 2.8 2.7<br>1H chemical shift (ppm) 1H chemical shift (ppm)<br>c<br>X [Bcmim]Cl<br>H3C NH2 + HX PPS decomposition<br>H3C NH3 Less deprotonation<br>MA + Slower rate MA<br><!-- End of picture text -->

**Fig. 2 |**<sup>**1**</sup> **H NMR spectra of the PPS degradation at 60 °C for 24 h. a** , Control. **b** , Target. Key peaks from MFAI (2.78 ppm) and DMFAI (2.94 ppm) are highlighted. Spectra were recorded every 15 min in a mixture of d6-DMSO:d7-DMF with the ratio used for PSC fabrication and the intensity is normalized to the residual solvent peak (*). **c** , Mechanism of the [Bcmim]Cl-mediated stabilization of the PPS. 

207Pb peak chemical shift indicate an increase in free halide content, linked to extent of decomposition. Notably, PTFs fabricated from target PPSs have the same morphology regardless of whether the PPS was freshly prepared or aged for 10 days, whereas the control PTFs 

show notable symptoms of degradation when not made from a fresh PPS (Supplementary Fig. 13). By considerably slowing PPS decomposition, [Bcmim]Cl leads to high-quality PTFs and, as a result, highly efficient and stable PSMs. 

The improved stability and efficiency of the target PSCs highlight the synergistic effect from combining [Bcmim]Cl and MACl in the PTF. To clarify potential stabilization mechanisms and/or interactions between MACl and [Bcmim]Cl that might contribute to the observed synergism, several model NMR spectroscopic experiments were carried out on the PPS (Fig. 3a). Adding [Bcmim]Cl (0.01–1 eq., 0.2–20 mol% relative to the operational concentration of PbI2) to a MACl solution results in substantial broadening (from 0.015 ppm to 0.1 ppm; Fig. 3b) of the MA<sup>+</sup> cation NH peak (7.99 ppm) in the<sup>1</sup> H NMR spectra. Furthermore, as the concentration of [Bcmim]Cl increases, this signal shifts from 7.99 ppm to 8.23 ppm (Fig. 3c). Replacing MACl by MAI results in identical changes to the<sup>1</sup> H NMR spectra (Supplementary Fig. 14a), indicating that these effects are intrinsic to the MA<sup>+</sup> cation. The addition of other ionic liquids previously used as additives<sup>10,14</sup> (Fig. 3a) or LiCl (Supplementary Fig. 14b) with MACl also results in a broadening of the peak, but only the combinations with [Bcmim]Cl show a notable effect at relevant fabrication concentrations (0.6 mol% relative to operational concentration of PbI2) for the real PPS and PTF systems (Fig. 3b). 

The observed downfield shift of the NH peak in the<sup>1</sup> H NMR spectrum with the addition of all ionic liquids tested (Fig. 3c) is indicative of hydrogen bonding, which has been shown to improve PTF stability and efficiency<sup>24</sup> . Efficient passivation of PSCs containing bis(cyanomethyl) imidazolium bis(trifluoromethylsulfonyl)imide ([Bcmim]TFSI), which establishes an extended hydrogen bond network to improve the stability of the prepared PTFs, has been previously reported<sup>13</sup> . [Bcmim]Cl 



<!-- Start of picture text -->
a 0 1<br>2 3<br>4 5<br>N N NH 10 20<br>Cl 40 60<br>N N 80 100<br>8.3 8.2 8.1 8.0 7.9<br>N N<br>Cl<br>N<br>8.3 8.2 8.1 8.0 7.9<br>N N<br>Cl<br>8.3 8.2 8.1 8.0 7.9<br>N N<br>Cl<br>8.3 8.2 8.1 8.0 7.9<br>1H  chemical shift (ppm)<br>b c<br>8.24<br>0.12<br>8.16<br>0.08<br>8.08<br>0.04 [Bcmim]Cl [Bcmim]Cl<br>[Cmmim]Cl [Cmmim]Cl<br>[Dmim]Cl [Dmim]Cl<br>[Bmim]Cl 8.00 [Bmim]Cl<br>0<br>0 2 4 20 40 60 80 100 0 2 4 20 40 60 80 100<br>Ionic liquid/MACl ratio (%) Ionic liquid/MACl ratio (%)<br>FWHM (ppm)<br>Chemical shift (ppm)<br><!-- End of picture text -->

**Fig. 3 | NMR spectra of the interaction between [Bcmim]Cl and MACl. a** ,<sup>1</sup> H NMR spectra of MACl solution as a function of concentration for four ionic liquids: [Bcmim]Cl, 1-cyanomethyl-3-methylimidazolium chloride ([Cmmim]Cl), 1,3-dimethylimidazolium chloride ([Dmim]Cl) and 1-butyl- 

3-methylimidazolium chloride ([Bmim]Cl). Full width at half maximum (FWHM) shift ( **b** ) and chemical shift of the MA<sup>+</sup> NH peak as a function of ionic liquid/MACl concentration ratio ( **c** ). 

Nature | Vol 628 | 11 April 2024 | **301** 

## Article 



<!-- Start of picture text -->
a         With MACl b With MACl/[Bcmim]Cl c Without MACl or [Bcmim]Cl<br>S1 S2 2H 4H 3C 4 S1 S2 2H 4H 3C S1 S2 2H 4H 3C<br>30 s 3 30 s<br>6 20 s 30 s 20 s<br>15 s 3<br>20 s 15 s<br>10 s 2<br>4 2 15 s 10 s<br>5 s 10 s<br>1<br>2 1<br>5 s 5 s<br>2 s<br>2 s 2 s<br>0 0 0<br>6 8 10 12 14 6 8 10 12 14 6 8 10 12 14<br>2 �  (º) 2 �  (º) 2 �  (º)<br>d With [Bcmim]Cl e<br>S1 S2 2H 4H 3C<br>2  Without MACl or [Bcmim]Cl<br>3 30 s  With [Bcmim]Cl<br>20 s  With MACl<br> With MACl/[Bcmim]Cl<br>15 s<br>2<br>10 s<br>1<br>1 5 s<br>2 s<br>0 0<br>6 8 10 12 14 10 20 30 40<br>2 �  (º) 2 �  (º)<br>4Intensity (a.u. × 10) 4Intensity (a.u. × 10) 5Intensity (a.u. × 10)<br>4Intensity (a.u. × 10) 5)Intensity (a.u. × 10<br><!-- End of picture text -->

**Fig. 4 | XRD patterns of the PTFs as a function of annealing time. a** , XRD patterns of the control PTF with only MACl as a function of annealing (100 °C) time. The peaks at 6.79° and 7.41° correspond to solvate phase S1 and the peak at 9.41° corresponds to solvate phase S2 (ref. 31). The peaks located at 11.99°, 13.39° and 14.15° correspond to the 2H phase (δ phase), hexagonal phase (4H) and 3C phase (α phase), respectively<sup>32</sup> . **b** , XRD patterns of the target PTF with 

both [Bcmim]Cl and MACl as a function of annealing (100 °C) time. **c** , XRD patterns of the PTF without MACl or [Bcmim]Cl as a function of annealing (100 °C) time. **d** , XRD patterns of the PTFs with only [Bcmim]Cl as a function of annealing (100 °C) time. **e** , XRD patterns of the PTFs after annealing at 100 °C for 60 min and at 150 °C for 10 min. The peak located at 12.70° corresponds to the (001) peak of PbI2. a.u., arbitrary units. 

was found to be a stronger hydrogen bond acceptor than [Bcmim]TFSI (Supplementary Fig. 15) using an established method<sup>25</sup> and may induce further stabilizing effects. 

Peak broadening demonstrates that the NH protons are engaging in chemical exchange (see Supplementary Note 1 and Supplementary Table 2). The interaction between these protons and other exchangeable protons in the PPS, such as the one in [Bcmim]Cl, accelerates nuclear relaxation of the NH proton, inducing peak broadening in the<sup>1</sup> H NMR spectra. Imidazolium-based ionic liquids can act as weak Brønsted acids through the proton in the 2-position. As confirmed by pH measurements (Supplementary Table 3), the electron-withdrawing nitrile-functionalized side chains in [Bcmim]Cl increase the acidity of this ionic liquid relative to the others investigated in this work. NMR exchange spectroscopy (EXSY), used to detect proton exchange, indicates that the NH protons of MACl and the acidic 2-proton of the [Bcmim]<sup>+</sup> cation exchange in solution (Supplementary Fig. 16a). Notably, this exchange process is also visible in the EXSY NMR spectra of the target PPS (Supplementary Fig. 16b) but not observed for [Bcmim]<sup>+</sup> when paired with other anions such as BF−4, PF−6, I− and SCN− (Supplementary Fig. 17), emphasizing the uniqueness of the Cl<sup>−</sup> salt. The observed proton exchange and reduced relaxation indicate that the deprotonation of MA<sup>+</sup> to methylamine is inhibited (Fig. 2c), deterring the condensation reaction between methylamine and FA<sup>+</sup> (Supplementary Fig. 9) and stabilizing the PPS. 

#### **[Bcmim]Cl/MACl-based PTF characteristics** 

The impact of [Bcmim]Cl on PTFs was investigated by preparing films from PPSs containing 20 mol% MACl and 0–1.4 mol% [Bcmim]Cl. X-ray diffraction (XRD) patterns of the PTFs are all comparable, with 

the (110) peak intensity increasing with increasing [Bcmim]Cl content (Supplementary Fig. 18a). As evidenced by rocking curves and grazing-incidence wide-angle X-ray scattering (GIWAXS) (Supplementary Fig. 18b–d), the addition of [Bcmim]Cl promotes crystal growth preferentially in the (110) and (220) orientations. Scanning electron microscopy (SEM) images reveal increased average grain size in perovskite crystals with increasing [Bcmim]Cl content (Supplementary Fig. 18e). Combining MACl and [Bcmim]Cl not only improves PTF crystallinity and promotes crystal growth along preferred orientations but is also applicable to [Bcmim]-based ionic liquids with other anions (Supplementary Fig. 19). Furthermore, the target has a much higher steady-state photoluminescence (PL) mapping intensity than the control PTF, consistent with the PL quantum yield (PLQY) and time-resolved PL (TRPL) spectra (Supplementary Fig. 20). Increased PLQY, TRPL lifetimes and charge-carrier diffusion in target PTFs indicate suppressed trap-assisted nonradiative recombination (Supplementary Table 4), confirming the improved _V_ OC (refs. 26,27). Therefore, combining [Bcmim]Cl and MACl reduces PTF defects and increases charge-carrier lifetime, which both improve device performance. 

To determine how MACl and [Bcmim]Cl improve PTF quality, the intermediate phase transition during the annealing process from precursor PTF to crystalline PTF was monitored by XRD. Unfavourable intermediate phases (see Fig. 4 legend for peak assignments) are present in the control PTFs during annealing (Fig. 4a). The unfavourable intermediate phase peaks decrease in intensity with prolonged annealing time and disappear after 30 s. Meanwhile, the intensity of the black-phase perovskite peak (3C or α phase, 14.15°) increases with extended annealing time, becoming the dominant phase after 30 s. By contrast, the unfavourable intermediate phases are initially absent in the target PTFs. The XRD pattern is instead dominated by 

**302** | Nature | Vol 628 | 11 April 2024 



<!-- Start of picture text -->
a SE [C–N] – Cl – I – b SE Cs + Pb +<br>c 0 30 0 50 0 40 d 0 100 0 15<br>Control<br>Without annealing<br>Target<br>Control<br>With annealing<br>Target<br><!-- End of picture text -->

**Fig. 5 | Secondary electron images with corresponding compositional mapping of PTFs by HIM-SIMS imaging.** Negative-mode ( **a** ) and positive-mode ( **b** ) SIMS polarity imaging of PTFs without annealing. Negative-mode ( **c** ) and 

positive-mode ( **d** ) SIMS polarity imaging of PTFs annealed at 100 °C for 60 min then at 150 °C for 10 min. SE, secondary electron. Scale bars, 1 μm. 

the black-phase perovskite peak (Fig. 4b), which increases in intensity with prolonged annealing time. PPSs that contain neither MACl nor [Bcmim]Cl crystallize by means of a 2H → 3C sequence (Fig. 4c), whereas adding [Bcmim]Cl alone considerably suppresses the 4H, S1 and S2 phases, inducing the 2H → 3C transition after less annealing time (Fig. 4d). The black-phase peak for the target PTF is more intense than for the control PTF and the PTF with MACl alone (8.27 and 3.66 times higher, respectively), indicating that only the synergism between MACl and [Bcmim]Cl substantially boosts PTF crystallinity (Fig. 4e). SEM images show that increasing MACl concentration enhances PTF crystallinity and grain size (Supplementary Figs. 21 and 22), but ≥30 mol% MACl induces excess pinhole formation (Supplementary Fig. 22). However, PTFs containing [Bcmim]Cl and high MACl concentrations demonstrate suppressed pinhole formation, maintaining large grains with greater uniformity (Supplementary Fig. 23). 

Phase distribution in the target and control PTFs, before and after annealing, was investigated using helium ion microscopy coupled with secondary ion mass spectrometry (HIM-SIMS). Unannealed control PTFs exhibit considerable MACl clustering, as evidenced by the co-localized concentrations of [C–N]<sup>−</sup> and Cl<sup>−</sup> ions (Fig. 5a). Similarly, Cs<sup>+</sup> aggregation is observed, as evidenced by areas enriched with Cs<sup>+</sup> and depleted of Pb<sup>+</sup> (Fig. 5b), which might be attributed to the low solubility of caesium salts in the PPS<sup>28</sup> . By contrast, unannealed target PTFs have a more homogeneous phase distribution (Fig. 5c), attributable to the presence of [Bcmim]Cl. After annealing, both PTFs exhibit improved phase uniformity. The Cs-based aggregates melt and disappear (Fig. 5d), in accordance with previous reports that annealing at 150 °C converts Cs-based aggregates into perovskite phases and eliminates local inhomogeneities<sup>28</sup> . However, the annealed target PTFs exhibit less Cs<sup>+</sup> depletion. Depth profiling of the target PTF using time-of-flight SIMS (ToF-SIMS) reveals that [Bcmim]<sup>+</sup> is uniformly distributed across the 

grain boundaries (Supplementary Fig. 24). Adding [Bcmim]Cl to the PPS maintains the large MACl-induced PTF grain sizes while improving crystal uniformity and quality by encouraging direct transformation to black-phase perovskite and even distribution of MACl and other components in the PTF. 

High-resolution X-ray photoelectron spectroscopy spectra of PTFs incorporating increasing [Bcmim]Cl concentrations show marked Pb 4f peak shifts to higher energy, indicating that [Bcmim]Cl interacts with Pb<sup>2+</sup> in the PTF (Supplementary Fig. 25). The [Bcmim]Cl adsorption energies on various perovskite surfaces were calculated using density functional theory (DFT) and show that both the nitrile groups in [Bcmim]<sup>+</sup> and Cl<sup>−</sup> are able to interact with Pb<sup>2+</sup> and occupy halide vacancies (Supplementary Fig. 26). The passivation of undercoordinated Pb<sup>2+</sup> sites has also been proposed to stabilize PTFs<sup>10</sup> . Solution 207Pb NMR spectra of the target and control PPSs further support the presence of interactions between [Bcmim]<sup>+</sup> and Pb<sup>2+</sup> ions (Supplementary Fig. 27). Because [Bcmim]Cl is distributed throughout the PTF (Supplementary Fig. 24b), it is plausible that it passivates undercoordinated sites at the grain boundaries within the PTF. However, the nature of this interaction is unlikely to be the formation of new Pb-N dative bonds as coordination of [Bcmim]<sup>+</sup> nitrile groups to Pb<sup>2+</sup> is not evident in single-crystal structures derived from model reactions (Supplementary Fig. 28) or DFT calculation results (Supplementary Fig. 26). 

Dynamic light scattering (DLS) measurements of the control PPS reveal two peaks with average diameters of 1.65 and 4,380 nm, respectively. A further peak at 600 nm is present for PPS containing [Bcmim]Cl (Supplementary Fig. 29), suggesting that [Bcmim]Cl may induce the formation of a new aggregate form. In fact, a model reaction between [Bcmim]Cl and PbI2 in DMF, intended to mimic reactivity and interactions in the grain boundaries, yields a 1D intermediate with the 

Nature | Vol 628 | 11 April 2024 | **303** 

## Article 

empirical formula [Bcmim]4Pb3Cl2I6·2DMF (Supplementary Fig. 28). It is plausible that, once formed, these 1D salts act as nucleation sites, promoting perovskite crystallization. Compared with [Bcmim]Cl, the non-nucleophilic TFSI<sup>−</sup> anion in [Bcmim]TFSI (ref. 13) is less likely to participate in counterion exchange processes that lead to the formation of these 1D salts (Supplementary Fig. 28e). 

Furthermore, as solvents evaporate during annealing, MACl and [Bcmim]Cl may react with FAI and PbI2 (as PbI−3) to form a eutectic ionic liquid<sup>29</sup> . As demonstrated by polarized light optical microscopy (Supplementary Fig. 30a–d), crystal growth from eutectic ionic liquid mixtures is substantially decelerated, allowing the formation of large, homogeneous, well-ordered crystals. Incorporating [Bcmim]Cl into the PPS causes more small monodispersed aggregates to form. However, at high concentrations, [Bcmim]Cl still promotes nucleation, as evidenced by the huge number of crystal seeds (Supplementary Fig. 30e), but also inhibits crystal growth, limiting the use of higher [Bcmim]Cl concentrations. [Bcmim]Cl promotes the homogeneous distribution of MACl, increasing crystal nucleation while reducing the growth rate of individual crystals. After thermal treatment, the aggregation of these particles results in the crystallization of a more homogeneous film with larger grain sizes and fewer defects. Adding both MACl and [Bcmim]Cl to the PPS has a synergistic effect on the PTF, enhancing film crystallinity, suppressing unfavourable intermediate phases, reducing defects and improving quantum yield and PL lifetime. 

#### **Long-term operational stability** 

Perovskite instability, caused by heat, oxygen, moisture, potential bias and ultraviolet (UV) light, is a substantial challenge as decomposition decreases photovoltaic activity<sup>30</sup> . Thermal ageing of the control PTF at 60 ± 5 °C for 600 h resulted in a gradual redshift of the UV–Vis absorption edge (Supplementary Fig. 31). XRD patterns of the control PTF show a gradual increase in PbI2 content throughout the ageing process (Supplementary Fig. 32). By contrast, the target PTF exhibits a smaller redshift than the control PTF (Δ _λ_ = 2.41 versus 9.76 nm; Supplementary Fig. 31), indicating improved thermal stability. After 600 h of ageing, XRD patterns of the target PTF show retention of the desirable black phase and suppression of PbI2 formation (Supplementary Fig. 32). This suggests that the combination not only stabilizes the PPS but mitigates PTF degradation and improves intrinsic stability by suppressing thermal decomposition. 

The stability of PSMs containing [Bcmim]Cl and MACl was evaluated using two International Summit on Organic Photovoltaic Stability (ISOS) protocols<sup>30</sup> . Under continuous one-sun illumination at room temperature (ISOS-L-1), the target PSM retained 94.66% of its initial efficiency after 1,000 h and the control PSM maintained only 84.53% (Supplementary Fig. 33a). Furthermore, when heated (65 °C) under one-sun illumination (ISOS-L-2), the target PSM maintained 87.19% of its original efficiency compared with only 75.80% for the control PSM (Supplementary Fig. 33b). The retention of efficiency highlights that the combination of [Bcmim]Cl and MACl effectively improves PSM long-term operational stability. 

#### **Conclusions** 

Highly efficient and stable perovskite-based photovoltaics were obtained with a synergistic dopant-additive combination strategy. [Bcmim]Cl and MACl interact to stabilize the PPS by inhibiting the condensation reaction between MACl and FAI, resulting in solutions with longer lifetimes, as well as high-quality films with large and oriented grain sizes and better phase purity. The resulting PSCs and PSMs show that combining MACl and [Bcmim]Cl improves efficiency and stability while allowing scaled-up production. The underlying molecular basis 

for the improvement caused by combining MACl with [Bcmim]Cl was established along with its impact on PPS stability and the resulting positive effects. We expect these findings to contribute to the large-scale production and commercialization of perovskite-based photovoltaic technologies. 

#### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-024-07228-z. 

1. Oga, H., Saeki, A., Ogomi, Y., Hayase, S. & Seki, S. Improved understanding of the electronic and energetic landscapes of perovskite solar cells: high local charge carrier mobility, reduced recombination, and extremely shallow traps. _J. Am. Chem. Soc._ **136** , 13818–13825 (2014). 

2. Wehrenfennig, C., Eperon, G. E., Johnston, M. B., Snaith, H. J. & Herz, L. M. High charge carrier mobilities and lifetimes in organolead trihalide perovskites. _Adv. Mater._ **26** , 1584–1589 (2014). 

3. Wang, H. Q. et al. Progress in perovskite solar cells towards commercialization—a review. _Materials_ **14** , 6569 (2021). 

4. Shi, P. et al. Oriented nucleation in formamidinium perovskite for photovoltaics. _Nature_ **620** , 323–327 (2023). 

5. Turren-Cruz, S. H., Hagfeldt, A. & Saliba, M. Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

6. Zhang, Y. et al. The synergism of DMSO and diethyl ether for highly reproducible and efficient MA0.5FA0.5PbI3 perovskite solar cells. _Adv. Energy Mater._ **10** , 2001300 (2020). 

7. Yang, W. S. et al. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. _Science_ **348** , 1234–1237 (2015). 

8. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. _Science_ **366** , 749–753 (2019). 

9. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ **3** , 2179–2192 (2019). 

10. Bai, S. et al. Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ **571** , 245–250 (2019). 

11. Lin, Y. H. et al. A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** , 96–102 (2020). 

12. Xia, R. et al. Retarding thermal degradation in hybrid perovskites by ionic liquid additives. _Adv. Funct. Mater._ **29** , 1902021 (2019). 

13. Gao, X. X. et al. Engineering long-term stability into perovskite solar cells via application of a multi-functional TFSI-based ionic liquid. _Cell Rep. Phys. Sci._ **2** , 100475 (2021). 

14. Gao, X. X. et al. Halide exchange in the passivation of perovskite solar cells with 

   - functionalized ionic. _Cell Rep. Phys. Sci._ **3** , 100848 (2022). 

15. Green, M. A. et al. Solar cell efficiency tables (version 62). _Prog. Photovolt. Res. Appl._ **31** , 651–663 (2023). 

16. O’Kane, M. E. et al. Perovskites on ice: an additive-free approach to increase the shelf-life of triple-cation perovskite precursor solutions. _ChemSusChem_ **14** , 2537–2546 (2021). 

17. Franssen, W. M. J., Bruijnaers, B. J., Portengen, V. H. L. & Kentgens, A. P. M. Dimethylammonium incorporation in lead acetate based MAPbI3 perovskite solar cells. _ChemPhysChem_ **19** , 3107–3115 (2018). 

18. Qin, M. C. et al. Fused-ring electron acceptor ITIC-Th: a novel stabilizer for halide perovskite precursor solution. _Adv. Energy Mater._ **8** , 1703399 (2018). 

19. Wang, S. R., Wang, A. L. & Hao, F. Toward stable lead halide perovskite solar cells: a knob on the A/X sites components. _Iscience_ **25** , 103599 (2022). 

20. Wang, X. et al. Perovskite solution aging: what happened and how to inhibit? _Chem_ **6** , 1369–1378 (2020). 

21. Ma, L. et al. Temperature-dependent thermal decomposition pathway of organic–inorganic halide perovskite materials. _Chem. Mater._ **31** , 8515–8522 (2019). 

22. Li, Z. P. et al. Ammonia for post-healing of formamidinium-based Perovskite films. _Nat. Commun._ **13** , 4417 (2022). 

23. Valenzano, V. et al. Methylammonium-formamidinium reactivity in aged organometal halide perovskite inks. _Cell Rep. Phys. Sci._ **2** , 100432 (2021). 

24. Nimens, W. J. et al. Understanding hydrogen bonding interactions in crosslinked methylammonium lead iodide crystals: towards reducing moisture and light degradation pathways. _Angew. Chem. Int. Ed._ **58** , 13912–13921 (2019). 

25. Milic, M. et al. NMR quantification of hydrogen-bond-accepting ability for organic molecules. _J. Org. Chem._ **86** , 6031–6043 (2021). 

26. Wang, J. et al. Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a Lewis base. _Nat. Commun._ **11** , 177 (2020). 

27. Xie, F. X., Su, H., Mao, J., Wong, K. S. & Choy, W. C. H. Evolution of diffusion length and trap state induced by chloride in perovskite solar cell. _J. Phys. Chem. C_ **120** , 21248–21253 (2016). 

28. Yang, J. et al. Understanding the role of cesium on chemical complexity in methylammonium-free metal halide perovskites. _Adv. Energy Mater._ **13** , 2202880 (2022). 

**304** | Nature | Vol 628 | 11 April 2024 

29. Zhang, Y. et al. A strategy to produce high efficiency, high stability perovskite solar cells using functionalized ionic liquid-dopants. _Adv. Mater._ **29** , 1702157 (2017). 

30. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

31. Zhang, C. et al. Effects of A site doping on the crystallization of perovskite films. _J. Mater. Chem. A_ **9** , 1372–1394 (2021). 

32. Dang, H. X. et al. Multi-cation synergy suppresses phase segregation in mixed-halide perovskites. _Joule_ **3** , 1746–1764 (2019). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2024 

Nature | Vol 628 | 11 April 2024 | **305** 

Article 

### **Methods** 

##### **Fabrication of TiO2 compact layer** 

##### **Materials** 

Titanium(IV) chloride (TiCl4, for synthesis), tin(II) chloride (SnCl2, reagent grade, 98%), lithium bis(trifluoromethylsulfonyl)imide (99.95% trace metals basis), tris(2-( _1H_ -pyrazol-1-yl)-4-tertbutylpyridine) cobalt(III) (FK209), polymethyl methacrylate (PMMA), [6,6]-phenyl- _C_ 61-butyric acid methyl ester (PCBM), caesium chloride (99.9%), imidazolium chloride ([Im]Cl), 1,3-dimethylimidazolium chloride ([Dmim]Cl), 1-butyl-3-methylimidazolium chloride ([Bmim]Cl), 1-cyanomethyl-3-methylimidazolium chloride ([Cmmim]Cl), trifluoroacetic acid (99%), molybdenum(VI) oxide (MoO3, 99.97% trace metals basis) and HCl (4 M in 1,4-dioxane) were purchased from Sigma-Aldrich. Water-free PEDOT:complex HTL Solar 3 in toluene was obtained from Ossila (product no. M125). Tris(pentafluorophenyl) borane (97%) was obtained from Shanghai Aladdin Biochemical Technology Co., Ltd. Methylammonium iodide (MAI), MACl, formamidinium iodide (FAI) and phenethylammonium iodide (PEAI) were purchased from GreatCell Solar Ltd. Lead(II) iodide (PbI2, 99.99%, trace metals basis) was purchased from Tokyo Chemical Industry Co., Ltd. (TCI). [Bcmim]Cl was prepared according to a literature method<sup>33</sup> . 1,3-bis(cyanomethyl)imidazolium bis(trifluoromethylsulfonyl)imide ([Bcmim]TFSI), 1,3-bis(cyanomethyl)imidazolium tetrafluoroborate ([Bcmim]BF4), bis(cyanomethyl)imidazolium iodide ([Bcmim]I), bis(cyanomethyl)imidazolium hexafluorophosphate ([Bcmim]PF6) and bis(cyanomethyl)imidazolium thiocyanate ([Bcmim]SCN) were prepared from [Bcmim]Cl by exchanging the counterion according to a literature method<sup>33</sup> . 1-Thiocyanomethyl-3-methylimidazolium chloride ([C1SCNmim]Cl) was prepared according to a literature method<sup>34</sup> . d6-DMSO (99.96%) and d7-DMF (99.50%) were purchased from Apollo. LiCl (99%, anhydrous) was purchased from Acros Organics. Deionized water was purified using a Millipore Milli-Q system. All other solvents (anhydrous, >99.9%) were purchased from commercial suppliers and used as received. 

##### **Reaction of [Bcmim]Cl and PbI2: synthesis of [Bcmim]2Pb3Cl2I6·2DMF** 

[Bcmim]Cl (18.3 mg, 0.1 mmol) and PbI2 (46.1 mg, 0.1 mmol) were mixed in DMF (1.0 ml) and the resulting mixture was heated at 65 °C for 1 h. The solvent was evaporated slowly at room temperature and crystals formed. The crystals were analysed by single-crystal X-ray diffraction (SC-XRD). 

##### **Reaction of [Bcmim]Cl with PbI2 and [MA]I or [FA]I: synthesis of [Bcmim]PbI3·DMF** 

[Bcmim]Cl (18.3 mg, 0.1 mmol), MAI (15.9 mg, 0.1 mmol) and PbI2 (46.1 mg, 0.1 mmol) were mixed in DMF (1 ml) and the mixture was heated at 65 °C for 1 h to form a yellow solution. The solvent was allowed to evaporate at room temperature and crystals formed. The crystals were analysed by SC-XRD. The reaction of [Bcmim]Cl (18.3 mg, 0.1 mmol), FAI (17.9 mg, 0.1 mmol) and PbI2 (46.1 mg, 0.1 mmol) resulted in the same product, as determined by SC-XRD. 

##### **Single-crystal characterization** 

Single, colourless, prism-shaped crystals of [Bcmim]4Pb3Cl2I6·2DMF and [Bcmim]PbI3·DMF were obtained and measured. Suitable crystals with dimensions of 0.42 × 0.07 × 0.04 mm<sup>3</sup> (for [Bcmim]4Pb3Cl2I6·2DMF) and 0.40 × 0.05 × 0.04 mm<sup>3</sup> (for [Bcmim]PbI3·DMF) were selected and mounted on a SuperNova, Dual, Cu at home/near, Atlas diffractometer. The crystal was kept at _T_ = 140.00(10) K during data collection. The structure was solved with the ShelXT-2018/2 (Sheldrick, 2015) solution program using dual methods and by using Olex2 1.3 (Dolomanov et al., 2009) as the graphical interface. The model was refined with ShelXL 2018/3 (Sheldrick, 2015) using full-matrix least-squares minimization on _F_<sup>2</sup> . 

The patterned FTO substrate (Asahi FTO glass, 12–13 Ω per square) was sequentially cleaned using acetone, isopropanol and deionized water for 15 min by means of ultrasonic cleaning. A 2 M aqueous TiCl4 stock solution was first prepared by mixing TiCl4 with deionized water at 0 °C and then stored in a refrigerator at 5 °C. The cleaned FTO substrate was soaked in a dilute TiCl4 solution (1:20 molar ratio of 2 M aqueous TiCl4 stock solution and deionized water) and placed in a sealed glass container. Then the glass container was put in a drying cabinet at 70 °C for 1 h. After cooling, the FTO substrate was rinsed with ethanol and deionized water three times and annealed at 120 °C for 1 h. 

##### **Fabrication of SnO2-modified TiO2 (SnO2@TiO2) compact layer** 

A 2 M SnCl2 stock solution in ethanol was first prepared by dissolving SnCl2 in ethanol and then stored in the refrigerator at 5 °C. The FTO substrate coated with TiO2 nanoparticles was soaked in a dilute SnCl2 solution (1:50 molar ratio of 2 M aqueous TiCl4 stock solution and cold deionized water) in a glass container. Then the glass container was placed in a drying cabinet at 70 °C for 1 h. After cooling down, the FTO substrate was rinsed with ethanol and deionized water three times. Finally, the substrate was annealed on a hotplate at 180 °C for 1 h. 

##### **Fabrication of PSCs** 

The PMMA:PCBM solution was prepared by mixing 1 mg of PMMA and 3 mg of PCBM in 1 ml of chlorobenzene. The PMMA:PCBM solution was spin-coated onto the SnO2@TiO2 layer at 5,000 rpm for 15 s. Subsequently, the substrate was annealed at 100 °C for 10 min. 

A pristine precursor solution was prepared by mixing CsCl (0.065 M), MAI (0.065 M), FAI (1.17 M) and PbI2 (1.365 M) in a solvent mixture of DMF and DMSO (4:1 v/v). The [Bcmim]Cl-only precursor solution was prepared by mixing CsCl (0.065 M), MAI (0.065 M), FAI (1.17 M), PbI2 (1.365 M) and [Bcmim]Cl (0.0078 M) in a solvent mixture of DMF and DMSO (4:1 v/v). The control precursor solution was prepared by mixing CsCl (0.065 M), MAI (0.065 M), FAI (1.17 M), PbI2 (1.365 M) and MACl (0.26 M) in a solvent mixture of DMF and DMSO (4:1 v/v). The target precursor solution was prepared by mixing CsCl (0.065 M), MAI (0.065 M), FAI (1.17 M), PbI2 (1.365 M), MACl (0.26 M) and [Bcmim]Cl (0.0078 M) in a solvent mixture of DMF and DMSO (4:1 v/v). The solution was then stirred for 3 h at 60 °C. The PPS was spin-coated onto the substrate surface at 1,000 rpm for 10 s, then accelerated to 4,000 rpm for 3 s and maintained at this speed for 20 s. The substrate was placed in a home-built rapid vacuum-drying apparatus, as previously reported<sup>35</sup> . After pumping for 20 s, a brown, semi-transparent perovskite film with a mirror-like surface was obtained. The fresh perovskite layer was annealed at 100 °C for 1 h and then at 150 °C for 10 min. Afterwards, 60 μl of PEAI isopropanol solution (5 mg ml<sup>−1</sup> ) was deposited on the perovskite film by spin-coating at 5,000 rpm for 30 s. 

A hole-transport layer was deposited on the perovskite film by spin-coating doped Spiro-OMeTAD solution at 3,000 rpm for 30 s. The doped Spiro-OMeTAD solution was prepared by dissolving Spiro-OMeTAD (32 mg), PEDOT:complex HTL Solar 3 (0.5 ml) and tris(pentafluorophenyl)borane (8 mg) in chlorobenzene (1 ml). A 5-nm-thick layer of MoO3 was thermally evaporated onto the Spiro-OMeTAD layer. Subsequently, a 100-nm-thick film of indium tin oxide (ITO) was sputtered onto the MoO3 layer. Finally, a back electrode consisting of an approximately 50-nm-thick layer of gold was evaporated. 

##### **Fabrication of PSMs based on spin-coating method** 

PSMs with eight subcells connected in series were fabricated on FTO glass with a size of 6.5 × 7.0 cm<sup>2</sup> . The series interconnection of the module was realized by P1, P2 and P3 lines, which were patterned using a laser scribing system with a wavelength of 1,064 nm and a 

power of 20 W (Trotec). The FTO substrate was pre-patterned for P1 (40 μm wide) at 60% laser power and a speed of 300 mm s<sup>−1</sup> with a frequency of 65 kHz and pulse width of 120 ns. The subsequent processes for the preparation of SnO2@TiO2 substrates, PMMA:PCBM layer, perovskite layer, PEAI layer and doped Spiro-OMeTAD layer are the same as the small-area-device procedures. The P2 lines (100 μm wide) were patterned with an average laser power of 15% at a speed of 1,000 mm s<sup>−1</sup> and frequency of 65 kHz for a pulse duration of 120 ns. After MoO3/ITO/Au layers were sequentially deposited, the P3 lines (40 μm wide) were patterned with an average laser power of 18% at a speed of 1,000 mm s<sup>−1</sup> and frequency of 65 kHz for a pulse duration of 120 ns. The distance between the P1 and P3 lines is about 280 μm and the geometric fill factor is around 95.74%. 

##### **Fabrication of PSMs using blade-coating** 

Laser etching and cleaning of FTO glass, as well as the preparation of the compact SnO2@TiO2 electron-transport layer by chemical-bath deposition, were conducted as previously described. Subsequently, the PMMA:PCBM solution was blade-coated onto the SnO2@TiO2/FTO substrate and the substrate was annealed at 100 °C for 10 min. Next, a MACl-based precursor solution was prepared by mixing CsCl (0.04 M), MAI (0.04 M), FAI (0.72 M), PbI2 (0.84 M) and MACl (0.16 M) in DMF/ DMSO (4:1 v/v). A MACl/[Bcmim]Cl-based precursor solution was prepared by mixing CsCl (0.04 M), MAI (0.04 M), FAI (0.72 M), PbI2 (0.84 M), MACl (0.16 M) and [Bcmim]Cl (0.0048 M) in DMF/DMSO (4:1 v/v). The perovskite solution was blade-coated onto the PMMA:PCBM/SnO2@ TiO2/FTO substrate. The as-coated perovskite liquid layer was dried using a gas-pump method, then annealed at 100 °C for 1 h and at 150 °C for 10 min. A PEAI solution (7:3 v/v of isopropanol:chlorobenzene) was blade-coated onto the perovskite film. A N2 air knife was used to facilitate drying throughout the coating process. Subsequently, the Spiro-OMeTAD solution was blade-coated onto the perovskite film. The N2 air knife was used to assist drying during the coating process. The P2 lines, MoO3/ITO/ Au layers and P3 lines were conducted as previously described. 

##### **Module encapsulation** 

The modules were encapsulated by glass–glass encapsulation technology combined with an edge seal (UV Curing Sealant, ThreeBond 3035B) of the module under UV light illumination (LED flood lamp, DELOLUX 20). First, the edge of the device was laser-cleaned. An indium solder was laid on the FTO and Au electrodes on the edge of the 65 × 70-mm<sup>2</sup> substrate. Then, a glass piece (60 × 65 mm<sup>2</sup> ) was placed on top of the Au layer of the device. A light-curing sealant was deposited on the edges of the glass to fully cover the gap between the top glass piece and the module. Finally, cross-linking of the sealant was induced by a UV light at 25% of maximum power for 120 s in a glovebox. 

##### **Film characterization** 

**XRD and 2D GIWAXS.** The phase composition of the films was characterized by XRD with a Bruker D8 Advance diffractometer equipped with a Cu Kα radiation source ( _λ_ = 1.5418 Å). GIWAXS patterns represented in reciprocal lattice space were conducted at beamline BL46XU of SPring-8. The samples were irradiated with X-ray energy of 12.39 keV ( _λ_ = 1 Å) at a fixed incident angle on the order of 2.0° using a Huber diffractometer. The GIWAXS patterns were recorded with a 2D image detector (Pilatus 300 K). 

**Observation of the crystallization process.** To record the crystallization process of the perovskite films, the PPS was first spin-coated onto the FTO substrate. Wet perovskite precursor films were then mounted on an in situ heating holder at 100 °C and observed with a microscope (DM2500P, Leica) equipped with a hot stage (LTSE420, Linkam) and a camera (MicroPublisher 5.0 RTV, QImaging). PPSs with 0, 0.2, 0.6, 1.0 and 1.4 mol% of [Bcmim]Cl (with respect to 1.0 M PbI2) were studied. 

**DLS.** The characterization of DLS was conducted using a Zetasizer Nano ZS particle size analyser from Malvern Instruments Ltd. The concentration of the PPS used for the DLS measurement was equivalent to that used in the device fabrication. 

**Morphological characterization.** Top-view and cross-sectional morphologies of the perovskite films and devices were characterized using a scanning electron microscope (FEI Sirion 200) with a voltage of 5 kV and a current of 0.1 nA. 

**UV–Vis absorption and X-ray photoelectron spectroscopy.** Absorption spectra of the perovskite films were collected using a UV–Vis absorption spectrophotometer (PerkinElmer Lambda 950S). X-ray photoelectron spectroscopy measurements were conducted using a VersaProbe II (Physical Electronics Inc.) equipped with a monochromator and Al Kα source (1,486.6 eV). The spectrum was referenced using the C–C-bound component of adventitious carbon. 

**PL and PLQY characterization.** Steady-state PL mapping was carried out with a laser confocal Raman spectrometer (Princeton Instruments, Acton Standard Series SP-2558), a digital charge-coupled device (PIXIS: 100B_eXcelon) and a 488-nm laser (PicoQuant LDH-P-C-485, 0.4 mW with a 1% optical density filter), using a home-built confocal microscope on an area of 1 × 1 mm<sup>2</sup> . TRPL spectra of films were obtained using a time-correlated single-photon counting system (Nanofinder 30) with an excitation wavelength of 480 nm. PLQY spectra were acquired following a three-step procedure<sup>36</sup> , using an FLS1000 Photoluminescence Spectrometer, coupled with an integrating sphere (N-M01, Edinburgh Instruments). Samples were excited at a wavelength of 635 ± 10 nm and emission was recorded between 700 and 870 nm. 

**Device characterization.** All devices were measured using an Oriel solar simulator (450 W xenon, AAA class) equipped with a Keithley 2400 source meter at a light intensity of 100 mA cm<sup>−2</sup> , calibrated using a Si reference solar cell (KG3, Newport). A black metal mask (0.06 cm<sup>2</sup> ) was applied to define the testing area of PSCs. PSCs were measured in forward and reverse scan modes with a bias voltage from 0 to 1.2 V at a scanning step of 10 mV and a delay time of 500 ms. PSMs were measured in forward and reverse scan modes with a bias voltage from 0 to 9.5 V at a scanning step of 50 mV and a delay time of 200 ms with a metal mask (27.22 cm<sup>2</sup> ). External quantum efficiency spectra were measured using an IQE-200B (Oriel) system without bias light. 

**Operational stability test of modules.** _I_ – _V_ curves were measured using an electronic system equipped with a 22-bit delta-sigma analogue-to-digital converter. A reference Si photodiode was placed next to the modules to record the light intensity. The encapsulated modules were maintained at the MPP using an MPP tracking algorithm under simulated solar light (AM 1.5 G, 100 mW cm<sup>−2</sup> ) according to the ISOS-L-1 protocol<sup>30</sup> . The encapsulated modules were placed on a hotplate set to 65 °C to measure their stability using the ISOS-L-2 protocol<sup>30</sup> . 

**Thermal stability tests.** The perovskite films were annealed at 60 ± 5 °C on a hotplate in a N2 glovebox to explore their thermal stability. Changes were tracked using XRD. 

**HIM-SIMS characterization.** The surface morphologies of perovskite films were initially characterized through images obtained in secondary electrons mode. The images were collected by scanning the surface using a helium beam (20 keV, 1 pA) from a helium ion microscope (Zeiss). This procedure aligns with method described in the literature<sup>37</sup> and produces images similar to those from SEM. The helium ion microscope was coupled with a secondary ion mass spectrometer and SIMS images were acquired using a high-energy neon (Ne<sup>+</sup> ) primary ion beam (20 keV, 3 pA). The Ne<sup>+</sup> beam was sourced from the same column as the 

## Article 

helium ion beam but is more efficient at sputtering. Consequently, the Ne<sup>+</sup> beam results in a stronger signal, making it more suitable for SIMS analysis<sup>37</sup> . Sweeping the Ne<sup>+</sup> beam across the surface induces the emission of secondary ions, which were collected, mass-filtered and counted using the SIMS instrument. HIM-SIMS, with a sub-15-nm lateral resolution and high chemical sensitivity, facilitates the identification and differentiation of submicron grain compositions<sup>37</sup> . SIMS images of the perovskite films were collected in a 512 × 512-pixel matrix with a 10 × 10-μm<sup>2</sup> (19.5 nm per pixel) field of view. To assess the phase distribution in the initial perovskite films, we performed compositional analysis on films fabricated by drying with a gas pump for 120 s to minimize residual solvent present before storage at room temperature. For the phase distribution in the final perovskite films, the films were annealed in two steps, first at 100 °C for 60 min and second at 150 °C for 10 min. 

Depth-dependent chemical composition variations were studied using ToF-SIMS (Münster) with bismuth (Bi<sup>+</sup> ) as the analytical primary ion source (25 keV, 0.37 pA). A low-energy Cs<sup>+</sup> ion beam (2 keV, 20 nA) was used to sputter the sample between two successive raster scans with the Bi<sup>+</sup> beam. The depth profile was collected by alternating sputtering and acquisition analysis steps on representative areas of 500 × 500 μm<sup>2</sup> and 200 × 200 μm<sup>2</sup> , respectively. The analysis time was used as a proxy for depth in the profile and was analytically transformed into a depth estimate. The intensity of secondary ions summed over the analysed area was represented as a data point in the profile and plotted against analysis time/depth. Ions were monitored either as ion M<sup>+</sup> (for example, Pb<sup>+</sup> , [Bcmim]<sup>+</sup> ) or their MCs<sup>+</sup> caesium cluster (for example, CsI<sup>+</sup> , CsCl<sup>+</sup> ). 

**TRMC measurements.** Time-resolved microwave conductivity (TRMC) measurements were used to determine the mobility of photogenerated charge carriers. Perovskite films fabricated on sapphire substrates were placed in a microwave resonator with a resonance frequency of 9 GHz. The charge carriers, generated with the second harmonic of a Nd:YAG laser (532 nm), led to an increase of the conductance _G_ of the perovskite film. The normalized change of reflected microwave power Δ _PP_ from the resonator, as measured, related to the change in conductance Δ _G_ between a dark and illuminated sample and a sensitivity factor _K_ , obtained by further resonance measurements, according to equation (1). Finally, to extract the sum of the electron and hole mobility Σ _μ_ according to equation (2), the maximum change of the conductance Δ _G_ Max, the absorption _F_ A of the perovskite film, the illumination intensity _I_ and the ratio of the resonator dimensions _β_ are needed. _ϕ_ describes a free carrier generation yield, which is close to unity for low-excitation fluences and _e_ is the elementary charge. All measurements were carried out in air at room temperature. 



<!-- Start of picture text -->
Δ P<br>= K ⋅Δ G (1)<br>P<br><!-- End of picture text -->



<!-- Start of picture text -->
G Max<br>ϕ Σ μ = Δ (2)<br>eβIF A<br><!-- End of picture text -->

A detailed description of the setup and measurement method can be found in ref. 38. 

**NMR spectroscopy.** NMR spectra were acquired on a Bruker 400 MHz spectrometer (9.4 T) equipped with a console AVIII HD and a 5-mm liquid-state BBO Z-gradient field three-channel (<sup>1</sup> H/<sup>2</sup> H/BBF) probe head. Experiments were performed at room temperature while locking to the deuterium signal of the d6-DMSO.<sup>1</sup> H and<sup>13</sup> C chemical shifts were referenced to Si(CH3)4 (δ(<sup>1</sup> H,<sup>13</sup> C) = 0 ppm) using the signals of the residual protons and of the<sup>13</sup> C of the deuterated solvent (δ<sup>1</sup> H = 2.50 ppm, δ<sup>13</sup> C = 39.52 ppm (d6-DMSO)) as secondary reference. 11B and 31P chemical shifts were indirectly referenced with the 1H signals of the residual protons of the deuterated solvent using the Ξ‐scale (Ξ = 32.083974 MHz and 40.480747 MHz, respectively) with 15% BF3OEt2 

in CDCl3 (δ(<sup>11</sup> B) = 0 ppm) or 85% H3PO4 (δ(<sup>31</sup> P) = 0 ppm) as secondary references. 1D<sup>1</sup> H,<sup>13</sup> C,<sup>11</sup> B and<sup>31</sup> P spectra were acquired using the standard pulse sequences from the Bruker library. 2D COSY, HSQC and HMBC NMR spectra were acquired using the standard pulse sequences from the Bruker library. NMR spectra were processed with MestreNova 14.2.1 (Mestrelab Research S.L.) and TopSpin 4.2.0 (Bruker). 

**NMR spectroscopic assessment of [Bcmim]Cl and MACl interactions.** The interaction between [Bcmim]Cl and MACl in solution was assessed by<sup>1</sup> H NMR spectroscopy. To a stock solution of MACl (0.3 M in d6-DMSO) in a 5-mm NMR tube, different volumes of [Bcmim]Cl (0.3 M in d6-DMSO) were added to obtain [Bcmim]Cl:MACl molar ratios from 0 to 100%. The final volume was adjusted to 0.6 ml with d<sup>6</sup> -DMSO. Control experiments were performed using the same methodology for [Dmim]Cl, [Bmim]Cl and [Cmmim]Cl. The effect of the anion in MAX was also studied by replacing MACl by MAI. The concentration dependence of [Bcmim]Cl peak shifts was studied by adding 5, 10, 15, 20 or 25 μl of a 0.15 M [Bcmim]Cl stock solution (0.0138 g, 0.0756 mmol in 0.5 ml d6-DMSO) to a 5-mm NMR tube. The final volume inside the tube was adjusted to 0.5 ml with d6-DMSO, resulting in 0.0015, 0.0030, 0.0045, 0.0060 and 0.0075 M of [Bcmim]Cl (equivalent to the concentrations in the 1, 2, 3, 4 and 5 mol% samples in the [Bcmim]Cl and MACl for interaction study). 

**Hydrogen-bond-accepting ability.** The hydrogen-bond-accepting ability of the selected ionic liquids ([Bcmim]Cl and [Bcmim]TFSI) was compared by studying the changes in the<sup>31</sup> P NMR chemical shift using phenylphosphinic acid (PPA) as a hydrogen-bond-accepting probe following a previously reported method<sup>25</sup> . The ionic liquid (3.0 eq., 0.0275 mmol) was dissolved in 0.4 ml of dry DMSO and transferred to an oven-dried 5-mm NMR tube and sonicated to ensure complete dissolution. Then, 0.15 ml (1.0 eq., 0.0092 mmol) of a stock solution of PPA (0.0611 M in d6-DMSO) was added to the tube. The<sup>31</sup> P NMR spectrum of each sample was recorded at room temperature with 16 scans and compared with a 0.0166 M external standard of PPA (0.15 ml PPA stock solution in d6-DMSO + 0.4 ml of DMSO) to determine the difference in the chemical shift. 

**In operando time-dependent and variable-temperature NMR spectroscopy experiments.** Time-dependent and variable-temperature NMR spectra were acquired on a Bruker 400 MHz spectrometer (9.4 T) equipped with a console AVIII HD and a BBO Z-gradient field three-channel (<sup>1</sup> H/<sup>2</sup> H/BB) liquid-state probe head for 10-mm NMR tubes. Custom-made (built in-house according to a literature protocol)<sup>39,40</sup> high-pressure 10-mm sapphire NMR tubes (with a length of 130 mm and an internal diameter of 8 mm) were used. Experiments were performed at variable temperatures in non-spinning mode while locking to the deuterium signal of d6-DMSO.<sup>1</sup> H and<sup>13</sup> C NMR chemical shifts were referenced to Si(CH3)4 (δ(<sup>1</sup> H,<sup>13</sup> C) = 0 ppm) using the signals of the residual protons and of the<sup>13</sup> C of the deuterated solvent (δ<sup>1</sup> H = 2.50 ppm, δ<sup>13</sup> C = 39.51 ppm (d6-DMSO)) as secondary reference.<sup>11</sup> B and<sup>207</sup> Pb chemical shifts were indirectly referenced with the 1H signals of the residual protons of the deuterated solvent using the Ξ‐scale (Ξ = 32.083974 MHz and 20.920599 MHz, respectively) with 15% BF3·OEt2 in CDCl3 (δ(<sup>11</sup> B) = 0 ppm) or Me4Pb + 5% C6D6 (δ(<sup>207</sup> Pb) = 0 ppm) as secondary references.<sup>1</sup> H,<sup>13</sup> C,<sup>11</sup> B and<sup>207</sup> Pb spectra were acquired using the standard pulse sequences from the Bruker library. 2D COSY, HSQC and HMBC spectra were acquired using the standard pulse sequences from the Bruker library, accumulating 16 scans and 128 points in the indirect dimension for the COSY spectra and 16 scans and 512 points in the indirect dimension for the HSQC and HMBC spectra. 

Lead-perovskite film precursor solutions were prepared by mixing CsCl (0.065 M), MAI (0.065 M), FAI (1.17 M), PbI2 (1.365 M) and MACl (0.26 M) in 2 ml of d7-DMF and d6-DMSO (4:1 v/v) in the presence and absence (control) of [Bcmim]Cl (0.6 mol%, 0.78 mM). The mixtures 

were sonicated to ensure complete dissolution and transferred to the 10-mm sapphire NMR tubes. The stability of the solutions was analysed using in operando NMR spectroscopy. Variable-temperature experiments were performed between 25 and 100 °C with 5 °C increments. The samples were allowed to equilibrate to the corresponding temperature for 600 s before acquiring the spectra. 1D spectra were acquired with one scan for<sup>1</sup> H NMR spectra, 16 scans for<sup>13</sup> C NMR spectra and 32 scans for<sup>207</sup> Pb NMR spectra. The 90° pulse and the recovery delay for<sup>1</sup> H,<sup>13</sup> C and<sup>207</sup> Pb NMR spectra were 25 μs and 600 s, 15 μs and 3.0 s and 15 μs and 2.0 s, respectively.<sup>207</sup> Pb NMR spectra were recorded between −3,500 and +2,000 ppm with 1,000-ppm-width subwindows, retuning the probe at each step. Time-dependent experiments were obtained using a pseudo-2D sequence consisting of<sup>1</sup> H NMR spectra recorded every 15 min for 24 h. Time-dependent experiments were performed at 25 and 60 °C. The samples were allowed to equilibrate to the corresponding temperature for 600 s before acquiring the spectra. 96 points in the indirect dimension were recorded, each consisting of a one-pulse sequence with 90° flip angle of 25 μs. EXSY spectra (a phase-sensitive 2D homonuclear correlation through dipolar coupling experiment that can detect chemical exchange) were acquired using a modified standard pulse sequence from the Bruker library. 1,024 points in the indirect dimension with an increment of 208.27 μs were recorded, each consisting of 16 scans and 2,048 data points (AQ = 0.21 s) using purge pulses before D1. A mixing time of 0.3 s was set as a simple delay and a recycle delay (D1) of 2.0 s was used. 

**pH measurements.** The studied ionic liquids ([Dmim]Cl, [Bmim]Cl, [Cmmim]Cl, [Bcmim]TFSI and [Bcmim]Cl) (0.0075 mmol, equivalent to 5 mol% of 0.15 M) were dissolved in 10.0 ml deionized H2O and sonicated to ensure complete dissolution. The pH was then measured at room temperature on a Metrohm 780 pH meter and corrected to 25 °C. 

**Computational details.** All simulations were performed using DFT, the Perdew–Burke–Ernzerhof density functional with Grimme’s D3 dispersion<sup>41</sup> correction. The wavefunction was expanded in the localized DZVP-MOLOPT basis set<sup>42</sup> , an auxiliary plane-wave basis set with the 600 Ry kinetic energy cutoff was used for the expansion of electron density and the core region was described with norm-conserving Goedecker–Teter–Hutter<sup>43</sup> pseudopotentials. The Brillouin zone was sampled at the Γ-point. The crystal structure of bulk perovskite Cs0.05MA0.05FA0.90PbI3 was fully relaxed, including both atomic positions and cell parameters. The atomic positions of surface structures, including those having adsorbed species, were also fully optimized. To simulate the deposition of an ionic liquid on the perovskite surfaces, Born–Oppenheimer molecular dynamics runs were performed at a constant temperature of 300 K for several picoseconds with a 1-fs time step using a velocity-rescaling algorithm. All simulations were accomplished with the CP2K code<sup>44</sup> . The structures were visualized using VESTA<sup>45</sup> and VMD<sup>46</sup> software. 

#### **Data availability** 

The data that support the findings of this study are available from the corresponding authors on reasonable request. 

33. Fei, Z. F. et al. Development of nitrile-functionalized ionic liquids for C–C coupling reactions: implication of carbene and nanoparticle catalysts. _Organometallics_ **26** , 1588–1598 (2007). 

34. Zhao, D. B., Fei, Z. F., Ang, W. H., Scopelliti, R. & Dyson, P. J. Thiocyanate functionalised ionic liquids: synthesis, characterisation and reactivity. _Eur. J. Inorg. Chem._ **2007** , 279–284 (2007). 

35. Ding, B. et al. Material nucleation/growth competition tuning towards highly reproducible planar perovskite solar cells with efficiency exceeding 20%. _J. Mater. Chem. A_ **5** , 6840–6848 (2017). 

36. Fries, F. & Reineke, S. Statistical treatment of photoluminescence quantum yield measurements. _Sci. Rep._ **9** , 15638 (2019). 

37. Usiobo, O. J. et al. Nanoscale mass-spectrometry imaging of grain boundaries in perovskite semiconductors. _J. Phys. Chem. C_ **124** , 23230–23236 (2020). 

38. Dörflinge, P. et al. Influence of an organic salt-based stabilizing additive on charge carrier dynamics in triple cation perovskite solar cells. _Adv. Sci._ **10** , 2304502 (2023). 

39. Roe, D. C. Sapphire NMR tube for high-resolution studies at elevated pressure. _J. Magn. Reson._ **63** , 388–391 (1985). 

40. Cusanelli, A., Frey, U., Richens, D. T. & Merbach, A. E. The slowest water exchange at a homoleptic mononuclear metal center: variable-temperature and variable-pressure<sup>17</sup> O NMR study on [Ir(H2O)6]3+. _J. Am. Chem. Soc._ **118** , 5265–5271 (1996). 

41. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

42. VandeVondele, J. & Hutter, J. Gaussian basis sets for accurate calculations on molecular systems in gas and condensed phases. _J. Chem. Phys._ **127** , 114105 (2007). 

43. Goedecker, S., Teter, M. & Hutter, J. Separable dual-space Gaussian pseudopotentials. _Phys. Rev. B_ **54** , 1703–1710 (1996). 

44. Kuhne, T. D. et al. CP2K: an electronic structure and molecular dynamics software package - Quickstep: efficient and accurate electronic structure calculations. _J. Chem. Phys._ **152** , 194103 (2020). 

45. Momma, K. & Izumi, F. VESTA 3 for three-dimensional visualization of crystal, volumetric and morphology data. _J. Appl. Crystallogr._ **44** , 1272–1276 (2011). 

46. Humphrey, W., Dalke, A. & Schulten, K. VMD: visual molecular dynamics. _J. Mol. Graph._ **14** , 33–38 (1996). 

**Acknowledgements** This work was supported by the Valais Energy Demonstrators Fund, the National Key R&D Program of China (2017YFE0133800), the 111 Project (no. B16016), the National Natural Science Foundation of China (no. 51961165106), the Science Foundation of China (no. 11974381), the German Science Foundation (DFG) program SPP2196 under DY18/14-2 (no. 424101351) and the Swiss National Science Foundation (grant 20021_200344). X.Z. and J.P. thank the Suzhou Key Laboratory of Functional Nano and Soft Materials, the Collaborative Innovation Center of Suzhou Nano Science & Technology, the 111 Project (B16016) and the Science Fund for Creative Research Groups of the National Natural Science Foundation of China (grant no. 51821002) for financial support. We thank the Swiss National Science Foundation (project number 200020L_1729/1) and National Research Fund Luxembourg (INTER no. 16/11534230) for their financial support of the SOLAR4D project. We also thank Lomonosov Moscow State University, which provided equipment for the shared HPC computing resources, and École Polytechnique Fédérale de Lausanne, which provided further financial support, as well as NMR support from the SB-ISIC-NMR platform. 

**Author contributions** B.D., Y.D., J.P., J.R-d.G., L.E.K.F., Z.F., X.Z., P.J.D. and M.K.N. conceived the idea, analysed and interpreted the data and led the project. B.D., Y.D., J.P., L.E.K.F. and J.R.-d.G. wrote the manuscript, with input from all other authors. B.D., Y.D. and J.P. fabricated the devices and conducted XRD and SEM characterization and device measurements. J.R.-d.G., L.E.K.F. and B.D. conducted NMR spectroscopy experiments. H.K. and So.Z. performed the PL mapping measurements. O.A.S. and M.A.S. conducted DFT calculations. Z.F., Sh.Z. and F.F.T. conducted the synthesis of adducts and single-crystal characterization. J.-N.A. and J.B. conducted HIM-SIMS and ToF-SIMS. P.D. and V.D. performed TRMC measurements. N.S. performed GIWAXS measurements. Y.N. and L.H. performed the observation of the nucleation-growth dynamic process. Y.L. and G.-J.Y. performed DLS. S.H. performed rocking curves. K.B. and S.K. conducted laser scribing and encapsulation. All authors contributed to the discussion of the results and revision of the manuscript. X.Z., P.J.D. and M.K.N. directed and supervised the project. 

**Funding** Open access funding provided by EPFL Lausanne. 

**Competing interests** The authors declare no competing interests. 

###### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-024-07228-z. **Correspondence and requests for materials** should be addressed to Yong Ding, Zhaofu Fei, Xiaohong Zhang, Paul J. Dyson or Mohammad Khaja Nazeeruddin. **Peer review information** _Nature_ thanks Diego Colombara, Shiva Navazani, Monika Rai and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. **Reprints and permissions information** is available at http://www.nature.com/reprints. 

