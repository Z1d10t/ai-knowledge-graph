# 2D/3D heterojunction engineering at the buried interface towards high-performance inverted methylammonium-free perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Energy |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 343 |
| 作者 | Hai-Yun Li, Cong-Li Zhang, Cheng Gong, Da-Liang Zhang, Hong Zhang, Q. Zhuang, Xuemeng Yu, Shaokuan Gong et al. |
| DOI | 10.1038/s41560-023-01295-8 |
| 源文件 | 020_Li_2023_2D3D-heterojunction-engineering-at-the-buried-in.pdf |

---
## **nature energy** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

# **2D/3D heterojunction engineering at the buried interface towards high-performance inverted methylammonium-free perovskite solar cells** 

|Received: 5 October 2022<br>Accepted: 1 June 2023|**Haiyun Li**<sup>**1,9**</sup>**, Cong Zhang**<sup>**1,9**</sup>**, Cheng Gong**<sup>**1,9**</sup>**, Daliang Zhang**<sup>**2,9**</sup>**, Hong Zhang**<br> <sup>**3**</sup><br>**,**<br>**Qixin Zhuang**<sup>**1**</sup>**, Xuemeng Yu**<sup>**4**</sup>**, Shaokuan Gong**<sup>**4**</sup>**, Xihan Chen**<br> <sup>**4**</sup>**, Jiabao Yang**<br> <sup>**5**</sup>**,**<br>**Xuanhua Li**<br> <sup>**5**</sup><br>**, Ru Li**<sup>**1**</sup>**, Jingwei Li**<sup>**2**</sup>**, Jinfei Zhou**<br> <sup>**2**</sup>**, Hua Yang**<sup>**6**</sup>**, Qianqian Lin**<br> <sup>**7**</sup>**,**|
|---|---|
|Published online: 6 July 2023|**Junhao Chu**<sup>**3**</sup>**, Michael Grätzel**<br> <sup>**8**</sup><br>**, Jiangzhao Chen**<br> <sup>**1**</sup><br>**& Zhigang Zang**<br> <sup>**1**</sup>|
|Check for updates||
||The main bottlenecks limiting the photovoltaic performance and stability<br>of inverted perovskite solar cells (PSCs) are trap-assisted non-radiative<br>recombination losses and photochemical degradation at the interface<br>between perovskite and charge-transport layers. We propose a strategy<br>to manipulate the crystallization o f m et hy la mm on iu m-free perovskite<br>by incorporating a small amount of 2-aminoindan hydrochloride into the<br>precursor inks. This additive also modulates carrier recombination and<br>extraction dynamics at the b ur ied i nt er face v i a t h e formation of a bottom-up<br>two-dimensional/three-dimensional heterojunction. The resultant inverted<br>PSC achieves a power conversion efficiency of 25.12% (certified 24.6%) at<br>laboratory scale (0.09 cm<sup>2</sup>) and 22.48% at a larger area (1 cm<sup>2</sup>) with negligible<br>hysteresis. More importantly, the resulting unencapsulated devices show<br>superior operational stability, maintaining >98% of their initial efficiency of<br>>24% after 1,500 hours of continuous maximum power point tracking under<br>simulated AM1.5 illumination. Meanwhile, the encapsulated devices retain<br>>92% of initial performance for 1,200 hours under the damp-heat test<br>(85 °C and 85% relative humidity).|



Inverted (p-i-n) perovskite solar cells (PSCs) have recently drawn intensive attention, owing to their merits of compatibility with different bottom cells for tandem solar cells<sup>1,2</sup> , low-temperature processability<sup>3,4</sup> and excellent stability<sup>5–9</sup> . Researchers have carried out numerous studies to improve the performance and stability of inverted PSCs, such as compositional engineering<sup>10</sup> , additive engineering<sup>11,12</sup> , processing methods<sup>13</sup> and interface engineering<sup>4–8,14–16</sup> . Although the efficiency of inverted PSCs has increased substantially over the years<sup>12</sup> , methylammonium (MA<sup>+</sup> ) and bromide (Br<sup>−</sup> ) are usually employed to modulate the crystal 

growth and stabilize the photoactive black phase of formamidinium lead triiodide (α-FAPbI3)<sup>4,12,17,18</sup> . However, since MA<sup>+</sup> was certified to easily volatilize and escape from the perovskite crystal lattices, large amounts of MA<sup>+</sup> doping (≥10 mol%) would cause material degradation of α-FAPbI3 at high temperatures and thus reduce thermal stability of the corresponding PSCs<sup>19,20</sup> . In addition, mixed halide (I/Br) perovskites inevitably suffer from phase segregation, which is exacerbated under light illumination and thermal ageing<sup>20–25</sup> . In the long run, MA- and Br-free perovskite is highly desirable for the fabrication of long-term 

> A full list of affiliations appears at the end of the paper. e-mail: hzhangioe@fudan.edu.cn; lixh32@nwpu.edu.cn; michael.graetzel@epfl.ch; jiangzhaochen@cqu.edu.cn; zangzg@cqu.edu.cn 

Nature Energy | Volume 8 | September 2023 | 946–955 

**946** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

operationally stable perovskite solar cells<sup>26</sup> . To overcome the above problems, caesium (Cs<sup>+</sup> ) cations have been widely adopted to prepare more stable mixed cation perovskites Cs _x_ FA1− _x_ PbI3 (refs. 27,28). While the doping of a small amount (≤5 mol%) of Cs<sup>+</sup> has been demonstrated to be an effective strategy for stabilizing the α-FAPbI3 (refs. 4,29,30), without the incorporation of MA<sup>+</sup> and Br<sup>−</sup> , it is still challenging to manipulate the crystallization dynamics of Cs _x_ FA1− _x_ PbI3 on a planar substrate, such as the hydrophobic poly(bis(4-phenyl)(2,4,6-trimethylphenyl)amine) (PTAA) films. Therefore, a facile modulation approach for preparing MA<sup>+</sup> - and Br<sup>−</sup> -free perovskite film should be urgently developed to further enhance the performance of inverted PSCs. 

Interfacial non-radiative recombination poses a serious challenge for the further advancement of the photovoltaic performance of inverted PSCs<sup>31</sup> . Recently, great efforts have been made to manipulate the perovskite/electron transport layer (ETL) interface<sup>4,6–8</sup> . For example, Zhu and coworkers employed an organometallic compound (FcTc2) to modify the perovskite/C60 interface and achieved an attractive performance due to effective defect passivation and ameliorated interfacial electron transfer<sup>8</sup> . In contrast to the perovskite/ETL top interface, the buried perovskite/hole transport layer (HTL) interface receives less attention. Considering most interfacial modulation molecules are easy to dissolve in polar solvents, that is, _N,N_ -dimethylformamide (DMF) and dimethyl sulfoxide (DMSO), while spin-coating perovskite precursor solution, it is much more difficult to modulate the HTL/ perovskite buried interface compared with the top interface. The HTL/ perovskite buried interface contains a high density of deep-level trap states, which is much larger than that within the perovskite film<sup>32</sup> . The NiO _x_ /perovskite interface also suffers from poor photostability because of interfacial reactions<sup>33,34</sup> . In addition, the energy barrier at the buried interface leads to imperfect interfacial hole extraction and thus low photovoltaic performance<sup>35,36</sup> . Consequently, it is urgently needed to minimize non-radiative recombination losses at the HTL/perovskite buried interface and enhance interfacial stability in inverted PSCs by facile interface engineering. Interestingly, Wakamiya and coworkers<sup>37</sup> modified the HTL/perovskite buried interface by directly incorporating glycine hydrochloride into the perovskite precursor ink. They revealed that the head group (–NH3+) of GlyH+ can bind to the surface of perovskite crystallites, which prefer to sediment at the bottom interface. Finally, the –NH3+ head was towards the perovskite layer, while the tail group (–COOH) was anchored to HTL, forming an interfacial dipole and thus electric field, which accelerated hole extraction and transfer. This indicates that appropriate ammonium salts would self-assemble at the buried interface when it is introduced into the precursor solution. Since two-dimensional (2D) perovskites have been widely employed to modify grain boundaries (GBs) and the surface of three-dimensional (3D) perovskites<sup>6,7</sup> , constructing a bottom-up 2D/3D perovskite heterojunction is highly desirable through incorporating tailored organic ammonium salts into the precursor ink. 

Herein we manipulated the crystallization of MA-free perovskite film (for example, Cs0.05FA0.95PbI3) and minimized the interfacial non-radiative recombination losses simultaneously by incorporating a small amount of 2-aminoindan hydrochloride (AICl) into the perovskite precursor inks. This strategy enabled high-quality MA-free perovskite films with improved crystallization, fewer trap states and enhanced interfacial hole extraction and transport, which stabilized this important interface and minimized non-radiative recombination losses. The resultant inverted device delivered a PCE of 25.12% (certified 24.6%) at laboratory scale (0.09 cm<sup>2</sup> ) and 22.48% at larger device area (1 cm<sup>2</sup> ) with negligible hysteresis. Moreover, the resulting unencapsulated device demonstrated excellent operational stability by maintaining >98% of its initial efficiency after 1,500 hours of continuous maximum power point (MPP) tracking under simulated AM1.5 illumination. The outstanding damp-heat stability was confirmed for an encapsulated device, which retained >92% of the initial PCE value after 1,200 hours ageing at 85 °C and 85% relative humidity (RH). 

### **Characterization of MA-free perovskite films** 

We adopted a stable MA- and Br-free perovskite composition (Cs0.05FA0.95PbI3) as light absorber to maximize the performance of inverted PSCs. The perovskite film was fabricated through a one-step method. To regulate the crystallization of Cs0.05FA0.95PbI3 films, we added a small amount of AICl into the perovskite precursor inks to form a 2D/3D heterojunction at the bottom interface. The chemical structure of AICl is shown in Supplementary Fig. 1. The perovskite films and the relevant devices made with incorporation of AICl are hereafter denoted as ‘target’. To form 2D perovskite at the bottom interface, we designed a large indan aromatic tail with large π-conjugation, which was attached to an ammonium A-site cation (-NH3+). Owing to the large size of the indan aromatic skeleton, the solubility of AICl molecules in DMF/DMSO mixed solvents is very low (Supplementary Fig. 2). Meanwhile, the interactions between AI<sup>+</sup> and PbI2 are stronger than that of FA<sup>+</sup> , which leads to easier formation of 2D perovskites than 3D perovskites, as evidenced by<sup>1</sup> H NMR spectra (Supplementary Fig. 3). Considering the low solubility and stronger interaction towards PbI2, we infer that an AI-based 2D perovskite ((AI)2(FA) _n_ −1Pb _n_ I3 _n_ −1Cl2) nucleate could form in the precursor inks. To verify this, we conducted dynamic light scattering measurements to investigate the colloidal properties of the precursor inks. As depicted in Supplementary Fig. 4, a large colloid with particle size over 1 µm appeared in the target precursor, which may be the prenucleation cluster caused by AI<sup>+</sup> . Therefore, we can infer that AI<sup>+</sup> can preferentially react with PbI2 to form a 2D perovskite crystallite in the precursor solution. The precrystallized 2D crystallites will sediment at the bottom interface, act as a seed crystal and provide nucleation sites for manipulating the crystallization of 3D perovskite crystals, which contributes to improved film quality (Supplementary Note 1 and Supplementary Fig. 5). Therefore, it is speculated that the 2D/3D perovskite heterojunction should be successfully constructed at the bottom interface by incorporating well-designed AICl into the precursor ink. 

In comparison to the control perovskite film, the target film showed an improved morphology with larger sized grain domain (Supplementary Fig. 6). As a result of the improved morphology, the carrier mobility was increased from 17 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> to 28 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> after modification (Supplementary Fig. 7). It is worth noting that the charge-carrier mobility could be reduced slightly with increase of excitation intensity, and charge-carrier lifetime was also reduced due to the increase in bimolecular recombination losses<sup>38–41</sup> . The photoluminescence and UV–visible absorption spectra show that the band gap and light-harvesting properties of the target perovskite film with the addition of AICl were unchanged (Supplementary Fig. 8). 

Next, we investigated the vertical distribution and form of existence of AICl salts in the perovskite films. Time-of-flight secondary-ion mass spectrometry (TOF-SIMS) measurements show that the 2D spacer species (AI<sup>+</sup> and Cl<sup>−</sup> ) were accumulated at the perovskite/HTL interface in the target sample (Fig. 1a and Supplementary Fig. 9). We performed 2D grazing-incidence wide-angle X-ray scattering (GIWAXS) to further investigate the formation of 2D perovskite at the bottom interface (Fig. 1b). As expected, the 2D perovskite signal can only be detected with high incidence angle, which indicates that 2D perovskite was mainly formed at the bottom of 3D perovskite films. The target films exhibited diffraction _qz_ peaks at ~0.3 to ~0.4 A<sup>−1</sup> , indicating the formation of 2D perovskite crystals. We also investigated the photoluminescence (PL) spectra of the target films by measuring from the front and back direction. As shown in Fig. 1c, the emission peaks at ~640 nm of 2D perovskites can only be detected from the back side, which demonstrates that the 2D perovskites were only formed at the bottom interface in the target films. These emission peaks were redshifted with respect to the dominant emission peak at ~492 nm of _n_ = 1 2D perovskite ((AI)2PbI2Cl2) (Supplementary Fig. 10). From these data we inferred that 2D perovskites ( _n_ ≥ 2) were formed at the 3D perovskite GBs at the buried interface, which was further supported by the theoretical calculations (Supplementary Fig. 11 and Supplementary Note 2). 

Nature Energy | Volume 8 | September 2023 | 946–955 

**947** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 



<!-- Start of picture text -->
a b 2.0 2,000 2.0 2,000<br>105 Perovskite Al2O3/PTAA/NiO x Control (0.2°) Control (1.0°)<br>CN –  (control) 1.5 1,500 1.5 1,500<br>104<br>103 CN – (target) 1.0 1,000 1.0 1,000<br>3D (100)<br>102 Cl – (target) 0.5 500 0.5 500<br>101<br>100 Cl –  (control) 0 –0.5 0 0.5 1.0 1.5 2.0 0 0 –0.5 0 0.5 1.0 1.5 2.0 0<br>qxy  (Å –1 ) qxy  (Å –1 )<br>0 50 100 150 200 250 300<br>c Sputter time (s) 2.0 Target (0.2°) 2,000 2.0 Target (1.0°) 2,000<br>Front 1.5 1,500 1.5 1,500<br>2D  Back Front Back 1.0 1,000 1.0 3D (100) 1,000<br>0.5 500 0.5 2D 500<br>600 700 0 0 0 0<br>–0.5 0 0.5 1.0 1.5 2.0 –0.5 0 0.5 1.0 1.5 2.0<br>500 600 700 800 900 qxy  (Å –1 ) qxy  (Å –1 )<br>Wavelength (nm)<br>e d<br>Ag 6.2 Å<br>3D<br>PCBM/BCP 4 nm<br>Ag<br>Cs0.05FA0.95PbI3<br>Al2O3/PTAA/NiO x 21.8 Å<br>2D<br>200 nm 20 nm<br>ETL<br>Perovskite<br>HTL<br>ITO<br>Intensity (counts)  (Å–1) qz  (Å–1) qz<br> (Å–1) qz<br> (Å–1) qz<br>Perovskite<br>Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Structural characterizations of the bottom-up 2D/3D heterojunction at the buried interface. a** , TOF-SIMS profile of ITO/NiO _x_ /PTAA/Al2O3/perovskite with bottom-up 2D/3D perovskite heterojunction at buried interface (2D spacer species: CN<sup>−</sup> and Cl<sup>−</sup> , ammonium salt: CN<sup>−</sup> ). The 2D perovskites are located in the region between the vertical orange dashed lines. **b** , 2D GIWAXS mappings of the control and target perovskite films with different incidence angles. **c** , PL spectra of the target perovskite film obtained from different incident directions. 

The inset shows the zoomed-in image between wavelengths of 550 and 750 nm. The perovskite films were deposited on ITO/NiO _x_ /PTAA/Al2O3 substrate. **d** , Crosssectional HRTEM image of the target PSC. The inset shows the enlarged TEM image of the region enclosed by a yellow box. The areas enclosed by the dashed white lines show the formed 2D perovskite. The distances measured show the lattice parameters for 3D and 2D perovskites. **e** , Device configuration of the inverted PSCs with bottom-up 2D/3D perovskite heterojunction at the buried interface. 

The cross-section of the target device was characterized by highresolution transmission electron microscopy (HRTEM) and energy dispersive X-ray spectroscopy (EDS; Supplementary Fig. 12). Cryogenic focused ion beam (cryo-FIB) was used to prepare the TEM specimen without damaging the inherent structures of the perovskite layer<sup>42</sup> . As shown in Fig. 1d and Supplementary Fig. 13, a thin layer of 2D perovskites ((AI)2(FA) _n_ −1Pb _n_ I3 _n_ −1Cl2) could be clearly discerned at the GBs of the 3D perovskite layer at the buried interface, which is consistent with the TOF-SIMS, PL and GIWAXS results. Meanwhile, the formation of this unique 2D/3D heterojunction is independent of the types of substrate (Supplementary Fig. 14). In a word, the addition of a small amount of AICl into the perovskite precursor solution resulted in spontaneous formation of a bottom-up 2D/3D perovskite heterojunction at the buried interface, as illustrated in Fig. 1e. 

### **Investigation of interfacial carrier dynamics** 

We next investigated the effect of the bottom-up 2D/3D heterojunction at the buried interface on the charge-carrier transport and recombination in the perovskite layer. The time-resolved photoluminescence 

(TRPL) spectra of the control and target perovskite films deposited on the glass substrates are shown in Fig. 2a. According to previous reports, the rapid decay of the first stage is determined by the initial hole transfer and carrier capture, and the decay of the second stage is only related to non-radiative recombination<sup>43,44</sup> . To simulate the TRPL data, we used the kinetic model described in our previous study<sup>5</sup> . From the simulations, we find that the carrier lifetime of perovskite films was increased from 762 ns ( _k_ 1 = 6.6 × 10<sup>5</sup> s<sup>−1</sup> ) to 1,119 ns ( _k_ 1 = 4.5 × 10<sup>5</sup> s<sup>−1</sup> ) after addition of AICl, indicating reduced defect density in the modified perovskite films. Additionally, the space charge-limited current measurements (Supplementary Fig. 15) further confirmed the decreased defect density through the addition of the AI<sup>+</sup> 2D spacer. The reduced defect density should be responsible for increased carrier lifetimes and carrier mobility, which resulted in inhibited trap-assisted non-radiative recombination. 

We then deposited perovskite films on NiO _x_ /glass substrate and used the quenched _τ_ 1 lifetimes to compare charge extraction (Fig. 2b). The quenched _τ_ 1 lifetime of the control film was 64.5 ns. After constructing the bottom-up 2D/3D heterojunction at the buried interface, the 

Nature Energy | Volume 8 | September 2023 | 946–955 

**948** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 



<!-- Start of picture text -->
a 100 b 100<br>Glass/perovskite Glass/NiO x /PTAA/Al2O3/perovskite<br>10–1<br>10–1<br>Control Control<br>Target Target<br>10–2<br>0 400 800 1,200 1,600 2,000 0 100 200 300 400<br>Time (ns) Time (ns)<br>c d<br>1.2 Control 2.50 eV 1.2 Target 2.50 eV<br>2.10 eV 2.10 eV<br>1.0 1.65 eV 1.0 1.65 eV<br>0.8 0.8<br>0.6 0.6<br>0.4 0.4<br>0.2 0.2<br>0 0<br>–0.2 Fit –0.2 Fit<br>0 1,000 2,000 3,000 4,000 5,000 0 1,000 2,000 3,000 4,000 5,000<br>Time delay (ps) Time delay (ps)<br>Intensity (a.u.) Intensity (a.u.)<br>Norm ∆ R Norm ∆ R<br><!-- End of picture text -->

**Fig. 2 | Charge-carrier dynamics. a** , **b** , TRPL spectra of the control and target perovskite films deposited on a bare glass substrate ( **a** ) and glass/NiO _x_ / PTAA/Al2O3 substrate ( **b** ). TRPL measurements were conducted with excitation from the glass side and with an emission wavelength of 810 nm. The solid line shows the fitting curves. To simulate the TRPL data, we used a model based on the continuity equation for the carrier concentration _n_ ( _z_ , _t_ ): ∂ _n_ ∂<sup>2</sup> _n_ ∂ _t_<sup>=</sup><sup>_D_</sup> ∂ _z_<sup>2−</sup><sup>_k_1</sup><sup>_n_−</sup><sup>_k_2</sup><sup>_n_2 −</sup><sup>_k_3</sup><sup>_n_3, where</sup><sup>_D_is the carrier diffusion coefficient,</sup> 

_k_ 1 the non-radiative monomolecular bulk recombination constant, _k_ 2 the radiative bimolecular recombination constant and _k_ 3 the Auger coefficient. **c** , **d** , TRS measurements for the control ( **c** ) and target ( **d** ) perovskite films on NiO _x_ /glass substrate. TRS measurements were performed with excitation from the glass side. The solid line shows the fitting curves. The details of the fits are provided in Methods. Norm Δ _R_ , normalized change in reflection. 

quenched _τ_ 1 lifetime of the target film was reduced to 29.4 ns, implying considerably improved charge extraction. Fits to the TRPL transients were used to compute the differential lifetime using the model of Krogmeier et al.<sup>45</sup> (Supplementary Fig. 16). The charge-transfer process at early times (~100 ns) led to a faster rise of differential lifetime in the target film than the control film. The occurrence of non-radiative first-order recombination is marked by a transition from an increasing carrier lifetime to a flat period, implying a fundamental end of charge transfer. To quantify how the TRPL lifetime is related to surface carrier extraction, we further investigated these films using transient reflection spectroscopy (TRS), from which carrier diffusivity ( _D_ ) and surface extraction velocity (SEV) could be extracted<sup>46–48</sup> . Figure 2c,d illustrates the surface carrier kinetics measured with transient reflection excited with three different pump pulses (2.50 eV, 2.10 eV and 1.65 eV). By simultaneously fitting the decay of charge carriers with a kinetics model (details of fits are shown in the Methods) that includes both diffusion and surface recombination, best-fit values of _D_ and SEV were obtained (Supplementary Table 1). In our modelling, _D_ represents the charge diffusivity and, as in thin films, both electrons and holes will diffuse together in a pair and we model them as an ambipolar diffusion constant. On the other hand, SEV only represents hole extraction velocity. For the control perovskite film, the extracted _D_ and SEV values were 1.88 ± 0.10 cm<sup>2</sup> s<sup>−1</sup> and 3,600 ± 500 m s<sup>−1</sup> , respectively. The target sample exhibited improved _D_ (1.94 ± 0.11 cm<sup>2</sup> s<sup>−1</sup> ) 

and SEV (4,100 ± 400 m s<sup>−1</sup> ) values, indicating that the hole extraction was facilitated by inserting our bottom-up 2D/3D heterojunction at the perovskite/HTL interface, which is consistent with the computed differential lifetimes. Certainly, improved morphology is also one of the important reasons for boosted carrier diffusivity, which contributed to enhanced carrier mobility. The energy level diagram in Supplementary Fig. 17 manifests that the cascade energy band alignment was formed because the valance band maximum (VBM) of 2D perovskite was located between the VBM of HTL and the VBM of 3D perovskite, which should be primarily responsible for improved hole extraction and collection, as confirmed by TRPL, TRS and transient photocurrent results. In short, the formed bottom-up 2D/3D heterojunction can promote hole extraction and suppress interfacial non-radiative recombination, which could account for the increased photovoltaic performance. 

### **Photovoltaic performance and long-term stability** 

Next, we fabricated inverted PSCs with a structure of ITO/NiO _x_ /PTAA/ Al2O3/Cs0.05FA0.95PbI3/PCBM/BCP/Ag. The optimal concentration of AICl was determined by comparing the device photovoltaic performance (Supplementary Fig. 18). The relevant devices made from the addition of 1.5 mg ml<sup>−1</sup> AICl are hereafter denoted as ‘target’. The average PCE value was increased from 21.94 ± 0.70% for the control device to 

Nature Energy | Volume 8 | September 2023 | 946–955 

**949** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 



<!-- Start of picture text -->
a b<br>16 Control<br>Target 25<br>14 Forward scan<br>Reverse scan<br>12 20<br>10 J sc V oc FF PCE<br>15 (mA cm –2 ) (V) (%) (%)<br>8<br>RS 26.22 1.165 82.2 25.12<br>6 10<br>FS 26.26 1.167 81.7 25.03<br>4<br>5<br>2<br>0 0<br>20 21 22 23 24 25 26 0 0.2 0.4 0.6 0.8 1.0 1.2<br>PCE (%) Voltage (V)<br>c d<br>Ref.  12 25 1 cm 2<br>25 Ref.  8<br>Reverse scan<br>This work<br>20 Forward scan<br>Ref.  7<br>Ref.  4 15 J sc V oc FF  PCE<br>24 (mA cm –2 ) (V) (%) (%)<br>Ref.  16<br>RS 25.21 1.145 77.6 22.42<br>Ref.  15 10<br>Ref.  14 Ref.  55 FS 25.02 1.145 78.1 22.48<br>Ref.  6<br>23 Ref.  11 Ref.  4 5<br>0<br>Perovskite Perovskite 0 0.2 0.4 0.6 0.8 1.0 1.2<br>with MA without MA Voltage (V)<br>e<br>25<br>20<br>15<br>MPP, under one-sun illumination at 55 ± 5 °C<br>10 Control<br>Target-1<br>5 Target-2<br>0<br>0 300 600 900 1,200 1,500<br>Time (h)<br>f 25<br>20<br>15 Damp-heat (85 °C/85% RH)<br>Control<br>Target<br>10<br>0 300 600 900 1,200<br>Time (h)<br>Counts<br>–2)Current density (mA cm<br>PCE (%)<br>–2)Current density  (mA cm<br>SPO (%)<br>PCE (%)<br><!-- End of picture text -->

**Fig. 3 | Device performance and stability. a** , PCE histogram of 20 PSCs with (target) and without (control) bottom-up 2D/3D heterojunction at buried interface. The solid line is a Gauss peak fit of the distribution. **b** , _J–V_ curves obtained in forward and reverse scans of the champion target PSCs. The insets show the relevant photovoltaic parameters. **c** , Comparison of the photovoltaic performance of the inverted PSC in this work with literature that reported PCEs over 23% (refs. 4,6–8,11,12,14–16,55). More details are shown in Supplementary Table 4. **d** , _J–V_ curve of the best-performing target device with an area of 1 cm<sup>2</sup> . 

The insets show the relevant photovoltaic parameters. **e** , PCE of the unencapsulated control and target devices measured at maximum power point under continuous one-sun illumination at 55 ± 5 °C in N2 atmosphere. The initial PCE of control, target-1 and target-2 devices is 21.73%, 24.42% and 24.11%, respectively. **f** , Damp-heat stability of the encapsulated control and target devices following the ISOS standards (85 °C and 85% RH). The initial PCE of control and target devices is 22.15 ± 0.13% and 24.32 ± 0.20%. The error bar is the standard deviation of three devices. Data are presented as mean values ± s.e.m. 

Nature Energy | Volume 8 | September 2023 | 946–955 

**950** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

24.58 ± 0.35% for the target device with AICl additive (Fig. 3a), mainly due to the increases in open-circuit voltage ( _V_ oc) from 1.122 ± 0.011 to 1.156 ± 0.010 V, short-circuit current density ( _J_ sc) from 25.36 ± 0.40 to 26.23 ± 0.20 mA cm<sup>−2</sup> and fill factor (FF) from 77.73 ± 1.88% to 81.06 ± 0.89% (Supplementary Fig. 19 and Supplementary Table 2). We attained a PCE of 25.12% for the best-performing target device ( _J_ sc of 26.22 mA cm<sup>−2</sup> , _V_ oc of 1.165 V and FF of 82.2%), along with negligible hysteresis and a stabilized PCE of 25.05% (Fig. 3b and Supplementary Fig. 20). One of the best-performing devices was validated by an independent solar cell accredited laboratory (National Photovoltaic Product Quality Inspection and Testing Center, China) for certification, where a PCE of 24.60% (with _J_ sc = 25.69 mA cm<sup>−2</sup> , _V_ oc = 1.173 V and FF = 81.63%) was confirmed (Supplementary Fig. 21), which is higher than the values reported for all inverted PSCs based on MA-free perovskite reported to date (Fig. 3c and Supplementary Table 3). Corresponding external quantum efficiency spectra (Supplementary Fig. 22) yielded an integrated _J_ sc of 24.88 mA cm<sup>−2</sup> for the target device and 23.92 mA cm<sup>−2</sup> for the control device, which was just slightly lower than the values obtained from _J–V_ measurements. The addition of AICl thus showed a marked improvement in PCE, which is associated with an enhanced _V_ oc and FF, as well as _J_ sc. The Mott–Schottky plots demonstrated a higher flat-band potential for the target device compared with the control device (Supplementary Fig. 23), which is directly related to an increase in _V_ oc. Moreover, we found that the target device has a smaller ideality factor ( _n_ id) than the control device (Supplementary Fig. 24), indicating the improved interfacial charge transfer/transport and suppressed non-radiative recombination channels, which accounts for the enhanced _V_ oc and FF. The increase in _J_ sc is ascribed to improved interfacial energy band alignment and thus charge extraction due to the formation of stepped band alignment induced by the bottom-up 2D/3D heterojunction at the perovskite/HTL interface<sup>49</sup> . The addition of AICl also contributed to the improved uniformity of the large-area perovskite films with less density of defects. As a result, in comparison to the control devices, the large-area target device with aperture area of 1.0 cm<sup>2</sup> showed better performance (Fig. 3d and Supplementary Fig. 25). A champion PCE of 22.48% was obtained for the large-area target device, which is also the highest value among all large-area inverted PSCs reported so far (Supplementary Table 4). Furthermore, AICl additive is universal for various perovskite compositions, as demonstrated by the systematic absolute PCE enhancement of 1.2 to 2.6% for device performance (Supplementary Figs. 26 and 27 and Supplementary Table 2). 

As a comparison, we also predeposited different amounts of AICl salts on the indium tin oxide (ITO)/HTL substrates before 3D perovskite formation (Supplementary Fig. 28), which is expected to form bottom-up 2D/3D heterojunctions according to previous reports<sup>16,27</sup> . As shown in Supplementary Fig. 29a, it is clear that a 2D perovskite layer was formed at the bottom of the 3D perovskite film. However, the fabricated inverted PSCs with the bottom-up 2D/3D perovskite films show poor photovoltaic performance compared to the control device (Supplementary Fig. 29b). These results further prove the advantages of our strategy of incorporating the 2D perovskite spacer into precursor inks. 

Finally, we evaluated the stability of the high-efficiency inverted PSCs under accelerated ageing conditions according to the International Summit on Organic Photovoltaic Stability (ISOS) protocols<sup>50</sup> . The long-term operational stability of the unencapsulated control and target PSCs was evaluated by MPP tracking under constant simulated AM1.5 illumination (100 mW cm<sup>−2</sup> ). Both the target devices maintained over 98% of their initial PCE of >24% after 1,500 hours of continuous tests at 55 ± 5 °C, whereas the control device degraded to 78% of its initial PCE of 21.73% (Fig. 3e). Additionally, we conducted damp-heat measurements for the encapsulated devices at 85 °C in the 85% relative humidity-controlled chamber. As shown in Fig. 3f, the target device exhibited a _T_ 90 (the time over which the device efficiency reduces to 90%) of >1,000 hours under the heating stress and thus successfully passed the main point of ISOS qualification for thermally accelerated ageing conditions (ISOS-T-1). 

The enhanced thermal and operational stability can be attributed to a lower concentration of defects and the suppressed ion migration at the HTL/perovskite interface caused by the construction of the bottom-up 2D/3D perovskite heterojunction<sup>6,7</sup> . Taken together, these data indicate that inverted PSCs with tailored bottom-up 2D/3D heterojunction at the buried interface exhibited excellent efficiency and stability, and this work takes an important step towards the realization of commercial perovskite-based single- and multiple-junction solar cells. 

### **Methods** 

#### **Materials** 

All chemicals and solvents were used as received without further purification. The nickel nitrate hexahydrate (Ni(NO3)2·6H2O, 99.999%), sodium hydroxide (NaOH, 99.9%), DMF (99.8%), DMSO (99.8%), chlorobenzene (CB, 99.8%), isopropanol (IPA, 99.5%) and Al2O3 dispersed solution (20 wt% in IPA) were all purchased from Sigma-Aldrich. Methylammonium bromide (MABr, 99.9%), methylammonium iodide (MAI, 99.9%), formamidium iodide (FAI, 99.9%), caesium iodide (CsI, 99.999%), lead(II) iodide (PbI2 ultra-dry, 99.999% purity) and lead(II) bromide (PbBr2, 99.99%) were purchased from Advanced Election Technology. PTAA (molecular weight distribution: 6,000–15,000) and bathocuproine (BCP) were purchased from Xi’an Polymer Light Technology. 2-Aminoindane hydrochloride (AICl, 98%) was bought from Macklin. NiO _x_ nanoparticles (NPs) were synthesized according to previous work<sup>51</sup> . 

#### **Device fabrication** 

ITO-coated glass substrates were etched by laser. The etched ITO glass was ultrasonically cleaned for 15 min using detergent, deionized water (twice) and ethanol (twice), sequentially. ITO-coated glass substrates were treated by ultraviolet ozone (UVO) for 30 min. Then, the 25 mg ml<sup>−1</sup> NiO _x_ NP aqueous ink was prepared by dispersing as-prepared NiO _x_ NPs into deionized water and then spin-coating onto ITO glass at 5,000 r.p.m. for 30 s. The NiO _x_ films were annealed at 150 °C for 10 min under ambient conditions. Then, the obtained NiO _x_ films were immediately transferred into a nitrogen-filled glovebox. PTAA solution (1 mg ml<sup>−1</sup> ) in CB was spin-coated onto NiO _x_ films at 6,000 r.p.m. for 30 s. After that, Al2O3 dispersion solution (0.4 wt% in IPA) was spin-coated onto PTAA films at 5,000 r.p.m. for 30 s. Perovskite films with different compositions were deposited by the spin-coating method (details presented below). Subsequently, the 23 mg ml<sup>−1</sup> of PC61BM solution in CB was spin-coated onto the perovskite films at 2,500 r.p.m. for 40 s. Then, 5 mg BCP was added into 1 mL IPA and shaken for 5 min to prepare a supersaturated solution, which was filtered using a PTFE filter before use. Afterwards, the obtained saturated solution was spin-coated on PC61BM film at 5,000 r.p.m. for 30 s. Finally, a 100 nm Ag electrode with an active area of 0.11 cm<sup>2</sup> and 1.10 cm<sup>2</sup> was deposited by thermal evaporation for small-area and large-area devices, respectively. 

For FA0.95Cs0.05PbI3 perovskite films, 1.4 M perovskite precursor solution was prepared by dissolving 228.4 mg FAI, 18.2 mg CsI and 645.4 mg PbI2 and AICl (0, 1, 1.5, 2 and 3 mg ml<sup>−1</sup> ) in mixed solvents of DMF and DMSO (v/v, 4/1). The perovskite precursor solution was spin-coated on glass/ITO/NiO _x_ /PTAA/Al2O3 substrate at 2,000 r.p.m. for 10 s and then at 4,000 r.p.m. for 40 s. During the second spin-coating step, 150 µl CB was dropped onto the perovskite film at 5 s before the end of the programme. The resultant wet perovskite films were annealed at 100 °C for 30 min. 

For (FA0.85MA0.15)0.95Cs0.05Pb(I0.85Br0.15)3 triple-cation perovskite films, 1.5 M perovskite precursor solution was prepared by mixing CsI, FAI, MABr, PbI2, PbBr2 and AICl (0, 1, 1.5, 2 and 3 mg ml<sup>−1</sup> ) in 1 ml mixed solvents of DMF:DMSO (v/v, 5/1), where excess 10 mol% of PbI2 was added to improve the device performance. A 60 µl perovskite solution was spin-coated onto glass/ITO/NiO _x_ /PTAA/Al2O3 substrate at 5,000 r.p.m. for 30 s. A 250 µl portion of CB was slowly dripped onto the centre of the film at 7 s before the end of spin-coating. 

Nature Energy | Volume 8 | September 2023 | 946–955 

**951** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

The as-prepared perovskite films were subsequently annealed on a hotplate at 110 °C for 60 min. 

For MAPbI3 perovskite films, the perovskite precursor solution was prepared by mixing 1.55 M MAI and 1.63 M PbI2 in 1 ml mixed solvents of DMF:DMSO (5/1, v/v), and stirring for 2 h before use. A 40 µl portion of perovskite solution was spin-coated onto glass/ITO/NiO _x_ /PTAA/Al2O3 substrate at 2,000 r.p.m. for 10 s and at 5,000 r.p.m. for 30 s. A 200 µl portion of CB was rapidly dripped onto the centre of the film at 5 s before the end of spin-coating. The as-prepared perovskite films were subsequently annealed on a hotplate at 100 °C for 60 min. 

#### **Characterization of the solar cells** 

The current density–voltage ( _J–V_ ) characteristics of the devices were measured in ambient air (relative humidity was 40–50%) using an AM 1.5G solar simulator equipped with 450 W xenon lamp (Newport-2612A) and a Keithley 2400 SourceMeter. Light intensity was adjusted to AM 1.5G one sun (100 mW cm<sup>−2</sup> ) with an NIM calibrated standard Si solar cell. _J–V_ curves were measured in forward scan (from −0.1 to 1.2 V) and reverse scan (from 1.2 to −0.1 V). The active area of cells was defined to be 0.09 cm<sup>2</sup> or 1 cm<sup>2</sup> by a black metal mask. For incident photon-to-current conversion efficiency measurement, a Newport Instruments system (Newport-74125) coupled with a lock-in amplifier and a 300 W xenon lamp was employed. 

#### **Characterization of the device stability** 

The operational stability measurement of the unencapsulated devices was conducted under a continuous one-sun illumination (a light-emitting diode (LED) lamp without UV filter) at 55 ± 5 °C at MPP by using a MPP trace system (YH-VMPP-16) in a N2-filled glovebox for 1,500 h. According to the ISOS-T-1 standard, the stability measurement of the encapsulated devices was conducted at 85 °C and 85% RH in the constant temperature and humidity test chamber (HS-408L) for 1,200 h. The devices were encapsulated by UV adhesive (LT-U001, Lumtec) and a glass on top. As for _J–V_ characterization, the PSCs were cooled to room temperature and measured by a Newport solar simulator (100 mW cm<sup>−2</sup> ; 94023 A Oriel Sol3A, Class AAA) at AM 1.5G (calibrated via a standard silicon cell (Hamamatsu S1133)) and a Keithley 2420 SourceMeter (scan rate was 0.1 V s<sup>−1</sup> ) at different time intervals. The devices used for damp-heat stability test were encapsulated. The devices were encapsulated in an N2 atmosphere via a top glass and edge encapsulation of UV adhesive (LT-U001, Lumtec). The light spectrum of the LED lamp (Kaiyingerdun, 50 W, 5,000 K) and xenon lamp (Newport 94023A Oriel Sol3A, Class AAA) were used for MPP tracking and damp-heat stability tests, respectively (Supplementary Fig. 30). The top glass on the device was fixed by a tweezer and aligned with the edge of the device. Then, about 200 µl of UV adhesive was applied at the edge gap between the glass and the device. Finally, the UV adhesive was solidified by a UV curing process (XY2008-GHX-1) for 2 min. 

#### **Scanning electron microscopy** 

Field-emission scanning electron microscopy (JEOL JSM-7800F) was employed to characterize the cross-sectional and surface morphology of perovskite films. 

#### **X-ray diffraction and UV–visible measurements** 

The X-ray diffraction patterns were acquired using a Panalytical Empyrean diffractometer equipped with CuKα radiation ( _λ_ = 1.5406 Å). The UV–visible absorption spectra of perovskite films were measured using a Shimadzu UV3600 spectrophotometer. The change of light absorption during spin-coating of perovskite film was studied using self-made in situ light absorption equipment. 

#### **Mott–Schottky measurements** 

Mott–Schottky measurements (1,000 Hz) were carried out on a Chenhua electrochemical workstation (CHI 760E) under dark conditions. 

#### **Photoluminescence measurements** 

The steady-state PL spectra and TRPL spectra were measured using a fluorescence spectrophotometer (FLS1000, Edinburgh Instruments) with the excitation with a 405 nm laser pulsed at a frequency of 1 MHz and 500 KHz, respectively. 

#### **Cryo-focused ion beam specimen preparation and STEM–EDS measurements** 

The scanning transmission electron microscopy (STEM) specimen preparations were performed on an FEI Helios 5 dual-beam microscope equipped with a cryogenic system<sup>42</sup> . The bulk sample was placed on the cryo-stage and gradually cooled to about −140 °C by supplying liquid N2. After curing the organometallic precursor to form a Pt-C protective layer, a prism-shaped specimen was cut and transferred to a TEM grid. The subsequent sectioning was by fine milling and specimen transfer processes. The high-angle annular dark-field scanning transmission electron microscopy (HAADF–STEM), EDS mapping and integrated differential phase contrast (iDPC)-STEM measurements were performed on a double Cs-corrected electron microscope (FEI Spectra 300) operated at 300 kV. The convergence semi-angle in the iDPC-STEM was 10.0 mrad. The probe current was about 1 pA. The dwell time was 5 µs per pixel, and the collection angle was 4–15 mrad. EDS analysis was performed using the high-efficient ‘Super X’ four-detector EDS detector. 

#### **TOF-SIMS measurements** 

The TOF-SIMS measurements (TOF-SIMS 5, IONTOF) were performed with the pulsed primary ions from an oxygen-ion beam (1 keV) for sputtering and a Bi<sup>+</sup> pulsed primary ion beam for analysis (25 keV). 

#### **GIWAXS measurements** 

The GIWAXS data were obtained from BL1W1A of the Beijing Synchrotron Radiation Facility. 

#### **UV photoelectron spectroscopy measurements** 

UV photoelectron spectra were measured (Thermo Fisher Escalab 250Xi spectrometer) using a monochromatized Al source. The UV photoelectron spectra were calibrated using the work function of Au. 

#### **TRS measurements** 

TRS measurements were performed by a pump-probe spectrometer (TA100, Time-Tech Spectra). A Ti:sapphire amplifier (Astrella, Coherent) was used to generate 800 nm light at 1 kHz repetition rate. The fundamental pulse was split into two parts. One part was sent to an optical parametric amplifier (TOPAS, light conversion) for the generation of various pump wavelengths at 1.65 eV, 2.1 eV and 2.6 eV. The pump was chopped at a frequency of 500 Hz and attenuated by neutral density filter wheels. The other part of the fundamental pulse was focused into a sapphire crystal to generate a visible continuum (450–810 nm) that was used as the probe. The probe pulses were delayed in time with respect to the pump pulses using a motorized translation stage mounted with a retroreflecting mirror. The pump and probe were spatially overlapped on the surface of the sample. For transient reflectance measurement, the incident angle for the pump was around 0° and for the probe was around 45°. The initial carrier density was of the order of 10<sup>16</sup> cm<sup>−3</sup> . 

For transient reflection kinetics, the measured surface carrier kinetics can be modelled with a diffusion and surface recombination/ transfer model. The carriers are generated with the profile _N_ ( _x_ , 0) = _N_ 0e<sup>−</sup><sup>_αx_</sup> (1) 

where _N_ 0 is the initial surface carrier density. If the traces are normalized, then _N_ 0 is equal to 1. The values for the absorption coefficient at different pump-photon energies for samples are known. The carrier movement obeys the diffusion and surface recombination/transfer equation: 

Nature Energy | Volume 8 | September 2023 | 946–955 

**952** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 



<!-- Start of picture text -->
∂ N ( x ,  t ) =  D ∂2 N ( x ,  t ) − N ( x ,  t ) (2)<br>∂ t ∂ x 2 τ B<br>∂ N ( x ,  t )<br>| x =0 = S F (3)<br>∂ t D N  (0,  t )<br>∂ N ( x ,  t )<br>| x = L = − SL (4)<br>∂ t D N  ( L ,  t )<br><!-- End of picture text -->

where _N_ ( _x_ , _t_ ) is the carrier density as a function of depth ( _x_ ) and time ( _t_ ), _D_ is the ambipolar diffusion coefficient and _τ_ B is the bulk carrier lifetime. Generally, in perovskite material, _τ_ B is of the order of hundreds of ns, and in the 5,000 ps probe window it can be neglected. The boundary condition can be described as follows. For the front surface, surface recombination/transfer will dominate ( _S_ F). For the back surface, surface recombination/transfer happens with _S_ L. For pure perovskites, the back surface and front surface can be assumed to have the same surface recombination velocity. For samples with HTL, the front surface transfer velocity is different from the back, where the back ( _S_ L) takes the value of pure perovskites. _L_ is the thickness of the film. 

The formation energy of each stage was calculated to investigate the 2D perovskite formation, and given that stage 3 should be the same for different numbers of layer _n_ , we ignored it. Supplementary Fig. 8b shows the formation energy for different numbers of layer _n_ , and it was found that the formation energy of _n_ = 2, 3, 4 and 5 was negative and decreases monotonically, which indicates that the energy is favourable to form the FA _n_ −1Pb _n_ I3 _n_ −1 perovskite flakes. In contrast, the formation energy of _n_ = 1 is positive, which means that it is difficult to form due to the non-favourable positive energy value. Therefore, in our case, the low-dimensional perovskites are easier to form for _n_ ≥ 2 compared to _n_ = 1. 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data generated or analysed during this study are included in the published article and its Supplementary Information and Source Data files. The data that support the plots within this paper and other findings of this study are available from the corresponding authors upon reasonable request. Source data are provided with this paper. 

#### **Time-resolved microwave conductivity measurements** 

For time-resolved microwave conductivity measurements, the perovskite film samples were deposited on glass and excited with a fast nanosecond laser pulse (LO-TIS TII Nd:YAG Laser System LS-2145-OPO), which generated a certain amount of carriers within the sample. Subsequently, we probed the samples with a microwave and the reflected microwave intensity was monitored as a function of time following photo-excitation with a microwave analyser (N9915A FieldFox, Keysight). To enhance the sensitivity, we introduced a high-Q microwave cavity, which has a resonance frequency of ~4.3 GHz. The source power of the microwave was set at 1 mW, and the excitation laser wavelength was 530 nm with a pulse length of ~5 ns, repetition rate of 10 Hz and excitation fluence of ~0.3–30 µJ cm<sup>−2</sup> , corresponding to a carrier density of 7.5 × 10<sup>15</sup> –7.5 × 10<sup>17</sup> cm<sup>−3</sup> . 

#### **Computational methods** 

We used the open source code cp2k<sup>52</sup> to perform the density functional theory-based geometry optimization, Multiwfn was used to assist with the input file generation<sup>53</sup> and the PBE-D3 functional was used with double-zeta basis sets (DZVP-MOLOPT) and Goedecker– Teter–Hutter pseudopotentials<sup>54</sup> with an energy cutoff of 400 Ry. Local minimum-energy geometry was obtained until the total force was less than 4.5 × 10<sup>−4</sup> Ry. As a large enough simulation box was used, a single gamma point was chosen for all the calculations. 

The formation of the 2D perovskite was divided into three stages, namely: (1) formation of (FA) _n_ −1Pb _n_ I3 _n_ −1 perovskite flakes by dissolved PbI2 and FAI at the surface; (2) formation of ligand-assisted 2D perovskite L2(FA) _n_ −1Pb _n_ I3 _n_ −1 (it should be noted that the ligand we used here was C9H11N **·** HCl; however, it is widely accepted that the Cl atom will not be incorporated into the crystal lattice but helps the perovskite crystallization in the intermediate compound, thus the C9H11N **·** HI iodine salt was used for calculation instead); (3) bulk 2D perovskite formation by way of stacking in the _z_ direction via the van der Waals interactions. The formation energy of the three stages is illustrated in Supplementary Fig. 8a and is defined as: 



<!-- Start of picture text -->
E form[stage 1] =  E [FA n −1Pb n I3 n −1] −( n  − 1) E [FAI] − nE [PbI2]<br><!-- End of picture text -->



<!-- Start of picture text -->
E form[stage 2] =  E [L2FA n −1Pb n I3 n +1] − E [FA n −1Pb n I3 n −1] − 2 E [LI]<br><!-- End of picture text -->



<!-- Start of picture text -->
E form[stage 3] =  E [bulk ∶ L2FA n −1Pb n I3 n +1] − E [slab ∶ L2FA n −1Pb n I3 n +1]<br><!-- End of picture text -->

### **References** 

1. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

2. Li, B. & Zhang, W. Improving the stability of inverted perovskite solar cells towards commercialization. _Commun. Mater._ **3** , 65 (2022). 

3. Zhang, H. et al. Toward all room-temperature, solution-processed, high-performance planar perovskite solar cells: a new scheme of pyridine-promoted perovskite formation. _Adv. Mater._ **29** , 1604695 (2017). 

4. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. _Science_ **375** , 434–437 (2022). 

5. Cao, Q. et al. Efficient and stable inverted perovskite solar cells with very high fill factors via incorporation of star-shaped polymer. _Sci. Adv._ **7** , eabg0633 (2021). 

6. Chen, H. et al. Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. _Nat. Photonics_ **16** , 352–358 (2022). 

7. Azmi, R. et al. Damp heat-stable perovskite solar cells with tailored-dimensionality 2D/3D heterojunctions. _Science_ **376** , 73–77 (2022). 

8. Li, Z. et al. Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. _Science_ **376** , 416–420 (2022). 

9. Chen, R. et al. Robust hole transport material with interface anchors enhances the efficiency and stability of inverted formamidinium–cesium perovskite solar cells with a certified efficiency of 22.3%. _Energy Environ. Sci._ **15** , 2567–2580 (2022). 

10. Xie, F. et al. Vertical recrystallization for highly efficient and stable formamidinium-based inverted-structure perovskite solar cells. _Energy Environ. Sci._ **10** , 1942–1949 (2017). 

11. Zheng, X. et al. Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. _Nat. Energy_ **5** , 131–140 (2020). 

12. Jiang, Q. et al. Surface reaction for efficient and stable inverted perovskite solar cells. _Nature_ **611** , 278–283 (2022). 

13. Wu, Y. et al. Perovskite solar cells with 18.21% efficiency and area over 1 cm<sup>2</sup> fabricated by heterojunction engineering. _Nat. Energy_ **1** , 16148 (2016). 

Nature Energy | Volume 8 | September 2023 | 946–955 

**953** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

14. Li, F. et al. Regulating surface termination for efficient inverted perovskite solar cells with greater than 23% efficiency. _J. Am. Chem. Soc._ **142** , 20134–20142 (2020). 

15. Degani, M. et al. 23.7% efficient inverted perovskite solar cells by dual interfacial modification. _Sci. Adv._ **7** , eabj7930 (2021). 

16. Chen, S. et al. Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 902–907 (2021). 

17. Jeon, N. J. et al. Compositional engineering of perovskite materials for high-performance solar cells. _Nature_ **517** , 476–480 (2015). 

18. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

19. Juarez, P. et al. Thermal degradation of CH3NH3PbI3 perovskite into NH3 and CH3I gases observed by coupled thermogravimetry– mass spectrometry analysis. _Energy Environ. Sci._ **9** , 3406–3410 (2016). 

20. Peña-Camargo, F. et al. Halide segregation versus interfacial recombination in bromide-rich wide-gap perovskite solar cells. _ACS Energy Lett._ **5** , 2728–2736 (2020). 

21. Liang, J. et al. Suppressing the phase segregation with potassium for highly efficient and photostable inverted wide-band gap halide perovskite solar cells. _ACS Appl. Mater. Interfaces_ **12** , 48458–48466 (2020). 

22. Balakrishna, R. G. et al. Mixed halide perovskite solar cells. Consequence of iodide treatment on phase segregation recovery. _ACS Energy Lett._ **3** , 2267–2272 (2018). 

23. Tang, X. et al. Local observation of phase segregation in mixed-halide perovskite. _Nano Lett._ **18** , 2172–2178 (2018). 

24. Knight, A. J. et al. Electronic traps and phase segregation in lead mixed-halide perovskite. _ACS Energy Lett._ **4** , 75–84 (2019). 

25. Brennan, M. C. et al. Light-induced anion phase segregation in mixed halide perovskites. _ACS Energy Lett._ **3** , 204–213 (2018). 

26. Turren-Cruz, S.-H. et al. Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

27. Lee, J.-W. et al. Formamidinium and cesium hybridization for photo- and moisture-stable perovskite solar cell. _Adv. Energy Mater._ **5** , 1501310 (2015). 

28. Yi, C. et al. Entropic stabilization of mixed A-cation ABX3 metal halide perovskites for high performance perovskite solar cells. _Energy Environ. Sci._ **9** , 656–662 (2016). 

29. Liu, B. et al. Interfacial defect passivation and stress release via multi-active-site ligand anchoring enables efficient and stable methylammonium-free perovskite solar cells. _ACS Energy Lett._ **6** , 2526–2538 (2021). 

30. Kim, G. et al. Impact of strain relaxation on performance of α-formamidinium lead iodide perovskite solar cells. _Science_ **370** , 108–112 (2020). 

31. Chen, J. et al. Materials and methods for interface engineering toward stable and efficient perovskite solar cells. _ACS Energy Lett._ **5** , 2742–2786 (2020). 

32. Ni, Z. et al. Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. _Science_ **367** , 1352–1358 (2020). 

33. Boyd, C. C. et al. Overcoming redox reactions at perovskite-nickel oxide interfaces to boost voltages in perovskite solar cells. _Joule_ **4** , 1759–1775 (2020). 

34. Zhang, J. et al. Elimination of interfacial lattice mismatch and detrimental reaction by self-assembled layer dual-passivation for efficient and stable inverted perovskite solar cells. _Adv. Energy Mater._ **12** , 2103674 (2022). 

35. Wang, S. et al. Critical role of removing impurities in nickel oxide on high-efficiency and long-term stability of inverted perovskite solar cells. _Angew. Chem. Int. Ed._ **61** , e202116534 (2022). 

36. Chen, W. et al. Molecule-doped nickel oxide: verified charge transfer and planar inverted mixed cation perovskite solar cell. _Adv. Mater._ **30** , e1800515 (2018). 

37. Hu, S. et al. Optimized carrier extraction at interfaces for 23.6% efficient tin–lead perovskite solar cells. _Energy Environ. Sci._ **15** , 2096–2107 (2022). 

38. Hempel, H. et al. Predicting solar cell performance from terahertz and microwave spectroscopy. _Adv. Energy Mater._ **12** , 2102776 (2022). 

39. Savenije, T. et al. Quantifying charge-carrier mobilities and recombination rates in metal halide perovskites from timeresolved microwave photoconductivity measurements. _Adv. Energy Mater._ **10** , 1903788 (2020). 

40. Hutter, E. M. et al. Charge transfer from methylammonium lead iodide perovskite to organic transport materials: efficiencies, transfer rates, and interfacial recombination. _Adv. Energy Mater._ **7** , 1602349 (2017). 

41. Labram, J. G. et al. Recombination at high carrier density in methylammonium lead iodide studied using time-resolved microwave conductivity. _J. Appl. Phys._ **122** , 065501 (2017). 

42. Zhou, J. et al. Cryogenic focused ion beam enables atomicresolution imaging of local structures in highly sensitive bulk crystals and devices. _J. Am. Chem. Soc._ **144** , 3182–3191 (2022). 

43. Kirchartz, T. et al. Photoluminescence-based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

44. Baloch, A. A. B. et al. Analysis of photocarrier dynamics at interfaces in perovskite solar cells by time-resolved photoluminescence. _J. Phys. Chem. C_ **122** , 26805–26815 (2018). 

45. Krogmeier, B. et al. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain_ . _Energy Fuels_ **2** , 1027–1034 (2018). 

46. Xue, J. et al. Reconfiguring the band-edge states of photovoltaic perovskites by conjugated organic cations. _Science_ **371** , 636–640 (2021). 

47. Price, M. B. et al. Hot-carrier cooling and photoinduced refractive index changes in organic–inorganic lead halide perovskites. _Nat. Commun._ **6** , 8420 (2015). 

48. Chen, X. et al. Tuning spin-polarized lifetime in two-dimensional metal–halide perovskite through exciton binding energy. _J. Am. Chem. Soc._ **143** , 19438–19445 (2021). 

49. Chen, J. et al. Simultaneous improvement of photovoltaic performance and stability by in situ formation of 2D perovskite at (FAPbI3)0.88(CsPbBr3)0.12/CuSCN interface. _Adv. Energy Mater._ **8** , 1702714 (2018). 

50. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

51. Zhang, H. et al. Pinhole-free and surface-nanostructured NiO _x_ film by room-temperature solution process for high-performance flexible perovskite solar cells with good stability and reproducibility. _ACS Nano_ **10** , 1503–1511 (2016). 

52. Kuhne, T. D. et al. CP2K: an electronic structure and molecular dynamics software package–quickstep: efficient and accurate electronic structure calculations. _J. Chem. Phys._ **152** , 194103 (2020). 

53. Lu, T. et al. Multiwfn: a multifunctional wavefunction analyzer. _J. Comput. Chem._ **33** , 580–592 (2012). 

54. VandeVondele, J. et al. Gaussian basis sets for accurate calculations on molecular systems in gas and condensed phases. _J. Chem. Phys._ **127** , 114105 (2007). 

55. Li, M. et al. Stabilizing perovskite precursor by synergy of functional groups for NiOx-based inverted solar cells with 23.5% efficiency. _Angew. Chem. Int. Ed._ **61** , e202206914 (2022). 

Nature Energy | Volume 8 | September 2023 | 946–955 

**954** 

**Article** 

https://doi.org/10.1038/s41560-023-01295-8 

### **Acknowledgements** 

Z.Z. acknowledges funding from the Defense Industrial Technology Development Program (JCKY2017110C0654), Fundamental Research Fund for the Central Universities (2022CDJQY-010) and National Natural Science Foundation of China (grant nos. 11974063 and 61904023). J. Chen acknowledges funding from Support Plan for Overseas Students to Return to China for Entrepreneurship and Innovation (grant no. cx2020003), the Fundamental Research Funds for the Central Universities (grant no. 2020CDJ-LHZZ-074) and Natural Science Foundation of Chongqing (grant no. cstc2020jcyj-msxmX0629). H.Z. acknowledges the funding from Shanghai Pujiang Program (22PJ1401200). M.G. acknowledges funding from the European Union’s Horizon 2020 research and innovation programme GRAPHENE Flagship Core 3 grant agreement no. 881603. X.L. acknowledges the Research Fund of the State Key Laboratory of Solidification Processing (NPU) (grant no. 2021-QZ-02) and the Fundamental Research Funds for the Central Universities (3102019JC005). 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41560-023-01295-8. 

**Correspondence and requests for materials** should be addressed to Hong Zhang, Xuanhua Li, Michael Grätzel, Jiangzhao Chen or Zhigang Zang. 

**Peer review information** _Nature Energy_ thanks Eline Hutter, Atsushi Wakamiya, Christian Wolff and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

### **Author contributions** 

H.L., J. Chen and Z.Z. conceived the project. H.L., C.Z., C.G. and Q.Z. prepared the samples and devices, and performed all other measurement except for TEM, TRS, GIWAXS and time-resolved microwave conductivity measurements. D.Z., J.L. and J.Z. performed TEM measurements. X.Y., S.G. and X.C. conducted TRS measurements. H.Y. carried out GIWAXS measurements. Q.L. performed time-resolved microwave conductivity measurements. H.Z. and J. Chen wrote the first draft of the manuscript. H.L. and R.L. certified the efficiency of the PSCs. J.Y. and X.L. conducted the long-term operational stability measurements. M.G. was involved in the data analysis and wrote the final version of the manuscript. H.Z., X.L., M.G., J. Chen and Z.Z. supervised this project. All authors analysed the data and contributed to the discussions. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

1Key Laboratory of Optoelectronic Technology & Systems (Ministry of Education), Chongqing University, Chongqing, China. 2Multi-scale Porous Materials Center, Institute of Advanced Interdisciplinary Studies, Chongqing University, Chongqing, China.<sup>3</sup> Shanghai Frontiers Science Research Base of Intelligent Optoelectronics and Perception, Institute of Optoelectronics, Department of Materials Science, Fudan University, Shanghai, China.<sup>4</sup> SUSTech Energy Institute for Carbon Neutrality, Department of Mechanical and Energy Engineering, Southern University of Science and Technology, Shenzhen, China.<sup>5</sup> State Key Laboratory of Solidification Processing, Center for Nano Energy Materials, School of Materials Science and Engineering, Northwestern Polytechnical University, Xi’an, China.<sup>6</sup> Institute of High Energy Physics, Chinese Academy of Sciences (CAS), Beijing, China.<sup>7</sup> Key Lab of Artificial Microand Nano-Structures of Ministry of Education of China, School of Physics and Technology, Wuhan University, Wuhan, China.<sup>8</sup> Laboratory of Photonics and Interfaces, École Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>9</sup> These authors contributed equally: Haiyun Li, Cong Zhang, Cheng Gong, Daliang Zhang. e-mail: hzhangioe@fudan.edu.cn; lixh32@nwpu.edu.cn; michael.graetzel@epfl.ch; jiangzhaochen@cqu.edu.cn; zangzg@cqu.edu.cn 

Nature Energy | Volume 8 | September 2023 | 946–955 

**955** 





