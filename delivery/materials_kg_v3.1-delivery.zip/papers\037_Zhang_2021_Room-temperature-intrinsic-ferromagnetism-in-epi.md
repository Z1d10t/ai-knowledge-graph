# Room-temperature intrinsic ferromagnetism in epitaxial CrTe2 ultrathin films

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 373 |
| 作者 | Xiaoqian Zhang, Qiangsheng Lu, Wen-Qing Liu, Wei Niu, Jia-Bao Sun, Jacob Cook, Mitchel Vaninger, P. Miceli et al. |
| DOI | 10.1038/s41467-021-22777-x |
| 源文件 | 037_Zhang_2021_Room-temperature-intrinsic-ferromagnetism-in-epi.pdf |

---


## ARTICLE 

https://doi.org/10.1038/s41467-021-22777-x 

**OPEN** 



# Room-temperature intrinsic ferromagnetism in epitaxial CrTe2 ultrathin films 

Xiaoqian Zhang<sup>1,2,12</sup> , Qiangsheng Lu<sup>2,12</sup> , Wenqing Liu<sup>1,3,12</sup> , Wei Niu<sup>4</sup> , Jiabao Sun 3, Jacob Cook2, Mitchel Vaninger<sup>2</sup> , Paul F. Miceli<sup>2</sup> , David J. Singh 2,5, Shang-Wei Lian6, Tay-Rong Chang 6,7, Xiaoqing He8,9, Jun Du<sup>10</sup> , Liang He 1✉, Rong Zhang 1✉, Guang Bian 2✉ & Yongbing Xu 1,11✉ 

While the discovery of two-dimensional (2D) magnets opens the door for fundamental physics and next-generation spintronics, it is technically challenging to achieve the roomtemperature ferromagnetic (FM) order in a way compatible with potential device applications. Here, we report the growth and properties of single- and few-layer CrTe2, a van der Waals (vdW) material, on bilayer graphene by molecular beam epitaxy (MBE). Intrinsic ferromagnetism with a Curie temperature (TC) up to 300 K, an atomic magnetic moment of ~0.21 μB/Cr and perpendicular magnetic anisotropy (PMA) constant (Ku) of 4.89 × 10<sup>5</sup> erg/cm<sup>3</sup> at room temperature in these few-monolayer films have been unambiguously evidenced by superconducting quantum interference device and X-ray magnetic circular dichroism. This intrinsic ferromagnetism has also been identified by the splitting of majority and minority band dispersions with ~0.2 eV at Г point using angle-resolved photoemission spectroscopy. The FM order is preserved with the film thickness down to a monolayer (TC ~ 200 K), benefiting from the strong PMA and weak interlayer coupling. The successful MBE growth of 2D FM CrTe2 films with room-temperature ferromagnetism opens a new avenue for developing large-scale 2D magnet-based spintronics devices. 

> 1 Jiangsu Provincial Key Laboratory of Advanced Photonic and Electronic Materials, School of Electronic Science and Engineering, Nanjing University, Nanjing, China.<sup>2</sup> Department of Physics and Astronomy, University of Missouri, Columbia, MO, USA.<sup>3</sup> Department of Electronic Engineering, Royal Holloway University of London, Egham, Surrey, UK.<sup>4</sup> New Energy Technology Engineering Laboratory of Jiangsu Provence & School of Science, Nanjing University of Posts and Telecommunications, Nanjing, China.<sup>5</sup> Department of Chemistry, University of Missouri, Columbia, MO, USA.<sup>6</sup> Department of Physics, National Cheng Kung University, Tainan, Taiwan.<sup>7</sup> Center for Quantum Frontiers of Research and Technology (QFort), Tainan, Taiwan.<sup>8</sup> Electron Microscopy Core Facility, University of Missouri, Columbia, MO, USA.<sup>9</sup> Department of Mechanical and Aerospace Engineering, University of Missouri, Columbia, MO, USA. 10 National Laboratory of Solid State Microstructures and Department of Physics, Nanjing University, Nanjing, China. 11 York-Nanjing Joint Centre (YNJC) for Spintronics and Nano Engineering, Department of Electronic Engineering, The University of York, York, UK.<sup>12</sup> These authors contributed equally: Xiaoqian Zhang, Qiangsheng Lu, Wenqing Liu.<sup>✉</sup> email: heliang@nju.edu.cn; rzhang@nju.edu.cn; biang@missouri.edu; ybxu@nju.edu.cn 

1 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 

wo-dimensional (2D) layered magnets exhibit novel phases of quantum matter with abrupt transition in the magnon Tdensity of states in atomically thin layers. In a threedimensional (3D) system, the magnon density of states are consecutive and chiefly determined by exchange interactions. Therefore, a magnetic phase transition could occur at a finite temperature. By contrast, the long-range magnetic order in 2D systems is fragile against thermal fluctuations according to the Mermin–Wagner theorem<sup>1,2</sup> . The magneto-anisotropy in 2D ferromagnets opens up a large spin-wave excitation gap, quenches thermal fluctuations<sup>3–9</sup> , and thus stabilizes the long-range magnetic order in 2D regime. In contrast to defect or dopant induced magnetism, the ferromagnetism occurring in a stoichiometric compound is defined as intrinsic ferromagnetism<sup>10</sup> . 

While the presence of 2D crystals with intrinsic magnetism has been well established, the intrinsic ferromagnetic (FM) order in the discovered magnetic van der Waals (vdW) materials is generally fragile with a low Curie temperature (TC). It mainly results from the enhanced spin fluctuation in reduced dimensions or the relatively weak exchange interactions. Note that the interlayer bonding strength in vdW compounds is 2–3 orders of magnitude weaker than that of traditional 3D materials<sup>4</sup> , which leads to a low TC in the bulk form already. It motivates research efforts to enhance the robustness of 2D FM order. The first route is doping a FM host with specific elements, which normally results in a limited increase of TC but unavoidable clusters and/or disorders from dopants<sup>11,12</sup> . The second one is constructing heterostructures with FM (or ferrimagnetic) metals (or insulators), in which the FM order can be enhanced by proximity effects<sup>13,14</sup> . For instance, the (Fe3GeTe2/ MnTe)3 superlattices possess an enhanced coercive field as a result of the proximity effect<sup>12</sup> . However, the penetration depth of proximity effect is usually very small (<5 nm), hindering an effective manipulation of magnetic order. The third method is doping 2D magnets with electrons via electrolyte gating, and thereby modulating the TC of ferromagnetism. For example, the TC of an atomically thin Fe3GeTe2 flake is successfully raised to even room temperature<sup>15</sup> . Nevertheless, particular device geometry and gating are required by this means. Apart from the issues mentioned above, most of the 2D magnetic materials reported so far are thin flakes exfoliated from bulk with typical size of several micrometers, which greatly limits the practical applications of those 2D magnets in spintronics. Therefore, there is a pressing need for the realization of stoichiometric 2D materials with intrinsic robust ferromagnetism (e.g., high TC and strong perpendicular anisotropy) and, importantly, compatibility with largescale solid-state device applications. 

Molecular beam epitaxy (MBE) growth is significant as it provides the opportunity to obtain nominally stoichiometric single-crystalline films, explore the role of physical dimensionality as well as fabricate heterostructures and superlattices in a way compatible with conventional microelectronics techniques. One remarkable work is the strong FM order in ML VSe2 epitaxial film with in-plane easy axis and a large magnetic moment (~15 μB/V) persisting to even above room temperature, as characterized by magneto-optical Kerr effect (MOKE) and vibrating sample magnetometry (VSM)<sup>16</sup> . However, according to the theoretical calculations, the magnetic moment of ML VSe2 mostly comes from V ions with an atomic value of ~0.6 μB<sup>17</sup> , which is completely contradictory to the experimentally observed large magnetic moment<sup>16</sup> , raising doubts about this presumed FM phase. Most recently, Wong et al. has provided the evidence of spin frustration with absence of a long-range magnetic order in ML VSe2 films from complementary temperatureand fielddependent susceptibility measurements<sup>18</sup> , in stark contrast to the previous study. Moreover, the electronic structure and X-ray magnetic circular dichroism (XMCD) measurements of ML VSe2 

conducted by Feng et al. reveal no signatures of FM order<sup>19</sup> . These studies suggest that the existence of 2D FM order in VSe2 remains to be further confirmed. Therefore, layer-controlled growth of stoichiometric large-scale 2D FM films with strong perpendicular magnetic anisotropy (PMA) and direct proof for the intrinsic ferromagnetism by unambiguous techniques would be mandatory. Notably, an above-room-temperature TC has been reported in 1T-CrTe2 in its bulk form<sup>20</sup> . Very recently, aboveroom-temperature ferromagnetism has been observed in the exfoliated thin flakes of CrTe2 (10 nm, or ~17 ML)<sup>21,22</sup> . Their properties were found to be rather similar to that of the bulk with in-plane magnetic anisotropy, but with enhanced coercivity compared with its bulk counterpart. However, the magnetic response (e.g., TC and PMA) of CrTe2 epitaxial thin films with thickness down to ML limit has not been explored so far. 

In this work, we succeed in synthesizing mono- and few-layer CrTe2 films by MBE and observed intrinsic long-range 2D ferromagnetism. The robust ferromagnetism and strong PMA of CrTe2 films persist up to 300 K, as evidenced by both superconducting quantum interference device (SQUID) and XMCD characterizations. In addition, the splitting of the majority and minority bands (~0.2 eV at Г point) with distinct photon-energy responses has been observed by in-situ angle-resolved photoemission spectroscopy (ARPES) measurements, suggesting the magnetic band structure of CrTe2 with spin-splitting. Furthermore, the CrTe2 thin films retain a robust ferromagnetism with high TC down to a ML, indicating a weak dimensionality effect. These results establish CrTe2 ultrathin films as a promising 2D ferromagnet for exotic low-dimensional spintronics applications. 

### Results 

CrTe2 is a layered trigonal crystal structure with a unit cell of a hexagonal Cr layer sandwiched between Te layers, as schematically illustrated in Fig. 1a. In our experiment, a bilayer graphene on SiC substrate was used to support a layer-by-layer growth of CrTe2 films. The optical image of a single-crystal CrTe2 film with large size (~4 mm × 5 mm) is shown in the inset of Fig. 1b. The microscopic topography taken from the surface of a few-layer CrTe2 film by in-situ scanning tunneling microscopy (STM) shows atomically flat terrace (Fig. 1b). Figure 1c exhibits the step height between adjacent layers with a uniform value of 6.14 Å, which is consistent with the thickness of the unit cell of CrTe2 crystal in 1T phase. One of the atomic resolution image taken by STM on the same sample is presented in Fig. 1e, showing the hexagonal lattice structure. The lattice constant obtained from the line profile in Fig. 1f is 3.81 Å, which is very close to the corresponding bulk CrTe2 lattice parameter (3.79 Å)<sup>20</sup> . STM measurements carried out on several CrTe2 thin films with different thicknesses (mono- to few-layer) show similar terraces, indicating the layer-by-layer growth mode and homogeneously wellstructured thin films (see Supplementary Fig. 1). 

There are various stable stoichiometries reported for chromium chalcogenides [e.g., CrTe<sup>23,24</sup> , Cr2Te3<sup>25,26</sup> , and Cr5Te8<sup>27,28</sup> ] depending on the Cr vacancies that occur in intercalation. However, none of them belongs to layered compounds with interlayer vdW gap, except for CrTe2. The layered surface morphology with a uniform step height characterized by STM suggests that the films are in a single phase with vdW gap. The atomic-resolution high-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) images show the p3a × a arrangement, revealing that CrTe2 thin films correspond to the 1T phase with an octahedral (Oh) symmetry (see Supplementary Fig. 2). Both TEM and STM characterizations manifest the epitaxial nature and crystallographic orientation of as-grown CrTe2 films. A typical X-ray diffraction (XRD) 2θ-ω scan was 

2 NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 





Fig. 1 Crystal structure and STM characterizations of epitaxially grown CrTe2 thin films. a Schematic illustration of MBE growth process of CrTe2 films on graphene. b The STM topology image (200 × 200 nm<sup>2</sup> ) of a 7 ML CrTe2 fabricated on graphene/SiC. U = +1 V, It = 200 pA. Inset on the left is an optical image. c The line-scan profile taken along the pink line in (b), with an average step height of ~6.14 Å. d XRD spectrum showing Laue fringes around the (001) CrTe2 reflections. The solid fitting curve indicates the thickness of 39 layers, the roughness of 2 layers, and the lattice constant c = 6.13 Å. e Atomically resolved STM image (4 × 4 nm<sup>2</sup> ) with a hexagonal structure. U = −1.5 mV, It = −440 pA. f The line-scan along the green arrow in (e), showing a lattice periodicity of ~3.81 Å. 

employed to further identify the crystal structure (Fig. 1d). The diffraction pattern with perpendicular constant c = 6.13 Å is matched to the (001) crystal planes of 1T-type hexagonal structure explored experimentally (a = 3.79 Å, c = 6.10 Å)<sup>20</sup> , rather than those of the 2H phase (a = 3.49 Å, c = 13.64 Å)<sup>29</sup> . We note that the magnetic exchange coupling is sensitive to the lattice parameters. For example, bulk 1T-CrSe2 with lattice constants of a = 3.39 Å and c = 5.92 Å shows an antiferromagnetic (AFM) order<sup>30</sup> , in contrast to the FM phase in CrTe2. With STM, TEM, and XRD characterizations, the formation of CrTe2 films with 1T phase and their single-crystalline nature has been confirmed. The reflectivity curves show Laue fringes, attesting to the structural coherence of the film. The chemical states and band structure of the assynthesized samples were determined by X-ray absorption spectroscopy (XAS) and ARPES as included in the following part, respectively, which further identify the metallic 1T phase in these few-layer CrTe2 films. 

Magnetic properties of CrTe2 thin films with both in-plane and out-of-plane configurations were examined by SQUID, as shown in Fig. 2. The temperature dependent magnetization (M–T) curves of CrTe2 thin films with different thicknesses under an out-of-plane magnetic field of 1000 Oe were measured, as shown in Fig. 2a. It shows a general trend of decreasing with the increase of temperature, demonstrating a FM nature. It indicates that the TC is close to the room temperature with the specific values depending on the thickness. The magnetization of 7 ML CrTe2 film is still observable at 300 K, indicating the FM order at room temperature. The magnetization curve exhibits a long “tail” near TC, which is commonly observed in ferromagnets<sup>4,11,31</sup> . It can be explained by a positive-feedback mean-field modification of the classical Brillouin magnetization theory<sup>32</sup> . 

The magnetization-magnetic field (M–H) hysteresis loops acquired from the 7 ML CrTe2 film at different temperatures are included in Fig. 2b and c. The sharp distinction between out-of- 

plane (Fig. 2b) and in-plane (Fig. 2c) M–H loops demonstrates a strong out-of-plane anisotropy of the magnetization with a large PMA constant (K u ¼ Hk2Ms<sup>) of 5.63 × 106 erg/cm3 at 20 K. The Ku</sup> in CrTe2 thin films is comparable to the typical PMA systems such as Co/Pd and Co/Pt (see Supplementary Table 1)<sup>33–36</sup> , which is vital for obtaining 2D FM order and is also considerably desirable for vdW heterostructures-based spintronics. The film also exhibits rather large coercivities (e.g., ~1000 Oe at 20 K), indicative of a hard magnetic phase. Well-defined hysteresis loops are observed at elevated temperatures up to 300 K (Fig. 2d) with the easy axis along the out-of-plane direction and hard axis along the in-plane one. The existence of PMA in the ultrathin 7 ML film is confirmed, supporting the FM order at room temperature. The in-plane magnetic hysteresis loops, similar to those reported in the FM vdW Cr2Ge2Te6 thin films<sup>37</sup> and typical PMA systems such as Mn2.5Ga<sup>38</sup> and Co/Pt<sup>39</sup> , can be attributed to the shape anisotropy favoring in-plane easy axis for thin films<sup>40,41</sup> . Control experiments on the field dependent magnetization of SiC/graphene substrate show a typical diamagnetic behavior (see Supplementary Fig. 4). Therefore, the possibility of magnetic contribution from magnetic impurities in the substrate can be ruled out. In order to clarify the thickness dependence of the magnetic properties, we have measured the field dependent magnetization curves of 3 ML and 5 ML CrTe2 thin films under out-of-plane and in-plane configuration (Supplementary Fig. 5). The squarish FM hysteresis loops in the out-of-plane magnetic field suggest the robust FM order with the easy axis perpendicular to the thin films, which is essential for the applications of FM devices. Compared with other 2D magnets from literature<sup>3,4,42,43</sup> , the CrTe2 films perform a relatively high TC (above room temperature) and strong magnetic anisotropy with a few atomic layers. Notably, a large K u (4.89 × 10<sup>5</sup> erg/cm<sup>3</sup> ) is maintained at 300 K, comparable to the value of bulk CrGeTe3 at 1.8 K (4.7 × 10<sup>5</sup> erg/cm<sup>3</sup> )<sup>44</sup> . The strong PMA in CrTe2 few-layer films is 

3 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 





Fig. 2 SQUID measurements of the CrTe2 films. a Temperature dependent magnetization curves of the films with various thicknesses under field-cooled mode. The magnetic field is applied along the out-of-plane direction with a magnitude of 1000 Oe. The high TC is preserved with thickness decreasing to 3 ML. b, c Magnetic hysteresis loops of 7 ML CrTe2 at different temperatures with external fields along the perpendicular (b) and parallel orientation (c) with respect to sample plane, indicating a strong out-of-plane magnetic anisotropy. d Enlarged hysteresis loops of 7 ML CrTe2 at 300 K, where the intrinsic ferromagnetism and PMA still maintains. Top inset: temperature dependence of Ku for 7 ML CrTe2, where the Ku is preserved at 300 K, despite the lower intensity with the increase of temperature. 

different from the in-plane magnetic anisotropy observed in bulk CrTe2<sup>20</sup> and exfoliated flakes (thicker than 10 nm)<sup>21</sup> . Here, the thickness dependent magnetic anisotropy suggests that the reduced symmetry at the interface plays an important role in determining the PMA in CrTe2 thin films<sup>45</sup> . As the magnetic film thickness approaches a few nm, the interfacial magnetism and inversion symmetry breaking give rise to the PMA<sup>46</sup> . This is a consequence of magneto-crystalline anisotropy from spin–orbit interactions, which apparently have a stronger effect in the more anisotropic film limit<sup>33,41,45</sup> . In addition, based on density functional theory (DFT) calculations, it has been found that the FM Cr–Cr intrasublattice exchange interactions dominate in CrTe2 thin films, and the total energy minima is at perpendicular direction<sup>47</sup> . In general, the magnetic moments of CrTe2 thin films are aligned in the perpendicular direction, due to the magnetocrystalline anisotropy and the anisotropy of exchange interactions. 

To examine the local electronic character and magnetic ground states of CrTe2 films, XAS and XMCD measurements at the Cr L2,3 absorption edges were performed, as schematically shown in Fig. 3a. This element-specific magnetic characterization technique can also exclude any possible magnetic impurities. The XAS spectra of Cr present multiplet structures around photon energies of 575 eV and 584 eV (Fig. 3b), which stem from the excitations 

from Cr 2p3/2 and Cr 2p1/2 core levels, respectively. A small peak (~2 eV away from L3 peak of Cr) marked with the black arrow comes from Te 5d5/2 core level, which slightly overlaps with the peak of Cr 2p3/2 with almost no magnetic contribution<sup>48</sup> . A small peak at the higher energy side (marked with orange arrow) of the main feature in Fig. 3b is related to the distribution of atomic multiplet. Due to the Oh coordination, the 3d orbitals of Cr split into eg and t2g states with energy separation of nominal 10 Dq. The t2g states are lower in energy than the eg states. In this case, the Cr<sup>3+</sup> (d<sup>3</sup> ) configuration with half-filled t2g states causes the reduction of free energy<sup>49</sup> , which is in good agreement with the reported theoretical value of magnetic moment, 3 μB/Cr atom<sup>50</sup> . The observed XAS spectral line shape is in line with that of spinel Cu(Cr,Ti)2Se4 polycrystals with trivalent Cr cations on Oh sites<sup>51</sup> , further providing a spectroscopic fingerprint of 1T-type CrTe2 with predominately Cr<sup>3+</sup> cations. In this case, approximately three electrons are removed from the Cr atoms, and distributed over the Te. 

The Cr L2,3 XMCD spectra in the bottom panel of Fig. 3b highlight the emergence of intrinsic ferromagnetism from Cr atoms. XMCD and XAS measurements were repeated at elevated temperatures, and the dichroism of 7 ML thin film at Cr L3 edge is evident up to 300 K. The characteristic peaks in the spectra remain at the same energy as the temperature rises, despite the 

4 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 



Fig. 3 XAS and XMCD characterization of 7 ML CrTe2 films. a Schematic geometry of XMCD experimental setup. b Typical pairs of XAS and XMCD spectra of 7 ML CrTe2 from 5 K to 300 K and the integrals at 5 K, where the dichroism at Cr L3 edge can be traced to 300 K (spectra at different temperatures are offset for clarify). c The partially enlarged XAS of Cr L3 edge at 200 K, 250 K, and 300 K. d ms and ml versus temperature derived from (b) using sum rules. The error bars reflect the uncertainties in the background estimation for the XMCD sum rules analysis. 

attenuation of intensity. For greater clarity, partial enlarged leftand right-circularly polarized XAS of Cr L3 edge at 200 K, 250 K, and 300 K are exhibited in Fig. 3c. There is an obvious difference between the XAS under distinct X-ray helicity even at 300 K, directly confirm the intrinsic FM order coming from the Cr<sup>3+</sup> cations in the CrTe2 films. The XMCD spectra have been analyzed in terms of element-specific magnetic moments according to the sum rules<sup>52,53</sup> . The spin moment (ms) and orbital moment (ml) can be obtained by sum rule: 



<!-- Start of picture text -->
6R L3 ð σþ � σ� ÞdE � 4R L2;3 ð σþ � σ� ÞdE<br>ms ¼ �nh ´ SC � �T z�<br>R L2;3 ð σþ þ σ� ÞdE<br><!-- End of picture text -->



<!-- Start of picture text -->
ð1Þ<br><!-- End of picture text -->



<!-- Start of picture text -->
4 R L2;3 ðσþ � σ�ÞdE<br>ml ¼ � 3 nh R L2;3 ðσþ þ σ�ÞdE ð2Þ<br><!-- End of picture text -->

where nh, SC and �T z� are the number of d holes, spin correction factor (estimated to be 2.0 ± 0.2 for Cr)<sup>13,54</sup> and the averaged magnetic dipole term, respectively. Based on the trivalent Cr, we assume nh = 7. The magnetic dipole term, �T z� can be neglected due to its rather small contribution (<5%) in the Cr t<sup>3</sup> 2g<sup>config-</sup> uration. An arctangent step-like function was employed in the fitting of the threshold of XAS spectra in order to exclude the nonmagnetic contribution<sup>55,56</sup> . 

The calculated ms and ml from 5 to 300 K are summarized in Fig. 3d. The derived ms demonstrates a Curie-like behavior. A remarkably large value of ms (2.85 ± 0.10 μB/Cr) is found at 5 K. The ms retains a sizable value of 0.82 ± 0.10 μB/Cr at 250 K and drops to 0.21 ± 0.05 μB/atom at 300 K, confirming a FM phase transition near this temperature. On the other hand, ml is relatively small of around 0.08 ± 0.05 μB/atom, consistent with a halffilled t2g level in Oh crystal field of 1T-CrTe2. The ml plays an important role in the magneto-crystalline anisotropy and the perpendicular orientation of the moments that underlies the FM order in this 2D system. The atomic magnetic moment of CrTe2 is determined to be ~3 μB/atom. The observed FM behavior cannot be attributed to the Cr clusters, since bulk Cr is AFM and therefore would give a zero XMCD intensity. 

The magnetic response of 1 ML CrTe2 film is worth exploring. It is difficult to detect magnetization in such ultrathin films by SQUID, since the magnetic signal of 1 ML CrTe2 is too weak compared with an overwhelmingly larger background signal from the substrate and beyond the resolution of SQUID. Therefore, we did element-specific XMCD characterization of 1 ML CrTe2 film (Fig. 4a). There is a noticeable difference in the XAS spectra between left- and right-handed circularly polarized setups (Fig. 4b). Although the dichroism is small compared with 7 ML sample, the clear XMCD signals appear near the absorption peaks. It suggests that the intrinsic ferromagnetism of 1 ML CrTe2 film originates from the spin polarization of Cr 3d electrons. Accurate calculation of the magnetic moment remains a challenge since the contribution of Te capping layer to the XAS spectra is so large for 1 ML sample. The XMCD percentage increases with the reduced temperature (Fig. 4c), in line with a typical FM behavior. The nonzero XMCD percentage persists when temperature approaches 200 K and disappears above 250 K, indicating that 1 ML CrTe2 has a TC of ~200 K. The TC has been obtained by using a critical power-law function α(1−T/TC)<sup>β</sup> to fit M-T curves without the inclusion of the paramagnetic tail<sup>42</sup> . In order to investigate the dimensionality effect of the ferromagnetism in CrTe2 stemming from thermal fluctuation, we plot the thickness dependent TC obtained from XMCD and SQUID measurements in Fig. 4d. The TC of CrTe2 decreases mildly as the film thickness is reduced, in contrast to the other known 2D magnets such as Cr2Ge2Te6<sup>4</sup> and Fe3GeTe2<sup>15</sup> (Supplementary Fig. 10). The high TC in the 2D limit demonstrates the robustness of ferromagnetism in the epitaxial CrTe2 thin films. 

The electronic band structure of CrTe2 thin films has been mapped by ARPES with two different photon energies of 21.2 eV and 40.8 eV at 107 K. The band dispersions of 7 ML CrTe2 measured at hv = 21.2 eV along high symmetry crystallographic direction M-Г-K in the surface Brillouin zone are shown in Fig. 5a. Near the Г point, the main features include two hole-like valence bands aligned close to the Fermi level, which shares identity with the typical features of 1T-ZrTe2<sup>57</sup> . Near the M point, there are two electron pockets with bottom locating at −1.2 eV and −1.8 eV, respectively. The Fermi surface map shows two circular pockets centered at Г point surrounded by six triangular 

5 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 





Fig. 4 XAS and XMCD characterization of CrTe2 films with thickness of monolayer. a Typical pairs of XAS and XMCD spectra of 1 ML CrTe2 thin film at various temperatures, where the dichroism at Cr L3 edge is observable up to 200 K. b The partially enlarged XAS spectra near the Cr L3 edge, where the difference between left- and right-circularly polarized XAS is evident. c XMCD percentage as a function of temperature derived from a. The error bars indicate the uncertainties in the background estimation for the XMCD percentage calculation. d Compiled thickness–temperature phase diagram with the TC obtained from XMCD and SQUID measurements. The error bars are the uncertainties in determining the TC. 

pockets at K points. Below the Fermi level, the pockets around K points begin to merge with the expanded pockets at Г point (Supplementary Fig. 11). The well-defined band structure indicates the high structural quality of the MBE-fabricated films. 

The origin of the band dispersions has been investigated by first-principle DFT calculations based on CrTe2 slab<sup>18</sup> . The mean free path of photoelectrons excited by photons of 21.2 eV and 40.8 eV is between 0.5 and 1 nm. Therefore, to compare with the experimental spectra, we simulated the band structure with a surface weight of each Bloch wavefunction. The higher intensity in the image means greater weight of wavefunction near the slab surface. Figure 4b shows the calculated spin-polarized band structure, with the majority and minority spin bands plotted in blue and red, respectively. Both magnetization and spin–orbit coupling (SOC) are taken into account in the calculation, and the magnetic moments are set along out-of-plane direction. According to the orbital and surface projection analysis of the band structure, the metallicity is a consequence of the hybridization of Te-5p and Cr-3d orbitals crossing the Fermi level at the center of the Brillouin zone (see Supplementary Fig. 13), which is confirmed by the calculated density of states (see Supplementary Fig. 14). The hybridization of Te and Cr states was also verified in previous DFT calculations<sup>20</sup> . There is an overall agreement between the experimental (Fig. 5a) and calculated band dispersions (Fig. 5b), except for the absence of two hole pockets from minority band near Г point. 

To compare experiment and theory in greater detail, the dispersion of hole pockets detected by different photon energies is plotted in Fig. 5c and d. Note that the two hole pockets near the Fermi level in Fig. 5c are mainly from the majority bands. Interestingly, the minority hole pocket shows up in the spectrum taken at hv = 40.8 eV (Fig. 5d) while the majority ones disappear. It suggests the emission from the minority spin pockets was suppressed in the measurement at hv = 21.2 eV as a consequence of matrix element effect<sup>58</sup> . The band dispersion can be traced by fitting the peak position in the momentum distribution curves 

(MDC), as marked by blue and red dashed lines in Fig. 5c and d, respectively. Combining the band structure near Fermi energy (EF) taken by He Iα and He IIα photons together, as shown in Fig. 5e, the electronic structure is clearly metallic in both the majority and minority spin channels, and agrees well with DFT calculations. Relatively small renormalizations are needed to match with ARPES results, indicating moderate-to-weak correlations. The experimental band structure of CrTe2 is in sharp contrast with the band structure calculated without the inclusion of spin polarization (Supplementary Fig. 15), where hole pockets near EF are degenerate at Г point as in the cases of VTe2<sup>59</sup> and VSe2<sup>18,19</sup> . There are no exchange splitting of band dispersion in MBE grown VSe2 films, indicating the absence of ferromagnetism<sup>18,19</sup> . By contrast, the splitting of majority and minority bands (~0.2 eV at Г point) in CrTe2 films corroborates the FM ground state, which highlights the unique interplay of ferromagnetism and electronic structure in CrTe2. In addition, the calculated magnetic moment of Cr is 2.89 μB/atom, in good agreement with the SQUID and XMCD measurements. For a comparison with the ARPES spectra, we also calculated the electronic band structure of 2H-CrTe2, which are different from those observed in the ARPES spectra and the calculated 1T-CrTe2 band structure in the low-energy bands (see Supplementary Fig. 17). Another significant difference between 1T and 2H phase is that the 1T-CrTe2 exhibits a FM ground state along c-axis, while the 2H-CrTe2 is PM as a result of the fully occupied dz2 orbital of tetravalent Cr. The observed FM band structure and FM properties corroborate the 1T phase of the epitaxial CrTe2 films. 

We have further studied the thickness dependence of hole pocket features. The evolution of the band structure for the films with a thickness ranging from 1 ML to 15 ML is shown in Fig. 5f. For the 1 ML film, there are two parabolic bands with a maximum above and below the Fermi level, respectively. When film thickness increases to 2 ML, one of the parabolic band overlaps with another one near the Fermi level, sharing similar feature with the case of few-layer ZrTe2<sup>57</sup> and HfTe2<sup>60</sup> . With further increasing 

6 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 



Fig. 5 Band structure of CrTe2 ultrathin films. a, b Plots of valence-band dispersion (a) and the first-principles calculations (b) of 7 ML CrTe2 with the inclusion of spin polarization along the high symmetry direction M-Г-K. The minority and majority spin bands are plotted in red and blue colors, respectively. The major features seen in the left panel are well reproduced in the right one. c–e Comparison of the valence-band dispersion near the Fermi level taken by He Iα (21.2 eV) (c), He IIα photons (40.8 eV) (d) with theoretical bands (e) along the high symmetry direction M-Г-M. The blue and red dashed lines indicate the position of hole pockets measured by He Iα and He IIα photons, respectively. The light blue/red markers represent the positions of MDC peaks. The error bars represent uncertainties in locating peak positions. f ARPES intensity maps of 1 ML, 2 ML, 3 ML, 5 ML, 7 ML, and 15 ML, respectively. The spectra of various thicknesses were taken along the high symmetry direction M-Г-M. 

the film thickness, the Fermi level moves towards the valence band with the band shape invariant. To understand the thicknessdependent electronic structure, we carried out first-principles calculations of 1T-CrTe2 with different thicknesses (see Supplementary Fig. 18). There is an excellent agreement between our experiment and theory. In particular, the hole-like band near EF and a relatively flat Cr 3d orbital band are similar to that of calculated 1T-CrTe2 with the inclusion of spin polarization. For the 1 ML film, the two parabolic hole pockets are well reproduced by the majority spin projections of the bands, which highlights the FM nature. These results demonstrate that the epitaxial 1 T structure and ferromagnetism have been established since 1 ML deposition, in line with the corresponding STM images. The layer-by-layer growth mode of the CrTe2 ultrathin films enables us to further explore the interplay between electronic structure and extraordinary magnetic properties on the basis of thin-film electronic devices. 

To summarize, we have successfully synthesized high-quality mono- to few-layer CrTe2 via MBE method, for the first time. The epitaxial CrTe2 ultrathin films with thickness up to 7 ML possess room-temperature intrinsic ferromagnetism, large magnetic moments (~3 μB/atom), strong perpendicular anisotropy and magnetic spin-split band structure. The high TC is preserved with the thickness down to one ML due to the strong magnetic anisotropy and the weak interlayer coupling. The FM CrTe2 films can be employed as a spin injector when hybridized with other 2D materials such as topological insulator and topological 

semimetals for exploring novel spin physics. At the same time, this work provides a tremendous potential for the future 2D magnet-based spintronics technologies, as the films can readily reach wafer size with MBE growth technique. 

### Methods 

Growth of CrTe2/bilayer graphene/SiC(0001) heterostructures. CrTe2 thin films were grown on a bilayer graphene/SiC substrate in an integrated MBE-STM ultrahigh vacuum (UHV) system with base pressure below 2 × 10<sup>−10</sup> mbar. The bilayer graphene was prepared by annealing a 6H SiC(0001) substrate at 1150 °C for 20 s and repeating 30 times. Then, high-purity Cr and Te were evaporated from an electron-beam evaporator and a standard Knudsen cell, with flux of 0.1 Å/min and 6 Å/min, respectively. The temperature of substrate was kept at 375 °C during the growth. The deposition rate of CrTe2 was ~0.73 Å/min as monitored by a quartz oscillator. In order to protect the thin film from contamination and oxidation during XRD, SQUID, XAS, and XMCD measurements, a Te capping layer (~5 nm) was deposited on sample surface after growth. 

Characterizations. High-resolution XRD was performed using MoKα1 radiation (0.70926 Å) which was obtained from a flat perfect crystal Ge monochromator that produced a line beam having angular divergence of in the scattering plane and out of the scattering plane. The measurements were performed by specular reflection and the data were modeled using the reflection amplitudes from the substrate, graphene layers, layers of CrTe2, and its structure factor. The TEM samples were prepared by a lift-out method in a ThermoFisher Scientific Scios focused ion beam (FIB) instrument at room temperature, and imaged in the ThermoFisher Scientific G2 Tecnai F30 FEG high resolution TEM operated at 300 kV. The SiC substrate was tilted to the [100] zone axis and the lattice fringes from both the graphene and the SiC can be clearly resolved. Great care has been taken to reduce the beam damage on the thin film samples both during the FIB lift out and during the sample tilting and high-resolution image acquisition process. The magnetization 

7 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 

measurements were performed by using a Quantum Design SQUID magnetometer with magnetic field up to 7 T. 

X-ray absorption spectroscopy and magnetic circular dichroism. The measurements were performed on beamline I10 at Diamond Light Source, UK, with 100% circularly polarized X-ray perpendicular to the sample plane and parallel to the magnetic field. XAS measurements with total electron yield (TEY) mode were carried out from 5 K to 300 K. By flipping the X-ray helicity at fixed magnetic field of 1 T, we obtained XMCD by taking the difference of XAS, σ<sup>+</sup> - σ<sup>−</sup> . 

Angle-resolved photoemission spectroscopy and scanning tunneling microscopy. After the growth, the CrTe2 films were in-situ transferred under ultra-high vacuum to the ARPES stage. ARPES measurements were performed at 107 K using a SPECS PHOIBOS 150 hemisphere analyzer with a SPECS UVS 300 helium discharge lamp (He Iα = 21.2 eV and He IIα = 40.8 eV). The energy resolution is 40 meV under 107 K. The size of the beam spot on the sample was ~1.5 mm. We didn’t find any change in the observed ARPES spectra when changing the beam position on the sample surface (~ 5 mm × 4 mm), indicative of the homogeneity of grown samples. The topography of the sample surface was mapped in-situ by an Aarhus STM housed in the growth chamber. 

First-principles calculations. First-principles calculations with DFT were performed by using the Vienna ab Initio Simulation Package (VASP) package. We used the Perdew–Burke–Ernzerhof (PBE) form of the exchange correlation functional. All the calculations were performed with a plane-wave cut-off energy of 300 eV on the 11 × 11 × 1 Monkhorst-Pack k-point mesh. The super cell includes CrTe2 layers with varying thicknesses and a vacuum layer of about 20 Å, in order to avoid interactions between the neighboring slabs. CrTe2 with an in-plane lattice constant of 3.81 Å was used. The atomic positions and the out-of-plane lattice constant were optimized by the conjugate gradient method. Calculations of the band structures were performed with the inclusion of SOC. 

### Data availability 

The authors declare that the main data supporting the findings of this study are available within the article and its Supplementary Information files. Extra data are available from the corresponding authors upon reasonable request. 

Received: 16 August 2020; Accepted: 22 March 2021; 



16. Bonilla, M. et al. Strong room-temperature ferromagnetism in VSe2 monolayers on van der Waals substrates. Nat. Nanotechnol. 13, 289–293 (2018). 

17. Ma, Y. D. et al. Evidence of the existence of magnetism in pristine VX2 monolayers (X=S, Se) and their strain-induced tunable magnetic Properties. ACS Nano 6, 1695 (2012). 

18. Wong, P. K. J. et al. Evidence of spin frustration in a vanadium diselenide monolayer magnet. Adv. Mater. 31, 1901185 (2019). 

19. Feng, J. et al. Electronic structure and enhanced charge-density wave order of monolayer VSe2. Nano Lett. 18, 4493–4499 (2018). 

20. Freitas, C. D. et al. Ferromagnetism in layered metastable 1T-CrTe2. J. Phys.: Condens. Matter 27, 176002 (2015). 

21. Sun, X. et al. Room temperature ferromagnetism in ultra-thin van der Waals crystals of 1T-CrTe2. Nano Res 13, 3358–3363 (2020). 

22. Purbawati, A. et al. In-plane magnetic domains and Neel-like domain walls in thin flakes of the room temperature CrTe2 van der Waals ferromagnet. ACS Appl. Mater. Inter. 12, 30702–30710 (2020). 

23. Kanazawa, K. et al. Structural and magnetic properties of hexagonal Cr1−δTe films grown on CdTe(001) by molecular beam epitaxy. J. Crys. Grow. 415, 31–35 (2015). 

24. Zhao, D. et al. Observation of unconventional anomalous Hall effect in epitaxial CrTe thin films. Nano Res. 11, 3116–3121 (2017). 

25. Chen, J. et al. Evidence for magnetic skyrmions at the interface of ferromagnet/topological-insulator heterostructures. Nano Lett. 19, 6144–6151 (2019). 

26. Roy, A. & Guchhait, S. Perpendicular magnetic anisotropy and spin glass-like behavior in molecular beam epitaxy grown chromium telluride thin films. ACS nano 9, 3772–3779 (2015). 

27. Wang, Y. et al. Magnetic anisotropy and topological Hall effect in the trigonal chromium tellurides Cr5Te8. Phys. Rev. B 100, 024434 (2019). 

28. Liu, Y. & Petrovic, C. Anomalous Hall effect in the trigonal Cr5Te8 single crystal. Phys. Rev. B 98, 195122 (2018). 

29. Bastos, C. M. O., Besse, R., Da Silva, J. L. F. & Sipahi, G. M. Ab initio investigation of structural stability and exfoliation energies in transition metal dichalcogenides based on Ti-, V-, and Mo-group elements. Phys. Rev. Mater. 3, 044002 (2019). 

30. Freitas, D. C. Antiferromagnetism and ferromagnetism in layered 1T-CrSe2 with V and Ti replacements. Phys. Rev. B 87, 014420 (2013). 

31. Li, Y. F. et al. Electronic structure of ferromagnetic semiconductor CrGeTe3 by angle-resolved photoemission spectroscopy. Phys. Rev. B 98, 125127 (2018). 

32. Harrison, R. G. Calculating the spontaneous magnetization and defining the Curie temperature using a positive-feedback model. J. Appl. Phys. 115, 033901 (2014). 

### References 

1. Mermin, N. D. & Wagner, H. Absence of ferromagnetism or antiferromagnetism in one- or two-dimensional isotropic Heisenberg models. Phys. Rev. Lett. 17, 1133–1136 (1966). 

2. Gibertini, M., Koperski, M., Morpurgo, A. F. & Novoselov, K. S. Magnetic 2D materials and heterostructures. Nat. Nanotechnol. 14, 408–419 (2019). 

3. Huang, B. et al. Layer-dependent ferromagnetism in a van der Waals crystal down to the monolayer limit. Nature 546, 270–273 (2017). 

4. Gong, C. et al. Discovery of intrinsic ferromagnetism in two-dimensional van der Waals crystals. Nature 546, 265–269 (2017). 

5. Song, T. et al. Giant tunneling magnetoresistance in spin-filter van der Waals heterostructures. Science 360, 1214–1218 (2018). 

6. Zhong, D. et al. Van der Waals engineering of ferromagnetic semiconductor heterostructures for spin and valleytronics. Sci. Adv. 3, e1603113 (2017). 

7. Seyler, K. L. et al. Ligand-field helical luminescence in a 2D ferromagnetic insulator. Nat. Phys. 14, 277–281 (2017). 

8. Wang, Z. et al. Electric-field control of magnetism in a few-layered van der Waals ferromagnetic semiconductor. Nat. Nanotechnol. 13, 554–559 (2018). 

9. Jiang, S., Shan, J. & Mak, K. F. Electric-field switching of two-dimensional van der Waals magnets. Nat. Mater. 17, 406–410 (2018). 

10. Shabbir, B. et al. Long range intrinsic ferromagnetism in two dimensional materials and dissipationless future technologies. Appl. Phys. Rev. 5, 041105 (2018). 

11. May, A. F., Calder, S., Cantoni, C., Cao, H. & McGuire, M. A. Magnetic structure and phase stability of the van der Waals bonded ferromagnet Fe3−xGeTe2. Phys. Rev. B 93, 014411 (2016). 

12. Liu, S. et al. Wafer-scale two-dimensional ferromagnetic Fe3GeTe2 thin films grown by molecular beam epitaxy. Npj 2D Mater. Appl 1, 30 (2017). 

13. Liu, W. et al. Enhancing magnetic ordering in Cr-doped Bi2Se3 using high-TC ferrimagnetic insulator. Nano Lett. 15, 764–769 (2015). 

14. He, Q. L. et al. Tailoring exchange couplings in magnetic topologicalinsulator/antiferromagnet heterostructures. Nat. Mater. 16, 94–100 (2017). 

15. Deng, Y. et al. Gate-tunable room-temperature ferromagnetism in twodimensional Fe3GeTe2. Nature 563, 94–99 (2018). 

33. Ikeda, S. et al. A perpendicular-anisotropy CoFeB-MgO magnetic tunnel junction. Nat. Mater. 9, 721–724 (2010). 

34. Wu, Y., Xu, X. G., Miao, J. & Jiang, Y. Perpendicular magnetic anisotropy in co-based full heusler alloy. Thin Films. Spin 5, 1540012 (2016). 

35. Richter, N. et al. Temperature-dependent magnetic anisotropy in the layered magnetic semiconductors CrI3 and CrBr3. Phys. Rev. Mater. 2, 024004 (2018). 

36. Yakushiji, K. et al. Ultrathin Co/Pt and Co/Pd superlattice films for MgObased perpendicular magnetic tunnel junctions. Appl. Phys. Lett. 97, 232508 (2010). 

37. Mogi, M. et al. Ferromagnetic insulator Cr2Ge2Te6 thin films with perpendicular remanence. APL Mater. 6, 091104 (2018). 

38. Wu, F. et al. Epitaxial Mn2.5Ga thin films with giant perpendicular magnetic anisotropy for spintronic devices. Appl. Phys. Lett. 94, 122503 (2009). 

39. Emori, S. & Beach, G. S. D. Optimization of out-of-plane magnetized Co/Pt multilayers with resistive buffer layers. J. Appl. Phys. 110, 033919 (2011). 

40. Lado, J. L. & Fernández-Rossier, J. On the origin of magnetic anisotropy in two dimensional CrI3. 2D Mater. 4, 035002 (2017). 

41. Lau, Y.-C. et al. Giant perpendicular magnetic anisotropy in Ir/Co/Pt multilayers. Phys. Rev. Mater. 3, 104419 (2019). 

42. Fei, Z. et al. Two-dimensional itinerant ferromagnetism in atomically thin Fe3GeTe2. Nat. Mater. 17, 778–782 (2018). 

43. Tan, C. et al. Hard magnetic properties in nanoflake van der Waals Fe3GeTe2. Nat. Commun. 9, 1554 (2018). 

44. Zeisner, J. et al. Magnetic anisotropy and spin-polarized two-dimensional electron gas in the van der Waals ferromagnet Cr2Ge2Te6. Phys. Rev. B 99, 165109 (2019). 

45. Dieny, B. & Chshiev, M. Perpendicular magnetic anisotropy at transition metal/oxide interfaces and applications. Rev. Mod. Phys. 89, 025008 (2017). 

46. Lee, A. J. et al. Interfacial Rashba-effect-induced anisotropy in nonmagneticmaterial-ferrimagnetic-insulator bilayers. Phys. Rev. Lett. 124, 257202 (2020). 

47. Fujisawa, Y. et al. Tailoring magnetism in self-intercalated Cr1+δTe2 epitaxial films. Phys. Rev. Mater. 4, 114001 (2020). 

48. Ye, M. et al. Carrier-mediated ferromagnetism in the magnetic topological insulator Cr-doped (Sb,Bi)2Te3. Nat. Commun. 6, 8913 (2015). 

8 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-22777-x 

49. Hu, T., Li, R. & Dong, J. Characterization of few-layer 1T-MoSe2 and its superior performance in the visible-light induced hydrogen evolution reaction. J. Chem. Phys. 139, 174702 (2013). 

50. Otero Fumega, A., Phillips, J. & Pardo, V. Controlled two-dimensional ferromagnetism in 1T–CrTe2: the role of charge density wave and strain. J. Phys. Chem. C. 124, 21047–21053 (2020). 

51. Noh, H. J. et al. Valence values of the cations in selenospinel Cu(Cr,Ti)2Se4. EPL 78, 27004 (2007). 

52. Chen, C. T. et al. Experimental confirmation of the X-ray magnetic circular dichroism sum rules for iron and cobalt. Phys. Rev. Lett. 75, 152–155 (1995). 

53. van der Laan, G. & Thole, B. T. Strong magnetic x-ray dichroism in 2p absorption spectra of 3dtransition-metal ions. Phys. Rev. B 43, 13401–13411 (1991). 

54. Liu, W. et al. Atomic-scale magnetism of Cr-Doped Bi2Se3 thin film topological insulators. ACS nano 9, 10237–10243 (2015). 

55. Liu, W. Q. et al. Atomic-scale interfacial magnetism in Fe/graphene heterojunction. Sci. Rep. 5, 11911 (2015). 

56. Liu, W. et al. Experimental observation of dual magnetic states in topological insulators. Sci. Adv. 5, eaav2088 (2019). 

57. Tsipas, P. et al. Massless dirac fermions in ZrTe2 semimetal grown on InAs (111) by van der Waals epitaxy. ACS nano 12, 1696–1703 (2018). 

58. Belopolski, I. et al. Discovery of topological Weyl fermion lines and drumhead surface states in a room temperature magnet. Science 365, 1278–1281 (2019). 

59. Wang, Y. et al. Evidence of charge density wave with anisotropic gap in a monolayer VTe2 film. Phys. Rev. B 100, 241404 (2019). 

60. Aminalragia-Giamini, S. et al. Molecular beam epitaxy of thin HfTe2 semimetal films. 2D Mater. 4, 015001 (2016). 

Taiwan. This work is also partially supported by the MOST, Taiwan, Grant MOST1072627-E-006-001 and by Higher Education Sprout Project, Ministry of Education to the Headquarters of University Advancement at National Cheng Kung University (NCKU). 

### Author contributions 

Y.X., G.B., R.Z., and L.H. planned the project. X.Z. and Q.L. synthesized CrTe2 thin films. Q.L., X.Z., and J.C. conducted the ARPES and STM experiments and analyzed the data. W.L., J.S., W.N., and J.D. performed XMCD and SQUID measurements and analyzed the data. Q.L., S.-W.L., T.-R.C., and D.J.S. did the DFT calculations. P.M. and M.V. conducted XRD measurements. X.H. performed the TEM characterizations. X.Z., Q.L., D.J.S., and G.B. wrote the paper. All the authors discussed the results and commented on the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-22777-x. 

Correspondence and requests for materials should be addressed to L.H., R.Z., G.B. or Y.X. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

### Acknowledgements 

This work is supported by the National Key Research and Development Program of China (No. 2016YFA0300803, No. 2017YFA0206304), the National Basic Research Program of China (No. 2014CB921101), the National Natural Science Foundation of China (No. 61427812, 11774160, 11574137, 61474061, 61674079, 11904174), Jiangsu Shuangchuang Program, the Natural Science Foundation of Jiangsu Province of China (No. BK20140054, BK20190729), NUPTSF (Grant No. NY219024), the Natural Science Foundation of the Jiangsu Higher Education Institutions of China (19KJB510047), UK EPSRC (EP/S010246/1), leverhulme Trust (LTSRF1819\15\12), and Royal Society (IEC \NSFC\181680). G.B. is supported by the US National Science Foundation (NSFDMR#1809160). Work of David Singh is supported by the U.S. Department of Energy, Basic Energy Sciences, Award Number DE-SC0019114. Diamond Light Source is acknowledged to I10 under proposal MM22532. T.-R.C. is supported by the Young Scholar Fellowship Program from the Ministry of Science and Technology (MOST) in Taiwan, under a MOST grant for the Columbus Program MOST108-2636- M-006-002, National Cheng Kung University, Taiwan, and National Center for Theoretical Sciences, 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

9 

NATURE COMMUNICATIONS | (2021) 12:2492 | https://doi.org/10.1038/s41467-021-22777-x | www.nature.com/naturecommunications 

