# Spontaneous Anomalous Hall Effect Arising from an Unconventional Compensated Magnetic Phase in a Semiconductor.

| 字段 | 内容 |
|---|---|
| 期刊 | Physical Review Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 378 |
| 作者 | R. D. Gonzalez Betancourt, J. Zubáč, R. Gonz'alez-Hern'andez, K. Geishendorf, Z. Šobáň, G. Springholz, K. Olejník, L. Šmejkal et al. |
| DOI | 10.1103/PhysRevLett.130.036702 |
| 源文件 | 035_Betancourt_2021_Spontaneous-Anomalous-Hall-Effect-Arising-from-a.pdf |

---
# **Spontaneous anomalous Hall effect arising from an unconventional** 

# **compensated magnetic phase in a semiconductor** 

R. D. Gonzalez Betancourt,<sup>1, 2, 3,</sup><sup>_∗_</sup> J. Zubáč,<sup>2, 4,</sup><sup>_∗_</sup> R. Gonzalez-Hernandez,<sup>5,</sup><sup>_†_</sup> 

K. Geishendorf,<sup>2</sup> Z. Šobáň,<sup>2</sup> G. Springholz,<sup>6</sup> K. Olejník,<sup>2</sup> 

L. Šmejkal,<sup>7, 2</sup> J. Sinova,<sup>7, 2</sup> T. Jungwirth,<sup>2, 8</sup> S. T. B. Goennenwein,<sup>9, 1</sup> 

A. Thomas,<sup>1, 3</sup> H. Reichlová,<sup>1</sup> J. Železný,<sup>2</sup> and D. Kriegner<sup>1, 2,</sup><sup>_‡_</sup> 

> 1 _Institute of Solid State and Materials Physics, Technical University Dresden, 01062 Dresden, Germany_ 

> 2 _Institute of Physics, Academy of Sciences of the Czech Republic, Cukrovarnická 10, 162 00 Praha 6, Czech Republic_ 

> 3 _Leibniz Institute of Solid State and Materials Research (IFW Dresden), Helmholtzstr. 20, 01069 Dresden, Germany_ 

> 4 _Charles University, Faculty of Mathematics and Physics, Ke Karlovu 3, 121 16 Prague 2, Czech Republic_ 

> 5 _Departamento de Fisica y Geociencias, Universidad del Norte, Barranquilla 080020, Colombia_ 

> 6 _Institute of Semiconductor and Solid State Physics,_ 

_Johannes Kepler University Linz, Altenbergerstr. 69, 4040 Linz, Austria_ 

> 7 _Institut für Physik, Johannes Gutenberg Universität Mainz, 55128 Mainz, Germany_ 

> 8 _School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, United Kingdom_ 

> 9 _Department of Physics, University of Konstanz, 78457 Konstanz, Germany_ 

(Dated: January 24, 2023) 

1 

# Abstract 

The anomalous Hall effect, commonly observed in metallic magnets, has been established to originate from the time-reversal symmetry breaking by an internal macroscopic magnetization in ferromagnets or by a non-collinear magnetic order. Here we observe a spontaneous anomalous Hall signal in the absence of an external magnetic field in an epitaxial film of MnTe, which is a semiconductor with a collinear antiparallel magnetic ordering of Mn moments and a vanishing net magnetization. The anomalous Hall effect arises from an unconventional phase with strong time-reversal symmetry breaking and alternating spin polarization in real-space crystal structure and momentum-space electronic structure. The anisotropic crystal environment of magnetic Mn atoms due to the non-magnetic Te atoms is essential for establishing the unconventional phase and generating the anomalous Hall effect. 

The ordinary and anomalous Hall effects are prominent phenomena in condensed matter physics and spintronics that refer to a non-dissipative current, **j** H = **h** _×_ **E** , generated in a transverse direction to the applied electric field **E** [1, 2]. The corresponding antisymmetric transverse components of the conductivity tensor, _σij_<sup>a=</sup><sup>_−σ_</sup> _ji_<sup>a,formapseudo-vector</sup><sup>**h**=</sup> ( _−σyz_<sup>a</sup><sup>_, σ_</sup> _xz_<sup>a</sup><sup>_, −σ_</sup> _xy_<sup>a)whosecomponentsflipsignunderthetime-reversaltransformation(</sup><sup>_T_)</sup> [1, 2]. In the ordinary Hall effect, **h** is typically proportional to an applied external magnetic field that breaks the _T_ -symmetry and couples to the electronic degrees of freedom via the Lorentz force. In contrast, the anomalous Hall effect (AHE) reflects the _T_ -symmetry breaking in the crystal and electronic structure associated with an internal magnetic order in a material [1, 2]. The AHE can, therefore, generate a spontaneous Hall signal even in the absence of an external magnetic field. It is established that the AHE can arise from a macroscopic magnetization in ferromagnets, or a non-collinear order of spins on certain lattices of magnetic atoms [1, 2]. 

Following a prediction for RuO2 [3], the research of the AHE has recently turned to materials belonging to the abundant family of crystals with compensated collinear antiparallel ordering of spins [3–7], for which the AHE and other _T_ -symmetry breaking spintronic phenomena have been traditionally considered to be excluded due to the vanishing net magnetization [2]. The surprising emergence of the _T_ -symmetry breaking responses in these compensated magnetic crystals has been recently ascribed to an unconventional magnetic phase [7, 8]. It is characterized by an alternating spin polarization in both real-space 

2 

crystal structure and momentum-space electronic structure, which has suggested to term this unconventional phase altermagnetism [7, 8]. Crystals hosting altermagnetism have the opposite-spin sublattices connected by crystal rotation transformations (proper or improper and symmorphic or non-symmorphic). In contrast, conventional antiferromagnets are characterized by the translation or inversion symmetry connecting the opposite-spin sublattices [9, 10]. A systematic symmetry based classification and description of this unconventional magnetic phase has been developed using a non-relativistic spin-group formalism [7, 8]. 

RuO2 is a prominent member of the altermagnetic family because of its metallic conduction combined with magnetic ordering above room temperature [11, 12], and because of the presence of the AHE [3, 13] and of non-relativistic spin splitting, charge-spin conversion and giant magnetoresistive phenomena [3, 13–21]. Moreover, RuO2 is a representative of the specific sub-class of altermagnets in which an anisotropic arrangement of non-magnetic atoms in the crystal (O-atoms in RuO2) breaks the inversion and translation symmetry, while preserving the rotation symmetry, connecting the opposite-spin sublattices. Because of the essential role of non-magnetic atoms, the AHE in materials like RuO2 has been referred to as originating from a crystal _T_ -symmetry breaking mechanism [3, 4, 6]. 

Transport measurements in RuO2 have confirmed the presence of the AHE signals [13]. However, the experiments relied on an externally applied magnetic field that served as a tool for reorienting the magnetic order vector from the [001] easy axis. Incidentally, this magnetic easy axis is a singular direction of the magnetic order vector in RuO2 for which the AHE vanishes by symmetry [3, 13]. 

In this Letter we report the experimental observation of the AHE in thin-film _α_ -MnTe with a room temperature compensated collinear magnetic order [22]. Despite the extensive exploration of MnTe in the past [13, 15, 22–25, 27, 29, 30], the AHE has not been theoretically or experimentally identified in this material prior to our work. We highlight that the MnTe structure shares with RuO2 the essential role of non-magnetic atoms (Te atoms in case of MnTe) in the formation of the altermagnetic phase, and the corresponding _T_ -symmetry breaking phenomena, including the AHE. In contrast to RuO2, our measurements in MnTe show hysteresis and spontaneous AHE signals at zero magnetic field. By symmetry analysis and density functional theory (DFT) calculations we show that the spontaneous nature of the AHE results from the favorable magnetic easy axes in our MnTe thin-film. 

The other major distinction of MnTe from metallic RuO2 and common ferromagnets or 

3 

non-collinear magnets with metallic conduction is that stoichiometric MnTe is an intrinsic room-temperature magnetic semiconductor [12–14, 22, 24]. The prospect of integrating _T_ - symmetry breaking spintronic phenomena with field-effect transistor functionalities in one material has driven the research of ferromagnetic semiconductors for decades, in particular of the III-V compounds that become ferromagnetic when heavily doped with Mn [33–35]. However, the required heavy charge dopings compromise the semiconducting nature of the host compounds, while the ferromagnetic transition temperatures have remained well below room temperature, i.e. far below the Curie temperatures of common transition-metal ferromagnets. Our observation of the AHE in MnTe demonstrates that altermagnetism can remove the roadblock associated with the notorious incompatibility of robust high-temperature ferromagnetism with semiconducting (insulating) band structures. 

A schematic crystal of _α_ -MnTe with NiAs structure (crystallographic space group _P_ 63 _/mmc_ #194 [36]) is shown in Fig. 1a. The magnetic moments on Mn have a parallel alignment within the _c_ -planes and an antiparallel alignment between the planes which allows to avoid frustration in the magnetic order. The crystallographic translation or inversion transformations do not connect the opposite spin sublattices because of the non-magnetic Te atoms that occupy non-centrosymmetric positions and form octahedra around the Mn atoms. This symmetry-lowering arrangement of non-magnetic atoms around the magnetic atoms is reminiscent of RuO2 [3]. The specific realization is, however, different. In RuO2, the O octahedra belonging to the opposite-spin sublattices share an edge and the two sublattices are connected by a crystallographic non-symmorphic four-fold rotation _C_ 4 combined with half unit-cell translation. In MnTe, the two opposite-spin sublattices are connected by a non-symmorphic six-fold rotation _C_ 6 combined with half-unit cell translation along the _c_ -axis **t** 1⁄2 (screw-axis), as highlighted by the blue and red shaded face sharing octahedra in Fig. 1a [2, 37]. 

The strong non-relativistic _T_ -symmetry breaking and alternating spin-splitting in the band structure of MnTe, accompanied by zero non-relativistic net magnetization, is described by a spin Laue group<sup>2</sup> 6 _/_<sup>2</sup> _m_<sup>2</sup> _m_<sup>1</sup> _m_ of symmetry transformations in decoupled real and spin space [7]. The spin-group symmetries imply the presence of four spin-degenerate nodal planes crossing the **Γ** -point of the momentum-dependent electronic structure ( _g_ -wave symmetry), corresponding to four mirror-symmetry planes combined with spin-space rotation of the compensated collinear spin arrangement on the real-space MnTe crystal [7]. 

4 



<!-- Start of picture text -->
a b easy axis c<br>no AHE<br>AHE<br>Mn1<br>Te<br>Mn2<br>c<br>a b a,x y b<br>d e<br>band<br>gap<br>yx xy<br><!-- End of picture text -->

FIG. 1. Theoretical calculation of spontaneous anomalous Hall signal in collinear MnTe: (a) Atomic configuration of Mn (blue/red) and Te (gold) with hexagonal NiAs structure. The two magnetic sublattices are connected by a six-fold screw axis along [0001]. (b,c) Magnetic moment configurations of the hexagonal _c_ -planes with magnetic moments (red arrows) oriented along [1<sup>¯</sup> 100] and [2<sup>¯</sup> 1<sup>¯</sup> 10], respectively. The magnetic unit cell shape (black line) and crystal symmetry operations corresponding to the generators of the magnetic point groups are indicated in the panels. Te atoms at different heights are indicated by different color saturation. (d) DFT Anomalous Hall conductivity vs. Fermi energy calculated for the moment configuration of panel (b) and Hall current along _x_ -direction. (e) Transverse conductivity components for the Fermi energy 0.25 eV below the valence band maximum as a function of the Néel vector orientation. The angle _φ_ is defined with respect to the _a_ -axis. 

Besides the _T_ -symmetry breaking, additional symmetry-lowering requirements have to be fulfilled by the magnetic state of the crystal to allow for an Hall pseudo-vector **h** [2]. These requirements are described within the formalism of relativistic magnetic-group symmetries in coupled real and spin space because, in general, the AHE in collinear (coplanar) magnets is observed in the presence of spin-orbit coupling [2]. Whether or not the AHE is allowed by the relativistic magnetic symmetries then depends on the orientation of the magnetic-order 

5 

(Néel) vector with respect to the crystal axes. 

Figures 1b,c show two representative orientations of the Néel vector within the _c_ -plane of MnTe. The first orientation is along the [1<sup>¯</sup> 100] magnetic easy axis in our thin-film [37], which is rotated by _φ_ = 30<sup>_◦_</sup> from the crystallographic _a_ -axis [29, 38]. In this case, the generators of the relativistic magnetic point-group _m_<sup>_′_</sup> _m_<sup>_′_</sup> _m_ are the inversion _P_ , a two-fold rotation _C_ 2 around the _c_ -axis, and a mirror perpendicular to the Néel vector combined with time-reversal _MT_ (indicated in Fig. 1b). This is compatible with the presence of the AHE pseudo-vector along the _c_ -axis [2, 3, 37] and therefore enables the detection of a hysteretic AHE signal. In contrast, for the Néel vector along the _a_ -axis ([2<sup>¯</sup> 1<sup>¯</sup> 10]), the generators of the relativistic magnetic point group _mmm_ are inversion _P_ , the two-fold rotation _C_ 2 around _c_ , and a mirror _M_ perpendicular to the Néel vector, which excludes the AHE by symmetry [37]. 

To calculate the intrinsic Berry-curvature anomalous Hall conductivity (AHC) [1, 2], we use the maximally localized Wannier functions based on the DFT framework [37]. The obtained AHC for various Néel vector orientations within the _c_ -plane corroborate our symmetry analysis. For the Néel vector aligned with the easy axis and current along the _a_ -axis, the dependence of the AHC on the Fermi energy is shown in Fig. 1d. AHC values above 300 S/cm are found for states deep in the valance band, while the magnitude diminishes when the Fermi level approaches the valance band edge. Note that for the indices of the components of the AHE pseudo-vector **h** = ( _−σyz_<sup>AHE</sup> _, σxz_<sup>AHE</sup> _, −σxy_<sup>AHE</sup> ), we use a notation in which _x_ corresponds to the crystal _a_ -axis ([2<sup>¯</sup> 1<sup>¯</sup> 10]), _y_ to the [01<sup>¯</sup> 10] crystal axis, and _z_ to the _c_ -axis ([0001]) of MnTe. 

Figure 1e shows the AHC components _σij_<sup>AHE</sup> calculated for a fixed Fermi energy as a function of the Néel vector angle _φ_ in the _c_ -plane measured from the _a_ -axis. Here _i_ labels the Hall current direction and _j_ the applied electric-field direction. As expected from symmetry, _σxy_<sup>AHE</sup> is the only non-zero component of the AHE pseudo-vector, i.e., **h** is parallel to the _c_ -axis and orthogonal to the in-plane Néel vector. This is strikingly distinct from the conventional AHE in ferromagnets where the Hall vector typically aligns with the magnetization order vector [1]. Similarly, it is distinct from the experimentally observed anomalous Hall effect in RuO2, ascribed to the Néel vector component parallel to the Hall vector [13]. The symmetry restrictions of MnTe also force _σxy_<sup>AHE</sup> ( _φ_ ) to zero every 60 degrees, when the Néel vector is aligned along the _a_ -axis or equivalent axes in the _c_ -plane. 

6 

For the AHE measurements, we have prepared epitaxial thin films of _α_ -MnTe by molecular beam epitaxy on a single-crystal InP(111)A substrate at a substrate temperature of 380<sup>_◦_</sup> C using Mn and Te beam flux sources. Reflection high energy electron diffraction and X- ray diffraction data indicate two-dimensional layer-by-layer growth, high crystallographic quality, and film thickness of 48 nm [37]. For the growth on InP(111)A, the epitaxial relationship is (0001) [1<sup>¯</sup> 100]MnTe _∥_ (111) [11<sup>¯</sup> 2]InP, which allows us to perform the desired AHE transport measurements in the _c_ -plane. Charge transport in our thin films is enabled by unintentional p-type doping commonly observed in MnTe [14, 39]. Details of the growth, transmission electron microscopy, and neutron diffraction studies of our films are described by Kriegner and coworkers [22, 29]. 

Hall bar microdevices, shown in Fig. 2a, were fabricated using electron beam lithography, argon milling, and Cr/Au contacts produced by a lift-off process. The Hall bar is along the _y_ -axis ([01<sup>¯</sup> 10]), and the magnetic field is applied in the [01<sup>¯</sup> 10] _−_ [0001] plane at an angle _β_ measured from the Hall-bar direction. In our semiconducting MnTe, the transverse resistivity plotted in Fig. 2b is dominated by the ordinary Hall contribution that is a linear function of the out-of-plane ([0001]) component of the applied magnetic field. The hole concentration and mobility inferred from the measurements in Fig. 2 by assuming a single band picture are 4 _._ 9 _×_ 10<sup>18</sup> cm<sup>_−_3</sup> and 29 cm<sup>2</sup> /Vs, consistent with the semiconducting character of MnTe and with a Fermi level within _∼_ 20 meV from the valance band edge. 

Besides the dominant ordinary Hall signal, the transverse resistivity in Fig. 2b contains an anomalous contribution, as seen from the hysteresis with different zero-field spontaneous Hall signals for the opposite field-sweep directions. In contrast, such a hysteretic behavior is absent in the longitudinal resistivity measurement, as shown in Fig. 2c. The anomalous Hall signal _ρ_<sup>AHE</sup> _yx_ is highlighted in Fig. 2d where we subtracted the ordinary Hall contribution ( _ρ_<sup>OHE</sup> _yx_ ) from the measured transverse resistivity, and where we also removed the even-infield contribution defined as _ρ_<sup>even</sup> _yx_ = [ _⟨ρyx_ ( _H_ ) _⟩_ + _⟨ρyx_ ( _−H_ ) _⟩_ ] _/_ 2. Here _⟨ρyx_ ( _H_ ) _⟩_ = [ _ρyx_ ( _H↑_ ) + _ρyx_ ( _H↓_ )] _/_ 2, and _H↑_ ( _↓_ ) refers to the measurement at the negative-to-positive (positive-tonegative) field sweep [37]. 

The hysteresis and the opposite zero-field spontaneous Hall signals for opposite fieldsweep directions are well pronounced in _ρ_<sup>AHE</sup> _yx_ when the applied magnetic field contains an out-of-plane component. This is again explained by symmetry. MnTe can have a weak relativistic magnetization due to terms in the thermodynamic potential that couple the weak 

7 



<!-- Start of picture text -->
||z<br>a z b β<br>y<br>||y<br>x V j || y<br>500 μm<br>V<br>c d<br><!-- End of picture text -->



FIG. 2. Magnetic field sweep measurements and AHE at _T_ = 150 K. (a) Microscopy image of the Hall bar together with electrical schematics of our measurement. For all transport measurements a moderate current density _j ∼_ 8 _·_ 10<sup>6</sup> A/m<sup>2</sup> was used. (b,c) Transverse and longitudinal resistivities measured during magnetic field sweeps in a geometry indicated by the sketch in (b). (d) Inferred anomalous Hall resistivity given by, _ρ_<sup>AHE</sup> _yx ≡ ρyx − ρ_<sup>OHE</sup> _yx − ρ_<sup>even</sup> _yx_ (see text). 

magnetization to the Néel vector [40]. The allowed presence of the weak magnetization in zero magnetic field requires in our MnTe the same symmetry lowering as the spontaneous AHE because both effects are described by a pseudo-vector that is odd under _T_ [2]. For the Néel vector in the _c_ -plane of MnTe, the anomalous Hall and the weak magnetization pseudo-vectors align with the _c_ -axis. Except when the Néel vector is parallel to the _a_ -axis or the other equivalent axes for which both effects vanish by symmetry. When an applied out-of-plane magnetic field reverses the weak magnetization, symmetry implies that the 

8 

Néel vector is also forced via the coupling in the thermodynamic potential to reverse, which results in the flip of the sign of the AHE. 

The presence of the in-plane component of the magnetic field in our measurements is favorable for maximizing the observed _ρ_<sup>AHE</sup> _yx_ because of the repopulation of domains with the Néel vectors aligned with the three equivalent zero-field easy axes. The repopulation, i.e., the in-plane Néel vector reorientation occurs for in-plane fields above the spin-flop transition which is around 2 T [37]. As a result, the measured AHE at saturation is maximized for _β_ = 60<sup>_◦_</sup> , while _β_ = 90<sup>_◦_</sup> gives the lowest saturation field (see Fig. 2d). 

Note that the decisive role of the out-of-plane field component for determining the sign of the spontaneous and saturated AHE signal is particularly visible for _ρ_<sup>AHE</sup> _yx_ traces recorded at _β_ = _±_ 30<sup>_◦_</sup> . While the in-plane component of the field is the same in both of these fieldsweep traces, the out-of-plane components have the opposite sign and, correspondingly, the measured hysteretic _ρ_<sup>AHE</sup> _yx_ also flips sign between the two traces. When removing the magnetic field, some domain randomization occurs due to magnetostriction [22]. This causes a reduction of the spontaneous zero-field AHE signal as compared to the saturated value (Fig. 2d). 

We also point out that while the weak magnetization facilitates the reversal of the sign of _ρ_<sup>AHE</sup> _yx_ by the out-of-plane component of the applied magnetic field, the AHE is not a consequence of the weak magnetization, as discussed in detail by L. Šmejkal and coworkers [2, 3]. The principle origin of the AHE is the _T_ -symmetry breaking due to the compensated antiparallel magnetic order on Mn atoms and the anisotropic crystal environment due to the Te atoms. The relativistic spin-orbit interaction then couples this strong _T_ -symmetry breaking to the charge Hall transport and, analogous but not as a consequence of the other, can also generate the weak magnetization [2, 3]. 

Measurements of the magnetization, shown in Fig. 3a, are consistent with the above origin of the spontaneous AHE in MnTe, and contrast with the conventional magnetizationinduced AHE in ferromagnets. We performed the magnetization measurements using the superconducting quantum interference device (SQUID) technique. The raw SQUID signal is dominated by the diamagnetic contribution from the substrate. After subtracting a linear background, we observe that the remanent out-of-plane magnetization, albeit allowed by symmetry and estimated to be _∼_<sup>_<_</sup> 2 _×_ 10<sup>_−_4</sup> _µ_ B/Mn from first principle calculations, is unobservable even within the high-resolution of the employed SQUID technique. This con- 

9 

trasts with the clearly observable spontaneous zero-field signals and hysteresis in the AHE measurements. Note that for in-plane magnetic fields, the kink found in the in-plane magnetization between 2 and 3 T (Fig. 3a) marks the spin-flop reorientation field of the Néel vector into an in-plane direction orthogonal to the applied field. This is visible for any inplane direction since three equivalent easy axes exist in the basal plane [29]. First principle calculations let us also exclude the weak magnetization as source for the found AHE since significantly larger magnetization would be needed to yield a sizable AHE. 

In Fig. 3b we show the conversion of _ρ_<sup>AHE</sup> _yx_ at 175 and 300 K, and _β_ = 30<sup>_◦_</sup> into the anomalous Hall conductivity _σxy_<sup>AHE</sup> . The temperature-dependent saturated and spontaneous AHE conductivity signals shown in Figs. 3c,d were extracted from _σxy_<sup>AHE</sup> as indicated in Fig. 3b. As expected for the AHE, they vanish when approaching the MnTe Néel temperature of 310 K. The complex temperature dependence below the Néel temperature can be governed by a combination of the variation of the longitudinal resistivity [15, 37], the achievable degree of polarization of the system, as well as a potential variation of the Fermi level. Nevertheless the measured magnitude of _σxy_<sup>AHE</sup> is within the scale predicted by our DFT calculations for the Fermi level on the order of _∼_ 20 meV below the valence-band edge, consistent with the hole density inferred from the ordinary Hall signal and using finite band broadening [37]. 

Finally, we note that hysteretic and spontaneous AHE signals are also found for the electrical current applied along the in-plane _a_ -axis ([2<sup>¯</sup> 1<sup>¯</sup> 10]). This is consistent with the outof-plane _c_ -axis orientation of the AHE pseudo-vector that allows for the AHE detection with any in-plane applied current. 

In conclusion, we have detected a spontaneous AHE in semiconducting MnTe with collinear compensated magnetic order. In magnetic field sweeps, we identify open and saturated hysteresis loops of the AHE signal, consistent with the _T_ -symmetry breaking by the antiparallel order of spins and anisotropic crystal environment in MnTe, and in contrast to the conventional AHE in ferromagnets generated by a macroscopic net magnetization. Our theoretical symmetry analysis and DFT calculations corroborate the experimental results. They confirm the favorable crystallographic orientation of the easy axis (axes) in MnTe films for generating the spontaneous AHE signal. DFT calculations of the intrinsic Berrycurvature contribution to the AHE conductivity are consistent with the measured scale of the AHE signals. Our work opens the prospect of exploring and exploiting _T_ -symmetry breaking phenomena arising from the unconventional altermagnetic phase in semiconductors and 

10 







<!-- Start of picture text -->
||z<br>a b<br>x<br>||y spontaneous AHE<br>c d<br>saturated AHE<br><!-- End of picture text -->





FIG. 3. (a) SQUID magnetization obtained for in-plane and out-of-plane magnetic field measured at 10 K on a 2000 nm thick film. To highlight the absence of remanent magnetization a linear slope obtained in vicinity of zero magnetic field was subtracted from each data set. Note that the slope contains the susceptibility of MnTe as well as the diamagnetic substrate. (b) AHE conductivity _σxy_<sup>AHE</sup> obtained from the measured _ρ_<sup>AHE</sup> _yx_ at 175 and 300 K, and _β_ = 30<sup>_◦_</sup> . (c,d) Temperature dependence of the spontaneous zero-field and saturated AHE conductivity. 

insulators. 

We acknowledge M. Rahn for his support with the crystal direction determination. This work was supported in part by the Ministry of Education of the Czech Republic Grants LM2018110 and LNSM-LNSpin, by the Grant Agency of the Czech Republic Grant No. 22-22000M, by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) - TRR 173/2 SPIN+X - 268565370 (project A03), by the French national research agency 

11 

(ANR) (Project MATHEEIAS, Grant No. 445976410), by the Austrian Science Funds - Project P30960-N27, and by the EU FET Open RIA Grant No. 766566. Part of the experiments were performed at MGML (mgml.eu), which is supported within the program of Czech Research Infrastructures (Project No. LM2018096). D.K. acknowledges the support by the Lumina fellowship LQ100102201 of the Czech Academy of Sciences. We acknowledge the computing time granted on the supercomputer Mogon at Johannes Gutenberg University Mainz (hpc.uni-mainz.de). 

- _∗_ R.D.G.B. and J.Z. contributed equally to this work 

- rhernandezj@uninorte.edu.co 

- kriegner@fzu.cz 

- [1] N. Nagaosa, J. Sinova, S. Onoda, A. H. MacDonald, and N. P. Ong, Anomalous Hall effect, Reviews of Modern Physics **82** , 1539 (2010). 

- [2] L. Šmejkal, A. H. MacDonald, J. Sinova, S. Nakatsuji, and T. Jungwirth, Anomalous Hall antiferromagnets, Nature Reviews Materials 10.1038/s41578-022-00430-3 (2022). 

- [3] L. Šmejkal, R. González-Hernández, T. Jungwirth, and J. Sinova, Crystal time-reversal symmetry breaking and spontaneous Hall effect in collinear antiferromagnets, Science Advances **6** , eaaz8809 (2020). 

- [4] K. Samanta, M. Ležaić, M. Merte, F. Freimuth, S. Blügel, and Y. Mokrousov, Crystal Hall and crystal magneto-optical effect in thin films of SrRuO3, Journal of Applied Physics **127** , 213904 (2020). 

- [5] M. Naka, S. Hayami, H. Kusunose, Y. Yanagi, Y. Motome, and H. Seo, Anomalous Hall effect in kappa-type organic antiferromagnets, Physical Review B **102** , 075112 (2020). 

- [6] I. I. Mazin, K. Koepernik, M. D. Johannes, R. González-Hernández, and L. Šmejkal, Prediction of unconventional magnetism in doped FeSb2, Proceedings of the National Academy of Sciences **118** , e2108924118 (2021). 

- [7] L. Šmejkal, J. Sinova, and T. Jungwirth, Altermagnetism: Spin-momentum locked phase protected by non-relativistic symmetries (2021), arXiv:2105.05820 [cond-mat]. 

- [8] L. Šmejkal, J. Sinova, and T. Jungwirth, Emerging research landscape of altermagnetism (2022), arXiv:2204.10844 [cond-mat]. 

12 

- [9] A. S. Núñez, R. A. Duine, P. Haney, and A. H. MacDonald, Theory of spin torques and giant magnetoresistance in antiferromagnetic metals, Physical Review B **73** , 214426 (2006). 

- [10] L. Šmejkal, J. Železný, J. Sinova, and T. Jungwirth, Electric Control of Dirac Quasiparticles by Spin-Orbit Torque in an Antiferromagnet, Physical Review Letters **118** , 106402 (2017). 

- [11] T. Berlijn, P. C. Snijders, O. Delaire, H.-D. Zhou, T. A. Maier, H.-B. Cao, S.-X. Chi, M. Matsuda, Y. Wang, M. R. Koehler, P. R. C. Kent, and H. H. Weitering, Itinerant Antiferromagnetism in RuO2, Physical Review Letters **118** , 077201 (2017). 

- [12] Z. H. Zhu, J. Strempfer, R. R. Rao, C. A. Occhialini, J. Pelliciari, Y. Choi, T. Kawaguchi, H. You, J. F. Mitchell, Y. Shao-Horn, and R. Comin, Anomalous Antiferromagnetism in Metallic RuO2 Determined by Resonant X-ray Scattering, Physical Review Letters **122** , 017202 (2019). 

- [13] Z. Feng, X. Zhou, L. Šmejkal, L. Wu, Z. Zhu, H. Guo, R. González-Hernández, X. Wang, H. Yan, P. Qin, X. Zhang, H. Wu, H. Chen, Z. Xia, C. Jiang, M. Coey, J. Sinova, T. Jungwirth, and Z. Liu, Observation of the Anomalous Hall Effect in a Collinear Antiferromagnet (2020), arXiv:2002.08712 [cond-mat, physics:physics, physics:quant-ph]. 

- [14] K.-H. Ahn, A. Hariki, K.-W. Lee, and J. Kuneš, Antiferromagnetism in RuO2 as d-wave Pomeranchuk instability, Physical Review B **99** , 184432 (2019). 

- [15] S. Hayami, Y. Yanagi, and H. Kusunose, Momentum-Dependent Spin Splitting by Collinear Antiferromagnetic Ordering, Journal of the Physical Society of Japan **88** , 123702 (2019). 

- [16] R. González-Hernández, L. Šmejkal, K. Výborný, Y. Yahagi, J. Sinova, T. Jungwirth, and J. Železný, Efficient Electrical Spin Splitter Based on Nonrelativistic Collinear Antiferromagnetism, Physical Review Letters **126** , 127701 (2021). 

- [17] L. Šmejkal, A. B. Hellenes, R. González-Hernández, J. Sinova, and T. Jungwirth, Giant and Tunneling Magnetoresistance in Unconventional Collinear Antiferromagnets with Nonrelativistic Spin-Momentum Coupling, Physical Review X **12** , 011028 (2022). 

- [18] D.-F. Shao, S.-H. Zhang, M. Li, C.-B. Eom, and E. Y. Tsymbal, Spin-neutral currents for spintronics, Nature Communications **12** , 7061 (2021). 

- [19] A. Bose, N. J. Schreiber, R. Jain, D.-F. Shao, H. P. Nair, J. Sun, X. S. Zhang, D. A. Muller, E. Y. Tsymbal, D. G. Schlom, and D. C. Ralph, Tilted spin current generated by the collinear antiferromagnet ruthenium dioxide, Nature Electronics , 1 (2022). 

- [20] H. Bai, L. Han, X. Y. Feng, Y. J. Zhou, R. X. Su, Q. Wang, L. Y. Liao, W. X. Zhu, X. Z. 

13 

Chen, F. Pan, X. L. Fan, and C. Song, Observation of Spin Splitting Torque in a Collinear Antiferromagnet RuO2, Physical Review Letters **128** , 197202 (2022). 

- [21] S. Karube, T. Tanaka, D. Sugawara, N. Kadoguchi, M. Kohda, and J. Nitta, Observation of spin-splitter torque in collinear antiferromagnetic RuO2 (2021), arXiv:2111.07487 [cond-mat]. 

- [22] D. Kriegner, K. Výborný, K. Olejník, H. Reichlová, V. Novák, X. Marti, J. Gazquez, V. Saidl, P. Němec, V. V. Volobuev, G. Springholz, V. Holý, and T. Jungwirth, Multiple-stable anisotropic magnetoresistance memory in antiferromagnetic MnTe, Nature Communications **7** , 11623 (2016). 

- [23] S. Greenwald, The antiferromagnetic structure deformations in CoO and MnTe, Acta Crystallographica **6** , 396 (1953). 

- [24] T. Komatsubara, M. Murakami, and E. Hirahara, Magnetic Properties of Manganese Telluride Single Crystals, Journal of the Physical Society of Japan **18** , 356 (1963). 

- [25] N. Kunitomi, Y. Hamaguchi, and S. Anzai, Neutron diffraction study on manganese telluride, Journal de Physique **25** , 568 (1964). 

- [13] J. W. Allen, G. Lucovsky, and J. C. Mikkelsen, Optical properties and electronic structure of crossroads material MnTe, Solid State Communications **24** , 367 (1977). 

- [27] E. Przeździecka, E. Kamińska, E. Dynowska, R. Butkut˙e, W. Dobrowolski, H. Kępa, R. Jakiela, M. Aleszkiewicz, E. Łusakowska, E. Janik, and J. Kossut, Preparation and characterization of hexagonal MnTe and ZnO layers, physica status solidi (c) **2** , 1218 (2005). 

- [15] Y. Magnin and H. T. Diep, Monte Carlo study of magnetic resistivity in semiconducting MnTe, Physical Review B **85** , 184413 (2012). 

- [29] D. Kriegner, H. Reichlova, J. Grenzer, W. Schmidt, E. Ressouche, J. Godinho, T. Wagner, S. Y. Martin, A. B. Shick, V. V. Volobuev, G. Springholz, V. Holý, J. Wunderlich, T. Jungwirth, and K. Výborný, Magnetic anisotropy in antiferromagnetic hexagonal MnTe, Physical Review B **96** , 214418 (2017). 

- [30] D. Bossini, S. Dal Conte, M. Terschanski, G. Springholz, A. Bonanni, K. Deltenre, F. Anders, G. S. Uhrig, G. Cerullo, and M. Cinchetti, Femtosecond phononic coupling to both spins and charges in a room-temperature antiferromagnetic semiconductor, Physical Review B **104** , 224424 (2021). 

- [12] G. Zanmarchi, Optical measurements on the antiferromagnetic semiconductor MnTe, Journal of Physics and Chemistry of Solids **28** , 2123 (1967). 

14 

- [14] C. Ferrer-Roca, A. Segura, C. Reig, and V. Muñoz, Temperature and pressure dependence of the optical absorption in hexagonal MnTe, Physical Review B **61** , 13679 (2000). 

- [33] H. Ohno, Making Nonmagnetic Semiconductors Ferromagnetic, Science **281** , 951 (1998). 

- [34] T. Dietl and H. Ohno, Dilute ferromagnetic semiconductors: Physics and spintronic structures, Reviews of Modern Physics **86** , 187 (2014). 

- [35] T. Jungwirth, J. Wunderlich, V. Novák, K. Olejník, B. L. Gallagher, R. P. Campion, K. W. Edmonds, A. W. Rushforth, A. J. Ferguson, and P. Němec, Spin-dependent phenomena and device concepts explored in (Ga,Mn)As, Reviews of Modern Physics **86** , 855 (2014). 

- [36] P. Villars and K. Cenzual, MnTe Crystal Structure: Datasheet from "PAULING FILE Multinaries Edition – 2012" in SpringerMaterials (https://materials.springer.com/isp/crystallographic/docs/sd_0379437), Springer-Verlag Berlin Heidelberg & Material Phases Data System (MPDS), Switzerland & National Institute for Materials Science (NIMS), Japan. 

- [37] See Supplemental Material at [URL] for additional experimental data and figures. 

- [38] Note that we use Bravais indices _hkil_ , with _i_ = _−h − k_ for the hexagonal MnTe, while Miller indices _hkl_ are used for the cubic substrate. 

- [39] J. Wasscher, _Electrical Transport Phenomena in MnTe, an Antiferromagnetic Semiconductor_ , Ph.D. thesis, Technische Hogeschool Eindhoven (1969). 

- [40] L. Landau and E. Lifshitz, _Electrodynamics of Continuous Media, Vol. 8 of Course of Theoretical Physics_ , 2nd ed. (Pergamon Press, Oxford, 1984). 

15 

# **Spontaneous anomalous Hall effect arising from an unconventional compensated magnetic phase in a semiconductor** 

# **Supplementary information** 

R. D. Gonzalez Betancourt,<sup>1, 2, 3,</sup><sup>_∗_</sup> J. Zubáč,<sup>2, 4,</sup><sup>_∗_</sup> R. Gonzalez-Hernandez,<sup>5,</sup><sup>_†_</sup> 

K. Geishendorf,<sup>2</sup> Z. Šobáň,<sup>2</sup> G. Springholz,<sup>6</sup> K. Olejník,<sup>2</sup> 

L. Šmejkal,<sup>7, 2</sup> J. Sinova,<sup>7, 2</sup> T. Jungwirth,<sup>2, 8</sup> S. T. B. Goennenwein,<sup>9, 1</sup> 

A. Thomas,<sup>1, 3</sup> H. Reichlová,<sup>1</sup> J. Železný,<sup>2</sup> and D. Kriegner<sup>1, 2,</sup><sup>_‡_</sup> 

> 1 _Institute of Solid State and Materials Physics, Technical University Dresden, 01062 Dresden, Germany_ 

> 2 _Institute of Physics, Academy of Sciences of the Czech Republic, Cukrovarnická 10, 162 00 Praha 6, Czech Republic_ 

> 3 _Leibniz Institute of Solid State and Materials Research (IFW Dresden), Helmholtzstr. 20, 01069 Dresden, Germany_ 

> 4 _Charles University, Faculty of Mathematics and Physics, Ke Karlovu 3, 121 16 Prague 2, Czech Republic_ 

> 5 _Departamento de Fisica y Geociencias,_ 

_Universidad del Norte, Barranquilla 080020, Colombia_ 

> 6 _Institute of Semiconductor and Solid State Physics,_ 

_Johannes Kepler University Linz, Altenbergerstr. 69, 4040 Linz, Austria_ 

> 7 _Institut für Physik, Johannes Gutenberg Universität Mainz, 55128 Mainz, Germany_ 

> 8 _School of Physics and Astronomy, University of Nottingham, Nottingham NG7 2RD, United Kingdom_ 

> 9 _Department of Physics, University of Konstanz, 78457 Konstanz, Germany_ 

(Dated: January 24, 2023) 

16 

## **Magnetic unit cells of MnTe** 

Here we briefly summarize the main symmetry properties for the two magnetic moment configurations shown in Fig. 1b,c of the main text. Figure S1 shows these two collinear magnetic order configurations in 3D. The two magnetic unit cells have the moments oriented along [1<sup>¯</sup> 100] (30 degree rotated from _a_ ) and [2<sup>¯</sup> 1<sup>¯</sup> 10] (along _a_ ) of the paramagnetic hexagonal unit cell. The magnetic cells for both orientations are described by an orthorhombic unit cell, which is a subgroup of the hexagonal paramagnetic cell. The orthorhombic cell has its _a_ and _c_ axis along with the corresponding axis of the crystalline hexagonal cell. Figure S1a with the magnetic moments along the experimentally reported easy axis has magnetic space group symmetry _Cm_<sup>_′_</sup> _c_<sup>_′_</sup> _m_ (#63.462) while the orthogonal arangement of the moments (Fig. S1b) corresponds to _Cmcm_ (#63.457). The difference of the symmetry properties of the unit cells are examplified in Fig. S1 by marked rotation axes. In the case of the easy axis orientation ( _Cm_<sup>_′_</sup> _c_<sup>_′_</sup> _m_ ) a Hall pseudovector can exist along the _c_ axis since the orthogonal rotation axis in combination with the time reversal operation ( _T_ ) leave it unchanged. Note that also all other not indicated symmetry operations do not alter a pseudovector along _c_ . Other components of a pseudovector need to vanish because of the two fold screw axis along _c_ . In contrast no pseudovector components, and therefore no AHE, can exist for the _Cmcm_ symmetry since the three orthogonal rotation axis would always transform any vector into a different state and thereby forcing it to vanish. The difference of the two magnetic symmetries manifests itself also in the fact that only the _Cm_<sup>_′_</sup> _c_<sup>_′_</sup> _m_ symmetry is compatible with ferromagnetism. Note that in addition to the marked rotation axes, the structures contain mirror plane(s) and centers of inversion which do not change the conclusion presented above. 

17 



<!-- Start of picture text -->
easy axis<br>a b no AHE<br>AHE<br>c c<br>a b a b<br>2-fold rotation axis<br>Mn Te magnetic moment 2-fold screw axis<br><!-- End of picture text -->

FIG. S1. Magnetic unit cells of MnTe for two magnetic moment configurations. In panel (a) the magnetic moments are rotated from the hexagonal _a_ -axis by 30 degree. (b) Magnetic moments oriented along the hexagonal _a_ -axis of the crystalline unit cell. The hexagonal crystalline symmetry is reduced to an orthorhombic magnetic unit cell in both cases which is indicated by black lines. A subset of the symmetry operations consisting of two-fold rotation and screw axis are indicated. Vectors _a_ , _b_ , _c_ indicate the magnetic unit cell vectors for the two configurations. Note that _a_ / _c_ of the magnetic orthorhombic and crystalline hexagonal cell coincide. 

## **Spin split band structure of MnTe** 

First-principles calculations based on density-functional theory (DFT) were used to study the electronic structure and transport properties of MnTe. We have used the VASP (Vienna _ab_ - _initio_ simulation package) code [1] and GGA+U (we use _U_ =3.03 eV to reconstruct well previous theory and experimental results[2–4]). The electron wave function was expanded in plane waves up to cut-off energy of 500 eV and a 12 _×_ 12 _×_ 16 _k_ -mesh has been used for the Brillouin-zone integration. By using maximally localized Wannier functions [5, 6], we have found an effective tight-binding Hamiltonian to calculate the anomalous Hall conductivity 

18 

tensor. Integration of the Kubo formula was carried out within a 400<sup>3</sup> _k_ -grid with the Wannier Tools code [7]. 

Our VASP band structure calculations of MnTe are shown in Fig. S2. Along the commonly shown hexagonal high symmetry directions (left panel) in agreement with previously published band structure calculations [3, 8, 9] we find no spin splitting. However, when looking between the Γ and _L_ points a splitting of spin polarized bands is observed which amounts to several 100 meV. It’s this splitting of the spin polarized bands which causes the discussed anomalous Hall effect. 



<!-- Start of picture text -->
a b c<br>2<br>1<br>band<br>* gap<br>0<br>yx xy<br>-1<br>-2<br>*<br><!-- End of picture text -->

FIG. S2. Band structure of MnTe. (a) Calculated bands near the Fermi energy. Along high symmetry directions bands for the two spin channels (shown in blue and red) overlap. The used high symmetry points are labelled in the inset and the band gap of the semiconducting material is marked. (b) Between the Γ and _L_ direction bands for different spin channels show significant splitting. Gray lines in (a,b) shows the band structure calculation including the effect of spin orbit coupling. (c) The energy dependent anomalous Hall conductivity calculated from the shown band structure. 

While the calculated anomalous Hall conductivity is sizable deep in the valence band it approaches zero at the Fermi level. Based on the experimental measurement of the hole concentration, we estimate the Fermi level to be shifted by _∼_ 20 meV from the top of the valence band. This estimate carries some uncertainty, however, since the experimental estimate is based on a single band picture. For this position of the Fermi level we find anomalous Hall conductivity _∼_ 1 S/cm. Taking the uncertainty of the Fermi level position into account, the estimated anomalous Hall conductivity is _∼_ 0 _._ 1 _−_ 10 S/cm. This is a 

19 

calculation of the zero-temperature intrinsic anomalous Hall conductivity, which corresponds to a perfect MnTe crystal. In a real system, there are be impurities and imperfections, which will change the AHE value. This can be simulated by including a band broadening Γ in the calculation. Here we use the Kubo formula derived in Ref. [10] and the code [11]. The result for several values of Γ and for a range of Fermi level values close to the top of the valence band is shown Fig. S3. It is seen that even a modest Γ results in a decrease of the AHE in the whole energy range, bringing the results quite close to the experimentally observed values. 



<!-- Start of picture text -->
2.0<br>= 5 meV<br>1.5 = 10 meV<br>= 50 meV<br>1.0<br>0.5<br>0.0<br>0.5<br>1.0<br>1.5<br>2.0<br>40 30 20 10 0<br>E EF (meV)<br>(S/cm)<br>yx<br>,<br>xy<br><!-- End of picture text -->

FIG. S3. The energy dependent anomalous Hall conductivity obtained for various band broadening values in the vicinity of the Fermi level. 

## **Thin film growth and characterization** 

Epitaxial MnTe layers were grown in a Varian GEN II molecular beam epitaxy system. The films were deposited onto InP(111)A substrates after oxide desorption at a growth temperature of 380 °C. The MnTe growth rate was around 1 Å/sec and an excess Te flux of 1 monolayers/sec was used, with the Mn and Te flux rates calibrated by the quartz microbalance method. The growth was monitored in situ by reflection high-energy electron 

20 

diffraction (RHEED) and the perfectly streaked diffraction patterns indicate a 2D growth of the layer. 

X-ray diffraction data of MnTe thin films on InP(111)A substrate are shown in Fig. S4. A symmetric radial scan shown in Fig. S4a probing the lattice planes parallel to the sample surface finds only _HHH_ and 000 _L_ diffraction maxima of InP and MnTe, respectively. The two-dimensional diffraction intensity around the InP 222 and MnTe 0004 Bragg diffraction peaks is mapped out in Fig. S4b. A low mosaicity of the thin film leads to a narrow peak. The high crystalline quality is evident from the visibility of Laue thickness fringes along the out of plane [0001] direction, which confirm the presence of a coherent lattice over the full film thickness. Fig. S4c shows a line cut through the diffraction map which highlights these thickness fringes and allows us to determine the film thickness which is found to be 48 nm. 

Similar to previous studies we find the longitudinal resistivity with the characteristic temperature variation typical for MnTe (Fig. S5a). Although MnTe is a semiconductor with _∼_ 1 _._ 4 eV band gap [12–14] the resistivity is decreasing below 250 K and only raises again below 50 K. This was previously attributed to spin dependent scattering processes [15]. In our case the decrease of _ρyy_ at temperatures above 250 K is governed by the thermal activation of carriers in the semiconducting InP substrate and can not be solely attributed to the MnTe thin film. Magnetotransport studies therefore focus on lower temperatures where the substrate can be considered isolating. The compensated magnetic nature of these thin films can be seen from the low susceptibility variation shown in Fig. S5b, which only shows a weak anomaly near the expected magnetic transition temperature and is otherwise dominated by the diamagnetic substrate. 

21 



<!-- Start of picture text -->
a 222 333 444<br>0004<br>0008<br>0006<br>b c 222<br>0004<br><!-- End of picture text -->

FIG. S4. X-ray diffraction data of MnTe thin films on InP(111)A substrate. (a) Radial scan evidencing the epitaxial growth of the thin films. Only _HHH_ and 000 _L_ diffraction maxima of InP and MnTe are observed. (b) Reciprocal space map near the 222 InP and 0004 MnTe diffraction maximum. Note that the intensity scale is saturated at the substrate peak. Laue thickness fringes along the out of plane direction are visible. Those are even more evident in a vertical line cut taken in this reciprocal space map, which is shown in panel (c). 

22 



<!-- Start of picture text -->
TN TN<br><!-- End of picture text -->



FIG. S5. Temperature dependent resistivity and DC susceptibility. The bulk Néel temperature _TN_ is indicated at 310 K. The susceptibility measurements were performed on XX nm thick MnTe films in a field of 0.05 T. The upturn in susceptibility at low temperatures can be attributed to paramagnetic oxygen inside the magnetometer or contribution from paramagnetic impurities in the substrate. 

23 

## **Symmetry analysis of the conductivity/resistivity tensor** 

The calculations presented in the main text’s figure 1 only considered the AHE, but in experiments we expect to find also other contributions to the conductivity/resistivity tensor upon a Néel vector rotation. Symmetry considerations outlined below lead us to expect a series of anisotropic magnetoresistance (AMR) contributions. In particular when considering terms up to the sixth-order the conductivity _σyy_ (in the coordinate system of Fig. 1 of the main text) is expected to contain terms proportional to cos _nφ_ , with _n_ = 2 _,_ 4 _,_ 6. The transversal conductivity _σyx_ can contain terms proportional to sin _nφ_ , with _n_ = 2 _,_ 3 _,_ 4. 

To analyze the symmetry of the conductivity tensor, we expand it in the Néel vector **L** : 



<!-- Start of picture text -->
σij ( L ) =  σij (0) +  σ ijk (1) Lk  +  σ ijkl (2) LlLl  +  . . . (1)<br><!-- End of picture text -->

We determine the symmetry of each term in this expansion, using the code Symmetr [16]. In the experiments, **L** is expected to be always in the _ab_ plane and thus can be expressed as **L** _/L_ = (cos( _φ_ ) _,_ sin( _φ_ ) _,_ 0), where _φ_ denotes the angle between the electric field and **L** . Substituting this for **L** we have an expansion in powers of cos( _φ_ ) and sin( _φ_ ). This can be converted to expansion in cos( _nφ_ ) and sin( _nφ_ ), where _n_ are integers. Note that in general terms of _n_ -th order in the powers of cos( _φ_ ) and sin( _φ_ ) expansion correspond to _n_ -th and _lower_ order terms in the cos( _nφ_ ) and sin( _nφ_ ) expansion. Considering current along the _y_ - direction, terms up to sixth order, and separating the components parallel and perpendicular to current, we obtain: 



<!-- Start of picture text -->
σyy =  σ (0) +  σ (2) cos(2 φ ) +  σ (4) cos(4 φ ) +  σ (6) cos(6 φ ) , (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
σyx =  σ (2) sin(2 φ ) +  σ (3) sin(3 φ )  − σ (4) sin(4 φ ) , (3)<br><!-- End of picture text -->

where _σ_<sup>(</sup><sup>_n_)</sup> corresponds to the amplitude of the respective conductivity contribution. Qualitatively similar results are obtained for current in the _x_ -direction and the results apply analogously to the resistivity tensor. 

24 

## **Even/odd separation in magnetic field sweeps** 

In the main text, we show measurements of _ρxy_ ( _H_ ) for the magnetic field swept from negative to positive ( _H ↑_ ) and positive to negative ( _H ↓_ ). The average of both sweep directions _⟨ρxy_ ( _H_ ) _⟩_ = ( _ρxy_ ( _H ↑_ ) + _ρxy_ ( _H ↓_ )) _/_ 2 is used to define the component symmetric, i.e. even, in magnetic field 



<!-- Start of picture text -->
ρ even xy ( H ) = ⟨ρxy ( H ) ⟩ + ⟨ρxy ( −H ) ⟩ . (4)<br>2<br><!-- End of picture text -->

The odd contribution for up and down sweeps is then obtained by subtraction 



<!-- Start of picture text -->
<br>ρxy ( H ↑ )  − ρ even xy ( H ) for H ↑<br>ρ odd xy ( H ) = . (5)<br><br> ρxy ( H ↓ )  − ρ even xy ( H ) for H ↓<br><!-- End of picture text -->

In the odd signal obtained by Eq. 5 also the odd in magnetic field ordinary Hall effect is contained. In order to highlight the hysteretic nature of the odd contribution a linear slope assigned to the ordinary Hall effect is typically subtracted. 

Figure S6 shows the various steps in the separation of even and odd signals and how the hysteretic contribution is isolated. 

25 





<!-- Start of picture text -->
a b<br>β=<br>j || y<br><!-- End of picture text -->









<!-- Start of picture text -->
c d<br><!-- End of picture text -->





FIG. S6. Transversal magnetoresistance for a magnetic field sweep recorded at _T_ = 150 K with a magnetic field angle _β_ = 60<sup>_◦_</sup> with respect to the current direction. (a) As measured transversal resistivity data. (b) Even in magnetic field signal _ρ_<sup>even</sup> _yx_ obtained by symmetrizing the average of up and down field sweep. (c) Odd contribution _ρ_<sup>odd</sup> _xy_ obtained from the raw data by subtraction of the even contribution. (d) Odd contribution _ρ_<sup>odd</sup> _yx_ minus a linear contribution attributed to the ordinary Hall effect. 

## **Additional magnetotransport data** 

Complementary to the magnetic field sweep measurements shown in the main text we show here angle dependent longitudinal and transveral resistivities for inplane magnetic fields. We rotate the magnetic field with various strength in the field plane and obtain the traces shown in Fig. S7. Various harmonic contributions are observed which tend to saturate 

26 

at the highest fields. Analysis of the data shows that the strongest contributions to the longitudinal resistivity (Fig. S7a,b) depend as predicted on cos( _nφ_ ) with _n_ = 2 _,_ 4 _,_ 6. These terms are even in the magnetic field and are attributed to the anisotropic magnetoresistance (AMR). At high fields, the six-fold contribution is strongest. It is noteworthy that the six-fold contributions in _ρxx_ and _ρyy_ follow the same pattern with minima observed at the same angles (0, 60, 120<sup>_◦_</sup> ,. . . ) whereas the two-fold contribution changes its sign and has a maximum at 0<sup>_◦_</sup> in _ρxx_ while a minimum is observed at the same angle in _ρyy_ . This indicates that the two-fold contribution is depending on the angle between Néel vector and current (non-crystalline AMR), whereas the six-fold contribution depends on the angle between Néel vector and crystal axis (crystalline AMR). 

The angle dependence of the transversal resistivity is shown in Fig. S7c and is dominated by the even contributions with two-fold and four-fold symmetry. In contrast to the longitudinal resistivities, the six-fold contribution is absent in this geometry. This is in agreement with the AMR contributions derived in Sec. . It also is in line with results in cubic/tetragonal systems, where crystalline AMR terms did not contribute to the transversal resistivities [17]. The amplitudes of the main contributions (two- and four-fold) do, however, agree with what was found in the corresponding longitudinal measurement. 

Since these measurements are performed with pure inplane field the AHE contribution is weak compared to the much stronger AMR contributions when the data are fit by a serious of sin( _nφ_ ) terms with _n_ as given in Fig. S7d. Figure S7d shows the magnetic field dependence of the amplitude of the sin( _nφ_ ) contributions. By the onset and saturation behavior of the strongest terms with _n_ = 2 _,_ 4 the spin-flop field of _∼_ 2 _..._ 3 T is determined. That a sin(3 _φ_ ) contribution corresponding to AHE signal is nevertheless detected in these magnetic field rotations can be seen when all even contributions are subtracted from the raw data (Fig. S8). What remains is a signal with predominant three-fold symmetry corresponding to the AHE which is shown in Fig. S8b. Consistent with the onset of magnetic moment reorientation at the spin flop field, data measured with fields _>_ 2 T show a three-fold contribution. 

In order to determine the magnetic easy axes of the thin films we turn our attention to the longitudinal resistivity data. For high magnetic fields the inplane anisotropy causes the moments to stay closer to the respective easy axis which is nearest to perpendicular to the magnetic field (spin-flop arrangement). Figure S9 shows examplaric for magnetic field rotations with a field strength of 6 T that the minima of six-fold contribution to the 

27 





<!-- Start of picture text -->
a b<br>c d<br><!-- End of picture text -->

FIG. S7. Angle dependent magnetotransport data recorded at _T_ = 50 K. (a,b) Longitudinal resistivity variation for inplane magnetic field for current along the _x ∥_ [2<sup>¯</sup> 1<sup>¯</sup> 10] and _y ∥_ [01<sup>¯</sup> 10] directions. (c) Transversal resistivity variation for inplane magnetic field and current along _y_ . The magnetic field dependence of the leading harmonic contributions to data in (c) is given in panel (d). The field angle _α_ is defined with respect to the crystalline _a_ -axis (c.f. Fig. 1 of the main text). 

longitudinal resistivity are wider than the respective maxima. These mimina occur for magnetic fields along the _a_ -axis and equivalent directions and therefore suggest magnetic easy axes for magnetic moments along _⟨_ 1<sup>¯</sup> 100 _⟩_ as shown in Fig. 1b of the main text (or equivalently Fig. S1a). 

The temperature dependence of the Hall signal is shown in the main text is furthermore distinct from the magnetoresistance effect which governs the variation of the longitudinal field sweeps which is shown in Fig. S10. 

28 



<!-- Start of picture text -->
a c d<br>b e f<br><!-- End of picture text -->

FIG. S8. Angle dependent transversal magnetotransport data recorded at _T_ = 50 K for inplane magnetic field and current along _y_ ((excerpt from Fig. S7c). (a, b) Transversal resistivity variation at field strength of 1.5 & 2 T and 3 & 4.5 T. (c-f) Odd in magnetic field contributions obtained after subtraction of fitted _sin_ ( _nα_ ) with even _n_ ( _n_ = 2 _,_ 4 _,_ 6 _,_ 8 _,_ 10). A guide to the eye proportional to sin 3 _α_ is shown in (d, e). The appearance of an additional contribution proportional to sin _α_ in data with higher fields is due to wobbling of the axis of the mechanical rotator which causes an unintentional out of plane field component and becomes obvious in panel (f). 

Since the discussed AHE effect is determined by an out of plane Hall pseudovector the inplane current direction does not matter. We verified this by the use of a Hall bar with current channel along the _x_ direction. The respective data are shown in Fig. S11. 

29 





<!-- Start of picture text -->
a<br>b c<br><!-- End of picture text -->





FIG. S9. Angle dependent longitudinal resistivity data recorded at _T_ = 50 K and magnetic field of 6 T. (a) Longitudinal resistivity variation for an inplane magnetic field rotation with geometry as given in Fig. S7. Colored rectangles mark the position and line color of the enlarged view near the maxima (b) and minima (c) of the six-fold magnetoresistance contribution. 

30 



<!-- Start of picture text -->
20<br>10<br>0<br>50 100 150 200 250 300<br>Temperature (K)<br> (%)<br>(0T)|yy<br>(0T)yy<br>(7T)yy<br>|<br><!-- End of picture text -->

FIG. S10. Temperature dependence of the magnetoresistance signal determined from the longitudinal resistivity difference between data at 7 and 0 T. The magnetoresistance was extracted for magnetic field sweeps recorded with magnetic field at an angle of _β_ = 30<sup>_◦_</sup> and current along _y ∥_ [01<sup>¯</sup> 10]. 

31 



<!-- Start of picture text -->
2<br>1<br>0<br>1 Up<br>Down<br>2<br>10 5 0 5 10<br>Magnetic field  0 H (T)<br>m)<br>AHE (xy<br><!-- End of picture text -->

FIG. S11. Odd in magnetic field transversal resistivity component for current along the _a_ -direction ([2<sup>¯</sup> 1<sup>¯</sup> 10]) and magnetic field along the current, i.e. inplane. For technical reasons no defined out of plane field component could be set for this current direction. 

32 

- _∗_ R.D.G.B. and J.Z. contributed equally to this work 

- rhernandezj@uninorte.edu.co 

- kriegner@fzu.cz 

- [1] G. Kresse and J. Furthmüller, Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set, Physical Review B **54** , 11169 (1996). 

- [2] D. Kriegner, H. Reichlova, J. Grenzer, W. Schmidt, E. Ressouche, J. Godinho, T. Wagner, S. Y. Martin, A. B. Shick, V. V. Volobuev, G. Springholz, V. Holý, J. Wunderlich, T. Jungwirth, and K. Výborný, Magnetic anisotropy in antiferromagnetic hexagonal MnTe, Physical Review B **96** , 214418 (2017). 

- [3] G. Yin, J.-X. Yu, Y. Liu, R. K. Lake, J. Zang, and K. L. Wang, Planar Hall Effect in Antiferromagnetic MnTe Thin Films, Physical Review Letters **122** , 106602 (2019). 

- [4] S. Mu, R. P. Hermann, S. Gorsse, H. Zhao, M. E. Manley, R. S. Fishman, and L. Lindsay, Phonons, magnons, and lattice thermal transport in antiferromagnetic semiconductor MnTe, Physical Review Materials **3** , 025403 (2019). 

- [5] A. A. Mostofi, J. R. Yates, G. Pizzi, Y.-S. Lee, I. Souza, D. Vanderbilt, and N. Marzari, An updated version of wannier90: A tool for obtaining maximally-localised Wannier functions, Computer Physics Communications **185** , 2309 (2014). 

- [6] G. Pizzi, V. Vitale, R. Arita, S. Blügel, F. Freimuth, G. Géranton, M. Gibertini, D. Gresch, C. Johnson, T. Koretsune, J. Ibañez-Azpiroz, H. Lee, J.-M. Lihm, D. Marchand, A. Marrazzo, Y. Mokrousov, J. I. Mustafa, Y. Nohara, Y. Nomura, L. Paulatto, S. Poncé, T. Ponweiser, J. Qiao, F. Thöle, S. S. Tsirkin, M. Wierzbowska, N. Marzari, D. Vanderbilt, I. Souza, A. A. Mostofi, and J. R. Yates, Wannier90 as a community code: New features and applications, Journal of Physics: Condensed Matter **32** , 165902 (2020). 

- [7] Q. Wu, S. Zhang, H.-F. Song, M. Troyer, and A. A. Soluyanov, WannierTools: An open-source software package for novel topological materials, Computer Physics Communications **224** , 405 (2018). 

- [8] M. Podgorny and J. Oleszkiewicz, Electronic structure of antiferromagnetic MnTe, Journal of Physics C: Solid State Physics **16** , 2547 (1983). 

- [9] S.-H. Wei and A. Zunger, Total-energy and band-structure calculations for the semimagnetic 

33 

Cd1-xMnxTe semiconductor alloy and its binary constituents, Physical Review B **35** , 2340 (1987). 

- [10] F. Freimuth, S. Blügel, and Y. Mokrousov, Spin-orbit torques in Co/Pt (111) and Mn/W (001) magnetic bilayers from first principles, Phys. Rev. B **90** , 174423 (2014). 

- [11] J. Železný, `https://bitbucket.org/zeleznyj/wannier-linear-response` (). 

- [12] G. Zanmarchi, Optical measurements on the antiferromagnetic semiconductor MnTe, Journal of Physics and Chemistry of Solids **28** , 2123 (1967). 

- [13] J. W. Allen, G. Lucovsky, and J. C. Mikkelsen, Optical properties and electronic structure of crossroads material MnTe, Solid State Communications **24** , 367 (1977). 

- [14] C. Ferrer-Roca, A. Segura, C. Reig, and V. Muñoz, Temperature and pressure dependence of the optical absorption in hexagonal MnTe, Physical Review B **61** , 13679 (2000). 

- [15] Y. Magnin and H. T. Diep, Monte Carlo study of magnetic resistivity in semiconducting MnTe, Physical Review B **85** , 184413 (2012). 

- [16] J. Železný, `https://bitbucket.org/zeleznyj/linear-response-symmetry` (). 

- [17] E. D. Ranieri, A. W. Rushforth, K. Výborný, U. Rana, E. Ahmad, R. P. Campion, C. T. Foxon, B. L. Gallagher, A. C. Irvine, J. Wunderlich, and T. Jungwirth, Lithographically and electrically controlled strain effects on anisotropic magnetoresistance in (Ga,Mn)As, New Journal of Physics **10** , 065003 (2008). 

34 

