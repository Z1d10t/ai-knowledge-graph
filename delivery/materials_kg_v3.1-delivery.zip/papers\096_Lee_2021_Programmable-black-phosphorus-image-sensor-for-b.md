# Programmable black phosphorus image sensor for broadband optoelectronic edge computing

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 229 |
| 作者 | Seokhyeong Lee, Ruoming Peng, Chang-Ming Wu, Mo Li |
| DOI | 10.1038/s41467-022-29171-1 |
| 源文件 | 096_Lee_2021_Programmable-black-phosphorus-image-sensor-for-b.pdf |

---
# **Programmable black phosphorus image sensor for broadband** 

# **optoelectronic edge computing** 

Seokhyeong Lee<sup>1�</sup> , Ruoming Peng<sup>1�</sup> , Changming Wu<sup>1</sup> , and Mo Li<sup>1,2</sup> 

_1Department of Electrical and Computer Engineering, University of Washington, Seattle, WA 98195, USA_ 

_2Department of Physics, University of Washington, Seattle, WA 98195, USA_ 

## **Abstract** 

Image sensors with internal computing capability enable in-sensor computing that can significantly reduce the communication latency and power consumption for machine vision in distributed systems and robotics. Two-dimensional semiconductors are uniquely advantageous in realizing such intelligent visionary sensors because of their tunable electrical and optical properties and amenability for heterogeneous integration. Here, we report a multifunctional infrared image sensor based on an array of black phosphorous programmable phototransistors (bP-PPT). By controlling the stored charges in the gate dielectric layers electrically and optically, the bP-PPT’s electrical conductance and photoresponsivity can be locally or remotely programmed with high precision to implement an in-sensor convolutional neural network (CNN). The sensor array can receive optical images transmitted over a broad spectral range in the infrared and perform inference computation to process and recognize the images with 92% accuracy. The demonstrated multispectral infrared imaging and in-sensor computing with the black phosphorous optoelectronic sensor array can be scaled up to build a more complex visionary neural network, which will find many promising applications for distributed and remote multispectral sensing. 

>  Corresponding author: pruoming@uw.edu, moli96@uw.edu 

> � These authors contributed equally to this work. 

## **Introduction** 

2D semiconductors have tremendous potential in optoelectronics because they afford a wide range of bandgaps with tunable optoelectronic properties<sup>1–3</sup> . Being atomically thin and transferable, they are amenable to heterogeneous integration with photonic circuits and microelectronics to realize advanced functionalities<sup>4–9</sup> . In terms of broadband operation in the infrared, black phosphorus (bP) stands out for its tunable bandgap corresponding to a wide infrared spectral range. Discrete, array, and waveguide-integrated bP photodetectors with compelling performance have been demonstrated for the infrared<sup>10–17</sup> .  Leveraging its broadband infrared responses, arrays of bP photodetectors can be utilized for multispectral imaging, which acquires spatial images with simultaneous spectral information<sup>17-18</sup> . Multispectral imaging combined with artificial neural networks (ANN) has become a powerful tool for biomedical imaging<sup>19–22</sup> , fresh food classification<sup>23–25</sup> , and surface damage detection in industrial sites<sup>26–28</sup> . This imaging technique can generate a tremendous amount of data and is consequently computation-intensive and latencysensitive, and thus can benefit from the emerging scheme of edge computing<sup>9,29–32</sup> . Preprocessing the images within the sensors at the edge rather than in the cloud can largely alleviate the data streaming load to the servers, improving the bandwidth budget<sup>33–35</sup> and reducing latency and power consumption. These advantages of edge computing have urged the development of novel optoelectronic edge sensors that combine vision-sensory and computational functionalities in the same devices<sup>8,9</sup> , which recently have been demonstrated using 2D transition metal dichalcogenides (TMDs) for visible spectral imaging. Realizing such a scheme using bP will extend it to the infrared spectral range, enabling intelligent night vision and multispectral sensing. 

Here, we present a multifunctional image sensor that combines the functions of multispectral imaging and analog in-memory computing to implement an in-sensor ANN for image recognition. The image sensor is based on an array of programmable phototransistors made of few-layer bP (bP-PPTs), which are sensitive to a broad infrared spectral range from 1.5 to 3.1 µm in wavelength. The bP-PPT’s programmability and memory stem from the stored charges in the rationally designed stack of gate dielectrics that have a long retention time and effectively modulate the photoconductance of the bP channel. The sensor can be programmed and read out both electrically and optically, enabling in-memory computing and remote programming. It is used as an optical frontend that can capture multispectral images in the infrared and perform image 

processing and classification tasks (Fig. 1a), demonstrating its promise for distributed and remote sensing applications at household, farming, and industrial sites. 

## **Result** 

Fig. 1b depicts the structure of a single bP-PPT device, which consists of a few-layer bP flake as the channel, a stack of Al2O3/HfO2/Al2O3 (AHA) as the gate dielectric and charge storage layer<sup>36–</sup> 38, and a top gate electrode. Contrary to the conventional floating gate devices that trap charges on an isolated metallic gate, the bP-PPT stores charges in the HfO2 dielectric layer with a lower barrier height, which offers more reliable and faster operation and simplifies the fabrication process<sup>38–41</sup> . For optical access to the bP-PPT, indium-tin-oxide (ITO) is used as the transparent top gate electrode. Fig. 1d depicts the band alignment of the multiple layers in the bP-PPT device. We design the layer structure and select the materials such that charges (electrons or holes) can tunnel from the top gate through the thin Al2O3 barrier layer to be stored in the HfO2 layer and effectively modulate the bP channel with field effect. Moreover, the electron affinity difference between Al2O3 and HfO2 ( _χ_ Al2O3= 1.0 eV, _χ_ HfO2= 2.5 eV) determines the storing energy to be ~1.5 eV, enabling optical control of the stored charges—they can be removed by illuminating with visible light (λ < 0.886 µm) but not with infrared light in the telecommunication band or longer wavelength. The conductance and photoresponsivity of the bP-PPT are controlled by the density of the trapped charges<sup>12–14</sup> , thus can be set either by applying electrical gate voltage or by shining visible spectral light pulses, enabling local and remote programming of the device. 

To construct an image sensor and processor, we fabricated a 4 × 3 array of bP-PPTs on a single bP flake, as shown in Fig. 1c (see Methods for more details about the fabrication process). We optimized the thickness and the deposition process of the AHA multilayer to realize a high charge storage density of 1.8×10<sup>13</sup> cm<sup>-2</sup> (see Supplementary note 2 for the method used to determine the density). Fig. 1e shows the collective measurement results of the source-drain current ( _I_ ds) of the devices in the array when the gate voltage ( _V_ G) is swept. Because charges are injected and stored in the AHA multilayer during the _V_ G sweep, the _I_ ds- _V_ G curve shows a hysteresis loop with a large memory window of 25 V in _V_ G. The high charge storage density leads to effective control in the electrical conductance of the bP-PPT, achieving an on/off ratio > 200<sup>36</sup> . Since the array is fabricated on the same bP flake, it has excellent uniformity that inter-device variation in the on/off ratio among 9 devices is less than 8% (inset, Fig. 1e). 

Fig. 2a illustrates the working principle of electrically programming the bP-PTTs by applying voltage pulses to the gate. The device can first be reset wit <mark>h a depressive pulse (-18 V amplitude, 50 ms duration) to a fully-off state (state #0) with low conductance. Afterward, it can be programmed by applying positive voltage pulses with amplitude in the range of 10 ~ 18 V and a fixed duration of 20 ms. By varying the pulse amplitude, the device can be programmed to states of more than 8 distinguishable levels (equivalent to 3 bit) in its conductance when the bP channel is changed from n-type to p-type doping (Fig. S1, Supplementary Information). Fig. 2c and d show results of four representative states with a long retention time >4000 s (Fig. 2c) and linear</mark> _<mark>I</mark>_ <mark>-</mark> _<mark>V</mark>_ <mark>characteristics (Fig. 2d). The latter is important for its application in analog computing.</mark> 

<mark>Even higher precision can be achieved by programming the devices optically because optical pulses can directly excite the stored charges to remove them, and the duration of optical pulses can be controlled more accurately than voltage pulses. We demonstrate optical programming of the bP-PPT devices using optical pulses in wavelength of 780 nm, which provides sufficient energy to activate the stored charges to overcome the trapping potential (Fig. 1d). Before programming, the bP-PPT is initialized electrically to state #0. Subsequently, it is illuminated with optical pulses with fixed average power (~10 µW at the device) and varying duration so the pulse energy is varied between 10 nJ and 2 µJ.  As shown in Fig. 2e, these optical pulses program the bP-PPT to 36 states with different levels in conductance to represent 5 digital bits, a record-high number of levels achieved in charge storage devices. The programming process is accurate, arbitrary, and repeatable. The inset of Fig. 2e shows three adjacent levels that can be programmed repeatedly with high precision. Furthermore, each programmed state is stable for >1000 s, sufficient for analog computation applications (see Supplementary Information).</mark> 

<mark>The narrow bandgap of bP enables the bP-PPTs to be operated as broadband photodetectors that can detect optical signals from the near-infrared (NIR) to the mid-infrared (MIR) spectral range. Earlier studies have reported that a bP photodetector’s responsivity is sensitive to the doping level and type of the bP channel</mark><sup>11–14</sup> <mark>.  In our bP-PPTs, since we can control the density of the stored charge to modulate the doping level and type of the bP channel, we can program their photoresponsivity in the same way as their electrical conductance. Fig. 2f shows the photoresponsivity of a bP-PPT measured in the wavelength range from 1.5-3.1 µm when the device is set to high and low conductance states (corresponding to states #0 and #35 in Fig. 2e),</mark> 

<mark>respectively. Note that the low conductance state (state #0) has a high photoresponsivity due to the Burstein-Moss effect</mark><sup>11,14</sup> <mark>.</mark> The unmeasured spectral range (1.8-2.6 𝜇m) is due to the tunability gap of the light source (M-Square Firefly IR). <mark>The linearity of the devices’ photoresponse is also verified for an incident optical power of up to 30 mW (Fig. S3 in Supplementary Information). Therefore, the bP-PPT has a programmable photoresponse in all the telecommunication bands (S, C, L bands) and the mid-infrared range.</mark> 

<mark>The above results show that the bP-PPT devices can be programmed both electrically and optically. The programmed state is non-volatile and can be read out either electrically by measuring the device’s conductance or optically by measuring its photoresponsivity. In both cases, the device is operated in the linear regime and thus can be utilized for analog computing. Such a hybrid of multifunctional operation modes enables the utilization of a bP-PPT array to implement a mixed-mode optoelectronic neural network system. The same bP-PPT array can act as both the optical frontend to receive and preprocess optical images and an electrical processor with inmemory computing to post-process the images (Fig. 3a).</mark> 

## **bP-PPT in-sensor convolution for edge detection** 

We first use the bP-PPT array to detect infrared optical images and preprocess them in the sensor<sup>8,9</sup> . To prove the concept, we configure the bP-PPT array to perform edge detection of images by programming their photoresponsivity ( _R_ ) to represent convolutional kernel matrices and receiving input images transmitted and encoded in the optical power ( _P_ in) in telecommunication bands. Measuring the photocurrent output 𝐼�� �𝑅∙𝑃�� from the array corresponds to a multiplyaccumulation (MAC) operation<sup>42–44</sup> on the input image with the kernel matrix stored in _R_ . For edge detection, the photoresponsivity matrix _R_ is optically programmed to binary values (Fig. 2f) and, after proper normalization, to represent kernel matrix �<sup>�1</sup> �1 11<sup>�for right edge detection</sup> (��1<sup>1</sup> �11<sup>� for top, �1</sup> 1 �1�1<sup>� for left, and ��1</sup> 1 �11<sup>� for bottom edges) 45–47.</sup> 

To demonstrate the broadband capability of the bP-PPT array, we encode three different 8- bit grayscale images (Fig. 3b; top: handwritten digits; middle: a husky dog; bottom: a cameraman) using wavelengths in three telecom bands: 1510 nm in the S band, 1550 nm in the C band, and 1590 nm in the L band, respectively. The brightness of each pixel is encoded into the optical power 

using variable optical attenuators (VOA) and illuminated on a 2×2 bP-PPT array. Each bP-PPT device is set to have a high responsivity of 60 mA/W to represent 1, or a low responsivity of 20 mA/W  to represent -1 (Fig. 2f). The measured photocurrents are normalized and offset to calculate the convolution. The convolved images without any further post-processing are shown in Fig. 3c to f, for right, top, left, bottom edges, respectively. Fig. 3g shows the combination of all types of edges, resulting in a clear silhouette of each image. Thus, we demonstrate the bP-PPT array’s application as an optical frontend capable of multispectral imaging reception and preprocessing. 

## **bP-PPT CNN for image recognition** 

Besides its photoresponsivity, the conductance of the bP-PPT array can also be programmed to perform MAC operation by measuring the source-drain current 𝐼�� �𝑉�� ∙g��, where g�� is the conductance matrix of the array programmed to represent the weight matrix, _V_ DS is the sourcedrain voltages applied to the array as the input vector. An optoelectronic convolutional neural network (CNN) thus can be implemented with the array connected to the previous sensory devices, where the optical input image is detected and converted to electrical signals (Fig. 4a, red boundary). In Fig. 2e, we have demonstrated precise programming of the bP-PPT to 36 discrete levels, ensuring high accuracy in weight training and inference calculation<sup>48,49</sup> . Here, we use the 3 × 3 bPPPT array to demonstrate a CNN that recognizes images of handwriting numbers “0” and “1” from the MNIST data set. The CNN consists of an input layer that captures a 28 × 28-pixel image, a convolution layer with two 3 × 3 kernels, an average pooling layer followed by an 8 × 2 fully connected (FC) layer (Fig. 4a). The network is trained offline with 12,000 images of the training set with 100 epochs, delivering the final output scores that classify the input image to “0” or “1” with 99% accuracy. The trained network model is remotely programmed into the bP-PPT array by illuminating each pixel with the programming optical pulses. The kernel elements are discretized to accommodate the 36 discrete levels of the programmable states and used consistently in the experiment and simulation (Fig. 4b). For example, the element value 2.00 in kernel 1 (K1), the largest element, is represented by setting a pixel of the bP-PPT to state #35 (in Fig. 2e). By optically programming the 9 pixels of the array to the kernel elements, encoding the image pixels in the source-drain voltages, and measuring the source-drain current, the convolution calculation is executed on-chip to obtain the feature maps, followed by the average pooling and FC layers. 

The two output nodes from the FC layer are activated with Softmax function and stored as scores to complete the classification task. 

To verify the accuracy of the bP-PPT optoelectronic CNN, 100 randomly chosen images of handwritten numbers (48 of “0”s and 52 of “1”s) from the MNIST data set were tested. The results are compared with the simulated results obtained from an offline computer. Note that this simulation is different from the first training with 99% accuracy due to the limited 36-level discreteness of the kernel element values. The bar graph in Fig. 4c compares the experimental and the simulated output scores of the two labels “0” and “1” for 50 test cases, which have shown excellent agreement. The gray-tarnished bars highlight the incorrectly recognized cases. The summary of the experimental and the simulation results are shown as the confusion table in Fig. 4d. The bP-PPT array-based CNN reached a high accuracy of 92%, comparable with the simulated results (95%). 

## **Conclusion** 

To summarize, we have demonstrated a phototransistor array based on bP (bP-PPT) that can be programmed electrically and optically by utilizing the stored charges in the gate dielectric stack that has a long retention time. Particularly, our device has a high programming precision with a resolution higher than 5-bit, which is among the highest of devices based on charged trapping mechanism. Leveraging its flexible functionality, we use the bP-PPT array to realize visionsensory functions with in-memory computing. The sensors’ programmable photoconductivity enables in-sensor computing for edge detection on images that are optically encoded and transmitted over a broad infrared band. The same bP-PPT array can also be electrically programmed on the backend to implement a CNN to perform image recognition tasks. Additionally, the demonstrated programmable photoresponsivity in the near-IR can be extended to a broader range of infrared (currently limited by the laser tunning range).  It will allow multispectral image processing on edge devices, which can expedite many processes in industrial or biomedical applications<sup>20–28</sup> . Furthermore, recently reported centimeter-scale growth of bP suggests that it is promising to scale the bP-PPT array to an even larger array of megapixels<sup>50</sup> . Thus, the demonstrated multifunctional optoelectronic bP-PPT array, combined with parallel imaging and programming schemes, such as spatial light modulation and wavelength division 

multiplexing, can realize more complex deep neural networks for machine vision sensors distributed with edge computing. 





**Figure 1.** Programmable bP phototransistor (bP-PPT) array. **a.** The bP-PPT array is capable of multispectral infrared imaging and is programmable for in-sensor computing. The array can be programmed remotely using optical control signals. **b.** The layer structure of a bP-PPT device. **c** . Optical microscope image of a 3 � 4 array of bP-PPT devices patterned from a single bP flake. White dashed square indicates the patterned bP. Scale bar: 10 𝜇m. **d.** Band diagram of the bP-PPT device. The AHA dielectric stack is designed to store charges in the HfO2 layer. The electron affinity (𝜒), bandgap (𝐸��, and work function ( _W_ ) of the layers are: 𝜒�����=1.0 eV, 𝐸�,�����=7.7 eV, 𝜒����= 2.5 eV, 𝐸�,����=4.9 eV, 𝜒�� = 4.4 eV, 𝐸�,�� = 0.3 eV, 𝑊�� = 5.01 eV, 𝑊��� = 4.7 eV. **e.** _I_ ds- _V_ G measurement of nine bP-PPT devices. Each bP-PPT shows a large memory window of 25 V in _V_ G and an on-off ratio of ~200. The inter-device variation (standard deviation) in the array is shown as the gray shaded area. Inset: histogram of the on-off ratio of the devices in the array. 





**Figure 2.** Mixed-mode operation of the bP-PPT device. **a, b.** The schematic illustration of the working principle of the programming the bP-PPT with electrical gate voltage pulses (a) and (b) optical pulses. **c.** The bP-PPT can be programmed to 6 states of well-resolved conductance levels using programming pulses of different voltage amplitudes ( _V_ prog). Note that a negative repressive pulse (-19 V) resets the device to the lowest conductance. **d.** The _I-V_ characteristics of the device at each programmed state, showing the linear conductance (𝑔��). **e.** The bP-PPT can be optically programmed using visible pulses to 36 levels in conductance. The inset shows the histogram of the well-separated conductance when the device is programmed repeatedly to three adjacent states. **f.** The bP-PPT’s photoresponsivity over the near-IR (including the telecom S,C, and L-bands) and the mid-IR ranges. The discontinued spectral region is due to the gap of the laser tunability. The bP-PPT’s photoresponsivity can be programmed to two states when its conductance is set to high (state #0 in **e** ) or low (state #35 in **e** ). 



**Figure 3.** bP-PPT array for imaging with in-sensor convolutional kernels. **a.** The bP-PPT array receives imaged in multiple wavelength bands. The array’s photoresponsivity matrix is programmed to represent the convolution kernel to directly preprocess the images in the optoelectronic domain (red dashed line box). The array’s conductance matrix is then programmed to perform inference computation in the electrical domain (blue dashed line box). **b.** The original input images encoded in the optical power transmitted in three different telecom bands. Top: handwritten digits (56 � 56 pixels, _S_ -band); middle: a husky dog (312 � 222 pixels, _C_ -band); bottom: a cameraman (256 � 256 pixels, _L_ -band). **c-f.** The resultant images after convolution with the right, top, left, and bottom edge kernels, respectively. **g.** The final images combining all the edges. 



**Figure 4.** bP-PPT array optoelectronic CNN for image recognition. **a.** A CNN model for classifying handwriting numbers “0” and “1” from the MNIST dataset. The CNN consists of two convolution kernels, an average pooling layer, and a fully connected layer.  The images captured by the bP-PPT array are further processed by the bP-PPT array in the electrical domain. **b.** The 3×3 bP-PPT array is programmed with 5-bit precision to represent two kernels generated by offline training. **c.** The experimental and simulated results for image recognition using the bP-PPT array. Each bar is the score indicating the possibility of the CNN recognizes an image in the MNIST image library. **d.** The experimental and simulated confusion table for 100 images from the MNIST dataset.  Colored diagonal elements in the table indicate the correctly identified cases. 

## **Reference:** 

1. Wang, Q. H., Kalantar-Zadeh, K., Kis, A., Coleman, J. N. & Strano, M. S. Electronics and optoelectronics of two-dimensional transition metal dichalcogenides. _Nat. Nanotechnol._ **7** , 699–712 (2012). 

2. Xia, F., Wang, H. & Jia, Y. Rediscovering black phosphorus as an anisotropic layered material for optoelectronics and electronics. _Nat. Commun._ **5** , 4458 (2014). 

3. Britnell, L., Ribeiro, R. M., Eckmann, A., Jalil, R., Belle, B. D., Mishchenko, A., Kim, Y.J.,Gorvachev, R.V., Georgiou, T., Morozov, S.V., Grigorenko, A.N., Geim, A.K., Casiraghi, C., Castro Neto, A.H. & Novoselov, K. S. Strong light-matter interactions in heterostructures of atomically thin films. _Science_ , **340** , 1311-1314 (2013). 

4. Liu, L., Liu, C., Jiang, L., Li, J., Ding, Y., Wang, S., Jiang, Y.G., Sun, Y.B., Wang, J., Chen, S., Zhang, D.W. & Zhou, P. Ultrafast non-volatile flash memory based on van der Waals heterostructures. _Nat. Nanotechnol._ **16** , 874–881 (2021). 

5. Wu, L., Wang, A., Shi, J., Yan, J., Zhou, Z., Bian, C., Ma, J., Ma, R., Liu, H., Chen, J., Huang, Y., Zhou, W., Bao, L., Ouyang, M., Pennycook, S.J., Pantelides, S.T. & Gao, H.-J. Atomically sharp interface enabled ultrahigh-speed non-volatile memory devices. _Nat. Nanotechnol._ **16** , 882–887 (2021). 

6. Xia, F., Wang, H., Xiao, D., Dubey, M. & Ramasubramaniam, A. Two-dimensional material nanophotonics. _Nat. Photonics_ 8, 899–907 (2014). 

7. Migliato Marega, G., Zhao, Y., Avsar, A., Wang, Z., Tripathi, M., Radenovic, A. & Kis, A. Logic-in-memory based on an atomically thin semiconductor. _Nature_ **587** , 72–77 (2020). 

8. Jang, H., Liu, C., Hinton, H., Lee, M.-H., Kim, H., Seol, M., Shin, H.-J., Park, S. & Ham, D. An Atomically Thin Optoelectronic Machine Vision Processor. _Adv. Mater._ **32** , 36 (2020). 

9. Mennel, L., Symonowicz, J., Wachter, S., Polyushkin, D.K., Molina-Mendoza, A. J. & Mueller, T. Ultrafast machine vision with 2D material neural network image sensors. _Nature_ **579** , 62–66 (2020). 

10. Huang, M., Wang, M., Chen, C., Ma, Z., Li, X., Han, J. & Wu, Y. Broadband BlackPhosphorus Photodetectors with High Responsivity. _Adv. Mater._ **28** , 3481–3485 (2016). 

11. Peng, R. Khalijji, K., Youngblood, N., Grassi, R., Low, T. & Li, M. Midinfrared Electrooptic Modulation in Few-Layer Black Phosphorus. _Nano Lett._ **17** , 6315–6320 (2017). 

12. Chen, X., Lu, X., Deng, B., Sinai, O., Shao, Y., Li, C., Yuan, S., Tran, V., Watanabe, K., Taniguchi, T., Naveh, D., Yang, L. & Xia, F. Widely tunable black phosphorus midinfrared photodetector. _Nat. Commun._ **8** , 1672 (2017). 

13. Bullock, J., Amani, M., Cho, J., Chen, Y.-Z., Ahn, G.H., Adinolfi, V., Shrestha, V. R., Gao, Y., Crozier, K. B., Chueh, Y.-L. & Javey, A. Polarization-resolved black phosphorus/molybdenum disulfide mid-wave infrared photodiodes with high detectivity at room temperature. _Nat. Photonics_ 12, 601–607 (2018). 

14. Youngblood, N., Chen, C., Koester, S. J. & Li, M. Waveguide-integrated black phosphorus photodetector with high responsivity and low dark current. _Nat. Photonics_ **9** , 247–252 (2015). 

15. Chen, C., Chen, F., Chen, X., Deng, B., Eng, B., Jung, D., Guo, Q., Yuan, S., Watanabe, K., Taniguchi, T., Lee, M. L. & Xia, F. Bright mid-infrared photoluminescence from thinfilm black phosphorus. _Nano Lett._ **19** , 1488–1493 (2019). 

16. Zong, X., Hu, H., Ouyang, G., Wang, J., Shi, R., Zhang, L., Zeng, Q., Zhu, C., Chen, S., Cheng, C., Wang, B., Zhang, H., Liu, Z., Huang, W., Wang, T., Wang, L. & Chen, X. Black phosphorus-based van der Waals heterostructures for mid-infrared light-emission applications. _Light Sci. Appl._ **9** , 114 (2020). 

17. Yuan, S., Naveh, D., Watanabe, K., Taniguchi, T. & Xia, F. A wavelength-scale black phosphorus spectrometer. _Nat. Photonics_ **15** , 601–607 (2021). 

18. Kim, H., Uddin, S.Z., Lien, DH., Yeh, M., Azar, N.S., Balendhran, S., Kim, T., Gupta, N., Rho, Y., Grigoropoulos, C.P., Crozier, K. B. & Javey, A. Actively variable-spectrum optoelectronics with black phosphorus. _Nature_ **596** , 232–237 (2021). 

19. Halicek, M., Lu, G., Little, J.V., Wang, X., Patel, M., Griffith, C.C., El-Deiry, M. W., Chen, A. Y. & Fei, B. Deep convolutional neural networks for classifying head and neck 

cancer using hyperspectral imaging. _J. Biomed. Opt._ **22** , 060503 (2017). 

20. Lu, G. & Fei, B. Medical hyperspectral imaging: a review. _J. Biomed. Opt._ **19** , 010901 (2014). 

21. Halicek, M., Little, J. V., Wang, X., Chen, A. Y. & Fei, B. Optical biopsy of head and neck cancer using hyperspectral imaging and convolutional neural networks. _J. Biomed. Opt._ **24** , 036007 (2019). 

22. Yang, W., Yang, C., Hao, Z., Xie, C. & Li, M. Diagnosis of Plant Cold Damage Based on Hyperspectral Imaging and Convolutional Neural Network. _IEEE Access_ **7** , 118239– 118248 (2019). 

23. Kong, W., Zhang, C., Liu, F., Nie, P. & He, Y. Rice Seed Cultivar Identification Using Near-Infrared Hyperspectral Imaging and Multivariate Data Analysis. _Sensors_ **13** , 8916– 8927 (2013). 

24. Elmasry, G., Sun, D. W. & Allen, P. Near-infrared hyperspectral imaging for predicting colour, pH and tenderness of fresh beef. _J. Food Eng._ **110** , 127–140 (2012). 

25. Ravikanth, L., Singh, C. B., Jayas, D. S. & White, N. D. G. Classification of contaminants from wheat using near-infrared hyperspectral imaging. _Biosyst. Eng._ **135** , 73–86 (2015). 

26. Rosi, F. _et al._ Noninvasive Analysis of Paintings by Mid-infrared Hyperspectral Imaging. _Angew. Chemie Int. Ed._ **52** , 5258–5261 (2013). 

27. Li, W., Wu, G., Zhang, F. & Du, Q. Hyperspectral Image Classification Using Deep PixelPair Features. _IEEE Trans. Geosci. Remote Sens._ **55** , 844–853 (2017). 

28. Aryal, S., Chen, Z. & Tang, S. Mobile Hyperspectral Imaging for Material Surface Damage Detection. _J. Comput. Civ. Eng._ **35** , 04020057 (2020). 

29. Chen, J. & Ran, X. Deep Learning With Edge Computing: A Review. _Proc. IEEE_ (2019). 

30. Shi, W., Cao, J., Zhang, Q., Li, Y. & Xu, L. Edge Computing: Vision and Challenges. _IEEE Internet Things J._ **3** , 637–646 (2016). 

31. Satyanarayanan, M. How we created edge computing. _Nat. Electron._ **2** , 42 (2019). 

32. Sebastian, A., Le Gallo, M., Khaddam-Aljameh, R. & Eleftheriou, E. Memory devices and applications for in-memory computing. _Nat. Nanotechnol._ **15** , 529–544 (2020). 

33. Sun, Y., Chen, Z., Tao, M. & Liu, H. Bandwidth Gain from Mobile Edge Computing and Caching in Wireless Multicast Systems. _IEEE Trans. Wirel. Commun._ **19** , 3992–4007 (2020). 

34. Wang, J., Feng, Z., Chen, Z., George, S., Bala, M., Pillai, P., Yang, S.-W. & Satyanarayanan, M. Bandwidth-efficient live video analytics for drones via edge computing. _ACM/IEEE Symp. Edge Comput. SEC,_ 159–173 (2018). 

35. Xu, T., Sun, Y., Xia, S., Li, H., Luo, L. & Chen, Z. Optimal bandwidth allocation with edge computing for wireless VR delivery. _IEEE/CIC Int. Conf. Commun. China, ICCC_ 903–907 (2019). 

36. Feng, Q., Yan, F., Luo, W. & Wang, K. Charge trap memory based on few-layer black phosphorus. _Nanoscale_ **8** , 2686–2692(2016). 

37. Zhang, E., Wang, W., Zhang, C., Jin, Y., Zhu, G., Sun, Q., Zhang, D. W., Zhou, P. & Xiu, F. Tunable Charge-Trap Memory Based on Few-Layer MoS2. _ACS Nano_ **9** , 612–619 (2014). 

38. Son, J. W., You, H. W. & Cho, W. J. Multi-layer stacked OHA and AHA tunnel barriers for charge trap flash non-volatile memory application. _Curr. Appl. Phys._ **11** , 10–15 (2011). 

39. Du, Y. _,_ Du, L., Gu, X., Du, J., Wang, X., Hu, B., Jiang, M., Chen, X., Iyer, S. & Chang, M.-C. F. An Analog Neural Network Computing Engine Using CMOS-Compatible Charge-Trap-Transistor (CTT). _IEEE Trans. Comput. Des. Integr. Circuits Syst._ **38** , 1811– 1819 (2019). 

40. Khan, F., Cartier, E., Woo, J. C. S. & Iyer, S. Charge Trap Transistor (CTT): An embedded fully logic-compatible multiple-time programmable non-volatile memory element for high-k-metal-gate CMOS technologies. _IEEE Electron Device Lett._ **38** , 44–47 (2017). 

41. Molas, G., Bocquet, M., Vianello, E., Perniola, L., Grampeix, H., Colonna, J. P., 

Masarotto, L., Martin, F., Brianceau, P., Gely, M., Bongiorno, C., Lombardo, S., Panakakis, G., Ghibaudo, G. & De Salvo, B. Reliability of charge trapping memories with high-k control dielectrics (Invited Paper). _Microelectron. Eng._ **86** , 1796–1803 (2009). 

42. Nahmias, M. A., de Lima, T.F., Tait, A. N., Peng, H., Shastri, B. J. & Prucnal, P. R. Photonic Multiply-Accumulate Operations for Neural Networks. _IEEE J. Sel. Top. Quantum Electron._ **26** , (2020). 

43. Cai, F., Correll, J. M., Lee, S. H., Lim, Y., Bothra, V., Zhang, Z., Flynn, M. P. & Lu, W. D. A fully integrated reprogrammable memristor–CMOS system for efficient multiply– accumulate operations. _Nat. Electron._ **2** , 290–299 (2019). 

44. Camus, V., Mei, L., Enz, C. & Verhelst, M. Review and Benchmarking of PrecisionScalable Multiply-Accumulate Unit Architectures for Embedded Neural-Network Processing. _IEEE J. Emerg. Sel. Top. Circuits Syst._ **9** , 697–711 (2019). 

45. Shen, B. & Sethi, I. K. Convolution-Based Edge Detection for Image/Video in Block DCT Domain. _J. Vis. Commun. Image Represent._ **7** , 411–423 (1996). 

46. Kanopoulos, N., Vasanthavada, N. & Baker, R. L. Design of an Image Edge Detection Filter Using the Sobel Operator. _IEEE J. Solid-State Circuits_ **23** , 358–367 (1988). 

47. Wu, C., Yu, H., Lee, S., Peng, R., Takeuchi, I. & Li, M. Programmable phase-change metasurfaces on waveguides for multimode photonic convolutional neural network. _Nat. Commun._ **12** , 1–8 (2021). 

48. Le Gallo, M., Sebastian, A., Mathis, R., Manica, M., Giefers, H., Tuma, T., Bekas, C., Curioni, A. & Eleftheriou, E. Mixed-precision in-memory computing. _Nat. Electron._ **1** , 246–253 (2018). 

49. Giannopoulos, I., Sebastian, A., Le Gallo, M., Jonnalagadda, V., Sousa, M., Boon, M.N. & Eleftheriou, E. 8-bit Precision In-Memory Multiplication with Projected Phase-Change Memory. _IEEE Int. Electron Devices Meet. IEDM_ , 27.7.1-27.7.4 (2018). 

50. Wu, Z., Lyu, Y., Zhang, Y., Ding, R., Zheng, B., Yang, Z., Lau, S. P., Chen, X. H. & Hao, J. Large-scale growth of few-layer two-dimensional black phosphorus. _Nat. Mater._ **20** , 1203–1209 (2021). 

