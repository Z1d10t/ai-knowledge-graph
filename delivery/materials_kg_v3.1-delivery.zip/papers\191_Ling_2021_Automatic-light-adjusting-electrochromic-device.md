# Automatic light-adjusting electrochromic device powered by perovskite solar cell

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 166 |
| 作者 | Huan Ling, Jian-Chang Wu, F. Su, Yan-Qing Tian, Yan-Jun Liu |
| DOI | 10.1038/s41467-021-21086-7 |
| 源文件 | 091_Ling_2021_Automatic-light-adjusting-electrochromic-device.pdf |

---


# ARTICLE 



> https://doi.org/10.1038/s41467-021-21086-7 **OPEN** 

Automatic light-adjusting electrochromic device powered by perovskite solar cell Huan Ling 1, Jianchang Wu 1, Fengyu Su 1,2,3✉, Yanqing Tian 1✉ & Yan Jun Liu 3✉ 

Electrochromic devices can modulate their light absorption under a small driving voltage, but the requirement for external electrical supplies causes response-lag. To address this problem, self-powered electrochromic devices have been studied recently. However, insensitivity to the surrounding light and unsatisfactory stability of electrochromic devices have hindered their critical applications. Herein, novel perovskite solar cell-powered all-in-one gel electrochromic devices have been assembled and studied in order to achieve automatic light adjustment. Two alkynyl-containing viologen derivatives are synthesized as electrochromic materials, the devices with very high stability (up to 70000 cycles) serves as the energy storage and smart window, while the perovskite solar cell with power-conversion-efficiency up to 18.3% serves as the light detector and power harvester. The combined devices can automatically switch between bleached and colored state to adjust light absorption with variable surrounding light intensity in real-time swiftly, which establish significant potentials for applications as modern all-day intelligent windows. 

> 1 Department of Materials Science and Engineering, Southern University of Science and Technology, Shenzhen, China. 2 Academy for Advanced Interdisciplinary Studies, Southern University of Science and Technology, Shenzhen, China.<sup>3</sup> Department of Electrical and Electronic Engineering, Southern University of Science and Technology, Shenzhen, China.<sup>✉</sup> email: fysu@sustech.edu.cn; tianyq@sustech.edu.cn; yjliu@sustech.edu.cn 

1 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

ncreased cooling demands in modern buildings and automobiles have led to increase in the consumption of energy<sup>1–3</sup> . Thus, it is Iurgent and meaningful to develop new technologies to efficiently modulate the light–heat flow between residences and surrounding environments. Smart electrochromic (EC) windows offer a promising approach since they respond to potential bias as transmittance changes smartly<sup>4–7</sup> . Though remarkable energy savings were achieved, the dependence on external power caused response-lag in light modulation for electrochromic devices (ECDs). In recent years, to address this issue, photovoltaic (PV) cell-powered ECDs have attracted intensive attention<sup>8,9</sup> . For examples, Dyer et al.<sup>10</sup> presented solar-powered transparent-magenta EC window with vertically integrated configuration containing two PV cells and a polymer ECD. Cannavale et al.<sup>11</sup> reported a combined semi-transparent PV and WO3-based ECD which was able to adjust the multifunctional device from a neutral semi-transparent to dark blue. Xia et al.<sup>12</sup> demonstrated that EC batteries were charged by perovskite solar cell (PSC) accompanied by color changes from transparent to blue color, with reduced graphene (rGO)-connected bilayer NiO nanoflake as the cathode and WO3 nanowire as the anode. These investigations dominantly utilized a sandwich configuration with a long-time coloration reservation; however, the ECD with layer-by-layer structure could easily turn to a colored state under strong light but failed to convert to transparent immediately when sunlight became weak only if a reverse potential bias was applied. In other words, conventional self-powered ECDs could not detect the change of sunlight intensity sensitively, especially to weakening light, which made the balance of outdoor vision and light–heat adjusting difficult. Additionally, the low PCE of PV cell, long response time, and unsatisfactory stability of ECD have limited these critical applications<sup>13</sup> . 

Among the configuration of ECDs, the all-in-one gel-type ECD refers to a device which is composed of an EC material, complementary material, and electrolyte in a homogeneous gel<sup>14</sup> . Unlike the conventional ECD with layer-by-layer sandwich 

configuration, all-in-one ECDs have a simpler structure and can convert to a transparent state without reversed voltage in a short duration<sup>15</sup> . Viologens, also known as bipyridine salts, have been explored intensively in all-in-one gel type ECDs<sup>16</sup> and energy storage devices<sup>17–19</sup> owing to their superior electrochemical properties in recent years. But the radical cations of viologens aggregate irreversibly on the electrode to form dimers, which would prevent the bleaching process<sup>14</sup> . These aggregations will eventually lead to poor stability. 

Aiming to develop long-term stable, dynamic tunable, and multi-colors smart ECDs, two viologens including a novel monoalkynyl-substituted viologen of 1-(pent-4-yn-1-yl)-[4,4′-bipyridin]-1-ium chloride (MPV) and a reported di-alkynylsubstituted viologen of 1,1′-di(pent-4-yn-1-yl)-[4,4′-bipyridine]1,1′-diium dichloride (DPV) were synthesized and used for the fabrication of ECDs. The synthetic route of the two viologen derivatives was shown in Fig. 1. Introduced alkynyl groups would establish donor–acceptor interactions with electron-deficient species, including even radicals inspired by the famous Sonogashira coupling reaction<sup>20</sup> and a recently reported visible-lightinduced radical alkynyl group migration reaction<sup>21</sup> . Herein, as a proof of concept, the gel-type ECD with the all-in-one configuration was integrated with PSC for automatic light-adjustment. PSC was selected as the energy harvester and light-detector due to its high photoelectric conversion efficiency, low cost, and mature assembly techniques<sup>22–30</sup> . The working schematic diagram of the combined devices was demonstrated in Fig. 2. PSC-powered ECDs can alter their colors automatically in real time depending on the surrounding solar intensity, and charged ECDs can serve as visual energy-statue ECSs (electrochromic supercapacitors) to supply other energy-consumption displays. To our delight, a large contrast ratio, excellent light sensitivity, and outstanding stability were obtained. This work may pave a new approach to develop dynamic light-tuning ECD-based commercial smart windows. 



Fig. 1 Synthetic route of MPV and DPV. One-step synthesis of mono- or di-substituted viologen compounds. 



Fig. 2 Schematic diagrams of device configurations and working principles of PSCs-powered ECS. Perovskite solar cell (left) harvests solar energy to drive ECD/ECS (middle) to different colored states under different light intensities, and the stored energy of ECS (in deep colored state) can light a red LED (right). 

2 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

## Results 

Performance of ECDs. As shown in Fig. 3a, for DPV-based ECD, the first redox couple was detected at −0.57 V (anodic peak) and −1.01 V (cathodic peak), which could be attributed to the redox process of molecular dications of DPV<sup>2+</sup> and radical cation of DPV<sup>+•</sup> . The second redox couple referred to the reaction of reversible transformation between DPV<sup>+•</sup> and full reduced species DPV<sup>0</sup> . The detected anodic peak (Epa) and cathodic peak (Epc) were −1.24 V and −1.50 V, respectively. Nevertheless, the mono-substituent MPV demonstrated solo redox pair as shown in Fig. 3b, which pointed to the exchange of 

MPV<sup>•</sup> and MPV<sup>+</sup> . The Epa(−1.00 V) and Epc(−1.87 V) of MPV were lower than the values of first redox couple of DPV. The redox process was described in Eq. (1) and Eq. (2) for DPV and MPV, respectively. The detailed kinetic studies were given in Supplementary Note 1. 



<!-- Start of picture text -->
DPV 2þ þ�#ee �� DPVþ� þ� # ee �� DPV0 ð1Þ<br><!-- End of picture text -->



<!-- Start of picture text -->
þe �<br>MPV þ �#e � MPV� ð2Þ<br><!-- End of picture text -->



Fig. 3 Performances of gel ECDs based on DPV and MPV. (DPV: a, MPV: b) Cyclic voltammograms at a scan rate of 100 mV/s; (DPV: c, MPV: d) chronoabsorptometry at different switching cycles between colored state (1.6 V for 10 s) and bleached state (−0.3 V for 10 s); (DPV: e, MPV: f) current densities versus elapsed time switching between 1.6 V (colored state, 20 s) and 0 V (bleached state, 20 s); (DPV: g, MPV: h) galvanostatic charge–discharge (GCD) curves of ECSs under increasing current densities from 3 to 10 mA/cm<sup>2</sup> . 

3 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

One of the important parameters to evaluate ECD performance is coloration efficiency (η), which can be calculated from Eq. (3): 



<!-- Start of picture text -->
η ¼ ΔOD=ΔQ ¼ logðTb=TcÞ=ΔQ ð3Þ<br><!-- End of picture text -->

where Tb, Tc were transmittance at a special wavelength in bleached and colored states, respectively; ΔQ was the required charge density for corresponding ΔOD. η was calculated by the slope of the linear region in the plots of ΔOD–ΔQ. Supplementary Fig. 3a and b gave the calculated values of the two viologen-based gel ECDs. The DPV exhibited higher η of 89.4 cm<sup>2</sup> /C at 605 nm than that of MPV of 37.2 cm<sup>2</sup> /C at 550 nm, which indicated DPV can consume less charge to achieve the same ΔOD. The CE value of 37.2 cm<sup>2</sup> /C for MPV was lower than the reported monoheptyl viologen-based ECDs (87.5 cm<sup>2</sup> /C at 546 nm by Oh et al.<sup>31</sup> , 80.7 cm<sup>2</sup> /C at 552 nm by Kim et al.<sup>32</sup> ).The value of 89.4 cm<sup>2</sup> /C of the DPV was higher than some symmetric di-substituent gel ECDs with heptyl viologen (87.3 cm<sup>2</sup> /C at 606 nm by Kim et al.<sup>32</sup> ) and dinonyl viologens (36 cm<sup>2</sup> /C at 605 nm by Lu et al.<sup>33</sup> ). 

Stability was regarded as the most significant parameter for real-world applications. To investigate the long-term stability of the two alkynyl-based viologen gel ECDs, transmittance versus time was conducted with identical time intervals (10/10 s) and switching voltages (1.6/−0.3 V). The initial ΔT of DPV-based ECD as shown in Fig. 3c was 74.3% with the switching voltage of 1.6/−0.3 V. Only 3.2% and 6.1% of ΔT was lost after 20,000 and 50,000 cycles, respectively. It is noted that the transmittance at colored state only slightly increased from 7.3% to 7.7%, even after 50,000 cycles, which indicated DPV<sup>+•</sup> did not aggregate on the electrode in the coloring process owing to the powerful interactions between alkynyl groups and radical cation when two alkynyl groups were introduced to one viologen molecule (Supplementary Fig. 2). Particularly, ΔT remained to be 60.9% after 70,000 cycles. To the best of our knowledge, the cycling stability of the DPV-based ECD was one of the best and even superior to most of the reported viologen-based ECDs (Supplementary Table 1), which demonstrated that the DPV possessed great potential for real applications. Compared to DPV, the cycling stability was relatively low for the MPV-based ECD (Fig. 3d). During the first five cycles, 62.6% of ΔT was obtained, and ΔT decreased to 43.2% after 10,000 cycles. The comparative low stability of MPV was ascribed to the aggregations of MPV<sup>•</sup> , which would impede the bleaching process. It is expected that the excellent stability of EC part would support the long-term work of the PSC-powered ECDs. 

Supplementary Fig. 4a and b showed the dynamic changes of transmittance at 605 nm and 550 nm for DPV- and MPV-based gel ECDs under the switching voltages of 1.6 V and −0.3 V. The calculated response times for MPV are 5.6 s and 5.2 s to accomplish 90% of ΔT in a span between the bleached and colored states, which are longer than 2.4 s and 2.8 s for the DPV. The steady current density (ip) in colored state was detected to be 2.78 mA/cm<sup>2</sup> for DPV and 2.16 mA/cm<sup>2</sup> for MPV at same applied voltage (Fig. 3e, f). These differences would be explained as following: the presence of radical dimers have hindered the generation of radical cation species. Instead, lower reduction potential was needed for DPV; additionally, the existence of two alkynyl groups in DPV not only restrained the formation of radical dimers, but also stabilized the produced radical cation species. As a result, DPV showed shorter coloring time and larger steady ip than those of MPV under the same switching voltages. On the other hand, MPV contained two oxidation reactions including MPV<sup>+</sup> /MPV<sup>•</sup> and MPV<sup>+</sup> /(MPV<sup>•</sup> )2 generated in the bleaching process, which led to longer bleaching time than that of DPV. In addition, the discharging time for ECDs based on DPV and MPV were 8.1 s and 9.1 s, which benefited to providing 

electrical power for external energy consumption. And the fast coloring and self-bleaching time were extremely significant to the sensitivity of PSC-powered ECDs. 

Energy storage properties as ECSs. Another fundamental function for the ECD was storing the charge from imported currents. The charging/discharging processes were accompanied with coloration and bleaching behaviors. Thus, it is likely to be regarded as a pseudocapacitor according to Fig. 3g, h. Galvanostatic charge–discharge (GCD) profiles with increasing current densities were recorded. The areal capacitor (C) was calculated from GCD curve utilizing Eq. (4): 



<!-- Start of picture text -->
C ¼ IΔt=SΔV ð4Þ<br><!-- End of picture text -->

where I, Δt, S, ΔV represent discharging current, discharging time, active areal of capacitor, and potential window, respectively. For instance, the C values were 6.7 mF/cm<sup>2</sup> , 4.9 mF/cm<sup>2</sup> , 5.0 mF/ cm<sup>2</sup> , and 2.2 mF/cm<sup>2</sup> at 3 mA/cm<sup>2</sup> , 4 mA/cm<sup>2</sup> , 5 mA/cm<sup>2</sup> , and 10 mA/cm<sup>2</sup> , respectively, for DPV-based ECS (Supplementary Fig. 5a). Supplementary Fig. 5b showed C values of MPV-based ECS (7.1 mF/cm<sup>2</sup> , 6.2 mF/cm<sup>2</sup> , 5.5 mF/cm<sup>2</sup> , and 3.5 mF/cm<sup>2</sup> at increasing current densities). It is observed that low C values were obtained at high current densities and ECS based on MPV exhibited a higher C value than DPV at same current density, which could be attributed to the faster diffusion process in ECS based on MPV. In addition, both ECSs demonstrated rapid charging/discharging process, especially very fast discharging; therefore, the coloring and bleaching processes would be completed in a short duration. Meanwhile, the stored energy in ECS could provide power for other electronics, which indicated the PSC-powered ECS has realized the functions of energy storage and reutilization. 

Performances of PSCs. Reverse structure is widely used in PSCs, where the hole transporting layer is located in the light incident side. Usually, poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA) and C60 were selected as hole transporting materials (HTMs) and electron transporting materials (ETLs) in inverted structures, while 2,2′,7,7′-Tetrakis[N,N-di(4-methoxyphenyl) amino]−9,9′-spiro-bifluorene (Spiro-OMeTAD) and TiO2 are selected for traditional structure. However, the oxygen vacancy in TiO2 (ref.<sup>34</sup> ) and the dopant in Spiro-OMeTAD layer<sup>35,36</sup> would accelerate the degradation of perovskite. Therefore, devices with inverted structure were selected as the power for ECD<sup>37,38</sup> . Supplementary Fig. 6a demonstrated the exact structure of the PSC. The deposition method of PSCs was similar to our previous work<sup>39</sup> . The perovskite was deposited on HTM. PEDOT:PSS and PTAA are star HTMs for PSCs, device based on PEDOT: PSS always shows a low open-circuit voltage (Voc) because of unmatched energy levels, which is harmful for powering the connected EC capacitor. Thus, aiming to achieve relatively high voltage to drive the ECD, we selected PTAA as the HTM. As depicted in Table 1, the PSC device can produce a Voc of 1.02 V with a short-circuit current of 22.8 mA/cm<sup>2</sup> and fill factor of 78.4% under illumination, and reasonable high PCE of 18.3% was achieved according to Supplementary Fig. 6b, which was better than reported work<sup>40,41</sup> . High PCE guaranteed the robust power 

Table 1 Parameters of fabricated PSCs. 

||PCE (%)|VOC (V)|JSC|(mA/cm<sup>2</sup>)|FF (%)|
|---|---|---|---|---|---|
|Reserve scan|17.7|1.0|22.1||80.2|
|Forward scan|18.3|1.02|22.8||78.4|



PCE = Voc × Jsc × FF; Voc: open-circuit voltage; Jsc: short-circuit current density; FF: fill factor. 

4 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

for the ECDs. The PSCs generated the voltage and current, making the ECD change from transparent to a colored state, indicating the solar cell could power the ECD and the electrical power is stored in the ECD. 

Performances of PSC-powered ECDs. To detect the light sensitivity of PSC-powered ECDs, we have investigated the alterations of UV-visible spectrum opposing different light density and monitor the color changes in natural sunlight. As shown in Fig. 4a, e, the whole transmittance in visible range increased gradually with the weakening of light density. Both ECDs turned to highly transparent automatically. The corresponding characteristic peaks for DPV- and MPV-based PSC-powered ECDs were 605 nm and 550 nm, which were consistent with spectrum under common extra voltage exhibited in Supplementary Fig. 7. Afterward, in natural climate, the ECDs demonstrated excellent self-powered, smartly tunable features. For the DPV-based ECDs shown in Fig. 4b, d, a deep blue color was detected under high light density since more excitons were generated in PSCs when higher solar energy from sunlight was harvested, which initiated larger current (or electrons) to reduce more DPV<sup>2+</sup> to DPV<sup>+•</sup> species. With descending light density, the ECD demonstrated a light blue color because the current dropped. Finally, the ECDs transferred to highly transparent when the PSCs were blocked. Similarly, MPV-based ECDs were able to change the appearance depending on the natural surrounding sunlight. However, the distinction was that magenta-blue colors appeared with the drop of light density (Fig. 4f, h). The multi-colors of MPV-based ECDs were more convenient for us to evaluate the surrounding sunlight 

intensity and the stored power quantity in variable weather according to the color type and depth. In addition, we also conducted the switching stability of PSC-powered ECD in strong light/no light surrounding under moisture conditions as shown in Fig. 4i, j, both PSCs-powered ECDs did not show any decay after 2000 s constant working (ΔT = 71%, 62% for DPV and MPV, respectively) in air condition, which revealed good switching stability and fast response time (<30 s) for both of these combined devices (Supplementary Fig. 8). In addition, both charged ECDs with deep coloration (under strong light intensity) could drive a red LED successfully (Fig. 4k, l) as supercapacitors. These brilliant results suggested that PSC-powered ECDs possess a remarkable advantage to modulate the sunlight and could serve as an intelligent-curtain. When exterior sunlight intensity changed frequently, the unpredictable optical radiation and energy flow problems lead to a poor living experience. Different from the present solutions like using air-conditions to cool down and curtains to shade individually, this intelligent-curtain addressed the two main problems together. As depicted in Fig. 5, with the increasing of light intensity from 6:00 to 12:00, the transmittance dropped and the appearance of ECD transferred to colored state gradually. Afterward, with the decline of light density in afternoon, the color of intelligent-curtain will be shoaled automatically to let more light in to warm the house. Finally, it gets highly transparent near the evening, which gives us a good insight to observe the scenery outside as a classic window. The annual energy consumption of the PSC-powered ECD is given in detail in Supplementary Note 2. 

Colorimetric system was utilized to qualitatively characterize the colors through three parameters including L*, a*, b*, where 



Fig. 4 Performances of PSC-powered ECS based on DPV and MPV. UV-visible spectra of ECDs powered by two connected PSCs with decreased light density for DPV (a) and MPV (e); PSCs powered ECD in natural surrounding with strong light, weak light, and no light (b, c, d for DPV-based ECD and f, g, h for MPV-based ECD); transmittance switching tests under strong light and no light of PSC-powered ECD at maximum absorption (i: DPV, j: MPV); lighting LED by two connected ECDs (k DPV, l MPV). 

5 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

L* is lightness, and a* and b* were used to assess the green–red and blue–yellow colors, respectively. In order to evaluate the realtime response performances of intelligent ECDs, we simulate the change of outdoor light intensity through adjusting the distance between the illuminant and PSCs in situ as shown in Fig. 6a. When the distance L was 0.05 m, the PSCs were exposed to the light with high intensity, resulting in the values of L*/a*/b* being 36.29/0.42/−34.55 (Table 2) and 40.83/17.19/−20.37 (Table 3) for DPV- and MPV-based ECDs, respectively, which indicated deep blue and purple colors were obtained. With the increasing of L, as well as the decreasing of light intensity, the L* value for both ECDs rises gradually, while the colors simultaneously became shallower, which were proved by the decreasing |b*| for DPV and decreasing |a*| and |b*| for MPV. When the illumination was removed, the high L* and low |a*| and |b*| suggested ECDs were converted to highly transparent. Figure 6b, c vividly demonstrated the real-time color changes under different light intensity. These results confirmed that the PSC-powered ECDs possess excellent light sensitivity to alter their transparency and colors according to the surrounding light intensity, which paved a new way to design unprecedented intelligent-curtain. 

## Discussion 

In summary, the ECDs based on dipentynyl substituted viologen, DPV, worked very well up to 70,000 cycles. The outstanding stability was attributed to the intermolecular interactions between viologen radical species and alkynyl groups. As a proof of 



Fig. 5 Automatic light adjustment of PSC-powered ECDs in real-time. Digital images of outdoor sceneries viewed through PSC-powered ECDs by blocking device on the lens of the camera at different times (a: DPV; b: MPV). 

concept, ECDs with all-in-one gel configuration were combined with PSCs to realize the automatically dynamic light-adjusting. Two self-powered and light-sensitive intelligent-curtains with MPV- and DPV-based devices as the ECD part, and PSCs as the energy harvester were successfully fabricated. The characterizations and tests were performed in indoor and outdoor circumstances. Among them, DPV-based ECD exhibited transparentdeep blue color as the light intensity changed, and MPV-based ECD demonstrated transparent-blue-magenta colors depending on the light intensity. High optical contrasts, excellent light sensitivity, and excellent stability were achieved. Furthermore, energy harvesting, storage, and light regulation could change realtime responding to the surrounding light sensitively. Smart modulation of the solar radiation contributes to visual comfort for people. When the sunlight is strong, PSC harvests more energy and drive the EC into dark state, EC could permit less solar radiation to enter the building, therefore people inside will feel more comfortable under a weaker light than outside; on the other hand, when the sunlight is weak, PSC harvests less energy and drive the EC into relative bright state, EC could permit more solar radiation to enter the building, thus people inside will feel more comfortable under a brighter light. In addition, we can evaluate the light density and stored power by the colors and shades of ECDs. And the stored electrical energy successfully provided power to a LED. These extraordinary results suggest huge potentials of PSC-powered ECDs being applied for all-day intelligent-curtains and advanced electronic displays. However, considering the latent toxicity of DPV and MPV, strict sealing work would be required if PSC-powered ECDs were applied in modern buildings and automobiles. 

## Methods 

Materials and synthesis. The commercially available raw chemicals were used without further purification. 4,4′-Bipyridine was obtained from J&K Chemical (Beijing, China). HCl was purchased from Damao Chemical Ltd. (Shanghai, China). 5-Chloro-1-pentylene was obtained from Aladdin (Shanghai China). All solvents were purchased from XiLong Scientific (Guangzhou, China). ITO glass was purchased from NSG Group (Osaka, Japan). 

Nuclear magnetic resonance (NMR) spectra were acquired through NMR (Bruker 400M, Bremen, German). The electrochemical properties were characterized by electrochemical workstation (Ametek Parstat 3000A-DX, Berwyn, USA). The optical properties were measured by UV-vis spectrophotometer (PerkinElmer L6020365, Waltham, USA) and Colorimeter (CHN Spec CS-820, Guangzhou, China) combined with Waveform Generator (Rigol DG4102 Function/Arbitrary, Suzhou, China). A digital camera was used to record the photographs of the devices. 

Synthesis of 1-(pent-4-yn-1-yl)-[4,4′-bipyridin]-1-ium chloride (MPV). A total of 0.3 g (1.9 mmol) of 4,4′-bipyridine and 0.176 g (1.7 mmol) of 5-chloro-1-pentylene were dissolved in 2 ml of DMF. The mixture was heated to 90 °C and stirred for 16 h. After that, the residue was cooled to r.t. and then concentrated under reduced pressure. Finally, the mixture was purified by fresh silica gel to give the 1-(pent-4-yn-1-yl)-[4,4′- 



Fig. 6 Colorimetric tests of PSC-powered ECDs under different light intensities. a Schematic diagram for colorimetric test of ECD; colorimetric diagrams of DPV (b) and MPV (c) based PSC-powered ECDs with descending light intensity. 

6 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

## Table 2 L*, a*, and b* changes with different light density of DPV-based PSC-powered ECD. 

|L (m)|L*|a*|b*|
|---|---|---|---|
|0.05|36.29|0.42|−34.55|
|0.1|36.16|0.57|−34.47|
|0.2|39.13|−3.07|−34.87|
|0.3|43.61|−8.26|−32.72|
|0.4|47.59|−11.6|−29.45|
|0.5|48.47|−12.18|−28.62|
|0.6|52.62|−14.03|−24.3|
|0.7|64.42|−13.25|−9.84|
|0.8|66.21|−12.44|−7.42|
|1|75.09|−6.99|4.66|
|No light|75.97|−6.29|5.95|



1300 r.p.m. for 30 s, and then a thermal annealing at 150 °C for 15 min in an ambient air condition (20–30% humidity) was conducted. Then, the samples were transferred to a vacuum chamber. C60 (40 nm thick)/2, 9-dimethyl-4, 7-diphenyl-1, 10-phenanthroline, (BCP, 8 nm thick)/Ag (100 nm thick) were thermally evaporated in a vacuum chamber with the base pressure of <10<sup>−4</sup> Pa. 

Photocurrent density–voltage (J–V) curves were measured under AM 1.5G one sun illumination (100 mW/cm<sup>2</sup> ) with a solar simulator (Enlitech SS-F7-3A) equipped with 300 W Xenon lamp and a Keithley 2400 source meter. The light intensity was adjusted by an NREL-calibrated Si solar cell. During measurement, the cell was covered with a mask with an aperture of 0.0576 cm<sup>2</sup> . The J–V curves were recorded from −0.2 to 1.2 V (forward scan) or from 1.2 to −0.2 V (reverse scan) with 0.01 V steps, integrating the signal for 10 ms after a 10-ms delay. 

Reporting summary. Further information on experimental design is available in the Nature Research Reporting Summary linked to this paper. 

## Data availability 

The data that support the findings of this study are available from the corresponding authors on request. 

## Table 3 L*, a*, and b* changes with different light density of MPV-based PSC-powered ECD. 

|L|L*|a*|b*|
|---|---|---|---|
|0.05|40.83|17.19|−20.37|
|0.1|41.82|16.87|−20.9|
|0.2|46.27|11.15|−22.15|
|0.3|47.17|9.97|−22.26|
|0.4|51.23|3.23|−23|
|0.5|56.13|−2.9|−22.65|
|0.6|58.75|−4.77|−21.76|
|0.7|61.76|−7.24|−20.04|
|0.8|65.17|−8.17|−16.13|
|1|77.88|−3.93|11.1|
|No light|78.82|−3.66|11.82|



bipyridin]-1-ium chloride (MPV) as a gray solid (0.1 g, 20% yield).<sup>1</sup> H NMR (400 MHz, deuterium oxide) δ 9.09 (d, J = 6.7 Hz, 2H), 8.48 (d, J = 6.3 Hz 4H), 4.80 (t, J = 6.8 Hz, 4H), 2.39–2.05 (m, 10H).<sup>13</sup> C NMR (101 MHz, deuterium oxide) δ 153.98, 150.01, 145.05, 142.51, 126.09, 122.47, 82.08, 70.78, 60.29, 28.77, 14.56. HRMS m/z calcd for C15H15N2 ([M]<sup>+</sup> ) 223.1230, found 223.1231. 

### Synthesis of 1,1′-di(pent-4-yn-1-yl)-[4,4′-bipyridine]-1,1′-diium dichloride 

(DPV). A total of 0.3 g (1.9 mmol) of 4,4′-bipyridine and 0.49 g (4.8 mmol) of 5- chloro-1-pentylene were dissolved in 2 ml of DMF. The mixture was heated to 110 °C and stirred for 48 h. After that, the residue was cooled to r.t. and the precipitate was filtered and washed by DMF (3 × 2 ml), then dried in vacuum to give 1,1′-di(pent-4yn-1-yl)-[4,4′-bipyridine]-1,1′-diium dichloride (DPV) as a gray solid (450 mg, 66% yield).<sup>1</sup> H NMR (400 MHz, deuterium oxide) δ 8.94 (d, J = 6.8 Hz, 2H), 8.66 (s, 2H), 8.33 (s, 2H), 7.82 (s, 2H), 4.74 (t, J = 6.8 Hz, 2H), 2.40–1.98 (m, 5H).<sup>13</sup> C NMR (101 MHz, D2O) δ 150.24, 145.77, 127.04, 82.39, 71.13, 60.85, 28.77, 14.56. HRMS m/z calcd for C20H22N2 ([M]<sup>2+</sup> ) 145.0886, found 145.0889. 

Fabrication of ECDs. The preparation of MPV- and DPV-based EC gels was described as follows: 0.1 mmol of viologen, 150 mg of propylene carbonate (PC), 23 mg of ferrocene, 160 mg of lithium bis-(trifluoromethane)sulfonimide, and 300 mg of PVB (polyvinyl butyral) were dissolved in 1.5 ml of dried CH3OH. The mixture was stirred under N2 atmosphere for 3 h and was placed for a period of time without stirring for eliminating bubbles during the gel preparation. 

The prepared gel was injected into liquid crystal cells. The distance of 70 μm between the two electrodes was controlled by parafilm. The effective area of ECDs appeared as a circle with a radius of 0.8 cm (S = 2 cm<sup>2</sup> ). 

Fabrication of PSCs. ITO glass was cleaned by sequentially washing with deionized (DI) water, acetone, and isopropanol (IPA). Before using, the ITO was cleaned by ultraviolet ozone (UVO) for 20 min. Then, the substrate was spin coated with a thin layer of PTAA (2 mg/ml in chlorobenzene) at 5000 r.p.m./min for 25 s, and annealed at 100 °C for 10 min. The perovskite layer was deposited by a two-step sequential spin-coating method. Then, 60 μL of PbI2 precursor (600 mg of PbI2 dissolved in 1 ml of DMF:DMSO = 95:5 by volume) was spin coated on the substrate at 1500 r.p.m. Then, the mixture solution of formamidinium iodide (FAI): methylammonium bromide (MABr): methylamine chloride (MACl, 60 mg: 6 mg: 6 mg in 1 ml of isopropyl alcohol (IPA)) was spin-coated onto the PbI2 film at 

## Received: 30 July 2020; Accepted: 4 January 2021; 



## References 

1. Cannavale, A., Ayr, U., Fiorito, F. & Martellotta, F. Smart electrochromic windows to enhance building energy efficiency and visual comfort. Energies 13, 1449 (2020). 

2. Xu, J., Chen, Y. & Dai, L. Efficiently photo-charging lithium-ion battery by perovskite solar cell. Nat. Commun. 6, 8103 (2015). 

3. Davy, N. C. et al. Pairing of near-ultraviolet solar cells with electrochromic windows for smart management of the solar spectrum. Nat. Energy 2, 17104 (2017). 

4. Cai, G., Wang, J. & Lee, P. S. Next-generation multifunctional electrochromic devices. Acc. Chem. Res. 49, 1469–1476 (2016). 

5. Deb, S. K. Reminiscences on the discovery of electrochromic phenomena in transition metal oxides. Sol. Energy Mater. Sol. Cells 39, 191–201 (1995). 

6. Granqvist, C. G. Oxide electrochromics: why, how, and whither. Sol. Energy Mater. Sol. Cells 92, 203–208 (2008). 

7. Wen, R.-T., Granqvist, C. G. & Niklasson, G. A. Eliminating degradation and uncovering ion-trapping dynamics in electrochromic WO3 thin films. Nat. Mater. 14, 996–1001 (2015). 

8. Wang, Y. et al. Solar driven electrochromic photoelectrochemical fuel cells for simultaneous energy conversion, storage and self-powered sensing. Nanoscale 10, 3421–3428 (2018). 

9. Bechinger, C., Ferrere, S., Zaban, A., Sprague, J. & Gregg, B. A. Photoelectrochromic windows and displays. Nature 383, 608–610 (1996). 

10. Dyer, A. L. et al. A vertically integrated solar-powered electrochromic window for energy efficient buildings. Adv. Mater. 26, 4895–4900 (2014). 

11. Cannavale, A. et al. Perovskite photovoltachromic cells for building integration. Energy Environ. Sci. 8, 1578–1584 (2015). 

12. Xia, X. et al. Perovskite solar cell powered electrochromic batteries for smart windows. Mater. Horiz. 3, 588–595 (2016). 

13. Batmunkh, M., Zhong, Y. L. & Zhao, H. Recent advances in perovskite-based building-integrated photovoltaics. Adv. Mater. 32, e2000631 (2020). 

14. Alesanco, Y., Vinuales, A., Rodriguez, J. & Tena-Zaera, R. All-in-one gel-based electrochromic devices: strengths and recent developments. Materials (Basel) 11, 414 (2018). 

15. Gelinas, B., Das, D. & Rochefort, D. Air-stable, self-bleaching electrochromic device based on viologen- and ferrocene-containing triflimide redox ionic liquids. ACS Appl. Mater. Interfaces 9, 28726–28736 (2017). 

16. Madasamy, K., Velayutham, D., Suryanarayanan, V., Kathiresan, M. & Ho, K.C. Viologen-based electrochromic materials and devices. J. Mater. Chem. C 7, 4622–4637 (2019). 

17. Li, G. et al. Electrochromic poly(chalcogenoviologen)s as anode materials for high-performance organic radical lithium-ion batteries. Angew. Chem. Int. Ed. 58, 8468–8473 (2019). 

18. Liu, T., Wei, X., Nie, Z., Sprenkle, V. & Wang, W. A total organic aqueous redox flow battery employing a low cost and sustainable methyl viologen anolyte and 4-HO-TEMPO catholyte. Adv. Energy Mater. 6, 1501449 (2016). 

19. Sathyamoorthi, S., Kanagaraj, M., Kathiresan, M., Suryanarayanan, V. & Velayutham, D. Ethyl viologen dibromide as a novel dual redox shuttle for supercapacitors. J. Mater. Chem. A 4, 4562–4569 (2016). 

20. Chen, Q. et al. Sonogashira cross-coupling of aryltrimethylammonium salts. ACS Catal. 9, 3730–3736 (2019). 

7 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21086-7 

21. Xu, Y., Wu, Z., Jiang, J., Ke, Z. & Zhu, C. Merging distal alkynyl migration and photoredox catalysis for radical trifluoromethylative alkynylation of unactivated olefins. Angew. Chem. Int. Ed. 56, 4545–4548 (2017). 

22. Mitzi, D. B. Introduction: perovskites. Chem. Rev. 119, 3033–3035 (2019). 

23. Zheng, X. et al. Managing grains and interfaces via ligand anchoring enables 

   - 22.3%-efficiency inverted perovskite solar cells. Nat. Energy 5, 131–140 (2020). 

24. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of α-phase formamidinium lead iodide. Science 366, 749–753 (2019). 

25. Lin, Y. H. et al. A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. Science 369, 96–102 (2020). 

26. Wolff, C. M. et al. Perfluorinated self-assembled monolayers enhance the stability and efficiency of inverted perovskite solar cells. ACS Nano 14, 1445–1456 (2020). 

27. Liu, Z. et al. A holistic approach to interface stabilization for efficient perovskite solar modules with over 2,000-hour operational stability. Nat. Energy 5, 596–604 (2020). 

28. Zhao, Y. et al. A polymerization-assisted grain growth strategy for efficient and stable perovskite solar cells. Adv. Mater. 32, 1907769 (2020). 

29. Zhu, H. et al. Tailored amphiphilic molecular mitigators for stable perovskite solar cells with 23.5% efficiency. Adv. Mater. 32, 1907757 (2020). 

30. Jeong, M. et al. Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. Science 369, 1615 (2020). 

31. Oh, H., Seo, D. G., Yun, T. Y., Kim, C. Y. & Moon, H. C. Voltage-tunable multicolor, sub-1.5 V, flexible electrochromic devices based on ion gels. ACS Appl. Mater. Interfaces 9, 7658–7665 (2017). 

32. Kim, J. W. & Myoung, J. M. Flexible and transparent electrochromic displays with simultaneously implementable subpixelated ion gel‐based viologens by multiple patterning. Adv. Funct. Mater. 29, 1808911 (2019). 

33. Lu, H. C. et al. Achieving low-energy driven viologens-based electrochromic devices utilizing polymeric ionic liquids. ACS Appl. Mater. Interfaces 8, 30351–30361 (2016). 

34. Mabrouk, S. et al. Increased efficiency for perovskite photovoltaics via doping the PbI2 layer. J. Phys. Chem. C 120, 24577–24582 (2016). 

35. Calio, L., Kazim, S., Gratzel, M. & Ahmad, S. J. A. C. Hole‐transport materials for perovskite solar cells. Angew. Chem. Int. Ed. 55, 14522–14545 (2016). 

36. Wu, J. et al. Polystyrene with a methoxytriphenylamine-conjugated-thiophene moiety side-chain as a dopant-free hole-transporting material for perovskite solar cells. J. Mater. Chem. C 6, 13123–13132 (2018). 

37. Chen, Y. et al. Design of an inorganic mesoporous hole-transporting layer for highly efficient and stable inverted perovskite solar cells. Adv. Mater. 30, 1805660 (2018). 

38. Jia, L. et al. Double fullerene cathode buffer layers afford highly efficient and stable inverted planar perovskite solar cells. Org. Electron. 82, 105726 (2020). 

39. Hu, M. et al. Electron transporting bilayer of SnO2 and TiO2 nanocolloid enables highly efficient planar perovskite solar cells. Sol. RRL 4, 1900331 (2019). 

40. Ye, T. et al. Enhanced efficiency of planar heterojunction perovskite solar cells by a light soaking treatment on tris (pentafluorophenyl)borane-doped poly (triarylamine) solution. ACS Appl. Mater. Interfaces 11, 14004–14010 (2019). 

41. Zhao, Q. et al. Achieving efficient inverted planar perovskite solar cells with nondoped PTAA as a hole transport layer. Org. Electron. 71, 106–112 (2019). 

## Acknowledgements 

The authors would like to thank Shenzhen fundamental research programs (JCYJ20170817111349280, JCYJ20170412152922553, and JCYJ20180305180635082), and the start-up fund of SUSTech (Y01256114), the High-level university construction fund for SUSTech (G01256018), the National Key Research and Development Project funding from the Ministry of Science and Technology of China (grants no. 2016YFA0202400 and 2016YFA0202404), the Peacock Team Project funding from Shenzhen Science and Technology Innovation Committee (grant no. KQTD2015033110182370). This paper is dedicated to the 10th anniversary of Southern University of Science and Technology. 

## Author contributions 

H.L. designed and prepared the devices and performed the electrochromic tests. J.W. designed and carried out the tests of the perovskite solar cells. H.L. and F.S. conceived the idea and wrote the manuscript. Y.T. and Y.J.L. supervised the whole project and revised the manuscript. All authors discussed the results and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-21086-7. 

Correspondence and requests for materials should be addressed to F.S., Y.T. or Y.J.L. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021 

8 

NATURE COMMUNICATIONS | (2021) 12:1010 | https://doi.org/10.1038/s41467-021-21086-7 | www.nature.com/naturecommunications 

