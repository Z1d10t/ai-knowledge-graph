# Overcoming C60-induced interfacial recombination in inverted perovskite solar cells by electron-transporting carborane

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 171 |
| 作者 | Fangyuan Ye, Shuo Zhang, Jonathan H. Warby, Jiawei Wu, Emilio Gutiérrez-Partida, F. Lang, Sahil Shah, Elifnaz Sağlamkaya et al. |
| DOI | 10.1038/s41467-022-34203-x |
| 源文件 | 079_Ye_2022_Overcoming-C60-induced-interfacial-recombination.pdf |

---
Article 



https://doi.org/10.1038/s41467-022-34203-x 

# Overcoming C60-induced interfacial recombination in inverted perovskite solar cells by electron-transporting carborane 

Received: 17 May 2022 Fangyuan Ye<sup>1,2</sup> , Shuo Zhang<sup>1</sup> , Jonathan Warby<sup>2</sup> , Jiawei Wu<sup>3</sup> , Emilio Gutierrez-Partida<sup>2</sup> , Felix Lang<sup>2</sup> , Sahil Shah<sup>2</sup> , Elifnaz Saglamkaya<sup>2</sup> , Accepted: 17 October 2022 Bowen Sun<sup>2</sup> , Fengshuo Zu<sup>4</sup> , Safa Shoaee 2, Haifeng Wang3, Burkhard Stiller2, Dieter Neher 2, Wei-Hong Zhu 1, Martin Stolterfoht 2 & Yongzhen Wu 1 Check for updates Inverted perovskite solar cells still suffer from significant non-radiative recombination losses at the perovskite surface and across the perovskite/C60 interface, limiting the future development of perovskite-based single- and multi-junction photovoltaics. Therefore, more effective inter- or transport layers are urgently required. To tackle these recombination losses, we introduce ortho-carborane as an interlayer material that has a spherical molecular structure and a three-dimensional aromaticity. Based on a variety of experimental techniques, we show that ortho-carborane decorated with phenylamino groups effectively passivates the perovskite surface and essentially eliminates the non-radiative recombination loss across the perovskite/C60 interface with high thermal stability. We further demonstrate the potential of carborane as an electron transport material, facilitating electron extraction while blocking holes from the interface. The resulting inverted perovskite solar cells deliver a power conversion efficiency of over 23% with a low non-radiative voltage loss of 110 mV, and retain >97% of the initial efficiency after 400 h of maximum power point tracking. Overall, the designed carborane based interlayer simultaneously enables passivation, electron-transport and hole-blocking and paves the way toward more efficient and stable perovskite solar cells. 

Perovskite-based tandem solar cells are almost exclusively based on inverted (pin-type) perovskite cells due to their thin charge transport layers (nm to tens of nm) and absence of high-temperature treatments during fabrication (below 100 °C)<sup>1–8</sup> . Thus, improving the performance of these pin-type devices is an important task as this is where perovskites will likely enter the market for renewable energy generation. For record- 

level pin-type cells it has been shown that the voltage loss is governed by the top electron transport layer (e.g., C60 or PCBM), and this is quite irrespective of the involved perovskite composition (Fig. 1a). However, the non-radiative recombination at the perovskite/C60 interface and the involved defect states remain fundamentally poorly understood<sup>9–12</sup> . Recent results in this regard have shown that recombination occurs 

> 1Key Laboratory for Advanced Materials and Joint International Research Laboratory of Precision Chemistry and Molecular Engineering, Shanghai Key Laboratory of Functional Materials Chemistry, Frontiers Science Center for Materiobiology and Dynamic Chemistry, Institute of Fine Chemicals, School of Chemistry and Molecular Engineering, East China University of Science & Technology, Shanghai 200237, China.<sup>2</sup> Institute of Physics and Astronomy, University of Potsdam, D-14476 Potsdam-Golm, Germany.<sup>3</sup> Centre for Computational Chemistry and Research Institute of Industrial Catalysis, School of Chemistry and Molecular Engineering, East China University of Science & Technology, Shanghai 200237, China.<sup>4</sup> Humboldt-Universitat zu Berlin, Institut fur Physik & IRIS Adlershof, Brook-Taylor Straße 6, 12489 Berlin, Germany. e-mail: martin.stolterfoht@uni-potsdam.de; wu.yongzhen@ecust.edu.cn 

Nature Communications |  (2022) 13:7454 

1 

Article 

https://doi.org/10.1038/s41467-022-34203-x 



<!-- Start of picture text -->
a Pure Iodide 2D/3D Triple Cation d<br> Neat<br>10 -1  Pero/C60 10000 0.01<br>Full stack<br>10 -2<br>SCLC region<br>0.001<br>10 -3<br>1000 1 2 3 4 5<br>10 -4 V (voltage)<br>10 -5<br>100<br>b c -1.7 CB interlayer<br>-2<br>Ag e - 10<br>-3 -3.3<br>C60 CB -4 -3.9 -3.9 -4.0<br>CB interlayer<br>-5 1<br>Perovskite -6 -5.2 -5.4 CB-NH2<br>-6.0<br>h + C60<br>MeO-2PACz -7<br>-7.4<br>0.1 1<br>ITO/Glass CB-NH2 -8.2 Bias voltage (V)<br>Cs0.05FA0.95FAPbI0.8MA3 0.2PbI3MAPbI3MAPbIMAPbI33 co-evapBA4 2DBA3 2DBA2 2D95-5 TC83:17 TC83-17 TC83-17 TC76:24 TC70:30 TC60:40 TC50:50 TC<br>2-1-1)Vs<br>m<br>c<br>Y<br>Q ( ytilib<br>L o<br>P M<br>2)<br>m<br>c/<br>A<br>m<br>( ytis<br>n<br>e<br>d<br> t<br>)V ne<br>e rr<br>(  u<br>m C<br>m<br>u<br>c<br>a<br>v .s MeO-2PACz PVK CB 60C<br>v y<br>reg 2CB-NH<br>n<br>E<br><!-- End of picture text -->

Fig. 1 | Universal photoluminescence quantum yield (PLQY) losses induced by C60, device structure and energy level diagram. a C60-induced recombination losses in various pin-type perovskite systems. Data reproduced with permission from Warby, J. et al. Understanding Performance Limiting Interfacial Recombination in pin Perovskite Solar Cells. Adv. Energy Mater. 2022, 12, 2103567. 10.1002/ aenm.202103567 under a CC BY license https://creativecommons.org/licenses/by/ 4.0/.12 C60 lowers the PLQY to ≈1 × 10<sup>−4</sup> −1 × 10<sup>−3</sup> of the neat layer, for various perovskite compositions represented by the different shading, such as methyl ammonium lead iodide (MAPbI3), double cation (FA0.8MA0.2PbI3) and triple-cation perovskites (Cs0.05FAxMAyPb(IxBry)3) which are denoted as “TC”, where the x:y ratio 

reflects the molar ration of FAPbI3 versus MAPbBr3, 2D/3D perovskites are denoted by the spacer cation butylammonium (BA) and the number of layers of octahedra between spacer cations, e.g., n = 4 is BA4. b Device structure and molecule structures of o-carborane (CB) as well as phenylamino decorated carborane (CB-NH2). c Energy levels based on cyclic voltammetry and literature values. d Space-charge limited current measurement of electron-only devices with the configuration of ITO/ZnO/ CB-NH2 (100 nm) or C60 (200 nm)/BCP/Ag. The inset shows the mobility variation under different bias voltages. Source data are provided as a Source Data file. 

predominantly across the interface<sup>12</sup> , likely due to a small energy level offset between the conduction band minimum of the perovskite and the lowest unoccupied molecular orbital (LUMO) level of C6013, or charge transfer states at the interface<sup>12,14</sup> . Thus, it is critical to improve the energy alignment, passivate defects on the perovskite surface or repel minority carriers from the interface. However, to our knowledge, up to now, no study has been able to entirely suppress the interfacial recombination in the presence of the C60 layer. 

Notwithstanding this point, there have been many attempts to reduce recombination at the perovskite surface and across the perovskite/transport layer interfaces. Noteworthy for nip-structured perovskite solar cells (PSCs), Sutuanto et al.<sup>15</sup> showed that the implementation of a two-dimensional (2D) layer (~50 nm thick) on the perovskite surface essentially eliminates the interfacial recombination by preventing minority carriers from reaching the interface between Spiro-OMeTAD and the perovskite. This is due to the nearly lossless interface between the 3D and 2D perovskites and the appreciable thickness of the 2D perovskite layer, which physically separates electrons and holes, thus reducing interface recombination. Indeed, the use of 2D/3D perovskites at the top interface in nip cells is very prevalent and enabled high open-circuit voltages (VOCs)<sup>16–18</sup> . It, therefore, follows that a similar hole-blocking layer for pin cells should lead to reduced voltage losses, however, given the opposite charge polarity, the implementation of these 2D/3D layers in pin-type cells has been challenging. Nevertheless, the formation of 2D wide gap perovskites was recently demonstrated in several publications via phenethylammonium (PEA)based molecules which improved the VOC of pin-type perovskite cells<sup>19–21</sup> . A similar surface modification strategy is based on sulfate 

(SO42−) and phosphate (PO43−) dissolved in isopropanol or toluene22,23. Employed as a surface treatment, these molecules form a thin lead oxysalt layer (PbSO4 and Pb3(PO4)2) on the perovskite surface, which can stabilize under-coordinated bonds on the perovskite surface and improve the stability (T80 lifetimes of over 1000 h at 65 °C were reported)<sup>22</sup> . Despite this success, the long-term stability of 2D layers remains a concern, for example, due to the possible interdiffusion and mixing of the 2D/3D perovskite layers as discussed in a previous work<sup>24</sup> . 

Alternatively, some insulating layers were used to reduce the interfacial recombination without the concern of interdiffusion. For example, commercially available insulating polymers (such as PMMA and PS) have been utilized as interlayers between the perovskite and C60 for pin-type and for nip-type PSCs<sup>25–28</sup> . Moreover, the inorganic insulator LiF has been found effective at reducing the non-radiative recombination loss at the interface for various perovskite systems via the formation of a surface dipole that facilitates the extraction of electrons<sup>9,29</sup> . However, it should be noted that LiF/C60 still reduces the photoluminescence quantum yield (PLQY) of the neat layer by a factor of ~10 in the case of triple-cation perovskites, and again there are concerns regarding the long-term stability<sup>29,30</sup> . Generally, the application of insulating layers leads to the formation of a tunneling contact. However, the application of intrinsically insulating layers limits the ability to block minority charges without compromising the charge transport and thus fill factor (FF) performance. In addition, insulating layers may also cause a loss of the VOC as their low conductivity can lead to a gradient in the quasi-Fermi level of majority charges, resulting in a mismatch between internal and external VOC (“quasi-Fermi level splitting (QFLS)-VOC” mismatch)<sup>30–32</sup> . This is, for example, observed 

Nature Communications |  (2022) 13:7454 

2 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

when increasing the thickness of a PMMA interlayer (Supplementary Figs. 1 and 2). Thus, an effective and highly selective electron transport layer requires good hole-blocking properties and good electron transport capacities to simultaneously increase the FF and VOC. 

In this regard, carboranes are an interesting class of spherical molecules with three-dimensional aromaticity, which are potential electron-transporting materials but have not yet been explored in the field of PSCs. These molecules are composed of carbon, boron, and hydrogen and often form polyhedrons. Polyhedral and spherical molecules with delocalized π-orbitals are ideal for thin film organic transport layers due to their omnidirectional charge transport. They are also tunable as one can functionalize these molecules with various functional groups to tune the electronic structure and other properties of interest<sup>33,34</sup> . Furthermore, they have previously been used in light-emitting diodes<sup>35,36</sup> and as building block of hole-transporting materials in PSCs to improve the charge transfer rate<sup>37</sup> . 

Herein, we introduced ortho-carborane (CB, C2B10H12) as an interfacial layer in low-gap triple-cation pin-based PSCs to assist electron extraction and reduce across interface non-radiative recombination. We demonstrate the electron transport potential of functionalized caboranes. We additionally investigated CB functionalized by phenylamino groups (CB-NH2), which are Lewis bases that are reported to passivate perovskite surface defects. Besides, carborane exhibits a large ionization potential thus, it is effective at blocking holes when employed as a selective transport layer. It is also hydrophobic, which effectively improves the water resistance of the perovskite device. Using CB-NH2 as an interlayer we achieve a power conversion efficiency (PCE) of over 23% with low non-radiative voltage losses of 110 mV, in pin single junctions, and the PCE retains over 97% of its initial value after 400 h operation under maximum power point (MPP) conditions at 1-sun illumination and room temperature. A variety of experimental investigations indicate that CB-NH2 can overcome the long-standing C60-induced interfacial recombination in inverted PSCs. 

## Results 

### Molecular synthesis and energy levels of carborane 

O-carborane is commercially available, however, due to its low molecular weight in combination with weak intermolecular forces it has a low sublimation temperature under reduced pressure. This limits its use as an ETL because the thin films can evaporate under high vacuum during the completion of the device (e.g., evaporation of metal electrodes). We therefore chose to synthesize a derivative of o-carborane to increase its molecular weight and further modify its electronic/ passivation properties. We target a phenylamine functionalized o-carborane (structure Fig. 1b, CB-NH2 henceforth) to raise the LUMO by increased conjugation, and reduce electronic traps from previously mentioned DOS broadening via the Lewis base lone pairs on the primary amines<sup>38–41</sup> . The direct addition of functional groups on the carbon sites of o-carborane is very challenging. We, therefore, started the molecular synthesis (Supplementary Fig. 3) from dodecahydro-arachno-bis(acatonitrile)decaborane which is available commercially. An electrophilic addition reaction with diphenylacetylene was employed to yield phenyl functionalized CB (in short CB-ph). The amino functionalization of the phenylene group was achieved by an initial nitrification and subsequent reduction reaction to yield CB-NH2. The detailed synthesis, a description of the CB-NH2 molecule and additional molecular structure characterizations (such as nuclear magnetic resonance spectra) can be found in the Supplementary Note 1, and Supplementary Figs. 4–7. 

To estimate the energy levels of highest occupied and lowest unoccupied molecular orbitals (HOMO/LUMO), we employed cyclic voltammetry (CV) to measure the reduction potential (LUMO energy levels, Supplementary Fig. 8). Then optical energy gaps (EG) were 

calculated by the intersection of normalized absorption and emission spectra (Supplementary Fig. 9), and with Tauc plots of the absorption spectra (Supplementary Fig. 10)<sup>42,43</sup> . Finally, the HOMO energy levels were obtained by subtracting the LUMO energy level from the EG (Supplementary Table 1). As shown in Fig. 1c, the CB-NH2 has different energetics from CB. As predicted, the functionalized phenylamine groups in conjugation with the carborane core significantly raise the HOMO/ LUMO levels. Further in Fig. 1c, we compare the measured energetics with those of FAPbI3 and C60 where we observe the much deeper HOMO of the carboranes than C60. This should improve its hole-blocking ability as predicted. The energy levels of the perovskite and the electron and hole transport layers (details below) were obtained from photoemission yield spectroscopy and referred from literature<sup>30</sup> . 

### Electron transport properties of CB-NH2 

To evaluate the electron-transporting potential of carborane, we measured electron mobility of CB-NH2 via the space-charge limited current (SCLC) method and compared it with C60. We used the following configuration for the electron-only device ITO/ZnO/CB-NH2 (100 nm) or C60 (200 nm)/BCP/Ag, which precluded the ability to also assess the electron mobility of CB due to the previously mentioned volatility. As shown in Fig. 1d, the CB-NH2 device exhibits textbook-like SCLC behavior with a clear slope variation from 0–3 V. Using the MottGurney equation of J = 9εrε0μ(Vapp–Vbi)<sup>2</sup> /8L<sup>3</sup> , where Vapp the applied field and Vbi the built-in voltage, ε0 is the vacuum permittivity (8.85 × 10<sup>−12</sup> F m<sup>−1</sup> ), εr (3.5) is the dielectric constant, and L is the device thickness, the voltage-dependent mobility can be extracted in the SCLC region. As plotted in the inset picture in Fig. 1d, both the CB-NH2 and C60 device reveals the SCLC region (>1 V). This allows us to extract a mobility of 7.3 × 10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for CB-NH2, which is one order of magnitude lower than that of C60 (6.7 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ). When compared to other non-fullerene organic transport materials from the literature, the mobility of CB-NH2 is middling<sup>44,45</sup> . Nevertheless, when compared to commonly applied interlayer materials such as the widely used Lewis bases (PEAI) and the polymers PS, PMMA, which are basically insulating materials, the electron-transporting capability of CBNH2 is comparatively high. 

### Solar cell fabrication and photovoltaic performance 

We then applied CB and CB-NH2 as hole-blocking layers in pin-structured triple-cation PSCs using Cs0.05(MA0.05FA0.95)0.95Pb(I0.95Br0.05)3 with an optical bandgap of 1.56 eV as shown from the derivative of the external quantum efficiency (EQE) in the Supplementary Fig. 11. The full device structure was ITO/MeO-2PACz/perovskite/carborane interlayer/C60/BCP/Ag. The CB-based interlayers were implemented by spin coating a diluted solution (1 mg/mL in chlorobenzene) on top of the perovskite. Further methods are presented in the Methods. 

Figure 2a–c show the PV parameter distribution of the control, CB and CB-NH2- treated solar cells (over 14 cells for each type). The best control cell delivered a PCE of 21.5%, with a VOC of 1.128 V, a JSC of 23.52 mA cm<sup>−2</sup> , and an FF of 81.15%. This provides us with a good starting point for further interfacial improvements and pursuing record-level efficiency. When introducing the CB as an interlayer, we find that the VOC remains unchanged, while there is a statistical improvement in fill factor (FF) and short-circuit current (JSC). The best CB-based devices exhibit a slightly lower VOC of 1.120 V, with a JSC of 23.77 mA cm<sup>−2</sup> , and an FF of 81.68%, which represents only a small improvement compared to the control device. Any improvement is surprising given the volatile nature of the CB molecule, therefore we speculate there remains a small amount on the surface. 

The introduction of CB-NH2 has a far more profound effect on the device parameters. The JV curves of the best-performing cells with and without CB-NH2 are shown Fig. 2d. The champion CB-NH2 treated cell exhibit a PCE of 23.05%, with a high voltage of 1.170 V for the given 

Nature Communications |  (2022) 13:7454 

3 

Article 

https://doi.org/10.1038/s41467-022-34203-x 



<!-- Start of picture text -->
a b c<br>1.20 90 25<br>85<br>1.15<br>20<br>80<br>1.10<br>75 15<br>1.05<br>70<br>10<br>1.00<br>65<br>0.95 60 5<br>d 0 Control CB CB-NH2 e 26 Control CB CB-NH2 f 1.0 Control CB CB-NH2 25<br>Control<br>CB 24 @0.97V stablized PCE = 23.04%<br>-5 CB-NH2 22 0.8 20<br>20 @0.91V stablized PCE = 21.1%<br>-10 0.6 15<br>Cell V OC J SC FF  PCE<br>18<br>Control 1.128 23.52 81.15 21.53<br>-15 CB 1.120 23.77 81.68 21.74 16 0.4 10<br>CB-NH2 1.170 23.83 82.66 23.05 14  CB-NH2<br>-20  Control 0.2 5<br>12<br>-25 10 0.0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 0 100 200 300 400 500 600 300 400 500 600 700 800<br>V oc (V) Time (s) Wavelength (nm)<br>)( cVo )( F% )( E%<br>V F C<br>P<br>2)<br>m )<br>c/A ( E%<br>( J msc  CP IPCE<br>2Integrated current (mA/cm)<br><!-- End of picture text -->

Fig. 2 | Device performance of CB-NH2, CB treated and control cells. a–c Parameter distributions and corresponding standard deviations of VOC, FF, and PCE for control, CB, and CB-NH2 treated devices, respectively. d JV curves of the champion devices. e Stable power output results of CB-NH2 based and control cells. 

f Incident photon-to-current conversion efficiency and the integrated current density results of CB-NH2 treated and control cells. Source data are provided as a Source Data file. 

bandgap of the absorber (1.56 eV) and a small hysteresis at a scan speed of 20 mV/s as shown in Supplementary Fig. 12. Based on the EQE spectrum (Supplementary Fig. 13), we calculated the radiative recombination current in the dark (J0,rad), which corresponds to a radiative VOC limit of 1.28 eV. Therefore, the non-radiative voltage losses are approximately 110 mV. This is among the smallest VOC deficits for pinstructured cells, with only few reports that achieved even smaller voltage losses<sup>23,46,47</sup> . We also measured the steady-state power output (SPO) of the devices at their MPP voltage for 600 s. As shown in Fig. 2e, the stabilized current density of CB-NH2 treated and control devices are 23.73, 23.26 mA/cm<sup>2</sup> at a bias of 0.97 and 0.91 V, respectively, confirming a stabilized PCE of 23.04% and 21.10%, which are consistent with JV results. We note that there was a PCE drop in the initial 10 s for both devices, which is likely due to current losses related to ion movement in the perovskite absober<sup>48,49</sup> . We also note that the integrated current density from the EQE spectrum matches well with the JV results (Fig. 2f). 

### Passivation and device operational stabilities 

Highly motivated by the excellent performance improvements rendered by the CB-NH2 interlayer, we proceeded to quantify the deviceand passivation stability. We first confirmed that the CB-NH2 molecules do not change the absorption spectrum of the perovskite layer therefore unlikely to alter the perovskite bulk properties (Supplementary Fig. 14). We then performed water contact angle measurements to evaluate the influence of CB-NH2 on the surface properties of perovskite. A larger water contact angle of 75° was determined for the CB-NH2 coated perovskite film, in comparison to the 41° of the bare perovskite (Fig. 3a). The hydrophobicity of the carborane is beneficial for protecting perovskite from the ingress of moisture. Thermal stability is another concern for various interfacial passivation materials. We note that carboranes are regarded as thermally stable molecules that have been used as a building block for high-temperature-resistant materials<sup>50</sup> . A previous study has proven that the passivation effect of 

PEAI, one of the most popular passivation materials, deteriorates at elevated temperatures, causing decreased VOC in devices as a result of the formation of the 2D phase<sup>51</sup> . Similarly, LiF has also been suggested to negatively influence device stability<sup>29</sup> . We, therefore, compared CBNH2 with these two widely used materials at elevated temperatures (50 °C to 100 °C), and measured the PLQY variation to assess the “passivation stability”. As shown in Fig. 3b, the CB-NH2 coated perovskite sample shows the highest initial PLQY value, indicating an effective passivation of defects. At higher temperatures, the PLQY values of all samples decreases, e.g., the PEAI sample retains only 27% of its initial value, and this value for LiF sample is 41.2%. For comparison, the CB-NH2 coated film demonstrates a smaller decline, retaining 74% of its initial PLQY. Moreover, we noticed that after cooling down to room temperature, the PLQY of PEAI and LiF samples remained at a similar value as at 100 °C, indicating an irreversible process, while the CB-NH2 sample almost returned to its initial value. We noted that no new diffraction peak was detected in the CB-NH2 sample after annealing, indicating neither the molecule nor any degradation product entered the perovskite and no 2D phase was formed (Supplementary Fig. 15). To quantify the stability, we performed MPP tracking on the devices in a glovebox using a white-light-emitting diode (LED) without UV at 26 °C. The devices comprising CB-NH2 maintained over 97% of the initial PCE (Fig. 3c) under MPP and 1-sun equivalent illumination for 400 h, indicating superb operational stability. In contrast, the control sample retains 89% of its initial efficiency over the same time. The improved operational stability is attributed to effective passivation, which reduces the surface reactivity and retards the degradation rate. We further confirm the improved operational stability during maximum power point tracking under 1-sun equivalent illumination with a white LED in air (30% RH) and at a temperature of 40 °C. As shown in Supplementary Fig. 16, the CB-NH2 devices also demonstrate better stability under these conditions, thus the improvement might be related to the increased hydrophobicity and resistance to moisture. 

Nature Communications |  (2022) 13:7454 

4 

Article 

https://doi.org/10.1038/s41467-022-34203-x 



<!-- Start of picture text -->
a b<br>10<br>CB-NH2 PEAI<br>LiF  Control<br>1<br>75 o<br>CB-NH2 0.1<br>initial 50 85 100 cooled<br>Annealing temperature (˚C)<br>c<br>1.0 97%<br>0.8 95% 89%<br>0.6<br>41 o<br>Unencapsulated devices under 1 sun irradiation<br>0.4<br>CB-NH2<br>0.2  Control<br>Control<br>0.0<br>0 100 200 300 400<br>Time (h)<br>PLQY (%)<br>)%<br>(<br>E<br>C<br>P<br>d<br>e<br>zila<br>omr<br>N<br><!-- End of picture text -->

Fig. 3 | Stability evaluation. a Contact angle measurement using water for a neat reference and a CB-NH2-treated perovskite. For the CB-NH2 treated samples, the contact angle with water is larger. b Passivation stability of CB-NH2, PEAI, LiF on 

perovskite film under gradually elevated temperature. c Maximum power point tracking under a 1-sun equivalent intensity of CB-NH2 based and control PSCs in an inert atmosphere at 26 °C. Source data are provided as a Source Data file. 



<!-- Start of picture text -->
a Elimination of interface loss b loss paths<br>10 1.22 1.35<br>CB-NH2<br>Control 1.20 1.30 radiative limit<br>1.18 1.25<br>perovskite loss<br>1 1.16 1.20<br>n-interface loss<br>1.14 1.15<br>p-interface los s<br>1.12 1.10 V OC<br>0.1 1.05<br>pero pero/C60 cell Control CB-NH2<br>)  (V) V OC<br>% d<br>(  n<br>Y a<br>Q  )V<br>L e<br>P (<br>S<br>L<br>F<br>QFLS (eV) and  (V) V OC Q<br><!-- End of picture text -->

Fig. 4 | Photoluminescence quantum yield measurements (PLQY) and internal quasi-Fermi level splitting (QFLS) diagram. a PLQY and QFLS diagram and VOC from JV results for perovskite film, perovskite/C60 half stack, and full cell with/ without CB-NH2. The almost identical PLQY value between pero and pero/CB-NH2/ 

C60 samples indicates the elimination of interfacial recombination. The bars represent the QFLS results from PLQY measurement and the stars the VOC from JV results, respectively. b Voltage loss mechanism for the control and CB-NH2-based samples. Source data are provided as a Source Data file. 

### Suppression of perovskite/C60 interfacial recombination 

To understand the simultaneous improvement of the FF and the VOC in case of CB-NH2, we first employed PLQY measurements to analyze the non-radiative recombination in perovskite films, multilayer partial cell stacks, and complete PSCs. Given that it is a non-contact technique, PLQY characterization allows one to decouple the contribution of every layer/interface to the non-radiative recombination loss. We measured different partial cell stacks and compared the results with complete devices to enable insights into the working mechanism of CB-NH2. We use a laser of 520 nm wavelength with a spot size of near 0.5 cm<sup>2</sup> to illuminate the samples with a 1-sun equivalent intensity by adjusting the produced current close to the JSC under a standard solar simulator. As shown in Fig. 4a and Supplementary Fig. 17, the PLQY of the bare perovskite on glass is improved from 2.3% to 5.2% due to the CB-NH2 treatment, indicative of surface trap passivation. To correlate the PLQY results with the kinetic properties of photogenerated charges, time-resolved photoluminescence (TRPL) characterization was performed. As shown in Supplementary Fig. 18, a neat perovskite film without charge 

transport layers exhibit approximately a mono-exponential decay. In this case, then a Shockley–Read–Hall (SRH) recombinationdominated lifetime (τSRH) can be deduced to be 1800 and 1000 ns for CB-NH2 treated and control films, respectively. The extended τSRH of CB-NH2 coated perovskite films is favorable for carrier collection. When capped with C60, the PLQY of the control sample was reduced from 2.3% to 0.67% by a factor of ~4. In contrast, the C60 induced PL quenching was substantially reduced for the CB-NH2 treated perovskite/C60 stacks (from 5.2% to 2.1%). The PLQY of perovskite/CBNH2/C60 stack is nearly identical to the bare perovskite sample (2.3%), indicating that we overcame the critical C60-induced non-radiative recombination upon introducing the CB-NH2 interlayer for this system. To our knowledge, this is the first time that this was achieved for pin-type perovskite cells based on a C60 ETL. As a result, we obtained a very high PLQY of 1.45% in full device, which is rarely achieved in pin-type cells, demonstrating the unique passivation effect of carborane interlayer. 

To quantify the open-circuit voltage potential for every individual stack, we calculated the internal electron-hole quasi-Fermi level 

Nature Communications |  (2022) 13:7454 

5 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

Table 1 | PLQY and QFLS results of perovskite film, perovskite/ C60 half stack, and full cell with/without CB-NH2 

|Sample|PLQY|QFLS(eV)|VOC(V)|
|---|---|---|---|
|pero/CB-NH2|0.0523|1.204||
|neat pero|0.0234|1.183||
|pero/CB-NH2/C60|0.021|1.180||
|pero/C60|0.0067|1.150||
|cell-CB-NH2|0.0145|1.170|1.170|
|cell-control|0.00345|1.133|1.128|



splitting (QFLS) from PLQY results by using the equation QFLS = kBT*ln(PLQY × JG/J0,rad), where JG is the generated current density at 1-sun and J0,rad is the radiative recombination current in the dark as shown in Supplementary Fig. 13. As shown in Fig. 4a, the neat perovskite exhibits an implied VOC of 1.183 V. This value increases to 1.204 V after the introduction of CB-NH2, which is attributed to the passivation effect on the perovskite surface. The perovskite/C60 half stack exhibits a lower QFLS of 1.150 V, while the CB-NH2 treated perovskite/C60 sample shows QFLS of 1.180 V, which is nearly equal to the neat perovskite, indicating that the C60-induced interfacial recombination is effectively overcome. The PLQY and QFLS values mentioned above are collected in Table 1. Moreover, the difference between the QFLS and VOC of the cells is negligible in both samples (w/ and wo/CBNH2). This demonstrates spatially flat Fermi levels throughout the device and well-aligned energy levels for majority carriers. Note any misalignment (downhill energy offset for electrons and uphill offset for holes) in combination with a finite interface recombination velocity would readily cause a gradient in the electron/hole quasi-Fermi levels and a QFLS-VOC mismatch. Figure 4b depicts the voltage loss mechanism in the control and CB-NH2-based devices. Under the limitation of thermodynamic radiative which is 1.28 eV for the given bandgap, the perovskite loss and interface loss dominate the voltage loss in both samples whereas the transport loss is negligible (see the identical QFLS and VOC of the full device). After the introduction of CBNH2, the simultaneously suppressed perovskite loss and interface loss result in the improved VOC. 

In order to gain more insight into the influence of charge recombination dynamics in complete devices, we also performed transient photovoltage (TPV) measurements under a white LED with an equivalent intensity of 1-sun. As shown in Supplementary Fig. 19, the CB-NH2 treated device exhibits a long lifetime (4.43 μs) which is nearly twice as much as the blank device (2.26 μs). The improved carrier lifetime is consistent with the PLQY results. We note that this value is larger than the bulk SRH lifetime obtained from TRPL, which is likely related to capacitive effects impacting TPV<sup>52,53</sup> . In addition, electrochemical impedance spectroscopy (EIS) measurements were performed to characterize the charge carrier recombination near opencircuit conditions (≈1 V), the series resistance (Rs), and recombination resistance (Rrec) of the CB-NH2 and the reference device. All of these parameters can be obtained from the Nyquist plots intuitively. The equivalent circuits are presented in Supplementary Fig. 20. The semicircle of the CB-NH2-based devices is larger than that of the blank device, indicating a significant reduction in charge carrier recombination rate, attributed to the lower Rs and higher Rrec. We also estimated the apparent trap density (ntrap) of the perovskite films by measuring the dark JV profiles of the electron-only devices. As shown and discussed in Supplementary Fig. 21, the current in the ohmic region is smaller for the CB-NH2-based device, which could be correlated with a lower overall trap density and the improved VOC54. However, the measurable trap density from this experiment is limited by the electrode charge per unit cell volume, which is typically very similar to the apparent trap density in thin film (~500 nm) devices as recently shown in refs. 55, 56. 

We then aimed towards an understanding of the impact of our carborane passivation on the ideality factor (nID), fill factor losses, and efficiency potential and therefore investigated the intensity (or voltage) dependence of the non-radiative recombination losses. To this end, we employed three techniques: intensity-dependent quasi-Fermi level splitting, intensity-dependent VOC, and injection-dependent electroluminescence (EL). We first measured the intensity-dependent PLQY (iPLQY) of the different stack of samples. Upon converting the PLQY at different laser intensities to the QLFS, we obtain the QFLS as a function of light intensity (Fig. 5a). Furthermore, we construct a pseudo-dark JV curve by plotting the recombination current minus the voltage-independent generation current under AM1.5 G ( JSC) on the y-axis and the QFLS as x axis. As a result, we create a pseudo-light JV curves which allow us to quantify the implied JV performance of the film including the FF potential in the absence of Rs. As shown in Fig. 5a, CB-NH2-based samples demonstrates a holistically higher QFLS value in the complete device, half stack, and bare perovskite. The pseudo-JV curves are shown in Fig. 5b with photovoltaic parameters collected in Table 2. With regard to the ideality factors, in Fig. 5a for the control cell we obtain an nID of 1.55 while it is 1.43 for the CB-NH2 treated cell. We note that the difference between the pFF on the cells from the pseudo JVs reflects the different FF of the devices. Thus, the improved FF of the CB-NH2-based device is largely due to a lower ideality factor rather than improved charge transport. We also measured the iPLQY and corresponding QFLS on perovskite and perovskite/C60 stack with and without C60 (Fig. 5c, d). The pseudo JVs are plotted in Supplementary Fig. 22 and the parameters are shown in Table 2. The implied FF lost from the neat perovskite to perovskite/C60 half stack is 1.5% in the control films, while this decline of FF is reduced to 0.4% for the CB-NH2 coated samples. This demonstrates the introduction of CB-NH2 compensates for the compromised FF caused by the deposition of C60 due to dark recombination. For the perovskite and perovskite/C60 half stacks, we noticed an increase in nID by 0.15 from the neat perovskite (1.33) to the perovskite/C60 film (1.48), whereas for the CB-NH2 treated sample displays an nID of 1.43 (Fig. 5c, d). This is again consistent with reduced non-radiative recombination between the C60 and the perovskite. 

We further performed intensity-dependent VOC measurement and conducted injection-dependent EL measurements to further analyze the nID and pFF as shown in Supplementary Figs. 23 and 24. Both measurements, further confirm the higher pseudo FF, demonstrating the improved FF due to suppressed non-radiative recombination. 

### Electron extraction and hole blocking 

To reveal the working mechanism of the CB-NH2 layer, we quantified the charge selectivity at the perovskite/C60 interface. To this end, we carried out conductive atomic force microscopy (C-AFM) on ITO/MeO2PACz/Pero/(CB-NH2)/C60 films with and without CB-NH2 interlayer. This method has been used by Xu and Caprioglio et al. previsouly<sup>57,58</sup> . In addition, the samples were illuminated with a 5 mW/cm<sup>2</sup> white LED to generate electron-hole pairs. To demonstrate the different transport behavior between electrons and holes, we applied a step-by step voltage variation from positive to negative bias to the tip to imitate the process of electron and hole extraction. Electron extraction is imitated when we apply a positive voltage to the tip while hole extraction is imitated when we apply a negative voltage. Figure 6 demonstrates that the CB-NH2 treated samples exhibits a higher current in the positive bias region, whereas the current is lower at a negative bias with respect to the control sample. To be specific, when 1 V bias is applied to the tip, CB-NH2 treated samples approach an average current of −0.72 nA, while the control sample exhibits a lower average current (−0.2 nA). In contrast, CB-NH2 treated samples exhibit a lower current when −1 V is applied to the tip (0.02 nA) compared to the control sample (0.07 nA). The averaged values were obtained from area-averaged profiles. We note that the isolated spikes could be related to the carrier diffusion 

Nature Communications |  (2022) 13:7454 

6 

Article 

https://doi.org/10.1038/s41467-022-34203-x 



<!-- Start of picture text -->
a b<br>0<br>1.2 CB-NH2 nID= 1.43 CB-NH2<br>Control  nID= 1.55 -5 Control<br>1.1<br>V OC  J SC  FF  PCE<br>-10 Cell<br>1.0 10 -1 (V) (mA∙cm -2 ) (%) (%)<br>CB-<br>1.164 23.7 86.3 23.8<br>10 -2 -15 NH 2<br>0.9<br>Control 1.135 23.5 85.1 22.7<br>10 -3<br>0.8 -20<br>10 -4<br>0.01 0.1 1<br>0.7 Intensity (suns) -25<br>0.001 0.01 0.1 1 0.0 0.2 0.4 0.6 0.8 1.0 1.2<br>c Intensity (suns) d V oc (V)<br>1.2 CB-NH2 1.2 Control<br>1.1 1.1<br>1.0 1.0<br>0.9 0.9<br>perovskite nID=1.32 perovskite nID=1.33<br>0.8 half stack  nID=1.37 0.8 half stack  nID=1.48<br>full device nID=1.43 full device nID=1.55<br>0.7 0.7<br>0.001 0.01 0.1 1 0.001 0.01 0.1 1<br>Intensity (suns) Intensity (suns)<br>2)<br>m<br>c/<br>A<br>)( % (m<br>Y<br>QFLS (eV)PL QL J sc<br>P<br>QFLS (eV)PL QFLS (eV)PL<br><!-- End of picture text -->

Fig. 5 | Pseudo-JV and efficiency potential. a Intensity-dependent quasi-Fermi level splitting (QFLS) measurement. b Pseudo JV curves from intensity-dependent QFLS of the full devices. Intensity-dependent QFLS measurements for neat perovskite, perovskite/C60 half stack, and full devices of c CB-NH2-based sample and 

d control sample, respectively. The nID is smaller for samples with carborane, indicating less non-radiative recombination. Source data are provided as a Source Data file. 

pathway or the morphology. Moreover, all samples have relatively lower current value in the negative region than in the positive region, which is consistent with the electron-selective transport through the C60 layer. Overall, C-AFM clearly demonstrates that the CB-NH2 layer increases electron extraction while decreasing hole extraction. The improved electron extraction is also consistent with the improved FF and decreased trap density observed with PL. Note, due to the low light intensity (5 mW/cm<sup>2</sup> ) the measurement is in essence a dark JV measurement, and the low values of the current are limited by the small radius of the tip of 35 nm. Therefore, the current signal measured from C-AFM is not comparable to the JSC from JV curves. 

### Contribution from carborane and amino moiety to device performance 

In order to investigate the contribution from the carborane and amino group moiety in CB-NH2 to the improvement of device performance, we also studied the intermediate phenyl functionalized carborane (CBph) without the amino group because the bare carborane suffers from 

Table 2 | Parameters of pseudo JV curves constructed based on iPLQY from perovskite film, perovskite/C60 half stack, and full cell with/without CB-NH2 

||cell|VOC(V)|JSC(mA cm<sup>−2</sup>)|FF(%)|PCE(%)|
|---|---|---|---|---|---|
|CB-NH2|Device|1.164|23.7|86.3|23.8|
||Half stack|1.177|23.7|86.8|24.1|
||Perovskite|1.202|23.7|87.2|24.8|
|control|Device|1.135|23.5|85.1|22.7|
||Half stack|1.146|23.5|85.6|23.0|
||Perovskite|1.181|23.5|87.1|24.1|



sublimation on the perovskite layer. As can been seen in Supplementary Fig. 25, CB-ph leads to a significant FF improvement (~2%) but only slight VOC improvement (~10 mV). This indicates that the carborane alone reduces non-radiative recombination less effectively than CBNH2 but has a significant effect on the electron extraction which is consistent with the C-AFM result. The slight VOC improvement can be further confirmed by the improved PLQY of the ITO/perovskite/C60 stack with the CB-ph interlayer but identical PLQY of the ITO/perovskite with and without the CB-ph interlayer (Supplementary Fig. 26). These results suggest that there is a small contribution (~10 mV) of the carborane moiety to the total VOC gain of the CB-NH2 functionalized device (~50 mV) which we attribute to the improved hole-blocking ability of the carborane. However, the effect of the amino group is more significant. As for the FF improvement, our results indicate a more significant contribution of the carborane moiety (~2%) to the total gain (~4%), which suggests that the improvement originates partially from the hole-blocking and electron extraction ability of the CB molecule. Nevertheless, considering that the packing and adsorption ability of the CB-ph and the CB-NH2 molecules are likely different, the exact contribution of the carborane moiety is difficult to quantify. Given that the performance of the CB-NH2 device is optimum, we can conclude that the carborane and the amino group are working synergistically and are indispensable. 

### Surface passivation and Pb-CB-NH2 interaction 

To further explore the passivation mechanism of CB-NH2, we examined the intermolecular interactions between CB-NH2 and perovskite. We conducted Fourier transform infrared spectroscopy (FTIR) and X-ray photoelectron spectroscopy (XPS) measurements to study the interactions between CB-NH2 and perovskite moieties. We dissolved CB-NH2 and PbI2 in DMF solvent and then dried the solution to obtain a 

Nature Communications |  (2022) 13:7454 

7 

Article 

https://doi.org/10.1038/s41467-022-34203-x 



<!-- Start of picture text -->
0.2 nA CB-NH2<br>-0.2 @1V, Average current: -0.72 nA -2.5 nA<br>-0.6 -2<br>-1.0 @-1V, Average current: 0.02 nA -1.5<br>-1.4 -1<br>-1.8<br>-0.5<br>-2.2<br>0<br>-1.0 V -0.5 V 0 V 0.5 V 1.0 V<br>0.5<br>Control<br>900 pA<br>-1.2 nA<br>600 @1V, Average current: -0.2 nA -0.9<br>300<br>-0.6<br>0<br>@-1V, Average current: 0.07 nA<br>-300 -0.3<br>-600 0<br>-1.0 V -0.5 V 0 V 0.5 V 1.0 V<br>-900 0.3<br>Hole extraction  Electron extraction  0.6<br><!-- End of picture text -->

Fig. 6 | Improved electron extraction and hole blocking at perovskite/C60 interface. 3D conductive-AFM images (5 × 5 μm) of the samples with a structure of ITO/MeO-2PACz/Pero/CB-NH2/ C60 (CB-NH2 treated) and ITO/MeO-2PACz/Pero/ 

C60 (control). The images represent a step-by-step applied voltage variation from −1.0 V applied to the tip (left) for hole extraction to 1.0 V applied to the tip (right) for electron extraction. 



<!-- Start of picture text -->
a b c<br>2.68 Å 3.58 Å 3.11 Å<br>2.64 Å<br>Fig. 7 | Interaction between CB-NH2 and perovskite from DFT calculations. Top2 and perovskite from DFT calculations. Top and perovskite from DFT calculations. Top Top N-Pb are depicted. Color scheme: Pb: gray; I: light blue; C: pink; N: dark blue; B:<br>-terminated perovskite surface a without and b with CB-NH2. c Side a without and b with CB-NH2. c Side without and b with CB-NH2. c Side b with CB-NH2. c Side with CB-NH2. c Side2. c Side. c Side c Side Side green; H: white.<br><!-- End of picture text -->

Fig. 7 | Interaction between CB-NH2 and perovskite from DFT calculations. Top2 and perovskite from DFT calculations. Top and perovskite from DFT calculations. Top Top views of PbI2-terminated perovskite surface a without and b with CB-NH2. c Side a without and b with CB-NH2. c Side without and b with CB-NH2. c Side b with CB-NH2. c Side with CB-NH2. c Side2. c Side. c Side c Side Side views of the perovskite surface adsorbed with CB-NH2. Notes: the length of N-H···I/ 

mixed powder<sup>40,59</sup> . The FTIR spectra of the mixture and pure CB-NH2 powders, displayed in Supplementary Fig. 27, reveal that the addition of PbI2 results in the variation of the v(N-H) interaction. Given that the lone pairs of N contained functional groups, especially in the amino group, can interact with Pb<sup>2+</sup> , we speculate the shift of the v(N-H) peak originates from the interaction between the N atom and Pb<sup>2+</sup> . We further performed XPS measurements on perovskite films with/without CB-NH2 to study the interaction between the interlayer and the perovskite. As shown in Supplementary Fig. 28, the Pb signals between 136 eV and 146 eV binding energy demonstrate 2 main peaks, which can be ascribed to the excited electrons of the 4f7/2 and 4f5/2 orbitals. Apparently, the signal of the perovskite film with CB-NH2 shows a visible shift towards lower binding energies, indicating the interaction between under-coordinated Pb and CB-NH2. Since the undercoordinated Pb<sup>2+</sup> on the perovskite surface are typically active sites for interfacial reactions that act as electronic traps<sup>60,61</sup> , the interaction between CB-NH2 and Pb might explain the decreased surface trap density, as well as the improved operational stability. We note that the 

detected B 1 s signal proves the existence of CB-NH2. The observed interaction is likely related to the improvement of PL intensity and lifetime for neat perovskite. 

To obtain more atomistic information regarding to the interaction between the perovskite and CB-NH2 density functional theory (DFT) simulations were performed. We choose α-FAPbI3 perovskite and a (001) PbI2-terminated surface as model system in accordance with the studied perovskite. A detailed description of the DFT calculations can be found in Supplementary Note 2. Figure 7a, b displays a top view of the perovskite and the perovskite/CB-NH2 at the lowest energy. Figure 7c, shows a cross-sectional view highlighting that distinct hydrogen bonds are formed between N and H from the CB-NH2 molecule and I from the perovskite surface with a bond length of 2.68 and 2.64 Å, respectively. Such hydrogen bonds with iodide ions have been shown to reduce the trap states and suppress iodide migration, thus improving device performance and long-term stability<sup>62–64</sup> . Moreover, the simulations reveal a very short bond length of Pb-N in both phenylamino groups at 3.58 and 3.11 Å, respectively, indicating CB-NH2 

Nature Communications |  (2022) 13:7454 

8 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

passivates the under-coordinated Pb atoms on the perovskite surface. These short bond lengths result in an extraordinarily high adsorption energy of −3.42 eV<sup>64–66</sup> . To further corroborate these findings, we calculated the iodine Frenkel (interstitial/vacancy pair) defect formation energy (DFE) and we find an increased DFE by ~0.2 eV upon the CB-NH2 incorporation (Supplementary Fig. 29), indicating reduced creation and diffusion of iodide defects. Based on the above results, we can draw the conclusion that the synergistic bonding effect from N-H···I and N-Pb realize a strong interaction between the perovskite and CBNH2, which is beneficial for simultaneously passivating surface defects and improving the surface stability. 

precursor solution for better crystallization). The triple-cation perovskite films were deposited by spin-coating at 4000 rpm for 40 s (5 s for acceleration). 5 s before the end of the procedure chlorobenzene (300 μL) was dispensed onto the still spinning substrate in one continuous flow which lasts for approximately 1 second, following by annealing at 100 °C for 1 h. Subsequently, the carborane molecules were spin-coated from 1 mg/mL solution in chlorobenzene at an rpm of 6000 (3 s for acceleration). Then, the samples were transferred to an evaporation chamber where C60 (Sigma-Aldrich, 30 nm) at 0.2 Å/s, 8 nm BCP (Sigma-Aldrich) at 0.2 Å/s and 100 nm copper (Sigma-Aldrich) at 0.6 Å/s were deposited under vacuum (p = 10<sup>−7</sup> mbar). 

## Discussion 

In this work, we demonstrate effective control of non-radiative recombination losses at the perovskite/C60 interface by implementing a carborane-based interlayer in pin-type PSCs. This is achieved upon the introduction of a phenylamine functionalized carborane derivative CB-NH2, which enables efficient defect passivation and selective electron transport with mobility of 7 × 10<sup>−4</sup> cm<sup>2</sup> /Vs. The inverted PSCs with CB-NH2 incorporated as an interfacial layer reach high PLQYs of 1.4% and PCEs over 23%, with non-radiative voltage losses as low as 110 mV. By analyzing the PLQY and the QFLS of different partial cell stacks, we demonstrate that the implementation of CB-NH2 as an interlayer nearly eliminates the C60-induced interfacial recombination, which has not yet been achieved with other interfacial modifications. Based on a series of experimental methodologies, we demonstrate that the concomitantly improved VOC and FF with CB-NH2 is a result of the passivation of the perovskite surface, reduced nonradiative recombination across the perovskite/C60 interface combined with an increased charge carrier selectivity. The CB-NH2 interlayer also improves the thermal and operational stability of the complete devices, which is attributed to the stabilization of defects on the perovskite surface and the hydrophobic nature of CB-NH2. This work addresses one of the most critical issues of inverted PSCs and demonstrates the potential of carborane derivatives as interfacial and electron transport materials in perovskite-based opto-electronic devices. As such, we believe that future molecular design and optimization will pave the way for a particular class electron transport materials based on carboranes. 

## Methods 

### Materials and reagents 

The raw material dodecahydro-arachno-bis(acatonitrile)decaborane was purchased from Zhengzhou Yuanli Biological Technology Co., Ltd, China, Diphenylacetylene was purchased from Shanghai Macklin Biochemical Co., Ltd, China. PbI2, PbBr2, MABr, MACl, PEAI, BCP, and MeO-2PACz were purchased from TCI. Patterned indium tin oxide (ITO) glass, FAI, C60, and PCBM were purchased from Advanced Election Technology Co., Ltd. CsI was purchased from Sigma-Aldrich. DMSO, DMF, ethanol, chlorobenzene, and isopropanol were purchased from Acros. 

### PSCs fabrication 

Patterned ITO-coated glass substrates were cleaned sequentially for 15 min in suds, deionized water, ethanol, and acetone in ultrasonic bath. Then the substrates were treated with ultraviolet ozone (UVOzone) for 30 min and transferred to a nitrogen-filled glove box. All subsequent procedures were done in nitrogen-filled glove boxes. The solutions of MeO-2PACz (1 mmol mL<sup>−1</sup> in ethanol) were spin-coated on the ITO substrates at 3000 rpm for 30 s, followed by annealing at 100 °C for 10 min. The FA-based triple-cation perovskite precursor solution with a formula of Cs0.05(MA0.05FA0.95)0.95Pb(I0.95Br0.05)3 was prepared by mixing two 1.5 M FAPbI3 and MAPbBr3 perovskite solutions in DMF:DMSO (4:1 volume ratio, v-v), as well as the solution of CsI (1.5 M) and MACl in DMSO (20 mol% MACl were added into the 

### Characterization and measurements 

Absolute photoluminescence measurements. Excitation for the PL measurements was performed with a 520 nm CW laser (Insaneware) through an optical fiber into an integrating sphere. The intensity of the laser was adjusted to a 1-sun equivalent intensity by illuminating a 1 cm<sup>2</sup> -size PSC under short-circuit and matching the current density to the JSC under the sun simulator (22.0 mA/cm<sup>2</sup> at 100 mW cm<sup>−2</sup> , or 1.375 × 10<sup>21</sup> photons m<sup>−2</sup> s<sup>−1</sup> ). A second optical fiber was used from the output of the integrating sphere to an Andor SR393iB spectrometer equipped with a silicon CCD camera (DU420A-BR-DD, iDus). The system was calibrated by using a calibrated halogen lamp with specified spectral irradiance, which was shone into to integrating sphere. A spectral correction factor was established to match the spectral output of the detector to the calibrated spectral irradiance of the lamp. The spectral photon density was obtained from the corrected detector signal (spectral irradiance) by division through the photon energy (ℎv), and the photon numbers of the excitation and emission obtained from numerical integration using MATLAB. 

Electroluminescence measurements (EL). The absolute EL intensity was measured with a calibrated Si photodetector and a Keithley 485 pico Ampere meter. The detector (with an active area of ~2 cm<sup>2</sup> ) was placed directly in front of the device (0.13 cm<sup>2</sup> ), and the total photon flux was evaluated considering the emission spectrum of perovskite and silicon sub-cell, their relative intensities from the previously measured relative EL spectra and the external quantum efficiency of the detector. A slight underestimation of the EQEEL (≈1.08×), originating from an additional glass encapsulation, and some photons that escaped to the side and were not detected was compensated. A forward bias was applied to the cell using a Keithley 2400 source meter, and the injected current was monitored. Measurements were conducted with a home-written LabVIEW routine. Typically, the voltage was increased in steps of 20 mV, and the current stabilized for typical 1 s at each step. 

Intensity-dependent VOC measurements. Steady-state intensitydependent VOC (i–VOC) was measured under mimicked AM1.5 G illumination (Oriel class AAA Xenon lamp-based sun simulator), appropriated neutral density filters, and a Keithley2400. The samples were irradiated by using a 445 nm continuous wave laser (Insaneware). A continuously variable neutral density filter wheel (ThorLabs) was used to attenuate the laser power (up to OD 6). The light intensity was thereby simultaneously measured with a silicon photodetector and a Keithley 485 to improve the accuracy of the measurement. For each intensity, the VOC is measured for ~2 s before the JSC is measured for the same time. The filter wheel is then moved to the next position and the routine is repeated. A homemade lab view program controlled the variable neutral density filter wheel and measured the VOC using a Keithley2400. 

Current density-voltage characteristics. JV-curves were obtained in a 2-wire source-sense configuration with a Keithley 2400. An Oriel 

Nature Communications |  (2022) 13:7454 

9 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

class AAA Xenon lamp-based sun simulator was used for illumination providing approximately 100 mW cm<sup>−2</sup> of simulated AM1.5 G irradiation and the intensity was monitored simultaneously with a Si photodiode. The exact illumination intensity was used for efficiency calculations, and the simulator was calibrated with a KG5-filtered silicon solar cell (certified by Fraunhofer ISE). The temperature of the cell was fixed to 25 °C and a voltage ramp of 20 mV/s was used. The active area of tested cells was 12 mm<sup>2</sup> as defined from the area of overlap of the electrodes. To measure the JV-characteristics an illumination mask with an area of 9 mm<sup>2</sup> was used. The spectral mismatch factor (SM) was calculated to be 0.982 for the optimized devices with EQE spectra presented in Fig. 2f, however, the obtained current has not been upscaled by 1/SM. 

Conductive atomic force. Conductive Atomic Force Microscopy was performed with a Solver NT-MDT instrument with a hardware linearized 100 mm scanner and scanning tip. The measurements were performed in contact mode by measuring both spreading resistance and topography. The tip used was a platinum NSG10/Pt. 

Other Measurements. The<sup>1</sup> H NMR spectra were recorded with the Bruker AM 400 spectrometer. The cyclic voltammograms were measured by using a CHI660E electrochemical workstation (Chenhua Co. Ltd, Shanghai, China) in a three-electrode cell. X-ray diffraction measurements were obtained by a Rigaku Ultima IV (Cu Ka radiation, λ = 1.5406 Å) in the range of 5°–90° (2θ). The time-resolved photoluminescence decay lifetimes were determined with the single photon counting technique by Edinburgh FLS1000 spectrometer. Transient photovoltage test was conducted under a white-light (LED) which was adjusted to produce the VOC at 1-sun conditions (1-sun equivalent), and the laser pulses (532 nm, 2 Hz) to measure the decay of transient photovoltage signals. EQE measurements were measured by Newport-74125 system (Newport Instruments). The operational stability of the unencapsulated PSCs was performed at the MPP tracking under continuous white-light LED array illumination in N2 atmosphere, the light intensity was calibrated to achieve the same JSC from the PSCs measured under a standard solar simulator (AM1.5 G, 100 mW cm<sup>−2</sup> ). 

### Reporting summary 

Further information on research design is available in the Nature Research Reporting Summary linked to this article. 

## Data availability 

The data generated in this study are provided in the Supplementary Information/Source Data file. Source data are provided with this paper. 

## References 

1. Li, W. et al. High-performance solar flow battery powered by a perovskite/silicon tandem solar cell. Nat. Mater. 19, 1326–1331 (2020). 

2. Liu, J. et al. 28.2%-efficient, outdoor-stable perovskite/silicon tandem solar cell. Joule 5, 3169–3186 (2021). 

3. Roß, M. et al. Co-evaporated formamidinium lead iodide based perovskites with 1000 h constant stability for fully textured monolithic perovskite/silicon tandem solar cells. Adv. Energy Mater. 11, 2101460 (2021). 

4. Jošt, M. et al. Textured interfaces in monolithic perovskite/silicon tandem solar cells: advanced light management for improved efficiency and energy yield. Energy Environ. Sci. 11, 3511–3523 (2018). 

5. Lamanna, E. et al. Mechanically stacked, two-terminal graphenebased perovskite/silicon tandem solar cell with efficiency over 26%. Joule 4, 865–881 (2020). 

6. Aydin, E. et al. Interplay between temperature and bandgap energies on the outdoor performance of perovskite/silicon tandem solar cells. Nat. Energy 5, 851–859 (2020). 

7. Chen, B. et al. Grain engineering for perovskite/silicon monolithic tandem solar cells with efficiency of 25.4%. Joule 3, 177–190 (2019). 

8. Hou, Y. et al. Efficient tandem solar cells with solutionprocessed perovskite on textured crystalline silicon. Science 367, 1135–1140 (2020). 

9. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. Nat. Energy 3, 847–854 (2018). 

10. Stolterfoht, M. et al. How to quantify the efficiency potential of neat perovskite films: perovskite semiconductors with an implied efficiency exceeding 28%. Adv. Mater. 32, 2000080 (2020). 

11. Wolff, C. M., Caprioglio, P., Stolterfoht, M. & Neher, D. Nonradiative recombination in perovskite solar cells: the role of interfaces. Adv. Mater. 31, 1902762 (2019). 

12. Warby, J. et al. Understanding performance limiting interfacial recombination in pin perovskite solar cells. Adv. Energy Mater. 12, 2103567 (2022). 

13. Menzel, D. et al. Field effect passivation in perovskite solar cells by a LiF interlayer. Adv. Energy Mater. 12, 2201109 (2022). 

14. Liu, J. et al. Efficient and stable perovskite-silicon tandem solar cells through contact displacement by MgFx. Science 377, 302–306 (2022). 

15. Sutanto, A. A. et al. 2D/3D Perovskite engineering eliminates interfacial recombination losses in hybrid perovskite solar cells. Chem 7, 1903–1916 (2021). 

16. Grancini, G. et al. One-Year stable perovskite solar cells by 2D/3D interface engineering. Nat. Commun. 8, 15684 (2017). 

17. Zhou, T. et al. Crystal growth regulation of 2D/3D perovskite films for solar cells with both high efficiency and stability. Adv. Mater. 34, 2200705 (2022). 

18. Zhong, Y. et al. Diammonium molecular configuration-induced regulation of crystal orientation and carrier dynamics for highly efficient and stable 2D/3D perovskite solar cells. Angew. Chem. 134, e202114588 (2022). 

19. Li, J. et al. Universal bottom contact modification with diverse 2D spacers for high-performance inverted perovskite solar cells. Adv. Funct. Mater. 31, 2104036 (2021). 

20. Li, B. et al. Reduced bilateral recombination by functional molecular interface engineering for efficient inverted perovskite solar cells. Nano Energy 78, 105249 (2020). 

21. Gharibzadeh, S. et al. Two birds with one stone: dual grainboundary and interface passivation enables >22% efficient inverted methylammonium-free perovskite solar cells. Energy Environ. Sci. 14, 5875–5893 (2021). 

22. Yang, S. et al. Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. Science 365, 473–478 (2019). 

23. Li, X. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437 (2022). 

24. Akriti et al. Layer-by-layer anionic diffusion in two-dimensional halide perovskite vertical heterostructures. Nat. Nanotechnol. 16, 584–591 (2021). 

25. Wang, Q., Dong, Q., Li, T., Gruverman, A. & Huang, J. Thin insulating tunneling contacts for efficient and water-resistant perovskite solar cells. Adv. Mater. 28, 6734–6739 (2016). 

26. Peng, J. et al. A universal double-side passivation for high opencircuit voltage in perovskite solar cells: role of carbonyl groups in poly(methyl methacrylate). Adv. Energy Mater. 8, 1801208 (2018). 

27. Zhuang, Q. et al. Enhanced performance and stability of TiO2nanoparticles-based perovskite solar cells employing a cheap polymeric surface modifier. ChemSusChem 12, 4824–4831 (2019). 

28. Wolff, C. M. et al. Reduced interface-mediated recombination for high open-circuit voltages in CH3NH3PbI3 solar cells. Adv. Mater. 29, 1700159 (2017). 

Nature Communications |  (2022) 13:7454 

10 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

29. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300–1309 (2020). 

30. Stolterfoht, M. et al. The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. Energy Environ. Sci. 12, 2778–2788 (2019). 

31. Onno, A., Chen, C., Koswatta, P., Boccard, M. & Holman, Z. C. Passivation, conductivity, and selectivity in solar cell contacts: Concepts and simulations based on a unified partial-resistances framework. J. Appl. Phys. 126, 183103 (2019). 

32. Kavadiya, S. et al. Investigation of the selectivity of carrier transport layers in wide-bandgap perovskite solar cells. Sol. RRL 5, 2100107 (2021). 

33. Dash, B. P., Satapathy, R., Gaillard, E. R., Maguire, J. A. & Hosmane, N. S. Synthesis and properties of carborane-appended C 3 -symmetrical extended π systems. J. Am. Chem. Soc. 132, 6578–6587 (2010). 

34. King, R. B. Three-dimensional aromaticity in deltahedral boranes and carboranes. Russ. Chem. Bull. 42, 1283–1291 (1993). 

35. Wee, K.-R. et al. Carborane-based optoelectronically active organic molecules: wide band gap host materials for blue phosphorescence. J. Am. Chem. Soc. 134, 17982–17990 (2012). 

36. Furue, R., Nishimoto, T., Park, I. S., Lee, J. & Yasuda, T. Aggregationinduced delayed fluorescence based on donor/acceptor-tethered janus carborane triads: unique photophysical properties of nondoped OLEDs. Angew. Chem. Int. Ed. 55, 7171–7175 (2016). 

37. Kim, B. G. et al. An unusual charge transfer accelerator of monomolecular Cb-OMe (4,4’-(ortho-carborane)bis(N,N-bis(4-methoxyphenyl)aniline) in perovskite optoelectronic devices. Sol. Energy Mater. Sol. Cells 208, 110414 (2020) . 

38. Yang, S. et al. Tailoring passivation molecular structures for extremely small open-circuit voltage loss in perovskite solar cells. J. Am. Chem. Soc. 141, 5781–5787 (2019). 

39. Zuo, L. et al. Tailoring the interfacial chemical interaction for highefficiency perovskite solar cells. Nano Lett. 17, 269–275 (2017). 

40. Xu, X. et al. Improving contact and passivation of buried interface for high-efficiency and large-area inverted perovskite solar cells. Adv. Funct. Mater. 32, 2109968 (2022). 

41. Liu, C. et al. Tuning structural isomers of phenylenediammonium to afford efficient and stable perovskite solar cells and modules. Nat. Commun. 12, 6394 (2021). 

42. Rakstys, K. et al. Triazatruxene-based hole transporting materials for highly efficient perovskite solar cells. J. Am. Chem. Soc. 137, 16172–16178 (2015). 

43. Xu, B. et al. Carbazole-based hole-transport materials for efficient solid-state dye-sensitized solar cells and perovskite solar cells. Adv. Mater. 26, 6629–6634 (2014). 

44. Zhang, G. et al. Nonfullerene acceptor molecules for bulk heterojunction organic solar cells. Chem. Rev. 118, 3447–3507 (2018). 

45. Said, A. A., Xie, J. & Zhang, Q. Recent progress in organic electron transport materials in inverted perovskite solar cells. Small 15, 1900854 (2019). 

46. Azmi, R. et al. Damp heat–stable perovskite solar cells with tailoreddimensionality 2D/3D heterojunctions. Science 376, 73–77 (2022). 

47. Chen, H. et al. Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. Nat. Photon. 16, 352–358 (2022). 

48. Thiesbrummel, J. et al. Universal current losses in perovskite solar cells due to mobile ions. Adv. Energy Mater. 11, 2101447 (2021). 

49. Diekmann, J. et al. Pathways toward 30% efficient single-junction perovskite solar cells and the role of mobile ions. Sol. RRL 5, 2100219 (2021). 

50. Xing, T. & Zhang, K. Syntheses of novel soluble carborane polyimides with ultrahigh thermal stability. Polym. Int. 64, 1715–1721 (2015). 

51. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 460–466 (2019). 

52. Wolff, C. M. et al. Orders of recombination in complete perovskite solar cells – linking time-resolved and steady-state measurements. Adv. Energy Mater. 11, 2101823 (2021). 

53. Kiermasch, D. et al. Unravelling steady-state bulk recombination dynamics in thick efficient vacuum-deposited perovskite solar cells by transient methods. J. Mater. Chem. A 7, 14712–14722 (2019). 

54. Tan, H. et al. Efficient and stable solution-processed planar perovskite solar cells via contact passivation. Science 355, 722–726 (2017). 

55. Siekmann, J., Ravishankar, S. & Kirchartz, T. Apparent defect densities in halide perovskite thin films and single crystals. ACS Energy Lett. 6, 3244–3251 (2021). 

56. Le Corre, V. M. et al. Revealing charge carrier mobility and defect densities in metal halide perovskites via space-charge-limited current measurements. ACS Energy Lett. 6, 1087–1094 (2021). 

57. Xu, J. et al. Perovskite–fullerene hybrid materials suppress hysteresis in planar diodes. Nat. Commun. 6, 7081 (2015). 

58. Caprioglio, P. et al. Bi-functional interfaces by poly(ionic liquid) treatment in efficient pin and nip perovskite solar cells. Energy Environ. Sci. 14, 4508–4522 (2021). 

59. Zhang, Z. et al. Marked passivation effect of naphthalene‐1,8‐ dicarboximides in high‐performance perovskite solar cells. Adv. Mater. 33, 2008405 (2021). 

60. Lee, M. M., Teuscher, J., Miyasaka, T., Murakami, T. N. & Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science 338, 643–647 (2012). 

61. Wang, J. et al. Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a Lewis base. Nat. Commun. 11, 177 (2020). 

62. Li, X. et al. Enhancing the stability of perovskite solar cells through cross-linkable and hydrogen bonding multifunctional additives. J. Mater. Chem. A 9, 12684–12689 (2021). 

63. Meng, X. et al. Highly stable and efficient FASnI3-based perovskite solar cells by introducing hydrogen bonding. Adv. Mater. 31, 1903721 (2019). 

64. Xie, H. et al. Decoupling the effects of defects on efficiency and stability through phosphonates in stable halide perovskite solar cells. Joule 5, 1246–1266 (2021). 

65. He, J. et al. Surface chelation of cesium halide perovskite by dithiocarbamate for efficient and stable solar cells. Nat. Commun. 11, 4237 (2020). 

66. Kim, B., Kim, M., Lee, J. H. & Seok, S. I. Enhanced moisture stability by butyldimethylsulfonium cation in perovskite solar cells. Adv. Sci. 7, 1901840 (2020). 

## Acknowledgements 

This work was supported by the National Natural Science Foundation of China (22179037), Shanghai Municipal Science and Technology Major Project (2018SHZDZX03, 21JC1401700), Programmer of Introducing Talents of Discipline to Universities (B16017), and Fundamental Research Funds for the Central Universities. We acknowledge HyPerCells (a joint graduate school of the University of Potsdam and the HelmholtzZentrum Berlin) and the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)—SPP 2196 (project number 423749265SURPRISE and 424709669-HIPSTER)—SFB951 (project number 182087777) for funding. We also acknowledge financial support from the Federal Ministry for Economic Affairs and Energy within the framework of the 7th Energy Research Program (P3T-HOPE, 03EE1017C). Additional funding came from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) – Projektnummer 491466077. M.S. further acknowledges the Heisenberg program from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) for funding —project number 498155101. Y.W. thank the Research Center of Analysis and Test of East China University of Science and Technology for the help on NMR and FTIR analysis. 

Nature Communications |  (2022) 13:7454 

11 

Article 

https://doi.org/10.1038/s41467-022-34203-x 

## Author contributions 

F.Y. conceived and designed the experiments, synthesized the molecules, analyzed and interpreted data, conceptualized the study, and drafted the manuscript; S.Z. contributed to the perovskite optimization and performed device characterization. Jo.W. helped to characterize and analyze PMMA-containing devices. Ji.W. and H.W. performed DFT simulations and corresponding analysis. Jo.W., E.G-P., and F.L. contributed to PL, pseudo-JV characterization, EL, and VOC-suns experiments and data analysis. Sahil.S. contributed to device fabrication and characterization, E.S., Bo.S., and Safa.S. contributed to SCLC measurements and corresponding data analysis. F.Z. contributed to the analysis of energy level measurements and XPS. Bu.S. performed C-AFM measurements and data analysis. D.N. and W.Z. contributed to the molecule development, interpretation of all experimental results, and organic molecule characterization. M.S. and Y.W. contributed to data analysis, and interpretation of the results, and conceptualized the study. All authors contributed to proofreading and revising the manuscript. 

## Funding 

Open Access funding enabled and organized by Projekt DEAL. 

## Competing interests 

The authors declare no competing interest. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-34203-x. 

Correspondence and requests for materials should be addressed to Martin Stolterfoht or Yongzhen Wu. 

Peer review information Nature Communications thanks Thomas White and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2022 

Nature Communications |  (2022) 13:7454 

12 

