# Crystallization in one-step solution deposition of perovskite films: Upward or downward?

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 330 |
| 作者 | Shangshang Chen, Xun Xiao, Bo Chen, Leah L. Kelly, Jing-Jing Zhao, Yu-Ze Lin, M. Toney, Jin-Song Huang |
| DOI | 10.1126/sciadv.abb2412 |
| 源文件 | 003_Chen_2021_Crystallization-in-one-step-solution-deposition.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**APPLIED PHYSICS** 

# **Crystallization in one-step solution deposition of perovskite films: Upward or downward?** 

### **Shangshang Chen**<sup>**1**</sup> **, Xun Xiao**<sup>**1**</sup> **, Bo Chen**<sup>**1**</sup> **, Leah L. Kelly**<sup>**2**</sup> **, Jingjing Zhao**<sup>**1**</sup> **, Yuze Lin**<sup>**1**</sup> **, Michael F. Toney**<sup>**2,3**</sup> **, Jinsong Huang**<sup>**1**</sup> ***** 

**Despite the fast progress of perovskite photovoltaic performances, understanding the crystallization and growth of perovskite films is still lagging. One unanswered fundamental question is whether the perovskite films are grown from top (air side) to bottom (substrate side) or from bottom to top despite 10 years of development. Here, by using grazing incidence x-ray diffraction and morphology characterizations, we unveil that the perovskite films prepared by one-step solution processes, including antisolvent-assisted spin coating and blade coating, follow the downward growth from intermediate phase during thermal annealing. Such a top-to-bottom downward growth is initialized by the evaporation of residual solvent from the top surface of “wet” films and is less sensitive to perovskite compositions and the wettability of underlying substrates. Addressing this fundamental question is important to understand the heterogeneity of perovskite films along the vertical direction, which markedly affects the efficiency and stability of perovskite solar cells.** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

#### **INTRODUCTION** 

Solution-processed metal halide perovskites (MHPs) have emerged as a new type of photovoltaic material that ensures both low manufacturing cost and high power conversion efficiencies (PCEs) ( _1_ ). In the past decade, the PCEs of perovskite solar cells (PSCs) have increased rapidly from 3.8% ( _2_ ) to 25.2% ( _3_ ), and such remarkable progress is enabled by global collaborative research efforts dedicated to improving device performance via solvent/additive engineering, defect passivation, interface optimization, and crystallization control ( _4_ – _7_ ). The quality of perovskite films is paramount in determining the photovoltaic performance of PSCs, and large, monolithic, and high-crystallinity grains with good coverage on substrates (or no pin holes) are always the goal of device optimization. Among all methods that produce high-quality perovskite films, the single-step deposition processes are particularly attractive in industrial production due to their high speed and low cost. Solution-based spin coating is one of the commonly used methods to prepare perovskite films in laboratories, and blade coating is gaining popularity among both academic research and industrial research ( _8_ – _11_ ). The precursor solutions are generally prepared by dissolving perovskite precursors in high–boiling point polar solvents like -butyrolactone (GBL), _N_ , _N_ ′-dimethylformamide (DMF), dimethyl sulfoxide (DMSO), and _N_ -methyl-2-pyrrolidone (NMP) ( _12_ ), or their mixtures with low– boiling point solvents such as 2-methoxyethanol (2-ME) for fast film drying ( _13_ ). In the early stage of the PSC research, the perovskite films prepared from spin coating typically suffered from poor coverage on substrates due to the difficulty in controlling solvent evaporation and perovskite crystallization ( _14_ ). As a result, their device performances are quite limited. To address such an issue, one effective approach as reported by Jeon _et al._ ( _12_ ) and Xiao _et al._ ( _15_ ) in 2014 is to drip antisolvents like toluene and chlorobenzene at a proper time window during spinning, which can extract residual 

> 1Department of Applied Physical Sciences, University of North Carolina at Chapel Hill, Chapel Hill, NC 27599, USA.<sup>2</sup> Stanford Synchrotron Radiation Lightsource, SLAC National Accelerator Laboratory, Menlo Park, CA 94025, USA.<sup>3</sup> Department of Chemical and Biological Engineering, University of Colorado, Boulder, CO 80309, USA. 

> *Corresponding author. Email: jhuang@unc.edu 

solvents nearly instantly, producing uniform and smooth perovskite polycrystalline films with barely any pin holes. Similarly, an air knife in blade coating was used to accelerate the drying of solvents ( _10_ , _13_ ). The formation of methylammonium-based MHP phase generally goes through an intermediate phase that includes an adduct structure of methylammonium iodide (MAI), lead iodide (PbI2), and DMSO, regardless using antisolvent or air knife treatment or not ( _12_ ). Such an intermediate phase can effectively retard the rapid nucleation and growth of perovskite grains during the required thermal annealing, thus leading to dense and smooth perovskite polycrystalline films with much better coverage on substrates. 

Despite that these single-step perovskite deposition methods have enabled multiple cases of record efficiencies for PSCs ( _16_ – _19_ ), there is still a lack of understanding of how perovskite grains crystallize from solution to solid during thermal annealing. Such a phase transition includes the crystallization processes in both lateral and vertical directions. Unfortunately, previous studies mainly focus on grain growth along the in-plane direction ( _20_ – _23_ ), because it is easier to study using top-view scanning electron microscopy (SEM), while the grain growth along the vertical direction has been barely investigated. A full comprehensive picture of the phase transition including crystal structural evolution and grain growth mechanisms is missing. When considering the vertical growth of perovskite grains, a key question that arises is what the grain growth direction is (upward or downward). Figuring out this fundamental question is important in understanding the phase conversion and grain crystallization in polycrystalline perovskite films. The heterogeneity of perovskite films along the vertical direction has been shown to affect both efficiency and stability of PSCs ( _24_ , _25_ ), which is closely related to the grain growth process in the vertical direction. Knowing the grain formation mechanism is of critical importance in understanding heterogeneity in perovskite polycrystalline films. To date, there are two prevailing scenarios in terms of the grain growth direction in perovskite films, which is illustrated in Fig. 1. One scenario is that the grain nucleation starts at the interface of the film and substrates, and then, the grains grow upward by converting the intermediate phase into perovskites, because the interface provides heterogeneous nucleation sites ( _20_ , _26_ – _29_ ). The other scenario is that perovskite 

**1 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Schematics show the upward (A) and downward (B) grain growth models when as-prepared perovskite films are annealed on a hot plate.** 

grains may grow downward from film top surfaces, or perovskitegas interface, after nucleation there, because the residual solvents leave the surface first by evaporation ( _30_ , _31_ ). Thus far, there is still no solid evidence that conclusively supports which growth mode dominates, and whether film deposition methods and perovskite compositions have influence on this. 

To shed light on this outstanding question, here, by using typical grazing incidence x-ray diffraction (GIXRD) that causes negligible damage to perovskite materials in the time scale of the measurement, we unveil that one-step solution processed perovskite polycrystalline films follow the downward growth when the intermediate phases are converted to monolithic or multiple-layer perovskite grains during thermal annealing. It is the evaporation of the coordinating solvent at the top surface (perovskite-gas interface) of intermediate phases that initializes the growth of perovskite grains. Such downward growth is independent of the perovskite compositions or the wettability of underneath substrates. 

#### **RESULTS** 

In this study, all fresh MAPbI3 precursor solution was prepared by dissolving 1.35 M MAI and PbI2 in a mixture solvent of DMF/ DMSO at a volume ratio of 9:1. The MAPbI3 films were then prepared by one-step spin-coating method followed by dripping of toluene as antisolvent and then annealed on a hot plate kept at 100°C for 10 min. The devices made of these films delivered the highest PCE of 19.7% (average PCE of 19.1 ± 0.39%, fig. S1) with a p-i-n structure of glass/indium tin oxide (ITO)/poly(bis(4-phenyl) (2,4,6- trimethylphenyl)amine) (PTAA)/MAPbI3/fullerene (C60)/ bathocuproine (BCP)/copper (Cu) ( _32_ ). Before thermal annealing, the “wet” film looks almost translucent (Fig. 2A). The GIXRD pattern of this film exhibits three dominant characteristic peaks at 2 of 6.6°, 7.2°, and 9.2° as shown in Fig. 2B, which can be assigned to (002), (021), and (022) planes of the crystalline intermediate phase of MAI-PbI2-DMSO as previously reported ( _12_ , _33_ ). A rough top surface and bar-like grain structures can be observed in its tilted SEM image (Fig. 3A). After annealing for 1 s on a hot plate set at 100°C, the films rapidly turned black and became much smoother (Figs. 2A and 3B). It is noted that it took ~10 s for the perovskite films to reach 100°C when they were annealed on the hot plate, and the actual temperature of the perovskite films annealed for less than 10 s was recorded and listed in table S1. The diffraction peaks from perovskite phase emerged (Fig. 2C), present with the intermediate phase peaks, showing that the part of the film converted into the perovskite phase, accompanied by the evaporation of coordinating 

DMSO from the top surface of the films. The contour of perovskite grains started to appear at the upper half of the film, while the rodlike intermediate phase remained at the bottom half of the films (Fig. 3B). With extended annealing duration to 3 to 30 s, the peaks from the intermediate phase disappeared at small incident angle (<1°) but remained at large incident angle (Fig. 2, D and E, and fig. S2). The penetration depths of x-ray at incidence angles from 0.1° to 3° can be found in table S2. It is noted that we did not observe the self-evolution from the intermediate phase of MAI-PbI2-DMSO from MAPbI3 perovskite phase during GIXRD measurement, which might cause some inaccuracy on the quantitative analysis results because this phase transition occurs at room temperature and does not represent the real crystallization process during thermal annealing at 100°C. Each GIXRD scanning took ~2 min, while the film annealed for 3 s showed no notable difference in its GIXRD pattern after storage in air at room temperature for 3 hours (fig. S3). These results are also consistent with the SEM images (Fig. 3, C and D), which show few nanorods and voids at the film-substrate interface. A similar trend was observed when we further increased the annealing duration to 60 s. These results show that the conversion of intermediate phase to perovskite started at the top surface of wet films and then went downward, instead of initializing at the film-substrate interface. After annealing for 10 min, no peak from the intermediate phase was observed at any incident angles (Fig. 2G), indicating that the intermediate phase had completely converted into perovskite phase. This is also consistent with the device performance results—the MAPbI3 film annealed for 10 min delivered a high PCE approaching 20%. By comparing the integrated intensity for the MAI-PbI2-DMSO intermediate (002) and MAPbI3 (110) diffraction peaks at each incidence angle over the span of annealing duration (the analysis details can be found in Materials and Methods), we found that intermediate phase rapidly converted into perovskite phase from the top surface (air side) and then crystallized downward until no notable intermediate phase was observed after 10 min (Fig. 2H). In addition, the top-down grain growth occurs over two time scales: a rapid conversion in the first few seconds and a slow process that occurs from 3 s to 10 min. In the first step from 0- to 3-s annealing, the rate of conversion is fast, nearly converting all of the intermediate phase to perovskite phase. After 3-s annealing, the conversion markedly slows, likely because the surface has been fully converted and it takes longer for the residual DMSO to escape from the bulk. 

To understand whether the film deposition method affects this growth behavior, we also investigated the grain growth in bladecoated MAPbI3 films prepared from a N2 knife–assisted blading ( _13_ ). The precursor solution was prepared by dissolving stoichiometric 

**2 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 2. GIXRD measurement on MAPbI3 films.** ( **A** ) Photographs of the MAPbI3 films on glass/ITO/PTAA substrates (15 mm × 15 mm) annealed for different times. ( **B** to **G** ) GIXRD patterns (vertically offset for clarity, * denotes the peaks from the MAI-PbI2-DMSO intermediate phase) of the MAPbI3 films annealed for different times: (B) 0 s, (C) 1 s, (D) 3 s, (E) 30 s, (F) 60 s, and (G) 10 min. a.u., arbitrary units. ( **H** ) Evolution of intermediate phase in MAPbI3 films over annealing duration. 

MAI and PbI2 in 2-ME with 1.5% (v/v) DMSO as coordinating solvent (the detailed procedure can be found in Materials and Methods). Similar to antisolvent dripping, the N2 knife can rapidly remove the volatile 2-ME and convert the precursor solution to a mixture of intermediate or perovskite phases at room temperature. Upon 

flushing by the N2 knife, the film turned black (Fig. 4A, inset), indicating that perovskite phase already formed before thermal annealing. As shown in Fig. 4A, the perovskite phase is dominant at the top surface (x-ray incidence angle <0.5°). However, when further increasing the x-ray incidence angle from 1° to 3° in GIXRD measurement, 

**3 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. SEM characterization of MAPbI3 films.** ( **A** to **F** ) Tilted SEM images of the MAPbI3 films annealed for different times: (A) 0 s, (B) 1 s, (C) 3 s, (D) 30 s, (E) 60 s, and (F) 10 min. Scale bars, 1 m. 

the diffraction peaks from intermediate phase emerged, which indicates that the blade-coated films also follow the downward grain growth. 

In addition to the benchmark composition of MAPbI3, we also performed similar studies using other perovskite compositions with mixed cation and anion, which have been broadly used for higher efficiency and better stability ( _34_ , _35_ ). The highest PCE of 20.2% (average PCE of 19.4 ± 0.38%) was obtained using the composition of Cs0.05FA0.81MA0.14PbI2.55Br0.45 (CFM) in p-i-n structure devices, as shown by the typical _J-V_ curve under one-sun illumination in fig. S1. The CFM precursor solution was prepared by dissolving corresponding cation salts and lead halide in a DMF/DMSO (4:1) mixture. The CFM films prepared by one-step spin-coating method were already dark before thermal annealing. Its GIXRD pattern (fig. S4) shows the coexistence of both intermediate and perovskite phases. This is different from the MAPbI3 sample where the dominant species is intermediate phase right after spin coating (Fig. 2B). After short annealing for 5 s, the XRD peak for the intermediate phase was absent at small x-ray incident angle of <1° but retained at large x-ray incident angles to 2° and 3° (Fig. 4B). This indicates that the CFM films exhibited the same downward grain growth behavior as MAPbI3. Furthermore, a series of other perovskite compositions including wide-bandgap Cs0.40FA0.60PbI1.95Br1.05 ( _36_ ) and mediumbandgap Rb0.05Cs0.05FA0.75MA0.15PbI2.85Br0.15 (RCFM) ( _37_ ) were also tested. All these films were processed from precursor solutions containing 20% volume ratio of DMSO and thus underwent intermediate phases before forming perovskite phases. It should be noted that the intermediate phases vary with perovskite compositions, and MAfree compositions still undergo a PbI2-DMSO intermediate phase before converting into perovskites. As shown in fig. S5, all these perovskite films showed downward grain growth during thermal annealing. This result concludes that downward grain growth in one-step solution processed perovskite films is not obviously dependent on perovskite compositions. 

We also investigated how the wettability of substrates affects the vertical grain growth direction in one-step processed perovskite films with antisolvent dripping method. Besides the ITO substrates covered by PTAA that results in a hydrophobic surface, we also prepared ITO substrates covered by hydrophilic c-TiO2/mp-TiO2 and poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS). As shown in Fig. 4 (C and D), the MAPbI3 films annealed for 5 s on TiO2 and PEDOT:PSS exhibited the same top-down grain growth as that on the PTAA-covered substrate. A similar trend was also observed in the cases of SnO2 or PTB7-Th ( _38_ ) covered substrates (fig. S6). These results further support the idea that downward grain growth is induced by the evaporation of residual DMSO from the top surface and thus is not sensitive to the wettability of underlying substrates. Nevertheless, the aforementioned results are all based on perovskite films with the monolithic grain structure, i.e., one single layer of apparent perovskite grains. The formation of monolithic grains can be well explained by the unidirectional downward growth mechanism presented above. However, double- or even multiplelayer grains with horizontal grain boundaries are also commonly observed in perovskite films prepared by one-step deposition processes, although their formation mechanism remains unclear yet. This was ascribed to a bidirectional growth mode when both upward and downward growths occur simultaneously ( _28_ , _29_ ). The grazing x-rays in Figs. 2 and 4 were incident onto the air side of the films and cannot exclude such a possibility. To examine whether the doublelayer grains are grown along single or dual directions, we further carried out GIXRD measurement with x-ray incident from the perovskite/PTAA side into perovskite films. This sample was prepared by lifting off the MAPbI3 film (annealed for 5 s) from the PTAA-covered ITO glass substrates using an adhesive epoxy encapsulant, as illustrated in Fig. 5A, and the experimental details can be found in Materials and Methods. After flipping the MAPbI3 film, we were able to perform GIXRD measurement and acquire the composition information at the perovskite-PTAA interface that 

**4 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 4. GIXRD patterns of the perovskite films annealed for different times at 100°C.** ( **A** ) Blade-coated MAPbI3 film on glass/ITO/PTAA substrate without thermal annealing. ( **B** ) CFM film annealed for 5 s on glass/ITO/PTAA substrate. Insets show the photos of the film samples. MAPbI3 films annealed for 5 s on ( **C** ) glass/fluorine-doped tin oxide (FTO)/c-TiO2/mp-TiO2 and ( **D** ) glass/ITO/PEDOT:PSS substrates (vertically offset for clarity, * denotes the peaks from intermediate phase). 

contacted ITO substrates before peeling off. Different from the MAPbI3 film samples that were prepared from fresh precursor solution (Fig. 2), we used the precursor solution aged for 1 week to fabricate the perovskite films that often exhibited double-layer grain structure, as shown in Fig. 5C. The reason behind the formation of such a morphology is still under investigation, and we speculate that excessive crystallization nuclei were already formed in aged precursor solution. The GIXRD pattern of the flipped MAPbI3 film is presented in Fig. 5B. When the x-ray incident angle is 0.5°, the peak intensity of the intermediate phase at 2 of 6.6° is comparable to that of the perovskite phase (2 = 14.2°). This is very different from the results when x-ray came in from air side, as shown in Fig. 2 (C to E), which shows that the peak intensity of perovskite phase is much higher than that of the intermediate phase. We compared the relative intensity between intermediate ( _I_ inter, 2 = 6.6°) and perovskite ( _I_ pero, 2 = 14.2°) phases. As shown in Fig. 5D, the intermediate phase peak was much stronger for regions close to the interface of perovskite-PTAA (a small x-ray incident angle of 0.5°) and then significantly reduced when the x-ray incident angle increased to 3°. These results indicate that the intermediate phase was rich at the perovskite-substrate interface. If the double-layer grains were formed by bidirectional growth, the intermediate phase should 

have been trapped in the middle of the film rather than at the filmsubstrate interface. In addition, we prepared a MAPbI3 film with a much larger thickness of 1 m by increasing the concentration of aged precursor solution from 1.35 to 2.0 M. The thicker film could trap more intermediate phase inside before fully drying, enabling us to better observe the phase evolution in SEM characterization. As shown in Fig. 5E, we observed some voids embedded at the interface of perovskite-substrate. They should originate from the volume shrink for the drying of initially entrapped intermediate phase. Above these voids, lateral grain boundaries (outlined in yellow) can be observed. Similar phenomenon was also observed in previous reports ( _31_ , _39_ , _40_ ). If the grains followed bidirectional growth, the voids should have stayed in the middle of the film. These results further confirm that the double-layer grains still follow downward instead of bidirectional growth. We also investigate the crosssectional SEM images of the MAPbI3 films processed from the precursor solution with neat DMF as solvent. Similar results were observed (fig. S7), which indicates that the perovskites still follow the downward grain growth even without undergoing intermediate phase. Therefore, it is the evaporation of solvents from the top surface that initializes perovskite crystallization along the vertical direction. 

**5 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 5. The growth direction in the MAPbI3 films with multiple-layer grains.** ( **A** ) Preparation process, ( **B** ) GIXRD pattern (vertically offset for clarity), ( **C** ) cross-sectional SEM, and ( **D** ) relative GIXRD intensity of intermediate and perovskite phases of the flipped MAPbI3 film peeled off from the glass/ITO/PTAA substrate annealed for 5 s at 100°C. ( **E** ) Cross-sectional SEM image of the MAPbI3 film on glass/ITO/PTAA annealed for 5 s at 100°C prepared from an increased precursor concentration of 2.0 M (the lateral grain boundaries are outlined in yellow rectangle). 

#### **DISCUSSION** 

In summary, we unravel that the perovskite polycrystalline films prepared by one-step spin-coating or blade-coating methods follow the downward grain growth. Such vertical growth direction is intrinsically induced by the escape of residual solvents and is less sensitive to the wettability of substrates or perovskite compositions. The conclusions from this work will help the perovskite community understand the phase conversion and the heterogeneity along the vertical direction in perovskite polycrystalline films, thus providing guidance to manipulate grain growth and film morphology toward more efficient and stable PSCs. 

#### **MATERIALS AND METHODS** 

### **Materials** 

PTAA (average _M_ n 7000 to 10,000), PbI2 (99.999% trace metals), cesium iodide (99.999% trace metals basis), rubidium iodide (99.9% trace metals basis), DMF, DMSO, l--phosphatidylcholine (LP), 2-ME, toluene, chlorobenzene, and BCP were purchased from Sigma- Aldrich and used without further purification. MAI, methylammonium bromide (MABr), and formamidinium iodide (FAI) were purchased from GreatCell Solar. Methylammonium chloride (MACl) was purchased from Xi’an Polymer Light Technology Corp. C60 was purchased from Nano-C Inc. PTB7-Th was purchased from 1-Material Inc. 

**6 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

PEDOT:PSS (CLEVIOS Al 4083) was purchased from Heraeus. SnO2 (15% in H2O colloidal dispersion) was purchased from Alfa Aesar. 

### **Fabrication of film samples and PSCs** 

### **_Preparation of substrates and charge-transporting layers_** 

Patterned ITO glass substrates (1.5 cm × 1.5 cm, 0.7 mm thick) were first cleaned by ultrasonication with soap, deionized water, and Isopropyl alcohol (IPA) and then ultraviolet ozone–treated for 15 min before use. PTAA (2 mg ml<sup>−1</sup> ) dissolved in toluene was spin-coated onto ITO glass substrates at 5000 rpm for 20 s, followed by thermal annealing at 100°C for 10 min in a N2-filled glove box. PEDOT:PSS CLEVIOS Al 4083 was filtered with a 0.2-m Nylon filter and spin-coated onto ITO glass substrates at 5000 rpm for 20 s and then annealed for 150°C for 15 min in air. PTB7-Th (2 mg ml<sup>−1</sup> ) dissolved in toluene was spin-coated onto ITO glass substrates at 5000 rpm for 20 s, followed by thermal annealing at 100°C for 10 min in a N2-filled glove box. 

### **_Fabrication of the perovskite films and devices_** 

All spin-coated films were prepared in a N2-filled glove box. For one-step spin-coated MAPbI3 films, 1.35 M MAPbI3 was dissolved in DMF/DMSO (9:1) mixture and spin-coated onto PTAA-covered ITO glass substrates at 2000 rpm for 5 s and then 4000 rpm for 20 s. Toluene (130 l) was dripped onto the substrates at the 10th second. The as-cast films were annealed on a hot plate kept at 100°C for different times. For one-step spin-coated mixed composition films, 1.35 M CFM or RCFM was dissolved in DMF/DMSO (4:1) mixture and spin-coated onto PTAA-covered ITO substrates at 2000 rpm for 2 s and then 4000 rpm for 20 s. Chlorobenzene (130 l) was dripped onto the substrates at the 17th second. The as-cast films were annealed on a hot plate kept at 100°C for different times. Cs0. 40<sup>FA</sup> 0.60<sup>PbI</sup> 1.95<sup>Br</sup> 1.05<sup>(1.35 M) was dissolved in DMF/DMSO (4:1)</sup> and spin-coated at PTAA-covered ITO substrates at 6000 rpm for 40 s. Toluene (200 l) was dripped onto the substrates at the 20th second. The as-cast films were annealed on a hot plate kept at 100°C for different times. The blade-coated MAPbI3 films were prepared at room temperature in air. First, PTAA (3.3 mg ml<sup>−1</sup> ) in toluene was bladed-coated onto ITO substrates at a gap of 200 m and a movement of 20 mm s<sup>−1</sup> . After that, MAPbI3 precursor solution [1.67 M MAI and 1.67 M PbI2 in 2-ME, LP (0.3 mg ml<sup>−1</sup> ), MACl (1.5 mg ml<sup>−1</sup> ), 1.5% (v/v) DMSO, and 0.15% (v/v) MAH2PO2 as additives] was further blade-coated onto PTAA-covered ITO glass substrates at a gap of 250 m and a movement speed of 20 mm s<sup>−1</sup> , followed by thermal annealing on a hot plate kept at 100°C for different times. The N2 knife worked below 20 psi. For all solar cells, the optimized thermal annealing duration was 10 min. The devices were completed by thermally evaporating C60 (30 nm, 0.2 Å s<sup>−1</sup> ), BCP (6 nm, 0.1 Å s<sup>−1</sup> ), and Cu (90 nm, 1 Å s<sup>−1</sup> ) in sequential order. 

### **Device characterization** 

The _J-V_ characteristics of solar cells were performed using a Xenon lamp–based solar simulator (Oriel Sol3A, Class AAA Solar Simulator) at room temperature in air, and the power of the simulated light was calibrated to 100 mW cm<sup>−2</sup> by a silicon (Si) diode (Hamamatsu S1133) equipped with a Schott visible-color glass filter (KG5 color filter). For solar cells, a metal mask with an aperture area of 6.08 mm<sup>2</sup> (3.8 mm × 1.6 mm) aligned with the device area, and all cells were measured using a Keithley 2400 source meter with a scan rate of 0.1 V s<sup>−1</sup> with a delay time of 10 ms. SEM images were taken on FEI Helios 600 NanoLab DualBeam System operating at 5 kV. GIXRD 

measurements were carried out with a Rigaku SmartLab diffractometer using Cu K radiation (a wavelength of 1.5418 Å), and the height of films was calibrated before each measurement. The x-ray penetration depths at each incidence angle were calculated with an expression using the photon energy and index of refraction for MAPbI3 to determine the critical angle and to plot the penetration depth with angle ( _41_ , _42_ ). The relative amounts of each phase in Fig. 2H were analyzed by comparing the MAPbI3 (110) and intermediate (002) peak intensities at varied incidence angles for each annealing time. To further quantify the thickness of the MAPbI3 surface layer, the integrated intensities of MAPbI3 (110) and the intermediate phase (002) diffraction peaks were determined as a function of incidence angle. These integrated intensities were calculated by fitting the diffraction data with Voigt line shapes after a linear background had been subtracted. The ratio of integrated intensity for the MAPbI3 versus intermediate phase was then modeled with a proportionality derived from Toney and Brennan ( _43_ ) where both surface layer and bulk MAPbI3 are assumed to be present. Here, _I_ MAPI and _I_ int are the integrated intensities for MAPbI3 and the intermediate phase diffraction peaks, respectively. _D_ is the penetration depth (calculated from the photon energy, incidence angle, and critical angle for MAPbI3), and _D_ MAPI and _D_ int are the thicknesses of the MAPbI3 and intermediate phases in the film, respectively 



<!-- Start of picture text -->
I MAPI ( ) ∝ D [ 1 − exp (─ −  D D MAPI )]<br>I int ( ) ∝ D [ exp (─ −  D D MAPI )][  1 − exp  (  −  ─ D D int)]<br><!-- End of picture text -->

### **Preparation of flipped films for GIXRD measurement** 

The shortly annealed films on glass/ITO/PTAA substrates were encapsulated by 1.1-mm-thick glass slices using a Gorilla epoxy coated on the top sides of glass and then held by a metal clip for the purpose of better contact. After curing, the glass slides were carefully peeled off from ITO glass substrates with a glass nipping plier. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at http://advances.sciencemag.org/cgi/ content/full/7/4/eabb2412/DC1 

### **REFERENCES AND NOTES** 

1. M. A. Green, A. Ho-Baillie, H. J. Snaith, The emergence of perovskite solar cells. _Nat. Photonics_ **8** , 506–514 (2014). 

2. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, Organometal halide perovskites as visiblelight sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

3. NREL Best Research-Cell Efficiency Chart; https://www.nrel.gov/pv/cell-efficiency.html [accessed July 2020]. 

4. Y. Zhao, K. Zhu, Organic–inorganic hybrid lead halide perovskites for optoelectronic and electronic applications. _Chem. Soc. Rev._ **45** , 655–689 (2016). 

5. B. Chen, P. N. Rudd, S. Yang, Y. Yuan, J. Huang, Imperfections and their passivation in halide perovskite solar cells. _Chem. Soc. Rev._ **48** , 3842–3867 (2019). 

6. J. Seo, J. H. Noh, S. I. Seok, Rational strategies for efficient perovskite solar cells. _Acc. Chem. Res._ **49** , 562–572 (2016). 

7. A. Rajagopal, K. Yao, A. K.-Y. Jen, Toward perovskite solar cell commercialization: A perspective and research roadmap based on interfacial engineering. _Adv. Mater._ **30** , 1800455 (2018). 

8. Z. Li, T. R. Klein, D. H. Kim, M. Yang, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Scalable fabrication of perovskite solar cells. _Nat. Rev. Mater._ **3** , 18017 (2018). 

9. M. Yang, Z. Li, M. O. Reese, O. G. Reid, D. H. Kim, S. Siol, T. R. Klein, Y. Yan, J. J. Berry, M. F. A. M. van Hest, K. Zhu, Perovskite ink with wide processing window for scalable high-efficiency solar cells. _Nat. Energy_ **2** , 17038 (2017). 

10. J. Ding, Q. Han, Q.-Q. Ge, D.-J. Xue, J.-Y. Ma, B.-Y. Zhao, Y.-X. Chen, J. Liu, D. B. Mitzi, J.-S. Hu, Fully air-bladed high-efficiency perovskite photovoltaics. _Joule_ **3** , 402–416 (2019). 

**7 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 

## SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

11. I. A. Howard, T. Abzieher, I. M. Hossain, H. Eggers, F. Schackmar, S. Ternes, B. S. Richards, U. Lemmer, U. W. Paetzold, Coated and printed perovskites for photovoltaic applications. _Adv. Mater._ **31** , 1806702 (2019). 

12. N. J. Jeon, J. H. Noh, Y. C. Kim, W. S. Yang, S. Ryu, S. I. Seok, Solvent engineering for high-performance inorganic–organic hybrid perovskite solar cells. _Nat. Mater._ **13** , 897–903 (2014). 

13. Y. Deng, C. H. Van Brackle, X. Dai, J. Zhao, B. Chen, J. Huang, Tailoring solvent coordination for high-speed, room-temperature blading of perovskite photovoltaic films. _Sci. Adv._ **5** , eaax7537 (2019). 

14. G. E. Eperon, V. M. Burlakov, P. Docampo, A. Goriely, H. J. Snaith, Morphological control for high performance, solution-processed planar heterojunction perovskite solar cells. _Adv. Funct. Mater._ **24** , 151–157 (2014). 

15. M. Xiao, F. Huang, W. Huang, Y. Dkhissi, Y. Zhu, J. Etheridge, A. Gray-Weale, U. Bach, Y. B. Cheng, L. Spiccia, A fast deposition-crystallization procedure for highly efficient lead iodide perovskite thin-film solar cells. _Angew. Chem. Int. Ed._ **53** , 9898–9903 (2014). 

16. E. H. Jung, N. J. Jeon, E. Y. Park, C. S. Moon, T. J. Shin, T. Y. Yang, J. H. Noh, J. Seo, Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). _Nature_ **567** , 511–515 (2019). 

17. H. Tan, A. Jain, O. Voznyy, X. Lan, F. P. García de Arquer, J. Z. Fan, R. Quintero-Bermudez, M. Yuan, B. Zhang, Y. Zhao, F. Fan, P. Li, L. N. Quan, Y. Zhao, Z.-H. Lu, Z. Yang, S. Hoogland, E. H. Sargent, Efficient and stable solution-processed planar perovskite solar cells via contact passivation. _Science_ **355** , 722–726 (2017). 

18. M. Kim, G. H. Kim, T. K. Lee, I. W. Choi, H. W. Choi, Y. Jo, Y. J. Yoon, J. W. Kim, J. Lee, D. Huh, H. Lee, S. K. Kwak, J. Y. Kim, D. S. Kim, Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. _Joule_ **3** , 2179–2192 (2019). 

19. S. Yang, S. Chen, E. Mosconi, Y. Fang, X. Xiao, C. Wang, Y. Zhou, Z. Yu, J. Zhao, Y. Gao, F. de Angelis, J. Huang, Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. _Science_ **365** , 473–478 (2019). 

20. J.-W. Lee, D.-K. Lee, D.-N. Jeong, N.-G. Park, Control of crystal growth toward scalable fabrication of perovskite solar cells. _Adv. Funct. Mater._ **29** , 1807047 (2019). 

21. H. Hu, M. Singh, X. Wan, J. Tang, C. W. Chu, G. Li, Nucleation and crystal growth control for scalable solution-processed organic–inorganic hybrid perovskite solar cells. _J. Mater. Chem. A_ **8** , 1578–1603 (2020). 

22. M. Konstantakou, D. Perganti, P. Falaras, T. Stergiopoulos, Anti-solvent crystallization strategies for highly efficient perovskite solar cells. _Crystals_ **7** , 291 (2017). 

23. A. Dubey, N. Adhikari, S. Mabrouk, F. Wu, K. Chen, S. Yang, Q. Qiao, A strategic review on processing routes towards highly efficient perovskite solar cells. _J. Mater. Chem. A_ **6** , 2406–2431 (2018). 

24. E. M. Tennyson, T. A. S. Doherty, S. D. Stranks, Heterogeneity at multiple length scales in halide perovskite semiconductors. _Nat. Rev. Mater._ **4** , 573–587 (2019). 

25. C. Zhu, X. Niu, Y. Fu, N. Li, C. Hu, Y. Chen, X. He, G. Na, P. Liu, H. Zai, Y. Ge, Y. Lu, X. Ke, Y. Bai, S. Yang, P. Chen, Y. Li, M. Sui, L. Zhang, H. Zhou, Q. Chen, Strain engineering in perovskite solar cells and its impacts on carrier dynamics. _Nat. Commun._ **10** , 815 (2019). 

26. T. Ling, X. Zou, J. Cheng, Y. Yang, H. Ren, D. Chen, Modulating surface morphology related to crystallization speed of perovskite grain and semiconductor properties of optical absorber layer under controlled doping of potassium ions for solar cells. _Materials_ **11** , 1605 (2018). 

27. Y. Yu, S. Yang, L. Lei, Y. Liu, Nucleation mediated interfacial precipitation for architectural perovskite films with enhanced photovoltaic performance. _Nanoscale_ **9** , 2569–2578 (2017). 

28. Y. Bai, S. Xiao, C. Hu, T. Zhang, X. Meng, Q. Li, Y. Yang, K. S. Wong, H. Chen, S. Yang, A pure and stable intermediate phase is key to growing aligned and vertically monolithic perovskite crystals for efficient PIN planar perovskite solar cells with high processibility and stability. _Nano Energy_ **34** , 58–68 (2017). 

29. B. Shen, Y. Wang, Z. Hu, S. Tang, Y. Chen, J. Zhang, Y. Zhu, Growth of monolithically grained CH3NH3PbI3 film by a uniform intermediate phase for high performance planar perovskite solar cells. _J. Alloys Compd._ **776** , 250–258 (2019). 

30. Y. Lin, Y. Fang, J. Zhao, Y. Shao, S. J. Stuard, M. M. Nahid, H. Ade, Q. Wang, J. E. Shield, N. Zhou, A. M. Moran, J. Huang, Unveiling the operation mechanism of layered perovskite solar cells. _Nat. Commun._ **10** , 1008 (2019). 

31. F. Zhang, J. Song, L. Zhang, F. Niu, Y. Hao, P. Zeng, H. Niu, J. Huang, J. Lian, Film-through large perovskite grains formation via a combination of sequential thermal and solvent treatment. _J. Mater. Chem. A_ **4** , 8554–8561 (2016). 

32. J. Zhao, X. Zheng, Y. Deng, T. Li, Y. Shao, A. Gruverman, J. Shield, J. Huang, Is Cu a stable electrode material in hybrid perovskite solar cells for a 30-year lifetime? _Energ. Environ. Sci._ **9** , 3650–3656 (2016). 

33. J. Li, R. Munir, Y. Fan, T. Niu, Y. Liu, Y. Zhong, Z. Yang, Y. Tian, B. Liu, J. Sun, D. M. Smilgies, S. Thoroddsen, A. Amassian, K. Zhao, S. F. Liu, Phase transition control for highperformance blade-coated perovskite solar cells. _Joule_ **2** , 1313–1330 (2018). 

34. N. J. Jeon, J. H. Noh, W. S. Yang, Y. C. Kim, S. Ryu, J. Seo, S. I. Seok, Compositional engineering of perovskite materials for high-performance solar cells. _Nature_ **517** , 476–480 (2015). 

35. L. K. Ono, E. J. Juarez-Perez, Y. Qi, Progress on perovskite materials and solar cells with mixed cations and halide anions. _ACS Appl. Mater. Interfaces_ **9** , 30197–30246 (2017). 

36. Z. Yang, Z. Yu, H. Wei, X. Xiao, Z. Ni, B. Chen, Y. Deng, S. N. Habisreutinger, X. Chen, K. Wang, J. Zhao, P. N. Rudd, J. J. Berry, M. C. Beard, J. Huang, Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. _Nat. Commun._ **10** , 4498–4506 (2019). 

37. T. Matsui, T. Yamamoto, T. Nishihara, R. Morisawa, T. Yokoyama, T. Sekiguchi, T. Negami, Compositional engineering for thermally stable, highly efficient perovskite solar cells exceeding 20% power conversion efficiency with 85 °C/85% 1000 h stability. _Adv. Mater._ **31** , 1806823 (2019). 

38. S.-H. Liao, H.-J. Jhuo, Y.-S. Cheng, S.-A. Chen, Fullerene derivative-doped zinc oxide nanofilm as the cathode of inverted polymer solar cells with low-bandgap polymer (PTB7-Th) for high performance. _Adv. Mater._ **25** , 4766–4771 (2013). 

39. Y. Tu, J. Wu, Z. Lan, X. He, J. Dong, J. Jia, P. Guo, J. Lin, M. Huang, Y. Huang, Modulated CH3NH3PbI3−xBrx film for efficient perovskite solar cells exceeding 18%. _Sci. Rep._ **7** , 44603 (2017). 

40. T. Liu, Y. Zong, Y. Zhou, M. Yang, Z. Li, O. S. Game, K. Zhu, R. Zhu, Q. Gong, N. P. Padture, High-performance formamidinium-based perovskite solar cells via microstructuremediated -to- phase transformation. _Chem. Mater._ **29** , 3246–3250 (2017). 

41. M. F. Toney, S. Brennan, Observation of the effect of refraction on x rays diffracted in a grazing-incidence asymmetric Bragg geometry. _Phys. Rev. B_ **39** , 7963–7966 (1989). 

42. S. Lilliu, T. G. Dane, M. Alsari, J. Griffin, A. T. Barrows, M. S. Dahlem, R. H. Friend, D. G. Lidzey, J. E. Macdonald, Mapping morphological and structural properties of lead halide perovskites by scanning nanofocus XRD. _Adv. Funct. Mater._ **26** , 8221–8230 (2016). 

43. M. F. Toney, S. Brennan, Structural depth profiling of iron oxide thin films using grazing incidence asymmetric Bragg x-ray diffraction. _J. Appl. Phys._ **65** , 4763–4768 (1989). 

##### **Acknowledgments** 

**Funding:** We thank the complete financial support from the Center for Hybrid Organic Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the DOE Office of Basic Energy Sciences, Office of Science. **Author contributions:** S.C. and J.H. conceived the idea. S.C. prepared all films and solar cells and carried out GIXRD and SEM measurements. X.X. assisted the GIXRD measurement. B.C. prepared flipped film samples for GIXRD measurement. L.L.K. analyzed GIXRD results. M.F.T. supervised the analysis of GIXRD results. J.Z. assisted the GIXRD analysis. Y.L. participated in the discussions of the results. S.C. and J.H. wrote the manuscript with comments from all authors. **Competing interests:** The authors declare that they have no competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. Additional data related to this paper may be requested from J.H. (jhuang@unc.edu). 

Submitted 9 July 2020 Accepted 3 December 2020 Published 22 January 2021 10.1126/sciadv.abb2412 

**Citation:** S. Chen, X. Xiao, B. Chen, L. L. Kelly, J. Zhao, Y. Lin, M. F. Toney, J. Huang, Crystallization in one-step solution deposition of perovskite films: Upward or downward?. _Sci. Adv._ **7** , eabb2412 (2021). 

**8 of 8** 

Chen _et al_ ., _Sci. Adv._ 2021; **7** : eabb2412     22 January 2021 



### **Crystallization in one-step solution deposition of perovskite films: Upward or downward?** 

Shangshang Chen, Xun Xiao, Bo Chen, Leah L. Kelly, Jingjing Zhao, Yuze Lin, Michael F. Toney and Jinsong Huang 

_Sci Adv_ **7** (4), eabb2412. DOI: 10.1126/sciadv.abb2412 



<!-- Start of picture text -->
ARTICLE TOOLS http://advances.sciencemag.org/content/7/4/eabb2412<br>SUPPLEMENTARY MATERIALS http://advances.sciencemag.org/content/suppl/2021/01/14/7.4.eabb2412.DC1<br>REFERENCES This article cites 42 articles, 3 of which you can access for free<br>http://advances.sciencemag.org/content/7/4/eabb2412#BIBL<br>PERMISSIONS http://www.sciencemag.org/help/reprints-and-permissions<br><!-- End of picture text -->

Terms of Service 

Use of this article is subject to the 

_Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science, 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

