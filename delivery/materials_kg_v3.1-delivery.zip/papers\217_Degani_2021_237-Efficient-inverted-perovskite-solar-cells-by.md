# 23.7% Efficient inverted perovskite solar cells by dual interfacial modification

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science Advances |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 365 |
| 作者 | M. Degani, Qingzhi An, Miguel Albaladejo‐Siguan, Yvonne J. Hofstetter, Chang-Hun Cho, F. Paulus, G. Grancini, Yana Vaynzof |
| DOI | 10.1126/sciadv.abj7930 |
| 源文件 | 017_Degani_2021_237-Efficient-inverted-perovskite-solar-cells-by.pdf |

---
SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**M A T E RIALS SCIENC E** 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

# **23.7% Efficient inverted perovskite solar cells by dual interfacial modification** 

### **Matteo Degani**<sup>**1,2**</sup> **, Qingzhi An**<sup>**2**</sup> **, Miguel Albaladejo-Siguan**<sup>**2**</sup> **, Yvonne J. Hofstetter**<sup>**2**</sup> **, Changsoon Cho**<sup>**2**</sup> **†, Fabian Paulus**<sup>**2**</sup> **, Giulia Grancini**<sup>**1**</sup> ***, Yana Vaynzof**<sup>**2**</sup> ***** 

**Despite remarkable progress, the performance of lead halide perovskite solar cells fabricated in an inverted structure lags behind that of standard architecture devices. Here, we report on a dual interfacial modification approach based on the incorporation of large organic cations at both the bottom and top interfaces of the perovskite active layer. Together, this leads to a simultaneous improvement in both the open-circuit voltage and fill factor of the devices, reaching maximum values of 1.184 V and 85%, respectively, resulting in a champion device efficiency of 23.7%. This dual interfacial modification is fully compatible with a bulk modification of the perovskite active layer by ionic liquids, leading to both efficient and stable inverted architecture devices.** 

Despite this class of cations being commonly used for the formation of low-dimensional perovskites ( _23_ – _26_ ), in our work, we adopt a different strategy and use a very low concentration to modify both interfaces of inverted perovskite solar cells. We find that this approach does not change the bulk perovskite crystal structure or its dimensionality but rather improves the interfaces by facilitating high-quality film formation on top of the HTL and inducing efficient defect passivation at the perovskite/ETL interface. We show that the modification of the buried bottom interface leads to a more homogeneous film formation and the elimination of nanovoids at the perovskite/HTL interface. These improvements result in a significant increase in the FF accompanied by a small increase in the shortcircuit current ( _J_ SC). The modification of the top perovskite surface, on the other hand, leads to its efficient passivation, resulting in a substantial increase in the _V_ OC. The implementation of both modifications at the same time results in a simultaneous increase in all of the photovoltaic parameters leading to a superior device performance. As a result, we achieve a high PCE of 23.7%, with a net improvement of device _V_ OC up to 1.184 V and very high FF of 85%. 

#### **INTRODUCTION** 

Metal halide perovskites have experienced a rapid progress in highimpact optoelectronics, with particularly notable advances made in the field of perovskite photovoltaics ( _1_ – _3_ ). In single-junction devices, power conversion efficiencies (PCEs) of up to 25.5% have been demonstrated to date ( _4_ ). The record efficiency devices follow the standard device architecture, in which the perovskite active layer is deposited on top of an electron transport layer (ETL) such as titanium dioxide (TiO2) or tin oxide (SnO2) and is then coated with a hole transport layer (HTL) ( _5_ – _7_ ). Despite tremendous interest in inverted architecture perovskite solar cells—in which the order of charge extracting layers is inversed—the PCE of these devices lags behind, with maximum values rarely approaching 23% ( _8_ , _9_ ). For a detailed overview over the recent progress in inverted architecture perovskite solar cells, the readers are referred to several excellent reviews on the topic ( _10_ , _11_ ). The generally lower performance of inverted architecture perovskite solar cells is mainly associated with a reduced current extraction and nonradiative recombination losses that limit the device photovoltage and fill factor (FF) ( _12_ , _13_ ). The development of strategies to overcome these limitations has been subject to intense research, including interface and bulk passivation of traps, such as crystallographic defects, point defects, or higher-dimensional defects (at grain boundaries) ( _14_ – _22_ ). Predominantly, these approaches led to an improvement in device performance due to increased open-circuit voltage ( _V_ OC), with FFs remaining in the range of 75 to 80%. This highlights the need to develop new methods that would simultaneously improve the _V_ OC and the FF of inverted architecture devices. Here, we demonstrate an innovative strategy for the dual modification of both the HTL/perovskite and perovskite/ ETL interfaces by introducing a series of large organic cations (Fig. 1A): 2-phenylethylammonium iodide (PEAI), 4-chlorophenylethylammonium iodide (Cl-PEAI), and 4-fluorophenylethylammonium iodide (F-PEAI) in both these interfaces. 

#### **RESULTS AND DISCUSSION** 

### **Dual interfacial modification approach** 

In developing the approach for the dual optimization of the perovskite active layer interfaces, we focused on integrating the modification into deposition steps that are already present in the device fabrication of reference devices. In the case of the HTL/perovskite interface, the highly hydrophobic nature of poly[bis(4-phenyl) (2,4,6-trimethylphenyl) amine] (PTAA) ( _27_ , _28_ ) HTL makes it necessary to perform a prewashing step before the deposition of the perovskite precursor solution in which the solvent _N_ , _N′_ -dimethylformamide (DMF) is spin-coated atop the PTAA layer ( _29_ ). This has been shown to improve the wettability of the perovskite precursor solution on PTAA, allowing for the formation of the perovskite active layer. To modify this interface, we introduce the various PEAI cations (Fig. 1A) into the DMF solution used for the prewash step at a 20 mM concentration. Following the prewash step that either contains (HTL-modified) or does not contain (reference) the PEAI cation, the perovskite solution is deposited as previously reported using the solvent engineering approach ( _30_ ). To trigger the crystallization of the perovskite layer, an antisolvent is dispensed onto the 

> 1Department of Chemistry and INSTM, University of Pavia, Via T. Taramelli 14, 27100 Pavia, Italy.<sup>2</sup> Dresden Integrated Center for Applied Physics and Photonic Materials (IAPP) and Center for Advancing Electronics Dresden (cfaed), Technische Universität Dresden, 01062 Dresden, Germany. 

> *Corresponding author. Email: giulia.grancini@unipv.it (G.G.); yana.vaynzof@ tu-dresden.de (Y.V.) 

> †Present address: Cavendish Laboratory, Department of Physics, University of Cambridge, J.J. Thomson Avenue, Cambridge, CB3 0HE, UK. 

**1 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 1. Chemical structure of PEAI cations and schematics of the fabrication procedure and device architecture used in this work.** ( **A** ) Chemical structure of PEAI, Cl-PEAI, and F-PEAI. ( **B** ) Schematic presentation of the fabrication procedure of the perovskite active layer. ( **C** ) Solar cell device structures with the different combinations of passivated interfaces. 

perovskite solution shortly before the end of the spin-coating step. For the modification of the top surface (ETL-modified), we introduce the PEAI cations into the antisolvent at a low concentration of 0.5 mM and complete the layer fabrication by thermal annealing. These steps are schematically summarized in Fig. 1B. Considering that each of the modifications can be introduced on its own, we used this approach to fabricate four types of devices (Fig. 1C): reference, HTL-modified, ETL-modified, and dual HTL + ETL– modified, which enable us to study the effect of each interface separately. 

### **HTL/perovskite interface modification by PEAI cations** 

The introduction of the PEAI cations into the DMF wash step leads to an improvement in the photovoltaic performance, which can be seen in Fig. 2 (A to D). While no change in the _V_ OC can be observed, a small increase in the _J_ SC is observed and a significant increase in FF. Together, these changes lead to an overall increase in the performance and a narrower distribution of the PCE. To investigate the 

origin of this increase in FF, we characterized the microstructure of the perovskite layers by scanning electron microscopy (SEM). Topview SEM images acquired on reference perovskite layers (deposited on DMF-washed PTAA) exhibit a typical microstructure for triple cation perovskites, which consists of perovskite grains in the range of several hundreds of nanometers and small amount of excess lead iodide, which appears brighter in the SEM images (Fig. 2E). Nanosized pinholes (marked in circles) are also visible between some of the grains. Cross-sectional SEM reveals that small voids are also formed at the interface between the perovskite layer and the DMFwashed PTAA. On the other hand, samples that include an PEAI cation in the DMF wash step (Fig. 2, F to H) compact layers with no observable pinholes. This is also supported by the cross-sectional SEM images that show a continuous interface between the PTAA and the perovskite layers for the HTL-modified samples. Such a continuous and more intimate interface is expected to improve the efficiency of interfacial charge extraction and increase the shunt resistance of the photovoltaic devices. A similar effect has been 

**2 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 2. Photovoltaic performance, microstructure, and interfacial composition of the HTL-modified devices.** ( **A** ) _V_ OC, ( **B** ) _J_ SC, ( **C** ) FF, and ( **D** ) PCE of HTL-modified photovoltaic devices. Top-view and cross-sectional SEM of perovskite films deposited on ( **E** ) reference, ( **F** ) PEAI-modified, ( **G** ) Cl-PEAI–modified, and ( **H** ) F-PEAI–modified PTAA layers. Scale bars in top-view and cross-sectional images are 400 nm. C 1s, F 1s, Cl 2p, N 1s, and I 3d spectra measured on ( **I** ) reference, ( **J** ) PEAI-modified, ( **K** ) Cl-PEAI– modified, and ( **L** ) F-PEAI–modified PTAA layers. AU, arbitrary units. 

**3 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

previously observed in standard architecture devices, where the introduction of a self-assembled monolayer at the perovskite/ZnO interface led to a much-improved microstructure and an enhanced charge extraction ( _31_ ). Recently, it has also been shown that reducing the voids formed at the buried interfaces of blade-coated perovskites also improves the photovoltaic performance of perovskite modules ( _32_ ). Thus, our observation of a small increase in the extracted current density and the significantly enhanced FF of the PEAI cation HTL-modified photovoltaic devices is a result of the improved microstructure of perovskite layers formed on the PEAI cation–treated PTAA. This optimized interface to the PTAA HTL increases the shunt resistance of the solar cells (fig. S1), leading to an enhanced FF. 

The improvements in the microstructure suggest that the inclusion of the PEAI cations in the DMF wash step leads to a modification of the PTAA surface. This is confirmed by x-ray photoemission spectroscopy (XPS) measurements performed on PTAA and modified PTAA (Fig. 2, I to L). All of the samples show the characteristic C 1s and N 1s peaks associated with the PTAA polymer, the latter appearing at a binding energy of 399.5 eV, as expected from a triarylamine unit ( _33_ ). The presence of the PEAI cation on the PTAA after the DMF wash step is confirmed by the appearance of an additional N 1s peak at 401.8 eV, a I 3d doublet, and in the case of Cl-PEAI and F-PEAI, also the Cl 2p and F 1s signals. The atomic concentrations are summarized in table S1. This corroborates that a certain amount of the PEAI cations is left on top of the PTAA layer after the PEAI cation/DMF washing step. The presence of such organic salts—which are known to be polar—on top of the normally hydrophobic PTAA layer leads to an increase in its surface energy and consequently, a better wetting by the perovskite solution. This can be directly observed during the deposition procedure: The perovskite solution wets better the PEAI cation/DMF-washed PTAA than the pure DMF-washed PTAA (fig. S2). The improved wetting leads to an improved microstructure of the perovskite layer and the elimination of nanovoids at the perovskite/HTL interface. We note that the presence of the PEAI cations at the PTAA/perovskite interface does not change the energetic alignment at this interface, as is confirmed by ultraviolet (UV) photoemission spectroscopy (UPS) measurements (fig. S3). 

The fact that the perovskite layer is deposited from a solution of DMF and dimethyl sulfoxide (DMSO) mixture—which can dissolve the PEAI cations—raises the question of whether any cations are left at that interface after the deposition of the perovskite layer. To simulate this scenario, but still have excess to probe the PTAA surface via XPS, we rinsed the halogenated PEAI-modified PTAA layers with a solvent mixture of DMF:DMSO (4:1) without the perovskite precursors. As can be seen in fig. S4, a small I 3d and Cl 2p/F 1s signal is observed in the rinsed samples, which demonstrates that a small fraction of PEAI cations remains on the surface and is not washed away. We note that the second, high binding energy species of iodine is associated with a small amount of elemental iodine at the surface of the sample. To estimate the fraction of remaining PEAI cations, we compare the atomic % of the marker F and Cl elements in the rinsed samples as compared to the data collected on the samples before the rinsing (table S1). We find that the atomic % is reduced from approximately 2 to 0.2% suggesting that only 10% of the PEAI cations remain on the PTAA surface after the rinsing with DMF:DMSO. We note that this experiment differs slightly from the case in which a perovskite layer is deposited atop the modified 

PTAA since, in that case, the perovskite precursors are available to react with the PEAI cations and potentially a slightly larger fraction of these cations will remain at that buried interface, so our estimate represents a lower boundary to the amount of PEAI cations at that interface. However, we highlight that the role of PEAI cations at the bottom interface is related to their impact on the wettability of the PTAA layer, which is greatly improved due to their polar nature. The improved wettability prevents the formation of nanovoids and results in a more uniform and homogeneous interface between the perovskite and the PTAA layer. Even if most of the cations are dissolved in DMF and washed away during the spin-coating, their function was already achieved by improving the perovskite film formation process. 

### **Perovskite/ETL interface modification by PEAI cations** 

To examine the effect of introducing the PEAI cations into the antisolvent step, we fabricated devices in which the HTL was left unmodified. Figure 3 (A to D) displays the photovoltaic performance parameters of the devices that clearly demonstrate that the modification leads to a significant increase in _V_ OC and FF. Such an improvement is typically associated with a passivation of the three-dimensional (3D) perovskite interface by a two-dimensional (2D) perovskite formed upon the introduction of large organic spacer cations ( _34_ – _36_ ). To investigate whether a separate 2D perovskite layer is formed, we performed x-ray diffraction (XRD) experiments on the reference and PEAI cation–modified perovskite layers (Fig. 3E). Indexing the diffraction reflections (fig. S5) reveals that only contributions from the 3D perovskites are observed. Since we observe no diffraction reflections that are associated with a 2D perovskite, it suggests that either no 2D perovskite layers are formed or it is below the detection limit of XRD. Similarly, no evidence of 2D perovskite is observed in UV-visible absorption measurements (fig. S6). Surface and crosssectional SEM images (fig. S7) also do not display any evidence supporting the formation of a surface 2D perovskite layer. Moreover, should a 2D perovskite layer were to form at the perovskite/ ETL interface, its low electron affinity would hinder the electron extraction into the [6,6]-phenyl-C60-butyric acid methyl ester (PCBM) ETL; however, no such effect is observed since the _J_ SC remains largely unchanged (Fig. 3B). These results, together with the fact that only a very small amount of PEAI cations is introduced during the antisolvent step, suggest that it is insufficient to form a separate 2D perovskite layer. 

We note that the concentration of PEAI cations in the antisolvent step can be easily controlled. In fig. S8, we show the performance of photovoltaic devices fabricated with varying amounts of F-PEAI (0.01, 0.25, 0.5, and 1 mg/ml). We find that the concentration (0.5 mg/ml) resulted in the optimal performance, which is why we selected to use it throughout the study. Increasing the concentration to 1 mg/ml led to a decreased performance, with a significant drop in both the _J_ SC and FF. We believe that at this concentration, a thin layer of 2D could form atop the 3D perovskite layer, which would lead to a reduced electron extraction due to the high bandgap of the 2D perovskite layer. 

A possible reason for the increase in _V_ OC can be a change in the energetic alignment at the perovskite/PCBM interface by the presence of PEAI cations ( _37_ ). UPS measurements show, however, that no changes in the energetic levels of PEAI-modified perovskite layers occur (fig. S9). These results and the absence of a 2D perovskite layer suggest that the increase in _V_ OC is associated with a passivation of 

**4 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 3. Photovoltaic performance, crystalline structure, photoluminescence, and compositional depth profiling of perovskite layers made by PEAI cations containing antisolvent.** ( **A** ) _V_ OC, ( **B** ) _J_ SC, ( **C** ) FF, and ( **D** ) PCE of photovoltaic devices where the perovskite was deposited by antisolvent containing PEAI, Cl-PEAI, and F-PEAI. ( **E** ) X-ray diffractograms and ( **F** ) Photoluminescence (PL) spectra measured on reference perovskite films and perovskite films deposited by antisolvent containing PEAI, Cl-PEAI, and F-PEAI. ( **G** ) Cl 2p and ( **H** ) F 1s spectra collected upon etching the perovskite layers for up to 30 s using an argon cluster ion source. 

the interface to the ETL by the PEAI cations ( _14_ ). Photoluminescence (PL) measurements confirm that the PL quantum efficiency (PLQE) of the perovskite films is significantly enhanced in films that were modified by including the PEAI cations in the antisolvent (Fig. 3F). The PLQE of the reference film is 7%, while that of the modified films is more than doubled at 14 to 16% (fig. S10). This increase in PLQE suggests that the modified perovskite films exhibit suppressed nonradiative losses, leading to an increase in their _V_ OC. 

The incorporation of the PEAI cations via the antisolvent quenching step raises an important question regarding their distribution in the perovskite layer. XPS measurements performed on the reference and modified perovskite films confirmed that the PEAI cations are present in the modified perovskite layers (table S2). To investigate whether the PEAI cations are located exclusively at the surface of the films or also in their bulk, we monitored the amounts of Cl and F in the Cl-PEAI– and F-PEAI–containing samples via XPS depth profiling (Fig. 3, G and H). It can be seen that already after 20 to 30 s of etching using an argon cluster ion beam, the Cl 2p and F 1s signals are diminished. Considering the slow etching rate by the argon clusters (1.08 nm/min), a 30-s etching duration would remove less than 1 nm from the surface, thus confirming that the PEAI cations are exclusively located at the surface of the perovskite layers and there passivate the perovskite surface defects at the interface to the ETL. 

### **Combined interfacial modification of both interfaces** 

Having examined the effects on each interface separately, it is important to explore whether both modifications can be combined in a single device. To test this, dual modified perovskite solar cells were fabricated and characterized (fig. S11). We observe that dual modified devices combine the improvements observed at each interface, resulting in a number of devices with PCE above 22% and 

a maximum value of 23%. Moreover, for such a dual interfacial modification to find broad use in inverted architecture solar cells, its efficacy needs to be examined in combination with a modification of the bulk of the perovskite layer ( _38_ , _39_ ). For example, recent reports suggest that the introduction of ionic liquids into the perovskite active layer can significantly increase their stability ( _40_ – _42_ ). To explore this, we fabricated photovoltaic devices that combine both interfacial optimizations shown above along with the introduction of an ionic liquid (piperidinium salt [BMP]<sup>+</sup> [BF4]<sup>−</sup> ) into the perovskite active layer. Figure 4 (A to D) displays the photovoltaic parameters of the devices. In addition, in this case, we observe that both interfacial modifications can be successfully combined to increase simultaneously the _V_ OC, _J_ SC, and FF of the devices. The _V_ OC of the F-PEAI and Cl-PEAI devices was particularly high, reaching a maximum of 1.184 V. Similarly, the FF of these devices was also higher, reaching a maximum of 85%. Together, these improvements have led to high PCE reaching a maximum of 23.7% for the F-PEAI– modified device (Fig. 4E). The photovoltaic performance of the champion devices of each type is summarized in Table 1. 

Devices fabricated using F-PEAI cations consistently outperformed those made using the other derivatives. We believe that this is associated with the fact that a larger quantity of F-PEAI remains at both the HTL and ETL interface as evidenced, for example, by the higher atomic % of F at both these interfaces as compared to Cl. We propose that this is associated with differences in the solubility of the PEAI cations. We observe that F-PEAI cations are less soluble in the antisolvent (fig. S12), thus they will precipitate of solution earlier during the drying process of the antisolvent, thus resulting in a larger overall amount remaining on the surface. 

We note that the biggest contribution to the increased performance comes from the increase in _V_ OC. This is also evident from PLQE and electroluminescence QE (ELQE) measurements performed on 

**5 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 



**Fig. 4. Photovoltaic performance, photo- and electroluminescence, and stability of dual modified ionic liquid containing solar cells.** ( **A** ) _V_ OC, ( **B** ) _J_ SC, ( **C** ) FF, and ( **D** ) PCE of photovoltaic devices in which both interfaces were modified by PEAI, Cl-PEAI, and F-PEAI. ( **E** ) J-V characteristics of champion reference and F-PEAI–modified device. ( **F** ) PL and ( **G** ) electroluminescence measured on reference and dual modified solar cells. ( **H** ) Evolution of the PCE of the reference and dual modified solar cells over 2100 min under continuous illumination in N2. 

representative solar cells (Fig. 4, F and G). The PLQE of reference devices is very low at 0.14%. On the other hand, F-PEAI–modified devices reach a value of ~1%. Similarly, the ELQE of the devices is increased by a factor of ~4 at current injection equivalent to _J_ SC, confirming a significant decrease in nonradiative losses in the dual modified devices (see fig. S13 for _J-V-L_ measurements). The minor increase in _J_ SC is consistent with an improved charge extraction due to the more homogeneous, void-free perovskite/PTAA interface. This is also supported by our observation that the dependence of _V_ OC and _J_ SC on light intensity is not affected by the dual interfacial modification, as both the reference and the modified device (fig. S14, A and B) display the same slope, thus suggesting that the bulk recombination in both cases is very similar. However, examining the photocurrent decay (fig. S14C) shows that it is faster in the case of the modified device, suggesting an improved charge extraction. 

The integration of ionic liquids into the active layer leads to an excellent stability of the dual passivated devices. For example, Fig. 4H displays the evolution of the PCE of both the reference and PEAI cation dual modified devices under continuous illumination in N2. It can be seen that the reference device is very stable, maintaining 90% of its initial performance after 2000 min of continuous illumination. The dual passivated devices, however, are even more stable, maintaining their original performance for the entire duration of the experiment. Examining the evolution of all the photovoltaic parameters (fig. S15) reveals that the loss in the performance of the reference device originates from a loss in _J_ SC, possibly as a result of degradation at the perovskite/HTL interface mediated by the presence of nanovoids at that interface ( _30_ ). No deterioration in any of the photovoltaic parameters is observed for any of the dual modified devices. The observation that the dual interfacial modification approach developed here is fully compatible with the integration 

of ionic liquids into the perovskite active layer is highly promising for the application of this methodology for further development of efficient and stable perovskite solar cells in an inverted architecture. 

It is important to explore the applicability of the dual modification approach for the fabrication of other types of inverted architecture solar cells. The increasing recent interest in methylammonium (MA)–free perovskite compositions ( _9_ , _43_ , _44_ ) motivated us to examine whether the performance of Cs0.1FA0.9PbI2.9Br0.1 inverted architecture solar cells can also be enhanced by dual modification with PEAI cations. Figure S16 displays the photovoltaic performance of the devices, which, similar to the results on triple cation perovskite solar cells, exhibit a significant improvement in all of their photovoltaic parameters. These results confirm that the approach can be easily translated to the fabrication of inverted architecture solar cells based on other perovskite compositions. 

It is of potential interest to investigate whether the dual modification approach can be applied also to standard architecture photovoltaic devices. To preliminarily examine this, we fabricated devices with the architecture glass/indium tin oxide (ITO)/SnO2/perovskite/ SpiroOMeTAD/Au and performed the same interfacial modification procedure as described above with the PEAI cation. The photovoltaic results show that, while not fully optimized, the dual modified device performs significantly better than the reference ones (fig. S17), particularly due to an enhancement in their _V_ OC and FF. This suggests that our approach can be applicable also to standard architecture solar cells. 

The observation that the dual modification approach can significantly increase the FF of the devices can be particularly useful in the case of large-area solar cells, which are known to suffer from low FFs ( _45_ ). To investigate this, we fabricated devices with an area of 

**6 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

**Table 1.** **_V_ OC,** **_J_ SC, FF, and PCE of highest performing photovoltaic devices in which both interfaces were modified by PEAI, F-PEAI, and Cl-PEAI in comparison to reference devices.** Photovoltaic parameters for both reverse and forward directions scans are provided. 

|||**Reve**|**rse**|||**Forw**|**ard**||
|---|---|---|---|---|---|---|---|---|
||**_V_OC (V)**|**_J_SC (mA/cm**<sup>**2**</sup>**)**|**FF (%)**|**PCE (%)**|**_V_OC (V)**|**_J_SC (mA/cm**<sup>**2**</sup>**)**|**FF (%)**|**PCE (%)**|
|**Ref**|1.109|23.33|83.4|21.58|1.109|23.33|80.9|20.92|
|**PEAI**|1.148|23.65|81.2|22.04|1.155|23.65|76.9|21.00|
|**Cl-PEAI**|1.146|23.68|85.0|23.07|1.141|23.68|83.8|22.64|
|**F-PEAI**|1.162|24.13|84.6|23.72|1.155|24.13|83.7|23.32|



70 mm<sup>2</sup> , significantly larger than the small-area devices shown above (4.5 mm<sup>2</sup> ). We find that the dual modification approach is entirely applicable to large-area devices, with significant enhancements observed in all the photovoltaic parameters as compared to the reference device (fig. S18 and table S3). We observe a major increase in the FF of the devices, suggesting that our approach can be used also for the fabrication of large-area solar cells. 

In summary, we present a dual interfacial modification approach by integrating large organic cations at both the electron and HTL interfaces. We find that modification of the bottom interface leads to an improved wettability, which eliminates the formation of nanovoids at the interface with the HTL. The modification of the top perovskite surface leads to its efficient passivation and a reduction in nonradiative recombination losses. These two different mechanisms for improved photovoltaic performance can be combined to achieve a simultaneous improvement in all the photovoltaic parameters. Moreover, the dual modification approach can be easily combined with the incorporation of ionic liquids into the perovskite active layer, thus leading to both efficient and stable devices, reaching a maximum power conversion efficiency of 23.7%. 

#### **MATERIALS AND METHODS** 

Unless otherwise stated, all materials were purchased from SigmaAldrich or Alfa Aesar and used as received. Perovskite films and devices were fabricated using PbI2 and PbBr2 (99.99% purity) purchased from TCI, organic halide salts were purchased from GreatCell Solar, and cesium iodide (99.99% purity) was purchased from Alfa Aesar. The poly(triaryl amine) (PTAA) was purchased from Sigma-Aldrich. The PC61BM was purchased from Solenne. The bathocuproine (BCP; sublimed grade, 99.99% purity) was purchased from Sigma-Aldrich. All the anhydrous solvents were purchased from Acros Organics. 

### **Perovskite film preparation and device fabrication** 

Prepatterned ITO/glass substrates were sequentially cleaned with acetone and 2-propanol (IPA) by ultrasonication for 15 min in each solvent. The ITO/glass substrates were then dried with N2 and treated with oxygen plasma at 100 mW for 10 min. The HTL and the perovskite films were fabricated in a drybox (relative humidity (RH) <1%), while the ETL and the contacts were deposited inside a glovebox filled with inert atmosphere N2. For reference devices, an HTL of ∼10nm thickness made of PTAA with a concentration of 1.5 mg ml<sup>−1</sup> dissolved in toluene was spin-coated at a speed of 2000 rpm for 40 s and then annealed at 100°C for 10 min. After the annealing step, the samples were washed by DMF by spin-coating it on the prepared PTAA films at 4000 rpm for 30 s. The perovskite precursor solution 

(1.2 M) contained mixed cations (Pb, Cs, FA, and MA) and halides (I and Br) dissolved in a solvent mixture (DMF/DMSO = 4/1) according to a formula of Cs0.05(FA5/6MA1/6)0.95Pb(I0.85Br0.15)3 with an excess of PbI2 of 1%. For devices containing an ionic liquid, a piperidinium salt [BMP]<sup>+</sup> [BF4]<sup>−</sup> was dissolved in the perovskite solution at a molar ratio of 0.25 mole percent. The perovskite layer was deposited via a two-step spin-coating procedure with 1000 rpm for 12 s and 5000 rpm for 27 s. A mixture of antisolvents [chlorobenzene (CB)/IPA = 9/1, 150 l] was dripped on the spinning substrate during the 21 s of the second spin-coating step. Subsequently, the samples were annealed at 100°C for 30 min. The ETLs were dynamically deposited from a PC61BM solution (20 mg/ml in CB) and spin-coated onto the perovskite layer at the speed of 2000 rpm for 30 s (with a ramping speed of 1000 rpm/s) and annealed for 10 min at 100°C. Next, thin layers of BCP (0.5 mg/ml in IPA) were spin-coated at 4000 rpm for 30 s (with a ramping rate of 1000 rpm/s) as hole blocking layers. The small-area devices with an area of 4.5 mm<sup>2</sup> were completed by thermally evaporating of Ag (80 nm). For large-area devices, Ag electrodes with an area of 70 mm<sup>2</sup> were thermally evaporated. The devices with modified interfaces were prepared by dissolving a small amount of the PEAI-cations in DMF (20 mM) used for washing the PTAA and in the mixture CB/ IPA (0.5 mM) used in the antisolvent step. For the fabrication of MAfree perovskite solar cells, a 1.1 M Cs0.1FA0.9PbI2.9Br0.1 perovskite solution was prepared by dissolving powders of CsI, FAI, PbI2, and PbBr2 in the molar ratio of 2:18:19:1 in 4:1 (v/v) DMF/DMSO. All other device fabrication steps were unchanged. 

Standard architecture devices were fabricated using the glass/ ITO/SnO2/perovskite/Spiro-OMeTAD/Au architecture. SnO2 nanoparticles (15% in a H2O colloidal dispersion, Alfa Aesar) were diluted in deionized water with the volume ratio of 1:2. The prepared SnO2 solution was spin-coated on clean ITO substrates at 3000 rpm for 30 s. After annealing the samples at 180°C for 30 min in ambient air, the substrates were treated by UV ozone for 15 min and transferred into a drybox [<1% relative humidity (RH)] for further use. The perovskite layer was deposited as described above. Spiro-OMeTAD (99.8%; Borun New Material Technology Co. Ltd.) was dissolved in CB (80 mg/ml) with 28.8 l of 4-tert-butylpyridine and 17.5 l of Li-TFSI solution (520 mg/ml in acetonitrile) and spin-coated on top of the perovskite layer. Last, the devices were completed by thermally evaporating Au electrodes (80 nm). 

### **Photovoltaic device characterization** 

Current density voltage measurements were performed in ambient conditions under simulated AM 1.5 light with an intensity of 100 mW cm<sup>−2</sup> (Abet Sun 3000 Class AAA Solar Simulator). The intensity was calibrated using a Si reference cell (NIST traceable, 

**7 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

VLSI) and corrected by measuring the spectral mismatch between the solar spectrum, reference cell, and the spectral response of the photovoltaic device (fig. S19). The mismatch factor was approximately 1.1. Cells were scanned using a Keithley 2450 source measure unit from 1.2 to 0 V and back, with a step size of 0.025 V and a dwell time of 0.1 s, after light soaking for 2 s at 1.2 V. The pixel area was 3 mm by 1.5 mm. Intensity dependence studies were performed by using neutral density filters. For transient photocurrent measurements, the light of an inorganic light-emitting diode (Thorlabs; TO-1 ¾,  = 465 nm) was pulsed by a function generator (Agilent/ Keysight 33510B; pulse length, 2 ms) and focused on the solar cell. The resulting photocurrent was measured with an oscilloscope (Picoscope 5443A) with a 50-ohm terminator placed across the oscilloscope input. 

### **XPS and UPS** 

Samples for XPS/UPS (glass/ITO/PTAA and glass/ITO/PTAA/ perovskite) were prepared as described above and transferred into the ultrahigh vacuum chamber of the UPS system (Thermo Fisher Scientific ESCALAB250Xi) for measurement. XPS measurements were performed using an XR6 monochromated AlK source (hv = 1486.6 eV) and a pass energy of 20 eV. Argon cluster ion beam etching experiments were performed using a MAGCIS ion gun using a cluster energy of 4000 eV. The etch rate at these conditions was determined to be 1.08 nm/min via reference etching experiments. UPS measurements were carried out using a He discharge lamp (h = 21.2 eV) and a pass energy of 2 eV. 

### **X-ray diffraction** 

XRD patterns were measured in ambient air using a Bruker Advance D8 diffractometer equipped with a 1.6-kW Cu-Anode ( = 1.54060 Å) and a LYNXEYE_XE_T detector in 1D mode in parallel beam geometry. All scans (coupled 2/, 2 = 5° to 50°, step size 0.05°) were background-corrected using the Bruker Diffrac.Eva software. 

### **Scanning electron microscopy** 

Surface morphology of the perovskite films was examined using SEM (ZEISS GeminiSEM 500) operated at low voltage (1.5 keV). Crosssectional images of the layered devices were acquired on the same setup with a 5-keV voltage for the electron beam. 

### **PL spectroscopy** 

PLQE measurements were carried out inside an integrating sphere (Labsphere) with excitation by a 405-nm continuous wave (CW) laser (Coherent). The spectra were recorded using a QE65 Pro (Ocean Optics) spectrometer. The PLQE was calculated following the methodology of de Mello _et al._ ( _46_ ). 

### **Electroluminescence measurements** 

ELQE was characterized by directly covering the devices with a calibrated Si photodiode (Thorlabs, FDS10X10). Two source meter units were used for applying voltage to the device and reading current from the photodiode, respectively, controlled by the SweepMe! software. 

### **SUPPLEMENTARY MATERIALS** 

Supplementary material for this article is available at https://science.org/doi/10.1126/ sciadv.abj7930 

### **REFERENCES AND NOTES** 

1. H. J. Snaith, Perovskites: The emergence of a new era for low-cost, high-efficiency solar cells. _J. Phys. Chem. Lett._ **4** , 3623–3630 (2013). 

2. S. D. Stranks, H. J. Snaith, Metal-halide perovskites for photovoltaic and light-emitting devices. _Nat. Nanotechnol._ **10** , 391–402 (2015). 

3. V. D’Innocenzo, G. Grancini, M. J. P. Alcocer, A. R. S. Kandada, S. D. Stranks, M. M. Lee, G. Lanzani, H. J. Snaith, A. Petrozza, Excitons versus free charges in organo-lead tri-halide perovskites. _Nat. Commun._ **5** , 3586 (2014). 

4. National Renewable Energy Laboratory, NREL_efficiencies_chart.pdf (2021). 

5. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, Organometal halide perovskites as visiblelight sensitizers for photovoltaic cells. _J. Am. Chem. Soc._ **131** , 6050–6051 (2009). 

6. M. Jeong, I. W. Choi, E. M. Go, Y. Cho, M. Kim, B. Lee, S. Jeong, Y. Jo, H. W. Choi, J. Lee, J.-H. Bae, S. K. Kwak, D. S. Kim, C. Yang, Stable perovskite solar cells with efficiency exceeding 24.8% and 0.3-V voltage loss. _Science_ **369** , 1615–1620 (2020). 

7. J. J. Yoo, G. Seo, M. R. Chua, T. G. Park, Y. Lu, F. Rotermund, Y.-K. Kim, C. S. Moon, N. J. Jeon, J.-P. Correa-Baena, V. Bulović, S. S. Shin, M. G. Bawendi, J. Seo, Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

8. F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S.-H. Jang, J. Zhang, X. Lu, D. Lei, C.-S. Lee, Z. Zhu, A. K.-Y. Jen, Regulating surface termination for efficient inverted perovskite solar cells with greater than 23% efficiency. _J. Am. Chem. Soc._ **142** , 20134–20142 (2020). 

9. S. Gharibzadeh, P. Fassl, I. M. Hossain, P. Rohrbeck, M. Frericks, M. Schmidt, T. Duong, M. R. Kahn, T. Abzieher, B. A. Nejand, F. Schackmar, O. Almora, T. Feeney, R. Singh, D. Fuchs, U. Lemmer, J. P. Hofmann, S. A. L. Weber, U. W. Paetzold, Two birds with one stone: Dual grain-boundary and interface passivation enables >22% efficient inverted methylammonium-free perovskite solar cells. _Energ. Environ. Sci._ 10.1039/D1EE01508G (2021). 

10. X. Lin, D. Cui, X. Luo, C. Zhang, Q. Han, Y. Wang, L. Han, Efficiency progress of inverted perovskite solar cells. _Energ. Environ. Sci._ **13** , 3823–3847 (2020). 

11. T. Wu, Z. Qin, Y. Wang, Y. Wu, W. Chen, S. Zhang, M. Cai, S. Dai, J. Zhang, J. Liu, Z. Zhou, X. Liu, H. Segawa, H. Tan, Q. Tang, J. Fang, Y. Li, L. Ding, Z. Ning, Y. Qi, Y. Zhang, L. Han, The main progress of perovskite solar cells in 2020–2021. _Nano Micro Lett._ **13** , 152 (2021). 

12. X. Sun, Z. Li, X. Yu, X. Wu, C. Zhong, D. Liu, D. Lei, A. K.-Y. Jen, Z. Li, Z. Zhu, Efficient inverted perovskite solar cells with low voltage loss achieved by a pyridine-based dopant-free polymer semiconductor. _Angew. Chemie Int. Ed._ **60** , 7227–7233 (2021). 

13. M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Márquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, The impact of energy alignment and interfacial recombination on the internal and external open-circuit voltage of perovskite solar cells. _Energ. Environ. Sci._ **12** , 2778–2788 (2019). 

14. X. Zheng, B. Chen, J. Dai, Y. Fang, Y. Bai, H. Weu, X. C. Zeng, J. Huang, Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. _Nat. Energy_ **2** , 17102 (2017). 

15. Q. An, F. Paulus, D. Becker-Koch, C. Cho, Q. Sun, A. Weu, S. Bitton, N. Tessler, Y. Vaynzof, Small grains as recombination hot spots in perovskite solar cells. _Matter_ **4** , 1683–1701 (2021). 

16. D. Luo, W. Yang, Z. Wang, A. Sadhanala, Q. Hu, R. Su, E. Shivanna, G. F. Trindade, J. F. Watts, Z. Xu, T. Liu, K. Chen, F. Ye, P. Wu, L. Zhao, J. Wu, Y. Tu, Y. Zhang, X. Yang, W. Zhang, R. H. Friend, Q. Gong, H. J. Snaith, R. Zhu, Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. _Science_ **360** , 1442–1446 (2018). 

17. Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, Surface passivation of perovskite film for efficient solar cells. _Nat. Photonics_ **13** , 460–466 (2019). 

18. M. Wei, K. Xiao, G. Walters, R. Lin, Y. Zhao, M. I. Saidaminov, P. Todorovic, A. Johnston, Z. Huang, H. Chen, A. Li, J. Zhu, Z. Yang, Y.-K. Wang, A. H. Proppe, S. O. Kelley, Y. Hou, O. Voznyy, H. Tan, E. H. Sargent, Combining efficiency and stability in mixed tin–lead perovskite solar cells by capping grains with an ultrathin 2D layer. _Adv. Mater._ **32** , 1907058 (2020). 

19. J. Y. Kim, J. W. Lee, H. S. Jung, H. Shin, N.-G. Park, High-efficiency perovskite solar cells. _Chem. Rev._ **120** , 7867–7918 (2020). 

20. S. Wu, Z. Li, J. Zhang, Z. Zhu, A. K.-Y. Jen, Efficient large guanidinium mixed perovskite solar cells with enhanced photovoltage and low energy losses. _Chem. Commun._ **55** , 4315–4318 (2019). 

21. L. K. Ono, S. Liu, Y. Qi, Reducing detrimental defects for high-performance metal halide perovskite solar cells. _Angew. Chemie Int. Ed._ **59** , 6676–6698 (2020). 

22. J. Wang, J. Zhang, Y. Zhou, H. Liu, Q. Xue, X. Li, C.-C. Chueh, H.-L. Yip, Z. Zhu, A. K.-Y. Jen, Highly efficient all-inorganic perovskite solar cells with suppressed non-radiative recombination by a Lewis base. _Nat. Commun._ **11** , 177 (2020). 

23. M.-H. Li, H.-H. Yeh, Y.-H. Chiang, U.-S. Jeng, C.-J. Su, H.-W. Shiu, Y.-J. Hsu, N. Kosugi, T. Ohigashi, Y.-A. Chen, P.-S. Shen, P. Chen, T.-F. Guo, Highly efficient 2D/3D hybrid perovskite solar cells via low-pressure vapor-assisted solution process. _Adv. Mater._ **30** , 1801401 (2018). 

24. L. Zhou, Z. Lin, Z. Ning, T. Li, X. Guo, J. Ma, J. Su, C. Zhang, J. Zhang, S. Liu, J. Chang, Y. Hao, Highly efficient and stable planar perovskite solar cells with modulated diffusion 

**8 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 

SCIE N C E A D V A NCES | RESEA R CH A RT ICL E 

   - passivation toward high power conversion efficiency and ultrahigh fill factor. _Solar RRL_ **3** , 1900293 (2019). 

25. Y. J. Hofstetter, I. García-Benito, F. Paulus, S. Orlandi, G. Grancini, Y. Vaynzof, Vacuuminduced degradation of 2D perovskites. _Front. Chem._ **8** , 66 (2020). 

26. W. Fu, H. Liu, X. Shi, L. Zuo, X. Li, A. K.-Y. Jen, Tailoring the functionality of organic spacer cations for efficient and stable quasi-2D perovskite solar cells. _Adv. Funct. Mater._ **29** , 1900221 (2019). 

27. Q. An, F. Paulus, Y. Vaynzof, Controlling the microstructure and porosity of perovskite films by additive engineering. _ACS Appl. Energy Mater._ **4** , 2990–2998 (2021). 

28. C. Bi, Q. Wang, Y. Shao, Y. Yuan, Z. Xiao, J. Huang, Non-wetting surface-driven high-aspect-ratio crystalline grain growth for efficient hybrid perovskite solar cells. _Nat. Commun._ **6** , 7747 (2015). 

29. Y. Li, C. Liang, G. Wang, J. Li, S. Chen, S. Yang, G. Xing, H. Pan, Two-step solvent post-treatment on PTAA for highly efficient and stable inverted perovskite solar cells. _Photonics Res._ **8** , A39–A49 (2020). 

30. A. D. Taylor, Q. Sun, K. P. Goetz, Q. An, T. Schramm, Y. J. Hofstetter, M. Litterst, F. Paulus, Y. Vaynzof, A general approach to high-efficiency perovskite solar cells by any antisolvent. _Nat. Commun._ **12** , 1878 (2021). 

31. Q. An, P. Fassl, Y. J. Hoffstetter, D. Becker-Koch, A. Bausch, P. E. Hopkinson, Y. Vaynzof, High performance planar perovskite solar cells by ZnO electron transport layer engineering. _Nano Energy_ **39** , 400–408 (2017). 

32. S. Chen, X. Dai, S. Xu, H. Jiao, L. Zhao, J. Huang, Stabilizing perovskite-substrate interfaces for high-performance perovskite modules. _Science_ **373** , 6557, 902–907 (2021). 

33. L. Wang, H. Liu, C. Liu, W. Kong, H. Chen, W. Wang, H. Zhang, X. Zhang, C. Cheng, Approaching optimal hole transport layers by an organic monomolecular strategy for efficient inverted perovskite solar cells. _J. Mater. Chem. A_ **8** , 16560–16569 (2020). 

34. A. A. Sutanto, P. Caprioglio, N. Drigo, Y. J. Hofstetter, I. Garcia-Benito, V. I. E. Queloz, D. Neher, M. Khaja Nazeeruddin, M. Stolterfoht, Y. Vaynzof, G. Grancini, 2D/3D perovskite engineering eliminates interfacial recombination losses in hybrid perovskite solar cells. _Chem_ **7** , 1903–1916 (2021). 

35. Y. Liu, S. Akin, L. Pan, R. Uchida, N. Arora, J. V. Milić, A. Hinderhofer, F. Schreiber, A. R. Uhl, S. M. Zakeeruddin, A. Hagfeldt, M. I. Dar, M. Grätzel, Ultrahydrophobic 3D/2D fluoroarene bilayer-based water-resistant perovskite solar cells with efficiencies exceeding 22%. _Sci. Adv._ **5** , eaaw2543 (2019). 

36. Y.-W. Jang, S. Lee, K. M. Yeom, K. Jeong, K. Choi, M. Choi, J. H. Noh, Intact 2D/3D halide junction perovskite solar cells via solid-phase in-plane growth. _Nat. Energy_ **6** , 63–71 (2021). 

37. P. Fassl, V. Lami, A. Bausch, Z. Wang, M. Klug, H. Snaith, Y. Vaynzof, Fractional deviations in precursor stoichiometry dictate the properties, performance and stability of perovskite photovoltaic devices. _Energ. Environ. Sci._ **11** , 3380–3391 (2018). 

38. J. Wang, G. Jin, Q. Zhen, C. He, Y. Duan, Bulk passivation and interfacial passivation for perovskite solar cells: Which one is more effective? _Adv. Mater. Interfaces_ **8** , 2002078 (2021). 

39. L. Fu, H. Li, L. Wang, R. Yin, B. Li, L. Yin, Defect passivation strategies in perovskites for an enhanced photovoltaic performance. _Energ. Environ. Sci._ **13** , 4017–4056 (2020). 

40. S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, Planar perovskite solar cells with long-term stability using ionic liquid additives. _Nature_ **571** , 245–250 (2019). 

41. Y.-H. Lin, N. Sakai, P. Da, J. Wu, H. C. Sansom, A. J. Ramadan, S. Mahesh, J. Liu, R. D. J. Oliver, J. Lim, L. Aspitarte, K. Sharma, P. K. Madhu, A. B. Morales-Vilches, P. K. Nayak, S. Bai, F. Gao, C. R. M. Grovenor, M. B. Johnston, J. G. Labram, J. R. Durrant, J. M. Ball, B. Wenger, B. Stannowski, H. J. Snaith, A piperidinium salt stabilizes efficient metal-halide perovskite solar cells. _Science_ **369** , 96–102 (2020). 

42. S. Akin, E. Akman, S. Sonmezoglu, FAPbI3-based perovskite solar cells employing hexyl-based ionic liquid with an efficiency over 20% and excellent long-term stability. _Adv. Funct. Mater._ **30** , 2002964 (2020). 

43. S. H. Turren-Cruz, A. Hagfeldt, M. Saliba, Methylammonium-free, high-performance, and stable perovskite solar cells on a planar architecture. _Science_ **362** , 449–453 (2018). 

44. Q. An, L. Vieler, K. P. Goetz, O. Telschow, Y. J. Hofstetter, R. Buschbeck, A. D. Taylor, Y. Vaynzof, Effect of antisolvent application rate on film formation and photovoltaic performance of methylammonium-free perovskite solar cells. _Adv. Energy Sustain. Res._ 2100061 (2021). 

45. S.-W. Lee, S. Bae, D. Kim, H.-S. Lee, Historical analysis of high-efficiency, large-area solar cells: Toward upscaling of perovskite solar cells. _Adv. Mater._ **32** , 2002202 (2020). 

46. J. C. de Mello, H. F. Wittmann, R. H. Friend, An improved experimental determination of external photoluminescence quantum efficiency. _Adv. Mater._ **9** , 230–232 (1997). 

##### **Acknowledgments** 

**Funding:** This project has received funding from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation program (ERC grant agreement no. 714067, ENERGYMAPS) and the Deutsche Forschungsgemeinschaft (DFG) within the framework of SPP 2196, project PERFECT PVs (project no. 424216076). G.G. acknowledges the “HY-NANO” project that has received funding from the European Research Council (ERC) Starting Grant 2018 under the European Union’s Horizon 2020 research and innovation program (grant agreement no. 802862). The authors acknowledge Greatcell Solar Materials Pty Ltd. for materials and useful discussion. Open Access Funding by the Publication Fund of the TU Dresden. **Author contributions:** Y.V. and G.G. conceived and planned the experiments and supervised the work. M.D. and Q.A. fabricated and characterized the photovoltaic devices. M.D. performed the PL and XRD measurements. M.A.-S. and Q.A. performed the SEM measurements. Y.J.H. performed the XPS and UPS measurements and analysis. C.C. performed the ELQE measurements and analysis. F.P. performed the solubility experiments and assisted with analysis and interpretation of results. Y.V. and G.G. wrote the manuscript with contributions from M.D. All authors have discussed the results and commented on the final manuscript. **Competing interests:** The authors declare that they have no competing interests. **Data and materials availability:** All data needed to evaluate the conclusions in the paper are present in the paper and/or the Supplementary Materials. 

Submitted 2 June 2021 Accepted 13 October 2021 Published 1 December 2021 10.1126/sciadv.abj7930 

**9 of 9** 

Degani _et al_ ., _Sci. Adv._ **7** , eabj7930 (2021)     1 December 2021 



## **23.7% Efficient inverted perovskite solar cells by dual interfacial modification** 

Matteo Degani, Qingzhi An, Miguel Albaladejo-Siguan, Yvonne J. Hofstetter, Changsoon Cho, Fabian Paulus, Giulia Grancini, and Yana Vaynzof 

_Sci. Adv._ **7** (49), eabj7930.  DOI: 10.1126/sciadv.abj7930 

**View the article online** https://www.science.org/doi/10.1126/sciadv.abj7930 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science Advances_ (ISSN 2375-2548) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science Advances_ is a registered trademark of AAAS. 

Copyright © 2021 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works. Distributed under a Creative Commons Attribution NonCommercial License 4.0 (CC BY-NC). 

