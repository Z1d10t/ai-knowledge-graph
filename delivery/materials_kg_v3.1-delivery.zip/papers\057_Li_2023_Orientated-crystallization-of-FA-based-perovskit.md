# Orientated crystallization of FA-based perovskite via hydrogen-bonded polymer network for efficient and stable solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 309 |
| 作者 | Mu-Bai Li, Riming Sun, Jin Chang, Jing-Jin Dong, Qiu-Shuang Tian, Hongze Wang, Zihao Li, Ping-Hui Yang et al. |
| DOI | 10.1038/s41467-023-36224-6 |
| 源文件 | 057_Li_2023_Orientated-crystallization-of-FA-based-perovskit.pdf |

---


Article 

https://doi.org/10.1038/s41467-023-36224-6 

# Orientated crystallization of FA-based perovskite via hydrogen-bonded polymer network for efficient and stable solar cells 

|Received: 15 September 2022<br>Accepted: 20 January 2023|Mubai Li<br>1,5, Riming Sun1,5, Jingxi Chang1, Jingjin Dong1, Qiushuang Tian1,<br>Hongze Wang<sup>1</sup>, Zihao Li<sup>1</sup>, Pinghui Yang<sup>1</sup>, Haokun Shi<sup>1</sup>, Chao Yang<sup>1</sup>, Zichao Wu<sup>1</sup>,<br>Renzhi Li<sup>1</sup>, Yingguo Yang<br>2, Aifei Wang1, Shitong Zhang3, Fangfang Wang<br>1<br>,|
|---|---|
||Wei Huang<br>1,4<br>& Tianshi Qin<br>1|
|Check for updates||
||Incorporating mixed ion is a frequently used strategy to stabilize black-phase<br>formamidinum lead iodide perovskite for high-efficiency solar cells. However,<br>these devices commonly suffer from photoinduced phase segregation and<br>humidity instability. Herein, wefind that the underlying reason is that the<br>mixed halide perovskites generally fail to grow into homogenous and high-<br>crystallinefilm, due to the multiple pathways of crystal nucleation originating<br>from various intermediate phases in thefilm-forming process. Therefore, we<br>design a multifunctionalfluorinated additive, which restrains the complicated<br>intermediate phases and promotes orientated crystallization ofα-phase of<br>perovskite. Furthermore, the additives in-situ polymerize during the per-<br>ovskitefilm formation and form a hydrogen-bonded network to stabilizeα-<br>phase. Remarkably, the polymerized additives endow a strongly hydrophobic<br>effect to the bare perovskitefilm against liquid water for 5 min. The unen-<br>capsulated devices achieve 24.10% efficiency and maintain >95% of the initial<br>efficiency for 1000 h under continuous sunlight soaking and for 2000 h at air<br>ambient of ~50% humid, respectively.|



Formamidinium lead iodide (FAPbI3) based perovskite solar cells (PSCs) have attracted much attention during the past decade and reached a recorded power-conversion efficiency (PCE) of 25.7%<sup>1</sup> , owing to the suitable bandgap for a single-junction solar cell<sup>2</sup> . Unfortunately, the photoactive black phase (α-FAPbI3) undergoes a notorious phase transition to the non-perovskite yellow phase (δ-FAPbI3) below a temperature of 150 °C<sup>3</sup> . Tremendous efforts have been devoted to improving the stability of α-FAPbI3. One strategy is introducing additives into the pure-FAPbI3 such as volatile salt (methylammonium chloride (MACl), methylammonium iodide (MAI))<sup>4–7</sup> , pseudo-anions 

(anion formate (HCOO<sup>-</sup> ), thiocyanate (SCN<sup>-</sup> ))<sup>8,9</sup> , and cations (methylenediammonium (MDA<sup>2+</sup> ), isopropylammonium (iPAmH<sup>+</sup> ))<sup>10,11</sup> , whereas most of those PSCs still need high fabrication temperature to 150 °C. Since the first report of the addition of MAPbBr3 to stabilize the α- FAPbI312, mixed cations and anions (MA+, Cs+, Br-, and Cl-)13 became another commonly used strategy to efficiently form black phase under low annealing temperature of 100 °C. To date, most of the efficiency records for perovskite solar cells have been achieved by mixed-ion FAbased perovskites<sup>7,14–17</sup> . However, small amounts of these ions affect the operational stability of corresponding devices. It has been 

> 1Key Laboratory of Flexible Electronics (KLOFE) & Institute of Advanced Materials (IAM), Nanjing Tech University (NanjingTech), Nanjing, Jiangsu 211816, P. R. China.<sup>2</sup> Shanghai Synchrotron Radiation Facility (SSRF), Shanghai Advanced Research Institute, Shanghai Institute of Applied Physics, Chinese Academy of Sciences, 239 Zhangheng Road, Shanghai 201204, P. R. China.<sup>3</sup> State Key Laboratory of Supramolecular Structure and Materials, Jilin University, Changchun, Jilin 130012, P. R. China.<sup>4</sup> Frontiers Science Center for Flexible Electronics, Xi’an Institute of Flexible Electronics (IFE), Xi’an Institute of Biomedical Materials and Engineering, Northwestern Polytechnical University (NPU), Xi’an, Shanxi 710072, P. R. China.<sup>5</sup> These authors contributed equally: Mubai Li, Riming Sun. e-mail: iamffwang2@njtech.edu.cn; iamwhuang@nwpu.edu.cn; iamtsqin@njtech.edu.cn 

Nature Communications |  (2023) 14:573 

1 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

demonstrated that the mixed-ion perovskites suffer from phase segregation<sup>18</sup> under continuous light illumination<sup>19</sup> . And the formation of pinholes and residual PbI2 in perovskite films caused by volatile cation components seriously affect the device performance under heat or humid conditions<sup>20</sup> . 

Herein, by using in-situ X-ray diffraction (XRD), in-situ ultravioletvisible (UV-vis) absorption spectra and in-situ grazing-incidence wideangle x-ray scattering (GIWAXS), we monitor and provide a deep insight into the intermediate phase, nucleation, and crystallization process of the perovskite films during spin-coating and annealing procedures. We find that the underlying reason for the predicament of the mixed halide perovskite is that it generally fails to grow into homogenous and high-crystalline film, due to the multiple pathways of crystal nucleation originating from various intermediate phases in the film-forming process<sup>21</sup> (Fig. 1a). Therefore, the formation of highquality and stable perovskite films with ordered crystal orientation and low defect density is essential for low nonradiative energy loss and the 

long-term stability of PSCs. To overcome these issues, we successfully designed a multifunctional fluorinated molecule 3-fluoro-4-methoxy4’,4”-bis((4-vinyl benzyl ether) methyl)) triphenylamine (FTPA) ((Fig. 1a, synthesis route and<sup>1</sup> H NMR of the molecule as shown in Supplementary Fig. 1, synthesis procedures of FTPA as shown in Supplementary Note 1)) as additive in FA0.95MA0.05Pb(I0.95Br0.05)3 perovskite (Abbreviated as FAMA). Four important design criteria for the molecule are shown in Fig. 1a, (i) Triphenylamine acts as the core of the molecule for efficient hole transport and energy level regulation in the bulk and surface of the perovskite film; (ii) Fluorine and oxygen atoms can interact with perovskite to restrain the generation of multiintermediate phase and promote the orientated crystallization of α- FAPbI3. (iii) The flexible diethyl ether groups act as a solubilizing unit to make FTPA a viscous liquid (inert picture in Supplementary Fig. 1), which facilitate continued interaction between molecule and perovskite during the spin-coating and annealing process. (iv) Vinyl groups endow FTPA with in-situ polymerizing and filling in the grain 



<!-- Start of picture text -->
a<br>FTPA Wet film w/o anti-solvent Wet film w/anti-solvent Annealed film<br>Control<br>Low orientation with δ-phase and PbI�<br>anti-solvent annealing<br>O Solubilizing Unit<br>100 ℃<br>Hole-transport Unit<br>N O MA�Pb�I�•2DMSO,δ-FAPbI�,α-FAPbI�<br>w/FTPA<br>F<br>Hydrogen-Bonding Preferred orientation of α-FAPbI� -<br>Interaction Unit<br>anti-solvent annealing<br>O<br>100 ℃<br>Polymerizable Unit FTPA•FAI•PbI� FTPA•δ-FAPbI�<br>DMF/DMSO FAI MAX(Br - ,Cl - ) [PbI�]2- [PbI�]4- FTPA δ-FAPbI� α-FAPbI� MA�Pb�I�•2DMSO<br>b c d<br>b a FAI FTPA/FAI C=N Stretch Pb  4f<br>FAI a b FAI<br>FTPA/FAI Pb⁰  4f5/2 Pb⁰  4f7/2<br>FTPA/FAI<br>O···HN<br>F···HN<br>FTPA/FAI/PbI� Pb  4f5/2 Pb  4f7/2<br>FTPA<br>FTPA/FAI/PbI�<br>C H N O F<br>10 9 8 7 6 1800 1700 1600 1500 1400 1300 145 140 135<br>δ (ppm) Wavenumber (cm -1 ) Binding energy (eV)<br>rmediatephase: MA�Pb�I�·2DMS<br>Inte O<br>Intensity (arb. units) Intensity (arb. units)<br><!-- End of picture text -->

Fig. 1 | Molecular design and interaction between FTPA and perovskite. a Molecular structure design of FTPA, and schematic diagram of the possible phase evolution of the nucleation and crystallization of FA-based mixed anion perovskites (FA0.95MA0.05Pb(I0.95Br0.05)3) during the film-forming process with (w) or without (w/o) FTPA. In the control perovskite film, the complicated intermediate phases, MA2Pb3I8·2DMSO and δ-FAPbI3, caused two competition pathways of crystalnucleation as shown in Eqs. (1) and (2), and finally resulted in a low crystal orientation with δ-phase and PbI2. In contrast, perovskite film with FTPA restrained the 

formation of the intermediate phases and formed a hydrogen-bonding polymer network in the perovskite films which induced stable and preferred orientation of α-FAPbI3. b A comparison of<sup>1</sup> H NMR spectra of FAI, FTPA/FAI, and FTPA/FAI/ PbI2. The photos are the FAI solution and FTPA/FAI mixture. Theoretical calculation show that the hydrogen bonds F⋯HN and O⋯HN formed between FTPA and FAI have a strength of −29.37 kcal mol<sup>−1</sup> . c FTIR spectra of the FAI, FTPA/FAI, and FTPA/ FAI/PbI2. d Pb 4 f XPS spectra of the perovskite films of control and with FTPA, respectively. 

Nature Communications |  (2023) 14:573 

2 

Article 

https://doi.org/10.1038/s41467-023-36224-6 





Fig. 2 | In-situ monitoring of intermediate phase, nucleation, and crystallization process of the control and FTPA based perovskite films during spincoating and annealing procedures. a In-situ tracking of X-ray diffraction of the perovskite films during three processes: wet perovskite film without (w/o) antisolvent during spin-coating, wet perovskite film with (w) anti-solvent during spincoating, and perovskite films annealed at 100 °C for various times. α and δ symbols indicated α-phase and δ-phase perovskite. b Optical microscopy images of the wet 

perovskite films without antisolvent during the spin-coating process. MA2Pb3I8·2DMSO film was prepared by perovskite of MAI/PbI2 (1:1 mol%) and δ- FAPbI3 was prepared by perovskite of FAI/PbI2 (1:1 mol%). c In-situ UV absorption spectra during the spin-coating process. d In-situ GIWAXS patterns during spincoating process. e In-situ UV absorption spectra during the initial annealing process at 100 °C. f GIWAXS patterns of perovskite films after annealing 1 h. 

boundaries of perovskite as a hydrogen-bonding network, which can efficiently stabilize α-FAPbI3 under operational conditions of PSCs. The planar PSCs based on FTPA exhibited a high PCE of 24.10% with photovoltage (VOC) of 1.182 V and fill-factor (FF) of 83.45%. Meanwhile, the unencapsulated device exhibited a prominent improvement in operation stability, maintaining the initial efficiency of >95% for 1000 h under continuous sunlight soaking and for 2000 h under air ambient of ~50% humid, respectively. It is noticeable that the perovskite with the polymer network can keep black-phase of FAPbI3 for more than 5 min after immersing the unencapsulated film into the water. 

## Results 

### Hydrogen-bonded interaction between FTPA and perovskite 

The strength of the interaction between the additives and the perovskite precursors determines the intermediate phases and thus plays a key role in managing the crystallization process<sup>13</sup> . FTPA could form hydrogen bonds with charged formamidine (FA<sup>+</sup> ), which were characterized by<sup>1</sup> H NMR (Fig. 1b). In pure deuterated DMSO solution, the resonance signal of protonated ammonium in FAI was at 8.787 ppm (Fig. 1b). With the addition of FTPA, the resonance signal of the ammonium split into two at 8.965 ppm and 8.629 ppm, respectively, 

implying that the interaction between FTPA and FA<sup>+</sup> led to different chemical environments for the two ammoniums in FA<sup>+</sup> . These results were consistent with the DFT calculations that the fluorine and oxygen atoms on FTPA were strongly hydrogen-bonded to the ammoniums in FA<sup>+</sup> . In addition, as shown in the photographs in (Fig. 1b), the transparent FAI solution turned yellow after FTPA was added, which confirmed the formation of the FTPA-FA<sup>+</sup> complex in solution. For the sample containing PbI2, the intensity of the ammonium resonance signal decreased but remained split, implying that although there was an interaction between PbI2 and the FTPA-FA<sup>+</sup> complex, the interaction between FA<sup>+</sup> and FTPA was stronger than that of FA<sup>+</sup> with PbI2 (Supplementary Fig. 2 and Supplementary Note 2). We obtained further evidence for the interaction between FTPA and the Pb ions by Fourier Transform Infrared Spectroscopy (FTIR) and X-ray photoelectron spectroscopy (XPS). In both film characterization and device discussed below, the amount of FTPA in all film samples was constant, i. e. the molar ratio of FTPA in the perovskite precursor was 5% (43.13 mg mL<sup>−1</sup> ). In FTIR spectra (Fig. 1c and Supplementary Fig. 3), the C = N stretching peak of the pure FAI shifted from 1695 cm<sup>−1</sup> to 1698 cm<sup>−1</sup> after addition of FTPA and then further shifted to 1709 cm<sup>−1</sup> after adding PbI2. As shown in Fig. 1d, XPS spectral profile showed that the main peaks at 

Nature Communications |  (2023) 14:573 

3 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

143.15 eV (Pb 4f5/2) and 138.25 (Pb 4f7/2) eV were shifted toward low binding energy regions (142.70 eV and 137.80 eV, respectively) after the introduction of FTPA in the perovskite, whereas the F 1 s peak of perovskite with FTPA showed the opposite trend (Supplementary Fig. 4). This could be attributed to the interaction between F group of FTPA and uncoordinated Pb ion. In addition, the small peaks of metallic Pb next to the main peaks in the FTPA perovskite films almost disappeared compared to the control film<sup>22</sup> . Supplementary Fig. 4 showed the I 3d XPS spectra assigned as Pb-I chemical species. The I 3d3/2 and I 3d5/2 peaks of the FTPA sample at 630.05 eV and 618.55 eV shifted to the lower binding energy region compared to the control (630.45 eV and 618.95 eV). This indicated that the Pb–I bond was weakened due to the interaction with the FTPA-FA<sup>+</sup> complex. We also noticed that the C-C=O peak (288.26 eV) in C 1 s of the control film related to oxygen/moisture was significantly suppressed after the addition of FTPA, demonstrating that FTPA could slow down the degradation of the perovskite layer<sup>7</sup> . The above results indicated the intermediate phase (FTPA-FAI-PbI2) could be formed due to the strong interactions between the FTPA units and perovskite. 

### In-situ monitoring of nucleation and crystallization of perovskite film 

The interaction between additives and perovskite affects the nucleation and crystallization process of perovskite<sup>23,24</sup> which often occurs rapidly at the stage of spin-coating and initial annealing process<sup>25</sup> . Therefore, in order to understand the transformation process of the intermediate phases into perovskite, we carried out in-situ tracking of XRD (Fig. 2a) to investigate different processes. For the control FAMA perovskites, although only small amounts of MA<sup>+</sup> were used in the perovskite precursor, complex intermediate phases, e.g., the solvate phases MA2Pb3I8·2DMSO (2θ = 6.73°, 7.38°, 9.33°) and δ-FAPbI3 (2θ = 11.9°), were formed from the DMSO/DMF solvent in the wet perovskite film without using anti-solvent. The formation of MA2Pb3I8·2DMSO was due to a strong interaction between perovskite precursor and DMSO, which was confirmed by the XRD pattern of the intermediate phase of MA2Pb3I8·2DMSO (Supplementary Fig. 5) and agreed with previous report<sup>26</sup> . After using antisolvent to extract DMF/ DMSO, most of the intermediate solvate phase transformed to α-phase of perovskite<sup>9</sup> . However, MA2Pb3I8·2DMSO and δ-FAPbI3 were still present in the film. As the anti-solvent assisted crystallization process<sup>27,28</sup> , Cl<sup>-</sup> from MACl in the perovskite precursor enter the perovskite lattice, which leads to the diffraction peak of δ-FAPbI3 shifted to high-angle region of 12.3°. The diffraction peak next to δ-FAPbI3 (12.3°) is the residual MA2Pb3I8·2DMSO diffraction peak at 11.87°, which is overlapped with δ-FAPbI3 before using anti-solvent as shown in the enlarged XRD patterns in Supplementary Fig. 5. During annealing process from 30 s to 5 min, the position of the δ-FAPbI3 peak (from 12.3° to 11.9°)and α-FAPbI3 (from14.15° to 13.9°)gradually shifts to lowangle region owing to the substitution of Cl ions by I ions<sup>5,6</sup> . Noticeably, δ-FAPbI3 was consistently observed during α-FAPbI3 crystallization, which might be due to two competition pathways of crystal-nucleation originating from the intermediate phases as shown below and the schematic diagram is shown in Fig. 1a, 



<!-- Start of picture text -->
MA2Pb3I8 � 2DMSO + 3FAI !Δ 3ðα � FAPbI3Þ + 2MAI " + 2DMSO " ð1Þ<br><!-- End of picture text -->



<!-- Start of picture text -->
δ � FAPbI3 !Δ α � FAPbI3 ð2Þ<br><!-- End of picture text -->

Therefore, it is unfeasible to control the nucleation and crystal growth of the α-FAPbI3 owing to the complex perovskite intermediates. After annealing at 100 °C for 1 h, the peak of α-phase perovskite dominated, but PbI2 (2θ = 12.8°) was observed due to the thermal decomposition of the unstable non-perovskite yellow phase. 

With the addition of FTPA (Fig. 2a), the intermediate phases of MA2Pb3I8·2DMSO and δ-FAPbI3 were obviously restrained, and the wet perovskite film without antisolvent exhibited inconspicuous crystalline phase with no discernible diffraction peaks, due to the hydrogenbonded interaction between FTPA and the perovskite precursors. As shown in<sup>1</sup> H NMR spectra of Supplementary Fig. 6 and Supplementary Note 3, FTPA could suppress the interaction between MA<sup>+</sup> (from MACl and MABr) and PbI2, thereby inhibited the formation of solvate intermediate phases from the source. The photograph of perovskite film containing FTPA was almost colorless compared to the yellow control films, which indicated that less nucleation occurred before antisolvent extraction (Supplementary Fig. 7). After using the anti-solvent, a broad diffraction peak at 11.74° was probably assigned to the intermediate phase of FTPA·δ-FAPbI3, and a small amount of α-FAPbI3 was also observed. With annealing at 100 °C, the FTPA·δ-FAPbI3 intermediate converted to the pure α-FAPbI3 in a short time. Along with increasing the annealing time, the peak of α-phase rose and the width of the halfpeak gradually narrowed. After annealing for 1 h, the perovskite film featured only a sharp peak of α-phase (Fig. 2a and Supplementary Fig. 8), which was attributed to a single crystallin pathway during perovskite formation. In addition, the in-situ polymerization of FTPA in the perovskite film is another reason for stabilizing the α-FAPbI3, which would be discussed later. To have a clearly view of the intermediate phase of the perovskite samples, the optical microscopy images of the wet perovskite films without antisolvent were measured, as shown in Fig. 2b and Supplementary Fig. 9. In the control perovskite film, the needles of MA2Pb3I8·2DMSO and blocks of δ-FAPbI3 were observed, which verified the two-competing crystalline intermediate phases discussed above. After the addition of FTPA, the wet perovskite films displayed amorphous features without obvious crystallization owing to hydrogen-bonding interaction of FTPA and the perovskite precursors. This also indicated that the liquid FTPA could continuously restrain the formation of the intermediate phases during the spincoating process. 

The effect of FTPA on perovskite film formation during spin-coating process was explored by in-situ UV-vis absorption spectra and in-situ GIWAXS. In Fig. 2c and Supplementary Fig. 10, it was found that the absorption of perovskite precursors with FTPA was significantly enhanced with the spin-coating time increasing, while the control film was obviously weakened, which probably due to the stronger internal interactions of the FTPA-perovskite complex than that of the solvent intermediate. In-situ GIWAXS patterns and the intensity profiles were shown in Fig. 2d and Supplementary Fig. 11, respectively. In the initial spin-coating stage, the nucleation signals of the wet perovskite film couldn’t be identified. After dropping antisolvent onto the control perovskite film at 30 s, the diffraction signals of MA2Pb3I8·2DMSO (q = 0.47 Å<sup>−1</sup> , 0.52 Å<sup>−1</sup> , 0.66 Å<sup>−1</sup> ), δ-FAPbI3 (q = 0.85 Å<sup>−1</sup> )), PbI2 (q = 0.88 Å<sup>−1</sup> ), and α-FAPbI3 (q = 1.01 Å<sup>−1</sup> ) were detected<sup>13</sup> . This confirmed that the phase evolution of the crystallization of FA-based mixed anion perovskites was complicated due to the numerous of possible crystalline species and the small differences in their formation energies. With addition of FTPA, the intermediate phase of MA2Pb3I8·2DMSO disappeared. Besides the FTPA·δ-phase and α-phase (weak) signals of FAPbI3, the perovskite film showed a new phase at q = 0.9523 Å<sup>−1</sup> , which might be the signal of FTPA·FAI·PbI2 complex. 

Furthermore, the formation and crystallization process of perovskite films during annealing process were monitored by in-situ UVvis absorption spectra and GIWAXS. As shown in Fig. 2e and Supplementary Fig. 12, the absorption intensity of the perovskite films started to increase from about 15 s of annealing, which indicated the formation of perovskite crystals. Moreover, the absorption wavelength range increased from 400–600 nm to 400–800 nm, which corresponded to the transition from the intermediate phase to the α-FAPbI3. The crystalline time of α-phase perovskite in the film with FTPA lasted 10 s, which was longer than that of the control film (6 s). Generally, too fast 

Nature Communications |  (2023) 14:573 

4 

Article 

https://doi.org/10.1038/s41467-023-36224-6 



<!-- Start of picture text -->
a<br>Control B-FTPA BS-FTPA<br>1μm 1μm 1μm<br>b c d<br>B-FTPA 10 -1  Control  Control<br>Perovskite  B-FTPA  B-FTPA<br> BS-FTPA 10 -2  BS-FTPA<br>10 -3 Electron-only device Hole-only device<br>Nt= 5.72×10 15 cm -3 10 -4 Nt= 3.81×10 15 cm -3<br>d=3.18 Å (200) 10 -5<br>Polymer Nt= 4.71×10 15 cm -3 10 -6 Nt= 4.63×10 15 cm -3<br>10 -7<br>10 nm Nt= 4.09×10 15 cm -3 Ohmic TFL Child Nt= 6.32×10 15 cm -3 Ohmic TFL Child<br>0.1 1 0.1 1<br>Voltage (V) Voltage (V)<br>e f g<br>Control Control -1.5 -1.54<br>B-FTPA B-FTPAFTPA -2 -2.03<br>10 -1<br>-2.5<br>-3<br>10 -2 BS-FTPABS-FTPA/Spiro- -3.5 -3.95 -3.84<br> OMeTAD -4 Ec -4.45<br>-4.5<br>E� -4.81 -4.93 -4.97<br>-5.15<br>10 -3 -5 -5.39<br>200 400 600 800 1000 0.0 0.5 1.0 1.5 2.0 15 16 17 -5.5 Ev -5.50 h + h +<br>Time (ns) Binding energy (eV)<br>Current (A)<br>Current (A)<br>   FTPA<br>Energy (eV)<br>Spiro - OMeTAD<br>Intensity (arb. units)<br>  PL Intensity (arb. units)<br>B-FTPA<br>Control<br><!-- End of picture text -->

Fig. 3 | Morphology, carrier extraction and energy level behaviors of the control, B-FTPA and BS-FTPA perovskite films. B-FTPA is the perovskite film with FTPA in the bulk, and BS-FTPA is the film further spin-coated 2 mg mL<sup>−1</sup> FTPA and annealed for in-situ polymerizing on the surface of the B-FTPA. a Top-view SEM images. b HR-TEM image clearly shows the polymerized FTPA surround the grain boundaries of perovskite. J-V curves of c the electron-only device (FTO/SnO2/perovskite/PCBM/Ag) and d the hole-only device (FTO/PEDOT PSS/perovskite/Spiro- 

OMeTAD/Au) measured by SCLC model. The J-V curves can be divided into three regions that are the Ohmic region, trap-filled limit region (TFL), and Child’s region. The electron and hole trap density (Nt) are shown in Fig. 3c, d, respectively. e Timeresolved PL spectra. f Valence-band region and photoemission cut off energy of the UPS spectra. g Energy level scheme of the devices. Conduction band minimum (EC), Valence band maximum (EV), and Fermi level (EF). 

crystallization of perovskite would lead to a high density of defect sites and severe nonradiative recombination<sup>29</sup> . The strong hydrogenbonding interaction of FTPA-perovskite slowed down the release of cations and anions of perovskite during the annealing process, resulting in an increased energy barrier for perovskite nucleation. The retarded perovskite nucleation and crystal growth are key to high crystal quality. GIWAXS measurements were carried out to probe the crystal orientation of the perovskite films without or with FTPA. As shown in Fig. 2f, GIWAXS pattern exhibited PbI2 peak at qz = 0.9 Å<sup>−1</sup> in control perovskite film, which was completely eliminated by adding FTPA. Moreover, the control film exhibited diffraction rings of the (100) plane at q = 1.0 Å<sup>−1</sup> , implying randomly oriented crystals. Remarkably, the perovskite film with FTPA showed the sharp Bragg spot of (100) plane along the out-of-plane (qz) direction, indicating well-aligned α-FAPbI3 perovskite<sup>25</sup> . As expected, FTPA effectively restrained complicated intermediate phase and retarded perovskite crystallization kinetics, which enabled oriented growth of perovskite films. 

### Morphology, carrier extraction and energy level behaviors of perovskite films 

We applied FTPA to the bulk of perovskite films (B-FTPA) and further on the B-FTPA film surface (BS-FTPA) to passivate defects, minimize bandgap penalty, and improve charge extraction and transport. FTPA with vinyl groups could be polymerized in-situ via atom transfer radical polymerization (ATRP) in the bulk or on the surface of the perovskite films during the annealing-step. The morphology of the control, B-FTPA, and BS-FTPA perovskite films were studied by scanning electron microscopy (SEM) and atomic force microscope (AFM). As shown in Fig. 3a, white PbI2 phase could be clearly observed in the control film<sup>30</sup> . The B-FTPA perovskite film exhibited the larger grains and the PbI2 phase was disappeared. The BS-FTPA perovskite film showed a completely covered surface by the polymerized FTPA, which was thin enough to discriminate the underlying grain boundaries. The grain-size distributions of these films were displayed in Supplementary Fig. 13. The control film had an average grain-size of ~550 nm, while the B-FTPA and BS-FTPA films exhibited larger size of ~820 nm and 

Nature Communications |  (2023) 14:573 

5 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

~870 nm, respectively. The surface roughness was reduced from 23.8 nm of the control film to 19.4 nm of the BS-FTPA perovskite, owing to the smoother polymer surface (Supplementary Fig. 14). Highresolution transmission electron microscopy (HR-TEM) images confirmed the in-situ polymerization of FTPA in the bulk of perovskite film. Figure 3b showed that the perovskite grains exhibited noticeable lattice fringes, while the polymerized FTPA with an amorphous morphology existed among or at the edges of the crystalline perovskite grains<sup>31,32</sup> . The lattice spacing of perovskite crystal was determined to be 3.18 Å, which corresponded to the (200) plane of the FAPbI3 crystal cubic phase. The differential scanning calorimeter (DSC) (Supplementary Fig. 15 and Supplementary Note 4) detected that the polymerization temperature of FTPA decreased from 158° to 100° by adding the free radical initiator, which was just the formation temperature of α-FAPbI3 crystals. Fourier transform infrared spectroscopy (FTIR) (Supplementary Fig. 16) also confirmed the complete polymerization of FTPA in the perovskite films, according to the vibration peaks ascribed to RCH = CH2 (915 cm<sup>−1</sup> ) that all disappeared after annealing at 100°. Therefore, during annealing, FTPA polymerized in the intergranular regions as the grains grew and the hydrogen-bonding interaction retarded perovskite crystallization, which induced orientated growth and good morphology of the perovskite film. 

In general, insulating polymers or cross-linked molecules in the perovskite film could passivate the defects but retarded carrier transport. The charge mobility and the trap-state density of electrononly (Fig. 3c) and hole-only devices (Fig. 3d) were characterized by space-charge limited current (SCLC) measurements. Compared to the control device, lower hole (or electron) trap density (Nt) obtained in B-FTPA and BS-FTPA could be credited to the passivation of defects in bulk and surface of perovskite films. The calculated electron mobilities of the control, B-FTPA, and BS-FTPA devices were comparable, being 1.98 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , 1.51 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , and 1.14 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , respectively. The corresponding hole mobility of B-FTPA perovskite (2.74 × 10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) has increased by an order of magnitude compared to that of the control one (1.01 × 10<sup>−5</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ), due to the excellent hole transport of pure FTPA (2.97 × 10<sup>−2</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) with triphenylamine as the molecular core (Supplementary Fig. 17 and Supplementary Note 5). The hole mobility of BS-FTPA perovskite further increased to 1.03 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , which contributed to the balance transport of electrons and holes in perovskite devices<sup>17,33</sup> . In addition, the enhanced hole mobility demonstrated that FTPA promoted the charge transfer between the perovskite grains. The meticulously designed FTPA acting as a connecting bridge of the grains could minimize electrical decoupling or insulation between the perovskite crystals, which could inhibit non-radiative recombination in the perovskite film<sup>31</sup> . 

To evaluate the dynamics of charge extraction, time-resolved photoluminescence (PL) (Fig. 3e) was measured and the fitted data by a biexponential equation were summarized in Supplementary Table 1. Compared to the control film with τ2 = 282.3 ns, the B-FTPA perovskite exhibited longer PL lifetime of τ2 = 325.1 ns, indicating the strongly suppressed non-radiative recombination due to the improved Schottky order of the bulk perovskite by FTPA<sup>34</sup> . Furthermore, BSFTPA perovskite film showed an average PL lifetime (τavg) of 50.1 ns, owing to the hole extraction of FTPA capping layer. By using SpiroOMeTAD as the hole transport layer on S-FTPA film, the PL τavg was further reduced to 26.9 ns. The trend of steady-state PL spectra (Supplementary Fig. 18) was consistent with the results of timeresolved PL measurement. Ultraviolet photoelectron spectroscopy (UPS) (Fig. 3f, g) showed a shifted-down Fermi level (EF) from −4.81 eV (control) to −4.93 eV (B-FTPA), indicating a higher p-doping of B-FTPA perovskite relative to the control counterpart<sup>35</sup> . The valence band maximum (EV) of B-FTPA was −5.39 eV and the high occupied molecular orbital (HOMO) of FTPA and Spiro-OMeTAD was −5.15 eV and −4.97 eV, respectively. Therefore, the addition of FTPA to the bulk and 

surface of the perovskite films led to gradient energy-level alignment, which could promote the hole transport/extraction<sup>16</sup> . 

### Photovoltaic performance and stability of PSCs 

The cross-sectional SEM images of the control and BS-FTPA PSCs were shown in Fig. 4a. The irregular crystals of the control perovskite converted to monolithic grains with indistinguishable grain boundaries after adding FTPA. We believed that FTPA can tune the nucleation and crystal growth processes of the perovskite films by restraining the complex intermediate phases to reduce the grain boundaries, which facilitates carrier transport. We further got insights into the spatial distributions of FTPA in the perovskite films via time-of-flight-secondary-ion mass spectrometry (ToF-SIMS) technique. The cross-section images (Fig. 4a), three-dimensional images (Supplementary Fig. 19) and depth profiles (Supplementary Fig. 20) of ToF-SIMS confirmed the FTPA uniformly distributions in the bulk and surface of perovskite film. Figure 4b showed current density-voltage (J-V) curves of the control B-FTPA and BS-FTPA PSCs, and the detailed photovoltaic parameters were shown in Table 1. The control cell had a maximum power conversion efficiency (PCE) of 22.48% with a JSC of 24.46 mA cm<sup>−2</sup> , a VOC of 1.143 V and a fill factor of 80.38%. The champion BS-FTPA PSC showed an excellent maximum PCE of 24.10% with a JSC of 24.43 mA cm<sup>−2</sup> , a VOC of 1.182 V and a fill factor of 83.45%. The incident photo-to-electron conversion efficiency (IPCE) measurements (Fig. 4c) showed that the integrated JSC of the control and BS-FTPA PSCs were 23.22 mA cm<sup>−2</sup> and 23.32 mA cm<sup>−2</sup> , respectively, which well matched the measured JSC under the solar simulator. Notably, the BS-FTPA PSCs showed a high VOC of 1.182 V, which was 93% of the Shockley–Queisser limit VOC (1.27 V) for the absorption threshold of 1.55 eV (Supplementary Fig. 21). The non-radiative recombination losses (ΔVOC loss) was calculated to be only 0.10 eV<sup>36,37</sup> (Supplementary Fig. 22). Moreover, the Urbach energy (Eu) of the BS-FTPA device (Fig. 4d) was 14.5 meV, which was among the lowest values in reported high-performance PSCs, suggesting very low defect density in the BS-FTPA perovskite film<sup>6,38</sup> . Electrochemical impedance spectra (EIS) in Supplementary Fig. 23 and Supplementary Table 2 showed that the BS-FTPA PSCs had a smaller charge-transfer resistance (Rct) and a larger carrier recombination resistance (Rrec) compared to the control device, stemming from the improved charge transport and suppressed non-radiative recombination<sup>39</sup> , which was the origin of the higher FF of the BSFTPA device. The PCE value of the BS-FTPA device was consistent with the stabilized power output near the maximum power point, revealing the operational the photovoltaic device was stable (Supplementary Fig. 24). Statistical analyses of the photovoltaic parameters based on 30 devices revealed good repeatability of the BS-FTPA devices with a higher average PCE of 23.75% compared to the control device (21.76%) (Fig. 4e). 

We evaluated the stability of the unencapsulated devices under illumination, relative humidity, and heat conditions according to the Organic Photovoltaic Stability (ISOS) protocols<sup>40</sup> . The B-FTPA and BSFTPA PSCs showed narrower performance distribution than the control device for six individual cells at different test time. Devices were aged in a thermostats (23 ± 2 °C, Supplementary Fig. 25) at simulated 1-sun illumination under a nitrogen atmosphere (ISOS-LC-1) (Fig. 4f). The PCE of the control device decreased to 59% of its initial PCE after aging 1000 h, while the PCE of BS-FTPA device decreased only 5% of the initial PCE. We also monitored the PCE change of the unencapsulated devices in ambient air of 25 ± 5 °C and 50 ± 10% relative humidity for 2000h (ISOS-D-1) (Fig. 4g). The PCE of the control device dropped to 95% of the initial value after aging for only 150 h, whereas the BSFTPA device remained 95% of its initial PCE after 2000 h. Generally, in n-i-p type PSCs, Li-doped Spiro-OMeTAD always bring degradation issue to the device, mainly stemming from the hygroscopic nature of Li-TFSI. Water molecules can easily penetrate the perovskite structure, which further degrades the performance of PSCs<sup>41</sup> . The excellent 

Nature Communications |  (2023) 14:573 

6 

Article 

https://doi.org/10.1038/s41467-023-36224-6 



<!-- Start of picture text -->
a<br>Control BS-FTPA 20<br>Au Au<br>Spiro-OMeTAD Spiro-OMeTAD Spiro-OMeTAD Spiro-OMeTAD<br>FTPA FTPA FTPA<br>Perovskite B-FTPA B-FTPA B-FTPA<br>SnO2 SnO2<br>500nm FTO 500nm FTO N F - PbI3- 0<br>b c 25 d<br>25 10 0<br>100<br>20 80 20 10 -1<br>15 60 15<br>10 -2<br>10 40 10<br>Control-Reverse 20 Control 10 - 3<br>5 B-FTPA-Reverse B-FTPA 5 Eu = 14.5 meV<br>BS-FTPA-Reverse<br>0 BS-FTPA<br>0 0 10 -4<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 800 900 1.4 1.5 1.6 1.7 1.8 1.9 2.0<br>Voltage (V) Wavelength (nm) Energy (eV)<br>e f<br>25 1.0<br>0.8<br>24<br>0.6<br>Control<br>23 0.4<br>B-FTPA<br>0.2 BS-FTPA AM 1.5G, 23±2°C, N�<br>22<br>g 0 200 400 600 800 1000<br>Time (h)<br>21 1.0<br>Control B-FTPA BS-FTPA 0.8<br>h<br>0.6<br>0.4  Control<br>47.4° 0.2  BS-FTPA B-FTPA 23±3°C, 50±10% RH<br>Control 0 500 1000 1500 2000<br>85.8° 5 min in H2O i Time (h)<br>1.0<br>B-FTPA 0.8<br>100.8° 0.6  Control<br>BS-FTPA- Control 0.4  B-FTPA<br> BS-FTPA 65±3°C, N2<br>BS-FTPA 0.2<br>0 100 200 300 400 500<br>Time (h)<br>-2Current Intensity (mA cm)<br>IPCE (%)<br>Normalized IPCE<br> -2 (mA cmIntergrated  J )SC<br>Normalized PCE<br> ��PCE%<br>Normalized PCE<br>Normalized PCE<br><!-- End of picture text -->

Fig. 4 | Photovoltaic characteristics and stability of PSCs based on control, B-FTPA and BS-FTPA. a A cross-sectional SEM images showed the device architectures: FTO/SnO2/perovskite/Spiro-OMeTAD/Au for control, FTO/SnO2/B-FPTA perovskite (with FTPA 43.13 mg mL<sup>−1</sup> in the bulk)/FTPA (2 mg mL<sup>−1</sup> )/Spiro-OMeTAD/ Au for BS-FTPA; ToF-SIMS cross-section images presented the element distribution in BS-FTPA. C12H10N<sup>-</sup> signals attributed to the diphenylamine branches of FTPA and Spiro-OMeTAD; F<sup>-</sup> signals corresponding to the Li-TFSI in Spiro-OMeTAD solution, FTPA in bulk and surface of perovskite, and FTO; the PbI3- signals corresponding to the perovskite. b J-V curves of the champion PSCs. c IPCE spectra of the devices integrated over the AM 1.5 G (100 mW cm<sup>−2</sup> ) solar spectrum. d Semilog plot of IPCE humidity stability of BS-FTPA PSCs could be attributed to the hydrophobic effect of polymerized FTPA with fluorinated group on GBs and surface of perovskite, which was confirmed by the significantly increased contact angles of water from 47.4° to 100.8° (Fig. 4h)<sup>42,43</sup> . Surprisingly, the BS-FTPA film could still maintain the black phase of FAPbI3 even after immersing in water for more than 5 min, while the control film without FTPA immediately turned yellow due to the decomposition into PbI2. This confirmed that FTPA could inhibit the penetration of H2O molecules in all directions. The detailed 

at the absorption onset for BS-FTPA based PSCs, measured using FTPS at Jsc. An Urbach energy (Eu) of 14.5 meV can be obtained from the red line, a sharp absorption edge. e Statistical device data based on 30 devices. f Device stability of unencapsulated devices under1-sun illumination at 23 ± 2 °C in a nitrogen atmosphere (ISOS-LC-1). g Device stability of unencapsulated devices held at 25 ± 5 °C and 50 ± 10% relative humidity (RH) (ISOS-D-1). h Contact angle of perovskite films, and photographs of perovskite films dipped in water, FTO/SnO2/perovskite for control and FTO/SnO2/B-FTPA/FTPA for BS-FTPA. i Device stability of unencapsulated devices under 65 ± 3 °C thermal aging (ISOS-T-1). All of the error bars in Fig. 4f, g and i represent the standard deviation for six devices. 

procedures of the water-immersing test were shown in Supplementary Movie 1. The strong stability of the unsealed perovskite film in water represented a significant progress in stabilizing α-FAPbI3 against moisture and liquid water. We have tracked the XRD patterns to estimate the morphological degradation of the control, B-FTPA and BSFTPA perovskite films under 85 °C (Supplementary Fig. 26). The control film exhibited obvious deterioration after 500 h manifested by a significant increase of the PbI2 peak, whereas the XRD pattern of the B-FTPA film showed only few of PbI2 peak, and no apparent impurity 

Nature Communications |  (2023) 14:573 

7 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

Table 1 | Device parameters of champion PSCs based on different device architecture and perovskite composition via FTPA modification 

|PSC architecture|Perovskite composition|FTPA application|VOC[V]|JSC[mA cm<sup>−2</sup>]|FF[%]|PCE[%]|
|---|---|---|---|---|---|---|
|n-i-p|FA0.95MA0.05Pb(I0.95Br0.05)3|Control<sup>a</sup>|1.143|24.46|80.38|22.48|
|||Bulk<sup>b</sup>|1.161|24.25|82.41|23.22|
|||Bulk/Surface<sup>c</sup>|1.182|24.43|83.45|24.10|
||Cs0.05FA0.85MA0.10Pb(I0.97Br0.03)3|Control<sup>a</sup>|1.157|23.95|76.78|21.27|
|||Bulk<sup>b</sup>|1.174|24.02|79.85|22.52|
|||Bulk/Surface<sup>c</sup>|1.196|24.11|80.77|23.29|
|p-i-n|FA0.95MA0.05Pb(I0.95Br0.05)3|Control<sup>d</sup>|1.031|23.01|79.06|18.75|
|||Bulk<sup>e</sup>|1.126|23.22|82.09|21.46|
||Cs0.05FA0.80MA0.15Pb(I0.85Br0.15)3|Control<sup>d</sup>|1.094|23.48|79.88|20.51|
|||Bulk<sup>e</sup>|1.138|23.74|81.54|22.03|
||Cs0.05FA0.80MA0.15Pb(I0.85Br0.15)3|Control<sup>d</sup>|1.081|23.39|78.89|19.95|
|||HTL<sup>f</sup>|1.156|23.93|81.27|22.48|



aFTO/CBD-SnO2/perovskite/Spiro-OMeTAD/Au; bFTO/CBD-SnO2/perovskite-FTPA/Spiro-OMeTAD/Au; cFTO/CBD-SnO2/perovskite-FTPA/FTPA/Spiro-OMeTAD/Au; dITO/PTAA/perovskite/PC61BM/C60/BCP/Ag; eITO/PTAA/perovskite-FTPA/PC61BM/C60/BCP/Ag; fITO/FTPA/perovskite/PC61BM/C60/BCP/Ag. 

peaks were observed in the BS-FTPA film. In addition, the long-term stability of the unencapsulated PSCs at temperature of 65 °C under a nitrogen atmosphere (ISOS-T-1, Fig. 4i) were also examined. After 500 h aging, B-FTPA ad BS-FTPA device stabilized over 80% and 85% of initial efficiency, while the control device only retains 58% of its initial efficiency merely after 500 h. The better thermal stability of FTPAbased PSCs might be attributed to the inhibition of ion migration by the polymer network formed in perovskite film<sup>44</sup> . 

### The generality of FTPA strategy 

Through investigating the effects of FTPA on perovskite crystallization, energy level modulation, and carrier transport balance, we believe that FTPA should be generally applicable to other cation and halide compositions and different PSC architectures. The corresponding photovoltaic data were summarized in Table 1. We applied FTPA as the perovskite additive in the triplication mixed-halide perovskite system, Cs0.05FA0.85MA0.10Pb(I0.97Br0.03)3 (Abbreviated as CsFAMA), and investigated the effect of FTPA on the crystallization kinetics of Cs-containing perovskite system by in-situ XRD, optical microscopy images, SEM images and in-situ UV-vis absorption spectra as shown in Supplementary Fig. 27. In-situ XRD showed that the intermediate phases were also mainly derived from MA2Pb3I8·2DMSO and δ-FAPbI3 as the MAFA perovskite system, and the Cs-related intermediate phase δ-CsPbI3 (2θ = 9.7°) was not observed<sup>45</sup> . The addition of FTPA could restrain the intermediate phase and promoted the formation of a better perovskite crystallinity. The optical microscopy images and SEM images also proved that the less intermediate phases during the perovskite formation stage facilitate larger crystal grains of the perovskite films. In-situ UV-vis absorption spectra during spincoating and annealing process of the perovskite also indicated that the strong internal interactions between the FTPA and perovskite slowed down the crystallization of perovskite, which is essential for the high crystal quality of the treated perovskite. Interestingly, the CsFAMAperovskite system (5 s) began to crystallize earlier than the FAMAperovskite system (15 s) after annealing, probably due to the addition of Cs ions promoting the formation of perovskite crystals. PSC performance based on CsFAMA-perovskite in both n-i-p and p-i-n perovskite architectures were improved compared to the reference sample (Supplementary Figs. 28–29 and Supplementary Note 6–7). In addition, benefits from high hole mobility and good energy level 

alignment with perovskite, we applied FTPA as the dopant-free hole transporting materials (HTM) to alternative the traditional PTAA in p-in PSCs<sup>46</sup> , and the device exhibited a champion PCE of 22.48% compared to the control device (19.95%) (Supplementary Fig. 30, Supplementary Note 8 and Supplementary Table 3). 

## Discussion 

Herein, we in-situ monitored and analyzed the intermediate phase, nucleation, and crystallization process of the perovskite films during spin-coating and annealing procedures. We found that the complex intermediate phases were the main reason for disordered crystallization of the mixed halide perovskites, which effected the corresponding photovoltage performance and stability of the PSCs. Based on this understanding, we developed a multifunctional fluorinated additive FTPA, which could suppress the complicated intermediate phase of perovskite and distinctly facilitated the orientated growth of α-FAPbI3. The corresponding PSCs exhibited excellent PCE up to 24.10% owing to several improvements, including balanced charge transport, low defect density, and gradient energy-level alignment. Furthermore, due to the formation of the hydrogen-bonding polymer network in the perovskite film, the stabilized α-FAPbI3 imparted the PSCs with excellent illumination, moisture, and thermal stability. We have opened a successful prospect for the rationalized screening of highly efficient molecular additives for efficient and stable FAPbI3 based PSCs. 

## Methods 

### Materials 

For synthesis of FTPA, all the reagents were purchased from Aladdin and Energy chemical (China). For perovskite fabrication, Formamidinium iodide (FAI, ≥99.5%) and Methylammonium bromide (MABr, ≥99.5%) were purchased from Hangzhou Perovs Optoelectronic Technology Corp (China). Methylammonium chloride (MACl, ≥99.5%), lead bromide (PbBr2, 99.99%), 2,2’,7,7’-tetrakis (N,N-di-pmethoxyphenylamine)−9,9’-spirobifluorene (Spiro-OMeTAD, >99.8%), lithiumbis (trifluoromethanesulfonyl) imide salt(Li-TFSI, ≥99%), FK209-Co(III)-TFSI (≥99%) were purchased from Xi’an Polymer Light Technology Corp (China). Lead iodide (PbI2, 99.99%), azodiisobutyronitrile (AIBN, ≥98%), N,N-dimethylformamide (DMF, >99.5%), dimethyl sulfoxide (DMSO, >99.0%), chlorobenzene (CB, >98.0%), ethyl 

Nature Communications |  (2023) 14:573 

8 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

acetate (EA, >99.5%), isopropanol (IPA, >99.5%), acetonitrile (ACN, >99.5%), urea (>99.0%), and 4-tert-butyl-pyridine (TBP, >96.0%) were purchased from TCI Shanghai (China). Stannous chloride SnCl2·2H2O (99.99%), thioglycolic acid (TGA, 98%), and urea (≥99.5%) were purchased from Sigma‐Aldrich (USA). All materials were used as received without further modifications. 

### Device fabrication 

FTO glass was cleaned ultrasonically for 20 min with detergent, deionized (DI) water and ethanol, respectively. And then dried with dry nitrogen and treated with UVO for 15 min. The compact SnO2 film was prepared by chemical bath deposition (CBD)<sup>17</sup> . The perovskite precursor of 1.474 M FA0.95MA0.05Pb(I0.95Br0.05)3 was prepared by dissolving 240.76 mg FAI, 706.9 mg PbI2, and 33.76 mg MACl, 8.21 mg MABr, 27.05 mg PbBr2 salts in the 1 mL DMF/DMSO (8:1, v/v) mixed solvent. For the B-FTPA system, the molar ratio of FTPA (with 0.1 mol% AIBN) in the perovskite precursor was 5 % (43.13 mg mL<sup>−1</sup> ). The perovskite solution was deposited on FTO/SnO2 by two consecutive spin-coating steps of 1000 rpm for 10 s and 5000 rpm for 30 s, respectively. During the second spin-coating step, 120 μL of EA was deposited onto the film after 20 s. Afterwards, the film was annealed at 100 °C for 1 h. For BSFTPA system, 2 mg mL<sup>−1</sup> FTPA was spin-coated on the B-FTPA perovskite film by 3000 rpm for 30 s, then annealed at 100 °C for 10 min. The hole-transport material was prepared by dissolving 30 μL of TBP, 18 μL of Li-TFSI solution (520 mg in 1 mL acetonitrile), 29 μL of FK209Co(III)-TFSI solution (300 mg in 1 mL acetonitrile) and 73 mg of SpiroOMeTAD in 1 mL CB. Then spin-coated on perovskite films by 3000 rpm for 30 s. Finally, Au (80 nm) was evaporated as the electrode. Perovskite preparation and device fabrication of the generality use of FTPA described in the Supporting information Figs. 28–30, Supplementary Note 6–8 and Supplementary Table 3. 

### Material characterization 

The<sup>1</sup> H and<sup>13</sup> C-NMR spectra were conducted in CDCl3/d6-DMSO using a Bruker 400 MHz instrument. MALDI-TOF MS spectra were measured on Waters Q-Tof Premier mass spectrometry. The Differential Scanning Calorimeter (DSC) and Thermogravimetric analysis (TGA) was performed on Shimadzu DSC-60A and Shimadzu DTG-60H at a heating rate of 10 °C min<sup>−1</sup> under nitrogen atmosphere, respectively. The absorbance spectra were measured by a UV-vis spectrophotometer with an integrating sphere (PerkinElmer, Lambda 950). Theoretical calculations were carried out with a Gaussian 09 D.01 package using b3lyp/6–31 g(d, p) method.<sup>1</sup> H and<sup>13</sup> C-NMR spectra, TGA, UV and CV characterization of FTPA were showed in Supplementary Figs. 31–39 and Supplementary Table 4. 

### Film characterization 

Fourier Transform Infrared Spectroscopy (FTIR) was performed by Thermo-Fisher Nicolet is50 system. X-ray photoelectron spectroscopy (XPS) measurement was carried out on a Thermo-Fisher ESCALAB 250Xi system with a monochromatized Al Kα (for XPS mode) under a pressure of 5.0 × 10<sup>−7</sup> Pa. Optical microscopy images was carried out using a LV100ND NIKON optical microscopy. In-situ X-ray diffraction (XRD) data were obtained by using a Bruker D8 Advance diffractometer with a high temperature stage, which allows sample to be measured at controlled temperatures. Grazing-incidence wide-angle x-ray scattering (GIWAXS) measurements were performed at beamline BL14B1 of Shanghai Synchrotron Radiation Facility. For ex situ measurement, samples were prepared in the chemistry lab in SSRF with the same procedure described in the film preparation part. The incident angle was set as 0.40°. For the in situ GIWAXS characterization, the spin-coating processes were conducted in a designed nitrogen-filled box, which contains two opposite Kapton windows to permit the transmission of X-rays, and all the processing conditions were kept the 

same asthe device fabrication process.The GIWAXSdata was collected at every 0.5 s and the exposure time is 50 s. The data of GIWAXS measurements were analyzed by Fit-2D and MATLAB, and were displayed in q coordinates. In-situ absorption spectra were measured by an ISAS-HI001 system (Nanjing Ouyi Optoelectronics Technology) consists of light source, detector, a spin-coater or a hot plate as shown in in Supplementary Figs. 10 and 12. The reflectance mode was used for the in-situ absorption measurements by evaporating the Ag layer on the backside of FTO. A Hamamatsu EQ-99-FC:DF001 laser-driven broadband light sources were used for the white light source. Scanning electron microscopy (SEM) was performed on a JEOL5 JSM-7800F operated at 3 kV. The surface morphology of the perovskite film was collected by atomic force microscope (AFM) (Park XE7). Highresolution transmission electron microscopy (HR-TEM) was performed on 7610F-PLUS (JEOL, Japan). Space charge limited current (SCLC) was recorded on Keithley 2450 SMU (Keithley, USA). Timecorrelated single photon counting (TCSPC) was performed on DeltaFlex TCSPC system (Horiba, Japan), recorded at 800 nm using excitation with a 520 nm light pulse. Steady-state photoluminescence (PL) was measured via a fluorescent spectrometer, model Hitach F4600 (Hitach, Japan). with excitation at 520 nm. Ultraviolet photoelectron spectroscopy (UPS) was performed by a PHI 5000 VersaProbe III with a He I source (21.22 eV) under an applied negative bias of 9.0 V. The ToFSIMS was measured by a ToF-SIMS 5–100 instrument (ION-TOF GmbH, Germany). The depth profiling was obtained through a 2 keV Cs sputtering beam raster of 300 × 300 µm area. 

### Device characterization 

Current density-voltage (J-V) curves were tested on a Keithley 2400 source meter in a solar simulator (Class 3 A, XES-40S3, SAN-EI) after calibrating the light intensity to AM1.5 G one sun (100 mW cm<sup>−2</sup> ) in a standard silicon solar cell (QE-B1) calibrated by Newport under AM1.5 G standard light. A black metal mask was used to define the effective active area of the device to be 0.1 cm<sup>2</sup> . The incident photonto-electron conversion efficiency (IPCE) measurements were carried out by a QE-R-900AD system (Nanjing Ouyi Optoelectronics Technology). A Hamamatsu S1337-1010BQ silicon diode used for IPCE measurements was calibrated at the National Institute of Metrology, China. The device characterizations of LEDs were carried out on EQE-R80 system (Nanjing Ouyi Optoelectronics Technology). The Fouriertransform photocurrent spectroscopy (FTPS) was record by a HS-EQE system (Nanjing Ouyi Optoelectronics Technology). It utilized Fourier transform signal processing techniques to enhance and push the detection limit of photocurrent signals. Electrochemical Impedance Spectroscopy (EIS) was measured by an electrochemical workstation (ChenHua, CHI760E, China). The devices are subjected to long-term light stability tests in a nitrogen glove box under white LEDs (1000 W m<sup>−2</sup> irradiance), tested periodically by a solar simulator (Class 3 A, XES-40S3, SAN-EI). The humidity stability of the devices is tested at a temperature of 25 ± 10 °C and a relative humidity of 50 ± 10%, measured periodically by a Solar Light Simulator (Class 3 A, XES-40S3, SANEI). The optimization data, forward and reverse scans and the detailed parameters of the PSCs are shown in Supplementary Figs. 40–43 and Supplementary Tables 5–8. 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

All data generated in this study are provided in the article and Supplementary Information, and the raw data supporting this study are available from the Source Data file. Source data are provided with this paper. 

Nature Communications |  (2023) 14:573 

9 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

## References 

1. Best Research-Cell Efficiency Chart (NREL, 2022); http://www.nrel. gov/pv/cell-efficiency.html 

2. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. Energy Environ. Sci. 7, 982–988 (2014). 

3. Yi, C. et al. Entropic stabilization of mixed A-cation ABX3 metal halide perovskites for high performance perovskite solar cells. Energy Environ. Sci. 9, 656–662 (2016). 

4. Xie, F. et al. Vertical recrystallization for highly efficient and stable formamidinium-based inverted-structure perovskite solar cells. Energy Environ. Sci. 10, 1942–1949 (2017). 

5. Kim, M. et al. Methylammonium chloride induces intermediate phase stabilization for efficient perovskite solar cells. Joule 3, 2179–2192 (2019). 

6. Ye, F. et al. Roles of MACl in sequentially deposited bromine-free perovskite absorbers for efficient solar cells. Adv. Mater. 33, 2007126 (2021). 

7. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. Nat. Photon. 13, 460–466 (2019). 

8. Jeong, J. et al. Pseudo-halide anion engineering for alpha-FAPbI3 perovskite solar cells. Nature 592, 381–385 (2021). 

9. Lu, H. et al. Vapor-assisted deposition of highly efficient, stable black-phase FAPbI3 perovskite solar cells. Science 370, 74 (2020). 

10. Min, H. et al. Efficient, stable solar cells by using inherent bandgap of a-phase formamidinium lead iodide. Science 366, 749–753 (2019). 

11. Park, B.-W. et al. Stabilization of formamidinium lead triiodide α- phase with isopropylammonium chloride for perovskite solar cells. Nat. Energy 6, 419–428 (2021). 

12. Jeon, N. J. et al. Compositional engineering of perovskite materials for high-performance solar cells. Nature 517, 476–480 (2015). 

13. Bu, T. et al. Lead halide–templated crystallization of methylaminefree perovskite for efficient photovoltaic modules. Science 372, 1327–1332 (2021). 

14. Saliba, M. et al. Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 6309 (2016). 

15. Yang, W. S. et al. Iodide management informamidinium-leadhalide–based perovskite layers for efficient solar cells. Science 356, 1376–1379 (2017). 

16. Jung, E. H. et al. Efficient, stable and scalable perovskite solar cells using poly(3-hexylthiophene). Nature 567, 511–515 (2019). 

17. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593 (2021). 

18. Gautam, S. K. et al. Reversible photoinduced phase segregation and origin of long carrier lifetime in mixed‐halide perovskite films. Adv. Funct. Mater. 30, 2002622 (2020). 

19. Rehman, W. et al. Photovoltaic mixed-cation lead mixed-halide perovskites: links between crystallinity, photo-stability and electronic properties. Energy Environ. Sci. 10, 361–369 (2017). 

20. Chang, Q. et al. Ferrocene-induced perpetual recovery on all elemental defects in perovskite solar cells. Angew. Chem. Int. Ed. 60, 25567–25574 (2021). 

21. Qin, M. et al. Manipulating the mixed-perovskite crystallization pathway unveiled by in situ GIWAXS. Adv. Mater. 31, 1901284 (2019). 

22. Yun, Y. et al. A nontoxic bifunctional (anti)solvent as digestiveripening agent for high-performance perovskite solar cells. Adv. Mater. 32, 1907123 (2020). 

23. Hu, Q. et al. In situ dynamic observations of perovskite crystallisation and microstructure evolution intermediated from [PbI6]<sup>(4-)</sup> cage nanoparticles. Nat. Commun. 8, 15688 (2017). 

24. Zou, Y. et al. Manipulating crystallization dynamics through chelating molecules for bright perovskite emitters. Nat. Commun. 12, 4831 (2021). 

25. Zhu, L. et al. Unveiling the additive-assisted oriented growth of perovskite crystallite for high performance light-emitting diodes. Nat. Commun. 12, 5081 (2021). 

26. Zhang, K. et al. A prenucleation strategy for ambient fabrication of perovskite solar cells with high device performance uniformity. Nat. Commun. 11, 1006 (2020). 

27. Jeon, N. J. et al. Solvent engineering for high-performance inorganic-organic hybrid perovskite solar cells. Nat. Mater. 13, 897–903 (2014). 

28. Xiao, M. et al. A fast deposition-crystallization procedure for highly efficient lead iodide perovskite thin-film solar cells. Angew. Chem. Int. Ed. 53, 9898–9903 (2014). 

29. Hui, W. et al. Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. Science 371, 1359–1364 (2021). 

30. Luo, D. et al. Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. Science 360, 1442–1446 (2018). 

31. Li, X. et al. In-situ cross-linking strategy for efficient and operationally stable methylammoniun lead iodide solar cells. Nat. Commun. 9, 3806 (2018). 

32. Zhao, Y. et al. A Polymerization-assisted grain growth strategy for efficient and stable perovskite solar cells. Adv. Mater. 32, 1907769 (2020). 

33. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450 (2021). 

34. Son, D.-Y. et al. Self-formed grain boundary healing layer for highly efficient CH3NH3PbI3 perovskite solar cells. Nat. Energy 1, 16081 (2016). 

35. Cui, P. et al. Planar p–n homojunction perovskite solar cells with efficiency exceeding 21.3%. Nat. Energy 4, 150–159 (2019). 

36. Yang, R. et al. Oriented quasi-2D perovskites for high performance optoelectronic devices. Adv. Mater. 30, 1804771 (2018). 

37. Guo, Z., Jena, A. K., Kim, G. & Miyasaka, T. High open-circuit voltage of perovskite solar cells: a review. Energy Environ. Sci. 15, 3171–3222 (2022). 

38. Subedi, B. et al. Urbach energy and open-circuit voltage deficit for mixed anion− cation perovskite solar cells. ACS Appl. Mater. Interfaces 14, 7796–7804 (2022). 

39. Chen, Q. et al. Rapid microwave-annealing process of hybrid perovskites to eliminate miscellaneous phase for high performance photovoltaics. Adv. Sci. 7, 2000480 (2020). 

40. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49 (2020). 

41. Boyd, C. C., Cheacharoen, R., Leijtens, T. & McGehee, M. D. Understanding degradation mechanisms and improving stability of perovskite photovoltaics. Chem. Rev. 119, 3418–3451 (2019). 

42. Wang, X. et al. Engineering fluorinated-cation containing inverted perovskite solar cells with an efficiency of >21% and improved stability towards humidity. Nat. Commun. 12, 52 (2021). 

43. Zong, Y. et al. Continuous grain-boundary functionalization for high-efficiency perovskite solar cells with exceptional stability. Chem 4, 1404–1415 (2018). 

44. Zhao, Y. et al. Suppressing ion migration in metal halide perovskite via interstitial doping with a trace amount of multivalent cations. Nat. Mater. 21, 1396–1402 (2022). 

45. Wang, S. et al. δ‐CsPbI3 intermediate phase growth assisted sequential deposition boosts stable and high‐efficiency triple cation perovskite solar cells. Adv. Funct. Mater. 30, 1908343 (2019). 

46. Rombach, F. M., Haque, S. A. & Macdonald, T. J. Lessons learned from Spiro-OMeTAD and PTAA in perovskite solar cells. Energy Environ. Sci. 14, 5161–5190 (2021). 

Nature Communications |  (2023) 14:573 

10 

Article 

https://doi.org/10.1038/s41467-023-36224-6 

## Acknowledgements 

This work is supported financially by National Natural Science Foundation of China (52003118 F.W., 62075094 T.Q., 62205143 W.H.); Natural Science Foundation of Jiangsu Province (BK20211537 T.Q.). 

## Author contributions 

F.W. conceived the idea, designed the experiment, and wrote the manuscript. F.W., T.Q., and W.H. supervised the work. M.L. synthesized and characterized the new material; R.S. and M.L. fabricated the perovskite devices and carried out the PV performance characterizations; J.C. repeated the synthesis of the molecule. J.D. and Y.Y. conducted the GIWAXS measurements, supported by the BL14B1 beamline of the Shanghai Synchrotron Radiation Facility; M.L. and R.S. carried out DSC, XPS, in-situ XRD, TCSPC, UPS and SIMS measurement; R.S. and M.L. carried out SCLC measurement with the assistance of Q.T. and H.W; Z.L. carried out the SEM measurement with the assistance of Z.W.; P.Y. carried out the PLQE and FTPS characterization; M.L. and R.S. carried out the IR measurement and optical microscopy measurement with the assistance of C.Y.; M.L. and R.S. carried out the in-situ absorption measurement with the assistance of H.S.; A.W. carried out the TEM measurement; S.Z. carried out the theoretical calculation. T.Q. and R.L. gave some revise suggestions. All authors discussed the results and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Correspondence and requests for materials should be addressed to Fangfang Wang, Wei Huang or Tianshi Qin. 

Peer review information Nature Communications thanks Zhanhua Wei, Jia Zhu and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permissions information is available at 

http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2023 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-023-36224-6. 

Nature Communications |  (2023) 14:573 

11 

