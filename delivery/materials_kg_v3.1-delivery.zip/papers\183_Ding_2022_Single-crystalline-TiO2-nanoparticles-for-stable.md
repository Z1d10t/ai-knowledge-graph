# Single-crystalline TiO2 nanoparticles for stable and efficient perovskite modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Nanotechnology |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 169 |
| 作者 | Yong Ding, Bin Ding, Hiroyuki Kanda, O. J. Usiobo, Thibaut Gallet, Zhen-Hai Yang, Yang Liu, Hao Huang et al. |
| DOI | 10.1038/s41565-022-01108-1 |
| 源文件 | 083_Ding_2022_Single-crystalline-TiO2-nanoparticles-for-stable.pdf |

---




<!-- Start of picture text -->
Single -c rystalline TiO2 Nanoparticles for Narrowing<br>the Scalability Gap towards Stable and E�cient<br>Perovskite Modules<br><!-- End of picture text -->

North China Electric Power University 

École Polytechnique Fédérale de Lausanne 

École Polytechnique Fédérale de Lausanne 

Luxembourg Institute of Science and Technology (LIST) 

University of Luxembourg https://orcid.org/0000-0001-8494-3206 

Chinese Academy of Sciences (CAS), 

University, Xi'an 

Hebei University 

Chinese Academy of Sciences (CAS), 

École Polytechnique Fédérale de Lausanne 

École Polytechnique Fédérale de Lausanne 

École Polytechnique Fédérale de Lausanne 

North China Electric Power University 

Luxembourg Institute of Science and Technology, Materials Research and Technology 

University of Luxembourg 

Page 1/19 

Hebei University 

Italian Institute of Technology 

École polytechnique fédérale de Lausanne 

University of Perugia 

Huazhong University of Science and Technology 

Huaqiao University https://orcid.org/0000-0002-9820-1382 

Hebei University 

North China Electric Power University 

École Polytechnique Fédérale de Lausanne 

MOHAMMAD KHAJA Nazeeruddin  (  mdkhaja.nazeeruddin@ep�.ch ) 

École Polytechnique Fédérale de Lausanne https://orcid.org/0000-0001-5955-4786 

Keywords: perovskite solar cells (PSCs), energy devices, nanoparticles, power conversion 

Posted Date: July 26th, 2021 

DOI: https://doi.org/10.21203/rs.3.rs-737440/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Page 2/19 

Remarkable progress in power conversion e�ciency of perovskite solar cells (PSCs) has been achieved over the last decade, reaching 25.5%. However, transferring these accomplishments from individual small-size devices into large-area modules while preserving their commercial competitiveness compared to other thin-�lm solar cells remains a challenge. A major obstacle is to reduce the resistive losses and the number of intrinsic defects of electron transport layers (mesoporous TiO2, ETL) and to fabricate highquality large-area perovskite �lms. Here, we report a facile solvothermal method to synthesize singlecrystalline TiO2 rhombus-like nanoparticles with exposed {001} facets. Owing to their low lattice mismatch with the perovskite absorber, high electron mobility and lower density of defects, singlecrystalline TiO2 nanoparticle-based small-size devices (0.09 cm<sup>2</sup> ) achieve an e�ciency of 24.05% and a �ll factor of 84.7%. Importantly, these devices maintain about 90% of their initial performance after continuous operation for 1400 h. Combined with vacuum quenching-assisted techniques, we have fabricated large-area modules and obtained a certi�ed e�ciency of 22.72% with an active area of nearly 24 cm<sup>2</sup> . This represents the highest e�ciency modules with the lowest e�ciency loss between small-size devices and modules, enabling to reproducibly fabricate stable and e�cient PSC modules. 

Laboratory-scale, small-area perovskite solar cells (PSCs) have progressed remarkably in recent years with certi�ed power conversion e�ciencies (PCEs) of 25.5%<sup>1,2,3</sup> . However, larger-scale PSC modules lag far behind the laboratory-scale devices<sup>4,5,6</sup> (Supplementary Fig. 1). The major obstacles to narrow the gap in e�ciency between the small devices and large-area modules come from the signi�cant resistive loss<sup>7,8</sup> and the complexity of the processes for achieving high-quality large-area perovskite �lms.<sup>4,5,6,9</sup> Although high-performance devices based on a planar structure were achieved<sup>1,2,10</sup> , utilization of mesoporous TiO2 (m-TiO2) skeletons has been demonstrated as an e�cient structure in most high-e�ciency devices<sup>7,11,12</sup> , because of a large TiO2/perovskite contact area for interfacial charge transfer and suppressed charge recombination over planar perovskite solar cells<sup>13,14</sup> . A detailed photoelectrical model<sup>15</sup> was proposed to rationalize and quantify the �ll factor (FF) losses of devices (Fig. 1). It can be found that the low electron mobility of the m-TiO2 layer and high interfacial defect density (Dit) at the TiO2/perovskite interface, which are ascribed to charge transport loss and current leakage through shunts, respectively, are the main reasons leading to the loss of FF (Supplementary Fig. 2).<sup>8</sup> (Supplementary Note 2) Therefore, it is highly desirable to use TiO2 nanoparticles with high conductivity and few trap states to enable rapid electron transport within m-TiO2 layers and e�cient TiO2/perovskite interfacial charge transfer to lower the resistive loss<sup>16</sup> . 

One of the strategies to reduce charge transport losses is to change the morphology of TiO2 nanocrystals. Random arrays of TiO2 nanorods or nanowires-based electron transport layers (ETLs) have negligible performance enhancement on the FF<sup>17</sup> . However, ordered TiO2 nanorods show promise due to 

Page 3/19 

their large surface area and combined with highly directional charge transport paths, resulting in low resistive losses.<sup>7</sup> Another strategy is to dope the ETL with various metal ions, e.g. lithium (Li)<sup>11, 18</sup> , Yttrium (Y)<sup>19</sup> , Indium (In)<sup>20</sup> , which can not only increases the conductivity of the ETL, but allows to tune the band offset in a device.<sup>21</sup> Fast charge transfer at the TiO2/perovskite interface is also critical to minimize current leakage through shunts.<sup>22</sup> It is essential to have excellent electronic coupling and favorable lattice matching at the TiO2/perovskite interface.<sup>23</sup> Density functional theory (DFT) calculations indicate that the (001) facets of anatase TiO2 nanoparticles exhibit a low lattice mismatch with crystalline MAPbI3, whereas the commonly observed (101) facetted TiO2 nanoparticles exhibit a larger lattice mismatch.<sup>24</sup> Thus, TiO2 nanoparticles with a high number of {001} oriented grains would be advantageous. Moreover, there have been several approaches involving the tailoring of surface/interface trap states and energy level alignment by coating them with thin surface layers, including graphene<sup>25</sup> , chlorine-capped TiO222, and ionic liquid-based<sup>26</sup> passivation methods. Surface/interface passivation strategies can improve the energy level alignment with the perovskite and increase the charge mobility of TiO2 by passivating trap states at the TiO2 surface.<sup>8</sup> It is noteworthy that although the doping approach and surface/interface passivation may help mitigate charge recombination and accumulation for e�cient PSCs, they may introduce extra processing steps and costs which is problematic for industrial-scale manufacturing. Therefore, it is essential to search for a facile method to fabricate TiO2 nanoparticles with a high conductivity, an improved crystallinity, and reduced defect concentrations, that is also scalable. 

Herein, we present single-crystalline TiO2 rhombus-like nanoparticles (SC) with exposed {001} facets by a one-step solvothermal method. The SC-based ETL showed higher electron mobility and lower trap density than commercial TiO2 nanoparticles (NP)-based ETLs. As a result, the SC-based devices achieved higher FF (up to 84.7%) and PCE (up to 24.05%) with a certi�ed e�ciency of 23.5%. Similar to the small-size device, a module with an active area of 24.63 cm<sup>2</sup> was fabricated by combining spin-coating and vacuum quenching-assisted method, delivering a FF of 82.0% and a PCE of 22.87%, which is the highest e�ciency and FF for a mini-module reported to date. Bene�ting from the fewer intrinsic defects of singlecrystalline TiO2 nanoparticles, the SC-based small device showed long-term operational stability, maintaining 90% of its initial e�ciency under continuous light illumination with maximum power point tracking for 1400 h. 



<!-- Start of picture text -->
Results And Discussions<br>Characterization of TiO2 nanoparticles and mesoporous TiO2 layers<br><!-- End of picture text -->

Commercial TiO2 nanoparticles (Supplementary Fig. 3) are often synthesized by a modi�ed Sol-Gel method and hydrothermal treatment<sup>27</sup> , which is costly and time consuming. Thus, a simpler method that can be scalable to fabricate TiO2 nanoparticles would be bene�cial. The SC was successfully synthesized in a one-step solvothermal method based on the Mannich reaction between acetone and isopropanol.<sup>28</sup> As determined by powder X-ray diffraction (XRD, Supplementary Fig. 4) and scanning 

Page 4/19 

electron microscopy (SEM), the synthesized SC is anatase and rhombus-like with a narrow size dispersion (a length of about 60 nm and a width of 20-30 nm, Fig. 2a). Comparing with conventional spherical TiO2 nanoparticles, XRD pattern of the SC exhibits a high ratio of {001}/(101) peaks, indicating that the ethylenediamine can control the growth of TiO2 nanocrystals along the [001] direction. Interestingly, the high-resolution TEM image in Fig. 2b shows that the entire nanoparticle is singlecrystalline and high crystalline with uniform and clear fringe patterns. The corresponding fast Fourier transform image (Inset in Fig. 2b) matches well with the theoretical value of the angle between the (101) and (001) facets. The detailed spherical aberration electron microscopy characterization (Fig. 2c) of the SC clearly illustrates the dumbbell pairs of Ti and O atoms along the [001] crystal direction (Inset in Fig. 2c). Therefore, the Ti ions are predominately in the 4+ oxidation state for the SC veri�ed by a �ne structure of Ti L2,3 edges, without obvious variations in the electron-energy-loss spectroscopy (EELS) pro�le as shown in the inset in Fig. 2c.<sup>29</sup> 

It was found that a thick SC �lm leads to a drop in the Voc and FF (Supplementary Fig. 6), therefore a 100 nm-thick SC �lm was chosen following optimization of the thickness of the SC (Supplementary Fig. 5). In this case, only 3 or 4 particles of SC TiO2 nanoparticles along the vertical direction are necessary to stack on the FTO/compact TiO2 (c-TiO2) substrate thereby minimizing the number of grain boundaries within the m-TiO2 layer, which shortens the electron diffusion distance. In addition, these mesopores and micropores on the surface are easily and fully �lled by the perovskite precursor to form close contact with perovskite grains (Supplementary Fig. 7). 

The SC �lm retains its {001} facets after annealing at 500 ºC (Supplementary Fig. 8), which ensures a well-de�ned interface between the TiO2 and perovskite as the perovskite spontaneous aligns with the {001} facets of TiO2. In contrast, the commercial spherical TiO2 nanoparticles with random orientation create a less oriented interface. We evaluated the TiO2/perovskite interface with DFT calculations by adopting a 3×3×3 perovskite tetragonal MAI-terminated slab deposited on to a 7×7×2 (001)-TiO2 anatase surface with a total number of 1398 atoms<sup>30</sup> . The adsorption energy (Eads) normalized by the number of I atoms on the perovskite surface was estimated to be 1.2 and 1.7 eV for the (101) and (001) facet-based interface. The corresponding lattice mismatch between (001)-TiO2 and perovskite is less than 1%, indicating the (001) facets of TiO2 provide a more stable TiO2/perovskite interface (Supplementary Fig. 9). In addition, the partial density of states suggests that the conduction band alignments of both (001)TiO2/perovskite and (101)-TiO2/perovskite interface are almost similar. The calculated band alignment (Fig. 3a) of the devices is further determined by combining the data from the UV-vis absorbance spectra (Supplementary Fig. 10) and ultraviolet photoelectron spectra (UPS, Supplementary Fig. 11). Moreover, Kelvin Probe Force Microscopy (KPFM) under ultra-high-vacuum was also carried out to identify the surface potential of the m-TiO2/perovskite interface (Supplementary Fig. 12). The surface of the SC �lm presents a higher average work function (4.25±0.02 eV) than that of the NP �lm (4.09±0.04 eV), in good accordance with the UPS result. 

Page 5/19 

Usually, the low electron mobility of the ETL is inclined to form an energy barrier that blocks electron transport, resulting in the charge carrier recombination and charge accumulation.<sup>31,32</sup> As estimated by Hall effect measurements (Supplementary Table 1), the mobility of the SC �lm is about 3.59 cm<sup>2</sup> /Vs, which is 3 times higher than that of the NP �lm (1.17 cm<sup>2</sup> /Vs). The high-resolution X-ray photoelectron spectra (Supplementary Fig. 13) and UV-vis absorption spectra (Supplementary Fig. 10) con�rmed that fewer defects (i.e., Ti<sup>3+</sup> and oxygen vacancies, Supplementary Note 1) are present in the SC compared to the commercial NP, where the presence of Ti<sup>3+</sup> and a red-shift of absorption edge of the NP are observed. These defects act as charge carrier traps and block charge extraction from the perovskite �lm.<sup>22,32</sup> Therefore, the favorable energy level, high electron mobility, and the reduced defect densities of the SC are conducive to rapid interfacial charge transfer at the m-TiO2/perovskite interface combined with a fast inter-grain charge transport between adjacent TiO2 nanoparticles. 

We fabricated small-size devices with a n-i-p structure comprising FTO/c-TiO2/mTiO2/Rb0.03Cs0.05MA0.05FA0.90PbI3/spiro-OMeTAD/Au using NP and SC, respectively as the ETL. The thickness of c-TiO2 �lm and m-TiO2 layers is ≈15 nm and ≈100 nm, respectively, capped with about 700 nm of perovskite �lm, 220 nm of Spiro-OMeTAD �lm as a hole transporting layer (HTL) and 70 nm of Au layer as a contact (Supplementary Fig. 14). The perovskite �lm on the NP and SC substrates shows an excellent morphology, and the grain size is larger than 1.0 μm (Supplementary Fig. 15). As demonstrated by XRD patterns (Supplementary Fig. 16), KPFM (Supplementary Fig. 17) and Helium Ion MicroscopySecondary Ion Mass Spectrometry (HIM-SIMS) (Supplementary Fig. 18) measurement, the presence of surface PbI2 grains does not form a barrier to charge transfer, but passivates the defects and reduces charge recombination in high-performance devices.<sup>31,33</sup> 

As shown in Fig. 3b, the best performance of a SC-based device presents a Voc of 1.121 V, Jsc of 25.35 mAcm<sup>-2</sup> , FF of 84.7%, and PCE of 24.05% under reverse scan (a quasi-steady state PCE up to 23.75%), much higher than 22.72% of the NP-based device (Fig. 3d). Moreover, the difference between the forward scan and reverse scan of the SC-based device is signi�cantly smaller than that of the NP-based device (Supplementary Fig. 19). The Jsc values for both devices are similar, which can be con�rmed by the external quantum e�ciency (EQE), in which the integrated Jsc is calculated to be 24.55 mAcm<sup>-2</sup> and 24.58 mAcm<sup>-2</sup> for the NP and SC-based devices, respectively (Fig. 3c). The similar integrated Jsc is ascribed to higher electron collection e�ciency, albeit with lower light harvesting e�ciency for the SC-based device (Supplementary Fig. 20). However, a substantial enhancement in the Voc and FF is observed for the SCbased device, which may be reduced charge recombination and lowered series resistance for rapid charge extraction (see below for further details). Moreover, excellent reproducibility is demonstrated by the narrow distribution of photovoltaic performance (Supplementary Fig. 21, and Supplementary Table 2 and Table 3). One of the best SC-based devices was certi�cated by Newport, which con�rmed the PCE of 23.50% under reverse scan with the quasi-steady state PCE of 22.73% (Supplementary Fig. 22). 

Page 6/19 

The Voc is related to the quasi-Fermi level separation at the contacts of a cell, and it is also in�uenced by the energy distribution of the charge transport layer and perovskite layer<sup>14</sup> . Since the FF is mainly determined by the competition between charge extraction and recombination, the resistance loss may be used to estimate the FF loss<sup>8</sup> . To gain more insight into charge transport and recombination, we measured the Jsc and Voc as a function of light intensity (Supplementary Fig. 23). A linear relationship between Jsc and light intensity for the NP and SC-based devices is found and coe�cient of 0.92 and 0.96 are extracted, respectively. Additionally, the SC-based device has an ideal factor (nid) of 1.26, which is much lower than that of the NP-based device (1.46), indicating the negligible bimolecular recombination and reduced trap-assisted recombination in the SC-based device (Fig. 3e).<sup>34,35</sup> After �tting the J-V curves, a lower series resistance of 0.49 Ω·cm<sup>2</sup> for the SC-based device was estimated compared with that of the NP-based device (1.31 Ω·cm<sup>2</sup> ), with a lower reverse bias saturation current of 4.08×10<sup>-10</sup> mA·cm<sup>-2</sup> compared to 3.44×10<sup>-7</sup> mA·cm<sup>-2</sup> (Supplementary Fig. 24). Based on the above data, the calculated FF is close to the real value with an error of less than 1% (Supplementary Table 7). 

Additionally, deduced from the space-charge-limited current (SCLC) model (Supplementary Fig. 25), the SC-based device has a low trap-state density of 1.42×10<sup>15</sup> cm<sup>-3</sup> , about one �fth of that of the NP-based device (6.66×10<sup>15</sup> cm<sup>-3</sup> ), which may be attributed to the fewer defects in the single-crystalline TiO2 nanoparticles and favorable lattice matching with the perovskite. In addition, it was found that the decay time of transient photovoltage increased from 1.47 to 2.24 ms on replacing the NP with the SC layer, suggesting a dramatic improvement of charge extraction and reduced recombination (Supplementary Fig. 26). The increased decay time and the reduced trap-state density lead to a reduction of trap-assisted recombination and charge accumulation, resulting in an increase of Voc35. 

Previous reports have shown that charge carrier recombination is ascribed to the presence of grain boundaries, interfaces and ion defects in the devices.<sup>36</sup> Trap-assisted recombination at the ETL/perovskite and HTL/perovskite interface, especially the SRH recombination via traps or defects, is the dominant recombination channel.<sup>8,35,37</sup> Since the interfacial HTL/perovskite quality remains unchanged, we assume that this interface can be ignored. The photoelectrical model explains the role of electron mobility in TiO2 and trap density (Dit) at the TiO2/perovskite interface on the photovoltaic performance<sup>15</sup> . The increased electron mobility in TiO2 leads to faster extraction of charge carriers which is re�ected by the increase of the FF (Supplementary Fig. 2). In addition, the substantial drop of the Voc and FF may be related to the increased concentration of Dit (Supplementary Fig. 2). Fitting the J-V experimental data gives rise to a Dit values of 1×10<sup>8</sup> and 2×10<sup>7</sup> cm<sup>-2</sup> for the NP- and SC-based devices, respectively (Fig. 3f). The higher the Dit value, the lower the Voc and FF. Thus, the mitigation of trap density and the elevation of electron mobility are essential for reducing the SRH recombination and improving device performance<sup>35</sup> . 

Page 7/19 

To further clarify the mechanism of the improved Voc and FF of the SC-based device, steady-state photoluminescence (PL) and time-resolved photoluminescence (TRPL) decay measurements were carried out to study carrier transfer dynamics. The PL intensity mapping of the FTO/SC/perovskite is lower than that of FTO/NP/perovskite, indicating a signi�cant PL quench by the SC substrate (Fig. 4a and 4b). The PL lifetimes (τ1) obtained from TRPL curves were �tted to be 37.9 and 34.4 ns for the FTO/cTiO2/NP/perovskite and FTO/c-TiO2/SC/perovskite �lms, respectively (Supplementary Table 4). The e�cient PL quench and shorter PL of the SC substrate indicate its fast electron extraction ability (Fig. 4c). Moreover, femtosecond transient absorption spectroscopy (fs-TAS) was further used to explore the effect of m-TiO2 on the charge transfer at the m-TiO2/perovskite interface. There are a photoabsorption (PA) positive peak at about 510-720 nm and a photobleaching (PB) negative peak at around 760-790 nm. The PA positive peak is related to the absorption of transient species, whereas the PB peak is ascribed to the exciton transition of the perovskite �lm.<sup>38</sup> The intensity of this PB peak for the FTO/SC/perovskite is evidently lowered, suggesting the occurrence of a faster exciton transition from the perovskite �lm (Fig. 4e and 4f). Furthermore, the TA lifetime of the FTO/SC/perovskite is higher than that of the FTO/NP/perovskite (Fig. 4d and Supplementary Table 4). Consequently, the photo-excited carriers can be e�ciently collected, and thus carrier recombination is reduced by using the SC as the ETL. In addition, capacitance-voltage (C-V) measurements in both dark and illumination conditions provide direct evidence that interfacial charge accumulation has been e�ciently mitigated using the SC instead of the NP as the ETL (Supplementary Fig. 27)<sup>39</sup> . 

A key issue to PSC commercialization is to keep the fabrication processes as simple as possible. As the area of devices is scaled up, problems emerge. High-quality perovskite �lms with uniformity and reproducibility are required, and at present, most of the state-of-the-art lab modules are fabricated using a spin coating to deposit the perovskite layer<sup>40</sup> . Nevertheless, spinning off the anti-solvent during the solvent washing steps leads to pinholes and/or cracks in the large-scale perovskite preparation. These defects in�uence charge carrier extraction from the perovskite layer to the charge transport layers<sup>6</sup> . In contrast, vacuum quenching-assisted techniques are more practical for manufacturing on a larger scale<sup>41</sup> . 

Here, based on the better performances of the SC-based small devices, we fabricated a module with a size of 6.5×7.0 cm<sup>2</sup> via the aforementioned vacuum quenching-assisted method. As presented in Fig. 5a, the modules have 9 sub-cells interconnected in series, and the active area is 24.63 cm<sup>2</sup> (Supplementary Fig. 30). The inset photo in Fig. 5a displays a high-quality perovskite �lm without any pinholes. The highest PCE of 22.87% was obtained with a FF of 82.0%, emphasizing the superiority quality of the SC as the ETL (Fig. 5b). The stabilized photocurrents of the modules at its maximum power output point are shown in Fig. 5c, giving stabilized PCEs of 22.22%. The photovoltaic parameter statistics of 25 modules 

Page 8/19 

are summarized in Supplementary Table 5, showing a good reproducibility from module to module. In addition, some of modules were evaluated by Photovoltaic Laboratory of the Institute of Micro Technique (IMT), Neuchâtel, Switzerland (Supplementary Fig. 31) and Photovoltaic and Wind Power Systems Quality Test Center, IEE, Chinese Academy of Sciences (Supplementary Fig. 32), respectively. The reverse scan e�ciency was certi�ed as 22.72% on an active area of 23.904 cm<sup>2</sup> with the FF of 79.1%. This is to our knowledge the record e�ciency and FF for modules, supported by data presented using the latest module e�ciencies (Supplementary Table 8). 

Long-term stability is another important requirement for practical application. In particular, the operational stability of the device under continuous illumination is an important determinant of long-term stability. The operation stability was tracked at the maximum power point (MPP) under continuous AM1.5G light illumination. As shown in Fig. 5d, the SC-based device without encapsulation maintains 90% of initial e�ciency for 1400 h, which is much better than the NP-based device (60%). The improved long-term operation stability might be due to three reasons. First, a high content of exposed {001} facets is bene�cial for carrier separation due to its better lattice and atoms arrangement with the perovskite.<sup>22,24</sup> Second, fewer defects and improved electron mobility could induce faster charge transport and reduce charge accumulation during operation. UV light-induced degradation was caused by photoinduced desorption of oxygen from oxygen vacancies on the TiO2 surface, leading to fast trap-assisted recombination across the TiO2/perovskite interface.<sup>42,43</sup> Third, compared to the NP, the absorption spectrum of the SC is blue shifted, which would reduce the absorption of high energy photons from UV illumination (Supplementary Fig. 10a). Furthermore, the markedly improved device stability of the SCbased device was further demonstrated by the sustained contact potential difference under long-time light illumination, suggesting that the improved stability originates from the introduction of the SC/perovskite interface (Supplementary Fig. 33)<sup>44</sup> . Encapsulation has a vital role in increasing the moisture stability of devices. Compared to drying environment, a glass-glass encapsulation technology combined with the use of a commercial sealant (UV Curing Sealant, Three bond) could improve their moisture stability under 85% relative humidity (RH) without sacri�cing the performance of devices, which was comparable to dried ambient environment (Fig. 5e). This encapsulation strategy paves the way for a scalable and robust encapsulation strategy feasible to PSC modules (Supplementary Video). 

In conclusion, we have described a simple and e�cient method for synthesizing single-crystalline TiO2 nanoparticles that greatly enhance performances and long-term operational stability of PSC devices. The synthesized TiO2 nanoparticles exhibit high conductivity and crystallinity, fewer defects, and less lattice matching with the perovskite, which minimizes resistive loss and affords the highest FF reported to date in small-sized PSC devices and modules. Our approach represents another milestone towards stable perovskite-based photovoltaic modules, and should be applicable to other optoelectronic applications that use the single-crystalline TiO2 nanoparticles. 

Page 9/19 

Acknowledgements: This work was supported by the National Key R&D Program of China (2018YFB1500101), the 111 Project (No. B16016), the National Natural Science Foundation of China (No. U1705256 and 51961165106). We thank the Swiss National Science Foundation (SNF) and Luxembourg Fonds National de la Recherche (FNR, “SUNSPOT”, Nr. 11244141), SNSF for �nancial support of the SOLAR4D project, SNF project number :200020L_1729/1 and FNR INTER n° 16/11534230. 

Author contributions: Y.D. and B.D. conceived and made the experiment. Y.D. synthesized the singlecrystallineline TiO2 nanoparticles. H.K. performed the XPS, UPS, and SEM characterization. O.J.U. conducted the ambient AFM, KPFM, and HIM-SIMS characterization with supervision from J.N.A. T.G. performed the UHV-AFM and KPFM measurement with supervision from A.R. Z.H.Y. and S.J. simulated the in�uence of trap state density and electron mobility of TiO2 on the whole photovoltaic performance. Y.L. conducted the UPS, Hall effect measurement and spherical aberration electron microscopy with supervision from G.J.Y. H.H performed the steady-state transient absorption spectroscopy and transient absorption spectroscopy measurement with supervision from W.D. C.L., Y.Y., and X.F.Z. conducted the PL mapping, SCLC, C-V, and transient photovoltage measurements. V.I.E.Q. made the TRPL characterization. Y.D. and B.D. wrote the �rst draft of the manuscript and all authors contributed feedback and comments. G.J.Y., J.H.W. S.Y.D., P.J.D., and M.K.N. directed and supervised the research. 

1.     Yoo JJ, Seo G, Chua MR, Park TG, Lu Y, Rotermund F, et al. E�cient perovskite solar cells via improved carrier management. Nature 2021, 590(7847): 587-593. 

2.     Liu Z, Qiu L, Ono LK, He S, Hu Z, Jiang M, et al. A holistic approach to interface stabilization for e�cient perovskite solar modules with over 2,000-hour operational stability. Nat. Energy 2020, 5(8): 596604. 

3.     Park B-w, Kwon HW, Lee Y, Lee DY, Kim MG, Kim G, et al. Stabilization of formamidinium lead triiodide α-phase with isopropylammonium chloride for perovskite solar cells. Nat. Energy 2021, 6(4): 419428. 

4.     Li Z, Klein TR, Kim DH, Yang M, Berry JJ, van Hest MFAM, et al. Scalable fabrication of perovskite solar cells. Nat. Rev. Mater. 2018, 3(4): 18017. 

5.     Werner J, Boyd CC, Moot T, Wolf EJ, France RM, Johnson SA, et al. Learning from existing photovoltaic technologies to identify alternative perovskite module designs. Energy Environ. Sci. 2020, 13(10): 3393-3403. 

Page 10/19 

6.     Lee SW, Bae S, Kim D, Lee HS. Historical Analysis of High-E�ciency, Large-Area Solar Cells: Toward Upscaling of Perovskite Solar Cells. Adv. Mater. 2020, 32(51): 2002202. 

7.     Peng J, Walter D, Ren Y, Tebyetekerwa M, Wu Y, Duong T, et al. Nanoscale localized contacts for high �ll factors in polymer-passivated perovskite solar cells. Science 2021, 371(6527): 390-395. 

8.     Stolterfoht M, Wolff CM, Amir Y, Paulke A, Perdigón-Toro L, Caprioglio P, et al. Approaching the �ll factor Shockley-Queisser limit in stable, dopant-free triple cation perovskite solar cells. Energy Environ. Sci. 2017, 10(6): 1530-1539. 

9.     Kim DH, Whitaker JB, Li Z, van Hest MFAM, Zhu K. Outlook and Challenges of Perovskite Solar Cells toward Terawatt-Scale Photovoltaic Module Technology. Joule 2018, 2(8): 1437-1451. 

10.   Jiang Q, Zhao Y, Zhang X, Yang X, Chen Y, Chu Z, et al. Surface passivation of perovskite �lm for e�cient solar cells. Nat. Photon. 2019, 13(7): 460-466. 

11.   Kim M, Choi I-w, Choi SJ, Song JW, Mo S-I, An J-H, et al. Enhanced electrical properties of Li-salts doped mesoporous TiO2 in perovskite solar cells. Joule 2021, 5(3): 659-672. 

12.   Kim G, Min H, Lee KS, Lee DY, Yoon SM, Seok SI. Impact of strain relaxation on performance of alpha-formamidinium lead iodide perovskite solar cells. Science 2020, 370(6512): 108-112. 

13.   Marchioro A, Teuscher J, Friedrich D, Kunst M, van de Krol R, Moehl T, et al. Unravelling the mechanism of photoinduced charge transfer processes in lead iodide perovskite solar cells. Nat. Photon. 2014, 8(3): 250-255. 

14.   Edri E, Kirmayer S, Henning A, Mukhopadhyay S, Gartsman K, Rosenwaks Y, et al. Why lead methylammonium tri-iodide perovskite-based solar cells require a mesoporous electron transporting scaffold (but not necessarily a hole conductor). Nano Lett. 2014, 14(2): 1000-1004. 

15.   Yang Z, Yang W, Yang X, Greer JC, Sheng J, Yan B, et al. Device physics of back-contact perovskite solar cells. Energy Environ. Sci. 2020, 13(6): 1753-1765. 

16.   Wang Y, Yue Y, Yang X, Han L. Toward Long-Term Stable and Highly E�cient Perovskite Solar Cells via Effective Charge Transporting Materials. Adv. Energy Mater. 2018, 8(22): 1800249. 

17.   Shahvaranfard F, Altomare M, Hou Y, Hejazi S, Meng W, Osuagwu B, et al. Engineering of the Electron Transport Layer/Perovskite Interface in Solar Cells Designed on TiO2 Rutile Nanorods. Adv. Funct. Mater. 2020, 30(10): 1909738. 

18.   Giordano F, Abate A, Correa Baena JP, Saliba M, Matsui T, Im SH, et al. Enhanced electronic properties in mesoporous TiO2 via lithium doping for high-e�ciency perovskite solar cells. Nat Commun. 2016, 7: 10379. 

Page 11/19 

19.   Zhou H, Chen Q, Li G, Luo S, Song TB, Duan HS, et al. Photovoltaics. Interface engineering of highly e�cient perovskite solar cells. Science 2014, 345(6196): 542-546. 

20.   Peng J, Duong T, Zhou X, Shen H, Wu Y, Mulmudi HK, et al. E�cient Indium-Doped TiOx Electron Transport Layers for High-Performance Perovskite Solar Cells and Perovskite-Silicon Tandems. Adv. Energy Mater. 2017, 7(4): 1601768. 

21.   Chen J, Tao HB, Liu B. Unraveling the Intrinsic Structures that In�uence the Transport of Charges in TiO2 Electrodes. Adv. Energy Mater. 2017, 7(23): 1700886. 

22.   Tan H, Jain A, Voznyy O, Lan X, Garcia de Arquer FP, Fan JZ, et al. E�cient and stable solutionprocessed planar perovskite solar cells via contact passivation. Science 2017, 355(6326): 722-726. 

23.   Luo J, Chen J, Wu B, Goh TW, Qiao W, Ku Z, et al. Surface Rutilization of Anatase TiO2 for E�cient Electron Extraction and Stable P max Output of Perovskite Solar Cells. Chem 2018, 4(4): 911-923. 

24.   Geng W, Tong CJ, Liu J, Zhu W, Lau WM, Liu LM. Structures and Electronic Properties of Different CH3NH3PbI3/TiO2 Interface: A First-Principles Study. Sci. Rep. 2016, 6: 20131. 

25.   Biccari F, Gabelloni F, Burzi E, Gurioli M, Pescetelli S, Agresti A, et al. Graphene-Based Electron Transport Layers in Perovskite Solar Cells: A Step-Up for an E�cient Carrier Collection. Adv. Energy Mater. 2017, 7(22): 1701349. 

26.   Noel NK, Habisreutinger SN, Wenger B, Lin YH, Zhang F, Patel JB, et al. Elucidating the Role of a Tetra�uoroborate‐Based Ionic Liquid at the n-Type Oxide/Perovskite Interface. Adv. Energy Mater. 2019, 10(4): 1903231. 

27.  Xiaobo C, S. MS. Titanium Dioxide Nanomaterials: Synthesis, Properties, Modi�cations, and Applications. Chem. Rev. 2007, 107(7): 2891–2959. 

28.   Ding Y, Zhang T, Liu C, Yang Y, Pan J, Yao J, et al. Shape-controlled synthesis of single-crystalline anatase TiO2 micro/nanoarchitectures for e�cient dye-sensitized solar cells. Sustain. Energy Fuels 2017, 1(3): 520-528. 

29.   Gloter A, Ewels C, Umek P, Arcon D, Colliex C. Electronic structure of titania-based nanotubes investigated by EELS spectroscopy. Phys. Rev. B 2009, 80(3): 035413. 

30.   Mosconi E, Ronca E, De Angelis F. First-Principles Investigation of the TiO2/Organohalide Perovskites Interface: The Role of Interfacial Chlorine. J. Phys. Chem. Lett. 2014, 5(15): 2619-2625. 

31.   Jiang Q, Zhang L, Wang H, Yang X, Meng J, Liu H, et al. Enhanced electron extraction using SnO2 for high-e�ciency planar-structure HC(NH2)2PbI3-based perovskite solar cells. Nat. Energy 2016, 2(1): 16177. 

Page 12/19 

32.   Klasen A, Baumli P, Sheng Q, Johannes E, Bretschneider SA, Hermes IM, et al. Removal of Surface Oxygen Vacancies Increases Conductance Through TiO2 Thin Films for Perovskite Solar Cells. J. Phys. Chem. C 2019, 123(22): 13458-13466. 

33.   Gratia P, Grancini G, Audinot JN, Jeanbourquin X, Mosconi E, Zimmermann I, et al. Intrinsic Halide Segregation at Nanometer Scale Determines the High E�ciency of Mixed Cation/Mixed Halide Perovskite Solar Cells. J. Am. Chem. Soc. 2016, 138(49): 15821-15824. 

34.   Shi J, Gao Y, Gao X, Zhang Y, Zhang J, Jing X, et al. Fluorinated Low-Dimensional RuddlesdenPopper Perovskite Solar Cells with over 17% Power Conversion E�ciency and Improved Stability. Adv. Mater. 2019, 31(37): 1901673. 

35.   Le Corre VM, Sherkar TS, Koopmans M, Koster LJA. Identi�cation of the dominant recombination process for perovskite solar cells based on machine learning. Cell Rep. Phys. Sci. 2021, 2(2): 100346. 

36.   Park N-G, Zhu K. Scalable fabrication and coating methods for perovskite solar cells and solar modules. Nat. Rev. Mater. 2020, 5(5): 333-350. 

37.   Tress W. Perovskite Solar Cells on the Way to Their Radiative E�ciency Limit - Insights Into a Success Story of High Open-Circuit Voltage and Low Recombination. Adv. Energy Mater. 2017, 7(14): 1602358. 

38.   Gong X, Sun Q, Liu S, Liao P, Shen Y, Gratzel C, et al. Highly E�cient Perovskite Solar Cells with Gradient Bilayer Electron Transport Materials. Nano Lett. 2018, 18(6): 3969-3977. 

39.   Lin PY, Wu T, Ahmadi M, Liu L, Haacke S, Guo TF, et al. Simultaneously enhancing dissociation and suppressing recombination in perovskite solar cells. Nano Energy 2017, 36: 95-101. 

40.   Qiu L, He S, Ono LK, Liu S, Qi Y. Scalable Fabrication of Metal Halide Perovskite Solar Cells and Modules. ACS Energy Lett. 2019, 4(9): 2147-2167. 

41.   Ding B, Huang S-Y, Chu Q-Q, Li Y, Li C-X, Li C-J, et al. Low-temperature SnO2-modi�ed TiO2 yields record e�ciency for normal planar perovskite solar modules. J. Mater. Chem. A 2018, 6(22): 1023310242. 

42.   Leijtens T, Eperon GE, Pathak S, Abate A, Lee MM, Snaith HJ. Overcoming ultraviolet light instability of sensitized TiO2 with meso-superstructured organometal tri-halide perovskite solar cells. Nat. Commun. 2013, 4: 2885. 

43.   Boyd CC, Cheacharoen R, Leijtens T, McGehee MD. Understanding Degradation Mechanisms and Improving Stability of Perovskite Photovoltaics. Chem. Rev. 2019, 119(5): 3418-3451. 

44.   Zhang F, Ullrich F, Silver S, Kerner RA, Rand BP, Kahn A. Complexities of Contact Potential Difference Measurements on Metal Halide Perovskite Surfaces. J. Phys. Chem. Lett. 2019, 10(4): 890-896. 

Page 13/19 



Effects of electron mobility of TiO2-based ETL and interfacial defect density of TiO2/perovskite interface on the FF loss. a, Electron mobility effect. b, Interfacial defect density effect. 

Page 14/19 



Morphology and characterization of single-crystalline TiO2 nanoparticles. a, Scanning electron microscopy (SEM) image. The inset shows transmission electron microscopy (TEM) image of the SC. b, High-resolution TEM image. The inset displays a fast Fourier transform image, suggesting it is a single crystal. c, Spherical aberration electron microscopy image. The upper inset illustrates the crystal structure along the [010] axis (blue, Ti; red, O), and the bottom inset shows an electron energy loss spectrum of the SC, demonstrating highly crystalline of the SC. 

Page 15/19 



Comparison of NP-and SC-based device photovoltaic performance and characterization. a, Energy band level of device of the devices. b, Current density-voltage (J-V) curves of the best performing devices for each condition measured from reverse scan under simulated AM1.5 sun-light. The devices were covered with an antire�ection �lm and a metal mask with an area of 0.09 cm2. c, EQE spectra and integrated photocurrent curve of the devices. The integrated Jsc values over the entire EQE spectra were 24.55 and 24.58 mAcm-2 for the NP and SC-based devices, respectively. d, Stabilized power output measured for 500 s at the maximum power point (MPP). The inset shows the steady-state current and voltage measurement. e, Voc dependence of light intensity with ideality factors nid. f, Simulation of electron mobility and interfacial defect density (Dit) effect on the performance. The solid line represents experiment data, and the open squares denote the simulation. 

Page 16/19 



Interfacial charge transfer dynamics of perovskite �lms based on the NP and SC substrates. Confocal photoluminescence (PL) intensity maps of perovskite �lms deposited on (a) the NP and (b) the SC substrates. Scale bar: 1.0 μm. c, Time-resolved photoluminescence (TRPL) spectra of perovskite �lms deposited on the FTO, FTO/c-TiO2/NP and FTO/c-TiO2/SC substrates. d, Normalized TA kinetic pro�les probed at 750 nm of FTO/c-TiO2/NP/perovskite and FTO/c-TiO2/SC/perovskite �lms. TA spectra at different delay times of (e) FTO/c-TiO2/NP/perovskite and (f) FTO/c-TiO2/SC/perovskite �lms. 

Page 17/19 



Module architecture and performance, and small-sized device’ stability. a, Schematic of module structure with 9 subcells connected in series. The inset shows a photograph of unencapsulated FTO/cTiO2/NP/perovskite/spiro-OMeTAD �lm. b, Champion J-V curve of a module in reverse scanning mode. c, The stabilized photocurrent output and PCE of a module under maximum power point. d, Operation stability of small devices without encapsulation measured at a maximum power point under a continuous AM1.5G LED light illumination in a N2 box with a relative humidity (RH) of below 5%. e, Humidity stability of small-sized devices encapsulated under a RH of 85% (upper) and a RH of <5% in a drying box (bottom). 

Page 18/19 

This is a list of supplementary �les associated with this preprint. Click to download. 

SupportingInformation.docx 

Page 19/19 

