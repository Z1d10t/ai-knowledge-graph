# Modulation of Charge Trapping by Island‐like Single‐Atom Cobalt Catalyst for Enhanced Photo‐Fenton‐Like reaction

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 210 |
| 作者 | Mengying Qian, Xi-Lin Wu, Mei-Chen Lu, Lizhou Huang, Wenxuan Li, Hong-Jun Lin, Jian-Rong Chen, Shao-Bin Wang et al. |
| DOI | 10.1002/adfm.202208688 |
| 源文件 | 043_Qian_2023_Modulation-of-Charge-Trapping-by-Islandlike-Sing.pdf |

---
**ReseaRch aRticle** 

**www.afm-journal.de** 



# **Modulation of Charge Trapping by Island-like Single-Atom Cobalt Catalyst for Enhanced Photo-Fenton-Like reaction** 

_Mengying Qian, Xi-Lin Wu,* Meichi Lu, Lizhou Huang, Wenxuan Li, Hongjun Lin, Jianrong Chen, Shaobin Wang, and Xiaoguang Duan*_ 

source of antibiotics that are discharged into the aquatic environment,<sup>[1,2]</sup> owing to the  inefficient elimination of antibiotics by conventional water purification techniques (e.g., biological treatment and chemical coagulation).<sup>[3,4]</sup> Recently, advanced oxidation processes (AOPs) are considered undoubtedly promising techniques for the treatment of antibiotic wastewater. Among the various AOPs, Fenton-like-reactions by catalytic activation of peroxymonosulfte (PMS) to generate highly reactive oxygen species (ROS), such as sulfate radical (SO4<sup>•–</sup> ), hydroxyl radical (•OH), superoxide radical (O2<sup>•–</sup> ) and singlet oxygen (<sup>1</sup> O2), are emerging approaches for the abatement of antibiotics contaminants from wastewater.<sup>[3,5]</sup> 

**Composites-based photocatalysis relies on the interfacial electron transfer between the metallic cocatalyst and photosensitizer (the semiconductor) to realize spatial separation of charge carriers. Herein, an ingenious heterojunction between Co-CN single atom catalysts (SACs) and g-C3N4 is constructed for heterogeneous photo-Fenton-like reactions. Driven by built-in electric field across the heterojunctions, the separation and migration of the photogenerated charge carriers is promoted, leading to the fast electron transfer from the g-C3N4 to the Co-CN SACs. Theoretical calculations and transient absorption spectroscopy reveal the modulated charge transfer and trapping in the SA-Co-CN/g-C3N4 heterostructure, resulting in the remarkably enhanced generation of reactive oxygen species via peroxymonosulfate activation under light irradiation. This ingenious SA-Co-CN/g-C3N4/PMS/vis system is efficient for the oxidation of various antibiotics with high removal efficiency (** > **98%), a wide operating pH range (pH 3–11) and excellent stability in longterm operation. This study provides a new tactic for rational design of SACsbased heterojunctions to bridge photocatalysis and heterogeneous catalysis, attaining superior photoredox activity via interfacial coupling.** 

Semiconductor-based photocatalysis offers a clean and sustainable approach for the exploration of renewable energy and environmental remediation.<sup>[6]</sup> Numerous investigations on the development of efficient photocatalysts for the activation of PMS, such as metal oxides,<sup>[7]</sup> metal sulfides,<sup>[8]</sup> and carbon nitrides,<sup>[9]</sup> have been conducted in the past few decades. However, for single-component photocatalysts, the rapid recombination of photoinduced electron-hole pairs and the poor light-adsorption property, resulting in low photocatalytic activity, greatly restrict their practical application. Construction of built-in electric field (EF) at interface of catalysts is a promising approach to improve the charge carriers’ separation and migration.<sup>[10]</sup> Built-in EF can be created by fabricating of the semiconductor-based junctions, such as _p–n_ homojunction, heterojunction or Schottky junction.<sup>[11]</sup> In this regard, fabrication of heterojunctions seems to be a feasible strategy to improve the performance of the semiconductorbased photocatalysis for PMS activation. 

## **1. Introduction** 

The occurrence of antibiotic-resistant bacteria and antibiotic resistance genes induced by the antibiotic residues in aquatic environments are on the list of the most important public health concerns of this century (World Health Organization).<sup>[1]</sup> Effluents from wastewater treatment plants are the main 

M. Qian, X.-L. Wu, M. Lu, L. Huang, W. Li, H. Lin, J. Chen College of Geography and Environmental Science Zhejiang Normal University Jinhua 321004, China E-mail: dbwxl@zjnu.cn S. Wang, X. Duan School of Chemical Engineering and Advanced Materials The University of Adelaide Adelaide, SA 5005, Australia E-mail: xiaoguang.duan@adelaide.edu.au 

Single-atom catalysts (SACs) are defined as catalysts containing atomically dispersed metal sites anchored on the support.<sup>[12]</sup> SACs can minimize the consumption of transition and noble metals and maximize the exposure of active sites via robust coordination, thus delivering excellent catalytic activity, selectivity and durability.<sup>[13,14]</sup> As emerging multifunctional materials, SACs have shown great promise for the treatment of organic pollutants via the heterogeneous activation of PMS. The single atom sites of Cu-N4,<sup>[5]</sup> Co-N4,<sup>[15]</sup> CoN2+2<sup>[16]</sup> and Fe-N4 anchored on various substrates empower SACs as efficient catalysts for PMS activation. Despite that a myriad of studies 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202208688. 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution-NonCommercial License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited and is not used for commercial purposes. 

**DOI: 10.1002/adfm.202208688** 

**2208688 (1 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

have reported the design and synthesis of SACs with wellidentified coordination and electronic structures, SACs-based heterojunctions are less explored. Fabricating SACs/semiconductor heterojunctions will combine the benefits of SACs and  photocatalysts, enhancing the performance and triggering other functions. 

In this study, heterojunctions of single-atom Co supported on N-rich carbons (SA-Co-CN) and graphitic carbon nitride (g-C3N4) were constructed and applied as heterogeneous catalysts for PMS activation. The heterojunctions facilitated the electron communication between the SACs and the photocatalysts within the nanocomposite, thereby boosting the catalytic performance of the SA-Co-CN/g-C3N4 in photo-Fenton-like reactions. The degradation of various antibiotics via PMS activation using SA-Co-CN/g-C3N4 was studied. Primary ROS generated in the SA-Co-CN/g-C3N4/PMS/vis system were identified by quenching experiments and electron paramagnetic resonance (EPR) spectroscopy, and further quantified by a series of colorimetric analyses. Besides, the charge transfer process was revealed by femtosecond transient absorption (fs-TA) spectroscopy and density functional theory (DFT) calculations. We propose the concept of single-atom “islands” 

in this work, which provides a new tactic for enhancing the performance of SACs. 

## **2. Results and Discussion** 

### **2.1. Theoretical Calculations** 

In this proof-of-concept study, DFT calculations were first performed to reveal the electronic structure and electron-transfer behavior of the in-plane heterostructures. From the total density of states (TDOS) of g-C3N4 ( **Figure 1** a), a large energy gap between the top of the valence band (VB) and the bottom of the conduction band (CB) is observed. TDOS of SA-Co-CN/gC3N4 exhibits a much narrower band gap with the VB crossing the Fermi level (Figure 1b), which facilitates the electron transitions between the energy levels.<sup>[14]</sup> Strong hybridization of the electronic orbits between SA-Co-CN and g-C3N4 can be observed from TDOS of SA-Co-CN/g-C3N4, implying the easy charge transfer across the heterostructure. Furthermore, charge distributions of g-C3N4 and SA-Co-CN/g-C3N4 upon one extra e<sup>-</sup> or h<sup>+</sup> injection were evaluated by Bader charge analysis 



**Figure 1.** a) TDOS of g-C3N4 and b) SA-Co-CN/g-C3N4. c) Bader charge of SA-Co-CN/g-C3N4 and SA-Co-CN/g-C3N4 upon excitation by one extra e<sup>-</sup> . d) Schematic illustration of the charge transfer between the heterojunction of SA-Co-CN and g-C3N4. 

**2208688 (2 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

(Figure S1, Supporting Information). For pristine g-C3N4, the holes only accumulate on _N_ atoms (0.94 h<sup>+</sup> ), while the electrons are mainly distributed on _C_ atoms (0.26 e<sup>-</sup> ) and _N_ atoms (0.57 e<sup>-</sup> ). For the SA-Co-CN/g-C3N4, the electrons and holes are primarily distributed on _C_ atoms (0.66 e<sup>-</sup> and 0.63 h<sup>+</sup> ) and _N_ atoms (0.33 e<sup>-</sup> and 0.31 h<sup>+</sup> ), suggesting the more delocalization of the charge carriers in the SA-Co-CN/g-C3N4. More interestingly, the electrons and holes are inclined to accumulate in the domains of SA-Co-CN (0.52 e<sup>-</sup> and 0.43 h<sup>+</sup> ) and g-C3N4 (0.47 e<sup>-</sup> and 0.51 h<sup>+</sup> ), respectively, which is indicative of the efficient charge separation between the heterojunction of SA-Co-CN and g-C3N4.<sup>[17]</sup> Thus, the efficient charge delocalization and separation in the heterostructure will certainly boost the photocatalytic performance of SA-Co-CN/g-C3N4.<sup>[18,19]</sup> As compared with the Bader charge of SA-Co-CN/g-C3N4 before and after the injection of one extra e<sup>-</sup> (Figure 1c), partial electron is also distributed over the Co-N4 sites (0.11 e<sup>-</sup> ). Thereby, the heterostructure could modulate the charge transfer and trapping behavior to boost the redox reaction of the Co single sites (Figure 1d). 

### **2.2. Synthesis and Characterization** 

Inspired by the above theoretical predictions, a heterojunction between single-atom Co catalyst and g-C3N4 was fabricated using a facile co-calcination method. Prussian blue analog (Co3[Co(CN)6]2, PBA-Co),<sup>[20]</sup> a common type of metal-organic framework, was applied as the precursor for the synthesis of island-like Co-CN SACs. The polymer precursor (PEI-MCA) made from melamine (M), cyanuric acid (CA) and polyethyleneimine (PEI) was applied for the fabrication of g-C3N4.<sup>[21]</sup> The heterojunction of SA-Co-CN/g-C3N4 was prepared by calcinating the mixture of PBA-Co and PEI-MCA at 550 °C for 2 h under the N2 atmosphere. Scanning electron microscopy (SEM) and transmission electron microscopy (TEM) observations show that the size of Co3[Co(CN)6]2 nanoparticles (NPs) are in the range of 100–200 nm, with a polyhedral structure (Figure S2, Supporting Information). All the X-ray diffraction (XRD) peaks in Figure S3 (Supporting Information) are assigned to the face-centered cubic phase of Co3[Co(CN)6]2 (JCPDF No.77-1161).<sup>[20]</sup> From the SEM and TEM images, g-C3N4 possesses a sheet-like structure with abundant mesopores on its surface (Figure S4, Supporting Information). SA-Co-CN/g-C3N4 has a similar morphology to polyhedral Co-CN NPs embedded in the g-C3N4 ( **Figure 2** a; Figure S5, Supporting Information). The high-resolution TEM (HR-TEM) image (Figure 2b) of the SA-Co-CN/g-C3N4 reveals the formation of heterojunctions between amorphous Co-CN and g-C3N4. From the high-angle annular dark-field scanning TEM (HAADF-STEM) image (Figure 2c), densely distributed bright spots (marked with circles) are observed in the domain of Co-CN, corresponding to the atomically dispersed Co atoms. During the high-temperature calcination process, Co3[Co(CN)6]2 NPs were carbonized and transformed into the single-atom Co sites anchored on the CN (SA-Co-CN). TEM image (Figure 2d) and the corresponding energy dispersive X-ray spectroscopy (EDX) mapping images (Figure 2e,f) show the homogeneous distribution of _C_ and _N_ elements over SA-Co-CN/g-C3N4, while the Co element is almost solely distributed within Co-CN NPs (Figure 2g), 

indicating the formation of the island-like Co-CN catalyst supported on g-C3N4. Electron Energy Loss Spectroscopy (EELS) was applied to analyze the Co contents along the SA-Co-CN/gC3N4 heterojunction (Figure S6, Supporting Information). The tested position is marked with 1 and the corresponding EELS spectra shows the Co elements are mainly distributed in the SA-Co-CN domain and almost no Co signals can be detected with increasing the distance away from the SA-Co-CN domain, suggesting the short-range and small amount of Co diffusion. 

The XRD pattern (Figure 2h) of SA-Co-CN/g-C3N4 only shows the graphitic peak for g-C3N4 without any impurity phase (metallic cobalt or cobalt oxides),<sup>[22]</sup> indicating that there is no Co NPs in the sample. The Co-contents were controlled by varying the mass ratio of PBA-Co in the precursor. The Co-loading amounts in the various SA-Co-CN/g-C3N4 samples were detected by using inductively coupled plasma mass spectrometry (ICP-MS). The results show that the Co-contents are varied from 3.7% to 14.7% (wt.%) (Table S2, Supporting Information). Furthermore, the XRD patterns of all the SA-Co-CN/gC3N4 samples (Figure S7, Supporting Information) only display the peak for g-C3N4, indicating that the loading of SA-Co-CN have not changed the main structure of g-C3N4 and no Co NPs are formed even at high Co-loading. The control samples were prepared by calcination of the precursors at various temperatures. As can be seen from the XRD patterns (Figure S8, Supporting Information), pure PBA-Co keeps its structure at calcination temperature of 400 °C, but it transforms into Co NPs at 550 and 700 °C. The changes of the phases of PBA-Co are also verified by TEM (Figure S9, Supporting Information). In addition, SA-Co-CN/g-C3N4 heterojunction is also formed by calcination of the mixture of PBA-Co and PEI-MCA at 400 °C, but it transforms into carbon nanotubes encapsulated with Co NPs at 700 °C (Figures S10 and S11, Supporting Information). The reason that PBA-Co transforms into SA-Co-CN at 550 °C could be due to the stabilization of PBA-Co NPs by the g-C3N4 substrate, thus realizing the formation of SA-Co-CN/g-C3N4 heterojunctions. 

The N 1s X-ray photoelectron spectroscopy (XPS) spectra of the g-C3N4 and SA-Co-CN/g-C3N4 are deconvoluted into three peaks at 398.2, 399.9 and 401.0 eV (Figure 2i), corresponding to pyridinic N, pyrrolic N, and graphitic N, respectively.<sup>[14,23]</sup> From the Co 2p XPS spectra (Figure 2j), the SA-Co-CN/g-C3N4 displays lower binding energy for the Co 2p1/2 and Co 2p3/2 orbits as compared with Co3[Co(CN)6]2, revealing the stronger interactions between Co single sites and the CN substrate. From the Co K-edge XANES spectra, the absorption edge of SA-Co-CN/gC3N4 is situated at higher energy than the reference samples (Figure 2k), indicating the average valence state of Co in SACo-CN/g-C3N4 is greater than +2. In the Fourier transformed extended X-ray absorption fine structure (FT-EXAFS) spectra (Figure 2l), SA-Co-CN/g-C3N4 and phthalocyanine cobalt (CoPc) show one distinct peak at ≈1.5 Å, which is due to the Co-N first coordination shell.<sup>[24]</sup> While the peak for Co-Co coordination (≈2.2 Å) is not observed, suggesting the absence of Co clusters or NPs in SA-Co-CN/g-C3N4.<sup>[24]</sup> The fitted EXAFS spectra (Figure 2m) and the corresponding fitting parameters (Table S3, Supporting Information) reveal that the Co atom is coordinated with four N atoms with a bond length of ≈2.0 Å (inset in Figure 2m). The wavelet transforms (WT) EXAFS spectra show 

**2208688 (3 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 2.** a) TEM image, b) HR-TEM image, c) HAADF-STEM image, and d–g) TEM image and the corresponding EDX mapping of SA-Co-CN/gC3N4. h) XRD patterns of g-C3N4 and SA-Co-CN/g-C3N4. i) High resolution N 1s XPS spectra and j) Co 2p XPS spectra of the samples. k) Co K-edge XANES and l) Fourier-transformed EXAFS of Co foil, CoPC and SA-Co-CN/g-C3N4. m) The corresponding EXAFS fitting of SA-Co-CN/g-C3N4 at R space. n) Wavelet transform for the EXAFS signals. 

WT intensity maximum of SA-Co-CN/g-C3N4 located at ≈1.5 Å for R space and 4.5 Å<sup>-1</sup> for k space (Figure 2n), corresponding to the signal of the Co-N coordination. These results collectively demonstrate the successful fabrication of heterojunctions between island-like single-atom Co catalyst and g-C3N4 photocatalyst, which may facilitate the electron communications at the heterostructure interface. The single-atom Co embedded in the matrix of g-C3N4 (SA-Co-g-C3N4) as the control sample was fabricated and characterized by XRD, TEM, HAADF-STEM and XAFS (Figure S12 and Table S2, Supporting Information). The characterization results verify the successful fabrication of SA-Co-g-C3N4 with Co-N4 coordination. 

From the UV-vis diffuse reflectance spectra (DRS) ( **Figure 3** a) and photoluminescence (PL) emission spectra (Figure S13a, 

Supporting Information), it can be observed that SA-CoCN/g-C3N4 well inherits the light absorption and emission feature of g-C3N4 with enhanced light-harvesting property and suppressed electron-hole recombination.<sup>[22]</sup> From the UV-vis DRS and the corresponding Tauc plots (Figure S13b,c, Supporting Information), the bandgaps of the g-C3N4 and SACo-CN/g-C3N4 are determined to be 2.39 and 2.09 eV, respectively. From the XPS valence band (VB) spectra (Figure S13d, Supporting Information), the VB maximum decreases from 1.72 eV for g-C3N4 to 1.03 eV for SA-Co-CN/g-C3N4. From the UV photoelectron spectroscopy (Figure S13e, Supporting Information),<sup>[25]</sup> the VB energy (vs. RHE) of SA-CoCN/g-C3N4 is converted to be 2.74 V. Based on the bandgap values and the VB energy, the band structures of g-C3N4 and 

**2208688 (4 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 3.** a) UV-vis DRS, b) transient photocurrent responses, and c) Zeta potential of g-C3N4, SA-Co-g-C3N4 and SA-Co-CN/g-C3N4. d) Surface potentials of the SA-Co-CN/g-C3N4 heterojunction measured by KPFM. 

SA-Co-CN/g-C3N4 are outlined in Figure S13f (Supporting Information). The formation of the heterojunctions obviously narrows the intrinsic bandgap of the SA-Co-CN/g-C3N4, giving rise to the enhanced production of photogenerated charge carriers. 

From the UV-vis DRS (Figure 3a), it is found that pure g-C3N4 and SA-Co-C3N4 have poorer light-harvesting properties as compared with SA-Co-CN/g-C3N4. Besides, the photocurrent densities of pure g-C3N4 and SA-Co-C3N4 are almost the same, but much smaller than that of SA-Co-CN/g-C3N4 (Figure 3b), indicating the promoted production and transportation of charge carriers in the heterostructure.<sup>[25]</sup> The improved separation and migration of the charge carriers could be due to the strong built-in EF across the SA-Co-CN/g-C3N4 heterojunction. According to Poisson’s equation-derived Kanada model, the built-in EF has high-positive correlation with the Zeta potential.<sup>[26]</sup> As shown in Figure 3c, the absolute value of the Zeta potential for SA-Co-CN/g-C3N4 (-33.5 mV) is 5.5 times and 17.6 times of that for SA-Co-g-C3N4 (-6.1 mV) and g-C3N4 (−1.9 mV), respectively, suggesting the presence of strong built-in EF in the SA-Co-CN/g-C3N4 heterojunction. The surface potential across the SA-Co-CN/g-C3N4 heterojunction was measured by Kelvin Probe Force Microscopy (KPFM). As shown in Figure 3d, the SA-Co-CN/g-C3N4 possesses large surficial electrostatic potential (64.9 mV), implying the presence of strong internal electric field across the heterojunction. Thus, driven by the strong built-in EF, the SA-Co-CN/g-C3N4 heterojunction can significantly promote the separation and transportation of the photogenerated charge carriers.<sup>[27]</sup> The decay curves of time- 



<!-- Start of picture text -->
resolved PL spectroscopy are fitted by the biexponential decay<br>equation: [22,28]<br>I t = I 0 + A 1 exp(− t /τ1) + A2 exp(− t /τ2 ) (1)<br><!-- End of picture text -->

where _I_ is PL intensity, _τ1_ and _τ2_ are decay times, and A1 and A2 are the corresponding PL amplitudes. As shown in Figure S14 (Supporting Information), SA-Co-CN/g-C3N4 possesses a longer average lifetime ( _τ_ average) of the charge carriers compared with pure g-C3N4, confirming the efficient charge transfer in the SACo-CN/g-C3N4 heterostructure.<sup>[25]</sup> The Mott–Schottky (M–S) plots of g-C3N4 and SA-Co-CN/g-C3N4 (Figure S15, Supporting Information) have positive slopes, which are the characteristics of _n_ -type semiconductors. The charge carrier density ( _N_ D) of the catalysts can be calculated from the slope of the M–S plots via the following equation:<sup>[29]</sup> 



<!-- Start of picture text -->
2 1<br>N D = (2)<br>qεε0 slope<br><!-- End of picture text -->

Herein, _q_ , _ε_ and _ε_ 0 are all the related constants,<sup>[29]</sup> thus _N_ D is inversely proportional to the slope of the M–S curves. As shown in Figure S15 (Supporting Information), SA-Co-CN/gC3N4 has a smaller M–S slope than g-C3N4, which reflects its higher charge carrier density. From the electrochemical impedance spectra (EIS) Nyquist plots (Figure S16, Supporting Information),<sup>[30]</sup> the EIS arc radius of SA-Co-CN/g-C3N4 is smaller than that of pure g-C3N4 both under dark and visible light irradiation, which is indicative of the less charge-transfer resistance of SA-Co-CN/g-C3N4. These results collectively demonstrate that the strong built-in EF across the heterojunctions 

**2208688 (5 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

between Co-CN SACs and g-C3N4 remarkably promotes the charge separation and migration. 

### **2.3. Catalytic Performance Evaluation** 

A proof-of-concept study was carried out using SA-Co-CN/gC3N4 as the catalyst to activate PMS for antibiotic wastewater treatment. The strategic growth of SA-Co “island” on the g-C3N4 substrate enhances the electron-transfer process via the heterojunctions, boosting surface redox reaction and facilitating ROS production. Norfloxacin (NOR) was selected as a model antibiotic to evaluate the catalytic performance of SA-Co-CN/g-C3N4. As shown in Figure S17 (Supporting Information), the catalytic performance of the SA-Co-CN/g-C3N4 is first enhanced and then keeps almost unchanged with the increasing of PBA-Co loading from 0.05 to 0.1 g and then from 0.1 to 0.2 g in the precursor, respectively. Thus, the PBA-Co loading is optimized to be 0.1 g with Co-content of 7.3% (wt.%) in the SA-Co-CN/g-C3N4 (Table S1, Supporting Information). As shown in **Figure 4** a, the removal percentage of NOR reaches 10.8% and 8.3% in the vis/ PMS and g-C3N4/PMS systems in 30 min, respectively, indicating that visible light and g-C3N4 alone are inactive for PMS activation. Moreover, photocatalysis is also inefficient for NOR degradation, with ≈7.0% and 10.9% removal in the g-C3N4/Vis and SA-Co-CN/g-C3N4/vis systems, respectively. Only 11.7% of NOR is eliminated in the g-C3N4/PMS/vis system, which 

confirms the low activity of g-C3N4. While ≈37.9% of NOR is degraded in the SA-Co-CN/g-C3N4/PMS system, owing to the high intrinsic activity of the Co single sites for PMS activation. Surprisingly, NOR degradation reaches ≈100% in the SA-CoCN/g-C3N4/PMS/vis system, demonstrating the remarkably enhanced catalytic performance of SA-Co-CN/g-C3N4 under light irradiation. These findings show that the catalytic performance of SA-Co-CN/g-C3N4 is remarkably boosted by efficient electron transfer within the heterojunctions and synergy of heterogeneous single-atom catalysis and photocatalysis. The NOR degradation percentages are positively correlated with PMS consumption in both SA-Co-CN/g-C3N4/PMS and SA-Co-CN/gC3N4/PMS/vis systems (Figure S18, Supporting Information), confirming the catalytic oxidation process is mainly contributed by PMS activation. Furthermore, ≈81.6% of the total organic carbon (TOC) is removed for NOR degradation (Figure S19, Supporting Information), implying the high mineralization capacity of the SA-Co-CN/g-C3N4 mediated photo-Fenton-like system. The observed kinetic rate constants ( _k_ obs) for NOR degradation in the various systems were calculated by the pseudofirst-order kinetic model (Figure 4b; Figure S20, Supporting Information). As expected, the value of _k_ obs (0.2601 min<sup>-1</sup> ) for the SA-Co-CN/g-C3N4/PMS/vis system is ≈20–220 times greater than the above-mentioned individual and uncoupled systems, indicating the synergistically enhanced PMS activation by the SA-Co-CN/g-C3N4 heterojunctions under visible light irradiation. 



**Figure 4.** a) NOR degradation efficiency and b) the corresponding kinetic rate constants in the various systems. c) Cyclic degradation of NOR and d) the degradation of various antibiotics in the SA-Co-CN/g-C3N4/PMS/Vis system. (Reaction condition: [Pollutants] = 20 mg L<sup>-1</sup> , [PMS] = 0.4 g L<sup>-1</sup> , [catalyst] = 0.2 g L<sup>-1</sup> and pH = 6.0). 

**2208688 (6 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

As shown in Figure S21 (Supporting Information), both pure PBA-Co and SA-Co-g-C3N4 are inferior to the SA-Co-CN/g-C3N4 for catalytic degradation of NOR in terms of the degradation efficiency and kinetics. Furthermore, concentrations of leached Co ions in the catalytic systems were monitored by ICP-MS. As shown in Table S4 (Supporting Information), the leached Co ions in the SA-Co-CN/g-C3N4/PMS/vis systems are all below 0.6 mg L<sup>-1</sup> at the pH range of 3–11, which are much lower than that in the PBA-Co/PMS/Vis system (1.0–22.0 mg L<sup>-1</sup> ). For comparison, Co<sup>2+</sup> ions were applied as the catalyst for PMS activation (Figure S22, Supporting Information). The results show that both Co<sup>2+</sup> /PMS and Co<sup>2+</sup> /PMS/vis systems exhibit low degradation efficiency and sluggish degradation kinetic for NOR degradation. Thus, driven by the built-in EF, the SA-Co-CN/gC3N4 outperforms the homogeneous (Co<sup>2+</sup> ions) and heterogeneous (SA-Co-g-C3N4) counterparts for the photo-Fenton-like reaction. Additionally, SA-Co-CN/g-C3N4 achieves a wide operating pH range and excellent reusability with NOR degradation maintained over 90% over pH 3–11 (Figure S23, Supporting Information) and ten cycles (Figure 4c), respectively. After 24 h continuous operation, the SA-Co-CN/g-C3N4/PMS/vis system shows no significant decay in the catalytic performance for NOR degradation (Figure S24, Supporting Information), suggesting its excellent stability for the photo-Fenton-like reaction. As compared with the state-of-the-art catalysts such as SA-Fe-gC3N4, SA-Co@g-C3N4, Co-C3N4 etc. (Table S5, Supporting Information), the SA-Co-CN/g-C3N4 exhibits better or comparable performance for elimination of pollutants in terms of the degradation efficiency and cycling performance. The SA-Co-CN/gC3N4/PMS/vis systems are also effective in the elimination of sulfamethoxazole (SMX), meropenem (MEM), amoxicillin (AML), tetracycline hydrochloride (TCH) and metronidazole (MNZ) with the removal percentages reaching 100%, 100%, 100%, 100%, and 98.7%, respectively (Figure 4d). These results suggest the great potential of the SA-Co-CN/g-C3N4 catalyst for antibiotic wastewater treatment. 

### **2.4. Generation of ROS** 

ROS produced in the SA-Co-CN/g-C3N4/PMS/vis system were identified and quantified. Methanol (MeOH) for both •OH and SO4<sup>•–</sup> ,<sup>[31]</sup> tert-butanol (TBA) for •OH, nitro blue tetrazolium (NBT) for O2<sup>•–</sup> and furfuryl alcohol (FFA) for<sup>1</sup> O2 were applied as the scavengers for quenching experiments (Figure S25, Supporting Information).<sup>[32,33]</sup> NOR removals are inhibited by 61.3% and 75.4% after adding TBA and MeOH, respectively, unveiling the dominant role of the radical species (•OH and SO4<sup>•–</sup> ) for NOR oxidation. In addition, NOR degradation is inhibited by 1.8% and 32.3% after adding NBT and FFA into the reaction system, respectively, implying O2<sup>•–</sup> is not the dominant ROS. The ROS was further identified by EPR spectroscopy with DMPO and TEMP as the spin-trapping reagent. As shown in **Figure 5** a, the observed EPR signals for •OH/SO4<sup>•–</sup> in the SACo-CN/g-C3N4/PMS/vis system are much stronger than that in the g-C3N4/PMS, g-C3N4/PMS/Vis and SA-Co-CN/g-C3N4/PMS systems, confirming the significantly enhanced PMS activation under visible light. These findings imply the synergistic effect between visible light and Co SACs to promote the elec- 

tron transfer across the SA-Co-CN/g-C3N4 heterojunction, subsequently accelerating the redox cycle of Co<sup>2+</sup> /Co<sup>3+</sup> for PMS activation (Equations 3–5). The maintained Co<sup>2+</sup> /Co<sup>3+</sup> cycle (Equation 6) can be verified by the strong Co<sup>2+</sup> signals in the Co 2p XPS spectrum of the recycled SA-Co-CN/g-C3N4 (Figure S26, Supporting Information). Figure 5b shows that DMPO-O2<sup>•–</sup> signals cannot be observed in the catalytic systems without visible light, suggesting that O2<sup>•–</sup> radicals are solely generated by photocatalysis. As shown in Figure 5c, The TEMP-<sup>1</sup> O2 signals are much stronger in the SA-Co-CN/g-C3N4/PMS and SA-Co-CN/gC3N4/PMS/Vis systems than in the g-C3N4/PMS and g-C3N4/ PMS/Vis systems, indicating the SA-Co-CN promotes the generation of<sup>1</sup> O2 via PMS activation (Equations 7 and 8).<sup>[34]</sup> 



<!-- Start of picture text -->
Co2+ + HSO5− → Co3+ + SO•4− + OH− (3)<br>Co2+ + HSO5− → Co3+ + SO24− + •OH (4)<br>SO•4− + H2O → SO24− + •OH + H+ (5)<br>Co3+ + e− → Co2+ (6)<br><!-- End of picture text -->



<!-- Start of picture text -->
Co3+ + HSO5− → Co2+ + SO•5− + H+ (7)<br><!-- End of picture text -->



<!-- Start of picture text -->
2SO•5− → 2SO24− + 1O2 (8)<br><!-- End of picture text -->

The ROS concentrations in different systems were determined. As can be seen from Figure 5d, a large amount of •OH is produced in the SA-Co-CN/g-C3N4/PMS/vis system within 15 min, which is responsible for the rapid oxidation of NOR. In contrast, the concentrations of •OH and<sup>1</sup> O2 are much lower in individual systems of SA-Co-CN/g-C3N4/PMS and SA-Co-CN/gC3N4/vis. The concentrations of O2<sup>•–</sup> and<sup>1</sup> O2 are much lower than •OH in all three systems, which confirms their insignificant contributions to NOR degradation. This is in accordance with the above experimental results and EPR analysis. Moreover, Figure S27 (Supporting Information) shows that a considerable amount of<sup>1</sup> O2 but fewer •OH is produced in the g-C3N4/ PMS/vis system compared with the SA-Co-CN/g-C3N4/PMS/ vis system, which verifies the critical role of the single-atom Co sites to generate ROS via heterogeneous PMS activation.<sup>1</sup> O2 is a selective ROS while •OH is non-selective, and the redox potential of •OH (2.8 V) is greater than<sup>1</sup> O2 (2.2 V).<sup>[33,35]</sup> Thus, •OH as the main ROS accounts for the oxidation and mineralization of antibiotics. These results collectively corroborate the above assumptions that ROS production is boosted by the synergistic combination of island-like Co-CN SACs with the photoactive g-C3N4 substrates. 

### **2.5. Electron Transfer Process** 

The interactions and electron transfer between the catalyst and PMS were monitored by in situ Raman spectroscopy and electrochemical measurements. As shown in Figure 5e, the sharp peak centered at ≈984 cm<sup>-1</sup> is assigned to SO4<sup>2–</sup> , and the peaks located at 889 and 1062 cm<sup>-1</sup> are ascribed to HSO5<sup>–</sup> .<sup>[36]</sup> The Raman peak of OO bond in PMS (HSO5<sup>–</sup> ) for the SA-CoCN/g-C3N4/PMS and SA-Co-CN/g-C3N4/PMS/Vis systems both 

**2208688 (7 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 5.** a–c) EPR spectra, d) the yield of ROS, and e) in situ Raman spectra of the various system. f) OCP of the g-C3N4/PMS and SA-Co-CN/g-C3N4/ PMS systems under dark or light irradiation. g) Amperometric _i-t_ curves of the g-C3N4/PMS and SA-Co-CN/g-C3N4/PMS systems under light irradiation. 

shifts to smaller wave number, which is ascribed to the strong interactions between PMS and the surface active sites of SA-CoCN/g-C3N4.<sup>[32,33]</sup> Subsequently, the strong interactions facilitates electron-transfer from the single-atom Co sites to the adsorbed PMS, promoting the break of OO bonds in PMS (HO–OSO3<sup>–</sup> ) to produce the reactive radical species. As compared with the SA-Co-CN/g-C3N4/PMS system, the faster consumption of PMS leads to observably decrease of the peak intensities for PMS in the SA-Co-CN/g-C3N4/PMS/vis system, implying enhanced catalytic performance of the SA-Co-CN/g-C3N4 under light irradiation. The electron-transfer process in the reaction systems was further explored by monitoring the changes in the open circuit voltage (OCP) and amperometric _i-t_ curves with time. Compared with the g-C3N4/PMS and g-C3N4/PMS/vis systems, the SA-Co-CN/g-C3N4/PMS and SA-Co-CN/g-C3N4/PMS/vis systems show significant increases in OCP signals (Figure 5f), proving the enhanced electron transfer from the Co single sites to PMS and the increased surface potential of the catalyst.<sup>[32]</sup> 

Compared with the weak photocurrent response of the g-C3N4 (Figure 5g), SA-Co-CN/g-C3N4 emerges an obvious reverse current signal promptly with the injection of PMS, which corroborates the efficient electron transfer from single Co sites to PMS. These results demonstrate enhanced PMS activation via efficient interfacial charge transfer mediated by the island-like single-atom Co catalyst. 

The electronic communications between the heterostructures of SA-Co-CN and g-C3N4 were unveiled by fs-TA spectroscopy upon 360 nm excitation. As illustrated in **Figure 6** a, the fs-TA spectra of g-C3N4 exhibit broad and continuous negative absorption signals (370–640 nm), whereas the negative absorption signals for SA-Co-CN/g-C3N4 range from 370 to 570 nm (Figure 6b). The negative absorption signals are ascribed to stimulated emission and bleaching of the ground state (GS).<sup>[37]</sup> Surprisingly, a positive absorption band (570–670 nm) stemming from the excited-state absorption is observed in the fs-TA spectra of SA-Co-CN/g-C3N4, suggesting the presence of 

**2208688 (8 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 6.** fs-TA spectra of a) g-C3N4 and b) SA-Co-CN/g-C3N4. The corresponding TA kinetics for c) g-C3N4 and d) SA-Co-CN/g-C3N4.g-C3N4. Schematic representation of proposed charge trapping model in e) g-C3N4, and f) SA-Co-CN/g-C3N4. 

abundant shallowly trapped electrons in SA-Co-CN/g-C3N4.<sup>[38,39]</sup> The negative signals of both samples show a fast increase in the peak intensity at the early time scale after photoexcitation (insets in Figure 6a,b), owing to the instantaneous generation of the charge carriers along with their direct excitation from GS to the emissive state. Shortly after that, the negative signals gradually decay (8 ps-2.5 ns), due to the recombination of photo- generated electron-hole pairs.<sup>[38]</sup> Deep charge trapping is induced by the insufficient extrinsic driving force in the photocatalyst which leads to the depopulation of photoactive species.<sup>[40]</sup> The generation of shallow trapped excitation in SACo-CN/g-C3N4 is beneficial for preserving photoinduced charges to participate in surface photocatalytic reactions. These results demonstrate the regulated trapping behavior of  photoinduced electrons by the island-like single-atom Co catalyst, which will enhance the photo-redox reactions due to the populated charge carriers. The dynamical decay traces of the photo-excited charge carriers in g-C3N4 and SA-Co-CN/g-C3N4 were probed 

at 380 nm (Figure 6c,d). A tri-exponential decay function was applied to fit the kinetics traces. For g-C3N4, the decay lifetimes of _τ_ 1 = 5.4 ps and _τ_ 2 = 54.7 ps are assigned to electron transfer to the shallow trapping state (TS) and deep TS,<sup>[41]</sup> respectively, and _τ_ 3 = 1167.1 ps is due to the recombination of the shallowtrapped electrons with holes.<sup>[42]</sup> The intrinsic deep TS of pure g-C3N4 would trap charges deeply, which is photocatalytic inertness and would restrain the electron transfer for surface redox reactions.<sup>[37]</sup> It is interesting to note that SA-Co-CN/gC3N4 possesses two fast decay components, owing to the electron transfer to the SA-Co-CN trapping sites ( _τ_ 1 = 4.5 ps) and to shallow ST ( _τ_ 1 = 5.4 ps), respectively. The fs-TA decay behavior of SA-Co-CN/g-C3N4 differs from pure g-C3N4, confirming the optimized charge trapping and transportation by the islandlike Co-CN SACs. These results are in good agreement with the theoretical predictions. Thus, driven by the strong built-in EF, the cascade electron transfer across the SA-Co-CN/g-C3N4 heterojunction leads to the enhanced degradation of emerging 

**2208688 (9 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

organic micropollutants via heterogeneous photo-Fenton-like reactions. 

## **3. Conclusion** 

In summary, we have successfully designed and fabricated the heterojunctions of Co-CN SACs and g-C3N4. Photoelectrochemical and fs-TA analysis certified the efficient separation and fast transportation of charge carriers in the heterostructure. The modulated charge trapping behavior by the islandlike Co SACs significantly improved the catalytic performance of SA-Co-CN/g-C3N4 in photo-Fenton-like reactions. Quenching experiments, EPR and quantitative analysis demonstrated the production of large amounts of ROS in the SA-Co-CN/g-C3N4/ PMS/vis system, contributing to the enhanced degradation of various antibiotics in the aqueous solution. This proof-of-concept work provides a promising strategy for the rational design of SACs-based heterojunctions for photocatalysis and environmental remediation. 

## **4. Experimental Section** 

_Catalysts Synthesis_ : All the chemicals were analytic grade and listed in the Supporting Information. For synthesizing prussian blue analogue (PBA-Co, Co3[Co(CN)6]2), 0.04 mmol of K3[Co(CN)6]2 and 0.3 g of sodium dodecylbenzene sulfonate were dissolved in 10 mL distilled water. Then, 0.075 mmol Co(CH3COO)2•nH2O dissolved in 10 mL distilled water was dropwise added into the above K3[Co(CN)6]2 solution under vigorous stirring. After 24 h of aging, pink precipitation was obtained and separated by filtration, then washed by distilled water and ethanol for several times, respectively. The colloidal polymer precusor PEI-MCA was prepared by assembling melamine (M), cyanuric acid (CA) and polyethyleneimine (PEI) in an aqueous solution according to the previous study.<sup>[33]</sup> For the fabrication of SA-Co-CN/g-C3N4, 0.1 g of Co3[Co(CN)6]2 and 1.25 g of PEI-MCA were dispersed in 15 mL distilled water separately and mixed under vigorous stirring. After continuously stirring for 4 h at room temperature, the mixture was filtered and dried at 60 °C overnight. Then the solid was ground into powder and calcined at 550 °C for 2 h under N2 atmosphere. The obtained brown product (SA-Co-CN/g-C3N4) was collected after the oven was cooled to room temperature. The control samples were fabricated by varying the mass ratio of PBA-Co to PEI-MCA from 0.05:1.25, 0.15:1.25, to 0.2:1.25, and the products were denoted as 0.05-Co-CN/g-C3N4, 0.15-Co-CN/g-C3N4 and 0.2-Co-CN/g-C3N4, respectively. The pure g-C3N4 was obtained following the same calcination procedure by using the polymer precursor as raw material. The SA-Co-g-C3N4 was prepared with the same procedure by using the mixture of CoCl2 and PEI-MCA as the precursor. 

_PMS Activation_ : The catalytic performance of the as-prepared catalysts for PMS activation was systematically studied by using NOR as the target pollutant. A 300 W xenon lamp (PLS-FX300HU, Beijing Perfectlight) with a UV cutoff filter ( _λ_ <420 nm) was used to simulate visible light. The solution pH was adjusted by using 0.1 M HCl or NaOH. Typically, 30 mL of reaction solution containing 20 mg L<sup>-1</sup> of NOR and 0.2 g L<sup>-1</sup> of the catalyst was first stirred in dark for 60 min to achieve the adsorption–desorption equilibrium. Catalytic degradation of NOR was triggered by adding a desired amount of PMS into the above suspension, and the reaction system was immediately subjected to light irradiation. The reaction solution was sampled at the required time intervals, immediately quenched with methanol, and then filtered with a 0.22 µm membrane to remove the solid catalyst. The concentration of NOR was determined by high-performance liquid chromatography (HPLC, Shimadzu 20AV) equipped with a C18 chromatographic column and a UV-vis detector at the detection wavelength of 278 nm. A mixture 

of HPLC grade methanol and water (45/55, v/v) with 0.1% formic acid was used as the mobile phase at a flow rate of 1.0 mL min<sup>-1</sup> . Degradation of other antibiotics (sulfamethoxazole (SMX), meropenem (MEM), amoxicillin (AML), tetracycline hydrochloride (TCH), metronidazole (MNZ)) was performed using the same procedures as mentioned above. The HPLC conditions for the detection of the various antibiotics are listed in Table S1 (Supporting Information). Details for the determination of PMS concentrations and the reusability of catalyst was evaluated by recycling the catalysts from the reaction system after each cycle. The recycled catalyst was washed with deionized water several times and then dried in a vacuum at 60 °C overnight for the next cycle. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

M.Q and X.-L.W. contributed equally to this work. X.-L.W. acknowledges the financial support from the Independent Designing Scientific Research Project of Zhejiang Normal University (2020ZS0302), J. C. acknowledges the Key R&D Project of Zhejiang Province (No. 2021C03163). The authors acknowledge Shenzhen HUASUAN Technology Co. LTD for helping with the DFT calculations. The authors thank the beamline 1W1B of Beijing Synchrotron Radiation Facility (BSRF, Beijing, China) and Shanghai Synchrotron Radiation Facility (SSRF) and the RapidXAFS 1 m (Anhui Absorption Spectroscopy Analysis Instrument Co., Ltd.) for XAS measurements. 

Open access publishing facilitated by The University of Adelaide, as part of the Wiley - The University of Adelaide agreement via the Council of Australian University Librarians. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Data Availability Statement** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

## **Keywords** 

fenton-like reactions, heterojunctions, interfacial charge transfers, photocatalyses, single-atom catalysts 

Received: July 28, 2022 Revised: December 8, 2022 Published online: January 6, 2023 

- [1] P. Kovalakova, L. Cizmas, T. J. McDonald, B. Marsalek, M. Feng, V. K. Sharma, _Chemosphere_ **2020** , _251_ , 126351. 

- [2] I. Michael, L. Rizzo, C. S. McArdell, C. M. Manaia, C. Merlin, T. Schwartz, C. Dagot, D. Fatta-Kassinos, _Water Res._ **2013** , _47_ , 957. 

- [3] Y. Gao, Q. Wang, G. Ji, A. Li, _Chem. Eng. J._ **2022** , _429_ , 132387. 

- [4] J. Wang, R. Zhuan, _Sci. Total Environ._ **2020** , _701_ , 135023. 

**2208688 (10 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [5] F. Chen, X.-L. Wu, L. Yang, C. Chen, H. Lin, J. Chen, _Chem. Eng. J._ **2020** , _394_ , 124904. 

- [6] L. Wang, D. W. Bahnemann, L. Bian, G. Dong, J. Zhao, C. Wang, _Angew. Chem., Int. Ed._ **2019** , _58_ , 8103. 

- [7] J. Jia, D. Liu, S. Wang, H. Li, J. Ni, X. Li, J. Tian, Q. Wang, _Sep. Purif. Technol._ **2020** , _253_ , 117510. 

- [8] X. Wang, Y. Ding, D. D. Dionysiou, C. Liu, Y. Tong, J. Gao, G. Fang, D. Zhou, _Sci. Total Environ._ **2020** , _749_ , 142387. 

- [9] J. M. Dangwang Dikdim, Y. Gong, G. B. Noumi, J. M. Sieliechi, X. Zhao, N. Ma, M. Yang, J. B. Tchatchueng, _Chemosphere_ **2019** , _217_ , 833. 

- [10] Y. Lin, C. Yang, S. Wu, X. Li, Y. Chen, W. L. Yang, _Adv. Funct. Mater._ **2020** , _30_ , 2002918. 

- [11] L. Su, W. Yang, J. Cai, H. Chen, X. Fang, _Small_ **2017** , _13_ , 1701687. 

- [12] W. Chen, J. Pei, C. T. He, J. Wan, H. Ren, Y. Wang, J. Dong, K. Wu, W. C. Cheong, J. Mao, X. Zheng, W. Yan, Z. Zhuang, C. Chen, Q. Peng, D. Wang, Y. Li, _Adv. Mater._ **2018** , _30_ , 1800396. 

- [13] F. Chen, X.-L. Wu, C. Shi, H. Lin, J. Chen, Y. Shi, S. Wang, X. Duan, _Adv. Funct. Mater._ **2021** , _31_ , 2007877. 

- [14] S. Liu, D. Liu, Y. Sun, P. Xiao, H. Lin, J. Chen, X.-L. Wu, X. Duan, S. Wang, _Appl. Catal. B_ **2022** , _310_ , 121327. 

- [15] X. Li, X. Huang, S. Xi, S. Miao, J. Ding, W. Cai, S. Liu, X. Yang, H. Yang, J. Gao, J. Wang, Y. Huang, T. Zhang, B. Liu, _J. Am. Chem. Soc._ **2018** , _140_ , 12469. 

- [16] X. Mi, P. Wang, S. Xu, L. Su, H. Zhong, H. Wang, Y. Li, S. Zhan, _Angew. Chem., Int. Ed._ **2021** , _60_ , 4588. 

- [17] S. Zhang, Y. Liu, P. Gu, R. Ma, T. Wen, G. Zhao, L. Li, Y. Ai, C. Hu, X. Wang, _Appl. Catal. B_ **2019** , _248_ , 1. 

- [18] S. Le, Y. Ma, D. He, X. Wang, Y. Guo, _Chem. Eng. J._ **2021** , _426_ , 130354. 

- [19] S. T. Cate, J. M. Schins, L. D. A. Siebbeles, _ACS Nano_ **2012** , _6_ , 8983. [20] L. Hu, P. Zhang, Q.-W. Chen, J.-Y. Mei, N. Yan, _RSC Adv._ **2011** , _1_ , 1574. 

- [21] P. Wang, P. Xiao, S. Zhong, J. Chen, H. Lin, X.-L. Wu, _J. Mater. Chem. A_ **2016** , _4_ , 15450. 

- [22] H. Zhang, J. Lin, Z. Li, T. Li, X. Jia, X.-L. Wu, S. Hu, H. Lin, J. Chen, J. Zhu, _Catal. Sci. Technol._ **2019** , _9_ , 502. 

- [23] X. Peng, J. Wu, Z. Zhao, X. Wang, H. Dai, L. Xu, G. Xu, Y. Jian, F. Hu, _Chem. Eng. J._ **2022** , _427_ , 130803. 

- [24] X. Zhao, X. Li, Z. Zhu, W. Hu, H. Zhang, J. Xu, X. Hu, Y. Zhou, M. Xu, H. Zhang, G. Hu, _Appl. Catal. B_ **2022** , 300. 

- [25] D. Zhao, Y. Wang, C.-L. Dong, Y.-C. Huang, J. Chen, F. Xue, S. Shen, L. Guo, _Nat. Energy_ **2021** , _6_ , 388. 

- [26] J. Xu, W. Li, W. Liu, J. Jing, K. Zhang, L. Liu, J. Yang, E. Zhu, J. Li, Y. Zhu, _Angew. Chem., Int. Ed._ **2022** , e202212243. 

- [27] L. Zhai, X. She, L. Zhuang, Y. Li, R. Ding, X. Guo, Y. Zhang, Y. Zhu, K. Xu, H. J. Fan, S. P. Lau, _Angew. Chem., Int. Ed._ **2022** , _61_ , e202116057. 

- [28] J. Zhang, S. Wu, T. Liu, Z. Zhu, A. K. Y. Jen, _Adv. Funct. Mater._ **2019** , _29_ , 1808833. 

- [29] C. Zhang, D. Qin, Y. Zhou, F. Qin, H. Wang, W. Wang, Y. Yang, G. Zeng, _Appl. Catal. B_ **2022** , _303_ , 120904. 

- [30] Y. Wang, X. Zhao, D. Cao, Y. Wang, Y. Zhu, _Appl. Catal. B_ **2017** , _211_ , 79. 

- [31] N. Li, R. Li, X. Duan, B. Yan, W. Liu, Z. Cheng, G. Chen, L. Hou, S. Wang, _Environ. Sci. Technol._ **2021** , _55_ , 16163. 

- [32] C. Guo, C. Chen, J. Lu, D. Fu, C. Z. Yuan, X. L. Wu, K. N. Hui, J. Chen, _J. Colloid Interf. Sci._ **2021** , _599_ , 219. 

- [33] J. Lu, C. Chen, M. Qian, P. Xiao, P. Ge, C. Shen, X.-L. Wu, J. Chen, _J. Colloid Interf. Sci._ **2021** , _603_ , 856. 

- [34] L. S. Zhang, X. H. Jiang, Z. A. Zhong, L. Tian, Q. Sun, Y. T. Cui, X. Lu, J. P. Zou, S. L. Luo, _Angew. Chem., Int. Ed._ **2021** , _60_ , 21751. 

- [35] Y. Bu, H. Li, W. Yu, Y. Pan, L. Li, Y. Wang, L. Pu, J. Ding, G. Gao, B. Pan, _Environ. Sci. Technol._ **2021** , _55_ , 2110. 

- [36] H. Dai, W. Zhou, W. Wang, _Chem. Eng. J._ **2021** , _417_ , 127921. 

- [37] L. Jing, R. Zhu, D. L. Phillips, J. C. Yu, _Adv. Funct. Mater._ **2017** , _27_ , 1703484. 

- [38] W. Lei, Y. Mi, R. Feng, P. Liu, S. Hu, J. Yu, X. Liu, J. A. Rodriguez, J.-o. Wang, L. Zheng, K. Tang, S. Zhu, G. Liu, M. Liu, _Nano Energy_ **2018** , _50_ , 552. 

- [39] D. H. K. Murthy, H. Matsuzaki, Z. Wang, Y. Suzuki, T. Hisatomi, K. Seki, Y. Inoue, K. Domen, A. Furube, _Chem. Sci._ **2019** , _10_ , 5353. 

- [40] W. Wang, X. Bai, Q. Ci, L. Du, X. Ren, D. L. Phillips, _Adv. Funct. Mater._ **2021** , _31_ , 2103978. 

- [41] W. Li, Z. Wei, K. Zhu, W. Wei, J. Yang, J. Jing, D. L. Phillips, Y. Zhu, _Appl. Catal. B_ **2022** , _306_ , 121142. 

- [42] W. Wang, Y. Tao, L. Du, Z. Wei, Z. Yan, W. K. Chan, Z. Lian, R. Zhu, D. L. Phillips, G. Li, _Appl. Catal. B_ **2021** , _282_ , 119568. 

**2208688 (11 of 11)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2208688 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

