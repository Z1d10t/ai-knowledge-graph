# Organic flexible electronics with closed-loop recycling for sustainable wearable technology

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 160 |
| 作者 | Haechan Park, Sehyun Kim, Juyeong Lee, Inwoo Lee, Sujitkumar Bontapalle, Younghoon Na, K. Sim |
| DOI | 10.1038/s41928-023-01078-9 |
| 源文件 | 100_Park_2023_Organic-flexible-electronics-with-closed-loop-re.pdf |

---




<!-- Start of picture text -->
Entirely recyclable all -o rganic electronics enabled<br>by closed -l oop recycling for the sustainable future<br>wearable systems<br>Haechan Park<br><!-- End of picture text -->

Ulsan National Institute of Science and Technology (UNIST) 

Ulsan National Institute of Science and Technology (UNIST) 

Ulsan National Institute of Science and Technology (UNIST) 

Ulsan National Institute of Science and Technology (UNIST) 

Ulsan National Institute of Science and Technology (UNIST) 

Ulsan National Institute of Science and Technology (UNIST) 

Kyoseung Sim  (  kyos@unist.ac.kr ) 

Ulsan National Institute of Science and Technology (UNIST) https://orcid.org/0000-0001-5284-6831 

Posted Date: July 7th, 2022 

DOI: https://doi.org/10.21203/rs.3.rs-1680147/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

# **Entirely recyclable all-organic electronics enabled by closed-loop recycling for the** 

# **sustainable future wearable systems** 

Haechan Park<sup>1</sup> , Sehyun Kim<sup>1</sup> , Juyeong Lee<sup>1</sup> , Inwoo Lee<sup>1</sup> , Sujitkumar Bontapalle<sup>1</sup> , Younghoon 

Na<sup>1</sup> , Kyoseung Sim<sup>1,2</sup> * 

1Department of Chemistry, Ulsan National Institute of Science and Technology (UNIST), Ulsan, 

44919, Republic of Korea. 

2Center for Wave Energy Materials, Ulsan National Institute of Science and Technology (UNIST), Ulsan, 44919, Republic of Korea 

*Correspondence to: kyos@unist.ac.kr 

1 

# **Abstract** 

<mark>With growing interest and effort in developing organic electronics for future technologies such as wearable electronics, organic e-wastes generated during synthesis and disposal are becoming an inevitable environmental issue. Organic e-wastes possess unforeseeable potential genotoxicity and cytotoxicity in nature and humans, but efforts to reduce e-wastes have primarily focused on recapturing metallic materials. Here, we report a recyclable organic flexible (ROF) electronic device enabled by closed-loop recycling of entire materials recapturing and reusing through selective dissolution and spin-coating-free fabrication. The ROF electrode and electronics show reliable electrical properties under mechanical bending and after five times recycling. Moreover, ROF transistors and logic gates based on organic semiconductors and dielectrics were fabricated, and recycled devices show no considerable degradation. Finally, we achieved the sustainable devices cycle by reconstructing various ROF electronics using only recycled materials from different functional devices. The ROF electronics</mark> 

<mark>in this work provide a promising strategy for a sustainable future wearable electronic system.</mark> 

2 

# **Introduction** 

<mark>The invention of digital electronics has brought unprecedented convenience to humans, but it inevitably involves environmental issues such as plastic pollution</mark><sup>1</sup> <mark>, hazardous organic waste</mark><sup>2</sup> <mark>, resource depletion</mark><sup>3</sup> <mark>, and electronic waste (e-waste)</mark><sup>4,5</sup> <mark>. Particularly, e-waste associated with the disuse of electronic devices induces highly toxic pollutants, emerging as a severe environmental problem</mark><sup>1,6</sup> <mark>. Consequently, annually increasing demands and resultant large scale manufacture of various electronic devices such as smartphones, electronic tablets, and wearable devices are considered to threaten our health as well as the environment despite their considerable convenience and usefulness</mark><sup>2,7</sup> <mark>.</mark> 

<mark>Although there have been ongoing worldwide efforts to reduce e-waste through various approaches</mark><sup>3,8</sup> <mark>, existing technologies mainly focusing on recycling e-waste from traditional electronic devices are insufficient to apply future technologies, especially flexible electronics for wearable systems, employing advanced materials. Reported rare examples of the recycling of flexible electronics have been achieved by recapturing conductive materials such as silver nanowire</mark><sup>9,10</sup> <mark>and liquid metal</mark><sup>11,12</sup> <mark>, and reuse of substrate</mark><sup>11,13</sup> <mark>. However, such efforts cannot be considered sufficient alternatives for a sustainable future due to the lack of recycling technologies for advanced functional materials, particularly organic electronic materials. As examples of organic electronic materials, organic semiconductors and conductors have been actively developed and studied to be used in various future electronics</mark><sup>14-17</sup> <mark>. However, such materials unavoidably produce various organic waste during the synthesis process. In addition, discharging organic-based new format of e-waste to nature might cause unpredictable potential toxicity to the environment and humans. Indeed, the severe risks of various organic materials for genotoxicity and cytotoxicity in nature have been continuously reported in recent years</mark><sup>2,4,7,18,19</sup> <mark>. Therefore, closed-loop recycling</mark> 

3 

<mark>processes for organic electronics should be achieved for sustainable future wearable electronics.</mark> 

<mark>Here, we present the recyclable organic flexible (ROF) electronic devices that are enabled by recapturing and reusing the entire electronic materials. This report achieved the successful closed-loop recycling of the organic devices without significant material loss by the selective dissolution of each organic component and spin-coating-free fabrication process. To achieve such recyclability, we choose</mark> poly(3,4-ethyelendioxythiophene):poly(styrene sulfonate) (PEDOT:PSS) as an organic conductor due to its wide range of use in various organic electronics, facile processibility, as well as excellent electrical and mechanical properties<sup>20,21</sup> . Importantly, PEDOT:PSS in organic electronics selectively dissolves in water, a poor solvent for typical organic electronic components. The organic conductor, PEDOT:PSS, retained its electrical properties under various bending radii and exhibited reliable recyclability at least 5 times, enabling the fabrication of the diverse wearable ROF electronics such as skin-mountable electrodes for <mark>electromyography (EMG) and electrocardiography (ECG) monitoring, and skin-mountable keypads. To fabricate such ROF electronics, polyethylene terephthalate (PET) was utilized as a substrate, which possesses chemical resistance properties to the typical solvents required for the recycling process. Besides, more complex but essential electronic devices, including transistors and logic gates (inverter) were demonstrated with the ROF feature using poly(3-hexylthiophene2,5-diyl) (P3HT), iongel, and PEDOT:PSS as an organic semiconductor, gate dielectric, and organic electrode, respectively. More importantly, we have demonstrated sustainable devices cycle with the reconfiguration of various ROF electronics based on only recycled material from different functional electronics without any material replenishment for device fabrication.</mark> 

4 

# **Results** 

# **ROF electronics** 

Figure 1a represents an overall conceptual process for ROF electronics composed of all organic electronic materials, which shows that all materials for the device fabrication can be individually recaptured through selective dissolution. Individual components in the ROF electronics demonstrated in this work were fabricated by drop-casting on flexible PET film through polyimide-based shadow masks. The significant difference in surface energy of PET and that of the shadow masks allows facile patterning for desired designs (Supplementary Fig. 1). In addition, UV-O3 treatment to PET substrate is a crucial step in enhancing adhesiveness between the substrate and electrodes by surface modification<sup>22</sup> . The ROF devices demonstrated in this work include ECG/EMG sensing electrodes, <mark>skin-mountable</mark> keypads, transistors, inverters, electrochemical transistors, and heaters/temperature sensors which are fabricated with PEDOT:PSS and P3HT as a conducting and semiconducting organic materials, respectively. The detailed fabrication processes of the devices are described in Methods and are shown in Supplementary Fig. 2. 

The facile recycling process of the ROF electrodes based on PEDOT:PSS is presented in Fig. 1b. Dimethyl sulfoxide (DMSO) was added as an additive into the PEDOT:PSS solution to ensure the sufficient electrical conductivity of the ROF electrodes through the formation of a conductive PEDOT-rich network by reducing Coulombic interaction between PEDOT and PSS<sup>23,24</sup> . The patterned PEDOT:PSS can be easily retrieved from the PET substrate by scrapping, as shown in Supplementary Fig. 3. The retrieving does not cause significant loss of PEDOT:PSS (Supplementary Fig.4) and apparent damages to PET substrate (Supplementary Fig. 5). Through vigorous stirring, the scrapped PEDOT:PSS flakes are fragmentized into aggregated particles. 

5 

Further ultrasonication results in uniformly dispersed PEDOT:PSS particles similar to the original state, which completes the recycling process of the ROF electrodes. Because the particle size of PEDOT:PSS in the solution state determines morphologies and electrical properties of the film<sup>25</sup> , recovery to the original size is crucial. Thus, dynamic light scattering (DLS) analysis was utilized to optimize stirring and ultrasonication time by investigating normalized particle size ( _d_ / _d_ 0) change. Figure 1c and Supplementary Fig. 6 show that the vigorous stirring led to fragmentation of the PEDOT:PSS into smaller particles for 10 hours, whereas no more significant change was observed under the longer stirring. Furthermore, a decrease in the _d_ / _d_ 0 under ultrasonication was saturated at around 60 min (Fig. 1d). Therefore, the sequential 10 hours of vigorous stirring and 1 hour of ultrasonication were employed for further studies and to demonstrate the recycling of wearable ROF electronics. 

# **PEDOT:PSS-based ROF electrodes** 

The critical feature of evaluating the recyclability of the ROF electrodes is maintaining the electrical characteristics under multiple recycling processes. Figure 2a shows a mild change in electrical conductivity ( _σ_ ) from 629.64 S/cm to 458.53 S/cm after 5 times of repeated recycling process. The average particle size ( _d_ avg) (Fig. 2b and Supplementary Fig. 7a) and zeta potential (ζpotential **)** (Fig. 2c and Supplementary Fig. 7b) of PEDOT:PSS solution increased moderately during the recycling process. The abovementioned changes might be attributed to the loss of PSS surrounding the aggregated PEDOT by repeated rinsing with DI water in the recycling process, owing to the polar nature of water molecules<sup>26</sup> . Specifically, the negatively charged PSS assists PEDOT in dispersing water by avoiding severe aggregation of the positively charged PEDOT<sup>27</sup> . Thus, PSS loss results in further aggregation of PEDOT, which affects the conductivity of the ROF 

6 

electrodes based on recycled PEDOT:PSS. Importantly, however, the reduced conductivities caused by repeated recycling are still in the range of sufficient values for fabricating the ROF electronics such as ECG/EMG sensing electrodes, <mark>skin-mountable</mark> keypads, transistors, inverters, electrochemical transistors, and heaters/temperature sensors, as described below. In addition, various electronics with PEDOT:PSS that have similar conductivity to our recycled ROF electrodes have been reported elsewhere<sup>24,28,29</sup> . The negligible difference in the surface morphologies of the organic electrodes (Fig. 2d and Supplementary Fig. 8) and Attenuated Total Reflectance Fourier Transform Infrared (ATR-FTIR) spectra (Supplementary Fig. 9) upon repeated recycling process prove that the materials exhibit no significant degradation during the recycling, which suggests that this approach is feasible for sustainable organic electronics. 

To assure the properties of the ROF electrodes for wearable electronics, the electrical performances under different bending radii ( _r_ ) were characterized. Figure 2e shows the excellent flexibility of the PEDOT:PSS-based ROF electrodes. The ROF electrodes exhibit exceptional durability with marginal variation in the electrical property under mechanical bending up to _r_ of 5 mm as shown in Fig. 2f. Moreover, similar durable trends compared to the pristine ROF electrodes were observed in the recycled ROF electrodes (Fig. 2f and Supplementary Fig. 10.). It is noted that the typical thickness of the organic electrodes is around 3 μm and does not change significantly during the repeated recycling process, as shown in Supplementary Fig. 11. The mechanical endurance against the number of bending cycles was also investigated up to 1000 bending cycles. As shown in Fig. 2g and Supplementary Fig. 12, negligible change in electrical characteristics of the ROF electrodes was observed under repeated bending, even after 5 times recycling processes. Figure 2h shows optical images of representative distinct patterned ROF electrodes for each recycling process. Various desired patterns of the electrodes on the flexible substrates were 

7 

feasible through a simple solution process with a shadow mask, as shown in Supplementary Fig. 13. These results indicate that the ROF electrodes can be sufficiently achievable, and the devices exhibit durable electrical properties under mechanical bending, which suggests that sustainable wearable electronics for direct mounting on the curvilinear surface of the human body is feasible. 

# **PEDOT:PSS-based wearable ROF electronics** 

We further fabricated the various wearable ROF electronics, including sensing electrodes for electrophysiological signal monitoring and the <mark>skin-mountable k</mark> eypad allowing integration with the calculator as a representative example of functional wearable ROF electronics. Figure 3a shows the optical image of the fabricated PEDOT:PSS-based ROF sensing electrodes for ECG/EMG monitoring. The detailed fabrication process of the sensing electrodes is described in Methods. Owing to the excellent flexibility of the devices enabling conformal contact to the curvilinear surface (Supplementary Fig. 14), the ROF sensing electrodes appropriately contact the surface of the human body (Fig. 3b), as well as exhibit comparable sensing properties with commercially available Ag/AgCl ECG electrodes (2224H, 3M) (Supplementary Fig. 15). The representative ECG traces with clear PQRST complexes of sinus rhythm from 5 times recycled sensing electrode shows reliable signal collecting properties similar to that of the pristine sensing electrode (Fig. 3c). Further EMG signals from the biceps brachii were collected by the ROF sensing electrodes during the exercise of an arm with two distinct forces (Fig. 3d). Both pristine and recycled ROF sensing electrodes show appropriate sensing properties, indicating excellent recyclability of the device (Fig. 3e). 

Apart from the ROF sensing electrode for electrophysiological signal monitoring, the <mark>skinmountable</mark> ROF keypad was further demonstrated, as shown in Fig. 3f. The device is constructed 

8 

out of two separated PEDOT:PSS-based flexible electrodes by PET spacers as schematically illustrated in Supplementary Fig. 16, which provides the flexibility of the device for the wearable device. The <mark>skin-mountable</mark> ROF keypad is incorporated into the external calculator to demonstrate the proper operation of the devices on the human skin. Two separated electrodes contact by pressing with a finger, which results in the current flow to deliver the signals of a designated symbol to the calculator (Fig. 3g and Supplementary Fig. 17). Supplementary Fig. 18 shows reliable operation with the fast current response by finger pressing. The various calculations were processed using pristine and 5 times recycled <mark>skin-mountable</mark> ROF keypads, as shown in Fig. 3h and Supplementary Fig. 19. The recycled ROF keypad without functional degradation proves the excellent recyclability for sustainable future electronics. 

# **ROF transistors and ROF inverters** 

One of the fundamental electronic devices is the transistor because it is the essential component for various circuits and switching systems<sup>30</sup> . Therefore, developing recyclable organic transistors in a flexible format is essential to achieve sustainable future wearable electronics. We developed the ROF transistor that is closed-loop recyclable by fabricating with PET, PEDOT:PSS, an iongel, and P3HT as substrates, conductors, gate dielectrics, and organic semiconductors. The key approach to enabling excellent recycling features for the ROF transistors fabrication is to employ drop-casting to form the semiconductor layer. Typical coating approaches such as spincoating induce significant material loss considered non-reusable waste, limiting the effective recycling approach for sustainable future electronics. Therefore, the drop-casting-based fabrication process provides an excellent solution for preventing material loss to realize the high yield recycling. Figure 4a shows the schematic exploded view and optical image of the ROF 

9 

transistor. The devices adapt ion-gated field-effect transistors configuration for low voltages operation capability which PEDOT:PSS coated iongel was chosen as a gate electrode/dielectric. The iongel was made out of 1-Ethyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide (EMIM-TFSI), and Poly(vinylidene fluoride-co-hexafluoropropylene) (PVDF-HFP) as ionic liquid and polymeric matrix, respectively. The detailed fabrication process is described in Methods. In addition, the optical images of the PEDOT:PSS coated iongel exhibiting excellent flexibility under various mechanical deformations are shown in Supplementary Fig. 20. Figure 4b and 4c show representative output and transfer curves of the ROF transistors performing typical p-channel characteristics. The calculated average and the highest field-effect mobility ( _μ_ FE) from the 30 devices are 19.41 <mark>cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> and 23.19 <mark>cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> <mark>,</mark> respectively. The high performance of the ROF transistor is attributed to the high crystalline self-assembled P3HT nanofibrils (P3HT-NFs) formed by heating and cooling process of the solution<sup>31</sup> . In addition, the low energy barrier between the semiconductor and electrode might be another reason for high performance, as the ohmic contact between P3HT-NFs and PEDOT:PSS-based source/drain electrodes favors charge transport<sup>32</sup> . 

For verifying the mechanical flexibility of the devices, the electrical performance under bending was evaluated using the curvilinear surfaced mold as shown in Fig. 4d. The transfer characteristics of the devices under various _r_ of infinite (∞), 20, 15, 10, and 5 mm exhibit moderate changes in the device performance (Fig. 4e). The extracted _μ_ FE and threshold voltage ( _V_ TH) under various _r_ are plotted in Fig. 4f. A slight decrease of _μ_ FE from 19.41 ± 3.60 <mark>cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> <mark>at flat t</mark> o 13.79 ± 3.87 <mark>cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> <mark>under</mark> _<mark>r</mark>_ <mark>of 5 mm was observed, a</mark> nd no significant change in the _V_ TH was obtained <mark>. Such mild changes in the electrical performance of the devices under bending are mainly attributed to the strain on the semiconductors, which can be further improved by optimizing the</mark> 

10 

<mark>thickness of the substrates for shifting the neutral mechanical plane</mark><sup>33</sup> <mark>. However, all the results indicate that the devices show sufficient electrical characteristics for normal operation as flexible electronic devices.</mark> 

<mark>The recycling process of the ROF transistors began with peeling off the PEDOT:PSS coated iongel from the substrate. In this work, the PEDOT:PSS coated iongel can be reused by simple separation and lamination processes at least 30 times without further treatment, as shown in Supplementary Fig. 21. After retrieving the PEDOT:PSS coated iongel, the devices were soaked into acetone to remove ionic liquid, especially TFSI</mark><sup>-</sup> <mark>anion, which penetrated into the semiconducting layer during operation under applying voltage on the gate electrode. Due to the low solubility of PEDOT:PSS and P3HT in acetone</mark><sup>34</sup> <mark>, this process does not cause material loss or contamination, which is proven by the negligible change in UV-vis absorption spectra of acetone before and after washing P3HT-NFs (Supplementary Fig. 22). Thereafter, the semiconducting layer was retrieved by dissolving it in chloroform, a widely used good solvent for P3HT. The considerably different solubility of P3HT and PEDOT:PSS in chloroform allows the selective dissolution of P3HT from the devices (Supplementary Fig. 23). Because only a tiny amount of P3HT solution was used for the device fabrication, many devices are required to retrieve a sufficient quantity of the semiconductors for the fabrication of recycled devices. The recycling process of the flexible organic transistors is completed by PEDOT:PSS-based electrodes recycling as described above. The detailed recycling process is described in Methods and shown in Supplementary Figs. 24 and 25.</mark> 

<mark>Finally, ROF transistors were fabricated using all-recycled materials. Figure 4g and Supplementary Fig. 26 show representative transfer and output characteristics of the recycled devices, which exhibit normal operation. Moreover, the extracted</mark> _μ_ FE, _V_ TH, on/off current ratio 

11 

( _I_ ON/ _I_ OFF), subthreshold swing ( _ss_ ) from the 30 devices of the pristine and recycled are 19.41 ± 3.60 <mark>cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> <mark>(pristine)/3.92 ± 0.99 cm</mark><sup>2</sup> <mark>·V</mark><sup>-1</sup> <mark>·s</mark><sup>-1</sup> <mark>(recycled), -2.42 ± 0.09 V (pristine)/-2.12 ± 0.18 V (recycled), (5.46 ± 1.46) ×10</mark><sup>3</sup> <mark>(pristine)/(7.56 ± 2.82) × 10</mark><sup>2</sup> <mark>(recycled), and  0.43 ± 0.07 V/dec (pristine)/0.58 ± 0.07 V/dec (recycled), respectively, which</mark> confirms the potential utility of our approach, although slight changes in electrical properties were observed (Fig. 4h and 4i, Supplementary Figs 27-30). These changes in electrical properties of the recycled devices are attributed to the aggregation of P3HT in recycled solution by ionic liquid as a dopant. The aggregation of P3HT suppresses the formation of high crystalline P3HT nanofibrils. In retrieving the semiconductors, washing with acetone might be insufficient to completely remove the deeply penetrated ionic liquid from the semiconducting layer. The remained small amounts of ionic liquid, especially TFSI<sup>-</sup> anion, in the P3HT could lead to the dopants-induced aggregation of P3HT by polaron-anion interaction<sup>35,36</sup> . The surface morphologies from the atomic force microscopic (AFM) images support the apparent aggregation of P3HT of the recycled film compared to the pristine (Supplementary Fig. 31). The UV-Vis absorption spectra of the pristine and recycled P3HT film are shown in Supplementary Fig. 32. The reduced absorption at around 520 nm implies the weakened intra-chain π-π* transition by the oxidation of P3HT by TFSI<sup>-</sup> anion<sup>37,38</sup> . In addition, intercalated TFSI<sup>-</sup> anions in the P3HT crystalline regions induce the decrease of π-π distance between the thiophene rings, which leads to the slight red shift of the peaks at ~560 nm, and ~605 nm associated with inter-band vibronic peaks<sup>39,40</sup> . Nonetheless, the performance of the recycled ROF transistors exhibits comparable characteristics with those of previously reported ion-gated p- channel organic transistors<sup>41</sup> . 

It is also indispensable to develop logic gates for various circuit applications to achieve advanced wearable electronics systems that can be recycled. We further demonstrated an inverter, 

12 

an essential building block for digital electronics, as one of the representative logic gates with recyclable and flexible features based on only organic electronic materials. Figure 4j illustrates a schematic exploded view of the ROF inverter, constructed with a zero- _V_ GS load configuration based on the p-channel ROF transistors, as shown in the optical image and the circuit diagram (Fig. 4k). The ratio of channel widths of the driver and load transistors in the logic gate was designed to be 1 to 5, and the length of both channels are the same, which ensures proper operation of the devices exhibiting output logic "0" under the input logic "1". The representative voltage transfer curves (VTCs) of both pristine and recycled ROF inverters under _V_ DD of 1 V in Fig. 4l indicate that the device has sufficient recyclability. The modest changes in the electrical properties, including gain, _V_ M, and noise margin after recycling, resulted from the performance changes of the ROF transistors compositing the inverters (Fig. 4m and Supplementary Figs. 33-34).  These results indicate that our approach for the ROF electronics is feasible for the more complex circuits for sustainable future wearable electronics. 

# **Sustainable device cycle with ROF electronics** 

The capability to reconstruct the devices using only recycled materials from the devices with different functionalities is another crucial feature for the sustainable future of wearable electronics. To demonstrate such reconfigurability by recycling, we achieved a sustainable device cycle (Fig. 5a) with the inverters demonstrated above and two more devices such as ROF electrochemical transistors and ROF heaters/temperature sensors that have not been fabricated above. The electrochemical transistors enabling sub-voltage operating with high transconductance are also promising devices for various future applications such as electroanatomical mapping and electrophysiological signal amplifications<sup>42,43</sup> . In addition, the temperature sensing property of 

13 

wearable electronics provides useful human body temperature monitoring functions<sup>44</sup> . Local warming features in wearable format can also serve various practical capabilities such as thermal therapy<sup>45</sup> . 

Supplementary Fig. 35 shows the schematic flow of our evaluation process to demonstrate reconfigurability by the recycling process, including ROF inverters, electrochemical transistors, and heaters/temperature sensors. It is noted that the fabricated ROF electrochemical transistors and heaters/temperature sensors exhibit appropriate recyclable capability, as shown in Supplementary Figs. 36 and 37, respectively. The detailed architectures and fabrication processes for those devices are described explicitly in Methods. Firstly, a pristine ROF inverter shows pertinent electrical characteristics with clearly distinguishable output logic states (Fig. 5b). Next, the fabricated ROF electrochemical transistors with the recycled materials from the inverters exhibit sufficient output and transfer characteristics, as shown in Fig. 5c and 5d, respectively. The obtained transconductance ( _g_ m) from the recycled ROF electrochemical transistor is comparable with that of previously reported PEDOT:PSS-based electrochemical transistors<sup>46</sup> . Afterward, the ROF heaters/temperature sensors were fabricated based on the recaptured PEDOT:PSS from the ROF electrochemical transistors, which show temperature-dependent resistance change with a negative temperature coefficient (NTC) that is typical behavior of semiconductors due to enhanced charge carriers transport upon the increase in thermal energy<sup>47</sup> . Fig. 5e shows the resistance ( _R_ ) change as a function of temperature between 30<sup>o</sup> C and 50<sup>o</sup> C. In addition, the linearly fitted plot of ln _R_ versus the reciprocal of the absolute temperature (1/ _T_ ) is shown in Fig. 5f. Finally, upon the range of applying bias from 1 to 4 V, the devices produce controllable Joule heating property around 70 oC at 4 V. Those results prove the capability of recycling for the ROF electronics reconfiguration without any materials replenishment, which provides a universal recycling manner for sustainable 

14 

future wearable electronics. 

# **Conclusions** 

We have reported all organic materials-based electronic devices enabling closed-loop recycling through recapturing and reusing entire electrical components. The PEDOT:PSS-based ROF electrodes exhibit consistent electrical characteristics even under 5 times of recycling process without considerable degradation. Based on the ROF electrodes, various wearable ROF electronic devices are further developed, including electrophysiological signal sensing electrodes and <mark>skinmountable</mark> keypads that enable direct mount on a surface of the human body. Those devices also show excellent recycling features. Moreover, ROF transistors were demonstrated, which provides significant importance to our approaches for achieving sustainable future wearable electronics, as the transistor is the fundamental building block for various electronics. More importantly, we believe it is a substantial accomplishment in achieving reconfiguration capability of the flexible organic devices by closed-loop recycling process to different electronics, including ROF electrochemical transistors and ROF heaters/temperature sensors. The demonstrated ROF electronics in this report could open up new vistas for future sustainable wearable systems by suppressing noxious organic e-waste. 

15 

# **Methods** 

# **Materials** 

Poly(3,4-ethyelendioxythiophene):poly(styrene sulfonate) (PEDOT:PSS, Heraeus Clevios PH1000) was purchased from Ossila. Dimethylsulfoxide (DMSO; >99.9%), dichloromethane (99%), chloroform (>99%), 1-Ethyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide (EMIM-TFSI), Poly(vinylidene fluoride-co-hexafluoropropylene) (PVDF-HFP; _M_ W =, ~400,000), and regioregular P3HT ( _M_ W = 50,000 – 100,000) were all purchased from Sigma-Aldrich and used as received. Acetone was purchased from Samchun Chemicals. P <mark>olyethylene terephthalate (PET, Premium OHP film, 100 MIC) film was purchased from Dong-A. Polydimethylsiloxane (PDMS; Sylgard 184) was purchased from Dow-Corning. ECG, and EMG gel (Caresonic 01-10) were purchased from Care Pharm.</mark> 

# **Preparation of the PEDOT:PSS-based ROF electrodes** 

PEDOT:PSS-based ROF electrode preparation began with adding DMSO into the PEDOT:PSS solution in a volume ratio of 5% to enhance the electrical conductivity. The solution was stirred vigorously at room temperature for 30 min. The patterned PEDOT:PSS electrodes were formed by drop-casting the solution on UV-O3 treated PET substrates through polyimide-based shadow masks prepared by a programmable cutting machine (Silhouette Portrait 3), followed by baking at 60<sup>o</sup> C for 20 min. The UV-O3 treatment for 20 min on the PET film improves surface energy, enabling the facile formation of PEDOT:PSS due to enhanced wettability. In addition, significantly different surface energy between the substrate and shadow mask assist effective patterning of the electrode<sup>22</sup> . Thereafter, the patterned electrodes were further dehydrated in the vacuum oven at 60 °C for 12 hours. 

16 

# **Fabrication of the ROF sensing electrodes** 

<mark>The fabrication of the</mark> ROF sensing electrodes for electrophysiological signal monitoring <mark>involved the preparation of PEDOT:PSS-based ROF electrodes on the PET substrates with the desired configuration by the patterning process as described above. A copper wire was connected to the electrode by applying the silver paste to ensure electrical contact. Kapton tape was used to fix the wire on the substrates for mechanical robustness. PDMS shielded the exposed silver paste to prevent unexpected electrical noises. Thereafter, a flexible transparent bandage (AD-1010, Everaid) was applied on the backside of the electrodes to adhere the sensor to the skin directly.</mark> 

# **Fabrication of the** **<mark>skin-mountable</mark> ROF keypads** 

<mark>The skin-mountable</mark> ROF keypads <mark>were fabricated by assembling two PEDOT:PSS-based flexible electrodes separated by appropriately shaped PET spacers through a</mark> programmable cutting machine <mark>. First, each flexible electrode with the desired pattern was prepared as described above. Then, the fabricated keypad was electrically wired to Arduino by copper wire, similar to the fabrication of the ROF sensing electrodes.</mark> 

# **Fabrication of the ROF transistors and inverters** 

<mark>The fabrication process of the</mark> ROF transistors <mark>involved patterning electrodes, forming an organic semiconducting layer, and preparing PEDOT:PSS coated iongel. Firstly, the patterning of PEDOT:PSS on the PET substrate for source and drain electrodes followed the procedure described above. To form the organic semiconducting layer, P3HT-NFs was chosen because of their significant charge-transporting properties. The P3HT-NFs preparation began with the</mark> 

17 

<mark>dissolving of P3HT in the dichloromethane (2 mg/mL at 80</mark><sup>o</sup> <mark>C for 30 min), followed by keeping it at −20 °C for longer than 1 hour. Such the heating and cooling process enables the formation of P3HT-NFs through self-assembly of the thiophene backbone by π- π stacking</mark><sup>31</sup> <mark>. The prepared P3HT-NFs solution was drop-casted on the channel region, then annealed at 120</mark><sup>o</sup> <mark>C for 20 min. The iongel was prepared using a mixed solution of PVDF-co-HFP, dehydrated EMIM-TFSI, and acetone in a weight ratio of 1:4:7, respectively. The homogeneous mixture was obtained by stirring at 80</mark><sup>o</sup> <mark>C on a hotplate for 1 hour. The free-standing iongel film was obtained by casting on a clean glass substrate and solidifying at 70</mark><sup>o</sup> <mark>C in the vacuum oven for 12 hours. Finally, the PEDOT:PSS solution was drop-casted on the free-standing iongel to form a gate electrode. Thereafter, the PEDOT:PSS coated iongel in the desired shape by cutting was laminated on the P3HT-NFs layer to complete the fabrication process of the ROF transistors. The ROF inverters were fabricated similarly to the transistor fabrication apart from the electrode pattern configuration.</mark> 

# **Fabrication of the ROF electrochemical transistors and ROF heaters/temperature sensors** 

To <mark>fabricate the</mark> ROF electrochemical transistors and heaters/temperature sensors for closed-looped recycling, the PEDOT:PSS-based electrodes were prepared with an appropriate pattern through a shadow mask. Then, premade iongel as electrolyte was laminated on the active region of the ROF electrochemical transistors, followed by contacting Ag/AgCl electrode to the iongel. 

# **Recycle procedure for the PEDOT:PSS-based ROF electrodes** 

<mark>The recycling of the PEDOT:PSS-based ROF electrodes began with successive rinsing by deionized (DI) water and acetone filtered by a 20 µm pored syringe filter to eliminate any</mark> 

18 

<mark>impurities. The rinsing was implemented at least twice. To retrieve the PEDOT:PSS from the substrates, the electrode was immersed in filtered water for around 20 s. The swelled PEDOT:PSS in water were carefully scrapped using a clean blade, which does not induce loss of the materials. In addition, no significant damage on the surface of PET substrates enables direct reuse as well as traditional polymer recycling. The retrieved PEDOT:PSS fragments were soaked into the appropriate amount of filtered DI water to make them the same concentration as the original PEDOT:PSS. The solution was vigorously stirred (1000 rpm) at room temperature for 10 hours to break the fragments into the aggregated particles. Further ultrasonication was applied for 1 hour to achieve a well-dispersed PEDOT:PSS solution that is ready to be reused to prepare the PEDOT:PSS-based ROF electrodes.</mark> 

# **Recycle procedure for the P3HT-NFs semiconducting layer** 

The recycling procedure for the P3HT-NFs involved at least three times repeated steps involving immersing the device without iongel into acetone and then drying. These steps assist in eliminating the remaining ionic liquid on the surface of the organic semiconducting layer. Thereafter, chloroform, a good solvent for P3HT, was applied for the selective dissolving of P3HTNFs and recapturing them. Finally, P3HT-NFs were retrieved by evaporating chloroform through a rotary evaporator. 

# **Characterization of devices and materials** 

Electrical properties of the PEDOT:PSS-based ROF electrodes, transistors, inverters, and electrochemical transistors were characterized by a semiconductor analyzer (4200-SCS, Keithley Instruments Inc.) with a customized curvilinear mold to investigate the performance under 

19 

different bending radii. The surface morphologies of the PET were examined with Field Emission Scanning Electron Microscopy (Nano230, Nova Ltd.). The dynamic light scattering (Zen 3600, Malvern Instruments Ltd.) was utilized to measure particle size and zeta potential for the pristine and recycled PEDOT:PSS solution. The surface morphologies of the pristine and recycled PEDOT:PSS-based ROF electrodes and P3HT-NFs film were characterized using an atomic force microscope (NX-10, Park Systems Inc.) under tapping mode. IR spectra in this work were obtained by using FT-IR spectrometer (Spectrum Two, Perkin Elmer Inc.) with an attenuated total reflectance (ATR) accessory. A spectrophotometer (V-670, JASCO Inc.) was employed to characterize the absorption property of the pristine and recycled P3HT-NFs film. The thickness of the pristine and recycled PEDOT:PSS-based ROF electrodes were measured with a surface profilometer (P6, KLA Tencor). The electrophysiological signals were obtained using Sparkfun AD8232 and Arduino UNO. The commercial gel was applied between skin and sensors to minimize interfacial impedance<sup>48,49</sup> . The practical tests of the ROF keypads for wearable electronics were performed with Arduino UNO, Arduino LCD 1602 and Keysight B2912B (Keysight Technologies Inc.). Joule heating properties of the ROF heaters were characterized by monitoring temperature using a digital thermometer (Fluke 566) equipped with a type K thermocouple probe under applied voltages from a DC power supply (GPS-3303, GW Instek). The temperature mapping of the heaters during Joule heating was captured by an infrared camera (FLIR ONE Pro, FLIR Systems). 

# **Data availability** 

The data that support the plots within this paper and other findings of this study are available from the corresponding author upon reasonable request. 

20 

# **Reference** 

- 1 Jambeck, J. R. _et al._ Plastic waste inputs from land into the ocean. _Science_ **347** , 768-771 (2015). 

- 2 Besis, A. _et al._ Toxic organic substances and marker compounds in size-segregated urban particulate matter - Implications for involvement in the in vitro bioactivity of the extractable organic matter. _Environ. Pollut._ **230** , 758-774 (2017). 

- 3 Nelson, J. J. M. & Schelter, E. J. Sustainable Inorganic Chemistry: Metal Separations for Recycling. _Inorg. Chem._ **58** , 979-990 (2019). 

- 4 Yang, Q. Y. _et al._ Exposure to typical persistent organic pollutants from an electronic waste recycling site in Northern China. _Chemosphere_ **91** , 205-211 (2013). 

- 5 Williams, N. X., Bullard, G., Brooke, N., Therien, M. J. & Franklin, A. D. Printable and recyclable carbon electronics using crystalline nanocellulose dielectrics. _Nat. Electron._ **4** , 261-268 (2021). 

- 6 Robinson, B. H. E-waste: An assessment of global production and environmental impacts. _Sci. Total Environ._ **408** , 183-191 (2009). 

- 7 Qin, Q. L. _et al._ Air pollution and body burden of persistent organic pollutants at an electronic waste recycling area of China. _Environ. Geochem. Health_ **41** , 93-123 (2019). 

- 8 Kwon, S. J., Seo, H. K., Ahn, S. & Lee, T. W. Value-Added Recycling of Inexpensive Carbon Sources to Graphene and Carbon Nanotubes. _Adv. Sustain. Syst._ **3** , 1800016 (2019). 

- 9 Liu, Y. X., Wang, H. Y. & Zhu, Y. Recycling of Nanowire Percolation Network for Sustainable Soft Electronics. _Adv. Electron. Mater._ **7** , 2100588 (2021). 

21 

- 10 Yoo, B., Kim, Y., Han, C. J., Oh, M. S. & Kim, J. W. Recyclable patterning of silver nanowire percolated network for fabrication of flexible transparent electrode. _Appl. Surf. Sci._ **429** , 151-157 (2018). 

- 11 Shi, C. Q. _et al._ Heterogeneous integration of rigid, soft, and liquid materials for selfhealable, recyclable, and reconfigurable wearable electronics. _Sci. Adv._ **6** , eabd0202 (2020). 

- 12 Teng, L. _et al._ Liquid Metal-Based Transient Circuits for Flexible and Recyclable Electronics. _Adv. Funct. Mater._ **29** , 1808739 (2019). 

- 13 Guo, Y. F. _et al._ Degradable and Fully Recyclable Dynamic Thermoset Elastomer for 3DPrinted Wearable Electronics. _Adv. Funct. Mater._ **31** , 2009799 (2021). 

- 14 Sim, K. _et al._ Fully rubbery integrated electronics from high effective mobility intrinsically stretchable semiconductors. _Sci. Adv._ **5** , eaav5749 (2019). 

- 15 Chow, P. C. Y. & Someya, T. Organic Photodetectors for Next-Generation Wearable Electronics. _Adv. Mater._ **32** , 1902045 (2020). 

- 16 Lee, Y. & Lee, T. W. Organic Synapses for Neuromorphic Electronics: From BrainInspired Computing to Sensorimotor Nervetronics. _Acc. Chem. Res._ **52** , 964-974 (2019). 

- 17 Janasz, L., Borkowski, M., Blom, P. W. M., Marszalek, T. & Pisula, W. Organic Semiconductor/Insulator Blends for Elastic Field-Effect Transistors and Sensors. _Adv. Funct. Mater._ **32** , 2105456 (2022). 

- 18 Rovira, J. & Domingo, J. L. Human health risks due to exposure to inorganic and organic chemicals from textiles: A review. _Environ. Res._ **168** , 62-69 (2019). 

- 19 Velali, E. _et al._ Cytotoxicity and genotoxicity induced in vitro by solvent-extractable organic matter of size-segregated urban particulate matter. _Environ. Pollut._ **218** , 1350-1362 (2016). 

22 

- 20 Fan, X. _et al._ PEDOT:PSS for Flexible and Stretchable Electronics: Modifications, Strategies, and Applications. _Adv. Sci._ **6** , 1900813 (2019). 

- 21 Dauzon, E. _et al._ Conducting and Stretchable PEDOT:PSS Electrodes: Role of Additives on Self-Assembly, Morphology, and Transport. _ACS Appl. Mater. Interfaces_ **11** , 1757017582 (2019). 

- 22 Nemani, S. K. _et al._ Surface Modification of Polymers: Methods and Applications. _Adv. Mater. Interfaces_ **5** , 1801247 (2018). 

- 23 Chou, T. R., Chen, S. H., Chiang, Y. T., Lin, Y. T. & Chao, C. Y. Highly Conductive PEDOT:PSS Film by Post-Treatment with Dimethyl Sulfoxide for ITO-Free Liquid Crystal Display. _Mol. Cryst. Liq. Cryst._ **612** , 201-210 (2015). 

- 24 Zhang, S. _et al._ Solvent-induced changes in PEDOT: PSS films for organic electrochemical transistors. _APL Mater._ **3** , 014911 (2015). 

- 25 Lee, Y.-Y. _et al._ Growth Mechanism of Strain-Dependent Morphological Change in PEDOT:PSS Films. _Sci. Rep._ **6** , 25332 (2016). 

- 26 DeLongchamp, D. M. _et al._ Influence of a water rinse on the structure and properties of poly(3,4-ethylene dioxythiophene): poly(styrene sulfonate) films. _Langmuir_ **21** , 1148011483 (2005). 

- 27 Zhang, X., Yang, W., Zhang, H., Xie, M. & Duan, X. PEDOT:PSS: From conductive polymers to sensors. _Nanotechnol. Precis. Eng._ **4** , 045004 (2021). 

- 28 Liang, Y. Y., Offenhaeusser, A., Ingebrandt, S. & Mayer, D. PEDOT:PSS-Based Bioelectronic Devices for Recording and Modulation of Electrophysiological and Biochemical Cell Signals. _Adv. Healthc. Mater._ **10** , 2100061 (2021). 

23 

- 29 Yang, Y., Deng, H. & Fu, Q. Recent progress on PEDOT:PSS based polymer blends and composites for flexible electronics and thermoelectric devices. _Mater. Chem. Front._ **4** , 3130-3152 (2020). 

- 30 Zhang, L., Di, C. A., Yu, G. & Liu, Y. Q. Solution processed organic field-effect transistors and their application in printed logic circuits. _J. Mater. Chem._ **20** , 7059-7073 (2010). 

- 31 Oh, J. Y. _et al._ Self-Seeded Growth of Poly(3-hexylthiophene) (P3HT) Nanofibrils by a Cycle of Cooling and Heating in Solutions. _Macromolecules_ **45** , 7504-7513 (2012). 

- 32 Zhang, Y., Chen, L., Hu, X. T., Zhang, L. & Chen, Y. W. Low Work-function Poly(3,4ethylenedioxylenethiophene): Poly(styrene sulfonate) as Electron-transport Layer for High-efficient and Stable Polymer Solar Cells. _Sci. Rep._ **5** , 12839 (2015). 

- 33 Kim, Y. H., Lee, E., Um, J. G., Mativenga, M. & Jang, J. Highly Robust Neutral Plane Oxide TFTs Withstanding 0.25 mm Bending Radius for Stretchable Electronics. _Sci. Rep._ **6** , 25734 (2016). 

- 34 Roesing, M., Howell, J. & Boucher, D. Solubility Characteristics of Poly(3hexylthiophene). _J. Polym. Sci. B Polym. Phys._ **55** , 1075-1087 (2017). 

- 35 Mansour, A. E. _et al._ The optical signatures of molecular-doping induced polarons in poly(3-hexylthiophene-2,5-diyl): individual polymer chains versus aggregates. _J. Mater. Chem. C_ **8** , 2870-2879 (2020). 

- 36 Jacobs, I. E. _et al._ Comparison of solution-mixed and sequentially processed P3HT:F4TCNQ films: effect of doping-induced aggregation on film morphology. _J. Mater. Chem. C_ **4** , 3454-3466 (2016). 

24 

- 37 Liang, Z. Q., Reese, M. O. & Gregg, B. A. Chemically Treating Poly(3-hexylthiophene) Defects to Improve Bulk Heterojunction Photovoltaics. _ACS Appl. Mater. Interfaces_ **3** , 2042-2050 (2011). 

- 38 Yamamoto, J. & Furukawa, Y. Raman characterization and electrical properties of poly(3hexylthiophene) doped electrochemically in an ionic liquid-gated transistor geometry. _Org. Electron._ **28** , 82-87 (2016). 

- 39 Thomas, E. M. _et al._ X-Ray Scattering Reveals Ion-Induced Microstructural Changes During Electrochemical Gating of Poly(3-Hexylthiophene). _Adv. Funct. Mater._ **28** , 1803687 (2018). 

- 40 Guardado, J. O. & Salleo, A. Structural Effects of Gating Poly(3-hexylthiophene) through an Ionic Liquid. _Adv. Funct. Mater._ **27** , 1701791 (2017). 

- 41 Lee, K. H. _et al._ "Cut and Stick" Rubbery Ion Gels as High Capacitance Gate Dielectrics. _Adv. Mater._ **24** , 4457-4462 (2012). 

- 42 Lee, W. _et al._ Nonthrombogenic, stretchable, active multielectrode array for electroanatomical mapping. _Sci. Adv._ **4** , eaau2426 (2018). 

- 43 Bontapalle, S., Na, M., Park, H. & Sim, K. Fully soft organic electrochemical transistor enabling direct skin-mountable electrophysiological signal amplification. _Chem. Commun._ **58** , 1298-1301 (2022). 

- 44 Trung, T. Q. _et al._ Freestanding, Fiber-Based, Wearable Temperature Sensor with Tunable Thermal Index for Healthcare Monitoring. _Adv. Healthc. Mater._ **7** , 1800074 (2018). 

- 45 Choi, S. _et al._ Stretchable Heater Using Ligand-Exchanged Silver Nanowire Nanocomposite for Wearable Articular Thermotherapy. _ACS Nano_ **9** , 6626-6633 (2015). 

25 

- 46 Han, S. G., Polyravas, A. G., Wustoni, S., Inal, S. & Malliaras, G. G. Integration of Organic Electrochemical Transistors with Implantable Probes. _Adv. Mater. Technol._ **6** , 2100763 (2021). 

- 47 Wang, Y.-F. _et al._ Fully Printed PEDOT:PSS-based Temperature Sensor with High Humidity Stability for Wireless Healthcare Monitoring. _Sci. Rep._ **10** , 2467 (2020). 

- 48 Shahandashti, P. F., Pourkheyrollah, H., Jahanshahi, A. & Ghafoorifard, H. Highly conformable stretchable dry electrodes based on inexpensive flex substrate for long-term biopotential (EMG/ECG) monitoring. _Sens. Actuator A Phys._ **295** , 678-686 (2019). 

- 49 Zhang, L. _et al._ Fully organic compliant dry electrodes self-adhesive to skin for long-term 

   - motion-robust epidermal biopotential monitoring. _Nat. Commun._ **11** , 4683 (2020). 

# **Acknowledgments** 

This work was supported by the Research Funds (1.200090.01) of Ulsan National Institute of Science & Technology (UNIST) and the National Research Foundation of Korea (NRF) grant funded by the Korean government (NRF-2021R1C1C1007714). 

# **Author Contributions** 

H.P. and K.S. conceived the concept and designed the experiments. H.P., S.K., J.L., and I.L., prepared materials and fabricated devices. H.P., J.L., characterized device performance. H.P., S.K., I.L., and Y.N. performed analysis of materials. S.B. assisted H.P to develop materials. H.P., S.K., J.K., and K.S analyzed the experimental data. H.P. and K.S. wrote the manuscript. All authors reviewed and revised the manuscript. 

26 

# **Competing financial interests** 

The authors declare no competing financial interests. 

27 



**Fig.1** . **ROF electronics. a** , Recycling concept of wearable ROF electronics. **b** , Recycling process of PEDOT:PSS-based ROF electrodes. **c,d** , _d_ / _d_ 0 of PEDOT:PSS depending on stirring time ( **c** ) and ultrasonication time ( **d** ). 

28 



**Fig. 2. Recycling characteristics and electrical performance of PEDOT:PSS-based ROF electrode. a-c,** Conductivity of the ROF electrode ( **a** ), the average size of the PEDOT:PSS particle (b), and ζ-potential of PEDOT:PSS solution ( **c** ) depending on the number of recycling. **d,** AFM image in a phase mode of the pristine and recycled PEDOT:PSS-based ROF electrodes. **e,** Optical images of the patterned PEDOT:PSS-based ROF electrode in flat and under bending. **f,g,** Normalized resistance changes of the pristine and 5 times recycled ROF electrodes depending on bending radius ( **f** ) and the number of bending cycles at the bending radius of 5 mm ( **g** ). **h,** Optical images of various representative pristine and recycled ROF electrode patterns. 

29 



**Fig. 3. Electrophysiological signal sensing by wearable ROF electrode and the operation of** 

**wearable ROF keypad. a,** Optical image of the wearable ROF electrode for ECG/EMG 

monitoring. Inset is an optical image of the electrode on a convex surface. **b,** The wearable ROF electrodes mounted on the human body for 3-leads ECG measurement. **c,** Representative ECG 

30 

traces from the pristine and 5 times recycled electrodes. **d,** Optical images of the wearable ROF electrodes mounted on a human arm for EMG monitoring from biceps brachii under two different force exercises. **e,** Measured EMG signal from the pristine and 5 times recycled wearable ROF electrodes under different force exercises. **f,** Optical image of the fabricated wearable ROF keypad. **g,** Optical image and the response of current upon pressing a keypad button on the human arm. **h,** Demonstration of calculation using the pristine and 5 times recycled wearable ROF keypads. 

31 



**Fig. 4. ROF transistor and ROF logic gate. a** , Schematic exploded view (left) and optical image (right) of the ROF transistor. **b** , **c** , Representative output ( **b** ) and transfer ( **c** ) characteristics of the ROF transistor. **d,** Schematic illustration (top) and optical image (bottom) of the ROF transistor on a convex surface. **e** , Transfer characteristics of the ROF transistor under different bending radii. **f** , The field-effect mobilities and threshold voltages under different bending radii. **g** , Transfer 

characteristics of the pristine and recycled ROF transistors. **h** , The comparison of the field-effect 

32 

mobilities and threshold voltages of the pristine and recycled ROF transistors. **i** , The comparison of the on/off ratio and subthreshold swings of the pristine and recycled ROF transistors. **j** , Schematic exploded view of the ROF inverter. **k** , Optical image (left) and circuit diagram (right) of the ROF inverter. **l** , VTC of the pristine and recycled ROF inverters. **m** , The comparison of gain (top) and _V_ M (bottom) of the pristine and recycled ROF inverters. 

33 



**Fig. 5. Sustainable device cycle with closed-loop recycling of ROF electronics. a** , Schematic of the sustainable device cycle enabling device reconfiguration by closed-loop recycling of ROF electronics. **b** , VTC of the pristine ROF inverter. **c,d** , Output ( **c** ) and transfer ( **d** ) curves of the recycled ROF electrochemical transistor. **e** , **f** , Temperature dependent _R_ change ( **e** ), and ln _R_ plot versus the 1/ _T_ with Arrhenius fitting ( **f** ) of the recycled ROF temperature sensor. **g,** Joule heating characteristics upon different _V_ APP of the recycled ROF heater. 

34 

This is a list of supplementary �les associated with this preprint. Click to download. 

Supplementary�nal.pdf 

