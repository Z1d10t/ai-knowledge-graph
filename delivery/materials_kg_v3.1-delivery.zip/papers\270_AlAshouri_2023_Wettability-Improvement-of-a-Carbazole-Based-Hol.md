# Wettability Improvement of a Carbazole-Based Hole-Selective Monolayer for Reproducible Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Energy Letters |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | A. Al-Ashouri, Mantas Marčinskas, Ernestas Kasparavičius, T. Malinauskas, A. Palmstrom, V. Getautis, S. Albrecht, M. McGehee et al. |
| DOI | 10.1021/acsenergylett.2c02629 |
| 源文件 | 055_AlAshouri_2023_Wettability-Improvement-of-a-Carbazole-Based-Hol.pdf |

---








http://pubs.acs.org/journal/aelccp 

## **Wettability Improvement of a CarbazoleBased Hole-Selective Monolayer for Reproducible Perovskite Solar Cells** 

Amran Al-Ashouri, Mantas Marcinskas,̌ Ernestas Kasparavičius, Tadas Malinauskas, Axel Palmstrom, Vytautas Getautis, Steve Albrecht, Michael D. McGehee, and Artiom Magomedov* 

|**Cite This:**_ACS Energy Lett._2023, 8, 898−900|**Read Online**||
|---|---|---|
|ACCESS<br>Metrics & More|Article Recommendations|*<br>**sı**<br>Supporting Information|



ABSTRACT: The wettability issue associated with the Me-4PACz hole-selective monolayer is solved by the introduction of the second component to the precursor solution. This results in a similar performance while simultaneously significantly improving the yield of the devices. 



n the past decade perovskite solar cell (PSC) technology has made a big step toward commercialization.<sup>1</sup> However, there I is still a lot of room for improvement in terms of stability, 

is still a lot of room for improvement in terms of stability, scalability, and manufacturability. Ideally, the processing of solar cells should be reliable and simple. Nonetheless, as such devices consist of several layers and there are unavoidable “hidden parameters”, it is usually hard to achieve good reproducibility from lab to lab, and even within the same lab. One particular example is (self-assembled) monolayer-based hole-selective material (HSM) Me-4PACz ([4-(3,6-dimethyl-9 _H_ -carbazol-9yl)butyl]phosphonic acid), which was used in the recordbreaking perovskite/Si<sup>2,3</sup> and perovskite/CIGS<sup>4</sup> tandem devices. While the materials from the same family, 2PACz ([2(9 _H_ -carbazol-9-yl)ethyl]phosphonic acid) and MeO-2PACz ([2-(3,6-dimethoxy-9 _H_ -carbazol-9-yl)ethyl]phosphonic acid) have become adopted in the community,<sup>5−7</sup> the wider use of Me-4PACz, despite its providing enhanced charge extraction, is hindered by the rather poor coverage by the perovskite precursor solution, due to the nonpolar surface.<sup>8</sup> Solving this issue could lead to further progress in tandem and singlejunction devices. 

In this Energy Express, we show a simple way to overcome this limitation: adding commercially available 1,6-hexylenediphosphonic acid (6dPA) as a second component to the Me4PACz precursor solution. 20.9% power conversion efficiency (PCE) was achieved for small-area devices, showing a promising direction for future optimization of monolayer-based selective layers. 

Typically, perovskite films are formed by statically dispensing around 120 _μ_ L<sup>9</sup> of perovskite precursor solution on the HSM- 

covered substrate and then starting the spin-coating program. To get a statistical distribution of the performance parameters and minimize the impact of macroscopic defects, several individual devices (called “pixels”) are usually formed on the same substrate. In our case, on one 25 × 25 mm<sup>2</sup> ITO-covered glass substrate, 6 individual devices are formed. The active area (defined as an overlapping area between Ag top and ITO bottom electrodes) of each unmasked pixel is ∼0.12 mm<sup>2</sup> . 

First, we fabricated devices using Me-4PACz (Figure 1a) monolayers and triple-cation<sup>10</sup> perovskite, in order to evaluate the yield of the working devices. An optical image of a representative substrate is shown in Figure 1c. By measuring _J/V_ data of the Me-4PACz-based cells, it was determined that 67% of the pixels were shunted (meaning having _V_ oc significantly lower than 1 V). 

To overcome this limitation, we added a second component to the monolayer precursor solution, commercially available 1,6hexylenediphosphonic acid (6dPA, Figure 1b). We expected that the presence of the phosphonic acid groups would increase the surface energy of the monolayer-covered ITO. Indeed, the addition of the 20 mol% 6dPA to the Me-4PACz precursor solution substantially improved the wetting, leading to only 8% 



Received: November 20, 2022 Accepted: December 29, 2022 

Published: January 6, 2023 

© 2023 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acsenergylett.2c02629 _ACS Energy Lett._ 2023, 8, 898−900 

**898** 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Energy Express</mark> 



Figure 1. Chemical structures of the materials used for the formation of the monolayers: (a) Me-4PACz and (b) 6dPA. Close-up optical images of the representative PSCs with (c) Me-4PACz and (d) Me4PACz+6dPA selective contact layer. Highlighted in red are the active cell areas not covered by perovskite film. Scale bar = 5 mm. (e, f) Optical images of the contact angle measurements made using triple-cation perovskite precursor solution on top of ITO/ monolayer substrates. 

of the pixels being shunted due to reasons unrelated to problems with the surface coverage (Figures 1d and S8). 

For a quantitative evaluation of the influence of the additive on changes in the surface energy, we measured the surface energy components (total, dispersive, and polar) using the modified Owens−Wendt method (for more details see Table S3 and Figure S7). The addition of 6dPA led to ∼10% increase in the total energy (from 36.1 to 40.5 mN/m). The majority of this increase comes from the polar part, due to the additional phosphonic acid groups on the surface of the monolayer. Also, the part of polar energy has increased from 8.2% for ITO/Me4PACz to 14.5% for ITO/Me-4PACz+6dPA, which was enough to have an impact on the improved surface coverage and reduction of the perovskite precursor solution contact angle from 42° to 28° (Figure 1e,f). 

To check the influence of the additive on the performance of the solar cells, we fabricated p-i-n PSCs with an ITO/HSM/ perovskite/LiF/C60/BCP/Ag architecture. Two popular perovskite compositions were used, known as “triple-cation” (FA0.79MA0.16Cs0.05Pb(I0.83Br0.17)3)<sup>10</sup> and “triple-halide” (FA0.75Cs0.22MA0.03Pb(I0.82Br0.15Cl0.03)3),<sup>11</sup> in two different laboratories (CU Boulder, CO, USA and HZB, Berlin, Germany). (See the SI for details on the fabrication.) Clearly, the addition of the second component had no negative effect on PCE (Figure 2a) and other performance parameters (Table S1, Figures S1−S3), and both average and best pixels had slightly higher values for the mixed monolayer cases, with comparable standard deviations (Table S1). The highest efficiency of 20.9% 



Figure 2. (a) Statistical distribution of the PCE for the device with pure Me-4PACz and mixed monolayer with two different perovskite compositions (shunted devices were excluded from analysis). (b) Comparison of the small area and 1 cm<sup>2</sup> performance of devices with triple-cation perovskite composition and Me-4PACz+6dPA monolayer. For both images, reverse scan is the darker color and forward scan is the lighter color. 

was achieved for devices fabricated with triple-halide perovskite and mixed Me-4PACz+6dPA monolayer, a state-of-the-art value for a 1.68 eV bandgap. 

The negligible impact of the additive on the perovskite film was further confirmed by SEM images and the quasi-Fermi-level splitting (QFLS) of the triple-halide perovskite on the ITO/ monolayer samples. The morphologies of the films are similar (Figure S6), and the same QFLS values of 1.26 eV were obtained for both compositions (Figure S15), in line with the previous results for perovskite on Me-4PACz.<sup>2</sup> It was further observed that for the films with 20 and 50 mol% of 6dPA, device performance was very close (Table S2, Figure S4). 

As additional proof of the significant effect of the additive on the manufacturability of PSCs, we made devices using the new material _t_ Bu-4PACz, where bulky aliphatic _tert_ -butyl groups were introduced instead of methyl groups (Scheme S1, Figures S9−S14). Our previous attempts to fabricate devices with this material were hindered by the very poor wettability of the substrate by the perovskite solution. However, by adding 6dPA we were able to get working devices with PCE as high as 18% (Figure S5). Despite lower FF values, this example demonstrates the possibility of further expanding the structural optimization of monolayer-based HSMs. 

Finally, the impact of the improved wetting was demonstrated in devices with a 1 cm<sup>2</sup> active area. Devices with an average PCE of 17.8% (18.7% best) were fabricated (Figure 2b), mainly limited by the FF. This could be attributed to the poor charge collection by the ITO substrate. Nevertheless, this result 

**899** 

https://doi.org/10.1021/acsenergylett.2c02629 _ACS Energy Lett._ 2023, 8, 898−900 

**<u>ACS Energy Letters</u>** 

**<mark>http://pubs.acs.org/journal/aelccp</mark>** 

<mark>Energy Express</mark> 

demonstrates the scalability of the proposed method to larger areas. 

In conclusion, we demonstrated a simple and easy-toimplement method to circumvent issues associated with the hole-selective monolayer formed from Me-4PACz. Addition of 6dPA to the monolayer precursor solution improves the wettability of the substrate by the perovskite solution while maintaining the performance of the devices. In addition, 1 cm<sup>2</sup> devices were demonstrated with a high PCE of 18.7%, demonstrating the great potential of the method. 

# ■<sup>**ASSOCIATED CONTENT**</sup> 

### * **sı Supporting Information** 

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsenergylett.2c02629. 

Experimental protocols on the fabrication of devices, measurements of the surface energy, and details of the synthesis (PDF) 

# ■<sup>**AUTHOR INFORMATION**</sup> 

#### **Corresponding Author** 

- Artiom Magomedov − _Department of Organic Chemistry, Kaunas University of Technology, Kaunas 50254, Lithuania; Department of Chemical and Biological Engineering, University of Colorado, Boulder, Colorado 80309, United States;_ orcid.org/0000-0003-3159-1870; 

- Email: artiom.magomedov@ktu.lt 

#### **Authors** 

- Amran Al-Ashouri − _Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin fu_ ̈ _r Materialien und Energie GmbH, 12489 Berlin, Germany;_ orcid.org/0000-00015512-8034 

- Mantas Marc **̌** inskas − _Department of Organic Chemistry, Kaunas University of Technology, Kaunas 50254, Lithuania_ 

- Ernestas Kasparavic **̌** ius − _Department of Organic Chemistry, Kaunas University of Technology, Kaunas 50254, Lithuania_ 

- Tadas Malinauskas − _Department of Organic Chemistry, Kaunas University of Technology, Kaunas 50254, Lithuania;_ orcid.org/0000-0002-5478-6550 

- Axel Palmstrom − _National Renewable Energy Laboratory, Golden, Colorado 80401, United States;_ orcid.org/00000001-6633-209X 

- Vytautas Getautis − _Department of Organic Chemistry, Kaunas University of Technology, Kaunas 50254, Lithuania;_ orcid.org/0000-0001-7695-4677 

associates of Quantum Yield Berlin GmbH (LuQY Pro PL setup). M.D.M. is an advisor to Swift Solar. 

# ■<sup>**ACKNOWLEDGMENTS**</sup> 

A.M. acknowledges funding from the Fulbright Scholar Program. Funding for A.A.A. and S.A. was provided by the Federal Ministry of Education and Research (BMBF) through the project PEROWIN (grant no. 03SF0631) and by the Helmholtz Association within the projects HySPRINT Innovation lab, the EU Partnering project TAPAS, and the project “Zeitenwende − Tandem Solarzellen”. This material is based upon work supported by the U.S. Department of Energy’s Office of Energy Efficiency and Renewable Energy (EERE) under Solar Energy Technologies Office (SETO) Agreement Number DEEE0009513 (M.D.M.). 

# ■<sup>**REFERENCES**</sup> 

(1) _Best Research-Cell Efficiency Chart | Photovoltaic Research | NREL_ . https://www.nrel.gov/pv/cell-efficiency.html (accessed 2022-11-15). 

(2) Al-Ashouri, A.; Köhnen, E.; Albrecht, S.; et al. Monolithic Perovskite/Silicon Tandem Solar Cell with > 29% Efficiency by Enhanced Hole Extraction. _Science_ 2020, _370_ , 1300. 

(3) Tockhorn, P.; Albrecht, S.; Becker, C.; et al. Nano-Optical Designs for High-Efficiency Monolithic Perovskite-Silicon Tandem Solar Cells. _Nat. Nanotechnol._ 2022, _17_ , 1214. 

(4) Jost, M.; Albrecht, S.; et al. Perovskite/CIGS Tandem Solar Cells:̌ From Certified 24.2% toward 30% and Beyond. _ACS Energy Lett._ 2022, _7_ , 1298. 

(5) Jiang, Q.; Yan, Y.; Zhu, K.; et al. Surface Reaction for Efficient and Stable Inverted Perovskite Solar Cells. _Nature_ 2022, _611_ , 278. 

(6) Li, L.; Zhang, L.; Tan, H.; et al. Flexible All-Perovskite Tandem Solar Cells Approaching 25% Efficiency with Molecule-Bridged HoleSelective Contact. _Nat. Energy_ 2022, _7_ , 708. 

(7) Liu, J.; de Wolf, S.; et al. Efficient and Stable Perovskite-Silicon Tandem Solar Cells through Contact Displacement by MgFx. _Science_ 2022, _377_ (6603), 302. 

(8) Datta, K.; Janssen, R. A.; et al. Monolithic All-Perovskite Tandem Solar Cells with Minimized Optical and Energetic Losses. _Adv. Mater._ 2022, _34_ (11), 2110053. 

(9) Saliba, M.; Abate, A.; et al. How to Make over 20% Efficient Perovskite Solar Cells in Regular (n-i-p) and Inverted (p-i-n) Architectures. _Chem. Mater._ 2018, _30_ , 4193. 

(10) Saliba, M.; et al. Cesium-Containing Triple Cation Perovskite Solar Cells: Improved Stability, Reproducibility and High Efficiency. _Energy Environ. Sci._ 2016, _9_ , 1989. 

(11) Xu, J.; McGehee, M. D.; et al. Triple-Halide Wide-Band Gap Perovskites with Suppressed Phase Segregation for Efficient Tandems. _Science_ 2020, _367_ , 1097. 

- Steve Albrecht − _Perovskite Tandem Solar Cells, HelmholtzZentrum Berlin fu_ ̈ _r Materialien und Energie GmbH, 12489 Berlin, Germany; Fakultät Elektrotechnik und Informatik, Technische Universität Berlin, 10587 Berlin, Germany;_ orcid.org/0000-0001-9962-9535 

- Michael D. McGehee − _Department of Chemical and Biological Engineering, University of Colorado, Boulder, Colorado 80309, United States;_ orcid.org/0000-0001-9609-9030 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsenergylett.2c02629 

#### **Notes** 

The authors declare the following competing financial interest(s): HZB and KTU have filed patents for the SAM molecules and their use in solar cells. A.A.A. and S.A. are 

**900** 

https://doi.org/10.1021/acsenergylett.2c02629 _ACS Energy Lett._ 2023, 8, 898−900 

