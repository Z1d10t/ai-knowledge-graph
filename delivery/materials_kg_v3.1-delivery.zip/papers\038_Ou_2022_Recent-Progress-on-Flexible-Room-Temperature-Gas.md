# Recent Progress on Flexible Room-Temperature Gas Sensors Based on Metal Oxide Semiconductor

| 字段 | 内容 |
|---|---|
| 期刊 | Nano-Micro Letters |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 372 |
| 作者 | Lang-Xi Ou, Meng Liu, Li-Yuan Zhu, David Wei Zhang, Hong-Liang Lu |
| DOI | 10.1007/s40820-022-00956-9 |
| 源文件 | 038_Ou_2022_Recent-Progress-on-Flexible-Room-Temperature-Gas.pdf |

---
e‑ISSN 2150‑5551 CN 31‑2103/TB 

https://doi.org/10.1007/s40820‑022‑00956‑9 

## **<mark>REVIEW</mark>** 



# **Recent Progress on Flexible Room‑Temperature Gas Sensors Based on Metal Oxide Semiconductor** 

###### **Cite as** 

Nano‑Micro Lett. (2022) 14:206 

Lang‑Xi Ou<sup>1</sup> , Meng‑Yang Liu<sup>1</sup> , Li‑Yuan Zhu<sup>1</sup> , David Wei Zhang<sup>1</sup> , Hong‑Liang Lu<sup>1,2*</sup> 

Received: 12 July 2022 Accepted: 12 September 2022 Published online: 21 October 2022 © The Author(s) 2022 

#### **HIGHLIGHTS** 

- Latest progress on flexible room temperature (FRT) gas sensor based on metal oxide semiconductors (MOS) is comprehensively reviewed. 

- FRT gas sensor based on pristine MOS and MOS modified with noble metal nanoparticles, organic polymers, carbon based materials and transition metal dichalcogenide materials are meticulously reviewed. 

- The gas sensing mechanism of MOS chemiresistive gas sensors are introduced and the applications, future perspectives, and chal‑ lenges of FRT gas sensors are also proposed. 

**ABSTRACT** With the rapid development of the Internet of Things, there is a great demand for portable gas sensors. Metal oxide semiconductors (MOS) are one of the most traditional and well‑studied gas sensing materials and have been widely used to prepare various commercial gas sensors. However, it is limited by high operat‑ ing temperature. The current research works are directed towards fabricating high‑ performance flexible room‑temperature (FRT) gas sensors, which are effective in simplifying the structure of MOS‑based sensors, reducing power consumption, and expanding the application of portable devices. This article presents the recent research progress of MOS‑based FRT gas sensors in terms of sensing mechanism, performance, flexibility characteristics, and applications. This review comprehensively summarizes and discusses five types of MOS‑based FRT gas sensors, including pristine MOS, noble metal nanoparticles modified MOS, organic polymers modified MOS, carbon‑ based materials (carbon nanotubes and graphene derivatives) modified MOS, and two‑dimensional transition metal dichalcogenides materials modified MOS. The effect 



<!-- Start of picture text -->
Gas sensors<br>e<br>nopar<br>m<br>a<br>t<br>m<br>ti<br>s<br>n<br>cl<br>o<br>n<br>e<br>tio<br>i<br>al es<br>ica<br>c<br>m<br>dif<br>et<br>o<br>e<br>m<br>mo Li<br>o<br>m od<br>s gh<br>r<br>d<br>le<br>ta<br>if<br>ial<br>p<br>n<br>ob ic<br>er ct<br>i<br>N<br>iv<br>at<br>e<br>at<br>e<br>x d<br>at<br>io<br>l<br>m io<br>on<br>r<br>n<br>o<br>ti<br>d<br>u<br>b<br>n<br>ca<br>a<br>se<br>i<br>l<br>ifi<br>c<br>t<br>ba<br>x<br>a<br>od<br>t<br>n-<br>u<br>m<br>t<br>e<br>e<br>s<br>bo<br>o<br>r<br>T<br>l<br>er<br>ar<br>M<br>e<br>M<br>m<br>F<br>C<br>D<br>r<br>ly Cs<br>po m<br>s<br>inc od<br>Orga ifiitca<br>no<br><!-- End of picture text -->

of light‑illuminated to improve gas sensing performance is further discussed. Furthermore, the applications and future perspectives of FRT gas sensors are also discussed. 

**KEYWORDS** Metal oxide semiconductor; Flexible gas sensor; Room temperature; Nanomaterials 

> * Hong‑Liang Lu, honglianglu@fudan.edu.cn 

> 1 State Key Laboratory of ASIC and System, Shanghai Institute of Intelligent Electronics &Systems, School of Microelectronics, Fudan University, Shanghai 200433, People’s Republic of China 

> 2 Yiwu Research Institute of Fudan University, Chengbei Road, Yiwu City 322000, Zhejiang, People’s Republic of China 

1 3 

**206** Page 2 of 42 

Nano‑Micro Lett. (2022) 14:206 

### **1 Introduction** 

In the past decade, the Internet of Things (IoTs), the net‑ works that connects diverse sensors and actuators, has attracted enormous attention [1–5]. Traditional electronic sensors are gradually transforming from bulky solid‑state devices to portable, high‑performance, and multifunctional devices. The rapid development of flexible electronics makes them play a significant role in the wide applications of IoTs, which serves as an ideal platform for wearable devices [6–12]. In recent years, flexible and wearable devices have been used as attractive alternatives to bulky analytical instru‑ ments and applied to perform continuous physiological monitoring of body movement, blood temperature, blood glucose, heart rate, and electrophysiological activities such as electroencephalography, electrocardiography, and elec‑ tromyography [13–16]. Recently, metaverse has become a hot issue. Metaverses are sensory‑rich virtual worlds where people engage with each other as virtuous avatars without any physical limitations [17, 18]. Wearable devices integrat‑ ing kinds of sensors, which can conduct continuous physi‑ ological monitoring and real‑time interaction with software agents, are of vital importance to the rapid development of metaverse [19]. 

Various hazardous gases are released from industrial and agricultural processes, such as CO,  NOx,  NH3,  H2,  H2S, and volatile organic compounds (VOCs), including ethanol, isopropanol, acetaldehyde, and formaldehyde [20–23]. The leakage of these pollutant gases will not only pollute the environment, but also have a detrimental effect on human body [24–27]. For instance, emissions of  NOx from coal fired power stations lead to ozone holes, acid rain and severe haze in metropolitan areas, causing serious damage to human health, the ecological environment and the national economy [28–30]. In particular, serious air pollution can damage the lungs of humans, facilitating the transmission and infection of COVID‑19 [31–34]. Real‑time detection of toxic gases in industrial production and the development of wearable gas warning devices are of significant to workers, especially in environments where toxic gas leaks can occur. In addi‑ tion to the need for timely detection of hazardous gases, the detection of specific gases is also widely used in the area of medical healthcare [35]. Gas chromatography–mass spectrometry analysis of human exhaled gas showed that the exhaled gas contains more than 870 different VOCs [36–38]. 

It is noticeable that the presence of some specific VOCs is related to specific diseases [39–41]. Through a simple breath analysis, many diseases can be diagnosed and therapeutic monitored noninvasively [42, 43]. For instance, ammonia and fatty acids are found in the breath of patients with cir‑ rhosis, while acetone and isoprene are found in the breath of patients with diabetes [44–46]. However, the conventional technology of breath analysis requires bulky and expensive equipment, long time‑consumption and well‑trained per‑ sonnel. Therefore, there is an increasing requirement for high‑performance gas sensors with low‑cost, high sensitiv‑ ity, rapid response, fabulous selectivity, and low limit of detection (LOD). 

Mechanically flexible gas sensors are one of the most pop‑ ular and forefront research directions of IoTs, meeting the enormous industrial requirements of smart wearable devices [47]. Moreover, they are crucial for monitoring environmen‑ tal gases, gaseous pollutants, volatile hazards, humidity, exhaled gases, body odor, nerve agents or explosives, and food quality. Conventional gas sensors are typically manu‑ factured on inorganic substrates, including quartz, glass, alumina ceramic tubes and silicon wafers. However, their rigidity and fragility limit their application in a variety of new fields. In contrast, the integration of gas sensors on flex‑ ible substrates, such as polymer, textiles, and paper‑based substrates has attracted the increasing attention of research‑ ers over the past few years, making them highly promising in the fields of portable electronics [48–51], smart textiles [52–54], radio frequency identification (RFID) [55–59], and medical health [60–62]. However, the sensing performance of flexible gas sensors including response value, selectivity, response/recovery time, and LOD is largely influenced by operating temperature, which generally require the configu‑ ration of microheaters, resulting in high energy consump‑ tion, great complexity of microstructure, and limitations of applications [63]. Therefore, the flexible gas sensors operating at room temperature (RT) are gradually arousing extensive attention. Their portability, excellent mechanical flexibility in harsh environments, and low energy consump‑ tion make them promising for various applications. Recently, flexible room‑temperature (FRT) MOS‑based sensors have been reported to detect a variety of gases, including  NO2 [54, 64–78],  NH3 [79–89],  H2 [90–94],  H2S [68, 95–98],  C2H2 [99], ethanol [100–103], acetaldehyde [104], formaldehyde [105], acetone [106], ozone [107], isopropanol [108], tri‑ methylamine [109], and triethylamine [110, 111]. Beyond 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 3 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

that, some reported FRT gas sensors have been applied to practical applications, such as smart face masks [100], E‑textiles [54, 104], passive wireless RFID [112], disease detection [98], and large‑scale flexible sensors array [65, 113], exhibiting broader application prospects in the fields of IoTs, metaverses, industrial production, medical application, etc. Nowadays, personalized wearable FRT gas sensors are extensively employed to monitor the exhaled gas of patients while they are out of hospital and provide sufficient infor‑ mation [48, 114]. For example, ketogenic diets (KDs) can perform more effective weight loss when cooperated with a FRT acetone gas sensor monitoring the concentration of exhaled acetone [115, 116]. 

The FRT gas sensors have high requirements for sensing materials that not only perform well at RT, but also under bending conditions. In general, traditional gas sensing mate‑ rials including metal oxide semiconductor (MOS), con‑ ducting polymers, and carbon‑based materials [117–122]. Among them, MOS is the most popular commercial sensing material due to its merits of easy synthesis, high response value, low cost, short response/recovery time, great revers‑ ibility, and excellent stability [123–129]. However, its disad‑ vantages such as high‑temperature operation and high‑power consumption hinder its wearable applications [130–132]. What’s worse, high‑temperature operation not only degrades the nanostructure of the sensing material, deteriorating the gas sensing performance, but also hinders the detection of explosive or flammable gases. Therefore, the ability of the MOS‑based sensors to work at RT is of vital significance because it leads to very low power consumption and simpli‑ fies the sensor structure. At the meantime, the conducting polymers‑based sensors can operate at RT without addi‑ tional power requirements, but their performance degrades in humid environment. In addition, the carbon‑based mate‑ rials can also greatly lower the operating temperature and contribute to high sensitivity, but long response/recovery time and complex processes render them inadequate for wide application [98, 133–135]. To achieve high‑performance FRT MOS‑based chemiresistive gas sensors, optimization has been performed from material design and alternate activation, which is graphically presented in Fig. 1. The thought of combining MOS with conducting polymers or carbon‑based materials is proposed owing to the integrated advantages of both components [136–142]. Beyond that, a number of strategies have been used to improve sensing performance of MOS‑based FRT gas sensors up to now, 



<!-- Start of picture text -->
Gas sensors<br>e<br>nopar<br>m<br>a<br>t<br>m<br>ti<br>s<br>n<br>cl<br>o<br>n<br>e<br>tio<br>i<br>al es<br>ica<br>c<br>m<br>dif<br>et<br>o<br>e<br>m<br>mo Li<br>o<br>m od<br>s gh<br>r<br>d<br>le<br>ta<br>if<br>ial<br>p<br>n<br>ob ic<br>er ct<br>i<br>N<br>iv<br>at<br>e<br>at<br>e<br>x d<br>at<br>io<br>l<br>m<br>io<br>on<br>r<br>n<br>o<br>ti<br>d<br>u<br>b<br>n<br>ca<br>a<br>se<br>i<br>l<br>ifi<br>c<br>t<br>ba<br>x<br>a<br>od<br>t<br>n-<br>u<br>m<br>t<br>e<br>e<br>s<br>bo<br>o<br>r<br>T<br>l<br>er<br>ar<br>M<br>e<br>M<br>m<br>F<br>C<br>D<br>r<br>ly Cs<br>po m<br>s<br>inc od<br>ga ifi<br>ca<br>Or it<br>no<br><!-- End of picture text -->

**Fig. 1** The strategies to achieve high‑performance FRT MOS‑based chemiresistive gas sensors 

such as morphological modification of pristine MOS, noble metal nanoparticles modified MOS, light‑illuminated MOS, and two‑dimensional (2D) transition metal dichalcogenides (TMDCs) modified MOS. Table 1 summarizes various reported MOS‑based FRT sensors. 

Several reviews based on flexible gas sensors have also been published, introducing carbon‑based [49, 143, 144], organic polymers‑based [145], and TMDC‑based [146] gas sensors. In addition, several reviews dedicated to RT gas sensors have been published, discussing the development of various nanostructured materials‑based RT gas sen‑ sors [120, 132, 147, 148] and MOS‑based chemiresistive RT gas sensors [118, 149]. However, no comprehensive review focusing on the recent advances on MOS‑based FRT gas sensors is available. Consequently, this review will systematically summarize and analyze the sensing mechanisms and recent advances in FRT MOS‑based gas sensors based on pristine MOS, noble metal nanopar‑ ticles modified MOS, organic polymers modified MOS, carbon‑based materials modified MOS, TMDCs materials modified MOS. In addition, the effect of light‑illuminated on improving the gas sensing performance is further dis‑ cussed. The current applications of FRT gas sensors are also summarized. 

1 3 

**206** Page 4 of 42 

Nano‑Micro Lett. (2022) 14:206 

|References|[90]<br>[92]<br>[102]<br>[70]|[104]<br>[103]<br>[69]|[78]<br>[107]|[105]|[109]<br>[82]<br>[71]<br>[76]<br>[233]|[91]<br>[93]|[99]<br>[80]|[172]<br>[79]|[74]||
|---|---|---|---|---|---|---|---|---|---|---|
|ycles Response<br>decrease/bend‑<br>ing cycles|–<br>–<br>–<br>–|–<br>–<br>–|–<br>–|No obvious<br>decrease|–<br>–<br>–<br>< 66.7%/4,000<br>–|–<br>13%/105,<br>52%/106|10.6%/104<br>No obvious<br>d|ecrease<br>21%<br>No obvious<br>d|ecrease<br>No obvious<br>decrease||
|Bending c|–<br>–<br>–<br>–|–<br>–<br>–|–<br>–|200|–<br>–<br>–<br>4,000<br>–|–<br>106|104<br>1,000|1,000<br>100|4,000||
|LOD|–<br>–<br>–<br>0.25 ppm|–<br>10 ppm<br>3 ppm|10 ppb<br>15 ppb|3.8 ppb|40 ppm<br>5 ppm<br>2 ppm<br>1.88 ppm<br>0.1 ppm|0.2 ppm<br>0.2 ppm|3 ppm<br>1 ppm|500 ppb<br>–|1 ppm||
|τres/τrec|~ 600/s<br>149/122 s<br>–<br>60/230 min|228/14 s<br>5/3 s<br>105/785 s|–<br>7/min|9/ ~ 300 s|~ 25/s<br>90/120 s<br>50/30 s<br>17/25 s<br>–|~ 18.8/s<br>~ 18.8/s|66/68 s<br>17/16 s|113/159 s<br>118/144 s|–||
|) Response|5c<br>109c<br>2.2a<br>2.568b|33c<br>~ 1.4a<br>5.75a|5.52<br>~ 72.5c|>  570b|150c<br>~ 0.25b<br>~ 1,100c<br>18,500c<br>56c|91c<br>91.2c|26.2a<br>7.08a|13.6<br>46a|27.33c||
|C (ppm|1,000<br>500<br>800<br>1|100<br>100<br>5|0.5<br>1.07|5|400<br>5<br>200<br>10<br>0.1<br>_i_|_i    rs_<br>1,000<br>1,000|1,000<br>100|100<br>100|20||
|Target gas|H2<br>H2<br>Ethanol<br>l<br>NO2|l<br>Acetaldehyde<br>Ethanol<br>NO2|NO2<br> <br>Ozone|Formaldehyde|TMA<br>NH3<br>NO2<br>NO2<br>NO2<br>_i_|_i S FRT gas senso_<br>H2<br>H2|C2H2<br>NH3|NH3<br>NH3|NO2|_i   as sensors_|
|Synthesis<br>method|_as sensors_<br>Hydrothermal<br>Hydrothermal<br>–<br>Suspension<br>flame spraying|l<br>Sol–gel<br>Hydrothermal<br>Oxidation|Electrospun<br>Magnetron sput‑<br>terin|g<br>Spinning|Anodization<br>Hydrothermal<br>Hydrothermal<br>Granule spray<br>Electrospun<br>_i_|_ticles modified MO_<br>Hydrothermal<br>Hydrothermal|Hydrothermal<br>Electrospun|Electrospun<br>Hydrothermal|Chemical pre‑<br>cipitation|_dified MOS FRT g_|
|Substrate|_istine MOS FRT g_<br>PET<br>Nylon<br>PET<br>PP|Cotton fabrics<br>PVA<br>PI|PI<br>PET|PET|PI<br>PET<br>PET<br>PI<br>PET/PDMS/<br>Paper<br>_i_|_ble metal nanopar i_<br>PI<br>PI/PET|PI<br>PET|PET<br>PI|PI|_ganic polymers moi_|
|Structure|_performance of pr_<br>Nanowires<br>Nanorods<br>Nanoparticles<br>Sheet‑like|Nanoparticles<br>Cubic crystals<br>Octahedral<br>nanoowders|p<br>Nanowires<br>Thin films|Thin films|Nanotubes<br>Nanorectangles<br>Nanoparticles<br>Films<br>Nanofibers<br>_i_|_performance of no   i_<br>Nanorods<br>Nanorods|Nanorods<br>Nanotubes|Nanotubes<br>Nanospheres/<br>Nfib|anoiers<br>Nanocubes|_performance of or  i_|
|Material|_Part A: Sensing_<br>ZnO<br>ZnO<br>ZnO<br>ZnO1‑x|ZnO<br>In2O3<br>In2O3|In2O3<br>InOx|TiO2|TiO2<br>CuO<br>Cellulose/Fe2O3<br>WO3‑δ<br>SnO2/ZnO<br>_i_|_Part B: Sensing      i_<br>Ga/ZnO<br>Pd/ZnO|Ag/ZnO<br>Pt/SrGe4O9|PANI/Rh/SnO2<br>PANI/In2O3/Au|SWCNT/PdO/<br>Co3O4|_Part C: Sensing     i_|



© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 5 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

|References|[87]|[83]|[81]|[85]|[89]|[84]|[234]|[86]|[110]|[111]|[186]|[106]|[97]|[95]|[96]|[73]|[72]|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|cycles Response<br>decrease/bend‑<br>ing cycles|–|No obvious<br>decrease|–|–|–|3.4%/500|No obvious<br>decrease|–|–|–|26.5%/500|No obvious<br>decrease|–|–|No obvious<br>decrease|0.7%/106,<br>2.1%/108|No obvious<br>decrease|
|Bending|–|500|–|–|–|500|100|–|–|–|500|60|–|–|5|108|106|
|LOD|500 ppb|16 ppb|2.5 ppm|0.5 ppm|5 ppm|25 ppb|10 ppb|> 1.8 ppm|1.2 ppm|0.55 ppm|500 ppb|0.1 ppm|15 ppm|15 ppm|10 ppm|0.1 ppm|1 ppm|
|e τres/τrec|13/49 s|14/6 min|50/1575 s|100/s|27/46 s|24.3/ ~ 410 s|125/167 s|34/s|~ 5/s|35/88.42 s|46/54 s|15/27 s|~ 13.6/s|~ 52|~ 19.1/s|10/27 min|7/15 min|
|) Respons|7a|262.7c|72c|6.12a|39c|118.3c|29.8|29a|69a|22.6a|20.4|2c|2.75a|~  20c|~  12c|14c|17c|
|C (ppm|10|50|100|100|100|50|100|100|100|100|100|0.5|200|300|300|_i    s_<br>5|5|
|Target gas|<br>NH3|NH3|NH3|NH3|<br>NH3|<br>NH3|NH3|<br>NH3|<br>TEA|<br>TEA|<br>NH3|<br>Acetone|H2S|H2S|H2S|_i  FRT gas sensor_<br>NO2|NO2|
|Synthesis<br>method|In situ polymeri‑<br>zation|Self‑assembly|Sol–gel|Hydrothermal|In situ polymeri‑<br>zation|In situ polymeri‑<br>zation|Hydrothermal|In situ polymeri‑<br>zation|In situ polymeri‑<br>zation|In situ polymeri‑<br>zation|In situ polymeri‑<br>zation|In situ polymeri‑<br>zation|Sol–gel|Hydrothermal|Sol–gel|_erials modified MOS_<br>Hydrothermal|Hydrothermal|
|Substrate|PET|PI|PET|PET|PET|PET|PET|PET|PET|PET|PET|PET|Chitosan/IL|CMC/IL|PVA/IL|_bon-based mat i_<br>PET|PI/PET|
|Structure|Nanofibers/<br>Flowerlike|Nanosheet/<br>Nanoparticle|Nanofiber/Nano‑<br>particle|Sea cucumber‑<br>shaped|Nanofiber/Nano‑<br>particle|Nanofiber/Nano‑<br>particle|Nanoparticles/<br>Nanofiber|i<br>Nanoparticle/<br>Nanofibers|i<br>Nanofibrous/<br>Nanoarticle|p<br>Nanorods/Nano‑<br>particle|Nanofiber/Nano‑<br>sphere|Nanopolyhedra/<br>Nanorob|Nanocomposite<br>membranes|Nanocomposite<br>membranes|Nanocomposite<br>membranes|_performance of car  i_<br>Nanoparticles|Nanoparticles|
|Material|PANI/WO3|PANI/CeO2|PANI/α‑Fe2O3|PANI/Fe2O3|PANI/α‑Fe2O3|PANI/CoFe2O4|SnO2@PANI|PANI@SnO2|PANI/SnO2|PANI/MoO3|PANI@SnO2/<br>Zn2SnO4|ZnO/S, N:<br>GQDs/PANI|Chitosan/WO3/<br>IL|CMC/CuO/IL|PVA/WO3/IL|_Part D: Sensing     i_<br>MWCNT/WO3|MWCNT/WO3/<br>RGO|



1 3 

**206** Page 6 of 42 

Nano‑Micro Lett. (2022) 14:206 

|References|[64]<br>[68]|[112]<br>[100]|[108]|[65]<br>[54]|[213]<br>[231]<br>[94]|[98]|[88]|[222]|[221]|[66]|[75]<br>[67]|s);  Responsec:<br>et gas, Δ_R_: the<br>Poly(3,4‑ethyl‑<br>yaniline;_GQD_<br>uced graphene|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Bending cycles Response<br>decrease/bend‑<br>ing cycles|–<br>–<br>16<br>No obvious<br>decrease|–<br>–<br>1,000<br>No obvious<br>|decrease<br>100<br>No obvious<br>decrease|–<br>–<br>3,000<br>No obvious<br>decrease|–<br>–<br>1,000<br>10.3%/1,000<br>–<br>–|60<br>No obvious<br>decrease|3,000<br>No obvious<br>decrease|–<br>–|10,000<br>20.26%/1,0000|–<br>–|–<br>–<br>1,000<br>No obvious<br>decrease|educing gas) or Δ_R_/_R_a(oxidizing ga<br>e of the sensors exposed to the targ<br>yvinylidene fluoride;_PEDOT:PSS_ <br>_PG_Liquid petroleum gas;_PANI_Pol<br>rbides and carbonitrides;_RGO_Red|
|LOD|0.1 ppm<br>1 ppm|100 ppb<br>–|1 ppm|50 ppb<br>0.2 ppm|100 ppm<br>20 ppm<br>0.5 ppm|50 ppb|1 ppm|3 ppm|s 0.5 ppm|50 ppb|2 ppm<br>20 ppb|b: Δ_R_/_R_g(r<br>_R_g: resistanc<br>;_PVDF_Pol l<br>ylamine;_L_<br>on metal ca|
|e τres/τrec|–<br>300/300 s|7/28 s<br>992/301 s|60/s|4.2/13.3 min<br>140/630 s|–<br>412/587 s<br>34/142 s|82/78 s|21/110 s|–|~ 180/ ~ 330|31/44 s|–<br>5/5 s|gas);  Response<br>ckground gas,<br>ethyl siloxane)<br>ine;_TEA_Trieth<br> _Mxene_Transiti|
|) Respons|~  32c<br>19/18.3c|~  35c<br>1.09a|4.96a|31.6c<br>44c|77c<br>0.2640b<br>49.2c|60.11c|2.48a|7.57|3.687|7.2a|~ 1.3a<br>33.2c|(oxidizing<br>ed to the ba<br>_S_Poly(dim<br>rimethylam<br>nanotubes;|
|C (ppm|1,000<br>10/100|1<br>500|100|1<br>15|600<br>100<br>100|2|100|9|50|1|5<br>20|as) or_R_g/_R_a <br>nsors expos<br>mide;_PDM_<br>ose;_TMA_T<br>led carbon|
|Target gas|NO2<br>NO2/H2S|H2S<br>Ethanol|Isopropanol|NO2<br>NO2|LPG<br>NO2<br>H2|‑<br>H2S<br>_i_|_i   as sensors_<br>NH3|NO2|NH3<br>_i   as sensors_|_i   g_<br>NO2|_i   as sensors_<br>NO2<br>NO2|_R_g(reducing g<br>tance of the se<br>cohol;_PI_Polyi<br>ymethyl cellul<br>_CNT_Multi‑wal|
|Synthesis<br>method|Heat treatment<br>CVD|Hydrothermal<br>Redox reaction|Hydrothermal|–<br>–|–<br>Spraying<br>Hot press|In situ polymeri<br>zation<br>_i_|_odified MOS FRT g_<br>Hydrothermal|E‑beam evapo‑<br>ration|Sol–gel<br>_odified MOS FRT_|_i_<br> <br>ALD|_i transistors FRT g_<br>CVD<br>Blow‑spinning|e;  Responsea=_R_a/<br>izing gas)._R_a: resis<br>he target gas<br>;_PVA_Polyvinyl al<br>quid;_CMC_Carbox<br>on nanotubes;_MW_|
|Substrate|Textile fabric<br>PP|PP<br>Nylon|PET|PI<br>Cotton/elastic<br>threads|–<br>PI<br> <br>PVDF|PET<br>_i_|_MDCs materials mi_<br>PET|PET|PI<br>_oranic materials i_|_g  i_<br>Yttria‑stabilized<br>zirconia|_GZO based thin-film_<br>PI<br>PEDOT:PSS|e time/recovery tim<br> _R_/_R_a**×**100% (oxid<br>after exposure to t<br> _PP_Polypropylene<br>ulfonate;_IL_Ionic li<br>Single‑walled carb<br>oxide|
|Structure|Nanofiber<br>Nanospheres|Flower‑shaped<br>Quantum dot|Nanoneedles|Nanoparticles<br>Nanosheet|Nanoparticles<br>Nanoparticles<br>Hot‑press thick<br>film|Hollow spheres<br>_i_|_erformance of T  i_<br>Nanotubes|Thin films|Nanotubes<br>_erformance of in  i_|_i_<br>Nanofibers|_performance of I  i_<br>Thin films<br>Nanofiber net‑<br>work|; τres/τrec: respons<br>educing gas) or Δ<br>nce of the sensors<br>ne terephthalate);<br>ne) polystyrene s<br>m dots;_SWCNT_ <br>um gallium zinc|
|Material|MWCNT/Co3O4 <br>SWCNT/Fe2O3|SWCNT/CuO<br>SWCNT@ZnO|RGO/<br>WO3·0.33H2O|In2O3@RGO<br>RGO/ZnO|Graphene/CdO<br>RGO/SnO2<br>RGO/SnO2/<br>PVDF|SnO2/RGO/<br>PANI<br>_i_|_Part E: Sensing p    i_<br>SnO2/SnS2|SnO2/MoS2|Au/SnO2/WS2<br>_Part F: Sensin     i_|_g     i_<br>In2O3/g‑C3N4|_Part G: Sensing     i_<br>IGZO<br>IGZO|C: concentration<br>Δ_R_/_R_g**×**100% (r<br>change in resista<br>_PET_Poly(ethyle<br>enedioxythiophe<br>Graphene quantu<br>oxide;_IGZO_Indi|



© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 7 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

### **2  Gas Sensing Mechanism of MOS Chemiresistive Gas Sensors** 

##### **2.1  Pristine MOS Gas Sensing Mechanism** 

The gas sensing mechanism of MOS is based on the oxy‑ gen adsorption model, which assumes that the change in resistance is related to chemisorbed oxygen [150–152]. In air, oxygen molecules adsorb on the MOS surface and form negatively charged chemisorbed oxygen ( O<sup>−</sup> 2<sup>,  O−,</sup> O<sup>2−</sup> ) by trapping conduction band electrons. The type of chemisorbed oxygen is related to the operating temper‑ ature and species of MOS material, which significantly determines the sensing performance of the sensing mate‑ rial [153, 154]. However, the temperature interval corre‑ sponding to the presence of chemisorbed oxygen ions on metal oxides is not well known and varies from different metal oxides. In general, O<sup>−</sup> 2<sup>is usually chemisorbed when</sup> the temperature is below 100 °C. Once the temperature is between 100 and 300 °C,  O<sup>−</sup> is generally chemisorbed and O<sup>−</sup> 2<sup>disappears rapidly. And when the temperature exceeds</sup> 300 °C, the chemisorbed oxygen is mainly in the form of O<sup>2−</sup> [155]. The process of oxygen ion formation can be summarized by the following equations [156]: 

As a result of these processes, the resistance of the sens‑ ing layer will change significantly, which will result in the response of the gas sensor. Therefore, the sensitivity of the MOS‑based gas sensors is generally defined as _R_ a/ _R_ g (reducing gas), _R_ g/ _R_ a (oxidizing gas), ΔR/Rg (reducing gas), Δ _R_ / _R_ a (oxidizing gas), Δ _R_ / _R_ g × 100% (reducing gas), or Δ _R_ / _R_ a × 100% (oxidizing gas) (where _R_ a is the resist‑ ance of the sensors exposed to the background gas, _R_ g is the resistance of the sensors exposed to the target gas, Δ _R_ is the change in resistance of the sensors after exposure to the target gas). 

Conventionally, MOS‑based gas sensors are operated at 300–500 ℃ to provide sufficient activation energy to facilitate oxygen adsorption, which is also called thermal activation. In contrast, at RT, the chemisorbed oxygen ions on the MOS surface are mainly O<sup>−</sup> 2<sup>, with a low content of</sup> other chemisorbed oxygen ions, making it a challenge to achieve RT operation of MOS. From the perspective of material design, in order to achieve RT operation, pris‑ tine MOS materials can be nanoconstructed with differ‑ ent morphologies, facilitating efficient modulation of the electron depletion layer. In addition, the construction of heterogeneous structures by surface modification of MOS materials is also an efficient strategy. 

In air ∶ O2(gas) → O2(ads) (1) 



<!-- Start of picture text -->
T  <  100 ◦ C ∶ O2(ads) +  e − → O − 2 (ads) (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
100 ◦ C  <  T  <  300 ◦ C ∶ O − 2 (ads) +  e − → 2O−(ads) (3)<br><!-- End of picture text -->



<!-- Start of picture text -->
T  >  300 ◦ C ∶ O − (ads) +  e − → O 2− (ads) (4)<br><!-- End of picture text -->

As a result of oxygen adsorption, an electron depletion layer with a low electron concentration is formed on the surface of the n‑type MOS, which has a higher resistance than the core region due to the reduced number of elec‑ trons. While on the surface of the p‑type MOS, a hole accumulation layer is formed, which has a lower resist‑ ance than the core region of the MOS due to the increased number of holes. 

When exposed to the target reducing gases, the target molecules adsorb to the surface of MOS sensing layer and react with the chemisorbed oxygen ions, releasing elec‑ trons into the MOS material. Conversely, for oxidizing gases, more electrons are trapped from the MOS surface. 

##### **2.2  Heterostructured MOS‑Based Nanocomposites Gas Sensing Mechanism** 

Generally, MOS are often hybrids with other MOS, organic polymers, carbon‑based materials and TDMCs to signifi‑ cantly improve their sensing performance. Due to the dif‑ ferent energy band structures of MOS and hybrid materials, electrons or holes are transferred at the interface between the components until their Fermi levels equilibrate to the same energy level. This process results in the formation of hetero‑ junctions at the interface between the MOS and the hybrid materials. The formation of the heterojunctions modulates the thickness of the depletion/accumulation layer and the height of the potential barrier, changing the internal electron distribution between different components and significantly affecting the sensing performance of the sensing materials. When analyzing the mechanism of MOS nanocomposites, the effect of heterojunctions needs to be considered primar‑ ily. In this section, the mechanism of heterostructured MOS‑ based nanocomposites is illustrated with two subsections: 

1 3 

**206** Page 8 of 42 

Nano‑Micro Lett. (2022) 14:206 

anisotype heterojunction (p–n) and isotype heterojunctions (n–n, p–p). 

For the anisotype heterojunction (p–n), the Fermi energy level of the n‑type semiconductor is generally higher than the Fermi energy level of the p‑type semiconductor. There‑ fore, when two dissimilar materials with different Fermi levels contact, the electrons are transferred from the n‑type semiconductors to the p‑type semiconductors, and the holes are transferred from the p‑type semiconductors to the n‑type semiconductors until the Fermi energy levels are balanced. After that, a depletion layer is formed at their interface and the energy bands on both sides are bent to create a potential barrier, which makes the electron transport channel nar‑ rower. In addition, owing to the wider depletion layer width of the heterojunction, the initial resistance increases greatly compared to the pristine MOS. Therefore, when exposed to an oxidizing gas atmosphere, the increase in resistance is small. However, when exposed to a reducing gas atmos‑ phere, the resistance decreases sharply, which can improve the selectivity of the sensor to some extent. 

For the isotype heterojunction (n–n, p–p), the band bend‑ ing phenomenon also occurs due to the difference in Fermi energy levels. For n–n heterojunctions, electrons are trans‑ ferred from the side with high Fermi energy levels to the side with low Fermi energy levels, while an electron depletion layer is formed on the side with high Fermi energy levels and an electron accumulation layer is formed on the other side. Similarly, for p–p heterojunction, holes are transferred from the side with low Fermi energy levels to the side with high Fermi energy levels, while the hole accumulation layer is formed on the side with high Fermi energy levels and the hole depletion layer is formed on the other side. 

Generally, to achieve RT operation and enhanced sensing performance of MOS‑based gas sensors, two perspectives can be considered: material design and alternate activation. From the perspective of material design, for pristine MOS, reducing the grain size, constructing various morphologies with enhanced surface‑to‑volume ratio are considerable sensitization strategies. In addition, chemical and electronic sensitization can be achieved by decorating precious metals, which can significantly improve the sensing performance under RT. Hybridizing with some unique materials that can chemically react with the target gas is also an effective way to achieve RT operation. For instance, PANI reduces from the conductive emeraldine salt state to the non‑conductive intrinsic emeraldine base state when reacting with certain 

target gases, which improves the sensing performance at RT. The addition of carbon‑based materials to the MOS can also remarkably improve the conductivity of the MOS‑based nanocomposite and optimize its sensing properties at RT. The modification of 2D TMDCs can effectively modulate the heterojunction between MOS and TMDCs due to its unique surface effect, exhibiting great potential at RT as well. From the perspective of alternate activation, materials with self‑ heating capability can achieve thermal activation without microheaters. Photoactivation also facilitates the reaction with the target gas by introducing additional photogenerated electron–hole pairs, thus enhancing the gas sensing perfor‑ mance at RT. These specific sensing mechanisms will be discussed further in different chapters. 

### **3  Pristine MOS FRT Gas Sensors** 

Pristine MOS generally have great stability, reversibility, and their manufacturing process is facile and cost‑effective [157–159]. Various morphologies of nanostructures for pris‑ tine MOS including nanoparticles [71, 97, 101, 102, 104], nanorods [92], nanowires [90], nanotubes [109], nanocu‑ bic crystals [103], nanorectangles [82], sheet‑like [70], and columnar [160] nanostructures have been fabricated and employed in flexible gas sensors to help reducing operat‑ ing temperature to RT (Fig. 2). These sensors can be used to detect a variety of gases, including  NH3,  NO2,  H2,  H2S, ethanol, isopropanol, trimethylamine (TMA), formaldehyde, acetaldehyde and ozone, performing with good sensing performance. 

N‑type pristine MOS including ZnO,  In2O3,  WO3,  Fe2O3, and  TiO2 are the sensing materials that have been reported for FRT chemiresistive gas sensors. Among these materi‑ als, ZnO has been a fascinating FRT gas sensing material attributed to the fusion of its inherent characteristics such as high electron mobility, wide bandgap, excellent chemi‑ cal stability, non‑toxicity and biocompatibility as well as its versatility in fabricating various nanostructures such as nanorods [92], nanowires [90], nanoparticles [102, 104], columnar [160], and sheet‑like [70] nanostructures. Moham‑ mad et al. [92] fabricated hexagonal‑shaped and well‑ aligned ZnO nanorods assembled on nylon substrates using hydrothermal method. The high specific surface area and high crystalline quality of ZnO nanorods contributed to the good response of 109% to 500 ppm hydrogen ambient with 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 9 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
WO3<br>Fe2O3 7%<br>7%<br>CuO13% metal oxidePristine 40%ZnO<br>semiconductors<br>used for flexible<br>room temperature<br>TiO2 gas sensors<br>13%<br>In2O3<br>20%<br>ype<br>tp- nt-<br>py<br>e<br><!-- End of picture text -->

**Fig. 2** Schematic diagram of various pristine metal oxide semicon‑ ductor used for flexible room‑temperature gas sensors introduced in this chapter 

rapid response/recovery time. Ong et al. [90] synthesized ZnO nanowires with a simple low‑temperature hydrother‑ mal method and proposed three methods, slide transfer, roll transfer and thermal transfer, to transfer the samples onto flexible poly(ethylene terephthalate) (PET) substrates. The mechanically flexible ZnO nanowires gas sensor exhibited an n‑type response value of 5.0% to 1000 ppm hydrogen. However, the ZnO nanowires with surface modification of ammonia plasma exhibited p‑type hall results, indicating that ammonia plasma treatment can lead to effective con‑ ductivity modulation of the ZnO nanowires. Furthermore, the ammonia plasma‑treated ZnO nanowires showed a sig‑ nificantly enhanced response of 15% to 500 ppm hydrogen with no apparent degradation after 14 months long‑term test. Cotton fabrics have also been reported to be excellent flexible substrates for MOS‑based FRT gas sensors. Sub‑ biah et al. [104] reported a multifunctional acetaldehyde gas sensor developed by growing hexagonal‑shaped ZnO nanoparticles on cotton fabrics through seed layer enhanced sol–gel techniques. The introduction of cotton fabric con‑ tributes to the uniform distribution of ZnO nanoparticles and the high porosity between yarns. More importantly, this ZnO nanostructure‑modified cotton fabric is also equipped with ultraviolet (UV) radiation protection, which reveals its 

promising application in wearable gas sensing devices with UV filtering capability. 

In2O3 is also an outstanding material for FRT gas sensors due to its excellent low‑temperature gas sensing properties and the ability to synthesize different controllable morphol‑ ogies.  In2O3 cubic crystals were prepared by a modified hydrothermal synthesis [103] and then made into a flexible composite film by blending with polyvinyl alcohol (PVA). This flexible composite film exhibited a response of 1.4 to 100 ppm ethanol at RT with significantly rapid response/ recovery time of 5/3 s. Nanostructure of  In2O3 octahedral nanopowders [69] was fabricated by oxidation of ionic pre‑ cursor compound in low‑oxygen atmosphere. The nanopow‑ ders were further mixed with propanediol and then deposited on polyimide (PI) substrates. The obtained sensor exhibited a good response of 3 to 5 ppm  NO2 at 100 °C, perform‑ ing its great potential for FRT  NO2 sensors. Kiriakidis et al. [107] reported an ozone sensor based on  InOx thin films with cylindrical structure and nanosize grains of about 20 nm, grown by magnetron sputtering on PET substrate. The sen‑ sor has a fabulous LOD of 15 ppb at RT and exhibited a large response of nearly 72.5% to 15 ppb ozone. 

N‑type  WO3,  TiO2, and  Fe2O3 were also reported for FRT gas sensors, while other n‑type pristine MOS applied for FRT gas sensors are rarely reported. Ryu et al. [76] pre‑ pared porous  WO3‑δ films on PI substrate with granule spray process. The gas sensor exhibited high sensing properties with a great response of 18,500% to 10 ppm  NO2, response/ recovery time of 17/25 s and LOD of 1.88 ppm. Further‑ more, the sensor maintained high performance after 4,000 bending/relaxing cycles, showing excellent flexibility prop‑ erties.  TiO2 has also been reported to be used in the prepara‑ tion of TMA sensors. TMA is known to be released in dead fishes with a pungent and ammonia‑like odor. The detection of ppm‑levels TMA has been used to estimate the fresh‑ ness of fishes and seafood products. However, most of the reported MOS‑based TMA sensors work at high tempera‑ ture, which is seriously inconsistent with the actual applica‑ tion. Perillo et al. [109] reported a  TiO2 nanotube prepared by anodization method and then slid it onto the PI substrate to obtain a flexible sensor. The response of  TiO2 FRT sen‑ sor reached 150% to 400 ppm TMA with fast response time of 25 s and the detection limit was 40 ppm, meeting the actual application situation. Kim et al. [71] demonstrated a novel bio‑friendly renewable  NO2 sensor based on cellu‑ lose nanocrystals (CNC)/Fe2O3 composites, which exhibited 

1 3 

**206** Page 10 of 42 

Nano‑Micro Lett. (2022) 14:206 

whisker‑shaped morphology. The CNC/Fe2O3 sensor exhib‑ ited a tremendous response of nearly 1100% to 200 ppm  NO2 with fabulous reversibility, which can be contributed to the novel dispersive morphology. 

There are few p‑type pristine MOS that have been reported in FRT gas sensors due to their low gas response. Hübner et al. [161] demonstrated that the sensitivity of the n‑type MOS gas sensor is the square of a p‑type gas sensor with identical morphology, suggesting that it is a great challenge to design a pristine p‑type MOS gas sensor with tremen‑ dous sensing performance. Kuritka et al. [101] fabricated a fully inkjet‑printed CuO‑based humidity and ethanol sensor on PET substrate. The CuO nanoparticles were fabricated by microwave‑assisted solvothermal method and exhibited flowerlike morphology. The inkjet‑printed sensor showed excellent reversibility and a great response of nearly 90% to saturated vapors of ethanol at RT, which could be attributed to the high surface‑to‑volume ratio of flowerlike‑shape CuO nanoparticles. Sakthivel et al. [82] presented a FRT  NH3 gas sensor fabricated by screen printing CuO nanorectangles material on PET substrate. The CuO nanorectangles were fabricated by a surfactant‑free hydrothermal method with an average length and breadth of 950 and 450 nm, respectively. The RT sensor showed a meaningful response to 5 ppm of NH3 with response/recovery time of 90/120 s. In addition, the sensor exhibited tremendous stability over three months, performing its promising application prospects. As shown above, the solely reported CuO‑based p‑type pristine MOS‑ based FRT gas sensors did not perform great sensing proper‑ ties compared to the n‑type pristine MOS. 

In brief, various morphologies of pristine MOS have been synthesized and transferred to flexible substrates by diverse methods for FRT gas sensors. These sensors have been widely used for the detection of various gases, and some excellent sensing performance has been achieved. In particular, one‑dimensional (1D) nanostructure exhibit great potential to overcome high‑temperature operation and low response due to their ultra‑high surface‑to‑volume ratios and the large number of sites for adsorption of gas molecules, which is currently an effective strategy for achieving RT with pristine MOS. However, it should be noted that for most pristine MOS FRT gas sensors, their response at RT is much lower than that at higher operating temperatures, their response/recovery time are quite long, and sometimes these sensors cannot fully recover at RT after bending. To improve their sensing performance at 

RT, modification of pristine MOS materials is necessary, which will be discussed in the following chapters. 

### **4  Noble Metal Nanoparticles Modified MOS FRT Gas Sensors** 

Surface modification with noble metals refers to doping Pt, Pd, Au, Ag, and other noble metal nanoparticles on MOS to improve the surface activity and promote the catalytic decomposition of gas molecules, so as to make significant contributions to the better sensing performance [162–164]. Noble metal nanoparticles modification is considered to be a valuable strategy to improve the response and selectivity, reduce operating temperature and response/recovery time of the MOS gas sensors [165, 166]. 

##### **4.1  Mechanism of Noble Metal Modified MOS for Enhanced Gas Sensing Performance** 

Surface modification with noble metals can be carried out by chemical sensitization and electronic sensitization [167, 168]. Chemical sensitization increases the rate of chemical processes between target gas and chemisorbed oxygen through the catalytic action of noble metal nano‑ particles, which is conducive to the easier migration of electrons, and thus enhance the performance of sensors. In chemical sensitization, the noble metal promoter acti‑ vates the target gas by converting it into highly reactive molecules and accelerating it to spill over to the semicon‑ ductor surface, facilitating the catalytic oxidation [169], which is also referred to spill‑over effect. Chemical sen‑ sitized noble metals do not directly affect the resistance of semiconductors and its sensing mechanism is the same as in the absence of doping. Electronic sensitization is the exchange of electrons between noble metal and MOS surface that directly affects the resistance of MOS [168]. The electronic sensitized noble metal forms stable noble metal oxides in air and are reduced to metal in a reducing gas atmosphere [170, 171]. As the oxidation state of noble metal varies with ambient atmosphere, the state of the electrons on the MOS surface changes accordingly. When the noble metal is oxidized, an electron depletion layer is established on the MOS surface, which directly affects the resistance of the semiconductor. On the other hand, 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 11 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

as the noble metal oxide is reduced to metal, the elec‑ tronic interaction with the MOS is disrupted, resulting in a decrease in the depth of electron depletion layer. These electronic sensitized noble metal oxides act as receptors for the target gas with much stronger electronic affinity than the adsorbed oxygen, enhancing the performance of the gas sensor [167]. 

##### **4.2  FRT Gas Sensors Based on Noble Metal Nanoparticles Modified MOS** 

For many noble metal nanoparticles modified MOS flex‑ ible low‑temperature gas sensors, 1D vertically well‑ aligned ZnO nanorods are often used as the sensitive layer due to the great inherent characteristics of ZnO and the simple hydrothermal synthesis method, for instance, Pd–ZnO nanorods/PI/PET [93], Pd–Ga–ZnO nanorods/ PI [91] and Ag–ZnO nanorods/PI [99]. Chung et al. [93] presented a FRT  H2 sensor based on the Pd‑decorated ZnO nanorods. Figure 3a exhibited the ZnO nanorods remained vertically aligned after 1000 bending/relax‑ ing test, exhibiting fabulous mechanical flexibility. As shown in Fig. 3b, the Pd‑ZnO nanorods/PI/PET sensor showed a large response of 91.2% to 1000 ppm  H2 at RT and great robustness with no significant degradation after 10<sup>5</sup> bending cycles with a curvature angle of 90°. The modification of Pd nanoparticles not only enhances the sensor response, but also exhibits high selective absorp‑ tion of  H2. The authors attributed this enhancement to two‑factors. One is that  H2 molecules can be easily dis‑ sociated on the Pd surface:  H2 + Pd ↔  2PdHx. Second,  O2 in the ambient air can easily react with Pd nanoparticles and generate a weak‑bonded state of PdO: 2Pd +  O2 ↔ 2PdO, which also can be dissociated and produce  O2 eas‑ ily. Furthermore, the same group [91] developed a FRT sensor based on perpendicularly aligned ZnO nanorods with Pd and Ga modifications. The Pd‑3%Ga–ZnO nanorods/PI sensor showed excellent selective charac‑ teristics towards  H2, as given in Fig. 3c. Beyond that, this sensor also exhibited a large response of 91% to 1000 ppm  H2 at RT, which was improved six‑fold com‑ pared with the undoped Ga‑seed. More importantly, this sensor also performed excellent mechanical stability with no degradation after bending  10<sup>5</sup> cycles, which might be 

related to its good crystallinity. Furthermore, the same group [99] also reported Ag nanoparticles modified ZnO nanorods gas sensor and its optical image is shown in Fig. 3d. The sensor can be activated under visible‑light illumination: a large amount of photogenerated absorbed oxygen ions is generated owing to the coupling between Ag nanoparticles and ZnO nanorods, which results in an increase of surface charge density and an enhance‑ ment of sensing performance. This Ag–ZnO nanorods/ PI sensor exhibited a linear response to  C2H2 concentra‑ tions from 3 to 1000 ppm with the maximum response of 26.2 to 1000 ppm  C2H2 at 130 °C. However, the sen‑ sor characteristics degraded obviously after bending  10<sup>4</sup> cycles, which might be attributed to the fracture of the ZnO nanorods forest because of the excessive pressure. 

In addition, 1D nanostructures are often fabricated through the controllable electrospinning method. Featured with regu‑ lated porosity, high surface‑to‑volume ratio, and tunable pore size, the electrospun 1D nanomaterials exhibit fabulous RT gas sensing properties. Moreover, modified with the proper noble metal catalyst, the 1D nanostructured MOS gas sensors show better RT sensing performance. A novel n‑type wide‑ bandgap MOS sensing material,  SrGe4O9 has been reported for the detection of  NH3 at RT by Huang et al. [80]. Polycrys‑ talline  SrGe4O9 nanotubes were synthesized via a single‑noz‑ zle electrospinning process and Pt‑modified  SrGe4O9 nano‑ tubes were prepared by annealing the mixture of  SrGe4O9 and H2PtCl6 solution, as shown in Fig. 3e. The sensing materials were further assembled on a PET substrate to form a FRT sensor. The sensor exhibited a reliable detection of  NH3 within the concentration of 1–500 ppm, a response of 7.08 to 100 ppm  NH3 with fast response/recovery time of 17/16 s, excellent mechanical stability with a large bending angle of 150° and  10<sup>3</sup> cycles of bending/relaxing test. Pt nanoparticles modified  SrGe4O9 exhibited significantly enhanced response compared to the pristine  SrGe4O9. The authors attributed the enhanced gas sensing performance to electronic sensitiza‑ tion and chemical sensitization. In electronic sensitization, a Schottky barrier was formed between  SrGe4O9 and Pt, there‑ fore, the electrons transferred from  SrGe4O9 to Pt. In chemi‑ cal sensitization, dissociation and adsorption of  O2 molecules on the surface of  SrGe4O9 were catalytically activated by Pt nanoparticles. The modification of noble metal nanoparticles can also enhance the sensing properties of metal oxide‑based heterojunction. Rh‑doped 1D hollow  SnO2 nanotubes have also been reported for FRT  NH3 sensors by Liu et al. [172]. 

1 3 

**206** Page 12 of 42 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) (b) 1.50 (c) 100<br>Flat 10 4  times bending/relaxing H2 Undoped seed<br>10 2  times bending/relaxing 10 5   times bending/relaxing 1% Ga-doped seed<br>1.25 10 3  times bending/relaxing 10 6   times bending/relaxing 80 2% Ga-doped seed<br>1.00 1000ppm ppm800 ppm600 ppm400 ppm200 ppm100 60 3% Ga-doped seed4% Ga-doped seed<br>5% Ga-doped seed<br>0.75 40<br>0.50<br>20<br>CO<br>0.25 CO2 N2<br>0<br>100 nm 0.00 0 200 400 600 800 1000120014001600 −20 O2 NO2<br>Time (s)<br>Porous Porous<br>(d) (e)<br>Sr(NO3)2/ Sr(NO3)2/Ge(OEt)4/ SrGe4O9 Pt-SrGe4O9<br>Ge(OEt)4/PVP PVP nanofibers nanotubes nanotubes<br>solution<br>Electrode<br>PET<br>Add<br>Annealing H2PtCl6<br>Ag-ZnO NRs/PI Annealing<br>Collector<br>(f) (g) 6 Bend 30° NH3 Conc. 50 ppm<br>5 Initial 20.0k Initial Bend<br>4 16.0k<br>1. SnClElecrto2s/PVP nanofiberpining 2. Rh-doped SnOSinteirngi n ari 2 nanotube 3. PANI/Rh-doped SnO In-slu  polymerization 2 nanotube 32 12.0k8.0k4.0k<br>10 0.00 400 800Time (s)0 400 800<br>0 200 400 600 800 1000 1200140016001800<br>Time (s)<br>6 Initial Bent for 500 times Bent for 1000 times<br>4<br>2<br>Rh<br>0<br>0 400 800 0 400 800 0 400 800<br>Time (s)<br>Relative resistance (R/R)ga<br>Response, S(%) = ΔR/R×100%a<br>Resistance (Ω)<br>Response (R)/Rga<br>Response (R/R)ga<br><!-- End of picture text -->

**Fig. 3  a** Cross‑sectional view of the Pd‑ZnO nanorods/PI/PET sensor after 1000 times bending/relaxing test. **b** The response, reliability test of Pd‑ZnO nanorods/PI/PET sensor. Reproduced with permission from Ref. [93]. Copyright (2013) Elsevier. **c** The selectivity of Pd–Ga‑ZnO nanorods/PI sensor for various Ga‑assisted seed layers conditions at 1000 ppm  H2. Reproduced with permission from Ref. [91]. Copyright (2014) Elsevier. **d** The optical image of Ag‑ZnO nanorods/PI sensor. Reproduced with permission from Ref. [99]. Copyright (2018) Springer Nature. **e** Schematic illustration of the fabrication process of Pt‑SrGe4O9 nanotubes. Reproduced with permission from Ref. [80]. Copyright (2018) Springer Nature. **f** Schematic illustration of the fabrication process of PANI/Rh/SnO2. **g** Response of PANI/Rh/SnO2 sensors to 50 ppm NH3 at RT under bending test. Reproduced with permission from Ref. [172]. Copyright (2021) Elsevier 

As presented in Fig. 3f, they synthesized Rh‑doped  SnO2 hollow nanotubes by electrospinning and sintering. Subse‑ quently, the PANI coated Rh‑doped  SnO2 hollow nanotubes was prepared by in situ polymerization and drop‑coated on PET to form flexible sensors. Beyond that, Rh can be modi‑ fied into the  SnO2 lattice due to the similar ionic radii of  Rh<sup>3+</sup> and  Sn<sup>4+</sup> , which contributed to the enhanced noble metal sensitization. The Rh modification not only facilitates the adsorption of  NH3, but also promotes the decomposition of NH3 into highly reducing H and  NH2, which can result in a 

rapid thinning the depletion region of  SnO2, resulting in a fast response (113 s) and larger response values (13.6 to 100 ppm NH3). Moreover, as performed in Fig. 3g, the response of the sensor decreases only slightly at a bending angle of 30° and it is worth noting that the bending has no significant effect on the initial resistance of the sensor. Even after bending for 1,000 times, the sensor still possesses a reliable response, which means that the 1D nanostructure remain stable under bending situation. 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 13 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

In brief, modification with noble metals is also a superior scheme to enhance the response and selectivity due to the synergistic effect of chemical sensitization and electronic sensitization. Noble metal modification is generally effec‑ tive in creating more defects, increasing the number of active sites, providing more oxygen species, and reducing the activation energy of the reaction between the gas mol‑ ecules and adsorbed oxygens, thus accelerating the dynamic equilibrium between oxygen adsorption and desorption. Fur‑ thermore, some noble metals are specific for the detection of certain gases, which is beneficial for RT operation. For instance, Pd‑modified MOS sensors exhibit a particularly large response to  H2 due to the unique break‑junction effect, while Rh‑modified MOS sensors have a high response to NH3. Beyond that, the small size of noble metal nanoparti‑ cles does not affect the mechanical flexibility properties of the sensing material. All these features help to enhance the FRT gas sensing performance of MOS‑based gas sensors. 

### **5  Organic Polymers Modified MOS FRT Gas Sensors** 

Organic conducting polymers‑based gas sensors have attracted numerous interests due to their tunable electri‑ cal properties, simple fabrication, great stability, flexibil‑ ity, environmental stability and RT operation [173–175]. However, the relatively low conductivity and the poor selectivity restrict the application of pristine conducting polymer‑based sensors [174]. Therefore, coupling con‑ ducting polymers with other heterogeneous materials is a considerable strategy to enhance the sensing properties of the sensors [176–179]. Combing organic conducting polymers with MOS can complement the drawbacks of pristine MOS and organic conducting materials, especially the poor response and selectivity of pristine organic con‑ ducting polymers and the high operating temperature of MOS [180–182]. Organic conducting polymers including polyaniline (PANI), polypyrrole (PPy), polythiophene (PTh), poly (3,4‑ethylenedioxythiophene) (PEDOT) and polyacetylene (PA) have been widely used in fabricating high‑performance RT gas sensors [183]. However, only PANI is widely used for FRT gas sensors. PANI arrested the most interest because of its relatively high conductiv‑ ity, ease of fabrication, RT operation, low cost, environ‑ mental stability, and friendliness [176, 184, 185]. 

##### **5.1  Mechanism of PANI Modified MOS for Enhanced Gas Sensing Performance** 

The gas sensing mechanism of pristine PANI has been widely investigated. Among them, the most commonly accepted mechanism was based on the PANI protonation/ deprotonation process. In the doped emeraldine salt (ES) form, PANI is electrically conductive and, contrarily, in the dedoped emeraldine base (EB) form is insulating, where doping and dedoping can be carried out with acid or base, respectively [119]. The ability to switch between the con‑ ducting and insulating forms enables PANI responsive to acids/bases and reducing/oxidizing gases such as  NH3, tri‑ ethylamine (TEA),  H2,  NO2, and some VOCs. 

The formation of heterojunction between PANI and MOS plays a significant role in the enhancement of the sensing properties. When PANI contacts MOS, the difference in Fermi energy levels leads to carrier transfer, forming a het‑ erojunction and a narrow depletion region at their interface. When exposed to the target gas, PANI and the chemisorbed oxygen on the surface of MOS reacts rapidly, which modu‑ lates the width of the depletion region and rapidly affects the resistance of the sensing nanocomposites. 

For instance, Quan et al. [110] synthesized network structures of PANI/SnO2 through in situ chemical oxidation polymerization. The mechanism for the enhanced sensing performance of the PANI/SnO2 composite was proposed. When p‑type PANI is in contact with n‑type  SnO2, the elec‑ trons in  SnO2 and holes in PANI will diffuse in opposite directions owing to their difference in Fermi energy levels. A p‑n heterojunction and a narrow depletion region are formed at the interface of PANI and  SnO2, as presented in Fig. 4a. In this process, at their interface, a hole depletion region is formed on the surface of PANI, while an electron deple‑ tion layer is formed on the surface of  SnO2. When PANI/ SnO2 is exposed to the atmosphere of the target gas TEA, on the one hand, the protons in the  N<sup>+</sup> –H sites of PANI are drawn off and PANI is reduced from the conductive doped ES state to the insulating dedoped EB state, which leads to a decrease in the conductivity of the materials. On the other hand, the absorbed TEA molecules release electrons into the p‑n heterojunction, which decrease the hole concentration of PANI and the electron concentration of  SnO2, leading to a thickening of the hole depletion region and a thinning of the electron depletion region (Fig. 4a). Since the nanocomposite exhibits p‑type semiconductor behavior, the conductivity of 

1 3 

**206** Page 14 of 42 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) Eg=2.4 eVLUMO TEA Wp Wa Ev (b) HN Cl − NH + 2 ES form PANI y NHN 3 Cl − NH + 1- y n<br>HOMO EEgf=3.2 eV<br>Ev HN Cl − N H y N Cl N − 1- y n<br>p-PANI n-SnO2 NH4 + EB form PANI NH4 +<br>Wp-TEA Wa-TEA<br>TEA<br>Depletion layer<br>PANI-CeO2 Film CeO2 CeO2<br>Hole Dedoped PANI Depletion region of PANI PANI NH3 PANI<br>Doped PANI SnO2 Depletion region of SnO2 conductivity pathway conductivity pathway<br>(c) in-situ assembled on<br>hydrothermal dopped with Au polymerization PET substrate<br>InCl3·4H2O mesoporous Au-loaded mesoporous PAInxAy lfexible sensinglif m<br>critric acid urea In2O3 nanospheres In2O3 nanospheres<br>(d) 8070 6 PANIPAIn10A0.5 PAIn10PAIn20A1 PANI PAIn10 (e) 120 PET-PAni-CoFe3O4 (50%)-50 ppm RH: 40% )f( 98 NH3 Conc. 10 ppm<br>60 4 PAIn5A2 PAIn10A0.5 PAIn20A1 100 without bending 7 Initial<br>50 2 PAIn5A2 80 bending at 60° 6 Bending 100 times<br>4030 00 500 Time (s)1000 1500 2000 60 54 Bending 500 times<br>20 40 3<br>10 20 2<br>1<br>0 0<br>0 1000 2000 3000 4000 5000 0 200 400 600 00 200 400 600<br>Time (s) Time (s) Time (s)<br>5 ppm<br>500 ppb 1 ppm<br>100 ppm<br>80 ppm<br>50 ppm<br>20 ppm<br>500 ppb 1 ppm 5 ppm 10 ppm<br>/R)Response (Rag<br>)Response (R/Rga Response (R)/Rga Response (R/R)ga<br><!-- End of picture text -->

**Fig. 4** Schematic illustrations of the sensing mechanism of **a** PANI/SnO2 and **b** PANI‑CeO2 for enhanced gas sensing performance. Reproduced with permission from Refs. [83, 110], Copyright (2018) Elsevier (2017) Elsevier. **c** The process flow for preparation of Au‑In2O3@PANI sen‑ sors. **d** Transient response of the Au–In2O3@PANI sensors to 0.5–100 ppm  NH3 at RT. Reproduced with permission from Ref. [79]. Copyright (2018) Elsevier. **e** Response of PANI‑CoFe2O4 with a bending angle of 60° at 50 ppm of  NH3. Reproduced with permission from Ref. [84]. Cop‑ yright (2021) MPDI. **f** Response of PANI @ porous nanospheres  SnO2/Zn2SnO4 after 100 and 500 cycles of bending/relaxing test. Reproduced with permission from Ref. [186]. Copyright (2020) Elsevier 

the composite decreases rapidly and result in enhanced sens‑ ing properties. The mechanisms of PANI modified MOS for enhanced gas sensing performance are mostly similar, and are illustrated based on the chemical state transition of PANI and the effective electron transfer in the heterojunction. 

##### **5.2  FRT Gas Sensors Based on PANI Modified MOS** 

2D PANI nanosheets have been applied to construct the core–shell nanostructures of PANI and MOS nanocompos‑ ites, which can effectively enhance the sensing surface area and electrical conductivity of the bulk of sensing materials. Liu et al. [83] proposed a FRT trace‑level  NH3 sensor based on in situ self‑assembled PANI‑CeO2 nanomembranes on 

a PI substrate. The nanomembranes presented a core–shell nanostructure with a core of  CeO2 nanoparticles and a shell of PANI nanosheet. The author suggested that  CeO2 nano‑ particles can influence the alignment of PANI and change the morphology of PANI shell. What’s more, an appealing dis‑ covery was observed that the synergistic oxidation of  CeO2 and ammonium persulfate increases the protonation and oxidation of PANI, resulting in an enhanced =  NH<sup>+</sup> –ratio, which would offer additional adsorption sites. Beyond that, the sensor performed a splendid gas sensing performance with large sensitivity of 262.7% to 50 ppm  NH3, fabulous response‑concentration linearity, great selectivity, ultralow detectable concentration of 16 ppb, and theoretical LOD of 0.274 ppb. In addition, there was no obvious decrease in 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 15 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

response after 500 times bending, which might originate from the flexibility of polyaniline chains and the splendid adhesion and nano‑mechanical properties of PANI‑CeO2 nanomembranes. The authors ascribed the fabulous gas sensing performance to the synergetic benefits of the for‑ mation of p‑n heterojunctions and the enhanced protonation degree of PANI, as presented in Fig. 4b. 

PANI nanofibers [79, 81, 84, 87, 89, 110] and nanorods [85] usually have higher specific surface area and conductiv‑ ity than the granular PANI owing to their 1D nanostructure, which facilitates electronic interactions between sensing material and target gas, and endows high response and low detection limit to FRT sensors. Li et al. [87] reported nano‑ hybrids of PANI nanofibers and flowerlike  WO3 nanoparti‑ cles, which was synthesized by an in situ chemical oxidation polymerization method. PANI grew on the flowerlike  WO3 surface, forming a loose and porous nanostructure, which facilitates the adsorption and diffusion of  NH3 molecules and promotes the modulation of the interfacial depletion region. Therefore, the fabricated sensors exhibited a high response of approximately 20.1 to 100 ppm  NH3 at RT, which was 6 times larger than pristine PANI. What’s more, the sensor also showed rapid response/recovery time of 13/49 s, LOD of 500 ppb, fabulous moisture resistance, great selectivity, and excellent mechanical stability. The same group [79] presented a core–shell nanostructure with the core of Au‑ decorated  In2O3 nanospheres and the shell of PANI nanofib‑ ers, which was synthesized by a facile hydrothermal and in situ chemical oxidation polymerization method (Fig. 4c). The fabricated nanohybrids were subsequently loaded on PET substrates to form flexible sensors. The sensing perfor‑ mance of sensors based on pristine PANI,  In2O3@PANI, and Au–In2O3@PANI at RT were tested as presented in Fig. 4d. The Au–In2O3@PANI sensor showed a high response up to 46 to 100 ppm  NH3 at RT, which is 14 and 4 times larger than the pristine PANI sensor and  In2O3@PANI sensor, respectively. The fabulous sensing properties is contrib‑ uted to the chemical sensitized effect of Au, the p‑n het‑ erojunction formed at the interface of  In2O3 and PANI, and the improved protonation degree of PANI. Saleh et al. [84] presented a trace‑level  NH3 gas sensor composed of PANI nanofibers and  CoFe2O4 nanoparticles on PET substrates by in situ chemical oxidation polymerization. The n‑type CoFe2O4 nanoparticles were encapsulated in the p‑type PANI, forming a p‑n heterojunction at the PANI–CoFe2O4 interface. Therefore, the sensor exhibited great selectivity to 

NH3 and a significant response of 118.3% response towards 50 ppm for 24.3 s at RT. Notably, the sensor showed no response degradation while bending at 60° (Fig. 4e) and exhibited a trace‑level detection limit of 25 ppb. 

PANI with 1D morphology was also hybridized with Fe2O3 to acclimatize its structural properties, forming high‑performance FRT gas sensors [81, 85, 89]. Bandgar et al. [81] displayed a RT  NH3 sensor based on camphor sulfonic acid‑doped PANI/ _α_ –Fe2O3 on PET substrates by in situ chemical oxidation polymerization method. Camphor sulfonic acid acted as a surfactant, contributing to the dis‑ persion of _α_ –Fe2O3 into PANI nanofibers matrix and the generation of active sites. This flexible sensor showed an ultrahigh selectivity towards  NH3 compared to liquid petro‑ leum gas (LPG),  CH3OH,  NO2, and  C2H5OH. Zhu et al. [85] prepared a sea cucumber‑shaped PANI/Fe2O3 nanocom‑ posites by hydrothermal method, and assembled the nano‑ composites on PET substrates. The sea cucumber‑shaped PANI/Fe2O3 were assembled by PANI nanorods with small Fe2O3 nanoparticles attached. As the amount of precursor (FeCl3·6H2O) increases, the  Fe2O3 nanoparticles become larger and the PANI nanorods become thicker. With a proper amount of precursor, the nanocomposites can have a porous nanostructure and a large surface‑to‑volume ratio, providing more active sites for efficient adsorption of  NH3. Moreover, the sensor has great reproducibility, humidity resistance, and attain an excellent linear response to  NH3 concentrations from 0.5 to 100 ppm at RT. 

1D PANI nanofibers were also employed to modify het‑ erostructured composites to form ternary compounds. Liu et al. [186] achieved rapid and selective detection of  NH3 at RT by using in situ chemical oxidation polymerization method to assemble PANI@porous nanospheres  SnO2/ Zn2SnO4 nanocomposites on PET. The prepared sensor with the optimal PANI content exhibited a large response of 20.4 at RT, which is 2.6 times higher than that of the pristine PANI (7.8) and showed a detection limit as low as 500 ppb. However, the response decreased by 18.99% and 26.54% after 100 and 500 bending cycles, respectively, as shown in Fig. 4f. To find the explanation for the decrease in sensitiv‑ ity, the morphology of the flexible sensor after 500 times of bending was observed through SEM. It was found that the location of the crease bending in the center of the sensor was damaged, leading to partial detachment and extrusion deformation of the nanocomposite. While the other parts mostly preserved the primitive morphology, which makes it 

1 3 

**206** Page 16 of 42 

Nano‑Micro Lett. (2022) 14:206 

possible to achieve reliable sensing for  NH3 under bending conditions. 

When PANI is used as the main component and MOS is used as a modifier of the sensing materials, the materi‑ als behave p‑type characteristics acting like PANI. While constructing sensing materials with MOS as the main com‑ ponent and PANI as a modifier is also a possible strategy to fabricate high‑performance gas sensors so that the sensing materials exhibit the desired n‑type or p‑type properties act‑ ing like MOS. However, the implementation of this strat‑ egy needs to depend on 0D PANI nanoparticles. Bai et al. [111] reported a FRT TEA gas sensor by loading _α_ ‑MoO3 nanorods as a framework on a PET substrate and then cov‑ ering the framework with 0D PANI nanoparticles through in situ chemical oxidation polymerization. The formation of p‑n heterojunctions and the porous network morphology contribute significantly to the superior sensing performance. The sensor performed an excellent linear response to TEA at concentrations from 10 to 100 ppm at RT, and the LOD is theoretically calculated to be 0.55 ppm. What is worth notic‑ ing is that the negative influence of the relative humidity on the TEA sensors is negligible. The same group [86] also pre‑ sented a heterostructure of 0D PANI nanoparticles modified with  SnO2 nanofibers. The hybrid was further coated onto a PET substrate to develop a FRT  NH3 gas sensor. The sensor reached a large response of 29 to 100 ppm  NH3, which was 5 and 29 times larger than the pristine PANI or  SnO2 based sensor, respectively. 

Beyond that, PANI‑modified MOS sensors also gener‑ ally exhibit fabulous humidity resistance at RT. Some sensors even show increased response when the humidity increases, which is completely opposite to the conventional MOS‑based gas sensors. This is due to the  H2O molecules adsorbed on the surface of PANI acting as a proton source, which increases its doping level and the conductivity. Taking NH3 gas sensor, which is the main subject of this chapter, as an example, two reactions occur when exposed to  NH3: 



<!-- Start of picture text -->
NH3 + PANIH + ↔ 퐍퐇 + 4 + PANI (5)<br><!-- End of picture text -->



<!-- Start of picture text -->
NH3 + H2O ↔ 퐍퐇 + 4 + OH− (6)<br><!-- End of picture text -->

Primarily, the  NH3 molecules adsorbed on the surface of PANI take away protons from the ‑NH<sup>+</sup> ‑ of PANI to form NH<sup>4+</sup> , and PANI changes from ES form to EB form, lead‑ ing to an increase in the resistance of PANI. Furthermore, 

NH3 molecules dissolved in water generated  OH<sup>−</sup> , which promoted the deprotonation of PANI. Under high humidity environment, these two reactions both facilitated the reaction degree of  NH3 and enhanced the deprotonation of PANI, which contributed to the increased humidity resistance of the PANI‑based RT sensor. 

##### **5.3  FRT Gas Sensors Based on Other Organic Polymers Modified MOS** 

MOS nanoparticles have been incorporated in organic poly‑ mers to form flexible sensing materials in recent studies, which cannot only be used as the flexible substrate of gas sensors without constructing the extra substrate layer, but also can optimize the gas sensing performance. Mahmoud et al. [97] presented semi‑conductive organic chitosan mem‑ brane based flexible  H2S sensors. At first,  WO3 nanoparticles were mixed with glycerin ionic liquid (IL) to form solutions. Then the homogenous solutions were cast into the organic chitosan sensing membrane. The presence of chitosan and glycerol increases the content of H‑bonding, accelerating the electron accommodation and transfer. As a result, the fabricated gas sensors exhibited great sensing performance with fast response (13.6 s), a response of 2.75 to 200 ppm H2S, LOD of 15 ppm and excellent selectivity to  H2S (com‑ pared to  H2,  NO2 and  C2H2) at 40 °C. In addition, they also fabricated two other  H2S gas sensors based on other organic materials [95, 96]. The flexible semiconductive polymeric matrix membranes [95] were prepared by mixing carboxy‑ methyl cellulose (CMC) powders with 5% glycerin IL and 5 wt% CuO nanoparticles. The CMC/CuO/IL sensor showed a response of ~ 20% to 300 ppm  H2S at low temperatures with a detection limit of 15 ppm. Before that, they also prepared novel flexible membranes [96] by embedding  WO3 nano‑ particles in PVA and glycerin IL polymeric solutions. More importantly, the conductivity of the mentioned membrane can be controlled by adjusting the proportion of glycerol. The environmental‑friendly organic materials (chitosan, CMC, PVA) also provide a flexible matrix to accommodate IL and MOS nanoparticles. 

Hydrogel is a 3D network‑structured polymeric material formed by chemical or physical cross‑linking and swelling in abundant water [187, 188]. Recently, novel ion‑conduc‑ tive hydrogel gas sensors have been proposed as one of the most promising flexible wearable sensors due to the tunable 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 17 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

sensing properties, RT operation, excellent stretchability, transparency, biocompatibility, and facile synthesis pro‑ cess [189–191]. Wu et al. [192] synthesized  SnO2‑modified reduced graphene oxide hydrogels  (SnO2/RGOH) with a 3D porous structure by simple hydrothermal process, and used a liquid crystal polymer as a flexible substrate to form flex‑ ible  NO2 sensors with excellent mechanical bending toler‑ ance. Compared with pristine RGOH, both sensitivity and LOD of  SnO2/RGOH hydrogel were improved by one order of magnitude when operating at RT. The enhanced sensing performance of the hydrogel originated from the formation of p‑n heterojunction at the interface of RGOH and  SnO2, which facilitated the charge transfer. In addition, the large number of pores formed on 3D  SnO2/RGOH hydrogel not only prompt the charge transfer through the charge hopping process, but also accelerate the gas diffusion through the pore filling effect. Besides, numerous oxygenated groups such as carboxyl and hydroxyl groups, which interact with NO2 molecules through hydrogen bonding, enhancing the adsorption capacity of  NO2. It is worth noting that large mechanical deformations do not degrade the gas‑sensitive performance of the 3D hydrogels due to the superior stretch‑ ability and self‑healing properties, especially meet the need of flexible sensors. Technologies such as hybridization of various materials and 3D structure design will facilitate the development and practical application of MOS‑based hydro‑ gel gas sensors. 

In brief, in this chapter, we introduced the sensing mech‑ anism of PANI modified MOS for enhanced gas sensing performance, which is based on the protonation/deproto‑ nation process of PANI and the enhanced sensitization of the heterojunction formed at their interface. Currently, 0D nanoparticles, 1D nanofibers, and 2D nanosheets of PANI have been employed to prepare high‑performance FRT gas sensors of  NH3 and TEA. Among them, 0D PANI nanopar‑ ticles attached on MOS exhibit excellent catalytic modifica‑ tion. 1D PANI nanofibers usually possess better RT sensing performance due to better electrical conductivity and higher surface‑to‑volume ratio. 2D PANI nanosheets performed excellent mechanical stability with no degradation under bending condition. In addition, PANI modified MOS sens‑ ing materials exhibited fabulous humidity resistance because the ES to EB transition process of PANI is accelerated in high humidity environment, expanding its application scope. Besides, we discussed flexible bulk materials with superior gas‑sensitive properties based on other flexible organic 

polymers blended with IL and MOS. The promising MOS‑ based hydrogel FRT gas sensor was also briefly presented. 

### **6  Carbon‑Based Materials Modified MOS FRT Gas Sensors** 

1D carbon nanotubes (CNTs) and 2D graphene deriva‑ tives are emerging materials for gas sensing owing to their high sensitivity, large surface‑to‑volume ratio, and abun‑ dant adsorption sites [120, 193, 194]. Nevertheless, target gas molecules are adsorbed on the carbon‑based materi‑ als mainly depend on weak van der Waals forces, which restrict the high sensing performance of sensors [149]. To overcome the shortcomings, hybridization of carbon‑based materials with MOS has been introduced, and this com‑ plementary hybridization not only complements the draw‑ backs of single components, but also introduces promis‑ ing advantages [195, 196]. Recently, several reviews have reported carbon‑based materials modified MOS gas sen‑ sors with enhanced sensing performance [197–199]. The results suggest that the carbon‑based material/MOS het‑ erostructure and the unique morphology of the composites contribute to the enhancement of the high‑performance gas sensors [200–202]. 

##### **6.1  Mechanism of Carbon‑Based Materials Modified MOS for Enhanced Gas Sensing Performance** 

In carbon‑based materials modified MOS, the main role of MOS is to detect the target gas molecules, while carbon‑ based materials can serve as great acceptors for injected electrons owing to their high electrical conductivity, large surface area and abundant adsorption sites. Although lit‑ tle is known about the gas sensing mechanism of these hybrids, the data reported so far suggest that their response mechanism is based on the modulation of the heterojunc‑ tion between the MOS and the carbon‑based material. 

In general, both CNTs and graphene derivatives exhibit p‑type properties. When a carbon‑based material is in contact with MOS, a p–n junction or a p–p junction is formed at the interface, depending on whether the MOS material is n‑type or p‑type. When exposed to an oxidizing gas atmosphere, the oxidizing gas extracts electrons from 

1 3 

**206** Page 18 of 42 

Nano‑Micro Lett. (2022) 14:206 

the heterojunction, the interfacial potential barrier and the thickness of the depletion region increases, which ampli‑ fies the increase in resistance. However, when exposed to a reducing gas atmosphere, the reducing gas releases electrons to the heterojunction, the interfacial potential barrier and the thickness of the depletion region decreases, leads to the sharp decrease of resistance. Beyond that, the heterojunctions can also enhance oxygen adsorption, thus forming a large number of oxygen vacancies on the surface of nanocomposites, providing extra active sites for sensing reactions. 

Furthermore, during the synthesis process, the carbon‑ based material can modulate the size and morphology of the metal oxide. Besides, the carbon‑based materials increase the electrical conductivity of the composites, which can transfer the electrons of sensing reactions to the metal electrodes rapidly. What’s more, carbon‑based materials contains a large number of mesopores, which facilitate the adsorption and desorption of gas molecules. These will improve the sensitivity and response speed of carbon‑based materials modified MOS gas sensors. 

##### **6.2  FRT Gas Sensors Based on CNTs Modified MOS** 

CNTs is a widely used carbon‑based material for gas sens‑ ing owing to its high specific surface area, fabulous electri‑ cal conductivity, and great flexibility characteristics [203]. In addition, CNTs provide an effective conductive path‑ way for electron transport, further improving the response value and response rate of the CNTs/MOS sensors [204]. Single‑walled carbon nanotubes (SWCNTs) are cylindrical nanotubes rolled up by honeycomb lattice carbon sheets. The hybrid of SWCNTs and MOS exhibits great sensing performance, especially low detection limits. Asad et al. [112] fabricated flower‑shaped CuO‑SWCNTs through a hydrothermal method and then the obtained materials were drop‑casted on the RFID. As shown in Fig. 5a, the obtained wireless RFID sensors can be perfectly attached to the skin, revealing their applications for healthcare and environmental monitoring. Beyond that, the fabricated sen‑ sor not only selectively detected  H2S with an ultralow LOD of 100 ppb at RT, but also showed a response of 35% to 1 ppm  H2S with 7 s response time. Hua et al. [68] prepared SWCNT films by floating catalytic chemical vapor deposi‑ tion with ferrocene as the catalyst, and then twig‑like  Fe2O3 

nanoparticles were obtained by a simple annealing process, which are attached on the surface of SWCNT bundles. The as‑grown  Fe2O3‑SWCNTs were then transferred onto PP plastic substrates to form flexible gas sensors, and showed great mechanical robustness after large‑degree deformation, as shown in Fig. 5b. The fabricated  Fe2O3–SWCNTs sensors obtained an enhanced response towards  NO2, as shown in Fig. 5c, and exhibited a significant response towards  H2S, while the pure SWCNTs sensor failed to detect  H2S. The improved sensing performance is ascribed to the presence of  Fe2O3 nanoparticles, which accelerates electron trans‑ port and promotes the electron–hole recombination. Gao et al. [100] prepared flexible nylon fiber gas sensors with SWCNTs, multi‑walled carbon nanotubes (MWCNTs) and ZnO quantum dot modified SWCNTs as sensing materials. Remarkably, as shown in Fig. 5d, SWCNTs@ZnO exhib‑ ited a significant response to ethanol while the SWCNTs and MWCNTs did not, which is contributed to the effect of ZnO quantum dots. The presence of ZnO quantum dots reduces the defects of SWCNTs and decreases the charge density, creating a high conductive state serves as a reduc‑ tion of the gating effect at the hybrid interface. In addition, the flexible gas sensor exhibited good mechanical bending ability and robustness, as shown in Fig. 5e. Robustness test towards washing treatment was also conducted by wash‑ ing the nylon sensors for different times and the sensors showed no significant degradation. More importantly, the fabricated flexible sensors were further integrated into face masks, selectively detected  NH3, HCHO and  C2H5OH by distinguishing whether the corresponding LEDs are lighted or not, as shown in Fig. 5f. 

SWCNTs can also be easily blended with other sensing materials to synthesize multivariate composites. Further‑ more, noble metal nanoparticles can be easily incorporated into various sensing materials by simple synthesized meth‑ ods such as hydrothermal, wet impregnation, and physical sputtering methods. Therefore, noble metal nanoparticles are often used to fabricate ternary or even multivariate composites to enhance the performance of sensors [74, 79, 205–207]. Kim et al. [74] fabricated SWCNTs decorated PdO/Co3O4 hollow nanocubes for  NO2 sensors. PdO–Co3O4 hollow nanocubes were synthesized by calcining of Pd‑infil‑ trated Co‑based ZIF‑67. Subsequently, SWCNTs were mixed with PdO‑Co3O4 hollow nanocubes dispersed in ethanol to help electrically bridging multiple PdO/Co3O4, which can increase the baseline electrical conductivity. With the Pd 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 19 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) (b) 30 0° 90° 180° 0° (c) −30 as-grown film NO2<br>SWNT-Fe2O3 film<br>20 −20<br>Fabricated<br>wireless 10 −10<br>Skin of sensor<br>hand<br>0 0<br>0 2 4 6 8 10 12 14 16 0 20 40 60 80 100<br>Cycle number Gas concentration (ppm)<br>(d) 1.4 (e) 1.3 )f(<br>1.3<br>1.2<br>1.2<br>1.1 1.1<br>1.0<br>1.0<br>0 1000 2000 3000 4000 5000<br>Time (s)<br>Co3O4 HNCs<br>(g) Δ R<br>SWCNTs-PdO-Co3O4 HNCs NO2<br>(top)<br>cPI<br>(middle)<br>PdO<br>Ni/Au core-shell mesh (bottom) SWCNTs<br>CH<br>Side view Cross secitona lview Magnified view( sensingl aye)r<br>SWCNT@ZnO<br>SWCNT<br>Ammonia MWCNT<br>Ethanol<br>Formaldehyde<br>Response (%) Response (%)<br>/ R 0g<br>R / R 0g<br><!-- End of picture text -->

**Fig. 5  a** The optical image of manufactured wireless RFID sensor. Reproduced with permission from Ref. [112]. Copyright (2016) Elsevier. **b** Response of  Fe2O3‑SWCNTs sensor under large‑degree deformation. **c** Response of SWCNTs and  Fe2O3‑SWCNTs sensor towards  NO2 (1, 10, 20, 50, and 100 ppm). Reproduced with permission from Ref. [68]. Copyright **(** 2017 **)** Elsevier. **d** Response of the SWCNT, MWCNT and SWC‑ NTs@ZnO nylon sensors to 500 ppm  NH3, HCHO and  C2H5OH at RT. **e** Response of the nylon‑based sensor under large‑degree deformation. **f** The optical image of a multifunctional mask with integrated  NH3, HCHO and  C2H5OH sensors. Reproduced with permission from Ref. [100]. Copyright **(** 2018 **)** Springer Nature. **g** Schematic illustrations of SWCNT/PdO/Co3O4 on flexible Ni/Au‑PI film. Reproduced with permission from Ref. [74]. Copyright **(** 2017 **)** American Chemical Society 

nanoparticles modification, the hole accumulation layer on the  Co3O4 nanocubes gets thicker and accelerates the redox reaction with  NO2 through the electronic sensitization. As shown in Fig. 5g, the SWCNTs/PdO/Co3O4 composite was further integrated on the Ni/Au‑PI film to construct FRT gas sensors. Moreover, the sensor exhibited reliable detection of NO2 at RT with a high response of 27.33% at 20 ppm and a LOD of 1 ppm. 

MWCNTs are concentric graphene rolled up with diam‑ eters on the order of hundreds of nanometers. Unlike the disordered arrangement of SWCNTs, MWCNTs are ordered and exhibit good electrical properties with enhanced charge migration in the direction of the arrangement. The reported FRT sensors based on the hybrid of MWCNTs and MOS exhibit ultralow detection limits. Rui et al. [64] used MOFs as precursors for MOS and aligned MWCNT nanofibers 

1 3 

**206** Page 20 of 42 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) (b)<br>0.00<br>2<br>0.1 5<br>−0.01 0.2 10<br>20<br>0.4<br>Depositing MOFs Twisting Annealing −0.02 0.6 0.8<br>1 ppm<br>MWCNT sheet −0.03 AC90<br>AC60<br>ZIF-67-Co<br>AC30<br>−0.04<br>0 20 40 60 80 100 120<br>MIL-88-Fe MOFs/MWCNT sheet MOFs/MWCNT fiber MOs/MWCNT fiber<br>Time (min)<br>(c) (d) (e)<br>0.0 0.00 2<br>−0.1 −0.01 0.1 5 10 20 MWCNTs<br>0.2<br>20 50<br>0.5<br>−0.2 50 −0.02 1 ppm<br>−0.3 100 −0.03<br>200<br>−0.4 −0.04<br>500<br>AC90 BC90-120°<br>−0.5 AC60 −0.05 BC90-60°<br>AC30 1000 ppm BC90-0°<br>−0.6 −0.06<br>120 130 140 150 160 170 180 0 20 40 60 80 100<br>Electrode<br>Time (min) Time (min)<br>)f( 14 1:1 MWCNTs-WO3NPs(S1) (g) 24 10 ppm WO3-MWCNTs-RGO (h) 35 10Unbend 3  bending/relaxing<br>12 1:3 MWCNTs-WO1:5 MWCNTs-WO33NPs(S2)NPs(S3) 20 WOPure MWCNTs3-MWCNTs 30 1010 46  bending/relaxing bending/relaxing<br>5 ppm<br>10 16 25 10 7  bending/relaxing<br>8 12 20<br>6 1 ppm<br>8 15<br>4<br>4 10<br>2<br>0 0 5<br>20 40 60 80 100 120 140 0 20 40 60 80 100 120 0 5 10 15 20 25<br>Temperature (°C) Time (min) NO2 concentration (ppm)<br>3 cm<br>0.7 cm<br>WO3 NPs<br>0.1 mm<br>PET substrate<br>1.5 cm<br>0.5 cm<br>ΔR/R<br>ΔR/R ΔR/R<br>Response, S(%) = (R)/R×100−Raag Response, S(%) = (R)/R×100−Raga )/RResponse, S(%) = (R×100−Rgaa<br><!-- End of picture text -->

**Fig. 6  a** The process flow for preparation of MOFs modified MWCNT fibers. Transient response of  Co3O4/MWCNT hybrid fibers to **b** 0.1– 20 ppm **c** 20–1000 ppm  NO2 at RT. **d** Transient response of the  Co3O4/MWCNT hybrid fibers to 0.1–50 ppm  NO2 at 0°, 60°, and 120°. Repro‑ duced with permission from Ref. [64]. Copyright (2018) American Chemical Society. **e** Schematic diagram of  WO3/MWCNT‑based sensor. **f** Response of  WO3/MWCNT‑based sensor as a function of operating temperature. Reproduced with permission from Ref. [73]. Copyright (2015) Elsevier. **g** Transient response of pure MWCNTs,  WO3/MWCNTs and  WO3/MWCNT/RGO. **h** Response of  WO3/MWCNT‑based sensor after different cycles of bending/relaxing tests. Reproduced with permission from Ref. [72]. Copyright (2016) Elsevier 

as the conductivity path for  NO2 sensing. First, they intro‑ duced ZIF–67–Co into the stacked MWCNT nanosheets by drop‑casting method. Then, the MOFs modified MWCNT nanosheets were twisted and annealed in air to form  Co3O4/ MWCNT hybrid fibers, as shown in Fig. 6a. The hybrid fiber was further sewn into commercially textile fabrics without damage. The manufactured textile fabrics  NO2 sensor per‑ formed a broad detection range from 0.1 to 1000 ppm at RT, as given in Fig. 6b, c. The porous MWCNT fibers help facilitating electron interactions and promoting electron 

transfer reactions. As depicted in Fig. 6d, the hybrid fiber sensor performed even better response when bent into dif‑ ferent angles, which might be ascribed to the promotion of electron transfer along the straightened MWCNT fiber under tension. The fabricated smart textiles are also equipped with energy storage functions, demonstrating potential applica‑ tions for integrated wearable devices. Yaqoob et al. [73] mixed the prepared  WO3 nanoparticles and MWCNTs with the assistance of α‑terpineol, and then fabricated flexible sensors through gel casting on PET substrates, as shown 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 21 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

in Fig. 6e. The sensor displays an interesting phenomenon that the response decreases as the operating temperature increases (Fig. 6f), which can be ascribed to the elimination or decline of the nano‑Schottky barrier or p‑n heterojunction between  WO3 and MWCNTs at higher temperature. This interesting phenomenon is contrary to the properties of MOS and informative to reduce the working temperature of MOS‑ based sensors. Furthermore, they mixed reduced graphene oxide (RGO) powders into the mixture and formed a  WO3/ MWCNT/RGO‑based sensor on a PI/PET substrate [72]. The Brunauer, Emmett and Teller analysis [208] illustrated that the specific surface area of  WO3/MWCNT/RGO was larger than  WO3/MWCNT. In addition, as shown in Fig. 6g, both WO3/MWCNT/RGO‑based and  WO3/MWCNT‑based sen‑ sors exhibit a large response to  NO2. The presence of  WO3 nanoparticles not only forms a p‑n heterojunction, but also provides an efficient electron transfer pathway. As for the modification of RGO, it can effectively increase the specific surface area and facilitate the adsorption–desorption kinetics to achieve better gas sensing properties. What’s more, the WO3/MWCNT/RGO‑based and  WO3/MWCNT‑based sen‑ sors showed low detection limit of 1 and 0.1 ppm, respec‑ tively. However, they both suffered from the long response times compared with other types of MOS‑based sensors. Figure 6h represents the response of  WO3/MWCNT/RGO‑ based sensor under different bending‑relaxing cycles. No remarkable degradation after  10<sup>6</sup> repeated cycles, which can be explained by the fabulous flexible properties of MWCNTs and RGO. 

##### **6.3  FRT Gas Sensors Based on Graphene Derivatives Modified MOS** 

Being one of the brightest promising materials, graphene attracted the extensive enthusiasm of researchers in the field of gas sensing owing to its outstanding overall characteris‑ tics, such as single atom thickness, 2D layered nanostruc‑ tures, high Young’s modulus of elasticity, room‑temperature stability, large surface‑to‑volume ratio, and excellent ther‑ mal and electrical conductivity [209–211]. The synergetic effect between MOS and graphene for the enhanced selec‑ tivity and sensitivity of gas sensors have been well demon‑ strated [118, 212]. Goutham et al. [213] fabricated a FRT transparent LPG sensor based on CdO/graphene hybrid. The presence of graphene reduces the aggregation of CdO 

nanoparticles, increases the surface‑to‑volume ratio and accelerates electron transfer by providing more conducting channels. Graphene derivatives are also promising candi‑ dates for the exploration of high‑performance carbon‑based gas sensors. Compared to pristine graphene and other gra‑ phene derivatives, RGO is prevailing owing to its fabulous characteristics such as large specific surface‑to‑volume ratio, great sensitivity, chemical and mechanical stability, and high carrier mobility. In addition to the synergetic benefits of MOS and RGO, the synthesis method of RGO is one of the most significant aspects affecting the properties of the RGO/MOS‑based sensor. You et al. [65] assembled a In2O3@RGO‑based 2 × 4  NO2 flexible sensor array by direct laser writing (DLW) process. The schematic diagram of the manufacture of the  In2O3@RGO FRT sensors and the optical photograph of the sensor array is shown in Fig. 7a, b. Confo‑ cal laser scanning was conducted on the border of GO and RGO, and the microscopy pictures is presented in Fig. 7c, exhibiting sharped edges that reveal the high accuracy of DLW treatment. What’s more, the surface and edges of GO sheets contain numerous oxygen containing groups (OCGs), which makes GO insulating. After DLW treatment, the resistance of  In2O3@GO decreased from ∼ 7.6 ×  10<sup>8</sup> to ~ 230 Ω due to the removal of OCGs. More importantly, DLW can also effectively promote the photoreduction of GO, allow‑ ing  In2O3@RGO to be patterned on flexible substrates. The sensor exhibits a linear response to trace‑level  NO2 over the concentration of 50–1000 ppb at RT with large response (31.6% to 1 ppm  NO2) and excellent selectivity. However, the sensor performed poorly regards to response/recovery time (4.2/13.3 min). The great sensing performance could be contributed to the recovery conductivity of GO, the p‑n het‑ erojunctions at the  In2O3/RGO interface, and the formation of nanopores on GO sheets during DLW treatment owing to the escape of the OCGs through  CO2,  H2O, CO, etc. 

It is known that  WO3 has several crystalline hydrates such as  WO3·2H2O,  WO3·H2O and  WO3·0.33H2O. Among them, WO3·0.33H2O exhibits the best sensing performance at RT [214]. Perfecto et al. [108] fabricated a FRT isopropanol sensor based on the composite of RGO and  WO3·0.33H2O nanoneedles. The RGO/WO3·0.33H2O composite was obtained by ultrasonic spray nozzle (USN) and microwave‑ assisted hydrothermal (MAH), as shown in Fig. 7d. The agglomerates containing  H2WO4 with GO sheets can be converted to GO‑H2WO4 clusters in a high nucleation rate by USN method, and the MAH method helps to facilitate 

1 3 

**206** Page 22 of 42 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) (d) Na2WO4 + GO<br>coating In2O3@GO laser treatment 130 W WO42− GO sheets<br>40 Hz USN<br>~35 µm Breaking of GO-H2WO4<br>droplet micro-droplet clusters<br>a)<br>(b) (c) HCl<br>HCl )I( )II( )III(<br>High nucleation<br>rate<br>In2O3@GO In2O3@RGO<br>b) )I( )II(<br>MAH<br>160 °C, 1 h<br>RGO-WO3·0.33H2O<br>(e) 60 8 (f)<br>10 ppm<br>50 7 Si NH2<br>6 1 ppm (i) APTES coating (ii) GO coating O O O Si NH2<br>40 OOO<br>5<br>30 0 100 200 300 400 500 Cotton/elastic threads APTES-fibers GO-fibers APTES-GO<br>20<br>(iii) Chemical<br>reduction (iv) APTES-ZnO coating O<br>10 O Si NH2<br>O<br>0 250 500 750 1000 1250 1500 APTES-ZnO<br>Time (s) RGOif-bers RGO/ZnO hybirdif bers<br>(g) 50 RGO (h) 10.0 )i( 40 Washing 0<br>RGO/ZnO-1 7.5 Washing 1<br>40 RGO/ZnO-2 30 Washing 3<br>RGO/ZnO-3 5.0 Washing 5<br>30 Twisted State Washing 8<br>2.5 20<br>20 Fixed End<br>0.0<br>10<br>10 −2.5 Free End<br>NO2 Dry air<br>0<br>0 −5.0<br>0 2 4 6 8 10 12 14 16 0 800 1600 2400 3200 4000 0 100 200 300 400 500 600 700<br>NO2 concentration (ppm) Twist angle (degree) Time (s)<br>In2O3@GO In2O3@RGO<br>Pl substrate 80 µm<br>100 µm<br>Au electrode<br>1 cm 1 cm<br>200 ppm<br>100 ppm<br>Resistance (MΩ) 50 ppm<br>1 ppm 10 ppm<br>Response (%) Response (%) Response (%)<br><!-- End of picture text -->

**Fig. 7  a** Schematic illustration of the fabrication process for  In2O3@RGO sensors. **b** The optical image of the 2 × 4  In2O3@RGO sensor array. **c** The confocal laser scanning microscopy images of the border of GO and RGO. Reproduced with permission from Ref. [65]. Copyright (2018) Elsevier. **d** Schematic illustration of the fabrication process for RGO/WO3·0.33H2O hybrids. **e** Transient resistance of the RGO/WO3·0.33H2O hybrids. Reproduced with permission from Ref. [108]. Copyright (2018) The Royal Society of Chemistry. **f** The process flow for preparation of RGO/ZnO hybrid threads. **g** Transient response of RGO and RGO/ZnO to different  NO2 concentration. **h** Response of RGO/ZnO sensors under different twist angles in 2 ppm  NO2 (0°, 360°, 720°, 1440°, 2160°, and 3,600°). **i** Response versus time plot of the RGO/ZnO sensors under dif‑ ferent washing times. Reproduced with permission from Ref. [54]. Copyright (2019) American Chemical Society 

the reduction of GO and form  WO3 nanoneedles on RGO sheets. As illustrated in Fig. 7e, the sensor exhibited a large and linear response to isopropanol at concentrations of 10–100 ppm. In addition, the response time for different isopropanol concentrations is relatively short, ranging from 

60 to 90 s. Li et al. [54] prepared a FRT  NO2 gas sensor with commercial flexible cotton/elastic threads substrates and RGO/ZnO nanosheets as a sensing material to fabricate con‑ ductive threads. Figure 7f demonstrated the manufacturing flow for RGO/ZnO composite threads. The introduction of 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 23 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) 70 PVDF (b) rGO SO2 + H2O<br>rGO/PVDF H2S<br>60 SnO2/PVDF<br>rGO/SnO2/PVDF<br>50<br>40<br>30<br>20<br>10 SnO2<br>0<br>10 ppm 50 ppm 100 ppm 200 ppm 500 ppm 1000 ppm PANI<br>(c) 100 10 ppm (d) 4.0 (e) 40<br>80 SnOSnO22/PANI 5 ppm 3.5 SnO2 SnO2/PANI SnO2/rGO SnOPANI2/rGO/<br>SnO2/rGO 3.0 30<br>SnO2/rGO/PANI 2 ppm<br>60 2.5 gas<br>1 ppm 2.0 air gas air 20<br>40 500 ppb 1.5 gas air<br>200 ppb 1.0 gas air 10<br>20<br>100 ppb<br>50 ppb 0.5<br>0 0.0 0<br>0 500 1000 1500 2000 2500 0 200 0 200 0 200 0 200 0 10 20 30 40 50 60<br>iTme( s) iTme( s) Bending Cycles<br>Response (%)<br>Response (%) Response (%)<br>Resistance (MΩ)<br><!-- End of picture text -->

**Fig. 8  a** Response comparison among the pristine PVDF, RGO/PVDF,  SnO2/PVDF, and RGO/SnO2/PVDF composites. Reproduced with per‑ mission from Ref. [94]. Copyright (2020) Springer Nature. **b** The sensing mechanism diagram of  SnO2/RGO/PANI nanocomposites towards H2S. **c** Response comparison among  SnO2,  SnO2/PANI,  SnO2/rGO and  SnO2/rGO/PANI. **d** Transient resistance of  SnO2,  SnO2/PANI,  SnO2/ RGO and  SnO2/RGO/PANI towards 2 ppm  H2S. **e** The response of  SnO2/RGO/PANI hybrid to 500 ppb  H2S after bending test. Reproduced with permission from Ref. [98]. Copyright (2019) Elsevier 

APTES coating helps to strengthen the adhesion of GO coat‑ ing on threads. After coating the GO film, a further chemical reduction reaction was performed to form RGO‑threads. The RGO‑threads were further immersed in an aqueous APTES‑ ZnO solution and subsequently annealed to form RGO/ZnO hybrid threads. Figure 7g exhibits the response of RGO/ZnO hybrid threads to  NO2, which was significantly enhanced over pristine RGO sensor. Furthermore, the sensor exhib‑ ited great long‑term stability (84 days) and low detection limit (200 ppb). Beyond that, the fabricated sensing threads exhibited superior mechanical and washing durability, as shown in Fig. 7h, i. With cotton/elastic threads as the flex‑ ible substrate, the sensor can even be stretched, twisted, and washed, providing a new perspective on wearable E‑textiles for practical multifunctional applications. 

RGO sheets are also excellent matrices for construct‑ ing multivariate composites. The synergistic effect of RGO and other multiple nanomaterials provides unprec‑ edented possibilities for innovative nanostructures and high performance of gas sensors. Punetha et al. [94] prepared 

optimized ternary nanocomposites based on RGO,  SnO2, and polyvinylidene fluoride (PVDF) by a simple hot press method. The proposed ternary nanocomposite‑based flex‑ ible sensor showed great response of 49.2% to 100 ppm H2 at RT, which is 2 and 3.5 times larger than  SnO2/PVDF and RGO/PVDF sensors, respectively, as shown in Fig. 8a. In addition, the RGO/SnO2/PVDF nanocomposite showed excellent stability with almost no response degradation after being tested for a month and presented a detection limit up to 500 ppb. Zhang et al. [98] synthesized sub‑ ppb level FRT  H2S sensors based on  SnO2/RGO/PANI nanocomposites. The ternary composite is closely packed together in the form of a porous network structure, which helps accelerating the absorption and desorption of  H2S, as shown in Fig. 8b. The fabricated sensor showed fabulous sensing properties with high sensitivity (60.11% to 2 ppm H2S), response/recovery time (82/78 s), stable repeatabil‑ ity, and long‑term stability. Figure 8c illustrates that the SnO2/RGO/PANI hybrid exhibited significantly improved response compared to pristine  SnO2 as well as the hybrid of 

1 3 

**206** Page 24 of 42 

Nano‑Micro Lett. (2022) 14:206 

SnO2/RGO and  SnO2/PANI, demonstrating the superiority of the ternary compound. The dynamic resistance transition of the sensors towards 2 ppm  H2S also indicated the effec‑ tive modulation of the baseline resistance by  SnO2/RGO/ PANI composite (Fig. 8d), which contributes to the expan‑ sion of the electronic pathway. Beyond that, the response of  SnO2/RGO/PANI hybrid showed no degradation after bending test (Fig. 8e). The reported ternary composite‑ based gas sensors reveal that ternary composite might help exploring a new route to develop novel FRT sensors with high performance, but the mechanical properties still need to be further studied to prevent the generation of fractures. 

In brief, this chapter presented the sensing mechanism of carbon‑based material modified MOS sensors. Carbon‑based materials are beneficial to promote electron transfer and oxy‑ gen adsorption/desorption due to their high conductivity, large surface area, and abundant adsorption sites. In addi‑ tion, the heterojunction formed between the carbon‑based material and MOS facilitates the rapid modulation of resist‑ ance and lower operating temperature. Moreover, both 1D CNTs and 2D graphene derivatives consist of a honeycomb‑ like lattice network of carbon atoms that remain resistant to fracture under bending. Besides, the carbon‑based materials provide more conductive channels that allow carbon‑based material modified MOS sensors to remain responsive after bending test. The potential of RGO nanosheets to construct excellent matrices of multivariate composites is also pre‑ sented. The synergistic effect of RGO, MOS, and tertiary materials such as noble metals and PANI, endows to achieve incredible gas sensing performance. To sum up, the nano‑ composites of MOS with carbon nanomaterials have much shorter response/recovery times, lower operating tempera‑ ture, better mechanical flexibility, and lower detection lim‑ its than pristine MOS, although the increase in response values obtained with these nanocomposites might be less pronounced. 

### **7  TMDCs Materials Modified MOS FRT Gas Sensors** 

Recently, gas sensing semiconducting 2D TMDCs have aroused growing interest owing to their attractive proper‑ ties that stem from their narrow band gap, large surface area provided by the sheet‑like nanostructure, and unique surface and quantum effects [215–217]. In addition, TMDCs has a 

lamellar structure with weak van der Waals forces between adjacent layers, which facilitates gas adsorption. And due to the unique electrical properties, TMDCs can operate at lower operating temperatures, reducing the overall power consumption and eliminating the need for external heating. It also has superior inherent electrical conductivity, ther‑ mal stability, and oxidative stability [218, 219]. However, the pristine TMDC‑based gas sensors exhibit low and slow response, inadequate recovery and poor selectivity [118, 220]. Therefore, promising 2D heterostructures combined with TMDC and MOS have been proposed due to their inte‑ grated advantages of both components. However, there are few papers proposed to fabricate the FRT gas sensor based on TMDC/MOS composites. 

Li et al. [88] used electrospun synthesized  SnO2 nano‑ tubes as a backbone and prepared  SnO2/SnS2 nanotubes using an in situ hydrothermal method, and then spun‑coated the samples on PET substrates to form flexible sensors. Fig‑ ure 9a illustrates the mechanism of  SnO2/SnS2 nanotube in air and  NH3 atmosphere. The work function of  SnO2 is smaller than  SnS2 so that the electrons are transferred from  SnS2 to  SnO2. Electron depletion region and accumu‑ lation region were established on the surface of  SnS2 and SnO2, respectively. When the sensor is in  NH3 atmosphere, gas molecules interact with  O<sup>−</sup> , reducing the thickness of depletion region and the resistance. The heterojunction effect of  SnO2 and  SnS2 contributes to enhance the sens‑ ing performance. As presented in Fig. 9b, the  SnO2/SnS2 nanotubes sensors showed a response of 2.48 to 100 ppm NH3, which was almost two times higher than the pristine SnO2 nanotubes sensors. Beyond that, the sensor presented a relatively rapid response/recovery time of 21/110 s, LOD of 1 ppm, outstanding selectivity. More importantly, the flex‑ ible  SnO2/SnS2 nanotubes exhibited fabulous mechanically flexibility with no response decrease after bending 3,000 times or under 150° bended angle. The fabulous FRT gas sensing performance is attributed to the high aspect ratio of nanotubes and the effect of  SnS2 modification. Kim et al. [221] implemented Au–SnO2–co‑modified  WS2 nanosheets on PI substrate. The sensor exhibited the highest response of 3.687 to 50 ppm CO at an optimum operating voltage of 4.7 V. More importantly, the optimized TMDCs‑based gas sensor exhibited fabulous sensing performance under tilting, bending, and stretching conditions. As presented in Fig. 9c, d, after  10<sup>4</sup> times bending or tilting test, the flexible sensors still exhibited a remarkable and reliable response, 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 25 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) depletion layer Oxygen depletion layer<br>O − O − O − O − SnS2<br>Oe −− e − e − SnS2 e − e − e − O − SnO2 SnO2<br>O − e − e −<br>e − SnO2 e − e − SnO2 e − O − SnS2<br>O − e − e −<br>e − e − SnS2 e − e − O −<br>O − O − O − O − O −<br>O − NO + H2O + e −<br>electron O − O −<br>Ec SnS2<br>Eg = 2.1 eV<br>Ef<br>SnO2 SnO2<br>Eg = 3.5 eV<br>hole SnS2<br>Ev<br>SnS2 SnO2<br>Ammonia depletion layer<br>(b) (c) (d)<br>2.0 SnO2 NTs 500 ppm 6M 3.9 Sensor response Res. time 450<br>200 @50 ppm CO, 4.7 V 3.8 Rec. time 400<br>1.5 10 20 80 100 5M 3.73.6<br>350<br>3.5<br>1.0 4M<br>3.4<br>5 0 100 200 300 400 500 600 700 3.3 300<br>4 SnO2/SnS2 NTs 500 ppm 3M No bending1000 times 3.2 250<br>200 3.1<br>32 10 20 80 100 2M 2500 times5000 times10000 times 3.02.9 200<br>1 1M 2.8 150<br>0 100 200 300 400 500 600 0 200 400 600 800 1000 0 2500 5000 7500 10000<br>Time (s) Time (s) Number of bending (times)<br>/I)Response (Iga<br>Resistance (ohm) Res. & Rec time (sec)<br>/R)Sensor response (Rag<br>Response (I)/Iga<br><!-- End of picture text -->

**Fig. 9  a** The sensing mechanism diagram of  SnO2/SnS2 nanotube in air and  NH3 atmosphere. **b** Transient response of the pristine  SnO2 and SnO2/SnS2 to 10–500 ppm  NH3 at RT. Reproduced with permission from Ref. [88]. Copyright (2017) The Royal Society of Chemistry. **c** Dynamic resistance of Au/SnO2/WS2 to 50 ppm CO after different cycles of bending tests. **d** Response values and response/recovery time of Au/ SnO2/WS2 to 50 ppm CO after different cycles of bending tests. Reproduced with permission from Ref. [221]. Copyright (2021) Elsevier 

which is largely derived from the high carrier mobility and the layered nanostructure of  WS2. Furthermore, for the ter‑ nary compound of Au–SnO2–co–modified  WS2 nanosheets, Schottky junctions form at the interface of Au and  SnO2 as well as Au and  WS2, while heterojunctions form at the interfaces of  SnO2–WS2 and Au/SnO2/WS2, providing a large number of easily modulated heterostructures. When exposed to CO atmosphere, the release of electrons can effectively modulate the potential barrier height of these heterojunctions for rapid and high response. In addition, the self‑heating effect endows the sensor with excellent RT properties. When applying a voltage, the intrinsic resistance of the  WS2 nanosheets and the numerous heterojunctions are great sources of Joule heating, enabling the sensors with‑ out additional heaters. Kang et al. [222] prepared  MoS2 on 

SiO2 by CVD and transferred to a flexible PET substrate, after which 2‑nm‑thick  SnO2 was deposited on its surface by e‑beam evaporation for  NO2 detection. Under visible light activation, unlike the pristine  MoS2, which showed little variation in response to different concentrations of  NO2, the functionalized  MoS2 showed responses of 2.43, 5.84, and 7.57 at RT when exposed to 3, 6, and 9 ppm  NO2, respec‑ tively. This suggests that phototransfer of electrons at the interface heterojunction between  MoS2 and  SnO2 plays a crucial role in the detection of target gas. 

In brief, 2D TMDCs are a novel gas‑sensitive material due to their unique surface effect and low operating tempera‑ ture. TMDCs modified MOS FRT gas sensors sufficiently exploit the superior mechanical flexible lamellar nanostruc‑ ture of TMDCs and substantially increase the slow and low 

1 3 

**206** Page 26 of 42 

Nano‑Micro Lett. (2022) 14:206 

response of pristine TMDCs by modulating the heterojunc‑ tion between MOS and TMDCs. Although there are few papers focus on the preparation of TMDC modified MOS FRT gas sensors, its tremendous mechanical flexibility and the low operating temperature make it a promising material for FRT sensors. 

### **8  Light‑illuminated MOS FRT Gas Sensors** 

##### **8.1  Mechanism of Light‑Illuminated MOS for Enhanced Gas Sensing Performance** 

Light illumination is also a superior strategy to enhance the gas sensing properties [223, 224], decreasing the operating temperature of MOS gas sensor [77, 225, 226], and provid‑ ing a distinctive pathway to achieve FRT MOS gas sensors [227]. When the device is irradiated by light with a certain wavelength, if the photon energy is larger than the MOS bandgap, photogenerated electron–hole pairs will be gener‑ ated, as listed in Eq. 7. The photo‑generated holes will inter‑ act with the chemisorbed oxygen ions on the MOS surface to release oxygen, as listed in Eq. 8, leading to the decrease of the depletion region width and the bulk resistance. In other respects, the photo‑generated electrons will interact with ambient oxygen molecules to form photo‑induced oxygen ions, as listed in Eq. 9. Unlike the strong adhesion of chem‑ isorbed oxygen ions on the MOS surface, the photo‑induced oxygen ions have weak bonding with MOS and thus react easily with target gas, resulting in an enhanced gas sensing response at RT. 



<!-- Start of picture text -->
hv → h + (hv) + e − (hv) (7)<br><!-- End of picture text -->



<!-- Start of picture text -->
h + (hv) + O − 2 → O2 (8)<br><!-- End of picture text -->



<!-- Start of picture text -->
e − (hv) + O2 → O − 2 (hv) (9)<br><!-- End of picture text -->

##### **8.2  FRT Gas Sensors Based on Light‑Illuminated MOS** 

Several FRT gas sensors under light‑illuminated have been reported [66, 70, 75, 99, 102, 105, 160]. The pristine ZnO is a direct bandgap semiconductor with a bandgap of 3.35 eV [228], thus it can be activated by UV‑light and generate photo‑generated electron–hole pairs to effectively lower 

the operating temperature. Zheng et al. [102] presented a UV‑activated flexible ethanol sensor through depositing ZnO nanoparticles on a PET‑ITO substrate. Under UV light illumination, the sensor exhibited a large response of 2.2 to 800 ppm ethanol at RT. In addition, using flexible transpar‑ ent PET‑ITO as a substrate, the sensor has a transmission rate of over 62% in the visible range of 400–800 nm. As another example, Jacobs et al. [160] reported a flexible UV‑ irradiation RT ZnO sensor made of low‑cost, biologically‑ derived ZnS nanoparticles that can be used to effectively detect and discriminate between  O2 and  H2O. 

Photoactivation and molecular sieving can also be com‑ bined to achieve exclusive selectivity and large response at RT. Jo et al. [105] fabricated a monolithic FRT sensor using a  TiO2 film sandwiched between a PET substrate and the molecular sieve ZIF‑7/polyether block amide (PEBA) hybrid overlayer, as shown in Fig. 10a. The obtained pristine  TiO2 sensor showed an ultrahigh response to 5 ppm formaldehyde (Sensitivity (S) = 5,041.0) and ethanol (S = 1,1264.3) under UV illumination (0.184 mW). In contrast, the sandwich‑ shaped sensor showed a large response to 5 ppm formalde‑ hyde (S = 1350.9), while ethanol response (S = 23.5) became negligible, showing an exclusive detection of formaldehyde, as shown in Fig. 10b. This result demonstrated that the molecular‑sieving effect of ZIF‑7/PEBA, successfully siev‑ ing formaldehyde by ethanol filtration. The UV‑irradiation not only provided a ppb‑level formaldehyde detection capa‑ bility with LOD of 3.8 ppb, but also laid a solid foundation for molecular sieve to improve the selectivity of formalde‑ hyde sensor with an ultrahigh response. Furthermore, the performance of sensors is barely affected after bending 200 times or bending at different angles. The outstanding robust‑ ness could be contributed to the superior sandwich structure. 

Apart from the UV illumination, visible‑light illumi‑ nation assisted FRT gas sensors with improved response have been presented. In particular, visible‑light illumina‑ tion has attracted numerous attentions as visible light is an environmental‑friendly and easily accessible light source for portable gas sensors. Geng et al. [70] fabricated lamel‑ lar layered  ZnO1−x FRT  NO2 gas sensors on polypropylene (PP) substrates through suspension flame spraying (SFS) method. The bandgap of ZnO was successfully narrowed down by SFS method due to the high heating/cooling rates and reducing atmosphere. As a result, the light absorption was successfully shifted from the UV to the visible light 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 27 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



**Fig. 10  a** The process flow for preparation of ZIF‑7/PEBA coated  TiO2 sensors. **b** Gas responses of bare  TiO2a, pure PEBA/TiO2b, and 5MMM/ TiO2c sensors exposed to different gas with concentration of 5 ppm at RT under UV‑illumination. Reproduced with permission from Ref. [105]. Copyright (2021) Springer Nature. **c** The linear responses of  ZnO1−x based sensors to 0.25‑1 ppm  NO2 under white‑light illumination. Repro‑ duced with permission from Ref. [70]. Copyright (2017) Elsevier. Transient response of ZI, ZIC, ZIC‑L (lower g‑C3N4 content), ZIC‑H (higher g‑C3N4 content) sensors to 1 ppm  NO2 at RT **d** in dark, **e** under visible‑light illumination. Reproduced with permission from Ref. [66]. Copy‑ right (2021) Wiley–VCH 

region. In addition, ascribed to high volume‑to‑surface ratio and the lamellar hierarchical porous nanostructure, the ZnO1−x nanofilms showed a linear response to 0.25–1 ppm NO2 under white‑light illumination, as shown in Fig. 10c. In addition, a flexible all‑inorganic RT MOS gas sensor based on yttria‑stabilized zirconia (YSZ)/In2O3/graphitic carbon nitride (g–C3N4) (ZIC) [66] was reported, employing a vis‑ ible‑light powered scheme to lower the operating tempera‑ ture, using fibrous ceramic YSZ as the flexible substrate and In2O3/g–C3N4 as the activated sensing region. The promot‑ ing effect of visible light on sensing performance was fur‑ ther studied. The dynamic  NO2 responses of YSZ/In2O3 (ZI) and ZIC flexible sensors at RT with or without visible‑light illumination are shown in Fig. 10d, e. It can be observed that in the absence of light irradiation, the response is low and the recovery ability is negligible. In contrast, under vis‑ ible light irradiation, the sensor exhibited sharply increased 

response after being exposed to  NO2 and the response fully recovered to original value after removing  NO2. Therefore, visible‑light irradiation can not only effectively improve the gas sensing response, but also prompting response/recovery process. 

In brief, photoactivation is effective in reducing the oper‑ ating temperature and provides a distinctive way to realize FRT MOS gas sensors. The mechanism of photoactivation is based on the activation of photogenerated electron–hole pairs generated by the photoelectric effect. The specific preparation process can reduce the MOS material bandgap, which shifts the light absorption from the UV region to the visible region. Both UV and visible light irradiation can effectively reduce the operating temperature, increase the response value, and speed up the response/recovery process, which is another perspective to achieve RT operation in addition to material design. 

1 3 

**206** Page 28 of 42 

Nano‑Micro Lett. (2022) 14:206 

- **9  Applications of the FRT Gas Sensors Based on MOS** 

Gas sensors are currently used in a wide range of applica‑ tions in smart homes, food safety monitoring, public safety, healthcare, medical diagnostics, environmental protection, and industrial/agricultural monitoring. Some emerging applications of gas sensing include ingestible electronic capsules, electronic skin, and smart electronic nose, impos‑ ing higher requirements on the low operating temperature, high gas sensing properties, excellent interference immunity, and stable mechanical flexibility of the gas sensors. Ingest‑ ible electronic capsules are non‑invasive capsules that are delivered to the human gastrointestinal tract to detect vari‑ ous gases such as methane, oxygen, hydrogen, and carbon dioxide for human health detection [229, 230]. Gas sensors that exhibit high performance at RT are considered to be one of the key components of ingestible electronic capsules. In addition, the natural skin uses ion reporting signals, while the flexible, comfortable and stretchable electronic skin uses electron reporting signals. The electronic skin equipped with stretchable gas sensors can be perfectly fitted to the human body to achieve real‑time detection of environmental gases. FRT gas sensors can effectively reduce the energy consumption, simplify the structure, and be applicable for harsh environments, such as for the detection of flammable explosives and various low‑temperature operating wearable devices. The traditional MOS materials are hindered by the disadvantage of high operating temperature for wearable applications. The MOS‑based FRT gas sensors with high performance presented in this paper are most attractive for wearable device applications. Currently, MOS‑based FRT gas sensors have been reported for multi‑detection sensor arrays and wearable devices such as smart masks, gas sens‑ ing watches, E‑textiles, and skin‑fitting RFID. 

With urbanization and industrialization, air pollution lev‑ els are increasing. Monitoring of the public environment is necessary to protect people from the gaseous pollutants and toxic gases. In addition, it is significant to detect the concen‑ tration of toxic gases in industrial production in real time and to develop wearable gas detection and warning devices for workers, especially in environments where toxic gas leaks are likely to occur. Zhang et al. [231] deposited RGO/SnO2 sensing films on PI substrates by spraying process and inte‑ grated them to form a FRT  NO2 monitoring system. The 

gas monitoring system can detect the lowest concentration limit of 20 ppm. When the blue indicator light turns on, the system is in operation. While the red warning indica‑ tor light turns up when the  NO2 gas concentration exceeds the set threshold. The  NO2 monitoring system can also be embedded in masks and watches owing to its small volume and excellent flexibility, realizing practical applications of flexible  NO2 gas sensors in the field of wearable electronics (Fig. 11a). Gao et al. [100] prepared SWCNTs, MWCNTs, and ZnO quantum dot‑modified SWCNTs as sensing mate‑ rials on flexible nylon fibers, which could be further inte‑ grated into the mask by weaving. The smart mask selectively detects  NH3, HCHO, and  C2H5OH by sensing the change of sensor resistance to control the corresponding LEDs to turn on (Fig. 4f). 

E‑noses are devices used for sniffing out gaseous com‑ pounds in the environment like the human olfactory organ. E‑noses typically consist of numerous chemical gas sensors, which are modulated by signal and pattern recognition tech‑ niques so that the sensor arrays can respond to a range of gases [232]. The selectivity is achieved by analyzing the characteristic patterns of response data in the sensor arrays. The integrated configuration of gas sensor arrays might be the future trend for constructing stable and efficient E‑noses. Kroutil et al. [113] prepared pristine PANI, PANI/CNTs, PANI/SnO2 and PANI/TiO2 composites on PI flexible sub‑ strates. Four sensor elements were fabricated on a single flexible substrate, greatly facilitating a wider and convenient application. The expanded view, structural composition, and physical demonstration of their sensor arrays are shown in Fig. 11b. The RT gas sensing performance of the fabricated gas sensor arrays towards different gas atmospheres  (O2, NH3,  CO2,  NO2, acetone, toluene, and relative humidity) was investigated. However, the sensor arrays did not further dem‑ onstrate effective discrimination of these gases, and the lack of selectivity is of concern and further investigation needs to be carried out. It is possible to combine with machine learning algorithms to achieve substantial enhancement, such as detect multiple gases and significantly improve the selectivity of the sensor arrays, which is unimaginable for the traditional sensors. A sensor array consisting of pristine SnO2,  SnO2/PANI, RGO/PANI and  SnO2/RGO/PANI was carried out by Zhang et al. [98]  H2S with different concen‑ trations (0.1–1.2 ppm) were apparently discriminated from other interfering gas species  (NH3, ethanol, and acetone) processed by principal component analysis algorithm. 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 29 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 



<!-- Start of picture text -->
(a) chamberGas NO2-out Power light-Blue (b) Top view Bottom view<br>Waning<br>light-Red<br>NO2-in<br>Face mask<br>Kapton solder stop mask<br>Heating<br>element<br>Cu IDT Cu Temperature<br>electrodes electrodes sensor<br>Au metallization Kaptonlayer Au metallization<br>PANI PANI+CNT<br>(c) 1.0 Exhaled breath(halitosis people) (d) (e) Flower-shaped<br>Exhaled breath CuO-SWCNT<br>0.5 (health people) sensing material<br>0.0<br>−0.5<br>−1.0−1.0 1.0 PANI+TiO2 PANI+SnO2<br>−0.5 0.0 0.0 0.5 Wearable E-textile 1 cm RFID tag ZIF connector<br>0.5 −0.5 12.5 mm<br>1.0 −1.0<br>Principal component 1(59.32%) Principal component 3(4.72%) Top view Bottom view<br>(24.13%)<br>Principal component 2<br><!-- End of picture text -->

**Fig. 11  a** The FRT  NO2 monitoring system and wearable applications for smart masks and watches. Reproduced with permission from Ref. [231]. Copyright (2022) Springer Nature. **b** The expanded view, structural composition, and physical demonstration of the PANI‑based sen‑ sor arrays. Reproduced with permission from Ref. [113]. Copyright (2018) IEEE. **c** The 3D feature space for principal component analysis of RGO/ZnO hybrid towards different exhaled gases from healthy individuals and patients with halitosis. Reproduced with permission from Ref. [98]. Copyright (2019) Elsevier. **d** The 5 × 5 gas sensors array networks of the E‑textile. Reproduced with permission from Ref. [54]. Copyright (2019) American Chemical Society. **e** The optical image of fabricated wireless RFID sensor. Reproduced with permission from Ref. [112]. Copyright (2016) Elsevier 

Furthermore, the sensor arrays can effectively distinguish between the exhaled gas of a healthy people and the exhaled gas of halitosis patients with a detection limit of 0.1 ppm. The classification map is presented in Fig. 11c, where it can be seen that the exhaled breath patterns of healthy individu‑ als are randomly dispersed, whereas the patterns of patients with halitosis are classifiable together, demonstrating its potential prospects for exhaled gas analyzers. 

In smart wearable electronic devices, E‑textiles are popu‑ lar for their low price, light weight, and good compatibility with clothes. Li et al. [54] prepared RGO/ZnO nanosheets on cotton/elastic threads to form conductive sensing fibers, which are stretchable, twistable and bendable with excel‑ lent wearability and knittability. The sensing threads exhib‑ ited superior sensing performance to  NO2 at RT with high response (44% to 50 ppm), low theoretical detection limit (43.5 ppb) and fabulous deformation tolerance. To further 

improve the reliability and expand the practical applications, the RGO/ZnO hybrid threads were woven into a 5 × 5 sen‑ sors array network (Fig. 11d). The response of the incor‑ porated networks is close to the average response value of individual sensors, thus achieving an enhanced sensing reli‑ ability with a single measurement. More importantly, even if some of the individual sensors are out of operation after long‑term use, the network can remain in working state, thus improving the repairability, long‑term stability, and prac‑ ticality of sensor array. The wearable e‑textile operating at RT with great sensing performance, superior flexibility and scalable applications represent a novel perspective for extensive monitoring of human activities in human–machine interactions and mobile devices. 

As the demand for low‑cost, flexible, and low‑energy wireless electronics and the growing interest in "cogni‑ tive intelligence", RFID is considered as one of the most 

1 3 

**206** Page 30 of 42 

Nano‑Micro Lett. (2022) 14:206 

revolutionary technologies to achieve ubiquitous IoTs. Asad et al. [112] drop‑cast the prepared flower‑like CuO‑SWCNTs on the antenna of the commercial 13.56 MHz RFID tags (Fig. 11e). The obtained wireless RFID sensor was adhered with adhesive paste on the back side, which could be per‑ fectly attached to the skin. What’s more, the RFID sensor can selectively detect  H2S at RT with an ultralow LOD of 100 ppb and a long‑term stability of 30 days, and exhibit excellent sensing performance under the bending situa‑ tion. These results indicates that the RT‑operating mate‑ rials can be manufactured into flexible RFID sensors by extremely facile drop‑casting process, demonstrating their possible wide application in healthcare and environmental monitoring. 

### **10  Conclusion and Future Perspectives** 

In this review, we have systematically analyzed and sum‑ marized the recent advances on FRT MOS gas sensors. Our attention concentrates on the critical review of FRT gas sen‑ sors, focusing on pristine MOS and the hybrids of MOS modified with nanostructure noble metal, organic polymers, carbon‑based structures, and TMDCs materials. In addition, light‑illuminated MOS‑based FRT gas sensors are also sum‑ marized. Strategies for implementing FRT gas sensors are discussed from the viewpoints of material design, alter‑ nate activation, and mechanism explanation. The diverse types of sensors discussed above indicate that an excellent mechanically flexible gas sensor is the appropriate combina‑ tion with flexible substrates (polymeric substrates, textiles, paper‑based substrates, etc.), device structures and steady contact between substrates and sensing materials. At the meantime, the high‑performance RT gas sensor is the justi‑ fied combination with morphological nanostructures, hybrid materials, and synergetic interfacial effect. This review will have considerable reference value for design, fabrication and development of novel FRT MOS gas sensors. 

Generally, MOS gas sensors have the merits of easy syn‑ thesis, high response value, low cost, rapid response/recov‑ ery, great reversibility, and excellent stability. However, their high‑temperature operation hinders their wider applications. For example, when operating at RT, many MOS gas sensors exhibit inadequate sensitivity, reduced selectivity and the response/recovery process becomes slower, sometimes up to tens of minutes, which is critical for the rapid detection 

of hazardous gases and timely alarm triggering. The per‑ formance of MOS gas sensors can be enhanced by several methods, including preparation of various morphologies of MOS, modification of MOS with noble metal, composites with organic polymers, carbon‑based materials and TMDCs materials, and light‑illuminated assistance. The main con‑ clusions are summarized as follows: 

- (1) Nanostructures of various morphologies for pristine MOS have been prepared to help reducing the operat‑ ing temperature to RT and enhancing their response value, response/recovery speed, selectivity, and LODs. Among them, 1D nanostructured sensing materials (nanofibers, nanowires, nanorods, etc.) are the pre‑ ferred materials for RT gas sensors due to their inher‑ ent geometrically higher surface‑to‑volume ratio. Fur‑ thermore, 1D nanostructures not only contribute to the increased adsorption capacity to the analyte, but also provide more significant modulation of the electrical properties when exposed to the analyte attributed to a broader region of interaction in the cross‑section. 

- (2) Modification with noble metals is also a superior scheme to enhance the response and selectivity due to the synergistic effect of chemical sensitization and electronic sensitization. In addition, noble metal modi‑ fication is generally effective in changing the surface nanostructure and morphology of MOS materials, increasing the number of active sites, creating more defects, generating more oxygen vacancies, providing more oxygen species, and enhancing surface lattice oxygen activity. Furthermore, Schottky barriers are formed when noble metals are in close contact with MOS materials, which can change the electron dis‑ tribution and energy band structure in MOS materi‑ als. Moreover, some noble metals are specific for the detection of certain gases, which is advantageous for RT operation. Besides, the small size of noble metal nanoparticles does not affect the mechanical flexibility properties of the sensing material. All these processes can help to enhance the gas sensing performance of FRT MOS‑based gas sensors. 

- (3) Organic conducting polymers especially PANI has been widely used in MOS‑based FRT gas sensors owing to their tunable electrical properties, excellent mechani‑ cal flexibility, RT operation, and morphological tun‑ ability. The protonation/deprotonation process of PANI and the formation of heterojunctions at the interface of PANI and MOS endow superior sensing properties. 0D nanoparticles, 1D nanofibers, and 2D nanosheets of PANI have been utilized for the preparation of high‑ 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 31 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

   - performance FRT gas sensors. Among them, 0D PANI nanoparticles attached to MOS exhibit favorable cata‑ lytic enhancement. 1D PANI nanofibers show better RT sensing performance due to better conductivity and higher surface‑to‑volume ratio. PANI nanosheets with large surface area and tremendous mechanical stabil‑ ity showed no degradation after bending tests. Beyond that, the PANI‑modified MOS sensing materials dem‑ onstrate fabulous demonstrate resistance due to the accelerated ES to EB transition process of PANI in high humidity environments. Generally, organic conducting polymers modified MOS FRT gas sensors exhibit high sensitivity and low LODs. 

- (4) Various organic polymers such as chitosan, PVA, CMC, etc. are mixed with IL and MOS to form membranes, which can not only act as the flexible substrate, but also exhibit gas sensing characteristics. The presence of IL can effectively control the electrical conductivity of the organic–inorganic compounds and help improving the stretchability and flexibility of the membranes. 

- (5) Carbon‑based materials including 1D SWCNTs, MWCNTs, and 2D RGOs have been applied to MOS‑ based FRT gas sensors owing to high carrier mobility, unique flexibility properties, high surface‑to‑volume ratio, abundant adsorptive sites, and RT operation. The reported carbon‑based materials modified MOS FRT gas sensors typically exhibit lower LODs, shorter response/recovery times, lower operating temperatures, and better mechanical flexibility. However, they suffer from the low significant increase in response value. 

- (6) TMDCs‑modified MOS FRT gas sensors take full advantage of the superior mechanically flexible lamel‑ lar nanostructure of TMDCs and the effective modu‑ lation of heterojunction between MOS and TMDCs, greatly improves the slow and low response of the original TMDCs. However, there are few papers pro‑ posed to fabricate the FRT gas sensor based on TMDC/ MOS composite. The performance of TMDCs materi‑ als modified MOS FRT gas sensors remains to be con‑ cluded and discovered. 

- (7) Light illumination is an alternate strategy to realize RT operation. The mechanism of light illumination is based on the activation of photo‑generated electron–hole pairs generated by the photoelectric effect. When illumina‑ tion, the surface of MOS generates photo‑induced oxygen ions, which have weak bonding with MOS and can be easily reacted with target gas, resulting in an enhanced gas sensing performance. Both UV‑light and visible‑light illumination have been employed to manufacture FRT gas sensors, effectively reducing the 

operating temperature, increasing the response value, and speeding up the response/recovery process. 

Although tremendous advances have been made in the development of FRT MOS gas sensors, many challenges and problems remain in achieving great mechanical flexibil‑ ity, high response valve, rapid response/recovery, exclusive selectivity, low LODs, and long‑term stability. The chal‑ lenges and future perspectives involved in FRT gas sensors are summarized as follows: 

- (a) Various MOS have been applied to FRT gas sensors, including n‑type MOS  (SnO2, ZnO,  TiO2,  WO3,  In2O3, Fe2O3,  MoO3, CdO,  CeO2,  CoFe2O4 and  SrGe4O9), and p‑type MOS (CuO and  Co3O4). However, there are still many sensitive and promising MOS that have not been applied to FRT gas sensors, such as  V2O5, NiO, and  MnO2, which have been extensively studied and behaved great gas sensing performance. The introduc‑ tion of novel MOS might be helpful to find new well‑ behaved sensing materials to achieve FRT sensors. 

- (b) In general, most FRT MOS‑based gas sensors are based on pristine MOS or two‑component composites. Recently, ternary composites‑based MOS gas sensors have been prepared to achieve superior performance. The substantial increase in sensing performance of ter‑ nary composites is mainly attributed to the formation of numerous easily modulated heterostructures at the interfaces of different components, the generation of more defects and active sites, and the increase in pos‑ sible conducting channels. However, there are still few researches focusing on ternary or multivariate compos‑ ites, which may have excellent prospects for FRT gas sensors. 

- (c) Flexible substrates have been developed relatively mature at present, exhibiting great mechanical property. Up to now, polymers (PI, PET, PDMS, nylon, etc.), tex‑ tiles (cotton fabric, yarn, fiber, etc.), and paper‑based substrates (cellulose, tattoo papers, etc.) have been widely used for flexible gas sensors. However, one of the key challenges is the cracking and spalling of the sensing component. Generally, flexible gas sensors are fabricated through simple spin‑coating, dip‑coating, and drying, which leads to the agglomeration, densifi‑ cation, and nonuniformity of the sensing component, deteriorating the long‑term stability and mechanically flexibility of the flexible gas sensors. As new process‑ ing and fabricating techniques have emerged, the prepa‑ ration of flexible gas sensors has also been innovated. Some preparation methods for in situ growth of sensing 

1 3 

**206** Page 32 of 42 

Nano‑Micro Lett. (2022) 14:206 

materials on flexible substrates reported in this review might increase the bonding between sensing materials and substrates, such as in situ hydrothermal process [92, 93], in situ sol–gel grown [104], in situ polym‑ erization [79, 87], and in situ self‑assembly method [83]. Several novel transfer methods have also been reported, such as suspension flame spraying [70, 76], hot pressing method [94], slide transfer, roll transfer, and heat transfer [90]. In addition, the sensing material and organic polymer solution are mixed and dispersed uniformly by stirring and ultrasonication, and then solution‑cast technique is used to form a monolithic flexible sensing material [95–97, 103, 192], which is beneficial for the stability and longevity. What’s more, some specific additives such as sorbitol and glycerol might be helpful to enhance the extensibility and flex‑ ibility of the sensitive film. However, there is less discussion on how the preparation methods affects the flexible properties of the sensors, and the fracture mechanism of sensing films remains to be explored. According to different sensing materials, selecting suit‑ able flexible substrates to reduce the elastic mismatch may be beneficial to fabricate flexible gas sensors with better mechanical properties. 

- (d) Up to now, TMDCs materials have been widely applied to RT gas sensors with low LODs, great response and rapid response/recovery. However, it is rarely combined with flexible substrates to form FRT sensors. TMDCs materials modified MOS might be promising materials for FRT gas sensors. 

- (e) Owing to its good electrical conductivity, carbon‑based materials can expand electron pathways and acceler‑ ate electron transport when hybridized with MOS. At present, carbon‑based materials modified MOS FRT gas sensors have excellent development prospects and have been reported in practical applications, such as smart face masks, smart textiles, and wireless RFID, which might be the earliest FRT gas sensors to be put into commercial products. 

- (f) At present, MOS‑based FRT sensor array has been reported. It is worth believing that the integrated con‑ figuration of sensor array might be the future trend of the robust flexible gas sensing system. The sensor array can not only get a more accurate and reliable result through one‑time detection, but also improve long‑ term stability of the system due to the configuration of multiple sensors. In addition, flexible gas sensor arrays in combination with machine learning algorithms to achieve multiple gases detection and significantly improve the selectivity of the sensor arrays, which is unimaginable for the traditional sensors. The integrated 

   - configuration of gas sensor arrays might be the future trend for constructing stable and efficient E‑noses. 

- (g) Although light illumination has been demonstrated to be a useful method to enhance the performance of sen‑ sors, the mechanism behind it remains to be explored. Generally, ultraviolet light sources are expensive and might lead to photodegradation of sensing materials, limiting its extensive applications. Therefore, designing more sensitive materials that can be activated by visible light is more beneficial for practical applications. 

To date, the development of FRT gas sensors has just started, and there are still many challenges and issues in achieving excellent flexibility and gas sensitive character‑ istics. In the future, as new materials, innovative processes and advanced structures are further developed, high‑per‑ formance FRT gas sensors will be more facilely available. 

**Acknowledgements** This work is supported by This work was supported by the National Key R&D Program of China (Nos. 2020YFB2008604 and 2021YFB3202500), the National Natural Science Foundation of China (Nos. 61874034 and 51861135105), the International Science and Technology Cooperation Program of Shanghai Science and Technology Innovation Action Plan (No. 21520713300), and Fudan University‑CIOMP Joint Fund (E02632Y7H0). 

**Funding** Open access funding provided by Shanghai Jiao Tong University. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Com‑ mons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Com‑ mons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creat iveco mmons. org/ licen ses/ by/4. 0/. 

### **References** 

1. M. Hassanalieragh, A. Page, T. Soyata, G. Sharma, M. Aktas et al., Health monitoring and management using internet‑of‑ things (IoT) sensing with cloud‑based processing: opportu‑ nities and challenges. Proc. IEEE Int. Conf. Serv. Comput., New York, NY, USA, 285–292 (2015). https:// doi. org/ 10. 1109/ Scc. 2015. 47 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 33 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

2. A. Zanella, N. Bui, A. Castellani, L. Vangelista, M. Zorzi, Internet of things for smart cities. IEEE Int. Things **1** (1), 22–32 (2014). https:// doi. org/ 10. 1109/ Jiot. 2014. 23063 28 

3. H. Li, K. Ota, M.X. Dong, Learning IoT in edge: deep learn‑ ing for the internet of things with edge computing. IEEE Network **32** (1), 96–101 (2018). https:// doi. org/ 10. 1109/ Mnet. 2018. 17002 02 

4. H.S. Ning, Z.O. Wang, Future Internet of things architecture: like mankind neural system or social organization frame‑ work? IEEE Commun. Lett. **15** (4), 461–463 (2011). https:// doi. org/ 10. 1109/ Lcomm. 2011. 022411. 110120 

5. K.P. Yuan, L.Y. Zhu, J.H. Yang, C.Z. Hang, J.J. Tao et al., Precise preparation of  WO3@SnO2 core shell nanosheets for efficient  NH3 gas sensing. J. Colloid Interf. Sci. **568** , 81–88 (2020). https:// doi. org/ 10. 1016/j. jcis. 2020. 02. 042 

6. M. Stoppa, A. Chiolerio, Wearable electronics and smart tex‑ tiles: a critical review. Sensors **14** (7), 11957–11992 (2014). https:// doi. org/ 10. 3390/ s1407 11957 

7. T. Yamada, Y. Hayamizu, Y. Yamamoto, Y. Yomogida, A. Izadi‑Najafabadi et al., A stretchable carbon nanotube strain sensor for human‑motion detection. Nat. Nanotechnol. **6** (5), 296–301 (2011). https:// doi. org/ 10. 1038/ Nnano. 2011. 36 

8. W. Gao, S. Emaminejad, H.Y.Y. Nyein, S. Challa, K.V. Chen et al., Fully integrated wearable sensor arrays for multiplexed in situ perspiration analysis. Nature **529** (7587), 509–514 (2016). https:// doi. org/ 10. 1038/ natur e16521 

9. W. Zeng, L. Shu, Q. Li, S. Chen, F. Wang et al., Fiber‑based wearable electronics: a review of materials, fabrication, devices, and applications. Adv. Mater. **26** (31), 5310–5336 (2014). https:// doi. org/ 10. 1002/ adma. 20140 0633 

10. T.Q. Trung, N.E. Lee, Flexible and stretchable physical sen‑ sor integrated platforms for wearable human‑activity moni‑ toring and personal healthcare. Adv. Mater. **28** (22), 4338– 4372 (2016). https:// doi. org/ 10. 1002/ adma. 20150 4244 

11. X.W. Wang, Y. Gu, Z.P. Xiong, Z. Cui, T. Zhang, Silk‑molded flexible, ultrasensitive, and highly stable electronic skin for monitoring human physiological signals. Adv. Mater. **26** (9), 1336–1342 (2014). https:// doi. org/ 10. 1002/ adma. 20130 4248 

12. D. Son, J. Lee, S. Qiao, R. Ghaffari, J. Kim et al., Multifunc‑ tional wearable devices for diagnosis and therapy of move‑ ment disorders. Nat. Nanotechnol. **9** (5), 397–404 (2014). https:// doi. org/ 10. 1038/ Nnano. 2014. 38 

13. Y. Khan, A.E. Ostfeld, C.M. Lochner, A. Pierre, A.C. Arias, Monitoring of vital signs with flexible and wearable medical devices. Adv. Mater. **28** (22), 4373–4395 (2016). https:// doi. org/ 10. 1002/ adma. 20150 4366 

14. S.M. Niu, N. Matsuhisa, L. Beker, J.X. Li, S.H. Wang et al., A wireless body area sensor network based on stretchable passive tags. Nat. Electron. **2** (8), 361–368 (2019). https:// doi. org/ 10. 1038/ s41928‑ 019‑ 0286‑2 

15. S. Seyedin, P. Zhang, M. Naebe, S. Qin, J. Chen et al., Tex‑ tile strain sensors: a review of the fabrication technologies, performance evaluation and applications. Mater. Horiz. **6** (2), 219–249 (2019). https:// doi. org/ 10. 1039/ c8mh0 1062e 

16. S. Xu, Y.H. Zhang, L. Jia, K.E. Mathewson, K.I. Jang et al., Soft microfluidic assemblies of sensors, circuits, and radios for the skin. Science **344** (6179), 70–74 (2014). https:// doi. org/ 10. 1126/ scien ce. 12501 69 

17. A. Davis, D. Khazanchi, J. Murphy, I. Zigurs, D. Owens, Avatars, people, and virtual worlds: foundations for research in metaverses. J. Assoc. Inf. Syst. **10** (2), 90–117 (2009). https:// doi. org/ 10. 17705/ 1jais. 00183 

18. J.D.N. Dionisio, W.G. Burns, R. Gilbert, 3D virtual worlds and the metaverse: current status and future possibilities. ACM Comput. Surv. **45** (3), 1–38 (2013). https:// doi. org/ 10. 1145/ 24807 41. 24807 51 

19. S. Ionut‑Cristian, D. Dan‑Marius, Using inertial sensors to determine head motion‑a review. J. Imaging **7** (12), 265 (2021). https:// doi. org/ 10. 3390/ jimag ing71 20265 

20. R. Atkinson, Atmospheric chemistry of VOCs and  NOx. Atmos. Environ. **34** (12–14), 2063–2101 (2000). https:// doi. org/ 10. 1016/ S1352‑ 2310(99) 00460‑4 

21. M. Ehn, J.A. Thornton, E. Kleist, M. Sipila, H. Junninen et al., A large source of low‑volatility secondary organic aerosol. Nature **506** (7489), 476–479 (2014). https:// doi. org/ 10. 1038/ natur e13032 

22. N. Dudareva, A. Klempien, J.K. Muhlemann, I. Kaplan, Biosynthesis, function and metabolic engineering of plant volatile organic compounds. New Phytol. **198** (1), 16–32 (2013). https:// doi. org/ 10. 1111/ nph. 12145 

23. G. Zeng, C. Wu, Y. Chang, C. Zhou, B.B. Chen et al., Detection and discrimination of volatile organic com‑ pounds using a single film bulk acoustic wave resonator with temperature modulation as a multiparameter virtual sensor array. ACS Sens. **4** (6), 1524–1533 (2019). https:// doi. org/ 10. 1021/ acsse nsors. 8b016 78 

24. M.S. Kamal, S.A. Razzak, M.M. Hossain, Catalytic oxi‑ dation of volatile organic compounds (VOCs) ‑ a review. Atmos. Environ. **140** , 117–134 (2016). https:// doi. org/ 10. 1016/j. atmos env. 2016. 05. 031 

25. J.H. Mo, Y.P. Zhang, Q.J. Xu, J.J. Lamson, R.Y. Zhao, Photocatalytic purification of volatile organic compounds in indoor air: a literature review. Atmos. Environ. **43** (14), 2229–2246 (2009). https:// doi. org/ 10. 1016/j. atmos env. 2009. 01. 034 

26. X.Y. Zhang, B. Gao, A.E. Creamer, C.C. Cao, Y.C. Li, Adsorption of VOCs onto engineered carbon materials: a review. J. Hazard. Mater. **338** , 102–123 (2017). https:// doi. org/ 10. 1016/j. jhazm at. 2017. 05. 013 

27. M. Hakim, Y.Y. Broza, O. Barash, N. Peled, M. Phillips et al., Volatile organic compounds of lung cancer and possi‑ ble biochemical pathways. Chem. Rev. **112** (11), 5949–5966 (2012). https:// doi. org/ 10. 1021/ cr300 174a 

28. C.T. Chang, C.J. Yang, K.H. Huang, J.C. Huang, T.C. Lin, Changes of precipitation acidity related to sulfur and nitrogen deposition in forests across three continents in north hemi‑ sphere over last two decades. Sci. Total Environ. **806** , 150552 (2022). https:// doi. org/ 10. 1016/j. scito tenv. 2021. 150552 

29. L.P. Naeher, M. Brauer, M. Lipsett, J.T. Zelikoff, C.D. Simp‑ son et al., Woodsmoke health effects: a review. Inhal. Toxicol. 

1 3 

**206** Page 34 of 42 

Nano‑Micro Lett. (2022) 14:206 

   - **19** (1), 67–106 (2007). https:// doi. org/ 10. 1080/ 08958 37060 09858 75 

30. D.N. Granger, P.R. Kvietys, Reperfusion injury and reactive oxygen species: the evolution of a concept. Redox Biol. **6** , 524–551 (2015). https:// doi. org/ 10. 1016/j. redox. 2015. 08. 020 

31. M.A. Sidell, Z.H. Chen, B.Z. Huang, T. Chow, S.P. Eckel et al., Ambient air pollution and COVID‑19 incidence dur‑ ing four 2020–2021 case surges. Environ. Res. **208** , 112758 (2022). https:// doi. org/ 10. 1016/j. envres. 2022. 112758 

32. Z. Zhang, T. Xue, X. Jin, Effects of meteorological conditions and air pollution on COVID‑19 transmission: evidence from 219 Chinese cities. Sci. Total Environ. **741** , 140244 (2020). https:// doi. org/ 10. 1016/j. scito tenv. 2020. 140244 

33. Y.J. Zhu, J.G. Xie, F.M. Huang, L.Q. Cao, Association between short‑term exposure to air pollution and COVID‑ 19 infection: evidence from China. Sci. Total Environ. **727** , 1604215 (2020). https:// doi. org/ 10. 1016/j. scito tenv. 2020. 138704 

34. E. Conticini, B. Frediani, D. Caro, Can atmospheric pol‑ lution be considered a co‑factor in extremely high level of SARS‑CoV‑2 lethality in northern Italy? Environ. Pollut. **261** , 114465 (2020). https:// doi. org/ 10. 1016/j. envpol. 2020. 114465 

35. W.W. Hu, W.W. Wu, Y.Y. Jian, H. Haick, G.J. Zhang et al., Volatolomics in healthcare and its advanced detection tech‑ nology. Nano Res. **15** , 8185–8213 (2022). https:// doi. org/ 10. 1007/ s12274‑ 022‑ 4459‑3 

36. W. Miekisch, J.K. Schubert, G.F.E. Noeldge‑Schomburg, Diagnostic potential of breath analysis‑focus on volatile organic compounds. Clin. Chim. Acta **347** (1–2), 25–39 (2004). https:// doi. org/ 10. 1016/j. cccn. 2004. 04. 023 

37. S.M. Aghaei, A. Aasi, S. Farhangdoust, B. Panchapakesan, Graphene‑like  BC6N nanosheets are potential candidates for detection of volatile organic compounds (VOCs) in human breath: a DFT study. Appl. Surf. Sci. **536** , 147756 (2021). https:// doi. org/ 10. 1016/j. apsusc. 2020. 147756 

38. A. Amann, B. Costello, W. Miekisch, J. Schubert, B. Busze‑ wski et al., The human volatilome: volatile organic com‑ pounds (VOCs) in exhaled breath, skin emanations, urine, feces and saliva. J. Breath Res. **8** (3), 034001 (2014). https:// doi. org/ 10. 1088/ 1752‑ 7155/8/ 3/ 034001 

39. D.S. Li, Z.H. Xie, M.J. Qu, Q. Zhang, Y.Q. Fu et al., Vir‑ tual sensor array based on Butterworth‑van Dyke equivalent model of QCM for selective detection of volatile organic compounds. ACS Appl. Mater. Interfaces **13** (39), 47043– 47051 (2021). https:// doi. org/ 10. 1021/ acsami. 1c130 46 

40. G. Konvalina, H. Haick, Sensors for breath testing: from nanomaterials to comprehensive disease detection. Acc. Chem. Res. **47** (1), 66–76 (2014). https:// doi. org/ 10. 1021/ ar400 070m 

41. R. Vishinkin, H. Haick, Nanoscale sensor technologies for disease detection via volatolomics. Small **11** (46), 6142–6164 (2015). https:// doi. org/ 10. 1002/ smll. 20150 1904 

42. S. Das, M. Pal, Review‑non‑invasive monitoring of human health by exhaled breath analysis: a comprehensive review. J. Electrochem. Soc. **167** (3), 037562 (2020). https:// doi. org/ 10. 1149/ 1945‑ 7111/ ab67a6 

43. X.H. Sun, K. Shao, T. Wang, Detection of volatile organic compounds (VOCs) from exhaled breath as noninva‑ sive methods for cancer diagnosis. Anal. Bioanal. Chem. **408** (11), 2759–2780 (2016). https:// doi. org/ 10. 1007/ s00216‑ 015‑ 9200‑6 

44. G.T. Fan, C.L. Yang, C.H. Lin, C.C. Chen, C.H. Shih, Appli‑ cations of Hadamard transform‑gas chromatography/mass spectrometry to the detection of acetone in healthy human and diabetes mellitus patient breath. Talanta **120** , 386–390 (2014). https:// doi. org/ 10. 1016/j. talan ta. 2013. 12. 025 

45. X.T. Xue, L.Y. Zhu, K.P. Yuan, C. Zeng, X.X. Li et al., ZnO branched p‑CuxO @n‑ZnO heterojunction nanowires for improving acetone gas sensing performance. Sens. Actuat. B Chem. **324** , 128729 (2020). https:// doi. org/ 10. 1016/j. snb. 2020. 128729 

46. K.P. Yuan, C.Y. Wang, L.Y. Zhu, Q. Cao, J.H. Yang et al., Fabrication of a micro‑electromechanical system‑based ace‑ tone gas sensor using  CeO2 nanodot‑decorated  WO3 nanow‑ ires. ACS Appl. Mater. Interfaces **12** (12), 14095–14104 (2020). https:// doi. org/ 10. 1021/ acsami. 9b188 63 

47. M.Y. Liu, C.Z. Hang, X.F. Zhao, L.Y. Zhu, R.G. Ma et al., Advance on flexible pressure sensors based on metal and car‑ bonaceous nanomaterial. Nano Energy **87** , 106181 (2021). https:// doi. org/ 10. 1016/j. nanoen. 2021. 106181 

48. S.C. Mukhopadhyay, Wearable sensors for human activity monitoring: a review. IEEE Sens. J. **15** (3), 1321–1330 (2015). https:// doi. org/ 10. 1109/ Jsen. 2014. 23709 45 

49. E. Singh, M. Meyyappan, H.S. Nalwa, Flexible graphene‑ based wearable gas and chemical sensors. ACS Appl. Mater. Interfaces **9** (40), 34544–34586 (2017). https:// doi. org/ 10. 1021/ acsami. 7b070 63 

50. M.C. McAlpine, H. Ahmad, D.W. Wang, J.R. Heath, Highly ordered nanowire arrays on plastic substrates for ultrasen‑ sitive flexible chemical sensors. Nat. Mater. **6** (5), 379–384 (2007). https:// doi. org/ 10. 1038/ nmat1 891 

51. Y. Pang, J.M. Jian, T. Tu, Z. Yang, J. Ling et al., Wearable humidity sensor based on porous graphene network for res‑ piration monitoring. Biosens. Bioelectron. **116** , 123–129 (2018). https:// doi. org/ 10. 1016/j. bios. 2018. 05. 038 

52. E. Comini, Metal oxide nanowire chemical sensors: innova‑ tion and quality of life. Mater. Today **19** (10), 559–567 (2016). https:// doi. org/ 10. 1016/j. mattod. 2016. 05. 016 

53. S.H. Wu, P.H. Liu, Y. Zhang, H.N. Zhang, X.H. Qin, Flexible and conductive nanofiber‑structured single yarn sensor for smart wearable devices. Sens. Actuat. B Chem. **252** , 697–705 (2017). https:// doi. org/ 10. 1016/j. snb. 2017. 06. 062 

54. W. Li, R. Chen, W. Qi, L. Cai, Y. Sun et al., Reduced gra‑ phene oxide/mesoporous ZnO nss hybrid fibers for flexible, stretchable, twisted, and wearable  NO2 E‑textile gas sen‑ sor. ACS Sens. **4** (10), 2809–2818 (2019). https:// doi. org/ 10. 1021/ acsse nsors. 9b015 09 

55. R. Singh, E. Singh, H.S. Nalwa, Inkjet printed nanomate‑ rial based flexible radio frequency identification (RFID) tag sensors for the internet of nano things. RSC Adv. **7** (77), 48597–48630 (2017). https:// doi. org/ 10. 1039/ c7ra0 7191d 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 35 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

56. E. Abad, S. Zampolli, S. Marco, A. Scorzoni, B. Mazzolai et al., Flexible tag microlab development: gas sensors inte‑ gration in RFID flexible tags for food logistic. Sens. Actuat. B Chem. **127** (1), 2–7 (2007). https:// doi. org/ 10. 1016/j. snb. 2007. 07. 007 

57. S. Shrestha, M. Balachandran, M. Agarwal, V.V. Phoha, K. Varahramyan, A chipless RFID sensor system for cyber centric monitoring applications. IEEE Trans. Microw. Theory Tech. **57** (5), 1303–1309 (2009). https:// doi. org/ 10. 1109/ Tmtt. 2009. 20172 98 

58. R. Vyas, V. Lakafosis, H. Lee, G. Shaker, L. Yang et al., Inkjet printed, self powered, wireless sensors for environ‑ mental, gas, and authentication‑based sensing. IEEE Sens. J. **11** (12), 3139–3152 (2011). https:// doi. org/ 10. 1109/ Jsen. 2011. 21669 96 

59. J.S. Lee, J. Oh, J. Jun, J. Jang, Wireless hydrogen smart sensor based on Pt/graphene‑immobilized radio‑frequency identification tag. ACS Nano **9** (8), 7783–7790 (2015). https:// doi. org/ 10. 1021/ acsna no. 5b020 24 

60. S. Patel, H. Park, P. Bonato, L. Chan, M. Rodgers, A review of wearable sensors and systems with application in reha‑ bilitation. J. NeuroEng. Rehabil. **9** , 21 (2012). https:// doi. org/ 10. 1186/ 1743‑ 0003‑9‑ 21 

61. T. Wang, Y.L. Guo, P.B. Wan, H. Zhang, X.D. Chen et al., Flexible transparent electronic gas sensors. Small **12** (28), 3748–3756 (2016). https:// doi. org/ 10. 1002/ smll. 20160 1049 

62. H.Y. Li, C.S. Lee, D.H. Kim, J.H. Lee, Flexible room‑ temperature  NH3 sensor for ultrasensitive, selective, and humidity‑independent gas detection. ACS Appl. Mater. Interfaces **10** (33), 27858–27867 (2018). https:// doi. org/ 10. 1021/ acsami. 8b091 69 

63. Y.S. Xu, L.L. Zheng, C. Yang, W. Zheng, X.H. Liu et al., Oxygen vacancies enabled porous  SnO2 thin films for highly sensitive detection of triethylamine at room tempera‑ ture. ACS Appl. Mater. Interfaces **12** (18), 20704–20713 (2020). https:// doi. org/ 10. 1021/ acsami. 0c043 98 

64. K. Rui, X. Wang, M. Du, Y. Zhang, Q. Wang et al., Dual‑ function metal‑organic framework‑based wearable fibers for gas probing and energy storage. ACS Appl. Mater. Inter‑ faces **10** (3), 2837–2842 (2018). https:// doi. org/ 10. 1021/ acsami. 7b167 61 

65. R. You, D.D. Han, F. Liu, Y.L. Zhang, G. Lu, Fabrication of flexible room‑temperature  NO2 sensors by direct laser writ‑ ing of  In2O3 and graphene oxide composites. Sens. Actuat. B Chem. **277** , 114–120 (2018). https:// doi. org/ 10. 1016/j. snb. 2018. 07. 179 

66. C. Han, X. Li, Y. Liu, Y. Tang, M. Liu et al., Flexible all‑inorganic room‑temperature chemiresistors based on fibrous ceramic substrate and visible‑light‑powered semi‑ conductor sensing layer. Adv. Sci. **8** (23), 2102471 (2021). https:// doi. org/ 10. 1002/ advs. 20210 2471 

67. B. Wang, A. Thukral, Z. Xie, L. Liu, X. Zhang et al., Flex‑ ible and stretchable metal oxide nanofiber networks for mul‑ timodal and monolithically integrated wearable electronics. Nat. Commun. **11** , 2405 (2020). https:// doi. org/ 10. 1038/ s41467‑ 020‑ 16268‑8 

68. C. Hua, Y. Shang, Y. Wang, J. Xu, Y. Zhang, A flexible gas sensor based on single‑walled carbon nanotube‑Fe2O3 com‑ posite film. Appl. Surf. Sci. **405** , 405–411 (2017). https:// doi. org/ 10. 1016/j. apsusc. 2017. 01. 301 

69. M. Alvarado, E. Navarrete, A. Romero, J.L. Ramirez, E. Llobet, Flexible gas sensors employing octahedral indium oxide films. Sensors **18** (4), 999 (2018). https:// doi. org/ 10. 3390/ s1804 0999 

70. X. Geng, C. Zhang, Y. Luo, M. Debliquy, Flexible  NO2 gas sensors based on sheet‑like hierarchical  ZnO1‑X coatings deposited on polypropylene papers by suspension flame spraying. J. Taiwan Inst. Chem. Eng. **75** , 280–286 (2017). https:// doi. org/ 10. 1016/j. jtice. 2017. 03. 021 

71. K.K. Sadasivuni, D. Ponnamma, H.U. Ko, H.C. Kim, L. Zhai et al., Flexible  NO2 sensors from renewable cellulose nanocrystals/iron oxide composites. Sens. Actuat. B Chem. **233** , 633–638 (2016). https:// doi. org/ 10. 1016/j. snb. 2016. 04. 134 

72. U. Yaqoob, A.S.M.I. Uddin, G.S. Chung, A high‑performance flexible  NO2 sensor based on  WO3 NPs decorated on MWC‑ NTs and RGO hybrids on PI/PET substrates. Sens. Actuat. B Chem. **224** , 738–746 (2016). https:// doi. org/ 10. 1016/j. snb. 2015. 10. 088 

73. U. Yacioob, P. Duy‑Thach, A.S.M.I. Uddin, G.S. Chung, Highly flexible room temperature  NO2 sensor based on MWCNTs‑WO3 nanoparticles hybrid on a PET substrate. Sens. Actuat. B Chem. **221** , 760–768 (2015). https:// doi. org/ 10. 1016/j. snb. 2015. 06. 137 

74. S.J. Choi, H.J. Choi, W.T. Koo, D. Huh, H. Lee et al., Metal‑ organic framework‑templated PdO‑Co3O4 nanocubes func‑ tionalized by SWCNTs: improved  NO2 reaction kinetics on flexible heating film. ACS Appl. Mater. Interfaces **9** (46), 40593–40603 (2017). https:// doi. org/ 10. 1021/ acsami. 7b113 17 

75. S. Knobelspies, B. Bierer, A. Daus, A. Takabayashi, G.A. Salvatore et al., Photo‑induced room‑temperature gas sensing with a‑IGZO based thin‑film transistors fabricated on flex‑ ible plastic foil. Sensors **18** (2), 358 (2018). https:// doi. org/ 10. 3390/ s1802 0358 

76. V. Annapureddy, Y. Kim, G.T. Hwang, H.W. Jang, S.D. Kim et al., Room‑temperature solid‑state grown  WO3‑delta film on plastic substrate for extremely sensitive flexible  NO2 gas sensors. Adv. Mater. Interfaces **5** (1), 1700811 (2018). https:// doi. org/ 10. 1002/ admi. 20170 0811 

77. G.Y. Lu, J. Xu, J.B. Sun, Y.S. Yu, Y.Q. Zhang et al., UV‑ enhanced room temperature  NO2 sensor using ZnO nanorods modified with  SnO2 nanoparticles. Sens. Actuat. B Chem. **162** (1), 82–88 (2012). https:// doi. org/ 10. 1016/j. snb. 2011. 12. 039 

78. X.X. Wang, H.Y. Li, X. Guo, Flexible and transparent sensors for ultra‑low  NO2 detection at room temperature under visible light illumination. J. Mater. Chem. A **8** (29), 14482–14490 (2020). https:// doi. org/ 10. 1039/ d0ta0 2934c 

79. S. Li, Y. Diao, Z. Yang, J. He, J. Wang et al., Enhanced room temperature gas sensor based on Au‑loaded mesoporous 

1 3 

**206** Page 36 of 42 

Nano‑Micro Lett. (2022) 14:206 

   - In2O3 nanospheres@polyaniline core‑shell nanohybrid assembled on flexible PET substrate for  NH3 detection. Sens. Actuat. B Chem. **276** , 526–533 (2018). https:// doi. org/ 10. 1016/j. snb. 2018. 08. 120 

80. T. Huang, Z. Lou, S. Chen, R. Li, K. Jiang et al., Fabrica‑ tion of rigid and flexible  SrGe4O9 nanotube‑based sensors for room‑temperature ammonia detection. Nano Res. **11** (1), 431–439 (2018). https:// doi. org/ 10. 1007/ s12274‑ 017‑ 1650‑z 

81. D.K. Bandgar, S.T. Navale, Y.H. Navale, S.M. Ingole, F.J. Stadler et al., Flexible camphor sulfonic acid‑doped PAni/ α‑Fe2O3 nanocomposite films and their room temperature ammonia sensing activity. Mater. Chem. Phys. **189** , 191–197 (2017). https:// doi. org/ 10. 1016/j. match emphys. 2016. 12. 050 

82. B. Sakthivel, L. Manjakkal, G. Nammalvar, High perfor‑ mance CuO nanorectangles‑based room temperature flexible NH3 sensor. IEEE Sens. J. **17** (20), 6529–6536 (2017). https:// doi. org/ 10. 1109/ jsen. 2017. 27493 34 

83. C. Liu, H. Tai, P. Zhang, Z. Yuan, X. Du et al., A high‑per‑ formance flexible gas sensor based on self‑assembled PANI‑ CeO2 nanocomposite thin film for trace‑level  NH3 detection at room temperature. Sens. Actuat. B Chem. **261** , 587–597 (2018). https:// doi. org/ 10. 1016/j. snb. 2017. 12. 022 

84. R.D. Alharthy, A. Saleh, A novel trace‑level ammonia gas sensing based on flexible PAni‑CoFe2O4 nanocomposite film at room temperature. Polymers **13** (18), 3077 (2021). https:// doi. org/ 10. 3390/ polym 13183 077 

85. C. Zhu, U. Cakmak, O. Sheikhnejad, X. Cheng, X. Zhang et al., One step synthesis of PANI/Fe2O3 nanocomposites and flexible film for enhanced  NH3 sensing performance at room temperature. Nanotechnology **30** (25), 255502 (2019). https:// doi. org/ 10. 1088/ 1361‑ 6528/ ab076e 

86. S. Bai, Y. Tian, M. Cui, J. Sun, Y. Tian et al., Polyaniline@ SnO2 heterojunction loading on flexible PET thin film for detection of  NH3 at room temperature. Sens. Actuat. B Chem. **226** , 540–547 (2016). https:// doi. org/ 10. 1016/j. snb. 2015. 12. 007 

87. S. Li, P. Lin, L. Zhao, C. Wang, D. Liu et al., The room tem‑ perature gas sensor based on polyaniline@flower‑like  WO3 nanocomposites and flexible PET substrate for  NH3 detection. Sens. Actuat. B Chem. **259** , 505–513 (2018). https:// doi. org/ 10. 1016/j. snb. 2017. 11. 081 

88. R. Li, K. Jiang, S. Chen, Z. Lou, T. Huang et al.,  SnO2/SnS2 nanotubes for flexible room‑temperature  NH3 gas sensors. RSC Adv. **7** (83), 52503–52509 (2017). https:// doi. org/ 10. 1039/ c7ra1 0537a 

89. D.K. Bandgar, S.T. Navale, M. Naushad, R.S. Mane, F.J. Stadler et al., Ultra‑sensitive polyaniline‑iron oxide nano‑ composite room temperature flexible ammonia sensor. RSC Adv. **5** (84), 68964–68971 (2015). https:// doi. org/ 10. 1039/ c5ra1 1512d 

90. W.L. Ong, C. Zhang, G.W. Ho, Ammonia plasma modifi‑ cation towards a rapid and low temperature approach for tuning electrical conductivity of ZnO nanowires on flexible substrates. Nanoscale **3** (10), 4206–4214 (2011). https:// doi. org/ 10. 1039/ c1nr1 0527b 

91. T.R. Brauns, D.T. Phan, G.S. Chung, Effect of Ga‑modified layer on flexible hydrogen sensor using ZnO nanorods deco‑ rated by Pd catalysts. Sens. Actuat. B Chem. **193** , 869–876 (2014). https:// doi. org/ 10. 1016/j. snb. 2013. 08. 049 

92. S.M. Mohammad, Z. Hassan, R.A. Talib, N.M. Ahmed, M.A. Al‑Azawi et al., Fabrication of a highly flexible low‑cost  H2 gas sensor using ZnO nanorods grown on an ultra‑thin nylon substrate. J. Mater. Sci. Mater. Electron. **27** (9), 9461–9469 (2016). https:// doi. org/ 10. 1007/ s10854‑ 016‑ 4993‑4 

93. T.R. Rashid, D.T. Phan, G.S. Chung, A flexible hydrogen sensor based on Pd nanoparticles decorated ZnO nanorods grown on polyimide tape. Sens. Actuat. B Chem. **185** , 777– 784 (2013). https:// doi. org/ 10. 1016/j. snb. 2013. 01. 015 

94. D. Punetha, M. Kar, S.K. Pandey, A new type low‑cost, flex‑ ible and wearable tertiary nanocomposite sensor for room temperature hydrogen gas sensing. Sci. Rep. **10** (1), 2151 (2020). https:// doi. org/ 10. 1038/ s41598‑ 020‑ 58965‑w 

95. W. Hittini, A.F. Abu‑Hani, N. Reddy, S.T. Mahmoud, Cel‑ lulose‑copper oxide hybrid nanocomposites membranes for H2S gas detection at low temperatures. Sci. Rep. **10** (1), 2940 (2020). https:// doi. org/ 10. 1038/ s41598‑ 020‑ 60069‑4 

96. A.F.S. Abu‑Hani, F. Awwad, Y.E. Greish, A.I. Ayesh, S.T. Mahmoud, Design, fabrication, and characterization of low‑ power gas sensors based on organic‑inorganic nano‑com‑ posite. Org. Electron. **42** , 284–292 (2017). https:// doi. org/ 10. 1016/j. orgel. 2016. 12. 050 

97. F.I.M. Ali, F. Awwad, Y.E. Greish, A.F.S. Abu‑Hani, S.T. Mahmoud, Fabrication of low temperature and fast response H2S gas sensor based on organic‑metal oxide hybrid nano‑ composite membrane. Org. Electron. **76** , 105486 (2020). https:// doi. org/ 10. 1016/j. orgel. 2019. 105486 

98. D.Z. Zhang, Z.L. Wu, X.Q. Zong, Flexible and highly sensi‑ tive  H2S gas sensor based on in‑situ polymerized  SnO2/rGO/ PANI ternary nanocomposite with application in halitosis diagnosis. Sens. Actuat. B Chem. **289** , 32–41 (2019). https:// doi. org/ 10. 1016/j. snb. 2019. 03. 055 

99. A.S.M.I. Uddin, G.S. Chung, Effects of Ag nanoparticles decorated on ZnO nanorods under visible light illumina‑ tion on flexible acetylene gas sensing properties. J. Elec‑ troceram. **40** (1), 42–49 (2018). https:// doi. org/ 10. 1007/ s10832‑ 017‑ 0096‑8 

100. Z. Gao, Z. Lou, S. Chen, L. Li, K. Jiang et al., Fiber gas sensor‑integrated smart face mask for room‑temperature dis‑ tinguishing of target gases. Nano Res. **11** (1), 511–519 (2018). https:// doi. org/ 10. 1007/ s12274‑ 017‑ 1661‑9 

101. P. Krcmar, I. Kuritka, J. Maslik, P. Urbanek, P. Bazant et al., Fully inkjet‑printed CuO sensor on flexible polymer substrate for alcohol vapours and humidity sensing at room tempera‑ ture. Sensors **19** (14), 3068 (2019). https:// doi. org/ 10. 3390/ s1914 3068 

102. Z.Q. Zheng, J.D. Yao, B. Wang, G.W. Yang, Light‑control‑ ling, flexible and transparent ethanol gas sensor based on ZnO nanoparticles for wearable devices. Sci. Rep. **5** , 11070 (2015). https:// doi. org/ 10. 1038/ srep1 1070 

103. M. Seetha, P. Meena, D. Mangalaraj, Y. Masuda, K. Sen‑ thil, Synthesis of indium oxide cubic crystals by modified 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 37 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

   - hydrothermal route for application in room temperature flexible ethanol sensors. Mater. Chem. Phys. **133** (1), 47–54 (2012). https:// doi. org/ 10. 1016/j. match emphys. 2011. 12. 034 

104. D.K. Subbiah, G.K. Mani, K.J. Babu, A. Das, J.B.B. Rayap‑ pan, Nanostructured ZnO on cotton fabrics‑a novel flexible gas sensor & UV filter. J. Clean Prod. **194** , 372–382 (2018). https:// doi. org/ 10. 1016/j. jclep ro. 2018. 05. 110 

105. Y.K. Jo, S.Y. Jeong, Y.K. Moon, Y.M. Jo, J.W. Yoon et al., Exclusive and ultrasensitive detection of formaldehyde at room temperature using a flexible and monolithic chemire‑ sistive sensor. Nat. Commun. **12** , 4955 (2021). https:// doi. org/ 10. 1038/ s41467‑ 021‑ 25290‑3 

106. D.Z. Zhang, Z.L. Wu, X.Q. Zong, Metal‑organic frameworks‑ derived zinc oxide nanopolyhedra/S, N: graphene quantum dots/polyaniline ternary nanohybrid for high‑performance acetone sensing. Sens. Actuat. B Chem. **288** , 232–242 (2019). https:// doi. org/ 10. 1016/j. snb. 2019. 02. 093 

107. G. Kiriakidis, K. Moschovis, I. Kortidis, R. Skarvelakis, Highly sensitive  InOx ozone sensing films on flexible sub‑ strates. J. Sens. **2009** , 727893 (2009). https:// doi. org/ 10. 1155/ 2009/ 727893 

108. T.M. Perfecto, C.A. Zito, T. Mazon, D.P. Volanti, Flexible room‑temperature volatile organic compound sensors based on reduced graphene oxide‑WO3 center dot 0.33H2O nano‑ needles. J. Mater. Chem. C **6** (11), 2822–2829 (2018). https:// doi. org/ 10. 1039/ c8tc0 0324f 

109. P.M. Perillo, D.F. Rodriguez, Low temperature trimethyl‑ amine flexible gas sensor based on  TiO2 membrane nano‑ tubes. J. Alloy. Compd. **657** , 765–769 (2016). https:// doi. org/ 10. 1016/j. jallc om. 2015. 10. 167 

110. L. Quan, J.H. Sun, S.L. Bai, R.X. Luo, D.Q. Li et al., A flexi‑ ble sensor based on polyaniline hybrid using ZnO as template and sensing properties to triethylamine at room temperature. Appl. Surf. Sci. **399** , 583–591 (2017). https:// doi. org/ 10. 1016/j. apsusc. 2016. 12. 133 

111. S.L. Bai, Y.H. Zhao, J.H. Sun, Z.F. Tong, R.X. Luo et al., Preparation of conducting films based on alpha‑MoO3/PANI hybrids and their sensing properties to triethylamine at room temperature. Sens. Actuat. B Chem. **239** , 131–138 (2017). https:// doi. org/ 10. 1016/j. snb. 2016. 07. 174 

112. M. Asad, M.H. Sheikhi, Highly sensitive wireless  H2S gas sensors at room temperature based on CuO‑SWCNT hybrid nanomaterials. Sens. Actuat. B Chem. **231** , 474–483 (2016). https:// doi. org/ 10. 1016/j. snb. 2016. 03. 021 

113. J. Kroutil, A. Laposa, J. Voves, M. Davydova, J. Nahlik et al., Performance evaluation of low‑cost flexible gas sensor array with nanocomposite polyaniline films. IEEE Sens. J. **18** (9), 3759–3766 (2018). https:// doi. org/ 10. 1109/ Jsen. 2018. 28114 61 

114. Y. Yang, W. Gao, Wearable and flexible electronics for continuous molecular monitoring. Chem. Soc. Rev. **48** (6), 1465–1491 (2019). https:// doi. org/ 10. 1039/ c7cs0 0730b 

115. H.J. Choi, J.H. Chung, J.W. Yoon, J.H. Lee, Highly selec‑ tive, sensitive, and rapidly responding acetone sensor using ferroelectric ε‑WO3 spheres doped with Nb for monitoring 

ketogenic diet efficiency. Sens. Actuat. B Chem. **338** , 129823 (2021). https:// doi. org/ 10. 1016/j. snb. 2021. 129823 

116. V. Ruzsanyi, M.P. Kalapos, Breath acetone as a potential marker in clinical practice. J. Breath Res. **11** (2), 024002 (2017). https:// doi. org/ 10. 1088/ 1752‑ 7163/ aa66d3 

117. M.V. Nikolic, V. Milovanovic, Z.Z. Vasiljevic, Z. Stamen‑ kovic, Semiconductor gas sensors: materials, technology, design, and application. Sensors **20** (22), 6694 (2020). https:// doi. org/ 10. 3390/ s2022 6694 

118. N. Joshi, T. Hayasaka, Y.M. Liu, H.L. Liu, O.N. Oliveira et al., A review on chemiresistive room temperature gas sensors based on metal oxide nanostructures, gra‑ phene and 2D transition metal dichalcogenides. Micro‑ chim. Acta **185** (4), 213 (2018). https:// doi. org/ 10. 1007/ s00604‑ 018‑ 2750‑5 

119. I. Fratoddi, I. Venditti, C. Cametti, M.V. Russo, Chemire‑ sistive polyaniline‑based gas sensors: a mini review. Sens. Actuat. B Chem. **220** , 534–548 (2015). https:// doi. org/ 10. 1016/j. snb. 2015. 05. 107 

120. J. Zhang, X.H. Liu, G. Neri, N. Pinna, Nanostructured mate‑ rials for room‑temperature gas sensors. Adv. Mater. **28** (5), 795–831 (2016). https:// doi. org/ 10. 1002/ adma. 20150 3825 

121. R.S. Andre, R.C. Sanfelice, A. Pavinatto, L.H.C. Mattoso, D.S. Correa, Hybrid nanomaterials designed for volatile organic compounds sensors: a review. Mater. Des. **156** , 154– 166 (2018). https:// doi. org/ 10. 1016/j. matdes. 2018. 06. 041 

122. L.Y. Zhu, K.P. Yuan, J.G. Yang, H.P. Ma, T. Wang et al., Fab‑ rication of heterostructured p‑CuO/n‑SnO2 core‑shell nanow‑ ires for enhanced sensitive and selective formaldehyde detec‑ tion. Sens. Actuat. B Chem. **290** , 233–241 (2019). https:// doi. org/ 10. 1016/j. snb. 2019. 03. 092 

123. A. Dey, Semiconductor metal oxide gas sensors: a review. Mater. Sci. Eng. B Adv. **229** , 206–217 (2018). https:// doi. org/ 10. 1016/j. mseb. 2017. 12. 036 

124. H.J. Kim, J.H. Lee, Highly sensitive and selective gas sensors using p‑type oxide semiconductors: overview. Sens. Actuat. B Chem. **192** , 607–627 (2014). https:// doi. org/ 10. 1016/j. snb. 2013. 11. 005 

125. D.R. Miller, S.A. Akbar, P.A. Morris, Nanoscale metal oxide‑ based heterojunctions for gas sensing: a review. Sens. Actuat. B Chem. **204** , 250–272 (2014). https:// doi. org/ 10. 1016/j. snb. 2014. 07. 074 

126. K. Wetchakun, T. Samerjai, N. Tamaekong, C. Liewhiran, C. Siriwong et al., Semiconducting metal oxides as sensors for environmentally hazardous gases. Sens. Actuat. B Chem. **160** (1), 580–591 (2011). https:// doi. org/ 10. 1016/j. snb. 2011. 08. 032 

127. L.Y. Zhu, K.P. Yuan, J.H. Yang, C.Z. Hang, H.P. Ma et al., Hierarchical highly ordered  SnO2 nanobowl branched ZnO nanowires for ultrasensitive and selective hydrogen sulfide gas sensing. Microsyst. Nanoeng. **6** (1), 30 (2020). https:// doi. org/ 10. 1038/ s41378‑ 020‑ 0142‑6 

128. J.H. Yang, K.P. Yuan, L.Y. Zhu, C.Z. Hang, X.X. Li et al., Facile synthesis of alpha‑Fe2O3/ZnO core‑shell nanowires for enhanced  H2S sensing. Sens. Actuat. B Chem. **307** , 127617 (2020). https:// doi. org/ 10. 1016/j. snb. 2019. 127617 

1 3 

**206** Page 38 of 42 

Nano‑Micro Lett. (2022) 14:206 

129. X.R. Zhou, X.W. Cheng, Y.H. Zhu, A.A. Elzatahry, A. Alghamdi et al., Ordered porous metal oxide semiconduc‑ tors for gas sensing. Chin. Chem. Lett. **29** (3), 405–416 (2018). https:// doi. org/ 10. 1016/j. cclet. 2017. 06. 021 

130. R.S. Devan, R.A. Patil, J.H. Lin, Y.R. Ma, One‑dimensional metal‑oxide nanostructures: recent developments in synthe‑ sis, characterization, and applications. Adv. Funct. Mater. **22** (16), 3326–3370 (2012). https:// doi. org/ 10. 1002/ adfm. 20120 1008 

131. A. Mirzaei, S.G. Leonardi, G. Neri, Detection of hazardous volatile organic compounds (VOCs) by metal oxide nano‑ structures‑based gas sensors: a review. Ceram. Int. **42** (14), 15119–15141 (2016). https:// doi. org/ 10. 1016/j. ceram int. 2016. 06. 145 

132. L. Zhu, W. Zeng, Room‑temperature gas sensing of ZnO‑ based gas sensor: a review. Sens. Actuat. A Phys. **267** , 242–261 (2017). https:// doi. org/ 10. 1016/j. sna. 2017. 10. 021 

133. E. Llobet, Gas sensors using carbon nanomaterials: a review. Sens. Actuat. B Chem. **179** , 32–45 (2013). https:// doi. org/ 10. 1016/j. snb. 2012. 11. 014 

134. J.H. Xu, Y.Z. Wang, S.S. Hu, Nanocomposites of graphene and graphene oxides: synthesis, molecular functionalization and application in electrochemical sensors and biosensors. A review. Microchim. Acta **184** (1), 1–44 (2017). https:// doi. org/ 10. 1007/ s00604‑ 016‑ 2007‑0 

135. S.X. Yang, C.B. Jiang, S.H. Wei, Gas sensing in 2D materi‑ als. Appl. Phys. Rev. **4** (2), 021304 (2017). https:// doi. org/ 10. 1063/1. 49833 10 

136. H. Zhang, J.C. Feng, T. Fei, S. Liu, T. Zhang,  SnO2 nan‑ oparticles‑reduced graphene oxide nanocomposites for NO2 sensing at low operating temperature. Sens. Actuat. B Chem. **190** , 472–478 (2014). https:// doi. org/ 10. 1016/j. snb. 2013. 08. 067 

137. D.Z. Zhang, H.Y. Chang, P. Li, R.H. Liu, Q.Z. Xue, Fab‑ rication and characterization of an ultrasensitive humidity sensor based on metal oxide/graphene hybrid nanocompos‑ ite. Sens. Actuat. B Chem. **225** , 233–240 (2016). https:// doi. org/ 10. 1016/j. snb. 2015. 11. 024 

138. S. Liu, B. Yu, H. Zhang, T. Fei, T. Zhang, Enhancing  NO2 gas sensing performances at room temperature based on reduced graphene oxide‑ZnO nanoparticles hybrids. Sens. Actuat. B Chem. **202** , 272–278 (2014). https:// doi. org/ 10. 1016/j. snb. 2014. 05. 086 

139. L.L. Wang, H. Huang, S.H. Xiao, D.P. Cai, Y. Liu et al., Enhanced sensitivity and stability of room‑temperature NH3 sensors using core‑shell  CeO2 nanoparticles@cross‑ linked PANI with p‑n heterojunctions. ACS Appl. Mater. Interfaces **6** (16), 14131–14140 (2014). https:// doi. org/ 10. 1021/ am503 286h 

140. S. Mallakpour, E. Khadem, Carbon nanotube‑metal oxide nanocomposites: fabrication, properties and applications. Chem. Eng. J. **302** , 344–367 (2016). https:// doi. org/ 10. 1016/j. cej. 2016. 05. 038 

141. X.H. Liu, W. Zheng, R. Kumar, M. Kumar, J. Zhang, Con‑ ducting polymer‑based nanostructures for gas sensors. 

Coord. Chem. Rev. **462** , 214517 (2022). https:// doi. org/ 10. 1016/j. ccr. 2022. 214517 

142. Y.Y. Jian, W.W. Hu, Z.H. Zhao, P.F. Cheng, H. Haick et al., Gas sensors based on chemi‑resistive hybrid functional nanomaterials. Nano‑Micro Lett. **12** , 71 (2020). https:// doi. org/ 10. 1007/ s40820‑ 020‑ 0407‑5 

143. T. Pandhi, A. Chandnani, H. Subbaraman, D. Estrada, A review of inkjet printed graphene and carbon nanotubes based gas sensors. Sensors **20** (19), 5642 (2020). https:// doi. org/ 10. 3390/ s2019 5642 

144. S. Park, M. Vosguerichian, Z.A. Bao, A review of fabrica‑ tion and applications of carbon nanotube film‑based flexible electronics. Nanoscale **5** (5), 1727–1752 (2013). https:// doi. org/ 10. 1039/ c3nr3 3560g 

145. D.D. Dong, J.W. Zhang, J. Tang, J. Wang, K. Yang et al., Fabrication of conductive materials based on natural poly‑ mers and their application in flexible sensors. Acta Polym. Sin. **51** (8), 864–879 (2020). https:// doi. org/ 10. 11777/j. issn1 000‑ 3304. 2020. 20114 

146. R. Kumar, N. Goel, M. Hojamberdiev, M. Kumar, Tran‑ sition metal dichalcogenides‑based flexible gas sensors. Sens. Actuat. A Phys. **303** , 111875 (2020). https:// doi. org/ 10. 1016/j. sna. 2020. 111875 

147. K.J. Choi, H.W. Jang, One‑dimensional oxide nanostruc‑ tures as gas‑sensing materials: review and issues. Sensors **10** (4), 4083–4099 (2010). https:// doi. org/ 10. 3390/ s1004 04083 

148. Z.J. Li, H. Li, Z.L. Wu, M.K. Wang, J.T. Luo et al., Advances in designs and mechanisms of semiconducting metal oxide nanostructures for high‑precision gas sensors operated at room temperature. Mater. Horizons **6** (3), 470–506 (2019). https:// doi. org/ 10. 1039/ c8mh0 1365a 

149. B.K.S. Reddy, P.H. Borse, Review‑recent material advances and their mechanistic approaches for room temperature chemiresistive gas sensors. J. Electrochem. Soc. **168** (5), 057521 (2021). https:// doi. org/ 10. 1149/ 1945‑ 7111/ abf4ea 

150. S. Das, S. Mojumder, D. Saha, M. Pal, Influence of major parameters on the sensing mechanism of semiconductor metal oxide based chemiresistive gas sensors: a review focused on personalized healthcare. Sens. Actuat. B Chem. **352** , 131066 (2022). https:// doi. org/ 10. 1016/j. snb. 2021. 131066 

151. H.C. Ji, W. Zeng, Y.Q. Li, Gas sensing mechanisms of metal oxide semiconductors: a focus review. Nanoscale **11** (47), 22664–22684 (2019). https:// doi. org/ 10. 1039/ c9nr0 7699a 

152. L.Y. Gai, R.P. Lai, X.H. Dong, X. Wu, Q.T. Luan et al., Recent advances in ethanol gas sensors based on metal oxide semiconductor heterojunctions. Rare Met. **41** (6), 1818–1842 (2022). https:// doi. org/ 10. 1007/ s12598‑ 021‑ 01937‑4 

153. T. Sahm, A. Gurlo, N. Barsan, U. Weimar, Basics of oxygen and  SnO2 interaction; work function change and conductiv‑ ity measurements. Sens. Actuat. B Chem. **118** (1–2), 78–83 (2006). https:// doi. org/ 10. 1016/j. snb. 2006. 04. 004 

154. A. Gurlo, Interplay between  O2 and  SnO2: oxygen iono‑ sorption and spectroscopic evidence for adsorbed oxygen. ChemPhysChem **7** (10), 2041–2052 (2006). https:// doi. org/ 10. 1002/ cphc. 20060 0292 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

Page 39 of 42 **206** 

Nano‑Micro Lett. (2022) 14:206 

155. Y.V. Kaneti, J. Yue, X.C. Jiang, A.B. Yu, Controllable syn‑ thesis of ZnO nanoflakes with exposed (1010) for enhanced gas sensing performance. J. Phys. Chem. C **117** (25), 13153–13162 (2013). https:// doi. org/ 10. 1021/ jp404 329q 

156. Z.J. Li, Z.J. Lin, N.N. Wang, Y.W. Huang, J.Q. Wang et al., Facile synthesis of alpha‑Fe2O3 micro‑ellipsoids by sur‑ factant‑free hydrothermal method for sub‑ppm level  H2S detection. Mater. Des. **110** , 532–539 (2016). https:// doi. org/ 10. 1016/j. matdes. 2016. 08. 035 

157. J. Zhang, Z.Y. Qin, D.W. Zeng, C.S. Xie, Metal‑oxide‑sem‑ iconductor based gas sensors: screening, preparation, and integration. Phys. Chem. Chem. Phys. **19** (9), 6313–6329 (2017). https:// doi. org/ 10. 1039/ c6cp0 7799d 

158. P.T. Moseley, Progress in the development of semiconduct‑ ing metal oxide gas sensors: a review. Meas. Sci. Technol. **28** (8), 082001 (2017). https:// doi. org/ 10. 1088/ 1361‑ 6501/ aa7443 

159. D. Zappa, V. Galstyan, N. Kaur, H.M.M.M. Arachchige, O. Sisman et al., “Metal oxide‑based heterostructures for gas sensors”‑a review. Anal. Chim. Acta **1039** , 1–23 (2018). https:// doi. org/ 10. 1016/j. aca. 2018. 09. 020 

160. C.B. Jacobs, A.B. Maksov, E.S. Muckley, L. Collins, M. Mahjouri‑Samani et al., UV‑activated ZnO films on a flexible substrate for room temperature  O2 and  H2O sens‑ ing. Sci. Rep. **7** , 6053 (2017). https:// doi. org/ 10. 1038/ s41598‑ 017‑ 05265‑5 

161. M. Hubner, C.E. Simion, A. Tomescu‑Stanoiu, S. Pokhrel, N. Barsan et al., Influence of humidity on CO sensing with p‑type CuO thick film gas sensors. Sens. Actuat. B Chem. **153** (2), 347–353 (2011). https:// doi. org/ 10. 1016/j. snb. 2010. 10. 046 

162. Y.F. Luo, C. Zhang, B.B. Zheng, X. Geng, M. Debliquy, Hydrogen sensors based on noble metal doped metal‑oxide semiconductor: a review. Int. J. Hydrog. Energy **42** (31), 20386–20397 (2017). https:// doi. org/ 10. 1016/j. ijhyd ene. 2017. 06. 066 

163. J.H. Ma, Y. Ren, X.R. Zhou, L.L. Liu, Y.H. Zhu et al., Pt nanoparticles sensitized ordered mesoporous  WO3 semicon‑ ductor: gas sensing performance and mechanism study. Adv. Funct. Mater. **28** (6), 1705268 (2018). https:// doi. org/ 10. 1002/ adfm. 20170 5268 

164. L. Satyanarayana, K.M. Reddy, S.V. Manorama, Nanosized spinel  NiFe2O4: a novel material for the detection of lique‑ fied petroleum gas in air. Mater. Chem. Phys. **82** (1), 21–26 (2003). https:// doi. org/ 10. 1016/ S0254‑ 0584(03) 00170‑6 

165. M.S. Barbosa, P.H. Suman, J.J. Kim, H.L. Tuller, J.A. Varela et al., Gas sensor properties of Ag‑ and Pd‑decorated SnO micro‑disks to  NO2,  H2 and CO: catalyst enhanced sensor response and selectivity. Sens. Actuat. B Chem. **239** , 253– 261 (2017). https:// doi. org/ 10. 1016/j. snb. 2016. 07. 157 

166. H.S. Gu, Z. Wang, Y.M. Hu, Hydrogen gas sensors based on semiconductor oxide nanostructures. Sensors **12** (5), 5517–5550 (2012). https:// doi. org/ 10. 3390/ s1205 05517 

167. C. Liu, Q. Kuang, Z.X. Xie, L.S. Zheng, The effect of noble metal (Au, Pd and Pt) nanoparticles on the gas sensing performance of SnO2‑based sensors: a case study on the 

221 high‑index faceted SnO2 octahedra. CrystEngComm **17** (33), 6308–6313 (2015). https:// doi. org/ 10. 1039/ c5ce0 1162k 

168. A. Sutka, K.A. Gross, Spinel ferrite oxide semiconductor gas sensors. Sens. Actuat. B Chem. **222** , 95–105 (2016). https:// doi. org/ 10. 1016/j. snb. 2015. 08. 027 

169. N. Yamazoe, New approaches for improving semiconduc‑ tor gas sensors. Sens. Actuat. B Chem. **5** (1–4), 7–19 (1991). https:// doi. org/ 10. 1016/ 0925‑ 4005(91) 80213‑4 

170. P. Jaroenapibal, P. Boonma, N. Saksilaporn, M. Horprathum, V. Amornkitbamrung et al., Improved  NO2 sensing perfor‑ mance of electrospun  WO3 nanofibers with silver doping. Sens. Actuat. B Chem. **255** , 1831–1840 (2018). https:// doi. org/ 10. 1016/j. snb. 2017. 08. 199 

171. U.T. Nakate, R.N. Bulakhe, C.D. Lokhande, S.N. Kale, Au sensitized ZnO nanorods for enhanced liquefied petroleum gas sensing properties. Appl. Surf. Sci. **371** , 224–230 (2016). https:// doi. org/ 10. 1016/j. apsusc. 2016. 02. 196 

172. A. Liu, S.Y. Lv, L.J. Zhao, F.M. Liu, J. Wang et al., Room temperature flexible  NH3 sensor based on polyaniline coated Rh‑doped  SnO2 hollow nanotubes. Sens. Actuat. B Chem. **330** , 129313 (2021). https:// doi. org/ 10. 1016/j. snb. 2020. 129313 

173. E. Song, J.W. Choi, Conducting polyaniline nanowire and its applications in chemiresistive sensing. Nanomaterials **3** (3), 498–523 (2013). https:// doi. org/ 10. 3390/ nano3 030498 

174. H. Bai, G.Q. Shi, Gas sensors based on conducting polymers. Sensors **7** (3), 267–307 (2007). https:// doi. org/ 10. 3390/ s7030 267 

175. D.W. Hatchett, M. Josowicz, Composites of intrinsically conducting polymers as sensing nanomaterials. Chem. Rev. **108** (2), 746–769 (2008). https:// doi. org/ 10. 1021/ cr068 112h 

176. X.L. Huang, N.T. Hu, R.G. Gao, Y. Yu, Y.Y. Wang et al., Reduced graphene oxide‑polyaniline hybrid: preparation, characterization and its applications for ammonia gas sens‑ ing. J. Mater. Chem. **22** (42), 22488–22495 (2012). https:// doi. org/ 10. 1039/ c2jm3 4340a 

177. F.L. Meng, Z. Guo, X.J. Huang, Graphene‑based hybrids for chemiresistive gas sensors. TrAc Trend Anal. Chem. **68** , 37–47 (2015). https:// doi. org/ 10. 1016/j. trac. 2015. 02. 008 

178. J.N. Gavgani, A. Hasani, M. Nouri, M. Mahyari, A. Salehi, Highly sensitive and flexible ammonia sensor based on S and N co‑doped graphene quantum dots/polyaniline hybrid at room temperature. Sens. Actuat. B Chem. **229** , 239–248 (2016). https:// doi. org/ 10. 1016/j. snb. 2016. 01. 086 

179. J.H. Sun, X. Shu, Y.L. Tian, Z.F. Tong, S.L. Bai et al., Facile preparation of polypyrrole‑reduced graphene oxide hybrid for enhancing  NH3 sensing at room temperature. Sens. Actuat. B Chem. **241** , 658–664 (2017). https:// doi. org/ 10. 1016/j. snb. 2016. 10. 047 

180. Y. Yan, G.Q. Yang, J.L. Xu, M. Zhang, C.C. Kuo et al., Con‑ ducting polymer‑inorganic nanocomposite‑based gas sensors: a review. Sci. Technol. Adv. Mater. **21** (1), 768–786 (2020). https:// doi. org/ 10. 1080/ 14686 996. 2020. 18208 45 

1 3 

**206** Page 40 of 42 

Nano‑Micro Lett. (2022) 14:206 

181. Z.H. Zhao, J. Tian, Y.H. Sang, A. Cabot, H. Liu, Structure, synthesis, and applications of  TiO2 nanobelts. Adv. Mater. **27** (16), 2557–2582 (2015). https:// doi. org/ 10. 1002/ adma. 20140 5589 

182. C.M. Hangarter, N. Chartuprayoon, S.C. Hernandez, Y. Choa, N.V. Myung, Hybridized conducting polymer chemiresistive nano‑sensors. Nano Today **8** (1), 39–55 (2013). https:// doi. org/ 10. 1016/j. nantod. 2012. 12. 005 

183. Y.C. Wong, B.C. Ang, A.S.M.A. Haseeb, A.A. Baharuddin et al., Review‑conducting polymers as chemiresistive gas sensing materials: a review. J. Electrochem. Soc. **167** (1), 037503 (2019). https:// doi. org/ 10. 1149/2. 00320 03jes 

184. Z.Q. Wu, X.D. Chen, S.B. Zhu, Z.W. Zhou, Y. Yao et al., Enhanced sensitivity of ammonia sensor using graphene/ polyaniline nanocomposite. Sens. Actuat. B Chem. **178** , 485–493 (2013). https:// doi. org/ 10. 1016/j. snb. 2013. 01. 014 

185. S. Abdulla, T.L. Mathew, B. Pullithadathil, Highly sensitive, room temperature gas sensor based on polyaniline‑multi‑ walled carbon nanotubes (PANI/MWCNTs) nanocomposite for trace‑level ammonia detection. Sens. Actuat. B Chem. **221** , 1523–1534 (2015). https:// doi. org/ 10. 1016/j. snb. 2015. 08. 002 

186. A. Liu, C.L. Wang, X.L. Yang, F.M. Liu, S.Q. Li et al., Poly‑ aniline @ porous nanosphere  SnO2/Zn2SnO4 nanohybrid for selective room temperature flexible  NH3 sensor. Sens. Actuat. B Chem. **317** , 128218 (2020). https:// doi. org/ 10. 1016/j. snb. 2020. 128218 

187. Y.N. Liang, Z.X. Wu, Y.N. Wei, Q.L. Ding, M. Zilberman et al., Self‑healing, self‑adhesive and stable organohydrogel‑ based stretchable oxygen sensor with high performance at room temperature. Nano‑Micro Lett. **14** , 52 (2022). https:// doi. org/ 10. 1007/ s40820‑ 021‑ 00787‑0 

188. Y.Q. Lin, Z.X. Wu, C.W. Li, Q.L. Ding, K. Tao et al., Deformable, transparent, high‑performance, room‑tempera‑ ture oxygen sensors based on ion‑conductive, environment‑ tolerant, and green organohydrogels. Ecomat. (2022). https:// doi. org/ 10. 1002/ eom2. 12220 

189. J. Wu, Z.X. Wu, W.X. Huang, X. Yang, Y.N. Liang et al., Stretchable, stable, and room‑temperature gas sensors based on self‑healing and transparent organohydrogels. ACS Appl. Mater. Interfaces **12** (46), 52070–52081 (2020). https:// doi. org/ 10. 1021/ acsami. 0c176 69 

190. Y.M. Wei, H. Wang, Q.L. Ding, Z.X. Wu, H. Zhang et al., Hydrogel‑ and organohydrogel‑based stretchable, ultrasensi‑ tive, transparent, room‑temperature and real‑time  NO2 sen‑ sors and the mechanism. Mater. Horizons **9** (7), 1921–1934 (2022). https:// doi. org/ 10. 1039/ d2mh0 0284a 

191. Z.X. Wu, L.M. Rong, J.L. Yang, Y.M. Wei, K. Tao et al., Ion‑conductive hydrogel‑based stretchable, self‑healing, and transparent  NO2 sensor with high sensitivity and selectivity at room temperature. Small **17** (52), 2104997 (2021). https:// doi. org/ 10. 1002/ smll. 20210 4997 

192. J. Wu, Z.X. Wu, H.J. Ding, Y.M. Wei, W.X. Huang et al., Three‑dimensional graphene hydrogel decorated with  SnO2 for high‑performance  NO2 sensing with enhanced immunity 

to humidity. ACS Appl. Mater. Interfaces **12** (2), 2634–2643 (2020). https:// doi. org/ 10. 1021/ acsami. 9b180 98 

193. V. Schroeder, S. Savagatrup, M. He, S.B. Ling, T.M. Swa‑ ger, Carbon nanotube chemical sensors. Chem. Rev. **119** (1), 599–663 (2019). https:// doi. org/ 10. 1021/ acs. chemr ev. 8b003 40 

194. M. Meyyappan, Carbon nanotube‑based chemical sensors. Small **12** (16), 2118–2129 (2016). https:// doi. org/ 10. 1002/ smll. 20150 2555 

195. A. Goldoni, V. Alijani, L. Sangaletti, L. D’Arsie, Advanced promising routes of carbon/metal oxides hybrids in sensors: a review. Electrochim. Acta **266** , 139–150 (2018). https:// doi. org/ 10. 1016/j. elect acta. 2018. 01. 170 

196. S.G. Chatterjee, S. Chatterjee, A.K. Ray, A.K. Chakraborty, Graphene‑metal oxide nanohybrids for toxic gas sensor: a review. Sens. Actuat. B Chem. **221** , 1170–1181 (2015). https:// doi. org/ 10. 1016/j. snb. 2015. 07. 070 

197. F. Schutt, V. Postica, R. Adelung, O. Lupan, Single and networked ZnO‑CNT hybrid tetrapods for selective room‑ temperature high‑performance ammonia sensors. ACS Appl. Mater. Interfaces **9** (27), 23107–23118 (2017). https:// doi. org/ 10. 1021/ acsami. 7b037 02 

198. J.S. Lee, O.S. Kwon, D.H. Shin, J. Jang,  WO3 nanonodule‑ decorated hybrid carbon nanofibers for  NO2 gas sensor appli‑ cation. J. Mater. Chem. A **1** (32), 9099–9106 (2013). https:// doi. org/ 10. 1039/ c3ta1 1658a 

199. G. Chimowa, Z.P. Tshabalala, A.A. Akande, G. Bepete, B. Mwakikunga et al., Improving methane gas sensing proper‑ ties of multi‑walled carbon nanotubes by vanadium oxide filling. Sens. Actuat. B Chem. **247** , 11–18 (2017). https:// doi. org/ 10. 1016/j. snb. 2017. 02. 167 

200. Y. Seekaew, A. Wisitsoraat, D. Phokharatkul, C. Wongchoosuk, Room temperature toluene gas sensor based on  TiO2 nanoparticles decorated 3D graphene‑carbon nano‑ tube nanostructures. Sens. Actuat. B Chem. **279** , 69–78 (2019). https:// doi. org/ 10. 1016/j. snb. 2018. 09. 095 

201. Q.T.M. Nguyet, N.V. Duy, C.M. Hung, N.D. Hoa, V.N. Hieu, Ultrasensitive  NO2 gas sensors using hybrid heterojunctions of multi‑walled carbon nanotubes and on‑chip grown  SnO2 nanowires. Appl. Phys. Lett. **112** (15), 153110 (2018). https:// doi. org/ 10. 1063/1. 50238 51 

202. M.S. Choi, J.H. Bang, A. Mirzaei, H.G. Na, Y.J. Kwon et al., Dual sensitization of MWCNTs by co‑decoration with p‑ and n‑type metal oxide nanoparticles. Sens. Actuat. B Chem. **264** , 150–163 (2018). https:// doi. org/ 10. 1016/j. snb. 2018. 02. 179 

203. X. Liu, S.T. Cheng, H. Liu, S. Hu, D.Q. Zhang et al., A sur‑ vey on gas sensing technology. Sensors **12** (7), 9635–9665 (2012). https:// doi. org/ 10. 3390/ s1207 09635 

204. C.M. Lou, K. Wang, X.H. Liu, X.Y. Li, H. Wang et al., Het‑ erogeneous  Co3O4/carbon nanofibers for low temperature triethylamine detection: mechanistic insights by operando drifts and DFT. Adv. Mater. Interfaces **9** (1), 2101479 (2022). https:// doi. org/ 10. 1002/ admi. 20210 1479 

205. Y.V. Kaneti, J.L. Moriceau, M. Liu, Y. Yuan, Q. Zakaria et al., Hydrothermal synthesis of ternary alpha‑Fe2O3‑ZnO‑ Au nanocomposites with high gas‑sensing performance. 

© The authors 

https://doi.org/10.1007/s40820‑022‑00956‑9 

