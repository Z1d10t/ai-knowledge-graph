# Surface redox engineering of vacuum-deposited NiOx for top-performance perovskite solar cells and modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 208 |
| 作者 | Min-Yong Du, Shuai Zhao, Lian-Jie Duan, Yuexian Cao, Hui Wang, Youming Sun, Likun Wang, Xue-Jie Zhu et al. |
| DOI | 10.1016/j.joule.2022.06.026 |
| 源文件 | 044_Du_2022_Surface-redox-engineering-of-vacuum-deposited-Ni.pdf |

---
**ll** 

## Article 

Surface redox engineering of vacuumdeposited NiOx for top-performance perovskite solar cells and modules 



Minyong Du, Shuai Zhao, Lianjie Duan, ..., Yantao Shi, Kai Wang, Shengzhong (Frank) Liu 

wangkai@dicp.ac.cn (K.W.) szliu@dicp.ac.cn (S.L.) 

Highlights 

High-performance NiOx by largearea e-beam evaporation at room temperature 

Facile SRE for NiOx films to make the large-area slot-die-coated PSCs 

SRE mechanism is revealed by experiments and theoretical simulations 

SRE strategy improves the efficiency and stability of the solar cells 

We propose a surface redox engineering (SRE) for NiOx films, which is achieved by subjecting the films to an Ar-plasma-initiated oxidation process and a Brønstedacid-mediated reduction process. The multifunctional SRE can foster the formation of a stabilized surface state and increase the surface energy. The assembled rigid (flexible) PSCs delivered high PCEs of up to 23.4% (21.3%) with excellent stability. Furthermore, large-area (156 3 156 mm<sup>2</sup> ) submodules are designed and integrated to yield PCE as high as 18.6%. 

Du et al., Joule 6, 1931–1943 August 17, 2022 ª 2022 Elsevier Inc. https://doi.org/10.1016/j.joule.2022.06.026 



**ll** 

#### Article 

# Surface redox engineering of vacuum-deposited NiOx for top-performance perovskite solar cells and modules 

Minyong Du,<sup>1,3,6</sup> Shuai Zhao,<sup>2,6</sup> Lianjie Duan,<sup>1</sup> Yuexian Cao,<sup>1</sup> Hui Wang,<sup>1</sup> Youming Sun,<sup>1</sup> Likun Wang,<sup>1</sup> Xuejie Zhu,<sup>4</sup> Jiangshan Feng,<sup>4</sup> Lu Liu,<sup>1,3</sup> Xiao Jiang,<sup>1</sup> Qingshun Dong,<sup>5</sup> Yantao Shi,<sup>5</sup> Kai Wang,<sup>1,</sup> * and Shengzhong (Frank) Liu<sup>1,3,4,7,</sup> * 

##### SUMMARY 

It is arduous to prepare thin charge transport layers (CTLs) of only a few nanometers in thickness for meter-sized products, particularly for commonly used solution processes. Thus, it is desirable to take advantages of both solution-processed perovskites and vacuumdeposited CTLs. Herein, a surface redox engineering (SRE) is proposed for vacuum-deposited NiOx to make it match with the slot-die-coated perovskite films. Not only does it eliminate the dewetting problem of perovskite ink, but it also imparts enhanced electronic properties at buried interfaces. Consequently, high-performance PSCs are achieved with amazing stability and outstanding power conversion efficiencies of 23.4% and 21.3% for rigid and flexible devices, respectively. Furthermore, perovskite submodules of area 156 3 156 mm<sup>2</sup> are successfully assembled with a remarkable PCE of 18.6% along with excellent stability. The SRE provides a strategy to use the advantages of both vacuum-fabricated CTLs with wet-processed perovskites for the development of large-area perovskite modules. 

##### INTRODUCTION 

State-of-the-art perovskite solar cells (PSCs) have glaringly entered the huge photovoltaic arena representing the most promising solar technology. The rapidly increasing power conversion efficiency (PCE) has exceeded 25% in a decade,<sup>1</sup> enabling PSCs to rival silicon solar cells and accelerating the wave of commercialization. Unequivocally, inverted PSCs are potentially more valuable than their normal counterparts because the former, with easily mitigated hysteresis behavior and long-term durability, are more compatible with commercial development.<sup>2–5</sup> Recently, the certificated PCE of inverted PSCs has risen to 23.91% as reported by Sargent’s group,<sup>6</sup> which marginally lags those of normal devices.<sup>1,7</sup> It is notable that wet-processed nickel oxide (NiOx) nanoparticles were employed to extract holes in this record rather than the costly and labile organic semiconductors,<sup>3,8–11</sup> substantiating the paramount value of NiOx hole transport layers. 

##### Context & scale 

Nickel oxide (NiOx) is one of the most commonly used inorganic hole transport materials in inverted perovskite solar cells (PSCs) because of its outstanding stability and optical transmittance in entire visible spectrum. Unfortunately, its hydrophobicity and oxidizability badly affect uniform preparation of large-area stable devices. Here, we report a facile surface redox engineering (SRE) for electron-beam evaporated NiOx to perfectly match the slot-die-coated largearea PSCs. This SRE strategy eliminates the local de-wetting problem of the perovskite ink and also imparts enhanced performance in electronic properties at the buried interface via modulating the NiOx surface features. Consequently, high-performance PSCs are attained with power conversion efficiencies (PCEs) of 23.4% and 21.3% for rigid and flexible devices. Furthermore, the large-area (156 3 156 mm<sup>2</sup> ) perovskite submodules are successfully assembled with a remarkable PCE as high as 18.6%. 

Although it has enabled the maximum PCE, wet-processed NiOx generally requires an energy-intensive annealing process, and its quality tends to be sensitive to the synthesis conditions (e.g., ambient temp, solution pH, and stirring time), and thus, it suffers from poor reproducibility.<sup>12–17</sup> More importantly, it is extraordinarily challenging to extend the fabrication of millimeter-size thin films as thin as �10 nm 



Joule 6, 1931–1943, August 17, 2022 ª 2022 Elsevier Inc. 1931 

**ll** 

Article 

to the decimeter or meter size via current scalable technologies (e.g., slot-die coating, spray coating, and inkjet printing) while assuring uniformity.<sup>18</sup> By contrast, dry vacuum processes with superior control over the film uniformity allow the effortless deposition of large-scale and pinhole-free films.<sup>19</sup> In addition, vacuum-processed metal oxides are generally sub-stoichiometric with oxygen/metal deficiency since they will undergo redox reactions readily in the deposition chamber.<sup>20</sup> This feature is beneficial for NiOx as the resulting point defects, along with its selfdoping mechanism, and will lead to strong p-type character and high hole density. Compared with other vacuum processes, such as sputtering method,<sup>21–24</sup> electronbeam evaporation (EBE) stands out as a mature and dominant method owing to its lower-cost equipment, low complexity, and damageless operation at room temperature.<sup>25–28</sup> Recently, Abzieher et al. systematically controlled the EBE-NiOx film composition through altering the deposition parameters, and yet the PSCs achieved only a mediocre PCE of 21.6% accompanied by stabilized power output of 18.5%, which is the maximum value for devices incorporating EBE-NiOx.<sup>29,30</sup> Therefore, this promising technology for NiOx deposition still suffers from inferior performance in devices. 

In addition to film composition, the interface state is also crucial to device performance and stability. For most vacuum-processed NiOx films, the relatively hydrophobic surface attenuates the adhesion of perovskite ink,<sup>31</sup> which marginally impacts the dynamic spin-coating process,<sup>32</sup> but the evident de-wetting behavior that induces ink shrink and pin-hole issues in printing make it challenging to deposit large-area perovskite films. Even worse, the common hydrophilization methods (e.g., UV-ozone and O2 plasma treatment) will decrease film transmittance and increase the density of sub-gap states.<sup>33</sup> Moreover, the surface chemistry of NiOx is rather complex as a large number of high-oxidative-state Ni species (Ni<sup>3+</sup> and Ni<sup>2+</sup> ), and chemically reactive hydroxyls (NiOOH and –Ni(OH)2) can decompose perovskites,<sup>34,35</sup> leading to an interface energy barrier and non-capacitive hysteresis.<sup>36,37</sup> To date, the developed surface engineering for NiOx, mainly for wet-processed NiOx, mostly adopts small molecules or costly p-type organic semiconductors to reduce interface defects and promote energy-level alignment.<sup>38–41</sup> In turn, these strategies frequently decrease the interface tension, rendering the deployment for large areas more challenging, and meanwhile ignore the performance/stability degradation caused by interfacial reaction issues. Thus, it is highly desirable to develop a scalable surface strategy for EBE-NiOx that can enable the surface to support optimal wettability for perovskite layer stacking and ensure a stable surface composition to achieve rapid hole dynamics, aimed at producing highly efficient NiOx-PSCs. 

Herein, we propose a method for surface redox engineering (SRE) of EBE-NiOx films, which is achieved by subjecting the films to an Ar-plasma-initiated oxidation process and a Brønsted acid-mediated reduction process. We attempt to reveal the mechanism of this SRE by combining in situ characterizations with theoretical simulation and illuminate the chemical reactions comprising evident screening behavior. The multifunctional SRE can not only foster the formation of a stabilized surface state accompanied by increased conductivity and improved energy-band alignment but also increase the surface energy to improve the stacking of perovskite film on NiOx. In this scenario, we successfully deposited large-area, full-coverage, highquality perovskites on NiOx via slot-die coating, and the assembled rigid (flexible) PSCs delivered high PCEs up to 23.4% (21.3%) with excellent stability. Furthermore, thanks to the scalability of this technology, large-area (156 3 156 mm<sup>2</sup> ) perovskite solar submodules were configured and yielded a PCE as high as 18.6%. The current 

1Dalian National Laboratory for Clean Energy, iChEM, Dalian Institute of Chemical Physics, Chinese Academy of Sciences, Dalian 116023, Liaoning, China 

2School of Science, Chongqing University of Technology, Chongqing 400054, China 3University of the Chinese Academy of Sciences, Beijing 100039, China 

4Key Laboratory of Applied Surface and Colloid Chemistry, Ministry of Education, Shaanxi Key Laboratory for Advanced Energy Devices, Shaanxi Engineering Lab for Advanced Energy Technology, Institute for Advanced Energy Materials, School of Materials Science and Engineering, Shaanxi Normal University, Xi’an 710119, China 

5State Key Laboratory of Fine Chemicals, Department of Chemistry, School of Chemical Engineering, Dalian University of Technology, Dalian 116024, China 

6These authors contributed equally 7Lead contact *Correspondence: wangkai@dicp.ac.cn (K.W.), szliu@dicp.ac.cn (S.L.) https://doi.org/10.1016/j.joule.2022.06.026 

1932 Joule 6, 1931–1943, August 17, 2022 

### **ll** 

#### Article 



<!-- Start of picture text -->
A<br>B D<br>C E F G<br><!-- End of picture text -->

Figure 1. The influence and mechanism of SRE (A) Schematic illustration showing the process of SRE. 

(B) The variation of Ni species caused by SRE. 

(C) Calculated formation energies of Ni and O vacancies as a function of the Fermi energy under Ni-rich and O-rich conditions. 

(D) UV-vis absorption spectra of solutions of NiO2/Ni(OH)2/Ni2O3/NiO powder dissolved in 3 M HNO3 (x axis is wavelength). (E–G) (E) Density of states, (F) optimized NiO surface structure, and (G) planar-averaged charge density difference of NiO surface with NO3 

> � adsorption. 

SRE provides a way for the surface regulation of vacuum-processed NiOx films, and the proof of concept combining vacuum-processed NiOx with wet-processed perovskites will promote the industrialization of perovskite solar modules. 

##### RESULTS AND DISCUSSION 

The influence and mechanism of SRE 

Figure 1A depicts the SRE process for NiOx films that first undergo a nonthermal Ar plasma environment to enhance the surface wettability. This process is named surface oxidation engineering (SOE) for NiOx, which will be rationalized in the following. Note that we have compared Ar plasma with UV ozone and O2 plasma as shown in Figure S1. They all can darken the films in a few minutes, except Ar plasma, which takes a prolonged time. Second, the films were exposed in facile Brønsted acid (where nitric acid is employed herein), which can bleach the films through a mechanism to be revealed. Notably, both the EBE and SRE are executed at room temperature. 

Figures S2A and S2B illustrate the X-ray photoemission spectroscopy (XPS) spectra to elucidate the SRE-dependent variation of surface moieties on NiOx 

Joule 6, 1931–1943, August 17, 2022 1933 

**ll** 

Article 

films. The Ni2p3/2 and O1s core-level envelopes were separated according to the literature as summarized in Tables S2 and S3. According to the literature, for the control and SOE-NiOx, the peaks located at 853.60, 854.45, 855.60,and 856.85 eV pertain to Ni<sup>2+</sup> in the integral NiO lattice, Ni(OH)2, Ni<sup>3+</sup> (including Ni2O3 and NiOOH), and Ni<sup>4+</sup> , respectively.<sup>22,36</sup> An additional peak positioned at 854.10 eV belongs to Ni(NO3)2 for the SRE-NiOx. Note that, in addition to the NiO backbone, Ni<sup>3+</sup> benefits the semiconductor properties, while the susceptible Ni<sup>4+</sup> is detrimental to the perovskite layer due to its strong oxidizing property, and –OH specie may trigger the deprotonation of perovskites.<sup>42</sup> Figure 1B shows the variation in the content of different Ni species. Upon SOE, both the concentrations of Ni<sup>3+</sup> and Ni<sup>4+</sup> increase, whereas there is a drop off in the percentage of NiO and Ni(OH)2 species. Videlicet, the energetic Ar plasma initiates an oxidizing process from the low-valent state of NiO and Ni(OH)2 to the high-valent state Ni<sup>R3+</sup> . We inferred that the high-energy bombardment would dissociate the chemical bonds between the lattice O<sup>2�</sup> and Ni<sup>2+</sup> and cause atomic displacement, thus easily generating Ni<sup>2+</sup> vacancy defects in the Ar plasma conditions. One Ni<sup>2+</sup> vacancy results in the formation of two Ni<sup>3+</sup> ions or one Ni<sup>4+</sup> to maintain charge neutrality, dramatically triggering the films to be largely composed of increased oxidation states. To support this inference, we predict the formation energy of Ni<sup>2+</sup> vacancy and O<sup>2�</sup> vacancy through density functional theory (DFT) calculation. Note that, dissimilar to other oxides (such as TiO2, ZnO, MoOx, WOx, and SnO2),<sup>43,44</sup> Ni vacancies are frequent defects in NiO as evidenced by its inferior formation energy compared with O<sup>2�</sup> vacancies under either Ni or O-rich conditions (Figure 1C). Furthermore, the Ni<sup>2+</sup> ions freed by the bombardment may escape into the vacuum or be chemisorbed near surface defects and then react with O2 or H2O in the air to form NiO or Ni(OH)2 due to the low thermodynamic potential E<sup>Q</sup> Ni<sup>2 +</sup> =Ni<sup>=�0.257VversusE</sup> O<sup>Q</sup> 2=H2O<sup>=</sup> 1.229 V. The presumed chemical equations are as follows: 



<!-- Start of picture text -->
NiOAr /plasmaNiR 3 + ðNi2O3 + NiO2Þ + Nivacancy + Ni% 2 + (Equation 1)<br><!-- End of picture text -->

Ni<sup>% 2 +</sup> + O2 + H2O /in airNiO + NiðOHÞ2 (Equation 2) 

This assumption is also in excellent agreement with the increased O/Ni ratio upon SOE (Figure S2C). As for the reduced Ni(OH)2 content, the energy of a dozen electron volts<sup>45</sup> in Ar plasma is sufficient to convert Ni(OH)2 to NiOOH since they possess an identical rhombohedral structure.<sup>34</sup> Thus, Ar plasma treatment can not only increase surface wettability (Figure S3) but also initiate the surface oxidation process and induce the formation of detrimental Ni<sup>4+</sup> species. 

Upon further modifying the surface with Brønsted acid, the contents of Ni(OH)2 and Ni<sup>4+</sup> significantly decline, while those of NiO and Ni<sup>3+</sup> remain constant. Thus, acid can selectively eliminate the detrimental Ni<sup>4+</sup> and –OH but reserve the beneficial Ni<sup>3+</sup> and NiO backbone. To explain the screening behavior of acid, the reaction dynamics were tracked via the UV-visible absorption spectra, whereby NiO2, Ni2O3, NiO, and Ni(OH)2 powder were used as model compounds in acid. As per Figure 1D, the order of chemical reaction activity is Ni<sup>4+</sup> > Ni(OH)2 [ Ni<sup>3+</sup> > NiO. We also observed that NiO2 is inert in water, whereas it reacts violently with acids and generates numerous bubbles. Combing the high thermodynamic potential E<sup>Q</sup> NiO2=Ni<sup>2 +</sup> (1.68 V) versus E<sup>Q</sup> O2=H2O<sup>(1.23V),werationallyinferthatNi4+inthelatticewillfirst</sup> convert into free Ni<sup>4+</sup> ions in the acid, which then oxidizes water into O2 accompanied by the formation of Ni<sup>%3+</sup> . In addition, Ni(OH)2 is converted into Ni(NO3)2 in 

1934 Joule 6, 1931–1943, August 17, 2022 

**ll** 

#### Article 

the Brønsted acid environment. All the reactions can be described by the following equations: 



<!-- Start of picture text -->
NiO2 + HNO3/Ni 4 + + H2O + NO3 �/Ni% 3 + + O2 + NO3 � ðfastÞ (Equation 3)<br><!-- End of picture text -->



<!-- Start of picture text -->
NiO or Ni2O3 + HNO3/Ni % 3 + + H2O + NO3 �ðslowÞ (Equation 4)<br><!-- End of picture text -->

NiðOHÞ2 or NiOOH + HNO3/Ni<sup>% 3 +</sup> + H2O + NO3 � ðfastÞ (Equation 5) 

Therefore, Brønsted acid capably mediates a reduction reaction for NiOx to selectively eliminate detrimental Ni<sup>4+</sup> and neutralize the surface hydroxyl. In addition, Figure S2C presents the calculated Ni<sup>3+</sup> /Ni<sup>2+</sup> ratios for the control, SOE, and SRE samples, which are 0.87, 1.73, and 2.08, respectively. The evidently rising Ni<sup>3+</sup> / Ni<sup>2+</sup> ratio in NiOx inevitably implies the reinforced p-type semiconductor property of SRE-NiOx film.<sup>17</sup> Furthermore, according to the DFT calculation, the adsorption energy of NO3� on the NiO surface was predicted to be �2.90 eV, indicating energetically favorable adsorption. As per the density of states in Figure 1E, the pristine NiO surface shows a semi-conductive electronic structure, similar to the bulk NiO. Upon adsorbing NO3� (Figure 1F), the d electrons of surface Ni2+ cations transfer to the NO3� group, leading to a decrease of the Fermi energy level. Moreover, the NO3� adsorption triggers charge reorganization, whereby �0.402 electron transfers from the NiO to the NO3� group (Figure 1G), which may increase the conductivity of the top NiO layer and induce an interfacial dipole, thus facilitating the hole injection process. Collectively, SRE for NiOx provides three functions: reducing surfacing tension, stabilizing the surface and enhancing the surface electrical properties. 

The scanning electron microscopy (SEM) images, atomic force microscopy (AFM) images, UV-visible absorption, and transmittance spectra of various NiOx films in Figures S4–S6 manifest the identical morphology of the films with �11-nm roughness and optical transmittances with a band gap of 3.68 eV regardless of SRE. Figure S7 shows the conducting-AFM (C-AFM) maps for various NiOx films. The gradually increasing average current in the order of control-, SOE-, SRE-NiOx implies enhanced conductivity, consistent with the Ni<sup>3+</sup> /Ni<sup>2+</sup> ratio variation. In addition, the Hall effect measurement reveals that the hall mobility increases from 1.38 to 1.47 and to 1.65 cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> for the control, SOE, and SRE samples. In the meantime, the carrier density also increases from 2.40 3 10<sup>15</sup> to 2.42 3 10<sup>15</sup> and to 2.84 3 10<sup>15</sup> cm<sup>�3</sup> for the control, SOE, and SRE samples, which are competitive with the previous results.<sup>22</sup> These results also imply that SRE may also alter the compositions within a certain depth of the film, similar to the effect of UV-ozone treatment reported by Islam et al.<sup>33</sup> In parallel, the Kelvin probe force microscopy (KPFM) results in Figure S8 also demonstrate the rising work function from �0.34 to �0.71 and to �0.75 V for the control, SOE, and SRE samples. This cascade shift potentially leads to improved band alignment along with smaller voltage loss at the heterojunctions and enhanced charge extraction.<sup>46</sup> Note that both the increments in the conductivity and work function are contributed by the enhanced p-type semiconductor property, which are in line with the XPS analysis and DFT calculations. 

###### Effect of SRE on perovskite films 

Have revealed the SRE mechanism on NiOx films, we deposited perovskite layers via slot-die coating; all the perovskite films hereafter were prepared with this method. As per Figures S3 and S9, the contact angle of a perovskite droplet on pristine 

Joule 6, 1931–1943, August 17, 2022 1935 

**ll** 

Article 

NiOx films is �40.6<sup>�</sup> , which is sufficient for achieving uniform perovskite layers via spin-coating. However, the slot-die coated perovskite layers on pristine NiOx films are full of clusters and large exposed regions, even on the small substrates, due to the local de-wetting issue and spontaneous shrink of perovskite wet films. Thus slot-die coating technology has higher requirements for wettability than spincoating. Upon SOE or SRE, the surface-free energy increases, and the contact angle was mitigated to �7<sup>�</sup> ; then, the adhesion between the perovskite ink and underlying NiOx surface is improved, and thus the slot-die coated perovskite film is uniform in appearance with nearly 100% coverage. Moreover, the wettability will affect the crystallization of perovskite films according to the association between the free energy (G) for heterogeneous and homogeneous nucleation: 



<!-- Start of picture text -->
ð2 + cos qÞð1 � cos qÞ 2<br>GHeterogeneous = GHomogeneous 3 (Equation 6)<br>4<br><!-- End of picture text -->

where q is the contact angle on the solid/liquid interface. The smaller q of perovskite ink on SRE-NiOx results in a lower energy barrier for heterogeneous nucleation, which promotes the formation of uniform and high-quality perovskite films. XRD patterns in Figure S10 show that both the diffraction intensity of the perovskite films and the texture coefficient of the (101) plane increase gradually in the order of control, SOE and SRE, signifying the gradually increased crystallinity and higher degree of preferred orientation. Figure S11 shows top-view SEM images of perovskite films on various substrates. The perovskite films on pristine NiOx films possess a large number of pinholes at grain boundaries, which will serve as pathways for charge recombination and initiating sites for degrading device performance. On the contrary, both SOE and SRE enable compact perovskite films with significantly diminished pinholes and enlarged grain sizes together with reduced defect density, thus achieving the prerequisite for high-efficiency devices. 

###### Photovoltaic performance and stability of perovskite solar cells 

Given these significant improvements to the surface and perovskite crystals, smallarea PSCs were initially assembled with the structure FTO/NiOx/perovskite/[6,6]Phenyl-C61-butyric acid methyl ester/bathocuproine/Ag. Figure 2A is a crosssectional SEM image of an integral device with labeled layers. The photovoltaic parameters are summarized in Table S4, and the statistical histogram of PCE is depicted in Figure S12. The average PCEs for the control, SOE and SRE PSCs are 18.0% G 0.9%, 20.3% G 0.4% and 22.7% G 0.4% (Table S5), respectively. The stepwise rising PCE along with decreased scattering is contributed by the synchronously increased open-circuit voltage (VOC) and fill factor (FF) rather than the similar shortcircuit current density (JSC), signifying the powerful effect of SRE for facilitating interface hole dynamics. The significantly improved parameters are attributed to the stabilized surface with better electrical properties and improved band alignment as well as the optimized perovskite polycrystalline films. Strikingly, Figure 2B shows the current density-voltage (J-V) curves (forward and reverse scans) for the champion SRE PSCs, which delivered a reverse-scan PCE as high as 23.4%, entailing a VOC of 1.16 V, JSC of 24.8 mA cm<sup>�2</sup> and FF of 81.4% along with negligible hysteresis and a steady-state maximum power point (MPP) efficiency of 22.7% under the bias of 0.96 V (Figure 2C). Since all the functional layers were prepared at low temperature <110<sup>�</sup> C, the entire recipe was effortlessly transferred for assembling flexible PSCs on polyethylene terephthalate coated by ITO with MgF2 antireflection, which yielded a high VOC of 1.09 V, JSC of 24.5 mA cm<sup>�2</sup> , and FF of 79.7%, thus leading to a maximum PCE of 21.3% with minimal hysteresis. (The average parameters are summarized in Table S6.) Note that both PCEs are among the highest for NiOx-based rigid and flexible PSCs via scalable technologies (Figure 2D; Table S7). In addition, 

1936 Joule 6, 1931–1943, August 17, 2022 

**ll** 

#### Article 



<!-- Start of picture text -->
A B C<br>D F<br>G<br>E<br>H<br><!-- End of picture text -->

Figure 2. Performance of perovskite solar cells with SRE (A) Cross-sectional SEM image of a PSC. 

(B) J-V curves of champion rigid/flexible devices. 

(C) Steady-state power and current output of a rigid PSC. 

(D) PCEs of NiOx-PSCs prepared using scalable technologies. (E) EQE curve. 

(F–H) Long-term stability of devices measured under various conditions. 

as per Figure 2E, the integrated JSC extracted from the external quantum efficiency (EQE) of the device is 24.1 mA cm<sup>�2</sup> , which is consistent with the values obtained from J-V curves. 

Organic lead-halide perovskites with ionic nature and low formation energy are prone to degrade and are especially susceptible to light, thermal, moisture, or electric-field stress, which deteriorates the PCE and restricts the levelized cost of energy of PSCs. The interface plays a crucial role in stabilizing PSCs.<sup>47–53</sup> We first examined the stability of unsealed devices in the laboratory environment (25<sup>�</sup> C, relative humidity < 20%). As per Figure 2F, after �1,100 h of aging, an SRE-PSC showed an obvious advancement in shelf-life stability and retained 90% of the initial PCE, whereas the conservation rate decreased to 83% for the control device. The operational stability of PSCs is measured under MPP tracking under continuous one-sun illumination. It was found that the SRE-PSC shows a T90 lifetime exceeding 1,300 h, demonstrating 

Joule 6, 1931–1943, August 17, 2022 1937 

**ll** 

Article 

outstanding long-term operational stability (Figure 2G). Besides aging in the laboratory, it is imperative to understand the degradation behavior under real outdoor conditions with extreme weather and climatic changes. As shown in Figure 2H, encapsulated SRE devices were aged in outdoor conditions (Dalian, winter, January to February), undergoing various weather conditions including light/dark, low temperature, rain, and snow. The PSCs degraded by 20% after �1,000 h, equal to more than 41 natural diurnal cycles. The robust ambient and operational stability of these SRE devices can be attributed to the following reasons: (1) the hydroxyl groups of the pristine NiOx surface decompose the perovskite into PbI2, FA, I<sup>�</sup> , and H2O via the degradation reactions FAPbI3 + OH<sup>�</sup> / PbI2 + FA + H2O + I<sup>�</sup> . The generated water would further accelerate the decomposition process. The acidified surface formed by replacing OH<sup>�</sup> with NO3� will impair the deprotonating capability toward organic cations. (2) Another stability risk of the pristine NiOx/perovskite interface is the oxidation of perovskites via the reaction Ni<sup>>3+</sup> + I<sup>�</sup> / Ni<sup>2+</sup> + I2. Such issue is tackled by the acid-mediated reduction reaction. Additionally, the enhanced crystallinity and enlarged grain size of the perovskite layers also render the devices more stable. 

###### Improved carrier dynamics on the surface of SRE-NiOx film 

The improved photovoltaic parameters and stability are related to the SRE-enhanced NiOx surface and the advanced perovskite films grown on it. Numerous measurements were carried out to gain insight into the influence of SRE on the interface carrier dynamics. Figure S13 shows the UV-vis absorption and photoluminescence (PL) spectra of perovskite films deposited on NiOx. In addition to the analogical absorption, SRE-NiOx confers greater PL quenching on the perovskites in comparison with the control sample. Meanwhile, the time-resolved PL spectra of perovskite films on SRE-NiOx also show a shorter decay time than the control (135 versus 360 ns), as shown in Figure 3A and Table S8. These results indicate that the interfacial hole transfer dynamics are effectively enhanced upon SRE. Given the close relation between charge dynamics and trap states, the space charge-limited current model was utilized for hole-only devices to quantitatively evaluate the density of trap states at the NiOx/ perovskite interface. From the dark J-V curves in Figure 3B, the trap-filled limit voltages (VTFL) were measured to be 0.37 and 0.20 V for the control and SRE devices, respectively. Then the calculated trap density for the SRE device is �1.70 3 10<sup>15</sup> cm<sup>�3</sup> according to previous report,<sup>54</sup> which is relatively lower than that of the pristine one (�3.14 3 10<sup>15</sup> cm<sup>�3</sup> ). Figure 3C shows the capacitance-potential curves of control and SRE PSCs. The built-in potential (Vbi) evaluated through Mott-Schottky analysis increases from 1.11 V for the control to 1.21 V for the SRE PSCs. The enlarged Vbi will not only accelerate the dissociation of photogenerated carriers but also promote the construction of an extended depletion region to powerfully suppress nonradiative recombination. The Nyquist plots in Figure S14A were generated from measurements over a sequence of positive potentials in the dark.<sup>55,56</sup> The equivalent-circuit model in the inset was used to fit the plots, where the sum of R1 and R2 refers to the recombination resistance Rrec,<sup>56</sup> and Cs represents the surface charge accumulation capacitance at the contact/perovskite interface.<sup>57</sup> As depicted in Figures 3D and S14B, the higher Rrec and lower Cs in SRE PSCs manifest the suppressed charge recombination process and inhibited interface charge accumulation. Thermal admittance spectroscopy was performed to examine the trap density of states (tDOS) in PSCs. As per Figure 3E, the pristine device shows a relatively large tDOS on the order of 10<sup>16</sup> –10<sup>20</sup> cm<sup>�3</sup> eV<sup>�1</sup> . Upon SRE, the tDOS beyond 0.5 eV is lower by more than an order of magnitude, indicating that SRE could efficiently reduce the density of deeplevel trap states both at the grain boundaries and interfaces. The light-intensity (I) dependence of JSC and VOC was measured to estimate recombination behaviors. Figure S15 displays the power law dependence of JSC on I (JSC f I<sup>a</sup> ) for both samples, 

1938 Joule 6, 1931–1943, August 17, 2022 

**ll** 

#### Article 



<!-- Start of picture text -->
A B C<br>D E F<br><!-- End of picture text -->



Figure 3. Interaction effect of SRE on the perovskite film and devices (A) Time-resolved PL decay curves of perovskite films on FTO glass and control- and SRE-NiOx films. (B) Dark current-voltage curves of hole-only devices based on control- and SRE-NiOx films. (C) Mott-Schottky plots. 

(D) Rrec as a function of the bias. 

(E) Trap density of states and (F) VOC versus light-intensity curves for PSCs with and without SRE. 

where the factor a approaching 1 signifies a negligible space charge effect in both devices.<sup>58</sup> Figure 3F shows that the VOC varies linearly with the logarithm of I. The deviation between the slope and kT/q (where k, T, and q are the Boltzmann constant, temperature, and elemental charge, respectively) positively correlates with Shockley-Read-Hall recombination.<sup>59</sup> It appears that the SRE devices possess evidently suppressed trap-assisted recombination, as reflected by the smaller slope, which is consistent with the increased VOC and FF. 

###### Efficient and stable perovskite submodules with SRE 

We further evaluated the compatibility of SRE-NiOx with the scaling up of the processes by fabricating perovskite submodules on substrates with area of 156 3 156 mm<sup>2</sup> . The details of the process for the perovskite submodules were described in the supplemental information and Video S1. It is worth noting again that we could not obtain uniform large-area perovskite films without SRE as shown in Figure S16. The modules were composed of 20 subcells of 7 mm width in series, and the interconnection was accomplished with laser-patterned P1, P2, and P3 channels; the geometrical FF is R85.7% (Figure S17). As per Figure 4A, the activearea (174 cm<sup>2</sup> ) PCE of the champion submodule is 18.6% (VOC = 20.74 V; ISC =198.9 mA; and FF = 78.4%) along with negligible hysteresis, as evidenced by the overlapped I-V curves measured in the reverse/forward scan directions. For each subcell with an area of 8.7 cm<sup>2</sup> in the champion submodule, the VOC and JSC are 1.04 V and 22.9 mA cm<sup>�2</sup> , respectively. In comparison with small-area devices, we attributed this VOC loss to the deficient laser power that induced a discontinuous P3 line, and the JSC loss is triggered by the slightly attenuated perovskite film 

Joule 6, 1931–1943, August 17, 2022 1939 

**ll** 

Article 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->





Figure 4. Performance of perovskite solar submodules (A) I-V curves of the champion module measured in the reverse and forward scan directions. (B) Steady-state power output of the module at a fixed bias of 17.6 V for 140 s. (C) Long-term stability of two modules aged in the ambient environment. (D) PCE distribution of 14 modules. 

thickness to lower the difficulty level of laser etching. We deduced this can be dramatically improved by optimizing the laser etching technique. Figure 4B shows the stabilized power output of the submodule, which delivers a stabilized PCE of 18.2% for 140 s. In addition, the submodules show excellent long-term shelf-life stability, retaining 80% of the initial performance upon aging in the dark for 1,500 h (Figure 4C). Additionally, the perovskite submodules showed excellent reproducibility (Figure 4D; Table S9), where �21% and �86% of modules realized PCEs of more than 18.0% and 17.0%, respectively. The outstanding module efficiency and stability originate from the good uniformity of the functional layers, the reduced interfacial trap density, and suppressed interfacial recombination. 

###### Conclusions 

In summary, a facile SRE process was proposed that not only enables slot-coating of perovskites on EBE-NiOx film but also improves the properties and stability of the interface between the NiOx and perovskite. Theoretical and experimental results reveal the redox reaction in the SRE induced variation of the surface moieties. Afterward, the SRE obviously improved the carrier transport and reduced the trap-assisted recombination in PSCs, boosting the device performance to 23.4% and 21.3% for rigid and flexible devices, respectively, while ensuring long-term stabilities over 1,000 h. Strikingly, the SRE was further extended to perovskite submodules, which demonstrate outstanding photovoltaic performance with PCE of 18.6% on 156 3 156 mm<sup>2</sup> substrates. Overall, the SRE connecting slot-die-coated perovskites to EBE-NiOx will facilitate the commercialization of efficient and stable perovskite modules. 

1940 Joule 6, 1931–1943, August 17, 2022 

**ll** 

#### Article 

##### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Shengzhong (Frank) Liu (szliu@dicp.ac.cn). 

###### Materials availability 

This study did not generate new unique reagents. 

###### Data and code availability 

This study did not generate or analyze any datasets or codes. The data and results supporting the current study are available from the lead contact upon reasonable request. 

##### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2022.06.026. 

##### ACKNOWLEDGMENTS 

This work was supported by the Strategic Priority Research Program of the Chinese Academy of Sciences (grant no. XDA17040506), the National Nature Science Foundation of China (U20A20252, U21A20102, and 62174103), the Innovation Fund Project of Dalian Institute of Chemical Physics (DICP I202025, DICP I202032), the Cooperation Foundation of Dalian National Laboratory For Clean Energy of the Chinese Academy of Sciences (DNL202015), the Natural Science Foundation of Liaoning Province (2021-MS-016), the Youth Science and Technology Star Project of Dalian (2021RQ121), the 111 Project (B1404), the Project of Knowledge Innovation Engineering (Y261261606), the Transformational Technologies for Clean Energy and Demonstration, Strategic Priority Research Program of the Chinese Academy of Sciences (XDA21061001 and XDA21061002), the Fundamental Research Funds for the Central Universities (GK202103106), and the Shanxi Science and Technology Department (20201101012). 

##### AUTHOR CONTRIBUTIONS 

S.F.L., K.W., and M.D. proposed the project. M.D., L.D., and Y.C. fabricated the devices. M.D., L.D., Y.C., Y.S., J.F., Q.D., and Y.S. carried out the material and device characterizations. H.W., L.W., X.Z., L.L., and X.J. contributed useful comments for the paper. S.Z. performed the simulations. M.D. and K.W. analyzed all experimental data. M.D., K.W., and S.F.L. wrote the manuscript with discussion and input from all the authors. S.F.L. and K.W. supervised the overall project, discussed the results, and contributed to the final manuscript. 

##### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: May 2, 2022 Revised: June 2, 2022 Accepted: June 22, 2022 Published: July 21, 2022 

Joule 6, 1931–1943, August 17, 2022 1941 

**ll** 

#### Article 

##### REFERENCES 

1. NREL (2022). Best Research-Cell Efficiency Chart. https://www.nrel.gov/pv/cell-efficiency. html. (NREL) 

2. Chen, S., Xiao, X., Gu, H., and Huang, J. (2021). Iodine reduction for reproducible and highperformance perovskite solar cells and modules. Sci. Adv. 7, eabe8130. 

3. Wang, H., Huang, Z., Xiao, S., Meng, X., Xing, Z., Rao, L., Gong, C., Wu, R., Hu, T., Tan, L., et al. (2021). An in situ bifacial passivation strategy for flexible perovskite solar module with mechanical robustness by roll-to-roll fabrication. J. Mater. Chem. A 9, 5759–5768. https://doi.org/10.1039/D0TA12067G. 

4. Bush, K.A., Palmstrom, A.F., Yu, Z.J., Boccard, M., Cheacharoen, R., Mailoa, J.P., McMeekin, D.P., Hoye, R.L.Z., Bailie, C.D., Leijtens, T., et al. (2017). 23.6%-efficient monolithic perovskite/ silicon tandem solar cells with improved stability. Nat. Energy 2, 17009. https://doi.org/ 10.1038/nenergy.2017.9. 

5. Xiao, K., Lin, R., Han, Q., Hou, Y., Qin, Z., Nguyen, H.T., Wen, J., Wei, M., Yeddu, V., Saidaminov, M.I., et al. (2020). All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surfaceanchoring zwitterionic antioxidant. Nat. Energy 5, 870–880. https://doi.org/10.1038/s41560020-00705-5. 

6. Chen, H., Teale, S., Chen, B., Hou, Y., Grater, L., Zhu, T., Bertens, K., Park, S.M., Atapattu, H.R., Gao, Y., et al. (2022). Quantum-size-tuned heterostructures enable efficient and stable inverted perovskite solar cells. Nat. Photonics 16, 352–358. https://doi.org/10.1038/s41566022-00985-1. 

7. Yoo, J.J., Seo, G., Chua, M.R., Park, T.G., Lu, Y., Rotermund, F., Kim, Y.K., Moon, C.S., Jeon, N.J., Correa-Baena, J.P., et al. (2021). Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593. https:// doi.org/10.1038/s41586-021-03285-w. 

8. Li, F., Deng, X., Qi, F., Li, Z., Liu, D., Shen, D., Qin, M., Wu, S., Lin, F., Jang, S.H., et al. (2020). Regulating surface termination for efficient inverted perovskite solar cells with greater than 23% efficiency. J. Am. Chem. Soc. 142, 20134– 20142. https://doi.org/10.1021/jacs.0c09845. 

9. Zheng, X., Hou, Y., Bao, C., Yin, J., Yuan, F., Huang, Z., Song, K., Liu, J., Troughton, J., Gasparini, N., et al. (2020). Managing grains and interfaces via ligand anchoring enables 22.3%-efficiency inverted perovskite solar cells. Nat. Energy 5, 131–140. 

10. Calio´ , L., Kazim, S., Gra¨tzel, M., and Ahmad, S. (2016). Hole-transport materials for perovskite solar cells. Angew. Chem. Int. Ed. Engl. 55, 14522–14545. https://doi.org/10.1002/anie. 201601757. 

11. Li, X., Zhang, W., Guo, X., Lu, C., Wei, J., and Fang, J. (2022). Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437. https://doi.org/10.1126/science.abl5676. 

12. Zhu, Z., Bai, Y., Liu, X., Chueh, C.C., Yang, S., and Jen, A.K. (2016). Enhanced efficiency and stability of inverted perovskite solar cells using highly crystalline SnO2 nanocrystals as the 

robust electron-transporting layer. Adv. Mater. 28, 6478–6484. https://doi.org/10.1002/adma., 6478–6484. https://doi.org/10.1002/adma. https://doi.org/10.1002/adma. 201600619.. 

- robust electron-transporting layer. Adv. Mater. 22. Zheng, X., Song, Z., Chen, Z., Bista, S.S., Gui, P., 28, 6478–6484. https://doi.org/10.1002/adma., 6478–6484. https://doi.org/10.1002/adma. https://doi.org/10.1002/adma. Shrestha, N., Chen, C., Li, C., Yin, X., Awni, R.A., 201600619.. et al. (2020). Interface modification of sputtered NiOx as the hole-transporting layer for efficient 

- 13. Wu, Y., Xie, F., Chen, H., Yang, X., Su, H., Cai, inverted planar perovskite solar cells. J. Mater. M., Zhou, Z., Noda, T., and Han, L. (2017). Chem. C 8, 1972–1980. https://doi.org/10. Thermally stable MAPbI3 perovskite solar cells 1039/C9TC05759E. with efficiency of 19.19% and area over 1 cm<sup>2</sup> achieved by additive engineering. Adv. Mater. 23. Zhumagali, S., Isikgor, F.H., Maity, P., Yin, J., 29, 1701073. https://doi.org/10.1002/adma. Ugur, E., De Bastiani, M., Subbiah, A.S., 201701073. Mirabelli, A.J., Azmi, R., Harrison, G.T., et al. 

   23. Zhumagali, S., Isikgor, F.H., Maity, P., Yin, J., Ugur, E., De Bastiani, M., Subbiah, A.S., Mirabelli, A.J., Azmi, R., Harrison, G.T., et al. (2021). Linked nickel oxide/perovskite interface passivation for high-performance textured monolithic tandem solar cells. Adv. Energy Mater. 11, 2101662. https://doi.org/10.1002/ aenm.202101662. 

14. Yin, X., Chen, P., Que, M., Xing, Y., Que, W., Niu, C., and Shao, J. (2016). Highly efficient flexible perovskite solar cells using solutionderived NiOx hole contacts. ACS Nano 10, 3630–3636. https://doi.org/10.1021/acsnano. 5b08135. 

   24. Li, G., Jiang, Y., Deng, S., Tam, A., Xu, P., Wong, M., and Kwok, H.S. (2017). Overcoming the limitations of sputtered nickel oxide for high-efficiency and large-area perovskite solar cells. Adv. Sci. 4, 1700463. https://doi.org/10. 1002/advs.201700463. 

15. Najafi, M., Di Giacomo, F., Zhang, D., Shanmugam, S., Senes, A., Verhees, W., Hadipour, A., Galagan, Y., Aernouts, T., Veenstra, S., and Andriessen, R. (2018). Highly efficient and stable flexible perovskite solar cells with metal oxides nanoparticle charge extraction layers. Small 14, e1702775. https:// doi.org/10.1002/smll.201702775. 

   25. Agarwal, D.C., Chauhan, R.S., Kumar, A., Kabiraj, D., Singh, F., Khan, S.A., Avasthi, D.K., Pivin, J.C., Kumar, M., Ghatak, J., and Satyam, P.V. (2006). Synthesis and characterization of ZnO thin film grown by electron beam evaporation. J. Appl. Phys. 99, 123105. 

16. Zhang, H., Cheng, J., Lin, F., He, H., Mao, J., Wong, K.S., Jen, A.K.Y., and Choy, W.C.H. (2016). Pinhole-free and surfacenanostructured NiOx film by room-temperature solution process for high-performance flexible perovskite solar cells with good stability and reproducibility. ACS Nano 10, 1503– 1511. https://doi.org/10.1021/acsnano. 5b07043. 

   26. Pae, S.R., Byun, S., Kim, J., Kim, M., Gereige, I., and Shin, B. (2018). Improving uniformity and reproducibility of hybrid perovskite solar cells via a low-temperature vacuum deposition process for NiOx hole transport layers. ACS Appl. Mater. Interfaces 10, 534–540. https:// doi.org/10.1021/acsami.7b14499. 

   27. Routledge, T.J., Wong-Stringer, M., Game, O.S., Smith, J.A., Bishop, J.E., Vaenas, N., Freestone, B.G., Coles, D.M., McArdle, T., Buckley, A.R., and Lidzey, D.G. (2019). Lowtemperature, high-speed reactive deposition of metal oxides for perovskite solar cells. J. Mater. Chem. A 7, 2283–2290. https://doi. org/10.1039/C8TA10827G. 

17. Bao, H., Du, M., Wang, H., Wang, K., Zuo, X., Liu, F., Liu, L., Eder, D., Cherevan, A., Wang, S., et al. (2021). Samarium-doped nickel oxide for superior inverted perovskite solar cells: insight into doping effect for electronic applications. Adv. Funct. Mater. 31, 2102452. https://doi. org/10.1002/adfm.202102452. 

18. Sahli, F., Werner, J., Kamino, B.A., Bra¨uninger, M., Monnard, R., Paviet-Salomon, B., Barraud, L., Ding, L., Diaz Leon, J.J., Sacchetto, D., et al. (2018). Fully textured monolithic perovskite/ silicon tandem solar cells with 25.2% power conversion efficiency. Nat. Mater. 17, 820–826. https://doi.org/10.1038/s41563-018-0115-4. 

   28. Pang, S., Zhang, C., Dong, H., Chen, D., Zhu, W., Xi, H., Chang, J., Lin, Z., Zhang, J., and Hao, Y. (2019). Efficient NiOx hole transporting layer obtained by the oxidation of metal nickel film for perovskite solar cells. ACS Appl. Energy Mater. 2, 4700–4707. https://doi.org/10.1021/ acsaem.9b00169. 

19. Feng, J., Jiao, Y., Wang, H., Zhu, X., Sun, Y., Du, M., Cao, Y., Yang, D., and Liu, S. (2021). Highthroughput large-area vacuum deposition for high-performance formamidine-based perovskite solar cells. Energy Environ. Sci. 14, 3035–3043. https://doi.org/10.1039/ D1EE00634G. 

   29. Abzieher, T., Moghadamzadeh, S., Schackmar, F., Eggers, H., Sutterlu¨ ti, F., Farooq, A., Kojda, D., Habicht, K., Schmager, R., Mertens, A., et al. (2019). Electron-beam-evaporated nickel oxide hole transport layers for perovskite-based photovoltaics. Adv. Energy Mater. 9, 1802995. https://doi.org/10.1002/aenm.201802995. 

20. Meyer, J., Hamwi, S., Kro¨ ger, M., Kowalsky, W., Riedl, T., and Kahn, A. (2012). Transition metal oxides for organic electronics: energetics, device physics and applications. Adv. Mater. 24, 5408–5427. https://doi.org/10.1002/adma. 201201630. 

   30. Eggers, H., Schackmar, F., Abzieher, T., Sun, Q., Lemmer, U., Vaynzof, Y., Richards, B.S., Hernandez-Sosa, G., and Paetzold, U.W. (2020). Inkjet-printed micrometer-thick perovskite solar cells with large columnar grains. Adv. Energy Mater. 10, 1903184. https:// doi.org/10.1002/aenm.201903184. 

21. Aydin, E., Troughton, J., De Bastiani, M., Ugur, E., Sajjad, M., Alzahrani, A., Neophytou, M., Schwingenschlo¨ gl, U., Laquai, F., Baran, D., and De Wolf, S. (2018). Room-temperaturesputtered nanocrystalline nickel oxide as hole transport layer for p–i–n perovskite solar cells. ACS Appl. Energy Mater. 1, 6227–6233. https:// doi.org/10.1021/acsasm.8b01263. 

31. Hossain, M., Zakaria, Y., Zikri, A., Samara, A., Aissa, B., El-Mellouhi, F., Hasan, N., Belaidi, A., Mahmood, A., and Mansour, S. (2020). E-beam evaporated hydrophobic metal oxide thin films as carrier transport materials for large scale perovskite solar cells. Mater. Technol. 37, 248–259. 

1942 Joule 6, 1931–1943, August 17, 2022 

**ll** 

#### Article 

   41. Ru, P., Bi, E., Zhang, Y., Wang, Y., Kong, W., Y., et al. (2022). Rational selection of the Sha, Y., Tang, W., Zhang, P., Wu, Y., Chen, W., polymeric structure for interface engineering of et al. (2020). High electron affinity enables fast perovskite solar cells. Joule 6, 1032–1048. hole extraction for efficient flexible inverted https://doi.org/10.1016/j.joule.2022.04.002. perovskite solar cells. Adv. Energy Mater. 10, 1903487. https://doi.org/10.1002/aenm. https://doi.org/10.1002/aenm. 51. Wu, S., Zhang, J., Li, Z., Liu, D., Qin, M., 201903487.. Cheung, S.H., Lu, X., Lei, D., So, S.K., Zhu, Z., 

32. Nishihara, Y., Chikamatsu, M., Kazaoui, S., Miyadera, T., and Yoshida, Y. (2018). Influence of O2 plasma treatment on NiOx layer in perovskite solar cells. Jpn. J. Appl. Phys. 57, 04FS07. https://doi.org/10.7567/JJAP.57. 04FS07. 

   1903487. https://doi.org/10.1002/aenm. https://doi.org/10.1002/aenm. 51. Wu, S., Zhang, J., Li, Z., Liu, D., Qin, M., 201903487.. Cheung, S.H., Lu, X., Lei, D., So, S.K., Zhu, Z., and Jen, A.K.-Y. (2020). Modulation of defects 

   42. Liu, Z., Qiu, L., Ono, L.K., He, S., Hu, Z., Jiang, and interfaces through alkylammonium M., Tong, G., Wu, Z., Jiang, Y., Son, D.-Y., et al. interlayer for efficient inverted perovskite solar (2020). A holistic approach to interface cells. Joule 4, 1248–1262. https://doi.org/10. stabilization for efficient perovskite solar 1016/j.joule.2020.04.001. modules with over 2,000-hour operational stability. Nat. Energy 5, 596–604. https://doi. 52. Chen, W., Zhou, Y., Chen, G., Wu, Y., Tu, B., Liu, org/10.1038/s41560-020-0653-2. F.-Z., Huang, L., Ng, A.M.C., Djuri�si�c, A.B., and He, Z. (2019). Alkali chlorides for the 

   43. Werner, J., Geissbu¨ hler, J., Dabirian, A., suppression of the interfacial recombination in Nicolay, S., Morales-Masis, M., Wolf, S.D., inverted planar perovskite solar cells. Adv. Niesen, B., and Ballif, C. (2016). Parasitic Energy Mater. 9, 1803872. https://doi.org/10. absorption reduction in metal oxide-based 1002/aenm.201803872. transparent electrodes: application in perovskite solar cells. ACS Appl. Mater. 53. Zheng, X., Troughton, J., Gasparini, N., Lin, Y., Interfaces 8, 17260–17267. https://doi.org/10. Wei, M., Hou, Y., Liu, J., Song, K., Chen, Z., 1021/acsami.6b04425. Yang, C., et al. (2019). Quantum dots supply bulk- and surface-passivation agents for 

   44. Hu, K., Wang, F., Liu, H., Li, Y., and Zeng, W. efficient and stable perovskite solar cells. Joule (2020). Enhanced hydrogen gas sensing 3, 1963–1976. https://doi.org/10.1016/j.joule. properties of Pd-doped SnO2 nanofibres by Ar 2019.05.005. plasma treatment. Ceram. Int. 46, 1609–1614. https://doi.org/10.1016/j.ceramint.2019.09. 54. Yang, D., Yang, R., Wang, K., Wu, C., Zhu, X., 132. Feng, J., Ren, X., Fang, G., Priya, S., and Liu, 

33. Islam, R., Chen, G., Ramesh, P., Suh, J., Fuchigami, N., Lee, D., Littau, K.A., Weiner, K., Collins, R.T., and Saraswat, K.C. (2017). Investigation of the changes in electronic properties of nickel oxide (NiOx) due to UV/ ozone treatment. ACS Appl. Mater. Interfaces 9, 17201–17207. https://doi.org/10.1021/ acsami.7b01629. 

34. Ratcliff, E.L., Meyer, J., Steirer, K.X., Garcia, A., Berry, J.J., Ginley, D.S., Olson, D.C., Kahn, A., and Armstrong, N.R. (2011). Evidence for nearsurface NiOOH species in solution-processed NiOx selective interlayer materials: impact on energetics and the performance of polymer bulk heterojunction photovoltaics. Chem. Mater. 23, 4988–5000. https://doi.org/10.1021/ cm202296p. 

35. Beverskog, B., and Puigdomenech, I. (1997). Revised Pourbaix diagrams for nickel at 25– 300<sup>�</sup> C. Corros. Sci. 39, 969–980. 

   54. Yang, D., Yang, R., Wang, K., Wu, C., Zhu, X., Feng, J., Ren, X., Fang, G., Priya, S., and Liu, S.F. (2018). High efficiency planar-type perovskite solar cells with negligible hysteresis using EDTA-complexed SnO2-. Nat. Commun. 9, 3239. https://doi.org/10.1038/s41467-01805760-x. 

36. Boyd, C.C., Shallcross, R.C., Moot, T., Kerner, R., Bertoluzzi, L., Onno, A., Kavadiya, S., Chosy, C., Wolf, E.J., Werner, J., et al. (2020). Overcoming redox reactions at perovskitenickel oxide interfaces to boost voltages in perovskite solar cells. Joule 4, 1759–1775. https://doi.org/10.1016/j.joule.2020.06.004. 

45. Edelberg, E.A., Perry, A., Benjamin, N., and Aydil, E.S. (1999). Energy distribution of ions bombarding biased electrodes in high density plasma reactors. J. Vac. Sci. Technol. A 17, 506–516. https://doi.org/10.1116/1.581612. 

      55. Guerrero, A., Garcia-Belmonte, G., Mora-Sero, I., Bisquert, J., Kang, Y.S., Jacobsson, T.J., Correa-Baena, J.-P., and Hagfeldt, A. (2016). Properties of contact and bulk impedances in hybrid lead halide perovskite solar cells including inductive loop elements. J. Phys. Chem. C 120, 8023–8032. https://doi.org/10. 1021/acs.jpcc.6b01728. 

   46. Luo, D., Yang, W., Wang, Z., Sadhanala, A., Hu, Q., Su, R., Shivanna, R., Trindade, G.F., Watts, J.F., Xu, Z., et al. (2018). Enhanced photovoltage for inverted planar heterojunction perovskite solar cells. Science 360, 1442–1446. https://doi.org/10.1126/ science.aap9282. 

37. Di Girolamo, D., Matteocci, F., Kosasih, F.U., Chistiakova, G., Zuo, W., Divitini, G., Korte, L., Ducati, C., Di Carlo, A., Dini, D., and Abate, A. (2019). Stability and dark hysteresis correlate in NiO-based perovskite solar cells. Adv. Energy Mater. 9, 1901642. https://doi.org/10.1002/ aenm.201901642. 

47. Hu, Q., Chen, W., Yang, W., Li, Y., Zhou, Y., Larson, B.W., Johnson, J.C., Lu, Y.-H., Zhong, W., Xu, J., et al. (2020). Improving efficiency and stability of perovskite solar cells enabled by A near-infrared-absorbing moisture barrier. Joule 4, 1575–1593. https://doi.org/10.1016/j. joule.2020.06.007. 

   56. Zarazua, I., Han, G., Boix, P.P., Mhaisalkar, S., Fabregat-Santiago, F., Mora-Sero´ , I., Bisquert, J., and Garcia-Belmonte, G. (2016). Surface recombination and collection efficiency in perovskite solar cells from impedance analysis. J. Phys. Chem. Lett. 7, 5105–5113. https://doi. org/10.1021/acs.jpclett.6b02193. 

38. Wang, Y., Ju, H., Mahmoudi, T., Liu, C., Zhang, C., Wu, S., Yang, Y., Wang, Z., Hu, J., Cao, Y., et al. (2021). Cation-size mismatch and interface stabilization for efficient NiOx-based inverted perovskite solar cells with 21.9% efficiency. Nano Energy 88, 106285. https://doi. org/10.1016/j.nanoen.2021.106285. 

      57. Pascoe, A.R., Duffy, N.W., Scully, A.D., Huang, F., and Cheng, Y.-B. (2015). Insights into planar CH3NH3PbI3 perovskite solar cells using impedance spectroscopy. J. Phys. Chem. C 119, 4444–4453. https://doi.org/10.1021/ jp509896u. 

   48. Chen, C., Liang, J., Zhang, J., Liu, X., Yin, X., Cui, H., Wang, H., Wang, C., Li, Z., Gong, J., et al. (2021). Interfacial engineering of a thiophene-based 2D/3D perovskite heterojunction for efficient and stable inverted wide-bandgap perovskite solar cells. Nano Energy 90, 106608. https://doi.org/10.1016/j. nanoen.2021.106608. 

39. Chen, W., Zhu, Y., Xiu, J., Chen, G., Liang, H., Liu, S., Xue, H., Birgersson, E., Ho, J.W., Qin, X., et al. (2022). Monolithic perovskite/organic tandem solar cells with 23.6% efficiency enabled by reduced voltage losses and optimized interconnecting layer. Nat. Energy 7, 229–237. https://doi.org/10.1038/s41560-02100966-8. 

      58. Mihailetchi, V.D., Wildeman, J., and Blom, P.W. (2005). Space-charge limited photocurrent. Phys. Rev. Lett. 94, 126602. https://doi.org/10. 1103/PhysRevLett.94.126602. 

   49. Yang, G., Ren, Z., Liu, K., Qin, M., Deng, W., Zhang, H., Wang, H., Liang, J., Ye, F., Liang, Q., et al. (2021). Stable and low-photovoltage-loss perovskite solar cells by multifunctional passivation. Nat. Photon. 15, 681–689. https:// 15, 681–689. https://, 681–689. https:// https:// doi.org/10.1038/s41566-021-00829-4.. 

40. Chen, W., Zhou, Y., Wang, L., Wu, Y., Tu, B., Yu, et al. (2021). Stable and low-photovoltage-loss B., Liu, F., Tam, H.W., Wang, G., Djuri�si�c, A.B., perovskite solar cells by multifunctional et al. (2018). Molecule-doped nickel oxide: passivation. Nat. Photon. 15, 681–689. https:// 15, 681–689. https://, 681–689. https:// https:// verified charge transfer and planar inverted doi.org/10.1038/s41566-021-00829-4.. mixed cation perovskite solar cell. Adv. Mater. 30, e1800515. https://doi.org/10.1002/adma. 50. Wang, M., Zhao, Y., Jiang, X., Yin, Y., Yavuz, I., 201800515. Zhu, P., Zhang, A., Han, G.S., Jung, H.S., Zhou, 

59. Yang, D., Zhou, X., Yang, R., Yang, Z., Yu, W., Wang, X., Li, C., Liu, S.F., and Chang, R.P.H. (2016). Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. Energy Environ. Sci. 9, 3071–3078. 

Joule 6, 1931–1943, August 17, 2022 1943 

