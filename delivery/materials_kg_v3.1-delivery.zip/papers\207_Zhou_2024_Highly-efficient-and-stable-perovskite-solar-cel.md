# Highly efficient and stable perovskite solar cells via a multifunctional hole transporting material

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 580 |
| 作者 | Jun-Jie Zhou, Liguo Tan, Yue Liu, Hang Li, Xiaopeng Liu, Minghao Li, Siyang Wang, Yu Zhang et al. |
| DOI | 10.1016/j.joule.2024.02.019 |
| 源文件 | 007_Zhou_2024_Highly-efficient-and-stable-perovskite-solar-cel.pdf |

---
**ll** 

### Article 

# Highly efficient and stable perovskite solar cells via a multifunctional hole transporting material 



Junjie Zhou, Liguo Tan, Yue Liu, ..., Wolfgang Tress, Simone Meloni, Chenyi Yi 易陈谊 

yicy@mail.tsinghua.edu.cn 

Highlights 

A low-cost, high-performance multifunctional HTM for perovskite solar cells 

Vacuum-evaporated perovskite solar cells with PCE of over 26% 

Inhibition of ion migration by HTM leads to more stable perovskite solar cells 

A low-cost, scalable multifunctional HTM for high-efficiency perovskite solar cells. 

Zhou et al., Joule 8, 1691–1706 June 19, 2024 ª 2024 Elsevier Inc. https://doi.org/10.1016/j.joule.2024.02.019 



**ll** 

##### Article 

## Highly efficient and stable perovskite solar cells via a multifunctional hole transporting material 

Junjie Zhou,<sup>1,5</sup> Liguo Tan,<sup>1,5</sup> Yue Liu,<sup>1,5</sup> Hang Li,<sup>1,5</sup> Xiaopeng Liu,<sup>1</sup> Minghao Li,<sup>1</sup> Siyang Wang,<sup>1</sup> Yu Zhang,<sup>1</sup> Chaofan Jiang,<sup>1</sup> Ruimao Hua,<sup>2</sup> Wolfgang Tress,<sup>3</sup> Simone Meloni,<sup>4</sup> and Chenyi Yi 易陈谊<sup>1,6,</sup> * 

###### SUMMARY 

The hole-transporting material (HTM) plays a crucial role in the performance and stability of perovskite solar cells (PSCs). Ideally, it facilitates lossless charge transfer and suppresses charge recombination and ion migration between the perovskite and electrode. These bulk and interface functionalities require tailored electronic, structural, and chemical properties of the material and film. Here, we report a multifunctional organic HTM T2 based on a thiomethylsubstituted fluorene arm and spiro-[fluorene-9,9<sup>0</sup> -xanthene] core exhibiting enhanced hole extraction and reduced interface recombination compared with the benchmark HTM spiro-OMeTAD. T2 exhibits strong interactions with adjacent layers, which effectively inhibit interlayer ion migration, leading to enhanced stability. In combination with thermally evaporated perovskite films, power conversion efficiencies of 26.41% (26.21% certified) and 24.88% (certified) have been achieved for 0.1 and 1.0 cm<sup>2</sup> PSCs. The excellent performance together with a scalable and low-cost synthesis laid a solid foundation for the future large-scale application of PSCs. 

###### INTRODUCTION 

Perovskite solar cells (PSCs) have become a rising star in the field of photovoltaic technology because of their outstanding power conversion efficiency (PCE) and low cost.<sup>1–3</sup> PCEs exceeding 25% have been achieved for laboratory-scale devices by improving the perovskite crystallization methodologies, modifying the perovskite interfaces, and optimizing the charge extraction materials on the basis of a comprehensive understanding of charge carrier extraction and transportation processes with the device.<sup>4–6</sup> Hole-transporting materials (HTMs) extract photogenerated holes and suppress charge recombination by blocking the injection of electrons, which is fundamentally important for the optoelectronic performance and long-term stability of PSCs.<sup>7–12</sup> 2,2<sup>0</sup> ,7,7<sup>0</sup> -tetrakis(N,N-di-p-methoxyphenylamine)9,9<sup>0</sup> -spirobifluorene (spiro-OMeTAD) is recognized as the benchmark HTM for PSCs owing to its capability of efficient hole extraction, compatibility with various dopants and a good valence band alignment with perovskites.<sup>13–16</sup> Nevertheless, the complex synthesis and purification processes of spiro-OMeTAD make it expensive and not conducive to large-scale industrialized applications.<sup>17</sup> In addition, some commonly used hygroscopic dopants (e.g., lithium bis(trifluoromethanesulfonyl) imide [Li-TFSI]) in spiro-OMeTAD and metal atoms from the back electrode can migrate into the underlying perovskite layer, which has a detrimental effect on the long-term stabilities of devices.<sup>18–20</sup> Therefore, low-cost HTMs serving as substitutes for spiro-OMeTAD and enabling suppressed ion migration and good coordination with adjacent layers without sacrificing efficiency are highly desirable for industrialized scalable fabrication.<sup>21,22</sup> 

###### CONTEXT & SCALE 

The hole-transporting material (HTM) is a key component in perovskite solar cells (PSCs), as it helps transfer charges and reduces unwanted interactions between the perovskite layer and the electrode. A new organic HTM called T2 has been developed, which outperforms the commonly used spiro-OMeTAD. T2 has unique electronic, structural, and chemical properties that enhance its ability to extract holes and reduce charge recombination at the interface. When used with thermally evaporated perovskite films, T2 achieved power conversion efficiencies of 26.41%. In addition, strong interactions of T2 with the adjacent layers help prevent ion migration, boosting PSC stability. These results, along with its simple and low-cost production process, make T2 a promising candidate for the future widespread use of PSCs. 



Joule 8, 1691–1706, June 19, 2024 ª 2024 Elsevier Inc. 1691 

**ll** 

Article 

Considering the possible effects of thiomethyl in lowering energy levels, molecular interactions with the perovskite and metal, hydrophobicity, and the feasibility of spiro-[fluorene-9,9<sup>0</sup> -xanthene] (FX) core,<sup>23,24</sup> we designed and synthesized a HTM T2 (Figure 1A) using thiomethyl-substituted fluorene as arm structure and FX as the core. T2 can be synthesized in a few steps from low-cost commercially available raw materials with good yields and large quantities, which drastically reduces the synthesis cost compared with spiro-OMeTAD. T2 exhibits a better energy level alignment (Figure 1B) and an overlapping partial local density of electronic states (LDOS) with the perovskite layer, contributing to enhanced charge extraction capability and less voltage loss. Furthermore, the sulfur atoms were found to interact with the uncoordinated lead atoms at the perovskite/HTM interface to passivate defects and deep-level traps. The passivation of the defects at the perovskite/HTM interface is beneficial to the efficiency and stability of PSCs.<sup>25</sup> Moreover, the sulfur atoms can coordinate with gold atoms at the HTM/electrode interface to effectively suppress the migration of gold. T2 also exhibits strong binding forces with the hygroscopic dopant Li-TFSI, resulting in a pinhole free HTM layer, which benefits the stability of the PSCs. Combined with the perovskite films fabricated by sequential vacuum deposition, a PCE of 26.41% for 0.1 cm<sup>2</sup> (26.21% certified) and a PCE of 24.88% (certified) for 1.0 cm<sup>2</sup> aperture area PSCs have been achieved. In addition, we achieved a PCE of 21.45% for a mini-module (Figure 1C) with a light illumination area confined by a mask (mask area) of 14.4 cm<sup>2</sup> . The T80 of maximum power point tracking (MPPT) for T2-based devices without encapsulation is 600 h, 4 times longer than that of spiro-OMeTAD-based PSCs. T2-based PSCs also exhibit excellent longterm device stability both during storage (maintaining 95% of their initial PCE after 2,800 h storage under air conditions with relative humidity (RH) 10% without encapsulation) and upon thermal heating (maintaining 84% of their initial PCE after heating at 60<sup>�</sup> C for 1,500 h). The outstanding performance and exceptional stability demonstrate the feasibility and promising future of our multifunctional HTM in the field of PSCs and other perovskite-based optoelectronics. 

###### RESULTS AND DISCUSSION 

The chemical structures of spiro-OMeTAD and T2 are shown in Figure 1A. T2 was synthesized in a few steps from commercially available reagents with excellent yields, as shown in Figure S1. The structure and purity of T2 and the corresponding intermediate products were identified by nuclear magnetic resonance (NMR) spectroscopy and mass spectrometry (more details about the synthesis and characterization of T2 can be found in Figures S1–S10). 

###### Improved charge extraction efficiency of T2-based devices 

Compared with spiro-OMeTAD, T2 exhibits a better band alignment, facilitating the hole extraction and transmission process within the device. The highest occupied molecular orbital (HOMO) of T2 was determined to be �5.13 eV from the oxidation onset edge of cyclic voltammetry (CV) (Figure S8).<sup>9</sup> Compared with spiro-OMeTAD, T2 exhibits a deeper HOMO level, which better aligns with the valence band of the perovskite and thus provides optimal conditions for hole transfer with a decreased loss of free energy. The lowest unoccupied molecular orbital (LUMO) levels can be calculated by adding the optical band gaps (determined by the absorption onset of the UV-vis spectra Figure S9) to the HOMO levels. The obtained LUMO level of T2 is significantly higher than that of the perovskite layer, making it efficient to block electrons and restrain carrier recombination (Figure 1B). We also conducted density functional theory (DFT) calculations (Figures S11 and 2) and found that the HOMO/ LUMO values of T2 (�4.70 and �1.21 eV) are lower than those of spiro-OMeTAD (�4.30 and �0.79 eV), consistent with the CV measurements. 

> 1State Key Laboratory of Power System Operation and Control, Department of Electrical Engineering, Tsinghua University, Beijing 100084, China 

2Department of Chemistry, Tsinghua University, Beijing 100084, China 3Institute of Computational Physics, Zurich University of Applied Sciences, Winterthur 8401, Switzerland 

4Department of Chemical, Pharmaceutical and Agricultural Sciences, University of Ferrara, via Luigi Borsari 46, 44121 Ferrara, Italy 5These authors contributed equally 6Lead contact *Correspondence: yicy@mail.tsinghua.edu.cn https://doi.org/10.1016/j.joule.2024.02.019 

1692 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 



Figure 1. Structure and properties of HTMs and perovskite devices (A) Chemical structure of spiro-OMeTAD and T2. (B) Band alignment for perovskite and HTMs. (C) Photograph of PSCs based on T2 with aperture areas of 0.1, 1.0, and 14.4 cm<sup>2</sup> defined by metal masks. 

As shown in Figure 3B, the T2-based devices have a 0.5 mA cm<sup>�2</sup> higher short-circuit current density and �2% higher fill factor. This can be attributed to a more efficient charge collection due to the improved band alignment mentioned above. This interpretation, however, does not allow to identify the atomistic mechanism of charge transfer across the perovskite/HTM. To address this question, a comparative analysis of the density of electronic states of the interface systems of FAPbI3 with the two HTMs and the character of the corresponding orbitals is performed. The computational model for present calculations consists of a FAPbI3 slab with an HTM molecule, either spiro-OMeTAD or T2, deposited on it. This simplistic model of the experimental samples, which does not take into account, for example, bulky 2-chlorophenylethylamium cations of the passivating agent between the perovskites surface and HTM molecules, is inspired from experimental evidence reported in the following (see section ‘‘molecular interactions with adjacent layers’’).<sup>26–28</sup> Indeed, experimental data show that in the case of T2, there is a strong, direct chemical binding between Pb<sup>2+</sup> and S. Though the same evidence is absent in the case of spiroOMeTAD, in this case, we also use the corresponding atomistic model. This approach allows to highlight the fundamental differences between the two HTMs, though additional differences might arise from indirect interaction with the light harvesting layer in the case of spiro-OMeTAD. Figure S12 shows the (projected) density of states (pDOSs) of the FAPbI3/HTM system over a broad energy range. A zoom of the pDOS in the region of the FAPbI3 valence band maximum is shown in Figures 2A and 2B. The general characteristics of the DOSs of FAPbI3 are the same for both 

Joule 8, 1691–1706, June 19, 2024 1693 

**ll** 

Article 



Figure 2. DFT calculations: Mechanism of hole extraction 

(A, B, D, and E) Character of the interface orbitals, measured by the contribution (percentage) of FAPbI3, bulk and surface, and HTM atomic orbitals for FAPbI3/spiro-OMeTAD (A and D) and FAPbI3/T2 (B and E). 

(C) Illustration of the FAPbI3/T2 interface. 

(F) Contribution of each atomic species of T2 to the corresponding FAPbI3/T2 orbitals. 

spiro-OMeTAD- and T2-coated perovskite films, the energy of occupied frontier orbitals shifts toward higher values for the surface layer with respect to the deeper ones (dominated bulk in the following). This provides the force driving holes to the FAPbI3/ HTM interface. Analyzing the bands’ composition in more detail, one notices a mixing between bulk and surface FAPbI3 orbitals (Figures 2D and 2E). This mixing declines at increasing energies, but it remains significant up to �0.2 eV of the very top of the slab valence band. Following the Marcus/Husch theory of charge transfer,<sup>29–31</sup> charge transport rate increases with the electronic coupling between initial and final states, here, pairs of orbitals of the system: Hinitial=final = CjinitialjH<sup>b</sup> jjfinalD. High values of Hinitial=final require the initial and final states to geometrically overlap, i.e., not being spatially separated, which is guaranteed by bulk-surface hybridization. 

Concerning HTMs, no sizable contribution of spiro-OMeTAD to the DOS at energies close to the valence band maximum of the slab system is found (Figure 2A). This is reflected on a negligible hybridization between FAPbI3 and spiro-OMeTAD (Figures 2D and S13). In contrast, T2 shows significant contribution to the DOS near the FAPbI3 valence band maximum (Figure 2B). This corresponds to a significant hybridization between perovskite and T2 orbitals, with a �25% and 20% contribution to states at �0.2 and �0.08 eV below the FAPbI3 valence band maximum, and a �4% contribution to the frontier orbital (Figures 2E and S14). The higher hybridization between FAPbI3 and T2 with respect to spiro-OMeTAD can also be appreciated visually, as shown by isodensity surfaces reported in Figures S13 and S14. Here, one notices a negligible electronic density of orbitals close to the valence band maximum of FAPbI3 on the spiro-OMeTAD. On the contrary, the corresponding orbitals in the FAPbI3/T2 system show a highly delocalized electronic density diffused on the HTM molecule. As explained before, the high localization for the FAPbI3/spiro-OMeTAD and the high delocalization 

1694 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 



Figure 3. Device performance and characterization (A) Comparison of device performance using spiro-OMeTAD and T2 as HTM with an aperture area of 0.1 cm<sup>2</sup> recorded in the reverse scan. (B and C) (B) J-V curves of the best device based on spiro-OMeTAD and T2 with an aperture area of 0.1 cm<sup>2</sup> and (C) 1.0 cm<sup>2</sup> (certified data from National Institute of Metrology, NIM, China). (D) The C<sup>�2</sup> -V characteristics measured in the dark. 

(E) Normalized TPV decay curves of PSC devices with different HTMs. 

(F) EQEEL curves of PSC devices with different HTMs. 

(hybridization) in the case of FAPbI3/T2 is a clear indication of a larger electronic coupling in the latter case, implying a more effective charge transfer across the corresponding perovskite/HTM interface, i.e., a more efficient charge extraction. Similarly, orbital hybridization between SnO2 and perovskite has been reported to contribute to the outstanding electron transport properties of SnO2,<sup>32</sup> and electronic coupling has been proposed as the dominate effect in facilitating charge transfer in organic solar cell.<sup>33</sup> 

To further analyze the origin of the delocalized orbitals encompassing perovskite and T2, we computed the elemental contributions of T2 to orbitals hybridized with perovskite ones (the FAPbI3/T2 interface as illustrated in Figure 2C). We focus first on highest energy orbital with a large hybridization, orbital number �4 in Figure 2E, with 20% contribution from T2, including that �11.5% of this orbital arises from T2 carbon, �5.5% from sulfur, and �2% from oxygen (Figure 2F). We speculate the major contribution of carbon to the conjugated structure of fluorene arm. The sizable contribution of sulfur to a delocalized orbitals involving T2 is not surprising, considering its role in the strong binding of the HTM molecule to FAPbI3. Though smaller, the surface perovskite maximum of the valence band also shows a degree of hybridization with T2 involving sulfur orbitals. Very interesting is the composition of bands from �9 to �12 as shown in Figure 2F. These consist mainly of carbon and oxygen. A visual inspection of the orbitals show that hybridization involves T2 orbitals localized on the central part of the molecule (see Figure S14). Interestingly, this part of the T2 differs from spiro-OMeTAD due to the presence of an oxygen atom in one of the 

Joule 8, 1691–1706, June 19, 2024 1695 

**ll** 

Article 

residues connecting the two wings of the molecule. This finding open novel perspectives and targets for further engineering of HTM molecules to further enhance hole extraction. 

In summary, for the FAPbI3/T2, strong electronic coupling drives holes from the bulk of the perovskite all throughout the interface into the HTM layer. For FAPbI3/spiroOMeTAD, even if the HTM molecules were in direct contact with perovskite, similar to the experimental data discussed in the next section that prove to be the case for T2, the electronic coupling at the perovskite/HTM interface is much lower, resulting in less efficient charge extraction. The enhanced electronic coupling in FAPbI3/T2 is attributed to the good conjugation of fluorene arm, the stronger binding enabled by sulfur (see next section), and the introduction of a heteroatom, oxygen, in the central part of the HTM molecule. 

###### Molecular interactions with adjacent layers 

The sulfur atoms in the T2 molecule may endow more intense coordination with the perovskite and Au electrode compared with the oxygen atom of spiro-OMeTAD.<sup>34,35</sup> We speculate that the strong interactions between the HTM and gold electrode suppress the diffusion of gold through the HTM layer. Thus, we calculated the adsorption energy of HTMs on the surface of Au and FAPbI3 by DFT calculations (Figures S15 and S16) to determine the difference in binding force. For the Au/HTM interface, despite geometry optimizations were started from analogous configurations, with oxygen and sulfur atoms oriented toward the surface, the binding modes are apparently different: S of T2 faces the metal surface, while oxygen is away from it in the case of spiro-OMeTAD. This is consistent with the renowned capability of sulfur to bind gold, which is exploited, for example, to prepare self-assembled monolayers of organosulfur molecules on Au surfaces.<sup>36–39</sup> The adsorption energy difference of HTMs on the Au surface is listed in Table S1. The adsorption energy between T2 and Au is 8.37 eV, which is higher than that of spiro-OMeTAD at 6.98 eV, indicating a stronger binding between T2 and Au. When T2 and spiro-OMeTAD were placed onto the surface of the Au layer, as indicated by the charge density difference in Figures S17A and S17B, an Au–S bond formed between Au and the T2 molecule, whereas no Au–O bond was observed between Au and spiro-OMeTAD. For the molecular interactions between the HTM and the perovskite layer, the calculated adsorption energy between T2 and FAPbI3 (2.33 eV) is larger than that of spiro-OMeTAD (1.38 eV) because of the tighter binding of Pb–S (Figures S17C and S17D; Table S2). This might be due to the better matching of the size of valence orbitals of S and Pb, which may contribute to a tighter bonding between T2 and perovskite. The higher polarizability of S probably makes it easier to form a dative bond from its orbitals to unsaturated surface Pb<sup>2+</sup> and decreases the surface trap density of the perovskite layer. 

To test our hypothesis, we characterized perovskite/HTM and Au/HTM by X-ray photoelectron spectroscopy (XPS). As a result, we observed a peak shift of Pb<sup>2+</sup> for the T2-based sample, which can be attributed to the interaction between lead and sulfur atoms (Figure S18A). Compared with the Au signal at the interface between the Au back electrode and HTM layer (Figure S18B), a similar peak shift was observed, indicating the existence of Au-S interactions. These peak shifts confirmed a stronger interaction between the T2 layer and the electrode and perovskite layer, preventing interlayer ion diffusion, thereby enhancing the stability of the PSCs.<sup>2</sup> 

###### Photovoltaic performance 

Solar cells based on a conventional structure fluoro-doped tin oxide (FTO)/ SnO2/perovskite/hole transporting layer (HTL)/Au were prepared to investigate the 

1696 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 

effect of T2 on device performance. The perovskite was fabricated via the sequential thermal vacuum deposition method.<sup>40</sup> Briefly, cesium iodide (CsI) and PbI2 were first co-evaporated using two sources separately at constant rates, followed by the deposition of formamidinium iodide (FAI) and methylamine hydrochloride (MACl). Highquality large-area perovskite films can be obtained after annealing. Statistics of the performance parameters of PSCs (Figures 3A and S19; Tables S3 and S4) clearly show better performances of the devices based on T2 than that of spiro-OMeTAD. The maximum PCE of the spiro-OMeTAD-based device was 24.43% with a short-circuit current density (Jsc) of 25.94 mA cm<sup>�2</sup> , open-circuit voltage (Voc) of 1.154 V, and fill factor (FF) of 81.57%. The best device using T2 showed a PCE value of 26.41% with a Jsc of 26.47 mA cm<sup>�2</sup> , Voc of 1.175 V, and FF of 84.94% (Figure 3B), outperforming that of spiro-OMeTAD-based PSCs. To date, this is the highest PCE for PSCs using alternative HTMs (previous reports of high-efficiency PSCs with alternative HTMs are summarized in Table S5). Moreover, we achieved a certified PCE of 26.21% and 24.88% (Figures S20, S21, and 3C) for the 0.1 and 1.0 cm<sup>2</sup> aperture area PSCs based on T2, respectively, which is the record up to date to the best of our knowledge. The steady power output of PSC based on T2 (Figures S20 and S21) matches well with the J-V result. The corresponding external quantum efficiency (EQE) spectra of devices based on spiro-OMeTAD and T2 can be found in Figure S22. 

Large-scale PSC modules are an inevitable path to commercial applications.<sup>41–44</sup> Thermal sequential evaporation strategies have advantages such as precise control of film thickness, film homogeneity, and avoidance of solvents, which are highly beneficial for upscaling and tandem solar cell fabrication.<sup>45,46</sup> We further fabricated large-area PSC modules (FTO size: 5 3 5 cm<sup>2</sup> ) using T2 as the HTM layer. As shown in Figure S23, a series structure was adopted in our module, and a dark mask with a mask area of 14.4 cm<sup>2</sup> covered the mini-module during J-V scanning (Figure S24). A high PCE of 21.45% was achieved for the champion mini-module with a Jsc of 6.41 mA cm<sup>�2</sup> , Voc of 4.385 V, and FF of 76.31% (Figure S25). 

Scalable synthesis of an HTM with competitive cost is an important step for the largescale production of PSCs. We performed a 10-g-scale reaction and obtained 15.5 g T2, as shown in Figure S26. The total cost of raw materials for 15.5 g T2 in the lab was calculated to be 219 $ (14.0 $ g<sup>�1</sup> ), much lower than the price of spiro-OMeTAD (Table S6), indicating the good feasibility of T2 as an HTM compatible for large-scale application in PSC modules. 

###### Device physics 

Electrical and transient optoelectronic measurements reveal the impact of charge carriers on device performance, including capacitance-voltage (C-V) under dark conditions and transient photovoltage (TPV) and transient photocurrent (TPC) decay under open- and short-circuit conditions (Figures 3D, 3E, and S27). The built-in potential (Vbi) of the T2-based device (1.07 V) was higher than that of the spiro-OMeTAD-based device (1.01 V), consistent with the lower-lying HOMO of T2 when assuming a similar doping efficiency as in spiro-OMeTAD. The enhanced built-in potential leads to a higher driving force for more efficient charge separation and collection in T2-based devices, which reduces interface recombination and facilitates a higher Voc. Since the linear region of the C<sup>�2</sup> -V plot spans a considerable voltage range, we assume that the determination of Vbi is possible. On the other hand, we refrain from stating doping densities and note only that the slope of the T2-based device near the built-in potential is 1.4 times higher than that of the spiro-OMeTAD-based device, which indicates reduced charge accumulation at the HTM/perovskite interface due to the better aligned valence 

Joule 8, 1691–1706, June 19, 2024 1697 

**ll** 

Article 

band.<sup>47</sup> The average decay time tTPV derived from a biexponential fit to the TPV curves are 13 and 24 ms for spiro-OMeTAD- and T2-based devices, respectively. These time constants are limited by the geometric capacitance Cg and the resistance R of the diode, which is commonly the recombination resistance at the given light intensity.<sup>48</sup> Since Cg is independent of HTL (see C at 0 V in Figure 3D), a higher tTPV implies a higher resistance and thus reduced recombination, consistent with the increased Voc. The photocurrent decay times are 5 and 3 ms based on the TPC measurement. Although those times are much higher than what is expected for the transit times of free charge carriers and thus also limited by resistancecapacitance (RC) effects, the reduced time constant might indicate more efficient charge extraction compared with devices using spiro-OMeTAD as the HTM. To rationalize the enhanced Voc, photoluminescence (PL) measurements have been undertaken on a series of film stacks (glass/FTO/perovskite) with and without HTLs and under varied conditions (Figures S28A–S28C). They show that the PL intensity is in a similar range when comparing perovskite and perovskite covered with spiro-OMeTAD, whereas perovskite covered with T2 shows an increase in PL by more than a factor of two, which is consistent with the Voc increase of few 10 s of mV. This trend is independent of excitation wavelength and direction. We furthermore quantified the PL quantum yield (PLQY) in a setup with integrating sphere at an incident light intensity of 0.1 kW m<sup>�2</sup> , where, again, the T2 sample showed an enhanced value (2.5% compared with <1%, Figure S28D). Thus, we conclude that the T2 efficiently reduces surface recombination, not only by a better aligned HOMO compared with spiro-OMeTAD but also by a passivation effect on the perovskite surface. 

When the PSCs are under a forward bias voltage, they become a light-emitting diode. We recorded the EQEEL values under different injection currents (Figure 3F). The higher EQEEL value of T2-based devices confirms reduced interface recombination and more balanced carrier injection due to an enhanced hole injection from the deeper HOMO, which is consistent with the above TPV/TPC results. In addition, nonradiative-related Voc losses can be derived from the EQEEL value when the injection current is equal to Jsc according to the equation DVnon-rad = <u>kTq</u><sup>~~l~~n(</sup> EQE1 EL<sup>~~)~~, where k is the</sup> Boltzmann constant and T is the absolute temperature. The obtained non-radiativerelated Voc loss of the T2-based device is 112 mV, which is lower than that of the spiro-OMeTAD-based device (127 mV). 

###### Device stability and analysis 

The stabilities of the T2-based devices under different conditions were tested, including dark storage (ISOS-D-1), light soaking (ISOS-L-1), and exposure to elevated temperatures.<sup>49</sup> The 2,800-h dark-storage stability in ambient air at �10% humidity and 25<sup>�</sup> C is shown in Figure 4A. The T2 device maintained 95% of its initial efficiency, while the spiro-OMeTAD-based control device only maintained 84% of its initial PCE. After 600 h of continuous light soaking in the N2 atmosphere without encapsulation, the steady-state power output of the T2-based device retained 80% of its initial efficiency, as shown in Figure 4B, while the control device based on spiro-OMeTAD maintained only 54% of its initial efficiency. The 1,500 h thermal stability was determined under 60<sup>�</sup> C thermal heating in an Ar atmosphere. The PCE of the T2-based device maintained 84% of its initial PCE. In comparison, the PCE of the control sample declined to 16% after aging (Figure 4C). 

Theoretical calculations and experimental characterizations were conducted to unveil the underlying reasons for the improved stabilities of T2-based devices. DFT calculations for the spiro-OMeTAD and T2 molecules were performed to calculate the 

1698 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 



Figure 4. Stability of PSC devices (A) Dark-storage stability (ISOS-D-1) in dry air (RH � 10%); the initial PCEs were 23.84% for T2-based device and 23.43% for spiro-OMeTAD-based device. (B) Light-soaking stability (ISOS-L-1) without encapsulation in a N2 atmosphere at room temperature; the initial PCEs were 24.25% for T2-based device and 22.73% for spiro-OMeTADbased device. 

(C) Thermal stability at 60<sup>�</sup> C in an Ar atmosphere; the initial PCEs were 22.94% for the T2-based device and 22.89% for the spiro-OMeTAD-based device. 

cohesive energy of the molecular crystals (Ecoh), which represents the intermolecular interactions of the materials.<sup>50</sup> The calculated Ecoh of T2 is 5.46 eV, much higher than that of spiro-OMeTAD (3.31 eV), indicating stronger cohesion of T2 in the condensed phase. In addition, we calculated the binding energy of T2 and spiroOMeTAD with the hygroscopic dopant Li-TFSI. The binding energy of T2 with Li<sup>+</sup> is 3.7 eV, which is significantly higher than that of spiro-OMeTAD at 2.7 eV. Some intuitive arguments for the higher cohesive energy of T2 and its higher binding 

Joule 8, 1691–1706, June 19, 2024 1699 

**ll** 

Article 

with Li<sup>+</sup> are discussed in the supplemental information (Figures S29 and S30). Here, we remark that these characteristics contribute to the formation of uniform and pinhole free HTM film (Figure S31), which improves the long-term stability of T2based devices. 

Furthermore, the aged devices (after 1,500 h of thermal stress) were subjected to characterizations to reveal the key role of T2 in improving the stability and the underlying degradation mechanism of the reference devices. XPS measurements of the aged PSCs after the thermal stability test were performed after the removal of the Au electrode and HTM layer (Figure S32). A clear signal of Au was found in the spiro-OMeTAD-based device, which indicates Au diffusion into the perovskite layer, which can lead to a PCE decline in PSCs.<sup>20,51</sup> In contrast, no Au signal is observed for T2-based devices, indicating that no Au diffuses into perovskite in T2-based PSCs. In addition, we observed a peak at 167 eV, which can be attributed to the S 2p of the chemical adsorption of T2 molecules. In summary, the enhancement in device performance is attributed to the synergism of Au-S/Pb-S interactions, denser film morphology, and stronger intermolecular interactions. 

In summary, we designed and synthesized a scalable, low-cost HTM T2 for high-efficiency and stable PSCs. The stronger chemical binding of T2 with its neighboring perovskite and electrode contributes to enhanced hole transmission through the interfaces and retards the interlayer ion migration of ionic species originating from the electrode and perovskite. PSCs based on T2 showed a record PCE of more than 26% and 24% for 0.1 and 1.0 cm<sup>2</sup> area devices, respectively. In addition, a mini-module adopting T2 as the HTM exhibited a PCE of 21.45% (14.4 cm<sup>2</sup> mask area), which is one of the highest reported PCE values for perovskite modules. The PSCs based on T2 showed better stability under continuous illumination, thermal heating, and storage in ambient air compared with PSCs with spiro-OMeTAD because of the suppressed ion migration and the resulting chemical reactions. Finally, DFT calculations allowed us to identify the atomistic origin of the enhanced hole extraction, which is attributed to a better energy level alignment and the overlapping partial LDOS between the valence band maximum of FAPbI3 at the interface and T2 energy level. 

###### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Chenyi Yi (yicy@mail.tsinghua.edu.cn). 

###### Materials availability 

T2 generated in this study will be made available on reasonable request, but we may require a payment and/or a completed Materials Transfer Agreement if there is a potential for commercial application. 

###### Data and code availability 

This study did not generate any datasets. 

###### Materials 

FAI was purchased from GreatCell Solar Materials. CsI was purchased from Beijing Mreda Technology. Li-TFSI and 4-tert-butylpyridine (t-BP) were purchased from Energy Chemical. Chlorobenzene and acetonitrile were purchased from Acros Organics. For the synthesis of T2, all the chemicals were purchased from commercially available company and used directly without further purification. 

1700 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 

###### Synthesis of T2 

To a 250 mL round-bottom flask, 19.6 g N-(4-methoxyphenyl)-9,9-dimethyl-7(methylsulfanyl)-9H-fluoren-2-amine, 7.0 g 2,3<sup>0</sup> ,6<sup>0</sup> ,7-tetrabromospiro[fluorene9,9<sup>0</sup> -xanthene], 6.3 g sodium tert-butoxide, 250 mg Pd2(dba)3, 500 mg x-phos, and 120 mL toluene were mixed under a N2 atmosphere. The reaction was carried out at 110<sup>�</sup> C for 12 h. After that, dilute hydrochloric acid solution (5 wt %) was added to quench the reaction, and then the mixture was extracted with dichloromethane. The organic layer was dried with anhydrous MgSO4 and filtrated to remove the catalyst and MgSO4. The solvent was removed under reduced pressure. Recrystallization using hexane/ethyl acetate afforded T2 as a yellow solid (15.5 g, 81%).<sup>1</sup> H NMR (800 MHz, chloroform-d) d 7.52–7.47 (m, 6H), 7.46 (d, J = 8.2 Hz, 2H), 7.43 (d, J = 8.2 Hz, 2H), 7.27 (s, 4H), 7.20 (dd, J = 3.9, 1.7 Hz, 2H), 7.19 (dd, J = 3.9, 1.7 Hz, 2H), 7.09 (d, J = 2.0 Hz, 2H), 7.08–7.03 (m, 12H), 6.99 (dd, J = 8.2, 2.0 Hz, 2H), 6.94 (dd, J = 8.2, 2.0 Hz, 2H), 6.87 (dd, J = 8.2, 2.0 Hz, 2H), 6.82 (d, J = 6.6 Hz, 4H), 6.81 (d, J = 6.6 Hz, 4H), 6.57 (dd, J = 8.6, 2.4 Hz, 2H), 6.53 (d, J = 2.4 Hz, 2H), 6.43 (d, J = 8.6 Hz, 2H), 3.80 (s, 6H), 3.77 (s, 6H), 2.52 (s, 6H), 2.51 (s, 6H), 1.36 (s, 12H), 1.34 (s, 12H).<sup>13</sup> C NMR (101 MHz, chloroform-d) d 156.37, 154.69, 154.27, 151.72, 147.91, 146.85, 140.27, 136.65, 136.02, 133.49, 128.03, 127.55, 126.98, 125.75, 123.03, 121.41, 120.31, 120.07, 119.77, 119.65, 118.25, 117.57, 116.37, 114.82, 108.74, 77.38, 77.06, 76.74, 55.44, 53.57, 46.77, 27.13, 16.61. High-resolution mass spectroscopy (HRMS): Calcd. For C117H100O5N4S4 [m/z]: 1,769.6610; found: 1,769.6813. 

###### Device fabrication 

The SnO2 electron transporting layer (ETL) was deposited on clean FTO glass by a chemical bath as previously reported.<sup>52</sup> The perovskite film was deposited via sequential vacuum thermal evaporation.<sup>53</sup> In brief, CsI and PbI2 powders were placed on separated quartz crucibles. The evaporation rates were monitored to be 0.1 and 3 A<sup>˚</sup> s<sup>�1</sup> for CsI and PbI2, respectively, through a quartz crystal microbalance (QCM) next to the substrates, and the final thickness of (PbI2 + CsI) was 350 nm. After that, 250 nm FAI were uniformly deposited, and then, 50 nm MACl was deposited on the surface of FAI film surface. For the deposition of FAI and MACl films, sufficient preheating of ammonium salts is recommended to prevent material splashing onto the surface of the film. The deposited films were annealed at 150<sup>�</sup> C for 15 min under ambient conditions. Then, the perovskite films were transferred to a N2 glove box. Before HTM deposition, the perovskite film was passivated with 2-chlorophenylethylamine hydroiodide (10 mM, spin-coated at 4,000 rpm for 20 s) followed by annealing at 100<sup>�</sup> C for 10 min.<sup>54,55</sup> After cooling, the HTM solution was spincoated on the perovskite surface at 4,000 rpm for 20 s. The recipe of the spiro-OMeTAD solution was the same as previously reported.<sup>56</sup> The concentration of the T2 solution was 40 mg/mL in chlorobenzene with the addition of 30 mL of 4-tert-butyl pyridine and 16 mL of Li-TFSI solution (1.81 mol L<sup>�1</sup> in acetonitrile). After storage in dry air overnight, 80 nm Au was deposited by thermal evaporation. Finally, 100 nm MgF2 was deposited on the glass side of the FTO substrate. The area of metal electrodes was 0.21 cm<sup>2</sup> (aperture area of mask 0.09973 cm<sup>2</sup> ) and 1.21 cm<sup>2</sup> (aperture area of mask 1.0053 cm<sup>2</sup> ) for the small- and large-area devices, respectively. 

For the mini-module fabrication, larger FTO substrates (5 3 5 cm<sup>2</sup> ) were first etched using laser scribing before cleaning to form four sub-cells with a width of 10 mm. SnO2 ETL, perovskite, and HTL layer deposition were the same as smallarea device. Before and after Au electrode evaporation, laser scribing was performed separately, and the total line width after three times laser scribing was 

Joule 8, 1691–1706, June 19, 2024 1701 

**ll** 

Article 

around 500 mm. The details of the laser width for the laser scribing can be found in our published work.<sup>54</sup> 

###### Device characterization 

XPS measurements were carried out using an EscaLab 250Xi, and the collected XPS signal was calibrated via carbon element. The PL was performed using an Edinburgh FLS 920 system. The excitation light wavelength was 488 and 600 nm, and the light was incident from the glass side and HTL side, respectively. PLQY was performed using Horiba NanoLOG-TCSPC, and the excitation light wavelength was set to be 488 nm with a light intensity of 0.1 kW m<sup>�2</sup> . The EQE-EL, TPV, TPC, and incident photon-to-electron conversion efficiency (IPCE) were obtained from the Cicci test platform, Italy. The C-V test was performed by the Keithley 4200A-SCS at a DC bias range of 0–1.2 V and a frequency of 10 kHz. The UV-vis spectra were obtained from GE Ultrospec9000. The NMR spectra were recorded on a JEOL ECS-400 and BRUKER AV-HD-800X. CV was carried out on a CHI660 electrochemical workstation using an Ag/Ag<sup>+</sup> electrode, platinum electrode, and glassy carbon electrode as the reference electrode, counter electrode, and working electrode, respectively. Differential scanning calorimetry and thermogravimetric analyses were performed on a TA Instruments, Q5000IR, under a N2 atmosphere with a heating rate of 10<sup>�</sup> C min<sup>�1</sup> . 

Sun J-V curves were obtained by testing the devices with aperture areas defined by dark masks with designated areas in air condition. A solar simulator (Newport, Oriel Class AAA, 94043 A) equipped with a 450 W xenon lamp (Newport 6279NS) was usedas light source, andthelight intensitywascalibrated using a siliconreferencediode (KG-3, Newport) to reach the AM 1.5 G. A digital source meter (Keithley Model 2400) was used for the current-voltage scanning. The scan rate of voltage was 200 mV s<sup>�1</sup> with a step voltage of 20 mV. The light-soaking stability of the devices without encapsulation was tested with a homemade platform using an LED light source under N2 atmosphere. The light intensity of LED source was adjusted to make sure that the device current density was equal to that under xenon lamp. The device temperature was set to be 25<sup>�</sup> C for the light stability test. For the thermal stability, the devices without encapsulation were placed on a 60<sup>�</sup> C hotplate in an Ar glovebox. For the dark-storage stability (�10% humidity), the devices without encapsulation were placed in a drying cabinet. 

###### Computational section 

All quantum chemical calculations involved were performed with the Gaussian16 program. The geometries of spiro-OMeTAD and T2 molecules were optimized using the B3LYP/6-31G* level in DFT. After obtaining a stable geometry, a higher accuracy B3LYP/6-31G** level was used for single point energy calculation to obtain the HOMO-LUMO energy level and orbital distribution of spiro-OMeTAD and T2 molecules. 

###### Crystal structure prediction 

Structures of spiro-OMeTAD and T2 optimized by Gaussian in the previous step were imported into Materials Studio. The Materials Studio polymorph prediction module was used to predict the crystal structures of spiro-OMeTAD and T2 under the dreiding force field, and 10 space groups with a large proportion were selected for crystallography structure prediction to obtain their total energy. After sorting the calculated crystal structures by total energy, the crystal structure with the lowest energy was selected. The crystal structure with the lowest energy of spiro-OMeTAD is the Cc space group and the Pna21 space group for T2. The molecular crystal unit cells of spiro-OMeTAD and T2 each contain 4 molecules. 

1702 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 

###### Cohesive energy calculation 

The calculation of cohesive energy was completed by the Vienna Ab-initio simulation package (VASP) program.<sup>57</sup> The plane wave basis set was adopted to expand the Kohn-Sham orbitals. The Perdew-Burke-Ernzerhof (PBE) generalized gradient approximation (GGA) functional was used to describe the exchange-correlation energy of valence electrons.<sup>58</sup> Dispersion forces are taken into account through DFT-D3.<sup>59</sup> 

The interaction potential between atomic nuclei and core electrons and valence electrons is described by the projected augmented wave (PAW) method.<sup>60</sup> The energy calculation parameters are as follows: only the gamma point is used for calculation, the energy convergence standard is 10<sup>�5</sup> eV, and the plane wave cutoff energy is 400 eV. 

The formula for calculating the cohesive energy Ecoh of molecular crystals is: 



<!-- Start of picture text -->
1<br>Ecoh = � �N Ebulk � Emol �<br><!-- End of picture text -->

Here, Ebulk is the total energy of the molecular crystal unit cell, N is the number of molecules in the unit cell, and Emol is the energy of a single molecule. The cohesive energy represents the energy gain in forming a crystal starting from its molecular components. VASP was used to calculate the molecular crystal energy and single molecular energy of spiro-OMeTAD and T2 and thus to obtain the cohesive energy. 

The models HTM/FAPbI3 and HTM/Au interface were prepared by positioning one spiro-OMeTAD or T2 in proximity of a perovskite or metal slab, respectively, and by optimizing the geometry of the system. In particular, the 5 layers (symmetric) PbI2 terminated, (100) FAPbI3 slab was initially relaxed. Then a molecular of either spiro-OMeTAD or T2 was deposited on the slab, and the geometry further relaxed. To avoid biasing the result due to an unfortunate choice in the initial configuration, the molecules were oriented so that as many oxygen atoms as possible were exposed to the FAPbI3 slab in the case of spiro-OMeTAD, while sulfur atoms were maximally exposed in the case of T2. Moreover, calculations were performed with several initial configurations of either molecule obtained by a systematic rotation of 20<sup>�</sup> around the axis passing by their barycenter and orthogonal to the FAPbI3 or Au slab. 

The DOSs of the two systems have been shifted to set the FAPbI3 valence band maximum to 0 eV. DOS, contribution of bulk and surface FAPbI3 and HTMs, and the corresponding analysis of contribution to individual orbitals were performed on data including spin-orbit coupling. 

###### Binding energy calculation 

The geometry of the complex composed of Li<sup>+</sup> and HTMs was optimized using the B3LYP-D3(BJ)/6-31G* level. After obtaining a stable geometry, a higher accuracy B3LYP-D3(BJ)/6-31G** level was used for single point energy calculation. 

The formula for calculating the binding energy Ebinding of Li<sup>+</sup> and HTMs is: 



<!-- Start of picture text -->
Ebinding = �ðEHTM+Li � EHTM � ELiÞ<br><!-- End of picture text -->

Here, EHTM + Li is the total energy of the complex composed of Li<sup>+</sup> and HTMs, and EHTM and ELi are the energies of HTMs and Li<sup>+</sup> in the complex state, respectively. 

Joule 8, 1691–1706, June 19, 2024 1703 

**ll** 

Article 

###### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2024.02.019. 

###### ACKNOWLEDGMENTS 

This work is financially supported by the National Natural Science Foundation of China (U23B20153), National Key Research and Development Program of China (2022YFB3803304), Tsinghua University Initiative Scientific Research Program (20221080065, 20223080044), Independent Innovative Research Program (ZK20230101), Department of Electrical Engineering, Tsinghua University, State Key Laboratory of Power System and Generation Equipment (no. SKLD21Z03 and SKLD20M03), Young Talents Thousand Program, State Grid Corporation of China, National Bio Energy Co. Ltd., grant no. 52789922000D. We acknowledge the ‘‘Explorer 100’’ cluster system of Tsinghua National Laboratory for Information Science and Technology for providing facility support. J.Z. thanks the support of the China Postdoctoral Science Foundation (2023TQ0176) and Shuimu Tsinghua Scholar Program. S.M. thanks University of Ferrara for financial support under the project ‘‘Optimization of perovskite films’’ to the FIR program. The CINECA Supercomputing center provided computational resources. 

###### AUTHOR CONTRIBUTIONS 

C.Y. conceived and directed the overall project. J.Z. and L.T. fabricated devices, conducted characterization, and wrote the manuscript. Y.L., R.H., and S.M. carried out theoretical calculations and data analysis. H.L. participated in manuscript writing and data analysis. X.L. participated in material synthesis. M.L., S.W., Y.Z., and C.J. carried out device characterization. R.H. and W.T. assisted with data analysis and discussion. 

###### DECLARATION OF INTERESTS 

C.Y., J.Z., L.T., M.L., Y.L., Y.Z., C.J., and H.L. are inventors on a Chinese patent application related to this work (no. CN 114181127A, filed 15 March 2022). 

Received: November 20, 2023 Revised: January 18, 2024 Accepted: February 23, 2024 Published: March 15, 2024 

###### REFERENCES 

1. Min, H., Lee, D.Y., Kim, J., Kim, G., Lee, K.S., Kim, J., Paik, M.J., Kim, Y.K., Kim, K.S., Kim, M.G., et al. (2021). Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450. https://doi. org/10.1038/s41586-021-03964-8. 

2. Li, X., Zhang, W., Guo, X., Lu, C., Wei, J., and Fang, J. (2022). Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437. https://doi.org/10. 1126/science.abl5676. 

3. Fei, C., Li, N., Wang, M., Wang, X., Gu, H., Chen, B., Zhang, Z., Ni, Z., Jiao, H., Xu, W., et al. (2023). Lead-chelating hole-transport layers for efficient and stable perovskite minimodules. Science 380, 823–829. https://doi.org/10.1126/ science.ade9463. 

4. Zhao, Y., Ma, F., Qu, Z., Yu, S., Shen, T., Deng, 71–76. https://doi.org/10.1126/science. H.X., Chu, X., Peng, X., Yuan, Y., Zhang, X., et al. abj2637. (2022). Inactive (PbI(2))(2)RbCl stabilizes perovskite films for efficient solar cells. Science 7. Zhang, C., Wei, K., Hu, J., Cai, X., Du, G., Deng, 377, 531–534. https://doi.org/10.1126/science., 531–534. https://doi.org/10.1126/science. https://doi.org/10.1126/science. J., Luo, Z., Zhang, X., Wang, Y., Yang, L., and abp8873.. Zhang, J. (2023). A review on organic hole 

- perovskite films for efficient solar cells. Science 7. Zhang, C., Wei, K., Hu, J., Cai, X., Du, G., Deng, 377, 531–534. https://doi.org/10.1126/science., 531–534. https://doi.org/10.1126/science. https://doi.org/10.1126/science. J., Luo, Z., Zhang, X., Wang, Y., Yang, L., and abp8873.. Zhang, J. (2023). A review on organic hole transport materials for perovskite solar cells: 

- 5. Park, S.M., Wei, M., Xu, J., Atapattu, H.R., structure, composition and reliability. Mater. Eickemeyer, F.T., Darabi, K., Grater, L., Yang, Today 67, 518–547. https://doi.org/10.1016/j. Y., Liu, C., Teale, S., et al. (2023). Engineering mattod.2023.06.009. ligand reactivity enables high-temperature operation of stable perovskite solar cells. 8. Rakstys, K., Igci, C., and Nazeeruddin, M.K. Science 381, 209–215. https://doi.org/10.1126/ 381, 209–215. https://doi.org/10.1126/, 209–215. https://doi.org/10.1126/ https://doi.org/10.1126/ (2019). Efficiency vs. stability: dopant-free hole science.adi4107.. transporting materials towards stabilized 

- operation of stable perovskite solar cells. 8. Rakstys, K., Igci, C., and Nazeeruddin, M.K. Science 381, 209–215. https://doi.org/10.1126/ 381, 209–215. https://doi.org/10.1126/, 209–215. https://doi.org/10.1126/ https://doi.org/10.1126/ (2019). Efficiency vs. stability: dopant-free hole science.adi4107.. transporting materials towards stabilized perovskite solar cells. Chem. Sci. 10, 6748– 

- 6. Zhang, F., Park, S.Y., Yao, C., Lu, H., Dunfield, 6769. https://doi.org/10.1039/c9sc01184f. S.P., Xiao, C., Uli�cna´, S., Zhao, X., Du Hill, L., Chen, X., et al. (2022). Metastable Dion9. Jeong, M., Choi, I.W., Go, E.M., Cho, Y., Kim, Jacobson 2D structure enables efficient and M., Lee, B., Jeong, S., Jo, Y., Choi, H.W., Lee, J., stable perovskite solar cells. Science 375, et al. (2020). Stable perovskite solar cells with 

   9. Jeong, M., Choi, I.W., Go, E.M., Cho, Y., Kim, M., Lee, B., Jeong, S., Jo, Y., Choi, H.W., Lee, J., et al. (2020). Stable perovskite solar cells with 

1704 Joule 8, 1691–1706, June 19, 2024 

**ll** 

##### Article 

W., Hagfeldt, A., and Gra¨tzel, M. (2016). Not all that glitters is gold: metal-migration-induced degradation in perovskite solar cells. ACS Nano 10, 6306–6314. https://doi.org/10.1021/ acsnano.6b02613. 

- efficiency exceeding 24.8% and 0.3-V voltage loss. Science 369, 1615–1620. https://doi.org/ 10.1126/science.abb7167. 

- 10. Zhang, S., Ye, F., Wang, X., Chen, R., Zhang, H., Zhan, L., Jiang, X., Li, Y., Ji, X., Liu, S., et al. (2023). Minimizing buried interfacial defects for efficient inverted perovskite solar cells. Science 380, 404–409. https://doi.org/10.1126/science. adg3755. 

- 11. Fu, Q., Tang, X., Liu, H., Wang, R., Liu, T., Wu, Z., Woo, H.Y., Zhou, T., Wan, X., Chen, Y., and Liu, Y. (2022). Ionic dopant-free polymer alloy hole transport materials for high-performance perovskite solar cells. J. Am. Chem. Soc. 144, 9500–9509. https://doi.org/10.1021/jacs. 2c04029. 

- 12. Du, M., Zhao, S., Duan, L., Cao, Y., Wang, H., Sun, Y., Wang, L., Zhu, X., Feng, J., Liu, L., et al. (2022). Surface redox engineering of vacuumdeposited NiOx for top-performance perovskite solar cells and modules. Joule 6, 1931–1943. https://doi.org/10.1016/j.joule. 2022.06.026. 

   32. Kim, J., Kim, K.S., and Myung, C.W. (2020). Efficient electron extraction of SnO2 electron transport layer for lead halide perovskite solar cell. npj Comput. Mater. 6, 100. https://doi. org/10.1038/s41524-020-00370-y. 

   33. Abramavicius, V., Pranculis, V., Melianas, A., Ingana¨s, O., Gulbinas, V., and Abramavicius, D. (2016). Role of coherence and delocalization in photo-induced electron transfer at organic interfaces. Sci. Rep. 6, 32914. https://doi.org/ 10.1038/srep32914. 

21. Yin, X., Song, Z., Li, Z., and Tang, W. (2020). Toward ideal hole transport materials: a review on recent progress in dopant-free hole transport materials for fabricating efficient and stable perovskite solar cells. Energy Environ. Sci. 13, 4057–4086. https://doi.org/10.1039/ d0ee02337j. 

   34. Yu, M., Bovet, N., Satterley, C.J., Bengio´ , S., Lovelock, K.R., Milligan, P.K., Jones, R.G., Woodruff, D.P., and Dhanak, V. (2006). True nature of an archetypal self-assembly system: mobile Au-thiolate species on Au(111). Phys. Rev. Lett. 97, 166102. 166102. https://doi.org/ 10.1103/PhysRevLett.97.166102. 

22. Calio´ , L., Kazim, S., Gra¨tzel, M., and Ahmad, S. (2016). Hole-transport materials for perovskite solar cells. Angew. Chem. Int. Ed. Engl. 55, 14522–14545. https://doi.org/10.1002/anie. 201601757. 

23. Xu, B., Zhang, J., Hua, Y., Liu, P., Wang, L., Ruan, C., Li, Y., Boschloo, G., Johansson, E.M.J., Kloo, L., et al. (2017). Tailor-making lowcost spiro[fluorene-9,9<sup>0</sup> -xanthene]-based 3D oligomers for perovskite solar cells. Chem 2, 676–687. https://doi.org/10.1016/j.chempr. 2017.03.011. 

   35. Tachibana, M., Yoshizawa, K., Ogawa, A., Fujimoto, H., and Hoffmann, R. (2002). Sulfurgold orbital interactions which determine the structure of alkanethiolate/Au(111) selfassembled monolayer systems. J. Phys. Chem. B 106, 12727–12736. https://doi.org/10.1021/ jp020993i. 

13. Zhang, T., Wang, F., Kim, H.-B., Choi, I.-W., Wang, C., Cho, E., Konefal, R., Puttisong, Y., Terado, K., Kobera, L., et al. (2022). Ionmodulated radical doping of spiro-OMeTAD for more efficient and stable perovskite solar cells. Science 377, 495–501. https://doi.org/10. 1126/science.abo2757. 

   24. Chiykowski, V.A., Cao, Y., Tan, H., Tabor, D.P., Sargent, E.H., Aspuru-Guzik, A., and 36. Herranz, M.A., Colonna, B., and Echegoyen, L. Berlinguette, C.P. (2018). Precise control of (2002). Metal ion recognition and molecular thermal and redox properties of organic holetemplating in self-assembled monolayers of transport materials. Angew. Chem. Int. Ed. cyclic and acyclic polyethers. Proc. Natl. Acad. Engl. 57, 15529–15533. https://doi.org/10. Sci. USA 99, 5040–5047. https://doi.org/10. 1002/anie.201810809. 1073/pnas.072658799. 

14. Kong, J., Shin, Y., Ro¨ hr, J.A., Wang, H., Meng, J., Wu, Y., Katzenberg, A., Kim, G., Kim, D.Y., Li, T.-D., et al. (2021). CO2 doping of organic interlayers for perovskite solar cells. Nature 594, 51–56. https://doi.org/10.1038/s41586021-03518-y. 

      37. Xue, Y., Li, X., Li, H., and Zhang, W. (2014). Quantifying thiol–gold interactions towards the efficient strength control. Nat. Commun. 5, 5,, 4348. https://doi.org/10.1038/ncomms5348. https://doi.org/10.1038/ncomms5348.. 

   25. Li, C., Wang, X., Bi, E., Jiang, F., Park, S.M., Li, 37. Xue, Y., Li, X., Li, H., and Zhang, W. (2014). Y., Chen, L., Wang, Z., Zeng, L., Chen, H., et al. Quantifying thiol–gold interactions towards (2023). Rational design of Lewis base molecules the efficient strength control. Nat. Commun. 5, 5,, for stable and efficient inverted perovskite 4348. https://doi.org/10.1038/ncomms5348. https://doi.org/10.1038/ncomms5348.. solar cells. Science 379, 690–694. https://doi. 38. Inkpen, M.S., Liu, Z.F., Li, H., Campos, L.M., 

   org/10.1126/science.ade3970. Neaton, J.B., and Venkataraman, L. (2019). Non-chemisorbed gold–sulfur binding prevails 

   26. Yoo, J.J., Wieghold, S., Sponseller, M.C., Chua, M.R., Bertram, S.N., Hartono, N.T.P., Tresback, in self-assembled monolayers. Nat. Chem. 11, J.S., Hansen, E.C., Correa-Baena, J.-P., Bulovi�c,�c,c, 351–358. https://doi.org/10.1038/s41557-019V., et al. (2019). An interface stabilized 0216-y. 

15. Sakai, N., Warren, R., Zhang, F., Nayak, S., Liu, J., Kesava, S.V., Lin, Y.H., Biswal, H.S., Lin, X., Grovenor, C., et al. (2021). Adduct-based p-doping of organic semiconductors. Nat. Mater. 20, 1248–1254. https://doi.org/10.1038/ s41563-021-00980-x. 

26. Yoo, J.J., Wieghold, S., Sponseller, M.C., Chua, M.R., Bertram, S.N., Hartono, N.T.P., Tresback, J.S., Hansen, E.C., Correa-Baena, J.-P., Bulovi�c,�c,c, V., et al. (2019). An interface stabilized perovskite solar cell with high stabilized efficiency and low voltage loss. Energy Environ. Sci. 12, 2192–2199. https://doi.org/10.1039/ C9EE00751B. 

   39. Ha¨kkinen, H. (2012). The gold–sulfur interface at the nanoscale. Nat. Chem. 4, 443–455. https://doi.org/10.1038/nchem.1352. 

16. Calio` , L., Salado, M., Kazim, S., and Ahmad, S. (2018). A generic route of hydrophobic doping in hole transporting material to increase longevity of perovskite solar cells. Joule 2, 1800–1815. https://doi.org/10.1016/j.joule. 2018.06.012. 

      40. Li, H., Zhou, J., Tan, L., Li, M., Jiang, C., Wang, S., Zhao, X., Liu, Y., Zhang, Y., Ye, Y., et al. (2022). Sequential vacuum-evaporated perovskite solar cells with more than 24% efficiency. Sci. Adv. 8, eabo7422. https://doi. org/10.1126/sciadv.abo7422. 

   27. Chen, B., Rudd, P.N., Yang, S., Yuan, Y., and Huang, J. (2019). Imperfections and their passivation in halide perovskite solar cells. Chem. Soc. Rev. 48, 3842–3867. https://doi. org/10.1039/C8CS00853A. 

17. Xu, B., Bi, D., Hua, Y., Liu, P., Cheng, M., Gra¨tzel, M., Kloo, L., Hagfeldt, A., and Sun, L. (2016). A low-cost spiro [fluorene-9,9<sup>0</sup> -xanthene]-based hole transport material for highly efficient solid-state dyesensitized solar cells and perovskite solar cells. Energy Environ. Sci. 9, 873–877. https://doi. org/10.1039/c6ee00056h. 

28. Ye, J., Byranvand, M.M., Martı´nez, C.O., Hoye, R.L.Z., Saliba, M., and Polavarapu, L. (2021). Defect passivation in lead-halide perovskite nanocrystals and thin films:toward efficient LEDs and solar cells. Angew. Chem. Int. Ed. Engl. 60, 21636–21660. https://doi.org/10. 1002/anie.202102360. 

   41. Park, N.-G., and Zhu, K. (2020). Scalable fabrication and coating methods for perovskite solar cells and solar modules. Nat. Rev. Mater. 5, 333–350. https://doi.org/10.1038/s41578019-0176-2. 

   42. Li, J., Wang, H., Chin, X.Y., Dewi, H.A., Vergeer, K., Goh, T.W., Lim, J.W.M., Lew, J.H., Loh, K.P., Soci, C., et al. (2020). Highly efficient thermally co-evaporated perovskite solar cells and minimodules. Joule 4, 1035–1053. https://doi.org/ 10.1016/j.joule.2020.03.005. 

18. Wang, S., Huang, Z., Wang, X., Li, Y., Gu¨ nther, M., Valenzuela, S., Parikh, P., Cabreros, A., Xiong, W., and Meng, Y.S. (2018). Unveiling the role of tBP-LiTFSI complexes in perovskite solar cells. J. Am. Chem. Soc. 140, 16720–16730. https://doi.org/10.1021/jacs.8b09809. 

29. Demadis, K.D., Hartshorn, C.M., and Meyer, T.J. (2001). The localized-to-delocalized transition in mixed-valence chemistry. Chem. Rev. 101, 2655–2686. https://doi.org/10.1021/ cr990413m. 

   43. Chen, S., Xiao, X., Gu, H., and Huang, J. (2021). Iodine reduction for reproducible and highperformance perovskite solar cells and modules. Sci. Adv. 7, eabe8130. https://doi. org/10.1126/sciadv.abe8130. 

19. Xiao, C., Zhang, F., Li, Z., Harvey, S.P., Chen, X., 30. Barbara, P.F., Meyer, T.J., and Ratner, M.A. Wang, K., Jiang, C.-S., Zhu, K., and Al-Jassim, (1996). Contemporary issues in electron M. (2020). Inhomogeneous doping of transfer research. J. Phys. Chem. 100, 13148– perovskite materials by dopants from hole13168. https://doi.org/10.1021/jp9605663. transport layer. Matter 2, 261–272. https://doi. org/10.1016/j.matt.2019.10.005.. 31. Newton, M.D., and Sutin, N. (1984). Electron 

- org/10.1016/j.matt.2019.10.005.. 31. Newton, M.D., and Sutin, N. (1984). Electron transfer reactions in condensed phases. Annu. 

- 20. Domanski, K., Correa-Baena, J.-P., Mine, N., Rev. Phys. Chem. 35, 437–480. https://doi.org/ Nazeeruddin, M.K., Abate, A., Saliba, M., Tress, 10.1146/annurev.pc.35.100184.002253. 

44. Ding, Y., Ding, B., Kanda, H., Usiobo, O.J., Gallet, T., Yang, Z., Liu, Y., Huang, H., Sheng, J., Liu, C., et al. (2022). Single-crystalline TiO2 nanoparticles for stable and efficient 

Joule 8, 1691–1706, June 19, 2024 1705 

#### **ll** 

##### Article 

perovskite modules. Nat. Nanotechnol. 17, 598–605. https://doi.org/10.1038/s41565-02201108-1. 

45. Chen, C.-W., Kang, H.-W., Hsiao, S.-Y., Yang, P.-F., Chiang, K.-M., and Lin, H.-W. (2014). Efficient and uniform planar-type perovskite solar cells by simple sequential vacuum deposition. Adv. Mater. 26, 6647–6652. https:// doi.org/10.1002/adma.201402461. 

46. Feng, J., Jiao, Y., Wang, H., Zhu, X., Sun, Y., Du, M., Cao, Y., Yang, D., and Liu, S. (2021). Highthroughput large-area vacuum deposition for high-performance formamidine-based perovskite solar cells. Energy Environ. Sci. 14, 3035–3043. https://doi.org/10.1039/ D1EE00634G. 

47. Almora, O., Aranda, C., Mas-Marza´, E., and Garcia-Belmonte, G. (2016). On Mott-Schottky analysis interpretation of capacitance measurements in organometal perovskite solar cells. Appl. Phys. Lett. 109, 173903. https://doi. org/10.1063/1.4966127. 

48. Wang, Z.S., Ebadi, F., Carlsen, B., Choy, W.C.H., and Tress, W. (2020). Transient photovoltage measurements on perovskite solar cells with varied defect concentrations and inhomogeneous recombination rates. Small Methods 4, 2000290. https://doi.org/10. 1002/smtd.202000290. 

49. Khenkin, M.V., Katz, E.A., Abate, A., Bardizza, G., Berry, J.J., Brabec, C., Brunetti, F., Bulovi�c, V., Burlingame, Q., Di Carlo, A., et al. (2020). Consensus statement for stability assessment and reporting for perovskite photovoltaics 

based on ISOS procedures. Nat. Energy 5, 35–49. https://doi.org/10.1038/s41560-0190529-5. 

50. Jeong, M., Choi, I.W., Yim, K., Jeong, S., Kim, M., Choi, S.J., Cho, Y., An, J.H., Kim, H.B., Jo, Y., et al. (2022). Large-area perovskite solar cells employing spiro-Naph hole transport material. Nat. Photonics 16, 119–125. https:// doi.org/10.1038/s41566-021-00931-7. 

51. Zhan, Y., Yang, F., Chen, W., Chen, H., Shen, Y., Li, Y., and Li, Y. (2021). Elastic lattice and excess charge carrier manipulation in 1D-3D perovskite solar cells for exceptionally longterm operational stability. Adv. Mater. 33, e2105170. https://doi.org/10.1002/adma. 202105170. 

52. Anaraki, E.H., Kermanpur, A., Steier, L., Domanski, K., Matsui, T., Tress, W., Saliba, M., Abate, A., Gra¨tzel, M., Hagfeldt, A., and Correa-Baena, J.-P. (2016). Highly efficient and stable planar perovskite solar cells by solutionprocessed tin oxide. Energy Environ. Sci. 9, 3128–3134. https://doi.org/10.1039/ C6EE02390H. 

53. Ahmad, S. (2022). Vapor deposition as a promising approach for the large-scale perovskite solar cell fabrication. iEnergy 1, 152. https://doi.org/10.23919/IEN.2022.0024. 

54. Tan, L., Zhou, J., Zhao, X., Wang, S., Li, M., Jiang, C., Li, H., Zhang, Y., Ye, Y., Tress, W., et al. (2023). Combined vacuum evaporation and solution process for high-efficiency large-area perovskite solar cells with exceptional reproducibility. Adv. Mater. 35, 

e2205027. https://doi.org/10.1002/adma. 202205027. 

55. Li, M., Zhou, J., Tan, L., Liu, Y., Wang, S., Jiang, C., Li, H., Zhao, X., Gao, X., Tress, W., et al. (2023). Brominated PEAI as multifunctional passivator for high-efficiency perovskite solar cell. Energy Environ. Materials 6, e12360. https://doi.org/10.1002/ eem2.12360. 

56. Wang, S., Tan, L., Zhou, J., Li, M., Zhao, X., Li, H., Tress, W., Ding, L., Graetzel, M., and Yi, C. (2022). Over 24% efficient MA-free CsxFA1�xPbX3 perovskite solar cells. Joule 6, 1344–1356. https://doi.org/10.1016/j.joule. 2022.05.002. 

57. Kresse, G., and Hafner, J. (1993). Abinitio molecular-dynamics for liquid-metals. Phys. Rev. B Condens. Matter 47, 558–561. https:// doi.org/10.1103/PhysRevB.47.558. 

58. Perdew, J.P., Burke, K., and Ernzerhof, M. (1996). Generalized gradient approximation made simple. Phys. Rev. Lett. 77, 3865–3868. https://doi.org/10.1103/PhysRevLett.77.3865. 

59. Grimme, S., Antony, J., Ehrlich, S., and Krieg, H. (2010). A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. J. Chem. Phys. 132, 154104. https://doi.org/10.1063/1.3382344. 

60. Blo¨ chl, P.E. (1994). Projector augmented-wave method. Phys. Rev. B Condens. Matter 50, 17953–17979. https://doi.org/10.1103/ PhysRevB.50.17953. 

1706 Joule 8, 1691–1706, June 19, 2024 

