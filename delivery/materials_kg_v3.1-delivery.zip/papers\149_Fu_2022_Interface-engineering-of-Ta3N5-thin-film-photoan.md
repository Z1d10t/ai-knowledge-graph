# Interface engineering of Ta3N5 thin film photoanode for highly efficient photoelectrochemical water splitting

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | Jie Fu, Ze-Yu Fan, Mamiko Nakabayashi, Huan-Xin Ju, N. Pastukhova, Ye-Quan Xiao, Chao Feng, N. Shibata et al. |
| DOI | 10.1038/s41467-022-28415-4 |
| 源文件 | 049_Fu_2022_Interface-engineering-of-Ta3N5-thin-film-photoan.pdf |

---


## ARTICLE 



> https://doi.org/10.1038/s41467-022-28415-4 **OPEN** 

# Interface engineering of Ta3N5 thin film photoanode for highly efficient photoelectrochemical water splitting 

Jie Fu<sup>1</sup> , Zeyu Fan<sup>1,2</sup> , Mamiko Nakabayashi 3, Huanxin Ju 4, Nadiia Pastukhova1, Yequan Xiao1, Chao Feng1, Naoya Shibata 3, Kazunari Domen 5,6 & Yanbo Li 1,2✉ 

Interface engineering is a proven strategy to improve the efficiency of thin film semiconductor based solar energy conversion devices. Ta3N5 thin film photoanode is a promising candidate for photoelectrochemical (PEC) water splitting. Yet, a concerted effort to engineer both the bottom and top interfaces of Ta3N5 thin film photoanode is still lacking. Here, we employ n-type In:GaN and p-type Mg:GaN to modify the bottom and top interfaces of Ta3N5 thin film photoanode, respectively. The obtained In:GaN/Ta3N5/Mg:GaN heterojunction photoanode shows enhanced bulk carrier separation capability and better injection efficiency at photoanode/electrolyte interface, which lead to a record-high applied bias photon-to-current efficiency of 3.46% for Ta3N5-based photoanode. Furthermore, the roles of the In:GaN and Mg:GaN layers are distinguished through mechanistic studies. While the In:GaN layer contributes mainly to the enhanced bulk charge separation efficiency, the Mg:GaN layer improves the surface charge inject efficiency. This work demonstrates the crucial role of proper interface engineering for thin film-based photoanode in achieving efficient PEC water splitting. 

> 1 Institute of Fundamental and Frontier Sciences, University of Electronic Science and Technology of China, Chengdu, China. 2 Yangtza Delta Region Institute (Huzhou), University of Electronic Science and Technology of China, Huzhou, China.<sup>3</sup> Institute of Engineering Innovation, The University of Tokyo, Tokyo, Japan.<sup>4</sup> PHI China Analytical Laboratory, CoreTech Integrated Limited, Nanjing, China.<sup>5</sup> Office of University Professors, The University of Tokyo, Tokyo, Japan.<sup>6</sup> Research Initiative for Supra-Materials (RISM), Shinshu University, Nagano, Japan.<sup>✉</sup> email: yanboli@uestc.edu.cn 

1 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 

rtificial photosynthesis that converts solar energy into sustainable energy and fuels is a highly desired solution to Ameet the increasing global energy demand and address the environmental issues related to the consumption of fossil fuels<sup>1–7</sup> . Semiconductor materials that absorb sunlight to generate electron-hole pairs are at the core of artificial photosynthetic devices<sup>8–11</sup> . Suppressing the bulk and interfacial nonradiative charge recombination in the semiconductor light absorbers is essential to achieve a high solar-to-fuel conversion efficiency<sup>12–17</sup> . Especially, the semiconductor/electrode and semiconductor/electrolyte interfaces play a decisive role in device performance because photogenerated charges must cross these interfaces to participate in the photosynthetic reactions. Most defects at the interfaces are high-dimensional deep-level defects, which usually have higher capture cross-sections than those of the point defects in the bulk of semiconductor<sup>18</sup> . Therefore, the nonradiative charge recombination at interfacial defect sites is detrimental to the device performance. In addition to interfacial defects, energy level alignment at the interfaces is also a key factor that affects the final device performance. Nonideal energy level alignment not only reduces device efficiency because of inefficient interfacial charge transfer, but it also deteriorates device stability due to interfacial charge accumulation which could promote self-oxidation/reduction of the semiconductor. Therefore, effective carrier management through interface engineering is essential to improve the efficiency and stability of photoelectrode for artificial photosynthesis<sup>17–19</sup> . 

Over the past decade, tremendous efforts have been devoted to interface engineering of various semiconductor photoelectrodes (e.g., Si<sup>20,21</sup> , α-Fe2O3<sup>22</sup> , BiVO4<sup>23</sup> , Cu2O<sup>24</sup> ) to improve their efficiency and stability through the passivation of interfacial defects or formation of hetero-/homojunctions. Ideally, the semiconductor thin film light absorbers should be sandwiched by a n-type electron transport layer (ETL) and a p-type hole transport layer (HTL) to achieve efficient charge separation, similar to the “n-i-p” device architecture commonly used in thin-film photovoltaics<sup>25</sup> . However, this type of “n-i-p” device architecture is rarely adopted in photoelectrochemical (PEC) devices<sup>26</sup> , especially for some of the emerging PEC materials. As one of the most promising photoanode materials for PEC water oxidation, Ta3N5 has a high theoretical solar-to-hydrogen (STH) efficiency of 15.9% owing to its wide absorption range (up to 600 nm) and proper band positions for water splitting. However, the full thermodynamic potential of Ta3N5 has yet to be unlocked. Although photocurrent approaching its theoretical value has been achieved<sup>14</sup> , the onset potential (usually >0.5 V vs. RHE) is still far higher than its theoretical limit (<0 V vs. RHE). Despite that various strategies have been employed to improve the bulk charge transfer efficiency, the applied bias photon-to-current efficiency (ABPE) of Ta3N5-based photoanode is still below 3.31%<sup>27,28</sup> . For pristine Ta3N5 thin film based photoanode, the ABPE is still limited to 2.25%<sup>29</sup> . Promising results have been achieved by interface engineering of Ta3N5 photoanodes with TiOx<sup>14</sup> , AlOx<sup>30</sup> , and GaN<sup>15,31,32</sup> to enhance the photocurrent, lower the onset potential, and improve the long-term stability. However, these previous studies only focus on either the Ta3N5/electrode or the Ta3N5/electrolyte interfaces. It is still lacking a concerted effort to engineer both interfaces to form a “n-i-p” device architecture that mimics the sandwich structure in perovskite solar cells. Such a synergistic interface engineering strategy is expected to further improve the efficiency of Ta3N5 thin film based photoanode. 

Herein, we propose to synergistically engineer the Ta3N5/ electrode and Ta3N5/electrolyte interfaces with an n-type indiumdoped gallium nitride (In:GaN) and a p-type magnesium-doped gallium nitride (Mg:GaN), respectively. The realization of the In:GaN/Ta3N5/Mg:GaN “n-i-p” heterostructure is possible 

because of the all-nitride compositions of the heterostructure that can be obtained by a single-step thermal nitridation process of their oxide precursors. The In:GaN and Mg:GaN interfacial layers not only facilitate selective charge extraction from Ta3N5 because of the desired energy band alignment of the formed “n-i-p” heterojunctions, they also passivate interfacial traps due to the formation of lattice-matched interfaces between Ta3N5 and the GaN layers. As a result, the ABPE is significantly improved from 2.29% for the pristine Ta3N5 photoanode to a record-high value of 3.46% for the In:GaN/Ta3N5/Mg:GaN photoanode, when both are modified with a highly active oxygen evolution reaction (OER) co-catalyst. Detailed mechanistic study reveals that the In:GaN layer mainly contributes to the enhanced bulk charge separation efficiency by selectively extracting photogenerated electrons from Ta3N5 through a mid-gap band generated by In doping in GaN. On the other hand, the Mg:GaN layer mainly contributes to improved surface charge injection efficiency by passivating surface traps in Ta3N5. These results demonstrate that interface engineering of semiconductor light absorbers with proper materials to construct band-aligned heterojunctions and passivate interface defects is an effective strategy to improve the solar-to-fuel conversion efficiency of artificial photosynthetic devices<sup>33</sup> . 

### Results and discussion 

Structural characterizations of In:GaN/Ta3N5/Mg:GaN heterostructure. In:GaN/Ta3N5/Mg:GaN heterostructure films were fabricated by one-step thermal nitridation process of InOx-GaOx/ TaOx/Mg:GaOx thin films deposited by electron-beam (EB) evaporation and atomic layer deposition (ALD). Figure 1 shows the schematic diagram for the preparation of In:GaN/Ta3N5/Mg:GaN thin films. The detailed procedures are given in Methods. The multilayer structure of the InOx-GaOx/TaOx/Mg:GaOx precursor film was resolved by using Auger electron spectroscopy (AES) in Supplementary Fig. 1. The scanning electron microscopy (SEM) images and X-ray diffraction (XRD) pattern of the prepared In:GaN/Ta3N5/Mg:GaN thin film on Nb substrate are shown in Supplementary Fig. 2. Polycrystalline film with grain size of several hundred nanometers and some small pores can been seen within the grains, which is characteristic of Ta3N5 thin film converted from TaOx precursor film due to volume contraction in the nitridation process<sup>29</sup> .The layered structure was not directly observed from the cross-sectional SEM image because of the thin thicknesses of the In:GaN (~5 nm) and Mg:GaN (~20 nm) layers and the lack of contrast between the three layers formed in a single-step nitridation process. Scanning transmission electron microscopy (STEM) was employed to further characterize the structure of the sample. Figure 2a shows the STEM energy dispersive x-ray spectroscopy (EDS) elemental mapping of the cross section of In:GaN/Ta3N5/Mg:GaN film deposited on Nb substrate and Fig. 2b shows the corresponding annular dark-field (ADF) STEM image. The STEM image and the EDS mapping of the metallic elements were overlapped in Fig. 2c. The thickness of the Ta3N5 layer is approximately 600 nm. A thin Ga-rich layer (~20 nm) on the top of the Ta3N5 layer was clearly revealed by the EDS mapping. However, the In:GaN layer at the bottom interface of the Ta3N5 layer was not clearly observed by EDS mapping. Therefore, AES cross sectional mapping and depth profile was employed to further characterize the sample (Supplementary Fig. 3). Similar to the EDS mapping results, AES mapping also only revealed the top Ga-rich layer, but not the bottom one. Nevertheless, AES depth profile clearly revealed the presence of a Ga-containing layer at the bottom interface of the Ta3N5 layer. It should be noted that Mg and In elements were also not detectable by either EDS or AES due to their low 

2 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 



<!-- Start of picture text -->
1) EB evaporation<br>2) ALD of GaOx<br>of InOx<br>Nb/InOx<br>Nb/InOx-GaOx<br>Nb foil<br>3) EB evaporation<br>of TaOx<br>Nb/In:GaN/Ta3N5/Mg:GaN Nb/InOx-GaOx/TaOx<br>5) Nitridation 4) ALD of Mg:GaOx<br>Nb/InOx-GaOx/TaOx/Mg:GaOx<br><!-- End of picture text -->

Fig. 1 Schematic diagram for the preparation of In:GaN/Ta3N5/Mg:GaN heterostructure thin film. 1 EB evaporation of InOx thin layer on Nb substrate. 2 ALD of GaOx layer using TEG as precursor. 3 EB evaporation of TaOx layer. 4 ALD of Mg:GaOx layer using MgCp2 and TEG as precursors. 5 One-step thermal nitridation in NH3 atmosphere at 1000 °C for 6 h. 



<!-- Start of picture text -->
a Ta N Nb d<br>Mg:GaN<br>Ta3N5<br>In:GaN<br>Ga Mg In<br>300 nm<br>e<br>b c<br>4 nm<br><!-- End of picture text -->

Fig. 2 Structural properties of In:GaN/Ta3N5/Mg:GaN heterostructure thin film on Nb substrate. a Cross-sectional STEM-EDS elemental mappings of Ta, N, Nb, Ga, Mg, and In. b Annular dark-field STEM image of the cross section of the sample. c Overlapping the AFD STEM image with the EDS mappings of the metallic elements. d Bright field TEM image of the film. e HRTEM image showing the lattice fringes of Ta3N5 with a spacing of 0.256 nm. 

concentrations. The homogenous mapping results of Mg and In in Fig. 2a were likely resulted from noise spectra of the EDS instrument. Figure 2d shows the TEM image of the Nb/In:GaN/ Ta3N5/Mg:GaN film, which exhibits intimate contact between 

each layers. The high-resolution TEM (HRTEM) image in Fig. 2e reveals lattice fringes with a spacing of 0.256 nm, corresponding to the (310) plane of Ta3N5. The lattice spacing is very close to that of GaN (002) plane (0.259 nm)<sup>34</sup> , making it possible to form 

3 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 



<!-- Start of picture text -->
a b c<br>Mg:GaN In:GaN 1.65 eV<br>In:GaN+Ta3N5+Mg:GaN 3.1 eV<br>2.81 eV<br>Ta3N5+Mg:GaN<br>In:GaN+Ta3N5<br>Ta3N5<br>Ta3N5 (JCPDS no. 89-5200)<br>10 20 30 40 50 60 70 35 3.6 3.4 3.2 3.0 2.8 2.6 2.4 3.0 2.7 2.4 2.1 1.8 1.5<br>2  (degree) Photon energy (eV) Photon energy (eV)<br>d e f<br>Mg:GaN In:GaN<br>ECutoff 1.99 eV ECutoff 2.02 eV<br>3.0 2.5 2.0 1.5 1.0<br>3.0 2.5 2.0 1.5 1.0 Binding energy (eV)<br>Binding energy (eV) 17.36 eV<br>17.61 eV<br>20 15 10 5 0 20 15 10 5 0<br>Binding energy (eV) Binding energy (eV)<br>g In:GaN/Ta3N5/Mg:GaN h =0.862 ns Ta3N5 Ex: 375 nm i In:GaN/Ta3N5/Mg:GaN<br>In:GaN/Ta3N5 =0.370 Fitted De: 475 nm In:GaN/Ta3N5<br>Ta3N5/Mg:GaN Ta3N5/Mg:GaN<br>Ta3N5 Ta3N5<br>=4.054 ns Ta3N5/Mg:GaN<br>=0.486 Fitted Ex: 510 nm<br>T: 10 K<br>Ex: 375 nmT: 10 K =3.837 ns =0.477 In:GaN/TaFitted 3N5<br>=4.452 ns In:GaN/Ta3N5/Mg:GaN<br>=0.504 Fitted<br>400 450 500 550 600 650 700 0 20 40 60 80 100 550 600 650 700 750 800 850<br>Wavelength (nm) Time (ns) Wavelength (nm)<br>) )<br>)<br>stin stin<br>stinu . bru . bru .<br>(bra (a (a<br> ytis  ytis<br> ytisItnen )( G200Na Lni Ptne ni LPtne<br>)stinbrau . )( ytisstinbIterannu . )bstinrau. )( ytisstinbItranenu .<br>( ytis ( ytis<br>n n<br>Iten Iten<br>) )<br>stin ) stin<br>u stin u<br> . u  .<br>bra br . bra<br>(a<br>( ytis ( ytis<br>n  ytis n<br>ni te tne ni te<br>L ni  L<br>P L P<br>P<br><!-- End of picture text -->

Fig. 3 Spectroscopic characterizations of GaN and Ta3N5-based thin films. a XRD patterns of different Ta3N5-based films deposited on quartz glass substrate. The narrow scan XRD patterns on the right side shows the (002) diffraction peaks of GaN. b PL spectra of Mg:GaN film deposited on quartz glass substrate under 270 nm LED excitation. and c PL spectra of In:GaN film deposited on quartz glass substrate under 375 nm laser excitation. d UPS spectrum of Mg:GaN deposited on Nb substrate. e UPS spectrum of In:GaN deposited on Nb substrate. f Schematic diagram of band structure for In:GaN/ Ta3N5/Mg:GaN film determined from UPS and UV–vis absorption measurements. g PL spectra and h TRPL spectra of four Ta3N5-based films on quartz glass substrate measured at 10 K under 375 nm laser excitation. i PL spectra of four Ta3N5-based films measured at 10 K under 510 nm laser excitation. 

a lattice-matched interface between Ta3N5 and GaN, thus reducing the interface trap density, as demonstrated below. 

Spectroscopic characterizations. XRD patterns of Ta3N5-based films with different layered structures deposited on quartz glass are exhibited in Fig. 3a. The main diffraction peaks can all be assigned to those of Ta3N5. No obvious change in the diffraction peaks is observed for films with different layered structures, indicating that the crystallinity of the Ta3N5 layer is well maintained after adding the GaN layers. However, a close-up of the peak at ~35° in the right panel of Fig. 3a reveals a distinct shoulder peak at ~34.7°, corresponding to the diffraction peak of GaN (002), when Mg:GaN layer is formed on top of the Ta3N5 film<sup>15</sup> . This indicates that these GaN-based layers have been successfully synthesized in a single-step nitridation process. To further confirm that the GaN layers can be formed by nitridation of GaOx precursor films, In:GaN and Mg:GaN thin films were deposited directly on quartz glass substrates by similar processes. 

The XRD patterns of the In:GaN and Mg:GaN films in Supplementary Fig. 4 match that of hexagonal GaN (JPCDS no. 500792), while a weak peak belonging to GaInO3 impurity phase at ~35.1° is found in the In:GaN film. A slight peak shift to lower angle is observed the In:GaN film, indicating In is incorporated into GaN lattice because the ionic radius of In<sup>3+</sup> is large than that of Ga<sup>3+</sup> . The presence of Mg and In in the synthesized GaN films is further confirmed by X-ray photoelectron spectroscopy (XPS) results (Supplementary Figs. 5 and 6). Photoluminescence (PL) spectroscopy was employed to investigate the fluorescence properties of Mg:GaN and In:GaN films (Fig. 3b, c). The PL spectrum of Mg:GaN film can be deconvolved into two sub-peaks centered at ~3.1 and ~2.8 eV, which are typical fluorescence emission peaks related to the isolated MgGa centers and Mgrelated deep levels, respectively<sup>35</sup> . In contrast, the PL spectrum of In:GaN film shows a emission peak at ~1.65 eV, which suggests In-doping induces mid-gap states in GaN. The In-induced midgap states could be beneficial to electron transport from the 

4 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 

Ta3N5 light absorber through the In:GaN layer to the Nb electrode, as shown below. 

The band positions of the Mg:GaN and In:GaN films were determined using ultraviolet photoelectron spectroscopy (UPS) (Fig. 3d, e). By subtracting the cut-off energies (ECutoff) of the secondary electrons from the He I excitation energy (21.22 eV), the Fermi levels of Mg:GaN and In:GaN were obtained at 3.61 and 3.86 eV below the vacuum level, respectively. The lowbinding energy edges of the UPS spectra reveal that the valence bands of Mg:GaN and In:GaN are 1.99 and 2.02 eV below their Fermi levels, respectively. The Tauc plots of the absorption spectra revealed that the optical bandgaps of the In:GaN and Mg:GaN films are both ~3.30 eV (Supplementary Fig. 7). Combining these data with the band positions of pristine Ta3N5 obtained in our previous study<sup>27</sup> , the band alignment of the Nb/In:GaN/Ta3N5/Mg:GaN layered structure is obtained and shown in Fig. 3f. The band alignment shows that pristine GaN is not suitable for electron extraction from Ta3N5 because its conduction band lies too high above that of Ta3N5. However, Indoping induces a mid-gap band at around −4.23 eV in In:GaN, which could serve as a conductive pathway for electrons. The ability of the In-induced inter-gap state to act as a channel for electrons was further verified by measuring cyclic voltammetry of a compact In:GaN film in the presence of a scavenger (Supplementary Fig. 8). Such a conduction mechanism through inter-gap defect states has previously been demonstrated with amorphous TiO2 coated on Si, GaAs, and GaP photoanodes<sup>1</sup> . Consequently, the photon-generated electrons and holes in the Ta3N5 layer can be efficiently extracted through the In:GaN and Mg:GaN layers, respectively. 

To reveal the effect of the In:GaN underlayer and Mg:GaN overlayer on the carrier dynamics of Ta3N5, low-temperature and time-resolved PL (TRPL) spectroscopies were employed to study samples with different layered structures. Due to the strong optical anisotropy of its orthorhombic lattice, Ta3N5 shows two intrinsic bandgaps of ~2.1 eV along the a-axis and ∼2.6 eV along the b- and c-axes<sup>29</sup> . We found that at low temperature (10 K) under 375-nm laser excitation the PL of Ta3N5 was dominated by an emission peak at ~475 nm (~2.6 eV), corresponding to the near band edge radiative recombination along the b- and c-axes. Therefore, the intensities and lifetimes of this peak were measured to probe the carrier dynamics in Ta3N5-based samples with different layered structures. The steady-state PL spectra in Fig. 3g show that the PL intensity is quenched when Ta3N5 film is modified with either In:GaN or Mg:GaN layers, suggesting their ability to extract photocarriers from Ta3N5. Moreover, the TRPL results reveal that the In:GaN and Mg:GaN layers also play a role in defect passivation besides carrier extraction. All the TRPL decay curves in Fig. 3h are well-fitted with a stretchedexponential decay (Supplementary Fig. 9). This decay law is typically observed in disordered systems and it is believed to be due to the dispersion diffusion of photoexcited carriers<sup>36</sup> . The degree of disorder depends on the trap density and is measured by the stretching component β (0 < β < 1). The higher the β value the less disorder (lower trap density) the semiconductor<sup>37,38</sup> . The details about the stretched-exponential decay fitting are given in Supplementary Note 1. The fitted results in Supplementary Table 1 show that both the average lifetime < τ> and the stretching component β increase significantly when the Ta3N5 film is modified with In:GaN and Mg:GaN layers. This indicates the trap density of the Ta3N5 layer is lowered by the interface and surface modification with the In:GaN and Mg:GaN layers. To further clarify the change of trap density in these samples, defectrelated PL spectra were measured under excitation of a 510-nm laser at 10 K (Fig. 3i). All the PL spectra could be deconvolved into two distinctive emission peaks centered at around 720 and 

820 nm (Supplementary Fig. 10), which are ascribed to defect emissions of nitrogen vacancies and reduced Ta<sup>3+</sup> defects, respectively, according to our previous study<sup>29</sup> . The intensity of the defect-related PL emission significantly decreases with In:GaN and Mg:GaN modification, which indicates the trap density in the Ta3N5 layer is reduced. In contrast to the abrupt lattice termination on the surface of bare Ta3N5 layer, the In:GaN and Mg:GaN modification resulted in lattice-matched GaN/Ta3N5 interfaces, thus reducing the defect density near the interfaces<sup>15</sup> . 

PEC performance of In:GaN/Ta3N5/Mg:GaN photoanode. The PEC performance of Ta3N5 films with or without interface engineering with In:GaN and Mg:GaN layers was tested after modifying their surfaces with a borate-intercalated nickel cobalt iron oxyhydroxide (NiCoFe-Bi) OER co-catalyst. The co-catalyst modification is essential to improve the activity and stability of the photoanodes (Supplementary Fig. 11). Figure 4a shows the photocurrent-potential (J–V) curves for Ta3N5-based photoanodes with different layer structures. The detailed parameters of the J–V curves were listed in Supplementary Table 2. The Ta3N5 photoanode exhibited a relatively low photocurrent density of 7.5 mA cm<sup>−2</sup> at 1.23 V vs. RHE. With either In:GaN or Mg:GaN modification, the photocurrent densities of the photoanodes were increased to over 8 mA cm<sup>−2</sup> at 1.23 V vs. RHE and the fill factors of the J–V curves were improved obviously. The most significant enhancement in photocurrent density was achieved when both the bottom and top interfaces of the Ta3N5 film were modified with In:GaN and Mg:GaN, yielding a value of 9.3 mA cm<sup>−2</sup> at 1.23 V vs. RHE. The enhancement was ascribed to the effective charge separation and interface defect passivation effect of the In:GaN and Mg:GaN layers. The photocurrent onset potential, measured at a steady-state photocurrent density of ~20 μA cm<sup>−2</sup> (Fig. 4b), was also found to shift cathodically from 0.47 V vs. RHE for the Ta3N5 photoanode to 0.38 V vs. RHE for the In:GaN/ Ta3N5/Mg:GaN photoanode. Consequently, a maximum ABPE of 3.46% was achieved for the In:GaN/Ta3N5/Mg:GaN photoanode (Fig. 4c), which is the highest ABPE reported so far for Ta3N5based photoanode, to the best of our knowledge (Supplementary Fig. 12). The In:GaN/Ta3N5/Mg:GaN photoanodes samples also showed good reproducibility in PEC performance: the average ABPE for a batch of eight samples is 3.31% with a standard deviation of 0.11% (Supplementary Fig. 13). 

The stability of NiCoFe-Bi modified Ta3N5 and In:GaN/Ta3N5/ Mg:GaN photoanodes was tested at 1.0 V vs. RHE in 1 M KOH under simulated sunlight. The photocurrent of the Ta3N5 photoanode decreased continuously due to the self-oxidation of the Ta3N5 surface (Supplementary Fig. 14). In contrast, the In:GaN/Ta3N5/Mg:GaN photoanode generated a stable photocurrent at ~8.9 mA cm<sup>−2</sup> for 160 min (Fig. 4d). The improved stability is ascribed to the passivation effect of the Mg:GaN layer, which prevents the self-oxidation of the Ta3N5 surface, a key factor of performance degradation in Ta3N5 photoanode<sup>19</sup> . For longer-term stability test, the In:GaN/Ta3N5/Mg:GaN photoanode maintained 80% of its initial photocurrent after 10 h and 70% after 15 h (Supplementary Fig. 15). Figure 4e plots the wavelength dependence of the incident photon-to-current conversion efficiency (IPCE) of the In:GaN/Ta3N5/Mg:GaN photoanode. The IPCE values were between 70% and 90% in a broad spectrum range of 400–550 nm, which indicates the impressive photon conversion efficiency of In:GaN/Ta3N5/Mg:GaN photoanode in the visible range. An integrated photocurrent density of ~9.0 mA cm<sup>−2</sup> was obtained by integrating the IPCE values over the standard AM 1.5 G solar spectrum, which matches well with the measured photocurrent density in Fig. 4a (~8.9 mA cm<sup>−2</sup> ). Figure 4f shows the amount of O2 evolved from the In:GaN/ 

5 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 



<!-- Start of picture text -->
a b c<br>10 In:GaN/TaIn:GaN/Ta33NN55/Mg:GaN 0.4 In:GaN/Ta3N5/Mg:GaN 4 In:GaN/TaIn:GaN/Ta33NN55/Mg:GaN 3.46%<br>8 TaTa33NN55/Mg:GaN 0.3 440 mV 3 TaTa33NN55/Mg:GaN 2.91%<br>2.89%<br>6 0.2 420 mV 2 2.29%<br>4 0.1 400 mV<br>380 mV<br>360 mV 380 mV 1<br>2 0.0<br>0 -0.1 0<br>0.4 0.6 0.8 1.0 1.2 0 2 4 6 8 10 0.4 0.6 0.8 1.0 1.2<br>Potential (V vs. RHE) Time (min) Potential (V vs. RHE)<br>d e 100 10 f<br>10 1.0 V vs. RHE 0.06 200 Gas chromatographye - /4<br>8 In:GaN/Ta3N5/Mg:GaN 80 8<br>150<br>6 60 0.04 6<br>4 Ta3N5 40 4 100<br>0.02<br>2 20 2 50<br>0 0 0.00 0 0<br>0 20 40 60 80 100 120 140 160 350 400 450 500 550 600 650 0 20 40 60 80 100 120 140 160<br>Time (min) Wavelength (nm) Time (min)<br>-2)<br>(mA cm -2)(mA cm )%(<br> ytis  ytis EP<br>d tne d tne BA<br>n n<br>e e<br>rr rr<br>u u<br>C C<br>-2)(mA cm )% )-2mol cm<br> ytisn ( CE (n<br>de PI oit<br> tnerr uloev<br>Cu O2<br>Solar photocurrent (mA cm) nm -2-1 Integreted photocurrent (mA cm)-2<br><!-- End of picture text -->

Fig. 4 PEC performance of the In:GaN/Ta3N5/Mg:GaN photoanode on Nb substrate. a J–V curves of Ta3N5-based photoanodes with different layered structures. All the photoanodes were modified with NiCoFe-Bi co-catalyst and tested in 1 M KOH electrolyte under AM 1.5 G illumination. b The steadystate photocurrent of In:GaN/Ta3N5/Mg:GaN photoanode under low-bias conditions. c ABPE curves calculated from the J-V curves in a. d Stability of the pristine Ta3N5 and In:GaN/Ta3N5/Mg:GaN photoanodes measured at an applied potential of 1.0 V vs. RHE. e IPCE spectrum of the In:GaN/Ta3N5/Mg:GaN photoanode at 1.0 V vs. RHE and the corresponding solar photocurrent and integrated photocurrent calculated using the standard AM 1.5 G solar spectrum (ASTM G173-03). f Amount of O2 evolved from the In:GaN/Ta3N5/Mg:GaN photoanode under an applied potential of 1.0 V vs. RHE. 

Ta3N5/Mg:GaN photoanode quantified by the gas chromatography (GC). The dark line plots a quarter of the electron numbers (e<sup>−</sup> /4) calculated from the measured photocurrent (Supplementary Fig. 16), which gives the expected amount of O2 evolution assuming 100% Faraday efficiency. The GC data points align well with the calculated e<sup>−</sup> /4 line, indicating nearly unity Faraday efficiency was achieved with the In:GaN/Ta3N5/Mg:GaN photoanode. This result demonstrates that the measured photocurrent is indeed contributed by OER and the ABPE calculated from J–V curve does represent the STH conversion efficiency of the In:GaN/Ta3N5/Mg:GaN photoanode. 

To further clarify the roles of In and Mg doping in the GaN layers in the heterojunction structure, pristine GaN layers were employed for interface engineering for comparison. The GaN/ Ta3N5 photoanode showed a degraded PEC performance compared with the Ta3N5 photoanode (Supplementary Fig. 17a), which is likely due to the mismatched band alignment that formed a large potential barrier on the back of the photoanode. In contrast, the In:GaN/Ta3N5 photoanode showed obviously improved PEC performance compared with the Ta3N5 photoanode, which is ascribed to the generation of a conductive midgap band in GaN by In doping, as revealed in Fig. 2f. The Ta3N5/ GaN photoanode showed a slightly enhanced PEC performance compared with Ta3N5 photoanode (Supplementary Fig. 17b), consistent with the previous report<sup>15</sup> . Nevertheless, the improvement was not as great as that achieved with Ta3N5/Mg:GaN photoanode. These results demonstrate that proper doping of the interfacial GaN layers is crucial to improve the carrier separation efficiency and hole injection efficiency of Ta3N5 photoanode. 

Electrochemical characterizations of the heterostructure. Surface injection efficiency (ηinj) and bulk charge separation efficiency (ηbulk) were determined to further investigate the effect of In:GaN and Mg:GaN layers. The details about the calculation of 

ηinj and ηbulk are given in Supplementary Note 2. ηbulk represents the fraction of photo-generated holes that arrive at the photoanode/electrolyte without recombination in the bulk, while ηinj denotes the fraction of those holes that successfully inject into the electrolyte for water oxidation. The J–V curves of four different photoanodes were measured in 1 M KOH electrolyte with or without 0.5 M H2O2 as a hole scavenger (Supplementary Fig. 18). The absorption photocurrent density (Jabs) of each photoanode was calculated based on the UV–visible absorption spectrum by assuming 100% absorbed photon-to-current conversion efficiency (Supplementary Fig. 19). The potential dependent ηbulk curves in Fig. 5a reveal that the improvement of ηbulk is mainly attributed to the modification of In:GaN at the bottom interface of Ta3N5 film. This is reasonable as In:GaN selectively extracts photogenerated electrons from the Ta3N5 film, thus improving the bulk electron-hole separation efficiency. Meanwhile, the potential dependent ηinj curves in Fig. 5b reveal that the improvement of ηinj is mainly originated from the modification of Mg:GaN on the surface of Ta3N5 film. These results have helped us distinguish the respective role of In:GaN and Mg:GaN in enhancing the PEC performance of the heterostructure photoanode. 

Photoelectrochemical impedance spectroscopy (PEIS) was employed to compare the charge transfer processes between Ta3N5 and In:GaN/Ta3N5/Mg:GaN photoanodes<sup>14,22</sup> . The PEIS Nyquist plots in Fig. 5c show that the radius of the semicircle curve for In:GaN/Ta3N5/Mg:GaN photoanode dramatically reduces compared with that of Ta3N5 photoanode, which indicates the improvement of charge separation efficiency and injection efficiency. A typical two-RC-unit equivalent circuit model was used to fit the Nyquist plot of Ta3N5 photoanode, while a more complex model with the addition of a heterojunction RC-unit was used to fit the Nyquist plot of In:GaN/Ta3N5/ Mg:GaN photoanode (Supplementary Fig. 20)<sup>22</sup> . The PEIS Nyquist plots were well-fitted using the equivalent circuit models 

6 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 



<!-- Start of picture text -->
a b c<br>100 300<br>In:GaN/Ta3N5/Mg:GaN<br>80 250 Ta3N5<br>80 Fitting<br>60 200<br>60<br>150<br>40<br>40<br>In:GaN/Ta3N5/Mg:GaN InGaN/Ta3N5/Mg:GaN 100<br>20 In:GaN/TaTa3N5/Mg:GaN3N5 20 InGaN/TaTa3N5/Mg:GaN3N5 50<br>Ta3N5 Ta3N5<br>0 0 0<br>0.4 0.6 0.8 1.0 1.2 0.4 0.6 0.8 1.0 1.2 0 100 200 300 400 500<br>Potential (V vs. RHE) Potential (V vs. RHE) Z' (ohm)<br>d 2.5 e 2.0 f 10 2<br> 1. 0 kHz Ta3N5  1. 0 kHz In:GaN/Ta3N5/Mg:GaN In:GaN/Ta3N5/Mg:GaN<br> 2. 0 kHz  2. 0 kHz Ta3N5<br>2.0  3. 0 kHz  3. 0 kHz<br>1.5<br>10 1<br>1.5<br>1.0<br>1.0 10 0<br>~0.3 s<br>0.5<br>0.5<br>0.15 V  0.77 V  0.05 V 0.37 V  10 -1 ~0.15 s<br>0.0 0.0<br>-0.5 0.0 0.5 1.0 -0.5 0.0 0.5 1.0 0.6 0.5 0.4 0.3 0.2<br>Potential (V vs. RHE) Potential (V vs. RHE) VOCP (V vs. RHE)<br>)m<br>h<br>o<br> (%)bulk  (%)inj ( ''Z-<br>4) 4)<br>-2 cm -2 cm<br>9 F 9 F  (s)n<br>2 (10 2 (10<br>1/C 1/C<br><!-- End of picture text -->

Fig. 5 Electrochemical characterizations of the Ta3N5-based thin films with different layered structures on Nb substrate. a Bulk charge separation efficiency (ηbulk). b Surface injection efficiency (ηinj). c PEIS of Ta3N5 and In:GaN/Ta3N5/Mg:GaN photoanodes measured in 1 M KOH electrolyte at 1.0 V vs. RHE under AM 1.5 G illumination. Red lines show the fitting of the PEIS data. M-S plots of d, Ta3N5 photoanode, and e In:GaN/Ta3N5/Mg:GaN photoanode. The M-S plots were measured in the dark without co-catalyst. f Carrier lifetimes derived from OCP-decay curves at the light on-off transient for Ta3N5 and In:GaN/Ta3N5/Mg:GaN photoanodes. 

and the detailed fitting parameters are listed in Supplementary Table 3. The trapping resistance (Rtrap) and the charge transfer resistance (Rct) of the In:GaN/Ta3N5/Mg:GaN photoanode are 6.0 and 23.0 Ω, respectively. In contrast, the Ta3N5 photoanode shows a significantly larger Rtrap and Rct values of 449.3 and 503.7 Ω, respectively. Although additional resistance (Rhete) is generated in the In:GaN/Ta3N5/Mg:GaN photoanode due to the heterojunctions, it is relatively small (1.13 Ω). These results demonstrate that the separation and injection efficiencies are indeed improved by interface engineering with the In:GaN and Mg:GaN layers. 

Mott-Schottky (M-S) analysis was employed to probe the change of surface energetics of the photoanodes with and without interface engineering. The M-S plot of Ta3N5 photoanode in Fig. 5d shows that the flat-band potential is at 0.15 V vs RHE. However, the slope of the M-S plot changes at higher applied potential region (>0.77 V vs RHE), suggesting that the band bending develops to a different extent in different potential regions (Supplementary Fig. 21a). At low potential region (<0.77 V vs RHE), the Fermi level pinning due to the existence a distribution of surface states causes the band bending to develop in a lesser extent while part of the applied potential drops at the Helmholtz layer<sup>39</sup> . At high potential region (>0.77 V vs RHE), the decreased density of surface states allows for the band bending to develop in a higher extent, leading to a larger slope in the M-S plot. For the In:GaN/Ta3N5/Mg:GaN photoanode in Fig. 5e, the flat-band potential shifts cathodically to 0.05 V vs RHE while the transition of the two slopes happens at 0.37 V vs RHE. The lower applied potential to overcome the Fermi level pinning suggests there is a lower density of surface states due to the passivation effect of the Mg:GaN layer. The band bending can be developed in a larger extend at lower applied potential region, thus reducing the bias-potential requirement for the water oxidation process (Supplementary Fig. 21b). The open circuit potential (OCP) 

decay profile was employed to further demonstrate the passivation of interfacial traps by interface engineering<sup>40–42</sup> . Supplementary Fig. 22 shows the OCP decay profiles of Ta3N5 and In:GaN/Ta3N5/Mg:GaN photoanodes. Compared with Ta3N5 photoanode, the amplitude of the OCP decay is significantly larger in In:GaN/Ta3N5/Mg:GaN photoanode, which indicates larger band bending at photoanode/electrolyte interface under illumination<sup>41</sup> . The carrier lifetimes are derived from the OCP decay curves (Supplementary Note 3) and plotted against OCP in Fig. 5f. At the transient when illumination was switched off, the carrier lifetime in In:GaN/Ta3N5/Mg:GaN photoanode was reduced by a factor of two compared to that in Ta3N5 photoanode. The faster decay kinetics upon switching off the illumination suggests the reduced charge trapping at the interfaces in In:GaN/Ta3N5/Mg:GaN photoanode. The larger band bending and reduced charge trapping in the depletion region near photoanode/electrolyte interface accelerate charge separation, leading to an improved PEC activity of the In:GaN/ Ta3N5/Mg:GaN photoanode. 

In summary, an “n-i-p” heterostructure In:GaN/Ta3N5/ Mg:GaN photoanode was prepared by one-step thermal nitridation process of InOx-GaOx/TaOx/Mg:GaOx precursor film deposited by EB evaporation and ALD. Mechanistic studies revealed that the n-type In:GaN layer mainly improved the bulk charge separation efficiency by selectively extracting photogenerated electrons from Ta3N5 through a conductive mid-gap band induced by In-doping. Meanwhile, the p-type Mg:GaN layer mainly contributed to the enhanced surface charge injection efficiency of the photoanode by passivating the traps on the surface of Ta3N5. Benefiting from the improved bulk charge separation efficiency and surface injection efficiency, the In:GaN/ Ta3N5/Mg:GaN photoanode yielded a maximum ABPE of 3.46%, which was significantly improved from 2.29% of the Ta3N5 

7 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 

photoanode. Owning to the passivation effect of Mg:GaN layer, the stability of the In:GaN/Ta3N5/Mg:GaN photoanode was also drastically improved. The application of In:GaN and Mg:GaN as interfacial modification layers could be extended to other oxynitride semiconductors (e.g., TaON, BaTaO2N, LaTiO2N) to further improve their conversion efficiency for PEC water splitting. Finally, it is proposed that effective carrier management through interface engineering should be generally considered to improve the efficiency and stability of photoelectrode for artificial photosynthesis. 

### Methods 

Synthesis of In:GaN/Ta3N5/Mg:GaN thin films. Indium oxide (InOx) layer with a nominal thickness of 2 nm was first deposited on Nb foils (10 × 10 × 0.1 mm<sup>3</sup> ), quartz glass (10 × 10 × 1 mm<sup>3</sup> ), or Si substrates (10 × 10 × 0.525 mm<sup>3</sup> ) by EB evaporation (Angstrom Engineering AMOD) at a deposition rate of 0.5 Å/s using In2O3 (99.99% in purity) as the source material. Then a gallium oxide (GaOx) layer with a thickness of ~5 nm was deposited on top of the InOx layer by plasmaenhanced ALD (Picosun R-200 Advanced) using triethyl gallium (TEG, 99.99%) as the source and O2 plasma as the oxidizer. The TEG source temperature was maintained at 25 °C and the substrate temperature was 250 °C. A typical ALD sequence consisted of TEG exposure (0.5 s)/N2 purge (5 s)/O2 plasma exposure (12 s)/N2 purge (5 s). Subsequently, a tantalum oxide (TaOx) layer with a thickness of 700 nm was deposited on top of the GaOx layer by EB evaporation at a deposition rate of 4 Å/s using Ta2O5 (99.99%) as the source material. During deposition, O2 gas (99.999%) was introduced into the deposition chamber at a flow rate of 5 sccm and the working pressure was approximately 2 × 10<sup>−4</sup> Torr. Afterwards, the InOx-GaOx/TaOx precursor films were dipped into a H2O2 aqueous solution (30%) for 2 h to oxidize the slightly reduced TaOx films. Subsequently, a magnesium-doped GaOx (Mg:GaOx) layer with a thickness of ~20 nm was deposited on top of the TaOx layer by plasma-enhanced ALD using TEG and bis(cyclopentadienyl)magnesium (MgCp2, 99.99%) as the sources. The MgCp2 source temperature was maintained at 80 °C and the substrate temperature was 250 °C. An ALD “super-cycle” consisted of: 5 cycles of TEG exposure (0.5 s)/ N2 purge (5 s)/O2 plasma exposure (12 s)/N2 purge (5 s), followed by one cycle of MgCp2 exposure (1.6 s)/N2 purge (5 s)/O2 plasma exposure (12 s)/N2 purge (5 s). The super-cycle was repeated 58 times to reach the target thickness. Finally, In:GaN/Ta3N5/Mg:GaN thin films were obtained by thermal nitridation of the InOx-GaOx/TaOx/Mg:GaOx thin films in a horizontal quartz tube (inner diameter: 21 mm) furnace (MTI OTF-1200X). The quartz tube was purged with 100 sccm NH3 (99.999%) flow at ambient pressure. The temperature was ramped at a rate of 10 °C min<sup>−1</sup> from room temperature to 1000 °C, maintained for 6 h, and cooled down naturally to room temperature. 

#### Structural and spectroscopic characterizations. XRD was measured with a 

Thermo Scientific ARL™ EQUINOX 1000 in θ–2θ configuration using a Cu Kα radiation source operated at 40 kV and 30 mA. SEM images were taken with a ZEISS Crossbeam 340. UV–vis spectra were measured with a SHIMADZU UV1900. XPS was performed by PHI 5000 VersaProbe III with a monochromatic Al Kα X-ray source with the beam size of 200 μm. Charge compensation was achieved by the dual beam charge neutralization and the binding energy was corrected by setting the binding energy of the hydrocarbon C 1 s feature to 284.8 eV. UPS was performed by PHI 5000 VersaProbe III with He I source (21.22 eV) under an applied negative bias of 9.0 V. Cross sectional samples were prepared by focused ion beam (JEOL JIB-4600F) etching and followed by 0.5–1.5 kV gentle Ar milling with a low angle ion milling and polishing system (JEOL 1010) for finishing. The cross-sectional STEM and HRTEM images and EDS mapping were taken with a JEOL JEM-2800 equipped with X-MAX 100TLE SDD detector (Oxford Instruments). AES was performed by PHI 710 Scanning Auger Nanoprobe, equipped with a thermally assisted Schottky field-emission electron gun and a coaxial cylindrical mirror analyzer. AES depth profiling was accomplished using the mono Ar ion source operated at 1 kV and rostered over a 2 × 2 mm area. PL and TRPL spectra were measured by Picoquant FluoTime 300 using 270 nm LED or 375/ 510 nm picosecond pulsed lasers as the excitation sources. The temperature of the samples was cooled to ~10 K using a closed-cycle He cryostat (ARS DE-202). 

Fabrication of In:GaN/Ta3N5/Mg:GaN photoanodes. The In:GaN/Ta3N5/ Mg:GaN thin films deposited on Nb substrates were used for the fabrication of photoanodes. Electrical contact was established by soldering a copper wire to the back side of the Nb substrate using indium. The edges and back side of the samples were then encapsulated by a rapid-curing epoxy (Araldite). The active area of the photoanode was approximately 0.94 cm<sup>2</sup> . After completely curing for at least 12 h, NiCoFe-Bi OER co-catalyst was deposited on the surface of the photoanode by a photo-assisted electrochemical deposition method. Borate buffer solution (pH ~10) prepared by mixing 0.6 M KOH and 1 M H3BO3 was used as the electrolyte. After purging the electrolyte with Ar for 15 min, 0.5 mM Co(NO3)2·6H2O, 2 mM NiSO4·6H2O and 0.8 mM FeSO4·7H2O were sequentially added to the electrolyte. 

The deposition process was carried out at a constant current density of 30 μA cm<sup>−2</sup> for 10 min under AM 1.5 G illumination (SAN-EI Electric, XES-40S3-TT). After deposition, the samples were rinsed with deionized water. 

PEC measurement. All the PEC measurements were conducted using a potentiostat (Bio-Logic SP-200) in three-electrode configuration with a Pt counter electrode and a Hg/HgO reference electrode. All measured potentials versus Hg/HgO were converted to RHE scale according to the Nernst equation. The Pt cathode chamber was separated from the photoanode chamber using a Nafion 117 membrane. Simulated sunlight from a solar simulator (SAN-EI ELECTRIC, XES-40S3-TT) with intensity calibrated to 100 mW cm<sup>−2</sup> (AM1.5 G) using a certified reference cell (Konica-Minolta AK-200) was used as the light source. J-V curves were recorded under a cathodic scan at a rate of 10 mV s<sup>−1</sup> at 283 K in 1 M KOH (pH 13.6) solution under magnetic stirring and Ar bubbling. ABPE was calculated from the J-V curves with the equation: ABPE = [(1.23 – Vapp) × Jlight/Plight] × 100%, where Vapp is the applied potential (versus RHE), Jlight is the photocurrent density under AM 1.5 G light, Plight equals to 100 mW cm<sup>−2</sup> for the simulated sunlight. IPCE spectrum was measured at 1 V vs RHE from 350 to 650 nm with an interval of 10 nm using a monochromatic light source (Zolix Sirius 300 P). The IPCE value at each wavelength (λ) was calculated by: IPCE = [(1240/λ) × (Jlight − Jdark)/Plight] × 100%, where Jlight was the measured photocurrent density, Jdark was the current density in the dark, Plight was the irradiance of the monochromatic light. The amount of oxygen evolved from the photoanode was quantified by a gas chromatography (Shimadzu GC-2014). PEIS was performed at 1.0 V vs RHE under AM 1.5 G simulated sunlight in frequency range of 1 Hz to 1 MHz. Fitting of the Nyquist plots was performed by ZSimDemo software. M-S plots were measured in the potential range of −0.6–1.3 V vs RHE with an AC amplitude of 10 mV in the frequency range of 1.0–3.0 kHz under dark conditions. The OCP decays at the light on/off transient were recorded after illuminating the sample for 10 min in 1 M KOH. 

### Data availability 

Source data are provided with this paper. 

Received: 21 September 2021; Accepted: 20 January 2022; 



### References 

1. Hu, S. et al. Amorphous TiO2 coatings stabilize Si, GaAs, and GaP photoanodes for efficient water oxidation. Science 344, 1005–1009 (2014). 

2. Takata, T. et al. Photocatalytic water splitting with quantum efficiency of almost unity. Nature 581, 411–414 (2020). 

3. Wang, Q. et al. Scalable water splitting on particulate photocatalyst sheets with a solar-to-hydrogen energy conversion efficiency exceeding 1%. Nat. Mater. 15, 611–615 (2016). 

4. Nishiyama, H. et al. Photocatalytic solar hydrogen production from water on a 100 m<sup>2</sup> -scale. Nature 598, 304–307 (2021). 

5. Lewis, N. S. Toward cost-effective solar energy use. Science 315, 798–801 (2007). 

6. Listorti, A., Durrant, J. & Barber, J. Solar to fuel. Nat. Mater. 8, 929–930 (2009). 

7. Nocera, D. G. The artificial leaf. Acc. Chem. Res. 45, 767–776 (2012). 

8. Blankenship, R. E. et al. Comparing photosynthetic and photovoltaic efficiencies and recognizing the potential for improvement. Science 332, 805–809 (2011). 

9. Du, C. et al. Hematite‐based water splitting with low turn‐on voltages. Angew. Chem. Int. Ed. 125, 12924–12927 (2013). 

10. Hisatomi, T., Kubota, J. & Domen, K. Recent advances in semiconductors for photocatalytic and photoelectrochemical water splitting. Chem. Soc. Rev. 43, 7520–7535 (2014). 

11. Takata, T. & Domen, K. Development of non-oxide semiconductors as light harvesting materials in photocatalytic and photoelectrochemical water splitting. Dalton Trans. 46, 10529–10544 (2017). 

12. Ma, S. S. K. et al. Enhanced water oxidation on Ta3N5 photocatalysts by modification with alkaline metal salts. J. Am. Chem. Soc. 134, 19993–19996 (2012). 

13. Wang, Z. et al. Overall water splitting by Ta3N5 nanorod single crystals grown on the edges of KTaO3 particles. Nat. Catal. 1, 756–763 (2018). 

14. Liu, G. et al. Enabling an integrated tantalum nitride photoanode to approach the theoretical photocurrent limit for solar water splitting. Energy Environ. Sci. 9, 1327–1334 (2016). 

15. Zhong, M. et al. Highly active GaN‐stabilized Ta3N5 thin‐film photoanode for solar water oxidation. Angew. Chem. 129, 4817–4821 (2017). 

16. Seo, J. et al. Mg-Zr cosubstituted Ta3N5 photoanode for lower-onset-potential solar-driven photoelectrochemical water splitting. J. Am. Chem. Soc. 137, 12780–12783 (2015). 

17. Kuang, Y., Yamada, T. & Domen, K. Surface and interface engineering for photoelectrochemical water oxidation. Joule 1, 290–305 (2017). 

8 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-022-28415-4 

18. Albohn, J. et al. Capture cross sections of defect states at the Si/SiO2 interface. J. Appl. Phys. 88, 842–849 (2000). 

19. He, Y. et al. What limits the performance of Ta3N5 for solar water splitting? Chem 1, 640–655 (2016). 

20. Zhou, X. et al. Interface engineering of the photoelectrochemical performance of Ni-oxide-coated n-Si photoanodes by atomic-layer deposition of ultrathin films of cobalt oxide. Energy Environ. Sci. 8, 2644–2649 (2015). 

21. Moreno-Hernandez, I. A., Brunschwig, B. S. & Lewis, N. S. Tin oxide as a protective heterojunction with silicon for efficient photoelectrochemical water oxidation in strongly acidic or alkaline electrolytes. Adv. Energy Mater. 8, 1801155 (2018). 

22. Zhang, H. et al. Gradient tantalum-doped hematite homojunction photoanode improves both photocurrents and turn-on voltage for solar water splitting. Nat. Commun. 11, 4622 (2020). 

23. Ye, K. H. et al. Enhancing photoelectrochemical water splitting by combining work function tuning and heterojunction engineering. Nat. Commun. 10, 3687 (2019). 

24. Li, C. Positive onset potential and stability of Cu2O-based photocathodes in water splitting by atomic layer deposition of a Ga2O3 buffer layer. Energy Environ. Sci. 8, 1493–1500 (2015). 

25. Li, Y. et al. Defective TiO2 with high photoconductive gain for efficient and stable planar heterojunction perovskite solar cells. Nat. Commun. 7, 12446 (2016). 

26. Khoomortezaei, S., Abdizadeh, H. & Golobostanfard, M. R. Triple layer heterojunction WO3/BiVO4/BiFeO3 porous photoanode for efficient photoelectrochemical water splitting. ACS Appl. Mater. Interfaces 2, 6428–6439 (2019). 

27. Xiao, Y. et al. Band structure engineering and defect control of Ta3N5 for efficient photoelectrochemical water oxidation. Nat. Catal. 3, 932–940 (2020). 

28. Pihosh, Y. et al. Ta3N5-nanorods enabling highly efficient water oxidation via advantageous light harvesting and charge collection. Energy Environ. Sci. 13, 1519–1530 (2020). 

29. Fu, J. et al. Identifying performance-limiting deep traps in Ta3N5 for solar water splitting. ACS Catal. 10, 10316–10324 (2020). 

30. Zhao, Y. et al. Interface engineering with an AlOx dielectric layer enabling an ultrastable Ta3N5 photoanode for photoelectrochemical water oxidation. J. Mater. Chem. A 9, 11285–11290 (2021). 

31. Asakura, Y. et al. Activation of a particulate Ta3N5 water-oxidation photoanode with a GaN hole-blocking layer. Sustain. Energy Fuels 2, 73–78 (2018). 

32. Nurlaela, E. et al. Towards zero bias photoelectrochemical water splitting: onset potential improvement on a Mg:GaN modified-Ta3N5 photoanode. J. Mater. Chem. A 6, 15265–15273 (2018). 

33. Pastukhova, N., Mavrič, A. & Li, Y. Atomic layer deposition for the photoelectrochemical applications. Adv. Mater. Interfaces 8, 2002100 (2021). 

34. Gaiser, H. F. et al. Ionic-liquid-based synthesis of GaN nanoparticles. Chem. Commun. 56, 2312–2315 (2020). 

35. Khan, M. A. et al. III–nitride UV devices. Jpn. J. Appl. Phys. 44, 7191–7206 (2005). 

36. Pelant, I. & Valenta, J. Luminescence spectroscopy of semiconductors (Oxford University Press, 2012). 

37. Chen, R. Apparent stretched-exponential luminescence decay in crystalline solids. J. Lumin. 102, 510–518 (2003). 

38. Bodunov, E., Antonov, Y. A. & Simões Gamboa, A. L. On the origin of stretched exponential (Kohlrausch) relaxation kinetics in the room temperature luminescence decay of colloidal quantum dots. J. Chem. Phys. 146, 114102 (2017). 

39. Nogami, G. Theory of capacitance‐voltage characteristics of semiconductor electrodes with interface states. J. Electrochem. Soc. 133, 525–531 (1986). 

40. Yi, S. S. et al. Highly efficient photoelectrochemical water splitting: surface modification of cobalt‐phosphate‐loaded Co3O4/Fe2O3 p–n heterojunction nanorod arrays. Adv. Funct. Mater. 29, 1801902 (2019). 

41. Soltani, T., Tayyebi, A. & Lee, B.-K. Efficient promotion of charge separation with reduced graphene oxide (rGO) in BiVO4/rGO photoanode for greatly enhanced photoelectrochemical water splitting. Sol. Energy Mater. Sol. Cells 185, 325–332 (2018). 

42. Zhong, M. et al. Surface modification of CoOx loaded BiVO4 photoanodes with ultrathin p-type NiO layers for improved solar water oxidation. J. Am. Chem. Soc. 137, 5053–5060 (2015). 

### Acknowledgements 

This work was supported by the National Natural Science Foundation of China (No. 21872019). M.N., N.S., and K.D. acknowledge the Artificial Photosynthesis Project (ARPChem) of the New Energy and Industrial Technology Development Organization (NEDO). A Part of this study was supported by the University of Tokyo Advanced Characterization Nanotechnology Platform in the Nanotechnology Platform Project sponsored By the Ministry of Education, Culture, Sports, Science and Technology (MEXT), Japan (JPMXP09-A-20-UT-0004). 

### Author contributions 

Y.L. and J.F. proposed the project; Y.L., N.S., and K.D. supervised the project; J.F. carried out the device fabrication and PEC tests with the assistance of Z.F., N.P., Y.X., and C.F.; M.N performed the STEM and HRTEM experiments; H.J. performed the AES experiment. Y.L. and J.F. analyzed the results and wrote the manuscript. All authors commented on and revised the manuscript. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-022-28415-4. 

Correspondence and requests for materials should be addressed to Yanbo Li. 

Peer review information Nature Communications thanks Néstor Guijarro and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

- © The Author(s) 2022 

9 

NATURE COMMUNICATIONS | (2022) 13:729 | https://doi.org/10.1038/s41467-022-28415-4 | www.nature.com/naturecommunications 

