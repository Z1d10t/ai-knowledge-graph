# Coherent manipulation of an Andreev spin qubit

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Science |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 211 |
| 作者 | M. Hays, V. Fatemi, D. Bouman, J. Cerrillo, S. Diamond, K. Serniak, T. Connolly, P. Krogstrup et al. |
| DOI | 10.1126/science.abf0345 |
| 源文件 | 019_Hays_2021_Coherent-manipulation-of-an-Andreev-spin-qubit.pdf |

---
## **Coherent manipulation of an Andreev spin qubit** 

M. Hays,<sup>1,</sup><sup>_∗_</sup> V. Fatemi,<sup>1,</sup><sup>_†_</sup> D. Bouman,<sup>2, 3</sup> J. Cerrillo,<sup>4, 5</sup> S. Diamond,<sup>1</sup> K. Serniak,<sup>1, 6</sup> T. Connolly,<sup>1</sup> 

P. Krogstrup,<sup>7</sup> J. Nyg˚ard,<sup>7</sup> A. Levy Yeyati,<sup>5, 8</sup> A. Geresdi,<sup>2, 3, 9</sup> and M. H. Devoret<sup>1,</sup><sup>_‡_</sup> 

> _1Department of Applied Physics, Yale University, New Haven, CT 06520, USA_ 

> _2QuTech and Delft University of Technology, 2600 GA Delft, The Netherlands_ 

> _3Kavli Institute of Nanoscience, Delft University of Technology, 2600 GA Delft, The Netherlands_ 

> _4 ´Area de F´ısica Aplicada, Universidad Polit´ecnica de Cartagena, E-30202 Cartagena, Spain_ 

> _5Departamento de F´ısica Te´orica de la Materia Condensada C-V,_ 

_Universidad Aut´onoma de Madrid, E-28049 Madrid, Spain_ 

> _6Current Affiliation: MIT Lincoln Laboratory, 244 Wood Street, Lexington, MA 02420, USA_ 

> _7Center for Quantum Devices, Niels Bohr Institute,_ 

_University of Copenhagen, Universitetsparken 5, 2100 Copenhagen, Denmark_ 

> _8Condensed Matter Physics Center (IFIMAC) and Instituto Nicol´as Cabrera, Universidad Aut´onoma de Madrid, E-28049 Madrid, Spain_ 

> _9Quantum Device Physics Laboratory, Department of Microtechnology and Nanoscience, Chalmers University of Technology, SE 41296 Gothenburg, Sweden_ 

Two promising architectures for solid-state quantum information processing are electron spins in semiconductor quantum dots and the collective electromagnetic modes of superconducting circuits. In some aspects, these two platforms are dual to one another: superconducting qubits are more easily coupled but are relatively large among quantum devices ( _∼_ mm), while electrostatically-confined electron spins are spatially compact ( _∼ µ_ m) but more complex to link. Here we combine beneficial aspects of both platforms in the Andreev spin qubit: the spin degree of freedom of an electronic quasiparticle trapped in the supercurrent-carrying Andreev levels of a Josephson semiconductor nanowire. We demonstrate coherent spin manipulation by combining single-shot circuit-QED readout and spin-flipping Raman transitions, finding a spin-flip time _T_ s = 17 _µ_ s and a spin coherence time _T_ 2 _E_ = 52 ns. These results herald a new spin qubit with supercurrent-based circuit-QED integration and further our understanding and control of Andreev levels – the parent states of Majorana zero modes – in semiconductor-superconductor heterostructures. 

A weak link between two superconductors hosts discrete, fermionic modes known as Andreev levels [1, 2]. They govern the physics of the weak link on the microscopic scale, ultimately giving rise to macroscopic phenomena such as the Josephson supercurrent. Superconducting quantum circuits crucially rely on the nonlinearity of the supercurrent in Josephson tunnel junctions, a manifestation of the ground-state properties of millions of Andreev levels acting in concert [3–5]. While the vast majority of conduction electrons participate in the nonlinear bosonic oscillations of the superconducting condensate, each Andreev level is itself a fermionic degree of freedom, able to be populated by electronic excitations known as Bogoliubov quasiparticles. 

In 2003, it was proposed to store quantum information in the spin state of a quasiparticle trapped in a weak link possessing a spin-orbit coupling [6–9]. It was pointed out that this Andreev spin qubit would carry a state-dependent supercurrent, opening new paths for spin manipulation and measurement that are unavailable to electrostatically-confined spin qubits [10, 11]. In particular, such a state-dependent supercurrent could be used to achieve strong coupling with a superconducting microwave resonator, an area of active research in the spin qubit community [12–18]. This supercurrentbased coupling has been used in such circuit quantum electrodynamics (cQED) architectures [19, 20] to detect and manipulate pairs of quasiparticles trapped in Andreev levels [21, 22]. However, because the Andreev levels of most weak links are paired into spin-degenerate doublets, quasiparticle spin manipulation has remained out of reach. 

The level structure of an Andreev doublet is determined by the geometric and material properties of the host weak link, as shown in weak links composed of superconductor-proximitized semiconductor nanowires, or “Josephson nanowires” for short [23, 24]. Thanks to recently-achieved atomic-scale perfection of the superconductor-semiconductor interface, it is now possible to observe the Andreev spectra of Josephson nanowires, revealing a rich interplay between electromagnetic field effects, device geometry, and spin-orbit coupling [25, 26]. These properties of Andreev levels in superconductor-semiconductor nanowires have been employed to demonstrate gate-tunable weak links for superconducting qubits [27, 28], probe non-abelian Andreev levels known as Majorana zero modes [29–33], and, importantly for this experiment, investigate spin-split doublets without a Zeeman field [26, 34]. 

In this letter, we demonstrate the first coherent manipulation of the spin of an individual quasiparticle excitation of a superconductor. The quasiparticle is trapped in the Andreev levels of a Josephson nanowire, where it resides predominantly in the two spin states of the lowestenergy Andreev doublet with roughly equal probability. First, we initialize this Andreev spin qubit in one of the two spin states by post-selecting on a single-shot cQED spin measurement, which we demonstrated in an earlier work [34]. We then achieve full coherent control of the Andreev spin qubit by driving Raman transitions in a natural Λ system formed by the two spin states and an excited state. We observe spin lifetimes up to _T_ s = 17 _µ_ s at the presented gate voltages [see Supplementary Information Fig. S9]. However, the much shorter spin coher- 

2 

ence time _T_ 2 = 52 ns appears to be limited by a spinful bath. 



FIG. 1: Principle of the Andreev spin qubit. (a) Illustration of a semiconductor nanowire (white) coated with epitaxial superconductor (light blue). A quasiparticle is trapped in the exposed weak link by the pair potential ∆of the superconducting leads. Due to spin-orbit coupling, if the quasiparticle is in the spin-up state (upper panel) supercurrent flows to the right near zero phase bias _ϕ̸_ = 0, while in the spin-down state (lower panel) supercurrent flows to the left. Applying nonzero _ϕ_ thus breaks spin degeneracy. (b) Level structure of two Andreev doublets tuned to a Λ configuration. Two microwave drives (frequencies _f↓_ and _f↑_ ) are equally detuned from _| ↓q ⟩↔| ↑a ⟩_ and _| ↑q ⟩↔| ↑a ⟩_ , inducing a coherent Raman process between the qubit states _|↓q ⟩_ and _|↑q ⟩_ via a virtual level (black dashed line). (c) Both microwave drives induce an rf electric field _E_ d between the superconducting leads. But, for a nanowire symmetric across the plane _M_ (i.e. only nanowire + substrate), drive-induced spin-flips would be forbidden. However, as depicted in the inset, here the mirror symmetry is broken by both the partial aluminum shell as well as the cutter (blue, bias _V_ g _,_ c) and plunger gates (black, bias _V_ g _,_ p). (d) The Josephson nanowire (light blue) is embedded in a superconducting loop (gray), which enables phase bias via an external flux _ϕ ≈_ 2 _π_ Φ _/_ Φ0 as well as inductive coupling to a superconducting microwave resonator (maroon). The resonator reflection coefficient Γ = _I_ + _iQ_ is probed with a tone near the resonator frequency _f_ r = 9.188 GHz. (e) Repeated 1 _._ 9 _µ_ s measurements of _I_ and _Q_ clustered into three distributions, corresponding to _|↓q ⟩_ , _|↑q ⟩_ and _|g⟩_ (standard deviation _σ_ ). The system state was assigned based on thresholds indicated by the black dotted lines. 

Our realization of the Andreev spin qubit hinges on the interplay between spin-orbit coupling in the semicon- 

ductor nanowire and the superconducting phase bias _ϕ_ across the weak link [Fig. 1(a)] [6–9, 26, 34]. In a conventional weak link, a trapped quasiparticle is restricted to spin-degenerate Andreev doublets and therefore the spin cannot be coherently manipulated. In a Josephson nanowire, however, an inter-subband spin-orbit interaction can cause spin to hybridize with translational degrees of freedom (this hybridized spin is sometimes known as pseudospin, though we will continue to refer to it as “spin” for simplicity). Due to this interaction between spin and motion, the two spin states of an Andreev doublet carry equal and opposite supercurrent _±I_ s _/_ 2 at _ϕ_ = 0, with _I_ s doublet-dependent. The doublet degeneracy can thus be lifted with a nonzero phase bias: perturbatively near _ϕ_ = 0, the spin splitting is given by _ϵ_ s = _I_ s _ϕ_ Φ0 _/_ 2 _π_ . 

Microwave quantum optics techniques are well-suited to achieve quasiparticle spin manipulation, given the frequency selectivity brought about by such a flux-induced spin splitting. In this experiment, the two spin states _| ↓q ⟩, | ↑q ⟩_ of one Andreev doublet form the qubit basis [Fig. 1(b)], while a second, higher-energy doublet provides auxiliary states _| ↑a ⟩_ , _| ↓a ⟩_ critical for both qubit control and measurement [34]. To manipulate the Andreev spin qubit, we use the qubit states _| ↓q ⟩, | ↑q ⟩_ in conjunction with _| ↑a ⟩_ as a Λ system. We apply simultaneous microwave drives to both the _|↑q ⟩↔|↑a ⟩_ transition (drive frequency _f↑_ ) and _| ↓q ⟩↔| ↑a ⟩_ (drive frequency _f↓_ ). By equally detuning the two drives from their respective transitions, a Raman process is induced such that the _{| ↓q ⟩, | ↑q ⟩}_ manifold can be coherently manipulated while _|↑a ⟩_ remains minimally populated. The success of the Raman process is contingent on our ability to drive both the spin-conserving transition _| ↑q ⟩↔| ↑a ⟩_ and the spin-flipping transition _| ↓q ⟩↔ | ↑a ⟩_ . While spin-orbit hybridization is necessary to enable electric-field induced spin-flips [35], in our situation a broken spatial symmetry of the Josephson nanowire is also required (see Supplementary Information for details). In this experiment, our hexagonal nanowire was made of [001] wurtzite indium arsenide grown by molecular beam epitaxy. Such a nanowire lying alone on a substrate would possess a transverse mirror symmetry [Fig. 1(c)]; this property would then be inherited by the levels of the nanowire such that one spin state of each doublet would be mirror-symmetric and the other antisymmetric. Since we apply the microwave drive voltage across the weak link, the rf electric field respects the mirror symmetry (it points along the nanowire) and therefore cannot flip spin. 

In the device used in this work, the mirror symmetry is broken by both the superconducting leads and the electrostatic gates [Fig. 1(c)], as well as any symmetrybreaking disorder present in the nanowire. The superconducting leads consist of 10 nm-thick epitaxial aluminum, of which a 500 nm length was removed to form the weak link. The aluminum only covers two of six nanowire facets, thereby breaking the mirror symmetry of the nanowire-substrate system. As the gates are fabricated on one side of the nanowire, they also break the mirror symmetry. Both the cutter and plunger gates were 

3 

used to tune the transparency of the weak link and were biased to _V_ g _,_ c = _−_ 71 _._ 9 mV and _V_ g _,_ p = 4 _._ 0 mV respectively, unless otherwise noted (see Supplementary Information for system tune up). With the mirror symmetry broken, the drive may induce spin flips and a Raman process can be used for coherent spin manipulation. 

We detect the state of the Andreev spin qubit by embedding the Josephson nanowire in a cQED architecture [Fig. 1(d)]. As we previously demonstrated [34], the effect of spin-orbit coupling on both the inter-doublet transition spectrum and supercurrent can be harnessed to achieve a spin-dependent dispersive shift of the frequency of a superconducting microwave resonator. Following that work, we detect the quasiparticle spin state by measuring the resonator response to a resonant probe tone [Fig. 1(e)]. The complex amplitude Γ = _I_ + _iQ_ of the reflected tone clustered into three distributions, corresponding to the two spin states _| ↓q ⟩_ , _| ↑q ⟩_ of a trapped quasiparticle as well as the ground state _|g⟩_ of the junction where no quasiparticle was present. Throughout this work, we present data in terms of spin state occupation probabilities _P↑, P↓_ , which we compute based on the thresholds displayed in Fig. 1(e). 

The Andreev spin qubit exists exclusively when a quasiparticle is stochastically trapped in the Josephson nanowire (see Supplementary Information for a quantum jumps trace). For the bias conditions presented in this work, we found that a trapped quasiparticle occupied the two spin states of the lowest doublet with roughly equal probability. Thus, under any coherent manipulation _| ↓q ⟩↔| ↑q ⟩_ the observed spin state populations would not change. Throughout this work, we overcame this problem by initializing the quasiparticle in _| ↑q ⟩_ via an initial readout pulse and post-selection (see Supplementary Information for the same measurements with _| ↓q ⟩_ post-selection). Our single-shot spin readout was thus critical to our observation of coherent population transfer between _|↑q ⟩_ and _|↓q ⟩_ . 

The first step in driving the Raman process [Fig. 1(b)] was locating the two transitions that defined the Λ system: _| ↓q ⟩↔| ↑a ⟩_ and _| ↑q ⟩↔| ↑a ⟩_ . After breaking spin degeneracy with Φ = _−_ 0 _._ 10Φ0 and tuning the transitions to a local maximum in _V_ g _,_ c to mitigate charge noise (see Supplementary Information), we measured the spectrum shown in Fig.2(a) using two-tone spectroscopy, without spin initialization. The dip in _P↑_ at 13 _._ 000 GHz corresponds to the drive coming into resonance with the _| ↑q ⟩↔| ↑a ⟩_ transition, resulting in population transfer out of _| ↑q ⟩_ and into _| ↑a ⟩_ . Similarly, the dip in _P↓_ at 13 _._ 684 GHz corresponds to the _| ↓q ⟩↔| ↑a ⟩_ transition (see Supplementary Information for gate voltage and Φ dependence). Taking the difference yields the spin splitting _ϵ_ s _/h_ = 684 MHz. 

Having characterized the Λ system, we then investigated two-photon Raman transitions of the trapped quasiparticle. After initializing the quasiparticle in _|↑q ⟩_ , we applied two simultaneous Gaussian pulses with variable respective carrier frequencies _f↑_ and _f↓_ and then measured the final qubit spin state [Fig. 2(b)]. Throughout the main text, we present data with _f↑_ and _f↓_ bluedetuned from _|↑q ⟩↔|↑a ⟩_ and _|↓q ⟩↔|↑a ⟩_ respectively 



FIG. 2: Raman transitions of a trapped quasiparticle. (a) In a two-tone measurement, the Josephson nanowire was first driven by a 1 _µ_ s saturation pulse (gray) of variable carrier frequency _fd_ before the quasiparticle state was determined with a readout pulse (maroon). A dip is observed in _P↑_ corresponding to the _|↑q ⟩↔|↑a ⟩_ transition and in _P↓_ corresponding to the _| ↓q ⟩↔| ↑a ⟩_ transition [see Fig. S5 for Φ-dependence]. (b) The quasiparticle was first prepared in _| ↑q ⟩_ via an initial readout pulse and post-selection. Simultaneous Gaussian pulses (235 ns full width at half maximum, 30 dB more power than used in (a)) with variable frequencies _f↓, f↑_ were then applied, followed by a final readout pulse. The observed peak in the final _| ↓q ⟩_ population lies along _f↓_ = _f↑_ + 609 MHz (black dashed line). (c) Full Γ histograms of the final readout pulse for the two subsets of measurements enclosed by the gray and black solid lines in (b). Data accrued in the region enclosed by the gray line shows little population transfer from the post-selected _| ↑q ⟩_ (left panel), while data in the region enclosed by the black shows significant population transfer to _|↓q ⟩_ (right panel). 

(see Supplementary Information for data over a wider frequency range). Along a line given by _f↓_ = _f↑_ +609 MHz, we observe increased _| ↓q ⟩_ population that we attribute to the onset of a Raman process. As expected for Raman transitions, the slope of this line is equal to one, since a shift of one drive frequency must be compensated by an equal shift of the other. The discrepancy between the spin splitting _ϵ_ s _/h_ = 684 MHz and the 609 MHz offset was due to an uncontrolled shift of the Andreev spectrum that occurred in between the measurements shown in Fig. 2(a) and Fig. 2(b) (see Supplementary Information). 

To further illustrate the dynamics of the quasiparticle under the Raman transitions, we histogram Γ for data points off/on resonance with the Raman process [Fig. 2(c)]. Off resonance, the quasiparticle was found predominantly in _| ↑q ⟩_ , as expected from post-selection on the initial readout pulse. On resonance, there was significant population transfer to _|↓q ⟩_ as desired, as well as a small population transfer to _|g⟩_ . This is due to drive- 

4 

induced quasiparticle de-trapping, which we comment on further below. 



FIG. 3: Coherent Λ-Rabi oscillations of the quasiparticle spin at _f↓_ = 13 _._ 280 GHz and _f↑_ = 13 _._ 964 GHz. (a) Independently varying the amplitudes _A↑_ and _A↓_ of the simultaneous Gaussian drive pulses (94 ns full width at half maximum) resulted in coherent oscillations between _| ↑q ⟩_ and _| ↓q ⟩_ characteristic of a Raman process. The oscillations are only present away from _A↑, A↓_ = 0, and are symmetric under sign flips of _A↓, A↑_ . (b) Simulated dynamics of the quasiparticle under the action of the drive pulse. The reduced contrast observed in (a) is taken into account using the measured readout fidelities. 

Finally, having induced spin population transfer using Raman transitions, we demonstrate the first coherent manipulation of the spin of an individual quasiparticle. We first chose our Raman drive frequencies using the same measurement as shown in Fig. 2, but with shorter pulses (94 ns full width at half maximum): we detuned _f↓_ by 280 MHz from _| ↓q ⟩↔| ↑a ⟩_ and varied _f↑_ until we observed maximum spin population transfer. We then varied the amplitudes _A↑, A↓_ of the two Gaussian pulses before determining the final quasiparticle state [Fig. 3(a)]. The observed oscillations in the population difference between the two spin states are characteristic of a coherent Raman process. Qualitatively, when either _A↓_ = 0 or _A↑_ = 0 there is no population transfer because both drives are required to induce the Raman process. As the amplitudes of both drives are increased (roughly along the diagonals _|A↓| ≃|A↑|_ ), the spin population difference undergoes coherent oscillations. As expected, the data are symmetric under _A↓ →−A↓_ and _A↑ →−A↑_ . 

Quantitatively, the data are well-represented by a simulation of the coherent quasiparticle dynamics under the action of the drive pulses [Fig. 3(b)]. Details of this numerical simulation can be found in the Supplementary Information. Using a Lindblad master equation [36] we calculated the dynamics of the quasiparticle between the two Andreev doublets, with the inter-doublet transition frequencies and dephasing rates, spin dephasing rate, state-dependent readout fidelities, and pulse frequencies and envelopes fixed to values determined by independent measurements and instrument settings. We then fit the simulation to the measured data by varying the four inter-doublet transition matrix elements [Fig. 1(d)], 

as well as a slight detuning from the Raman resonance condition, which we found to be 5 _._ 5 _±_ 0 _._ 1 MHz. We also included a phenomenological drive-induced quasiparticle de-trapping rate (10 _._ 8 _±_ 0 _._ 9 MHz at _|A↓|_ = _|A↑|_ = 1) to capture the measured increase of _| ↓q ⟩, | ↑q ⟩→|g⟩_ for larger drive powers. We were thus able to capture the measured Raman spin dynamics of a quasiparticle trapped in the Andreev levels of a Josephson nanowire. 



FIG. 4: Coherence decay of the quasiparticle spin ( _V_ g _,_ c = _−_ 59 _._ 1 mV _, V_ g _,_ p = _−_ 33 _._ 3 mV _,_ Φ = _−_ 0 _._ 115Φ0). Ramsey (a) and Hahn-echo (b) experiments reveal _T_ 2 _R_ = 18 _±_ 1 ns and _T_ 2 _E_ = 52 _±_ 3 ns, respectively. Solid lines indicate fits to the data (see main text). Oscillations were introduced in both cases by adding a phase proportional to _τ_ to the final Raman pulse. 

With the ability to perform coherent spin manipulation in hand, we then characterized the coherence lifetime of an Andreev spin. A Ramsey measurement [Fig. 4(a)] revealed spin coherence decay with a timescale _T_ 2 _R_ = 18 _±_ 1 ns, while a Hahn-echo pulse sequence [Fig. 4(b)] resulted in a slightly longer timescale _T_ 2 _E_ = 52 _±_ 3 ns. Both measurements were well-described by a decay envelope exp [ _−_ ( _τ/T_ 2)<sup>1+</sup><sup>_α_</sup> ] with _α_ = 0 _._ 3 _±_ 0 _._ 1, indicative of excess low-frequency components compared to a white noise spectrum where _α_ would be zero. The observed oscillations in _P↑, P↓_ are centered about a lower value in Fig. 4(b) as compared to 4(a), which we attribute to additional quasiparticle de-trapping _| ↓q ⟩, | ↑q ⟩→|g⟩_ caused by the echo pulse. Both the observed Ramsey and Hahnecho coherence times are comparable to that of the spinorbit qubit [12, 35, 37], the closest cousin of the Andreev spin qubit in that it consists of the spin-orbit hybridized pseudospin of a single electron. However, because here the quasiparticle was trapped in Andreev levels, we possessed a different experimental lens with which to investigate the effects of the environment on the spin coherence. 

As the Andreev levels of a Josephson nanowire are tunable via both electrostatic voltages and flux, we first suspected charge or flux noise as the source limiting the Andreev spin qubit coherence. However, we found that neither _T_ 2 _R_ nor _T_ 2 _E_ varied with _V_ g _,_ c around the sweet-spot bias point (see Supplementary Information). This indi- 

5 

cated that the spin coherence was not limited by charge noise, consistent with the observed weak dependence of _ϵ_ s on _V_ g _,_ c. By comparing to the charge-noise-limited interdoublet transitions, we extracted a lower-bound of 4 _._ 2 _µ_ s on the charge-noise-induced dephasing time of the quasiparticle spin (see Supplementary Information). Moreover, the spin coherence time was not limited by flux noise, as we found no measurable dependence on Φ. 

To better understand what was limiting the coherence of the Andreev levels, we additionally measured the coherence lifetimes of both inter-doublet transitions and so-called “pair transitions” at several gate bias points [Tab. 1]. The latter correspond to the excitation of two quasiparticles out of the condensate into both levels of a doublet [21, 22, 26, 38]. We found that the pair transition coherence times were systematically an order of magnitude longer than inter-doublet transition coherence times. To first order, perturbations that couple to spin (such as a Zeeman field) result in equal and opposite energy shifts of the two doublet levels [26]. As such, these perturbations do not change the frequency of the doublet pair transition, and therefore do not cause dephasing. However, such spin-specific perturbations do induce dephasing of both inter-doublet transitions and the Andreev spin qubit. It thus appears that the coherence lifetime of the Andreev spin qubit is limited by a spinspecific noise source such as hyperfine interactions with the spinful nuclei of indium and arsenic (though nuclear baths are typically lower frequency than the measured ratio _T_ 2 _E/T_ 2 _R_ = 2 _._ 9 and decay envelope would indicate [39]), phonon-induced fluctuations of the nanowire spinorbit coupling, or noisy paramagnetic impurities on the surface of the nanowire [10]. 

|**Transition**|**_V_g****_,_c (mV)**|**_V_g****_,_p (mV)**|**_T_2****_R_ (ns)**|**_T_2****_E_ (ns)**|
|---|---|---|---|---|
|_|↑q ⟩↔|↑a ⟩_|-166.3|-127.6|n.m.|39_±_8|
|pair|-164.9|-127.6|38_±_9|257_±_9|
|_|↓q ⟩↔|↑a ⟩_|144.5|24.9|n.m.|9_±_1|
|pair|116.2|23.8|11_±_1|420_±_20|
|_|↑q ⟩↔|↑a ⟩_|32.7|-4.7|n.m.|11_±_3|
|pair|30.0|-4.7|14_±_2|490_±_10|



TAB. 1: Coherence lifetimes of Andreev transitions at various bias points. Ramsey coherence times for the inter-doublet transitions were not measured (n.m.) as they were too short. 

In this work, we have demonstrated the first coherent manipulation of an Andreev spin qubit by driving Raman transitions of a single quasiparticle spin. In future experiments, the fidelity of this process may be improved by the implementation of a resonant STIRAP protocol [40], which would reduce the necessary pulse amplitude and length, thereby mitigating the effects of dephasing and quasiparticle de-trapping. The parity dynamics may also be suppressed by improved filtering of high-frequency radiation [41]. In addition, engineering of the nanowire mirror symmetry could result in larger spin-flip drive matrix elements without sacrificing the spin lifetime. Critical to the demonstration of spin manipulation was our ability to perform single-shot, cQED readout, which inher- 

ently relies on substantial coupling between the Josephson nanowire and a microwave resonator. In future experiments, this coupling could be used to achieve long-range interaction between separate qubits, a worthy goal in spin qubit research [12–14, 16, 18]. The nature of the spinful bath limiting the quasiparticle spin coherence may be elucidated by the application of magnetic field [10], which could also push the Josephson nanowire through a topological phase transition [29–33]. In general, a detailed understanding of the effect of magnetic field on quasiparticle dynamics will be critical for further progress. 

We thank Gijs de Lange for assistance with device design, and thank Nick Frattini and Vladimir Sivak for providing us with a SNAIL parametric amplifier. We are grateful to Marcelo Goffman, Cyril Metzger, Hugues Pothier, Leandro Tosi, and Cristi´an Urbina for sharing their experimental results and hypotheses. We acknowledge useful discussions with Nick Frattini, Luigi Frunzio, Leonid Glazman, Manuel Houzet, Pavel Kurilovich, Vlad Kurilovich, and Charles Marcus. 

This research was supported by the US Office of Naval Research (N00014-16-1-2270) and by the US Army Research Office (W911NF-18-1-0020, W911NF-18-1-0212 and W911NF-16-1-0349). D.B. acknowledges support by Netherlands Organisation for Scientific Research (NWO) and Microsoft Corporation Station Q. J.C. acknowledges the support from MICINN (Spain) (“Beatriz Galindo” Fellowship BEAGAL18/00081). J.N. acknowledges support from the Danish National Research Foundation. Some of the authors acknowledge the European Union’s Horizon 2020 research and innovation programme for financial support: A.G received funding from the European Research Council, grant no. 804988 (SiMS), and A.G., A.L.Y., J.C., and J.N. further acknowledge grant no. 828948 (AndQC) and QuantERA project no. 127900 (SuperTOP). A.L.Y. acknowledges support by Spanish MICINN through grants FIS2017-84860-R and through the “Mar´ıa de Maeztu” Programme for Units of Excellence in R&D (Grant No. MDM-2014-0377). 

### **Contributions** 

M.H., V.F., K.S., D.B., T.C., A.G., and M.D. designed the experimental setup. P.K. and J.N. developed the nanowire materials. D.B. and A.G. fabricated the device. M.H. and V.F. performed the measurements. V.F., M.H., J.C. and A.L.Y. developed the symmetry analysis and microscopic modeling. M.H., J.C., V.F., and A.L.Y. developed and performed the Raman simulations. M.H., V.F., K.S., S.D., and M.D. analyzed the data. M.H., V.F., and M.D. wrote the manuscript with feedback from all authors. 

- _∗_ Electronic address: max.hays@yale.edu 

- Electronic address: valla.fatemi@yale.edu 

- Electronic address: michel.devoret@yale.edu 

- [1] C. Beenakker and H. Van Houten, Phys. Rev. Lett. **66** , 3056 (1991). 

- [2] A. Furusaki and M. Tsukada, Phys. Rev. B **43** , 10164 (1991). 

6 

- [3] J. Clarke and A. I. Braginski, eds., _The SQUID Handbook_ , vol. 1 (Wiley, Weinheim, 2004). 

- [4] M. H. Devoret and R. J. Schoelkopf, Science **339** , 1169 (2013). 

- [5] A. Roy and M. Devoret, Comptes Rendus Physique **17** , 740 (2016). 

- [6] N. M. Chtchelkatchev and Y. V. Nazarov, Phys. Rev. Lett. **90** , 226806 (2003). 

- [7] C. Padurariu and Y. V. Nazarov, Phys. Rev. B **81** , 144519 (2010). 

- [8] A. A. Reynoso, G. Usaj, C. A. Balseiro, D. Feinberg, and M. Avignon, Phys. Rev. B **86** , 214519 (2012). 

- [9] S. Park and A. L. Yeyati, Phys. Rev. B **96** , 125416 (2017). 

- [10] R. Hanson, L. P. Kouwenhoven, J. R. Petta, S. Tarucha, and L. M. K. Vandersypen, Rev. Mod. Phys. **79** , 1217 (2007). 

- [11] L. Childress and R. Hanson, MRS Bull. **38** , 134 (2013). 

- [12] K. D. Petersson, L. W. McFaul, M. D. Schroer, M. Jung, J. M. Taylor, A. A. Houck, and J. R. Petta, Nature **490** , 380 (2012). 

- [13] N. Samkharadze, G. Zheng, N. Kalhor, D. Brousse, A. Sammak, U. Mendes, A. Blais, G. Scappucci, and L. Vandersypen, Science **359** , 1123 (2018). 

- [14] X. Mi, M. Benito, S. Putz, D. M. Zajac, J. M. Taylor, G. Burkard, and J. R. Petta, Nature **555** , 599 (2018). 

- [15] S. P. Harvey, C. G. L. Bøttcher, L. A. Orona, S. D. Bartlett, A. C. Doherty, and A. Yacoby, Phys. Rev. B **97** , 235409 (2018). 

- [16] A. J. Landig, J. V. Koski, P. Scarlino, U. Mendes, A. Blais, C. Reichl, W. Wegscheider, A. Wallraff, K. Ensslin, and T. Ihn, Nature **560** , 179 (2018). 

- [17] T. Cubaynes, M. R. Delbecq, M. C. Dartiailh, R. Assouly, M. M. Desjardins, L. C. Contamin, L. E. Bruhat, Z. Leghtas, F. Mallet, A. Cottet, et al., npj Quantum Inf. **5** , 1 (2019). 

- [18] F. Borjans, X. Croot, X. Mi, M. Gullans, and J. Petta, Nature **577** , 195 (2020). 

- [19] A. Blais, R.-S. Huang, A. Wallraff, S. M. Girvin, and R. J. Schoelkopf, Phys. Rev. A **69** , 062320 (2004). 

- [20] A. Wallraff, D. I. Schuster, A. Blais, L. Frunzio, R.-S. Huang, J. Majer, S. Kumar, S. M. Girvin, and R. J. Schoelkopf, Nature **431** , 162 (2004). 

- [21] C. Janvier, L. Tosi, L. Bretheau, C¸. O.<sup>¨</sup> Girit, M. Stern, P. Bertet, P. Joyez, D. Vion, D. Esteve, M. F. Goffman, et al., Science **349** , 1199 (2015). 

   - [30] R. M. Lutchyn, J. D. Sau, and S. Das Sarma, Phys. Rev. Lett. **105** , 077001 (2010). 

   - [31] Y. Oreg, G. Refael, and F. von Oppen, Phys. Rev. Lett. **105** , 177002 (2010). 

   - [32] V. Mourik, K. Zuo, S. M. Frolov, S. R. Plissard, E. P. A. M. Bakkers, and L. P. Kouwenhoven, Science **336** , 1003 (2012). 

   - [33] M. Deng, S. Vaitiek˙enas, E. B. Hansen, J. Danon, M. Leijnse, K. Flensberg, J. Nyg˚ard, P. Krogstrup, and C. M. Marcus, Science **354** , 1557 (2016). 

   - [34] M. Hays, V. Fatemi, K. Serniak, D. Bouman, S. Diamond, G. de Lange, P. Krogstrup, J. Nyg˚ard, A. Geresdi, and M. Devoret, Nat. Phys. **16** , 1103 (2020). 

   - [35] S. Nadj-Perge, S. Frolov, E. Bakkers, and L. P. Kouwenhoven, Nature **468** , 1084 (2010). 

   - [36] J. R. Johansson, P. D. Nation, and F. Nori, Computer Physics Communications **184** , 1234 (2013). 

   - [37] J. Van den Berg, S. Nadj-Perge, V. Pribiag, S. Plissard, E. Bakkers, S. Frolov, and L. Kouwenhoven, Phys. Rev. Lett. **110** , 066806 (2013). 

   - [38] L. Bretheau, C¸. Girit, H. Pothier, D. Esteve, and C. Urbina, Nature **499** , 312 (2013). 

   - [39] F. K. Malinowski, F. Martins, P. D. Nissen, E. Barnes, �L. Cywi´nski, M. S. Rudner, S. Fallahi, G. C. Gardner, M. J. Manfra, C. M. Marcus, et al., Nature nanotechnology **12** , 16 (2017). 

   - [40] J. Cerrillo, M. Hays, V. Fatemi, and A. Levy Yeyati, arXiv preprint: 2012.07132 (2020). 

   - [41] K. Serniak, S. Diamond, M. Hays, V. Fatemi, S. Shankar, L. Frunzio, R. Schoelkopf, and M. Devoret, Phys. Rev. Applied **12** , 014052 (2019). 

   - [42] Frattini, N. E., Sivak, V. V., Lingenfelter, A., Shankar, S. & Devoret, M. H., Phys. Rev. Applied **10** , 054020 (2018). 

   - [43] M. Governale and U. Z¨ulicke, Phys. Rev. B **66** , 073311 (2002). 

   - [44] E. Levenson-Falk, F. Kos, R. Vijay, L. Glazman, and I. Siddiqi, Phys. Rev. Lett. **112** , 047002 (2014). 

   - [45] J. M. Martinis, S. Nam, J. Aumentado, K. M. Lang, and C. Urbina, Phys. Rev. B **67** , 094510 (2003). 

   - [46] A. A. Houck, J. Koch, M. H. Devoret, S. M. Girvin, and R. J. Schoelkopf, Quantum Information Processing **8** , 105 (2009). 

   - [47] W. Press, _Numerical Recipes in C++ : The Art of Scientific Computing_ (Cambridge University Press, 2002). 

- [22] M. Hays, G. de Lange, K. Serniak, D. van Woerkom, D. Bouman, P. Krogstrup, J. Nyg˚ard, A. Geresdi, and M. Devoret, Phys. Rev. Lett. **121** , 047001 (2018). 

- [23] P. Krogstrup, N. L. B. Ziino, W. Chang, S. M. Albrecht, M. H. Madsen, E. Johnson, J. Nyg˚ard, C. M. Marcus, and T. S. Jespersen, Nat. Mater. **14** , 400 (2015). 

- [24] W. Chang, S. Albrecht, T. Jespersen, F. Kuemmeth, P. Krogstrup, J. Nyg˚ard, and C. M. Marcus, Nature nanotechnology **10** , 232 (2015). 

- [25] D. J. van Woerkom, A. Proutski, B. van Heck, D. Bouman, J. I. V¨ayrynen, L. I. Glazman, P. Krogstrup, J. Nyg˚ard, L. P. Kouwenhoven, and A. Geresdi, Nat. Phys. **13** , 876 (2017). 

- [26] L. Tosi, C. Metzger, M. Goffman, C. Urbina, H. Pothier, S. Park, A. L. Yeyati, J. Nyg˚ard, and P. Krogstrup, Phys. Rev. X **9** , 011010 (2019). 

- [27] T. W. Larsen, K. D. Petersson, F. Kuemmeth, T. S. Jespersen, P. Krogstrup, J. Nyg˚ard, and C. M. Marcus, Phys. Rev. Lett. **115** , 127001 (2015). 

- [28] G. De Lange, B. Van Heck, A. Bruno, D. Van Woerkom, A. Geresdi, S. Plissard, E. Bakkers, A. Akhmerov, and L. DiCarlo, Phys. Rev. Lett. **115** , 127002 (2015). 

- [29] L. Fu and C. L. Kane, Phys. Rev. Lett. **100** , 096407 (2008). 

1 

# **Supplementary Information** 

#### **I. SYMMETRY ANALYSIS OF PSEUDOSPIN-FLIP MATRIX ELEMENTS** 

In this section we motivate a simple physical picture to explain the qualitative features of the driven spin-flipping transitions. First, note that while an electron spin does in principle couple to the magnetic field of our microwave drive, this coupling is extremely weak. The electric field of the drive, on the other hand, only couples to motional degrees of freedom, so it cannot induce spin-flip transitions if spin is a good quantum number. Spin-orbit coupling is the conventional invocation to solve this problem since it hybridizes spin and translational wavefunction components into what is often referred to as pseudospin [35]. We will use symmetry considerations to show that this conversion to pseudospin is necessary but insufficient to allow electric fields to flip the quasiparticle pseudospin in our system, and that an additional broken spatial symmetry is required. Following this we further validate these ideas by inspection of a tight-binding model that specifically incorporates the physics and energy scales of Andreev levels. 

#### **A. General Considerations** 

We are interested in how transitions between the Andreev levels of the Josephson nanowire are induced by our microwave drive voltage _Vd_ cos _ωdt_ . Here _ωd_ is the drive frequency and _Vd_ the spatial profile. Initially, we will model the spatial profile as a purely longitudinal differential voltage along the Josephson nanowire _Vd_ ( _x_ ) _≈−Vd_ ( _−x_ ), which is a reasonable starting point given our highly symmetric device design [Fig. S3]. The transition rates will depend both on the matrix element of _Vd_ between the initial/final states, as well as on the mismatch between ¯ _hωd_ and the energy difference between the initial/final states. We first focus on matrix element considerations, initially assuming that Φ = 0 such that the system is time-reversal symmetric, before generalizing to any value of Φ. 

Let’s begin by imagining the Josephson nanowire as a quasi-1d system described by a Hamiltonian _H_ 0. This Hamiltonian includes both the superconducting leads and the semiconductor nanowire, though for the moment we neglect spin-orbit coupling. Additionally, let us suppose that the system is rotationally invariant about the _x_ -axis. As with any spin-1/2 system with time-reversal symmetry, the energy levels are paired into spin-degenerate doublets (Kramers theorem). In order to achieve the Raman process investigated in this experiment, it was necessary to simultaneously drive spin-conserving and spin-flipping inter-doublet transitions. Under our current model of the system, while _Vd_ can induce spin-conserving inter-doublet transitions by coupling to the spatial character of the wavefunctions, it cannot induce spin-flipping transitions because both _H_ 0 and _Vd_ are block-diagonal in spin (they are spin-rotation-symmetric). 

Spin-orbit coupling can help solve this problem by mixing spin and motional degrees of freedom. We can see this in the form of a Rashba interaction generated by a static electric field in the _z_ direction _HR_ = _iEzγ_ ( _σx∂y − σy∂x_ ), where _σi_ are Pauli matrices of the spin and _γ_ is a material parameter. Thus, in the presence of spin-orbit interaction, the quasiparticle “spin” is actually a pseudospin. We stress that a hybridization like this must be present in our system, as it is critical to break the Andreev-doublet degeneracy [8, 26, 43]. Upon including a Rashba interaction, the Hamiltonian _H_ = _H_ 0 + _HR_ is no longer block-diagonal in spin, and one might imagine that _Vd_ could flip pseudospin. 

However, a selection rule prevents this. While the static electric field in the _z_ direction associated with the Rashba effect breaks rotational symmetry, a transverse mirror symmetry in the _y_ direction remains [see main text Fig. 1(c)]. This mirror symmetry is described by the operator _My_ = _−iσyδy,−y_ , where _δy,−y_ sends _y_ to _−y_ . Because [ _H, My_ ] = 0, the energy eigenstates are also mirror eigenstates. Moreover, as spin is flipped under time-reversal _TσyT_<sup>_−_1</sup> = _−σy_ , the mirror eigenvalue is also flipped. Therefore, the pair of pseudospins comprising each doublet have mirror eigenvalues + _i_ and _−i_ (this remains true in the presence of a time-reversal-symmetry-breaking phase-bias, as explained below). As our longitudinal drive _Vd_ ( _x_ ) _≈−Vd_ ( _−x_ ) also obeys the mirror symmetry [ _Vd, My_ ] = 0, it cannot induce transitions between states of different mirror eigenvalue (pseudospin flips). 

To induce pseudospin-flip transitions, the mirror symmetry must be broken. In the real device, this symmetry is broken by the epitaxial aluminum shell which covers two of six nanowire facets, the presence of the side gates and their applied voltages [main text Fig. 1(c)], as well as any non-idealities of the device. As such, the symmetry may be broken in any/all of the Hamiltonian terms: 

- [ _H_ 0 _, My_ ] _̸_ = 0: asymmetric superconducting leads, gate-electrode perturbations to the transverse confinement 

- [ _HR, My_ ] _̸_ = 0: modified Rashba interaction due to non-symmetric electric field profiles 

- [ _Vd, My_ ] _̸_ = 0: drive applied via asymmetric leads and perturbed by presence of the metallic gate 

Under this broken mirror symmetry, both the pseudospin-conserving transition _| ↑q ⟩↔| ↑a ⟩_ and the pseudospinflipping transition _|↓q ⟩↔|↑a ⟩_ are allowed and therefore the Raman process can be driven. 

Thus far in this section, we have assumed Φ = 0 such that _THT_<sup>_−_1</sup> = _H_ . Because the drive also obeys time-reversal symmetry _TVdT_<sup>_−_1</sup> = _Vd_ , the direct pseudo-spin transition _| ↓q ⟩↔| ↑q ⟩_ is thus forbidden for Φ = 0. While this 

2 

feature is ideal for the use of the Andreev doublets as a Λ system, in this experiment it was necessary to break the doublet degeneracy such that _| ↓q ⟩↔| ↑a ⟩_ and _| ↑q ⟩↔| ↑a ⟩_ were frequency-resolved. We therefore performed most measurements at a nonzero flux bias (Φ _≈−_ 0 _._ 1Φ0) such that we could drive the inter-doublet transitions as well as detect the pseudospin state of the lower doublet. As we investigate numerically in the next section, we expect the direct spin-flip transition to remain suppressed even for nonzero Φ. Note that as long as the additional time-reversalbreaking terms in _H_ respect the mirror symmetry, as is the case for a dc phase applied to mirror-symmetric leads, all the inter-doublet transition considerations presented above for Φ = 0 automatically generalize to the case of nonzero Φ. In particular, one state of each doublet has mirror eigenvalue + _i_ and the other _−i_ , independent of Φ. 

#### **B. Numerical Tight-Binding Model** 

We now explore these symmetry considerations numerically using a tight-binding model. We begin by investigating spin-orbit hybridization and broken mirror symmetry in the band structure of an un-proximitized nanowire, before moving on to the Andreev levels themselves. 

#### _1. Unconfined Normal Channels_ 

Our model of the un-proximitized nanowire is graphically represented in Fig. S1(a). It consists of two coupled infinite parallel chains aligned along the _x_ -direction, and with Rashba spin-orbit coupling: 



<!-- Start of picture text -->
H = � ( ϵi,τ − µ ) c † i,τ,σ ci,τ,σ  +  txc† i,τ,σ ci +1 ,τ,σ  +  σαxc† i,τ,σ ci +1 ,τ,σ ¯ + H.c.<br>i,τ,σ<br>+ � tyc † i, 1 ,σ ci, 2 ,σ  +  iαyc† i, 1 ,σ ci, 2 ,σ ¯ + H.c. (1)<br>i,σ<br>Here the operators c † i,σ,τ create an electron on the site i , within the channel τ = 1 ,  2 and spin σ . The scalar hopping<br>strengths {tx, ty} correspond to the { longitudinal, transverse } directions, while the Rashba hopping strengths are<br>given by {αx, αy} . The strengths are scaled by the discretization of a continuous Hamiltonian with a longitudinal<br>lattice parameter a = 20 nm and width W = 100 nm, giving tx = ¯ h 2 / ( m ∗ a 2 ), αx = α/ (2 a ), ty = ¯ h 2 / ( m ∗ W 2 ) and<br>αy = α/ (2 W ), where m ∗ = 0 . 028 me is the effective mass for InAs and α = Ezγ = 25 meV · nm is the Rashba<br>parameter. In the mirror-symmetric case, the on-site energies ϵi,τ are given by 2 tx . Momentarily, we will break<br>this mirror symmetry by including an energy offset VA,y between the two chains such that ϵ 1 ,τ → ϵ 1 ,τ +  VA,y/ 2 and<br>ϵ 2 ,τ → ϵ 2 ,τ − VA,y/ 2. Below, we will express all energies as fractions of the superconducting gap of bulk aluminum<br>∆= 0 . 185 meV.<br><!-- End of picture text -->

3 



FIG. S1: (a) Visual representation of the tight-binding model of the un-proximitized infinite nanowire. (b) Band structure of the tight-binding model for _VA,y_ = 0. Bands split by the longitudinal Rashba term (gray dashed lines) undergo avoided crossings due to the transverse Rasbha term to give the final bands of the model (colored lines). Bands colored in blue are anti-symmetric eigenstates of _My_ , and bands colored in red are symmetric eigenstates. The black star marks the slow, positive momentum Fermi point, the transverse wavefunction components of which are plotted in (c) for the values of _µ_ indicated by the gray strip. Only the anti-symmetric amplitudes _a−_ and _b−_ are nonzero. As the chemical potential is tuned through the avoided crossing between the bands, weight shifts from _| ⇐, S⟩_ to _| ⇒, A⟩_ (see Eqn. S3). (d) For _VA,y_ = 2∆, the bands are qualitatively similar to (b), but are no longer mirror eigenstates. As shown in (e), the wavefunction of the slow, positive-momentum Fermi point has both symmetric and anti-symmetric components. 

First, we consider the mirror-symmetric case _VA,y_ = 0. The model has four bands [Fig. S1(b)]: the spatial character of the transverse wavefunction can either be symmetric _|S⟩_ (lower energy) or anti-symmetric _|A⟩_ (higher energy), while the spin can be either _| ⇒⟩_ or _| ⇐⟩_ in the _y_ -direction. The longitudinal Rashba term _iαxc_<sup>_†_</sup> _i,τ,σ_<sup>_ci_+1</sup><sup>_,τ,σ_¯+ H.c.</sup> generates momentum split-bands [gray dashed lines in Fig. S1(b)], but spin in the _y_ -direction remains a good quantum number. However, the transverse part of the Rashba term _iασx∂y → iαyc_<sup>_†_</sup> _i,_ 1 _,σ_<sup>_ci,_2</sup><sup>_,σ_¯ +H.c. generates an avoided crossing</sup> between the lower-energy, transverse-symmetric band and the higher-energy, transverse-anti-symmetric band. This inter-band mixing results in hybridization between spin and transverse motional degrees of freedom, so that the transverse character of the resultant low-energy band is given by 



<!-- Start of picture text -->
| + ⟩ =  a + | ⇒, S⟩ +  b + | ⇐, A⟩ (2)<br><!-- End of picture text -->



<!-- Start of picture text -->
|−⟩ =  a−| ⇐, S⟩ +  b−| ⇒, A⟩ (3)<br><!-- End of picture text -->

The numerically-calculated value for the _|−⟩_ coefficients is shown in Fig. S1(c). As _µ_ is swept through the avoided crossing, weight shifts from _| ⇐, S⟩_ to _| ⇒, A⟩_ , with maximal hybridization occurring around _µ ≈−_ 0 _._ 05∆. Critically, although there is hybridization, the new bands are still eigenstates of the mirror operator _My|±⟩_ = _±i|±⟩_ . As such, a mirror-symmetric drive cannot induce transitions between them. 

To model a broken mirror symmetry, we set a non-zero inter-chain potential difference _VA,y_ = 2∆. The bands for this case are depicted in Fig. S1(d). While the change in the energy dispersion relation is subtle, we can see the effect of the broken mirror symmetry in the wavefunction character [Fig. S1(e)]. The band near the avoided crossing now has character of all four basis states _| ⇒, S⟩, | ⇐, S⟩, | ⇒, A⟩, | ⇐, A⟩_ . There are thus no selection rules forbidding transitions induced by a mirror-symmetric drive. 

4 

_2. Andreev Levels_ 

Now we confine the normal region between two superconducting leads with a pair potential ∆and a different chemical potential _µS_ [Fig. S2(a)]. The total number of sites in each of the two chains is _N_ . The superconducting phase difference is applied within the gauge of the _tx_ hopping elements in the middle of the chain, i.e. between sites _N/_ 2 and _N/_ 2 + 1. Symbolically the Hamiltonian is 



<!-- Start of picture text -->
H = � ( ϵi,τ − µi ) c † i,τ,σ ci,τ,σ  +  txc† i,τ,σ ci +1 ,τ,σ − αxc† i,τ,σ ci +1 ,τ,σ ¯ + H.c.<br>i,τ,σ<br>+ � ∆ ici,τ,↓ci,τ,↑ + H.c. + � tyc † i, 1 ,σ ci, 2 ,σ  +  iαyc† i, 1 ,σ ci, 2 ,σ ¯ + H.c. (4)<br>i,τ i,σ<br><!-- End of picture text -->

where _µi_ = _µS_ for the sites in the superconducting leads and _µi_ = _µ_ for the normal region as in the previous section. We simulate the Hamiltonian Eqn. S(4) in Nambu space, fixing _µS_ = 1 _._ 5∆, _N_ = 34, and the number of sites in each lead _N_ leads = 6. We have found that while _N_ leads = 6 is large enough for the qualitative investigation we present here, more lead sites are necessary if quantitative accuracy is desired. 

We examine both the mirror-symmetric case _VA,y_ = 0 and the non-symmetric case _VA,y_ = ∆. We note that we apply _VA,y_ only to the sites in the normal region _N_ leads _< i < N − N_ leads. For both the mirror-symmetric and non-symmetric cases, we find Andreev levels with qualitatively similar energies [Fig. S2(b/c)] and therefore similar inter-doublet transition frequencies [Fig. S2(d/e)]. For _VA,y_ = 0, the Andreev levels are eigenstates of the mirror operator just as in the states of the infinite nanowire. 

Next, we check the drive matrix elements. We model the drive voltage profile as a linear potential drop between the leads _Vd_ ( _x_ ) = _L_ <u>2</u><sup>_V_0</sup><sup>_x_,choosing</sup><sup>_V_0=2∆.Forthemirror-symmetriccase,onlymirror-preservingtransitionscan</sup> be driven regardless of flux [Fig. S2(f)] and chemical potential [Fig. S2(h)], as expected. For _VA,y_ = ∆, we indeed find that all transitions are allowed. However, while the inter-doublet transitions are finite for all values of Φ, the direct spin-flip matrix element goes to zero at Φ _→_ 0 _,_ Φ0 _/_ 2 as required by time-reversal symmetry. We also find that the matrix element of pseudospin preserving and flipping transitions become of similar magnitude for higher chemical potentials [Fig. S2(h)]. This is consistent with the stronger degree of spin-orbital mixing when the chemical potential is close to the next sub-band as shown in Fig. S1(e). 

5 



FIG. S2: (a) Visual representation of the tight-binding model, now including superconducting leads. (b-h) For _VA,y_ = 0 _,_ ∆, we compute the Andreev level energies (b,c), all transition frequencies (d,e), all _Vd_ matrix elements versus Φ (f,g), and _Vd_ matrix elements (drive amplitude _V_ 0 = 2∆) versus _µ_ involving the lowest energy level (h,i). For _VA,y_ = 0, states are colored by their mirror eigenvalue as before: red for +1 and blue for _−_ 1. For _VA,y_ = ∆, states are colored the same as in main text Fig. 1(a). Inter-doublet transition frequencies and matrix elements take the same color as the participating lower doublet state, while those for the intra-doublet transition are grey. Thick dashed lines correspond to pseudospin-conserving transitions, while thin dashed lines correspond to pseudospin-flipping transitions. Vertical dashed black lines in (f)/(g) correspond to Φ for (h)/(i), while vertical dashed black lines in (h)/(i) correspond to _µ_ for (f)/(g). 

6 

**II. EXPERIMENT SCHEMATIC** 



FIG. S3: Cryogenic wiring diagram and device micrographs (see Extended Data of Ref. [34] for original publication). Optical micrograph (e) is of the device on which the presented measurements were performed. Optical micrographs (b), (c), (d) and scanning electron micrograph (f) are of an extremely similar (unmeasured) device, the main difference being that the length of the weak length is 750 nm instead of 500 nm. The microwave readout and drive tones pass through the depicted circuitry (a) before being routed through the ∆port of a 180<sup>_◦_</sup> hybrid resulting in differential microwave voltages at the device input. After reaching two coupling capacitors (c), the readout tone was reflected off the differential _∼ λ/_ 4 mode of the coplanar strip resonator (red, frequency _f_ r = 9 _._ 18843 GHz, coupling _κ_ c = 2 _π ×_ 1 _._ 23 MHz, internal loss _κ_ i = 2 _π ×_ 1 _._ 00 MHz) and then routed through the depicted amplification chain (a), which was comprised of a SNAIL parametric amplifier (SPA) [42], HEMT, and room-temperature amplifiers. In this circuit, the drive tone creates an ac phase drop across the nanowire (f), which is embedded in the superconducting Φ-bias loop (green) at the end of the resonator (d,e). One edge of the loop connects the two strips of the resonator and thereby forms the shared inductance with the nanowire. We controlled the electrostatic potential in the nanowire weak link (f) with a dc gate (pink, voltage _V_ g _,_ c). Gates on the nanowire leads (orange) were used to gain additional electrostatic control (voltage _V_ nw). To reference the resonator/nanowire island to ground, an additional strip runs between the resonator strips, and connects to a large finger capacitor (purple). This strip does not significantly perturb the resonator’s microwave properties because it resides at the zero voltage point with respect to the resonator’s differential mode. 

#### **III. TUNING UP THE DEVICE** 

In this experiment, we possessed three _in-situ_ control knobs of the nanowire Andreev levels: a loop flux Φ [Fig. S3(d, e)], a main gate voltage _V_ g _,_ c acting on the nanowire weak link [Fig. S3(f)], and an additional gate voltage _V_ g _,_ p applied to two more gates positioned on either side of the main gate [Fig. S3(f)]. Upon cooling down the device, we observed Φ and gate voltage dependence of the readout resonance around _V_ g _,_ c _, V_ g _,_ p = 0, indicating that conduction channels in the nanowire link were transmitting. With Φ = _−_ 0 _._ 13Φ0 and _V_ g _,_ p = 0, we swept _V_ g _,_ c while performing two-tone spectroscopy [Fig. S4(a)]. We observed several dispersing transitions, with a local maximum at _V_ g _,_ c = _−_ 71 _._ 0 mV. Parking _V_ g _,_ c at the local maximum to mitigate the effects of electrostatic noise on the Andreev level coherence (see 

7 

below for further data and discussion), we then performed two-tone spectroscopy while sweeping Φ [Fig. S4(b)]. Four flux-dependent resonances were observed, which cross at Φ = 0. This is characteristic of inter-doublet transitions of a quasiparticle between spin-orbit split Andreev levels [26]. In conjunction with the population transfer measurements shown in Fig. 2(a) of the main text, this characteristic spectrum allowed us to identify the two lowest-frequency transitions as _|↑q ⟩↔|↑a ⟩_ and _|↓q ⟩↔|↑a ⟩_ . 

At certain Φ bias points, some of the transitions are not visible, or become significantly dimmer. For example, the _| ↑q ⟩↔| ↑a ⟩_ transition is barely visible at Φ = _≃−_ 0 _._ 13Φ0. This drop in signal occurs because the quasiparticle population of the relevant level of the lower doublet (either _| ↓q ⟩_ or _| ↑q ⟩_ ) decreases, often below 0.01. We attribute these population drops to evacuation of the quasiparticle into cold, dot-like levels in the nanowire that are brought into resonance with the Andreev doublets as Φ, _V_ g _,_ c, and _V_ g _,_ p are varied. While these features are not completely understood, we found they could be easily avoided with an appropriate choice of bias conditions. The effects of these population drops can be observed in Figs. SS4 and SS5. 

Having identified the transitions that defined the Λ system, we searched for a local maximum of the transitions in both gate voltages in order to mitigate electrostatic noise. We found such a bias point at _V_ g _,_ c = _−_ 71 _._ 9 mV and _V_ g _,_ p = 4 _._ 0 mV (see Fig. S5 for Φ-dependence at these gate voltages). 



FIG. S4: Gate and flux dependence of the inter-doublet transitions. (a) A local maximum (“sweet spot”) is observed in both _|↑q ⟩↔|↑a ⟩_ and _|↓q ⟩↔|↑a ⟩_ at _V_ g _,_ c = _−_ 71 _._ 0 mV (black dotted line). (b) Flux dependence of the four inter-doublet transitions at _V_ g _,_ c = _−_ 71 _._ 0 mV, _V_ g _,_ p = 0 _._ 0 mV. Black dotted line indicates Φ bias for data shown in (a). 



FIG. S5: Flux dependence of _|↑q ⟩↔|↑a ⟩_ and _|↓q ⟩↔|↑a ⟩_ at the bias point for all data presented in the main text, excluding Fig. 4 ( _V_ g _,_ c = _−_ 71 _._ 9 mV, _V_ g _,_ p = 4 _._ 0 mV). 

#### **IV. SEARCHING FOR RAMAN TRANSITIONS** 

With the gate voltages set to the optimum values discussed above and Φ = _−_ 0 _._ 10Φ0, we applied simultaneous Gaussian drive pulses of variable carrier frequency, as explained in the main text and Fig. 2(b). Here we present all measured transition probabilities, and over a wider frequency range than in the main text [Fig. S6]. The drive powers used in this measurement were 30 dB larger than in the two-tone spectroscopy measurement of Fig. 2(a). The _|↓q ⟩↔|↑a ⟩_ transition is visible (though broadened) just above its low-power value, while the _|↑q ⟩↔|↑a ⟩_ transition is no longer visible. Other transitions that are constant in one drive frequency or the other are observed, perhaps due to evaporation of the quasiparticle into the same dot-like levels as discussed above. Several multi-photon transitions are observed that lie along _f↑_ = _−f↓_ + _c_ . The _−_ 1 slope indicates that the two drive frequencies are adding to reach a highly-excited state of the system, perhaps exciting the quasiparticle above the superconducting gap or into other dot-like states in the nanowire. Finally, the desired two-photon Raman process _| ↓q ⟩↔| ↑q ⟩_ occurs along the black dashed line, which has slope 1 and intersects with the crossing point of the two single-photon transitions of the Λ 

8 

system (unlike the data shown in Fig. 2(b) of the main text). This measurement was taken between the measurements displayed in Fig. 2(b) and 2(a) of the main text. We thus conclude that there was an uncontrolled shift of the Andreev levels between the measurement shown Fig. S6 and Fig. 2(b), as referenced in the main text. Such jumps were not uncommon in this experiment, and occurred on a timescale of days to weeks. 



FIG. S6: All transition probabilities under the action of simultaneous drive pulses of variable carrier frequencies, as in Fig. 2(b) of the main text. Measured transition frequencies of _| ↑q ⟩↔| ↑a ⟩_ and _| ↓q ⟩↔| ↑a ⟩_ are indicated by pink and purple dashed lines, respectively. Black dashed lines have a slope of one, and run through the crossing point of the two transitions. 

#### **V. COHERENT SPIN DYNAMICS** 

Using an experiment similar to that shown in Fig. S6, we chose drive frequencies such that the desired Raman process _| ↓q ⟩↔| ↑q ⟩_ was being driven, but the drives were maximally detuned from undesired processes. We then varied the amplitudes _A↓_ , _A↑_ to induce coherent oscillations of the quasiparticle spin [main text, Fig. 3(a)]. To better understand these coherent dynamics, we performed a simulation of our system using QuTiP [36] [main text, Fig. 3(b)]. Here we present transition probabilities out of the two spin states under the action of these variable amplitude drive pulses, both measured [Fig. S7(a)] and simulated [Fig. S7(b)] (measurements where the system started in _|g⟩_ showed no features). 

The simulation of the coherent dynamics included all four Andreev levels _| ↓q ⟩_ , _| ↑q ⟩_ , _| ↑a ⟩_ , and _| ↓a ⟩_ [Fig. S7(c)]. While there were only two drives applied in this experiment, because each drive could couple to each of the four inter-doublet transitions we needed to account for a total of eight Hamiltonian terms. Four of these terms produced two Raman processes [dashed double-headed arrows in Fig. S7(c)], one of which was via _| ↑a ⟩_ as desired, and the other was via _| ↓a ⟩_ . The _| ↑a ⟩_ Raman process dominated the dynamics, as the detuning of the drives from _| ↑a ⟩_ was ∆R = _−_ 290 MHz, as compared to the detuning to _|↓a ⟩_ which was ∆<sup>_′_</sup> R<sup>= 1</sup><sup>_._36 GHz.The other four Hamiltonian terms</sup> produced Stark shifts [thin solid double-headed arrows in Fig. S7(c)]. 

The fixed parameters in the simulation were the four inter-doublet transition frequencies, the measured dephasing rates of both doublets, the pulse length and shape (Gaussian, 40 ns standard deviation), and the detunings ∆R = _−_ 290 MHz, ∆<sup>_′_</sup> R<sup>=1</sup><sup>_._36GHz.Wefitthesimulationtothedatausingsixfreeparameters:thefourdrivematrix</sup> elements associated with the four inter-doublet transitions ( _M↓,↑_ , _M↑,↑_ , _M↓,↓_ , _M↑,↓_ ), the detuning _δ_ from the Raman resonance condition, and the ratio _α_ of the _f↑_ drive amplitude to the _f↓_ drive amplitude. From the fit, we extract the 

9 

below values and associated co-variance matrix: 



<!-- Start of picture text -->
δ/ (2 π ) = 5 . 5  +0 . 02 +0 . 01 − 0 . 09 +0 . 2 +0 . 2 +0 . 0003 <br>M↑,↑/ (2 π ) = 232 MHz  +0 . 01 +70 − 50 − 200 +200 +0 . 02 <br> <br>M↓,↑/ (2 π ) = 255 MHz  − 0 . 09 − 50 +30 +100 − 100 − 0 . 02 <br>C =   (5)<br>M↓,↓/ (2 π ) = 280 MHz  +0 . 2 − 200 +100 +500 − 40 − 0 . 05 <br>M↑,↓/ (2 π ) = 80 MHz  +0 . 2 +200 − 100 − 40 +400 +0 . 06 <br>α  = 0 . 54 +0 . 0003 +0 . 02 − 0 . 02 − 0 . 05 +0 . 06 +0 . 00002<br><!-- End of picture text -->

Note that the extracted values of the matrix elements include the drive amplitudes at the device, which we estimate to be _∼_ 400 nV across the junction. We note that, in the experimental data, the oscillation minima/maxima do not lie perfectly along _|A↑|_ = _|A↓|_ ; the inclusion of _δ_ in the fit is necessary to reproduce this. The inclusion of the Stark shift terms, on the other hand, were not needed to reproduce the data, but in reality they must be present. 



FIG. S7: Coherent Λ-Rabi oscillations of the quasiparticle spin, as in Fig. 3 of the main text. (a) Measured final state probabilities after the application of simultaneous drive pulses, with the spin initialized in either _| ↓q ⟩_ or _| ↑q ⟩_ . (b) Simulated probabilities. (c) Level diagram with simulation parameters. 

Additionally, as can be seen in Fig. S7, we observed a drive-induced quasiparticle evaporation rate; the _|g⟩_ population grows as the drive amplitudes are increased. In simulation, we found that this quasiparticle evaporation was captured by including two dissipators on the lower doublet of the form ~~�~~ Γde _−_ trap( _|A↓|_<sup>2</sup> + _|A↑|_<sup>2</sup> + _|A↓||A↑|_ ) _|g⟩⟨↓q |_ , ~~�~~ Γde _−_ trap( _|A↓|_<sup>2</sup> + _|A↑|_<sup>2</sup> + _|A↓||A↑|_ ) _|g⟩⟨↑q |_ , with Γde _−_ trap _/_ (2 _π_ ) = 1 _._ 2 _±_ 0 _._ 1 MHz as extracted from the _|g⟩_ population data. While this is certainly an over-simplified model (no frequency dependence, no spin dependence, etc.), the scaling of the rate with the drive amplitudes indicates that the evaporation is likely due to multi-photon transitions of the trapped quasiparticle to excited states either in the dot-like levels previously discussed or into the continuum above the superconducting energy gap of the leads. This differs with previous results on drive-induced quasiparticle evaporation where a linear scaling of the rate with power was observed [44], most likely because the Andreev levels studied in this work exist at lower energy. These results are also consistent with our observation that the undesired transitions seen in Fig. S7 only occur at high powers. 

10 

Finally, we included readout errors in the simulation by extracting the transition probabilities between the outcomes of the first and second readout pulses for the zero-amplitude experimental data and then applying the resultant transfer matrix to the simulated probabilities for all drive amplitudes. While this did not result in a qualitative change of the data, it was important for replication of the experimental contrast. Note that this is why there are some Raman features visible in the simulated _|g⟩_ data: the rate at which the quasiparticle spontaneously evacuates the junction during readout is slightly spin-dependent. Although we were unable to measure the upper doublet population directly because the dispersive shift of these states was too small at this bias point, the simulation indicates that it was below 20%. 

#### **VI. ANALYSIS OF THE ANDREEV LEVEL COHERENCE TIMES** 

As discussed in the main text, we observed no dependence of the quasiparticle spin _T_ 2 on any of the _in-situ_ bias knobs (Φ _, V_ g _,_ c _, V_ g _,_ p). However, we did find that the coherence times of the inter-doublet transitions depended on _V_ g _,_ c [Fig. S8(a)]. In particular, we found that the _T_ 2 of the _| ↑q ⟩↔| ↑a ⟩_ was maximum around a _V_ g _,_ c sweet spot at _−_ 71 _._ 0 mV. Away from this sweet spot, first-order electrostatic noise contributed to dephasing, causing _T_ 2 to drop. We model this behavior using the relation for exponential coherence decay _T_ <u>12</u><sup>=</sup> �2 _πV_ rms _dVdf_ g _,_ c �2 + Γc, where _V_ rms = 0 _._ 24 _±_ 0 _._ 01 mV is the effective root-mean-square voltage noise and Γc = 0 _._ 012 _±_ 0 _._ 001 ns<sup>_−_1</sup> is a _V_ g _,_ c-independent dephasing rate [45]. We note that the _T_ 2 at the sweet spot is given by Γc, as we found that second-order noise coupling _d_<sup>2</sup> _<u>f</u>_ to _dV_ g<sup>2</sup> _,_ c<sup>wasnegligible[46].</sup> 

To calculate the effect of this electrostatic noise on the quasiparticle spin _T_ 2, we first extracted the _V_ g _,_ c dependence of the _| ↓q ⟩↔| ↑q ⟩_ splitting _ϵ_ s, which is given by the difference between the frequencies of the _| ↓q ⟩↔| ↑a ⟩_ and _|↑q ⟩↔|↑a ⟩_ transitions. We visualize this in Fig. S8(b) by plotting the same two-tone data as shown in Fig. S8(a), but with the fitted value of the _|↑q ⟩↔|↑a ⟩_ transition _f↑↔↓_ subtracted from the drive frequency _fd_ at every _V_ g _,_ c bias. The _|↑q ⟩↔|↑a ⟩_ transition thus lies along _fd − f↑↔↓_ = 0 (pink horizontal line), while the _V_ g _,_ c dependence of _ϵ_ s _/h_ is given by the behavior of _f↓↔↓_ (purple horizontal line). We observe that _ϵ_ s _/h_ has no discernible slope with _V_ g _,_ c, consistent with the lack of a spin _T_ 2 dependence on _V_ g _,_ c. However, using an upper bound on this slope<sup>_dϵ_</sup> _dV_<sup>s</sup> g<sup>_<u>/</u>_</sup> _,_<sup>_h_</sup> c<sup>_<_32MHz</sup><sup>_/_mV</sup> [black dashed line in Fig. S8(b)] and _twice_ the extracted value of _V_ rms as an upper bound on the electrostatic noise [black dashed line in Fig. S8(a)], we find a lower bound on the spin dephasing time of 4 _._ 2 _µ_ s. 



FIG. S8: Extracting a lower-bound on the electrostatic-noise-induced dephasing time of the quasiparticle spin. (a) Same spectroscopy data as shown in Fig. S2(a). A local maximum is observed in both transitions at _V_ g _,_ c = _−_ 71 _._ 0 mV. Measurements of the coherence time of _| ↑q ⟩↔| ↑a ⟩_ are shown in pink (right axis). White dashed line is a fit to the _T_ 2 data assuming firstorder noise in _V_ g _,_ c plus a constant dephasing rate. Black dashed line corresponds to the expected _T_ 2 given this same constant dephasing rate, but _twice_ the _V_ g _,_ c noise. (b) Same data as shown in (a), but with the fitted frequency of the _| ↑q ⟩↔| ↑a ⟩_ transition subtracted from _f_ d for each _V_ g _,_ c bias. Both the purple and pink lines have no slope, and lie along the average values of the two transitions. The yellow dashed line is an upper bound on the slope of the _|↓q ⟩↔|↑a ⟩_ transition. 

#### **VII. ANALYSIS OF THE ANDREEV LEVEL LIFETIMES** 

To extract the transition rates between _|g⟩_ , _|↓q ⟩_ , and _|↑q ⟩_ , we analyzed the quantum jumps of the system using a hidden Markov model algorithm [Fig. S9] [22, 34, 47]. As we reported in Ref. [34], the spin lifetime _T_ s increased with _|_ Φ _/_ Φ0 _|_ . Unlike in the data presented in Ref. [34], at this gate bias point the parity lifetime did vary with Φ due to 

11 

evacuation of the quasiparticle into the cold, fermionic modes discussed above. In Fig. S9, we plot quantum jumps for Φ = _−_ 0 _._ 14Φ0 where _T_ s = 17 _±_ 1 _µ_ s and _T_ parity = 22 _±_ 1 _µ_ s. 



FIG. S9: Quantum jumps of spin and parity at Φ = _−_ 0 _._ 14Φ0. (a) Γ histogram resulting from 10<sup>5</sup> consecutive readout pulses. (b) Plotting _Q_ against time reveals quantum jumps between _|g⟩_ , _|↓q ⟩_ , and _|↑q ⟩_ (only a subset of the time trace is shown). A hidden Markov algorithm was employed to perform state assignment (colored rectangles), as well as to extract all six transition rates between the three states. These are summarized by the parity lifetime _T_ parity = 22 _±_ 1 _µ_ s and spin lifetime _T_ s = 17 _±_ 1 _µ_ s. 

