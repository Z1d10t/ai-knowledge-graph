# Strong-bonding hole-transport layers reduce ultraviolet degradation of perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 249 |
| 作者 | Chengbin Fei, Anastasia Kuvayskaya, Xiaoqiang Shi, Meng-Ru Wang, Zhi-Fang Shi, Hao-Yang Jiao, T. Silverman, Michael Owen-Bellini et al. |
| DOI | 10.1126/science.adi4531 |
| 源文件 | 085_Fei_2024_Strong-bonding-hole-transport-layers-reduce-ultr.pdf |

---
# Strong-bonding hole-transport layers reduce ultraviolet degradation of perovskite solar cells 

Chengbin Fei<sup>1</sup> , Anastasia Kuvayskaya<sup>2</sup> , Xiaoqiang Shi<sup>1</sup> , Mengru Wang<sup>1</sup> , Zhifang Shi<sup>1</sup> , Haoyang Jiao<sup>1</sup> , Timothy J. Silverman<sup>3</sup> , Michael Owen-Bellini<sup>3</sup> , Yifan Dong<sup>4</sup> , Yeming Xian<sup>5</sup> , Rebecca Scheidt<sup>4</sup> , Xiaoming Wang<sup>5</sup> , Guang Yang<sup>1</sup> , Hangyu Gu<sup>1</sup> , Nengxu Li<sup>1</sup> , Connor J. Dolan<sup>6</sup> , Zhewen J. D. Deng<sup>6</sup> , Deniz N. Cakan<sup>6</sup> , David P. Fenning<sup>6</sup> , Yanfa Yan<sup>5</sup> , Matthew C. Beard<sup>4</sup> , Laura T. Schelhas<sup>3</sup> , Alan Sellinger<sup>2,4</sup> , Jinsong Huang<sup>1,7</sup> * 

The light-emitting diodes (LEDs) used in indoor testing of perovskite solar cells do not expose them to the levels of ultraviolet (UV) radiation that they would receive in actual outdoor use. We report degradation mechanisms of p-i-n–structured perovskite solar cells under unfiltered sunlight and with LEDs. Weak chemical bonding between perovskites and polymer hole-transporting materials (HTMs) and transparent conducting oxides (TCOs) dominate the accelerated A-site cation migration, rather than direct degradation of HTMs. An aromatic phosphonic acid, [2-(9-ethyl-9H-carbazol-3-yl)ethyl]phosphonic acid (EtCz3EPA), enhanced bonding at the perovskite/HTM/TCO region with a phosphonic acid group bonded to TCOs and a nitrogen group interacting with lead in perovskites. A hybrid HTM of EtCz3EPA with strong hole-extraction polymers retained high efficiency and improved the UV stability of perovskite devices, and a champion perovskite minimodule—independently measured by the Perovskite PV Accelerator for Commercializing Technologies (PACT) center—retained operational efficiency of >16% after 29 weeks of outdoor testin <mark>g</mark> . 

UV-filter layers or down-conversion luminescent materials (12), they may suffer from instability issues, including wear over years, or increased cost and sacrificed energy yield. 

erovskite solar cells (PSCs) with high power conversion efficiency (PCE) and improved durability and scalability have been reported (1–3). Some devices have P reached T90 lifetimes—the time to a 10% drop in PCE—of >10,000 hours of light exposure, not only for small perovskite cells but also for perovskite minimodules (4). Several strategies were also reported to retain >90% of their initial PCE after light exposure tests at high temperature of 85°C for >1000 hours (5–7). However, almost all of the light-soaking stability tests were conducted using inorganic lightemitting diodes (LEDs) as light sources, which do not have a substantial ultraviolet (UV) component (2, 8–11). There is no demonstration of outdoor stability that shows perovskite modules with an area of >15 cm<sup>2</sup> that still have an aperture efficiency of >15% after 10 weeks of outdoor testing. Thus, a huge gap exists between the indoor and outdoor durability testing results, and much improved outdoor durability is needed. Although it is possible to completely or partially block UV light by using 

Outdoor conditions are different from indoor light soaking or maximum power point (MPP) trackinginseveralways.Temperature,irradiance, and UV light intensity constantly change outdoors. We speculate that the indoor-outdoor durability gap mainly comes from the lack of or weak UV light from most LED lamps for indoor tests because perovskite devices are frequently reported to pass the IEC61215 thermal cycling test (13–15). UV light has been reported to accelerate the degradation of PSCs, but there is still no consensus yet on the mechanisms. Photocatalytic effects have been considered as the main reason for UV-induced perovskite degradation in n-i-p–structured PSCs with titanium dioxide (TiO2) (16) and tin oxide (SnO2) (17) as electron-transport layers. The UV light–generated electrons in TiO2 were reported to convert adsorbed oxygen on TiO2 into hydroxyl radicals that oxidize I<sup>−</sup> to I2 (18). Another study suggested that UV light could directly activate oxygen vacancies and the cations in TiO2 and SnO2, which would prompt the accumulation of I3− (19). In p-i-n– structured devices, UV light was also reported to directly break down the chemical bonds in the organic hole-transporting materials (HTMs), such as poly[bis(4-phenyl)(2,4,6trimethylphenyl)amine] (PTAA), and thus introduce charge-trapping defects (20, 21). 

> 1Department of Applied Physical Sciences, University of North Carolina at Chapel Hill, Chapel Hill, NC 27599, USA. 

> 2Department of Chemistry, Colorado School of Mines, Golden, CO 80401, USA.<sup>3</sup> Materials, Chemicals, and Computational Science Directorate, National Renewable Energy Laboratory, Golden, CO 80401, USA.<sup>4</sup> Chemistry and Nanoscience Center, National Renewable Energy Laboratory, Golden, CO 80401, USA.<sup>5</sup> Department of Physics and Astronomy, University of Toledo, Toledo, OH 43606, USA. 

> 6Department of Nanoengineering, University of California San Diego, La Jolla, CA 92093, USA.<sup>7</sup> Department of Chemistry, University of North Carolina at Chapel Hill, Chapel Hill, NC 27599, USA. *Corresponding author. Email: jhuang@unc.edu 

In this work, we investigate the mechanism of UV light–induced degradation in p-i-n– structured PSCs with organic HTMs and develop a method to narrow down the gap be- 

tween indoor and outdoor durability. The trap density of the perovskite/indium tin oxide (ITO) substrate interface in the devices increased with exposure under UV light and generated more positively charged iodine interstitials, which accelerated the cation migration and phase segregation at the buried perovskite/ITO interface. Using this HTM with improved bonding in the PSCs, the perovskite/ ITO interface was stabilized and then used in minimodules with demonstrated record outdoor stability. 

## Solar cell degradation mechanism under outdoor test 

To evaluate the indoor and outdoor durability, we fabricated small-area devices with a p-i-n structure of ITO/PTAA/FA0.9Cs0.1PbI3/C60/ bathocuproine (BCP)/Cu, where FA is formamidinium (fig. S1A). The spectra of lamps used for light-soaking stability evaluation are shown in fig. S2 together with the solar spectrum. The UV light in most commercial LED lamps for the indoor testing was found to be extremely weak and constituted <0.1% of total light, far lower than the 4.6% UV light in the solar spectrum. After light soaking under a LED lamp at 60° ± 5°C and open-circuit (OC) conditions for ~200 hours, these optimized devices with a polyisobutylene (PIB) blanket encapsulation retained ~103% of the initial PCE (Fig. 1A), which is consistent with our prior results (2, 22). However, outdoor devices with the same encapsulation were tested under OC conditions in North Carolina, USA in October 2021, when there was an average temperature of ~20°C in daytime (fig. S1), and they showed a rapid reduction in PCE by ~21% after 10 days. The degradation of devices was mainly from the reduced short-circuit current density (JSC) and fill factor (FF). 

The main difference between the indoor and outdoor tests should be the temperature, light source, and the light cycling. Temperature is likely not the key factor difference because the outdoor temperature was even lower than the indoor temperature. In addition, our recent study showed that the smallarea devices using the same device structure could last >3000 hours under light exposure tests at 60° ± 5°C (2). After 35 cycles of standard light cycling (ISOS-LC-1) testing (fig. S3) (23), the devices kept ~105% of initial PCE, which excludes the light cycling as the main reason for the fast outdoor degradation. Thus, the higher UV component in sunlight is likely the main reason for faster degradation. We used a light emission plasma (LEP) lamp, which contains 3.5% UV light, to simulate sunlight (fig. S2C). After covering the devices with a long-pass optical filter with a cut-off wavelength of 435 nm, the rapid degradation disappeared at the initial stage (fig. S4), which confirms that UV light is likely responsible 



<!-- Start of picture text -->
A B<br>25<br>20<br>Indoor<br>15<br>Outdoor<br>0 100 200 Initial Indoor Outdoor<br>Duration (hours)<br>C D E<br>1.0 Before 1.0 Before<br>After After<br>0.5 Bottom 0.5 Top<br>0.0 0.0<br>0 1000 2000 0 1000 2000<br>Time decay (ps) Time decay (ps)<br>F 2000 G<br>Before After Before After<br>808<br>0 804<br>20 800<br>796<br>0<br>H I<br>Before After Before After<br>0.25<br>0.20<br>0.15<br>0.10<br>0.05<br>0.00<br>Fig. 1. Perovskite degradation in indoor and outdoor conditions. (A) (A)A)) Indoor UV inside, 60° ± 5°C, OC conditions) tested from the bottom (D) and top (E) side.<br>and outdoor light-soaking stability of PSCs. The devices tested indoors were (F and G) PL intensity-lifetime mapping (F) and the corresponding PL emission<br>under an LED lamp (100 mW cm −22 with <0.1% UV inside, 60° ± 5°C, OC peak wavelength mapping (G) of the PTAA-based perovskite films before and after<br>conditions), and those tested outdoors were under sunlight and ~20°C average LEP lamp illumination for ~100 hours. The images were collected from the bottom<br>daytime temperature (North Carolina, USA). (B)B)) Photographs of the PSCs side. Scale bars, 10 mm. (H) SEM images of the bottom perovskite layer before<br>(ITO/HTM side) before and after indoor and outdoor tests. Scale bars, 2 mm. and after LEP light illumination for ~200 hours. Scale bars, 5 mm. (I) XRF mapping of<br>C)) Illustration for the TR spectroscopy test of the perovskite films. (DD and E)) TR the Cs/I ratio of the bottom perovskite layer before and after light illumination.<br>decay of the LEP lamp–illuminated–illuminatedilluminated perovskite films (100 mW cm −22 , with ~3.5% Scale bars, 5 mm.<br>Efficiency (%)<br>Events (Cnts)<br>Fast Lifetime (ns)<br><!-- End of picture text -->

Fig. 1. Perovskite degradation in indoor and outdoor conditions. (A) (A)A)) Indoor and outdoor light-soaking stability of PSCs. The devices tested indoors were under an LED lamp (100 mW cm<sup>−22</sup> with <0.1% UV inside, 60° ± 5°C, OC conditions), and those tested outdoors were under sunlight and ~20°C average daytime temperature (North Carolina, USA). (B)B)) Photographs of the PSCs (ITO/HTM side) before and after indoor and outdoor tests. Scale bars, 2 mm. (C)) Illustration for the TR spectroscopy test of the perovskite films. (DD and E)) TR decay of the LEP lamp–illuminated–illuminatedilluminated perovskite films (100 mW cm<sup>−22</sup> , with ~3.5% 

only lost 0.5% of their PCE compared with the reference devices (fig. S5C), which was 1/10 of the reduction in Fig. 1A and is mainly from the OC voltage (VOC) reduction. The PCE loss in the outdoor test was dominated by the reduction of JSC and FF, which suggests a different degradation mechanism. 

for the accelerated device degradation in the outdoor test. 

PTAA powder was used for device fabrication (fig. S5A). The absorption spectra change of PTAA was used to characterize the degree of damage to the PTAA layer by UV light illumination (fig. S5B). PTAA shows an absorption in the wavelength range <425 nm. The absorption peak of the PTAA film prepared from UV-irradiated PTAA was reduced by ~45% and showed obvious UV damage. However, devices prepared using the UV-irradiated PTAA 

UV light may damage primary chemical bonds in PTAA and perovskites or the secondary bonding at the ITO/PTAA/perovskite region. To pinpoint which one dominates the UVinduced device degradation, PTAA powder was exposed to a UV lamp (390 to 400 nm) with a light intensity of 10 mW cm<sup>−2</sup> in N2 atmosphere for ~200hours, and the UV-irradiated 

We then checked the perovskite film stability and PCE evolution with In<sup>3+</sup> surface processing because In<sup>3+</sup> ions in ITO have been 

We studied both top and bottom interfaces with incident blue excitation light from both sides of the perovskite films before and after 100 hours of illumination under an LEP lamp. At the perovskite film bottom, many dark spots appeared after illumination in the photoluminescence (PL) intensity mapping images (Fig. 1F). The optical bandgap mapping by tracking the PL emission peak showed that the illuminated films became more nonuniform (Fig. 1G), which confirmed phase segregation induced by cation migration in FACsPbI3. For the perovskite top surface, the changes in PL intensity and bandgap mapping were much smaller after illumination (fig. S8, A and B). Thus, the degradation under the LEP lamp started from PTAA side and was induced by cation migration. The PL peak position of the fresh samples at the top side blue shifted by 3 nm compared with the bottom side (fig. S8D), which reflected a different Cs ratio in the vertical direction in this composition (26). 

of the perovskite and with short wavelength excitation. The fast initial decay of the amplitude represents carriers moving out of the probing region (carrier diffusion from the surface to the bulk), and the longer time kinetics represents the total carrier density decay reflecting both surface and bulk recombination. We observed no change of the fast decay when light entered from the perovskite/air side, which indicates no degradation of perovskite within the probing region at the top surface. 

hypothesized to leach into the perovskite under UV treatment and cause perovskite damage (24, 25). As shown in fig. S6, the perovskite films with indium tribromide (InBr3) surface treatment did not show faster color changes (yellowing) under the LEP lamp than samples with formamidinium bromide (FABr) surface treatment. The device durability showed a similar trend, which indicates that In<sup>3+</sup> is unlikely to have introduced additional perovskite damage. Therefore, the accelerated degradation in outdoor test comes from either fast degradation of perovskite itself or the breakdown of the weak interface between perovskites and the underlying ITO/PTAA substrates. 

The longer time decay improved after 300hoursofLEPexposure,whichwasmostlikely the result of improved surface recombination. During probing of the perovskite/PTAA/ITO side, the fast component underwent noticeably slower decay after 300 hours, which indicates that a large reduction in carrier mobility (slower carrier diffusion away from the surface) occurred in the perovskite film near the PTAA side after photodegradation. As shown in fig. S7 and table S1, the grazing incident x-ray diffraction (GIXRD) was also conducted from the top surface of the photodegraded perovskite films with different incident angles (w). With the increase of w from 0.3° to 1° that resulted in increased x-ray penetration depth, the ratio of yellow-phase and black-phase perovskite increased by ~90%, which confirms the faster degradation of perovskites near the PTAA side. 

The ITO side of the PSCs changed from a dark color initially to gray after the ~200 hours test under LEP light (3.5% UV, ~100 mW cm<sup>−2</sup> , 60° ± 5°C, OC conditions), which indicates changes in the perovskite layer (Fig. 1B). To understand the material change, we performed transient reflectance (TR) spectroscopy analysis on perovskite films before and after light soaking. The perovskite films were deposited on ITO/PTAA substrates and illuminated from the ITO side. The perovskite film was excited and probed from the top side (perovskite/air) and bottom side (ITO/PTAA) with a pump laser wavelength of 400 nm, which penetrates <50 nm into perovskites (Fig. 1, C to E). In TR spectroscopy experiments, the light only probes ~20 nm 

Scanning electron microscope (SEM) images revealed that several needle-shaped regions emerged at the bottom of the perovskite films (Fig. 1G), which was different from the morphology of pristine FA1-xCsxPbI3. Similar morphologies were also observed in x-ray fluorescence (XRF) mapping (Fig. 1H), in which these needle regions had higher Cs/I element ratios and pronounced segregation of A-site cations. A 



Fig. 2. Mechanism of UV-induced perovskite degradation. (A) J-V curves of PTAA-based small devices illuminated under an LEP light (100 mW cm<sup>−2</sup> , with ~3.5% UV inside, ~60°C, OC conditions) at the initial stage. (B and C) Trap density of PTAA-based PSCs illuminated by LEP lamp (B) and LED lamp (C) for different times. (D) Temperature-dependent dark conductivity of the lateral structure devices before and after 50 hours illumination under the LEP lamp. The inset is the sample configuration. (E) Schematic degradation process of perovskite under light illumination with strong UV light. 

weak phase segregation was also observed in FA1-xCsxPbI3 under the LED lamp by PL mapping, but only after 2000 to 3000 hours (fig. S8C). The more severe and faster phase segregation under the LEP lamp indicates that UV light accelerated the migration of A-site cations and phase segregation by >10 times. 

To understand why and how UV light accelerated the phase separation of A-site ions, we studied the evolution of J-V curves (where J is current density and V is voltage) and the trap density in the devices with PTAA as the HTM. The samples were exposed to LEP light with a light intensity of 100 mW cm<sup>−2</sup> at ~60°C. With increased light exposure time from 0 to 20 hours, the PCE of the devices decreased monotonically (Fig. 2A). The trap density of state (tDOS) of the devices was measured by thermal admittance spectroscopy and typically exhibited three distinct trap bands (I, II, and III), which represent Ii− and Ii+ defects and a defect related to amorphous regions near the bottom interface, respectively, in iodide-based PSCs (27, 28). As shown in Fig. 2B, defects in all trap bands monotonically increased, which is consistent with the trend in the PCE reduction of the device. The initial large background Ii− density made the change less distinct for Ii+ defects. Nevertheless, the marked increase of already high-density trap band III indicated that the perovskites near the bottom interface became much more amorphous. Figure 2C shows the variation of tDOS of the devices made in the same batch but exposed to LED lamps of the same light intensity. Only a very small change in trap band II was observed, but no notable change was observed for trap band I and III. 

The temperature-dependent dark conductivity was also measured to evaluate ion migrationnear the bottomperovskites. To measure the ion migration near the bottom interface, a narrow (30-mm) channel was formed by etching ITO so that we could evaluate the lateral ion migration with the device structure shown in Fig. 2D. After 50 hours of illumination under the LEP lamp, the derived ion migration activation energy (Ea) decreased from 410 to 266 meV, which indicates accelerated ion migration near the ITO/PTAA/perovskite interface region after aging. All of these studies showed that the UV light–induced degradation of device was caused by damage in this region. 

We hypothesize that the weak interaction of perovskites with PTAA and ITO at the bottom is adversely affected by UV light and makes the buried perovskite interface resemble the top perovskite surface. The formation of dangling bonds (29) resulted in faster ion migration at the bottom of the perovskite films and accelerated the phase segregation, which breaks down the crystal and generates more point defects. The Ii+ defects could trap photogenerated electrons and leave excess holes for the devices under illumination. Excess 



<!-- Start of picture text -->
A B<br>KOH, Pd[P(tBu)3]2,<br>Acetone, Ncy2Me dioxane,<br>40ºC 80ºC<br>TES,<br>Pb 2+ 10%Pd/C,<br>THF/EtOH<br>-NH2, =O, -X,<br>-P(OH)2, -C-OH<br>ITO O O (EtCz3EPA)<br>C<br>31.3º 18.9º 24.2º<br>PTAA:BCP EtCz3EPA EtCz3EPA/PTAA:BCP<br>D<br>2 2 2<br>E F G<br>0 0 0<br>-2 -2 -2<br>H I J<br>K L M<br><!-- End of picture text -->

Fig. 3. Molecular design for stronger-bonding HTMs. (A) Schematic interfacial contact of perovskite, bifunctional molecular, and ITO substrate. (B) Synthesis route of EtCz3EPA. EtOH, ethanol; HO, hydroxide; KOH, potassium hydroxide; Ncy2Me, N,N-dicyclohexylmethylamine; NH2, amine; OH, hydroxyl; tBu, tert-butyl; TES, N-tris(hydroxymethyl)methyl-2-aminoethanesulfonic acid; THF, tetrahydrofuran. (C) Contact angles of FAPbI3 solution (1 M, dissolved in 2-ME) on different HTM substrates. 2-ME, 2-methoxyethanol. (D) Illustrations for the different HTMs on the ITO substrate. (E to G) AFM-IR spectroscopy of different HTMs on ITO substrates: PTAA:BCP (E), EtCz3EPA (F), and the hybrid HTM (G). The images were collected at the wave numbers of 1028, 1012, and 1028 cm<sup>−1</sup> , respectively, which correspond to C-H bending in the -CH3 groups. Scale bars, 1 mm. (H to M) SEM images of the bottom morphology of perovskite layer peeled from different ITO/HTM substrate before [(H) to (J)] and after [(K) to (M)] ~1000 hours annealing process under 85°C in the dark. (H) and (K) are PTAA:BCP-based samples, (I) and (L) are EtCz3EPA-based samples, and (J) and (M) are the hybrid HTM–based samples. Scale bars, 2 mm. 

Enhancing UV and outdoor stability using bilateral bonding HTMs 

holes have been shown to accelerate the migration of the A-site cations (30) and eventually lead to the segregation of cations at the bottom of perovskite films (Fig. 2E). 

On the basis of this hypothesis, enhancing the interaction of perovskites with ITO and HTM 

is needed to improve the UV and thus outdoor stability of these devices. We chose linker molecules that could anchor to ITO at one end and bond to perovskites at the other end (Fig. 3A). As shown in fig. S9, several new and existing molecules were selected as linkers and used to replace the PTAA or form a linker/PTAA hybrid layer structure as the HTM, which included a new molecule [2-(9-ethyl-9H-carbazol3-yl)ethyl]phosphonic acid (EtCz3EPA) and well-studied [2-(9H-carbazol-9-yl)ethyl]phosphonic acid (2PACz) (10, 31–34). The acid groups such as carboxyl (-COOH) and -PO(OH)2 can be linked to the OH groups on ITO substrate, whereas -NH-, =O, halide (-X), and carbazole groups can interact with Pb<sup>2+</sup> in the perovskites. The chemical structure, synthesis route, and characterizations of EtCz3EPA are shown in Fig. 3B and fig. S10. The EtCz3EPA synthesis used inexpensive chemicals, mild reaction conditions, and simple purification steps. EtCz3EPA had similar carbazole and phosphonic acid groups as 2PACz, but the side chain with the phosphonic acid group was directly linked to the aromatic rings rather than N in the carbazole. Density functional theory (DFT) calculations (fig. S11) showed that the carbazole group in 2PACz prefers to align normal to the perovskite surface and had a small binding energy of 0.259 eV with perovskites. By contrast, the carbazole group in EtCz3EPA with an ethyl group preferred to stay in an in-plane direction, which allowed for better interaction of N with Pb<sup>2+</sup> in perovskite. The binding energies of EtCz3EPA on the (111) plane of the In2O3 surface and the (001) plane of the FAPbI3 surface are 0.70 eV and 0.78 eV stronger, respectively, than that of 2PACz. The use of the EtCz3EPA molecule as an interfacial binder is expected to reduce the formation of point defects at the buried interface and suppress UVinduced degradation. The device fabricated with EtCz3EPA also exhibited higher PCEs and improved stability under the LEP lamp compared with the other molecules tested in this study (fig. S12), so we selected EtCz3EPA as the linker for the continued study. 

Direct use of EtCz3EPA to replace PTAA initially resulted in inferior device performance, mainly because of the lower conductivity and hole-extraction capability of EtCz3EPA. The TR decay of EtCz3EPA-based samples showed a 1.7-fold longer lifetime than the PTAA-based sample, which confirmed the faster hole extraction of PTAA (fig. S13). Because excess holes play a critical role in the UV-accelerated perovskite degradation, we applied an EtCz3EPA/ PTAA:BCP hybrid HTM, in which a layer of BCP-doped PTAA is coated on EtCz3EPA. This hybrid HTM enhanced device efficiency and stability. BCP was added into PTAA to improve the structural stability of perovskites at the bottom interface through chelation of BCP with lead ion (2). However, BCP itself did not 

enhance the interaction of perovskite with ITO because BCP did not interact with ITO. The contact angle measurement results showed that the FAPbI3 solution had much better wetting on EtCz3EPA than on PTAA:BCP (Fig. 3C). The intermediate contact angle of the hybrid HTM suggested that the PTAA:BCP layer on the top of EtCz3EPA is likely noncontinuous, as shown in Fig. 3D, and provides enough area for the contact of perovskite and the bottom EtCz3EPA. 

We conducted atomic force microscope– infrared (AFM-IR) spectroscopy measurements to understand the distribution of the HTM layer on the ITO substrate. The IR signal was collected from the peak of 1012 or 1028 cm<sup>−1</sup> , which corresponds to the C-H bending vibrations in the -CH3 group. As shown in Fig. 3, E and F, and fig. S14, neither PTAA:BCP nor EtCz3EPA exhibited homogeneous coverage on the ITO substrate. EtCz3EPA showed a weaker signal because it formed a much thinner layer. PTAA:BCP coated on EtCz3EPA was a much less continuous film and left regions that exposed EtCz3EPA, which allowed the direct contact of EtCz3EPA with the perovskite (Fig. 3G). The diameter of the EtCz3EPA region is small enough that photogenerated holes can still diffuse to PTAA:BCP for efficient collection. 

Perovskite films were then deposited onto different HTMs to check the bonding strength of perovskites with the ITO/HTM substrates, which was evaluated by our previously established peeling-off method (9, 35). The bottom surfaces of perovskites peeled from hybrid HTMs were rougher than those from PTAA: BCP regardless of the annealing process, as shown in the SEM images in Fig. 3, J and M, which suggests that the fracture of perovskites occurred in some regions where perovskites stick strongly to ITO during the peel-off process (fig. S15, A and B). Perovskites prepared on PTAA detached at the perovskite/ITO interface.TheperovskitefilmspreparedonEtCz3EPAonly or the hybrid HTMs failed cohesively in the perovskite layer, which suggests a stronger adhesion of perovskites with ITO and the EtCz3EPA linker. This finding also implied a stronger interaction of EtCz3EPA with both ITO and perovskites than PTAA:BCP. The 2PACz-based sample was between the PTAAand EtCz3EPA-based samples, and the exposed bottom surface was smoother than that of the EtCz3EPA-based sample (fig. S15C). 

Single-lap shear tests were performed to verify the interface bonding strength of perovskite films and the ITO/HTM substrates according to the ASTM D1002 standard (36) with the test setup shown in fig. S16A. The observed fracture modes were the same as the peeling-off test, as shown by the photos of the fractured films in fig. S16B. The average critical shear stress (sc) of PTAA:BCP-, 2PACz-, and EtCz3EPAbased samples are 1.25 MPa, 2.79 MPa, and 

4.01 MPa, respectively (fig. S16C). This result again showed that the adhesion of EtCz3EPA with perovskites was the strongest among all the HTMs tested, which explains why the EtCz3EPA-based devices had better lightsoaking stability under LEP illumination. 

Our previous study showed that voids near the embedded interface could be generated after long-term light soaking or thermal annealing mainly because of the recrystallization of amorphous regions in the absorber layer (9). Here, we annealed the samples in the dark at 85°C, which drove the evaporation of residual dimethyl sulfoxide (DMSO) and the recrystallization. For devices with EtCz3EPA-only or hybrid HTMs, the peeled-off perovskite films did not show voids in both pristine samples and after ~1000 hours thermal annealing at 85°C (Fig. 3, I, J, L, and M). By contrast, the perovskite film grown on PTAA:BCP showed many voids with sizes of 30 to 100 nm formed around the grain boundaries after the annealing process (Fig. 3K). Therefore, the perovskites grown on EtCz3EPA are less amorphous, which indicates that EtCz3EPA affected the perovskite nucleation and crystallization process. The GIXRD patterns in fig. S17 show the enhanced crystallinity of bottom perovskite that was prepared based on the ITO/EtCz3EPA substrate. 

## Improved long-term stability for PSCs 

The J-V curves of the as-prepared and lightsoaked devices with different HTMs are shown in Fig. 4, A to C. After 2 days of testing under LEP light, the PTAA:BCP-based devices showed decreased FF and 9% loss in PCE, whereas the EtCz3EPA-based devices showed decreased VOC and only 1% PCE loss. BCP can only bond to perovskites but has negligible interaction with ITO, which leads to a similar variation trend for J-V curves from PTAA:BCP- and PTAA-based devices. When we did the same measurement to measure the ion migration activation energy with the device structure in Fig. 2D, a larger Ea of 546 meV was observed, which indicates better crystallinity of perovskite at the bottom interface grown on EtCz3EPA and is consistent with the GIXRD results (37, 38). 

After illumination for 50 hours under LEP light, only a slight reduction of Ea (523 meV) was observed, which shows that stronger bonding reinforced the bottom interface (fig. S18). The PL emission peak mapping of the EtCz3EPAbased samples also showed more uniform bandgap distribution than that of PTAA-based samples after the LEP light illumination, which confirmed suppressed cation migration (fig. S19). The PL peak position of fresh samples measured from the top side and bottom side almost overlapped (fig. S8E) and showed a more homogeneous composition along the vertical direction. This result highlighted the 



Fig. 4. Long-term stability of PSCs. (A to C) J-V curves of small devices (0.08 cm<sup>2</sup> ) with different HTMs and 50 hours LEP light soaking: PTAA:BCP (A), EtCz3EPA (B), and the hybrid HTM (C). (D to F) Corresponding trap density of PSCs based on PTAA:BCP (D), EtCz3EPA (E), and the hybrid HTM (F) and illuminated by LEP lamp for 50 hours. (G and H) Light-soaking stability of small-area devices (OC conditions, 60° ± 5°C) based on different HTM layers under the illumination of an LED lamp (G) 

and an LEP lamp (H). The light intensities of the lamps were calibrated to 100 mW cm<sup>−2</sup> . (I) Damp-heat test under 85°C and 85% humidity (ISOS-D-3) of the small devices for ~1000 hours. RH, relative humidity. (J) Thermal cycling test between −40° and 85°C of the small devices for 200 cycles. All the data for the small devices in the long-term stability test were collected from 20 to 30 devices for each group. 



<!-- Start of picture text -->
A B<br>80<br>60<br>40<br>PTAA:BCP (Reverse)<br>PTAA:BCP (Forward)<br>20<br>EtCz3EPA/PTAA:BCP (Reverse)<br>EtCz3EPA/PTAA:BCP (Forward)<br>0<br>0 2 4 6<br>Voltage (V)<br>C 0.4<br>June 25, 2023 20<br>0.3 15<br>0.2 10<br>P0014-02<br>0.1 P0014-03 5<br>P0014-04<br>0.0 0<br>5 10 15 20 5 10 15 20<br>Time Time<br>D P0014-02 No temperatureLight barsand spectrumhave <4 kWh/mcorrection 2 POAI<br>(17.88 cm 2 ) Hidden bars have snow or missing data<br>20<br>15<br>10<br>5<br>0<br>0 10 20 30 40 50 60 70<br>Duration (days)<br>Current (mA )<br>Power (W)<br>Efficiency (%)<br>Efficiency (%)<br><!-- End of picture text -->

Fig. 5. Outdoor test of perovskite minimodules. (A) J-V curves of the minimodules based on PTAA:BCP and the hybrid HTMs. The minimodules with an aperture area of 17.88 cm<sup>2</sup> and PDMS antireflection layers have been presoaked under an LED lamp for ~100 hours to achieve highest efficiency. (B) Typical photograph of the outdoor stability testing system for perovskite modules. (C) Daily output power and efficiency of the minimodules on 25 June 2023. (D) Outdoor test of hybrid HTM–based perovskite minimodule measured by PACT center. The minimodule was measured without PDMS antireflection layer and stored in the dark for ~7 weeks before testing outdoors. The daily efficiency is calculated by the daily energy delivered by the photovoltaic device divided by the daily energy incident on the device. The incident power is the irradiance measured by a broadband pyranometer multiplied by the device aperture area. POAI, plane of array irradiance. 

importance of the connection between ITO, the HTM, and perovskites. Although the trap density of the EtCz3EPA-based device was substantially lower than those of the PTAA: BCP-based devices, trap bands II and III still increased after light soaking (Fig. 4, D to F). This result was consistent with the evolution of device efficiency, which suggests that the ITO/perovskite interface has not been effectively stabilized under UV light by BCP addition. The trap density of the EtCz3EPA/PTAA: BCP-based devices did not have a substantial increase after illumination, which is consistent with J-V results and could be attributed to the faster hole extraction of the additional PTAA: BCP layer. 

evaluate the long-term stability. As shown in Fig. 4G, the PTAA:BCP-based devices showed a T90 lifetime of ~3240 hours under LED lamp, which is consistent with our previous result on the basis of lead-chelation capable molecules (2). The hybrid HTM–based devices had an increased T90 lifetime of ~4610 hours. Under LEP light with ~3.5% UV, the PTAA:BCP-based devices showed a T90 lifetime of ~190 hours, whereas the devices with hybrid HTMs had a T90 lifetime of ~1780 hours (Fig. 4H). 

We also conducted the damp-heat test at 85°C and 85% humidity (ISOS-D-3) (23) on the PIB-encapsulated small devices for 1000 hours, which examined not only the encapsulation quality but also the intrinsic heat stability of perovskites (Fig. 4I). The devices with all three types of HTMs showed <2% efficiency loss 

The light-soaking stability of these devices with an active area of 8 mm<sup>2</sup> was measured to 

after ~1000 hours of testing. In addition, all of the devices with three types of HTM passed the thermal cycling test with <2% efficiency loss after 200 thermal cycles between −40° and 85°C (Fig. 4J). 

## Outdoor performance testing of perovskite minimodules 

We upscaled the HTM coating and fabricated minimodules with an aperture area of 15 to 50 cm<sup>2</sup> . As shown in Fig. 5A, the minimodule based on a hybrid HTM showed a PCE of 22.1% measured near room temperature. This value is comparable to that of the PTAA:BCP-based minimodules (21.6%) after being exposed to a 1-sun LED lamp for ~100 hours and is indicative of good uniformity of the hybrid HTM. The polydimethylsiloxane (PDMS) film was applied as an antireflective layer on the surface of the ITO glass, which increased the photocurrent by ~6% and was removed during the outdoor tests. The minimodules had the same encapsulation as the small-area devices. Although laser scribing area in modules may impose additional degradation pathways, we did not observe a reaction of the Cu electrode with perovskites after light soaking the minimodules for 4000 hours (fig. S20). 

The encapsulated minimodules were then sent to the Perovskite PV Accelerator for Commercializing Technologies (PACT) center for independent outdoor testing (39). The minimodule PCEs were measured outdoors in Colorado, USA from May to September of 2023. The minimodules were deployed in the field on a fixed-tilt rack (Fig. 5B), and the module surface temperature was monitored daily. The maximum module surface temperature reached 50°C during the summer of 2023 (fig. S21). The minimodules were actively loaded at MPP, except at night, when they were kept at short circuit. The irradiance was measured using a broadband thermopile pyranometer and used in efficiency calculations, which may yield a different PCE to those measured under a solar simulator. There were no temperature, spectrum, angle of incidence, or other corrections applied to field test results to the testing system. 

The evolution in device PCE over a single day measured in outdoor conditions. For a daily output evaluation (Fig. 5C) showed that the PCE of the champion minimodules stayed at a plateau of >18% for ~9 hours. As shown in Fig. 5D and fig. S22, the operational PCE of the best minimodule remained 17.5% after 10 weeks of outdoor testing in the summer from May 2023, and the average operational efficiency of the minimodules was >16%. The initial PCE of the minimodule (~15%) at the operational temperature was measured after 7 weeks dark storage between fabrication and field deployment and recovered to ~18% after operation for 6 weeks outdoors. The daily PCE 

of the minimodules increased for the first several weeks of testing before it began to decline, which is a normal light-soaking effect of this perovskite composition. The daily PCE of the best minimodule installed from September 2023 remained >16% after 29 weeks of outdoor testing (fig. S23). This is the longestlasting minimodule tested at the PACT center to date (40). 

The device’s PCE measured in the testing field is different from those measured at roomtemperature indoor testing because of the differences in light intensity, light spectrum, and temperature. The perovskite temperature was higher than module surface temperature because the perovskites were heated by sunlight. We used a hot plate to control the module surface temperature to be between 40° and 50°C, with the module being covered by a glass container to minimize airflow, and found that the perovskite temperature was measured to be 8° to 10°C higher using a solar simulator and a perovskite minimodule with the same size and encapsulation (fig. S24). The temperature difference of perovskites and module surface may be slightly different in the field. 

We tested how sensitive these modules are to light intensity and temperature using minimodules fabricated by the same process. As shown in figs. S25 and S26, the PCE of minimodules was almost constant with light intensity from 20 to 100 mW cm<sup>−2</sup> . However, they showed a temperature coefficient of −0.32% °C<sup>−1</sup> , which is still better than that of silicon solar cells but larger than has been reported for MAPbI3-based minimodules (41). 

## Discussion 

We identified the UV-induced perovskite degradation mechanism and showed that the introduction of a stronger interconnection layer to the devices improved the outdoor stability of the perovskite minimodules. UV light directly damaged the interface of perovskite and the substrate, which resulted in inefficient hole extraction and accelerated the A-site cation migration.Theintroductionofstronger-bonding molecules at the buried interface reduced the amorphous phase around the perovskite/HTM/ ITO region and suppressed cation migration 

under UVlight. With the hybrid HTM EtCz3EPA/ PTAA:BCP in the small-area PSCs, the T90 lifetimes measured under LED and LEP lamps were increased to ~4610 and ~1780 hours, respectively. The champion minimodule with the hybrid HTM retained an operational efficiency of >16% after 29 weeks of outdoor testing independently measured by the PACT center. 

### REFERENCES AND NOTES 

1. J. Park et al., Nature 616, 724–730 (2023). 

2. C. Fei et al., Science 380, 823–829 (2023). 3. Y. Zhao et al., Science 377, 531–534 (2022). 

4. G. Grancini et al., Nat. Commun. 8, 15684 (2017). 5. C. Li et al., Science 379, 690–694 (2023). 6. X. Zhao et al., Science 377, 307–310 (2022). 7. M. Wang et al., Nat. Energy 8, 1229–1239 (2023). 8. N. Li et al., Science 373, 561–567 (2021). 

9. M. Wang, C. Fei, M. A. Uddin, J. Huang, Sci. Adv. 8, eabo5977 (2022). 

10. X. Zheng et al., Nat. Energy 8, 462–472 (2023). 

11. J. Yin, X. Shi, L. Wang, H. Yan, S. Chen, Angew. Chem. Int. Ed. 61, e202210610 (2022). 

12. N. U. Rahman et al., J. Mater. Chem. A 7, 6467–6474 (2019). 

13. L. Shi et al., Science 368, eaba2412 (2020). 14. T. Wang et al., Nat. Commun. 14, 1342 (2023). 15. X. Xiao et al., Sci. Adv. 7, eabi8249 (2021). 

16. H. Hussain et al., Nat. Mater. 16, 461–466 (2017). 17. R. Liu, L. Wang, Y. Fan, Z. Li, S. Pang, RSC Adv. 10, 11551–11556 (2020). 

18. W. Li, J. Li, G. Niu, L. Wang, J. Mater. Chem. A 4, 11688–11695 (2016). 

19. J. Ji et al., iScience 23, 101013 (2020). 

20. M. Petrović et al., Nanoscale Adv. 1, 3107–3118 (2019). 21. J. H. Park, O. J. Kwon, T.-H. Kim, J. Mun, Y. D. Park, Org. Electron. 62, 394–399 (2018). 

22. Y. Deng et al., Nat. Energy 6, 633–641 (2021). 23. M. V. Khenkin et al., Nat. Energy 5, 35–49 (2020). 24. R. A. Kerner, B. P. Rand, ACS Appl. Energy Mater. 2, 6097–6101 (2019). 

25. Q. Jiang et al., Nature 623, 313–318 (2023). 

26. Z. Liang et al., Nature 624, 557–563 (2023). 

27. Z. Ni et al., Science 367, 1352–1358 (2020). 

28. Z. Ni et al., Nat. Energy 7, 65–73 (2022). 

29. J. Ye et al., Angew. Chem. Int. Ed. 60, 21636–21660 (2021). 

30. Y. Lin et al., Nat. Commun. 9, 4981 (2018). 

31. Y. Lin et al., ACS Energy Lett. 5, 2935–2944 (2020). 

32. A. Al-Ashouri et al., Energy Environ. Sci. 12, 3356–3369 (2019). 

33. B. Abdollahi Nejand et al., Nat. Energy 7, 620–630 (2022). 

34. R. Lin et al., Nature 620, 994–1000 (2023). 

35. S. Chen et al., Science 373, 902–907 (2021). 36. T. R. Guess, R. E. Allred, F. P. Gerstle Jr., J. Test. Eval. 5, 84–93 (1977). 

37. Y. Yuan, J. Huang, Acc. Chem. Res. 49, 286–293 (2016). 

38. J. Huang, Y. Yuan, Y. Shao, Y. Yan, Nat. Rev. Mater. 2, 17042 (2017). 

39. PACT, “PACT Perovskite PV Module Outdoor Test Protocol” (2024); https://pvpact.sandia.gov/download/1305/. 

40. PACT, PACT field performance plot (2024); https://pvpact. sandia.gov/results-and-data/. 

41. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

### ACKNOWLEDGMENTS 

Funding: This material is based on work supported by the US Department of Energy (DOE) Office of Energy Efficiency and Renewable Energy (EERE) under the Solar Energy Technologies Office, award no. DE-EE0009520. PACT testing is supported by the US DOE EERE under the Solar Energy Technologies Office, award no. 38050. The outdoor stability testing was authored by the National Renewable Energy Laboratory, operated by Alliance for Sustainable Energy, LLC, for the US DOE under contract no. DE-AC36-08GO28308. A portion of the optical characterizations and DFT calculations was supported by the Center for Hybrid Organic Inorganic Semiconductors for Energy (CHOISE), an Energy Frontier Research Center funded by the Office of Basic Energy Sciences, Office of Science, within the US DOE. The nanoprobe XRF measurements were supported in part by the US DOE EERE under the Solar Energy Technologies Office, award no. DE-EE0009527, and in part by the National Science Foundation under award no. DMR-1848371. The views expressed here do not necessarily represent the views of the US DOE or the US government. Author contributions: C.F. and J.H. conceived the idea. C.F. fabricated and characterized perovskite films and devices. A.K. and A.S. designed, synthesized, and characterized the HTM molecule EtCz3EPA. C.F. and J.H. also participated in the design of EtCz3EPA. X.S. fabricated some of the minimodules for outdoor stability evaluation. M.W. performed the GIXRD measurements and acquired the SEM images. Z.S. carried out the PL mapping of the samples. H.J. carried out the AFM-IR measurement and analysis. T.J.S., M.O-B., and L.T.S. carried out the outdoor test. Y.D., R.S., and M.C.B. measured the TR spectra and did the analysis. H.G. did the UV-vis absorption measurement. G.Y. carried out the tDOS analysis. N.L. established the light cycling stability test system. Y.X., X.W., and Y.Y. did the DFT calculations. C.J.D., Z.J.D.D., D.N.C., and D.P.F. carried out the XRF measurement and analysis. C.F. and J.H. wrote the manuscript, and all authors commented on the manuscript. Competing interests: C.F., A.K., A.S., and J.H. are authors of a provisional patent (application no. 63/574,079) based on this manuscript. Tandem PV is an entity to which the following technologies used or evaluated in this paper have been licensed: an ink formulation for fast coating of perovskites and benzylhydrazine hydrochloride (BHC) for reducing iodine. J.H. is an inventor of technologies and has received royalties. These relationships have been disclosed to and are under management by UNC-Chapel Hill. The authors declare no other competing interests. Data and materials availability: All data are available in the main text or the supplementary materials. License information: Copyright © 2024 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/ science-licenses-journal-article-reuse 

### SUPPLEMENTARY MATERIALS 

science.org/doi/10.1126/science.adi4531 Materials and Methods Figs. S1 to S26 Tables S1 to S4 

Submitted 27 September 2023; resubmitted 18 March 2024 Accepted 24 April 2024 10.1126/science.adi4531 

