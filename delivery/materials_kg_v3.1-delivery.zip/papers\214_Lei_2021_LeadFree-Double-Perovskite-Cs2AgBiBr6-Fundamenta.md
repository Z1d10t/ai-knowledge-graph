# Lead‐Free Double Perovskite Cs2AgBiBr6: Fundamentals, Applications, and Perspectives

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 438 |
| 作者 | Hong-Wei Lei, D. Hardy, Feng Gao |
| DOI | 10.1002/adfm.202105898 |
| 源文件 | 014_Lei_2021_LeadFree-Double-Perovskite-Cs2AgBiBr6-Fundamenta.pdf |

---
**Review** 

**www.afm-journal.de** 



# **Lead-Free Double Perovskite Cs2AgBiBr6: Fundamentals, Applications, and Perspectives** 

_Hongwei Lei,* David Hardy, and Feng Gao*_ 

solar concentrators.<sup>[3,4]</sup> Among these applications, lead-based perovskite solar cells (PeSCs) are best known, having achieved a state-of-the-art power conversion efficiency (PCE) of 25.5% for a single-junction laboratory-scale device and a 29.5% record PCE for a perovskite/silicon tandem mono lithic device.<sup>[5]</sup> This progress has been achieved through fabricating high-quality perovskite films and optimizing device interface contact to minimize energy losses. Additionally, lead-based perovskite light-emitting diodes (PeLEDs) now have also delivered high external quantum efficiencies (EQEs) over 20% through suppression of non-radiative recombination and improvement of light out-coupling efficiency.<sup>[6]</sup> 

**Cs2AgBiBr6, as a benchmark lead-free double perovskite, has emerged as a promising alternative to lead-based perovskites because of its high stability, non-toxicity, exceptional optoelectronic properties, and multifunctionality. To encourage further research on Cs2AgBiBr6 and its broad applications, in this review, its fundamental properties including the structure-property relation, synthesis, stability, origin of absorption and photoluminescence, electronphonon coupling, role of defects, charge carrier dynamics, and bandgap modulation are comprehensively emphasized. The recent progress on the wide applications including solar cells, light/X-ray detectors, and ferroelectric/magnetic devices are highlighted. Moreover, the challenges of Cs2AgBiBr6 materials and related applications are discussed and perspectives are provided for guiding the future development of this research area.** 

Despite the notable progress in perovskite optoelectronic devices, lead perovskites still suffer from two major issues, i.e., the lack of stability and Pb toxicity. Indeed, lead halide perovskite films are sensitive to ambient conditions (oxygen and water), prolonged illumination, and high temperatures, leading to fast material degradation. Although considerable efforts have been devoted to improving the stability of PeSCs, their lifetime is still far behind the warranty of 25 years for commercial PV modules. Furthermore, for PeLEDs, its operational stability is even worse than PeSCs, with most reported lifetimes ( _T_ 50) generally limited to tens to hundreds of hours, due mainly to ion migration, electrochemical reactions, and interfacial reactions.<sup>[7]</sup> The toxicity of Pb presents another big obstacle for future commercialization. Pb is a particularly insidious bioaccumulative hazard that has the potential to cause irreversible health problems. While perovskite devices are carefully encapsulated and lead ions are rationally captured by lead-absorbing materials and strictly recycled, the prevention of Pb leakage into the environment cannot be guaranteed. 

## **1. Introduction: The Emergence of Lead-Free Perovskites** 

Lead (Pb) halide perovskites, with a general chemical formula of ABX3, where A is a CH3NH3<sup>+</sup> (MA<sup>+</sup> ), CH(NH2)2<sup>+</sup> (FA<sup>+</sup> ) or Cs<sup>+</sup> cation, B is a Pb<sup>2+</sup> cation and X is Cl<sup>–</sup> , Br<sup>–</sup> or I<sup>–</sup> anion, have attracted tremendous attention in both scientific and industrial fields in the last 10 years. Lead-based perovskites have demonstrated exceptional optoelectronic properties such as a suitable and tuneable direct bandgap, strong light absorption, long carrier lifetime and diffusion length, small and balanced carrier effective mass, easy solution fabrication, high structural diversity, and high defect tolerance.<sup>[1,2]</sup> Such remarkable properties make perovskite a versatile material for a wide range of applications such as solar cells, photodetectors, light-emitting devices, photocatalysis, X-ray imaging, lasing and luminescent 

H. W. Lei College of Science Huazhong Agricultural University Wuhan 430070, China E-mail: leihw@mail.hzau.edu.cn H. W. Lei, D. Hardy, F. Gao Department of Physics Chemistry and Biology (IFM) Linköping University Linköping SE-58183, Sweden E-mail: feng.gao@liu.se 

To tackle these issues, significant efforts have been committed to developing lead-free perovskites, in the hope to combine the impressive optoelectronic properties of lead-based perovskites with high stability and nontoxicity. As the superior properties of lead perovskites originate from the unique electronic configuration of Pb 6 _s_<sup>2</sup> , divalent tin (Sn<sup>2+</sup> ) and germanium (Ge<sup>2+</sup> ) in the same group with similar lone pair were first used to replace Pb. However, Sn and Ge-based perovskites show very poor stability because of the rapid oxidation of Sn<sup>2+</sup> and Ge<sup>2+</sup> to +4 states. Furthermore, Sn might be even more toxic than Pb for human beings upon dispersion into the environment.<sup>[8]</sup> An emerging and promising method is to use one monovalent and one trivalent metal cation to replace the position of Pb in the crystal structure, forming so-called ordered double perovskites with a general chemical formula of 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202105898. 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative  Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

### **DOI: 10.1002/adfm.202105898** 

**2105898 (1 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

A2B<sup>+</sup> B<sup>3+</sup> X6. This strategy is very effective because it maintains the 3D perovskite structure and at the same time offers more material diversity. Through combining different A, B<sup>+</sup> , B<sup>3+</sup> and X elements (for example, A = K, Rb, Cs; B<sup>+</sup> = Li, Na, K, Rb, Cs, Ag; B<sup>3+</sup> = Al, Ga, In, Sb, Bi, Sc, Y, and X = F, Cl, Br, I), more than 100 double perovskites with a structural tolerance factor and octahedra factor in a reasonable range have been predicted to be thermodynamically stable.<sup>[9]</sup> Therefore, the structural and functional diversity, combined with the high stability observed in double perovskites, make them very promising lead-free candidates for a wide range of optoelectronic applications. 

Of these double perovskites, Cs2AgBiBr6 stands out among the rest, possessing similar optoelectronic properties to lead-based perovskites such as a 3D structure, a long carrier lifetime, a relatively small carrier effective mass, while additionally demonstrating high stability and low toxicity. Indeed, to date, Cs2AgBiBr6 solar cells have delivered improved PCE of over 3%, and Cs2AgBiBr6 single crystals demonstrate high sensitivity to X-ray (detectable dose rate of 59.7 nGyair s<sup>−1</sup> ).<sup>[10,11]</sup> However, despite these favorable characteristics and promising applications, Cs2AgBiBr6 still faces some challenges which require further systematic research. For example, the wide indirect bandgap of Cs2AgBiBr6 largely limits the PCEs of corresponding photovoltaic devices. Moreover, the fundamental structural, optical, and electronic properties of Cs2AgBiBr6 are still not yet fully understood. Therefore, a timely review is needed to identify the characteristics of this emerging material, the current technical challenges that it faces, and its potential for future optoelectronic applications. 

This review focuses on the emergence and development of the promising benchmark lead-free double perovskite Cs2AgBiBr6. First, the structure-property relation, synthesis, and stability of Cs2AgBiBr6 are emphasized. Next, the fundamental optical and electronic properties, i.e., the absorption, photoluminescence, electron-phonon coupling, defects, charge carrier dynamics, and bandgap engineering, are discussed. Then, the recent progress in optoelectronic applications including solar cells, photo/X-ray detectors, and ferroelectric/magnetic devices, etc., are reviewed. Finally, the main challenges facing Cs2AgBiBr6 materials and related applications are presented alongside perspectives and possible solutions that may allow for the achievement of commercial, high-efficiency, stable, and nontoxic lead-free optoelectronic devices. 

## **2. Lead-Free Double Perovskite Cs2AgBiBr6: Structure, Synthesis, and Stability** 

### **2.1. Structure-Property Relation** 

### _2.1.1. Structure and Chemical Bonds_ 

Typical double perovskites implement a heterovalent substitution strategy of using a monovalent and a trivalent metal cation to replace Pb and retain the 3D connectivity of the structure. The crystal structure evolution from standard MAPbI3 to Cs2AgBiBr6 and its derivatives as well as representative band structures are presented in **Figure 1** . Lead perovskite MAPbI3 (Figure 1a) utilizes a cubic structure (space group _Pm_ 3 _m_ ) at 

high temperature over 327 K,<sup>[12]</sup> with the octahedra maintained by IPbI bond angle of 90° and PbI bond length of 3.136 Å.<sup>[13]</sup> As shown in the inset of Figure 1a the valence band maximum (VBM) of MAPbI3 consists mainly of the antibonding states of Pb s and I p orbitals, and conduction band minimum (CBM) is composed of the antibonding states of Pb p and I s orbitals, which results in the direct bandgap with high absorption. Note that the I orbital is omitted in the schematic. 

Cs2AgBiBr6 displays a similar cubic double perovskite structure with a space group of _Fm_ 3 _m_ (lattice parameter 11.27 Å) at room temperature (RT).<sup>[14]</sup> This so-called rock salt ordering structure is formed by alternating corner-connected [AgBr6]<sup>5–</sup> and [BiBr6]<sup>3–</sup> octahedra in all three directions with Cs<sup>+</sup> located at the framework cavities (Figure 1b). The configuration of the octahedra, including the volume variation and distortion/tilting (mainly associated with bond lengths and bond angles), have a significant effect on the electronic structure and thus determine the optoelectronic properties of the perovskites. In ordered Cs2AgBiBr6, the corresponding AgBr/BiBr and AgBrBi bonds all maintain a 90° or 180° angle, and the bond length for Ag-Br and Bi-Br is comparable (2.804–2.828 Å). A shorter bond length compared with MAPbI3 means the electrons are more tightly bound to the atoms, contributing to stronger bond strength and stiffness in the Cs2AgBiBr6 framework.<sup>[15]</sup> Basically, the [AgBr6]<sup>5–</sup> and [BiBr6]<sup>3–</sup> octahedra volume are determined by the metal ionic radius (1.15 and 1.03 Å for Ag<sup>+</sup> and Bi<sup>3+</sup> , respectively), the electronegativity (1.93 and 2.02 for Ag<sup>+</sup> and Bi<sup>3+</sup> , respectively) and the interaction from neighboring octahedra, which yield a combined result of complex volume variation such as expansion or contraction of octahedra.<sup>[16]</sup> The tilting/distortion of octahedra is partially caused by the mismatch of the octahedral sublattice, and to accommodate this mismatch, strain relaxation will modify the bond lengths/ angles. Experimentally, detailed structural information can be obtained from the Raman vibrational modes and refinement of X-ray diffraction (XRD) patterns. 

The corresponding band structure of Cs2AgBiBr6 is simplified in inset of Figure 1b revealing that the VBM is composed of Ag d, Bi s character and CBM has Ag s, Bi p character which locate at different positions. Here the Br p orbital that contributes to both VBM and CBM is omitted as well in the schematic. Hence the hybridization between Ag and Bi orbitals at band edges is responsible for the indirect bandgap nature. Although Cs<sup>+</sup> orbitals do not make obvious contributions near band edges, they can have an impact on the band structure through bonding interaction between Cs<sup>+</sup> and the metal framework. Understanding the structure-property relationship is important to design and achieve Cs2AgBiBr6 based materials with desirable optoelectronic properties. For example, a homogenous octahedral contraction and shrinkage of Bi−Br− Ag bonds in Cs2AgBiBr6 can promote the overlap of elemental orbitals and thus lead to bandgap narrowing.<sup>[17]</sup> Under thermal treatment, Cs2AgBiBr6 will show a lattice expansion with varied AgBr and BiBr bond length and the thermal expansion coefficient of AgBr bond is obviously larger than the BiBr bond, suggesting that variation of the AgBr bond is the main contributor to lattice thermal expansion.<sup>[18]</sup> These anharmonic fluctuations of AgBr and BiBr bonds change the energy 

**2105898 (2 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 1.** Structure evolution and band structures of perovskites. a) lead-based MAPbI3, b) ordered Cs2AgBiBr6, c) disordered Cs2AgBiBr6, d) RP Cs2AgBiBr6 derivatives, _n_ = 2, e) DJ Cs2AgBiBr6 derivatives, _n_ = 1. Insets of a), b) and e) present the corresponding band structures with the arrow representing the lowest-energy transition. 

band structure, which are one of the main factors for the observed thermochromism of Cs2AgBiBr6 crystals and films.<sup>[19]</sup> 

### _2.1.2. Atomic Arrangement_ 

Apart from chemical bond variation, the atomic arrangement in Cs2AgBiBr6 can also significantly affect the band structure and optoelectronic properties.<sup>[20]</sup> Here the metal atomic arrangement is discussed, i.e., the cation order/disorder of Ag and Bi octahedra (Figure 1b,c). Similarly, B<sup>+</sup> /B<sup>3+</sup> alternate cation order also heavily influences the optoelectronic properties especially the magnetic and ferroelectric properties of oxide double perovskites A2B<sup>+</sup> /B<sup>3+</sup> O6.<sup>[21]</sup> In a regularly ordered crystal structure, each [AgBr6]<sup>5–</sup> octahedra is surrounded by six [BiBr6]<sup>3–</sup> octahedra and vice versa. It should be noted that the solution processing of Cs2AgBiBr6 films or crystals will cause vacancies, interstitials, and antisites including Ag-onBi and Bi-on-Ag, leading to lattice disorder.<sup>[10,22]</sup> The ordering degree ( _η_ ) of Cs2AgBiBr6 can be described with the following formula: 



<!-- Start of picture text -->
η = PAgAg − PAgBi = PBiBi − PBiAg = 2 x − 1 (1)<br><!-- End of picture text -->

where _PAA_ and _PAB_ represent the relative occupancies ( _x_ ) of _A_ atoms on _A_ site and _B_ site, respectively.<sup>[21,23,24]</sup> Thus, for a perfectly ordered structure, η = _PAgAg_ = _PBiBi_ = 1, while for a completely disordered structure, _PAgAg_ = _PBiBi_ = 0.5, _and_ η = 0. Experimentally, the disordered behavior can be observed in the XRD pattern because of the different scattering effects of Ag<sup>+</sup> and Bi<sup>3+</sup> and the reduced symmetry in the disordered 

structure.<sup>[10]</sup> The degree of the disorder can be simply determined by comparing the peak intensity of the super lattice order-related plane (111) and the normal lattice-related reflection plane (022), with a higher ratio representing a higher order extent.<sup>[25,26]</sup> The atomic arrangement in the double perovskite has a big effect on its optoelectronic properties, including bandgaps, lattice distortion, defects, and carrier mobility. By manipulating cations from ordered to disordered, Cs2AgBiBr6 shows enhanced light absorption in the visible and near-infrared region, with the band structure changing from 1.46 eV indirect to 0.44 eV pseudo direct bandgap,<sup>[20]</sup> providing a promising method to improve light absorption of Cs2AgBiBr6. The bandgap narrowing arises from the altering of band hybridization in the reduced crystal symmetry caused by disordered arrangement of [AgBr6]<sup>5–</sup> and [BiBr6]<sup>3–</sup> octahedra. Unfortunately, this strategy requires very high temperatures (beyond 1200 K) which greatly limit practical applications. Strategy of using additives such as phenylethylamine bromide (PEABr) can effectively increase the ordering degree because of the selective coordination effect between the functionalized groups in PEA<sup>+</sup> and metal framework. Ordered crystals present less lattice distortion, reduced defect density, suppressed trapped-exciton formation, enhanced carrier mobility, hence superior X-ray detection performance.<sup>[25]</sup> For potential optoelectronic applications, disordered antisites are attributed to deep-level defects, which decrease the carrier mobility and cause carrier recombination in Cs2AgBiBr6.<sup>[27]</sup> Therefore, to obtain highly ordered Cs2AgBiBr6, researchers need to pay attention to the key growth factors such as using moderate temperature, slower synthesis speed, higher pressure, suitable additives or dopants in the material fabrication process.<sup>[28,29]</sup> 

**2105898 (3 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

### _2.1.3. Layered Structure_ 

To modulate the properties of Cs2AgBiBr6 double perovskite such as a transition from indirect to direct bandgap, or selectively tune the bandgap, layered Cs2AgBiBr6 derivatives have been developed based on specific organic spacer cations, forming homologous compounds with stoichiometries of R4AgBiX8, R2CsAgBiX7, and R2AgBiX8 which adopt the singlelayer ( _n_ = 1) Ruddlesden-Popper (RP) structure, bilayer ( _n_ = 2) RP structure (Figure 1d) and single-layer Dion-Jacobson (DJ) structure (Figure 1e), respectively. However, layered Cs2AgBiBr6 derivatives with a DJ structure ( _n_ = 2) or _n_ values greater than 2 for RP and DJ structure have not been demonstrated experimentally so far. 

A wide choice of organic cations is available because layered structures do not have a strict restriction on the length or size of the interlayer organic spacer cations. Representative bulky R cations in Cs2AgBiBr6 derivatives are monovalent alkyl-ammonium cations such as propylammonium (PA, CH3(CH2)2NH3<sup>+</sup> ), butylammonium (BA, CH3(CH2)3NH3<sup>+</sup> ), and divalent cations such as 1,4-butanediammonium (BDA, (CH2)4(NH3)<sup>2+</sup> ).<sup>[30,31]</sup> To choose a specific R cation for a potential optoelectronic application, one should consider the interaction between the inorganic framework and the organic cations. Generally, R cations that have smaller interlayer distance and stronger hydrogen bonding, coupled with _π_ – _π_ interactions, would generate higher charge transport efficiency in the layered perovskite. R cations can also be selectively tailored to be highly luminescent or to contribute to perovskite ferroelectricity.<sup>[32,33]</sup> The incorporation of R cations causes obvious distortion or tilting of the perovskite lattice (related to the Ag-halide-Bi bond and metal-halide bond), crystalizing the lattice in a monoclinic or triclinic system with lower symmetry. Compared with the [BiBr6]<sup>3–</sup> octahedra, the distortion of [AgBr6]<sup>5–</sup> octahedra is more pronounced, with a larger deviation in the equatorial and axial AgBr bond lengths, arising from the mixing of filled Ag _n_ d orbitals with empty ( _n_ +1)s orbitals.<sup>[31]</sup> 

Regarding the properties of low-dimension Cs2AgBiBr6 derivatives, their optical bandgaps are usually larger than their 3D counterparts, with minimal difference between varied R cations, therefore further understanding is needed to explain what contribution the R cation makes to the structure and properties of Cs2AgBiBr6. The indirect bandgap of Cs2AgBiBr6 becomes direct in most cases when the inorganic framework becomes a monolayer, with the typical band structure shown in the inset of Figure 1e. This direct transition originates from the single-metal-orbital contributions to the VBM and CBM of layered Cs2AgBiBr6 derivatives in the case of _n_ = 1. This dimension reduction would result in more pronounced lattice distortion and reshaping the orbital composition of the band edges. 

Given that the corresponding photoluminescence is usually too weak to be observed at RT and the more distorted structure, layered Cs2AgBiBr6 perovskite derivatives presently appear to have limited optoelectronic applications. However, these low dimensional perovskites offer a research platform for selftrapping emission arising from electron-phonon coupling, or ferroelectric, ferro/antiferromagnetic, and spin-electronic applications. 

### **2.2. Synthesis and Stability** 

The synthesis processes of Cs2AgBiBr6 materials such as single crystals, thin films, nanocrystals, and quantum dots are facile and simple. Approaches including cooling-induced crystallization, inverse temperature crystallization, antisolvent vapor crystallization and slow solvent evaporation have been widely used to grow bulk perovskite single crystals. One-step solution deposition (spin-casting or spray-coating) methods can be used to deposit high-quality Cs2AgBiBr6 films if one carefully controls the precursor stoichiometry.<sup>[34]</sup> In contrast, vacuum-evaporation deposited Cs2AgBiBr6 thin films usually suffer from halogen losses, which may introduce additional point defects. Cs2AgBiBr6 nanocrystals and quantum dots with uniform shape, high purity and high crystallinity have been synthesized using hot-injection and ligand-assisted reprecipitation methods.<sup>[35,36]</sup> These nanoscale materials hold potential for lighting applications due to the strong quantum confinement effects. Detailed synthesis methods and related discussions can be found in a recent article by Yang et al.<sup>[37]</sup> The synthesis should be carried out bearing in mind that the properties of Cs2AgBiBr6 including the stoichiometry, atomic arrangement, chemical bond, energy level, crystallinity, conductivity, and mobility, etc., depend on the specific fabrication method. 

One of the most attractive properties of Cs2AgBiBr6 is its superior stability compared with lead-based materials. All inorganic Cs2AgBiBr6 shows excellent moisture, light, and thermal stability. Crystals show no signs of decomposition for up to 240 days in ambient atmosphere, with even the chemical bonds remaining unchanged.<sup>[38]</sup> Also, no evidence of decomposition is detected for crystals irradiated (halogen lamp, 0.75 sun) at 50 °C for 30 days, or heated at 100 °C for 72 h and mass loss is only observed at temperatures higher than 430 °C.<sup>[39]</sup> As a quaternary compound, Cs2AgBiBr6 can form a single-phase without any competing binary or ternary phases, proved by both phase thermodynamic stability diagram evaluation and experimental results. While Cs2AgBiBr6 usually crystalizes in a space group of _Fm_ 3 _m_ with a face-centered-cubic structure at RT, phase transitions (cubic, tetragonal, monoclinic, and triclinic) may occur when one decreases the temperature, modulates the material dimensions, uses high pressure treatment, or incorporates new elements into the lattice. For instance, the room temperature cubic phase (space group _Fm_ 3 _m_ ) will transform to a tetragonal phase (space group _I_ 4 _/m_ ) at 122 K or high pressure of ≈2.3 GPa.<sup>[40,41]</sup> A similar phase transition has been observed when a certain amount of Fe replaces the Bi position in the lattice, causing reduced symmetry in the octahedra.<sup>[42]</sup> To estimate the structural stability of ABX3 perovskites, the Goldschmidt tolerance factor and the octahedral factor have been proposed. The tolerance factor _τ_ with high prediction accuracy and octahedral factor _μ_ is defined as: 



<!-- Start of picture text -->
τ = rA − nA  nA − rA / rB  (2)<br>rB  ln ( rA / rB ) <br><!-- End of picture text -->



<!-- Start of picture text -->
rB<br>µ = (3)<br>rX<br><!-- End of picture text -->

where _ri_ is the ionic radius of ion _i_ , _nA_ is the oxidation state and _rA_ > _rB_ by definition. Stable perovskite forms when _τ_ < 4.18 and 

**2105898 (4 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

0.44 ≤ _μ_ ≤0.9. For double perovskite like Cs2AgBiX6 (X = Cl or Br), _rB_ is approximately calculated to be the average of the Ag<sup>+</sup> and Bi<sup>3+</sup> radius and thus the (µ, _τ_ ) is in the stable ranges of (0.56–0.60, 4.07–4.21).<sup>[43]</sup> Moreover, the decomposition energies (Δ _H_ ) with respect to possible decomposition pathways including CsBr, AgBr, Cs2AgBr3, CsAgBr2, and Cs3Bi2Br9 are calculated to be positive and larger than that of MAPbI3, suggesting a higher thermodynamic stability of Cs2AgBiBr6.<sup>[44]</sup> Note that Δ _H_ of the closely related Cs2AgBiI6 is negative, indicating Cs2AgBiI6 is unstable and may decompose spontaneously.<sup>[27]</sup> These methods are useful to predict the probability of successfully synthesizing novel Cs2AgBiBr6-based perovskites by engineering the A, B, or X sites using new elements. 

The intrinsic high stability of all-inorganic Cs2AgBiBr6 tends to guarantee the high stability of its optoelectronic devices. Taking a solar cell as an example, unencapsulated Cs2AgBiBr6 solar cells show no obvious PCE degradation for more than 4 months (hole transport layer (HTL) free, temperature: 20–30 °C, humidity: 40–60%).<sup>[45]</sup> However, for practical devices using organic interlayers, stability issues appear because of the instability of organic materials and interfaces. When stored at higher humidity (68±7%) for 68 days, unusual ion migration of Ag and Br from Cs2AgBiBr6 to P3HT/Cu interface is detected in solar cells, possibly caused by the volatility of halide and/ or reactivity of halide with Ag or Cu metals.<sup>[46]</sup> Indeed, there are some discrepancies in different studies about the ambient stability of solar cells using P3HT or Spiro-OMeTAD HTL.<sup>[46,47]</sup> 

Therefore, further investigation is still needed to point out the potential degradation pathways for Cs2AgBiBr6 optoelectronic devices using organic interlayers under various testing conditions, such as continuous light-illumination, to guarantee a high stability for practical applications. 

## **3. Fundamental Optoelectronic Properties of Cs2AgBiBr6** 

### **3.1. Photophysics of Absorption and Photoluminescence** 

As an indirect bandgap semiconductor, Cs2AgBiBr6 shows a moderate absorption coefficient of around 4 × 10<sup>4</sup> cm<sup>–1</sup> at energies higher than 2.5 eV.<sup>[48]</sup> As a comparison, MAPbI3 has a large absorption coefficient in the order of 10<sup>5</sup> cm<sup>–1</sup> over almost the whole visible range.<sup>[49]</sup> For the typical absorption spectrum of Cs2AgBiBr6 films, as shown in **Figure 2** a, we usually observe three regions. At lower wavelengths, we observe a flat and high absorption range, which is attributed to the direct bandgap absorption. A characteristic and strong peak located at around 438 nm is observed and questions remain about the origin of this peak.<sup>[50]</sup> This sharp peak, which contributes more than 20% of the overall light absorption of Cs2AgBiBr6 perovskite, has been assigned to either excitonic absorption, the chargetransfer-like transition between Ag and Bi/Br orbitals, or localized Bi 6s-6p transitions. Recently, this characteristic absorption 



**Figure 2.** a) Typical absorption spectrum of Cs2AgBiBr6 films with the inset showing the absorption onset at 610 nm. Reproduced with permission.<sup>[45]</sup> Copyright 2017, WILEY-VCH GmbH & Co. KGaA, Weinheim. b) Plot of the center of absorption peak versus smallest side length of cubes of Cs2AgBiBr6 NCs. Inset shows graphs of a suspension of Cs2AgBiBr6 NCs and the orange-red bulk material. Reproduced with permission.<sup>[51]</sup> Copyright 2018, American Chemical Society. c) PL spectrum of Cs2AgBiBr6 powders fitted using a Gaussian function. Red: fit peak 1, green: fit peak 2, blue dashed line: cumulative fit peak. Reproduced with permission.<sup>[55]</sup> Copyright 2017, WILEY-VCH GmbH & Co. KGaA, Weinheim. d) Fluence-dependent PL decays of Cs2AgBiBr6 SC upon 530-nm laser excitation. Reproduced with permission.<sup>[57]</sup> Copyright 2021, American Association for the Advancement of Science. e) The absorbance (black), high-energy PL spectrum (red), and PLE spectrum (blue) recorded at emission energy of 2.0 eV at room temperature. Inset: high-energy PL spectrum (red) and PLE spectrum (blue) of the same sample at 8 K. Reproduced with permission.<sup>[52]</sup> Copyright 2020, American Chemical Society. 

**2105898 (5 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

peak has been demonstrated to show no strong dependence on Cs2AgBiBr6 nanocrystal sizes, as shown in Figure 2b, reflecting that the peak does not in fact originate from confined excitons.<sup>[51]</sup> Furthermore, the photo-emissions related to this absorption peak are virtually independent of sample temperature, which contrasts with exciton emission behavior, as exciton emission normally shifts with temperature.<sup>[52]</sup> Therefore, the possibility of excitonic absorption should be excluded based on these findings. However, regarding the transition between the Ag 4d and Br/Bi p orbitals, the possibility of this transition-induced absorption cannot be fully excluded, because it exhibits similar energy with Bi 6s-6p orbital transition. Note that a similar peak also appears in the absorption spectrum of Bi-based halide material such as Cs3Bi2Br9,<sup>[53]</sup> so we tend to attribute the nature of the peak to the s-p transition of bismuth in [BiBr6]<sup>3–</sup> octahedra. Specifically, this absorption is related to an optical transition from<sup>1</sup> S0 ground state to the triplet<sup>3</sup> P1 excited state of Bi<sup>3+</sup> in Cs2AgBiBr6. Even though the transition is spin forbidden, the transition is allowed because of the strong spin-orbit coupling of heavy Bi<sup>3+</sup> .<sup>[52]</sup> A weak and broad tailing absorption at higher wavelength is also observed (with an edge at ≈610 nm), which originates from the indirect bandgap absorption. An estimate of the exciton binding energy of Cs2AgBiBr6 could be obtained from the absorption edge at the direct transition using the Elliott model, providing a high exciton binding energy of 268 meV.<sup>[54]</sup> 

The photoluminescence (PL) of Cs2AgBiBr6 at RT is relatively weak, broad, and shows a Stokes shift, which is believed to be caused by the indirect bandgap and the electron-phonon coupling. The electron-phonon coupling will be discussed in the following section. The origin of the emission of Cs2AgBiBr6 remains a subject under debate. Cs2AgBiBr6 usually shows a broad red emission (at RT) situated at 600–700 nm, which reveals two PL peaks through Gaussian fitting of the broad PL spectrum (Figure 2c) with the higher energy peaks assigned to band edge emission from the indirect bandgap and the other lower energy emission attributed to the defect states in band structure or self-trapped excitons (STEs).<sup>[38,52,55]</sup> Note that there are reports claiming that the PL peak results from the spatially localized color centers which can be either intrinsic selftrapping of excitons/carriers or defects.<sup>[50,56]</sup> Instead, we have recently demonstrated that the PL emission of Cs2AgBiBr6 is mainly from the band-to-band emission. To start, the fluencedependent PL intensity versus carrier density is measured and reveals a power-law factor of 1.94 and 1.26 when the excitation density is smaller or larger than 10<sup>16</sup> cm<sup>–3</sup> , respectively, which implies both free carrier and exciton emission in Cs2AgBiBr6 samples. The PL decay dynamic is then compared and shows a photoexcitation fluence-dependent behavior (Figure 2d), suggesting that the PL is from free carrier band-to-band emission because the defects or exciton emission rate is typically independent of the excitation density in the low regime. We speculate that the emission contribution from defects or STEs is small considering the single-peak and fluence-dependent PL emission behavior. The fitting of the decay curves using an expression of _dn_ / _dt_ = − _k_ 1 _n_ − _k_ 2 _n_<sup>2</sup> , where _k_ 1 and _k_ 2 are the first-order Shockley-Read-Hall recombination and second-order electron-hole (bimolecular) recombination coefficients respectively, yields a relatively larger _k_ 2 of 4.5 ± 0.1 × 10<sup>–11</sup> cm<sup>3</sup> s<sup>–1</sup> 

than traditional indirect semiconductors such as Si or GaP (10<sup>–15</sup> to 10<sup>–14</sup> cm<sup>3</sup> s<sup>–1</sup> ). The nature of the emission is actually a polaronic band-to-band transition, meaning the emission is accompanied by the lattice deformation and this also explains the breaking of forbidden transition rules.<sup>[57]</sup> 

Apart from the red emission, interestingly, a high energy blue emission at 2.825 eV is also detected with significantly lower peak intensity, as shown in Figure 2e. The split photoluminescence excitation (PLE) spectra recorded at the conventional red emission reveal two features located ≈50–60 meV above/below the absorption peak, which suggests a carrier cooling process from at least two excited states close to the absorption peak down to the luminescent state (red emissive). A reduced PLE signal at the absorption peak position is observed (more obvious at low temperature), correlating well with the emergence of blue emission. The origin of this blue emission is attributed to the carrier transition between the<sup>1</sup> S0 ground state and the<sup>3</sup> P1 triplet state of [BiBr6]<sup>3−</sup> complex which also leads to the strong absorption peak. The radiative lifetimes of the excited state from the dominant transition are very short (about 30 ps) and thus result in a very weak blue PL emission and simultaneously enable a relaxation to the ground state (red emission).<sup>[52]</sup> 

Note that for experimentally measured PL emission, the variations in fabrication (solution process or vacuum deposition, etc.) and post treatment methods (annealing or high pressure, etc.) contribute to different stoichiometry, atomic arrangement, dimensionality, morphology, crystallinity, electronic structure, and defect distribution in Cs2AgBiBr6 samples, which cause the PL spectrum discrepancies. Another important point is to improve the PL performance of Cs2AgBiBr6 as it is highly related to optoelectronic applications. Promising methods are to optimize the material quality so as to reduce the non-radiative defects, change the bandgap from indirect to direct type, decrease the electron-phonon coupling (for instance, emission of Cs2AgBiBr6 can be highly bright at cryogenic temperature) or introduce emissive dopants such as lanthanide doping of Eu or Yb.<sup>[58]</sup> 

It is still challenging to obtain direct-bandgap Cs2AgBiBr6 with high intrinsic PL performance currently, the reported direct-bandgap Cs2AgBiBr6 and its derivatives have shown either lower PL or a complete lack of PL performance. For example, the dilute Tl-doped Cs2AgBiBr6 is direct bandgap but shows no PL performance, which might be caused by the symmetry-forbidden bandgap transition.<sup>[59,60]</sup> Future improvement is expected to break the forbidden transition through band structure engineering.<sup>[61]</sup> Cs2AgBiBr6 derivatives such as layered perovskite (BA)4AgBiBr8 display weak and slightly broadened PL even at 20 K, and quench rapidly upon warming. We speculate that it is because the dimensional reduction has led to significantly distorted lattice and introduced more non-radiative defects.<sup>[31]</sup> Therefore, further investigation is required to realize high PL emission in Cs2AgBiBr6 and its derivatives at RT. 

### **3.2. Giant Electron-Phonon Coupling** 

In a real crystal lattice, atoms are not fixed but are vibrating all the time at RT. Phonons, defined as the quantum of lattice vibration, are classified as optical phonon and acoustic phonon 

**2105898 (6 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

branches. In the former mode, the atoms in the unit cell show out-of-phase displacement whereas in the latter mode the atoms have an in-phase vibration. It is generally recognized that the carrier-phonon scattering, especially the electron-optical phonon coupling, is a fundamental interaction effect that plays a major role in determining the charge carrier mobility and excitationemission of perovskites. Likewise, the acoustic phonon interactions determine the thermal properties of a material. Usually, for perovskites, a strong electron-phonon coupling would result in obvious carrier scattering and decrease the carrier mobility. Furthermore, it also leads to a large Stokes shift and broadens the PL line widths. A study on the electron-phonon coupling mechanism is therefore important to describe the charge carrier dynamics and fully understand the fundamental optoelectronic properties of perovskites. For traditional lead-based perovskites such as MAPbX3 or FAPbX3, the Frohlich coupling between carriers and longitudinal optical (LO) phonons rather than the acoustic phonon deformation potential coupling or scattering from ionized impurities, is demonstrated to be the dominant charge carrier scattering mechanism at RT.<sup>[62,63]</sup> 

For Cs2AgBiBr6 double perovskite, the scattering becomes more complicated because of the complex environment caused by additional B-site metal vibrations. Using a combination of optical spectroscopic techniques and density functional theory (DFT) calculations, a giant electron-phonon coupling in Cs2AgBiBr6 was observed.<sup>[64]</sup> As shown in **Figure 3** a, the typical PL emission peak narrows as the temperature decreases. The dependence of the PL linewidth on temperature can be compactly expressed as: 



<!-- Start of picture text -->
Γ ( T ) = Γ0 + Γ ac + Γ LO = Γ0 +γ acT +γ LOn ( T ) (4)<br><!-- End of picture text -->

where Γ0 is a constant and represents the inhomogeneous broadening parameter arising from the scattering from the disorder or imperfections.<sup>[65,66]</sup> The second and third terms Γ _ac_ and Γ _LO_ are temperature-dependent parameters, representing the scattering from acoustic phonons and LO phonons with electron-phonon coupling strengths of _γac_ and _γLO_ , respectively. _n_ ( _T_ ) is the population of electron-LO phonon coupling, as given by Bose-Einstein distribution _n_ ( _T_ ) = 1/(exp(ℏ _ω_ / _k_ B _T_ ) − 1), where 



**Figure 3.** a) Temperature dependence of Cs2AgBiBr6 emission line width. The FWHM of single-crystal Cs2AgBiBr6 steady-state PL spectra as a function of temperature, with an example of measured raw PL data provided in the inset for several different temperatures. The red line is a fit made with Equation (4) while the acoustic and LO phonon coupling are parsed via the blue and green traces, respectively. b) Raman spectrum of Cs2AgBiBr6 recorded using 808 nm excitation, revealing the T2g mode of Cs<sup>+</sup> ions at 40 cm<sup>–1</sup> , the T2g (breathing), Eg and A1g (both stretching) modes of the [AgBr6]<sup>5–</sup> octahedron at 75, 135, and 175 cm<sup>–1</sup> , respectively. The inset shows a representation of the primitive cell. a,b) Reproduced with permission.<sup>[64]</sup> Copyright 2018, American Chemical Society. c) Temperature-dependent PL linewidth of Cs2AgBiBr6 SC. The dashed line is fitted with the conventional Equation (4) and the solid line is fitted with the model proposed by Toyozawa et al. for strong coupling. d) The TR kinetics of Cs2AgBiBr6 SC probed at 440 nm. e) Schematic of the self-trapping of charge carriers by acoustic phonons. The dots between adjacent perovskite octahedra represent the omitted lattice units for simplicity. f) Schematic of the energy diagram for carrier self-trapping under the generalized coordinate. c–f) Reproduced with permission.<sup>[57]</sup> Copyright 2021, American Association for the Advancement of Science. 

**2105898 (7 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

ℏ _ω_ is an optical phonon energy and _kB_ is the Boltzmann constant. Note that here the scattering from ionized impurities are ignored considering their negligible contribution.<sup>[67]</sup> From the fit of the curve, one can obtain the electron-phonon coupling constants of Cs2AgBiBr6, with _γac_ = 81 ± 16 _μ_ eV K<sup>−1</sup> and _γLO_ = 226 ± 14 meV K<sup>−1</sup> . These values are several times larger than the lead-based MAPbX3 or FAPbX3 perovskite ( _γLO_ is in the range of 40–60 meV), demonstrating a giant electron-phonon coupling within Cs2AgBiBr6. Additionally, it is found that the Frohlich interactions with LO phonons are the major cause of the line width broadening in Cs2AgBiBr6 at RT, with acoustic scattering being far less important.<sup>[68]</sup> The electron-phonon coupling strength can also be quantified by the Huang-Rhys factor _S_ , which can be derived from the following equations:<sup>[16,69,70]</sup> 



<!-- Start of picture text -->
∆ EStokes = 2 S  ω (5)<br><!-- End of picture text -->



<!-- Start of picture text -->
FWHM = 2.36 S  ω coth    2  k ω BT    (6)<br><!-- End of picture text -->

where the Stokes shift energy Δ _EStokes_ is obtained from the PL and absorption spectrum of Cs2AgBiBr6 and FWHM is the full width at half maximum values of PL peaks at different temperatures. A small S (<1) generally indicates weak electron-phonon coupling and carrier localization. While for Cs2AgBiBr6, the reported S value is relatively large, reaching between 11 and 16.<sup>[56,64]</sup> Combined with DFT results, the Fröhlich phonon coupling constant _α_ can also be calculated by the following formula:<sup>[71]</sup> 



<!-- Start of picture text -->
α = e 2 1 m ∗  1 − 1  (7)<br> ω 4πε0 2  ω   ε∞ ε s  <br><!-- End of picture text -->

where _e_ is the electric unit, _ε_ 0 is the vacuum permittivity, _m_ * is the effective mass and _ε_ ∞ and _εs_ are the electronic and static dielectric constants, respectively. Note that the calculated Fröhlich coupling parameter of Cs2AgBiBr6 is comparable with that of lead-based perovskite ( _α_ = 2),<sup>[71]</sup> which is notably lower than experimental results. It is reasonable because the simulated calculation uses a perfect ordered structure, which would underestimate the coupling constant. 

Moreover, through Raman spectrum characterization, one can obtain useful lattice dynamics information revealing the contribution of the vibrations from [AgBr6]<sup>5–</sup> or [BiBr6]<sup>3–</sup> sublattice. Representative Raman spectra recorded using 808 nm excitation in Figure 3b reveal a low-energy vibration of Cs<sup>+</sup> ions with translational mode and three higher energy modes corresponding to a single breathing and two stretching vibrations arising from [AgBr6]<sup>5–</sup> sublattice where we can identify the LO phonon (A1g symmetry) energy. However, currently there is a disparity about the origin of the Raman peak, especially the main A1g peak, possibly because the assignment is related to specific DFT calculation.<sup>[19,56,64]</sup> Further investigation is therefore needed to clarify the main vibration origins of the Cs2AgBiBr6 lattice. 

Very recently, evidence of strong deformation potential (defined as the derivative of the electronic energy levels due to the phonon scattering) has been uncovered in Cs2AgBiBr6 through systematic spectroscopy measurements and DFT 

calculations.<sup>[57]</sup> By investigating the temperature-dependent PL bandwidth broadening (Figure 3c), it is found the typical expression of Γ( _T_ ) as discussed before is not valid for the PL bandwidth at high temperatures (≈200–300 K). Instead, the temperature-dependent PL linewidth shows a proportional correlation to the square of the temperature _T_ , providing solid evidence of strong electron-phonon coupling in Cs2AgBiBr6.<sup>[72]</sup> Note that the discrepancies are observed between different reports and the fitting may bear some uncertainties due to limited data pointes and too many variables. The Frohlich coupling constant _α_ is then calculated to be 2.68 and 2.52 for electrons and holes, respectively, suggesting an intermediate Frohlich coupling. In sharp contrast, the deformation potential is 13.7 and 14.7 eV at VBM and CBM of Cs2AgBiBr6, respectively, which is greatly improved compared with lead-based perovskite such as CsPbBr3 (2.2 and 6.3 eV). We therefore believe that the optical phonons (Frohlich coupling) and acoustic phonons (deformation potential) both synergistically contribute to the electron-phonon scattering mechanism and the PL linewidth broadening. The broadening contribution differs at varied temperature, revealing that at higher temperature the acoustic phonon scattering is stronger than optical branches and at low temperature the optical phonons scattering dominates. Ultrafast transient reflection (TR) dynamic (Figure 3d) analysis reveals a fast scattering and trapping process, with t1 attri buted to hot carrier relaxation via LO phonons and formation of Frohlich polaron and t2 (about 4 ps) assigned to the electronacoustic phonon coupling and ultrafast self-trapping of the carriers by the acoustic phonons. The assignment is reasonable considering t1 and t2 are intrinsic parameters for Cs2AgBiBr6 because they are invariant to the defect density and excitation concentrations. Thus, the self-trapping process can be understood as shown in Figure 3e,f. The electron and hole charge carriers in Cs2AgBiBr6 are first localized by optical phonons (with a time constant of 0.2 ps) and then are self-trapped by acoustic phonons (with a time constant of around 4 ps), which further localize the charge carriers. 

As discussed previously, the giant electron-phonon coupling including both optical and acoustic branches in Cs2AgBiBr6 typically introduces more carrier scattering, limits the carrier mobility, and decreases the color purity of light emitters. Therefore, it is expected that finely modulating this scattering effect will solve these intrinsic limitations of Cs2AgBiBr6 for efficient optoelectronic devices such as solar cells, detectors, and LEDs. Furthermore, increasing the lattice order degree, maintaining a highly symmetric cubic structure, introducing chemical/ mechanical pressure, and engineering the elemental composition are promising strategies for tuning the electron-phonon coupling strength in Cs2AgBiBr6. Controlling the electronphonon coupling may be of particular interest as in some cases giant coupling in perovskite can be used to produce THz radiation or white emission.<sup>[73]</sup> 

### **3.3. Defects: Tolerant or Not?** 

Ideally, in a semiconductor crystal lattice, all the atoms reside at their specific positions without any defects or impurities. However, in real cases, lots of defects are inevitably generated 

**2105898 (8 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 4.** Calculated formation enthalpies, Δ _H_ , of intrinsic defects in Cs2AgBiBr6 as a function of the Fermi level, EF, at representative a) Br-rich and b) Br-poor condition. Defects with very high Δ _H_ values are shown by the dashed lines. Calculated transition energy levels _ε_ ( _q_ / _q_ ′) for c) intrinsic acceptors and d) intrinsic donors. Reproduced with permission.<sup>[27]</sup> Copyright 2016, WILEY-VCH GmbH & Co. KGaA, Weinheim. 

during the growth and processing of materials. Defects in semiconductors are mainly classified into point defects (i.e., vacancies, interstitials, and antisites), line defects (i.e., dislocation), plane defects (i.e., surface and grain boundaries), and bulk defects (i.e., voids or precipitates). Defects significantly affect the charge carrier transport/recombination dynamics in perovskite materials and devices, therefore understanding defects at a fundamental level is important for achieving highly efficient optoelectronic devices. Lead-based perovskite is highly defecttolerant because most of the formed defects are found to be shallow level defects (states appear closely above the VBM or below the CBM) which barely affect the materials optoelectronic properties such as the charge carrier mobility and lifetime. The high defect tolerance of lead-based perovskite is attributed to its strong antibonding coupling between Pb lone-pair s orbitals, symmetry, high ionicity, and large lattice constant. 

In contrast, Cs2AgBiBr6, with its two B-site metals, expresses a very different landscape for defects. **Figure 4** a,b compares the formation enthalpy of typical point defects in Cs2AgBiBr6 under representative Br-poor and Br-rich conditions, respectively, while Figure 4c,d summarize the thermodynamic transition energy level of different point defects in Cs2AgBiBr6 perovskite. The results are determined by DFT calculation using Heyd-ScuseriaErnzerh (HSE) hybrid function with the inclusion of spin-orbital coupling (SOC) based on Perdew-Burke-Ernzerhof (PBE) optimized structures.<sup>[27,74–76]</sup> Twenty different point defects, including vacancies, cation-on-anion antisites, anion-on-cation antisites, and interstitials are studied. We can thus determine from these calculations of Cs2AgBiBr6 that: i) Ag vacancies are the most easily formed defects due to the lowest formation enthalpy, even in Ag-rich conditions.<sup>[76]</sup> They are shallow acceptor defects that lead to the intrinsic p-type conductivity and therefore do not deteriorate optoelectronic performance; ii) the dominant deep-level (i.e., located within the middle third of the forbidden bandgap) acceptor defects present low formation enthalpy or energy. These deep defects, which might be AgBi antisites, Bi vacancies, BiAg antisites, and Br vacancies, are not thermally ionized within the lattice and form uncontrollable non-radiative recombination 

channels (governed Shockley-Read-Hall recombination), which then eliminate the charges and deteriorate device performance.<sup>[77]</sup> iii) Cs2AgBiBr6 thus shows defect intolerance, possessing more deep-level defects compared to lead-based perovskites. However, this does not mean that Cs2AgBiBr6 has more trap-state densities. In fact, it only possesses moderate trap densities (crystal: 1.7 × 10<sup>9</sup> cm<sup>–3</sup> ; film or device: 10<sup>16</sup> –10<sup>17</sup> cm<sup>–3</sup> ).<sup>[78–80]</sup> Apart from these point defects, higher dimensional surface or grain boundary traps are often composed of deep-level defects. 

To suppress the unfavorable deep-level defects in Cs2AgBiBr6, it is suggested that the growth condition should be carefully controlled. Note that the formation energy and defect types are very sensitive to the chemical environment or calculation methods, somewhat explaining the disputes in literature.<sup>[27,76,81–83]</sup> For instance, questions regarding whether Br and Bi vacancies belong to deep or shallow traps are still under debate. Experimentally, vacuum-deposited Cs2AgBiBr6 films usually show a Br deficient composition and generate inferior photovoltaic performance compared with solution-processed films with a better stoichiometry.<sup>[84]</sup> Whether post-annealing of the films in Br vapor will improve film quality still waits to be validated. Additionally, reports have noticed using a precursor mixed with excess AgBr and a BiBr3 deficiency may result in increased crystallinity, charge carrier mobility, and carrier lifetimes.<sup>[85]</sup> However, the formation of an undesired secondary phase is also observed and its impact is not yet elucidated. Hence, in addition to the electronic structure calculations, further experimental characterization (such as capacitance property and deep-level transient spectroscopy) or device performance investigations is imperatively required. Such studies would determine the defect levels and concentrations, explain the relationship between stoichiometry and defects and provide guidance of reducing the deep-level defects in Cs2AgBiBr6. 

### **3.4. Charge-Carrier Dynamics** 

Understanding the charge carrier dynamics of Cs2AgBiBr6 such as the charge carrier generation, relaxation, and diffusion 

**2105898 (9 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

process is vital to achieve high-performance optoelectronic devices. For solar cells, photodetectors, and LEDs, it is necessary to gently control these carriers to either separate, deliver photovoltage/photocurrent, or recombine to emit light. 

Charge carrier generation in perovskites usually is a very fast process (picosecond), supported by time-resolved terahertz spectroscopy (TRTS). Charge carrier relaxation process in Cs2AgBiBr6 can be studied through femtosecond transient absorption (TA) spectroscopy and time-resolved microwave conductance (TRMC) measurements. **Figure 5** a shows the pseudo color TA spectrum of Cs2AgBiBr6 nanocrystals at 350 nm pump with a fluence of 1 × 10<sup>15</sup> photos/pulse cm<sup>–2</sup> .<sup>[86]</sup> A ground-state bleaching (GSB) peak at 443 nm is detected, which is caused by the state-filling effect from both the conduction band and the valance band. Another broad photo-induced absorption (PIA) band centered at 520 nm is also observed. When the decay time between the probe and pump shifts from 0.1 to 0.6 ps, the PIA band decreases as the GSB signal increases (Figure 5b), suggesting a typical hot carrier relaxation process of the PIA signal.<sup>[87–89]</sup> PIA band is totally replaced by a bleaching band at longer times such as 1 ns. Indeed, analysis of PIA and GSB decay dynamics probed at varied pump fluences reveal the lifetimes for different dynamic processes in Cs2AgBiBr6 nanocrystals (Figure 5c). Note that the build-up dynamics of the GSB band should correspond to the PIA decay dynamics. Thus, the GSB signal presents a fast time constant of 0.2 ps (relaxation of hot holes) followed by a partial decay with a lifetime of 1.4 ps (hole trapping by sub-bandgap states), 

while the PIA band signal reveals a fast decay of 0.8 ps (relaxation of hot electrons) and a slower decay lifetime of 40 ps (electron trapping by sub-bandgap states). The trapping component by sub-bandgap states can be greatly reduced by a surface passivation agent such as oleic acid (OA), as demonstrated by TA decay.<sup>[90,91]</sup> Further extending the decay time of the bleaching signal would provide the signal from long-lived (a time scale of nanoseconds) bimolecular carrier recombination. Moreover, the intrinsic self-trapping of carriers must be considered because of the giant electron-phonon coupling as described above. This self-trapping process is also ultrafast (1–2 ps or less).<sup>[92]</sup> 

TRMC spectra further probe the formation and decay of mobile/free charge carriers in Cs2AgBiBr6. TRMC results are expressed as Δ _P_ / _P_ (where _P_ is the power of absorbed microwave) as a function of time, normalized for _I_ 0 (number of incident photos) and for the surface area of the sample ( _A_ ), which is proportional to the concentration of charge carriers and the sum of their mobility. Upon pulsed irradiation at 580 nm (penetration depth over 5 µm), Cs2AgBiBr6 crystals show a rapid initial decay and a slow long-lived tail in all the pulse-radiolysis TRMC traces, as shown in Figure 5d,e. This fast decay is attributed to surface-related recombination (within hundreds of nanometers of the surface) and the slow decay arises from the mobile charges in the deep bulk of the crystals which could escape from surface recombination. The signals all fall into a timescale of several µs magnitude, implying the presence of mobile charge carriers with long lifetimes comparable with MAPbI3 crystals. At higher temperatures (348 K), increasing 



**Figure 5.** TA spectra of colloidal OA-capped Cs2AgBiBr6 NCs. a) Pseudo color TA plot pumped with 350 nm. b) TA spectra at indicated delay time from 0.1 ps to 1 ns (350 nm pump with a fluence of 1 × 10<sup>15</sup> photos/pulse cm<sup>–2</sup> ). c) PIA (top) and GSB (bottom) decay dynamics at early time probed at 520 nm (350 nm pump with a lower fluence of 1 × 10<sup>14</sup> photos/pulse cm<sup>–2</sup> ). Reproduced with permission.<sup>[86]</sup> Copyright 2018, WILEY-VCH GmbH & Co. KGaA, Weinheim. TRMC traces recorded at different photon fluences for Cs2AgBiBr6 NCs upon pulsed laser excitation ( _λ_ = 580 nm) at d) 348 K and e) 198 K. Reproduced with permission.<sup>[95]</sup> Copyright 2018, American Chemical Society. f) Schematic representation of the charge carrier dynamics of Cs2AgBiBr6. Egi means indirect bandgap and Egd means direct bandgap. 

**2105898 (10 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

the photo fluence results in a decreased TRMC signal, indicating a typical high-order recombination process, i.e., bimolecular band-to-band recombination or Auger recombination (Figure 5d). In contrast, it reveals an opposite intensity dependence at lower temperatures (198 K, Figure 5e), which is a signature of charge trapping. This means at low fluence, all the charges are captured by trap states and additional mobile charges will be produced after the saturation of these traps either at high fluence or being thermally released at high temperatures. This also explains the suppression of long-lived tails at 198 K compared with 348 K, caused by the immobilization of charges in shallow trap states, as the photogeneration is independent of temperature and the mobility increases upon cooling. Therefore, the charge carrier dynamics differ at varied temperatures and positions in the crystals. For crystals, the charge lifetime is long enough, in a time scale of microseconds, but for Cs2AgBiBr6 thin films (thickness of 150 nm), the longlived TRMC tails disappear, suggesting surface-related recombination. Reducing surface traps and improving film quality can thus also realize long lifetimes, such as 1.4 µs, in Cs2AgBiBr6 films.<sup>[48]</sup> 

To better clarify the charge carrier dynamics, we present a general model of Cs2AgBiBr6 dynamics in Figure 5f showing the typical charge carrier generation and recombination process (radiative and non-radiative) together with the time constants. Process I represents the absorption and generation of free carriers or excitons, followed by the hot carrier relaxation to the conduction band minimum. A very weak blue emission is detected with short lifetimes (Process II). The charge carriers or excitons will be trapped/localized by the optical and acoustic phonons and a band-to-band emission (free electron– hole recombination) is observed with the contribution from the phonons (Process III). Process IV presents the trapping and thermal releasing process of charge carriers by the shallow electron/hole traps in the Cs2AgBiBr6 materials. This may also involve the radiative recombination process (Process V). For simplicity, Process V can also represent the STE emission. Note that the recombination of Process II, III, and V would well explain the experimentally observed PL spectra of Cs2AgBiBr6. At the same time, we would observe competing non-radiative recombination at deep-level bandgap defects and surface/interface traps (Process VI). 

The carrier diffusion length ( _L_ D) and carrier mobility of Cs2AgBiBr6 are also important properties determining optoelectronic device performance. They are calculated by equations of _LD_ = _D_ τ and _μ_ = _De_ /( _k_ B _T_ ), respectively, where _D_ is the carrier diffusion coefficient (obtained from cross-sectional time-dependent PL image), _τ_ is the lifetime of the excited carrier, _kB_ is Boltzmann’s constant, _e_ is the electronic charge, and _T_ is the temperature. By using TRPL lifetime values, the _LD_ of Cs2AgBiBr6 single crystal is calculated to be from 700 nm to 2.44 µm within the temperature range of RT to 123 K, and the corresponding carrier mobility is 0.8 and 10 cm<sup>2</sup> V<sup>–1</sup> s<sup>–1</sup> , respectively.<sup>[93]</sup> The thin films also have the mobility of up to 0.39 (vacuum-processed) and 0.74 (solution-processed) cm<sup>2</sup> V<sup>–1</sup> s<sup>–1</sup> .<sup>[84]</sup> For Cs2AgBiBr6 films, the carrier diffusion length is up to 110 ± 20 nm for electrons and holes, respectively.<sup>[94]</sup> Therefore, the long carrier lifetime, long carrier diffusion length, and high mobility make Cs2AgBiBr6 an ideal candidate for multiple 

optoelectronic applications. To further increase the carrier diffusion length in thin films, the carrier lifetime and carrier mobility should be carefully optimized. Traps/defects in films should be largely reduced because they are regarded as trapping sites for carrier recombination. Detailed methods such as employing surface passivators, modifying film morphologies (less grain boundaries), reducing the carrier scattering, and optimizing the device architecture would effectively enable a longer diffusion length in future investigations. 

### **3.5. Bandgap Engineering** 

Bandgap engineering is an important approach to modulate the optoelectronic properties of semiconductors for potential applications. For Cs2AgBiBr6 with a large and indirect bandgap, the engineering strategy mainly includes element doping/alloying, dimensional reduction, and tuning the order parameter. 

Doping and alloying are the most powerful methods in tailoring the optical, electrical, and structural properties of semiconductors. By intentional incorporation of elements on A, B or X sites, the properties of Cs2AgBiBr6 can be significantly modified. For instance, alkali-metal cations, i.e., lithium (Li<sup>+</sup> ), sodium (Na<sup>+</sup> ), potassium (K<sup>+</sup> ) and rubidium (Rb<sup>+</sup> ) have been used to substitute A-site Cs<sup>+</sup> in Cs2AgBiBr6. The substitution ratio should be restricted to a moderate level (e.g., <15%) to avoid the formation of impurities (A3B2X9 phase).<sup>[96]</sup> These alloying usually result in similar or slightly reduced bandgaps, but they also possess some other altered properties. Specifically, Rb<sup>+</sup> substitution has exhibited a substantial increase in the X-ray response of Cs2AgBiBr6 crystals, arising from the prolonged carrier lifetime, greatly reduced dark currents, and polaron formation.<sup>[97]</sup> The incorporation of 1% Li<sup>+</sup> into Cs2AgBiBr6 films has demonstrated increased crystallinity, improved morphology, and a reduction of defects, originating from the higher electronic chemical potentials and higher interface wettability of Li<sup>+</sup> doped Cs2AgBiBr6.<sup>[98]</sup> Organic-inorganic hybrid double perovskite with A-site cations comprised of linear CH3NH3 molecules can also be synthesized and such a material, (MA)2AgBiBr6 expresses a slightly decreased bandgap with a distorted lattice. This is because the bonding interaction between MA molecules and inorganic frameworks will alter the bond lengths of AgBr and BiBr and hence result in a dispersed energy level of bonding state.<sup>[99]</sup> 

B-site and X-site engineering seem more effective for changing the bandgap because the Ag, Bi, and halide orbitals contribute significantly to the energy bands of Cs2AgBiBr6. A straightforward way to achieve this is to use trivalent or monovalent metals which have similar ionic radius with Bi<sup>3+</sup> and Ag<sup>+</sup> to substitute B sites. Indeed, through alloying with In<sup>3+</sup> or Sb<sup>3+</sup> , the indirect bandgaps of bulk Cs2AgBiBr6 (2.12 eV) have been altered to 2.27 and 1.86 eV, respectively, which is caused by the different atomic configurations of In and Sb. Note that for bulk double perovskite, a high alloying proportion of In<sup>3+</sup> (>0.75) or Sb<sup>3+</sup> (>0.35) results in an unstable perovskite because of its high formation energy and small ionic radius, but this challenge can be overcome by synthesizing colloidal nanocrystals.<sup>[92]</sup> However, most of the In and Sb alloyed samples show reduced PL intensity, suggesting the presence of relatively deep 

**2105898 (11 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

defect states. Sb/Bi alloyed thin films have been fabricated by decreasing the annealing temperature and time, which processes a reduction in the bandgap of 170 meV (from 2.25 to 2.08 eV).<sup>[100,101]</sup> Karunadasa and co-workers also proved that dilute alloying of thallium (Tl, 0.75%) can greatly reduce the bandgap by 0.5 eV; however, Tl is much more toxic than Pb.<sup>[59]</sup> So, they further utilized less toxic Sn<sup>2+</sup> (compared with Tl) to synthesize Sn-doped Cs2AgBiBr6 and achieved a very promising bandgap of 1.48 eV. But Sn oxidation will make the Sn-doped Cs2AgBiBr6 films sensitive to the ambient atmosphere and make it difficult to precisely control the doping percentage.<sup>[102]</sup> 

X-site halide alloying is also capable of altering the bandgap. Chloride can be mixed with bromide at any ratio, with corresponding bandgaps of Cs2AgBiBr6− _x_ Cl _x_ varying from 2.19 eV ( _x_ = 0) to 2.77 eV ( _x_ = 6). This bandgap increase is because chlorine is more electronegative and thus Cl 3p energy level lowers the valence band position.<sup>[103]</sup> Interestingly, the mixing of chloride and bromide does not change the PL emission peak significantly, possibly because of the large electron-phonon coupling and broad STE emission which is not substantially dependent on halide composition.<sup>[104,105]</sup> Unfortunately iodide can only be incorporated into bromide or chloride lattice at low concentration (<3 mol%) because higher alloying level results in non-perovskite phases.<sup>[104]</sup> Additionally, mixing sulphide and bromide (Cs2AgBiBr5.8S0.1) is demonstrated to slightly contract the bandgap by shifting up the valence band edge.<sup>[106]</sup> 

Recently, we have reported an effective way to enhance the light harvesting of Cs2AgBiBr6 by using Cu doping.<sup>[107]</sup> **Figure 6** a presents the absorption of Cs2AgBiBr6 crystals with different Cu molar concentrations to Ag in precursors. Cu doping changes the crystal color from red to black, and the corresponding absorption is enhanced with a new tail absorption edge extended to 860 nm. Furthermore, the PL spectra of doped crystals are similar to pristine samples (Figure 6b) and no peak shift is observed. Combined with the decreased PL intensity, shorter PL lifetime, and DFT calculation for Cudoped samples, we claim that Cu doping barely changes the bandgap but instead, increases the absorption by introducing defect/sub-bandgap states. To understand how Cu exists in the crystal,<sup>133</sup> Cs and<sup>209</sup> Bi solid-state nuclear magnetic resonance (ssNMR) is conducted with results shown in Figure 6c,d. A small shoulder peak appears at _δ_ iso = 83.4±0.5 ppm for<sup>133</sup> Cs NMR spectrum, implying that there exist two crystallographic positions of Cs<sup>+</sup> ions and the extra position is related to the presence of Cu<sup>+</sup> /Cu<sup>2+</sup> ions. Further analysis of the<sup>209</sup> Bi NMR spectrum reveals a broad signal at _δ_ iso = 5500 ppm with a spinspin interaction _J_ X-Bi = 1341 Hz, which suggests a different environment of Bi<sup>3+</sup> ions caused by the replacement of Ag<sup>+</sup> ions by Cu<sup>+</sup> /Cu<sup>2+</sup> ions. Therefore, the underlying mechanism is revealed. A small amount of Cu, i.e., 1%, as calculated by inductively coupled plasma mass spectrometry (ICP-MS), is doped into the crystal lattice, and substitutes the Ag position in the form of Cu<sup>+</sup> /Cu<sup>2+</sup> ions and introduces sub-bandgap states which contribute to the much-improved absorption. Although the Cu-doping barely affects the bandgap, the further photoconductive measurement confirms the near-IR light-responsive property of the Cu-induced sub-bandgap states, suggesting the potential for application in photo detection. Additionally, magnetic ions such as Fe<sup>3+</sup> can also be alloyed with Bi<sup>3+</sup> or In<sup>3+</sup> to 

#### **www.afm-journal.de** 

decrease the bandgap of double perovskites, however, the Fe<sup>3+</sup> alloyed samples are less likely to be used in optoelectronic fields because of the PL quenching effect of Fe<sup>3+</sup> .<sup>[108–110]</sup> Instead, they offer possibilities for potential spin-electronic applications, which will be discussed later. 

Dimensional reduction and tuning the order parameter are useful bandgap engineering tools as well. As mentioned before, dimensional reduction offers plenty of opportunities to create novel double perovskites with chemical and structural diversity. The reported optical bandgaps of layered Cs2AgBiBr6 derivatives are larger than their 3D counterpart. Typical layered double perovskites such as (PA)4AgBiX8 (RP phase, _n_ = 1), (PA)2CsAgBiX7 (RP phase, _n_ = 2) and (BDA)2AgBiX8 (DJ phase, _n_ = 1) process bandgaps of 2.41, 2.32, and 2.43 eV, respectively.<sup>[30]</sup> The organic cation orbitals do not contribute to the band edges, but they can interact with the halides in the inorganic layer which then, in turn, influence the bandgaps. 

Apart from the aforementioned methods, it is possible to intentionally tune the order-disorder parameter through growth modulation or external pressure treatment to alter the bandgap. We have reported a relatively small bandgap of 1.72 eV for bulk Cs2AgBiBr6 crystals under ambient conditions. The bandgapnarrowed crystal is achieved by carefully controlling the growth condition, i.e., the evaporation rate of hydrobromide solution. As marked in Figure 6e, the DP-150 (double perovskite with an evaporation temperature of 150 °C) sample presents an obvious red shift of absorption edge from 625 to 715 nm. The bandgap narrowing is verified by the PL spectra (Figure 6f), showing a consistent red shift of PL peak with a faster PL decay (spectrum not shown here). Considering that the temperature is the only difference when preparing the crystals, Ag-Bi disorder is assigned as the origin of defect states and bandgap narrowing. Further calculation proves the assumption, revealing the disordered-lattice induced Ag-d/Br-p and Bi-p/Br-p defect states emerge from valence band edge to bandgap, and from conduction band edge to bandgap, respectively.<sup>[38]</sup> 

The typical optical indirect/direct bandgaps of various Cs2AgBiBr6 and its doped/alloyed and low dimensional derivatives are summarized in Figure 6g. Direct bandgaps can be achieved from some low-dimension structures such as the (BA)4AgBiBr8 and (AE2T)2AgBiI8. In fact, it is expected that future reliable direct bandgaps, which do not suffer from increased defects, poor stability, or increased toxicity, shall be achieved through clever doping/alloying methods to change the perovskite band structure. However, presently the available bandgaps for Cs2AgBiBr6 in ambient conditions can already be tuned from 1.4 to 2.85 eV, offering the potential for a wide range of optoelectronic applications. 

## **4. Wide Application of Cs2AgBiBr6** 

### **4.1. Solar Cells** 

In 2016, Slavney et al. reported the first synthesis of non-toxic and stable Cs2AgBiBr6 which presents a long carrier lifetime of 660 ns and an indirect bandgap of 1.95 eV, suggesting promise for photovoltaic applications.<sup>[39]</sup> From then, Cs2AgBiBr6 solar cells (Shockley-Queisser efficiency limit: ≈16%) have attracted 

**2105898 (12 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 



**Figure 6.** a) Normalized UV–vis absorption and b) photoluminescence of pristine Cs2AgBiBr6 (Cu-0) and Cs2(Ag:Cu)BiBr6 (Cu-1, Cu-10, Cu-30, and Cu-50) double perovskites. Inset is the optical images of representative crystals. c) The<sup>133</sup> Cs-<sup>133</sup> Cs SD/MAS NMR and<sup>133</sup> Cs Hahn-echo MAS NMR spectra of Cs2(Ag:Cu)BiBr6 (Cu-50). d) The<sup>209</sup> Bi ssNMR of Cs2(Ag:Cu)BiBr6 (Cu-50), which were conducted at static conditions. a–d) Reproduced with permission.<sup>[107]</sup> Copyright 2020, The Authors. Published by Wiley-VCH GmbH. e) Normalized UV-Vis absorption spectra of DP-60 and DP-150 Cs2AgBiBr6 single crystals with inset showing the optical images of crystals. f) Normalized PL spectra of DP-60 and DP-150 single crystals at RT. e) and f) Reproduced with permission.<sup>[38]</sup> Copyright 2020, The Authors. Published by Wiley-VCH GmbH & Co. KGaA, Weinheim. g) Optical bandgaps of various Cs2AgBiBr6 and its derivatives. The samples without special statements are crystals. The blue spheres and circles represent indirect and direct bandgap, respectively. CPA is chloropropylammonium and AE2T is 5,5-diylbis(aminoethyl)-[2,2-bithiophene]. 

much research interest.<sup>[111]</sup> Theoretically, the spectroscopic limited maximum efficiency (SLME) of Cs2AgBiBr6 (200 nm) solar cells is 7.92%, impacted by its relatively large and indirect bandgap.<sup>[112]</sup> A higher simulated power conversion efficiency of 11.17% can be achieved by gently engineering the valence band offset between the Cs2AgBiBr6 absorber (600 nm) and Cu2O HTL.<sup>[113]</sup> Still yet more encouragingly, through proper selection of electron transport layer and HTL to avoid built-in 

voltage loss, optimized devices with a structure of FTO/ZnOS/ Cs2AgBi0.75Sb0.25Br6 (400 nm)/Cu2O/Au can generate a simulated 18.18% efficiency, thus highlighting the great potential of Cs2AgBiBr6 based lead-free solar cells.<sup>[114]</sup> 

Experimentally, the first Cs2AgBiBr6 solar cell (mesoporous structure, PCE = 2.43%) was reported in 2017 using a spincoated Cs2AgBiBr6 film as the absorber, demonstrating the suitability of double perovskites for photovoltaic devices.<sup>[115]</sup> 

**2105898 (13 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

As discussed previously, the carrier diffusion length of Cs2AgBiBr6 crystals is more than 700 nm, and how about the diffusion length in a thin film? To answer this question, our group has carried out TRPL experiments to quantify the magnitude. We prepared PC61BM ETL and Spiro-OMeTAD HTL on top of Cs2AgBiBr6 films and then analyzed the corresponding decay dynamics to obtain PL lifetime quenching ratios ( **Figure 7** a). By using a charge-carrier extraction model based on diffusion,<sup>[116]</sup> we estimated a 110 ± 20 nm photoexcitation diffusion length for electrons and holes.<sup>[94]</sup> It is worth noting that the hole’s diffusion length here is a little smaller than the electron’s. This long diffusion length suggests promising performance for Cs2AgBiBr6 solar cells with a planar structure. Following this, we demonstrated the first planar Cs2AgBiBr6 solar cells with an architecture of ITO/TiO2/Cs2AgBiBr6 (205 nm)/SpiroOMeTAD/Au. The optimal device yields a 1.22% PCE with an open-circuit voltage ( _V_ OC) of 1.06 V and a high fill factor (FF) of 74% (Figure 7b). Notably, there is almost no hysteresis in the planar device, suggesting less trapping/detrapping or ion migration. However, the maximum short-circuit current density ( _J_ SC) is only 1.7 mA cm<sup>−2</sup> , which is lagging far behind the simulated values. It is expected that the _J_ SC might be increased by improving the absorber quality and enhancing the extraction efficiency of ETL and HTL. For instance, the low-pressure assisted deposition process, anti-solvent dropping technology, thermal evaporation method, or composition stoichiometry engineering can improve the film quality (dense and smooth 

morphology with large grain size and high crystallinity), generating moderate PCEs.<sup>[45,84,85,117,118]</sup> Furthermore, the above-mentioned promising bandgap narrowing methods such as using Sb alloying or disorder arrangement have limited reports for solar cell applications, possibly because difficulties are encountered when forming high-quality thin films or decreasing the bandgaps. 

In fact, there have been a recent number of device engineering methods that have succeeded in boosting the performance of Cs2AgBiBr6 solar cells. Firstly, to increase the light absorption of Cs2AgBiBr6 solar cells, researchers have turned to apply a dye interlayer (N719) or photoactive ETL/HTL (carboxy-chlorophyll derivative(C-Chl), zinc chlorophyll derivative) into the device.<sup>[11,47,119]</sup> As shown in Figure 7c, the incorporation of C-Chl on top of the mesoporous TiO2 increases the EQE significantly over nearly the whole spectrum, especially between 650–750 nm, correlating well with the absorption of the C-Chl film. Combining with its other advantages such as reducing defects, accelerating charge extraction, and suppressing recombination, C-Chl results in a clear improvement of the photocurrent density. This lead to an outstanding efficiency of 3.11% with a _V_ OC of 1.04 V, a _J_ SC of 4.09 mA cm<sup>−2</sup> , and an FF of 73%, which is by far the highest PCE reported for Cs2AgBiBr6 solar cells (Figure 7d).<sup>[11]</sup> It should be noted this improvement of _J_ SC and PCE is partially due to the contribution of additional sunlight absorption of the photosensitizer rather than intrinsic improvements to the Cs2AgBiBr6 absorber layer. 



**Figure 7.** a) PL decay dynamics of Cs2AgBiBr6, Cs2AgBiBr6/PC61BM and Cs2AgBiBr6/Spiro-OMeTAD films. b) _J_ – _V_ curves of the optimized planar Cs2AgBiBr6 solar cells. a,b) Reproduced with permission.<sup>[94]</sup> Copyright 2018, WILEY-VCH GmbH & Co. KGaA, Weinheim. c) EQE (solid lines) and correlated integrated current density curves (broken-dotted lines) of mesoporous Cs2AgBiBr6 solar cells based on m-TiO2 without and with C-Chl, with inset showing the device structure. d) Corresponding _J_ – _V_ curves of the best-performing devices. c,d) Reproduced with permission.<sup>[11]</sup> Copyright 2021, American Chemical Society. e) Ambient stability characteristics of the Cs2AgBiBr6 PVSCs based on TiO2 and Ti3C2T _x_ @TiO2 recorded under simulated AM 1.5 sunlight of l00 mW cm<sup>−2</sup> irradiance. Reproduced with permission.<sup>[120]</sup> Copyright 2021, American Chemical Society. f) _J_ SC and PCE evolution of Cs2AgBiBr6 solar cells with spheres representing the mesoporous type and circles representing the planar type. 

**2105898 (14 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

Next, to enhance the carrier extraction efficiency in Cs2AgBiBr6 solar cells, one can properly select ETLs/HTLs with fast and balanced charge transport properties.<sup>[80]</sup> Solution-processed compact TiO2 layer usually has a relatively low electron conductivity and mobility, which results in charge accumulation at the interface or in ETL. As such, Li et al. have doped singlelayered MXene nanosheets into TiO2 to fabricate Ti3C2T _x_ @ TiO2 multifunctional ETL for planar Cs2AgBiBr6 solar cell.<sup>[120]</sup> MXene nanosheets not only improve the conductivity, electron extraction and decrease the nonradiative recombination sites in TiO2 but also modifies the surface wettability of ETL and promotes crystallization of Cs2AgBiBr6 films. Notably, Cs2AgBiBr6 solar cells are very stable in the ambient atmosphere under continuous AM 1.5G sunlight irradiance, and the PCE retains 93% of its initial value (2.8%) after 15 days for devices based on Ti3C2T _x_ @TiO2 ETL (Figure 7e). Indeed, even at high temperatures (85 °C, 0% RH), Cs2AgBiBr6 solar cells can remain 80% of their initial efficiencies after 60 days.<sup>[98]</sup> 

Despite these developments in Cs2AgBiBr6 solar cells, it is clear the current PCE (below 3.11%) is still far from satisfying (Figure 7f), either for single-junction or tandem solar cells. Therefore, if significant improvements are to be made there must also be a focus on the intrinsic properties of the Cs2AgBiBr6 layer. Firstly, when looking for further improvements to PCE it is worth studying the _V_ OC. In semiconductor solar cells, the achievable _V_ OC is defined by the difference between the split quasi-Fermi levels of electrons and holes.<sup>[121]</sup> The typical _V_ OC deficit ratio ( _V_ OC/Eg) of Cs2AgBiBr6 solar cells is 0.56 (1.177 V/2.12 V), which is comparable to organic solar cells (0.55) but lower than lead-based solar cells (0.69) and traditional amorphous silicon or GaAs thin-film solar cells (0.80).<sup>[122]</sup> To further boost the _V_ OC and reduce the photon energy loss of Cs2AgBiBr6 solar cells, the limiting mechanisms must be understood. The _V_ OC loss (difference between _V_ OC and the radiative limit, i.e., _V_ OC,rad) relationship in Cs2AgBiBr6 solar cells can be described as:<sup>[121,123–125]</sup> 



<!-- Start of picture text -->
kT<br>∆ VOC = VOC , rad − VOC = − ln ( EQEEL ) (8)<br>q<br>VOC , rad = kT ln  JSC + 1 (9)<br>q  J 0, rad <br><!-- End of picture text -->



<!-- Start of picture text -->
EQEEL = J 0, rad (10)<br>J 0, rad + J 0, non − rad<br><!-- End of picture text -->

where _kT/q_ is the thermal voltage, _EQEEL_ is expressed as the ratio of radiative currents to total recombination currents and can be quantified by measuring the EQE of electroluminescence of solar cells under injection current densities equal to _J_ SC, _J_ 0, _rad_ is the saturation current density for radiative recombination and _J_ 0, _non_ − _rad_ is the non-radiative recombination currents. Therefore, the voltage losses due to non-radiative recombination in Cs2AgBiBr6 solar cells can be quantified by either calculating the radiative limit voltage or measuring the _EQEEL_ of the complete cells. The VOC,rad represents the thermodynamic voltage limit for Cs2AgBiBr6 solar cells and can be determined from the EQE by combining electroluminescence 

and Fourier transform photocurrent spectroscopy. The _EQEEL_ can be affected by many factors such as the charge injection balance, interface layer recombination, and light out-coupling efficiency. The _V_ OC,rad and _EQEEL_ of Cs2AgBiBr6 solar cells have been reported very recently, revealing a _V_ OC,rad of 1.6 V and an EL yield of 10<sup>–8</sup> .<sup>[126]</sup> While the _V_ OC,rad and _EQEEL_ for In-doped Cs2AgBiBr6 solar cells is recently determined to be 1.36 eV and 10<sup>–10</sup> respectively, for an absorber with a bandgap of 2.23 eV.<sup>[127]</sup> The low _V_ OC,rad and EL yields call for further studies to unravel the origin and provide guidance of increasing the radiative efficiency. Alternatively, one can use the intrinsic property of the material, i.e., the photoluminescence quantum yield (PLQY), to understand the non-radiative recombination of the absorber. PLQY can be written as carrier density, _k_ 1 is the first-order trap-mediated recombination _PLQY_ = _k_ 1 + _nknk_ 2 2+ _n_ 2 _k_ 3 , where _n_ is the rate constant, _k_ 2 is the second-order radiative recombination rate constant and _k_ 3 is the third-order Auger recombination rate constant. The PLQY of Cs2AgBiBr6 films presents a very low value at RT, i.e., 0.01% at high excitation power density of 500 mW cm<sup>−2</sup> ,<sup>[48]</sup> demonstrating that the main recombination pathways in Cs2AgBiBr6 are non-radiative (trap-mediated recombination and Auger recombination). Auger recombination dominates at higher carrier densities (e.g., >10<sup>17</sup> cm<sup>–3</sup> ) and can be reduced by compositional modulation and hence it has relatively little effect on photovoltaic applications,<sup>[128]</sup> while trap-related non-radiative recombination is related to the perovskite film quality and the interface between the absorber and ETL/HTL. In principle, improving the PLQY or _EQEEL_ of Cs2AgBiBr6 films or devices would reduce/increase the nonradiative/radiative recombination and allow for a lower voltage loss. Therefore, detailed approaches including controlling the perovskite stoichiometry, increasing perovskite crystallinity, increasing the grain sizes, and using more efficient ETLs/HTLs or interface interlayers show promise to minimize the voltage loss. Additionally, developing effective passivation methods to heal the defects/traps is important for further _V_ OC improvement in Cs2AgBiBr6 solar cells. 

However, looking beyond the _V_ OC, the small current density, which is less than 6 mA cm<sup>−2</sup> , is the main performance-limiting factor for Cs2AgBiBr6 solar cells. The reason is attributed to the lower absorption coefficient from the indirect wide bandgap and insufficient charge collection. As discussed previously, the absorption of Cs2AgBiBr6 film is very weak in the third wavelength range (with an edge at ≈610 nm), as assigned to the indirect bandgap absorption. Most of the light absorption is contributed by the short wavelength range, i.e., the direct bandgap absorption and the Bi orbital transition. As such, enhancement of light absorption is required to boost the limited current density and efficiency. Therefore, bandgap engineering is an important area for research, as it has the potential to solve these problems. Besides, we can use a thicker active layer to absorb more incident light. In that case, we need to make sure that Cs2AgBiBr6 films have a long diffusion length in thicker films (i.e., the minority diffusion length is higher than half of the thickness of film) to achieve high current output. The next step is to enhance the charge collection efficiency and guarantee a balanced electron/hole charge transport. Longo and co-workers have fabricated planar n-i-p Cs2AgBiBr6 solar cells and analyzed the EQE spectrum via illumination through the n-side and 

**2105898 (15 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.afm-journal.de** 

p-sides of the cells. The measured p-side EQE is much lower than the n-side EQE, which means that when electrons must travel a long distance across the active layer they cannot be collected efficiently. This reveals that Cs2AgBiBr6 suffers from much lower electron-diffusion length (about 30 nm) than holediffusion length (>150 nm).<sup>[129]</sup> A strategy to overcome the short electron diffusion length is to eliminate the energetic disorder and the electron traps. It is noted that there exists a discrepancy in charge transport properties, which may be caused by the different synthesis protocols.<sup>[94,129]</sup> 

Although Cs2AgBiBr6 solar cells have experienced advancements in their PCE, it is apparent that more research work is needed to match those of other technologies. Indeed, alterations to device architecture yield greatly improved performances, but it must be noted that further improvement to Cs2AgBiBr6 absorber layers by reducing non-radiative recombination, decreasing the optical bandgaps, and increasing the charge collection efficiency present themselves as the most promising approaches to seeing further improvements in the performance of Cs2AgBiBr6 solar cells. 

### **4.2. Photodetectors** 

Photodetectors that capture light signals and convert them into electrical signals are the cornerstone component of numerous applications including optical communications, biomedical imaging, non-destructive inspection, and machine vision.<sup>[130,131]</sup> Conventional photodiode and phototransistor detectors are based on silicon and III–V semiconductors, which suffer from broad spectral photoresponse and relatively high manufacturing costs. Solution-processed perovskites offer its notable advantages of processing versatility and exceptional optoelectronic properties including high absorption with tuneable bandgaps, high charge carrier mobilities, and low binding energies, making them suitable for light detecting applications.<sup>[132–135]</sup> 

Among all the perovskites, Cs2AgBiBr6 stands out as a promising candidate because of its excellent stability and high resistivity, which is important to obtain a stable and nontoxic photodetector with a low dark current.<sup>[136–138]</sup> In general, to evaluate the performance of photodetectors, parameters including response time, responsivity, detectivity, linear dynamic range and stability are important. The response time can be calculated by a standard square wave method, i.e., the rise/fall time is defined as the time for the photocurrent to increase/decrease from 10%/90% to 90%/10% of the light response peak or by a transient photocurrent method, i.e., it is defined as the time for the photocurrent decrease from the peak to about 1/e after a single exponential fit for the decay curve. And the responsivity ( _R_ ) at a certain wavelength _λ_ can be expressed as: 



<!-- Start of picture text -->
R = J ph = EQE × λ (11)<br>P hv<br><!-- End of picture text -->

where _Jph_ is the photocurrent density, _P_ is the incident light intensity, EQE is the external quantum efficiency of the photodetector, _h_ is the Planck constant and _ν_ is the speed of light. The specific detectivity ( _D_ *), as the most important figure of merit of a photodetector, is defined by: 



<!-- Start of picture text -->
∗ AB<br>D = (12)<br>in / R<br><!-- End of picture text -->

where _A_ is the active area, _B_ is the bandwidth of the noise and _in_ is the measured dark current noise. The linear dynamic range (LNR), indicating the linear correlation between photocurrent and light intensity in a certain spectral range, is described by: 



<!-- Start of picture text -->
LNR = 20 × log J J∗ p d h (13)<br><!-- End of picture text -->

where _J_ ∗ _ph_ is the photocurrent density measured at a light intensity of 1 mW cm<sup>−2</sup> , _Jd_ is the dark current density. The stability of photodetectors is mainly assessed by the device long-term stability to air (oxygen, moisture) and continuous illumination. 

There are mainly three types of photodetector structure, i.e., photodiode, photoconductor, and phototransistor,<sup>[139]</sup> as depicted in **Figure 8** a. Photodiodes, which have a narrow charge transit distance and inner electric field, usually have fast response speed, low noise, and large detectivity, but suffer from low responsivity and EQE. By contrast, photoconductors show large responsivity/EQE because of the photoconductive gain (defined as the ratio of the lifetime of trapped carriers to the transit time of the transport carriers), but shows low response time and small detectivity.<sup>[140]</sup> In comparison, phototransistors present balanced parameters among these three structures.<sup>[131]</sup> Motivated by the progress made in solar cells, Cs2AgBiBr6 was employed as a photoactive layer for symmetrically structured photoconductive detector.<sup>[141]</sup> The photodetector is fabricated using Si/ SiO2 as substrates, one-step solution-processed Cs2AgBiBr6 thin film as absorbers, and fingers of Au as contact electrode, forming a planar metal-semiconductor-metal structure (inset of Figure 8b). Under illumination with proper energy, Cs2AgBiBr6 film will generate electron-hole pairs, then the electronhole pairs separate and are collected by opposite electrodes with help of the external electric field, producing an efficient photodetector. The device shows a maximum _R_ and _D_ * of 7.01 A W<sup>−1</sup> (Figure 8b) and 5.66 × 10<sup>11</sup> Jones (1 Jones = 1 _cm Hz_ W−<sup>1</sup> ) at incident irradiance (520 nm) and intensity of 0.0143 mW, indicating a promising weak light signal behavior (high on/off ratio: 2.16 × 10<sup>4</sup> ). More importantly, the detectors possess remarkable operational stability over aging tests in ambient air with continuous bias voltage and light irradiation (Figure 8c). To decrease the current leakage and increase the response speed in photoconductors, photodiodes with p-i-n/n-i-p structure have been employed. We have demonstrated an efficient Cs2AgBiBr6 photodiode detector by optimizing the HTL and ETL and reducing the trap state densities in devices. The combination of a SnO2 ETL and TFB HTL outperform other candidates and generate lower capacitances with much-decreased trap state densities (Figure 8d), mainly because of the superior transport capacity of SnO2 ETL and additional passivation effect of TFB HTL. Benefiting from the optimized interface and dark current density, we have achieved photodetectors with outstanding parameters including a high _D_ * of 3.29 × 10<sup>12</sup> Jones at 445 nm (Figure 8e), a high LDR of 193 dB (from 2 × 10<sup>–11</sup> to 0.15 W cm<sup>−2</sup> ), and a fast response time of 17 ns, which are comparable or higher than those of the best-performing 

**2105898 (16 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 8.** a) Device architectures of conventional photodetectors including photodiode, photoconductor, and phototransistor. b) Photoresponsivity of the Au/Cs2AgBiBr6/Au thin film photodetector versus the light illumination power. The inset is the energy band diagram of the detector showing the generation, transfer, and collection processes of photogenerated carriers. c) Long-term operational stability of the Cs2AgBiBr6 thin-film photodetector: normalized photocurrent of the unencapsulated photodetector as a function of running time. b,c) Reproduced with permission.<sup>[141]</sup> Copyright 2018, The Royal Society of Chemistry. d) Trap state density of Cs2AgBiBr6 photodetectors based on different electron and hole transport layers. e) Responsivity and detectivity at 0 V bias of the Cs2AgBiBr6 photodetectors based on SnO2 ETL and TFB HTL. d,e) Reproduced with permission.<sup>[79]</sup> Copyright 2019, WILEY-VCH GmbH & Co. KGaA, Weinheim. f) Time-dependent photoresponse of Cs2AgBiBr6 photodetectors with different substrates including pristine, ultrathin Al2O3, TiO2, and NiO _x_ modified FTO substrates. Reproduced with permission.<sup>[142]</sup> Copyright 2020, American Chemical Society. 

lead-based perovskite photodetectors.<sup>[79]</sup> The light absorber quality is an important factor for determining the device’s photodetection parameters. By modifying the commercial FTO substrates with ultra-thin metal oxides including Al2O3, TiO2, and NiO _x_ , the quality of Cs2AgBiBr6 films has been improved significantly with increased grain size and high uniformity. This improvement mechanism is shown by XPS analysis, revealing that the Cs2AgBiBr6 lattice bonds with the oxygen atoms from the metal oxides (Bi-O interaction). Specifically, the modified photodetector based on FTO/NiO _x_ /Cs2AgBiBr6/ETL/ Au exhibits high light current (Figure 8f) and very low dark current (1.3 × 10<sup>–11</sup> A), yielding a high _D_ * of 1.2 × 10<sup>13</sup> Jones.<sup>[142]</sup> More recently, the photodetection performance has been further improved using a 2D Cs2AgBiBr6 nanoflakes grown by a space-confined method as the active layer. The nanoflakes exhibits significantly enhanced light-matter interaction and thus enables high-performance photodetection with an _R_ of 54.6 A W<sup>−1</sup> and a remarkable _D_ * of 7.4 × 10<sup>14</sup> Jones.<sup>[143]</sup> 

**Table 1** summarizes the key parameters of Cs2AgBiBr6 photodetectors together with representative lead-based/leadfree photo detectors.<sup>[144,145]</sup> Cs2AgBiBr6 has shown a decent performance with a wide range photoresponse (265–620 nm), a maximum _R_ of 54.6 A W<sup>−1</sup> , a maximum _D_ * of 7.4 × 10<sup>14</sup> Jones, a maximum LDR of 193 dB with a detecting limit of tens of pW cm<sup>−2</sup> and the shortest response time of 17 ns, which is very promising for light detection and imaging. To further improve the photodetector performance for practical applications, the focus must be paid to the material (absorber and interlayer) 

engineering and architecture engineering. The perovskite absorber/active layer should be considered first, as the relatively poor absorption of Cs2AgBiBr6 would limit the further improvement of the photodetector light response. For this, strategies such as bandgap modulation and integration of plasmonic nanostructure or optical waveguide can be used. Synthesis of high-quality absorber films or single crystals with optimized morphology (smooth, pinhole-free, fewer grain boundaries), high crystallinity, high charge mobility, and long carrier lifetime is vital for improving the detecting performance. Defects in devices, which mainly come from the absorber and the ETL/ HTL interface/surface, need to be carefully removed/passivated to minimize the loss of photo-charge carriers and suppress the leakage current of photodetectors. It is worth noting that Cs2AgBiBr6 materials, especially its low-dimension derivatives, may present tuneable wavelength-dependent photodetection (from UV to NIR), which are rarely reported and thus need future investigation. In terms of device architecture engineering, there are also several further improvements to be made. Currently, it remains challenging to obtain a high responsivity and a fast response speed simultaneously for Cs2AgBiBr6 photodetectors.<sup>[146]</sup> Therefore, experiments on Cs2AgBiBr6 photo transistors are needed to verify if they can deliver a balanced detecting performance.<sup>[147]</sup> Additionally, heterojunction or multi-junction structures, for example, combining perovskite with low-bandgap polymers, can be employed to realize absorption compensation or tuneable wavelength photodetection. Through rational design and manipulation of the materials and 

**2105898 (17 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

**Table 1.** Key figures of merits of Cs2AgBiBr6 photodetectors together with representative lead-based and other lead-free photodetectors. 

|Structure|Measurement<br>Conditions|_R_[A W<sup>−1</sup>]|_D_* [Jones]|Response time [ms]|LDR [dB]|On/off ratio|Ref.|
|---|---|---|---|---|---|---|---|
|Au/Cs2AgBiBr6SC/Au|1 V, 530 nm|15.0|1.6×10<sup>13</sup>|0.77|–|–|[10]|
|Au/Cs2AgBiBr6/Au|5 V, 520 nm|7.01|5.66×10<sup>11</sup>|0.956/0.995|–|2.16×10<sup>4</sup>|[141]|
|Ag/Cs2AgBiBr6SC/Ag|5 V, 400 nm|0.9×10<sup>–3</sup>|1.38×10<sup>9</sup>|159/85|–|42|[148]|
|ITO/SnO2/Cs2AgBiBr6/Au|0 V, 350 nm|0.11|2.1×10<sup>10</sup>|<3|–|–|[136]|
|ITO/SnO2/Cs2AgBiBr6/TFB/Au|0 V, 445 nm|0.14|3.29×10<sup>12</sup>|1.7×10<sup>–5</sup>|193|–|[79]|
|In/GaN/Cs2AgBiBr6/Ag|0 V, 265 nm|1.46|9.4×10<sup>12</sup>|3.463/8.442|55|4.16×10<sup>4</sup>|[137]|
|FTO/NiO_x_/Cs2AgBiBr6/TiO2/Au|0 V, 405 nm|–|1.2×10<sup>13</sup>|1.61/1.74|165.2|≈400|[142]|
|FTO/TiO2/Cs2AgBiBr6/CuSCN/Au|0 V, 405 nm|0.34|1.03×10<sup>13</sup>|28.75/32.95|126.8|≈100|[149]|
|Au/2D Cs2AgBiBr6/Au|5 V, 455 nm|54.6|7.4×10<sup>14</sup>|1.7/1.7|54|7.4×10<sup>4</sup>|[143]|
|ITO/PEDOT:PSS/Cs3Bi2I6Br3/C60/BCP/Ag|0 V, 400 nm|0.015|4.6×10<sup>11</sup>|40.7/27.1|–|4.1×10<sup>4</sup>|[150]|
|ITO/Cs3Cu2I5film/ITO|1 V, 265 nm|0.0649|6.9×10<sup>11</sup>|26.2/49.9||127|[151]|
|ITO/SnO2/Cs0.05(FA0.85MA0.15)0.95Pb(I0.85Br0.15)3/Spiro-OMeTAD/Ag|0 V, 720 nm|0.473|1.35×10<sup>13</sup>|0.35/0.18|110|–|[152]|



architectures, continuous rising of Cs2AgBiBr6 photodetector performance is highly expected. 

### **4.3. X-Ray Detectors** 

Apart from photodetectors, X-ray detectors also have important and broad applications in non-destructive inspection, medical diagnostics, defence, and scientific research.<sup>[153]</sup> Typically, there are two strategies to detect X-rays, i.e., direct detection which converts the X-ray radiation to electrical currents, and indirect detection which transforms the radiation into UV/visible light followed by a light-electric signal conversion using photodiodes, with the corresponding structure shown in **Figure 9** a. Traditional X-ray detectors rely on inorganic semiconductors such as direct-type materials Si, amorphous Se, HgI2, PbI2, CdZnTe, and indirect-type scintillator Bi4Ge3O12, CsI: Tl and YAlO3: Ce, suffering from limitations of low stopping power, poor stability, high toxicity, and complex/costly fabrication processes.<sup>[154]</sup> 

In recent years, perovskite, especially lead-free perovskites, have emerged as efficient X-ray detector materials because of their intrinsic advantages including easy fabrication, high stability, environmental friendliness and superior optoelectronic properties (high atomic number, high X-ray absorption, high charge mobility and tuneable bandgap).<sup>[155,156]</sup> To evaluate the X-ray absorption capacity of certain materials, the absorption can be expressed as: 



<!-- Start of picture text -->
Id = I 0 e −αρ d (14)<br><!-- End of picture text -->



<!-- Start of picture text -->
Z 4<br>α = ρ AE 3<br><!-- End of picture text -->



<!-- Start of picture text -->
(15)<br><!-- End of picture text -->

where _I_ d and _I_ 0 represent the X-ray intensities at a thickness of _d_ and zero, _e_ is the electron charge, _α_ is the absorption coefficient, _ρ_ is the density, _Z_ is the atomic number, _A_ is the atomic mass and _E_ is the X-ray photon energy. Therefore, Cs2AgBiBr6 perovskites with heavy metal (Bi<sup>3+</sup> , _Z_ = 83) with an average _Z_ 

value of 53.1 can efficiently interact with X-rays and possess a large stopping power ability. 

To efficiently collect the charges, especially in direct X-ray detection, materials should have a high carrier drift length per unit electric field, i.e., the µ _τ_ product, where _μ_ is the carrier mobility and _τ_ is the carrier lifetime. The µ _τ_ product can be calculated from the bias-dependent photoconductivity fitting using modified Hecht equation: 



<!-- Start of picture text -->
1 − exp − L 2 <br>I = I 0µ L τ2 V ×   Ls µτ V   (16)<br>1+<br>V µ<br><!-- End of picture text -->

where _I_ is the photocurrent, _I_ 0 is the saturated photocurrent, _L_ is the thickness, _V_ is the applied bias and _s_ is the recombination velocity.<sup>[153]</sup> Typical X-ray detection parameters include the sensitivity and detection limit. Sensitivity represents the response ability of detectors at a given amount of radiation and is expressed by the formula: 



<!-- Start of picture text -->
Rs = I p − Id (17)<br>D × S<br><!-- End of picture text -->

where _R_ s is the sensitivity, _I_ p is the induced photocurrent, _I_ d is the dark current, _D_ is the irradiation dose rate of X-ray and _S_ is the effective area of the device. And the standard detection limitation is defined by the International Union of Pure Applied Chemistry as the dose rate producing a signal which is three times of the noise. 

Tang and co-workers first reported a Cs2AgBiBr6 singlecrystal direct X-ray detector with a low detection limit in 2017.<sup>[10]</sup> As shown in Figure 9b, Cs2AgBiBr6 crystals exhibit a high attenuation efficiency for 50 KeV hard X-ray photons and hence a small thickness of 1.18 mm is enough for Cs2AgBiBr6 crystal to attenuate 99% of incident X-ray, which is superior to MAPbBr3. Through thermal annealing at a moderate temperature (373 K), the order degree of the crystals has been improved and Ag/Bi antisites defects are reduced, generating high mobility and low 

**2105898 (18 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 9.** a) Schematic structure of direct and indirect X-ray detectors. b) Attenuation efficiency of a few representative semiconductors to 50 keV X-ray photons versus thickness. c) Signal-to-noise ratio of the device derived by calculating the standard deviation of the X-ray photocurrent. The red dashed line represents an SNR of 3, and thus the detection limit is indicated by the purple star surrounded by the red dashed circle. b,c) Reproduced with permission.<sup>[10]</sup> Copyright 2017, Springer Nature. d) Arrhenius plots of the temperature dependence of _kT_ versus 1000/T for Cs2AgBiBr6 wafer with/without BiOBr passivation. The fitting curve gives the activation energy of ionic migration. e) Bias-dependent photoconductivity and the derived µ _τ_ value of the Cs2AgBiBr6 wafers with/without BiOBr passivation. f) X-ray sensitivity of corresponding wafers under different electric fields. d–f) Reproduced with permission.<sup>[161]</sup> Copyright 2019, The Authors, Published by Springer Nature. 

trap density of 11.81 cm<sup>2</sup> V s<sup>–1</sup> and 1.74 × 10<sup>9</sup> cm<sup>–3</sup> , respectively. Therefore, a promising µ _τ_ product of 6.3 × 10<sup>–3</sup> cm<sup>2</sup> V<sup>–1</sup> has been achieved, which is comparable to that of lead-based perovskites and CdZnTe. Additional surface treatment using isopropanol or ethyl acetate can further remove the surface states, decrease the surface recombination velocity, and most importantly increase the resistivity to 1.6 × 10<sup>11</sup> Ω cm, which is much higher than lead-based perovskite (10<sup>7</sup> –10<sup>8</sup> Ω cm). The high X-ray absorption, adequate µ _τ_ product and high resistivity properties of Cs2AgBiBr6 crystals have thus finally guaranteed an impressive X-ray detection performance with very low dark current density (0.15 nA cm<sup>2</sup> at 5 V) and low detection limit of 59.7 nGyairs<sup>–1</sup> (Figure 9c). 

Ion migration in perovskites can cause noise, render the baseline drift, reduce the sensitivity and limit the X-ray detection especially the imaging performance.<sup>[157]</sup> Generally, the smaller and less charged ions, which have a shorter jumping distance, or those that stay in a crystal lattice with more vacancies will migrate faster.<sup>[158,159]</sup> For Cs2AgBiBr6, the Br<sup>–</sup> vacancies, which have lower activation energy ( _E_ a, also known as the ion diffusion barriers), are found to be the main species accounting for the migration.<sup>[10]</sup> To effectively suppress the ionic migration, BiOBr is epitaxially grown onto Cs2AgBiBr6 wafers (epitaxial growth model is shown in the inset of Figure 9d). BiOBr can supply additional Br<sup>–</sup> to suppress the Br<sup>–</sup> vacancies thus reducing the migration channels. The reduced migration 

can be reflected by the calculation of the activation energy in Figure 9d. The ion motion is in proportion to the ion conductivity and sensitive to the applied electric field. When the bias on X-ray detection devices is off, the ions accumulate at the interface between the electrode and the absorber and result in an opposite electrical field, which will therefore reduce photocurrent and cause the photocurrent decay following a function of:<sup>[160]</sup> 



<!-- Start of picture text -->
ln ( kT ) = C − Ea (18)<br>k B T<br><!-- End of picture text -->

where _k_ is the decay rate of the photocurrent, _C_ is a constant, _k_ B is the Boltzmann’s constant and _T_ is the temperature. The _E_ a of BiOBr passivated Cs2AgBiBr6 wafer is then calculated to be 360 meV, much higher than the control wafers (203 meV) and slightly higher than pure Cs2AgBiBr6 crystals (348 meV), as shown in Figure 9d. By measuring the bias-dependent photocurrent as mentioned above, the µ _τ_ product of BiOBr passivated Cs2AgBiBr6 wafer is improved from 1.57 × 10<sup>–3</sup> to 5.51 × 10<sup>–3</sup> cm<sup>2</sup> V<sup>–1</sup> (Figure 9e). The combination of suppressed ion migration, increased µ _τ_ product and increased resistivity by BiOBr passivation enable the fabrication of high-efficiency X-ray detectors with low signal drifting, low noise, high sensitivity (250 µC Gyair<sup>–1</sup> cm<sup>–2</sup> at 0.5 V µm<sup>–1</sup> , shown in Figure 9f), and high spatial resolution.<sup>[161]</sup> 

**2105898 (19 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

**Table 2.** Parameters of X-ray detectors based on Cs2AgBiBr6, its derivatives, other lead-free materials and conventional counterparts. 

|Material|X-ray energy [eV]|µ_τ_product [cm<sup>2</sup>V<sup>–1</sup>]|Sensitivity [µC Gyair<sup>−1</sup>cm<sup>–2</sup>]|Detection limit [nGyairs<sup>–1</sup>]|Ref.|
|---|---|---|---|---|---|
|Cs2AgBiBr6SC<sup>a)</sup>|≤50 K,_E_peak =30 K|6.3×10<sup>–3</sup>|105 (25 V mm<sup>–1</sup>)|59.7 (2.5 V mm<sup>–1</sup>)|[10]|
|Cs2AgBiBr6wafer|≤50 K,_E_peak =30 K|5.51×10<sup>–3</sup>|250 (1000 V mm<sup>–1</sup>)|95.3 (5–10 V mm<sup>–1</sup>)|[161]|
|LT<sup>b)</sup>-Cs2AgBiBr6SC|≤50 K,_E_peak =30 K|–|988 (50 V mm<sup>–1</sup>)|–|[78]|
|Cs2AgBiBr6SC|18–100 K,_E_eff =39 K|–|316 (6 V mm<sup>–1</sup>)||[164]|
|Cs2AgBiBr6SC|50 K|9.14×10<sup>–4</sup>|165.6 (22.7 V mm<sup>–1</sup>)|–|[25]|
|PEA-Cs2AgBiBr6SC|50 K|1.94×10<sup>–3</sup>|288.8 (22.7 V mm<sup>–1</sup>)|–|[25]|
|(BA)2CsAgBiBr7SC|70 K|1.21×10<sup>–3</sup>|4.2 (5 V mm<sup>–1</sup>)|–|[165]|
|CC<sup>c)</sup>-Cs2AgBiBr6SC|≤50 K,_E_peak =30 K|5.95×10<sup>–3</sup>|1974 (50 V mm<sup>–1</sup>)|45.7 (2.5 V mm<sup>–1</sup>)|[166]|
|(CPA)4AgBiBr8SC|70 K|1.0×10<sup>–3</sup>|0.8 (5 V mm<sup>–1</sup>)|–|[32]|
|Cs2AgBiBr6film|45 K|–|40 (4000 V mm<sup>–1</sup>)|–|[167]|
|Cs3Bi2I9SC|40 K|7.94×10<sup>–4</sup>|1652.3 (50 V mm<sup>–1</sup>)|130 (50 V mm<sup>–1</sup>)|[168]|
|(NH4)3Bi2I9SC|≤50 K,_E_peak =22 K|1.1×10<sup>–2</sup>|8.2×10<sup>3</sup>(2.2 V mm<sup>–1</sup>)|55 (6.5 V mm<sup>–1</sup>)|[157]|
|MA3Bi2I9SC|100 K|1.2×10<sup>–3</sup>|10 620 (48 V mm<sup>–1</sup>)|0.62 (48 V mm<sup>–1</sup>)|[169]|
|MA3Bi2I9SC|40 K|2.87×10<sup>–3</sup>|1947 (60 V mm<sup>–1</sup>)|83 (50 V mm<sup>–1</sup>)|[158]|
|CsPbI3SC|80 K|3.63×10<sup>–3</sup>|2990 (31.25 V mm<sup>–1</sup>)|219 (31.25 V mm<sup>–1</sup>)|[170]|
|MAPbI3SC|≤50 K,_E_peak =22 K|–|7.1×10<sup>5</sup>(100 V mm<sup>–1</sup>)|1.5 (100 V mm<sup>–1</sup>)|[171]|
|_α_-Se film|28 K|10<sup>−7</sup>|20 (10<sup>4</sup>V mm<sup>–1</sup>)|5500|[156]|



a)SC: single crystal; b)LT: low temperature; c)CC: controlled cooling. 

As an emerging technology, an increasing number of leadfree Bi-based semiconductors including Cs2AgBiBr6, and its low dimensional derivatives and A3Bi2I9 (A = Cs<sup>+</sup> , MA<sup>+</sup> or NH4<sup>+</sup> ) have been applied in direct X-ray detection and achieved very promising performances, as shown in **Table 2.**<sup>[146,157,162]</sup> For a perfect X-ray detector, it should possess high sensitivity, high stability, low noise current, low detection limit, and quick response time. All inorganic Bi-based materials such as Cs2AgBiBr6 have achieved low detection limits with decent air stability and quick response.<sup>[156]</sup> However, challenges remain for Cs2AgBiBr6 direct X-ray detectors, for example, currently, their achieved sensitivity still lags behind that of the best performing lead-based perovskite. Optimization of the X-ray absorber and device architecture can significantly improve the sensitivity and other properties. For instance, increasing the µ _τ_ product or increasing the applied voltage would enhance the charge collection efficiency and hence improve the sensitivity. However, a high voltage will introduce more dark currents or noise, which further requires the materials have a large resistivity and a small number of defect states. Reducing the density of trap states by improving the order degree or tuning the composition has been demonstrated to yield a higher µ _τ_ product.<sup>[25,163]</sup> Moreover, the ion migration should be adequately suppressed because it can induce baseline drift, increase the ionic conductivity, the dark current, and noise. Eliminating the possible ion motion channels or passivating the perovskites are important approaches to suppress the ion migration. Challenges also exist in developing a time-saving method to fabricate large-area Cs2AgBiBr6 single crystals or synthesize novel lead-free low-dimensional perovskites as competitive direct X-ray detection or scintillators for further development. The combination or integration of Cs2AgBiBr6 crystals/films with other organic/inorganic materials and 

developing new structure-function relationships are also important in advancing X-ray detection research. 

### **4.4. Ferroelectricity** 

Ferroelectric materials, featuring a switchable spontaneous electric polarization, present an exciting field of research as they are suited to many technological applications such as capacitors, data storage, and sensors.<sup>[172]</sup> Despite the established success of oxide perovskite ferroelectrics, emerging halide perovskites have the potential to produce new low-cost multifunctional ferroelectric devices, through a combination of low-temperature solution synthesis and diverse optoelectronic properties. However, it is difficult to achieve ferroelectricity in the typical 3D perovskite structure, due to the high symmetry imposed by the Goldschmidt Tolerance factor.<sup>[173]</sup> Therefore, recent works have opted for 2D perovskites that enable the symmetry breaking necessary for ferroelectric polarization to be expressed. While this has been used in lead-based perovskites to achieve favorable ferroelectric properties, stability and toxicity concerns and diverse structures mean that lead-free Cs2AgBiBr6 offers a potentially superior material system. 

Indeed, Zhang et al. presented the first 2D ferroelectric halide double perovskite (PA)2CsAgBiBr7 in 2020, which undergoes a phase transition from the _P_ 21/ _m_ paraelectric phase to a _P_ 21 non-centrosymmetric ferroelectric phase below the Curie temperature of 222 K.<sup>[174]</sup> This results in a spontaneous polarization of 1.5 µC cm<sup>–2</sup> due to disorder in the crystal lattice, causing the displacement of the Cs<sup>+</sup> and organic cations. While this spontaneous polarization is somewhat smaller compared to lead-based perovskite counterparts (2.9–13 µC cm<sup>–2</sup> ), 

**2105898 (20 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.afm-journal.de** 



**Figure 10.** a) (CPA)4AgBiBr8 crystal structure at 270 K shows the clear distortion of the CPA ligand, resulting in polarization component (yellow arrows), while above the Curie temperature (340 K) the crystal adopts a symmetrical structure. b) Temperature dependence of the dielectric constant ( _ε_ ’) measured on (CPA)4AgBiBr8 crystals along different directions. c) Electric polarization versus electric field ( _P_ – _E_ ) hysteresis loop (red continuous curve), and current density versus electric field ( _J_ – _E_ ) curve measured at room temperature (dark yellow dots) which display the ferroelectric behavior of the (CPA)4AgBiBr8 perovskite. a–c) Reproduced with permission.<sup>[32]</sup> Copyright 2020, Wiley-VCH GmbH & Co. KGaA, Weinheim. d) Comparison of crystal structures of (DFPIP)4AgBiI8 and its advantageous ring-shaped ligand. (Ferroelectric phase, _T_ < 305 K. Paraelectric phase, _T_ > 305 K). The red arrow reveals the direction of spontaneous polarization ( _P_ s). The green arrow represents the crystallographic C2 axis. H atoms of C atoms were omitted for clarity. Reproduced with permission.<sup>[176]</sup> Copyright 2021, Wiley-VCH GmbH. 

(PA)2CsAgBiBr7 also exhibits impressive photodetection performance, with large on/off ratios (≈10<sup>4</sup> ), fast response rates (141 µs), and high detectivity (5.3 × 10<sup>11</sup> Jones). Therefore, their work succeeded in highlighting the multifunctional potential that ferroelectric Cs2AgBiBr6 perovskites may possess. Gou and co-workers further reported room temperature ferroelectric in (CPA)4AgBiBr8.<sup>[32]</sup> This material is synthesized by modifying the A-site organic cations in a previously reported centrosymmetric (BA)4AgBiBr8 double perovskite.<sup>[31]</sup> The terminal CH3 group of BA<sup>+</sup> is substituted for chlorine, forming asymmetric CPA<sup>+</sup> ligands that can dynamically reorientate, breaking the planar crystal symmetry, and providing the driving force for phase transition ( **Figure 10** a). As a result, (CPA)4AgBiBr8 achieves room temperature ferroelectricity, undergoing a phase transition at a Curie temperature of 305 K (Figure 10b), and 

boosts an improved spontaneous polarization of ≈3.2 µC cm<sup>–2</sup> at RT (Figure 10c). 

Recently, Liu et al. observed multi-axial ferroelectricity in the (BA)2CsAgBiBr7 perovskite system.<sup>[175]</sup> Already determined to possess an impressive X-ray response, (BA)2CsAgBiBr7 also demonstrates two phase transitions occurring at 273 and 375 K, resulting in low, intermediate, and high-temperature phases. The low-temperature phase (P21) is ferroelectric with the largest spontaneous polarization reported for Cs2AgBiBr6 perovskite: 5.2 µC cm<sup>–2</sup> (at 250 K). When transitioning to the centrosymmetric intermediate temperature phase ( _P_ 21/ _m_ ), (BA)2CsAgBiBr7 exhibits ferroelastic domains, and finally at high temperature ( _I_ 4/ _mm_ ) the crystal domain structure disappears, forming a paraelectric state. In addition to three unique phases, (BA)2CsAgBiBr7 demonstrates impressive fatigue 

**2105898 (21 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

resistance, maintaining stable polarization after 2 × 10<sup>7</sup> on/ off switching cycles, implying the great potential for digital memory applications. Despite these improvements in spontaneous polarization, Cs2AgBiBr6 has recently been surpassed by the closely related Cs2AgBiI6, as the 2D double perovskite: (DFPIP)4AgBiI8 (DFPIP = 4,4-difluoropiperidinium).<sup>[176]</sup> This novel material displays superior spontaneous polarization of 10.5 µC cm<sup>–2</sup> (9.9 µC cm<sup>–2</sup> at RT), and a high Curie temperature of 422 K, which is more comparable to some oxide or leadbased perovskites.<sup>[177,178]</sup> Wang et al. specifically attribute this high Curie temperature to using a ring-shaped organic ligand versus the chain-like organic cations used in the previous works (Figure 10d), noting this trend applies to most 2D perovskite ferroelectric materials.<sup>[176]</sup> 

Although there is limited research in this area of 2D ferroelectric lead-free double perovskites, it is clear that the diverse properties displayed by the Cs2AgBiBr6 system hold promise for multifunctional ferroelectric devices. Additionally, the achievement of high Curie temperatures in the closely related Cs2AgBiI6 system indicates that through rational design of organic cations, it is possible to produce many high-temperature and performant Cs2AgBiBr6 ferroelectric materials with widespread real-world applications in the coming years. 

### **4.5. Magnetism** 

Magnetic perovskite semiconductors are becoming the subject of increased interest due to their potential in the emerging field of spintronics. Consequently, recent studies into lead-based perovskites have explored their magnetic properties such as spin-orbit coupling or magnetic doping/alloying.<sup>[179,180]</sup> Now focus has begun to shift toward the lead-free Cs2AgBiBr6 material system through the recent reports on the promising magnetic properties of Fe<sup>3+</sup> alloyed Cs2AgBiBr6.<sup>[14,42]</sup> Cs2Ag(Bi:Fe) Br6 can be formed through a simple alloying process where magnetic Fe<sup>3+</sup> ions are distributed homogenously throughout a 3D Cs2AgBiBr6 perovskite lattice as [FeBr6]<sup>3–</sup> octahedra, replacing Bi<sup>3+</sup> ions.<sup>[14]</sup> We utilized electron spin resonance (ESR) in conjunction with a superconducting quantum interference device, to determine the perovskite’s paramagnetic centers and identify ferromagnetic or antiferromagnetic resonance signals within the Cs2Ag(Bi:Fe)Br6 crystals.<sup>[14]</sup> By conducting measurements over a range of temperatures (5–300 K), it is observed that Cs2Ag(Bi:Fe)Br6 exhibits diamagnetism at RT and weak magnetic susceptibility temperature dependence above 30 K. Obvious magnetic response appears below 20 K as proved by the rapid increase of magnetic susceptibility ( **Figure 11** a). As presented in Figure 11b, field-dependent magnetization _M(H)_ is linear with a negative slope above 50 K, consistent with the temperature-dependent magnetic susceptibility. While _M(H)_ at 2 K has a positive component at low fields saturating to ≈0.15 _μ_ B per Fe after subtracting the diamagnetic component. In addition, there is no obvious magnetic hysteresis in the _M(H)_ loop in the low fields (inset of Figure 11b). At 40 K, the crystal’s ESR signal is comprised of the sum of two paramagnetic centers, i.e., isolated Fe<sup>3+</sup> with tetragonal symmetry (S = 5/2, _g_ = 2.032) and a defect center of unknown origin (S = 1/2, _g_ = 2.032). In comparison, at 7.2 K, an extra broad 

component emerges and become dominant in the ESR spectrum (Figure 11c). The intensities of isolated Fe<sup>3+</sup> and S = 1/2 defect center are found to gradually and monotonically increase with decreasing temperature, proving that the sharp rise in the material’s magnetic response is related to the third and broad component that becomes dominant at _T_ <35 K. (Figure 11d). We postulate this broad component may be due to a weak ferromagnetic or antiferromagnetic coupling from localized regions within the crystal lattice, due to phase separated magnetic clusters or regions of high Fe<sup>3+</sup> composition caused by inhomogeneous alloy fluctuations. If this is the case, higher Fe<sup>3+</sup> alloying concentrations may yield a magnetic semiconducting lead-free perovskite, which need further investigation. This investigation into the potential magnetic properties of Cs2Ag(Bi:Fe)Br6 indicate that Cs2AgBiBr6-based alloys would be a candidate for a whole new category of lead-free perovskite-based spintronic materials. Therefore, future work is needed to better understand the origin of these properties and to obtain them at room temperature. 

In addition, we also used a combination of ESR and Raman spectra to probe the structural phase transitions and the interplay between the structural, spin, and vibrational properties of Cs2Ag(Bi:Fe)Br6.<sup>[42]</sup> As Cs2Ag(Bi:Fe)Br6 underdoes a symmetrybreaking phase transition below 120 K, from a cubic to tetragonal phase, the six-fold degenerate S = 5/2 state of Fe<sup>3+</sup> splits into three Kramer doublets _M_ s = ± <u>12</u><sup>,</sup> ± <u>32</u><sup>,</sup> ± 25 at zero magnetic fields, transforming the ESR spectra from a single line to multiple lines. Similarly, the symmetry reduction effect is found for the enharmonic breathing mode of the octahedra, which splits below the phase-transition temperature. This indicates a small amount of distortion due to a phase transition has a significant impact on the high spin states of the incorporated Fe<sup>3+</sup> ions, thus highlighting ESR and Raman techniques in probing the interplay between structural phase transitions and spin properties in lead-free double perovskites. 

### **4.6. Other Applications** 

Perovskite materials are also intensively studied for LED applications. However, presently Cs2AgBiBr6 has shown limited potential as an emissive material for LED applications, due to its poor PL/PLQY performance. Therefore, as previously discussed, improvements to the PL/PLQY must be addressed before efficient LEDs can be realized. Some methods to achieve this are: reducing non-radiative defects, decreasing the electron-phonon coupling, changing the bandgap from indirect to direct, or incorporating emissive dopants. 

Chen et al. reported the first example of doping Yb<sup>3+</sup> ions into the double perovskite Cs2AgBiX6 (X = Cl<sup>−</sup> , Br<sup>−</sup> ) NCs which endows a near-infrared emission band in addition to their intrinsic emission. The origin of this Yb<sup>3+</sup> induced NIR emission at 1000 nm is due to an energy transfer from Cs2AgBiX6 (X = Cl<sup>−</sup> , Br<sup>−</sup> ) hosts to the<sup>2</sup> F5/2 state of Yb<sup>3+</sup> ions. Thus, doping Yb<sup>3+</sup> or Mn<sup>2+</sup> cations into Cs2AgBiX6 (X = Cl<sup>−</sup> , Br<sup>−</sup> ) would provide a unique system with tunable dual emission.<sup>[181]</sup> Schmitz and coworkers further investigated Yb<sup>3+</sup> and Eu<sup>3+</sup> lanthanide doping upon bulk hydrothermally processed Cs2AgBiBr6 and achieved a PLQY of 28% (±3). The Yb<sup>3+</sup> doped samples display an extremely 

**2105898 (22 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 11.** a) Temperature-dependent magnetic susceptibility of Cs2Ag(Bi:Fe)Br6 under zero-field-cooled (ZFC) and field-cooled (FC) procedures with a magnetic field _H_ = 1000 Oe. b) Isothermal field-dependent magnetization of Cs2Ag(Bi:Fe)Br6. Inset plot: low-magnetic field magnetization from −0.1 to 0.1 T. c) ESR spectrum from Cs2AgBiBr6 (the gray curves) and Cs2Ag(Bi:Fe)Br6 (the red curves) crystal powder, measured at 7.2 and 40 K, respectively. The simulated ESR spectra (the blue curves) are obtained from a spin Hamiltonian analysis, which consists of contributions from Fe<sup>3+</sup> , with S = 5/2 and _g_ = 2.032, and a defect center of unknown origin, with S = 1/2 and _g_ = 2.032. The discrepancy between the simulated and experimental ESR spectra indicates the existence of a third ESR signal-a broad background signal, which becomes more pronounced at low temperatures. d) Temperature dependence of total microwave absorption (the black spheres), together with the contributions from the three individual ESR components, highlighting the influence of the broad component. Reproduced with permission.<sup>[14]</sup> Copyright 2020, The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. 

high PL intensity relative to the pristine Cs2AgBiBr6 PL peak (at 300:1), indicating the hydrothermal synthesis method is superior for Yb-dopant sensitization compared to the nanocrystal sensitization conducted by Chen et al. (2.5:1 peak ratio, best case).<sup>[58]</sup> Improvement in Cs2AgBiBr6 light emitting applications is expected through further enhancement of PL/PLQY, as observed by its closely related double perovskite Cs2AgInCl6. 

Cs2AgBiBr6 has also provided new opportunities in energyrelated photocatalysis. The basic photocatalytic mechanism involves the absorption of photons to generate electrons and holes, charge separation and migration to the reaction sites, and chemical oxidation/reduction reactions mediated by the photoinduced electrons and holes.<sup>[182]</sup> Besides the traditional standards for photocatalytic materials (high light absorption, efficient charge separation, and appropriate redox ability), Cs2AgBiBr6 has enhanced operational chemical stability under different catalytic conditions like strong acidic/basic solutions and highly reducing/oxidizing atmospheres.<sup>[183]</sup> Typically, Cs2AgBiBr6 nanocrystals could convert CO2 into solar fuels such as CO and CH4, affording an impressive total electron consumption of 105 µmol g<sup>−1</sup> over 6 h, with no H2 side product detected.<sup>[184]</sup> Beyond CO2 reduction, the successful application of Cs2AgBiBr6 has also been demonstrated in dye degradation 

and H2 generation.<sup>[184–187]</sup> Because of its high humidity-dependence of the electrical properties, Cs2AgBiBr6 thin film can also work as a humidity sensor, showing fast response time (1.78 s) and recovery time (0.45 s).<sup>[188]</sup> 

## **5. Challenges and Future Perspectives: Where to Move on?** 

With the benefit of high structure-property diversity, high stability, and nontoxicity, lead-free double perovskite Cs2AgBiBr6 has attracted increasing research interests in recent years focusing on its fundamental material properties and wide applications, including photovoltaic conversion, light/X-ray detection, ferroelectricity, and magnetism, etc. In this review, we have systematically discussed and evaluated these fundamental optoelectronic properties and wide applications of Cs2AgBiBr6. From this it is clear, there remains a great opportunity for further device development based upon the lead-free double perovskite Cs2AgBiBr6 material system. However, there are still challenges which must be overcome as we move forward. The challenges and perspectives/research directions are briefly summarized in **Figure 12** and are discussed below: 

**2105898 (23 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



**Figure 12.** Main challenges and perspectives in Cs2AgBiBr6 research. 

- 1) The bandgap tunability of Cs2AgBiBr6 remains an important issue and requires more research efforts to address. The indirect, wide bandgap nature, which is caused by the mixing of Ag and Bi frontier orbitals in Cs2AgBiBr6, currently severely limits its photovoltaic performance.<sup>[189,190]</sup> Attempts using element substitution of Ag or Bi have not yet efficiently solved this problem, each experiencing trade-offs. For example, Cu<sup>+</sup> or In<sup>+</sup> are promising for an indirect to direct transition, but they will form non-perovskite [CuX4] tetrahedra or are unstable due to easy oxidation of In<sup>+</sup> .<sup>[191,192]</sup> Iodide incorporation can decrease the bandgap to 1.77 eV, however, iodide pure phases have not been experimentally synthesized yet and only a small amount (<3 mol%) of iodide can be mixed into the halides site.<sup>[44,104]</sup> A complete substitution of Bi<sup>3+</sup> with In<sup>3+</sup> would exhibit a direct large wide bandgap of 3.3 eV which suffer from parity-forbidden transition issue.<sup>[61]</sup> Sn alloying results in a good bandgap reduction of 0.5 eV but sacrifices the stability due to Sn<sup>2+</sup> oxidation.<sup>[102]</sup> Therefore, researchers must continue to search for suitable doping or alloying strategies to effectively manipulate the bandgap in both bulk and thin-film Cs2AgBiBr6. 

To find promising doping/alloying elements, the selection should meet the criteria of a positive decomposition energy, a suitable tolerance factor and octahedral factor ( _τ_ < 4.18, 0.44 ≤ _μ_ ≤0.9), an optimal bandgap range, a small and balanced carrier effective mass. Specifically, elements which have similar ionic radius with Ag<sup>+</sup> or Bi<sup>3+</sup> should be considered first. Metal elements which lone-pair _s_<sup>2</sup> orbital configurations are also preferred because they would form double perovskites with B-sites of _s_<sup>2</sup> + _s_<sup>2</sup> type to ensure superior optoelectronic properties. Note that doping/alloying may sometimes result in parity-forbidden transition issues which calls for further modification to break the inversion symmetry. As reported, Sb<sup>3+</sup> alloying is a promising choice because Sb<sup>3+</sup> can elevate the VBM position, but it is still challenging to obtain high-quality phase-pure Cs2AgBi _x_ Sb1− _x_ Br6 films considering the high tendency for decomposition into 2D Cs3Sb2Br9 

impurities.<sup>[193]</sup> Therefore, careful design of the precursor stoichiometry and film growth optimization is vital to achieve Sb/Bi alloyed thin films with a decreased bandgap. Au<sup>+</sup> /Au<sup>3+</sup> are also alternative B-site metals. Using Au<sup>+</sup> /Au<sup>3+</sup> to substitute Ag<sup>+</sup> /Bi<sup>3+</sup> can form stable Cs2AuBiCl6 (1.4 eV indirect bandgap) and Cs2AgAuI6 (1.289 eV direct bandgap) perovskites with low hole/electron effective masses, which are worthy of further experimental research.<sup>[194,195]</sup> Similar interesting lead-free halides such as Cu2AgBiI6 have emerged as promising solar cell absorbers with a direct bandgap of 2.06 eV, even if it is not a perovskite.<sup>[196,197]</sup> Low-dimensional Cs2AgBiBr6 derivatives also offer the possibility to transform indirect to direct bandgap and change the optoelectronic properties. The alternating arrangement of organic-inorganic structure will form quantum-confined architecture which enables a large exciton binding energy, making the low-dimensional Cs2AgBiBr6 derivatives potential scintillation materials. Overall, through the alteration of this current large indirect bandgap, it would be possible to improve the currently limited maximum theoretical efficiency of Cs2AgBiBr6 based solar cells. We should also note that although the indirect bandgap feature of Cs2AgBiBr6 is not preferred, it is beneficial for low carrier recombination rates and thus long minority carrier diffusion lengths, which are important factors in determining optoelectronic applications. 

- 2) Strong electron-phonon coupling is a big concern for Cs2AgBiBr6 double perovskite as it significantly affects the carrier scattering, charger carrier mobility, PL linewidth broadening, PLQY, and electron–hole recombination. With more investigations, the charge-lattice scattering mechanism of Cs2AgBiBr6 is becoming clearer, reflecting the optical phonons (Frohlich coupling) and acoustic phonons (deformation potential) both synergistically contribute to the interaction, charge carrier localization, and the self-trapping process. Further studies are needed to understand the modulation of the electron-phonon coupling, for example, elucidating the relationship between the Jahn-Teller distortion, the B-site octahedra disordering, the structure dimensionality, and the 

**2105898 (24 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

electron-phonon coupling in Cs2AgBiBr6. Various strategies including doping/alloying, combined with heterojunction structures, dielectric confinement, and bond length compression (by chemical/mechanical pressure) are promising to reduce the electron-phonon coupling in Cs2AgBiBr6. Successful reduction should yield a higher current density from solar cells and photodetectors, resulting in increased efficiency and responsivity. 

- 3) The defects in Cs2AgBiBr6 should be carefully suppressed. Cs2AgBiBr6 is prone to defect formations, especially deeplevel defects. For Cs2AgBiBr6, the trap-state density is currently optimized to be 1.74 × 10<sup>9</sup> , 2.13 × 10<sup>16</sup> and 9.1 × 10<sup>16</sup> cm<sup>–3</sup> for single crystals, evaporated and solution-processed thin films, respectively, which is comparable or slightly higher than the representative MAPbI3 crystals and films (crystals: 7.6 × 10<sup>8</sup> cm<sup>–3</sup> , films: 2.2 × 10<sup>16</sup> cm<sup>–3</sup> ).<sup>[80,118,166,198]</sup> However, considering more deep-level defects exist in Cs2AgBiBr6, defect manipulation is more imperative. The possible antisite defects (AgBi or BiAg) and vacancy defects (Bi or Br vacancies) should be omitted to reduce non-radiative recombination. Experimental evidence is needed to fully understand the impact that defects have upon the material optoelectronic properties and device performance. Strategies of optimization on the growth condition, introducing passivation materials, or modification on device interfaces will play important roles in reducing the deep-level bulk/interface defects. A reduction in defect recombination is an effective method to reduce voltage losses and increase current density across many devices. 

- 4) Despite Cs2AgBiBr6 having presented its multifunctionality in many different applications, there is still a massive scope to improve the performance. Taking solar cells as an example, the 3D structure, high stability, environmental friendliness, long carrier lifetime, and diffusion length have made Cs2AgBiBr6 attractive in the photovoltaic research field. However, current devices are limited by their low _J_ SC and _V_ OC, enhancing light absorption, reducing trap-related non-radiative recombination, and improving charge extraction efficiency will be the key steps to achieve better performance. In addition, using novel structures such as p-n or p-i-n homojunctions can guarantee a high-quality interface and perfect grain orientation, which will improve charge extraction in Cs2AgBiBr6 solar cells. There is the opinion that the wide and indirect bandgap will rule out the photovoltaic applications, but we hope that through the aforementioned methods, a significant breakthrough in the efficiency, especially the current density, will be realized in the near future. In fact, Cs2AgBiBr6’s wide bandgap may actually allow for alternative applications such as promising semi-transparent or tandem photovoltaics. Apart from solar cells, it is apparent that Cs2AgBiBr6 presents an exciting opportunity for many single/multifunctional applications, such as photodetectors, X-ray detectors, ferroelectric data storage, magnetic spintronics, light emission, photocatalysis, etc. Therefore, through continued investigation on rational design and manipulation of materials and devices, the performance of these diverse applications will be taken to a new level, thus, enabling the wide-scale commercialization of next-generation, non-toxic, stable, and efficient perovskite-based devices. 

## **Acknowledgements** 

The authors thank F. X. Ji, S. P. Wang, and Dr. Y. Q. Shang for helpful discussions. H.W.L. would like to thank the National Natural Science Foundation of China (Grant No. 11904115). The investigation into leadfree double perovskites at Linköping University is financially supported by Knut and Alice Wallenberg Foundation (Dnr KAW 2019.0082), the Swedish Energy Agency (46564-1), and the Swedish Government Strategic Research Area in Materials Science on Functional Materials at Linköping University (faculty grant SFO-Mat-LiU no. 2009-00971). F.G. is Wallenberg Academy Fellow. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Keywords** 

applications, Cs2AgBiBr6, fundamentals, lead-free 

Received: June 18, 2021 Revised: August 9, 2021 Published online: September 5, 2021 

- [1] M. A. Green, A. Ho-Baillie, H. J. Snaith, _Nat. Photonics_ **2014** , _8_ , 506. [2] S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, _Nature_ **2019** , _571_ , 245. 

- [3] M. V. Kovalenko, L. Protesescu, M. I. Bodnarchuk, _Science_ **2017** , _358_ , 745. 

- [4] Y. Zhao, K. Zhu, _Chem. Soc. Rev._ **2016** , _45_ , 655. 

- [5] NREL Best Research-Cell Efficiency Chart, https://www.nrel. gov/pv/assets/pdfs/best-research-cell-efficiencies.20200104.pdf (accessed: April 2021). 

- [6] X.-K. Liu, W. Xu, S. Bai, Y. Jin, J. Wang, R. H. Friend, F. Gao, _Nat. Mater._ **2021** , _20_ , 10. 

- [7] C. Kuang, Z. Hu, Z. Yuan, K. Wen, J. Qing, L. Kobera, S. Abbrent, J. Brus, C. Yin, H. Wang, W. Xu, J. Wang, S. Bai, F. Gao, _Joule_ **2021** , _5_ , 618. 

- [8] J. Li, H.-L. Cao, W.-B. Jiao, Q. Wang, M. Wei, I. Cantone, J. Lü, A. Abate, _Nat. Commun._ **2020** , _11_ , 310. 

- [9] T. Zhang, Z. Cai, S. Chen, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 20680. 

- [10] W. Pan, H. Wu, J. Luo, Z. Deng, C. Ge, C. Chen, X. Jiang, W.-J. Yin, G. Niu, L. Zhu, L. Yin, Y. Zhou, Q. Xie, X. Ke, M. Sui, J. Tang, _Nat. Photonics_ **2017** , _11_ , 726. 

- [11] B. Wang, N. Li, L. Yang, C. Dall’Agnese, A. K. Jena, S.-i. Sasaki, T. Miyasaka, H. Tamiaki, X.-F. Wang, _J. Am. Chem. Soc._ **2021** , _143_ , 2207. 

- [12] F. Brivio, J. M. Frost, J. M. Skelton, A. J. Jackson, O. J. Weber, M. T. Weller, A. R. Goñi, A. M. A. Leguy, P. R. F. Barnes, A. Walsh, _Phys. Rev. B_ **2015** , _92_ , 144308. 

- [13] S. Jiang, Y. Fang, R. Li, H. Xiao, J. Crowley, C. Wang, T. J. White, W. A. Goddard III, Z. Wang, T. Baikie, J. Fang, _Angew. Chem., Int. Ed._ **2016** , _55_ , 6540. 

- [14] W. Ning, J. Bao, Y. Puttisong, F. Moro, L. Kobera, S. Shimono, L. Wang, F. Ji, M. Cuartero, S. Kawaguchi, S. Abbrent, H. Ishibashi, R. De Marco, I. A. Bouianova, G. A. Crespo, Y. Kubota, J. Brus, D. Y. Chung, L. Sun, W. M. Chen, M. G. Kanatzidis, F. Gao, _Sci. Adv._ **2020** , _6_ , eabb5381. 

- [15] L. Dong, S. Sun, Z. Deng, W. Li, F. Wei, Y. Qi, Y. Li, X. Li, P. Lu, U. Ramamurty, _Comput. Mater. Sci._ **2018** , _141_ , 49. 

**2105898 (25 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [16] H. Siddique, Z. Xu, X. Li, S. Saeed, W. Liang, X. Wang, C. Gao, R. Dai, Z. Wang, Z. Zhang, _J. Phys. Chem. Lett._ **2020** , _11_ , 9572. 

- [17] Q. Li, Y. Wang, W. Pan, W. Yang, B. Zou, J. Tang, Z. Quan, _Angew. Chem., Int. Ed._ **2017** , _56_ , 15969. 

- [18] F. Wei, Z. Deng, S. Sun, N. T. P. Hartono, H. L. Seng, T. Buonassisi, P. D. Bristowe, A. K. Cheetham, _Chem. Commun._ **2019** , _55_ , 3721. 

- [19] W. Ning, X.-G. Zhao, J. Klarbring, S. Bai, F. Ji, F. Wang, S. I. Simak, Y. Tao, X.-M. Ren, L. Zhang, W. Huang, I. A. Abrikosov, F. Gao, _Adv. Funct. Mater._ **2019** , _29_ , 1807375. 

- [20] J. Yang, P. Zhang, S.-H. Wei, _J. Phys. Chem. Lett._ **2018** , _9_ , 31. 

- [21] C. Meneghini, S. Ray, F. Liscio, F. Bardelli, S. Mobilio, D. D. Sarma, _Phys. Rev. Lett._ **2009** , _103_ , 046403. 

- [22] M. Delor, A. H. Slavney, N. R. Wolf, M. R. Filip, J. B. Neaton, H. I. Karunadasa, N. S. Ginsberg, _ACS Energy Lett._ **2020** , _5_ , 1337. 

- [23] G. Y. Liu, G. H. Rao, X. M. Feng, H. F. Yang, Z. W. Ouyang, W. F. Liu, J. K. Liang, _J. Alloys Compd._ **2003** , _353_ , 42. 

- [24] S. Vasala, M. Lehtimäki, Y. H. Huang, H. Yamauchi, J. B. Goodenough, M. Karppinen, _J. Solid State Chem._ **2010** , _183_ , 1007. 

- [25] W. Yuan, G. Niu, Y. Xian, H. Wu, H. Wang, H. Yin, P. Liu, W. Li, J. Fan, _Adv. Funct. Mater._ **2019** , _29_ , 1900234. 

- [26] N. Setter, L. E. Cross, _J. Mater. Sci._ **1980** , _15_ , 2478. 

- [27] Z. Xiao, W. Meng, J. Wang, Y. Yan, _ChemSusChem_ **2016** , _9_ , 2628. 

- [28] M. García-Hernández, J. L. Martínez, M. J. Martínez-Lope, M. T. Casais, J. A. Alonso, _Phys. Rev. Lett._ **2001** , _86_ , 2443. 

- [29] T.-W. Lim, S.-D. Kim, K.-D. Sung, Y.-M. Rhyim, H. Jeen, J. Yun, K.-H. Kim, K.-M. Song, S. Lee, S.-Y. Chung, M. Choi, S.-Y. Choi, _Sci. Rep._ **2016** , _6_ , 19746. 

- [30] L. Mao, S. M. L. Teicher, C. C. Stoumpos, R. M. Kennard, R. A. DeCrescent, G. Wu, J. A. Schuller, M. L. Chabinyc, A. K. Cheetham, R. Seshadri, _J. Am. Chem. Soc._ **2019** , _141_ , 19099. 

- [31] B. A. Connor, L. Leppert, M. D. Smith, J. B. Neaton, H. I. Karunadasa, _J. Am. Chem. Soc._ **2018** , _140_ , 5235. 

- [32] W. Guo, X. Liu, S. Han, Y. Liu, Z. Xu, M. Hong, J. Luo, Z. Sun, _Angew. Chem., Int. Ed._ **2020** , _59_ , 13879. 

- [33] G. Grancini, M. K. Nazeeruddin, _Nat. Rev. Mater._ **2019** , _4_ , 4. 

- [34] N. Daem, J. Dewalque, F. Lang, A. Maho, G. Spronck, C. Henrist, P. Colson, S. D. Stranks, R. Cloots, _Solar RRL_ **2021** , _5_ , 2100422. 

- [35] J. Cho, J. T. DuBose, P. V. Kamat, _Chem. Mater._ **2020** , _32_ , 510. 

- [36] D. E. Lee, S. Y. Kim, H. W. Jang, _J. Korean Ceram. Soc._ **2020** , _57_ , 455. 

- [37] X. Yang, W. Wang, R. Ran, W. Zhou, Z. Shao, _Energy Fuels_ **2020** , _34_ , 10513. 

- [38] F. Ji, J. Klarbring, F. Wang, W. Ning, L. Wang, C. Yin, J. S. M. Figueroa, C. K. Christensen, M. Etter, T. Ederth, L. Sun, S. I. Simak, I. A. Abrikosov, F. Gao, _Angew. Chem., Int. Ed._ **2020** , _59_ , 15191. 

- [39] A. H. Slavney, T. Hu, A. M. Lindenberg, H. I. Karunadasa, _J. Am. Chem. Soc._ **2016** , _138_ , 2138. 

- [40] L. Schade, A. D. Wright, R. D. Johnson, M. Dollmann, B. Wenger, P. K. Nayak, D. Prabhakaran, L. M. Herz, R. Nicholas, H. J. Snaith, P. G. Radaelli, _ACS Energy Lett._ **2019** , _4_ , 299. 

- [41] R. Fu, Y. Chen, X. Yong, Z. Ma, L. Wang, P. Lv, S. Lu, G. Xiao, B. Zou, _Nanoscale_ **2019** , _11_ , 17004. 

- [42] Y. Puttisong, F. Moro, S. L. Chen, P. Höjer, W. Ning, F. Gao, I. A. Buyanova, W. M. Chen, _J. Phys. Chem. Lett._ **2020** , _11_ , 4873. 

- [43] J. Su, T. Mou, J. Wen, B. Wang, _J. Phys. Chem. C_ **2020** , _124_ , 5371. 

- [44] X.-G. Zhao, J.-H. Yang, Y. Fu, D. Yang, Q. Xu, L. Yu, S.-H. Wei, L. Zhang, _J. Am. Chem. Soc._ **2017** , _139_ , 2630. 

- [45] C. Wu, Q. Zhang, Y. Liu, W. Luo, X. Guo, Z. Huang, H. Ting, W. Sun, X. Zhong, S. Wei, S. Wang, Z. Chen, L. Xiao, _Adv. Sci._ **2018** , _5_ , 1700759. 

- [46] M. Ghasemi, L. Zhang, J.-H. Yun, M. Hao, D. He, P. Chen, Y. Bai, T. Lin, M. Xiao, A. Du, M. Lyu, L. Wang, _Adv. Funct. Mater._ **2020** , _30_ , 2002342. 

- [47] B. Wang, L. Yang, C. Dall’Agnese, A. K. Jena, S.-i. Sasaki, T. Miyasaka, H. Tamiaki, X.-F. Wang, _Sol. RRL_ **2020** , _4_ , 2000166. 

- [48] R. L. Z. Hoye, L. Eyre, F. Wei, F. Brivio, A. Sadhanala, S. Sun, W. Li, K. H. L. Zhang, J. L. MacManus-Driscoll, P. D. Bristowe, R. H. Friend, A. K. Cheetham, F. Deschler, _Adv. Mater. Interfaces_ **2018** , _5_ , 1800464. 

- [49] S. De Wolf, J. Holovsky, S.-J. Moon, P. Löper, B. Niesen, M. Ledinsky, F.-J. Haug, J.-H. Yum, C. Ballif, _J. Phys. Chem. Lett._ **2014** , _5_ , 1035. 

- [50] A. D. Wright, L. R. V. Buizza, K. J. Savill, G. Longo, H. J. Snaith, M. B. Johnston, L. M. Herz, _J. Phys. Chem. Lett._ **2021** , _12_ , 3352. 

- [51] Y. Bekenstein, J. C. Dahl, J. Huang, W. T. Osowiecki, J. K. Swabeck, E. M. Chan, P. Yang, A. P. Alivisatos, _Nano Lett._ **2018** , _18_ , 3502. 

- [52] A. Schmitz, L. L. Schaberg, S. Sirotinskaya, M. Pantaler, D. C. Lupascu, N. Benson, G. Bacher, _ACS Energy Lett._ **2020** , _5_ , 559. 

- [53] B. Yang, J. Chen, F. Hong, X. Mao, K. Zheng, S. Yang, Y. Li, T. Pullerits, W. Deng, K. Han, _Angew. Chem., Int. Ed._ **2017** , _56_ , 12471. 

- [54] R. Kentsch, M. Scholz, J. Horn, D. Schlettwein, K. Oum, T. Lenzer, _J. Phys. Chem. C_ **2018** , _122_ , 25940. 

- [55] K.-z. Du, W. Meng, X. Wang, Y. Yan, D. B. Mitzi, _Angew. Chem., Int. Ed._ **2017** , _56_ , 8158. 

- [56] S. J. Zelewski, J. M. Urban, A. Surrente, D. K. Maude, A. Kuc, L. Schade, R. D. Johnson, M. Dollmann, P. K. Nayak, H. J. Snaith, P. Radaelli, R. Kudrawiec, R. J. Nicholas, P. Plochocka, M. Baranowski, _J. Mater. Chem. C_ **2019** , _7_ , 8350. 

- [57] B. Wu, W. Ning, Q. Xu, M. Manjappa, M. Feng, S. Ye, J. Fu, S. Lie, T. Yin, F. Wang, T. W. Goh, P. C. Harikesh, Y. K. E. Tay, Z. X. Shen, F. Huang, R. Singh, G. Zhou, F. Gao, T. C. Sum, _Sci. Adv._ **2021** , _7_ , eabd3160. 

- [58] F. Schmitz, K. Guo, J. Horn, R. Sorrentino, G. Conforto, F. Lamberti, R. Brescia, F. Drago, M. Prato, Z. He, U. Giovanella, F. Cacialli, D. Schlettwein, D. Meggiolaro, T. Gatti, _J. Phys. Chem. Lett._ **2020** , _11_ , 8893. 

- [59] A. H. Slavney, L. Leppert, D. Bartesaghi, A. Gold-Parker, M. F. Toney, T. J. Savenije, J. B. Neaton, H. I. Karunadasa, _J. Am. Chem. Soc._ **2017** , _139_ , 5015. 

- [60] A. H. Slavney, L. Leppert, A. Saldivar Valdes, D. Bartesaghi, T. J. Savenije, J. B. Neaton, H. I. Karunadasa, _Angew. Chem., Int. Ed._ **2018** , _57_ , 12765. 

- [61] J. Luo, X. Wang, S. Li, J. Liu, Y. Guo, G. Niu, L. Yao, Y. Fu, L. Gao, Q. Dong, C. Zhao, M. Leng, F. Ma, W. Liang, L. Wang, S. Jin, J. Han, L. Zhang, J. Etheridge, J. Wang, Y. Yan, E. H. Sargent, J. Tang, _Nature_ **2018** , _563_ , 541. 

- [62] A. D. Wright, C. Verdi, R. L. Milot, G. E. Eperon, M. A. PérezOsorio, H. J. Snaith, F. Giustino, M. B. Johnston, L. M. Herz, _Nat. Commun._ **2016** , _7_ , 11755. 

- [63] C. Wehrenfennig, M. Liu, H. J. Snaith, M. B. Johnston, L. M. Herz, _J. Phys. Chem. Lett._ **2014** , _5_ , 1300. 

- [64] J. A. Steele, P. Puech, M. Keshavarz, R. Yang, S. Banerjee, E. Debroye, C. W. Kim, H. Yuan, N. H. Heo, J. Vanacken, A. Walsh, J. Hofkens, M. B. J. Roeffaers, _ACS Nano_ **2018** , _12_ , 8081. 

- [65] J. Lee, E. S. Koteles, M. O. Vassell, _Phys. Rev. B_ **1986** , _33_ , 5512. 

- [66] S. Rudin, T. L. Reinecke, B. Segall, _Phys. Rev. B_ **1990** , _42_ , 11218. 

- [67] H.-H. Fang, F. Wang, S. Adjokatse, N. Zhao, J. Even, M. A. Loi, _Light: Sci. Appl._ **2016** , _5_ , 16056. 

- [68] M. Fu, P. Tamarat, J.-B. Trebbia, M. I. Bodnarchuk, M. V. Kovalenko, J. Even, B. Lounis, _Nat. Commun._ **2018** , _9_ , 3318. 

- [69] J. Fu, M. Li, A. Solanki, Q. Xu, Y. Lekina, S. Ramesh, Z. X. Shen, T. C. Sum, _Adv. Mater._ **2021** , _33_ , 2006233. 

- [70] R. Zeng, L. Zhang, Y. Xue, B. Ke, Z. Zhao, D. Huang, Q. Wei, W. Zhou, B. Zou, _J. Phys. Chem. Lett._ **2020** , _11_ , 2053. 

**2105898 (26 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [71] Y. Lan, B. J. Dringoli, D. A. Valverde-Chávez, C. S. Ponseca, M. Sutton, Y. He, M. G. Kanatzidis, D. G. Cooke, _Sci. Adv._ **2019** , _5_ , eaaw5558. 

- [72] Y. Toyozawa, _Prog. Theor. Phys._ **1958** , _20_ , 53. 

- [73] B. Guzelturk, R. A. Belisle, M. D. Smith, K. Bruening, R. Prasanna, Y. Yuan, V. Gopalan, C. J. Tassone, H. I. Karunadasa, M. D. McGehee, A. M. Lindenberg, _Adv. Mater._ **2018** , _30_ , 1704737. 

- [74] J. P. Perdew, K. Burke, M. Ernzerhof, _Phys. Rev. Lett._ **1996** , _77_ , 3865. 

- [75] J. Paier, M. Marsman, K. Hummer, G. Kresse, I. C. Gerber, J. G. Ángyán, _J. Chem. Phys._ **2006** , _124_ , 154709. 

- [76] T. Li, X. Zhao, D. Yang, M.-H. Du, L. Zhang, _Phys. Rev. Appl._ **2018** , _10_ , 041001. 

- [77] C. Freysoldt, B. Grabowski, T. Hickel, J. Neugebauer, G. Kresse, A. Janotti, C. G. Van de Walle, _Rev. Mod. Phys._ **2014** , _86_ , 253. 

- [78] J. A. Steele, W. Pan, C. Martin, M. Keshavarz, E. Debroye, H. Yuan, S. Banerjee, E. Fron, D. Jonckheere, C. W. Kim, W. Baekelant, G. Niu, J. Tang, J. Vanacken, M. Van der Auweraer, J. Hofkens, M. B. J. Roeffaers, _Adv. Mater._ **2018** , _30_ , 1804450. 

- [79] J. Yang, C. Bao, W. Ning, B. Wu, F. Ji, Z. Yan, Y. Tao, J.-M. Liu, T. C. Sum, S. Bai, J. Wang, W. Huang, W. Zhang, F. Gao, _Adv. Opt. Mater._ **2019** , _7_ , 1801732. 

- [80] W. Gao, C. Ran, J. Xi, B. Jiao, W. Zhang, M. Wu, X. Hou, Z. Wu, _ChemPhysChem_ **2018** , _19_ , 1696. 

- [81] T. Islam, R. Jani, S. M. A. Amin, K. M. Shorowordi, S. S. Nishat, A. Kabir, M. F. N. Taufique, S. Chowdhury, S. Banerjee, S. Ahmed, _Comput. Mater. Sci._ **2020** , _184_ , 109865. 

- [82] J. Xiu, Y. Shao, L. Chen, Y. Feng, J. Dai, X. Zhang, Y. Lin, Y. Zhu, Z. Wu, Y. Zheng, H. Pan, C. Liu, X. Shi, X. Cheng, Z. He, _Mater. Today Energy_ **2019** , _12_ , 186. 

- [83] H. Chen, C.-R. Zhang, Z.-J. Liu, J.-J. Gong, W. Wang, Y.-Z. Wu, H.-S. Chen, _Mater. Sci. Semicond. Process._ **2021** , _123_ , 105541. 

- [84] F. Igbari, R. Wang, Z.-K. Wang, X.-J. Ma, Q. Wang, K.-L. Wang, Y. Zhang, L.-S. Liao, Y. Yang, _Nano Lett._ **2019** , _19_ , 2066. 

- [85] M. T. Sirtl, M. Armer, L. K. Reb, R. Hooijer, P. Dörflinger, M. A. Scheel, K. Tvingstedt, P. Rieder, N. Glück, P. Pandit, S. V. Roth, P. Müller-Buschbaum, V. Dyakonov, T. Bein, _ACS Appl. Energy Mater._ **2020** , _3_ , 11597. 

- [86] B. Yang, J. Chen, S. Yang, F. Hong, L. Sun, P. Han, T. Pullerits, W. Deng, K. Han, _Angew. Chem., Int. Ed._ **2018** , _57_ , 5359. 

- [87] X. Y. Zhu, V. Podzorov, _J. Phys. Chem. Lett._ **2015** , _6_ , 4758. 

- [88] Z. Guo, Y. Wan, M. Yang, J. Snaider, K. Zhu, L. Huang, _Science_ **2017** , _356_ , 59. 

- [89] H. Chung, S. I. Jung, H. J. Kim, W. Cha, E. Sim, D. Kim, W.-K. Koh, J. Kim, _Angew. Chem., Int. Ed._ **2017** , _56_ , 4160. 

- [90] K. Zheng, K. Žídek, M. Abdellah, J. Chen, P. Chábera, W. Zhang, M. J. Al-Marri, T. Pullerits, _ACS Energy Lett._ **2016** , _1_ , 1154. 

- [91] B. Yang, K. Han, _Acc. Chem. Res._ **2019** , _52_ , 3188. 

- [92] B. Yang, F. Hong, J. Chen, Y. Tang, L. Yang, Y. Sang, X. Xia, J. Guo, H. He, S. Yang, W. Deng, K. Han, _Angew. Chem., Int. Ed._ **2019** , _58_ , 2278. 

- [93] Y. Yin, W. Tian, J. Leng, J. Bian, S. Jin, _J. Phys. Chem. Lett._ **2020** , _11_ , 6956. 

- [94] W. Ning, F. Wang, B. Wu, J. Lu, Z. Yan, X. Liu, Y. Tao, J.-M. Liu, W. Huang, M. Fahlman, L. Hultman, T. C. Sum, F. Gao, _Adv. Mater._ **2018** , _30_ , 1706246. 

- [95] D. Bartesaghi, A. H. Slavney, M. C. Gélvez-Rueda, B. A. Connor, F. C. Grozema, H. I. Karunadasa, T. J. Savenije, _J. Phys. Chem. C_ **2018** , _122_ , 4809. 

- [96] Z. Zhang, C. Wu, D. Wang, G. Liu, Q. Zhang, W. Luo, X. Qi, X. Guo, Y. Zhang, Y. Lao, B. Qu, L. Xiao, Z. Chen, _Org. Electron._ **2019** , _74_ , 204. 

- [97] M. Keshavarz, E. Debroye, M. Ottesen, C. Martin, H. Zhang, E. Fron, R. Küchler, J. A. Steele, M. Bremholm, J. Van de Vondel, H. I. Wang, M. Bonn, M. B. J. Roeffaers, S. Wiedmann, J. Hofkens, _Adv. Mater._ **2020** , _32_ , 2001878. 

- [98] J. Li, J. Duan, J. Du, X. Yang, Y. Wang, P. Yang, Y. Duan, Q. Tang, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 47408. 

- [99] R. Yin, G. Yu, W.-Y. Cong, C. Guan, J. Li, Y.-B. Lu, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 44798. 

- [100] Z. Li, S. R. Kavanagh, M. Napari, R. G. Palgrave, M. AbdiJalebi, Z. Andaji-Garmaroudi, D. W. Davies, M. Laitinen, J. Julin, M. A. Isaacs, R. H. Friend, D. O. Scanlon, A. Walsh, R. L. Z. Hoye, _J. Mater. Chem. A_ **2020** , _8_ , 21780. 

- [101] E. M. Hutter, M. C. Gélvez-Rueda, D. Bartesaghi, F. C. Grozema, T. J. Savenije, _ACS Omega_ **2018** , _3_ , 11655. 

- [102] K. P. Lindquist, S. A. Mack, A. H. Slavney, L. Leppert, A. Gold-Parker, J. F. Stebbins, A. Salleo, M. F. Toney, J. B. Neaton, H. I. Karunadasa, _Chem. Sci._ **2019** , _10_ , 10620. 

- [103] M. B. Gray, E. T. McClure, P. M. Woodward, _J. Mater. Chem. C_ **2019** , _7_ , 9686. 

- [104] D. J. Kubicki, M. Saski, S. MacPherson, K. Gałkowski, J. Lewiński, D. Prochowicz, J. J. Titman, S. D. Stranks, _Chem. Mater._ **2020** , _32_ , 8129. 

- [105] L. Zhang, Y. Fang, L. Sui, J. Yan, K. Wang, K. Yuan, W. L. Mao, B. Zou, _ACS Energy Lett._ **2019** , _4_ , 2975. 

- [106] N. Pai, J. Lu, M. Wang, A. S. R. Chesman, A. Seeber, P. V. Cherepanov, D. C. Senevirathna, T. R. Gengenbach, N. V. Medhekar, P. C. Andrews, U. Bach, A. N. Simonov, _J. Mater. Chem. A_ **2020** , _8_ , 2008. 

- [107] F. Ji, Y. Huang, F. Wang, L. Kobera, F. Xie, J. Klarbring, S. Abbrent, J. Brus, C. Yin, S. I. Simak, I. A. Abrikosov, I. A. Buyanova, W. M. Chen, F. Gao, _Adv. Funct. Mater._ **2020** , _30_ , 2005521. 

- [108] F. Ji, F. Wang, L. Kobera, S. Abbrent, J. Brus, W. Ning, F. Gao, _Chem. Sci._ **2021** , _12_ , 1730. 

- [109] H. Yin, Y. Xian, Y. Zhang, W. Chen, X. Wen, N. U. Rahman, Y. Long, B. Jia, J. Fan, W. Li, _Adv. Funct. Mater._ **2020** , _30_ , 2002225. 

- [110] S. K. Sahoo, D. Sharma, R. K. Bera, G. Crisponi, J. F. Callan, _Chem. Soc. Rev._ **2012** , _41_ , 7195. 

- [111] V. K. Ravi, N. Singhal, A. Nag, _J. Mater. Chem. A_ **2018** , _6_ , 21666. 

- [112] C. N. Savory, A. Walsh, D. O. Scanlon, _ACS Energy Lett._ **2016** , _1_ , 949. 

- [113] M. T. Islam, M. R. Jani, S. M. Al Amin, M. S. U. Sami, K. M. Shorowordi, M. I. Hossain, M. Devgun, S. Chowdhury, S. Banerje, S. Ahmed, _Opt. Mater._ **2020** , _105_ , 109957. 

- [114] N. Singh, A. Agarwal, M. Agarwal, _Opt. Mater._ **2021** , _114_ , 110964. 

- [115] E. Greul, M. L. Petrus, A. Binek, P. Docampo, T. Bein, _J. Mater. Chem. A_ **2017** , _5_ , 19972. 

- [116] G. Xing, N. Mathews, S. Sun, S. S. Lim, Y. M. Lam, M. Grätzel, S. Mhaisalkar, T. C. Sum, _Science_ **2013** , _342_ , 344. 

- [117] D. Zhao, B. Wang, C. Liang, T. Liu, Q. Wei, S. Wang, K. Wang, Z. Zhang, X. Li, S. Peng, G. Xing, _Sci. China Mater._ **2020** , _63_ , 1518. 

- [118] M. Wang, P. Zeng, S. Bai, J. Gu, F. Li, Z. Yang, M. Liu, _Sol. RRL_ **2018** , _2_ , 1800217. 

- [119] X. Yang, Y. Chen, P. Liu, H. Xiang, W. Wang, R. Ran, W. Zhou, Z. Shao, _Adv. Funct. Mater._ **2020** , _30_ , 2001557. 

- [120] Z. Li, P. Wang, C. Ma, F. Igbari, Y. Kang, K.-L. Wang, W. Song, C. Dong, Y. Li, J. Yao, D. Meng, Z.-K. Wang, Y. Yang, _J. Am. Chem. Soc._ **2021** , _143_ , 2593. 

- [121] D. Luo, R. Su, W. Zhang, Q. Gong, R. Zhu, _Nat. Rev. Mater._ **2020** , _5_ , 44. 

- [122] Y. Shao, Y. Yuan, J. Huang, _Nat. Energy_ **2016** , _1_ , 15001. 

- [123] S. Chen, Y. Hou, H. Chen, M. Richter, F. Guo, S. Kahmann, X. Tang, T. Stubhan, H. Zhang, N. Li, N. Gasparini, C. O. R. Quiroz, L. S. Khanzada, G. J. Matt, A. Osvet, C. J. Brabec, _Adv. Energy Mater._ **2016** , _6_ , 1600132. 

- [124] J. Yao, T. Kirchartz, M. S. Vezie, M. A. Faist, W. Gong, Z. He, H. Wu, J. Troughton, T. Watson, D. Bryant, J. Nelson, _Phys. Rev. Appl._ **2015** , _4_ , 014020. 

- [125] T. Kirchartz, U. Rau, _Adv. Energy Mater._ **2018** , _8_ , 1703385. 

**2105898 (27 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 

- [126] M. T. Sirtl, F. Ebadi, B. T. van Gorkom, P. Ganswindt, R. A. J. Janssen, T. Bein, W. Tress, _Adv. Opt. Mater._ **2021** , _9_ , 2100202. 

- [127] L. Schade, S. Mahesh, G. Volonakis, M. Zacharias, B. Wenger, F. Schmidt, S. V. Kesava, D. Prabhakaran, M. Abdi-Jalebi, M. Lenz, F. Giustino, G. Longo, P. G. Radaelli, H. J. Snaith, _ACS Energy Lett._ **2021** , _6_ , 1073. 

- [128] D. W. deQuilettes, K. Frohna, D. Emin, T. Kirchartz, V. Bulovic, D. S. Ginger, S. D. Stranks, _Chem. Rev._ **2019** , _119_ , 11007. 

- [129] G. Longo, S. Mahesh, L. R. V. Buizza, A. D. Wright, A. J. Ramadan, M. Abdi-Jalebi, P. K. Nayak, L. M. Herz, H. J. Snaith, _ACS Energy Lett._ **2020** , _5_ , 2200. 

- [130] C. Bao, J. Yang, S. Bai, W. Xu, Z. Yan, Q. Xu, J. Liu, W. Zhang, F. Gao, _Adv. Mater._ **2018** , _30_ , 1803422. 

- [131] W. Tian, H. Zhou, L. Li, _Small_ **2017** , _13_ , 1702107. 

- [132] N. Li, Z. Lan, L. Cai, F. Zhu, _J. Mater. Chem. C_ **2019** , _7_ , 3711. 

- [133] F. P. García de Arquer, A. Armin, P. Meredith, E. H. Sargent, _Nat. Rev. Mater._ **2017** , _2_ , 16100. 

- [134] M. Ahmadi, T. Wu, B. Hu, _Adv. Mater._ **2017** , _29_ , 1605242. 

- [135] C. Bao, W. Xu, J. Yang, S. Bai, P. Teng, Y. Yang, J. Wang, N. Zhao, W. Zhang, W. Huang, F. Gao, _Nat. Electron._ **2020** , _3_ , 156. 

- [136] C. Wu, B. Du, W. Luo, Y. Liu, T. Li, D. Wang, X. Guo, H. Ting, Z. Fang, S. Wang, Z. Chen, Y. Chen, L. Xiao, _Adv. Opt. Mater._ **2018** , _6_ , 1800811. 

- [137] Y. Li, Z. Shi, L. Lei, S. Li, D. Yang, D. Wu, T. Xu, Y. Tian, Y. Lu, Y. Wang, L. Zhang, X. Li, Y. Zhang, G. Du, C. Shan, _Adv. Mater. Interfaces_ **2019** , _6_ , 1900188. 

- [138] W. Zhang, Z. Gong, S. Pan, Y. Zhang, D. Chen, J. Pan, _J. Cryst. Growth_ **2020** , _552_ , 125922. 

- [139] J. Liu, Y. Wang, H. Wen, Q. Bao, L. Shen, L. Ding, _Solar RRL_ **2020** , _4_ , 2000139. 

- [140] Y. Wang, L. Song, Y. Chen, W. Huang, _ACS Photonics_ **2020** , _7_ , 10. [141] L.-Z. Lei, Z.-F. Shi, Y. Li, Z.-Z. Ma, F. Zhang, T.-T. Xu, Y.-T. Tian, D. Wu, X.-J. Li, G.-T. Du, _J. Mater. Chem. C_ **2018** , _6_ , 7982. 

- [142] G. Yan, B. Jiang, Y. Yuan, M. Kuang, X. Liu, Z. Zeng, C. Zhao, J.-H. He, W. Mai, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 6064. 

- [143] F. Fang, H. Li, S. Fang, B. Zhou, F. Huang, C. Ma, Y. Wan, S. Jiang, Y. Wang, B. Tian, Y. Shi, _Adv. Opt. Mater._ **2021** , _9_ , 2001930. 

- [144] L. Li, S. Ye, J. Qu, F. Zhou, J. Song, G. Shen, _Small_ **2021** , _17_ , 2005606. 

- [145] F. Cao, L. Li, _Adv. Funct. Mater._ **2021** , _31_ , 2008275. 

- [146] F. Cao, X. Xu, D. Yu, H. Zeng, _Nanophotonics_ **2021** , _10_ , 2221. 

- [147] W. Lin, G. Chen, E. Li, L. He, W. Yu, G. Peng, H. Chen, T. Guo, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 43967. 

- [148] Y. Dang, G. Tong, W. Song, Z. Liu, L. Qiu, L. K. Ono, Y. Qi, _J. Mater. Chem. C_ **2020** , _8_ , 276. 

- [149] G. Yan, Z. Ji, Z. Li, B. Jiang, M. Kuang, X. Cai, Y. Yuan, W. Mai, _Sci. China Mater._ **2021** , _64_ , 198. 

- [150] D. Liu, B.-B. Yu, M. Liao, Z. Jin, L. Zhou, X. Zhang, F. Wang, H. He, T. Gatti, Z. He, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 30530. 

- [151] Z.-X. Zhang, C. Li, Y. Lu, X.-W. Tong, F.-X. Liang, X.-Y. Zhao, D. Wu, C. Xie, L.-B. Luo, _J. Phys. Chem. Lett._ **2019** , _10_ , 5343. 

- [152] W. Tian, L. Min, F. Cao, L. Li, _Adv. Mater._ **2020** , _32_ , 1906974. 

- [153] H. Wei, Y. Fang, P. Mulligan, W. Chuirazzi, H.-H. Fang, C. Wang, B. R. Ecker, Y. Gao, M. A. Loi, L. Cao, J. Huang, _Nat. Photonics_ **2016** , _10_ , 333. 

- [154] Y. Xu, X. Zhao, M. Xia, X. Zhang, _J. Mater. Chem. C_ **2021** , _9_ , 5452. [155] Y. Zhou, J. Chen, O. M. Bakr, O. F. Mohammed, _ACS Energy Lett._ **2021** , _6_ , 739. 

- [156] Z. Li, F. Zhou, H. Yao, Z. Ci, Z. Yang, Z. Jin, _Mater. Today_ **2021** , https://doi.org/10.1016/j.mattod.2021.01.028. 

- [157] R. Zhuang, X. Wang, W. Ma, Y. Wu, X. Chen, L. Tang, H. Zhu, J. Liu, L. Wu, W. Zhou, X. Liu, Y. Yang, _Nat. Photonics_ **2019** , _13_ , 602. 

- [158] Y. Liu, Z. Xu, Z. Yang, Y. Zhang, J. Cui, Y. He, H. Ye, K. Zhao, H. Sun, R. Lu, M. Liu, M. G. Kanatzidis, S. Liu, _Matter_ **2020** , _3_ , 180. 

- [159] Y. Yuan, J. Huang, _Acc. Chem. Res._ **2016** , _49_ , 286. 

- [160] D. Li, H. Wu, H.-C. Cheng, G. Wang, Y. Huang, X. Duan, _ACS Nano_ **2016** , _10_ , 6933. 

- [161] B. Yang, W. Pan, H. Wu, G. Niu, J.-H. Yuan, K.-H. Xue, L. Yin, X. Du, X.-S. Miao, X. Yang, Q. Xie, J. Tang, _Nat. Commun._ **2019** , _10_ , 1989. 

- [162] S. Tie, W. Zhao, D. Xin, M. Zhang, J. Long, Q. Chen, X. Zheng, J. Zhu, W.-H. Zhang, _Adv. Mater._ **2020** , _32_ , 2001981. 

- [163] Z. Zhang, D. Cao, Z. Huang, E. O. Danilov, C.-C. Chung, D. Sun, G. Yang, _Adv. Opt. Mater._ **2021** , _9_ , 2001575. 

- [164] H. Zhang, Z. Gao, R. Liang, X. Zheng, X. Geng, Y. Zhao, D. Xie, J. Hong, H. Tian, Y. Yang, X. Wang, T. Ren, _IEEE Trans. Electron Devices_ **2019** , _66_ , 2224. 

- [165] Z. Xu, X. Liu, Y. Li, X. Liu, T. Yang, C. Ji, S. Han, Y. Xu, J. Luo, Z. Sun, _Angew. Chem., Int. Ed._ **2019** , _58_ , 15757. 

- [166] L. Yin, H. Wu, W. Pan, B. Yang, P. Li, J. Luo, G. Niu, J. Tang, _Adv. Opt. Mater._ **2019** , _7_ , 1900491. 

- [167] H. Li, X. Shan, J. N. Neu, T. Geske, M. Davis, P. Mao, K. Xiao, T. Siegrist, Z. Yu, _J. Mater. Chem. C_ **2018** , _6_ , 11961. 

- [168] Y. Zhang, Y. Liu, Z. Xu, H. Ye, Z. Yang, J. You, M. Liu, Y. He, M. G. Kanatzidis, S. Liu, _Nat. Commun._ **2020** , _11_ , 2304. 

- [169] X. Zheng, W. Zhao, P. Wang, H. Tan, M. I. Saidaminov, S. Tie, L. Chen, Y. Peng, J. Long, W.-H. Zhang, _J. Energy Chem._ **2020** , _49_ , 299. 

- [170] B.-B. Zhang, X. Liu, B. Xiao, A. B. Hafsia, K. Gao, Y. Xu, J. Zhou, Y. Chen, _J. Phys. Chem. Lett._ **2020** , _11_ , 432. 

- [171] Y. Song, L. Li, W. Bi, M. Hao, Y. Kang, A. Wang, Z. Wang, H. Li, X. Li, Y. Fang, D. Yang, Q. Dong, _Research_ **2020** , _2020_ , 5958243. 

- [172] Y.-M. You, W.-Q. Liao, D. Zhao, H.-Y. Ye, Y. Zhang, Q. Zhou, X. Niu, J. Wang, P.-F. Li, D.-W. Fu, Z. Wang, S. Gao, K. Yang, J.-M. Liu, J. Li, Y. Yan, R.-G. Xiong, _Science_ **2017** , _357_ , 306. 

- [173] N. A. Benedek, C. J. Fennie, _J. Phys. Chem. C_ **2013** , _117_ , 13339. 

- [174] W. Zhang, M. Hong, J. Luo, _Angew. Chem., Int. Ed._ **2020** , _59_ , 9305. 

- [175] X. Liu, Z. Xu, P. Long, Y. Yao, C. Ji, L. Li, Z. Sun, M. Hong, J. Luo, _Chem. Mater._ **2020** , _32_ , 8965. 

- [176] C.-F. Wang, H. Li, M.-G. Li, Y. Cui, X. Song, Q.-W. Wang, J.-Y. Jiang, M.-M. Hua, Q. Xu, K. Zhao, H.-Y. Ye, Y. Zhang, _Adv. Funct. Mater._ **2021** , _31_ , 2009457. 

- [177] N. Nuraje, K. Su, _Nanoscale_ **2013** , _5_ , 8752. 

- [178] W.-Q. Liao, Y. Zhang, C.-L. Hu, J.-G. Mao, H.-Y. Ye, P.-F. Li, S. D. Huang, R.-G. Xiong, _Nat. Commun._ **2015** , _6_ , 7338. 

- [179] B. Náfrádi, P. Szirmai, M. Spina, H. Lee, O. V. Yazyev, A. Arakcheeva, D. Chernyshov, M. Gibert, L. Forró, E. Horváth, _Nat. Commun._ **2016** , _7_ , 13406. 

- [180] J. Wang, C. Zhang, H. Liu, R. McLaughlin, Y. Zhai, S. R. Vardeny, X. Liu, S. McGill, D. Semenov, H. Guo, R. Tsuchikawa, V. V. Deshpande, D. Sun, Z. V. Vardeny, _Nat. Commun._ **2019** , _10_ , 129. 

- [181] N. Chen, T. Cai, W. Li, K. Hills-Kimball, H. Yang, M. Que, Y. Nagaoka, Z. Liu, D. Yang, A. Dong, C.-Y. Xu, R. Zia, O. Chen, _ACS Appl. Mater. Interfaces_ **2019** , _11_ , 16855. 

- [182] H. Huang, B. Pradhan, J. Hofkens, M. B. J. Roeffaers, J. A. Steele, _ACS Energy Lett._ **2020** , _5_ , 1107. 

- [183] X. Xu, Y. Zhong, Z. Shao, _Trends Chem._ **2019** , _1_ , 410. 

- [184] L. Zhou, Y.-F. Xu, B.-X. Chen, D.-B. Kuang, C.-Y. Su, _Small_ **2018** , _14_ , 1703762. 

- [185] Z. Zhang, Y. Liang, H. Huang, X. Liu, Q. Li, L. Chen, D. Xu, _Angew. Chem., Int. Ed._ **2019** , _58_ , 7263. 

- [186] T. Wang, D. Yue, X. Li, Y. Zhao, _Appl. Catal., B_ **2020** , _268_ , 118399. [187] Y. Wang, H. Huang, Z. Zhang, C. Wang, Y. Yang, Q. Li, D. Xu, _Appl. Catal., B_ **2021** , _282_ , 119570. 

**2105898 (28 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

#### **www.afm-journal.de** 

- [188] Z. Weng, J. Qin, A. A. Umar, J. Wang, X. Zhang, H. Wang, X. Cui, X. Li, L. Zheng, Y. Zhan, _Adv. Funct. Mater._ **2019** , _29_ , 1902234. 

- [189] E. T. McClure, M. R. Ball, W. Windl, P. M. Woodward, _Chem. Mater._ **2016** , _28_ , 1348. 

- [190] A. Dey, A. F. Richter, T. Debnath, H. Huang, L. Polavarapu, J. Feldmann, _ACS Nano_ **2020** , _14_ , 5855. 

- [191] Z. Xiao, K.-Z. Du, W. Meng, D. B. Mitzi, Y. Yan, _Angew. Chem., Int. Ed._ **2017** , _56_ , 12107. 

- [192] Z. Xiao, K.-Z. Du, W. Meng, J. Wang, D. B. Mitzi, Y. Yan, _J. Am. Chem. Soc._ **2017** , _139_ , 6054. 

- [193] M. R. Filip, X. Liu, A. Miglio, G. Hautier, F. Giustino, _J. Phys. Chem. C_ **2018** , _122_ , 158. 

- [194] C. Feng, G. Feng, Q. Zhao, S. Li, D. Li, _Front. Mater._ **2020** , _7_ , 168. 

- [195] A. J. Kale, R. Chaurasiya, A. Dixit, _Adv. Theory Simulations_ **2021** , _4_ , 2000224. 

- [196] L. R. V. Buizza, A. D. Wright, G. Longo, H. C. Sansom, C. Q. Xia, M. J. Rosseinsky, M. B. Johnston, H. J. Snaith, L. M. Herz, _ACS Energy Lett._ **2021** , _6_ , 1729. 

- [197] H. C. Sansom, G. Longo, A. D. Wright, L. R. V. Buizza, S. Mahesh, B. Wenger, M. Zanella, M. Abdi-Jalebi, M. J. Pitcher, M. S. Dyer, T. D. Manning, R. H. Friend, L. M. Herz, H. J. Snaith, J. B. Claridge, M. J. Rosseinsky, _J. Am. Chem. Soc._ **2021** , _143_ , 3983. 

- [198] Z. Ni, C. Bao, Y. Liu, Q. Jiang, W.-Q. Wu, S. Chen, X. Dai, B. Chen, B. Hartweg, Z. Yu, Z. Holman, J. Huang, _Science_ **2020** , _367_ , 1352. 



**Hongwei Lei** received his Ph.D. in Microelectronics and Solid-State Electronics from Wuhan University in 2017. He then joined and worked at Huazhong Agricultural University and now he is a postdoctoral researcher in Prof. Feng Gao’s group at Linköping University. His research interests mainly focus on lead-free perovskite materials and related optoelectronic devices. 



**David Hardy** received his Master’s Degree in Sustainable Energy Technologies from the University of Southampton in 2019. He joined Prof. Feng Gao’s research group at Linköping University as a Ph.D. student in 2020. His research interests focus on emerging lead-free perovskite materials for third generation solar cell applications. 



**Feng Gao** is a professor and Wallenberg Academy Fellow at Linköping University in Sweden. He received his Ph.D. from the University of Cambridge (UK) in 2011, followed by a Marie Curie postdoc fellowship at Linköping University. His group currently focuses on research into solutionprocessed energy materials and devices, mainly based on organic semiconductors and metal halide perovskites. 

**2105898 (29 of 29)** 

_Adv. Funct. Mater._ **2021** , _31_ , 2105898 

© 2021 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

