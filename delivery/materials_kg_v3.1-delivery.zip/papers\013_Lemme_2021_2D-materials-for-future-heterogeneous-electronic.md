# 2D materials for future heterogeneous electronics

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 532 |
| 作者 | M. Lemme, D. Akinwande, C. Huyghebaert, C. Stampfer |
| DOI | 10.1038/s41467-022-29001-4 |
| 源文件 | 013_Lemme_2021_2D-materials-for-future-heterogeneous-electronic.pdf |

---
# **<u>2D Materials for Future Heterogeneous Electronics</u>** 

Max C. Lemme<sup>1,2,*</sup> , Deji Akinwande<sup>3</sup> , Cedric Huyghebaert<sup>4</sup> , Christoph Stampfer<sup>5,6</sup> 

1 Chair of Electronic Devices, RWTH Aachen University, Otto-Blumenthal-Str. 2, 52074 Aachen, Germany 

- 2 AMO GmbH, Advanced Microelectronic Center Aachen, Otto-Blumenthal-Str. 25, 52074 Aachen, Germany 

- 3 Department of Electrical and Computer Engineering, Microelectronics Research Center, The University of Texas at Austin, Austin, 78712, Texas, USA 

4 IMEC, Leuven, Belgium 

- 5 JARA-FIT and 2nd Institute of Physics, RWTH Aachen University, 52074 Aachen, Germany, EU 

- 6 Peter Grünberg Institute (PGI-9), Forschungszentrum Jülich, 52425 Jülich, Germany, EU 

## **Abstract** 

Graphene and two-dimensional materials (2DM) remain an active field of research in science and engineering over 15 years after the first reports of 2DM. The vast amount 

of available data and the high performance of device demonstrators leave little doubt about the potential of 2DM for applications in electronics, photonics and sensing. So 

where are the integrated chips and enabled products? We try to answer this by 

summarizing the main challenges and opportunities that have thus far prevented 2DM applications. 

1 

## **Manufacturing Technology** 

The key answer to this question, in our opinion, can be found by comparing the manufacturing readiness level of 2DM with standard semiconductor technology. What is needed, but not available yet, are turnkey manufacturing solutions that bring 2DM into silicon (Si) semiconductor factories. These “unit processes” then serve to integrate 2DMs with Si complementary metal oxide semiconductor (CMOS) chips in the back-end or front-end of the line.<sup>1,2</sup> Deposition and growth technology of 2DMs is generally available at the wafer scale, but defects and contaminations are not yet compliant with specifications defined for production.<sup>3</sup> In addition, high process temperatures are typically required for high quality materials, which complicates direct growth on wafers and makes transfer technologies desirable. In principle, wafer bonding techniques could solve this, but have not reached full manufacturing levels.<sup>4</sup> At the device level, challenges are linked to the control of the dielectric- and contact interfaces to the 2DMs. The self-passivated nature of 2DM surfaces requires seeding to achieve the deposition of dielectrics with manufacturable methods, e.g. through atomic layer deposition. The resulting non-ideal interfaces limit device performance compared to the best laboratory demonstrators that use crystalline 2D insulators such as hexagonal boron nitride.<sup>5</sup> The same is true for electrical contacts to 2DMs, which only partly meet industry specifications,<sup>6</sup> and have not reached manufacturing readiness. The removal or etching of materials with high selectivity towards underlying layers is particularly challenging for 2DMs, because it requires atomic precision that can only be achieved with specific chemistry and dedicated atomic layer etching tools. Developing suitable processes will be tedious, because of the wide range of potential 2DMs and their combinations. As a 

2 

result, etching chemistry and other, physical process parameters depend strongly on the specific situation which each require individual solutions. Doping, or the replacement of atoms in the crystal lattice, is a standard but crucial technology for silicon that relies on statistical distributions. In the 2DM field, the term doping is often used to describe charge transfer to the 2D layer from defects or molecular adsorbates in its vicinity. Controlling this “effective-doping” with precision and long-term stability remains a challenge, but so would classic doping, which would ideally require replacing 2D crystal atoms in a deterministic way, as shown for silicon technology.<sup>7</sup> Solving these crucial manufacturing bottlenecks is the explicit goal of the European Experimental Pilot Line for 2D Materials.<sup>8</sup> Co-integration of 2DMs with silicon CMOS technology will lead to a vast increase in chip functionality and enable the arrival of 2DM applications in the order of their device complexity, as illustrated in Figure 1 and presented in the following. 

3 



Figure 1: The era of geometrical or Dennard<sup>9</sup> scaling of silicon technology ended around the turn of the century (green lines, “happy scaling”). Since then, material and architecture innovations like copper interconnects,<sup>10</sup> high-k dielectrics with metal gates<sup>11</sup> and FinFETs<sup>12</sup> continued to drive Moore’s law (yellow lines, “less happy scaling”). Future scaling, or “More Moore”, may require thin nanosheet transistors, where 2D materials are considered ideal candidates (magenta, inset a and transmission electron micrograph).<sup>13,14</sup> Substantial performance and functionality gains are expected through “CMOS + X” integration, for example through sensors or high frequency electronics integrated on CMOS chips in the “More Than Moore” domain (inset c). Photonic integrated circuits may boost overall system performance and data handling capabilities, as well as unlock spectroscopic sensing applications, enabled by the optoelectronic performance of 2DMs. Computing-In-Memory or memristors will enable future 

4 

neuromorphic computing applications and 2DMs may be ideally suited to be integrated with silicon CMOS (inset b). 2D quantum technologies are the least mature even at the laboratory level, but will benefit from all expected achievements as 2DMs enter semiconductor processing lines. 2D materials hold great promise to become the X-Factor for CMOS. This may be described as the era of heterogenous scaling, where new and additional materials provide unprecedented performance in three-dimensional chip stacks. Note that the Y-axis had a unit of "log2(#transistors/$)“ during the classic “Moore’s law” period. This has to be replaced in the era of heterogeneous scaling, and we suggest labeling it „Performance (a.u.)”, because the increase in performance will become application specific. It will be determined by (combined) factors like power consumption and efficiency, capability to perform pattern recognition, sensor fusion etc., which results in somewhat arbitrary units due to the diverse functionalities and underlying technologies. (Insets: BEOL Introduction of Cu: Reproduced with permission from the AAAS, reference<sup>10</sup> ; High-k/Metal Gate: © 2007 IEEE. Reprinted, with permission, from Mistry, K. _et al._ A 45nm Logic Technology with High-k + Metal Gate Transistors, Strained Silicon, 9 Cu Interconnect Layers, 193nm Dry Patterning, and 100% Pb-free Packaging. in _2007 IEEE International Electron Devices Meeting_ 247–250 (2007)<sup>11</sup> ; FinFET / New architectures: Republished with permission of IEEE, from Jan, C.-H. et al. A 22nm SoC platform technology featuring 3-D tri-gate and high-k/metal gate, optimized for ultra low power, high performance and high density SoC applications. in 2012 International Electron Devices Meeting 3.1.1-3.1.4, 2012<sup>12</sup> ; permission conveyed through Copyright Clearance Center, Inc.; 2D Materials: source: reference<sup>14</sup> ). 

5 

## **More Moore** 

In general, gains in advanced semiconductor technology nodes are enabled through increased complexity of the integration architectures as well as holistic systemtechnology co-optimization. On the device level, leading semiconductor manufacturers are turning from FinFETs to stacked nanosheet FET architectures for the most advanced nodes of CMOS technology.<sup>15</sup> These nanosheet devices are currently still based on Si channels. Different flavors of such nanosheet architectures are in evaluation for future technology nodes, e.g. a so-called fork sheet design that allows tighter n-to-p spacing,<sup>16</sup> or integration of p and n-type nanosheets on top of each other.<sup>17</sup> Further scaling of the channel length requires shrinking the channel thickness by a similar factor to guarantee sufficient electrostatic control to suppress short channel effects. Trimming down the Si sheet thickness to the required values increases the charge scattering at the interfaces and results in a dramatic drop of the carrier mobility in the channel,<sup>18</sup> which ruins device performance. 2D semiconductors would be the ultimate version of nanosheets, because they are self-passivated in the 3<sup>rd</sup> dimension and charge carrier mobility is not strongly affected from surface scattering. Therefore, mobility remains high even at the atomic thickness limit. This unique behavior in principle enables real scaling for a several technology nodes and is a strong incentive for the semiconductor industry to finally consider replacing silicon as the transistor channel material for future advanced nodes.<sup>13,14,19</sup> This takes us back to the fundamental technical and scientific challenges which are linked to 2D integration. Here, identifying a suitable gate oxide stack and finding low ohmic contact schemes are particularly important. The former is essential to preserve the 2D material properties and 

6 

to provide sufficient electrostatic control while limiting gate leakage currents.<sup>5</sup> 2D hexagonal boron (hBN) nitride has been widely applied to demonstrate high performance devices based on 2DMs, but its band gap and band offsets dictate that sufficient electrostatic control can only be achieved with one or two monolayers. This additional boundary condition leads to intolerably high gate leakage currents and other solutions will have to be found.<sup>20</sup> Low ohmic contacts are required to maintain the benefits of the channel material in integrated circuits, because high resistance contacts can dominate and severely limit the integrated device performance.<sup>21</sup> Recently, substantially improved electrical contact resistance to MoS2 has been reported by using semi-metallic Bismuth, which strongly suppresses metal induced gap states and the spontaneous formation of degenerate states in the MoS2.<sup>22</sup> Nevertheless, more breakthroughs like this are needed to uncover and fully exploit the potential of monolayer transistors in CMOS circuits, to revive transistor downscaling and continue Moore’s law. 

## **More Than Moore** 

Applications in this category are likely first to enter the market, because they are manyfold, yet often very specific, so that they may tolerate defects and larger device variations. 

2DMs are well-suited for gas, chemical and biosensing, because of their inherently high surface to volume ratio and versatile functionalization.<sup>23</sup> Thus, any charged particle or molecule in the vicinity of certain 2D layered materials can modify their conductivity. However, ideal 2DMs are chemically inert, which means that chemically active defect sites strongly enhance the reactivity of 2D based sensors. Precise defect engineering is 

7 

therefore essential for controlling sensitivity. In addition, sensor selectivity is essential. It may be achieved through surface functionalization or via arrays made from different sensors to mimic complex biological systems like the nose. Here, the portfolio of 2DMs with diverse sensor “fingerprints” may be utilized in conjunction with machine learning algorithms for sensor read-out. 

Micro- and nanoelectromechanical systems (MEMS/NEMS) typically rely on mechanically movable parts on the chip. 2DMs exhibit exceptional mechanical properties that produce ultra-thin membranes, which translates directly to extremely high sensitivities in piezoresistive and opto-mechanical read out schemes, providing efficient signal transduction in NEMS. 2D membrane-based NEMS applications include pressure sensors, accelerometers, oscillators, resonant mass sensors, gas sensors, Hall effect sensors, and bolometers.<sup>24</sup> 

2DMs possess a range of advantages over existing technologies for optoelectronic and photonic applications,<sup>25</sup> in particular outside of the spectral range that can be addressed with silicon. But even there, the direct band gaps of many semiconducting 2DMs provide advantages over silicon when it comes to light emission.<sup>26</sup> Semi-metallic and small band gap materials like graphene, platinum diselenide or black phosphorous open up the infrared (IR) regime, where they compete with often costly III-V semiconductor technologies. Although the 2D nature translates into low absolute absorption in the vertical direction, the combination with IR-sensitive absorption layers leads to high detector responsivity.<sup>27</sup> 

8 

## **Photonic Integrated Circuits** 

Photonic integrated circuits are considered as ultimate performance boosters for data transmission on and across computer chips.<sup>28</sup> Connecting them to silicon electronics through optoelectronic converters at extremely high data rates is a key enabling technology. 2DMs, and in particular graphene, can be transferred onto photonic waveguides and provide wide-band photodetection and modulation.<sup>25,29,30</sup> By removing the need for epitaxy, 2D-based photonics thus allows integrating active device components with Si photonics, but also with passive amorphous waveguide materials, like silicon nitride. This opens the door for facile integration of complex photonics applications on top of CMOS. In fact, some 2DMs like platinum diselenide can also be directly and conformally grown at temperatures below 400°C,<sup>31</sup> which is a clear advantage in the quest to co-integrate photonic integrated circuits with silicon CMOS technology.<sup>32</sup> With the potential for integrated 2D light sources,<sup>26</sup> 2DMs could ultimately enable the convergence of electronics and photonics and bridge the spectrum across the THz gap. 

## **Neuromorphic Computing** 

Neuromorphic computing aims to provide brain-inspired computing devices and architectures to realize energy efficient hardware for artificial intelligence applications.<sup>33</sup> On the device level, requirements for neuromorphic computing include merging memory with logic to enable Computing-In-Memory and memristive device characteristics that mimic synapses and neurons. The former can already be realized with conventional memory technologies while the latter translates to threshold switches, and non-volatile 

9 

memristors with a wide range of programmable resistance states.<sup>34,35</sup> Though relatively nascent, 2D memristors have shown promising performance including switching energies on the order of zeta-joules, sub nano-second switching times, dozens of programmable states, and prototype artificial neural networks at the wafer-scale.<sup>36</sup> This may enable applications in sensor systems and edge computing, for example by preprocessing of sensor data or on-chip sensor fusion.<sup>37</sup> In addition to neuromorphic computing, 2D memristive devices have been shown to provide a wide range of noncomputing functions including physically unclonable functions for security systems, and radio-frequency switching for communication systems.<sup>38</sup> 

From a scientific view, the phenomena of resistive switching in 2D devices have been attributed to ionic transport,<sup>39,40</sup> defect/filament formation<sup>41</sup> or phase change effects.<sup>42</sup> Notwithstanding these fundamental aspects, 2D memristive switching remains a topic enjoying increasing discussion and research. At the device level, a fundamental challenge is improving the number of times the resistance can be switched, so-called endurance, which requires further studies into the aging effect of the underlying mechanism(s). Similarly, improving material uniformity will be essential in order to 

realize massively connected device arrays that can mimic the hyper-connectivity and efficiency of the brain. Hearteningly, over a dozen 2DMs have exhibited memristive effect with this collection likely to grow in the coming years. Therefore, computational methods will be increasingly needed to guide experimental studies and optimize memristive devices for maximum performance. 

10 

## **Quantum Technologies** 

2D materials and related van-der-Waals heterostructures offer also a variety of properties that make them highly tunable quantum materials interesting for spintronics and future quantum technologies.<sup>43</sup> Two-dimensional material systems not only have the ability to enable artificial states of quantum matter, but fulfil a number of promises for solid-state quantum computing, to serve as key components in quantum communication circuits or allow interesting quantum sensing schemes. Indeed, 2DMs are a promising solid-state platform for quantum-dot qubits, as recognized quite early,<sup>44</sup> for topological quantum computing elements, as well as coherent sources of singlephoton emitters. 

Quantum computing based on semiconductor quantum dots (DQs) uses individual spin states of trapped electrons. It relies, for example, on long spin coherence times with the host material. This makes graphene a very interesting materials for spin qubits, thanks to its weak spin-orbit coupling (carbon atoms are very light) and weak hyperfine coupling (Carbon 12 is nuclear spin free). With the recent progress in confining singleelectrons in gate-controlled QDs in gapped bilayer graphene,<sup>45,46</sup> first spin-qubits are now around the corner. The possibility to make spin qubits in 2DMs will also allow evaluating the additional valley degree of freedom as possible qubit states; interesting proposals of valley- and spin-valley qubits exist. In addition, stationary qubits in 2DMs may afford coupling to photonic qubits realized by single-photon emitters (SPEs), for example in nearby wide band-gap hexagonal boron nitride or semiconducting transition metal dichalcogenides, such as WSe2.<sup>47</sup> In these 2DMs, SPEs have been demonstrated in recent years and this opens the door to distributed quantum networks, where 

11 

photonic qubits could act as interlinks that entangle distant stationary qubits, e.g., spinqubits. Such robust, bright and indistinguishable single-photon emitters are essential for creating photonic (flying) qubits for efficient quantum communication. 

2D heterostructures are, moreover, promising materials for topological quantum computing, where quantum states are better (i.e. topologically) protected against disorder, compared to standard quantum computing.<sup>48</sup> Combining, for example, a 

quantum anomalous Hall insulator or graphene tuned into the canted anti-ferromagnetic quantum Hall phase with s-wave superconductors is a promising platform for topological quantum computing. In short, these advances make 2DMs and their heterostructures in many ways an exciting and promising platform for future quantum technologies. 

## **Conclusions** 

2DMs provide exceptional performance benefits over existing technologies at the device level. They also carry the promise of easy integration with silicon CMOS technology. This makes them prime candidates for substantially expanding the functionality of silicon chips, also referred to as “CMOS + X”. We are confident that 2DMs will increasingly become such an X-factor in future integrated products. The bottleneck towards 2D material-based heterogeneous electronics is reaching the required manufacturing readiness levels, which may be different depending on the targeted application. 

12 

## **Acknowledgements** 

The authors acknowledge funding from the European Union’s Horizon 2020 research and innovation programme under grant agreements 881603 (Graphene Flagship), 952792 (2D-EPL), 101017186 (AEOLUS), 101016734 (MISEL), 971398 (ULTRAPHO), 101006963 (GreEnergy), 956813 (2Exciting), 863337 (WIPLASH), 825272 (ULISSES) and 829035 (QUEFORMAL) as well as the European Research Council (ERC) under grant agreements 820254 and 307311. We further acknowledge support from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany’s Excellence Strategy - Cluster of Excellence Matter and Light for Quantum Computing (ML4Q) EXC 2004/1 -390534769 and through the DFG grants STA 1146/111, STA 1146/12-1, LE 2440/7-1, LE 2440/8-1 and LE 2440/11-1. Furthermore, support 

by the Bundesministerium für Bildung und Forschung (BMBF, German Ministry of Education and Research) through the grants 03XP0210 (GIMMIK), 16ES1121 (NobleNEMS) and 16ME0399 (NEUROTEC II) is acknowledged, as is the Alexander 

von Humboldt-Foundation. Part of the work leading to this manuscript has been carried out in the Aachen Graphene & 2D Materials Center. 

## **Author contributions** 

MCL, DH, CH and CS co-wrote the manuscript and co-created the figure. 

## **Competing interests** 

There is no competing interest. 

## **Data availability statement** 

Data sharing not applicable. 

13 

## **References** 

1. Akinwande, D. _et al._ Graphene and two-dimensional materials for silicon technology. _Nature_ **573** , 507–518 (2019). 

2. Neumaier, D., Pindl, S. & Lemme, M. C. Integrating graphene into semiconductor fabrication lines. _Nature Materials_ **18** , 525 (2019). 

3. Lupina, G. _et al._ Residual Metallic Contamination of Transferred Chemical Vapor Deposited Graphene. _ACS Nano_ **9** , 4776–4785 (2015). 

4. Quellmalz, A. _et al._ Large-area integration of two-dimensional materials and their heterostructures by wafer bonding. _Nature Communications_ **12** , 917 (2021). 

5. Illarionov, Y. Yu. _et al._ Insulators for 2D nanoelectronics: the gap to bridge. _Nature Communications_ **11** , 3385 (2020). 

6. Passi, V. _et al._ Ultralow Specific Contact Resistivity in Metal–Graphene Junctions via Contact Engineering. _Advanced Materials Interfaces_ **6** , 1801285 (2019). 

7. Fuechsle, M. _et al._ A single-atom transistor. _Nature Nanotechnology_ **7** , 242–246 (2012). 

8. Graphene Flagship launches first European Experimental Pilot Line. https://www.mynewsdesk.com/graphene-flagship/pressreleases/graphene-flagshiplaunches-first-european-experimental-pilot-line-3040987. 

9. Baccarani, G., Wordeman, M. R. & Dennard, R. H. Generalized scaling theory and its application to a 1/4 micrometer MOSFET design. _IEEE Transactions on Electron Devices_ **31** , 452–462 (1984). 

10. Miller, R. D. In Search of Low-k Dielectrics. _Science_ **286** , 421–423 (1999). 

11. Mistry, K. _et al._ A 45nm Logic Technology with High-k+Metal Gate Transistors, Strained Silicon, 9 Cu Interconnect Layers, 193nm Dry Patterning, and 100% Pb-free Packaging. in _2007 IEEE International Electron Devices Meeting_ 247–250 (2007). doi:10.1109/IEDM.2007.4418914. 

12. Jan, C.-H. _et al._ A 22nm SoC platform technology featuring 3-D tri-gate and highk/metal gate, optimized for ultra low power, high performance and high density SoC applications. in _2012 International Electron Devices Meeting_ 3.1.1-3.1.4 (2012). doi:10.1109/IEDM.2012.6478969. 

13. Zhou, R. & Appenzeller, J. Three-Dimensional Integration of Multi-Channel MoS2 Devices for High Drive Current FETs. in _2018 76th Device Research Conference (DRC)_ 1–2 (2018). doi:10.1109/DRC.2018.8442137. 

14. Schram, T. _et al._ High yield and process uniformity for 300 mm integrated WS2 FETs. in _2021 Symposium on VLSI Technology_ 1–2 (2021). 

14 

15. Loubet, N. _et al._ Stacked nanosheet gate-all-around transistor to enable scaling beyond FinFET. in _2017 Symposium on VLSI Technology_ T230–T231 (2017). doi:10.23919/VLSIT.2017.7998183. 

16. Mertens, H. _et al._ Forksheet FETs for Advanced CMOS Scaling: ForksheetNanosheet Co-Integration and Dual Work Function Metal Gates at 17nm N-P Space. in _2021 Symposium on VLSI Technology_ 1–2 (2021). 

17. C.-Y. Huang et al. 3-D Self-Aligned Stacked NMOS-on-PMOS Nanoribbon Transistors for Continued Moore’s Law Scaling,. in _IEDM 2020_ . 

18. Schmidt, M. _et al._ Mobility extraction in SOI MOSFETs with sub 1 nm body thickness. _Solid-State Electron._ **53** , 1246–1251 (2009). 

19. Das, S. _et al._ Transistors based on two-dimensional materials for future integrated circuits. _Nat Electron_ **4** , 786–799 (2021). 

20. Knobloch, T. _et al._ The performance limits of hexagonal boron nitride as an insulator for scaled CMOS devices based on two-dimensional materials. _Nature Electronics_ **4** , 98–108 (2021). 

21. Bittle, E. G., Basham, J. I., Jackson, T. N., Jurchescu, O. D. & Gundlach, D. J. Mobility overestimation due to gated contacts in organic field-effect transistors. _Nat Commun_ **7** , 1–7 (2016). 

22. Shen, P.-C. _et al._ Ultralow contact resistance between semimetal and monolayer semiconductors. _Nature_ **593** , 211–217 (2021). 

23. Anichini, C. _et al._ Chemical sensing with 2D materials. _Chemical Society Reviews_ **47** , 4860–4908 (2018). 

24. Lemme, M. C. _et al._ Nanoelectromechanical Sensors Based on Suspended 2D Materials. _Research_ **2020** , 8748602 (2020). 

25. Romagnoli, M. _et al._ Graphene-based integrated photonics for next-generation datacom and telecom. _Nature Reviews Materials_ **3** , 392–414 (2018). 

26. Pospischil, A., Furchi, M. M. & Mueller, T. Solar-energy conversion and light emission in an atomic monolayer p-n diode. _Nat Nano_ **9** , 257–261 (2014). 

27. Konstantatos, G. _et al._ Hybrid graphene-quantum dot phototransistors with ultrahigh gain. _Nat Nano_ **7** , 363–368 (2012). 

28. Alexoudi, T. _et al._ Optics in Computing: From Photonic Network-on-Chip to Chipto-Chip Interconnects and Disintegrated Architectures. _J. Lightwave Technol., JLT_ **37** , 363–379 (2019). 

29. Liu, M. _et al._ A graphene-based broadband optical modulator. _Nature_ **474** , 64–67 (2011). 

15 

30. Schall, D. et al. 50 GBit/s Photodetectors Based on Wafer-Scale Graphene for Integrated Silicon Photonic Communication Systems. _ACS Photonics_ **1** , 9, 781–784 (2014). 

31. Prechtl, M. _et al._ Conformal and selective deposition of layered PtSe2: 2D goes 3D. _Advanced Functional Materials_ 2103936 (2021). 

32. Parhizkar, S. _et al._ Two-dimensional Platinum Diselenide Waveguide-Integrated Infrared Photodetectors. _ACS Photonics_ **9** , 859-867 (2022). 

33. Christensen, D. V. et al. 2022 Roadmap on Neuromorphic Computing and Engineering. _Neuromorph. Comput. Eng_ . https://doi.org/10.1088/2634-4386/ac4a83 (2022). in press. 

34. Liu, C. _et al._ Two-dimensional materials for next-generation computing technologies. _Nature Nanotechnology_ **15** , 545–557 (2020). 

35. Sangwan, V. K. & Hersam, M. C. Neuromorphic nanoelectronic materials. _Nat. Nanotechnol._ **15** , 517–528 (2020). 

36. Chen, S. _et al._ Wafer-scale integration of two-dimensional materials in highdensity memristive crossbar arrays for artificial neural networks. _Nature Electronics_ **3** , 638–645 (2020). 

37. Mennel, L. _et al._ Ultrafast machine vision with 2D material neural network image sensors. _Nature_ **579** , 62–66 (2020). 

38. Kim, M. _et al._ Analogue switches made from boron nitride monolayers for application in 5G and terahertz communication systems. _Nat Electron_ **3** , 479–485 (2020). 

39. Sangwan, V. K. _et al._ Gate-tunable memristive phenomena mediated by grain boundaries in single-layer MoS2. _Nature Nanotechnology_ **10** , 403–406 (2015). 

40. Belete, M. _et al._ Nonvolatile Resistive Switching in Nanocrystalline Molybdenum Disulfide with Ion-Based Plasticity. _Advanced Electronic Materials_ 1900892 (2020) doi:10.1002/aelm.201900892. 

41. Hus, S. M. _et al._ Observation of single-defect memristor in an MoS 2 atomic sheet. _Nature Nanotechnology_ 1–5 (2020) doi:10.1038/s41565-020-00789-w. 

42. Zhang, F. _et al._ Electric-field induced structural transition in vertical MoTe 2 - and Mo 1–x W x Te 2 -based resistive memories. _Nature Materials_ **18** , 55 (2019). 

43. Liu, X. & Hersam, M. C. 2D materials for quantum information science. _Nat Rev Mater_ **4** , 669–684 (2019). 

44. Trauzettel, B., Bulaev, D. V., Loss, D. & Burkard, G. Spin qubits in graphene quantum dots. _Nature Phys_ **3** , 192–196 (2007). 

16 

45. Eich, M. _et al._ Spin and Valley States in Gate-Defined Bilayer Graphene Quantum Dots. _Phys. Rev. X_ **8** , 031023 (2018). 

46. Banszerus, L. _et al._ Single-Electron Double Quantum Dots in Bilayer Graphene. _Nano Lett._ **20** , 2005–2011 (2020). 

47. He, Y.-M. _et al._ Single quantum emitters in monolayer semiconductors. _Nature Nanotech_ **10** , 497–502 (2015). 

48. Kennes, D. M. _et al._ Moiré heterostructures as a condensed-matter quantum simulator. _Nat. Phys._ **17** , 155–163 (2021). 

17 

