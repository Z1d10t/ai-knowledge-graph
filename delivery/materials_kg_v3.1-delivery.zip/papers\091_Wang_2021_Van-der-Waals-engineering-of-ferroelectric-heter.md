# Van der Waals engineering of ferroelectric heterostructures for long-retention memory

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 238 |
| 作者 | Xiao-Wei Wang, Chao Zhu, Ya Deng, Rui-Huan Duan, Jie-Qiong Chen, Qing-Sheng Zeng, Jia-Dong Zhou, Qun-Dong Fu et al. |
| DOI | 10.1038/s41467-021-21320-2 |
| 源文件 | 091_Wang_2021_Van-der-Waals-engineering-of-ferroelectric-heter.pdf |

---


## ARTICLE 

https://doi.org/10.1038/s41467-021-21320-2 

### **OPEN** 



# Van der Waals engineering of ferroelectric heterostructures for long-retention memory 

Xiaowei Wang 1, Chao Zhu 1, Ya Deng1, Ruihuan Duan1, Jieqiong Chen1, Qingsheng Zeng1, Jiadong Zhou 1, Qundong Fu<sup>1</sup> , Lu You 2, Song Liu3, James H. Edgar 3, Peng Yu4 & Zheng Liu 1,5,6✉ 

The limited memory retention for a ferroelectric field-effect transistor has prevented the commercialization of its nonvolatile memory potential using the commercially available ferroelectrics. Here, we show a long-retention ferroelectric transistor memory cell featuring a metal-ferroelectric-metal-insulator-semiconductor architecture built from all van der Waals single crystals. Our device exhibits 17 mV dec<sup>−1</sup> operation, a memory window larger than 3.8 V, and program/erase ratio greater than 10<sup>7</sup> . Thanks to the trap-free interfaces and the minimized depolarization effects via van der Waals engineering, more than 10<sup>4</sup> cycles endurance, a 10-year memory retention and sub-5 μs program/erase speed are achieved. A single pulse as short as 100 ns is enough for polarization reversal, and a 4-bit/cell operation of a van der Waals ferroelectric transistor is demonstrated under a 100 ns pulse train. These device characteristics suggest that van der Waals engineering is a promising direction to improve ferroelectronic memory performance and reliability for future applications. 

> 1 School of Materials Science and Engineering, Nanyang Technological University, Singapore, Singapore. 2 Jiangsu Key Laboratory of Thin Films, School of Physical Science and Technology, Soochow University, Suzhou, China.<sup>3</sup> Tim Taylor Department of Chemical Engineering, Durland Hall, Kansas State University, Manhattan, KS, USA.<sup>4</sup> School of Materials Science and Engineering, State Key Laboratory of Optoelectronic Materials and Technologies, Sun Yatsen University, Guangzhou, China.<sup>5</sup> CINTRA CNRS/NTU/THALES, UMI 3288, Research Techno Plaza, Singapore, Singapore.<sup>6</sup> Centre for Micro-/Nanoelectronics (NOVITAS), School of Electrical and Electronic Engineering, Nanyang Technological University, Singapore, Singapore.<sup>✉</sup> email: z.liu@ntu.edu.sg 

1 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 

erroelectric materials with switchable macroscopic polarization have been exploited in a wide range of technological Fapplications such as nonvolatile memory, logic, sensors, and actuators over the past few decades<sup>1–6</sup> . In particular, field-effect transistors with a ferroelectric gate dielectric (FeFETs) are recognized as an attractive architecture to the existing semiconductor memory technologies owing to their nondestructive and low voltage operation, small cell size, and nonvolatility<sup>1,2,7,8</sup> . However, the severe depolarization effects and carrier charge trapping drastically limit the memory retention time, and prevent the commercialization of nonvolatile memory potential of FeFET using the commercially available ferroelectrics<sup>9–11</sup> . Furthermore, attempts to synthesize ferroelectrics on semiconductors are impeded by ferroelectric-semiconductor interdiffusion and lattice mismatch<sup>12,13</sup> . 

The recent emerged two-dimensional (2D) van der Waals (vdW) ferroelectrics<sup>14–16</sup> , combined with other 2D components ranging from metals<sup>17</sup> , semiconductors<sup>18</sup> to insulators<sup>19</sup> , open the possibilities for achieving a long-retention FeFET memory via vdW engineering. One of the primary advantages of vdW materials is the absence of dangling bonds, which is desirable for engineering a trap-free interface to rule out memory performance degradation<sup>11,20</sup> . A single-crystal vdW ferroelectric layer also affords the possibility of a square ferroelectric hysteresis loop that helps to eliminate the depolarization field induced retention loss<sup>11,21</sup> . Moreover, the flexibility of the vdW stacking process facilitates the engineering a desired device structure without the interdiffusion and constraints of lattice parameters. 

In this work, a nonvolatile FeFET memory cell featuring a metalferroelectric-metal-insulator-semiconductor (MFMIS) structure is built from all vdW single crystals by integrating a ferroelectric CuInP2S6 (CIPS) layer onto the gate of a 2D FET, with MoS2 as the channel material, hexagonal-BN (h-BN) as the gate dielectric, and graphene as the gate contact. The vdW engineering enables the convenient integration of a single-crystal ferroelectric together with other 2D components while maintaining a clean interface. The introduction of a bipolar graphene layer into the gate stack allows the complete compensation of the ferroelectric polarization in CIPS, which is beneficial for eliminating the depolarization field. Enabled by these abilities, our vdW FeFET exhibits sub-60 mV dec<sup>−1</sup> switch and a counterclockwise hysteresis loop with a memory window larger than 3.8 V and a current ratio of over 10<sup>7</sup> . More than 10<sup>4</sup> cycles endurance, a 10-year retention, and sub-5 μs writing speed are achieved with vdW FeFET memory. Multilevel storage with 16 distinct current levels is also demonstrated in the present FeFET under a pulse train with a width of 100 ns. 

#### Results 

Figure 1a shows the schematic structure of vdW FeFET with a metal-ferroelectric-metal-insulator-semiconductor (MFMIS) structure that comprises a CIPS ferroelectric capacitor integrated onto a 2D FET, with a few-layer MoS2 as the channel material, h-BN (thickness, 4−9 nm) as the gate dielectric, and graphene (thickness, 2−13 nm) as gate contact. 5 nm Cr/80 nm Au is used as the topgate electrode and source/drain contacts. The polarization of the ferroelectric CIPS layer controls the surface potential of MoS2, and the source–drain current of the underlying 2D FET. Including a bipolar graphene layer in the present device structures are crucial for compensating for both downward and upward oriented polarization in CIPS<sup>22,23</sup> . Additionally, the graphene layer also serves as the internal gate for characterizing the baseline 2D FET. The general layout of a vdW FeFET is given in the false-color scanning electron microscopy (SEM) image of Fig. 1b. The MoS2/ h-BN/graphene/CIPS vdW heterostructure was created with freshly 

exfoliated flakes, via the dry transfer technique, before the lithography process to maintain the clear vdW interfaces<sup>24</sup> . Details on material preparation and device fabrication are provided in Methods and Supplementary Fig. 1. 

The ferroelectricity of CIPS was characterized by vertical piezoresponse force microscopy (PFM) under dual AC resonance tracking (DART) mode and polarization versus electric field (P −E) hysteresis loop measurements. Figure 1c, d present the phase and amplitude images of local piezoresponse on a vdW heterostructure, created with a three-layer MoS2, 9 nm h-BN, 2 nm graphene, and 85 nm CIPS (see Supplementary Fig. 2 for the topographic image and Supplementary Fig. 3 for the determination of the layer number of MoS2). The bright and dark regions observed on CIPS represent the out-of-plane ferroelectric domains with upward and downward polarization, respectively. Note that the domain size of CIPS on graphene is larger than that on the h-BN or SiO2 substrate (see Supplementary Fig. 4 for statistics on domain size) due to the sufficient screening capability of graphene, which suggests the great potential of this vdW heterostructure for memory applications. The off-field PFM measurements were then carried out to acquire appropriate piezoresponse hysteresis loop by reducing the electrostatic effect. As presented in Fig. 1e, f, a standard butterfly amplitude loop with a 180° phase flip at the coercive voltages confirms the good ferroelectric switching nature of CIPS (see Supplementary Fig. 5 for the raw data). Polarization switching tests (Supplementary Fig. 6) were also conducted to demonstrate the out-of-plane ferroelectricity in CIPS. In the P−E measurements, voltage of a triangular waveform was applied to a CIPS parallel-plate capacitor (see Supplementary Fig. 7 for the optical image of a typical CIPS capacitor) to obtain the polarization hysteresis loops. As shown in Fig. 1g, the P−E characteristic of CIPS shows a nearly square hysteresis loop with a large (~300 kV/cm) coercive field and moderate remnant polarization (~4 μC/cm<sup>2</sup> ) compared to ferroelectric strontium bismuth tantalite (SBT) and lead zirconium titanate (PZT)<sup>25,26</sup> . 

The room temperature electrical performance of a vdW FeFET with a three-layer MoS2 and 87 nm CIPS is presented in Fig. 2 (see Supplementary Fig. 8 for more vdW FeFETs with different thickness of CIPS). Figure 2a shows the schematic of the measurement setup used to characterize the underlying 2D FET through the internal gate with the top gate floating. The Ids − Vint characteristics of 2D FET at various gate voltage ranges in Fig. 2b represent zero-hysteresis with subthreshold swing (SS) approaching the thermionic limit (Fig. 2c), indicating the absence of charge traps at the vdW interfaces<sup>27</sup> . The transfer curves (Ids– Vtg) of the FeFET, measured using the top gate with internal gate floating (as illustrated in Fig. 2d) at different sweeping ranges of top-gate voltage, are given in Fig. 2e. The FeFET exhibits a typical n-type behavior with an anticlockwise hysteresis loop arising from ferroelectric polarization switching. By increasing the Vtg sweeping range, the hysteresis loop is increased to achieve a large memory window (MW) with two different stable states, namely a program state induced by remnant downward polarization, and an erase state induced by upward polarization. An MW of 3.8 V, much larger than the one of the FeFET featuring an MFS structure (Supplementary Fig. 9), with an over 10<sup>7</sup> program/erase (P/ E) current ratio is achieved for the vdW FeFET at the sweeping range of 4 V. Moreover, due to the negative capacitance effect in CIPS, the FeFET exhibits sub-60 mV dec<sup>−1</sup> switch for both the forward and reverse sweep, with an average SS less than the Boltzmann’s limit for over 6 decades of drain current and minimum SS of 28 mV dec<sup>−1</sup> , as shown in Fig. 2c. The sub-60 mV dec<sup>−1</sup> SS is beneficial for stabilizing P/E ratio and MW due to low off-state leakage<sup>28</sup> . The lowest SS demonstrated in a vdW FeFET is 17 mV dec<sup>−1</sup> (Supplementary Fig. 10). Compared with 

2 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 



Fig. 1 All-vdW FeFET. a Schematic diagram of an MoS2/h-BN/graphene/CIPS vdW FeFET. A ferroelectric CIPS capacitor is integrated onto the gate of the 2D FET, with MoS2 as the channel material, h-BN as the gate dielectric and graphene as the gate contact, to realize the vdW FeFET with an MFMIS structure. b False-color SEM image of a typical vdW FeFET. Scale bar, 2 μm. c, d PFM amplitude c and phase d image of an MoS2/h-BN/graphene/CIPS vdW heterostructure. MoS2, graphene, and CIPS are indicated by the blue, green, and red dashed lines, respectively. Scale bar, 2 μm. e, f The off-field PFM amplitude e and phase f hysteresis loops during the switching process for the CIPS flake. g The P−E hysteresis loops of a 200-nm-thick CIPS parallel-plate capacitor at 1 kHz. 

an MoS2 based FeFET with an MFS or MFIS structure<sup>22,29</sup> , the improved SS in the vdW FeFET with an MFMIS structure is attributed to the sufficient compensating ability of graphene for downward and upward polarization of CIPS. The output curves (Ids − Vds) for both the forward and reverse Vtg step direction of another vdW FeFET with a coercive voltage of ~1.2 V (see Supplementary Fig. 11 for the transfer curves) are presented in Fig. 2f. After poling CIPS up (down), the drain current remains at a low (high) level and changes slightly with an increase (decrease) of Vtg as long as Vtg does not exceed the positive (negative) coercive voltage. Owing to negative drain-induced-barrier-lowering effect in the vdW FeFET, negative differential resistance is also observed in Fig. 2f for the reverse Vtg step. 

To evaluate the reliability of vdW FeFET for nonvolatile memory applications, we examined the endurance and time retention characteristics in a device with a four-layer MoS2 and 86 nm CIPS. A similar counterclockwise hysteresis loop with an MW of ~2.5 V is observed, as shown in Fig. 3a. Two distinct current states with a P/E ratio over 10<sup>7</sup> at Vtg = 0 V and Vds = 0.5 V are achieved after poling the polarization of CIPS up and down. The top-gate leakage current is below 0.3 pA in the entire gate voltage region, which is at least two orders lower than that of FeFETs with classical ferroelectrics<sup>1,29–31</sup> . The ultra-low subthreshold leakage current (~13 fA) and top-gate leakage current, as the two main contributions of leakage current in vdW FeFETs, 

promise long-retention and fatigue-free memory performance. We then investigated the dynamic characteristics of the same device by applying periodic voltage pulses with an amplitude of 3.5 V and a width of 1 s to the top-gate electrode. As shown in Fig. 3b, stable switching between the program and erase states with a dynamic P/E ratio greater than 10<sup>6</sup> is reached at Vds = 0.5 V and without any external gate voltage. Figure 3c shows the endurance performance of this vdW FeFET as a function of the number of alternating programs and erase cycles. The P/E switching is reproducible and well-defined with no obvious reduction of the dynamic P/E ratio for over 10<sup>4</sup> cycles, indicating our memory device is fatigue-free. The stability of the program and erase states, which is crucial for nonvolatile data storage, was further examined by monitoring their time-resolved characteristics. Room-temperature retention characteristics of the same device after a 1 s gate voltage pulse of ±5 V is depicted in Fig. 3d. Two distinct states are maintained with negligible P/E ratio degradation for over one hour. 

The programing and erasing speeds of vdW FeFET were further estimated by measuring the gate voltage pulse width dependence of the Ids binary state. Figure 4a, b, c illustrate the detailed program and erase characteristics of a vdW FeFET examined by varying pulse amplitude (2 to 10 V) and width (100 ns to 1 s). Ids–time curves at various top-gate voltage pulses are provided in Supplementary Note 1 and Supplementary 

3 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 



Fig. 2 Electric transport properties of vdW FeFETs. a Schematics of the measurement setup used to characterize the internal 2D FET. b Internal-gate Ids−Vint characteristics of 2D FET at various gate voltage ranges measured with Vds = 0.5 V and top gate floating. The device has a three-layer MoS2 channel and an 87-nm-thick CIPS layer. c Internal-gate SS−Ids characteristics (left) and top-gate SS−Ids characteristics (right) for the forward and reverse sweep. d Schematics of the measurement setup used to characterize the vdW FeFET. e Top-gate Ids−Vtg characteristics of the vdW FeFET at various gate voltage ranges measured with Vds = 0.5 V and internal gate floating. f The Ids−Vds curves for the forward and reverse Vtg step direction with the internal gate floating. 



Fig. 3 Cycle endurance and time retention characteristics. a Top-gate Ids−Vtg characteristics (red) and leakage current (black) of a vdW FeFET measured with Vds = 0.5 V and internal gate floating. The device has a four-layer MoS2 channel and an 86-nm-thick CIPS layer. b Dynamic characteristics of the same vdW FeFET in response to periodic top-gate voltage pulses with an amplitude of 3.5 V and width of 1 s. Ids was probed with Vds = 0.5 V after applying the gate pulse. Inset shows the periodic pulse mode applied to the top gate. c Endurance performance through more than 10<sup>4</sup> P/E cycles. d Retention properties of this device at the program and erase states. Ids was monitored at Vds = 0.5 V and Vtg = 0 V. 

4 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 



Fig. 4 Programing/erasing speed measurements. a, b, c Program a and erase b state current and the P/E current ratio c of a vdW FeFET as a function of Vtg pulse width for various pulse amplitudes. Ids was probed at Vds = 0.5 V after applying each pulse. The reference erase (Ref. Erase) and program (Ref. Program) currents were collected after each reset operation but before the writing operation. The device has a six-layer MoS2 channel and a 36-nm-thick CIPS layer. d Dynamic characteristic of the same device in response to periodic Vtg pulses with the amplitude of 10 V and width of 13 μs. Ids was probed at Vds = 0.5 V. e Ids as a function of the program (red dot) and erase (blue dot) pulse amplitude. The pulse width was fixed at 13 μs. f Ids–time curve of the same vdW FeFET under a 10 V/100 ns pulse train. Dots and bars in a, b, c, and e are the mean and standard deviation of Ids recorded in 20 s after applying each pulse, respectively. 

Fig. 12–18. Before each program or erase pulse, vdW FeFET was set into the erased or programed state through a reset pulse. As shown in Fig. 4a, when the FeFET is switched from the erase to program state with a 2 V gate voltage pulse, Ids increases gradually at first, and then rapidly with increasing pulse width and finally saturates at around 80 ms. Conversely, Ids decreases with increasing erase pulse width when the vdW FeFET is switched from the program to erase state, as shown in Fig. 4b. Stable switching between the program and erase states with a P/E ratio of more than 10<sup>6</sup> is achieved at a 2 V/300 ms gate voltage pulse, as presented in Fig. 4c. No polarization reversal is observed for a 2 V voltage pulse when the pulse width decreases to 1 ms. Writing speed is sensitively dependent on the applied gate voltage amplitude and much shorter time is taken for polarization reversal when the amplitude of Vtg approaches 10 V. Switching to the program or erase states is completed with a pulse amplitude of 10 V and width of 8 μs or 13 μs, respectively, as shown in Fig. 4a, b. Figure 4d depicts the reproducible P/E characteristics of the same device under an alternating program and erase pulses of ±10 V/13 μs. Note that this vdW FeFET still has a P/E current ratio of more than 2 orders at a writing speed of 5 μs, as shown in Fig. 4c. 

The writing voltage was also estimated by measuring the pulse amplitude dependence of Ids. The program and erase state current as a function of the amplitude of applied Vtg pulse, with the width fixed, are plotted in Fig. 4e. Ids gradually increases with the program pulse amplitude and saturates approximately at 400 nA when the pulse amplitude is greater than 8.5 V. While the erase operation does not saturate before the device is set into an erased state at Vtg = −10 V. The asymmetric switching characteristics, including the relatively large pulse width and amplitude for erasing compared to programing, are attributed to the partially divided gate voltage by the MoS2 channel when a device is switched to the erase state<sup>32</sup> . That varying the program pulse 

width or amplitude induces various Ids offers the possibility of multilevel storage in a vdW FeFET. Figure 4f shows the multilevel Ids under 15 gate voltage pulses with an amplitude of 10 V and a width of 100 ns. The stepwise program state is clearly distinct with increasing pulse numbers and 16 levels, corresponding to 4- bit, in 6 orders of drain current with clear gaps. Polarization switching with the current ratio larger than 10<sup>6</sup> by a single pulse of 100 ns was also observed in a vdW FeFET (Supplementary Fig. 19). Considering the RC delay of the measurement setup, the intrinsic polarization response is expected to be faster than 100 ns. The fast ionic ordering in CIPS simultaneously enhances writing speed and reduces writing voltage in a vdW FeFET. By contrast, it is impossible to decrease the writing speed below several μs with a voltage as low as 10 V in a poly(vinylidene difluoride-trifluoroethylene) (P(VDF-TrFE)) based FeFET<sup>31,33,34</sup> . The operating speed of a vdW FeFET can be further improved by reducing the channel length to accelerate domain wall motion<sup>32</sup> . 

The memory characteristics of a vdW FeFET were then comprehensively investigated by varying the thickness of the MoS2 layer. As shown in Fig. 5a, increasing the thickness of MoS2 enhances the conductance and P/E ratio. However, the threshold voltage (Vth) of the FeFET is reduced due to the increased work function for a thicker MoS2. Further reducing the Vth shifts MW completely to the negative Vtg region and deteriorates the memory performance. To achieve a sufficient P/E ratio and long retention time, MoS2 with a layer number less than 10 was selected as the FeFET channel in this work. The retention properties of FeFETs with bilayer and five-layer MoS2 are given in Fig. 5b, c, respectively. The current ratio of P/E retention is above 10<sup>6</sup> after more than 3 h for the bilayer MoS2 FeFET and 4 × 10<sup>3</sup> after more than 10 h for the five-layer MoS2 FeFET. As indicated by the dashed gray lines in Fig. 5b, c, the program and erase states can be clearly distinguished up to an extrapolation of 10 years 

5 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 



Fig. 5 Analysis of memory retention performance of vdW FeFET. a Top-gate transfer characteristics of vdW FeFETs with different thickness of MoS2. b, c Program and erase state retention properties of the vdW FeFET with bilayer b and five-layer c MoS2 after voltage pulses of ± 3 V/1 s. Ids was monitored at Vds = 0.5 V and Vtg = 0 V. Dashed red and blue lines are the fitting using the exponential decay function. The thickness of CIPS flake is 39 nm (b) and 66 nm (c). d Schematic band diagram and charge distribution of a vdW FeFET during retention time of the program state. e Calculated retention time vs. Ed/Ec ratio and Ntrap for vdW FeFET, P(VDF-TrFE), PZT, SBT, and hafnium oxide based FeFETs. Error bars indicate the range of variation for Ed/Ec and Ntrap. f Load-line analysis of layer-dependent retention performance of vdW FeFET. The solid lines are hysteresis loops of MFM capacitor at different statuses. The dashed color lines are load line curves of underlying 2D FET with different thickness of MoS2 under the same magnitude of Vtg. 

retention for both devices, demonstrating the great potential of vdW FeFETs for nonvolatile memory applications. 

#### Discussion 

Two major mechanisms have been proposed to account for the retention loss in FeFET:<sup>11,20,35</sup> 1) a depolarization field arises from incomplete charge compensation, which induces the fast retention loss at the early stage of time evolution, and 2) carrier charge trapping, which is responsible for the retention loss in the longer time regime. The rate of early-stage retention loss is determined by the ratio of the depolarization field (Ed) to coercive field (Ec) of FeFET<sup>21</sup> , where Ed = P[εCIPS (CIS/CCIPS + 1)]<sup>−1</sup> (Supplementary Note 2 and Supplementary Fig. 20) and P, εCIPS, and CCIPS are the ferroelectric polarization, dielectric constant, and capacitance of CIPS, and CIS is the series combination of the capacitance of h-BN and MoS2 channel. The retention loss induced by charge trapping is proportional to the trap density (Ntrap)<sup>35</sup> . From these discussions, vdW FeFET affords the full advantages from material to structure in preventing retention loss induced by both mechanisms. The nearly squared P−E loop of CIPS with a large coercive field and moderate remnant polarization leads to a weak depolarization effect. Note that the remnant polarization of CIPS (in the range of 2.5−4.0 μC/cm<sup>2</sup> )<sup>15,36,37</sup> matches well with the charges required for the underlying 2D FET, the maximum value of which is calculated to be 3.99 μC/ cm<sup>2</sup> . This enables a vdW FeFET operating with a major ferroelectric hysteresis loop and makes it invulnerable to the internal depolarization field<sup>38</sup> . As illustrated by the band diagrams of Fig. 5d, the employment of MFMIS structure moves compensating charges close to the surface of the ferroelectric, leaving an eliminated residual depolarization field. Gate leakage followed by trapping can also be suppressed through this vdW MFMIS structure due to the high 

barrier of h-BN and ideal defect-free surfaces. Figure 5e illustrates the comparison of calculated retention performance for vdW FeFET, PZT, SBT, P(VDF-TrFE), and hafnium oxide based FeFETs, where one can see vdW FeFET exhibits much lower Ed/Ec and Ntrap (as low as 5.2 × 10<sup>9</sup> cm<sup>−2</sup> )<sup>39,40</sup> compared with the other FeFETs. Therefore, vdW FeFET is much more likely to achieve a memory retention time of more than 10 years. The details for the estimation of retention performance of FeFETs are provided in Supplementary Note 3 and Supplementary Table 1. The asymmetric retention property between the program and erase states in Fig. 5b, c is ascribed to the difference in operating point. As schemed in Fig. 5f, the operating point for a FeFET, with a thinner (thicker) MoS2 at the programing (erasing) phase, sets up on the minor hysteresis loop, making the program (erase) state relatively vulnerable to the depolarization field. While the major loop is utilized for FeFET with a thinner (thicker) MoS2 during erasing (programing). This is also supported by the observed symmetric retention characteristic of the vdW FeFET with a four-layer MoS2 (shown in Fig. 3), where the MW is located with centering around Vtg = 0 V and the major loop is employed under the same magnitude of gate voltage for both programing and erasing operations. The finally saturated current in Fig. 5b, c indicate much less trapping-related retention loss, which benefits from the trap-free vdW interfaces. 

Table 1 summarizes the main features of the vdW FeFET benchmarked against the reported FeFET memory devices that employ P(VDF-TrFE), PZT and ferroelectric hafnium oxide as the gate dielectric. Among these devices, the vdW FeFET exhibits comparable memory performance with the hafnium oxide based FeFETs and better performance in operation speed than the P (VDF-TrFE) based FeFETs. 

In summary, nonvolatile memory FeFETs have been demonstrated with the MFMIS structure entirely built from all vdW 

6 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 

Table 1 Comparison of this work and previous works that employed ferroelectric P(VDF-TrFE), PZT and hafnium oxide as the gate dielectric of FeFET. 

|Ferroelectric|Channel|P/E ratio|P/E speed|Endurance|Retention|
|---|---|---|---|---|---|
|P(VDF-TrFE)<sup>31</sup>|MoSe2|> 10<sup>5</sup>|50μs/2 ms|10<sup>4</sup>|> 2 × 10<sup>3 </sup>s|
|P(VDF-TrFE)<sup>33</sup>|MEH-PPV|> 10<sup>4</sup>|<br>500μs/50μs|10<sup>3</sup>|2 × 10<sup>5 </sup>s|
|PZT<sup>41</sup>|IGZO|10<sup>6</sup>|3 s|–|10<sup>3 </sup>s|
|PZT<sup>42</sup>|ZnO|10<sup>5</sup>|150 ms|–|10 years|
|Si:HfO2<sup>43</sup>|Si|≈10<sup>3</sup>|10μs|2 × 10<sup>4</sup>|1 h|
|Si:HfO2<sup>44</sup>|Si|> 100|1–10μs|10<sup>5</sup>|72 h|
|HZO<sup>45</sup>|Si|10<sup>6</sup>|100μs|10<sup>7</sup>|10 years|
|HZO<sup>46</sup>|Si|10<sup>4</sup>|0.5μs|10<sup>6</sup>|10 years|
|CIPS (this work)|MoS2|> 10<sup>7</sup>|5μs|> 10<sup>4</sup>|10 years|



material components. The vdW FeFET features sub-20 mV dec<sup>−1</sup> operation, a MW larger than 3.8 V, and a current ratio greater than 10<sup>7</sup> at zero gate voltage. Deterioration is negligible even after more than 10<sup>4</sup> cycles of P/E endurance. A memory retention time of more than 10 h extrapolated to 10 years is achieved at room temperature. Sub-5 μs writing speed is demonstrated, and even a single pulse with a width of 100 ns pulses is enough for polarization reversal. Moreover, the gradual polarization switching behavior and high P/E current ratio of vdW FeFETs allow 16 distinct storage states per cell. We suggest that long memory retention, high endurance, and fast writing speed make the present device architecture a suitable candidate for nonvolatile memory applications. Also, our work reveals that vdW engineering is a practical solution to the ferroelectric memory retention problem. 

#### Methods 

Heterostructure preparation and device fabrication. Single crystals of CIPS and MoS2 were synthesized by solid-state reaction, and h-BN was produced by the atmospheric pressure metal flux method<sup>19</sup> . All the vdW flakes, including MoS2, h- BN, graphene, and CIPS, were achieved by mechanical exfoliation from bulk crystals. The heterostructures were produced with a dry transfer technique as reported. A few-layer MoS2 flake was first exfoliated onto a Si substrate covered with a 300-nm-thick SiO2 layer. BN, graphene, and CIPS flakes were exfoliated onto transparent poly-dimethylsiloxane (PDMS) films. A PDMS film with an h-BN flake was then stamped onto an MoS2 flake with the aid of a micromanipulator under an optical microscope. The h-BN flake was released and transferred onto the MoS2 flake after the PDMS film was lifted off. Next, graphene and the CIPS flake were transferred onto the h-BN with the same method. Finally, Cr/Au (5 nm/80 nm) electrodes were defined on the fabricated heterostructure using the standard e- beam lithography process followed by the metal thermal evaporation and lift-off process. To fabricate the parallel-plate capacitors, CIPS flakes were exfoliated onto a Si/SiO2 wafer covered with a Cr (5 nm)/Au (30 nm) metal layer and Cr (5 nm)/ Au (80 nm) was then deposited on the surface of CIPS flakes as the top electrodes. 

Characterizations. Atomic force microscopy (AFM, Asylum Research Cypher S) in a tapping mode was used to characterize the morphology of the heterostructures and devices. The layer number of the MoS2 was identified by AFM or microRaman spectroscopy (Witec) with a 532 nm laser. Out-of-plane PFM measurements were carried out on the Cypher S AFM in the DART mode. Off-field PFM hysteresis loops were measured by recording the piezoresponse amplitude and phase signals after the individual DC pulse was turned off. P−E hysteresis loop measurements were carried out using a Radiant ferroelectric tester with an applied voltage of a triangular waveform at 1 kHz. Static transport properties were measured with an Agilent B1500A Semiconductor Device Parameter Analyzer in a vacuum chamber of 10<sup>−2</sup> torr. The dynamic and writing speed tests were performed with the top-gate electrode connected to a RIGOL DG1032Z signal generator and source and drain connected to the Agilent B1500A. 

#### Data availability 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 

Received: 10 October 2020; Accepted: 21 January 2021; 



#### References 

1. Park, B. E., Ishiwara, H., Okuyama, M., Sakai, S. Yoon, S. M. Ferroelectric-Gate Field Effect Transistor Memories (Springer, 2016). 

2. Das, S. & Appenzeller, J. FETRAM. An organic ferroelectric material based novel random access memory cell. Nano Lett. 11, 4003–4007 (2011). 

3. Tian, B. B. et al. Tunnel electroresistance through organic ferroelectrics. Nat. Commun. 7, 11502 (2016). 

4. Salahuddin, S. & Datta, S. Use of negative capacitance to provide voltage amplification for low power nanoscale devices. Nano Lett. 8, 405–410 (2008). 

5. Smith, S. W. et al. Pyroelectric response in crystalline hafnium zirconium oxide (Hf1-xZrxO2) thin films. Appl. Phys. Lett. 110, 072901 (2017). 

6. Balakrishna, A. R., Huber, J. E. & Landis, C. M. Nano-actuator concepts based on ferroelectric switching. Smart Mater. Struct. 23, 085016 (2014). 

7. Miller, S. L. & McWhorter, P. J. Physics of the ferroelectric nonvolatile memory field effect transistor. J. Appl. Phys. 72, 5999–6010 (1992). 

8. Hoffman, J. et al. Ferroelectric field effect transistors for memory applications. Adv. Mater. 22, 2957–2961 (2010). 

9. Black, C. T., Farrell, C. & Licata, T. J. Suppression of ferroelectric polarization by an adjustable depolarization field. Appl. Phys. Lett. 71, 2041–2043 (1997). 

10. Takahashi, M. et al. Analysis and improvement of retention time of memorized state of metal-ferroelectric-insulator-semiconductor structure for ferroelectric gate FET memory. Jpn. J. Appl. Phys. 40, 2923–2927 (2001). 

11. Ma, T. P. & Jin-Ping, H. Why is nonvolatile ferroelectric memory field-effect transistor still elusive? IEEE Electron. Dev. Lett. 23, 386–388 (2002). 

12. Fan, Z., Chen, J. & Wang, J. Ferroelectric HfO2-based materials for nextgeneration ferroelectric memories. J. Adv. Dielect. 6, 1630003 (2016). 

13. Singamaneni, S. R., Prater, J. T. & Narayan, J. Multifunctional epitaxial systems on silicon substrates. Appl. Phys. Rev. 3, 031301 (2016). 

14. Cui, C., Xue, F., Hu, W.-J. & Li, L.-J. Two-dimensional materials with piezoelectric and ferroelectric functionalities. NPJ 2D Mater. Appl. 2, 18 (2018). 

15. Liu, F. et al. Room-temperature ferroelectricity in CuInP2S6 ultrathin flakes. Nat. Commun. 7, 12357 (2016). 

16. Wang, X. et al. Van der Waals negative capacitance transistors. Nat. Commun. 10, 3037 (2019). 

17. Novoselov, K. S. et al. Electric field effect in atomically thin carbon films. Science 306, 666–669 (2004). 

18. Zhou, J. et al. A library of atomically thin metal chalcogenides. Nature 556, 355–359 (2018). 

19. Liu, S. et al. Single crystal growth of millimeter-sized monoisotopic hexagonal boron nitride. Chem. Mater. 30, 6222–6225 (2018). 

20. Ma, T. P. & Gong, N. Retention and endurance of FeFET memory cells. 2019 IEEE 11th International Memory Workshop (IMW). 1–4 (2019). 

21. Gong, N. & Ma, T. Why is FE-HfO2 more suitable than PZT or SBT for scaled nonvolatile 1-T memory cell? A retention perspective. IEEE Electron. Dev. Lett. 37, 1123–1126 (2016). 

22. Wang, X. et al. Two-dimensional negative capacitance transistor with polyvinylidene fluoride-based ferroelectric polymer gating. NPJ 2D Mater. Appl. 1, 38 (2017). 

23. Chyasnavichyus, M. et al. Size-effect in layered ferrielectric CuInP2S6. Appl. Phys. Lett. 109, 172901 (2016). 

24. Castellanos-Gomez, A. et al. Deterministic transfer of two-dimensional materials by all-dry viscoelastic stamping. 2D Mater. 1, 011002 (2014). 

25. Tanaka, H., Kaneko, Y. & Kato, Y. A ferroelectric gate field effect transistor with a ZnO/Pb(Zr,Ti)O3 heterostructure formed on a silicon substrate. Jpn. J. Appl. Phys. 47, 7527–7532 (2008). 

26. Yu, B. G., Lee, W. J., Cho, C. R., Shin, C. H. & Kim, B. W. The effect of annealing temperature on electrical properties of SrBi2Ta2O9/insulators/Si (MFIS) structure for NDRO-type FRAM devices. Cryst. Res. Technol. 34, 1197–1204 (1999). 

7 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

<u>ARTICLE</u> 

NATURE COMMUNICATIONS <u>|</u> https://doi.org/10.1038/s41467-021-21320-2 

27. Choi, K. et al. Trap density probing on top-gate MoS2 nanosheet field-effect transistors by photo-excited charge collection spectroscopy. Nanoscale 7, 5617–5623 (2015). 

28. Chiu, Y. et al. Low power 1T DRAM/NVM versatile memory featuring steep sub-60-mV/decade operation, fast 20-ns speed, and robust 85 °C-extrapolated 10<sup>16</sup> endurance. Symp. VLSI Tech. 184–185 (2015). 

29. Shen, P.-C., Lin, C., Wang, H., Teo, K. H. & Kong, J. Ferroelectric memory field-effect transistors using CVD monolayer MoS2 as resistive switching channel. Appl. Phys. Lett. 116, 033501 (2020). 

30. Horiuchi, T., Takahashi, M., Ohhashi, K. & Sakai, S. Memory window widening of Pt/SrBi2Ta2O9/HfO2/Si ferroelectric-gate field-effect transistors by nitriding Si. Semicond. Sci. Technol. 24, 105026 (2009). 

31. Wang, X. et al. Ferroelectric FET for nonvolatile memory application with two-dimensional MoSe2 channels. 2D Mater. 4, 025036 (2017). 

32. Kaneko, Y. et al. Correlated motion dynamics of electron channels and domain walls in a ferroelectric-gate thin-film transistor consisting of a ZnO/ Pb(Zr,Ti)O3 stacked structure. J. Appl. Phys. 110, 084106 (2011). 

33. Naber, R. C. G. et al. High-performance solution-processed polymer ferroelectric field-effect transistors. Nat. Mater. 4, 243–248 (2005). 

34. Yoon, S. et al. Oxide semiconductor-based organic/inorganic hybrid dual-gate nonvolatile memory thin-film transistor. IEEE Trans. Electron. Dev. 58, 2135–2142 (2011). 

35. Pan, X. & Ma, T. P. Retention mechanism study of the ferroelectric field effect transistor. Appl. Phys. Lett. 99, 013505 (2011). 

36. Maisonneuve, V., Cajipe, V. B., Simon, A., Von Der Muhll, R. & Ravez, J. Ferrielectric ordering in lamellar CuInP2S6. Phys. Rev. B 56, 10860–10868 (1997). 

37. Si, M. et al. Room-temperature electrocaloric effect in layered ferroelectric CuInP2S6 for solid-state refrigeration. ACS Nano 13, 8760–8765 (2019). 

38. Migita, S., Ota, H. & Toriumi, A. Design points of ferroelectric field-effect transistors for memory and logic applications as investigated by metalferroelectric-metal-insulator-semiconductor gate stack structures using Hf0.5Zr0.5O2 films. Jpn. J. Appl. Phys. 58, SLLB06 (2019). 

39. Vu, Q. A. et al. Near-zero hysteresis and near-ideal subthreshold swing in h- BN encapsulated single-layer MoS2 field-effect transistors. 2D Mater. 5, 031001 (2018). 

#### Acknowledgements 

This research was supported by the Singapore Ministry of Education Academic Research Fund Tier 2 MOE2017-T2-2-136, Tier 3 MOE2018-T3-1-002, by the National Research Foundation Singapore programme NRF-CRP21-2018-0007 and NRF-CRP22-2019-0007. J.H.E. acknowledges support from the National Science Foundation (CMMI 1538127) and the II−VI Foundation. P.Y. acknowledges support from “100 Top Talents Program” of Sun Yat-sen University (No. 29000-18841216) and “Young-teacher Training Program” of Sun Yat-sen University (No. 29000-31610036). 

#### Author contributions 

Z.L. and X.W.W. conceived and designed the project. X.W.W. performed the AFM, PFM, SEM and Raman measurement, device fabrication, electrical properties measurement, and data analysis. J.Q.C. and L.Y. carried out the P-E measurement. S.L and J.H.E. grew the single-crystal h-BN. P.Y. performed the single-crystal CIPS growth. X.W.W. and Z.L. summarized the manuscript. C.Z., Y.D., R.H.D., Q.S.Z., J.D.Z., and Q.D.F. discussed and commented on the manuscript. 

#### Competing interests 

The authors declare no competing interests. 

#### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-021-21320-2. 

Correspondence and requests for materials should be addressed to Z.L. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

40. Cui, X. et al. Multi-terminal transport measurements of MoS2 using a van der Waals heterostructure device platform. Nat. Nanotech. 10, 534–540 (2015). 

41. Besleaga, C. et al. Ferroelectric field effect transistors based on PZT and IGZO. IEEE J. Electron Devices Soc. 7, 268–275 (2019). 

42. Kaneko, Y., Tanaka, H. & Kato, Y. NOR-type nonvolatile ferroelectric-gate memory cell using composite oxide technology. Jpn. J. Appl. Phys. 48, 09KA19 (2009). 

43. Dünkel, S. et al. A FeFET based super-low-power ultra-fast embedded NVM technology for 22nm FDSOI and beyond. IEDM 19.17.11–19.17.14 (2017). 

44. Trentzsch, M. et al. A 28nm HKMG super low power embedded NVM technology based on ferroelectric FETs. IEDM 11.5.1–11.5.4 (2016). 

45. Chatterjee, K. et al. Self-aligned, gate last, FDSOI, ferroelectric gate memory device with 5.5-nm Hf0.8Zr0.2O2, high endurance and breakdown recovery. IEEE Electron. Dev. Lett. 38, 1379–1382 (2017). 

46. Chen, K. et al. Non-volatile ferroelectric FETs using 5-nm Hf0.5Zr0.5O2 with high data retention and read endurance for 1T memory applications. IEEE Electron. Dev. Lett. 40, 399–402 (2019). 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2021, corrected publication 2021 

8 

NATURE COMMUNICATIONS | (2021) 12:1109 | https://doi.org/10.1038/s41467-021-21320-2 | www.nature.com/naturecommunications 

