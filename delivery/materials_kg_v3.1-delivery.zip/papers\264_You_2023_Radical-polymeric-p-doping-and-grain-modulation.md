# Radical polymeric p-doping and grain modulation for stable, efficient perovskite solar modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Science |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 196 |
| 作者 | Shuai You, Haipeng Zeng, Yuhang Liu, Bing Han, Min Li, Lin Li, Xin Zheng, Rui-Ting Guo et al. |
| DOI | 10.1126/science.add8786 |
| 源文件 | 050_You_2023_Radical-polymeric-p-doping-and-grain-modulation.pdf |

---
RESEARCH 



oping doping strategies for HTMs (33) in PSCs. Kong et al. doped spiro-MeOTAD by bubbling carbon dioxide through HTM precursor solution under ultraviolet (UV) light, thereby decreasing the doping time (34). Zhang et al. developed a method that avoids post-oxidation by using stable organic radicals and ionic salts as dopants (35). Although proven effective for small-area laboratory cells (36, 37), efficient HTM doping for larger-area PSMs has not been reported yet. 

#### SOLAR CELLS 



## Radical polymeric p-doping and grain modulation for stable, efficient perovskite solar modules 

Shuai You<sup>1,2</sup> †, Haipeng Zeng<sup>1</sup> †, Yuhang Liu<sup>2</sup> †, Bing Han<sup>3</sup> †, Min Li<sup>1</sup> , Lin Li<sup>1</sup> , Xin Zheng<sup>1</sup> , Rui Guo<sup>1</sup> , Long Luo<sup>1</sup> , Zhe Li<sup>4</sup> , Chi Zhang<sup>5</sup> , Ranran Liu<sup>1</sup> , Yang Zhao<sup>1</sup> , Shujing Zhang<sup>1</sup> , Qi Peng<sup>1</sup> , Ti Wang<sup>4</sup> , Qi Chen<sup>5</sup> , Felix T. Eickemeyer<sup>2</sup> , Brian Carlsen<sup>2</sup> , Shaik M. Zakeeruddin<sup>2</sup> , Liqiang Mai<sup>6,7</sup> , Yaoguang Rong<sup>1,6</sup> *, Michael Grätzel<sup>2</sup> *, Xiong Li<sup>1</sup> * 

We introduce two cooperative strategies to address these issues and realize efficient PSMs that achieve an unprecedented operational stability and, at the same time, can be manufactured on a large scale at a competitive production rate. We used a redox-active polymeric dopant consisting of a polyoxyethylene backbone endowed with 2,2,6,6-tetramethylpiperidin1-yl)oxyl, abbreviated as PPO-TEMPO (molecular structure shown in Fig. 1A), as an oxidant to afford p-doping of the HTLs through hole injection. This strategy not only shortened the doping time to a few seconds, which enables high production rates for PSMs, but also stabilized the device by suppressing the Li ion aggregation and diffusion into the adjacent layers. We also synthesized the fullerene derivative 4-(1′,5′- dihydro-1′-methyl-2′H-[5,6] fullerenoC60-Ih-[1,9-c]pyrrol-2′-yl) phenylphosphonic acid (CPPA; molecular structure shown in Fig. 1A) to mitigate GB defects of mixed-cation perovskites. CPPA features a conductive fullerene core functionalized by phosphonic acid anchoring groups that can interact with perovskites through hydrogen bonding, Pb coordination, and fullerene−halide radical interactions (26–29). By self-assembling at the GBs, CPPA enhanced the tolerance of the perovskite film against illumination, heat, and moisture and accelerated intergrain electronic charge carrier transport.Thecombinedactionofthetwoagents suppresses interfacial ion migration, contributing in a crucial manner to the high performance of our devices. These approaches allowed us to fabricate efficient PSCs and PSMs showing outstanding long-term operational stability. 

High-quality perovskite light harvesters and robust organic hole extraction layers are essential for achieving high-performing perovskite solar cells (PSCs). We introduce a phosphonic acid–functionalized fullerene derivative in mixed-cation perovskites as a grain boundary modulator to consolidate the crystal structure, which enhances the tolerance of the film against illumination, heat, and moisture. We also developed a redox-active radical polymer, poly(oxoammonium salt), that can effectively p-dope the hole-transporting material by hole injection and that also mitigates lithium ion diffusion. Power conversion efficiencies of 23.5% for 1-square-centimeter mixed–cation-anion PSCs and 21.4% for 17.1-square-centimeter minimodules were achieved. The PSCs retained 95.5% of their initial efficiencies after 3265 hours at maximum power point tracking under continuous 1-sun illumination at 70° ± 5°C. 

# O 

films. Commonly used approaches to scale up device size use “perovskite inks” that are compatible with processes such as slot-die coating, doctor-bladecoating,and vacuum flash–assisted solution processing (VASP) (16–19). Besides morphology control, it is also necessary to passivate defects, suppress unfavorable ion diffusion, and promote electronic charge carrier transport within the perovskite films (9, 20, 21). Functional molecular modulators were introduced into the grain boundaries (GBs) to heal defects and prevent ion migration (22–29). Our group has introduced phosphonic acid derivatives [−PO(OH)2] as more efficient passivation and cross-linking agents compared with carboxylic acids (26, 27). However, prior work generally made use of aliphatic backbones— which are electrochemically inert and do not interact with perovskite—to connect the functional groups. Hence, designing a grain modulator that can facilitate intergrain electron transfer, while strengthening their binding, is essential to fabricating high-quality large-area perovskite films for PSMs. 

rganic-inorganic hybrid perovskites have attracted extensive research interest for photovoltaic (PV) applications (1–3). Although the power conversion efficiency O (PCE) of organic-inorganic hybrid perovskite solar cells (PSCs) can now exceed 25% (4–7), such high efficiencies have been obtained only with small-area PSCs (aperture areas < 0.1 cm<sup>2</sup> ). Advances reported for small laboratory cells do not necessarily transfer to perovskite solar modules (PSMs), because issues such as film inhomogeneity, resistive losses from photocurrent collection, and instability resulting from ion diffusion escalate steeply with device area (8). Thus, larger-area devices based on current materials and fabrication techniques often have substantial performance losses (9–12), so it is essential to deposit compact perovskite light-harvesting layers and charge-transporting layers with low defect densities over larger areas. 

The antisolvent spin-coating process has been widely used to deposit perovskite thin films (13–15). However, this technique cannot be applied for casting large-area perovskite 

The fabrication of high-performance PSMs will also require both shortening the processing time and increasing the conductivity and stability of the hole-transporting layer (HTL). For an n-i-p device, typical hole-transporting materials (HTMs) such as 2,2′7,7′-tetrakis-(N,Ndi-p-methoxyphenyl-amine)-9,9′-spirobifluorene (spiro-MeOTAD) or poly[bis(4-phenyl)(2,4,6trimethylphenyl)amine] (PTAA) are deposited on top of the perovskite layer. Because of their low intrinsic conductivity, a p-type doping process with hygroscopic lithium salts, for example, lithium bis(trifluoromethylsulfonyl)imide (LiTFSI), is usually applied. The conventional doping process of spiro-MeOTAD typically takes hours and results in by-products (e.g., LixOy) that will seriously degrade cell performance (30–32). Efforts have been devoted to devel- 

#### PSM fabrication and performance 

1Michael Grätzel Center for Mesoscopic Solar Cells, Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology, Wuhan 430074, Hubei, China. 2Laboratory of Photonics and Interfaces, École polytechnique fédérale de Lausanne, 1015 Lausanne, Switzerland.<sup>3</sup> Department of Materials Science and Engineering, Southern University of Science and Technology, Shenzhen 518055, Guangdong, China. 4School of Physics and Technology and Key Laboratory of Artificial Micro- and Nanostructures of Ministry of Education, Wuhan University, Wuhan 430072, Hubei, China.<sup>5</sup> i-Lab, CAS Key Laboratory of Nanophotonic Materials and Devices, Suzhou Institute of Nano-Tech and Nano-Bionics, Chinese Academy of Sciences (CAS), Suzhou 215123, Jiangsu, China.<sup>6</sup> State Key Laboratory of Advanced Technology for Materials Synthesis and Processing, Wuhan University of Technology, Wuhan 430070, Hubei, China.<sup>7</sup> Hubei Longzhong Laboratory, Wuhan University of Technology (Xiangyang Demonstration Zone), Xiangyang 441000, Hubei, China. 

The PSCs and PSMs we fabricated have the layered architecture indium tin oxide (ITO)/ tin(IV) oxide (SnO2)/perovskite/HTL/Ag or Au (Fig. 1B). The triple-cation perovskite CsFAMAPb(I1−xBrx)3 [where Cs is cesium, FA is HC(NH2)2, and MA is CH3NH3] (38, 39) was deposited by the VASP method (see supplementary materials for device fabrication details). The VASP method enables fast removal and recuperation of solvent, which boosts the rapid crystallization of the dimethyl sulfoxide (DMSO)/lead(II) iodide (PbI2) Lewis base adduct intermediate phase (14, 15). Upon thermal annealing, highly oriented, crystalline perovskite films can be obtained (19, 40). This 

*Corresponding author. Email: ygrong2022@outlook.com (Y.R.); michael.graetzel@epfl.ch (M.G.); xiongli@hust.edu.cn (X.L.) †These authors contributed equally to this work. 

1 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A B<br>Pinholes<br>Aggregated LiTFSI<br>Au or Ag PPO-TEMPO<br>Organic HTL<br>CPPA<br>Perovskite<br>SnO2<br>ITO/glass<br>CPPA<br>C<br>HTL<br>Spiro-Li (Spiro-Li)-PPO-TEMPO<br>Perovskite<br>+<br>SnO2<br>TFSI -<br>PPO-TEMPO PPO-TEMPO(TFSI) 300 nm 300 nm<br>D E 70 F<br>25<br>60 20<br>Stabilized PCE of 21.1%<br>20 50 15<br>10<br>15 Cell area V OC J SC FF PCE 40 0 100 Time (s) 200 300<br>1.0 cm 2 (mV) (mA cm -2 ) (%) (%) 30<br>10 Control 1.13 24.5 77.3 21.4 Module V OC I SC FF PCE<br>20 17.1 cm 2 (mV) (mA) (%) (%)<br>CPPA 1.15 24.8 80.0 22.8<br>5 Lab Test 6.97 66.3 79.2 21.4<br>TEMPOPPO- 1.18 24.8 80.2 23.5 10 Certified 6.99 65.1 73.8 19.6<br>00.0 0.2 0.4 0.6 0.8 1.0 1.2 00 1 2 3 4 5 6 7 1 cm<br>Voltage (V) Voltage (V)<br>-2) )<br>%<br>m (<br>c  CE<br>A P<br>m<br>( )(mA<br> t<br>n<br>ytis e<br>d tne Crru<br>n<br>e<br>rr<br>u<br>C<br><!-- End of picture text -->

Ag electrodes had been removed for conducting TOF-SIMS measurements of the HTL layer (fig. S1). (D) J-V curves and photovoltaic parameters of a representative cell that used CsFAMA and Spiro-Li (control), CsFAMA-CPPA and Spiro-Li (CPPA), and CsFAMA-CPPA and (Spiro-Li)-PPO-TEMPO (PPO-TEMPO). (E) J-V curves and stabilized output of the PSM recorded in the lab using a mask with an aperture area of 17.1 cm<sup>2</sup> . The photovoltaic parameters certified by an accredited testing laboratory are also presented for comparison. (F) A photograph of the PSM. 

Fig. 1. Device configuration and photovoltaic performance. (A) Molecular structures of CPPA, PPO-TEMPO, and PPO-TEMPO(TFSI). (B) Schematic outline of the architecture of as-fabricated PSCs, and the stabilizing strategy for the perovskite layer and HTL. The perovskite layer had a composition Cs0.05FA0.85MA0.10Pb(I0.97Br0.03)3. (C) Cross-sectional SEM images of perovskite/HTL/Ag aged under illumination at 75°C for 100 hours. The degraded area of the perovskite and HTL films is marked by the dashed line. In both images, 

method allows deposition of perovskite films on a large substrate area and can be applied to continuous production processes. Previously, we have demonstrated operationally stable PSCs using CsFAMA perovskite polycrystalline film and Spiro-MeOTAD/LiTFSI/4-tertbutyl pyridine (tBP) blend film (abbreviated as Spiro-Li) (39, 40). However, the cells could only deliver stable electricity output at a temperature below 65°C. When the cells were stressed at a higher temperature, cell performance decayed severely owing to the degradation of the Spiro-Li layer. At elevated temperatures, small pinholes within the Spiro-Li layer were formed, enlarged, and ultimately caused severe mor- 

phological deformation that provided channels for the escape of volatile and corrosive ingredients from the perovskite layer (41–44). Upon introducing the PPO-TEMPO doping strategy to the Spiro-Li layer, the bulk morphology of the perovskite/HTL bilayer featuring well-defined interfaces was markedly stabilized under illumination at 75°C for 100 hours (Fig. 1C). Time-of-flight secondary ion massspectrometry (TOF-SIMS) measurements showed that PPO-TEMPO doping could also minimize the interfacial diffusion of iodide from the perovskite layer to the HTL (fig. S1). 

formance, we fabricated and tested a batch of 20 cells. The representative current density– voltage (J-V) curves are compared in Fig. 1D, and the statistical results are shown in table S1 and fig. S2. When CPPA was introduced into the perovskite layer, the fill factor (FF) increased from 77.3% to 80.0%, and the opencircuit voltage (VOC) increased from 1.13 V to 1.15 V. We attribute the improved cell performance to enhanced intragrain charge transport and suppression of nonradiative charge recombination by CPPA molecules at the GBs (45). Meanwhile, when PPO-TEMPO doping was applied, the VOC was further increased to 1.18 V, which we attribute to a more favorable 

To evaluate the effect of the CPPA modulator and PPO-TEMPO doping on cell per- 

2 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 



gions there was an amorphous region, which is considered beneficial for stress relaxation within crystalline perovskite films. 

tal lead. This process is triggered by the loss of iodine from the lattice, leaving MAI and Pb behind. The prevention of decomposition by CPPA indicates that its presence at the perovskite GBs impairs the escape of iodine. Such a stabilization effect may also contribute to the HTL, because the diffusion of iodide ions from the perovskite into the HTL can reduce the oxidized HTMs and cause dedoping issues (55). 

band alignment. For the cell using CsFAMACPPA as the absorbing layer and (Spiro-Li)PPO-TEMPO as the HTL, we achieved a PCE of 23.5% with negligible hysteresis (fig. S3). We confirmed the measured short-circuit density (JSC) of 24.8 mA cm<sup>−2</sup> by recording incident photon–to-current efficiency (IPCE) spectra, which yield an integrated current density of 24.7 mA cm<sup>−2</sup> . This value is in good agreement with the measured JSC value and indicated that there was negligible spectral mismatch between our solar simulator and the standard global AM 1.5 solar emission (fig. S4). 





We analyzed the stabilization effect of CPPA on mixed-halide perovskites by measuring the photoluminescence (PL) properties of the CPPAmodulated perovskite films under blue-light irradiation. A typical mixed-halide perovskite composition of MAPb(I0.5Br0.5)3 was used as a model. When the films were exposed to high-intensity (13.0 W cm<sup>−2</sup> ) blue-light irradiation, significant phase evolution was observed (Fig. 2C). Both MAPb(I0.5Br0.5)3 and MAPb(I0.5Br0.5)3-CPPA showed PL peaks of an iodine-rich (I-rich) phase at ~747 nm after 1 min of irradiation, resulting from the regular photoinduced phase segregation (48–51). After 10 min of irradiation, a phase decomposition for the pristine MAPb(I0.5Br0.5)3 emerged that manifested itself by a weak PL peak at 537 nm, corresponding to the characteristic emission peak of MAPbBr3 (52–54). This indicated that the I-rich phase decomposed under the intense light illumination, leaving MAPbBr3 behind, which appeared to be less susceptible than MAPbI3 to decomposition under the intense light beam. After 15 min, the intensity of the 537-nm peak became comparable to that of the I-rich phase with a peak at 737 nm. This indicated that MAPbBr3 has become the dominant phase in the mixed-halide perovskite film. The decomposition of MAPbI3 may be caused by either photolysis or thermolysis, according to the equation that follows (see also supplementary note 2) 

We found that CPPA can also improve the hydrophobicity and moisture stability of the modulated perovskite film. We exposed the perovskite to ambient atmosphere with a high relative humidity of 70% and found that pristine CsFAMA rapidly degraded to d-FAPbI3 and PbI2, whereas CsFAMA-CPPA maintained its original crystal structure (Fig. 2, E and F, and fig. S16). We performed conductive atomic force microscopy (c-AFM) measurements to investigate the charge transport properties of the perovskite films (fig. S17). Compared with pristine CsFAMA, CsFAMA-CPPA presented higher current flow through the film. In particular, the brighter contrast at GBs indicates a suppressed charge-transporting barrier across the GBs of CsFAMA-CPPA. Absolute spectral photon flux F was measured to derive the PL quantum yield (PLQY) of the perovskite films (Fig. 2G), which increased from 3.27% to 6.41% after doping the perovskite with CPPA. The quasi–Fermi level splitting DEF/q (where EF is the Fermi level and q is the elementary charge) increased from 1.176 to 1.192 V for CsFAMA versus CsFAMA-CPPA (table S3) (56, 57) and reflected the suppression of nonradiative recombination with the CPPA additive. 

To highlight the advantages of using the VASP method to deposit large-area perovskite films, we fabricated PSMs consisting of six subcells connected in series and obtained a PCE of 21.4% with an aperture area of 17.1 cm<sup>2</sup> (the stabilized PCE reached 21.1%) (Fig. 1E). We also sent one of the minimodules to a PV measurement laboratory, and the validated PCE reached 19.6% (fig. S5). A photograph of the PSM is presented in Fig. 1E. The short-circuit photocurrent (ISC) of the module reached 66.3 mA, corresponding to a JSC of 23.3 mA cm<sup>−2</sup> for the subcells, which was 94% of the JSC obtained with lab-scale cells. As confirmed by scanning electron microscopy (SEM), the perovskite film deposited by the VASP method showed uniform grain size and height at different locations over a 10-cm scale (fig. S6). 

#### Grain modulation of the perovskite layer 

Density functional theory calculations revealed that CPPA associated with lead halide perovskites through hydrogen bonding as well as coordinative bonding and fullerene–iodide interactions (see Fig. 2A, fig. S7, table S2, and supplementary note 1 in the supplementary text for details). Accordingly, we postulated that CPPA associated with GBs, thereby enhancing the stability of the perovskite film (26, 27). To prove this, we used cryo–transmission electron microscopy (which minimizes the electron beam damage to the perovskites) to analyze the microstructures of aged perovskite films (46). The pristine and CPPA-modulated perovskite films were exposed to continuous illumination at 85°C. Representative high-resolution transmission electron microscopy (HRTEM) images of selected areas are shown in Fig. 2B and fig. S8. For the aged CsFAMA film, three distinct crystal structures were observed, and the interplanar spacings (ISs) and fast Fourier transform patterns (fig. S9) of a selected area were analyzed. The crystalline region with an IS of 3.16 Å was identified as the (200) domain of a-FAPbI3, and the region with an IS of 6.90 Å corresponded to the hexagonal PbI2 domain (47). For the aged CsFAMA-CPPA film, crystalline regions corresponded to (220) and (210) domains of a-FAPbI3, and no PbI2 domain was observed (fig. S10). Between the crystalline re- 



<!-- Start of picture text -->
MAPbI3 = I2 + Pb + MAI (1)<br><!-- End of picture text -->

#### Radical polymeric p-doping of the HTL 

In contrast, the CPPA-treated MAPb(I0.5Br0.5)3 resisted degradation under prolonged exposure to the intense blue light. Notably, the 747-nm PL peak remained unchanged within 15 min of irradiation. The stable PL emission indicated that the presence of CPPA prevented the decomposition of MAPbI3 under high-intensity irradiation. The PL imaging results as a function of irradiation time are presented in Fig. 2D and fig. S11. For MAPb(I0.5Br0.5)3, it was found that green spots started to emerge at the illumination area after 10 min and became more intense after 15 min of irradiation. By contrast, the irradiated area of CPPA-treated MAPb (I0.5Br0.5)3 maintained its red emission during the whole irradiation process. This implied that CPPA could effectively enhance the photostability of mixed-halide perovskites (see supplementary note 2 for details). 

Effective and homogeneous doping and stabilization of the HTM is critically important for high-performance PSMs. In addition, it is necessary to develop effective HTM doping methods to facilitate the fabrication of PSMs. We oxidized the neutral radical polymer PPOTEMPO to a poly(oxoammonium salt) of PPOTEMPO(TFSI) (see the materials and methods section of the supplementary materials for synthesis details) and incorporated it as a p-dopant of spiro-MeOTAD. PPO-TEMPO/ PPO-TEMPO(TFSI) had a redox potential of 0.925 V compared with a normal hydrogen electrode (NHE), as determined by electrochemical measurements (fig. S18), which is greater than that of spiro-MeOTAD/spiroMeOTAD·<sup>+</sup> (0.72 V compared with NHE) and provides a driving force of ~200 mV to oxidize spiro-MeOTAD through a one-electron transfer reaction (58). Upon the reduction of the oxoammonium, this cationic pendant group formed the stable radical polymer poly(4glycidyloxy-2,2,6,6-tetramethylpiperidine1-oxyl) (PPO-TEMPO), which can interact with Li<sup>+</sup> ions and stabilize the HTL (Fig. 3A) (59). 

The stabilization of MAPbI3-rich grains formed during the phase segregation by CPPA clearly arises from its prevention of their photoor thermally induced decomposition under blue-light irradiation. Our detailed analysis shows that MAPbI3 decomposes into iodine, methylammonium iodide (MAI), and elemen- 

3 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 



<!-- Start of picture text -->
A C MAPb(I0.5Br0.5)3 MAPb(I0.5Br0.5)3-CPPA<br>Decomposition ×<br>1.0 15 min Segregation 1.0 Segregation 15 min<br>0 min 10 min 0 min 10 min<br>0.8 1 min 0.8 1 min<br>0.6 0.6<br>0.4 0.4<br>0.2 0.2<br>0.0 0.0<br>500 600 700 800 500 600 700 800<br>C N O P H FA + [PbI6] 4-<br>Wavelength (nm) Wavelength (nm)<br>B D<br>CsFAMA CsFAMA-CPPA MAPb(I0.5Br0.5)3 CsFAMA MAPb(I0.5Br0.5)3-CPPA<br>Crystalline<br>Crystalline<br>PbI2<br>amorphous<br>5 nm 5 nm 20 μm 20 μm<br>E F G 25<br>δ CsFAMA CsFAMA-CPPAα CsFAMA-CPPA 0 h 10 h  CsFAMACsFAMA-CPPA<br>PbI2 168 h 20<br>PbI2 PLQY = 6.41%<br>α 168 h CsFAMA 0 h10 h 15<br>168 h 168 h<br>PLQY = 3.27%<br>10<br>10 h 10 h<br>5<br>0 h 0 h 0<br>10 12 14 16 10 12 14 16 600 700 800 900 700 750 800 850 900 950<br>2θ (degree) 2θ (degree) Wavelength (nm) Wavelength (nm)<br>Normalized intensity Normalized intensity<br>-1)<br> ).<br>a.u.) au. -1 nm<br>( e -1 m<br>c<br>( ytisnItne barsno 16 s<br>bA Φ (×10<br><!-- End of picture text -->

lamp; wavelength: 460 to 490 nm; intensity: 13.0 W cm<sup>−2</sup> ). (D) PL imaging results of MAPb(I0.5Br0.5)3 and MAPb(I0.5Br0.5)3-CPPA films after 15 min of blue-light irradiation. (E) X-ray diffraction (XRD) patterns and (F) UV-vis spectra of CsFAMA and CsFAMA-CPPA perovskite films aged in a humid environment (relative humidity: 70 to ~75%) for 0 to ~168 hours. (G) Photoluminescence spectra photon flux F of the perovskite films. a.u., arbitrary units. 

Fig. 2. Working mechanism of CPPA and luminescence enhancement in perovskite films. (A) The scheme of interaction modes between CPPA and perovskites. (B) Cryo-HRTEM images of perovskite films aged under continuous illumination at a temperature of 85°C for 7 days in nitrogen atmosphere. The magnifications of the boxed areas are shown in fig. S7. (C) The evolution of PL spectra of MAPb(I0.5Br0.5)3 and MAPb(I0.5Br0.5)3-CPPA films under continuous blue-light irradiation (mercury 

The doping effect was further investigated by conductivity and UV photoelectron spectroscopy (UPS) measurements. The conductivity of the Spiro-Li film was evaluated by measuring the J-V curves of a symmetrical device with Au/Spiro-Li/Au architecture. As shown in Fig. 3C, the undoped Spiro-Li film kept under N2 showed quite a low electrical conductivity of 1.19 × 10<sup>−7</sup> S cm<sup>−1</sup> , but the Spiro-Li film with PPO-TEMPO doping had a high electrical conductivity of 3.32 × 10<sup>−5</sup> S cm<sup>−1</sup> without exposure to oxygen (see supplementary note 3 for details). UPS results confirmed that PPOTEMPO doping improved the energy band 

The changes in the UV-visible (UV-vis) absorption spectrum of a spiro-MeOTAD solution in chlorobenzene upon PPO-TEMPO doping are shown in Fig. 3B. Increasing the amount of dopant gave rise to an absorption peak at ~520 nm from the monocation radical of spiroMeOTAD·<sup>+</sup> that increased linearly with dopant concentration (30). We estimated the doping efficacy, defined by the molar ratio of the oxidized spiro-MeOTAD to the added dopant, to be ~ 90%. Although spiro-MeOTAD was oxidized to the cation radical spiro-MeOTAD·+, PPO-TEMPO(TFSI) was reduced to its neutral polymeric radical state in the doped HTMs. 

alignment in the perovskite/HTL/Au stack (see figs. S19 and S20 and supplementary note 4 for details). Thedeepened Fermileveland increased conductivity confirmed efficient p-type doping with PPO-TEMPO/PPO-TEMPO(TFSI). 

Compared with the gas-doping strategies with O2 or CO2, which usually involve photoinduced gas-liquid or gas-solid reactions (34), PPO-TEMPO doping in HTM solution was more efficient and would largely simplify the doping process. The Li<sup>+</sup> /PPO-TEMPO radical interaction (59) can also prevent the migration of lithium cations under heat and voltage stress. To evaluate this effect, the Spiro-Li 

4 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A Ether<br>oxygen<br>LiTFSI<br>LiTFSI<br>polymer backbone<br>PPO-TEMPO(TFSI) PPO-TEMPO PPO-TEMPO  … LiTFSI  interaction<br>B D F<br>Spiro-Li in N2 Spiro-Li Spiro-Li<br>(Spiro-Li)-PPO-TEMPO5%<br>(Spiro-Li)-PPO-TEMPO10%<br>5 μm 300 nm<br>400 500 600 700 800<br>Wavelength (nm)<br>C 2 E G<br>Spiro-Li in N2 (Spiro-Li)-PPO-TEMPO (Spiro-Li)-PPO-TEMPO<br>Spiro-Li in air<br>(Spiro-Li)-PPO-TEMPO in N2<br>1 Aged (Spiro-Li)-PPO-TEMPO<br>0<br>Conductivity (S cm -1 )<br>-1 Au 1.91 ×2.30 × 1010 -7-5<br>Spiro 3.32 × 10 -5<br>Au 2.97 × 10 -5 5 μm 300 nm<br>-2<br>-1000 -500 0 500 1000<br>Bias (mV)<br>).<br>au.<br>(<br>e<br>c<br>n<br>a<br>bor<br>s<br>b<br>A<br>-2)<br>m<br>c<br>(A t<br>n<br>e<br>rr<br>u<br>C<br><!-- End of picture text -->

conductivity of the HTL with and without PPO-TEMPO doping in air and nitrogen (the inset shows the extracted conductivity values). The aged samples were heated at 75°C for 30 min. (D and E) Surface SEM images of Spiro-Li films with and without PPO-TEMPO doping after aging at 75°C for 100 hours. (F and G) Li element EELS mapping images of aged Spiro-Li films with and without PPO-TEMPO doping. 

Fig. 3. Doping effect and stabilized bulk morphology. (A) Schematic illustration of the doping mechanism of PPO-TEMPO and PPO-TEMPO(TFSI) of organic HTMs, and the interaction mode between the reduction product PPO-TEMPO and LiTFSI additive. (B) The absorption spectra of Spiro-Li without doping and Spiro-Li with PPO-TEMPO doping of different ratios. (C) The J-V curves measured with symmetrical device of Au/Spiro-Li/Au for evaluating the 

films with and without PPO-TEMPO doping were aged under heat at 75°C in dry air. After 100 hours, voids, microdefects, and particles emerge on the film without PPO-TEMPO, whereas the film with PPO-TEMPO doping maintained its initial pinhole-free surface morphology (Fig. 3, D and E). The voids represent inhomogeneities within the HTL. 

tion. In the control sample, the higher-contrast white spots highlighted by yellow cycles indicate a high Li content. These Li-rich domains of ~50-nm size were associated with the pits shown in the HRTEM morphology image. Thus, our direct mapping of Li in a control HTL film revealed nanoscale inhomogeneities (nonstoichiometric regions) associated with local phase separation. It appeared that PPO-TEMPO doping could improve the PSC stability by preventing such local Li<sup>+</sup> accumulation. 

contrast, the PSM with PPO-TEMPO doping exhibited its optimal photovoltaic performance with modular PCE > 20% right after fabrication. Our approach has provided effective HTM doping of the PSM and will facilitate future mass production of PSMs. 

We investigated the operational stability of as-fabricated cells by conducting maximum power point (MPP) tracking under continuous illumination. The target cells treated with CPPA and PPO-TEMPO doping maintained 95.5% of their initial PCE after 3265 hours under continuous illumination at 70° ± 5°C, whereas the control cells without PPO-TEMPO doping lost >30% of their initial PCEs in just 1000 hours (Fig. 4A). The void-like structures and inhomogeneities within HTLs likely impeded the top-down charge transport during 

We correlated these morphological deformations with inhomogeneous distribution of Li<sup>+</sup> by analyzing the films with the EELS (electron energy loss spectroscopy) mapping technique (Fig. 3, F and G; see supplementary note 5 for details). In the HRTEM morphology images (fig. S21), several pits were observed, which was consistent with those in SEM images. For EELS mapping images, the relative color shift depicts the fluctuation in local Li concentra- 

In addition, this polymeric p-doping strategy also provides an effective solution of HTM doping for the fabrication of PSMs. As shown in fig. S22, PSM using the regular Spiro-Li HTL required an ambient air exposure process of more than 24 hours. Such a process will unduly slow down the fabrication of PSMs. By 

5 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 





<!-- Start of picture text -->
A<br>1.0 95.5%<br>0.8<br>64.5%<br>0.6<br>Spiro-Li<br>0.4 (Spiro-Li)-PPO-TEMPO MPP tracking under AM 1.5 illumination @ 70 5 C<br>0 500 1000 1500 2000 2500 3000<br>Time (hour)<br>B C<br>105 Ag HTL Perovskite 105 1.0<br>104 104 0.8<br>103 103 0.6<br>102 102 0.4<br>101 Spiro-Li 101 0.2 Spiro-Li<br>(Spiro-Li)-PPO-TEMPO (Spiro-Li)-PPO-TEMPO @85 C<br>100 100 0.0<br>0 50 100 150 200 250 300 0 200 400 600 800 1000<br>Sputtering time (s) Time (hour)<br>E<br>C<br>P<br>d<br>e<br>zila<br>mro<br>N<br>)%<br> ytis (<br>n E<br>te CP<br>d<br>ni la e<br>n zila<br>gis e mro<br>nid N<br>Io Silver signal intensity<br><!-- End of picture text -->

Fig. 4. Device stability and degradation analysis. (A) Evolution of the PCE over time, as measured by MPP tracking of encapsulated cells under light soaking with AM1.5G simulated illumination at a temperature of 70° ± 5°C. (B) TOF-SIMS depth profiles of the iodine and Ag in SnO2/perovskite/HTL/Ag stacked layers. (C) Thermal stability test performed at 85°C for the cells using Spiro-Li as the HTL with and without PPO-TEMPO doping. 

operation of PSCs and would lead to severe degradation of the devices by triggering the reactions between the perovskite and metal back contacts (41, 43). TOF-SIMS results proved that PPO-TEMPO doping can effectively suppress the intrusion of iodide into the HTL (Fig. 4B) and prevent the reaction between the perovskite layer and metal electrode. 

We also attributed the enhanced stability to the suppressed Li<sup>+</sup> diffusion in the HTL (60) and conducted TOF-SIMS depth profiling of Li<sup>+</sup> along the vertical direction through the stacks (fig. S23, and see supplementary note 6 for details). When PSCs were aged with a Spiro-Li layer, Li<sup>+</sup> was found at a higher concentration at the perovskite/SnO2 interface. Li<sup>+</sup> intrusion into the perovskite active layer could also result in decomposition of the perovskite, leading to cell performance degradation (61). However, only a small amount of Li<sup>+</sup> diffused out from the aged PPO-TEMPO–doped HTL, which we attributed to the formation of Lewis acid-base interaction between Li<sup>+</sup> and the ether linkages in the PPO-TEMPO polymer backbone (62). 

To investigate the stability of the cells under thermal stress, we tested PSCs under prolonged heat exposure at 85°C according to ISOS (International Summit on Organic Photovoltaic Stability) procedures (63). Given the glass-transition issues of Spiro-MeOTAD, the cells suffered a certain extent of initial losses (Fig. 4C). For the 

cells using Spiro-Li as the HTL, power output rapidly decayed by >40% after 200 hours, and by >70% after 1000 hours, of storage at 85°C. Conversely, after doping Spiro-Li with PPOTEMPO, the cell power output decayed only by <20% after 1000 hours of storage at 85°C. 

To show the universality of this polymeric redox couple doping strategy, we used PPOTEMPO doping for two other representative polymeric hole conductors, PTAA and poly(3hexylthiophene) (P3HT). Both of the doped HTLs exhibited higher conductivities than did pristine films (fig. S24), realizing more-efficient PSCs without any postfabrication treatments (see table S4, fig. S25, and supplementary note 7 for details). We infer that the doping and stabilizing effect of PPO-TEMPO doping on organic HTMs could be broadly applicable. The highly doped HTLs exhibited better conductivity, so the thickness of the HTL in PSCs can be increased to >150 nm. Integrated with the CPPA-enhanced perovskite layer, the holistic strategy for stabilizing the perovskite/HTL heterostructure provides promising technical routes for fabricating efficient and stable PSMs. 

##### REFERENCES AND NOTES 

1. A. Kojima, K. Teshima, Y. Shirai, T. Miyasaka, J. Am. Chem. Soc. 

- 131, 6050–6051 (2009). 

2. Q. Dong et al., Science 347, 967–970 (2015). 

3. G. E. Eperon, M. T. Hörantner, H. J. Snaith, Nat. Rev. Chem. 1, 0095 (2017). 

4. D. Bi et al., Nat. Energy 1, 16142 (2016). 5. J. J. Yoo et al., Nature 590, 587–593 (2021). 

6. National Renewable Energy Laboratory, Photovoltaic Research: Best Research-Cell Efficiency Chart; https://www.nrel.gov/pv/ cell-efficiency.html. 

7. J. Jeong et al., Nature 592, 381–385 (2021). 

8. E. Bi et al., Joule 3, 2748–2760 (2019). 

9. Y. Deng et al., Nat. Energy 6, 633–641 (2021). 

10. N.-G. Park, K. Zhu, Nat. Rev. Mater. 5, 333–350 (2020). 

11. Z. Yang et al., Sci. Adv. 7, eabg3749 (2021). 

12. Y. Deng et al., Sci. Adv. 5, eaax7537 (2019). 

13. N. J. Jeon et al., Nat. Mater. 13, 897–903 (2014). 

14. Y. Rong et al., Nanoscale 7, 10595–10599 (2015). 

15. N. Ahn et al., J. Am. Chem. Soc. 137, 8696–8699 (2015). 

16. F. Di Giacomo et al., Sol. Energy Mater. Sol. Cells 181, 53–59 (2018). 

17. Y. Deng et al., Nat. Energy 3, 560–566 (2018). 

18. D.-N. Jeong et al., ACS Energy Lett. 4, 1189–1195 (2019). 

19. X. Li et al., Science 353, 58–62 (2016). 

20. J. Xue, R. Wang, Y. Yang, Nat. Rev. Mater. 5, 809–827 (2020). 

21. L. K. Ono, S. F. Liu, Y. Qi, Angew. Chem. Int. Ed. 59, 6676–6698 (2020). 

22. B. Chen, P. N. Rudd, S. Yang, Y. Yuan, J. Huang, Chem. Soc. Rev. 48, 3842–3867 (2019). 

23. S. Yang et al., J. Am. Chem. Soc. 141, 5781–5787 (2019). 

24. M.-H. Choi et al., Nano Energy 71, 104639 (2020). 

25. Q. Jiang et al., Nat. Photonics 13, 460–466 (2019). 

26. X. Li et al., Nat. Chem. 7, 703–711 (2015). 

27. H. Xie et al., Joule 5, 1246–1266 (2021). 

28. J. Xu et al., Nat. Commun. 6, 7081 (2015). 

29. Y. Shao, Z. Xiao, C. Bi, Y. Yuan, J. Huang, Nat. Commun. 5, 5784 (2014). 

30. A. Abate et al., Phys. Chem. Chem. Phys. 15, 2572–2579 (2013). 

31. U. B. Cappel, T. Daeneke, U. Bach, Nano Lett. 12, 4925–4931 (2012). 

32. F. Lamberti et al., Chem 5, 1806–1817 (2019). 

33. T. H. Schloemer, J. A. Christians, J. M. Luther, A. Sellinger, Chem. Sci. 10, 1904–1935 (2019). 

6 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 

RESEARCH | RESEARCH ARTICLE 







60. S.-G. Kim et al., Adv. Mater. 33, e2007431 (2021). 

34. J. Kong et al., Nature 594, 51–56 (2021). 

and Y.R. Supervision: X.L., M.G., and Y.R. Writing – original draft: S.Y. and Y.R. Writing – review & editing: Y.R., Y.L., M.G., and X.L. X.L. and Y.R. conceived of and supervised the project. X.L., Y.R., and M.G. designed this project. S.Y., M.L., R.L., and S.Z. fabricated the PSCs and PSMs. H.Z. synthesized the chemicals and conducted UV-vis measurements. B.H. conducted cryo-HRTEM measurements and analyzed the data. S.Y. and Q.P. conducted SEM measurements. Z.L. and T.W. conducted PL imaging measurements. X.Z. and L.L. conducted the DFT calculations. L.L. and Y.Z. conducted TOF-SIMS and UPS measurements. C.Z. and Q.C. conducted c-AFM measurements. L.M. contributed to PL, XRD, and x-ray photoelectron spectroscopy measurements. B.C. and S.M.Z. performed PLQY measurements. Y.R., Y.L., R.G., F.T.E., and L.M. performed the investigations and analyzed the data. Y.R. and S.Y. wrote the original draft. Y.R., Y.L., M.G., and X.L. contributed to the editing of the manuscript. All authors discussed the results and reviewed the manuscript. Competing interests: X.L. and H.Z. have filed a patent based on the concept developed in this manuscript. The other authors declare no competing interests. Data and materials availability: All data are available in the main text or the supplementary materials. License information: Copyright © 2023 the authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original US government works. https://www.science.org/about/science-licenses-journal-article-reuse 

61. J. A. Dawson et al., ACS Energy Lett. 2, 1818–1824 (2017). 

35. T. Zhang et al., Science 377, 495–501 (2022). 

62. Y. Joo, V. Agarkar, S. H. Sung, B. M. Savoie, B. W. Boudouris, Science 359, 1391–1395 (2018). 

36. T. H. Schloemer et al., ACS Energy Lett. 4, 473–482 (2019). 

37. J. Urieta-Mora, I. García-Benito, A. Molina-Ontoria, N. Martín, Chem. Soc. Rev. 47, 8541–8571 (2018). 

63. M. V. Khenkin et al., Nat. Energy 5, 35–49 (2020). 

38. M. Saliba et al., Energy Environ. Sci. 9, 1989–1997 (2016). 

##### ACKNOWLEDGMENTS 

39. S. You et al., Adv. Mater. 32, 2003990 (2020). 

40. D. Bi et al., Nat. Commun. 9, 4482 (2018). 

We thank the Analytical and Testing Center of Huazhong University of Science and Technology and the Center for Nanoscale Characterization and Devices at Wuhan National Laboratory for Optoelectronics for performing various characterizations and measurements; the Pico and Cryo-TEM Center at Southern University of Science and Technology (SUSTech) Core Research Facility; Y. Zou and Y. Deng at the Cryo-TEM Center of SUSTech for help with TEM measurements. H. Xu for help with PL measurements; Z. Xiao for providing VASP software copyright and server computing resources; and W. Tress for valuable discussions. Funding: This work was supported by the National Key Research and Development Program of China [2020YFA0715000 (L.M.) and 2022YFB4200305 (X.L. and Y.R.)]; the Chinese National Thousand Talents Plan (X.L.); the National Natural Science Foundation of China [21875081 and 22279039 (X.L.), 52172200 (Y.R.), and 52127816 (L.M.)]; the Science and Technology Department of Hubei Province [2021CFB315 (Y.R.)]; the Frontier Project of the Application Foundation of Wuhan Science and Technology Plan Project [2020010601012202 (X.L.)]; the Innovation Project of Optics Valley Laboratory OVL2021BG008 (X.L.); the Foundation of State Key Laboratory of New Textile Materials and Advanced Processing Technologies Grant FZ2021011 (X.L.); the Graduates’ Innovation Fund of Huazhong University of Science and Technology 2021yjsCXCY037 (S.Y.); and the Günes Corporation (M.G.). Author contributions: Conceptualization: X.L., Y.R., and M.G. Investigation: S.Y., X.Z., Y.L., B.H., T.W., H.Z., C.Z., Q.C., R.L., Y.Z., L.Li, L.Luo, S.M.Z., R.G., Y.R., F.T.E., B.C., S.Z., Q.P., and L.M. Visualization: S.Y., Y.L., Y.R., and X.L. Funding acquisition: X.L., Y.R., and L.M. Project administration: X.L. 

41. Y. Kato et al., Adv. Mater. Interfaces 2, 1500195 (2015). 

42. X. Niu et al., J. Mater. Chem. A Mater. Energy Sustain. 7, 7338–7346 (2019). 

43. K. Domanski et al., ACS Nano 10, 6306–6314 (2016). 

44. S. Wang, Y. Jiang, E. J. Juarez-Perez, L. K. Ono, Y. Qi, Nat. Energy 2, 16195 (2016). 

45. D.-Y. Son et al., Nat. Energy 1, 16081 (2016). 

46. M. U. Rothmann et al., Adv. Mater. 30, e1800629 (2018). 

47. B.-W. Park et al., Nat. Energy 6, 419–428 (2021). 

48. E. T. Hoke et al., Chem. Sci. 6, 613–617 (2015). 

49. C. G. Bischak et al., Nano Lett. 17, 1028–1033 (2017). 

50. M. C. Brennan, A. Ruth, P. V. Kamat, M. Kuno, Trends Chem. 2, 282–301 (2020). 

51. A. J. Knight, L. M. Herz, Energy Environ. Sci. 13, 2024–2046 (2020). 

52. J. T. DuBose, P. V. Kamat, Acc. Mater. Res. 3, 761–771 (2022). 

53. Z. Li et al., Adv. Sci. (Weinh.) 9, e2103948 (2022). 

##### SUPPLEMENTARY MATERIALS 

54. G. F. Samu et al., J. Am. Chem. Soc. 141, 10812–10820 (2019). 

science.org/doi/10.1126/science.add8786 Materials and Methods Supplementary Text Figs. S1 to S25 Tables S1 to S4 References (64–70) 

55. T. Wang et al., Science 377, 1227–1232 (2022). 

56. W. Tress et al., Adv. Energy Mater. 5, 1400812 (2015). 

57. H. Zhu et al., Adv. Mater. 32, e1907757 (2020). 

58. J. Burschka et al., J. Am. Chem. Soc. 133, 18042–18045 (2011). 

Submitted 11 July 2022; accepted 15 December 2022 10.1126/science.add8786 

59. I. Yu, D. Jeon, B. Boudouris, Y. Joo, Macromolecules 53, 4435–4441 (2020). 

7 of 7 

You et al., Science 379, 288–294 (2023) 20 January 2023 



### **Radical polymeric p-doping and grain modulation for stable, efficient perovskite solar modules** 

Shuai You, Haipeng Zeng, Yuhang Liu, Bing Han, Min Li, Lin Li, Xin Zheng, Rui Guo, Long Luo, Zhe Li, Chi Zhang, Ranran Liu, Yang Zhao, Shujing Zhang, Qi Peng, Ti Wang, Qi Chen, Felix T. Eickemeyer, Brian Carlsen, Shaik M. Zakeeruddin, Liqiang Mai, Yaoguang Rong, Michael Grätzel, and Xiong Li 

_Science_ **379** (6629), .  DOI: 10.1126/science.add8786 

#### **Two additives for perovskite modules** 

The performance of large-area perovskite solar cells and modules fabricated by the vacuum flash solution-processing method has been enhanced with two different additives. You _et al_ . synthesized a fullerene derivative with a phosphonate group that accelerated electron transfer across grain boundaries in the perovskite film and suppressed ion migration. They also prepared a polypropylene oxide polymer substituted with a redox active species that could facilitate p-doping of the hole transport layer quickly, unlike the conventional air-doping approach. Large-area modules (17 square centimeters) had power-conversion efficiencies of up to 21.4%. The modules retained 95% of their efficiency after more than 3000 hours of continuous illumination at elevated temperature. —PDS 

**View the article online** https://www.science.org/doi/10.1126/science.add8786 **Permissions** https://www.science.org/help/reprints-and-permissions 

Use of this article is subject to the Terms of service 

_Science_ (ISSN 1095-9203) is published by the American Association for the Advancement of Science. 1200 New York Avenue NW, Washington, DC 20005. The title _Science_ is a registered trademark of AAAS. 

Copyright © 2023 The Authors, some rights reserved; exclusive licensee American Association for the Advancement of Science. No claim to original U.S. Government Works 

