# Steering perovskite precursor solutions for multijunction photovoltaics

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 164 |
| 作者 | Shuai-Feng Hu, Jun-Ke Wang, Pei Zhao, Jorge Pascual, Jia-Nan Wang, F. Rombach, Akash Dasgupta, Wen-Tao Liu et al. |
| DOI | 10.1038/s41586-024-08546-y |
| 源文件 | 093_Hu_2024_Steering-perovskite-precursor-solutions-for-mult.pdf |

---
Article 

# **Steering perovskite precursor solutions for multijunction photovoltaics** 

|https://doi.org/10.1038/s41586-024-08546-y<br>Received: 11 July 2024|**Shuaifeng Hu**<sup>**1,2,14** ✉</sup>**, Junke Wang**<sup>**1,14**</sup>**, Pei Zhao**<sup>**1,3**</sup>**, Jorge Pascual**<sup>**2,4**</sup>**, Jianan Wang**<sup>**5,6**</sup>**,**<br>**Florine Rombach**<sup>**1**</sup>**, Akash Dasgupta**<sup>**1**</sup>**, Wentao Liu**<sup>**2**</sup>**, Minh Anh Truong**<sup>**2**</sup>**, He Zhu**<sup>**5,6**</sup>**,**<br>**Manuel Kober-Czerny**<sup>**1**</sup>**, James N. Drysdale**<sup>**1**</sup>**, Joel A. Smith**<sup>**1**</sup>**, Zhongcheng Yuan**<sup>**1**</sup>**,**|
|---|---|
|Accepted: 18 December 2024|**Guus J. W. Aalbers**<sup>**7,8**</sup>**, Nick R. M. Schipper**<sup>**7,8**</sup>**, Jin Yao**<sup>**9**</sup>**, Kyohei Nakano**<sup>**10**</sup>**,**<br>|
|Published online: 23 December 2024|**Silver-Hamill Turren-Cruz**<sup>**2,11**</sup>**, André Dallmann**<sup>**12**</sup>**, M. Greyson Christoforo**<sup>**1**</sup>**, James M. Ball**<sup>**1**</sup>**,**<br>**David P. McMeekin**<sup>**1**</sup>**, Karl-Augustin Zaininger**<sup>**1**</sup>**, Zonghao Liu**<sup>**5,6**</sup>**, Nakita K. Noel**<sup>**1**</sup>**, Keisuke Tajima**<sup>**10**</sup>**,**|
|Open access|**Wei Chen**<sup>**5,6**</sup>**, Masahiro Ehara**<sup>**3**</sup>**, René A. J. Janssen**<sup>**7,8,13**</sup>**, Atsushi Wakamiya**<sup>**2** ✉</sup>**& Henry J. Snaith**<sup>**1** ✉</sup>|
|Check for updates||
||Multijunction photovoltaics (PVs) are gaining prominence owing to their superior<br>capability of achieving power conversion efficiencies (PCEs) beyond the radiative<br>limit of single-junction cells<sup>1–8</sup>, for which improving narrow-bandgap (NBG) tin–lead<br>perovskites is critical for thin-film devices<sup>9</sup>. Here, with a focus on understanding the<br>chemistry of tin–lead perovskite precursor solutions, we find that Sn(ii) species<br>dominate interactions with precursors and additives and uncover the exclusive role of<br>carboxylic acid in regulating solution colloidal properties and film crystallization and<br>ammonium in improving film optoelectronic properties. Materials that combine these<br>two functional groups, amino acid salts, considerably improve the semiconducting<br>quality and homogeneity of perovskite films, surpassing the effect of the individual<br>functional groups when introduced as part of separate molecules. Our enhanced tin–<br>lead perovskite layer allows us to fabricate solar cells with PCEs of 23.9%, 29.7%<br>(certified 29.26%) and 28.7% for single-junction, double-junction and triple-junction<br>devices, respectively. Our 1-cm<sup>2</sup>triple-junction devices show PCEs of 28.4% (certified<br>27.28%). Encapsulated triple-junction cells maintain 80% of their initial efficiencies<br>after 860 h maximum power point tracking (MPPT) in ambient. We further fabricate<br>quadruple-junction devices and obtain PCEs of 27.9% with the highest open-circuit<br>voltage of 4.94 V. This work establishes a new benchmark for multijunction PVs.|



Integrating several absorber bandgaps into tandem PVs allows for more effective solar energy conversion, thanks to minimized carrier thermalization losses<sup>4</sup> . With tremendous efforts invested in the field, the leading efficiency of monolithic ‘two-terminal’ perovskite-on-silicon tandem cells is 34.6% (ref. 10), with full-scale industrial modules certified at 26.9% (ref. 11). Parallel to this, tandem PV technology has also provided high efficiencies of 24.2% (ref. 12), 24.9% (ref. 13), 25.2% (ref. 14) and 30.1% (ref. 15) (highest literature report 28.5% (ref. 16)) for perovskite-on-Cu(InGa)Se2, perovskite-on-CuInSe2, organic-on-perovskite and ‘all-perovskite’ counterpart devices, respectively. Among these material combinations, all-perovskite tandems stand out for their superior ability to integrate multijunction cells monolithically<sup>17–21</sup> , thanks to the exceptional bandgap tunability of perovskite materials<sup>22,23</sup> . On the basis of the principle of detailed balance<sup>8</sup> , the double-junction, triple-junction and quadruple-junction cells show 

maximum theoretical efficiencies of about 45%, 52% and 56%, respectively, under 1-sun irradiance<sup>24,25</sup> . A further increase in the number of integrated junctions beyond four, may, however, increase the levelized cost of electricity<sup>26</sup> , as the added fabrication costs may not justify the slight improvement in efficiency, resulting in a longer payback time. In terms of maximizing energy yield under real-world operation, the optimum number of junctions is around five<sup>24</sup> . Targeting four or five junctions should ultimately lead to the highest energy-yielding PVs. For all-perovskite double-junction and multijunction cells, further advancement is largely hindered by the challenging but necessary tin– lead perovskite material ( _E_ g ≈ 1.25 eV), owing to the facile oxidation of Sn(ii) to Sn(iv) and the difficult-to-control crystallization dynamics<sup>27</sup> . The field has extensively investigated suppressing Sn(ii) oxidation using various additives<sup>28–36</sup> or non-oxidizing solvents<sup>37</sup> and improving the performance through surface modifications<sup>9</sup> . By contrast, studies 

> 1Clarendon Laboratory, Department of Physics, University of Oxford, Oxford, UK. 2Institute for Chemical Research, Kyoto University, Gokasho Uji-city, Kyoto, Japan. 3Research Center for Computational Science, Institute for Molecular Science, Okazaki, Japan.<sup>4</sup> Polymat, University of the Basque Country – UPV/EHU, Donostia-San Sebastian, Spain.<sup>5</sup> Wuhan National Laboratory for Optoelectronics, Huazhong University of Science and Technology (HUST), Wuhan, China.<sup>6</sup> Hubei Optics Valley Laboratory, Wuhan, China.<sup>7</sup> Molecular Materials and Nanosystems, Eindhoven University of Technology, Eindhoven, The Netherlands.<sup>8</sup> Institute for Complex Molecular Systems, Eindhoven University of Technology, Eindhoven, The Netherlands.<sup>9</sup> National Thin-Film Cluster Facility for Advanced Functional Materials, Department of Physics, University of Oxford, Oxford, UK.<sup>10</sup> RIKEN Center for Emergent Matter Science (CEMS), Wako, Saitama, Japan.<sup>11</sup> Instituto Universitario de Ciencia de los Materiales (ICMUV), Universitat de València, Paterna, Spain.<sup>12</sup> Institut für Chemie, Humboldt-Universität zu Berlin, Berlin, Germany.<sup>13</sup> Dutch Institute for Fundamental Energy Research, Eindhoven, The Netherlands.<sup>14</sup> These authors contributed equally: Shuaifeng Hu, Junke Wang.<sup>✉</sup> e-mail: shuaifeng.hu@physics.ox.ac.uk; wakamiya@scl.kyoto-u. ac.jp; henry.snaith@physics.ox.ac.uk 

Nature | Vol 639 | 6 March 2025 | **93** 

## Article 

on precursor solution chemistry and their impacts on the crystallization process and film properties are limited. We have previously found that an amino acid salt glycine hydrochloride could preferentially accumulate at the bottom interface, improving device hole extraction<sup>38</sup> . This strategy has been widely used for fabricating efficient single-junction and tandem cells<sup>9</sup> , whereas understanding the core mechanism and how to further adapt this approach to make further gains is underexplored. To understand the role of amino acid salts further and decouple the effect of functional groups from a solution chemistry perspective, herein we select three structurally similar molecules that individually contain ammonium, carboxyl or both motifs on a single molecule, that is, phenethylammonium chloride (PEA), 3-phenylpropionic acid (PPA) and l-phenylalanine hydrochloride (PhA), respectively. 

### **Solution chemistry** 

We use solution nuclear magnetic resonance (NMR) to study perovskite precursor solutions containing PhA, PEA and PPA (Fig. 1 and Supplementary Figs. 1–5). First, we combine PhA with different perovskite precursor components individually. The combination with A-site organic components, that is, MAI and FAI, leads to upfield shifts for the protons in the ammonium and carboxyl groups of PhA (Fig. 1a). The shielding of these protons originates from a slightly higher electronic density around them, implying the presence of H-bonding of PhA, which could be with both perovskite ammonium components and iodide ions. The lower shift found when in the presence of CsI indicates that PhA—and amino acid salts in general—establish favourable interactions with ammonium-based halide precursors (Supplementary Fig. 3). This is probably because of the addition of H-bonding formed between –C=O of PhA and protons from the ammonium cations compared with the inorganic Cs<sup>+</sup> , in which only ionic interactions are present. When PhA is added, the signal at 8.99 ppm, integrating for the four FA ammonium protons, splits into two peaks at 8.98 and 9.19 ppm. These signals correspond to the _cis_ and _trans_ protons, with respect to the C-bound proton, observable owing to the diamagnetic anisotropy present in conjugated systems. We interpret this as a strengthened conjugation and/or interrupted rapid proton transfer between two –NH2 groups of FA<sup>+</sup> owing to the establishment of PhA–FAI interactions. We also observe the same behaviour after the addition of PhA to the FAPbI3 solution (Supplementary Fig. 4). In the case of the FASnI3 solution, however, this splitting is already present before introducing the additives, indicating a stronger interaction between components in Sn-based perovskite precursors in comparison with FAPbI3 solutions. Mixed Sn–Pb perovskite precursor solutions show the two signals of FA ammonium protons in<sup>1</sup> H NMR (Supplementary Fig. 5). We then investigate the interactions of PhA with the metal-based precursors. In the presence of metal halides PbI2 and SnI2, the upfield shift of PhA ammonium protons further increased. The carboxyl signal also shows a variation, notably higher for the case of SnI2. These results indicate that Sn-related chemistry dominates precursor pre-organization in this mixed-metal solution. 

We carry out<sup>119</sup> Sn and<sup>207</sup> Pb NMR experiments, in which we observe invariable Pb<sup>2+</sup> signals but considerable downfield shifts for Sn<sup>2+</sup> signals when in the presence of ammonium and/or carboxyl (Fig. 1b). This effect could be attributed to the inert-pair effect of Pb<sup>2+</sup> with the outermost atomic 6s orbital remaining unshared and the steric activity (more accessible) of the SnX2 (X: halides) compounds according to the valence-shell electron-pair repulsion theory. When adding ammonium and carboxylic acid together, denoted as PEAPPA, to the system, we observe a reduced chemical shift for the Sn(ii) signal compared with the PEA and PPA cases. By contrast, the effects from both functional groups are not masked but summed when combined in a sterically confined structure as an amino acid salt (PhA), suggesting separate and synergistically strengthened roles of each functional group. A chemical downfield shift for Sn<sup>2+</sup> species indicates a reduced electron density 

on these nuclei, suggesting that strong electron-donating species in solution, for example, dimethyl sulfoxide (DMSO), are complexing the metal cation to a lesser degree. We thus speculate that the pre-forming of the H-bonding interaction generated between PEA and PPA weakens the interactions of each other towards the Sn-based species. However, presenting both groups at the same site with a confined geometry will suppress the H-bonding interaction and reduce the entropic cost, enabling strong interactions. Relativistic effects from the combination of Sn/Pb and heavy halogen atoms contribute to chemical shifts and are influenced by several factors, including solvent type and concentration. In this study, we keep these external parameters as constant as possible between the samples, so that we can interpret the chemical shifts to result from changes in the coordination environment of tin cations, as corroborated by the clear shifts in<sup>1</sup> H NMR. Overall, these results indicate the ability of both functional groups to interact with perovskite precursors in solution, and amino acid structures offer the possibility of interaction with several components in the solution and will, on average, be more closely co-located favourably around perovskite precursor complexes. We speculate that this arrangement of molecular components with cation/ligand exchange dynamics around Sn-centred complexes will delay their assembling into perovskite. Accordingly, the larger effects on Sn<sup>2+</sup> over Pb<sup>2+</sup> by amino acid salts make these functionalities ideal for modifying the environment of Sn species and colloidal components in solution to control their heterogeneous nucleation (Supplementary Fig. 6). 

To corroborate the NMR results, we carry out density functional theory (DFT) calculations (Fig. 1c and Supplementary Fig. 6). When modelling PhA with two MAI and FAI species, the structures show interaction energies of −12.05 and −12.13 eV, respectively, mainly originating from the H-bonding interaction, as well as the electrostatic interaction. The interaction energy for PhA with SnI2 is −21.79 eV with the H-bonding and –C=O⋯Sn interactions manifested. The SnI2•DMSO shows an interaction energy of −22.56 eV, suggesting a strong complexing. In SnI2 + PhA, two I atoms show distances of 2.854 and 2.935 Å to the Sn centre, with I2 slightly deflected by the sterically confined ammonium group of the amino acid terminal, decreasing the electron density on Sn. We further calculate the electrostatic potentials of the SnI2•DMSO and SnI2 + PhA species and estimate that the electrostatic potential of the Sn in SnI2 + PhA is more positive compared with the SnI2•DMSO adduct, suggesting a reduced electron density of Sn. Accordingly, these results rationalize the downfield shift of the<sup>119</sup> Sn NMR with the addition of amino acid salt, ammonium, as well as carboxyl into the precursor solutions. 

We conduct dynamic light scattering (DLS) measurements to study the colloidal properties of precursor solutions (Fig. 1d). We observe separate hydrodynamic size distributions that originate from differences in size-dependent Brownian motion in all cases. For the control solution, the colloidal particles evolve to a slightly increased size in the first 30 min and then the distribution of particle sizes widens. For the PhA solution, we observe no considerable size increase and/or change in distribution variations in the first 30 min. From 30 to 60 min, the solution notably evolves into a system dominated by particles with a narrow distribution of larger sizes, and it becomes stable from 60 to 120 min. By contrast, the ammonium PEA solution maintains a broadened distribution of particle sizes except for the distinctive emergence of narrow distributions at 30-min and 90-min points. For the PPA system, we observe a maintained largely broadened size distribution of the colloidal particles in the first 90 min, followed by a substantially narrowed size distribution from 120 min. For the PEAPPA solution, we observe broadened size distributions throughout the entire period, with a narrow distribution occurring only at 30 min. We conclude that the stable chemical interactions built in the solution system between the amino acid salt and precursor materials, especially Sn(ii)-based species, manifestly contribute to the colloidal particle stability and homogeneity, subsequently benefiting the nucleation. 

**94** | Nature | Vol 639 | 6 March 2025 



<!-- Start of picture text -->
a b<br>PhA b PhA b PhA b Control 119Sn 207Pb<br>a b a a a PhA<br>MAI FAI PhA + PbI2 b<br>PEA<br>a PPA<br>PhA + MAI b PhA + FAI b PhA + SnI2 b<br>PEAPPA<br>a a a<br>15 14 13 9 8 7 6 15 14 13 9 8 7 6 15 14 13 9 8 7 6 −100 −200 1,800 1,700 1,600 1,500<br>Chemical shift (ppm) Chemical shift (ppm) Chemical shift (ppm) Chemical shift (ppm)<br>c<br>I1<br>2.854 Å<br>Sn<br>2.935 Å<br>PhA<br>I2<br>A: PhA + 2MAI C: PhA + SnI2<br>C<br>PEA –35 50 30 160<br>B<br>kcal mol –1<br>A SnI2•DMSO SnI2 + PhA<br>0 −6 −12 −18 −24<br>PPA B: PhA + 2FAI Δ E int (eV)  avg(Sn): 10.56  avg(Sn): 88.66<br>d<br>240 min Control PhA PEA PPA PEAPPA<br>120 min<br>90 min<br>60 min<br>30 min<br>10 min<br>0 min<br>10 0 10 1 10 2 10 3 10 4 10 5 10 0 10 1 10 2 10 3 10 4 10 5 10 0 10 1 10 2 10 3 10 4 10 5 10 0 10 1 10 2 10 3 10 4 10 5 10 0 10 1 10 2 10 3 10 4 10 5<br>Size (nm) Size (nm) Size (nm) Size (nm) Size (nm)<br>Scattering intensity (%)<br><!-- End of picture text -->

**Fig. 1 | Chemistry of Sn–Pb perovskite precursor solutions. a** ,<sup>1</sup> H NMR spectra of PhA in combination with different perovskite precursors dissolved in a solvent mixture of DMSO- _d_ 6 and DMF- _d_ 7 (1:3, v:v). **b** ,<sup>119</sup> Sn NMR and<sup>207</sup> Pb NMR spectra showing Sn(ii) and Pb(ii) signals in perovskite precursor solutions containing different additives. **c** , Left, chemical structure of PhA, PEA and PPA. Middle, DFT-calculation-generated potential chemical interaction configurations 

for PhA with MAI, FAI and SnI2 species, along with the bar plot of calculated interaction energies (Δ _E_ int) for A, B and C species. Right, Gaussian-calculated electrostatic potentials ( _φ_ ) are shown for SnI2•DMSO adduct and SnI2 + PhA. The colour bar from red to blue marks the increase of electropositivity. **d** , DLS results for perovskite precursor solutions measured at different points after preparation. 

### **Morphology, crystallinity and electronic properties** 

As observed in scanning electron microscopy (SEM) images, some deposits are visible between the perovskite grain boundaries of the control films (Fig. 2a), which are associated with SnF2 deposits<sup>39</sup> and are less prominent in PhA films. From the cross-sectional view, both the control and PhA films mostly maintained monolithic grains 

with an average thickness of 850 ± 40 and 860 ± 80 nm, respectively (Supplementary Fig. 7). We further investigate minor variations in amino acid structure and deposit films with 4-fluoro-phenylalanine hydrochloride (4FPhA) and 4-methyl-phenylalanine hydrochloride (4MePhA). In general, we observe similar phenomena as PhA (Supplementary Figs. 8–10), indicating a generic role the amino acid salt plays on the morphology of perovskite films, with only 

Nature | Vol 639 | 6 March 2025 | **95** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
a<br>Control PhA PEA PPA PEAPPA<br>b<br>2.0<br>1.5<br>1.0<br>0.5<br>0<br>–2 –1 0 1 2 –2 –1 0 1 2 –2 –1 0 1 2 –2 –1 0 1 2 –2 –1 0 1 2<br>Qxy  (Å –1 ) Qxy  (Å –1 ) Qxy  (Å –1 ) Qxy  (Å –1 ) Qxy  (Å –1 )<br>c d<br>E vac<br>0<br>10 1 PhA + Control 10 1 PEA + Control 10 –1 PPA – Control<br>PhA PhA PhA<br>CB<br>10 –1 PEAPPA 10 –1 PEAPPA 10 –2 PEAPPA −4.0 E WFC –4.21 –4.26 –4.27 –4.30 –4.17<br>PEAPPA PEAPPA 10 –3 PEAPPA −4.5 E F<br>10 –3 10 –3 10 –4 −5.0 0.73 0.91 0.73 0.87 0.75<br>−5.5 E V –5.47 –5.52 –5.53 –5.56 –5.43<br>10 –5 10 –5 10 –5 −6.0 VB<br>0 20 40 60 80 100 120 0 20 40 60 80 100 120 0 20 40 60 80 100 120<br>Sputtering time (s) Sputtering time (s) Sputtering time (s)<br>Control PhA PEA PPAPEAPPA<br> (Å–1 Q ) z<br>Energy (eV)<br>Normalized intensity (a.u.) Normalized intensity (a.u.) Normalized intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Morphology, crystallinity and electronic properties of Sn–Pb perovskite films. a** , Top view and cross-sectional SEM images of control, PhA, PEA, PPA and PEAPPA perovskite films fabricated on PEDOT:PSS-coated FTO glass substrates. Scale bars, 500 nm. **b** , 2D GIWAXS patterns examined at a grazing incidence angle of 0.4° for perovskite films. The halo at the scattering vector of 1 and 2 Å<sup>−1</sup> comes from the diffraction of (100) and (200) peaks, respectively. The patterns are presented on the same scale. The partial 

scattering ring at _q_ = 0.9 Å<sup>−1</sup> originates from residual PbI2 in films. The corresponding 1D XRD patterns are also provided in Supplementary Fig. 13. **c** , ToF-SIMS depth profile of PhA<sup>+</sup> , PEA<sup>+</sup> and PPA<sup>−</sup> ions for control and modified films. **d** , Energy-level diagram of perovskite films. Fermi level ( _E_ F) and valence band (VB) maximum ( _E_ V) are shown aligned at the vacuum level ( _E_ vac). Conduction band (CB) minimum ( _E_ C) is calculated from _E_ V + _E_ gap (bandgap, 1.26 eV). The UPS spectra are given in Supplementary Fig. 22. a.u., arbitrary units. 

weak influence from extra non-protic substituents on the phenyl core. Notably, the exposure of different facets of perovskite grains seems to occur on increasing the concentration of amino acid salts, which we interpret to be caused by changed facet surface energy, suggesting the successful attachment of molecules to grain surfaces. 

The PEA films form dendritic structures at the top surfaces with increased heterogeneity and ‘wrinkled’ surfaces, resulting in increased thickness deviation, 950 ± 450 nm (Fig. 2a and Supplementary Fig. 11). For PPA films, we observe a considerably increased number of bright deposits at surfaces primarily along grain boundaries. Furthermore, we find ‘meso-voids’ at buried interfaces, despite maintaining good thickness uniformity, 870 ± 60 nm. Notably, as viewed by the eye from the glass side of films, these voids are apparent as a ‘haziness’ to the substrate (Supplementary Fig. 12). With a mixture of ammonium and carboxyl, PEAPPA, more needle-shaped species are formed and monolithic grains are less well maintained, with less evident voids at the bottom region and fewer hazy spots, giving a thickness of 940 ± 190 nm. These results indicate that the ammonium and carboxyl moieties in the single molecule led to superior film homogeneity and morphology compared with films modified solely with the ammonium or carboxyl as well as their mixture. 

We conduct one-dimensional (1D) X-ray diffraction (XRD) and two-dimensional (2D) grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements (Fig. 2b and Supplementary Fig. 13). From the XRD results, we observe greater than threefold enhancement in the (100) peak intensity of PhA films compared with the control. The PEA 

films show a similar peak intensity as the control, whereas the PPA film is close to that of the PhA. The PEAPPA films show a slightly reduced peak intensity compared with PPA films but substantially higher than the control. Interrogating the 2D GIWAXS results, we find that the PhA films exhibit reflections in concentrated regions of the q-space as compared with the control. With the sole addition of ammonium, the PEA films show a slightly enhanced scattering at the direction of about 30° out of the Qxy plane. However, the carboxyl gives the films a preferential orientation in both in-plane and out-of-plane directions. This leads us to conclude that the carboxyl group plays a critical structure-directing role in modifying the growth of perovskite crystals, whereas the ammonium contributes weakly. 

We use time-of-flight secondary-ion mass spectrometry (ToF-SIMS) to track the distribution of additive ions, that is, PhA<sup>+</sup> , PEA<sup>+</sup> and PPA<sup>−</sup> (Fig. 2c). The results show that introduced PhA<sup>+</sup> cations are mainly distributed at the perovskite surface regions, with a particular evident accumulation at the buried interface. By contrast, PEA<sup>+</sup> cations are found to be much more homogeneously distributed. Note that the PEA detected from PhA films is most probably attributed to PhA fragments without –COOH, caused by the primary ion beam excitation. Notably, we observe a higher intensity from the PPA molecule at the bottom region of PPA-containing films, whereas the detection limit of this technique means that we cannot exclude the presence of the molecule at grain boundaries and top surfaces. We infer that the preferential accumulation of amino acid ligands at the bottom region of films may be governed by the carboxyl moiety of molecules with less contribution from the ammonium. 

**96** | Nature | Vol 639 | 6 March 2025 



<!-- Start of picture text -->
a b c<br>Control QFLS (eV)0.90 PhA QFLS (eV)0.90 10 0 10 –4<br>0.88 0.88 10 –5<br>10 −1<br>0.86 0.86<br>10 –6 Control<br>0.84 0.84 PhA<br>10 −2<br>0.82 0.82 10 –7 PEA<br> Control  PEA PPA<br>0.80 0.80  PhA  PPA  PEAPPA PEAPPA<br>10 −3 10 –8<br>0 3 6 9 12 10 –8 10 –7 10 –6 10 –5<br>Time (μs) Time (s)<br>PEA QFLS (eV) PPA QFLS (eV) d e<br>0.90 0.90<br>10 1 10 1<br>0.88 0.88<br>0.86 0.86<br>0.84 0.84 10 0 10 0<br>PhA<br>0.82 0.82<br>Control<br>0.80 0.80 Fit<br>10 −1 10 −1<br>10 15 10 16 10 17 10 18<br>Absorbed photon flux (cm –2  s –1 )<br>f g<br>PEAPPA QFLS (eV)0.90 Control E CB e – 35<br>0.88 PhA 28<br>PEA<br>0.86 PPA t shallow Auger 21<br>PEAPPA<br>0.84 t deep 14<br>0.82 7 Control<br>0.80 E VB PhA<br>0<br>−0.04 0 0.04 0.08 h + 0 0.2 0.4 0.6 0.8 1.0<br>Centre-normalized QFLS QFLS (eV)<br>Control PhA PEA PPAPEAPPA<br>Gen. Rad.<br>Differential lifetime (s)<br>PL intensity (normalized)<br>PLQE (%) PLQE (%)<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 3 | Optoelectronic property characterizations of Sn–Pb perovskite films. a** , QFLS mapping calculated from 2 mm × 2 mm PLQE images for the perovskite films recorded at _V_ OC conditions under illumination (equivalent to 1-sun intensity for a 1.26-eV bandgap) with the set-up reported previously<sup>47</sup> . The centre-normalized QFLS are plotted to evaluate spatial QFLS variations. **b** , TRPL of the films. The samples are illuminated from the glass side with a 635-nm centre wavelength laser (4.9 nJ cm<sup>−2</sup> pulse<sup>−1</sup> ). **c** , The differential lifetime 

_τ_ diff ( _t_ ). **d** , PLQE of different perovskite films illuminated with a 532-nm laser at a 1-sun equivalent intensity for a 1.26-eV bandgap. Data are mean ± s.e.m. **e** , Intensity-dependent PLQE of control and PhA films. **f** , Generation and recombination pathways in a two-trap level SRH model. _t_ shallow and _t_ deep represent shallow-level and deep-level carrier trapping states, respectively. The detrapping and Auger processes are also presented. **g** , Pseudo _J_ – _V_ curves reconstructed from intensity-dependent PLQE measurements. 

We have performed DFT calculations to study the possible defect passivation effect (Supplementary Figs. 14–21). When the PhA molecule is applied to iodide vacancies centred with Sn and Pb, that is, VI(Sn) and VI(Pb), the systems are stabilized with energies of −1.60 (VI(Sn)) and −1.74 eV (VI(Pb)). The newly established Sn–O and Pb–O covalent bonds give lengths of 2.905 and 3.039 Å, respectively. The substitution of –F and –CH3 in PhA slightly increases resultant binding energies. PhA can also coordinate with A-site vacancies (V(A)) by means of the ammonium group, with energies of about −1.28 eV. Similarly, the PEA and PPA molecules also show individual ability to passivate A-site and X-site vacancies. Apart from further stabilization with PhA, as for the single VI(Sn/Pb) defect, the bulky amino acid terminal of PhA slightly deforms the lattice. Thus, we construct a two-defect system, containing one A-site vacancy accompanied by one adjacent iodide vacancy. PhA<sup>+</sup> is modelled to the A-site vacancy while the undercoordinated Sn/Pb atoms form ionic bonding with chloride from PhA, enabling considerably decreased energies ranging from −2.27 to −2.80 eV. This suggests that these two-defect systems can be greatly stabilized by PhA and the substitution effect of –F and –CH3 is like the trend observed in single-defect systems. The superior passivation effect of amino acid salts largely originates from the numerous behaviours of functional 

units, which allow these molecules to passivate both donor and acceptor types of defect in a mutually reinforced manner. The effects are also reflected in other film electronic properties (Fig. 2d, Supplementary Figs. 22 and 23 and Supplementary Table 1). 

### **Optoelectronic properties** 

We map out the quasi-Fermi level splitting (QFLS) by calculating the imaged absolute photoluminescence quantum efficiency (PLQE; Fig. 3a). Compared with the control, the PhA films present substantially increased QFLS over the entire examined region. For PEA films, the image suggests an enhanced QFLS, whereas the homogeneity is worse as quantified by the broadening of the peak in centre-normalized QFLS plots. The PPA films show reduced QFLS values but a comparable QFLS homogeneity with the control. When the film is modified with a mixture of ammonium and carboxyl, PEAPPA, we observe increased heterogeneity compared with the control, despite an improvement in QFLS, indicating a greater variation in the optoelectronic quality. 

The interpretation of photoluminescence (PL) transient decay curves gives PL lifetimes of 2.2, 9.5, 6.5, 0.7 and 9.4 µs for control, PhA, PEA, PPA and PEAPPA films, respectively (Fig. 3b). The PEAPPA films show 

Nature | Vol 639 | 6 March 2025 | **97** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
b<br><!-- End of picture text -->



<!-- Start of picture text -->
a b c<br>35 1J-Fwd.<br>1J-Rev.<br>Ag<br>BCP 28 2J-Rev.<br>C60 2J-Fwd.<br>NBG 1.26 eV 21 3J-Rev.<br>3J-Fwd.<br>PEDOT:PSS<br>14 4J-Rev.<br>FTO<br>4J-Fwd.<br>7<br>Ag<br>SnOx 0<br>C60 0 1 2 3 4 5<br>NBG 1.26 eV Voltage (V)<br>PEDOT:PSS<br>SnOx/IZO d<br>PCBM 30<br>28.3%<br>WBG 1.77 eV 28.2%<br>SAM 27.4%<br>FTO<br>24<br>23.6%<br>Ag 1J<br>SnOx 2J<br>C60 3J<br>NBG 1.26 eV 4J<br>18<br>PEDOT:PSS<br>0 10 20 30 40<br>SnOx/IZO<br>Time (s)<br>C60<br>MBG 1.61 eV<br>NiO x /SAM e f<br>SnOx/IZO 16 115 mA cm –2 12<br>PCBM<br>WBG 1.97 eV<br>12<br>Measured<br>SAM 8<br>Matched current,<br>FTO 8 no irreversible capacity loss<br>95%  V OC limit<br>4 J SC (mA cm –2 )  10.3 11.0 11.0<br>Ag 4 V OC (V) 3.39 3.46 3.76<br>SnOx 0.5 FF              0.82 0.82 0.83<br>C60 0 0 PCE (%) 28.7 31.3  34.4<br>NBG 1.26 eV 500 700 900 1,100 0 1 2 3 4<br>PEDOT:PSS Wavelength (nm) Voltage (V)<br>SnOx/IZO<br>C60 g<br>MBG 1.55 eV 1.0<br>NiO x /SAM<br>0.8<br>SnOx/IZO<br>PCBM T 80 = 860 h<br>0.6<br>WBG 1.80 eV<br>NiO x /SAM 0.4<br>SnOx/IZO<br>0.2<br>PCBM Encapsulated, simulated AM 1.5 G, RT, ~45% RH<br>WBG 2.26 eV 0<br>SAM 0 200 400 600 800 1,000<br>FTO Time (h)<br>–2Current density (mA cm)<br>PCE (%)<br>–1EL intensity ()W nmμ<br>–2)Current density (mA cm<br>Normalized PCE<br><!-- End of picture text -->

**Fig. 4 | Solar cell devices. a** , Device configuration (top to bottom). **b** , Crosssectional SEM images (top to bottom). Scale bars, 1 µm. _J_ – _V_ curves ( **c** ) and the steady-state output ( **d** ) of optimized single-junction (1J), double-junction (2J), triple-junction (3J) and quadruple-junction (4J) cells. ‘Rev.’ and ‘Fwd.’ represent reverse ( _V_ OC to _J_ SC) and forward ( _J_ SC to _V_ OC) _J_ – _V_ scan directions, respectively. Details of the device stacks are provided in Methods. The performance for the 0.25-cm<sup>2</sup> tandem cells is shown here, whereas the results for 1-cm<sup>2</sup> tandems are provided in Supplementary Fig. 41. **e** , EQEEL spectra of one representative triple-junction cell measured as a function of injected current density ranging from 0.5 to 115 mA cm<sup>−2</sup> . The emission peaks of WBG (1.97 eV), MBG (1.61 eV) and 

NBG subcells are centred at about 620, 762 and 1,005 nm, respectively. Inset, photograph of the emission from a 1-cm<sup>2</sup> cell under a forward bias of about 3.5 V. **f** , Experimental and reconstructed _J_ – _V_ curves of the triple-junction device from the simulated EQE at different optical conditions and assuming that a _V_ OC of 95% detailed-balance limit is achieved in each subcell. **g** , MPPT stability of an encapsulated triple-junction device, measured in ambient air at room temperature (RT) with a relative humidity (RH) of about 45% under simulated AM 1.5 G illumination. Insets, photographs of the aged cell with the top contact of Cr (2.5 nm)/Au (20 nm)/Ag (100 nm). The initial PCE of the triple-junction cells is 26.5%, with _J_ – _V_ curves provided in Supplementary Fig. 59. 

**98** | Nature | Vol 639 | 6 March 2025 

**Table 1 | PV parameters of the best-performing multijunction cells** 

|**Cells**|**Device area (cm**<sup>**2**</sup>**)**|**Scan direction**<sup>**a**</sup>|**_V_OC (V)**|**_J_SC (mA cm**<sup>**−2**</sup>**)**|**FF**|**PCE (%)**|**Steady-state PCE (certified, %)**<sup>**b**</sup>|**Best****_V_OC (V)**|
|---|---|---|---|---|---|---|---|---|
|Double junction|0.25|Rev.|2.20|16.4|0.81|29.2|28.3|2.22|
|||Fwd.|2.18|16.3|0.78|27.7|||
||1|Rev.|2.18|16.6|0.79|28.4|28.2|2.21|
|||Fwd.|2.16|16.5|0.77|27.3|||
|Triple junction|0.25|Rev.|3.39|10.3|0.82|28.7|28.2|3.46|
|||Fwd.|3.37|10.3|0.81|28.2|||
||1|Rev.|3.42|10.3|0.81|28.4|28.0 (27.28)|3.46|
|||Fwd.|3.41|10.3|0.79|28.0|||
|Quadruple junction|0.25|Rev.|4.87|7.0|0.81|27.9|27.4|4.94|
|||Fwd.|4.83|7.0|0.77|26.3|||
||1|Rev.|4.90|7.6|0.73|27.4|26.9|4.90|
|||Fwd.|4.86|7.6|0.72|26.8|||



> a‘Rev.’ and ‘Fwd.’ represent reverse ( _V_ OC to _J_ SC) and forward ( _J_ SC to _V_ OC) _J_ – _V_ scan directions, respectively. bThe certified PCE of double-junction cells with the 0.0498-cm2 active area is 29.26%. 

an ultra-long lifetime similar to that of PhA. Extremely long PL lifetimes have historically been interpreted to indicate very low amounts of trap-assisted recombination and hence defect densities. As recently highlighted<sup>40</sup> , however, ultra-long PL lifetimes probably originate from a population of carriers trapped in shallow-level defect states, which cause delayed PL when released from traps back into the bands. These carriers are expected to dominate the population in Sn–Pb perovskites after photoexcitation<sup>41</sup> , making the single lifetime value less physically meaningful. We then calculate the differential lifetime ( _τ_ diff) from the time-resolved photoluminescence (TRPL) decays<sup>42,43</sup> (Fig. 3c). After the pulse, we observe a fast increase in _τ_ diff for control, PEA, PPA and PEAPPA films. By contrast, the _τ_ diff remains relatively constant for PhA films, with no initial short-lifetime component. Higher-order recombination processes such as Auger or radiative recombination are unlikely to greatly contribute to this difference in early-time _τ_ diff, as we apply a low laser fluence for measurements and do not expect modified films to have markedly different high-order recombination rates. Instead, the lack of faster initial recombination for PhA films would be consistent with reduced trap-filling at the start of the decay, which could be because of either a lower density or carrier capture cross-section of traps. The PPA films show similar _τ_ diff evolution as the control, whereas PEAPPA films are closer to PEA films with a longer decay time. This suggests that the PEA predominantly governs the optoelectronic property of PEAPPA films. 

We conduct macroscopic PLQE measurements under 1-sun equivalent intensity (Fig. 3d). The best PLQE value for PhA films is 12.7%, with an average value of 10.6 ± 1.35%, consistent with the reduced trap-assisted recombination suggested by TRPL results. By contrast, the best PLQE for control, PEA, PPA and PEAPPA films are about one order of magnitude smaller, with values of 1.75%, 1.14%, 0.94% and 2.48%, respectively. 

We fit the PLQE results measured at a range of excitation intensities with a Shockley–Read–Hall type model with one shallow and one deep electron trap<sup>44</sup> (Fig. 3e,f) as a function of absorbed photons, allowing _k_ trap,shallow and _k_ trap,deep to vary between two samples (Supplementary Table 2). On the basis of fitting, the _k_ trap,shallow values decrease from 2.3 × 10<sup>6</sup> to 9.6 × 10<sup>4</sup> s<sup>−1</sup> and the _k_ trap,deep values decrease from 4.7 × 10<sup>4</sup> to 1.4 × 10<sup>4</sup> s<sup>−1</sup> comparing PhA samples with control. We expect this reduction in trapping rate to result from the reduced density of both deep and shallow defects. This is consistent with the constant and high _τ_ diff observed in PhA films, characteristic of both reduced trap-filling at the beginning of the TRPL decay and reduced emission from shallow traps at later times of the decay, with the latter inferred from the smaller _τ_ diff than some of the other samples at longer times. 

Using intensity-dependent PLQE results, we generate pseudo current density–voltage (p _J_ – _V_ ) curves (Fig. 3g). The curves suggest that PhA-films-based devices could generate a pseudo- _V_ OC of 0.93 V (94% of the radiative limit at 1.26-eV bandgap<sup>45</sup> ) and a pseudo-fill factor (FF) of 0.87 (p _V_ OC × pFF is about 93% of the limit), which are considerably higher than the values of the control with p _V_ OC of 0.88 V and pFF of 0.85. Assuming a generally achievable current density obtained from actual cells, 32.5 mA cm<sup>−2</sup> , the pseudo-PCE for control and PhA devices is 24.7% and 26.5%, respectively. 

### **PV device performance** 

We fabricate single-junction devices with structures shown in Fig. 4a,b. We first examine the effect and generic role of amino acid salts, that is, PhA, 4FPhA and 4MePhA, with accordingly modified PV devices. Compared with control devices, the amino-acid-salt-based cells show consistently improved PCEs that mainly originate from the boosted _V_ OC (Supplementary Figs. 24–29), benefiting partially from slightly suppressed sub-bandgap states (Supplementary Fig. 30). Also, PhA devices outperform PEA, PPA and PEAPPA cells (Supplementary Figs. 31 and 32). We thus obtain the best PCE value of 23.9% from the forward _J_ – _V_ scan ( _V_ OC: 0.90 V, _J_ SC: 33.07 mA cm<sup>−2</sup> , FF: 0.80), with the best _V_ OC of 0.91 V (Fig. 4c,d and Supplementary Figs. 33–36) and steady-state PCE of 23.4% (Supplementary Fig. 37). The highest external quantum efficiency (EQE) value of PhA devices reaches 92.5% at approximately 680 nm (Supplementary Fig. 38), with an integrated _J_ SC of 32.7 mA cm<sup>−2</sup> . Under ‘shelf-storage’ conditions (International Summit on Organic and Hybrid Photovoltaics Stability (ISOS)-D-1)<sup>46</sup> (Supplementary Fig. 39), the unencapsulated control, PhA, 4FPhA and 4MePhA devices maintain 82%, 84%, 87% and 93% of their initial performances, respectively, after 2,200 h. 

We fabricate double-junction and triple-junction devices after optimizing a series of neat Pb perovskites. Schematics of the precise layers used in devices and their SEM images are shown in Fig. 4a,b. Device parameters for the champion cells are provided in Table 1. When scanned from _V_ OC to _J_ SC, the double-junction cells show PCE values of up to 29.2% and 28.4% for 0.25-cm<sup>2</sup> and 1-cm<sup>2</sup> devices, respectively (Fig. 4c,d and Supplementary Figs. 40 and 41). The best _V_ OC obtained for this type of device is 2.22 V, close to the summed _V_ OC of single-junction perovskite solar cells, 2.25 V (Supplementary Figs. 42 and 43). The _J_ SC estimated by integrating EQE spectra is 16.5 and 15.9 mA cm<sup>−2</sup> for wide-bandgap (WBG) and NBG subcells, respectively (Supplementary Fig. 44). For triple-junction cells, the 0.25-cm<sup>2</sup> and 1-cm<sup>2</sup> devices also show high PCE values of up to 28.7% and 28.4% (27.28% certified 

Nature | Vol 639 | 6 March 2025 | **99** 

## Article 

by the Japan Advanced Institute of Science and Technology (AIST), respectively, with the best _V_ OC of 3.46 V, slightly lower than the summed voltage 3.54 V (Fig. 4c,d and Supplementary Figs. 41 and 45). The _J_ SC estimated by integrating the EQE spectra is 11.5, 9.1 and 10.5 mA cm<sup>−2</sup> for the WBG, middle-bandgap (MBG) and NBG subcells, respectively (Supplementary Fig. 46). Our measured _J_ SC of 10.3 mA cm<sup>−2</sup> is extremely close to the value of 10.2 mA cm<sup>−2</sup> from the AIST, giving a great level of confidence in the accuracy of our in-house measurements. We note that our Sn–Pb perovskite fabrication recipe is also highly reliable and reproducible (Supplementary Figs. 47 and 48), having been reproduced in laboratories at Oxford, Kyoto and Wuhan. Double-junction cells fabricated in Wuhan have been verified by an external laboratory (SIMIT, China), demonstrating a certified PCE of 29.76% (steady-state 29.26%; Supplementary Fig. 49). As a proof-of-concept, the 0.25-cm<sup>2</sup> and 1-cm<sup>2</sup> quadruple-junction devices show PCEs of up to 27.9% and 27.4%, respectively, with the best _V_ OC of 4.94 V (Fig. 4c,d and Supplementary Figs. 41, 50 and 51). Compared with previous reports, our tandem cells demonstrate superior efficiencies across all fabricated junctions, particularly when accounting for our large cell area (Supplementary Fig. 52). 

We select triple-junction cells to measure the electroluminescence external quantum efficiency (EQEEL) (Fig. 4e, Supplementary Fig. 53 and Supplementary Table 3). Under an injection current density of about 9.4 mA cm<sup>−2</sup> , the device shows EQEEL of up to 1.95%, with values of 0.01%, 0.48% and 1.46% from 1.97-eV, 1.61-eV and 1.26-eV subcells, respectively. Notably, the EL-derived QFLS values are very close to those measured for individual single-junction and integrated triple-junction devices, suggesting that only a small _V_ OC loss of about 30 mV is introduced in interconnecting layers of the multijunction device stack. With this _V_ OC loss omitted and a matched current, the triple-junction cells should generate greater than 31% PCEs (Fig. 4f and Supplementary Figs. 54–57). The potential PCE of triple-junction devices can be greater than 34% under the context of a successful gain of 95% radiative voltage of each subcell. We note that our 1.26-eV, 1.55-eV, 1.61-eV, 1.77-eV and 1.80-eV cells achieve more than 90% of the _V_ OC radiative limit (Supplementary Fig. 58). Although 1.97-eV and 2.26-eV cells show record-low voltage losses, they remain more loss than narrower-gap junctions and hence should be the future focus. 

We conduct MPPT at room temperature (ISOS-L-1)<sup>46</sup> (Fig. 4g and Supplementary Fig. 59), giving a _T_ 80 of 860 h for triple-junction cells. When the cells are stressed under 85 °C in dark conditions (ISOS-D-2)<sup>46</sup> , they exhibit reasonably good stability, maintaining about 70% on average of their initial efficiencies after more than 1,200 h (Supplementary Figs. 60 and 61). However, when cells are stressed under more accelerated conditions, 85 °C and 1 sun at _V_ OC (ISOS-L-2)<sup>46</sup> , we observe a rapid degradation, with _T_ 80 as short as 5 h. These results indicate that, although our multijunction cells are reasonably stable operating at ambient conditions and when heated in the dark, further improvements are required to reach suitable stability under combined temperature and light. Overall, our work represents a milestone, in which large-area triple-junction cells closely match the efficiency of double-junction cells. We expect triple-junction or quadruple-junction cells to lead the efficiency race for thin-film tandem devices shortly. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-024-08546-y. 

1. Eperon, G. E., Hörantner, M. T. & Snaith, H. J. Metal halide perovskite tandem and multiplejunction photovoltaics. _Nat. Rev. Chem._ **1** , 0095 (2017). 

2. Leijtens, T., Bush, K. A., Prasanna, R. & McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. _Nat. Energy_ **3** , 828–838 (2018). 

3. Duan, L. et al. Stability challenges for the commercialization of perovskite–silicon tandem solar cells. _Nat. Rev. Mater._ **8** , 261–281 (2023). 

4. Wang, R. et al. Prospects for metal halide perovskite-based tandem solar cells. _Nat. Photon._ **15** , 411–425 (2021). 

5. Aydin, E. et al. Pathways toward commercial perovskite/silicon tandem photovoltaics. _Science_ **383** , eadh3849 (2024). 

6. Brinkmann, K. O. et al. Perovskite–organic tandem solar cells. _Nat. Rev. Mater._ **9** , 202–217 (2024). 

7. Isikgor, F. H. et al. Molecular engineering of contact interfaces for high-performance perovskite solar cells. _Nat. Rev. Mater._ **8** , 89–108 (2023). 

8. Shockley, W. & Queisser, H. J. Detailed balance limit of efficiency of p–n junction solar cells. _J. Appl. Phys._ **32** , 510–519 (1961). 

9. Hu, S. et al. Narrow bandgap metal halide perovskites for all-perovskite tandem photovoltaics. _Chem. Rev._ **124** , 4079–4123 (2024). 

10. LONGi. 34.6%! Record-breaker LONGi once again sets a new world efficiency for siliconperovskite tandem solar cells. _LONGi News_ https://www.longi.com/en/news/2024-snecsilicon-perovskite-tandem-solar-cells-new-world-efficiency/ (2024). 

11. Oxford PV. Oxford PV debuts residential solar module with record-setting 26.9% efficiency. _Oxford PV_ https://www.oxfordpv.com/news/oxford-pv-debuts-residential-solar-modulerecord-setting-269-efficiency (2024). 

12. Jošt, M. et al. Perovskite/CIGS tandem solar cells: from certified 24.2% toward 30% and beyond. _ACS Energy Lett._ **7** , 1298–1307 (2022). 

13. Ruiz-Preciado, M. A. et al. Monolithic two-terminal perovskite/CIS tandem solar cells with efficiency approaching 25%. _ACS Energy Lett._ **7** , 2273–2281 (2022). 

14. Wu, S. et al. Redox mediator-stabilized wide-bandgap perovskites for monolithic perovskite-organic tandem solar cells. _Nat. Energy_ **9** , 411–421 (2024). 

15. All-perovskite tandem cells reach a certified efficiency of up to 30.1%. _Renshuo Solar_ (24 May 2024); https://mp.weixin.qq.com/s/3Ggl6caa-TiTABNq0sFcbQ. 

16. Lin, R. et al. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. _Nature_ **620** , 994–1000 (2023). 

17. Wang, J. et al. 16.8% monolithic all-perovskite triple-junction solar cells via a universal two-step solution process. _Nat. Commun._ **11** , 5254 (2020). 

18. McMeekin, D. P. et al. Solution-processed all-perovskite multi-junction solar cells. _Joule_ **3** , 387–401 (2019). 

19. Hörantner, M. T. et al. The potential of multijunction perovskite solar cells. _ACS Energy Lett._ **2** , 2506–2513 (2017). 

20. Wang, J. et al. Halide homogenization for low energy loss in 2-eV-bandgap perovskites and increased efficiency in all-perovskite triple-junction solar cells. _Nat. Energy_ **9** , 70–80 (2023). 

21. Wang, Z. et al. Suppressed phase segregation for triple-junction perovskite solar cells. _Nature_ **618** , 74–79 (2023). 

22. McMeekin, D. P. et al. A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151–155 (2016). 

23. Hao, F., Stoumpos, C. C., Chang, R. P. & Kanatzidis, M. G. Anomalous band gap behavior in mixed Sn and Pb perovskites enables broadening of absorption spectrum in solar cells. _J. Am. Chem. Soc._ **136** , 8094–8099 (2014). 

24. Peters, I. M., Gallegos, C. D. R., Lüer, L., Hauch, J. A. & Brabec, C. J. Practical limits of multijunction solar cells. _Prog. Photovolt._ **31** , 1006–1015 (2023). 

25. Philipps, S. P. & Bett, A. W. III-V multi-junction solar cells and concentrating photovoltaic (CPV) systems. _Adv. Opt. Technol._ **3** , 469–478 (2014). 

26. Li, Z. Q. et al. Cost analysis of perovskite tandem photovoltaics. _Joule_ **2** , 1559–1572 (2018). 

27. Hu, S., Smith, J. A., Snaith, H. J. & Wakamiya, A. Prospects for tin-containing halide perovskite photovoltaics. _Precis. Chem._ **1** , 69–82 (2023). 

28. Chen, Q. et al. Unveiling roles of tin fluoride additives in high-efficiency low-bandgap mixed tin–lead perovskite solar cells. _Adv. Energy Mater._ **11** , 2101045 (2021). 

29. Nakamura, T. et al. Sn(IV)-free tin perovskite films realized by in situ Sn(0) nanoparticle treatment of the precursor solution. _Nat. Commun._ **11** , 3008 (2020). 

30. Zhang, W. et al. Lead-lean and MA-free perovskite solar cells with an efficiency over 20%. _Joule_ **5** , 2904–2914 (2021). 

31. Li, Z. et al. 4-Hydrazinobenzoic-acid antioxidant for high-efficiency Sn–Pb alloyed perovskite solar cells. _Energy Technol._ **10** , 2200217 (2022). 

32. Wang, C. et al. Self-repairing tin-based perovskite solar cells with a breakthrough efficiency over 11%. _Adv. Mater._ **32** , 1907623 (2020). 

33. Liu, H. et al. Modulated crystallization and reduced _V_ OC deficit of mixed lead–tin perovskite solar cells with antioxidant caffeic acid. _ACS Energy Lett._ **6** , 2907–2916 (2021). 

34. Wen, Q. et al. All-inorganic CsPb1-xSnxI2Br perovskites mediated by dicyandiamide additive for efficient 4-terminal tandem solar cell. _Chem. Eng. J._ **452** , 139697 (2023). 

35. He, D. et al. Accelerated redox reactions enable stable tin-lead mixed perovskite solar cells. _Angew. Chem. Int. Ed._ **63** , e202317446 (2023). 

36. Yu, D. et al. Electron-withdrawing organic ligand for high-efficiency all-perovskite tandem solar cells. _Nat. Energy_ **9** , 298–307 (2024). 

37. Di Girolamo, D. et al. Solvents for processing stable tin halide perovskites. _ACS Energy Lett._ **6** , 959–968 (2021). 

38. Hu, S. et al. Optimized carrier extraction at interfaces for 23.6% efficient tin–lead perovskite solar cells. _Energy Environ. Sci._ **15** , 2096–2107 (2022). 

39. Liao, W. et al. Lead-free inverted planar formamidinium tin triiodide perovskite solar cells achieving power conversion efficiencies up to 6.22%. _Adv. Mater._ **28** , 9333–9340 (2016). 

40. Yuan, Y. et al. Shallow defects and variable photoluminescence decay times up to 280 µs in triple-cation perovskites. _Nat. Mater._ **23** , 391–397 (2024). 

41. Meggiolaro, D., Ricciarelli, D., Alasmari, A. A., Alasmary, F. A. S. & De Angelis, F. Tin versus lead redox chemistry modulates charge trapping and self-doping in tin/lead iodide perovskites. _J. Phys. Chem. Lett._ **11** , 3546–3556 (2020). 

**100** | Nature | Vol 639 | 6 March 2025 

42. Krogmeier, B., Staub, F., Grabowski, D., Rau, U. & Kirchartz, T. Quantitative analysis of the transient photoluminescence of CH3NH3PbI3/PC61BM heterojunctions by numerical simulations. _Sustain. Energy Fuels_ **2** , 1027–1034 (2018). 

43. Krückemeier, L., Krogmeier, B., Liu, Z., Rau, U. & Kirchartz, T. Understanding transient photoluminescence in halide perovskite layer stacks and solar cells. _Adv. Energy Mater._ **11** , 2003489 (2021). 

44. Kirchartz, T., Márquez, J. A., Stolterfoht, M. & Unold, T. Photoluminescence-based characterization of halide perovskites for photovoltaics. _Adv. Energy Mater._ **10** , 1904134 (2020). 

45. Rühle, S. Tabulated values of the Shockley–Queisser limit for single junction solar cells. _Sol. Energy_ **130** , 139–147 (2016). 

46. Khenkin, M. V. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. _Nat. Energy_ **5** , 35–49 (2020). 

47. Dasgupta, A. et al. Visualizing macroscopic inhomogeneities in perovskite solar cells. _ACS Energy Lett._ **7** , 2311–2322 (2022). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/. 

© The Author(s) 2024 

Nature | Vol 639 | 6 March 2025 | **101** 

## Article **Methods** 

#### **Materials** 

Unless otherwise stated, all materials were used as received without further purification. Methylammonium iodide (MAI, >99.0%), formamidinium iodide (FAI, >98.0%) and formamidinium bromide (FABr, >99.99%) were purchased from Greatcell Solar Materials. Bathocuproine (BCP, >99.0%), lead iodide (PbI2, 99.99%, trace metals basis), lead(ii) bromide (PbBr2, >98.0%), lead(ii) chloride (PbCl2, >99.5%), methylamine hydrobromide (MABr, >98%), methylamine hydrochloride (MACl, >98.0%), piperazine (anhydrous, PP, >98.0%), l-phenylalanine (Phe, >98.0%), 4-methyl-phenylalanine (4MePhe, >98.0%), 2-phenylethylamine hydrochloride (PEA, >98.0%), PPA (>98.0%), [2-(3,6-dimethoxy-9H-carb azol-9-yl)ethyl]phosphonic acid (MeO-2PACz), 2-phenylethylamine hydroiodide (PEAI, >98.0%) and hydrochloride acid solution (35–37 wt% in water) were purchased from Tokyo Chemical Industry Co., Ltd. (TCI). Caesium iodide (CsI, 99.999%, metals basis) was purchased from Alfa Aesar. Ammonium thiocyanate (NH4SCN, 99.99% trace metals basis), tin fluoride (SnF2, 99%), tin iodide (SnI2, beads, 99.99%, trace metals basis), Sn(0) powder (<45 µm particle size, 99.8% trace metals basis), 4-fluoro-d-phenylalanine hydrochloride (4FPhA, 99%), C60 pyrrolidine tris-acid (97%), propane-1,3-diammonium iodide (PDAI2, >98%), poly(ethyleneimine) solution (PEI, 50 wt% in H2O) and poly(methyl methacrylate) (PMMA, >98%) were purchased from Sigma-Aldrich Co., Ltd. (Sigma-Aldrich). Poly(3,4-ethylenedioxythiophene):poly (styrene sulfonate) (PEDOT:PSS) aqueous solution (Clevios PVP AI 4083) was purchased from Heraeus Co., Ltd. Fullerene C60 (sublimed, 99.99%) was purchased from ATR Company. [6,6]-Phenyl-C61-butyric acid methyl ester (PC61BM, >99%) was purchased from Ossila. (2-(4-(bis(4-methoxyphenyl)amino)phenyl)-1-cyanovinyl)phosphonic acid (MPA-CPA) and (4-(3,6-diiodo-9H-carbazol-9-yl)butyl) phosphonic acid (I-4PACz) were purchased from Dyenamo AB. NiO _x_ nanoparticles were purchased from Avantama. Dehydrated dimethylsulfoxide (DMSO) and propan-2-ol (IPA) were purchased from FUJIFILM Wako Pure Chemical Co., Ltd. or Sigma-Aldrich. Dehydrated _N,N_ -dimethylformamide (DMF), toluene, anisole and chlorobenzene were purchased from Kanto Chemical Co., Inc. or Sigma-Aldrich. Methanol and diethyl ether for synthesis were purchased from FUJIFILM Wako Pure Chemical Co., Ltd. or Nacalai Tesque, Inc. All of these solvents were degassed by Ar gas bubbling for 1 h and further dried with molecular sieves (3 Å) in an Ar-filled (at Kyoto) glovebox (H2O, O2 < 0.1 ppm) before use. No treatment was applied for the solvents used at Oxford. Tetrakis(dimethylamino) tin(iv) was purchased from Pegasus Chemicals Limited. Indium zinc oxide (IZO) and SiO2 sputtering targets (99.995%) were purchased from Angstrom Engineering. 

#### **Synthesis of amino acid salts** 

PhA was prepared by dissolving 2.5 g (15 mM) of Phe in 50 ml of methanol. While the solution was being stirred, 3.0 g (2.0 eq, 30 mM) of hydrochloride acid solution (35–37 wt% in water) was added. The solution was stirred for 1 h at 0 °C to ensure a complete reaction and, subsequently, the solvent was removed using a rotary evaporator. Purification was accomplished by recrystallization in methanol and diethyl ether, affording PhA white powder (2.38 g, yield 78%). The resulting PhA powder was dried at 70 °C under vacuum for 4 h and then transferred to an Ar-filled or N2-filled glovebox. The synthesis procedure and the product yield of 4MePhA are similar to that of PhA described above. 

The left-handed configuration was mainly used in the study, as the chirality of the amino acid showed no considerable impact on the device performance in our study, whereas some interesting chiral spacers may determine the packing configuration of low-dimensional perovskite units that could affect the device performance<sup>48</sup> . We also note that the amino acid in a zwitterionic form could also work for improving the _V_ OC of the PV devices, whereas the FF shows lower values than the case using the protonated amino acid, that is, amino acid salts. 

Also, the solubility of the amino acid is much lower than the amino acid salts in most of the solvents, for example, DMSO and DMF, and even the solvent with high polarity, for example, water, because of the strong intermolecular H-bonding and ionic attractions generated between the –COO<sup>−</sup> and –NH3+ terminals of the amino acid. We thus recommend using amino acid salts but not amino acids in their unprotonated zwitterionic form. The sterically confined configuration and the distance between the ammonium and carboxylic acid groups in the amino acid salts is also critical, as a long distance between them could lead to the formation of low-dimensional perovskite phases with the ammonium group intercalating into the lattice and the whole molecule serving as a quantum wall spacer. Low-dimensional perovskite phases show a larger insulating nature than the 3D perovskites, decreasing the carrier mobility of the 3D perovskite-dominated films applied for the PV cells. 

On the basis of previous studies<sup>49–52</sup> , modifiers with the aromatic moiety should, in general, outperform the modifiers with the aliphatic moiety. We thus select PhA to extend our previous glycine hydrochloride research<sup>38</sup> . Also, using PhA as the amino acid salt allows us to compare with the ammonium-only analogue PEA—one of the most applied additives in the perovskite research—in our Sn–Pb perovskites and the carboxylic-acids-only analogue, PPA, to decouple the role of ammonium and carboxylic acid moieties in the amino acid salt additives. 

#### **Fabrication of perovskite thin films** 

**1.26-eV bandgap mixed tin–lead perovskites.** The perovskite film was prepared in an Ar-filled (at Kyoto) or N2-filled (at Oxford) glovebox (H2O, O2 < 0.1 ppm). The Cs0.1FA0.6MA0.3Sn0.5Pb0.5I3 perovskite precursor solution was prepared by mixing CsI (48.06 mg, 0.185 mmol), FAI (190.89 mg, 1.11 mmol), MAI (88.23 mg, 0.555 mmol), SnI2 (344.58 mg, 0.925 mmol), PbI2 (426.43 mg, 0.925 mmol), SnF2 (14.50 mg, 0.0925 mmol) and NH4SCN (2.82 mg, 0.037 mmol) in a solvent mixture of 0.25 ml DMSO and 0.75 ml DMF to reach a concentration of 1.85 M for the control samples. 0.5 mg ml<sup>−1</sup> Sn(0) powder was added to the perovskite precursor solution to scavenge the potential Sn(iv) introduced by oxidation of Sn(ii)<sup>53</sup> . For the PhA samples, 3 mol% of PhA (11.19 mg, 0.0555 mmol) was added to the control materials. 3 mol% of PEA (8.75 mg, 0.0555 mmol) was added to the control materials for the PEA samples. For the PPA samples, 3 mol% of PPA (8.33 mg, 0.0555 mmol) was added to the control materials. For the PEAPPA samples, 3 mol% of PEA (8.75 mg, 0.0555 mmol) and PPA (8.33 mg, 0.0555 mmol) were added to the control materials. The precursor solutions were stirred at 45 °C for about 40 min and filtered through a 0.20-µm PTFE filter before use. To spin-coat the films, 200 µl of the room-temperature precursor solution was applied to the substrate. A two-step spin-coating programme was used. The first step was 1,000 rpm for 10 s with an acceleration of 200 rpm s<sup>−1</sup> and the second was 4,000 rpm for 40 s with a ramp-up of 1,000 rpm s<sup>−1</sup> . Room-temperature chlorobenzene (400 and 500 µl for 25 × 25 mm<sup>2</sup> (at Kyoto) and 30 × 30 mm<sup>2</sup> (at Oxford) substrates, respectively) was used as the antisolvent. The chlorobenzene was quickly dripped onto the surface of the spinning substrate over an interval of 1 s during the second spin-coating step 20 s before the end of the procedure. The substrate was then immediately annealed on a 100 °C hotplate for 10 min, followed by annealing at 65 °C for more than 10 min to avoid glovebox vapour ingress of the as-prepared films, then the films were cooled to room temperature for the following processes. The post-treatment was done by dripping the PPCPTA (piperazine and C60 pyrrolidine tris‐acid) solution dynamically while spinning the as-prepared perovskite films, an approach we developed previously<sup>54</sup> . The spin-coating process was set at 4,000 rpm for 20 s with an acceleration of 1,333 rpm s<sup>−1</sup> . Following spin-coating, the films were immediately annealed again at 100 °C for about 5 min. 

**1.55-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm 

for 30 s (3 s acceleration to 3,000 rpm) without post-treatment. The hole-selective layer was deposited with the mixture of MeO-2PACz (0.25 mg ml<sup>−1</sup> ) and I-4PACz (0.25 mg ml<sup>−1</sup> ) solution in IPA by spin-coating inside an N2-filled glovebox and the substrates were annealed at 105 °C for 10 min. To deposit the perovskite film with the main composition of Cs0.05FA0.90MA0.05PbI2.95Br0.05, 1.5 M perovskite precursor solution was prepared by mixing CsI, FAI, MABr and PbI2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. Further 2 mol% PbI2 and 5 mol% MACl were added to the precursor as additives for better film quality<sup>55</sup> . The perovskite precursor (200 µl) was spin-coated at 4,000 rpm for 50 s (5 s acceleration to 4,000 rpm). 270 µl anisole was dropped on the film 20 s before the end of the spinning programme. The film was immediately annealed at 105 °C for 20 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 0.5 mg PEAI added to 1 ml IPA and chlorobenzene (v:v, 1:1) mixed solvent, was spin-coated onto the as-prepared perovskite films and followed up with 3 min of thermal annealing under 105 °C. 

**1.61-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) without any post-treatment. 1 mg ml<sup>−1</sup> MPA-CPA solution in ethanol was spin-coated inside an N2-filled glovebox at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) and the substrates were annealed at 100 °C for about 10 min. To deposit the perovskite film with the main composition of Cs0.1FA0.9Pb(I0.85Br0.15)3, 1.5 M perovskite precursor solution was prepared by mixing CsI, FAI, PbBr2 and PbI2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. The perovskite precursor (200 µl) was spin-coated at 1,000 rpm for 10 s (2 s acceleration to 1,000 rpm) and 5,000 rpm for 30 s (2 s acceleration to 5,000 rpm). 160 µl anisole was dropped on the film 5 s before the end of the spinning programme. The film was immediately annealed at 100 °C for 10 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 1 mg PEAI added to 1 ml IPA, was spin-coated onto the as-prepared perovskite films and followed up with 5 min thermal annealing under 100 °C. 

**1.77-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) without any post-treatment. 1 mg ml<sup>−1</sup> MPA-CPA solution in ethanol was spin-coated inside an N2-filled glovebox at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) and the substrates were annealed at 100 °C for about 10 min. To deposit the perovskite film with the main composition of Cs0.2FA0.8Pb(I0.6Br0.4)3, 1.2 M perovskite precursor solution was prepared by mixing CsI, FAI, PbBr2 and PbI2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. The perovskite precursor (200 µl) was spin-coated at 4,000 rpm for 32 s (4 s acceleration to 4,000 rpm). 160 µl anisole was dropped on the film 8 s before the end of the spinning programme. The film was immediately annealed at 100 °C for 15 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 1 mg PEAI added to 1 ml IPA, was spin-coated onto the as-prepared perovskite films and followed up with 5 min thermal annealing under 100 °C. 

**1.80-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) without any post-treatment. 1 mg ml<sup>−1</sup> MPA-CPA solution in ethanol was spin-coated inside an N2-filled glovebox at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) and the substrates were annealed at 100 °C for about 10 min. To deposit the perovskite film with the main composition of Cs0.15FA0.85Pb(I0.55 Br0.45)3, 1.2 M perovskite precursor solution was prepared by mixing CsI, FAI, PbBr2 and PbI2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. The perovskite precursor (200 µl) was spin-coated at 1,000 rpm for 10 s (2 s acceleration to 1,000 rpm) and 5,000 rpm for 30 s (2 s acceleration to 5,000 rpm). 160 µl anisole was 

dropped on the film 5 s before the end of the spinning programme. The film was immediately annealed at 100 °C for 10 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 1 mg PEAI added to 1 ml IPA, was spin-coated onto the as-prepared perovskite films and followed up with 5 min thermal annealing under 100 °C. 

**1.97-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) without any post-treatment. 0.5 mg ml<sup>−1</sup> Me-4PACz solution in ethanol was spin-coated inside an N2-filled glovebox at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) and the substrates were annealed at 100 °C for about 10 min. To deposit the perovskite film with the main composition of Cs0.15FA0.85Pb(I0.33 Br0.67)3, 0.8 M perovskite precursor solution was prepared by mixing CsI, FAI and PbBr2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. Further 0.5 mol% PDAI2, PbCl2 and MACl were added to the precursor as additives for better film quality, as we recently reported<sup>20</sup> . The perovskite precursor (200 µl) was spin-coated at 1,000 rpm for 10 s (2 s acceleration to 1,000 rpm) and 5,000 rpm for 30 s (2 s acceleration to 5,000 rpm). 170 µl anisole was dropped on the film 5 s before the end of the spinning programme. The film was immediately annealed at 100 °C for 10 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 1 mg PEAI added to 1 ml IPA, was spin-coated onto the as-prepared perovskite films and followed up with 5 min thermal annealing under 100 °C. 

**2.26-eV bandgap neat lead perovskites.** For the hole-selective layer, NiO _x_ (diluted in 1:10 ethanol, v:v) was spin-coated in the air at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) without any post-treatment. 0.5 mg ml<sup>−1</sup> Me-4PACz solution in ethanol was spin-coated inside an N2-filled glovebox at 3,000 rpm for 30 s (3 s acceleration to 3,000 rpm) and the substrates were annealed at 100 °C for about 10 min. To deposit the perovskite film with the main composition of FAPbBr3, 0.9 M perovskite precursor solution was prepared by mixing FABr and PbBr2 in DMF:DMSO (4:1, v:v) mixed solvent subject to the stoichiometric ratio. The perovskite precursor (200 µl) was spin-coated at 1,000 rpm for 10 s (2 s acceleration to 1,000 rpm) and 5,000 rpm for 30 s (2 s acceleration to 5,000 rpm). 160 µl anisole was dropped on the film 5 s before the end of the spinning programme. The film was immediately annealed at 100 °C for 10 min. For the interfacial passivation layer, a solution, with 0.5 mg EDAI2 and 1 mg PEAI added to 1 ml IPA, was spin-coated onto the as-prepared perovskite films and followed up with 5 min thermal annealing under 100 °C. 

#### **Fabrication of solar cell devices** 

Unless otherwise stated, all of the vacuum-based depositions were processed with the National Thin-Film Cluster Facility for Advanced Functional Materials (NTCF) assembled by Angstrom Engineering Inc. The Picosun model R200 Advanced Plasma atomic layer deposition (ALD) chamber was connected and controlled by a main cluster operation system. The ALD system was vacuum-pumped by a two-stage Edwards iXH610 pumping system and the process pressure was usually maintained at 5 mbar. The background carrier gas for the ALD system was N2 (99.9999%). The ALD system was equipped with two room-temperature sources for liquid-based precursors (typically, deionized water and trimethylaluminium (TMA, Pegasus) were loaded) in Pico 100 containers and two heatable sources in Pico 200 (TDMASn, Pegasus) and Pico 300 (InCp, EpiValence) liquid-based precursor containers. 20 nm SnO _x_ was grown at the ALD chamber using the combination of the TDMASn and deionized water precursors with a pulse time set at 1.4 and 1.6 s for TDMASn(iv) and H2O, respectively. The SnO _x_ layer deposition for neat lead-based films was conducted under the reactor temperature of 100 °C for 150 cycles, whereas 85 °C and 120 cycles were used for the layer on the mixed Sn–Pb perovskites. Sputtering deposition of the IZO interconnection layer was conducted under the process pressure of 

## Article 

4 × 10<sup>−3</sup> mbar. The flow rates of 18 and 0.4 sccm (standard cubic centimetres per minute) were applied for Ar and O2, respectively, to generate the plasma for deposition at room temperature. The plasma was ignited with DC power under a pulse frequency of 20 kHz. Sputtering deposition of the SiO _x_ layer was carried out under the process pressure of 4 × 10<sup>−3</sup> mbar at room temperature using a SiO2 target with the flow of Ar at the rate of 18 sccm. 

verifies our previous studies<sup>9,20,27,38,54,56,57</sup> . Note that, the PEDOT:PSS layer deposited for the tandem cell fabrication was spin-coated with a diluted PEDOT:PSS dispersion (with two times the volume using IPA). The films were then annealed under 105 °C in the air for about 10 min, and another 10 min at 105 °C inside the glovebox before the deposition of narrow bandgap Sn–Pb perovskite films. 

#### **Double junction** 

#### **Single-junction mixed tin–lead perovskite solar cells** 

Glass/FTO substrates (10 Ω sq<sup>−1</sup> , AGC Inc.) were etched with zinc powder and HCl (6 M in deionized water) and consecutively cleaned for 15 min in an ultrasonic bath in water, acetone and detergent solution (Semico Clean 56, Furuuchi chemical), water and isopropanol, followed by drying with an air gun and finally plasma treatment. For the devices fabricated at Oxford, the patterned glass/FTO substrates (15 Ω sq<sup>−1</sup> , Latech Scientific Supply Pte. Ltd. or 10 Ω sq<sup>−1</sup> , AGC Inc.) were used. The PEDOT:PSS hole-transport layer was fabricated from an aqueous dispersion (without diluting), which was filtered through a 0.45-µm PVDF filter and then spin-coated on the FTO substrate using a spin programme of 10 s at 500 rpm followed by 30 s at 4,000 rpm. The films were then annealed in air at 140 °C for 20 min. After transferring to an Ar-filled (at Kyoto) or N2-filled (at Oxford) glovebox (H2O, O2 < 0.1 ppm), the substrates were degassed at 140 °C for 30 min. The perovskite layer was fabricated on PEDOT:PSS following the above-mentioned procedure, whereas the concentration of the precursor solution was increased to 1.9 M for cells fabricated at Oxford, as per the tandem cells fabricated. The samples were moved under Ar or N2 to a vacuum deposition chamber, in which 20 nm of C60 (deposition rate 0.01 nm s<sup>−1</sup> ) and 8 nm of BCP (deposition rate 0.01 nm s<sup>−1</sup> ) were deposited by thermal evaporation. The top electrode was prepared by depositing 100 nm of silver (Ag) through a shadow mask. The deposition rate for Ag was first set as 0.005 nm s<sup>−1</sup> to reach 5 nm, then raised to 0.01 nm s<sup>−1</sup> to reach 20 nm and finally raised to 0.08 nm s<sup>−1</sup> to reach the target thickness. The cells fabricated at Kyoto for the EQE measurements were encapsulated with the AFTINNOVA-EF FD20 film (Ajinomoto Fine-Techno Co., Inc.)-pasted glass by heating at 65 °C for 5 min. The deposition rate for Cr and Au was 0.005 and 0.01 nm s<sup>−1</sup> , respectively. For Cr-containing cells, we note that cleaning the Cr bar to remove the oxidized species before each deposition is critical for the success of device fabrication. 

#### **Tandems** 

When optimizing all perovskite tandem cells, the choice and optimization of the recombination layer between the subcells is critical. It should be highly transparent, enable maximum forward transmission and minimum reflection of sub-bandgap light transmitted through the previous cell, be suitably conductive to enable low loss recombination of electrons and holes from the adjacent subcells and be robust to the processing of subsequent cells, while protecting adjacent layers. Typically, for the high-efficiency two-junction tandem cells, a recombination layer stack comprises tin-oxide (SnO _x_ ) deposited from ALD and a very thin layer of metallic gold clusters (nominal 1 nm), followed by PEDOT:PSS. This works effectively between a WBG Pb-based and NBG Sn–Pb perovskite cells. However, there is substantial visible and near-infrared parasitic absorbance in both the gold clusters and the PEDOT:PSS and, if the second (or third) cell is a Pb-based cell, which will be the case for a triple junction or quadruple junction, then PEDOT:PSS is not the hole-transport material of choice. Here we have investigated a range of options for the recombination layer and find that a simple double layer of ALD-grown SnO _x_ followed by a thin (about 10 nm) layer of sputter-coated indium zinc oxide acts as a highly efficient, ‘universal recombination layer’. We also note that the diamine-based and diammonium-based post-treatment is very effective and serves as ‘universal post-treatment’ in improving the performance of the seven different perovskite absorbers applied in this study, which also 

For all-perovskite double-junction solar cells, the perovskite absorbers were prepared as previously described. Between WBG and NBG perovskite subcells, after depositing PCBM, PEI solution (0.025 wt% diluted in IPA) was spin-coated at 4,000 rpm for 30 s (2,000 rpm s<sup>−1</sup> acceleration) without any post-processing. 20 nm of ALD-grown SnO _x_ was then deposited on top and followed by sputtering of 10 nm IZO. Shadow masks were used to ensure that only active areas were covered with IZO to avoid shunt losses. Instead of BCP, 20 nm of ALD-grown SnO _x_ was deposited on top of NBG perovskite and C60. 

For the double-junction cells fabricated at HUST, the NBG and WBG subabsorbers were fabricated with the recipe described above. For the interconnecting layer, C60 (18 nm), ALD-grown SnO _x_ (about 30 nm) and Au (about 0.8 nm) were deposited sequentially under vacuum. The layers above the NBG subabsorber were composed of C60 (25 nm), BCP (5 nm) and Ag (100 nm). 

#### **Triple junction** 

For all-perovskite triple-junction solar cells, the perovskite absorbers were prepared as previously described. Between WBG and MBG perovskite subcells, after depositing PCBM, PEI solution (0.025 wt% diluted in IPA) was spin-coated at 4,000 rpm for 30 s (2,000 rpm s<sup>−1</sup> acceleration) without post-processing. 20 nm of ALD-grown SnO _x_ was then deposited on top and followed by sputtering of 10 nm IZO. Between MBG and NBG perovskite subcells, 20 nm of ALD-grown SnO _x_ was deposited on C60 and followed by sputtering of 10 nm of IZO before spin-coating PEDOT:PSS in the air. Shadow masks were used to ensure that only active areas were covered with IZO to avoid shunt losses. Instead of BCP, 20 nm of ALD-grown SnO _x_ was deposited on top of NBG perovskite and C60. 

#### **Quadruple junction** 

For all-perovskite quadruple-junction solar cells, the perovskite absorbers were prepared as previously described. Between WBG (2.26 eV) and WBG (1.80 eV) perovskite subcells, after depositing PCBM, PEI solution (0.025 wt% diluted in IPA) was spin-coated at 4,000 rpm for 30 s (2,000 rpm s<sup>−1</sup> acceleration) without post-processing. 20 nm of ALD-grown SnO _x_ was then deposited on top and followed by sputtering of 10 nm IZO. Between WBG (1.80 eV) and MBG perovskite subcells, after depositing PCBM, PEI solution (0.025 wt% diluted in IPA) was spin-coated at 4,000 rpm for 30 s (2,000 rpm s<sup>−1</sup> acceleration) without any post-processing. 20 nm of ALD-grown SnO _x_ was then deposited on top and followed by sputtering of 10 nm IZO. Between MBG and NBG perovskite subcells, 20 nm of ALD-grown SnO _x_ was deposited on C60 and followed by sputtering of 10 nm of IZO before spin-coating PEDOT:PSS in the air. Shadow masks were used to ensure that only active areas were covered with IZO to avoid shunt losses. Instead of BCP, 20 nm of ALD-grown SnO _x_ was deposited on top of NBG perovskite and C60. 

In Fig. 4b, the thickness of the NBG absorber in the single-junction cells is about 930 nm. The thickness of the WBG and NBG subabsorbers in the double-junction cells is about 350 and 970 nm, respectively. The thickness of the WBG, MBG and NBG subabsorbers in the triple-junction cells is about 290, 550 and 940 nm, respectively. The thickness of the WBG (2.26 eV), WBG (1.80 eV), MBG and NBG subabsorbers in the quadruple-junction cells is about 250, 370, 740 and 900 nm, respectively. 

All types of cell were encapsulated with a cover glass and ultraviolet (UV)-activated adhesive (Eversolar AB-341, Everlight Chemical 

Industrial Co.), which was cured under a UV LED lamp (peak emission at 365 nm) for 3 min inside an N2-filled glovebox (H2O, O2 < 0.1 ppm) before any related characterization under ambient conditions. Before the glass encapsulation, a 300-nm on-site encapsulation SiO _x_ layer<sup>58</sup> was deposited on the top of the devices fabricated with the Cr (2.5 nm)/ Au (90 nm) top electrode that was subjected to the 85 °C ageing tests. 

#### **Characterizations** 

PLQE of samples was determined according to the method in ref. 59. Samples were placed inside an integrating sphere and excited from the substrate side with a 657-nm continuous-wave laser excitation source (Thorlabs) at 70.9 mW cm<sup>−2</sup> (equivalent to 1 sun for a 1.26-eV bandgap) with a large spot size of 0.15 cm<sup>2</sup> . The resulting PL signal was collected using a fibre bundle (Ocean Optics QR600 7 SR125BX) coupled with a spectrometer (QE Pro, Ocean Optics). Three different spots were measured on each substrate. For intensity-dependent PLQE measurements, the same measurements were collected on one spot over a wide range of fluences from about 0.1 to 150 mW cm<sup>−2</sup> . 

We applied a stray light correction to recorded PL spectra by subtracting the spectrum of the excitation laser (attenuated to the correct intensity according to the fraction of laser absorbed by the sample). PL emission spectra with a signal-to-noise ratio below 2 were not used. Furthermore, the detector used was not able to effectively detect PL above 1,050 nm, which means that, for the 1.26-eV bandgap samples used here, we were only able to map slightly more than half of the PL emission peak. To correct this, we fit the PL measurements to a pseudo-Voigt function and used the resulting peaks to calculate PLQE (fits were only used if _R_<sup>2</sup> > 0.8 was achieved). 

QFLS was calculated according to the following equation<sup>60</sup> : 



<!-- Start of picture text -->
QFLS = QFLSrad + k B T ln(PLQE)<br><!-- End of picture text -->

in which _k_ B is the Boltzmann constant and _T_ is the absolute temperature. In the SRH model, the change in the density of free electrons, free holes and trapped electrons owing to an electron trap can be described by equations (1)–(3). Here _β_ n and _β_ p represent the electron and hole capture coefficients, respectively, _N_ t the trap density, _n_ t the density of trapped carriers, _N_ C and _N_ V the density of states at the conduction and valence bands, respectively, _E_ CB and _E_ VB the energies of the conduction and valence bands, respectively, and _E_ T the energy of the trap state transition. The first term in each equation describes the trapping rate and the second term describes the detrapping rate. 



<!-- Start of picture text -->
R n-trapping = − β n n ( N t − n t) + β n N C e E T kT − E CB  n t (1)<br>   <br>R p-trapping = − β p pn t + β p N V e E VB kT − E T ( N t − n t) (2)<br>   <br><!-- End of picture text -->



<!-- Start of picture text -->
dd nt t = R p-trapping − R n-trapping (3)<br><!-- End of picture text -->

We assume that the doping density _p_ 0 in this material (approximately 10<sup>14</sup> cm<sup>−3</sup> when photoexcited charge densities are expected to be around 10<sup>14</sup> –10<sup>15</sup> cm<sup>−3</sup> ) is sufficiently low such that n = p = Δ _n_ is valid. Further assumptions leading to the model used for fitting were as in ref. 40 but are briefly detailed below. 

At a steady state, the hole and electron trapping rates are equal. The equation resulting from this can be rearranged to solve for the trap occupancy _n_ t, which is then used to determine the defect-mediated recombination rate given in equation (4). Here the lifetimes are used to denote _τ_ p = _β_ p1 _N_ T<sup>and</sup> _τ_ n = _β_ n1 _N_ T<sup>. As detrapping is only expected to be</sup> 

substantial in one direction (to the VB or to the CB), we can simplify equation (4) to equation (5) for an electron trap. 



<!-- Start of picture text -->
2<br>n<br>R SRH =  E T − E CB  E T − E CB (4)<br>n + N C e kT τ n + n + N C e kT τ p<br>       <br>2<br>n<br>R SRH =  E T − E CB (5)<br>n + N C e kT τ n + nτ p<br>   <br><!-- End of picture text -->

For a deep (mid-gap) trap, we make further simplifications by considering the detrapping rate to be negligible. For a deep trap, the recombination rate thus simplifies to: 



<!-- Start of picture text -->
n<br>R SRH = τ n + τ p (6)<br><!-- End of picture text -->

The total recombination rate resulting from one shallow electron trap and one deep trap can hence be described by equation (7). Assuming equal rates of electron and hole trapping for both the shallow and the deep traps leads to equation (8). 



<!-- Start of picture text -->
2<br>n n<br>R SRH = τ deep,n + τ deep,p +  n + N C e E T kT − E CB τ shallow,n + nτ shallow,p (7)<br>   <br>2<br>n n<br>R SRH = τ deep + τ shallow  21 N C e E T − kTE CB + n  (8)<br>   <br><!-- End of picture text -->

Computational studies have indicated that the expected trap depths in Sn–Pb perovskites range from 0.05 to 0.35 eV (relatively shallow compared with other perovskite compositions)<sup>41</sup> , but precise trap depths and associated electron and hole capture coefficients have not been determined. We hence use a model that contains a trap to represent both ‘extremes’—one relatively deep electron trap (0.35 eV) and one very shallow hole trap (0.05 eV). 

Intensity-dependent PLQE fitting was performed by modelling the recombination as below, then solving for the steady-state carrier density at each excitation density. The background hole density in the lead–tin perovskite used here is expected to lie around 10<sup>14</sup> cm<sup>−3</sup> , hence we expect to be in the high injection regime for all fluences used here. 



<!-- Start of picture text -->
dd nt = 0 = G − k trap,deep n − k trap,shallow2 nn +2 n 1 − k rad,ext n 2 − k aug n 3 (9)<br><!-- End of picture text -->

Here _G_ is the generation rate of charge carriers obtained from the laser intensity, spot size and perovskite thickness, _k_ rad,ext is the external radiative bimolecular recombination rate and _k_ aug is the Auger recombination rate. Trap-assisted recombination is modelled through one deep trap, from which carriers cannot be emitted, and one shallow trap, from which carriers can be emitted before recombining. _k_ trap is the trapping rate into the trap and _n_ 1 is related to the energetic depth of the trap (Δ _E_ t) through 



<!-- Start of picture text -->
n 1 = N Ce−Δ E t/ k B T (10)<br><!-- End of picture text -->

_N_ C is the density of states in the conduction band and is assumed to be 10<sup>18</sup> cm<sup>−3</sup> here. The equilibrium carrier concentration under the continuous illumination obtained by solving equation (9), _n_ eq, is then used to calculate the PLQE according to 



<!-- Start of picture text -->
PLQEint = k rad n eq2 + k trap,deep n eq2 k +rad k trap,shallow 2 n eq2 nn eqeq+2 n 1 + k aug n eq2 (11)<br><!-- End of picture text -->

## Article 

In accordance with the previous report<sup>61</sup> , the measured external PLQE is then described by 



<!-- Start of picture text -->
PLQEext = (1 −PLQE P escintPLQE) + ( P escintPLQEint) (12)<br><!-- End of picture text -->

in which _P_ esc is the escape probability of a photon generated within the perovskite material. We solve these equations iteratively for each generation rate to extract the parameters from the data. Fitting was performed using the Levenberg–Marquardt algorithm in limit and uncertainties were calculated by inverting the second derivative matrix of fit quality for each variable parameter. 

TRPL measurements were collected by exciting samples from the substrate side with a 635-nm laser head (LDH-635, PicoQuant GmbH) pulsed at a frequency of 10 kHz with a fluence of 4.9 nJ cm<sup>−2</sup> pulse<sup>−1</sup> and a spot size of 2.43 × 10<sup>−3</sup> cm<sup>2</sup> . The TRPL signal was collected from the same side with a time-correlated single-photon-counting set-up (FluoTime 300, PicoQuant GmbH using a TimeHarp 260 for photon counting). The emission was individually attenuated to keep the detector pile-up rate under 5%. 

The resulting data were processed by subtracting a background determined by the mean signal intensity during the 40 ns before the excitation pulse and normalizing. The tails of the resulting decays were fitted with a stretched exponential decay between 300 ns and the time at which the signal-to-noise ratio dropped below 2. 

Differential lifetime over time was plotted by first fitting the decays using a superposition of five exponential decays to smooth the data. The differential lifetime was then calculated according to the following equation<sup>43</sup> : 



<!-- Start of picture text -->
τ diff =   − 2 1 dlnd( t PL)   −1<br><!-- End of picture text -->

The QFLS images were obtained using the same set-up as our previous report<sup>47</sup> , which is also demonstrated with the scheme below. The sample was optically excited with a 450-nm LED and electronically contacted by a sourcemeter. 

The intensity of the LED that corresponds to an equivalent 1-sun illumination was determined by measuring the current on a fully fabricated device at a short circuit and varying the intensity until this current matched that measured on our calibrated solar simulator. The PL images were captured on an Andor Zyla CMOS image sensor. A long-pass filter was used to stop the excitation light. 

The PLQE was estimated by imaging the excitation light incident on a white reference plate, placed on the focal plane of the camera, without a filter. We use this as a dividing factor for the PLQE, considering the wavelength-dependent response of the camera lenses and the image sensor itself. For each measurement, the illumination was held for 30 s before measurement, to allow for the PL to stabilize. 

#### **Calculation of the** **_V_ OC loss based on EQEEL measurements** 

EQEEL of the triple-junction cells was measured on a home-built EQEEL platform at room temperature, in which an Ocean Insight QE Pro Spectrometer and an integrating sphere coupled with fibre were used for the EL spectra collection and a Keithley 2400 was used to drive the devices. The system was calibrated by a standard light source (HL-3P-INT-CAL radiometrically calibrated tungsten halogen light source) for the absolute spectral response of the spectrometer. The EQEEL values of all three junctions were calculated from the associated emission peaks. 



<!-- Start of picture text -->
EQE(EL) = N photon(V) × 100% = Φ λλe d λ × 100%<br>N charges(V) ∫ hcJA<br><!-- End of picture text -->

in which _N_ photo and _N_ charges are emitted photons and injected charge carriers, respectively; _Φλ_ (µw nm<sup>−1</sup> ) is spectral flux, _h_ is the Plank constant 

(6.626 × 10<sup>−34</sup> J s), _c_ is the speed of light in vacuum (2.998 × 10<sup>8</sup> m s<sup>−1</sup> ), _J_ (mA cm<sup>−2</sup> ) is the current density and _e_ is the elementary charge (1.602 × 10<sup>−19</sup> C). The working area of the device is _A_ (m<sup>2</sup> ). The _V_ OC loss values were calculated following the equation 



<!-- Start of picture text -->
Δ V OC,nrad = − kq B T ln(EQEEL( J SC ))<br><!-- End of picture text -->

in which _q_ is the elementary charge and _k_ B is the Boltzmann constant. EQEEL( _J_ SC) is the EQEEL (ratio of emitted photons to the injected charge carriers) of the solar cell at an injected current density that is the same as the _J_ SC of the triple-junction cells under the simulated AM 1.5 G illumination. 

#### **TPC** 

Transient photoconductivity (TPC) was measured using a homebuilt set-up. Interdigitated gold electrodes spaced 300 and 500 µm apart were evaporated onto the sample on a glass substrate and used to bias the sample with a weak electric field of <0.01 V µm<sup>−1</sup> . The sample was illuminated from the substrate side by a 10-Hz pulsed laser at 650 nm with power densities <1 mW cm<sup>−2</sup> . Discrete neutral density filters were used to change the excitation intensity over an area of 0.25 cm<sup>2</sup> . The excitation pulse used during the TPC experiment had a pulse width of 3.7 ns and was used as an optical trigger for a digital oscilloscope (Tektronix DPO3054), which measures the voltage across a terminal resistor. More details about the technique can be found in our previous report<sup>62</sup> . 

#### **Extracting mobility from TPC** 

A more detailed explanation has been reported in our previous report<sup>62</sup> . In short, the sum mobility (Σ _μ_ ) can be estimated from the photoconductivity through 



<!-- Start of picture text -->
σ photo( t = 0) = eϕ Σ μN 0,<br><!-- End of picture text -->

in which _e_ is the elementary charge, _N_ 0 is the excitation charge carrier density and _Φ_ is the fraction of free charge carriers. The last of these needs to be estimated to obtain Σ _μ_ . This is done by taking both recombination during the laser pulse as well as exciton formation at higher excitation intensities into account. The corrected Σ _μ_ is then largely independent of excitation intensity. We report the median mobilities of six intensities of two samples each for the control and PhA cases. We find a much lower in-plane mobility for the modified case. 

SEM at Kyoto was performed with a Hitachi S8010 ultra-highresolution scanning electron microscope (Hitachi High-Tech Corporation) under the accelerating voltage of 2 kV for the experiments (cross and top view of the perovskite films) conducted in Kyoto. The crosssection images of the devices were recorded by a FEI Quanta 3D FEG microscope at Oxford. A 10-kV electron beam with a spot size of 2 and a secondary electron detector were used. A typical working distance was about 11 mm and dwell time for single-pass image acquisition was 5 µs. Focusing and alignment were done away from imaged areas to minimize electron-beam-induced damage. 

_J–V_ curves for the devices fabricated at Kyoto were measured in an N2-filled glovebox (H2O, O2 < 0.1 ppm) with an OTENTO-SUN-P1G solar simulator (Bunkoukeiki Co., Ltd.). The light intensity of the illumination source was calibrated using a standard silicon photodiode. Each device was measured with a 10-mV voltage step and a 100-ms time step (that is, scan rate of 0.1 V s<sup>−1</sup> ) using a Keithley 2400 sourcemeter. The active area of the device was defined by an optical mask, 0.0985 cm<sup>2</sup> for the usual devices. Steady-state power output measurement was performed by holding the device at the voltage of the maximum power point, as determined by _J–V_ characterization, and monitoring the current density over the period examined. 

For the devices fabricated at Oxford, _J_ – _V_ and maximum power point measurements (in turbo mode with four cells measured in parallel) were 

measured using four Keithley 2400 series sourcemeters in the ambient environment under both simulated sunlight (AM 1.5 G irradiance generated by a Wavelabs SINUS-220 simulator) and in the dark (for the dark _J_ – _V_ ). The active area of the solar cell was masked with a black-anodized metal aperture to either 0.25 or 1 cm<sup>2</sup> , within a light-tight holder. The _J_ – _V_ characteristics were taken from a reverse scan (that is, from forward bias to short circuit) followed by a forward scan (that is, from short circuit to forward bias) at a scan rate of 300 mV s<sup>−1</sup> . Subsequently, active MPPT measurements using a gradient descent algorithm were performed for the projected period to obtain the MPPT efficiency as the steady-state performance. The intensity of the solar simulator was set periodically such that the short-circuit current density from a WPVS reference cell (monocrystalline silicon solar cell, provided and certified by Fraunhofer ISE) matched its 1-sun certified value. The mismatch factor, estimated for the test cells, calibration cells and simulator, was estimated to be less than 1% and, hence, was not applied<sup>63</sup> . 

EQE spectra for single-junction devices fabricated at Kyoto were measured with a Bunkoukeiki SMO-250III system equipped with a Bunkoukeiki SM-250 diffuse reflection unit (Bunkoukeiki Co., Ltd.). The incident light intensity was calibrated with a standard SiPD S13371010BQ silicon photodiode. 

For the devices fabricated at Oxford, we measured the EQE using a homebuilt set-up. To determine the EQE, the photocurrent spectrum of the device under test was divided by that of a calibrated Si reference cell (Newport) of a known EQE. The light illumination first goes through a monochromator (Princeton Instruments SP2150) with a filter wheel (Princeton Instruments FA2448) and is followed by being chopped with an optical chopper (Thorlabs MC2000B) at 280 Hz and focused onto the measured cell with a smaller spot size than the solar cell area (as defined by the metallic top contact). The amplitude of the resulting AC signal was measured with a lock-in amplifier (Stanford Research Systems SR830) as the voltage drop across a 50-Ω resistor connected in series with the solar cell under measurement. For double-junction tandem devices, we measured the EQE response from the WBG subcell by biasing the NBG subcell to its open-circuit voltage conditions with an LED light at the wavelength of 850 nm. The response of the NBG subcell was recorded by biasing the WBG subcell to its open-circuit voltage conditions with an LED light at the wavelength of 455 nm. For triple-junction dells, we measured the EQE response from the WBG subcell by biasing the MBG and NBG subcells to their open-circuit voltage conditions with two LED lights at wavelengths of 740 and 850 nm. The response of the MBG subcell was recorded by biasing the WBG and NBG subcells to their open-circuit voltage conditions with two LED lights at wavelengths of 455 and 850 nm. The response of the NBG subcell was recorded by biasing the WBG and MBG subcells to their added open-circuit voltage conditions with two LED lights at wavelengths of 455 and 740 nm. For quadruple-junction dells, we measured the EQE response from the WBG1 (2.26 eV) subcell by biasing the WBG2, MBG and NBG subcells to their open-circuit voltage conditions with three LED lights at wavelengths of 585, 740 and 850 nm. The response of the WBG2 subcell was recorded by biasing the WBG1, MBG and NBG subcells to their open-circuit voltage conditions with three LED lights at wavelengths of 455, 740, and 850 nm. The response of the MBG subcell was recorded by biasing the WBG1, WBG2 and NBG subcells to their open-circuit voltage conditions with three LED lights at wavelengths of 455, 585 and 850 nm. The response of the NBG subcell was recorded by biasing the WBG1, WBG2 and MBG subcells to their added open-circuit voltage conditions with three LED lights at wavelengths of 455, 585 and 740 nm. LED light sources were purchased from Mightex. The measurements were conducted under ambient conditions. 

To determine the equivalent short-circuit current density under 1-sun irradiance from the EQE measurements, the overlap integral of the AM 1.5 photon flux ( _φ_ AM1.5) spectrum with the EQE was calculated. Explicitly, this is given by 



<!-- Start of picture text -->
∞<br>J SC = q ∫0 d λ EQE( λ ) φ AM1.5( λ )<br><!-- End of picture text -->

in which _q_ is the elementary charge and _λ_ is the wavelength. 

Ultraviolet photoelectron spectroscopy (UPS) was performed with a photoelectron spectroscopy system (PHI 5000 VersaProbe II, ULVAC-PHI, Inc.) with He I excitation (21.22 eV). A −5.0 V bias was applied to the samples. The chamber base pressure was approximately 1 × 10<sup>−6</sup> Pa. Samples were transferred from the glovebox to the UPS chamber without air exposure. 

X-ray photoelectron spectroscopy (XPS) was performed with a photoelectron spectroscopy system (PHI 5000 Versa Probe II, ULVAC-PHI, Inc.). Monochromated Al Kα (1,486.6 eV) radiation with an operating power of 50 W (15 kV voltage) was used in all of the XPS measurements. The diameter of the analysed area was 200 µm. The take-off angle was 45° to the substrate. For the measurement of each atomic element, pass energy of 46.95 eV and 0.050-eV energy steps were used. Four different positions of the samples were analysed and obtained spectra were averaged to improve the signal-to-noise ratio. No sample charging was observed during all of the measurements. 

XRD and 2D GIWAXS measurements were performed on a Rigaku SmartLab equipped with a goniometer-mounted 2D hybrid pixel array detector (HyPix-3000) with a rotating Cu Kα source ( _λ_ = 1.5406 Å). Perovskite films were deposited on the top of PEDOT:PSS with glass/FTO as substrates to mimic the growth conditions in full devices and covered with a thin film of spin-coated PMMA to prevent direct exposure to air. For GIWAXS, samples were mounted on a 2D XRD attachment head with a knife-edge to prevent air scatter, positioned directly behind a pinhole to reduce sample footprint broadening, with a beam stop for the direct beam. The sample-to-detector distance was 65 mm, the incidence angle was set to 0.4°, the detector 2 _θ_ angle was 13.5° and the total collection time was 10 min. Detector images were then resampled into _Q_ -space using scripts based on the pyFAI and pygix libraries<sup>64</sup> . 

**NMR spectra.**<sup>1</sup> H NMR spectra were recorded on a Bruker Avance 400 spectrometer (400 MHz).<sup>119</sup> Sn and<sup>207</sup> Pb NMR spectra were recorded on a Bruker Avance III 500 NMR spectrometer (500 MHz). The NMR chemical shifts are reported in ppm relative to the residual protons of DMSO- _d_ 6 ( _δ_ = 2.54 ppm) and –HC=O proton of DMF _-d7_ at 7.95 ppm. The metal NMR set-up was calibrated with measured shielding constant of tetramethyl metal reference compounds. The samples were prepared by dissolving the subjected content(s) into 0.6 ml DMSO- _d_ 6 and DMF- _d_ 7 mixed solvent with a concentration of 1.85 M. After filtration through a 0.20-µm PTFE filter, the solutions were injected into NMR tubes for testing. 

DLS was conducted with an ELSZ-2000 particle size analyser (Otsuka Electronics Co., Ltd.). The perovskite precursor solution preparation was conducted in an Ar-filled glovebox (H2O, O2 < 0.1 ppm). The 1.85 M Cs0.1FA0.6MA0.3Sn0.5Pb0.5I3 perovskite precursor solution was prepared as a foundation reference. To prepare the PhA, PEA, PPA and PEAPPA samples, 3 mol% of the additives, that is, PhA, PEA, PPA and PEA, together with PPA, with respect to the total amount of SnI2 and PbI2, were respectively added to the foundation precursor materials to form these modified 1.85 M solutions. As stated in the perovskite preparation section, the precursor solution was stirred at 45 °C for 30 min and filtered through a 0.20-µm PTFE filter before being subject to the DLS tests. 2.0 ml perovskite precursor solution for each condition was loaded in a clean quartz cuvette for measurement (Ar-sealed). The DLS measurement was conducted at 0, 10, 30, 60, 90, 120 and 240 min after the sample preparation for each condition. The refractive indices and viscosity of the solvent were 1.4405 and 1.1005, respectively, based on the DMF and DMSO with a volume ratio of 3:1. CONTIN analysis mode was applied. 

ToF-SIMS measurements were carried out using a ToF-SIMS 5 (IONTOF GmbH) operated in the high-lateral-resolution mode (burst 

## Article 

alignment mode). A 60-keV Bi32+ primary ion beam with a pulse width of 3 ns was used for data acquisition. Primary ion dose density was maintained at less than approximately 5 × 10<sup>11</sup> ions cm<sup>−2</sup> in each measurement cycle to prevent sample damage from the irradiation of the primary ion beam. For sample etching, a 10-keV Ar1200+ gas cluster ion beam with a centre size of approximately 1,200 atoms was used as a sputtering ion beam. Depth profiles of treated ingredients (or ions) were reconstructed from the raw data after data acquisition. Also, mass spectra and depth profiles with high mass resolution were acquired from an area of 200 µm × 200 µm by using high-mass-resolution mode (bunching mode). A low-energy electron flood gun was used for charge compensation. The films were loaded under an N2 atmosphere. 

For 85 °C ageing, encapsulated devices fabricated with the Cr (2.5 nm)/Au (90 nm) top electrode were subjected to an oven with the temperature set at 85 °C for thermal ageing. For the dark ageing, the ageing oven was put inside a glovebox (O2 < 10 ppm, H2O < 0.1 ppm). For the light ageing, the ageing chamber for storing the encapsulated samples was air-cooled with the temperature controlled at 85 °C (measured using a black standard temperature control unit positioned next to the test cells). During the ageing period, the relative humidity in the laboratory (at about 20 °C) was monitored at about 45%. 

**MPPT test.** The operating stability tests for MPPT were carried out under simulated AM 1.5 G illumination (Class ABA Newport solar simulator (LSH-7320)) with 1-sun intensity using a homebuilt LabVIEW-based MPPT script and a Keithley 2401 sourcemeter to track the cell performance in ambient conditions (temperature approximately 25 °C, RH 30–50%). No UV filter was applied during operation but we do note that this simulator generates very little UV light. The spectrum of the solar simulator can be accessed at: https://web.archive.org/ web/20240502204722/https://www.newport.com/mam/celum/celum_ assets/np/resources/DS-092001_MiniSol_LED_Solar_Simulator_Datasheet.pdf?3. 

Highly sensitive EQE measurements used the light from an Osram 64655 HLX 250 W tungsten halogen lamp mechanically chopped at 333 Hz passing appropriate sorting filters (OD > 5) and dispersed using an Oriel Cornerstone 260 monochromator. The cell was kept in an electrically insulated nitrogen-filled container. The response was recorded using a Stanford Research SR570 preamplifier and a Stanford Research SR830 lock-in amplifier. Calibration was performed using reference Si and InGaAs detectors. The measured highly sensitive EQE spectra were scaled to normal EQE data. 

Optical simulations and optimizations were performed using a custom-made program<sup>65</sup> , written in Python, based on the ‘tmm’ transfer-matrix modelling Python module<sup>66</sup> . The optical constants for each of the layers in the device stacks were obtained from our previous studies<sup>20,67</sup> . 

#### **Computational methods** 

As learnt from the previous single-crystal results<sup>68</sup> , the Sn(ii) and Pb(ii) in perovskite prepared with FA0.5MA0.5Sn0.5Pb0.5I3-subjected composition show equal occupation at the B-site of the ABX3 structure. This indicates that the Sn(ii) and Pb(ii) in the Sn–Pb perovskites are more likely to assemble their octahedral structures in a way that all of the Sn(ii) are surrounded by Pb(ii), and vice versa. We constructed the Cs0.125 FA0.625MA0.25Sn0.5Pb0.5I3 A–I-terminated (001) surface (about 25 × 25 Å<sup>2</sup> ) with a vacuum of 20 Å to separate neighbouring surfaces in the _z_ direction. DFT calculations were performed by the Perdew–Burke–Ernzerhof generalized gradient approximation and the projector augmented wave as implemented in the Vienna Ab initio Simulation Package (VASP)<sup>69–73</sup> . The DFT-D3 method was used for the van der Waals correction<sup>74</sup> . Dipole corrections were included for the slab calculations. The plane-wave cut-off energy of 400 eV was used. The Brillouin zone was sampled using a single gamma point. The energy and force convergence criteria were set to 10<sup>−5</sup> eV and 0.03 eV Å<sup>−1</sup> , respectively. The binding energies 

( _E_ b) of adsorbate molecules with the perovskite surface were calculated as _E_ mol/pvsk − _E_ pvsk − _E_ mol, in which _E_ mol/pvsk, _E_ pvsk and _E_ mol are the total energies of the adsorption system, the perovskite system and adsorbate molecules, respectively. 

Calculations on the configuration of MAI, FAI and SnI2 with amino acid salt molecules are performed by the ωB97X-D functional<sup>75</sup> combined with the 6-311G(2d,p)<sup>76–78</sup> (for C, N, O, and H atoms) and LANL2DZ<sup>79</sup> (for Sn and I atoms) basis sets. Optimized structures were confirmed as local minima through vibrational frequency analysis. Interaction energies were calculated using the following equation: Δ _E_ int = _E_ (MAI/ FAI/SnI2 + amino acid) − ( _E_ (MA/FA/Sn) + _E_ (I/I/2I) + _E_ (amino acid)), considering the ionic nature of the species. The above calculations were carried out using the Gaussian 16 suite of programs version A.03 (ref. 80). The electrostatic potentials were calculated at the level of ωB97X-D/6-311G(2d,p) (LANL2DZ for Sn and I) and corresponding values were obtained by Multiwfn<sup>81</sup> . 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

The data supporting the findings of this study are available from the corresponding author on request. 

48. Duan, T. et al. Chiral-structured heterointerfaces enable durable perovskite solar cells. _Science_ **384** , 878–884 (2024). 

49. Zheng, K. et al. Inter-phase charge and energy transfer in Ruddlesden–Popper 2D 

   - perovskites: critical role of the spacing cations. _J. Mater. Chem. A_ **6** , 6244–6250 (2018). 

50. Yan, L. et al. Charge-carrier transport in quasi-2D Ruddlesden–Popper perovskite solar cells. _Adv. Mater._ **34** , 2106822 (2022). 

51. Zou, Y., Gao, Y. & Liu, Y. The role of organic spacers in 2D/3D hybrid perovskite solar cells. _Mater. Chem. Front._ **8** , 82–103 (2024). 

52. Cao, Q. et al. Two-dimensional perovskites: impacts of species, components, and properties of organic spacers on solar cells. _Nano Today_ **43** , 101394 (2022). 

53. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(ii) oxidation in precursor ink. _Nat. Energy_ **4** , 864–873 (2019). 

54. Hu, S. et al. Synergistic surface modification of tin–lead perovskite solar cells. _Adv. Mater._ **35** , 2208320 (2023). 

55. Liu, S. et al. Buried interface molecular hybrid for inverted perovskite solar cells. _Nature_ **632** , 536–542 (2024). 

56. Hu, S. et al. A universal surface treatment for p–i–n perovskite solar cells. _ACS Appl. Mater. Interfaces_ **14** , 56290–56297 (2022). 

57. Chen, H. et al. Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676–681 (2023). 

58. Kirmani, A. R. et al. Metal oxide barrier layers for terrestrial and space perovskite photovoltaics. _Nat. Energy_ **8** , 191–202 (2023). 

59. de Mello, J. C., Wittmann, H. F. & Friend, R. H. An improved experimental determination of external photoluminescence quantum efficiency. _Adv. Mater._ **9** , 230–232 (1997). 

60. Caprioglio, P. et al. On the relation between the open-circuit voltage and quasi-Fermi level splitting in efficient perovskite solar cells. _Adv. Energy Mater._ **9** , 1901631 (2019). 

61. Richter, J. M. et al. Enhancing photoluminescence yields in lead halide perovskites by photon recycling and light out-coupling. _Nat. Commun._ **7** , 13941 (2016). 

62. Lim, J. et al. Long-range charge carrier mobility in metal halide perovskite thin-films and single crystals via transient photo-conductivity. _Nat. Commun._ **13** , 4201 (2022). 

63. Snaith, H. J. How should you measure your excitonic solar cells? _Energy Environ. Sci._ **5** , 6513–6520 (2012). 

64. Ashiotis, G. et al. The fast azimuthal integration Python library: pyFAI. _J. Appl. Crystallogr._ **48** , 510–519 (2015). 

65. Ball., J. jmball/pv_optics: v1.0.0. Zenodo https://doi.org/10.5281/zenodo.12707035 (2024). 

66. Byrnes, S. J. Multilayer optical calculations. Preprint at https://arxiv.org/abs/1603.02720 (2020). 

67. Datta, K. et al. Monolithic all-perovskite tandem solar cells with minimized optical and energetic losses. _Adv. Mater._ **34** , 2110053 (2022). 

68. Ke, W. et al. Ethylenediammonium-based “hollow” Pb/Sn perovskites with ideal band gap yield solar cells with higher efficiency and stability. _J. Am. Chem. Soc._ **141** , 8627–8637 (2019). 

69. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys. Rev. B_ **54** , 11169–11186 (1996). 

70. Kresse, G. & Furthmüller, J. Efficiency of ab-initio total energy calculations for metals and semiconductors using a plane-wave basis set. _Comput. Mater. Sci._ **6** , 15–50 (1996). 

71. Kresse, G. & Joubert, D. From ultrasoft pseudopotentials to the projector augmented-wave method. _Phys. Rev. B_ **59** , 1758–1775 (1999). 

72. Kresse, G. & Hafner, J. Ab initio molecular dynamics for liquid metals. _Phys. Rev. B_ **47** , 558–561 (1993). 

73. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys. Rev. Lett._ **77** , 3865–3868 (1996). 

74. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H-Pu. _J. Chem. Phys._ **132** , 154104 (2010). 

75. Chai, J.-D. & Head-Gordon, M. Long-range corrected hybrid density functionals with damped atom–atom dispersion corrections. _Phys. Chem. Chem. Phys._ **10** , 6615–6620 (2008). 

76. Krishnan, R., Binkley, J. S., Seeger, R. & Pople, J. A. Self‐consistent molecular orbital methods. XX. A basis set for correlated wave functions. _J. Chem. Phys._ **72** , 650–654 (1980). 

77. McLean, A. D. & Chandler, G. S. Contracted Gaussian basis sets for molecular calculations. I. Second row atoms, _Z_ =11–18. _J. Chem. Phys._ **72** , 5639–5648 (1980). 

78. Francl, M. M. et al. Self‐consistent molecular orbital methods. XXIII. A polarization‐type basis set for second‐row elements. _J. Chem. Phys._ **77** , 3654–3665 (1982). 

79. Wadt, W. R. & Hay, P. J. Ab initio effective core potentials for molecular calculations. Potentials for main group elements Na to Bi. _J. Chem. Phys._ **82** , 284–298 (1985). 

80. Frisch, M. J. et al. Gaussian 16 Rev. A.03 (Gaussian, Inc., 2016). 

81. Lu, T. & Chen, F. Multiwfn: a multifunctional wavefunction analyzer. _J. Comput. Chem._ **33** , 580–592 (2012). 

**Acknowledgements** We acknowledge the Engineering and Physical Sciences Research Council (EPSRC), UK, under grant numbers EP/S004947/1, EP/X038777/1 and EP/T028513/1, UK Research and Innovation (UKRI) under the UK government’s Horizon Europe funding guarantee under grant number 10054976 (the NEXUS project has received financing from the European Union’s Horizon Europe research and innovation programme under grant agreement no. 101075330. The views and opinions expressed are however those of the author(s) only and do not necessarily reflect those of the European Union or RIA. Neither the European Union nor the granting authority can be held responsible for them), the Marie Skłodowska-Curie Actions Postdoctoral Fellowships (UKRI Guarantee, grant numbers EP/Y029216/1 and EP/Y029135/1), New Energy and Industrial Technology Development Organization (NEDO), JST-Mirai Program (JPMJMI22E2), KAKENHI (JP21H04699, JP24H00481) and the International Collaborative Research Program of ICR, Kyoto University, for support. M.E. thanks the financial support from the Japan Society for the Promotion of Science (JSPS) KAKENHI (JP22H05133). P.Z. thanks the financial support from the JSPS KAKENHI (JP24K17663). M.A.T. thanks the financial support from the Grant-in-Aid for Scientific Research (B) (JP24K01571). The computations were partly performed using the Research Center for Computational Science, Okazaki, Japan (project 23-IMS-C197). J.P. acknowledges support from Energy for the future – E4F Postdoctoral fellowship programme MSCA-COFUND (101034297). Z.L. and W.C. acknowledge the financial support from the National Natural Science Foundation of China (52473301, U20A20252), the Young Elite Scientists Sponsorship Program by CAST and the financial support from the Innovation Project of Optics Valley Laboratory (OVL2021BG008). Jianan Wang acknowledges the Fundamental Research Funds for the Central Universities, HUST(2023JYCXJJ041). S.-H.T.-C. gratefully acknowledges support from the Ministry of Science and Innovation of Spain under Ayudas Ramón y Cajal (RYC2022-035578-I). N.R.M.S. acknowledges financing from HyET Solar Netherlands B.V. R.A.J.J. acknowledges support from the European Union’s Horizon Europe research and innovation programme under grant agreement number 101075605 (SuPerTandem), the ERC (PERSTACK, 101098168) and the Dutch Research Council (NWO, Spinoza grant). We thank the National Thin-Film Cluster Facility for Advanced Functional Materials (NTCF) at the Department of Physics, 

University of Oxford, which has been financed by EPSRC (EP/M022900/1) and the Wolfson Foundation. We thank Y. Iwasaki (Kyoto University) for the assistance with SEM measurements, N. Rees (University of Oxford) for the assistance with the NMR measurements, T. Hasegawa (Kyoto University) for the assistance with the XRD measurements, D. Shirakura (Toray Research Center) for the assistance with the ToF-SIMS measurements, H. Shimura, R. Yamaguchi and M. Yoshita from the Photovoltaic Calibration, Standards and Measurement Team, Renewable Energy Research Center (RENRC), National Institute of Advanced Industrial Science and Technology (AIST), Japan, for the kind support on our device calibration and M. Tetsuhiko (AIST) for the assistance with the device storage in Japan. 

**Author contributions** S.H. conceived the idea, designed the experiments and prepared the original draft of the manuscript. S.H., J.P., J.A.S. and N.K.N. conducted the NMR characterizations and analysed the NMR and DLS results. A. Dallmann discussed the NMR results. S.H. and W.L. synthesized the amino acid salts. W.L. conducted the DLS measurements. S.H. conducted the SEM, XRD and 2D GIWAXS measurements. P.Z. and M.E. conducted the DFT calculations. F.R. carried out the TRPL, PLQE and QFLS characterizations. A. Dasgupta conducted the PL image measurements and helped with generating the p _J_ – _V_ analyses. M.K.-C. performed the TPC measurements and the fitting of the PLQE results. M.A.T. prepared the samples for the UPS, XPS and ToF-SIMS measurements. K.N. and K.T. conducted the UPS and XPS measurements. Junke Wang and Z.Y. performed the EQEEL measurements and analyses. S.H. and Junke Wang fabricated the solar cell devices and performed the related characterizations. Jianan Wang, H.Z., Z.L. and W.C. prepared some double-junction cells at HUST. Junke Wang contributed to the optimization of WBG subcells and conducted the optical simulations. J.N.D. contributed to the primary optimization of IZO interconnecting layers for triple-junction cells with the deposition of a 1.97-eV subcell. J.Y. contributed to some film depositions at NTCF. J.M.B. provided the optical simulation code and built the EQE set-up. M.G.C. and H.J.S. designed the single-junction and multijunction cell layouts. M.G.C., J.M.B. and K.-A.Z. developed and maintained the solar cell test and characterization equipment and methodologies. J.M.B. developed the optical simulation programme. M.G.C., J.M.B., D.P.M. and K.-A.Z. acquired the data for the estimation of the mismatch factor. G.J.W.A., N.R.M.S. and R.A.J.J. conducted the sensitive EQE characterizations. Junke Wang, J.P., J.A.S., S.-H.T.-C., N.K.N., A.W. and H.J.S. contributed to the revision of the manuscript. H.J.S. and A.W. supervised the project and raised the grant funding for the laboratory infrastructure and research. All authors commented on and contributed to improving the written manuscript. 

**Competing interests** H.J.S. is the co-founder and CSO of Oxford PV Ltd. A.W. is the co-founder and CSO of EneCoat Technologies Co., Ltd. M.G.C. and J.M.B. are co-founder and co-CEO of Ark Metrica LTD. 

##### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-024-08546-y. 

**Correspondence and requests for materials** should be addressed to Shuaifeng Hu, Atsushi Wakamiya or Henry J. Snaith. 

**Peer review information** _Nature_ thanks the anonymous reviewers for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at http://www.nature.com/reprints. 





