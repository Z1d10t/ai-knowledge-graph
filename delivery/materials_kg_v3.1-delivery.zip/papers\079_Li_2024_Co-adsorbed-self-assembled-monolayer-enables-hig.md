# Co-adsorbed self-assembled monolayer enables high-performance perovskite and organic solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 259 |
| 作者 | Dong-Yan Li, Qing Lian, T. Du, Rui-Jie Ma, Heng Liu, Qiong Liang, Yu Han, Guo-Jun Mi et al. |
| DOI | 10.1038/s41467-024-51760-5 |
| 源文件 | 079_Li_2024_Co-adsorbed-self-assembled-monolayer-enables-hig.pdf |

---
Article 



https://doi.org/10.1038/s41467-024-51760-5 

# Co-adsorbed self-assembled monolayer enables high-performance perovskite and organic solar cells 

|Received: 5 March 2024<br>Accepted: 14 August 2024|Dongyang Li<br>1,2,8, Qing Lian1,8, Tao Du3,8, Ruijie Ma<br>2<br>, Heng Liu<sup>4</sup>,<br>Qiong Liang<sup>2</sup>, Yu Han<sup>2</sup>, Guojun Mi<sup>1</sup>, Ouwen Peng<sup>1</sup>, Guihua Zhang<sup>1</sup>, Wenbo Peng<sup>1</sup>,<br>Baomin Xu<br>1, Xinhui Lu<br>4, Kuan Liu2, Jun Yin<br>3, Zhiwei Ren<br>2<br>,|
|---|---|
||Gang Li<br>2,5<br>& Chun Cheng<br>1,6,7|
|Check for updates||
||Self-assembled monolayers (SAMs) have become pivotal in achieving high-<br>performance perovskite solar cells (PSCs) and organic solar cells (OSCs) by<br>significantly minimizing interfacial energy losses. In this study, we propose a<br>co-adsorb (CA) strategy employing a novel small molecule, 2-chloro-5-(tri-<br>fluoromethyl)isonicotinic acid (PyCA-3F), introducing at the buried interface<br>between 2PACz and the perovskite/organic layers. This approach effectively<br>diminishes 2PACz’s aggregation, enhancing surface smoothness and increas-<br>ing work function for the modified SAM layer, thereby providing aflattened<br>buried interface with a favorable heterointerface for perovskite. The resultant<br>improvements in crystallinity, minimized trap states, and augmented hole<br>extraction and transfer capabilities have propelled power conversion effi-<br>ciencies (PCEs) beyond 25% in PSCs with a p-i-n structure (certified at 24.68%).<br>OSCs employing the CA strategy achieve remarkable PCEs of 19.51% based on<br>PM1:PTQ10:m-BTP-PhC6 photoactive system. Notably, universal improve-<br>ments have also been achieved for the other two popular OSC systems. After a<br>1000-hour maximal power point tracking, the encapsulated PSCs and OSCs<br>retain approximately 90% and 80% of their initial PCEs, respectively. This work<br>introduces a facile, rational, and effective method to enhance the performance<br>of SAMs, realizing efficiency breakthroughs in both PSCs and OSCs with a<br>favorable p-i-n device structure, along with improved operational stability.|



Interface engineering has made a great contribution to the development of solution-processable third-generation photovoltaic (PV) devices, bearing the hope of achieving carbon neutrality via sustainable energy production, like perovskite/organic solar cells (OSCs and PSCs)<sup>1–11</sup> . Poly(3,4-ethylenedioxythiophene) polystyrene sulfonate (PEDOT:PSS) is a benchmark hole transport layer (HTL), which has enabled continuous power conversion efficiency (PCE) breakthroughs, especially for those p–i–n structural PV devices, due to its favorable energy level and electron blocking ability<sup>12–16</sup> . However, its instability 

under external stress (light or heat) and acidity strongly restricted the device's stability<sup>17–19</sup> . Therefore, constructing low-cost and green solvent-processable HTL has become a critical research topic in recent years<sup>20–24</sup> . 

Self-assembled-monolayers (SAMs), particularly phosphonic acidbased ones, are nowadays the emerging star HTLs used in both PSCs and OSCs to boost PCE and stability<sup>25–30</sup> . Principally, SAM materials consist of (a) anchoring groups of bond with oxide substrates (e.g.: ITO) via covalent/coordinative bonds, (b) the terminal groups that 

> A full list of affiliations appears at the end of the paper. e-mail: ruijie.ma@polyu.edu.hk; zhiweipv.ren@polyu.edu.hk; gang.w.li@polyu.edu.hk; chengc@sustech.edu.cn 

Nature Communications |  (2024) 15:7605 

1 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

determine the surface properties such as work function (WF), and (c) the backbones called spacer groups connect anchoring and terminal groups. The ultrathin nature of SAMs can maintain the high transmittance of substrates well, which is beneficial to short-circuit current density (JSC). Meanwhile, SAM’s chemical bonding with substrates and non-acidity further guarantee the device's stability<sup>31–33</sup> . Furthermore, the low-cost and alcohol-processable features make them adaptive for photovoltaic commercialization. 

Notwithstanding their potential, the attainment of high-density, closely packed SAMs remains challenging, resulting in unpredictable interfacial properties. For instance, the inherent amphiphilic characteristics of SAMs often lead to undesirable self-aggregation, particularly in alcoholic solvents, inducing the formation of micelles<sup>34</sup> . An additional energetic barrier might be consequently formed during the disassembly of micelles while SAM molecules bind to the substrate surface. Thereby, a tightly compacted SAM structure cannot be easily and stably obtained<sup>34</sup> . Moreover, due to the rough substrate and solution-deposited methods, defects become inevitable in the monolayer, particularly for those regions that lack SAM coverage<sup>25</sup> . These defects are potentially inducing current leakage at the buried interface, causing energy loss and instability of optoelectronic devices<sup>35</sup> . 

Terminal functional groups within SAMs frequently experience significant aggregation, leading to notable losses at interfaces. To address this issue, numerous strategies have been investigated, such as optimizing SAM layer deposition techniques, implementing bilayer structures, and incorporating additives<sup>34,36</sup> . For example, the evaporation of Me-4PACz enhances the wettability and alters the morphology of perovskites without considerably impacting their chemical attributes. This approach effectively enhances the quality of interfaces on textured surfaces, contributing to near-lossless contacts<sup>37</sup> . The employment of a bilayer structure incorporating NiOx and SAM demonstrates promise in reducing interfacial losses and increasing surface coverage, fostering enhanced device stability<sup>38,39</sup> . Furthermore, employing small molecules, such as methyl phosphonic acid (MPA) and 3-mercaptopropionic acid (3-MPA) are able to minimize the interfacial energy loss at the SAM/perovskite with reduced aggregation<sup>40,41</sup> . These methodologies are primarily directed toward augmenting surface coverage, adjusting energy levels, and reducing energy dissipation at the perovskite/SAM junction. 

In the realm of dye-sensitized solar cells (DSSCs), researchers have employed a co-adsorbed strategy to mitigate dye aggregation and enhance device performance by a small molecule. The co-adsorbed strategy is originally utilized to combine dye absorption and reduce charge recombination on the surface of TiO242. Leveraging the widely utilized [2-(9H-Carbazol-9-yl)ethyl]phosphonic acid (2PACz) as the hole transport layer (HTL) in both perovskite solar cells (PSCs) and organic solar cells (OSCs), we incorporate a small molecule 2-chloro-5(trifluoromethyl)isonicotinic acid (PyCA-3F) with 2PACz to form a functionalized ultrathin layer, which is aimed to reduce SAM’s selfaggregation<sup>40,43–45</sup> . Our characterizations reveal that the 2PACz/PyCA3F co-adsorbed surface (denoted as CA) is smoother in surface roughness, with fewer agglomerates, and minimized interfacial nanovoids. Furthermore, the increased WF and narrower surface potential distribution at the SAM/perovskite interface enables a more p-type and uniform behavior, facilitating the hole extraction and transfer process at the buried interface<sup>46</sup> . For PSCs, the CA surface helps enhance grain grooves and increases the interfacial energy, which contributes to a flattened perovskite buried interface and reduced photovoltaic inactive phase, resulting in a remarkable PCE exceeding 25% for p-i-n devices. These advantages can also be extended to OSCs, with PM1:PTQ10:m-BTP-PhC6 photoactive system realizing a PCE of 19.51%, among the leading values. Furthermore, PBQx-Cl:PY-IT blend achieves a PCE of 17.77%, a decent value among all-polymer binary OSCs; the PM6:eC11 combination attains 17.71%, representing one of the best results for open-air blade coating devices cast by non-halogenated 

solvents ortho-xylene (o-XY). Notably, the operational stability, as indicated by maximal power point tracking (MPPT) results, scores the superiority of the CA approach for both PSCs and OSCs. In summary, our work presents a facile, rational, and effective co-adsorbed strategy to enhance the performance of SAM-based devices, resulting in efficiency breakthroughs for both PSCs and OSCs based on p–i–n device structure, coupled with enhanced operational stability. 

## Results 

### Evaluation of HTLs 

The chemical structures of 2PACz and PyCA-3F are presented in Fig. 1a. Concurrently, there also shows the HTL fabrication schemes of 2PACz SAMs and CA SAMs; the latter is formed by sequentially depositing 2PACz and PyCA-3F and a co-absorbed 2PACz/PyCA-3F dual molecule surface is expectedly constructed. The surfaces of ITO and HTLs are first investigated by atomic force microscopy (AFM) measurements. From the height images displayed in Figs. S1 and 1b–d, it is found that ITO has a highly rough surface, which is harmful for thin film formation, no matter perovskite (thickness around 800 nm) or organic (thickness around 100 nm), leading to poor crystallite organization order and general crystallinity, thus unsatisfying photovoltaic performance. The ITO itself demonstrates surface roughness around 3.71 nm. However, 2PACz SAM on ITO can lead to a slightly higher roughness of 4.02 nm, which can be a result of the aggregation of disordered 2PACz molecules on ITO<sup>35</sup> . Since the SAM’s thickness is within 5 nm, this can be taken as a trade-off of maintaining transmittance and smoothening surface. Moreover, the surface potential distribution of ITO, 2PACz, and CA is also measured by Kevin probe force microscopy (KPFM), as shown in the right panels of Fig. 1b–d. The contact potential difference (CPD) that can reflect the surface potential variations is extracted and shown in Fig. 1e. The bare ITO demonstrates a CPD of around 310 meV. For 2PACz, the CPD increases to 380 meV, indicating a more p-type surface with SAM deposition<sup>47,48</sup> . For CA, the CPD of 417 meV is obtained, demonstrating that the incorporation of PyCA-3F can further increase the WF49–51. Moreover, the CA surface gives a narrower full width at half maximum (FWHM) value of 20 mV than those of ITO (25 mV) and 2PACz (29 mV), demonstrating that a smooth and uniform surface is obtained. To gain more insight into SAM distribution, we perform the Scanning Electron Microscopy with energy dispersive X-ray analysis (SEM-EDX) upon ITO, 2PACz and CA, and the results are shown in Figure S2. The characteristic element Indium of ITO is easily observed in all three samples, facilitated by the ultrathin nature of SAM. For the 2PACz/ITO surface, the phosphorus element’s signal is clearly stronger than others, and the CA surface exhibits more fluorine response from PyCA-3F. Therefore, the special co-adsorbed strategy may result in a dual-molecule structured SAM surface, which is smoother and more uniform with reduced aggregation and thus could further improve the optoelectronic properties of photovoltaic devices. 

Next, the substrate transmittance spectra are measured as plotted in Fig. 1f. 2PACz and CA SAMs lead to almost no change to ITO’s original transmittance, so parasitic light absorption from HTLs is fundamentally eliminated and better JSC values can be foreseeable. Parallelly, the general X-ray photoelectron spectroscopy (XPS) detection is carried out. As shown in Fig. S3, the results show that the incorporation of PyCA-3F brings negligible changes to the general distribution of elements on ITO surfaces of 2PACz. In exploring the role of 2PACz in mitigating molecular aggregation in solution, dynamic light scattering (DLS) analyses were performed to examine the size distributions of 2PACz, CA, and PyCA-3F. The results, illustrated in Fig. S4, reveal that 2PACz exhibits a substantial hydrodynamic diameter of ~70 nm. In contrast, the incorporation of PyCA-3F results in a significant reduction in the hydrodynamic diameter of CA to about 40 nm. This reduction underscores the effectiveness of PyCA-3F in substantially diminishing the tendency of 2PACz molecules to aggregate in solution<sup>34,41</sup> . As evidence for inhibited aggregation in film, Atomic 

Nature Communications |  (2024) 15:7605 

2 

Article 

https://doi.org/10.1038/s41467-024-51760-5 



<!-- Start of picture text -->
(b) Rq = 3.71 nm<br>(a)<br>(c) Rq = 4.02 nm<br>2PACz in EtOH<br>Thermal Anneal<br>ITO substrate<br>(d)<br>Rq = 3.25 nm<br>PyCA-3F in EtOH<br>Thermal Anneal<br>(e) (f) (g)<br>ITO 100<br>ITO<br> 2PACz<br>2PACz<br> CA 80<br>CA<br>60 ITO<br>2PACz<br>40 CA<br>20 mV<br>25 mV<br>29 mV<br>20 WF<br>250 300 350 400 450 500 0<br>400 600 800 1000 17.5 17.0 16.5 16.0 15.5<br>Potential (mV)<br>Wavelength (nm) Binding Energy (eV)<br>). )%( ).<br>(Cstanouu. ttiTeamsnacnr (ytisItanenu.<br><!-- End of picture text -->

Fig. 1 | Evaluation of the HTLs. a Chemical structures of 2PACz and PyCA-3F, and schematic diagram of HTL/SAM fabrication. b The AFM height images and KPFM images of ITO substrates. c The AFM height images and KPFM images of 2PACz substrates. d The AFM height images and KPFM images of CA substrates. 

e Potential distribution plots of ITO, 2PACz, and CA films, the full width at half maximum (FWHM) values of ITO, 2PACz, and CA are 25, 29, and 20 mV, respectively. f The transmittance spectra of ITO, 2PACz, and CA substrates. g UPS spectra of ITO, 2PACz, and CA substrates. 

Force Microscopy-Infrared spectroscopy (AFM-IR) was utilized to explore the composition heterogeneity and identify specific moieties with a feature peak of 1460 cm<sup>−1</sup> in 2PACz, as shown in Figs. S5 and S15<sup>37,52</sup> . Compared to the 2PACz/ITO substrate, the CA sample exhibits a markedly more uniform distribution of the 2PACz ITO surface. This improved homogeneity suggests that the incorporation of PyCA-3F not only promotes even dispersion but also substantially reduces the clustering of 2PACz molecules on ITO. Additionally, in the mixed sample (mixing 2PACz and PyCA-3F in EtOH), a similar impediment to the aggregation of 2PACz is evidenced, further highlighting the efficacy of PyCA-3F<sup>41</sup> . 

Work function (WF) is an important factor for the surface property of HTLs, which represents the electron-blocking ability. Thereby, ultraviolet photoelectron spectroscopy (UPS) experiments are conducted to figure out the WF values, through locating the secondary electron cut-offs. As a result, the WF of three kinds of anode surfaces is 4.30 eV (ITO), 5.10 eV (2PACz), and 5.16 eV (CA) in Fig. 1g, respectively. 

Principally, possessing a high WF for HTL is beneficial to boosting hole extraction and transfer at the p-side, and dense coverage contributes, as well. The 2 or 3 nm thick 2PACz, though with higher WF, but less complete coverage and aggregation, can risk performance loss. However, the CA surface with further improved WF and reduced aggregation is supposed to compensate for the energy loss at the HTL side. Moreover, the hygroscopic nature of the CA substrate with a higher contact angle shown in Fig. S6 would be beneficial for enhanced crystallinity and reduced charge recombination at the HTL interfaces<sup>53–55</sup> . 

Subsequently, density functional theory (DFT) calculation is utilized to obtain an understanding of the incorporation of PyCA-3F on 2PACz. The electrostatic potentials (ESP) of 2PACz and PyCA-3F are displayed in Fig. 2a. For 2PACz, the electron-rich area (blue) and electron-poor area (red) are located in the carbazole group and phosphate group, giving the highest occupied molecular orbit (HOMO) and lowest unoccupied molecular orbit (LUMO) value of −4.82 and −1.61 eV, respectively. As for PyCA-3F, the electron-rich area 

Nature Communications |  (2024) 15:7605 

3 

Article 

https://doi.org/10.1038/s41467-024-51760-5 



<!-- Start of picture text -->
(a) (b) 2PACz/ITO (100) CA/ITO (100)<br>2PACz PyCA-3F<br>(c) (d)<br>0.9<br>2PACz<br>CA<br>0.8<br>0.7<br>0.6<br>0.5<br>0 10 20 30 40 50<br>Time (ps)<br>e<br>g<br>are<br>v<br>o<br>C<br>la<br>n<br>oitc<br>Far<br><!-- End of picture text -->

Fig. 2 | Calculation of the HTLs. a Electrostatic potential distribution of 2PACz and PyCA-3F calculated by DFT, the colors represent electron-rich area (blue) and electron-poor area (red). b Top view of equilibrated molecular representations on the ITO surface. c Fractional coverage of ITO surface by the 2PACz and 2PACz with 

PyCA-3F molecules. Note that the projected area of the simulated substrate is around 10,000 Å<sup>2</sup> . d The adsorption process of 2PACz and PyCA-3F molecules on the ITO substrate. The interfacial structures within small circles are magnified in larger circle areas. 

and electron-poor area are located in the pyridine group and trifluoromethyl group, providing a HOMO and LOMO of −3.54 and −2.49 eV, respectively. Both the electron-rich group and electron-poor group are potentially beneficial for the passivation of the negative and positive defects at the perovskite interface. Figure S7 and Table S1 offer the calculated WF from potential and EF. The derived WF values for 2PACz and CA SAMs are 5.09 and 5.18 eV, respectively<sup>56,57</sup> . The incorporation of PyCA-3F leading to a more p-type surface of CA SAMs is in consistent with KPFM and UPS results above. To better elucidate the interaction mechanism between 2PACz and PyCA-3F, classical molecular dynamics simulations have been performed to elucidate the interaction mechanisms between 2PACz and PyCA-3F molecules on the ITO substrate in Fig. 2b. The simulation results indicate that the 2PACz/ITO surface experiences pronounced phase segregation, even though the molecules are initially uniformly placed near the ITO surface. As shown in Figs. 2c and S8, the coverage surface of 2PACz with PyCA-3F is always larger than that of 2PACz on ITO, indicating that PyCA-3F can effectively reduce the aggregation of 2PACz. The coverage surfaces of both systems increase and then level off as a function of the simulation time, which confirms the SAMs reach an equilibrium state on the ITO surface. Figure 2d further illustrates the interfacial structure between 2PACz and PyCA-3F on the ITO surface. The molecular dynamics simulations results reveal that PyCA-3F restricts the mobility of 2PACz molecules by creating a complex structure, significantly mitigating their tendency to clump together. In particular, the trifluoromethyl groups in PyCA-3F form hydrogen bonds with the phosphonic acid groups of 2PACz. These resulting complexes play a crucial role in curbing the development of larger aggregates by constraining the interactions among adjacent 2PACz molecules. It has been observed that PyCA-3F can assume a transient surface adsorption mode, wherein the carboxylate groups are anchored to the surface while the trifluoromethyl groups extend nearby. This configuration can facilitate the attraction of other unanchored 2PACz molecules that are diffusing freely, guiding them toward the surface. 

### Evaluation of 2PACz/PYCA-3F based p–i–n inverted perovskite solar cells (PSCs) 

We first examine the growth of perovskite films on 2PACz substrates with and without PyCA-3F. The perovskite films are carefully lifted off using UV epoxy and cover glass, enabling the examination of both the top and buried surfaces of perovskite films (Fig. S9)<sup>58</sup> . The top-view SEM images (Fig. S10) reveal similar top surface morphology for the two perovskite films, regardless of the presence of PyCA-3F. In both perovskite films, discernible perovskite grains with grain sizes approaching 1 μm are prominently observed, where the excess Pb-rich phase is distributed around the perovskite grain boundaries in both cases, in consistent with the excess PbI2 that is regarded as better perovskite growth and trap passivation<sup>59</sup> . The buried interface for both perovskite films shows analogous morphology without excess Pb-rich phase in Fig. 3a and b, conforming to the “From top to down” perovskite growth orientation<sup>58</sup> . However, noticeable nanovoids are observed at the buried surface when perovskite film is directly deposited on 2PACz similar to previous report<sup>60</sup> . In contrast, the buried surface of perovskite films on CA is flat and densely compacted<sup>61,62</sup> . These results are also supported by the XRD results (Fig. S11): the excess Pb-rich phase is absent at the buried side of perovskite films but exists on the top side for both cases<sup>63</sup> . Similarly, to visualize the roughness of both top/buried interfaces, atomic force microscopy (AFM) measurement is conducted. As shown in Figs. 3c and d and S12, AFM height images for the top surface and buried interfaces of both perovskite films reveal a subtle reduction in surface roughness with the incorporation of PyCA-3F. This observation suggests that the coadsorbed strategy employed does not induce significant changes in surface morphology but is more likely to change the properties of the buried interface. 

To gain deeper insights into the impact of PyCA-3F incorporation at the buried interface, we introduce perovskite grain boundary groove angles, which are consistently formed through the residue solvent evaporation process, guiding the top-down grain growth direction<sup>58,61</sup> . We postulate that PyCA-3F serves as a mediating bridge, 

Nature Communications |  (2024) 15:7605 

4 

Article 

https://doi.org/10.1038/s41467-024-51760-5 



<!-- Start of picture text -->
(a) (b) (c) (d)<br>2PACz CA 2PACz CA<br>500 nm 500 nm<br>Voids<br>(e) (f) 2PACz (g) CA (h)<br>Perovskite Perovskite<br>Grain Grain<br>φ θ<br>SAM/ITO<br>(i) (j) (k) (l)<br>10 4 2PACz 10 4 CA CA top2PACz top 2PACz BuriedCA Buried<br>10 3 PbI - 10 3 PbI - Pb 2+  4f7/2 Pb 2+  4f7/2<br>10 2 PO2- 10 2 PO2 - Pb 2+  4f5/2<br>F - F - Pb 2+  4f5/2<br>10 1 SnO2- 10 1 SnO2 -<br>PyCA-3F<br>10 0 0 200 Perovskite 400 600 800 SAM/ITO 1000 10 0 0 200 Perovskite 400 600 800 SAM/ITO 1000 148 144 140 136 148 144 140 136<br>(m) Time (s) (n) Time (s) (o) Binding Energy (eV) (p) Binding Energy (eV)<br>).(ytisItanenu. ).(ytisItanenu. ).(ytisItanenu. ).(ytisItanenu.<br><!-- End of picture text -->

Fig. 3 | Evaluation of perovskite/HTL interfaces. a SEM images of the buried interface of 2PACz-based perovskite film. b SEM images of the buried interface of CA-based perovskite film, the scale bar is 500 nm. c AFM images of the buried interface of 2PACz-based perovskite film. d AFM images of the buried interface of CA-based perovskite film. e The illustration of grain groove angles at the buried interface. f high-resolution AFM images of the buried interface of 2PACz-based perovskite film, the grain boundary groove angles are estimated to be 51°. g highresolution AFM images of the buried interface of CA-based perovskite film, the grain boundary groove angles are estimated to be 118°. h The illustration of the flattened grain groove angles with PyCA-3F. i TOF-SIMS images of the buried 

interface of 2PACz-based perovskite film. j TOF-SIMS images of the top surface of CA-based perovskite film. k XPS spectra of Pb4f at the buried interface of 2PACz and CA perovskite films. l XPS spectra of Pb4f at the buried interface of 2PACz and CA perovskite films. m GIWAXS patterns of the top surface for 2PACz-based perovskite films, the incidenceangle is 0.5°. n GIWAXS patterns of the top surface for CA-based perovskite films, the incidence angle is 0.5°. o GIWAXS patterns of the buried interface for 2PACz-based perovskite films, the incidence angle is 0.05°. p GIWAXS patterns of the buried interface for CA-based perovskite films, the incidence angle is 0.05°. 

influencing the modification of heterointerface energy at the perovskite/2PACz interface. In Fig. 3e, the interplay between grain boundary energy (γGB), heterointerface energy (γHI), grain boundary groove dihedral angle (φ), and the side angle (θ) between SAM/ITO and perovskite film is illustrated. The relationship between γGB and γHI is defined by the following equation: 



<!-- Start of picture text -->
γGB φ<br>γHI = 2 cos�2� = 2 sinðθÞ ð1Þ<br><!-- End of picture text -->

Figure 3f and g presents the peel-offed buried interface height profiles obtained through high-resolution AFM. The control film (peeled from 2PACz) exhibits a buried grain boundary groove angle (φ1) of 51°. In contrast, the incorporation of PyCA-3F results in a 

substantially larger groove angle (φ2) of 118°, indicative of a notably higher heterointerface energy. As the scheme of groove angles shown in Fig. 3h, the significant augmentation in groove dihedral angles, evident in the presence of PyCA-3F, plays a pivotal role in mitigating the occurrence of physical nanovoids at the buried interface. This notable increase stands as a strategic advantage, contributing to the effective reduction of interfacial traps and nonradiative centers at the buried interface. 

The distribution of PyCA-3F in perovskite films is investigated by time-of-flight secondary-ion mass spectroscopy (ToF-SIMS) for ITO/ 2PACz (with or without PyCA-3F)/Perovskite. As shown in Fig. 3i and j, the intensity tracing of SnO2−, PO2−, PbI− and F− are prosecuted for both perovskite films with and without PyCA-3F, which referred to the existence of ITO, 2PACz, perovskite, and PyCA-3F, respectively. In the 

Nature Communications |  (2024) 15:7605 

5 

Article 

https://doi.org/10.1038/s41467-024-51760-5 



<!-- Start of picture text -->
(a) (b) (c) 100<br>-25 25<br>2PACz<br>80<br>-20 CA 2PACz 20<br>60 CA<br>-15 15<br>-10 VOC JSC FF PCE 40 10<br>2PACz 1.14 24.86 0.82 23.36<br>-5 20 5<br>CA 1.17 25.22 0.86 25.12<br>0 0 0<br>0.0 0.2 0.4 0.6 0.8 1.0 1.2 400 500 600 700 800<br>Voltage (V) Wavelength (nm)<br>(d) 0 (e) (f)<br>1.04 V, 24.84%<br>25 1.0 1.0<br>-5<br>0.98 V, 23.04% 20<br>-10<br>2PACz 2PACz<br>15 0.8 CA 0.8 CA<br>-15<br>10<br>-20 23.50 mA/cm 2 5 0.6 Thermal stability, 0.6<br>-25 23.88 mA/cm 2 Unencapsulated, 65℃, N2<br>0 50 100 150 200 250 3000 0 200 400 600 0 200 400 600 800 1000<br>Time (h) Time (h)<br>Time (s)<br>2)<br>m<br>c/ )<br>(Am %(ytis<br>n<br>ytisne Iten<br>Dtn QE<br>e E<br>rr<br>u<br>C<br>Integrated Current Density (mA/cm2)<br>2)<br>m<br>c/ ) )<br>(Am %(E %(E<br>C C<br>ytis P P<br>n d d<br>e e e<br>D SPO (%)<br>tn zila zila<br>Cerru Nmro Nmro<br><!-- End of picture text -->

Fig. 4 | Device performance of PSCs. a Energy level of the top surface and buried interface of 2PACz and CA-based perovskite films. b J–V curves of 2PACz and CAbased devices. c EQE curved of both 2PACz and CA-based devices. d Steady output 

of 2PACz and CA-based devices. e Thermal stability of 2PACz and CA-based devices. f Operational stability of 2PACz and CA-based devices. 

target film, a notable signal attributed to the presence of PyCA-3F becomes evident within the time range of 800–1000 s, represented by a significant F<sup>−</sup> signal. Additionally, the shared positions of SnO2−, PO2−, and F<sup>−</sup> signals indicate chemisorption interactions occurring among ITO, 2PACz, and PyCA-3F on the ITO surface, particularly in proximity to the interface between the perovskite and ITO as shown in Fig. S13. These observations collectively suggest that the inclusion of PyCA-3F may not happen in the perovskite formation process or penetrate to the perovskite grain boundary and the top surface but firmly anchoring at the perovskite/2PACz interface. 

The interaction between perovskite and PyCA-3F is carried out by X-ray photoelectron spectroscopy (XPS) and is shown in Figs. 3k, l and S14. At the top surface, no apparent shifting can be observed in either Pb4f or the I3d peaks, indicating that the PyCA-3F does not participate in the interaction at the top surface. In contrast, at the buried interface, the Pb4f and I3d peaks have shifted: from 143.0 and 138.2 eV to 142.8 and 138.0 eV for Pb4f, and for I3d, shifted from 630.6 and 619.1 eV to 630.4 and 618.9 eV, respectively, demonstrating the interaction between perovskite and molecule at the buried interface. The slight downward shift observed in the binding energies of Pb4f and I3d can be attributed to the interaction between Pb<sup>2+</sup> and PyCA-3F. This suggests that PyCA-3F can passivate uncoordinated Pb<sup>2+</sup> ions, consequently diminishing the propensity for metallic lead formation<sup>64–66</sup> . Moreover, attenuated total reflectance Fourier transform infrared spectroscopy (ATR-FTIR) measurement is conducted for both 2PACz and CA films in Fig. S15. The presence of 2PACz is clearly indicated by the peaks in the vicinity of 1234 cm<sup>−1</sup> , corresponding to P = O vibrations, which shift to 1236 cm<sup>−1</sup> with the incorporation of PyCA-3F<sup>67–69</sup> . To further confirm the interaction at the buried interface, as shown in the FTIR results of 2PACz-PbI2 and CA-PbI2, the C-N vibrations and C–H vibrations, initially identified around 1065 and 800 cm<sup>−1</sup> , respectively, experience a shift of ~2 cm<sup>−1</sup> in the presence of PyCA-3F. These observed shifts signify the enhanced binding of perovskite and 2PACz following the incorporation of PyCA-3F<sup>70,71</sup> . 

The crystalline structure of perovskite films is investigated using angel-dependent grazing incidence wide-angle X-ray scattering 

(GIWAXS) measurements for both perovskite top surface and buried interface in Figs. 3m–p, S16 and S17. Three different incidence angles (0.05°, 0.3°, and 0.5°) are selected to analyze the perovskite film’s characteristics at the top surface, bulk, and near the buried interface, respectively<sup>72,73</sup> . Similarly, the perovskite films exhibit a predominant peak at a q ~ 1.02 Å<sup>−1</sup> , corresponding to the (100) plane of FAPbI359,74. Interestingly, the presence of a PbI2 phase at q = 0.94 Å<sup>−1</sup> can be observed in the 2PACz-based perovskite films (both top and buried), but this peak tends to vanish in the buried interface of the control perovskite film with an incidence angle of 0.05° (Fig. S18), indicating that the PbI2 is more likely to distribute at the top surface/bulk rather than the buried interface<sup>75</sup> . However, this PbI2 peak is not detected in any of the perovskite buried interfaces, which agrees with the XRD results. Furthermore, a small peak corresponding to the δ-FAPbI3 phase at ~0.77 Å<sup>−1</sup> is exclusively observed in the 2PACz-based buried interface, while both the top surface and buried interface of the CAbased perovskite films are free of δ-FAPbI3 (Fig. S18)<sup>76</sup> . The presence of the photoinactive δ phase, with its low absorption coefficient and nonperovskite nature, could inherently hinder the device's performance. Consequently, the utilization of PyCA-3F is found to be advantageous in reducing the photoinactive PbI2 and δ-FAPbI3 and enhancing perovskite crystallinity. 

Energy level variations are characterized using ultraviolet photoelectron spectroscopy (UPS). As depicted in Figs. 4a and S19, no significant changes are observed for the top surface of either the control or target perovskite films. However, a substantial variation in energy levels can be detected at the buried interface of the target perovskite film compared with the control. The initial valence band maximum (VBM) and work function (WF) at the buried interface are measured to be −5.42 eV and 4.20 eV, respectively. With the presence of PyCA-3F, VBM, and EF were found at −5.49 and 4.57 eV<sup>77</sup> . These findings are similar to the UPS and KPFM results obtained for ITO/2PACz and ITO/ CA discussed earlier. In addition, the downshifted VBM and slight p-typed shifting of the buried interface in the CA perovskite film contributes to a narrower energy gap across the top/buried interface, resulting in a reinforced built-in electric field that improves carrier 

Nature Communications |  (2024) 15:7605 

6 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

extraction and transfer<sup>78</sup> . These analogous results can also be obtained from the KPFM images shown in Fig. S20. The top surface for both perovskite films demonstrated a close surface contact potential difference (CPD) of around −330 meV. In contrast, the buried interface growth on 2PACz delivers a CPD of around 5 meV. With PyCA-3F, the CPD increases to 25 meV for the buried interface of CA. Moreover, the buried interface of CA shows a more centralized distribution, demonstrating a flattened surface with less potential distribution difference. Furthermore, the similar results of the buried interface that the increased WF, accompanied by a more p-type behavior in the CAbased perovskite films, is expected to facilitate hole extraction and transfer at the buried interface with a p-type contact<sup>79</sup> . 

To investigate the introduction of PyCA-3F on carrier dynamics, steady-state photoluminescence (PL) and time-resolved photoluminescence (TRPL) measurements are performed. As illustrated in Fig. S21, both perovskite films exhibit similar PL peak positions, centered around 790 nm. Notably, the CA/perovskite film shows an enhanced PL intensity compared to the control film, suggesting a reduction in trap states and suppressed nonradiative recombination<sup>41</sup> . This phenomenon of enhanced PL intensity is also observed at the buried interface. Additionally, the TRPL results (Fig. S21 and Table S2) demonstrate that the carrier lifetime of the perovskite film cast on CA was prolonged, indicating the suppression of trap-assisted nonradiative recombination with the incorporation of PyCA-3F at the buried interface<sup>77</sup> . The suppression of nonradiative recombination and favorable carrier dynamics can inherently contribute to improved device performance, particularly in terms of VOC and FF. 

Furthermore, space-charge-limited current (SCLC) measurement is conducted with the device structure of ITO/2PACz (with or without PyCA-3F)/Perovskite/PTAA/Cu. The trap-filling limit voltage (VTFL) is denoted to be the transition of the ohmic region and TFL region, where the trap density (Nt) is associated with VTFL and can be calculated by the equation: 



<!-- Start of picture text -->
2ε0εV TFL<br>Nt = ð2Þ<br>eL 2<br><!-- End of picture text -->

ε0, ε represent vacuum permittivity, dielectric constant and e, L represent element charge, perovskite film thickness, respectively. As shown in Fig. S22 and Table S3, the control devices deliver a VTFL of 1.28 V, corresponding to a Nt of 3.09 × 10<sup>15</sup> cm<sup>−3</sup> , while the device with PyCA-3F performed a VTFL of 0.86 V, showing a much smaller Nt of 2.08 × 10<sup>15</sup> cm<sup>−3</sup> , indicating that the trap density is reduced in CA-based PSCs, which can result from the smooth and uniform buried interface. 

To investigate the impact of the buried interface on photovoltaic performance, inverted perovskite solar cells are fabricated with the following architecture: ITO/2PACz/Cs0.05(FA0.98MA0.02)0.95Pb (I0.98Br0.02)3/C60/BCP/Cu, where the deposition of PyCA-3F process is before the fabrication of perovskite films. Figure 4b shows that the control device achieved a peak power conversion efficiency (PCE) of 23.3%, with a VOC of 1.14 V, Jsc of 24.85 mA/cm², and FF of 82%. In contrast, the device based on CA realizes a champion efficiency of over 25%, featured by a VOC of 1.17 V, a JSC of 25.21 mA/cm², and an outstanding FF of 86%. Additionally, external quantum efficiency (EQE) measurements are conducted (Fig. 4c), supporting an integrated current density of 24.7 mA/cm² for the control and a slightly higher one of 25.0 mA/cm² for the target, which suggests the high accuracy of J–V measurement. The CA-based device exhibits a stabilized PCE of 24.84% and a stabilized VOC of 1.04 V, while the 2PACz-based device could only produce a 23.04% stabilized PCE (Fig. 4d). The statistic distribution of 2PACz and CA are shown in Fig. S23, where the Mixed devices (by mixing 2PACz and PyCA-3F as HTL) also show superior performance to 2PACz-based devices. The enhancement in PCE can be ascribed to the rise in both VOC and FF, leading to a minimized voltage loss of 0.36 for 

1.53 eV bandgap perovskite (as determined from the EQE plots, certified 24.68%, Figs. S24 and S25). 

We also evaluate the thermal stability of the devices under continuous annealing at 65 °C for ~650 h. The target device maintained 92% of its initial efficiency, outperforming the control device, which retained 87% (Fig. 4e). More critically, the operational stability of the devices is evaluated by maximum power point tracking (MPPT) under ambient atmosphere conditions<sup>80</sup> . As shown in Fig. 4f, the CA devices can retain ~90% of their initial efficiency after 1000 h- tracking, while the control devices suffer from a rapid fall, with efficiency dropping to 72% after approximately 450 h. To further confirm the enhanced stability of the CA approach, we used an accelerating aging test by deliberately annealing the devices at 85 °C with light soaking, as shown in Fig. S26. After aging for ~200 h, the increased amount of unwanted nanovoids can be observed at the buried interface of the 2PACz-based device. Under operational conditions, these nanovoids were found to be sensitive to light irradiation and thermal disturbance and initialize the structural evolution and degradation of solar cells. One possible degradation mechanism of the buried interface is the formation and expansion of a void structure under light and thermal stimuli. The existence of nanovoids within the 2PACz device amplifies inhomogeneity, leading to an intensified current near the tip in areas abundant with defects. This intensification can generate additional Joule heating, potentially accelerating the evolution of the perovskite structure. Moreover, these voids can block the transport of charge carriers, resulting in less efficient collection in areas near the voids. Conversely, a buried interface that is free of voids and an HTL surface with reduced aggregation contribute to enhanced device stability<sup>81</sup> . Therefore, the device performance of inverted PSCs can be comprehensively (both efficiency and stability) improved by the CA approach. 

Evaluation of 2PACz/PYCA-3F-based organic solar cells (OSCs) To comprehensively assess the general applicability of our CA approach, based on ITO/HTL/PM1:PTQ10:m-BTP-phC6/PFN-Br-MA/ Ag p–i–n configuration, we also fabricated a series of OSCs to compare the performance of PEDOT:PSS, 2PACz and CA<sup>82–84</sup> . The optimization of PM1:PTQ10:BTP-phC6 ternary system weight ratio is presented in Table S4. Poor efficiency is observed in ITO-only devices, due to severe surface recombination. PEDOT:PSS can effectively promote the PCE to a near 19% level, contributed by decent VOC, JSC, and FF. Alternated by 2PACz, the target device can achieve a 19.06% efficiency, generated by JSC increase, but limited by the tiny reductions in VOC and FF. Next, 19.51% PCE is realized by the CA strategy, where SAM-enabled JSC promotion is kept, and VOC × FF gets closer to PEDOT:PSS-based devices. The mentioned materials are drawn in Fig. 5a; J–V characteristics are in Fig. 5b; PV parameters are summarized in Table S5. Nevertheless, The PCE of OSCs is influenced by an amalgamation of both surface electronic and morphological properties. The elevated contact angle observed with CA substrates could lead to suboptimal surface coverage in comparison to the hygroscopic PEDOT:PSS, thereby resulting in marginally reduced Voc and FF<sup>51,85</sup> . To assure the measurement accuracy, the EQE spectra of them are also given in Fig. 5c. The integrated JSC values guarantee that errors are within 5%. Besides, the spectra shape of PEDOT:PSS device is different from others, in consistency with its transmittance tuning effect. Furthermore, we compare the transmittance spectra and EQE spectra of devices to ensure there are no abnormally high EQE spectra in Fig. S27. In addition, the PCE average values are collected from at least 20 independent devices in Figs. 5d and S28a–S28c, confirming the reliability and reproducibility and corresponding to the J–V results. 

Corresponding basic device physics characterizations are implemented upon all four groups of OSCs. The dark current curves of them 

Nature Communications |  (2024) 15:7605 

7 

Article 

https://doi.org/10.1038/s41467-024-51760-5 



<!-- Start of picture text -->
(b) (c)<br>(a) 5 100<br>0<br>ITO 80<br>-5 PEDOT:PSS<br>-10 2PACz 60 ITO<br>CA PEDOT:PSS<br>-15 40 2PACz<br>-20 CA<br>20<br>-25<br>-30 0<br>0.0 0.2 0.4 0.6 0.8 1.0 400 600 800 1000<br>Voltage (V) Wavelength (nm)<br>(d)22 (e)<br>ITO<br>20 1e2 PEDOT:PSS<br>CCl2H5 C4H9 N N 18 1 2PACzCA<br>S S S S S S S n 108 ITO2PACzPEDOT:PSS 1e-2<br>S C6H13 C4H9 C4H9 C6H13 6 CA 1e-4<br>Cl<br>C4H9 C2H5 PBQx-Cl 4 1e-6<br>-1.0 -0.5 0.0 0.5 1.0<br>(f) (g)5 (h) 100 Voltage (V)<br>100<br>0<br>PBQx-Cl:PY-IT 80<br>80<br>-5 PEDOT:PSS<br>6040 PM1:PTQ10:m-BTP-phC6 -10 CA2PACz 6040 PBQx-Cl:PY-IT PEDOT:PSS<br>PEDOT:PSS -15 2PACz<br>20 2PACzCA -20 20 CA<br>0 -25 0<br>0 500 1000 1500 2000 2500 0.0 0.2 0.4 0.6 0.8 1.0 300 450 600 750 900<br>Time (h) Voltage (V) Wavelength (nm)<br>(i) (j) 5 (k) 100<br>0<br>PM6:eC11 (Open-air blade coating) 80<br>-5 PEDOT:PSS<br>2PACz 60<br>-10<br>CA<br>-15 40<br>PM6:eC11 (Open-air blade coating)<br>-20 PEDOT:PSS<br>20 2PACz<br>-25<br>CA<br>-30 0<br>0.0 0.2 0.4 0.6 0.8 1.0 300 450 600 750 900<br>Voltage (V) Wavelength (nm)<br>-2 )<br>m<br>c<br>A<br>m ( )%<br> ytis (<br>n E<br>e Q<br>D E<br> t<br>n<br>e<br>rr<br>u<br>C<br>2 )<br>m<br>c/<br>A<br>)% m (<br>(<br>CEP  ytisDne<br> t<br>n<br>e<br>rr<br>u<br>C<br>)% 2c/m )<br>(  A<br>CEP m ( )%(<br>de  ytisDne QEE<br>zila  tn<br>Nmro Cerru<br>2 )<br>m<br>c/<br>A<br>m ( )%<br>(<br> ytis E<br>n Q<br>e E<br>D<br> t<br>n<br>e<br>rr<br>u<br>C<br><!-- End of picture text -->

Fig. 5 | Device performance of OSCs. a Chemical structures of PM1, PTQ10, m-BTPphC6, PBQx-Cl, and PY-IT, which are materials used in spin-coating devices. b J–V characteristics and c EQE spectra of PM1:PTQ10:m-BTP-phC6 (weight ratio = 0.8:0.2:1.2) ternary blend devices based on bare ITO, PEDOT:PSS, 2PACz, and CA. d Normal distribution of PCEs and e dark current curves of above systems. f Opencircuit type MPP tracking curves of the devices based on PEDOT:PSS, 2PACz, and 

CA. g J–V characteristics and h EQE spectra all-polymer blend PBQx-Cl:PY-IT-based devices of PEDOT:PSS, 2PACz, and CA, respectively. i Schematic diagram of openair blade coating device fabrication by using PM6:eC11 blend solution dissolved in ortho-xylene on PEDOT:PSS, 2PACz, and CA surface. Relative j J–V characteristics and k EQE spectra. 

are demonstrated in Fig. 5e, in the form of semi-log coordination. The bare ITO-based device presents a high dark current signal and a low turning point of applied voltage, indicating severe current leakage and poor diode ideality. Meanwhile, the 2PACz-enabled device exhibits a higher dark current than PEDOT:PSS-based one, but CA-modified anode can realize a dark current nearly identical to that in PEDOT:PSS case. These results imply the CA-based OSCs can play a similar role in realizing high FF as PEDOT:PSS does. Besides, dark current dataderived photocurrent (Jph) vs. effective voltage (Veff) relationships of them are illustrated in Fig. S28d. The details for derived parameters and methods are elaborated in Table S6. These results support the best FF of PEDOT:PSS and high JSC of SAM. Moreover, the light intensitydependent VOC and JSC values are depicted in semi-log and full-log forms in Fig. S28e and S28f, respectively. As a result, the main difference among the four groups is the competition between trapassisted recombination and surface recombination, while the 

bimolecular one is found to be similar<sup>86</sup> . Last, the operational stability of the devices under 1-sun illumination is tracked as shown in Fig. 5f. PEDOT:PSS-based devices are observed a very fast degradation, within 500 h. 2PACz is better and maintains ca. 60% initial efficiency after nearly 1000-h tracking. The hybrid CA-based PM1:PTQ10:m-BTP-phC6 cells display two times longer lifetime compared with 2PACz, where 80% initial PCE is kept at >1000 h point and 60% maintaining the rate at ca. 2000-h tracking time in total. 

After the success in high-efficiency polymer donor vs. small molecular acceptor type OSCs, the CA strategy is also extended to some other organic systems: (1) non-halogenated solvent processed binary all-polymer solar cells (PBQx-Cl:PY-IT)<sup>87,88</sup> ; (2) non-halogenated solvent-based room temperature open-air blade coating binary OSCs (PM6:eC11)<sup>89</sup> . As given in Fig. 5g, h and Table S5, SAM (2PACz or CA) type modifications can promote the PCE in a similar way, and the results in one of the highest efficiencies of hydrocarbon solvent 

Nature Communications |  (2024) 15:7605 

8 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

processed binary all-polymer solar cells. In Fig. 5i, we provide a schematic diagram for open-air blade coating photoactive layer fabrication. Both PEDOT:PSS and SAM are air-stable, supporting the feasibility of this experiment. Similarly, the results in Fig. 5j, k and Table S5 substantiate the general applicability of CA’s efficiency enhancement effect. Meanwhile, 17.71% is one of the greatest PCEs for high-boiling point green solvent-enabled blade coating OSCs. 

## Discussion 

In summary, our work demonstrated a co-adsorbed (CA) approach to rationally modify the SAM-based HTL layer, yielding significantly improved stability and PCEs for both PSCs and OSCs of p-i-n configuration. Theoretical investigations reveal that PyCA-3F, through a coadsorbed strategy with 2PACz, facilitates the formation of a smooth surface and a favorable energy band alignment, thereby reducing the energy barrier between 2PACz and the perovskite/organic layers. Furthermore, the CA approach flattens the buried interface of the perovskite layer, leading to an enhanced heterointerface energy and a defect-free interface feature, thus minimizing the energy loss therein. This improvement is effectively translated to promote efficiency and operational stability of corresponding PSCs and OSCs. Our study demonstrates a successful case of a facile, rational, and effective modification of the SAM-based HTL layer towards more efficient solution-processable PVs. 

## Methods 

### Materials 

Cesium iodide (CsI), methylamine hydrochloride (MACl), formamidinium iodide (FAI), Lead bromide (PbBr2) methylamine hydrobromide (MABr), and lead iodide (PbI2) are purchased from Advanced Election Co., Ltd. C60, and BCP are obtained from Xian Yurisolar Co., Ltd. PyCA-3F is obtained from Bidepham. PEDOT:PSS (Al 4083) is from Hareus. 2PACz and is obtained from TCI. Co., Ltd. PM1, PBQx-Cl, PY-IT, PM6, and eC11 are from Solarmer Inc. m-BTP-PhC6 is from eFlex PV Inc. PTQ10 is from 1-Materials Inc. Other chemicals and solvents are purchased from Sigma-Aldrich Co., Ltd. and used without further purification. 

### Hole transport layers (HTLs) fabrication 

The ITO substrates were first washed with detergent and then sonicated with deionized water, acetone, and isopropanol subsequently, and dried by N2. The cleaned substrates were treated with UV-Ozone for 20 min. Afterward, SAM (2PACz, 0.5 mg/ml in EtOH) was spincoated to the substrates at 4000 rpm for 30 s, followed by annealing at 100 °C for 10 min. After cooling down to room temperature, the 2PACz film surface was washed with ethanol at 3000 rpm for 30 s and annealed at 100 °C for 10 min subsequently. As for co-adsorption deposition, EtOH solution was replaced by PyCA-3F (1 mg/ml in EtOH) and annealed at 100 °C for 10 min. For mixed HTL, 2PACz and PyCA-3F (9:1, w/w) were mixed with a total concentration of 0.5 mg/ml and were spin-coated onto the ITO substrates at 4000 rpm for 30 s, followed by annealing at 100 °C for 10 min to achieve mix substrate. For PEDOT:PSS deposition, PEDOT:PSS (Al4083 from Hareus) was spin-cast onto the ITO substrates at 7500 rpm for 30 s, and then dried at 160 °C for 15 min in N2 atmosphere. 

immediately annealed at 110 °C for 20 min. Then, the films are transferred to the evaporation chamber, C60 and BCP are thermal evaporated successively for 40 and 8 nm, respectively. The devices are completed with the deposition of 100 nm Cu. 

Organic solar cell fabrication. As for the organic photoactive layer, the PM1:PTQ10:m-BTP-PhC6 blend (weight ratio is 0.8:0.2:1.2) is dissolved in chloroform (the concentration of donor was 7 mg/ml), with 1-chloronaphthalene (0.7 vol%) an additive, and stirred at 45 °C hotplate for 1 h. The blend solution was spin-cast at 3000 rpm for 30 s onto HTLs, followed by a temperature annealing of 100 °C for 1 min. A thin PFN-Br-MA layer (0.5 mg/ml in methanol and 0.25 wt% melamine, 3000 rpm) was coated on the active layer, followed by the deposition of Ag (evaporated under 3 × 10<sup>−4</sup> Pa through a shadow mask). The optimal active layer thickness measured by a Bruker Dektak XT stylus profilometer was about 110 nm. 

### Characterization 

UV–vis absorption spectra were measured using a Shimadzu UV-2500 recording spectrophotometer. AFM measurements were obtained by using a MultiMode 8-HR atomic force microscope (AFM, Bruker) in a tapping mode, and KPFM measurements were recorded using FMKPFM mode. SEM-EDX was recorded by a Hitachi SU8230 scanning electron microscope (SEM) with an accelerating voltage of 5 kV. The samples for GIWAXS measurements were fabricated on silicon substrates using the same recipe for the devices. X-ray diffraction (XRD) analyses were conducted utilizing a Bruker ECO D8 diffractometer, equipped with Cu Kα radiation (λ = 1.5418 Å). X-ray photoelectron spectroscopy (XPS) and ultraviolet photoelectron spectroscopy (UPS) measurements were performed using an ESCALAB XI electron analyzer (Thermo Fisher Scientific) with an X-ray source (Al Kα, hν = 1486.7 eV) and helium ionization source (He Iα, hν = 21.22 eV). To mitigate the impact on the measured work function by the instrument, a bias voltage of −7 V was systematically applied during the experiments. Steady-state photoluminescence (PL) and time-resolved photoluminescence (TRPL) transient decay spectra were acquired using an FLS920 PL spectrometer from Edinburgh Instruments, attenuated total reflection Fourier transform infrared spectroscopy (ATRFTIR) measurements utilized a Bruker Vertex 70v system. And atomic force microscopy-infrared spectroscopy (AFM-IR) analyses were conducted with a nano-IR3 system from Bruker. Dynamic light scattering (DLS) measurements were performed using Malvern Zetasizer Nano ZS. 

The current density–voltage (J–V) curves of devices were measured using a Keysight B2901A Source Meter in the glove box under AM 1.5 G (100 mW cm<sup>−2</sup> ) using an Enlitech solar simulator (Enlitech SSF7-3A). The device contact area was 0.086 cm<sup>2</sup> , device illuminated area during testing was 0.084 cm<sup>2</sup> , which was determined by a nonreflective metal mask. The J–V curves were measured by reverse scanning (from 1.30 to −0.02 V) and then forward scanning (from −0.02 to 1.30 V), the voltage step of 0.02 V and the delay time of 10 ms. The EQE spectra were measured using a Solar Cell Spectral Response Measurement System QE-R3011 (Enlitech Co., Ltd.) with AC mode. The light intensity at each wavelength was calibrated using a standard monocrystalline Si photovoltaic cell. The MPP tracking was carried out upon epoxy encapsulated devices under 1-sun white LED array in air. 

### Perovskite solar cell fabrication 

For perovskite precursor deposition, perovskite solution with a molar concentration of 1.6 M was prepared elsewhere with a stoichiometric composition of Cs0.05(FA0.98MA0.02)0.95Pb(I0.98Br0.02)3 by adding corresponding CsI, MACl, FAI, PbI2, and MAPbBr3 into mixed DMF/DMSO solution (4:1). After vigorous stirring for 2 h at room temperature, 50 μl precursor is dripped onto different HTL substrates and spin-coating at 1000 (200 ramp) for 10 s and 5000 rpm for 30 s (2000 ramp), while antisolvent (anisole) is dripped after 27 s. Then the perovskite films are 

### The analysis of Jph vs. Veff relationships 

The definition of Jph is the current density under illumination (JL) minus the dark current density (JD), and V0 refers to the voltage value when Jph = 0. Accordingly, Veff = V0−Vappl, where Vappl represents applied voltage, has a clear meaning. Importantly, when Veff reaches a high value (>2 V) it is normally believed that generated excitons are fully collected, in which Jph is equal to saturated current density (Jsat). Then, we can calculate JSC/Jsat and Jmax/Jsat to describe exciton dissociation 

Nature Communications |  (2024) 15:7605 

9 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

(ηdiss) and charge collection (ηcoll) efficiency. Jmax is the Jph at the maximal output point. 

### Computational details 

DFT calculation. First-principles calculations were carried out on the basis of periodic DFT using a generalized gradient approximation within the Perdew–Burke–Ernzerh of exchange correction functional. 2PACz and PyCA-3F molecules were adsorbed on the ITO surface. The wave functions were constructed from the expansion of plane waves with an energy cutoff of 500 eV. Gamma-centered k points of 3 × 3 × 1 have been used for geometry optimization. The consistency tolerances for the geometry optimization are set as 1.0 × 10<sup>−5</sup> eV/atom for total energy and 0.05 eV/Å for force, respectively. In order to avoid the interaction between the two surfaces, a large vacuum gap of 15 Å has been selected in the periodically repeated slabs. The structural stability was checked with frequency calculation. The DFT models used in this manuscript are provided in Supplementary Data 1. 

Classical molecular dynamic (MD) simulations. Following the methodology from Park S.M. et al.<sup>41</sup> , the adsorption process of 2PACz and PyCA-3F on the ITO surface was further investigated by classical MD simulations using the large-scale atomic/molecular massively parallel simulator (LAMMPS) package<sup>90</sup> . The atomic interactions within the 2PACz and PyCA-3F molecules were described using the OPLS-AA force field<sup>91</sup> , where the detailed parameters were generated using the LigParGen software<sup>92</sup> . To better describe the conformation of the phosphonic functional group, the interactions within this group were switched to a specially designed force field developed by Meltzer et al.<sup>93</sup> . Inspired by Park S.M. et al.<sup>41</sup> , the ITO substrate was simplified as In2O3 and simulated using the Buckingham potential, which can effectively reproduce the In2O3 structure. The interactions between molecules and the substrates were simulated using the Lennard–Jones (LJ) and Coulombic interactions, where the parameters of the LJ terms were obtained from the Universal force field using geometric mixing rules<sup>94</sup> . Initially, 2PACz molecules (controlled system) and PyCA-3F molecules (mixed system, with the experimental molar ratio 2PACz:PyCA-3F = 9:1) were randomly placed near the surface of In2O3 substrate with a minimum interatomic distance of 2.0 Å to avoid atomic overlap. The interfacial systems were then equilibrated in the canonical NVT ensemble at 300 K for 1.0 ns which is long enough to converge the potential energy. The In2O3 substrate was fixed during the equilibration to avoid unexpected structure changes. The motion of the atoms was integrated using the velocity-Verlet algorithm with a time step of 1 fs. 

During the simulations, the atomic trajectories were visualized using the Ovito software<sup>95</sup> . The aggregation of molecules was determined by the coverage surface on the substrate, which is calculated by creating a surface mesh using the method implemented in Ovito. The interfacial adsorption energy was calculated as Eadsorption = Etotal � EIn2O3 � ESAMs, where Etotal, EIn2O3 , and ESAMs are the potential energy of the whole system, In2O3 substrate, and SAM molecules, respectively. The MD simulation results of ITO/2PACz and ITO/CA used in this manuscript are provided in Supplementary Data 2. 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

The main data supporting the findings of this study are available within the published article and its Supplementary Information and source data files. Additional data are available from the corresponding author on request. Source data are provided with this paper. 

## References 

1. Zhou, H. et al. Photovoltaics. Interface engineering of highly efficient perovskite solar cells. Science 345, 542–546 (2014). 

2. Grancini, G. et al. One-year stable perovskite solar cells by 2D/3D interface engineering. Nat. Commun. 8, 15684 (2017). 

3. Yan, C. et al. Ambipolar-transport wide-bandgap perovskite interlayer for organic photovoltaics with over 18% efficiency. Matter 5, 2238–2250 (2022). 

4. Zhao, X. et al. Accelerated aging of all-inorganic, interfacestabilized perovskite solar cells. Science 377, 307–310 (2022). 

5. Li, Y., Xie, H., Lim, E. L., Hagfeldt, A. & Bi, D. Recent progress of critical interface engineering for highly efficient and stable perovskite solar cells. Adv. Energy Mater. 12, 2102730 (2021). 

6. Jiang, Y. et al. An alcohol-dispersed conducting polymer complex for fully printable organic solar cells with improved stability. Nat. Energy 7, 352–359 (2022). 

7. Yao, J. et al. Fluorinated perylene-diimides: cathode interlayers facilitating carrier collection for high-performance organic solar cells. Adv. Mater. 34, e2203690 (2022). 

8. Xiong, X. et al. Melamine-doped cathode interlayer enables highefficiency organic solar cells. ACS Energy Lett. 6, 3582–3589 (2021). 

9. Jeong, B., Gkoupidenis, P. & Asadi, K. Solution‐processed perovskite field‐effect transistor artificial synapses. Adv. Mater. 33, 2104034 (2021) 

10. Kang, Q. et al. n-doped inorganic molecular clusters as a new type of hole transport material for efficient organic solar cells. Joule 5, 646–658 (2021). 

11. Yu, R. et al. Efficient interface modification via multi-site coordination for improved efficiency and stability in organic solar cells. Energ. Environ. Sci. 15, 822–829 (2022). 

12. Bai, Y., Meng, X. & Yang, S. Interface engineering for highly efficient and stable planar p–i–n perovskite solar cells. Adv. Energy Mater. 8, 1701883 (2018). 

13. Zhu, L. et al. Single-junction organic solar cells with over 19% efficiency enabled by a refined double-fibril network morphology. Nat. Mater. 21, 656–663 (2022). 

14. Chin, Y. C., Daboczi, M., Henderson, C., Luke, J. & Kim, J. S. Suppressing PEDOT:PSS doping-induced interfacial recombination loss in perovskite solar cells. ACS Energy Lett. 7, 560–568 (2022). 

15. Ma, R. et al. Rational anode engineering enables progresses for different types of organic solar cells. Adv. Energy Mater. 11, 2100492 (2021). 

16. Zhan, L. et al. Manipulating charge transfer and transport via intermediary electron acceptor channels enables 19.3% efficiency organic photovoltaics. Adv. Energy Mater. 12, 2201076 (2022). 

17. Girtan, M. & Rusu, M. Role of ITO and PEDOT:PSS in stability/ degradation of polymer:fullerene bulk heterojunctions solar cells. Sol. Energy Mater. Sol. Cells 94, 446–450 (2010). 

18. Vitoratos, E. et al. Thermal degradation mechanisms of PEDOT:PSS. Org. Electron 10, 61–66 (2009). 

19. Cameron, J. & Skabara, P. J. The damaging effects of the acidity in PEDOT:PSS on semiconductor device performance and solutions based on non-acidic alternatives. Mater. Horiz. 7, 1759–1772 (2020). 

20. Yun, J. M. et al. Solution-processable reduced graphene oxide as a novel alternative to PEDOT:PSS hole transport layers for highly efficient and stable polymer solar cells. Adv. Mater. 23, 4923–4928 (2011). 

21. Labban, A. E. et al. Improved efficiency in inverted perovskite solar cells employing a novel diarylamino-substituted molecule as PEDOT:PSS replacement. Adv. Energy Mater. 6, 1502101 (2016). 

22. Kang, Q. et al. A new PEDOT derivative for efficient organic solar cell with a fill factor of 0.80. Adv. Energy Mater. 12, 2103892 (2022). 

Nature Communications |  (2024) 15:7605 

10 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

23. Lin, Y. et al. 17% Efficient organic solar cells based on liquid exfoliated WS(2) as a replacement for PEDOT:PSS. Adv. Mater. 31, e1902965 (2019). 

24. Chen, W.-Y. et al. Low-cost solution-processed copper iodide as an alternative to PEDOT:PSS hole transport layer for efficient and stable inverted planar heterojunction perovskite solar cells. J. Mater. Chem. A 3, 19353–19359 (2015). 

25. Kim, S. Y., Cho, S. J.,Byeon, S. E., He, X. & Yoon, H. J. Self‐assembled monolayers as interface engineering nanomaterials in perovskite solar cells. Adv. Energy Mater. 10, 2002606 (2020). 

26. Dai, Z. et al. Interfacial toughening with self-assembled monolayers enhances perovskite solar cell reliability. Science 372, 618–622 (2021). 

27. Jiang, W. et al. pi-Expanded carbazoles as hole-selective selfassembled monolayers for high-performance perovskite solar cells. Angew. Chem. Int. Ed. 61, e202213560 (2022). 

28. Li, Y., Li, T. & Lin, Y. Stability: next focus in organic solar cells based on non-fullerene acceptors. Mater. Chem. Front. 5, 2907–2930 (2021). 

29. Yalcin, E. et al. Semiconductor self-assembled monolayers as selective contacts for efficient PiN perovskite solar cells. Energ. Environ. Sci. 12, 230–237 (2019). 

30. Li, D. et al. Recent progress of inverted organic-inorganic halide perovskite solar cells. J. Energy Chem. 79, 168–191 (2023). 

31. Deng, X. et al. Co-assembled monolayers as hole-selective contact for high-performance inverted perovskite solar cells with optimized recombination loss and long-term stability. Angew. Chem. Int. Ed. 61, e202203088 (2022). 

32. Wang, S. et al. Water‐soluble triazolium ionic‐liquid‐induced surface self‐assembly to enhance the stability and efficiency of perovskite solar cells. Adv. Funct. Mater. 29, 1900417 (2019). 

33. Wolff, C. M. et al. Perfluorinated self-assembled monolayers enhance the stability and efficiency of inverted perovskite solar cells. ACS Nano 14, 1445–1456 (2020). 

34. Liu, M. et al. Compact hole‐selective self‐assembled monolayers enabled by disassembling micelles in solution for efficient perovskite solar cells. Adv. Mater. 35, e2304415 (2023). 

35. Vidyasagar, D. et al. Surface-functionalized hole-selective monolayer for high efficiency single-junction wide-bandgap and monolithic tandem perovskite solar cells. J. Energy Chem. 88, 317–326 (2024). 

36. Kulkarni, A. et al. A universal strategy of perovskite ink–substrate interaction to overcome the poor wettability of a self‐assembled monolayer for reproducible perovskite solar cells. Adv. Funct. Mater. 33, 2305812 (2023) 

37. Farag, A. et al. Evaporated self‐assembled monolayer hole transport layers: lossless interfaces in p–i–n perovskite solar cells. Adv. Energy Mater. 13, 2203982 (2023) 

38. Lin, J. et al. Dual surface modifications of NiOx/Perovskite interface for enhancement of device stability. ACS Appl. Mater. Interfaces 15, 24437–24447 (2023). 

39. Phung, N. et al. Enhanced self-assembled monolayer surface coverage by ALD NiO in p–i–n perovskite solar cells. ACS Appl. Mater. Interfaces 14, 2166–2176 (2021). 

40. Kapil, G. et al. Tin–lead perovskite solar cells fabricated on hole selective monolayers. ACS Energy Lett. 7, 966–974 (2022). 

41. Park, S. M. et al. Low-loss contacts on textured substrates for inverted perovskite solar cells. Nature 624, 289–294 (2023). 

42. Shi, Y. et al. New ruthenium sensitizers featuring bulky ancillary ligands combined with a dual functioned coadsorbent for high efficiency dye-sensitized solar cells. ACS Appl. Mater. Interfaces 5, 144–153 (2012). 

43. Lin, Y. et al. Self-assembled monolayer enables hole transport layerfree organic solar cells with 18% efficiency and improved operational stability. ACS Energy Lett. 5, 2935–2944 (2020). 

44. Bin, H. et al. Finetuning hole-extracting monolayers for efficient organic solar cells. ACS Appl. Mater. Interfaces 14, 16497–16504 (2022). 

45. Gharibzadeh, S. et al. Two birds with one stone: dual grainboundary and interface passivation enables >22% efficient inverted methylammonium-free perovskite solar cells. Energ. Environ. Sci. 14, 5875–5893 (2021). 

46. Deng, X. et al. Co‐assembled monolayers as hole‐selective contact for high‐performance inverted perovskite solar cells with optimized recombination loss and long‐term stability. Angew. Chem. Int. Ed. 134, e202203088 (2022) 

47. Kralj, S. et al. Impact of the TCO microstructure on the electronic properties of carbazole-based self-assembled monolayers. ACS Mater. Lett. 6, 366–374 (2023). 

48. Tang, H. et al. Reinforcing self-assembly of hole transport molecules for stable inverted perovskite solar cells. Science 383, 1236–1240 (2024). 

49. Kang, Z. et al. Kelvin probe force microscopy for perovskite solar cells. Sci. China Mater. 62, 776–789 (2019). 

50. Spadafora, E. J., Demadrille, R., Ratier, B. & Grévin, B. Imaging the carrier photogeneration in nanoscale phase segregated organic heterojunctions by Kelvin probe force microscopy. Nano Lett. 10, 3337–3342 (2010). 

51. Guan, S. et al. Self‐assembled interlayer enables high‐performance organic photovoltaics with power conversion efficiency exceeding 20%. Adv. Mater. 36, 2400342 (2024) 

52. Tan, Q. et al. Inverted perovskite solar cells using dimethylacridinebased dopants. Nature 620, 545–551 (2023). 

53. Bi, C. et al. Non-wetting surface-driven high-aspect-ratio crystalline grain growth for efficient hybrid perovskite solar cells. Nat. Commun. 6, 7747 (2015). 

54. Liu, T. et al. Tailoring vertical phase distribution of quasi-twodimensional perovskite films via surface modification of holetransporting layer. Nat. Commun. 10, 878 (2019). 

55. Shu, H. et al. Self-assembled hydrophobic molecule-based surface modification: a strategy to improve efficiency and stability of perovskite solar cells. ACS Sustain. Chem. Eng. (2020). 

56. Wu, J. et al. Bisphosphonate‐anchored self‐assembled molecules with larger dipole moments for efficient inverted perovskite solar cells with excellent stability. Adv. Mater. 36, 2401537 (2024). 

57. Li, D. et al. In situ interface engineering for highly efficient electrontransport-layer-free perovskite solar cells. Nano Lett. 20, 5799–5806 (2020). 

58. Chen, S. et al. Crystallization in one-step solution deposition of perovskite films: upward or downward? Sci. Adv. 7, eabb2412 (2021). 

59. Li, D. et al. Surface regulation with polymerized small molecular acceptor towards efficient inverted perovskite solar cells. Adv. Energy Mater. 13, 202204247 (2023). 

60. Zhang, S. et al. Minimizing buried interfacial defects for efficient inverted perovskite solar cells. Science 380, 404–409 (2023). 

61. Hao, M. et al. Flattening grain-boundary grooves for perovskite solar cells with high optomechanical reliability. Adv. Mater. 35, e2211155 (2023). 

62. Rohrer, G. S. Grain boundary energy anisotropy: a review. J. Mater. Sci. 46, 5881–5895 (2011). 

63. Wu, X. et al. Backbone engineering enables highly efficient polymer hole-transporting materials for inverted perovskite solar cells. Adv. Mater. 35, e2208431 (2023). 

64. Fan, R. et al. Tungstate-mediated in-situ passivation of grain boundary grooves in perovskite solar cells. Angew. Chem. Int. Ed. 62, e202303176 (2023). 

65. Fu, S. et al. Efficient passivation with lead pyridine‐2‐carboxylic for high‐performance and stable perovskite solar cells. Adv. Energy Mater. 9, 1901852 (2019) 

Nature Communications |  (2024) 15:7605 

11 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

66. Wang, Z. et al. Managing multiple halide‐related defects for efficient and stable inorganic perovskite solar cells. Angew. Chem. Int. Ed. 135, e202305815 (2023) 

67. Paniagua, S. A. et al. Phosphonic acid modification of indium−tin oxide electrodes: combined XPS/UPS/contact angle studies. J. Phys. Chem. C 112, 7809–7817 (2008). 

68. Koh, S. E. et al. Phenylphosphonic acid functionalization of indium tin oxide: surface chemistry and work functions. Langmuir 22, 6249–6255 (2006). 

69. Liu, Z. et al. Ultratough hydrogen‐bond‐bridged phosphorene films. Adv. Mater. 34, e220333 (2022). 

70. Qin, P. L. et al. Stable and efficient organo‐metal halide hybrid perovskite solar cells via π‐conjugated lewis base polymer induced trap passivation and charge extraction. Adv. Mater. 30, e1706126 (2018). 

71. Chen, J., Kim, S.-G., Ren, X., Jung, H. S. & Park, N.-G. Effect of bidentate and tridentate additives on the photovoltaic performance and stability of perovskite solar cells. J. Mater. Chem. A 7, 4977–4987 (2019). 

72. Qin, M., Chan, P. F. & Lu, X. A systematic review of metal halide perovskite crystallization and film formation mechanism unveiled by in situ GIWAXS. Adv. Mater. 33, e2105290 (2021). 

73. Steele, J. A. et al. How to GIWAXS: grazing incidence wide angle X‐ ray scattering applied to metal halide perovskite thin films. Adv. Energy Mater. 13, 202300760 (2023). 

74. Yang, T. et al. One-stone-for-two-birds strategy to attain beyond 25% perovskite solar cells. Nat. Commun. 14, 839 (2023). 

75. Zhang, K. et al. Efficient inorganic vapor-assisted defects passivation for perovskite solar module. Adv. Mater. 35, e2211593 (2023). 

76. Jeong, S. et al. Cyclohexylammonium‐based 2D/3D perovskite heterojunction with funnel‐like energy band alignment for efficient solar cells (23.91%). Adv. Energy Mater. 11, 2102236 (2021). 

77. Chen, P. et al. Efficient inverted perovskite solar cells via improved sequential deposition. Adv. Mater. 35, e2206345 (2023). 

78. Wang, L. et al. Interface regulation enables hysteresis free widebandgap perovskite solar cells with low VOC deficit and high stability. Nano Energy 90, 106537 (2021) 

79. Wang, W. T. et al. Synergistic reinforcement of built‐in electric fields for highly efficient and stable perovskite photovoltaics. Adv. Funct. Mater. 30, 1909755 (2020) 

80. Khenkin, MarkV. et al. Consensus statement for stability assessment and reporting for perovskite photovoltaics based on ISOS procedures. Nat. Energy 5, 35–49 (2020). 

81. Fei, C. et al. Strong-bonding hole-transport layers reduce ultraviolet degradation of perovskite solar cells. Science 384, 1126–1134 (2024). 

82. Chai, G. et al. Fine-tuning of side-chain orientations on nonfullerene acceptors enables organic solar cells with 17.7% efficiency. Energ. Environ. Sci. 14, 3469–3479 (2021). 

83. Luo, Z. et al. Asymmetric side-chain substitution enables a 3D network acceptor with hydrogen bond assisted crystal packing and enhanced electronic coupling for efficient organic solar cells. Energ. Environ. Sci. 15, 4601–4611 (2022). 

84. Bao, S. et al. Volatilizable solid additive-assisted treatment enables organic solar cells with efficiency over 18.8% and fill factor exceeding 80. Adv. Mater. 33, e2105301 (2021). 

85. Ge, Z. et al. Suppressing trap‐assisted nonradiative recombination via interface modification for achieving efficient organic solar cells. Adv. Energy Mater. 14, 2400203 (2024) 

86. Karki, A. et al. Unifying charge generation, recombination, and extraction in low‐offset non‐fullerene acceptor organic solar cells. Adv. Energy Mater. 10, 2001203 (2020). 

87. Xu, Y. et al. A new conjugated polymer that enables the integration of photovoltaic and light-emitting functions in one device. Adv. Mater. 33, e2101090 (2021). 

88. Luo, Z. et al. Precisely controlling the position of bromine on the end group enables well-regular polymer acceptors for allpolymer solar cells with efficiencies over 15. Adv. Mater. 32, e2005942 (2020). 

89. Cui, Y. et al. Organic photovoltaic cell with 17% efficiency and superior processability. Natl Sci. Rev. 7, 1239–1246 (2020). 

90. Thompson, A. P. et al. LAMMPS—a flexible simulation tool for particle-based materials modeling at the atomic, meso, and continuum scales. Comput. Phys. Commun. 271, 108171 (2022) 

91. Jorgensen, W. L. & Tirado-Rives, J. The OPLS [optimized potentials for liquid simulations] potential functions for proteins, energy minimizations for crystals of cyclic peptides and crambin. J. Am. Chem. Soc. 110, 1657–1666 (1988). 

92. Dodda, L. S., Cabeza de Vaca, I., Tirado-Rives, J. & Jorgensen, W. L. LigParGen web server: an automatic OPLS-AA parameter generator for organic ligands. Nucleic Acids Res. 45, W331–W336 (2017). 

93. Meltzer, C. et al. Indentation and self-healing mechanisms of a selfassembled monolayer—a combined experimental and modeling study. J. Am. Chem. Soc. 136, 10718–10727 (2014). 

94. Rappe, A. K., Casewit, C. J., Colwell, K. S., Goddard, W. A. & Skiff, W. M. UFF, a full periodic table force field for molecular mechanics and molecular dynamics simulations. J. Am. Chem. Soc. 114, 10024–10035 (2002). 

95. Stukowski, A. Visualization and analysis of atomistic simulation data with OVITO—the open visualization tool. Model. Simul. Mater. Sci. Eng. 18, 015012 (2009). 

## Acknowledgements 

G. Li acknowledges Research Grants Council of Hong Kong (Project ID: 15221320, 15307922, C5037-18G, C4005-22Y, C7018-20G), RGC Senior Research Fellowship Scheme (SRFS2223-5S01), Shenzhen Science and Technology Innovation Commission (JCYJ20200109105003940). the Hong Kong Polytechnic University: Sir Sze-yuen Chung Endowed Professorship Fund (8-8480), RISE (Q-CDBK), PRI (Q-CD7X) and Guangdong-Hong Kong-Macao Joint Laboratory for Photonic-Thermal Electrical Energy Materials and Devices (GDSTC No. 2019B121205001). R.M., G.L. thanks for the support of the PolyU Distinguished Postdoctoral Fellowship (1-YW4C). Z. Ren thanks the Start-up Fund for RAPs under the Strategic Hiring Scheme (1-BD1H), Projects of RISE (Q-CDBK), and RIiWEAR Strategic Supporting Scheme (1-CD94). Q. Lian thanks the National Natural Science Foundation of China (22305111). J. Yin acknowledges financial support from Hong Kong Polytechnic University (Grant no. P0042930) and a grant from the Research Grants Council of the Hong Kong Special Administrative Region, China (Project no. PolyU 25300823). C.C. thanks for the support by Shenzhen Science and Technology Program (grant no.20231115112954001). 

## Author contributions 

D.L., Q. Lian., R.M., C.C. and G.L. conceived the idea and designed the research, D.L., Q. Lian, and R.M. performed the experiments, and wrote the manuscript. T.D. and J.Y. performed the molecular dynamics simulations. H.L., Q. Liang, Y.H., G.M., O.P., G.Z. and W.P. performed the experiments and analyzed the data. B.X., X.L. and K.L. discussed the results. R.M., Z.R., C.C. and G.L. supervised the research. Z.R., C.C. and G.L. provided funding support. All authors discussed the results and commented on the manuscript. 

## Competing interests 

The authors declare no competing interests. 

Nature Communications |  (2024) 15:7605 

12 

Article 

https://doi.org/10.1038/s41467-024-51760-5 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-024-51760-5. 

Correspondence and requests for materials should be addressed to Ruijie Ma, Zhiwei Ren, Gang Li or Chun Cheng. 

Peer review information Nature Communications thanks the anonymous reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence toshare adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creativecommons.org/licenses/by-nc-nd/4.0/. 

© The Author(s) 2024 

1Department of Materials Science and Engineering, Southern University of Science and Technology, 518055 Shenzhen, Guangdong Province, China. 2Department of Electrical and Electronic Engineering, Research Institute for Smart Energy (RISE), Photonic Research Institute (PRI), The Hong Kong Polytechnic University, Hung Hom, 999077 Kowloon, Hong Kong, China.<sup>3</sup> Department of Applied Physics, The Hong Kong Polytechnic University, 999077 Kowloon, Hong Kong, China.<sup>4</sup> Department of Physics, The Chinese University of Hong Kong, New Territories, Hong Kong, China.<sup>5</sup> The Hong Kong Polytechnic University Shenzhen Research Institute, 518057 Shenzhen, China.<sup>6</sup> Guangdong Provincial Key Laboratory of Energy Materials for Electric Power, Southern University of Science and Technology, 518055 Shenzhen, Guangdong Province, China.<sup>7</sup> Shenzhen Engineering Research and Development Center for Flexible Solar cells, Southern University of Science and Technology, 518055 Shenzhen, Guangdong Province, China.<sup>8</sup> These authors contributed equally: Dongyang Li, Qing Lian, Tao Du. e-mail: ruijie.ma@polyu.edu.hk; zhiweipv.ren@polyu.edu.hk; gang.w.li@polyu.edu.hk; chengc@sustech.edu.cn 

Nature Communications |  (2024) 15:7605 

13 

