# Ionic Liquid Stabilizing High‐Efficiency Tin Halide Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 166 |
| 作者 | Guixiang Li, Zhen-Huang Su, Meng Li, Feng Yang, M. Aldamasy, Jorge Pascual, Fengjiu Yang, Hai-Rui Liu et al. |
| DOI | 10.1002/aenm.202101539 |
| 源文件 | 067_Li_2021_Ionic-Liquid-Stabilizing-HighEfficiency-Tin-Hali.pdf |

---
**ReseaRch aRticle** 



**www.advenergymat.de** 

# **Ionic Liquid Stabilizing High-Efficiency Tin Halide Perovskite Solar Cells** 

_Guixiang Li, Zhenhuang Su, Meng Li,* Feng Yang, Mahmoud H. Aldamasy, Jorge Pascual, Fengjiu Yang, Hairui Liu, Weiwei Zuo, Diego Di Girolamo, Zafar Iqbal, Giuseppe Nasti, André Dallmann, Xingyu Gao, Zhaokui Wang, Michael Saliba, and Antonio Abate*_ 

## **1. Introduction** 

**Tin halide perovskites attract incremental attention to deliver lead-free perovskite solar cells. Nevertheless, disordered crystal growth and low defect formation energy, related to Sn(II) oxidation to Sn(IV), limit the efficiency and stability of solar cells. Engineering the processing from perovskite precursor solution preparation to film crystallization is crucial to tackle these issues and enable the full photovoltaic potential of tin halide perovskites. Herein, the ionic liquid** **_n_ -butylammonium acetate (BAAc) is used to tune the tin coordination with specific O…Sn chelating bonds and N**  **H…X hydrogen bonds. The coordination between BAAc and tin enables modulation of the crystallization of the perovskite in a thin film. The resulting BAAc-containing perovskite films are more compact and have a preferential crystal orientation. Moreover, a lower amount of Sn(IV) and related chemical defects are found for the BAAc-containing perovskites. Tin halide perovskite solar cells processed with BAAc show a power conversion efficiency of over 10%. This value is retained after storing the devices for over 1000 h in nitrogen. This work paves the way toward a more controlled tin-based perovskite crystallization for stable and efficient lead-free perovskite photovoltaics.** 

Metal halide perovskites have demonstrated extraordinary optoelectronic properties for photovoltaic devices, such as adjustable bandgap, favorable carrier mobility, and high light-harvesting coefficient.<sup>[1]</sup> Through the ongoing efforts of researchers, lead-based halide perovskite solar cells (PSCs) have managed to consistently improve the power conversion efficiency (PCE) to up to the latest 25.5%, i.e., close to their Shockley–Queisser limit.<sup>[2]</sup> However, the high toxicity of lead may hinder PSCs’ commercialization.<sup>[3]</sup> Specifically, it has been found that Pb from halide perovskites is more dangerous than other Pb-containing electronic products through the assessment of Pb-absorption by plants from contaminated soil.<sup>[4]</sup> 

G. Li, Dr. M. Li, M. H. Aldamasy, Dr. J. Pascual, Dr. F. Yang, Z. Iqbal, Prof. A. Abate Helmholtz-Zentrum Berlin für Materialien und Energie GmbH Hahn-Meitner-Platz 1, 14109 Berlin, Germany E-mail: meng.li@helmholtz-berlin.de; antonio.abate@helmholtz-berlin.de 

Z. Su, Prof. X. Gao Shanghai Synchrotron Radiation Facility (SSRF) Shanghai Advanced Research Institute Shanghai Institute of Applied Physics Chinese Academy of Sciences 239 Zhangheng Road, Shanghai 201204, P. R. China Dr. M. Li 

Key Lab for Special Functional Materials of Ministry of Education National and Local Joint Engineering Research Center for High-Efficiency Display and Lighting Technology School of Materials Science and Engineering Collaborative Innovation Center of Nano Functional Materials and Applications Henan University Kaifeng 475004, China Prof. F. Yang, H. Liu Henan Key Laboratory of Photovoltaic Materials School of Physics Henan Normal University Xinxiang 453007, China 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202101539. 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium, provided the original work is properly cited. 

M. H. Aldamasy Egyptian Petroleum Research Institute Nasr City, Cairo P.O. 11727, Egypt W. Zuo, Prof. M. Saliba Institute for Photovoltaics (IPV) University of Stuttgart Pfaffenwaldring 47, D-70569 Stuttgart, Germany 

Dr. D. Di Girolamo, Dr. G. Nasti, Prof. A. Abate Department of Chemical, Materials and Production Engineering University of Naples Federico II Piazzale Tecchio 80, Naples 80125, Italy Dr. A. Dallmann Institut für Chemie AG NMR Humboldt Universität zu Berlin 12489 Berlin, Germany Prof. Z. Wang Institute of Functional Nano and Soft Materials (FUNSOM) Jiangsu Key Laboratory for Carbon-Based Functional Materials and Devices Soochow University Suzhou 215123, China Prof. M. Saliba Helmholtz Young Investigator Group FRONTRUNNER IEK5-Photovoltaics Forschungszentrum Jülich 52425 Jülich, Germany 

### **DOI: 10.1002/aenm.202101539** 

**2101539 (1 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

Environmentally friendly metals as a substitute for Pb in PSCs have been extensively proposed in the community, with examples such as tin,<sup>[5]</sup> germanium,<sup>[6]</sup> copper,<sup>[7]</sup> bismuth,<sup>[8]</sup> and antimony.<sup>[9]</sup> In the divalent Sn(II) form, tin is believed to be the most promising candidate among numerous Pb-free alternatives since they possess outstanding optoelectronic properties, such as suitable bandgap, small exciton binding energy and high carrier mobility.<sup>[10]</sup> However, due to the charge recombination caused by its high defect density, the device performance, especially the open-circuit voltage ( _V_ oc), is far behind that of Pb-based PSCs.<sup>[11]</sup> Recent efforts have been directed to the poor film morphology, caused by the rapid crystallization, and to the p-type self-doping from the oxidation of Sn(II) to Sn(IV), which are considered to be the sources of defects.<sup>[3c,12]</sup> Poor film morphology, with a large number of pinholes and voids, on the one hand, will lead to poor device efficiency, and on the other hand, may promote the intake of water and oxygen. This scenario would cause severe oxidation of Sn(II) and the degradation of the absorber material.<sup>[13]</sup> Moreover, it has been recently reported that the traditional solvent dimethyl sulfoxide (DMSO) oxidizes Sn(II) to Sn(IV) in the precursor solution through an irreversible redox reaction.<sup>[14]</sup> Therefore suppressing the oxidation of Sn(II) in the precursor solution is also an urgent issue to be solved concomitantly. Many strategies have been implemented to overcome these problems, including solvent engineering,<sup>[15]</sup> composition adjustment,<sup>[5,16]</sup> reducing additives,<sup>[3c]</sup> dimensional manipulation,<sup>[17]</sup> etc. However, these implementations have significant limitations and one-sidedness. Few researchers simultaneously consider both the effect of the chemical bonds in the Sn-based perovskite precursors on the oxidation of Sn(II) and the crystal growth. In this sense, tuning chemical bonds in the precursor solution can effectively hinder the oxidation of Sn(II), reducing the generation of defects during film formation and annealing. In the same way, optimization of solution properties through chemical interactions tuning can regulate the crystallization process, further improving the quality of Sn-based crystal films. Therefore, it is necessary to provide systematic research to achieve high-quality crystal growth by synergistically managing the solution coordination and crystallization kinetics of the Sn-based perovskite film. 

In this work, we introduce the ionic liquid _n_ -butylammonium acetate (BAAc) to tune the precursor coordination and control the perovskite crystallization toward high-quality films. Due to the solid O…Sn bonds and NH…X hydrogen bonds established through interactions between the BAAc and perovskite precursors, a stable precursor solution can be formed, providing a potent constraint on the oxidation of Sn(II) by DMSO. Also, these strong forces can effectively retard the crystallization process and provide more uniform nucleation sites, resulting in a pinhole-free and preferentially oriented perovskite film, which has been systematically analyzed via the (in situ) synchrotronbased grazing-incidence wide-angle X-ray scattering (GIWAXS). The long aliphatic chain BA<sup>+</sup> with ammonium functional group assembled on the perovskite surface provides an enhanced hydrophobic effect and improved oxidation repellency for Sn(II). After a thorough optimization, the resulting BAAc-containing devices demonstrate high PCEs of up to 10.4% in an inverted p-i-n planar architecture. Most importantly, 96% of the initial efficiency is maintained upon storing in a N2-filled glovebox at 

room temperature over 1000 h. Moreover, impressive thermal stability under 85 °C is provided as the first report for Sn-based PSCs, recording 80% of the initial efficiency ( _T_ 80) approaching 400 h. Overall, this work provides an in-depth insight into the crystallization kinetics for controlling high-quality film growth with the innovative introduction of ionic liquids, promoting highly efficient and stable tin halide PSCs. 

## **2. Results and Discussion** 

The perovskite precursor solution properties determine the crystallization dynamics and film morphology.<sup>[18]</sup> To modulate the interaction between the precursor solution’s components and stabilize Sn(II) ions, the ionic liquid BAAc was introduced into the tin halide perovskite solution. BAAc is an excellent choice to achieve these tasks. Possessing a long alkyl hydrophobic chain, it can anchor the perovskite’s surface through the ammonium group. Simultaneously, the carbonyl oxygen of its acetate part with a lone pair of electrons can stabilize Sn(II) at the B site. Since low-dimensional perovskites in Sn-based PSCs have been proven to possess improved thermodynamic stability, ethylammonium bromide (EABr), and phenethylammonium bromide were simultaneously added into the FASnI3 precursor solution to obtain the quasi-2D-structured Sn-based perovskite for a reference device, as an efficient strategy for the acquisition of excellent characteristics in tin halide PSCs.<sup>[19]</sup> SnF2 was also included in the solution to reduce the oxidation of Sn(II) and improve film morphology.<sup>[19b]</sup> As shown in the schematic illustration in **Figure 1** a, for the reference precursor solution, since the SnI2 layered structure is weakly bonded through van der Waals-type interactions, DMSO molecules as the solvent can easily intercalate into SnI2 layer spaces to achieve dissolution, where DMSO induces SnI2 lattice expansion along the _c_ -axis.<sup>[20]</sup> Subsequently, the reference perovskite film formed by the DMSO-SnI2 intermediate exhibits a large number of pinholes, attributed to the fast crystallization due to the continued rapid volatilization of DMSO.<sup>[21]</sup> In addition, recent studies have shown that the conventionally used DMSO can oxidize Sn(II) to Sn(IV) in solution by an irreversible redox reaction.<sup>[14]</sup> Therefore, this may be another reason for the inferior crystal film quality. 

In contrast, with the addition of 5 m% BAAc, strong bonds can be obtained between the ionic liquid and the tin halide perovskite precursors (typically formamidinium iodide and SnI2) through O…Sn bonds and NH…X hydrogen bonds. Specifically, O…Sn bonds are formed via chelation between Ac<sup>–</sup> (CH3COO<sup>–</sup> ) and Sn(II)<sup>[15a]</sup> and NH…X hydrogen bonds belong to the interaction between BA<sup>+</sup> and X-site anions (I<sup>–</sup> , Br<sup>–</sup> ).<sup>[18]</sup> The existence of these bonds in our FASnI3-BAAc system was supported by the characterization of these solutions by nuclear magnetic resonance (NMR). Figure S1 in the Supporting Information shows how the Sn(II) signal moves to higher chemical shift values after the addition of 5 m% BAAc. This may be the result of a lower electron density around Sn(II), suggesting that acetate anions, which are weaker Lewis bases than DMSO, may partially replace the solvent molecules as ligands of Sn(II). If we take a look at the<sup>13</sup> C NMR (Figure S2, Supporting Information), we can see that the quaternary carbon of the acetate anion (175 ppm) is deshielded when in contact with FASnI3 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 **2101539 (2 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 1.** Schematic illustration of BAAc ionic liquid-assisted crystallization kinetics of Sn-based perovskite films. Perovskite films processed a) without and b) with BAAc. 

precursors. This means that the carbon of the carbonyl group has lost some electron density, which can be well explained by the coordination of the acetate oxygens to a Lewis acid such as Sn(II). While<sup>119</sup> Sn and<sup>13</sup> C spectra clearly support the idea of the O…Sn bond, the<sup>1</sup> H spectra give us information of the role on the BA<sup>+</sup> ammonium group (Figure S3, Supporting Information). FA<sup>+</sup> remains unaffected, but BA<sup>+</sup> protons, both ammonium (8.0 ppm) and most of the aliphatic ones (0.5–1.5 ppm), are shielded when in the presence of FASnI3 precursors. With iodide being the only Lewis base, these results suggest the NH…X interaction between X-site anions (I<sup>–</sup> , Br<sup>–</sup> ) and BA<sup>+</sup> cations. O…HN hydrogen bonds from Ac<sup>–</sup> and A-site cations (FA<sup>+</sup> , EA<sup>+</sup> , and PEA<sup>+</sup> ) were also considered in this study according to previous reports,<sup>[22]</sup> but we saw no clear interaction for this particular case. These strong interactions result in a stable precursor solution, which will well inhibit the oxidation of Sn(II) by DMSO (Figure 1b). For this purpose, the fresh precursor solution of FASnI3 with and without BAAc is prepared (Figure S4 and Video S1, Supporting Information). Through heating the solution at 100 °C for 2 h in a N2-filled glovebox, the color of the FASnI3 solution is darkened (Figure S5, Supporting Information), which corresponds to the presence of SnI4 due to the oxidation of Sn(II) to Sn(IV) by DMSO.<sup>[14,15b]</sup> On the contrary, the solution color of FASnI3 with BAAc did not change from yellow. This result indicates that the addition of BAAc endows the precursor solution with enhanced stability, where the oxidation of Sn(II) by DMSO is inhibited. We confirmed this by measuring these solutions by liquid-state<sup>119</sup> Sn NMR. We found that no Sn(IV) was generated in the BAAccontaining solution, whilst reference FASnI3 solution generated a detectable amount of it (Figure S6, Supporting Information). This effect may be the same one happening with other additives such as SnF2 that also inhibit this oxidation<sup>[14b]</sup> and 

also turn FASnI3 solution into pale yellow (Figure S4, Supporting Information). 

During the spin-coating process, while DMSO leaves the film, it can be expected that BAAc is retained due to its high boiling point and ionic state.<sup>[20a]</sup> Furthermore, BAAc, with its high boiling point, is challenging to volatilize at an annealing temperature of 100 °C entirely. Hence, during crystallization, it is expelled from the perovskite lattices and accumulates at the film’s grain boundaries and surface, contributing to the filling of the pinholes and grain boundaries.<sup>[12,18]</sup> The multiple bonds between BAAc and SnI2 effectively slow down the crystal growth rate of perovskite films. The hydrogen bonds (NH…I) formed between the ammonium group in BA<sup>+</sup> and I<sup>–</sup> in [SnX6]<sup>4−</sup> framework may inhibit the migration of I<sup>–</sup> ions to the surface of the film and the oxidation process of I<sup>–</sup> ions to I2 or I3<sup>–</sup> , which would reduce iodide defects and further suppress the degradation of the perovskite film to a certain extent. Besides, the long-chain BA<sup>+</sup> group can enhance the perovskite hydrophobicity, while its interaction with the perovskite absorber provides a channel for electron transfer. Moreover, the coordination of Sn(II) by Ac<sup>–</sup> , partially substituting DMSO and modifying the electronic environment of Sn(II), will make the oxidation of Sn(II) by DMSO much less favorable, having as a consequence the reduction of the perovskite trap density.<sup>[23]</sup> In parallel, the infiltration of BAAc in the perovskite precursor complexes can slow the rate in which these would nucleate to form the perovskite crystals. Therefore, by controlling the crystallization kinetics with BAAc, we can expect to obtain a highquality, pinhole-free film with a stable crystal structure. 

The morphology of perovskite films was observed by scanning electron microscope (SEM) to investigate BAAc additive influence on the nucleation and crystallization processes. Perovskite films were deposited on poly(3,4-ethylenedioxythiophene: 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 **2101539 (3 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 2.** Structural characterization of BAAc-containing perovskite films. Top-view SEM images of a) pristine reference and b) optimized BAAccontaining perovskite films. Cross-sectional SEM images of c) reference and d) BAAc-containing perovskite films. 2D GIWAXS patterns of e) reference and f) BAAc-containing perovskite films. g) Azimuthally integrated 1D plots along the out-of-plane direction (azimuth at 90°) and h) radially integrated intensity plots along the ring at _q_ = 10 nm<sup>–1</sup> , assigned to the perovskite (100) plane for reference and BAAc-containing perovskite films. Inset figure in (g) is an enlarged view of the corresponding intensity plots at _q_ = 10 nm<sup>–1</sup> . The scheme in (h) illustrates the change of perovskite crystal structure before and after introducing BAAc. 

poly(styrenesulfonate) (PEDOT: PSS)-coated fluorine-doped tin oxide (FTO) substrates, undergoing subsequent thermal annealing. From the top-view SEM images in **Figure 2** a and Figure S7 in the Supporting Information, we can see that the resultant reference perovskite films exhibit numerous pinholes. These morphological defects are attributed to the rapid growth of crystals over the nucleation.<sup>[24]</sup> However, we found that the perovskite grains arrange more closely after BAAc modification in the perovskite film, which displays almost no pinholes and fewer grain boundaries (Figure 2b and Figure S8, Supporting Information). We also studied the average grain size in the films, which increased after adding BAAc, from ≈439 nm in reference perovskite to ≈532 nm in BAAc-containing perovskite (Figure S9, Supporting Information). The cross-sectional SEM images were displayed in Figure 2c,d, exhibiting a consistent thickness of the perovskite layers of around 350 nm. From these images, we also found out that the reference films contained pinholes on their surface and in bulk, which is strongly undesirable for carrier transport. However, for BAAc-containing perovskite film, the bulk is pretty compact and dense with good crystallinity throughout. The distinct film morphology can be explained considering that the introduction of BAAc provides the interactions of Ac-Sn bridging and hydrogen bonds between BAAc and the [SnX6]<sup>4−</sup> lattice, which can slow down the crystal growth rate and then nucleate uniformly to enhance the film crystallinity, resulting in the pinhole being filled and the crystal size increasing.<sup>[24,25]</sup> 

X-ray diffraction (XRD) was carried out to further study the influence of BAAc on the film crystallization, as demonstrated in Figure S10 in the Supporting Information. We could clearly observe significantly enhanced primary diffraction peak intensities at 2 _θ_ values of around 14.7° and 28.8°, assigned to (100) and (200) planes. These sharply increased peak intensities confirmed that BAAc-containing perovskite possesses a 

higher crystallinity compared to the reference one. Also, 2D GIWAXS was utilized to investigate the effect of BAAc additive on perovskite films’ surface crystal characteristics. As shown in Figure 2e,f, there is a specific difference for the Debye– Scherrer-like ring (D-S ring) in the perovskite crystal structure. The reference perovskite film displayed scattering rings dominated by (100) and (200) crystal planes. After adding BAAc, the GIWAXS pattern showed enhanced intensity along the (100) ring at _q_ ≈ 10 nm<sup>–1</sup> as the scattering vector ( _q_ = 4 _π_ sin _θ_ / _λ_ , where _λ_ is the incident wavelength and 2 _θ_ is the scattering angle), where the signal in the main out-of-plane direction was the strongest, suggesting a preferred orientation. This preferential crystal orientation in BAAc-containing film can effectively promote charge transport and extraction in the vertical direction.<sup>[10a,19b]</sup> This is reflected in the out-of-plane line profile of BAAc-containing film shown in Figure 2g as enhanced peak intensities, especially at _q_ = 10 nm<sup>–1</sup> with a more substantial peak. Also, the radially integrating intensity along the ring at _q_ = 10 nm<sup>–1</sup> performed a relatively sharp peak with the azimuth at 90° for BAAc-containing film, as shown in Figure 2h, which indicates a higher preferential orientation of perovskite.<sup>[26]</sup> 

To quantitatively analyze the crystal orientation distribution, the orientational order parameter _S_ is calculated as follows<sup>[27]</sup> 



<!-- Start of picture text -->
1<br>S = 2 ( 3 f ⊥ − 1) (1)<br><!-- End of picture text -->

where _f_ ⟘ represents the orientation of [SnX6]<sup>4−</sup> octagon along the axis normal of the substrate surface, related to Figure 2h. Specifically, _f_ ⟘ is given by the following function 



<!-- Start of picture text -->
π<br>2<br>2<br>f ⊥ = ∫ ( cos x ) f ( x ) d x (2)<br>0<br><!-- End of picture text -->

**2101539 (4 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 



**Figure 3.** Characterization of crystallization kinetics for perovskite film formation via in situ GIWAXS analysis. Time-resolved azimuthally integrated intensity patterns along the out-of-plane direction (azimuth at 90°) for a) reference and b) BAAc-containing perovskite films. The representative azimuthintegration 1D plots along the out-of-plane direction (azimuth at 90°) for c) reference and d) BAAc-containing perovskite films from (a) and (b), respectively. Time evolutions of radially integrated intensity patterns along the ring at _q_ = 10 nm<sup>–1</sup> for e) reference and f) BAAc-containing perovskite films. 

where _f_ ( _x_ ) is the geometrically corrected scattering intensity (more details in the Supporting Information). 

We calculated and obtained the _f_ ⟘ value of 0.904 and the _S_ value of 0.855 for the reference sample based on the above function. For the BAAc sample, the _S_ value of 0.920 was obtained, while the _f_ ⟘ value is 0.947. The increased _S_ value depicts a better orientation in the out-of-plane direction. The results clearly show that the addition of BAAc significantly improves the crystal orientation of Sn-based perovskite films. 

The two perovskite samples without and with BAAc exhibit distinct structural evolution dynamics to form the perovskite phase. First, the duration of initial annealing stage is determined through the film transfer process from spin coating to annealing (Figure S11, Supporting Information). For reference film in Figure S11a in the Supporting Information, it experienced about 3 s from the yellow phase to the black phase, indicating that the formation duration of the perovskite phase during the initial annealing is ≈3 s. For BAAc-containing film, we can see that the transition time from yellow phase to black phase is delayed to around 4.5 s (Figure S11b, Supporting Information), which is related to the inhibition of crystal growth by BAAc. 

After that, the in situ synchrotron-based GIWAXS measurements were carried out during the annealing process to systematically analyze the crystallization kinetics of perovskite films, as shown in **Figure 3** . 

In the early annealing stage (within the first ≈40 s), blurred scattering halos suggested the reference film crystallinity was poor, which was mainly contributed by the rapid volatilization of residual DMSO under heating, reflected in Figure 3a. DMSO 

molecules were almost completely removed from the film, showing a relatively uniform diffraction intensity.<sup>[28]</sup> Notably, for the BAAc-containing perovskite film, the crystallinity in the initial annealing stage (within the first ≈70 s) is significantly improved (Figure 3b), which may originate from a more stable precursor solution.<sup>[18]</sup> Moreover, the scattering halos centered at _q_ = 10, 17.5, and 20 nm<sup>–1</sup> gradually shift to higher _q_ values. After spin coating, residual DMSO molecules in the crystal lattice caused the perovskite lattice expansion. During heating, with the volatilization of DMSO, the lattice spacing keeps getting smaller. According to the equation of _q_ = 4 _π_ sin _θ_ / _λ_ = 2 _π_ / _d_ (where _d_ is the Bragg spacing in scattering) converted from the Bragg’s law, so we observe the diffraction peak position gradually increases. Also, the duration for the primary crystal conversion in BAAc-containing film was extended to over 40 s. An annealing temperature of 100 °C is not enough to completely volatilize the BAAc ingredient, so it is inferred that BAAc is still present in a large amount in the perovskite film. Due to the existence of AcSn bonds and NH…X hydrogen bonds, the crystallization process of the perovskite film was retarded, thereby extending the time to transform into [SnX6]<sup>4−</sup> octahedra. The delayed crystallization can also support more uniformly complete nucleation sites, resulting in a flat and pinhole-free film.<sup>[29]</sup> It can be seen that, during thermal annealing, the diffraction intensity of BAAc-containing film is stronger than that of the reference film, consistent with the improvement of the crystal characteristics. 

Figure 3c,d shows the representative plots of the azimuthally (90°) integrated intensity of (100) plane for reference and 

**2101539 (5 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** Photovoltaic device performance. a) Device architecture with cross-sectional SEM image of the PSCs. b) _J_ – _V_ curves, c) statistical box charts of PCEs distribution, and d) IPCE spectra and integrated _J_ sc values for reference and BAAc-containing PSCs. e) The stabilized power outputs of reference and BAAc-containing PSCs measured at a fixed MPP voltage as a function of time. f) Enduring stability showing the PCE of reference and BAAccontaining devices as a function of storage period in an N2 atmosphere at 25 °C. If not specified, the amount of BAAc used is 5 m%. 

BAAc-containing films, which can more clearly reflect the crystal structure evolution during annealing. It can be seen from Figure 3c that, with the volatilization of DMSO, the reference film evolved from a bulge peak into a sharper peak, implying the rapid formation of perovskite crystals. Differently, for the BAAc-containing system, the residual DMSO, BA<sup>+</sup> and Ac<sup>–</sup> molecules remaining in the perovskite film at the end of spin coating led to the splitting of the peak, suggesting the emergence of a new perovskite phase (Figure 3d). Since the ionic radius of Ac<sup>–</sup> is larger than that of halogen ions X (I<sup>–</sup> , Br<sup>–</sup> ), a smaller _q_ value is obtained according to _q_ = 2 _π_ / _d_ . Therefore, the splitting left peak ( _q_ ≈ 9.6 nm<sup>–1</sup> ) corresponded to the perovskite with the ASnAc _a_ X3− _a_ structure, and the splitting right peak ( _q_ ≈ 10.0 nm<sup>–1</sup> ) assigned to the ASnX3 type perovskite. At the beginning of the annealing, the DMSO molecules are preferentially escaping the film surface due to their relatively low boiling point. This phenomenon explains why in Figure 3c, the reference peak becomes sharper within the first 40 s. Subsequently, Ac<sup>–</sup> was gradually substituted by X<sup>–</sup> and then expelled to the grain boundaries, resulting in the formation of [SnX6]<sup>4−</sup> octahedra.<sup>[18,30]</sup> At the same time, BA<sup>+</sup> was also discharged on the film surface along with the crystal growth process.<sup>[31]</sup> This evolutionary process is reflected in Figure 3d, where the splitting left peak gradually decreases with the annealing time and the right peak gradually increases. Through the conversion between crystal phases, a unique peak was eventually distinguished after 10 min of annealing, indicating that a stable perovskite structure was formed. More evidence can also be found in Figure S12 in the Supporting Information, where _q_ is around 20 nm<sup>–1</sup> , demonstrating a consistent crystallization mechanism. 

From the perspective of in situ radially integrated intensity along the ring at _q_ = 10 nm<sup>–1</sup> , we can also observe the crystallization process’s improvement after adding BAAc (Figure 3e,f). Furthermore, BAAc-containing film exhibited more substantial diffraction peaks at azimuth = 90° than the reference film. It remained relatively stable with the passage of annealing time, suggesting a better preferential crystal orientation. These dynamical observations indicate that BAAc additive plays a critical role in the interaction with Sn(II) and I<sup>–</sup> during film formation and gives rise to Sn-based perovskite films with better morphology, crystallinity, and preferential orientation. 

To investigate the influence of this more controllable crystal growth process by BAAc additive on photovoltaic performance, we fabricated p-i-n PSCs with a glass/FTO/PEDOT: PSS/ perovskite/C60/bathocuproine/Ag configuration, as illustrated in **Figure 4** a. Each layer of the device was also characterized by cross-sectional SEM on the right side of Figure 4a, confirming the uniform and pinhole-free character of the perovskite film, well sandwiched between PEDOT: PSS hole transport layer (HTL) and C60 electron transport layer (ETL). 

Subsequently, we compared the effect of the addition of different concentrations of BAAc (without BAAc, with 2, 5, 10, and 20 m% BAAc) on the photovoltaic performance measured with an active area of 0.18 cm<sup>2</sup> . Current density–voltage ( _J_ – _V_ ) curves in Figure 4b showed a PCE of 8.6% for the reference PSCs without BAAc, with short-circuit current density ( _J_ sc) of 21.1 mA cm<sup>−2</sup> , _V_ oc of 0.60 V, and fill factor (FF) of 67.4%. While 5 m% BAAc-containing PSCs possessed a significantly improved PCE of 10.4%, with _J_ sc of 22.2 mA cm<sup>−2</sup> , _V_ oc of 0.65 V, and FF of 71.6%, which was also higher than those for 2 m% 

**2101539 (6 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 

BAAc-containing PSCs (PCE of 9.5%), 10 m% (9.9%), and 20 m% (8.9%), as shown in Figure S13 in the Supporting Information. All photovoltaic parameters are summarized in Table S1 in the Supporting Information. In addition, the champion device performance is comparable or even better than those of recent reports in terms of device efficiency and corresponding active area (Figure S14, Supporting Information). For the sake of simplicity, we refer to “BAAc” to indicate 5 m% BAAc in this work, given that it was the optimal concentration. The enhanced PCE was mainly attributed to the concurrent increase of _J_ sc, _V_ oc, and FF parameters, originating from the high-quality perovskite films with improved crystallinity, preferential orientation, and reduced charge recombination centers as well as the suppression of Sn(II) oxidation and I<sup>–</sup> migration. Moreover, _J_ – _V_ curves obtained from the reverse and forward scans of reference and BAAc-containing PSCs were presented in Figure S15 in the Supporting Information, which embodied negligible hysteresis after introducing BAAc, corresponding to low bulk defects and surface traps.<sup>[32]</sup> The box charts in Figure 4c exhibit the statistics of photovoltaic PCEs distribution for the reference and BAAc-containing PSCs, showing good reproducibility. More corresponding detailed data collected from dozens of devices about _J_ sc, _V_ oc, and FF are available in Figure S16 in the Supporting Information. The results suggest that the introduction of BAAc significantly improves overall device performance. Figure 4d displays the incident photon-to-current conversion efficiency (IPCE) spectra of reference and BAAc-containing PSCs. The two devices showed identical IPCE onsets at 900 nm. Differently, the BAAc introduction increased the IPCE value in the entire wavelength range from 350 to 850 nm, which corresponds to the higher _J_ sc for BAAc-containing PSCs. The integrated _J_ sc calculated from IPCE data for the reference and BAAc-containing PSCs is 20.17 and 21.56 mA cm<sup>−2</sup> , respectively, which agree with those _J_ sc value measured from _J_ – _V_ curves in Figure 4b. 

In Figure 4e, the stabilized power outputs at a fixed maximum power point (MPP) voltage were recorded for 180 s under continuous standard air-mass 1.5 global (AM 1.5G) illumination. Fixed voltages were 0.46 and 0.53 V for the reference and BAAc-containing PSCs, respectively. The BAAc-containing PSCs yielded a higher efficiency than the reference ones and emerged straight forward without attenuation, demonstrating an excellent photostability. Given that Sn-based PSCs stability is a major application-oriented challenge, we further monitored the efficiency evolution of unsealed devices stored in a N2-filled glovebox. As illustrated in Figure 4f, the BAAc-containing device maintained 96% of its original efficiency over 1000 h. The reference device retained 96% of its initial efficiency for just 250 h and then degraded rapidly to below 30% within 800 h. Therefore, the BAAc-containing device exhibits impressive long-term stability in addition to enhanced performance, which suggests that the coordination of Ac<sup>–</sup> and Sn(II) inhibits the oxidation of Sn(II), and the introduction of BA<sup>+</sup> long-chain provides superb hydrophobic and oxygen-repellent properties. Furthermore, we found that the device exhibited a fluctuating performance that first increased and then decreased slowly with increasing storage time, with the highest value on the sixth day. The increase in efficiency can be ascribed to the self-healing property or the release of perovskite crystal strain under dark conditions.<sup>[10b,16]</sup> 

Steady-state photoluminescence (PL) measurements were implemented for the perovskite films on quartz substrates to study the charge recombination dynamics. As illustrated in Figure S17 in the Supporting Information, the PL intensity of the BAAc-containing film was significantly higher than that of the reference film. The more vigorous PL intensity revealed that the nonradiative recombination loss is reduced dramatically after adding BAAc. Moreover, compared with the reference film, the PL peak of the BAAc-containing film manifested a slight blueshift, indicating that BAAc additive improved the properties of perovskite crystals and reduced the density of trap states.<sup>[33]</sup> 

Figure S18 in the Supporting Information displayed the quasi-Fermi level splitting (QFLS) histogram occurring in the active perovskite layers of reference and BAAc-containing samples. The latter possessed a higher QFLS value (1.1874 V) than that of reference film (1.1849 V). This result confirmed that the reference film had relatively more extensive radiative recombination, while the introduction of BAAc can alleviate recombination loss due to the increased perovskite crystallinity. By comparing the QFLS in different architectures, interface recombination losses were also evaluated. As shown in Figure S19a in the Supporting Information, the QFLS values decreased after inserting hole and electron transport layers. It was found that charge recombination outside the perovskite bulk mainly occurred in the interface between the perovskite layer and the HTL. Compared with the reference samples, BAAc-containing samples exhibited higher QFLS values corresponding to lower interface recombination (Figure S19b, Supporting Information), which indicated a better contact and carrier extraction between two layers. 

To further confirm the reason for the reduced charge recombination, the devices dark _J_ – _V_ curves were carried out (Figure S20, Supporting Information). The BAAc-containing PSCs possessed a lower dark current density than the reference PSC, indicating the lower leakage current in the BAAc-containing devices.<sup>[19a]</sup> This allowed the reduction of the nonradiative recombination of charge carriers, which simultaneously led to increased _V_ oc of BAAc-containing devices. 

The p-type self-doping arising from the oxidation of Sn(II) to Sn(IV) is considered an unfavorable defect source, which leads to severe bulk recombination of photogenerated carriers.<sup>[34]</sup> To identify the changes in Sn’s valence state in the perovskite film, we employed the X-ray photoelectron spectroscopy (XPS) on these films to study the redox activity of Sn. As displayed in **Figure 5** a,b, Sn 3d region presented the two divided peaks at 487.2 and 488.1 eV, which are assigned to the binding energy of Sn(II) in perovskite lattice and oxidized Sn(IV) species on the film surface, respectively. The ratio of Sn(IV)/Sn (7.6%) of BAAc-containing sample was much lower than that of the reference sample (18.3%), suggesting that the oxidation of Sn(II) was suppressed remarkably by the introduction of BAAc. The corresponding proportion of the Sn(II) and Sn(IV) species is shown in Table S2 in the Supporting Information. This positive effect is attributed to the controllable crystallization process. The resultant compact BAAc-containing perovskite film, the excellent hydrophobicity of long-chain BA<sup>+</sup> cations, and the strong coordination between Ac<sup>–</sup> and Sn(II) synergistically inhibit water and oxygen ingressing into the film and 

**2101539 (7 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 5.** The stability of films and devices against oxidation, water, and heat. High-resolution XPS spectra of Sn 3d for a) reference and b) BAAccontaining films. Contact angles of water droplets on the surface of c) reference and d) BAAc-containing films. e) Long-term thermal stability examined at 85 °C inside a N2-filled glovebox for a BAAc-containing device. f) XRD pattern of BAAc-containing films heated at 85 °C for different periods. 

improving the oxidation resistance of the film, promoting the redox stability of Sn(II).<sup>[16]</sup> 

The contrasted high-resolution XPS spectra of C 1s in Figure S21 in the Supporting Information well confirmed the successful introduction of BAAc into the perovskite film through enhanced CO and CNH3<sup>+</sup> peaks. Since the content of FA<sup>+</sup> in films is constant, which means that CN peak is unchanged, the change of CN/CO peak is caused by the introduction of Ac<sup>–</sup> being equivalent to CO in Ac<sup>–</sup> . Similarly, the enhancement of the CNH3<sup>+</sup> peak is contributed to BA<sup>+</sup> . From the high-resolution spectra of I 3d in Figure S22 in the Supporting Information, it can be observed that BAAccontaining film possessed a higher percentage of I<sup>–</sup> compared to the reference film, and the specific proportion was shown in Table S3 in the Supporting Information. It means that the addition of BAAc can make I<sup>–</sup> more likely to participate in the perovskite lattice, thus reducing the existence of free I<sup>–</sup> ions for conversion to I2 or I3<sup>–</sup> . The resultant high proportion Sn(II) and I<sup>–</sup> in the BAAc-containing perovskite film would better match the stoichiometric ratio of the perovskite absorber’s crystal structure, indicating that the introduction of BAAc hindered the decomposition of the perovskite. 

Furthermore, the hydrophobicity of the reference and BAAccontaining films was assessed by contact angles measurements. It can be seen from Figure 5c,d that the contact angle 

of water drops over BAAc-containing film (73.5°) was distinctly higher than that of the reference film (46.2°), which confirmed an improved hydrophobicity after the introduction of BAAc. The film’s enhanced hydrophobic property was due to the distribution of long-chain BA<sup>+</sup> in the crystalline film. As the crystal growth proceeds, the long-chain spacer cation BA<sup>+</sup> with a larger ionic radius was expelled to the crystal film’s surface, thereby acting as effective surface passivation to isolate water and oxygen.<sup>[31]</sup> This superior hydrophobicity is the basis for resisting the perovskite degradation under ambient conditions that enabled a stable Sn-based PSC. 

In addition to the stability to water and oxidation, thermal stability measurement at 85 °C is crucial for tin-based PSCs, as it is one of the commercial standards that are striving to achieve.<sup>[3a]</sup> In this regard, we performed the 85 °C stability measurement, which has not been reported in Sn-based PSCs yet. The results showed a 80% efficiency retention ( _T_ 80) after nearly 400 h for heating under 85 °C for the BAAc-containing PSCs (Figure 5e), demonstrating the impressive thermal stability of devices containing this ionic liquid. To understand the mechanism of the thermal stability of BAAc-containing devices, we conducted an XRD analysis for the films displayed in Figure 5f. BAAc-containing perovskite films maintained firm diffraction peaks clearly along the (100) and (200) planes. This result indicated a superior crystallinity as the heating time progressed, 

**2101539 (8 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advancedsciencenews.com** 

which would be why the thermally stable device suppresses ion migration during heating.<sup>[35]</sup> After forming perovskite crystals, the SnI bond rupture in the crystal is one of the main pathways to cause Sn(II) oxidation.<sup>[36]</sup> Therefore, restraining this phenomenon is the key to improve device stability. 

All these observations unanimously point out that the introduction of BAAc significantly reduces the carrier recombination, inhibits the oxidation of Sn(II), and improves the film’s hydrophobicity and the stability of the perovskite crystal structure, as reasons for excellent photovoltaic characteristics and durability for Sn-based PSCs. 

## **3. Conclusion** 

In this work, we introduced BAAc ionic liquid into the perovskite solution to regulate the perovskite film’s precursor coordination environment and crystallization kinetics. The strong interactions between the BA<sup>+</sup> /Ac<sup>–</sup> and Sn(II)/X<sup>–</sup> led to a stable precursor solution, inhibiting the oxidation of Sn(II) by DMSO. Subsequently, interacting bonds slowed down the crystal growth rate. As the perovskite crystals formed, BAAc moved to the grain boundary and acted as a bridge, eliminating the pinholes. The long-chain BA<sup>+</sup> cations were ultimately expelled to the perovskite surface and endowed perovskite with excellent hydrophobicity and oxidation resistance. As a result, we obtained a high-quality perovskite film with reduced defect density and preferential crystal orientation. Correspondingly, we reported a champion PCE of 10.4% in a p-i-n planar architecture for BAAc-containing PSCs, which maintained 96% of its original efficiency over 1000 h upon storage in dark and nitrogen. Also, BAAc-containing perovskite films possessed a stable crystal structure at 85 °C, resulting in an impressive device thermal stability. Because tuning the coordination environment and crystallization process is conducive to fabricating high-quality perovskite films and achieving highly efficient and stable devices, we anticipate this work will be a valuable reference for accelerating the performance of tin-based PSCs. 

**www.advenergymat.de** 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Data Availability Statement** 

Research data are not shared. 

## **Keywords** 

enhancing crystallization, ionic liquids, lead free solar cells, tin perovskites, tuning coordination 

Received: May 17, 2021 Revised: June 13, 2021 Published online: July 2, 2021 

- [1] a) Q. Jiang, Y. Zhao, X. Zhang, X. Yang, Y. Chen, Z. Chu, Q. Ye, X. Li, Z. Yin, J. You, _Nat. Photonics_ **2019** , _13_ , 460; b) Akriti, E. Shi, S. B. Shiring, J. Yang, C. L. Atencio-Martinez, B. Yuan, X. Hu, Y. Gao, B. P. Finkenauer, A. J. Pistone, Y. Yu, P. Liao, B. M. Savoie, L. Dou, _Nat. Nanotechnol._ **2021** , _16_ , 584. 

- [2] a) Best Research-Cell Efficiencies, https://www.nrel.gov/pv/assets/ pdfs/best-research-cell-efficiencies.20200104.pdf (accessed: April 2021); b) N.-G. Park, _Nat. Sustainable_ **2020** , _4_ , 192; c) R. Nie, R. R. Sumukam, S. H. Reddy, M. Banavoth, S. I. Seok, _Energy Environ. Sci._ **2020** , _13_ , 2363. 

- [3] a) J. Cao, F. Yan, _Energy Environ. Sci._ **2021** , _14_ , 1286; b) A. Abate, _Joule_ **2017** , _1_ , 659; c) T. Nakamura, S. Yakumaru, M. A. Truong, K. Kim, J. Liu, S. Hu, K. Otsuka, R. Hashimoto, R. Murdey, T. Sasamori, H. D. Kim, H. Ohkita, T. Handa, Y. Kanemitsu, A. Wakamiya, _Nat. Commun._ **2020** , _11_ , 3008. 

- [4] J. Li, H.-L. Cao, W.-B. Jiao, Q. Wang, M. Wei, I. Cantone, J. Lü, A. Abate, _Nat. Commun._ **2020** , _11_ , 310. 

- [5] E. Jokar, C.-H. Chien, C.-M. Tsai, A. Fathi, E. W.-G. Diau, _Adv. Mater._ **2019** , _31_ , 1804835. 

- [6] I. Kopacic, B. Friesenbichler, S. F. Hoefler, B. Kunert, H. Plank, T. Rath, G. Trimmel, _ACS Appl. Energy Mater._ **2018** , _1_ , 343. 

- [7] Z. Lan, J. Meng, K. Zheng, I. E. Castelli, _J. Phys. Chem. C_ **2021** , _125_ , 1592. 

- [8] Z. Liu, H. Yang, J. Wang, Y. Yuan, K. Hills-Kimball, T. Cai, P. Wang, A. Tang, O. Chen, _Nano Lett._ **2021** , _21_ , 1620. 

## **Supporting Information** 

Supporting Information is available from the Wiley Online Library or from the author. 

## **Acknowledgements** 

G.L. and Z.S. contributed equally to this work. The authors acknowledge financial support from the Natural Science Foundation of China (No. 51903181). G.L. acknowledges China Scholarship Council (CSC) for financial support (Grant No. 201906150131). M.S. and W.Z. acknowledge the German Research Foundation for funding via the priority program SPP2196. The authors thank beamline BL14B1 at the Shanghai Synchrotron Radiation Facility (SSRF) for providing the beam time. This work has received funding from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (Grant Agreement No. 804519). 

Open access funding enabled and organized by Projekt DEAL. 

- [9] F. Lin, H. Wang, H. Lin, W. Liu, J. Li, _Chem. Commun._ **2021** , _57_ , 1754. 

- [10] a) S. Shao, J. Liu, G. Portale, H.-H. Fang, G. R. Blake, G. H. ten Brink, L. J. A. Koster, M. A. Loi, _Adv. Energy Mater._ **2018** , _8_ , 1702019; b) T. Wang, Q. Tai, X. Guo, J. Cao, C.-K. Liu, N. Wang, D. Shen, Y. Zhu, C.-S. Lee, F. Yan, _ACS Energy Lett._ **2020** , _5_ , 1741. 

- [11] X. Jiang, F. Wang, Q. Wei, H. Li, Y. Shang, W. Zhou, C. Wang, P. Cheng, Q. Chen, L. Chen, Z. Ning, _Nat. Commun._ **2020** , _11_ , 1245. 

- [12] C. Wang, Y. Zhang, F. Gu, Z. Zhao, H. Li, H. Jiang, Z. Bian, Z. Liu, _Matter_ **2021** , _4_ , 709. 

- [13] X. Meng, T. Wu, X. Liu, X. He, T. Noda, Y. Wang, H. Segawa, L. Han, _J. Phys. Chem. Lett._ **2020** , _11_ , 2965. 

- [14] a) M. I. Saidaminov, I. Spanopoulos, J. Abed, W. Ke, J. Wicks, M. G. Kanatzidis, E. H. Sargent, _ACS Energy Lett._ **2020** , _5_ , 1153; b) J. Pascual, G. Nasti, M. H. Aldamasy, J. A. Smith, M. Flatken, N. Phung, D. Di Girolamo, S.-H. Turren-Cruz, M. Li, A. Dallmann, R. Avolio, A. Abate, _Mater. Adv._ **2020** , _1_ , 1066. 

- [15] a) W. Hui, L. Chao, H. Lu, F. Xia, Q. Wei, Z. Su, T. Niu, L. Tao, B. Du, D. Li, Y. Wang, H. Dong, S. Zuo, B. Li, W. Shi, X. Ran, P. Li, 

**2101539 (9 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

**www.advenergymat.de** 

**www.advancedsciencenews.com** 

   - H. Zhang, Z. Wu, C. Ran, L. Song, G. Xing, X. Gao, J. Zhang, Y. Xia, Y. Chen, W. Huang, _Science_ **2021** , _371_ , 1359; b) D. Di Girolamo, J. Pascual, M. H. Aldamasy, Z. Iqbal, G. Li, E. Radicchi, M. Li, S.-H. Turren-Cruz, G. Nasti, A. Dallmann, F. De Angelis, A. Abate, _ACS Energy Lett._ **2021** , _6_ , 959. 

- [16] E. Jokar, C.-H. Chien, A. Fathi, M. Rameez, Y.-H. Chang, E. W.-G. Diau, _Energy Environ. Sci._ **2018** , _11_ , 2353. 

- [17] F. Wang, X. Jiang, H. Chen, Y. Shang, H. Liu, J. Wei, W. Zhou, H. He, W. Liu, Z. Ning, _Joule_ **2018** , _2_ , 2732. 

- [18] X. Wang, X. Ran, X. Liu, H. Gu, S. Zuo, W. Hui, H. Lu, B. Sun, X. Gao, J. Zhang, Y. Xia, Y. Chen, W. Huang, _Angew. Chem., Int. Ed._ **2020** , _59_ , 13354. 

- [19] a) S. Shao, J. Dong, H. Duim, G. H. ten Brink, G. R. Blake, G. Portale, M. A. Loi, _Nano Energy_ **2019** , _60_ , 810; b) M. Li, W.-W. Zuo, Y.-G. Yang, M. H. Aldamasy, Q. Wang, S. H. T. Cruz, S.-L. Feng, M. Saliba, Z.-K. Wang, A. Abate, _ACS Energy Lett._ **2020** , _5_ , 1923; c) Y. Liao, H. Liu, W. Zhou, D. Yang, Y. Shang, Z. Shi, B. Li, X. Jiang, L. Zhang, L. N. Quan, R. Quintero-Bermudez, B. R. Sutherland, Q. Mi, E. H. Sargent, Z. Ning, _J. Am. Chem. Soc._ **2017** , _139_ , 6693. 

- [20] a) L. Chao, Y. Xia, B. Li, G. Xing, Y. Chen, W. Huang, _Chem_ **2019** , _5_ , 995; b) Y. Xia, C. Ran, Y. Chen, Q. Li, N. Jiang, C. Li, Y. Pan, T. Li, J. Wang, W. Huang, _J. Mater. Chem. A_ **2017** , _5_ , 3193. 

- [21] X. Liu, Y. Wang, F. Xie, X. Yang, L. Han, _ACS Energy Lett._ **2018** , _3_ , 1116. 

- [22] X. Li, M. I. Dar, C. Yi, J. Luo, M. Tschumi, S. M. Zakeeruddin, M. K. Nazeeruddin, H. Han, M. Grätzel, _Nat. Chem._ **2015** , _7_ , 703. 

- [23] D. Wei, F. Ma, R. Wang, S. Dou, P. Cui, H. Huang, J. Ji, E. Jia, X. Jia, S. Sajid, A. M. Elseman, L. Chu, Y. Li, B. Jiang, J. Qiao, Y. Yuan, M. Li, _Adv. Mater._ **2018** , _30_ , 1707583. 

- [24] X. Meng, J. Lin, X. Liu, X. He, Y. Wang, T. Noda, T. Wu, X. Yang, L. Han, _Adv. Mater._ **2019** , _31_ , 1903721. 

- [25] M. Qin, H. Xue, H. Zhang, H. Hu, K. Liu, Y. Li, Z. Qin, J. Ma, H. Zhu, K. Yan, G. Fang, G. Li, U. S. Jeng, G. Brocks, S. Tao, X. Lu, _Adv. Mater._ **2020** , _32_ , 2004630. 

- [26] S. Shao, W. Talsma, M. Pitaro, J. Dong, S. Kahmann, A. J. Rommens, G. Portale, M. A. Loi, _Adv. Funct. Mater._ **2021** , _31_ , 2008478. 

- [27] a) J. Song, G. Zhou, W. Chen, Q. Zhang, J. Ali, Q. Hu, J. Wang, C. Wang, W. Feng, A. B. Djurišić, H. Zhu, Y. Zhang, T. Russell, F. Liu, _Adv. Mater._ **2020** , _32_ , 2002784; b) J. T. Rogers, K. Schmidt, M. F. Toney, G. C. Bazan, E. J. Kramer, _J. Am. Chem. Soc._ **2012** , _134_ , 2884. 

- [28] M. Wang, W. Tian, F. Cao, M. Wang, L. Li, _Adv. Funct. Mater._ **2020** , _30_ , 1909771. 

- [29] D. Huang, P. Xie, Z. Pan, H. Rao, X. Zhong, _J. Mater. Chem. A_ **2019** , _7_ , 22420. 

- [30] L. Chao, T. Niu, H. Gu, Y. Yang, Q. Wei, Y. Xia, W. Hui, S. Zuo, Z. Zhu, C. Pei, X. Li, J. Zhang, J. Fang, G. Xing, H. Li, X. Huang, X. Gao, C. Ran, L. Song, L. Fu, Y. Chen, W. Huang, _Research_ **2020** , _2020_ , 2616345. 

- [31] X. Zheng, Y. Hou, C. Bao, J. Yin, F. Yuan, Z. Huang, K. Song, J. Liu, J. Troughton, N. Gasparini, C. Zhou, Y. Lin, D.-J. Xue, B. Chen, A. K. Johnston, N. Wei, M. N. Hedhili, M. Wei, A. Y. Alsalloum, P. Maity, B. Turedi, C. Yang, D. Baran, T. D. Anthopoulos, Y. Han, Z.-H. Lu, O. F. Mohammed, F. Gao, E. H. Sargent, O. M. Bakr, _Nat. Energy_ **2020** , _5_ , 131. 

- [32] A. Fakharuddin, L. Schmidt-Mende, G. Garcia-Belmonte, R. Jose, I. Mora-Sero, _Adv. Energy Mater._ **2017** , _7_ , 1700623. 

- [33] K. Liu, Q. Liang, M. Qin, D. Shen, H. Yin, Z. Ren, Y. Zhang, H. Zhang, P. W. K. Fong, Z. Wu, J. Huang, J. Hao, Z. Zheng, S. K. So, C.-S. Lee, X. Lu, G. Li, _Joule_ **2020** , _4_ , 2404. 

- [34] a) T.-B. Song, T. Yokoyama, C. C. Stoumpos, J. Logsdon, D. H. Cao, M. R. Wasielewski, S. Aramaki, M. G. Kanatzidis, _J. Am. Chem. Soc._ **2017** , _139_ , 836; b) G. Nasti, A. Abate, _Adv. Energy Mater._ **2020** , _10_ , 1902467. 

- [35] R. Wang, J. Xue, L. Meng, J.-W. Lee, Z. Zhao, P. Sun, L. Cai, T. Huang, Z. Wang, Z.-K. Wang, Y. Duan, J. L. Yang, S. Tan, Y. Yuan, Y. Huang, Y. Yang, _Joule_ **2019** , _3_ , 1464. 

- [36] X. Jiang, Z. Zang, Y. Zhou, H. Li, Q. Wei, Z. Ning, _Acc. Mater. Res._ **2021** , _2_ , 210. 

**2101539 (10 of 10)** 

© 2021 The Authors. Advanced Energy Materials published by Wiley-VCH GmbH 

_Adv. Energy Mater._ **2021** , _11_ , 2101539 

