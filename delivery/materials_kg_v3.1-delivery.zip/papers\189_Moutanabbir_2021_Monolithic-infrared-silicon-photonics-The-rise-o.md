# Monolithic infrared silicon photonics: The rise of (Si)GeSn semiconductors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Applied Physics Letters |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 166 |
| 作者 | O. Moutanabbir, S. Assali, X. Gong, E. O'Reilly, C. Broderick, B. Marzban, J. Witzens, W. Du et al. |
| DOI | 10.1063/5.0043511 |
| 源文件 | 089_Moutanabbir_2021_Monolithic-infrared-silicon-photonics-The-rise-o.pdf |

---
# **Monolithic Infrared Silicon Photonics: The Rise of (Si)GeSn Semiconductors** 

O. Moutanabbir,<sup>1,*</sup> S. Assali,<sup>1</sup> X. Gong,<sup>2</sup> E. O'Reilly,<sup>3</sup> C. Broderick,<sup>3</sup> B. Marzban,<sup>4</sup> J. Witzens,<sup>4</sup> W. Du,<sup>5</sup> S- Q. Yu,<sup>6</sup> A. Chelnokov,<sup>7</sup> D. Buca,<sup>8</sup> D. Nam<sup>9</sup> 

> 1 _Department of Engineering Physics, École Polytechnique de Montréal, Québec, Canada_ 

> 2 _Department of Electrical and Computer Engineering National University of Singapore, Singapore_ 

> 3 _Tyndall National Institute, University College Cork, Ireland_ 

> 4 _Institute of Integrated Photonics, RWTH Aachen University, Aachen, Germany_ 

> 5 _Department of Electrical Engineering and Physics, Wilkes University, PA, USA_ 

> _6 Department of Electrical Engineering, University of Arkansas, AR, USA_ 

> 7 _Univ. Grenoble Alpes, CEA, Leti, Grenoble, France_ 

> 8 _Peter Gruenberg Institute 9 (PGI-9), Forschungszentrum Jülich, Jülich, Germany_ 

> 9 _School of Electrical and Electronic Engineering, Nanyang Technological University, Singapore_ 

* Email: oussama.moutanabbir@polymtl.ca 

## **Abstract** : 

(Si)GeSn semiconductors are finally coming of age after a long gestation period. The demonstration of devicequality epi-layers and quantum-engineered heterostructures has meant that tunable all-group IV Si-integrated infrared photonics is now a real possibility. Notwithstanding the recent exciting developments in (Si)GeSn materials and devices, this family of semiconductors is still facing serious limitations that need to be addressed to enable reliable and scalable applications. The main outstanding challenges include the difficulty to grow highcrystalline quality layers and heterostructures at the desired Sn content and lattice strain, preserve the material integrity during growth and throughout device processing steps, and control doping and defect density. Other challenges are related to the lack of optimized device designs and predictive theoretical models to evaluate and simulate the fundamental properties and performance of (Si)GeSn layers and heterostructures. This Perspective highlights key strategies to circumvent these hurdles and bring this material system to maturity to create farreaching new opportunities for Si-compatible infrared photodetectors, sensors, and emitters for applications in free-space communication, infrared harvesting, biological and chemical sensing, and thermal imaging. 

1 

(Si)GeSn alloys constitute isovalent substitution of the group-IV element Sn in cubic diamond-structured (Si)Ge lattices. This emerging family of semiconductors provides strain and composition as two degrees of freedom to independently engineer the lattice parameter and the band structure, in a similar fashion to the mature compound semiconductors. The prospect of mimicking III-V and II-VI heterostructures and devices using all-group IV semiconductors on a Si platform has generated a great deal of interest, motivated by the potential to achieve the long-sought-after monolithic integration of electronics and photonics.<sup>1-8</sup> Fig. 1(a) illustrates this potential by showing the bandgap energy-lattice parameter space that can be covered by these semiconductors. Short-wave infrared (SWIR: 1.5-3 μm), mid-wave infrared (MWIR: 3-8 μm), and longwave infrared (LWIR: 8-14 μm) bands can be potentially served by all-group IV (Si)GeSn devices. Freespace data communications, infrared harvesting, biochemical sensing, eye-safe LiDAR applications, and thermography technologies would strongly benefit from the availability of cost-effective and Si-compatible (Si)GeSn opto-electronic devices. Moreover, the bandgap is expected to progressively close as Sn content increases, eventually leading to a negative bandgap above 35 at.% Sn with an indirect semimetal behavior.<sup>9</sup> Topological Dirac semimetals could become accessible in this composition range,<sup>10</sup> thus enabling group IV platforms to explore exotic states of matter and potentially harness them in scalable quantum technologies. 



**Figure 1. (a) Bandgap energy of GeSn as a function of the lattice parameter, and for selected III-V, II-VI semiconductors. The Sn content is shown in the top scale; (b) Composition diagram showing constant bandgap contours, indirect-direct bandgap partition, and achieved compositions by MBE and CVD methods.** 

Sn-containing group IV semiconductors were first mentioned in 1982 in a theoretical work that shed light on the potential of GeSn as direct bandgap semiconductors.<sup>11</sup> A few years later, theoretical studies supported these observations and stressed on the possibility of achieving a direct bandgap, but overestimated the Sn critical content (~20 at.%) for the indirect-to-direct band crossover.<sup>12</sup> However, the 

2 

progress and impact of the early experimental studies were limited by multiple challenges. One of the major issues is the difficulty to obtain high-quality crystalline layers due to thermodynamic constraints limiting the solid solubility of Sn to <1 at.% in Ge and <0.1 at.% in Si, which is significantly below the critical content for the direct bandgap (≥~8 at.%). Consequently, the progress in the field required methods to achieve metastable, diamond structure (Si)GeSn materials. Recently, novel epitaxial processes using molecular beam epitaxy (MBE) or chemical vapor deposition (CVD) revived the interest in this system, allowing better control of the crystalline quality of metastable (Si)GeSn-based layers and heterostructures. Fig. 1(b) exhibits the composition range currently achieved by these two methods. Although the growth of high crystalline quality alloys at compositions across the entire pseudoternary phase diagram remains an open challenge, the last few years witnessed exciting developments at the device level. For instance, optically-pumped GeSn lasers were demonstrated at temperatures progressively approaching roomtemperature using both pulsed and continuous wave (CW) excitation,<sup>1-4</sup> and the first electrically-pumped laser was demonstrated in 2020 at cryogenic temperatures.<sup>5</sup> Photodetectors covering the SWIR range and part of the MWIR range were also demonstrated.<sup>6,7,13</sup> Despite these promising proofs of concept, (Si)GeSnbased devices are still in their infancy and face serious challenges that need to be addressed to make them reliable technological building blocks. This Perspective highlights major hurdles in materials development, theoretical modeling and device processing, and discusses potential strategies to bring the (Si)GeSn system closer to maturity. 

**Materials.** The broadly employed approach for the monolithic integration of (Si)GeSn on Si has been epitaxial growth using Ge as interlayer. Consequently, the grown layers are typically compressively strained. This compressive strain has been identified as a limiting factor preventing the incorporation of Sn during growth, and its gradual relaxation yields a composition gradient in thick layers. Plastic relaxation through the growth of lower Sn content buffer layers has been demonstrated to be effective to grow GeSn alloys with uniform Sn incorporation in the 10-20 at.% range with high crystalline quality, sharp interfaces and absence of Sn clusters.<sup>14-16</sup> This process is illustrated in Fig. 2. Dislocations in the GeSn multi-layer structure are mainly confined in the lower Sn content buffer layers, while high structural quality is obtained in the upper portion of the heterostructure. However, the underlying defective buffer layers can be a source of non-radiative recombination and leakage current, with a detrimental effect on device performance. Moreover, the viability of this growth process to achieve micron-thick layers with high and uniform Sn content or multilayer structures with modulated composition is yet to be demonstrated. 

3 



**Figure 2. (a) Schematics of GeSn multi-layer heterostructures grown on a Si wafer. Tight control of the growth temperature yields an enhanced and uniform incorporation of Sn. (b) Cross-sectional TEM image recorded along the [110] zone axis of Ge0.87Sn0.13 grown by a step-graded process.**<sup>**7**</sup> **(c) The corresponding reciprocal space map around the asymmetrical (224) reflection.**<sup>**7**</sup> 

Despite the progress in CVD and MBE processes, alternative growth protocols and designs are still needed to obtain higher Sn content materials and also improve the crystalline quality to enhance device performance. One rather challenging but ambitious possibility would be the direct growth of GeSn on Si and/or to promote more Lomer (pure-edge 90°) which would efficiently relax the strain without creating a high-density of threading dislocations. The recently reported growth of strain-free GeSn-on-Si layers reaching a Sn content up to ~30 at.% lays the groundwork to exploit this approach and test its suitability to grow device-quality, thick layers.<sup>17</sup> Future improvements should also include selective-area growth and _in situ_ low temperature thermal cyclic annealing processes, similar to what is currently used for the growth of Ge or SiGe on Si.<sup>18</sup> However, a low thermal budget must be considered to prevent any degradation of GeSn layers, which are inherently metastable. _Ex situ_ treatments such as laser or flash lamp annealing can also be envisaged to reduce dislocation density. However, systematic studies to elucidate the recrystallization process of laser-annealed (Si)GeSn will be needed to identify key experimental parameters to preserve crystallinity and improve basic properties. Alternatively, the use of nanoscale growth substrates can be effective to mitigate the strain-related effects in (Si)GeSn and enhance the incorporation of Sn.<sup>19,20</sup> Freestanding nanomembranes made of Ge or SiGe are among many templates that can be explored. After their release and transfer onto foreign materials, they would offer highly compliant substrates partitioning the strain with the growing layer.<sup>19</sup> The growth of a Sn-rich layer on a nanostructured substrate would strongly reduce the compressive strain, which could result in higher Sn incorporation without segregation and phase separation. This strategy has already been shown to be effective for the growth of nanowire heterostructures. 

4 

Enhanced strain relaxation along the radial direction of the nanowire core yields defect-free, high Sn content, fully-relaxed Sn-containing shells.<sup>21-25</sup> 

Controlled growth of lattice-matched SiGeSn/GeSn heterostructures across a broad composition range is another important challenge that would greatly improve the performance of optoelectronic devices by enhancing electron and hole confinement. Despite that the equilibrium solubility of Sn in Si is limited to ~0.1 at.%, SiGeSn layers with a tunable composition (4-20 at.% Si, 1-5 at.% Sn) and bandgap in the 0.61.2 eV range have been demonstrated at growth temperatures that are compatible with the growth of binary GeSn layers.<sup>26</sup> However, the integration of SiGeSn/GeSn heterostructures in devices is still at an early stage.<sup>27</sup> While an increased optical emission is expected for SiGeSn/GeSn multi-quantum well (MQW) heterostructures, the band offset must be sufficiently large to be effective for room-temperature operation. Higher Si content is therefore needed to preserve the confinement at room temperature in the GeSn active layer. In the recently demonstrated electrically-pumped GeSn laser, a 250 nm-thick p-type Si0.03Ge0.89Sn0.08 layer was used.<sup>5</sup> Thicker SiGeSn layers (above 500 nm) would be necessary to further increase the lasing mode overlap in GeSn and reduce optical losses away from the SiGeSn contact region. Emitters will also benefit from developing n-type SiGeSn barriers to increase hole confinement in p-i-n or n-i-p structures. 

As-grown intrinsic (Si)GeSn layers have an inherent background doping typically in the low 10<sup>17</sup> cm<sup>-3</sup> range. This behavior is attributed to point defects (vacancy type) and to thermally generated free carriers in such narrow bandgap semiconductors. However, in-depth studies of the underlying origin of this behavior are still conspicuously missing in the literature. These studies are essential to devise effective processes to control any possible effects of growth defects on optical and electronic properties of as-grown (Si)GeSn heterostructures. The background doping combined with defective buffer layers can result in a large leakage or dark current in optoelectronic devices, thus limiting their efficiency. This can be mitigated to a certain extent by using p-i-n heterostructures. However, both n- and p-type dopant incorporation impacts the Sn content in the growing layers, which is attributed to a surface-site competition mechanism between the dopants and Sn atoms.<sup>28,29</sup> While these layers have been integrated in detectors and emitters, fundamental studies correlating device performance with the structural properties would shed light on the current limitations. Future works should also investigate the randomness of the doped (Si)GeSn layers down to the atomic scale to elucidate possible Sn clustering and short-range ordering and their potential impact on the optoelectronic properties.<sup>30</sup> The growth of high Sn content layers would also greatly benefit from the development of new precursors to provide higher reactivity, decomposition at lower temperature and higher growth rates.<sup>31</sup> 

5 

**Theory.** Establishing predictive theoretical models and simulations is vital to accurately design new (Si)GeSn materials and devices. Despite numerous investigations, most published theoretical calculations rely on empirical fitting to match experimental measurements. This highlights the need to consider the impact of atomistic effects on the electronic structure evolution in (Si)GeSn. The “inverted” direct bandgap of semimetallic α-Sn motivated Jenkins and Dow<sup>12</sup> to propose, based on tight-binding (TB) calculations employing the virtual crystal approximation (VCA), that a direct bandgap should emerge in Ge1- _x_ Sn _x_ for _x_ > 15%. Experimental measurements confirmed the transition to a direct bandgap,<sup>32,33</sup> but showed the bandgap decreasing more rapidly with increasing Sn content _x_ than predicted by TB and empirical pseudopotential VCA calculations. Small supercell calculations have subsequently been undertaken by several groups to account explicitly for atomistic effects arising due to differences in size and electronegativity between the group IV elements. Strong bandgap bowing was shown by Moontragoon _et al._<sup>34</sup> using 8-atom supercell charge self-consistent pseudopotential calculations, demonstrating significant deviations from equivalent VCA calculations. An accurate description of the energy gap and of the Γ7c-L6c conduction band (CB) energy splitting in Ge can be obtained using density functional theory (DFT) based on the modified Becke Johnson (mBJ) local density approximation. DFT-mBJ calculations for 216-atom<sup>35</sup> and 54-atom<sup>36</sup> Ge1-xSnx alloy supercells have both shown strong bandgap bowing, indicative of the importance of explicitly including atomistic effects to describe the alloy band structure. Strong mixing (hybridization) is also observed between the lowest conduction state at Γ and other low-lying conduction states which originate from close to the L point in the supercells considered.<sup>36</sup> 



**Figure 3. Bandgap pressure coefficient** **_vs_ . Sn content** **_x_ for Ge1-** **_x_ Sn** **_x_ , measured**<sup>**39**</sup> **(closed circles) and calculated via TB for 1024-atom supercells (open circles). Theoretical data points represent values averaged over those calculated for 25 distinct disordered supercells; error bars represent associated standard deviations. Inset: TBcalculated pressure coefficient vs. supercell size for** **_x_ = 12.5%.** 

6 

The strong band mixing and bandgap bowing can be understood by considering an ordered supercell, such as Ge15Sn1 ( _x_ = 6.25%) where one Ge atom has been replaced by Sn. It can be shown for such a supercell that the lowest conduction state consists primarily of an admixture of two Ge states: (i) a linear combination 𝐿𝐿6𝑐𝑐(𝐴𝐴1)⟩ of Ge L6c CB edge states having _A_ 1 symmetry (i.e. purely _s_ -like orbital between Γ and L-related conduction states then pushes the lowest conduction state downwards in energy, character) at the substitutional Sn lattice site, and (ii) the zone-center Ge CB edge state 𝛤𝛤7𝑐𝑐⟩. This mixing causing bandgap bowing. It is most pronounced in ordered supercells, but persists in all small Ge _N_ - _M_ Sn _M_ supercells ( _N_ <~ 200) which can be investigated via DFT. The question then arises as to whether Sn-induced band mixing effects are an artefact of small supercell calculations, or whether they persist in large-scale atomistic calculations and in experiment, where they will have potentially significant implications for device-relevant optical and electrical properties. 

To enable large-scale calculations, a multi-scale framework for multinary group-IV alloys was recently established,<sup>37</sup> incorporating semi-empirical valence force field (VFF) potentials and TB Hamiltonians parametrized via hybrid functional DFT calculations. The VFF and TB models, which have been benchmarked directly against DFT calculations for small (~ 100 atom) alloy supercells,<sup>38</sup> respectively enable atomistic structural relaxation and electronic structure calculations to be performed for alloy systems containing > 10<sup>4</sup> atoms. Applying the TB method to VFF-relaxed Ge1- _x_ Sn _x_ supercells, it was found at fixed _x_ that alloy band mixing persists, although the scale of mixing decreases with increasing supercell size (and therefore increasing disorder) up to ~2000 atoms, as discussed further below. Hydrostatic pressure provides a useful experimental technique to quantify band mixing in tetrahedrally bonded semiconductors. In Ge, this is facilitated by the very different pressure coefficients of 4.3 and 12.9 meV kbar<sup>-1</sup> associated respectively with the indirect (fundamental) L6c-Γ8v and direct Γ7c-Γ8v bandgaps.  Given the small (≈ 140 meV) L6c-Γ7c energy difference in Ge, the supercell calculations described above suggest that Sn-induced L6c-Γ7c hybridization should have significant impact on the nature and evolution of the Ge1-xSnx bandgap. This is supported by recent pressure-dependent spectroscopic measurements for Ge1- _x_ Sn _x_ photodiodes.<sup>39</sup> The closed circles in Fig. 3 show the measured pressure dependence of the band edge in Ge1- _x_ Sn _x_ samples, obtained from photovoltage measurements of Ge1- _x_ Sn _x_ photodiodes as a function of hydrostatic pressure, while the open circles show the pressure dependence calculated using the TB method for a series of 1024atom supercells. We see in both cases that the pressure coefficient for _x_ ~ 6% is intermediate between those associated with the indirect and direct bandgaps of Ge, suggesting a hybridized bandgap which is neither purely direct nor indirect in nature. The 1024-atom TB calculations underestimate the experimental measurements at higher compositions. The inset to Fig. 3 shows the calculated supercell size-dependent 

7 

pressure coefficient for _x_ = 12.5%, highlighting that large-scale calculations are required to quantitatively understand electronic structure evolution in the presence of alloy band mixing effects. 

Given the difficulties in extracting accurate (Si)GeSn band parameters from first principles calculations, most material and device analysis has to date been based on models parametrized empirically to treat the dependence of the bandgap on Sn composition and strain. This approach has successfully guided impressive progress to date. Strong band mixing is observed in all atomistic theoretical calculations, which persist in large supercell empirical calculations. Experimental evidence for band mixing and its consequences is to date limited. Further theoretical and experimental work is therefore now required, firstly to enable more detailed analysis of the band structure, and ultimately to enable predictive analysis of the impact of previously overlooked atomistic effects on device characteristics. 



<!-- Start of picture text -->
Si CMOS Si Photonics<br>GeSn PD<br>SOI  SOI  SOI<br>Waveguide Grating Coupler Modulator<br>Si<br>SiO2<br>Si substrate<br>Conventional silica fiber HC-PBGF + TDFA<br> Cost advantage<br>1.26 1.46 1.565 1.675 1.91 2.02 λ  (μm) <br>Ease of integration<br> Full coverage to U-<br>1.36 1.53 1.625<br>band and tunable to<br>O E S C L U 2 μm cover “2 μm” band<br><!-- End of picture text -->

**Figure 4. Optical communication wavelength bands using conventional silica fibers and the novel 2 μm band. Solutions using GeSn materials for photodetection and monolithically integrating them with waveguides, grating couplers, and modulators on a common SOI substrate could offer cost advantages, ease of integration with mainstream complementary metal-oxide-semiconductor (CMOS) technology, and full coverage from conventional telecommunication bands to the 2 µm band.** 

**Photodetectors and sensors.** The availability of high quality and stable (Si)GeSn alloys would be a disruptive technology to revolutionize SWIR, MWIR, and LWIR sensing and imaging, which can enable lighter, faster, higher signal-to-noise, integrated, and more energy efficient devices at significantly lower cost. Moreover, (Si)GeSn can also play an immediate role in extending the capabilities of Ge-based Si 

8 

photonics and its flagship applications in data communications and optical components. Current Ge photodetectors only provide good coverage up to the C-band (1530-1565 nm) and their efficiency drops significantly in the L-band (1565-1625 nm).<sup>40</sup> Given the requirement for longer wavelength operation to support further growth in broadband data throughput, new types of photodetectors with extended detection capability are strongly needed. GeSn photodetectors can fulfil this requirement while preserving Sicompatibility. Indeed, with a low Sn content of ~2-3 at.%, full coverage of the O- to U- telecommunication bands with wavelengths from 1260 to 1675 nm can be achieved. 

Higher Sn contents can expand this coverage to much longer wavelengths. Recent studies in lowloss hollow-core photonic bandgap fibers find the lowest-loss window shift from 1.55 to 2 μm, where a new and promising spectral window could be exploited for communication applications<sup>41</sup> to address the forecasted upcoming ‘capacity crunch’. The theoretically predicted minimum loss is even lower than that of conventional single mode fibers. Thulium-doped fiber amplifiers with high gain and low noise in the two-micron-wavelength window (1910-2010 nm) further enhance its practicality to serve as a supplement to current telecommunication infrastructure, as illustrated in Fig. 4. Current photodetectors operating at 2 μm are mainly based on III-V materials such as InGaAs and GaSb, which are difficult to integrate monolithically on a Si substrate or with Si photonics. High volume manufacturing is less likely due to the limited scalability of native III-V substrates. Monolithic integration based on (Si)GeSn materials could offer cost advantages and ease of integration with mainstream complementary metal-oxide-semiconductor (CMOS) technology (Fig. 4). In this vein, a high speed GeSn p-i-n photodiode integrated on a 300 mm Si wafer was recently demonstrated at 2 μm with a 3-dB bandwidth above 10 GHz.<sup>6</sup> An ultra-low leakage current density of 44 mA/cm<sup>2</sup> (at a reverse bias of 1 V) was achieved, similar to that of a Ge photodiode. As compared to p-i-n photodiodes, avalanche photodiodes (APDs) can provide a significant improvement in detector responsivity due to the internal carrier multiplication mechanism. The first GeSn-on-Si APD, in which separate GeSn and Si layers are respectively employed for light absorption and carrier multiplication, was achieved with a cut-off wavelength beyond 2 μm.<sup>42</sup> The obtained thermal coefficient of the avalanche breakdown voltage is 0.053% K<sup>−1</sup> , smaller than that of APDs with III-V multiplication material. The smaller thermal coefficient indicates that the GeSn-on-Si APD has a less stringent requirement for temperature stability. 

Current mainstream Si photonics is built on Si-on-insulator (SOI) platforms.<sup>43</sup> Photonic components, including low-loss waveguides, (de)multiplexers, Mach-Zehnder interferometer modulators, and micro-ring modulators, have been realized on SOI with excellent performance at wavelengths in the 1.31-1.55 μm range. Analogously, Ge-on-insulator (GeOI) is expected to deliver similar building blocks for applications at 2 μm and beyond, as Ge becomes transparent in that wavelength range. In the short term, 

9 

the introduction of GeSn into mainstream Si photonic chips, i.e., wavelength division multiplexing transceivers, could replace Ge photodetectors and extend the detection range up to the U-band to fully exploit the telecommunication bands. To achieve high responsivity and a longer detection wavelength range, high crystalline quality GeSn with higher Sn content would be needed. Currently, integrated Ge waveguide photodetectors are selectively grown on SOI photonics platform. So far, there have been no reports on GeSn waveguide photodetectors integrated on SOI. Selective area growth of GeSn on SOI and realization of SOI waveguide-based photodetectors should also be explored. The race is indeed still on to establish optimal growth processes and Sn content to reach the targeted performance while providing a reliable processing window. 

With their tunable bandgap energy in the SWIR to LWIR range (Fig. 1(a)), the potential of (Si)GeSn materials extends beyond optical communications. Indeed, these systems can also be exploited to implement large-scale sensing devices for thermal imaging as well as for the spectral identification of substances sharing O-H, C-H and N-H bonds. Current SWIR and MWIR technologies are based predominantly on InGaAs, InSb, or HgCdTe. These materials are prohibitively expensive, which translates into a limited imaging and sensing array size and an overall cost of a megapixel sensor that can exceed tens of thousands of dollars. Several advantages, such as its compatibility with CMOS for large-scale manufacturing utilizing state-of-the-art Si image sensor circuits on the same chip, make (Si)GeSn a promising material system for next-generation IR sensing technologies. 

As mentioned above, extended SWIR detectors based on GeSn at a Sn content up to 10 at.% have already been demonstrated. For MWIR detectors, there are limited experimental reports; however recent results show that coverage can be extended to this wavelength range.<sup>7,15</sup> Although the Sn content needed to cover the whole MWIR band has been achieved by several groups, the inherent compressive strain in the as-grown epi-layers limits the actual wavelength coverage.  Strain engineering could be an effective strategy to get around this issue.<sup>44-46</sup> Regardless of the operation wavelength, adding Sn into Ge is typically associated with an increase in the dark current density as compared to that of standard Ge detectors. This is mainly due to the degradation of material quality, re-emphasizing the need to reduce or eliminate growth defects.  For mature IR detector materials such as HgCdTe and InGaAs, empirical rules, for example, under the diffusion current limited conditions, have been developed to give a standard comparison of different devices at different longwave cutoffs under variable temperatures. A similar methodology should be adopted by the (Si)GeSn community to fairly compare the device performance and document the development progress, which requires reporting of the complete set of device characteristics such as temperature dependent dark current, spectrum response, responsivity, and detectivity. 

10 

For LWIR detectors, there are initial optical absorption data for both MBE- and CVD-grown GeSn that can reach this band.  However, more material development effort is needed before devices can be fabricated.  A possible new direction worth exploring is to evaluate if lattice-matched SiGeSn/Ge quantum wells could be used to develop L-valley inter-subband quantum well infrared photodetectors (QWIPs) for LWIR applications. The advantage of group-IV over III-V materials for QWIPs is its much longer nonpolar phonon-dominated scattering lifetime in comparison with that of III-V materials that is dominated by a much shorter polar phonon scattering process. 

Beyond these immediate applications, (Si)GeSn is also a testbed to address fundamental questions in photodetection. For instance, in searching for new IR detection materials it would be instructive to evaluate if indirect bandgap IR materials would offer any advantage over direct bandgap materials. Or, from a more general perspective, what is the ideal band structure for infrared materials that gives the highest detector performance? This question has been overlooked by the community due to a lack of suitable materials to study. In general, the nature of a photodetector is to generate and collect photoexcited carriers. A long carrier lifetime means more carriers to be collected. A dramatic difference of (Si)GeSn over all dominating IR semiconductors is its unique ability to be either a direct or an indirect narrow bandgap material and therefore to tune the carrier lifetime at the same optical transition energy. 

|**Parameter Table**|**HgCdTe**|**T2SL**|**InGaAs**|**Si**|**Ge**|**Ge0.9Sn0.1**|**SiGeSn**|
|---|---|---|---|---|---|---|---|
|**Bandgap**|Direct|Direct|Direct|Indirect|Quasi-direct|**Direct**|**Quasi-direct**|
|**Radiative (cm**<sup>**3**</sup>**/s)**|2×10<sup>-11</sup>|1×10<sup>-10</sup>|>1×10<sup>-10</sup>|1×10<sup>-14</sup>|6×10<sup>-14</sup>|**~10**<sup>**-10**</sup>|**~10**<sup>**-11**</sup>**-10**<sup>**-13**</sup>|
|**Auger (cm**<sup>**6**</sup>**/s)**|2-3×10<sup>-26</sup>|1.6×10<sup>-26</sup>|10<sup>-29</sup>|10<sup>-30</sup>|10<sup>-30</sup>|**~10**<sup>**-28**</sup>|**~10**<sup>**-28**</sup>**-10**<sup>**-29**</sup>|
|**Lifetime (µs)**|~20|~10-20|~10|>1000|~1000|**>10**|**>100**|
|**Absorption (cm**<sup>**-1**</sup>**)**|Med.|Med., long tail|High|Low-Med.|Med.-High|**High**|**Med– High**|



**Table I. Summary of key parameters of (Si)GeSn benchmarked against other popular materials.** 

Table I presents as benchmark the upper (Si)GeSn carrier lifetime limit (estimated by using experimentally reported data on Si and Ge) and theoretically calculated Ge0.9Sn0.1 radiative and Auger recombination coefficients.<sup>47,48</sup> When (Si)GeSn is converted from direct to indirect bandgap by introducing Si into GeSn, both radiative and Auger recombination coefficients will decrease, leading to an extended carrier lifetime on the order of hundreds of microseconds and a corresponding long diffusion length, which could potentially surpass those of HgCdTe, type II superlattices (T2SL), and InGaAs once the material quality is improved.<sup>49</sup> Meanwhile, for absorption, experimental results show that the GeSn absorption spectrum under direct-indirect transition has a high value of ~10,000 cm<sup>-1</sup> with a steep longwave cutoff<sup>50</sup> - twice that of HgCdTe and T2SL. Thus, it is possible to use band structure engineering to search for a sweet spot at which the material absorbs like a direct bandgap but possesses a long carrier lifetime as if it were an 

11 

indirect bandgap material. In fact, when a material is under “quasi-direct” condition (i.e. direct valley is close to but slightly higher in energy than the indirect valleys), high absorption results from the direct optical transition; however, subsequently electrons could quickly scatter to the indirect valleys which could result in a long carrier lifetime due to suppressed radiative and Auger recombination. This so called “kspace charge separation” would only come into play in high quality materials in which Shockley-Read-Hall (SRH) recombination is negligible compared with radiative and Auger recombination, and its validity is yet to be confirmed. 

**Light emitters** . Since the demonstration of the first optically pumped GeSn laser at 90 K, substantial progress has been made to reach higher operation temperatures, lower thresholds, CW operation, and electrical pumping.<sup>1-5</sup> Nevertheless, additional efforts are still needed to integrate all these characteristics in a single device. As mentioned above, improving growth protocols to achieve higher Sn incorporation is of paramount importance. This would increase the energy separation between the Γ- and L-valleys, which is an essential parameter for GeSn gain materials. A smaller Sn content results in a larger fraction of photoexcited electrons populating the L-valleys due to band-filling and thermalization effects. This increases the required pump thresholds and the device temperature, which, in turn, increases the L-valley population relative to Γ, resulting in a runoff of free carrier absorption. 

Pump thresholds on the other hand can be improved by reducing the dimensionality of the gain material in GeSn/SiGeSn quantum wells (QWs).<sup>51</sup> However, with the 13 at.% GeSn alloy used in that work, the maximum operating temperature remained around 120 K, due to the limited directness of the bandgap. Moreover, they reported optical threshold levels, on the order of 35 kW/cm<sup>2</sup> at 20 K with a 1064-nm pump, which are an order of magnitude below that of comparable devices with bulk gain materials,<sup>52</sup> but remain more than one order of magnitude larger than that of III-V lasers with a comparable number (10) of QWs. A second breakthrough in regards to threshold was recently achieved by utilizing a highly tensile strained, low 5.4 at.% GeSn alloy, demonstrating a low threshold of 1.1 kW/cm<sup>2</sup> achieved in CW operation.<sup>4</sup> A high tensile strain of 1.4% was obtained by fully encasing the GeSn gain material in a strained silicon nitride compositions in as-grown layers. However, the lasing temperatures being limited to 70 K and 100 K for layer, which results in a directness 𝛥 **𝛥** 𝐿𝐿–𝛤𝛤 of 70 meV that is commonly only achieved at much higher Sn CW and pulsed operation, respectively, indicates that GeSn with a larger directness must be reached to unlock device operation approaching room-temperature. 

Dark recombination rates are likely to play a very important role in these metastable materials. Indeed, low lifetimes of 214 ps<sup>53</sup> have been recently reported for GeSn at Sn content x = 12.5 at.%, suggesting short nonradiative lifetimes when substantial levels of Sn are being incorporated. Since Sn 

12 

incorporation depends on the growth temperature, with lower Sn content materials grown at higher temperatures, it appears likely that nonradiative lifetimes due to SRH recombination depend on the Sn content and worsen as the latter increases.<sup>54</sup> Another constraint in the design of GeSn/SiGeSn heterostructures is the higher growth temperature that is typically required for the SiGeSn cladding and barrier layers. In fact, low temperature Si incorporation is hindered by limited precursor (e.g., disilane) cracking. With its wider bandgap, and thus smaller refractive index, SiGeSn can serve to confine both free carriers and photons and is thus essential to improve the performance and the operating temperature of GeSn lasers. In order for MQWs involving the SiGeSn material system to operate effectively at room temperature, not only does the directness of the gain material need to be high enough, the barriers confining carriers in the QWs also need to be high enough to adequately confine thermalized carriers inside the wells. Thus, increasing the Si content in auxiliary layers is also of high importance to reach high-efficiency room temperature lasing. 



**Figure 5. Two concepts for undercut MD lasers with improved heat sinking. The insets show the strain profile along the vertical axis drawn close to the periphery of the disk as well as an exaggerated representation of the deformation occurring after undercut. Modeling is based on a 752 nm thick SiGeSn/GeSn gain material stack with six 13.5 at.% GeSn QWs, with silicon nitride stressor layer, with an initial compressive hydrostatic stress of -1 GPa and -2.8 GPa, respectively for panels a dopant profile optimized for electrical injection and grown on top of a 2.5 (a) and (b), deforms the membrane. In addition to radial extension, it bows slightly downward at its outer periphery (23.6** 𝜇 **m thick virtual substrate. A 300 nm thick** 𝜇 **nm in (a), 126.7 nm in (b)). In both cases, the residual radial strain component drops to almost zero; however, in (a) the azimuthal compressive strain remains at -0.5%, close to its as-grown value. In (b), the inner part of the annulus shaped membrane is also under etched to allow further deformation, with the pillar bending outwards and the membrane bending further down at its outer edge. Residual compressive strain in the wells is close to biaxial and remains below -0.18%, close to what was achieved for the optically pumped structure reported by D. Stange** **_et al_ .**<sup>**52**</sup> 

13 

As mentioned above, externally induced tensile strain provides an additional means to improve the directness without sacrificing material quality or the Si content of barrier layers. In the case of electrically pumped structures, free standing membranes, however, present an additional level of complexity, as they increase electrical path lengths and worsen heat sinking. Similar difficulties were for example encountered with electrically pumped III-V photonic crystal membrane lasers, which were solved with a pedestal placed right below the nanocavity serving as both a heat sink and an ideally placed electrical connection.<sup>55</sup> Fig. 5(a) shows a concept for an undercut microdisk (MD) laser, in which the underlying Ge is etched away to a much smaller extent to provide better heat sinking while allowing for membrane deformation in the optically active region. A silicon nitride stressor, deposited and patterned on top of the SiGeSn gain stack, induces tensile stress resulting in radial extension in the undercut region (𝜖𝜖𝑟 **𝑟** ). Note that the strain in the hydrostatic compressive strain (as averaged over all three spatial dimensions), or conversion of the azimuthal direction, 𝜖𝜖𝜃 **𝜃** , remains very close to that of the initially grown structure. The reduction of the hydrostatic strain component from compressive to tensile, improves the directness of the material and thus enables higher temperature lasing. 

It is worth noting that biaxial compressive (tensile) strain in the previously described structures increases the gain of modes with strong in-plane (out-of-plane) E-field components including quasitransverse-electric (TE) polarized (quasi-transverse-magnetic (TM) polarized) whispering gallery modes (WGMs). However, the uniaxial compressive strain along the azimuthal direction seen here favors modes with E-fields oriented along the azimuthal direction, which correspond to radially propagating Fabry-Perot resonances, that are not supported by this structure. In order to remedy this problem, annulus-shaped structures can be used (Fig. 5(b)). By replacing the central pedestal with a ring-shaped structure, that is etched from both sides, higher deformation of the structure is achieved, with the top of the pedestal bending outwards and a more pronounced bending of the outer membrane edge towards the substrate (insets show an exaggerated representation of the deformation). This allows to relieve the compressive strain in both inplane directions. Modeling of these structures at 100 K indicates that these selection rules might play less of a role then first expected, as a consequence of population of both heavy- and light-hole bands as well as polarization-dependent inter-valence band absorption. Thus, while the uniaxial compressive strain seen along the azimuthal direction is detrimental to the amplification of WGMs, and the structure in Fig. 5(b) is preferable from that perspective, it might not prevent the structure in Fig. 5(a) from lasing and constitutes only one of several considerations in the device optimization. Concepts developed for waveguide coupling MD lasers<sup>56</sup> also have yet to be adapted to undercut structures. 

14 

In both designs in Figs. 5(a) and 5(b), the top contact is drawn inside the disk, away from the outer periphery at which the lowest order WGMs have their maximal field strength, in order to reduce resulting optical absorption losses. This type of contacting scheme works very well for III-V disk lasers heterogeneously integrated into silicon photonics,<sup>57</sup> in which, above threshold, the increased radiative recombination in the high optical field regions leads to effective diffusion-driven carrier transport to the active gain medium. However, low SRH lifetimes with current SiGeSn materials would reduce the efficiency of this carrier transport mechanism. Combination of vertical light confinement by means of wider bandgap optical cladding layers, enabling top electrode placement right above the optically active gain region while maintaining acceptable optical losses, with the strain engineering proposed here, might be conducive to obtain even better performance electrically pumped lasers. 

In addition to lasers, (Si)GeSn light-emitting diodes (LEDs) should also be properly investigated because of their relevance as sources of free-space incoherent optical emission needed in biomedical and gas sensing applications.<sup>58,59</sup> The aspects of electrical injection and carrier confinement are somewhat similar to electrically pumped lasers, while the integration into an optical cavity is not required. Being spatially multimode, LEDs are not appropriate for efficient coupling with few-mode optical waveguides. The outcoupling of the incoherent emission from high index semiconductors into free space brings with it many issues, but these problems are rather well understood today. Until now, the reported (Si)GeSn LEDs were just used as test vehicles for laser experiments, with little effort spent on improving the LED itself. Surprisingly, the efficiency of the first, non-optimized GeSn LEDs was on par with commercial III-V InAsSb mid-IR LEDs.<sup>60</sup> A simple gas detection using GeSn LEDs was recently demonstrated.<sup>61</sup> 

In both GeSn homojunctions and MQW heterostructures, the LED efficiency follows the same trend observed in optically pumped GeSn lasers. The best barrier material to date for QWs is the SiGeSn alloy. The barrier energy offset between SiGeSn and GeSn confines carriers in a smaller GeSn well, and strongly increases the radiative recombination. This was proved experimentally, however, for indirect GeSn.<sup>62,63</sup> Indeed, quantization decreases the GeSn alloy directness and lowers the barrier-well energy band offset, thus reducing the emission efficiency and limiting the confinement effect at higher temperatures. To date, the efficiency of the MQW LEDs at elevated temperatures drops well under that of bulk GeSn LEDs that employ higher Sn content, even though the higher Sn content GeSn suffers more lattice defects.  More research is required to improve the epitaxy of (Si)GeSn alloys at a larger Si molar fraction in barriers to extend the MQW advantages towards room temperature operation of LEDs. 

**Summary.** This Perspective provides a glimpse into the development and potential of (Si)GeSn semiconductors and how they brought to the limelight an ambitious roadmap to achieve the long-sought- 

15 

after monolithic integration of electronics and photonics. The ability to precisely and simultaneously control lattice parameters and electronic bands in these group IV alloys enables a variety of heterostructures and low-dimensional systems, which are versatile building blocks for silicon-compatible infrared detectors, sensors, and emitters. Despite recent major advances, further hurdles face the development of these technologies. From our analysis, overcoming thermodynamic constraints to develop high-quality materials remains the most pressing challenge that needs to be solved. The collective efforts of the community are necessary to improve growth processes and identify key experimental parameters to achieve optimal (Si)GeSn layers and heterostructures for higher device performance. The race towards reliable (Si)GeSn technologies would also benefit from predictive theoretical models and simulations and adapted device processing protocols. Current device performance falls short when compared with that demonstrated by established compound semiconductors. Nevertheless, one should not ignore that the latter have already benefited from decades of research and development.<sup>64,65</sup> We envision that similar efforts will be crucial to advance (Si)GeSn materials and harness their properties in innovative silicon-integrated infrared technologies. 

**Acknowledgements.** O. Moutanabbir acknowledges the support from NSERC Canada (Discovery, SPG, and CRD Grants), Canada Research Chairs, Canada Foundation for Innovation, Mitacs, PRIMA Québec, and Defence Canada (Innovation for Defence Excellence and Security, IDEaS). E. O'Reilly and C. Broderick acknowledge the support of Science Foundation Ireland (SFI; project no. 15/IA/3082), and the National University of Ireland (Post-Doctoral Fellowship in the Sciences to C.B.). D. Buca, J. Witzens and B. Marzban gratefully acknowledge funding from the “Deutsche Forschungsgemeinschaft” for grant no. 299480227. D. Nam acknowledges the support from National Research Foundation of Singapore through the Competitive Research Program (NRF-CRP19-2017-01). S.-Q. Yu acknowledges the financial support from the Air Force Office of Scientific Research (AFOSR) (Grant Nos. FA9550-18-1-0045, FA9550-191-0341). A. Chelnokov acknowledges AAPG and Carnot grants by the French ANR. 

The following article has been submitted to Applied Physics Letters. After it is published, it will be found at https://aip.scitation.org/journal/apl. 

**Data availability.** The data that support the findings of this study are available within this article. 

16 

## **References** 

1 S. Wirths, R. Geiger, N. von den Driesch, G. Mussler, T. Stoica, S. Mantl, Z. Ikonic, M. Luysberg, S. Chiussi, J.M. Hartmann, H. Sigg, J. Faist, D. Buca, and D. Grützmacher, Nat. Photonics **9** , 88 (2015). 

2 Y. Zhou, W. Dou, W. Du, S. Ojo, H. Tran, S.A. Ghetmiri, J. Liu, G. Sun, R. Soref, J. Margetis, J. Tolle, B. Li, Z. Chen, M. Mortazavi, and S.Q. Yu, ACS Photonics **6** , 1434 (2019). 

3 J. Chrétien, N. Pauc, F. Armand Pilon, M. Bertrand, Q.-M. Thai, L. Casiez, N. Bernier, H. Dansas, P. Gergaud, E. Delamadeleine, R. Khazaka, H. Sigg, J. Faist, A. Chelnokov, V. Reboud, J.-M. Hartmann, and V. Calvo, ACS Photonics **6** , 2462 (2019). 

4 A. Elbaz, D. Buca, N. von den Driesch, K. Pantzas, G. Patriarche, N. Zerounian, E. Herth, X. Checoury, S. Sauvage, I. Sagnes, A. Foti, R. Ossikovski, J. Hartmann, F. Boeuf, Z. Ikonic, P. Boucaud, D. Grützmacher, and M. El Kurdi, Nat. Photonics **14** , 375 (2020). 

5 Y. Zhou, Y. Miao, S. Ojo, H. Tran, G. Abernathy, J.M. Grant, S. Amoah, G. Salamo, W. Du, J. Liu, J. Margetis, J. Tolle, Y.-H. Zhang, G. Sun, R.A. Soref, B. Li, and S.-Q. Yu, Optica **7** , 924 (2020). 

> 6 S. Xu, W. Wang, Y.-C. Huang, Y. Dong, S. Masudy-Panah, H. Wang, X. Gong, and Y.-C. Yeo, Opt. Express **27** , 5798 (2019). 

7 M.R.M. Atalla, S. Assali, A. Attiaoui, C. Lemieux-Leduc, A. Kumar, S. Abdi, and O. Moutanabbir, Adv. Funct. Mater., in press. https://doi.org/10.1002/adfm.202006329 

8 M. Oehme, K. Kostecki, K. Ye, S. Bechler, K. Ulbricht, M. Schmid, M. Kaschel, M. Gollhofer, R. Körner, W. Zhang, E. Kasper, and J. Schulze, Opt. Express **22** , 839 (2014) 

> 9 H.-S. Lan, S.T. Chang, and C.W. Liu, Phys. Rev. B **95** , 201201 (2017). 

- 10 X. Kong, L. Li, and F.M. Peeters, Appl. Phys. Lett. **112** , 251601 (2018). 

- 11 C. H. L. Goodman, IEE Proc. I Solid State Electron Devices **129** , 189 (1982). 

- 12 D.W. Jenkins and J.D. Dow, Phys. Rev. B **36** , 7994 (1987). 

- 13 H. Tran, T. Pham, J. Margetis, Y. Zhou, W. Dou, P.C. Grant, J.M. Grant, S. Al-Kabi, G. Sun, R.A. Soref, J. Tolle, 

Y.-H. Zhang, W. Du, B. Li, M. Mortazavi, and S.-Q. Yu, ACS Photonics **6** , 2807 (2019). 

- 14 J. Aubin, J.M. Hartmann, A. Gassenq, J.L. Rouviere, E. Robin, V. Delaye, D. Cooper, N. Mollard, V. Reboud, and V. Calvo, Semicond. Sci. Technol. **32** , 094006 (2017). 

- 15 J. Margetis, A. Mosleh, S.A. Ghetmiri, S. Al-Kabi, W. Dou, W. Du, N. Bhargava, S.-Q. Yu, H. Profijt, D. Kohen, R. Loo, A. Vohra, and J. Tolle, Mater. Sci. Semicond. Process. **70** , 38 (2017). 

- 16 S. Assali, J. Nicolas, S. Mukherjee, A. Dijkstra, and O. Moutanabbir, Appl. Phys. Lett. **112** , 251903 (2018). 

- 17 C. Xu, D. Ringwala, D. Wang, L. Liu, C.D. Poweleit, S.L.Y. Chang, H.L. Zhuang, J. Menéndez, and J. Kouvetakis, Chem. Mater. **31** , 9831 (2019). 

- 18  A. Nayfeh, C. O. Chui, . K. C. Saraswat, and T. Yonehara, Appl. Phys. Lett. **85** , 2815 (2004). 

- 19 A. Bhat, O. Elleuch, X. Cui, Y. Guan, S. A. Scott, T. F. Kuech, and M. G. Lagally, ACS Appl. Mater. Interfaces **12** , 20859 (2020). 

- 20 V. Schlykow, P. Zaumseil, M. A. Schubert, O. Skibitzki, Y. Yamamoto, W. M. Klesse, Y. Hou, M. Virgilio, M. De Seta, L. Di Gaspare, T. Schroeder, and G. Capellini, Nanotechnology **29** , 415702 (2018). 

21 M.S. Seifner, A. Dijkstra, J. Bernardi, A. Steiger-Thirsfeld, M. Sistani, A. Lugstein, J.E.M. Haverkort, and S. Barth, ACS Nano **13** , 8047 (2019). 

- 22 S. Assali, A. Dijkstra, A. Li, S. Koelling, M.A. Verheijen, L. Gagliano, N. von den Driesch, D. Buca, P.M. Koenraad, J.E.M. Haverkort, and E.P.A.M. Bakkers, Nano Lett. **17** , 1538 (2017). 

> 23 A.C. Meng, C.S. Fenrich, M.R. Braun, J.P. McVittie, A.F. Marshall, J.S. Harris, and P.C. McIntyre, Nano Lett. **16** , 7521 (2016). 

- 24 J. Doherty, S. Biswas, E. Galluccio, C. A. Broderick, A. Garcia, R. Duffy, E. P. O’Reilly, and J. D. Holmes, Chem. Mater. **32** , 4383 (2020) 

- 25 Y. Yang, X. Wang, C. Wang, Y. Song, M. Zhang, Z. Xue, S. Wang, Z. Zhu, G. Liu, P. Li, L. Dong, Y. Mei, P. K. Chu, W. Hu, J. Wang, and Z. Di, Nano Lett. **20** , 3872 (2020) 

26 C. Xu, R.T. Beeler, G.J. Grzybowski, A.V.G. Chizmeshya, D.J. Smith, J. Menéndez, and J. Kouvetakis, J. Am. Chem. Soc. **134** , 20756 (2012). 

17 

27 G. R. Suwito, M. Fukuda, E. Suprayoga, M. Ohtsuka, E. H. Hasdeo, A. R. T. Nugraha, M. Sakashita, S. Shibayama, and O.Nakatsuka, Appl. Phys. Lett. **117** , 232104 (2020). 

28 B. Vincent, F. Gencarelli, H. Bender, C. Merckling, B. Douhard, D.H. Petersen, O. Hansen, H.H. Henrichsen, J. Meersschaut, W. Vandervorst, M. Heyns, R. Loo, and M. Caymax, Appl. Phys. Lett. **99** , 152103 (2011). 

- 29 N. Bhargava, J. Margetis, and J. Tolle, Semicond. Sci. Technol. **32** , 094003 (2017). 

- 30 B. Cao, S. Chen, X. Jin, J. Liu, and T. Li, ACS Appl. Mater. Interfaces **12** , 57245 (2020). 

- 31 T. Hu, _Synthesis and Properties of Sn-based Group IV Alloys_ , Thesis, Arizona State University (2019). 

- 32 G. He and H. A. Atwater, Phys. Rev. Lett. **79** , 1937 (1997). 

- 33 V.R. D’Costa, C.S. Cook, A.G. Birdwell, C.L. Littler, M. Canonico, S. Zollner, J. Kouvetakis, and J. Menéndez, Phys. Rev. B **73** , 125207 (2006). 

- 34 P. Moontragoon, R. A. Soref, and Z. Ikonic, J. Appl. Phys. **112** , 073106 (2012). 

- 35 C. Eckhardt, K. Hummer, and G. Kresse, Phys. Rev. B **89** , 1 (2014). 

- 36 M.P. Polak, P. Scharoch, and R. Kudrawiec, J. Phys. D. Appl. Phys. **50** , 195103 (2017). 

- 37 C.A. Broderick, E.J. O’Halloran, M.D. Dunne, A.C. Kirwan, A.D. Andreev, S. Schulz, and E.P. O’Reilly, in 2020 IEEE Photonics Soc. Summer Top. Meet. Ser. (IEEE, 2020), pp. 1–2. 

- 38 E.J. O’Halloran, C.A. Broderick, D.S.P. Tanner, S. Schulz, and E.P. O’Reilly, Opt. Quantum Electron. **51** , 314 (2019). 

- 39 T.D. Eales, I.P. Marko, S. Schulz, E. O’Halloran, S. Ghetmiri, W. Du, Y. Zhou, S.-Q. Yu, J. Margetis, J. Tolle, E.P. O’Reilly, and S.J. Sweeney, Sci. Rep. **9** , 14077 (2019). 

- 40 Y. Lin, D. Ma, K. H. Lee, J. Zhou, X. Guo, H. Wang, C. S. Tan, and J. Michel, Proc. IEEE Conf. Group IV Photon., 53-54 (2018). 

- 41 F. Gunning and B. Corbett, Optics and Photonics News **30** , 42 (2019). 

- 42 Y. Dong, W. Wang, S. Y. Lee, D. Lei, X. Gong, W. K. Loke, S.-F. Yoon, G. Liang, and Y.-C. Yeo, Semicond. Sci. Technol. **31** , 095001 (2016). 

- 43 X. Zeng, Z. Huang, B. Wang, D. Liang, M. Fiorentino, R. G. Beausoleil, Optica **6** , 772 (2019). 

- 44 A. Attiaoui and O. Moutanabbir, J. Appl. Phys. **116** , 063712 (2014) 

- 45 Y.-C. Tai, P.-L. Yeh, S. An, H.-H. Cheng, M. Kim, and G.-E. Chang, Nanotechnology **31** , 445301 (2020). 

- 46 R. W. Millar, D. C. S. Dumas, K. F. Gallacher, P. Jahandar, C. MacGregor, M. Myronov, and D. J. Paul, Opt. Express **25** , 25374 (2017). 

> 47 <u>http://www.ioffe.ru/SVA/NSM/Semicond/</u> 

- 48 G. Sun, R. A. Soref, and H. H. Cheng, J. Appl. Phys. **108** , 033107 (2010). 

- 49 <u>https://www.osti.gov/servlets/purl/1241693</u> 

- 50 H. Tran, W. Du, S. A. Ghetmiri, A. Mosleh, G. Sun, R. A. Soref, J. Margetis, J. Tolle, B. Li, H. A. Naseem, and S- Q. Yu, J. Appl. Phys. **119** , 103106 (2016). 

- 51 D. Stange, N. von den Driesch, T. Zabel, F. Armand-Pilon, D. Rainko, B. Marzban, P. Zaumseil, J.-M. Hartmann, Z. Ikonic, G. Capellini, S. Mantl, H. Sigg, J. Witzens, D. Grützmacher, and D. Buca, ACS Photonics **5** , 4628 (2018). 

- 52 D. Stange _et al._ , ACS Photonics **3** , 1279 (2016). 

- 53 B. Julsgaard _et al._ , Photonics Res. **8** , 788 (2020). 

- 54 E. Vitiello, S. Rossi, C. A. Broderick, G. Gravina, A. Balocchi, X. Marie, E. P. O’Reilly, M. Myronov, and F. Pezzoli, Phys. Rev. Applied **14** , 064068 (2020) 

- 55 H.-G. Park, _Science_ **305** , 1444 (2004). 

- 56 B. Marzban, J. Nojic, D. Stange, D.  Buca, and J.  Witzens, J. Design of a waveguide-coupled GeSn disk laser. in _2020 IEEE Photonics Society Summer Topicals Meeting Series (SUM)_ 1–2 (IEEE, 2020). doi:10.1109/SUM48678.2020.916103418. 

> 57 J. Van Campenhout _et al._ Optimization of Electrically Pumped Microdisk Lasers Integrated with a Nanophotonic SOI Waveguide Circuit. in _Integrated Photonics and Nanophotonics Research and Applications / Slow and Fast Light_ vol. 15 ITuG3 (OSA, 2007). 

> 58 J. Dong and D. Xiong, Annals of Biomedical Engineering **45** , 2509 (2017). 

18 

> 59 W. Zeller, L. Naehle, P. Fuchs, F. Gerschuetz, L. Hildebrandt, J. Koeth, Sensors **10** , 2492 (2010). 

> 60 For e.g., LED34, Roitner LaserTechnik, <u>http://www.roithner-laser.com/led_midir_standard.html; MIRDOG http://mirdog.spb.ru/products.htm</u> 

61 L. Casiez, M. Bertrand, J. Chretien, A. Quintero, Q. M. Thai, M. Frauenrath, O. Lartigue, P. Barritault, N. Bernier, P. Rodriguez, A. Chelnokov, J.-M. Hartmann, N. Pauc, V. Calvo, V. Reboud, GIEEE 17th International Conference on Group IV Photonics, accepted (2021). 

62 D. Stange, N. von den Driesch, D. Rainko, S. Roesgaard, I. Povstugar, J.-M. Hartmann, T. Stoica, Z. Ikonic, S. Mantl, D. Grützmacher, D. Buca, Optica **4** , 185 (2017),. 

> 63 L. Peng, X. Li, J. Zheng, X. Liu, M. Li, Z. Liu, C. Xue, Y. Zuo, B. Cheng, Journal of Luminescence **228** , 117539 (2020). 

> 64 A. Yariv, IEEE Transactions on Electron Devices **31** , 1656 (1984). 

> 65 Z. Alferov, IEEE Journal of Selected Topics in Quantum Electronics **6** , 832 (2000). 

19 

