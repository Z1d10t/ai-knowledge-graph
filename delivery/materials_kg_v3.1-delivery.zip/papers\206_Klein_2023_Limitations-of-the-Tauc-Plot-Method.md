# Limitations of the Tauc Plot Method

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Functional Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 586 |
| 作者 | J. Klein, L. Kampermann, Benjamin Mockenhaupt, M. Behrens, Jennifer Strunk, G. Bacher |
| DOI | 10.1002/adfm.202304523 |
| 源文件 | 006_Klein_2023_Limitations-of-the-Tauc-Plot-Method.pdf |

---
**PERSPECTIVE** 

**www.afm-journal.de** 



# **Limitations of the Tauc Plot Method** 

_Julian Klein, Laura Kampermann, Benjamin Mockenhaupt, Malte Behrens, Jennifer Strunk, and Gerd Bacher*_ 

## **1. Introduction** 

**The** **_Tauc plot_ is a method originally developed to derive the** **_optical gap_ of amorphous semiconductors such as amorphous germanium or silicon. 1 By measuring the absorption coefficient** **_𝜶_ (** **_h𝝂_ ) and plotting (** **_𝜶hv_ ) 2 versus photon energy** **_h𝝂_ , a value for the** **_optical gap_ (** **_Tauc gap_ ) is determined. In this way** **_non-direct_ optical transitions between approximately parabolic bands can be examined. In the last decades, a modification of this method for (poly-) crystalline semiconductors has become popular to study** **_direct_ and** **_indirect_ interband transitions. For this purpose, (** **_ah𝝂_ )**<sup>**_n_**</sup> **(** **_n_ =**<sup>**1**</sup> **2**<sup>**, 2) is plotted against**</sup><sup>**_h𝝂𝝂_**</sup> **to determine a value of the** **_electronic bandgap_ . Due to the ease of performing UV–vis measurements, this method has nowadays become a standard to analyze various (poly-) crystalline solids, regardless of their different electronic structure. Although this leads partially to widely varying values of the respective bandgap of nominally identical materials, there is still no study that critically questions which peculiarities in the electronic structure prevent a use of the** **_Tauc plot_ for (poly-) crystalline solids and to which material classes this applies. This study aims to close this gap by discussing the** **_Tauc plot_ and its limiting factors for exemplary (poly-) crystalline solids with different electronic structures.** 

One of the most fundamental properties af- **1** fecting the electrical and optical behavior of **) 2 versus** solids is the bandgap describing the ener- **) is determined. In** getic barrier between the conduction and the valence band. The size of the bandgap allows for the classification of solids as insulators, semiconductors, or metals<sup>[1,2]</sup> and **and** **_indirect_** it determines at which energy a solid can<sup>**, 2) is plotted against**</sup><sup>**_h𝝂𝝂_**</sup> effectively absorb light. The interaction of a material with light is important for applications in, e.g., optoelectronic components or photocatalytic processes. In the last decade, UV–vis measurements, and the implementation of the so-called _Tauc plot_ have become an established and probably the most frequently used method for determining bandgap values ( **Figure 1** a). **and its limiting fac-** Hereby, the measured absorbance is fitted using simple power-law expressions from which values for direct or indirect bandgaps are derived.<sup>[3]</sup> Compared to other analysis techniques, the relatively simple and fast method of UV–vis spectroscopy enables the absorption behavior of the material to be examined in a short time and thus promises a fast access to the bandgap of solid materials. A look at the literature shows that besides elementary and compound semiconductors, _2D_ -materials and others, particularly the size of the bandgap of metal oxides is often derived in this way (see Figure 1a). To give a few examples, the _Tauc plot method_ is used to determine whether a GaAs compound can be applied in photonic devices, ZnO can act as a transparent injection layer/electrode in optoelectronic applications or TiO2 particles can function as absorber in heterogeneous photocatalysis.<sup>[4]</sup> 

J. Klein, L. Kampermann, G. Bacher Werkstoffe der Elektrotechnik and CENIDE Universität Duisburg-Essen Bismarckstraße 81, 47057 Duisburg, Germany E-mail: gerd.bacher@uni-due.de B.Mockenhaupt,M.Behrens Instituteof Inorganic Chemistry andCENIDE Universität Duisburg-Essen Universitätsstraße7,45141 Essen,Germany B.Mockenhaupt Catalysis Engineering Delft University of Technology Van derMaasweg 9,2629 HZ Delft,Netherlands M.Behrens Instituteof Inorganic Chemistry Christian-Albrechts-Universität zu Kiel Max-Eyth-Straße2,24118 Kiel,Germany J.Strunk LeibnizInstituteforCatalysis at theUniversity of Rostock Albert-Einstein-Straße29a,18059 Rostock,Germany 

The resulting values of the direct bandgap derived from the _Tauc plot method_ for the III–V and II–VI semiconductors GaN and CdS are found to be between 3.3–3.45 eV and 2.27–2.61 eV, respectively (Figure 1b, left panel). Values between 2.24 and 2.34 eV are extracted for the bulk lead halide perovskite CsPbBr3 using the _Tauc plot method_ . Very consistent values of the (indirect) bandgap could be derived in the case of elementary semiconductors, such as crystalline silicon ( _c_ -Si) ( _E_ c-Si ≈ 1.1–1.12 eV), while larger variations (between 1 and 1.3 eV) are found for the indirect bandgap of a _2D_ -material like PbSe2 (if present as trilayer). Metal oxides can show insulating, semiconducting or metallic behavior depending on, e.g., the crystal symmetry, metaloxygen bond lengths or the valence electron population.<sup>[5]</sup> These properties strongly influence the optical absorption and thus the results of the derived bandgap, when the _Tauc plot method_ is 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/adfm.202304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution-NonCommercial-NoDerivs License, which permits use and distribution in any medium, provided the original work is properly cited, the use is non-commercial and no modifications or adaptations are made. 

### **DOI: 10.1002/adfm.202304523** 

**2304523 (1 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 1.** a) Number of publications using the _Tauc plot method_ versus year of publication. The total number (gray) as well as the number of publications specifically for metal oxides (red) is shown. Data were obtained through an evaluation using the search engine _Google Scholar_ with the keywords “ _Tauc plot_ ” and _“Tauc plot”_ in combination with _“metal oxide_ . _”_ b) Literature overview of bandgap values for GaN,<sup>[6]</sup> CdS,<sup>[7]</sup> CsPbBr3,<sup>[8]</sup> _c_ -Si,<sup>[9,10]</sup> and _2D_ -PdSe2 (trilayer)<sup>[11]</sup> as well as the metal oxides ZnO,<sup>[12]</sup> P25-TiO2,<sup>[13,14,15]</sup> NiO,<sup>[16]</sup> Fe3O4,<sup>[17]</sup> and Co3O4,<sup>[18]</sup> at room temperature. All values were determined using the _Tauc plot method_ . 

applied (Figure 1b, right panel). For ZnO, values between 3.26 and 3.34 eV are extracted assuming a direct interband transition. For the well-known photocatalyst P25-TiO2 direct and indirect bandgap values between 2.9 and 3.65 eV are reported. For transition metal oxides with highly filled _d-bands_ , it is often observed that a wide range of different bandgap values is derived for the same material. Huge differences of around 2 eV are reported for NiO, Fe3O4, or Co3O4, respectively, and thus no distinct value of the bandgap can be defined. While different manufacturing methods surely affect the structural properties of these materials, they cannot completely explain the huge variation of the bandgap of up to 2 eV for nominally the same material. While apparently the _Tauc plot method_ provides consistent data on the bandgap for certain materials, large variations occur for others, and the reasons behind are poorly understood. Consequently, the question arises whether the _Tauc plot method_ is suitable for deriving the bandgap of all these different types of solids. 

The _Tauc plot method_ was originally developed in the early 1970s to investigate _non-direct_ interband transitions in amorphous semiconductors, such as _amorphous Ge or Si_ .<sup>[3,19]</sup> For this purpose, the expression ~~√~~ _𝛼_ ( _E_ ) _h𝜈_ ∝ _h𝜈_ − _E_ opt was used to determine a value for an _optical gap_ .<sup>[3]</sup> Thus, the original theory according to Tauc was derived for an amorphous structure. However, solids can also have a (poly-) crystalline structure, and, in addition, show direct interband transitions in _k_ - space, in contrast to Si or Ge. For this reason, an alternative approach for deriving the bandgap from optical absorption data became very popular in recent years. This alternative considers the band edge-near absorption in the presence of a crystalline structure, and is commonly used to investigate _direct_ (( _𝛼_ ( _E_ ) _h𝜈_ )<sup>2</sup> ∝ _h𝜈_ − _E_ g) or _indirect_ ( ~~√~~ _𝛼_ ( _E_ ) _h𝜈_ ∝ _h𝜈_ ± _h_ Ωph − _E_ g) interband transitions and to determine their _bandgap E_ g.<sup>[20]</sup> Here, _E_ g is the electronic bandgap, and _h_ Ωph corresponds to the phonon energy. This approach is commonly referred to as “ _Tauc plot_ ,” although not describing the original method after Tauc. 

Despite the common establishment of the _Tauc plot method_ (see Figure 1a), there is surprisingly little discussion about which properties the electronic structure of a solid must possess for a successful application of this methodology. The few studies dealing with a critical evaluation of the _Tauc plot method_ consider selected materials (i.e., ZnO, TiO2) and follow a mathematical approach.<sup>[20–22]</sup> It was investigated, for example, how the respective bandgaps for a combination of two materials can be calculated or which steepness the absorption edge must have to be able to successfully determine a bandgap value by a _Tauc plot_ . Other critical studies of the _Tauc plot method_ primarily present alternative methods of evaluating optical absorption spectra.<sup>[9,23]</sup> However, little attention has been paid to physical effects or peculiarities that can occur in the diverse electronic (band) structures of solids and strongly influence the absorption behavior. A comprehensive study showing under which conditions a bandgap value can be determined using optical absorption spectroscopy and which effects in a solid prevent this is still missing. 

This perspective is intended to fill this gap by considering the diverse electronic structure of solids and highlighting challenges in determining their bandgaps via the _Tauc plot method_ . It is discussed which conditions an electronic structure must fulfill for a successful application and for which solids this does not apply. Based on a consideration of the original theory for amorphous solids according to Tauc<sup>[3]</sup> and the band-to-band absorption of crystalline semiconductors, physical phenomena like band tails, quantization, exciton absorption, _Burstein-Moss_ shift, bandgap renormalization or charge transfer processes are described that can change or superimpose interband transitions and thereby modify the character of the absorption edge and the derived bandgap. This discussion is guided by considering examples of more “classical,” i.e., non-oxide semiconductors (GaN, AlxGa1−xAs, Si, and TlGaS2) as well as diverse metal oxides (CoxFe3−xO4, TiO2, and ZnO). Metal oxides, with their diverse electronic structures, are excellent example materials to show the different challenges that can arise when determining bandgaps in solids. At the end of this evaluation, alternative possibilities are presented to obtain information about the electronic structure of a solid. 

**2304523 (2 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 2.** Optical absorption in amorphous bulk ( _3D_ ) semiconductors: a) Typical optical absorption behavior (Redrawn from ref. [3]), b) density of states _N_ ( _E_ ) as function of energy _E_ according to the _Mott-CFO_ model modified by Tauc (Redrawn from ref. [3]), c) dependence of ~~√~~ _𝛼_ ( _E_ ) _hv_ on photon energy _hv_ (after Tauc<sup>[3]</sup> ) from which the _optical gap E_ opt can be determined. 

## **2. Extracting the Optical Gap Using the Original Tauc Plot Method** 

The _Tauc plot method_ was originally developed for the investigation of the optical absorption edge of amorphous semiconductors.<sup>[3]</sup> Thus, to discuss its ability to describe solids in general, the original method and its application to amorphous semiconductors must be considered first. In contrast to their crystalline counterparts, there is usually no sharp absorption edge in amorphous semiconductors, but rather a widespread increase in the absorption coefficient _𝛼_ ( _E_ ). This broad absorption edge can be separated into three parts: A) the high absorption region due to the fundamental band-to-band absorption (usually _𝛼_ ( _E_ ) _>_ 10<sup>4</sup> cm<sup>−1 [3]</sup> ), B) an exponential part, the so-called _Urbach tail_ (usually _𝛼_ ( _E_ ) ≈ 1–10<sup>3</sup> cm<sup>-1</sup> ), and C) a weak absorption tail (WAT, usually _𝛼_ ( _E_ ) _<_ 1 cm<sup>−1</sup> ) ( **Figure 2** a).<sup>[3,24]</sup> 

For the exponential region B, the _Urbach tail_ , absorption processes involving band edge-near defect states are usually given as cause. The weak absorption tail in region C is mostly explained by the presence of impurities.<sup>[19,25]</sup> However, in order to determine the _optical gap_ , band-to-band transitions must be considered, given by the fundamental band-to-band absorption in region A. In contrast to crystalline semiconductors (see below), the band-to-band absorption in amorphous semiconductors is much more complex and difficult to describe. The most important assumption when discussing transitions between bands is that the selection rule of momentum conservation is relaxed. In contrast to indirect optical transitions in crystalline semiconductors, however, no absorption or emission of a phonon is necessary for such a change in momentum and the complete energy is made available by the absorption of the incident photon.<sup>[3]</sup> To distinguish this process from indirect transitions, it is called a _non-direct_ transition. The cause of the occurrence of these non-direct transitions and the relaxation of the selection rule lies in the different character of the wave functions in an amorphous material compared to a crystalline one. In amorphous semiconductors, not all wavefunctions extend over the whole solid, but some are localized over 

a certain volume. The transition probability between states localized at different sites differs depending on the overlap of the wavefunctions of the initial and final states.<sup>[19]</sup> 

To fully describe the absorption process and to define a dependence of _𝛼_ on the photon energy, knowledge of the energetic distribution of the states between optical transitions taking place is necessary. In the following, we first restrict ourselves to the case of a bulk material ( _3D_ ). An established model to describe the electronic structure and the density of states of non-crystalline bulk materials is the _Mott-CFO (Cohen-Fritzsche-Ovshinsky) model_<sup>[19,26]</sup> which was also adapted by Tauc for his definition of the _optical gap_ (Figure 2b).<sup>[3]</sup> In this model it is proposed that, just like in crystals, states exist in bands separated by an energy gap. Unlike in crystals, however, the densities of states in the valence and conduction band differ and a joint density of states cannot be formulated. According to Mott and Davis, the bands in non-crystalline semiconductors can be divided into states localized near the band edge and delocalized extended states that are further away from the band edge. _E_ c<sup>mand</sup><sup>_E_</sup> v<sup>mindicate the energies at which this sep-</sup> aration between localized and extended states occurs; their energetic distance is called the _mobility gap E_ mob.<sup>[19]</sup> Tauc adapted this model and added another energetic gap, the _optical gap E_ opt or _Tauc gap_ . _E_ opt describes the lowest-energy transition between the valence and conduction band in amorphous semiconductors. According to Tauc, transitions between localized states are possible, making these transitions within the _mobility gap_ define the value of the _optical gap_ .<sup>[3]</sup> The matrix element for these interband transitions is considered as independent of the photon energy ( _constant momentum-matrix-element assumption_ ).<sup>[27]</sup> Assuming that localized states (analogous to the crystalline case) are approximately described by parabolic bands in amorphous bulk (3D) materials, the density of states _N_ ( _E_ ) can be extrapolated deeper into the bands. According to Tauc, the following definition of _E_ opt results for amorphous bulk semiconductors (Figure 2b).<sup>[3]</sup> 



<!-- Start of picture text -->
E opt =  E c , opt − E v , opt (1)<br><!-- End of picture text -->

**2304523 (3 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 

_E_ c,opt corresponds to the energy of the (localized) conduction band state lowest in energy and _E_ v,opt to the highest (localized) energy state of the valence band. Due to _band tails_ describing defect states between the bands, the _optical gap E_ opt is not an “actual bandgap,” i.e., an energetic zone with almost no occupiable states as known from most crystalline semiconductors. According to the _Mott-CFO model_ (modified by Tauc), the density of states _N_ ( _E_ ) never completely vanishes within _E_ opt (Figure 2b). Tauc’s assumptions also result in an expression describing the dependence of _𝛼_ ( _E_ ) on the photon energy _h𝜈_ near the band edge.<sup>[3]</sup> 



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 − E opt)2 (2)<br><!-- End of picture text -->

This relation can be used to determine _E_ opt of an amorphous semiconductor measuring the absorption coefficient _𝛼_ ( _E_ ) and plotting ~~√~~ _𝛼_ ( _E_ ) _hv_ versus the photon energy _hv_ (Figure 2c). The energy at which the extrapolated linear part of the plot hits the energy axis ( _𝛼_ ( _E_ ) = 0) corresponds to the value of _E_ opt. The extrapolation is necessary because in amorphous semiconductors there is always an exponential decay of _𝛼_ ( _E_ ) into the bandgap ( _Urbach tail_ ) as well as a weak absorption tail, which superimposes the interband absorption at lower energies. These absorption tails can shift the absorption onset in amorphous semiconductors even by a few hundred meV up to 1 eV to lower energies.<sup>[3]</sup> This graphical representation according to _Formula_ (2) is the original _Tauc plot_ . 

The _Tauc plot_ was thus initially derived to determine _E_ opt when examining an amorphous semiconductor with non-direct optical transitions between approximately parabolic bands. This is the case for “classical” semiconductors such as silicon or germanium if they are amorphous.<sup>[3]</sup> However, if the original _Tauc plot_ only refers to amorphous semiconductors, the question arises whether it is possible to extract a bandgap for (poly-) crystalline semiconductors as well using UV–vis spectroscopy. For this purpose, it must be considered how the fundamental band-to-band absorption transitions occurs in a crystalline semiconductor. 

phonon. These phonon-assisted transitions are characteristic for indirect bandgaps.<sup>[28,29]</sup> Due to the involvement of a phonon in indirect interband transitions, the rising point of the fundamental absorption edge differs slightly from the electronic bandgap _E_ g. This shift in the absorption onset due to phonons is usually in the range of a few tens of meV.<sup>[30]</sup> Thus, in both interband transitions, the quasi-momentum must be conserved, in the case of direct transitions solely through photons. 

In addition to the type of optical transition (i.e., direct or indirect in _k_ -space), the density of states _N_ ( _E_ ) of the considered semiconductor material strongly affects the behavior of the fundamental band-to-band absorption near the band edge. Assuming a parabolic band structure, _N_ ( _E_ ) of a crystalline bulk semiconductor is proportional to ~~√~~ _E_ (Figure 3c).<sup>[1,28]</sup> The final factors influencing the band-to-band absorption of a crystalline semiconductor are the selection rules of optical transitions. A transition between the valence and the conduction band can be _optically allowed_ or _forbidden_ . The transition probability for an allowed optical transition is many times greater than for a forbidden one, resulting in stronger absorption signals. Consequently, forbidden optical transitions only become dominant at the band edge when no allowed transition is possible.<sup>[1]</sup> Optical transitions are allowed if the transition matrix element of the dipole operator between valence and conduction band functions is non-zero from a symmetry point of view. If this is not the case, the transition is optically forbidden. Since the absorption coefficient _𝛼_ ( _E_ ) of crystalline semiconductors itself is a function of the transition matrix element, optically allowed and forbidden bandgap transitions own different absorption profiles near the band edge.<sup>[1,28,29]</sup> 

If all these factors are considered, there are four expressions for describing the band-to-band absorption and the relationship between _𝛼_ ( _E_ ) and the energy of the incident photons _h𝜈_ .<sup>[19,28]</sup> If the energy dependence of the transition matrix element is neglected, the result for directly allowed interband transitions is:<sup>[1]</sup> 



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 − E g) 2 1 (3)<br><!-- End of picture text -->

## **3. Fundamental Band-to-Band Absorption in Crystalline Semiconductors** 

In a crystalline semiconductor there are basically two different types of optical band-to-band transitions that determine the fundamental absorption and thus the absorption edge, _direct_ and _indirect_ transitions in _k_ -space ( **Figure 3** a,b). In both cases, an electron is excited from the valence to the conduction band under the incidence of a photon and can thus overcome the energetic barrier of the bandgap. In a defect-free direct semiconductor, the fundamental absorption edge marks exactly the energetic difference between the lowest energy state of the conduction band and the highest energy state of the valence band in case excitons are neglected. Consequently, the energy at which the fundamental absorption edge begins to rise corresponds to the electronic bandgap _E_ g.<sup>[1,28]</sup> Such a direct bandgap is always present when the two extremes of the conduction and valence band are at the same point in _k_ -space and therefore no change in the wave vector is necessary for the interband transition. If this is not the case, a transition between the bands is only possible if there is simultaneous interaction with the lattice. The electron wavevector can be altered during the optical transition through the participation of a 

Assuming that the transition matrix element increases linearly with h _𝜈_ − _E_ g, the absorption coefficient _𝛼_ ( _E_ ) for forbidden direct interband transitions, is given by:<sup>[1]</sup> 



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 − E g) 2 3 (4)<br><!-- End of picture text -->

Accordingly, the following two expressions result for indirect allowed (5) and forbidden (6) interband transitions: 



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 ±  h Ωph − E g)2 (5)<br><!-- End of picture text -->



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 ±  h Ωph − E g)3 (6)<br><!-- End of picture text -->

Here, _E_ g is the electronic bandgap, and _h_ Ωph corresponds to the phonon energy. The phonon energy is often considered to be negligibly small, which simplifies Equations (5) and (6) to the following expressions for indirect transitions: 



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 − E g)2 (5a)<br><!-- End of picture text -->



<!-- Start of picture text -->
𝛼 ( E )  h𝜈 ∝ ( h𝜈 − E g)3 (6a)<br><!-- End of picture text -->

**2304523 (4 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 3.** Optical band-to-band absorption in a perfect crystalline bulk ( _3D_ ) semiconductor: a) direct optical absorption process, b) indirect optical absorption process under the emission of a phonon, c) _3D_ -density of states _N_ ( _E_ ) as a function of the energy, d) different kinds of absorption edges for direct allowed ( _n_ =<sup>1</sup> 2<sup>)andforbidden(</sup><sup>_n_=</sup> 32<sup>)aswellasindirectallowed (</sup><sup>_n_=2)and forbidden(</sup><sup>_n_=3)transitions. Excitoniceffectsand bandfilling</sup> effects are neglected. In (d), the phonon energy _h_ Ωph is neglected for indirect transitions. 

If (3), (4), (5a), and (6a) are plotted against the photon energy _h𝜈_ , each interband transition shows a different course of the fundamental band-to-band absorption near the band edges (Figure 3d). In a perfect crystalline semiconductor in which no excitons are formed and state filling and the contribution from phonons are neglected, the energy at which _𝛼_ ( _E_ ) becomes zero agrees with the electronic bandgap _E_ g. Analogous to the original _Tauc plot method_ , the electronic bandgap _E_ g can then be derived if ( _ahv_ )<sup>n</sup> is plotted against the photon energy _hv_ . For direct allowed (forbidden) transitions _n_ takes the value 2 (<sup>2</sup> 3<sup>) and for indirect al-</sup> lowed (forbidden) transitions the value<sup>1</sup> 2<sup>(1</sup> 3<sup>).</sup> 

As an example, an optically allowed direct bandgap of ≈1.42 eV can be determined for GaAs at room temperature by plotting ( _ahv_ )<sup>2</sup> versus _hv_ ( **Figure 4** a). Note that GaAs does not show a 

stable exciton at room temperature, although Coulomb interactions can cause a slight deviation from the theoretical absorption behavior.<sup>[31]</sup> Similarly, by plotting ( _ahv_ ) 12 against _hv_ , an optically allowed indirect bandgap of ≈1.12 eV can be identified for crystalline silicon ( _c_ -Si) at room temperature (Figure 4b). Note that in the vicinity of the indirect bandgap energy, there are deviations from the theoretical behavior according to (5a) due to the contribution of different phonons.<sup>[1]</sup> Nevertheless, both bandgap values derived with this method are in excellent agreement with the well-known bandgap values for these two crystalline semiconductors.<sup>[1,32,33]</sup> 

The use of the ( _ahv_ )<sup>n</sup> plots is possible for these showcase materials since their absorption edges are clearly formed by the fundamental band-to-band absorption under the given conditions. 

**2304523 (5 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



1 **Figure 4.** a) ( _ahv_ )<sup>2</sup> plot for estimating the size of the optically allowed direct bandgap of crystalline GaAs. Data were taken from ref. [9]. b) ( _ahv_ ) 2 plot for estimating the size of the optically allowed indirect bandgap of crystalline silicon ( _c_ -Si). Data were taken from ref. [10]. 

However, there is a bulk of peculiarities in the electronic structure and various physical phenomena that can limit or even prevent the use of ( _ahv_ )<sup>n</sup> plots in (poly-) crystalline solids. This includes: 

- Absorption tails (Section 4) 

- Quantization effects (Section 5) 

- Spectral overlap of different bands (Section 6) 

- Excitons/many-body effects (Section 7) 

- Optical transitions via localized charge carrier transfer (Section 8) 

These limitations of the ( _ahv_ )<sup>n</sup> _plots_ have hardly been addressed in literature up to now and will therefore be discussed in the following sections using different (poly-) crystalline solids as examples that are of practical relevance in electronics, optoelectronics, photovoltaics, or catalysis. 

## **4. Absorption Tails** 

The ( _ahv_ )<sup>n</sup> plots outlined in Section 3 are based on the electronic structure and the theoretical band-to-band absorption behavior of a perfect defect-free crystalline semiconductor, where neither excitons are present nor band filling effects occur. This assumption is a good approximation of the real absorption behavior of singlecrystalline GaAs or _c_ -Si at room temperature but is not valid for many other semiconductor materials. Most semiconductors have additional defects or a polycrystalline structure, i.e., they do not have a perfect crystalline structure but can neither be described 

as amorphous. These deviations in the electronic structure cause changes in the optical absorption behavior, which has implications for the use of the ( _ahv_ )<sup>n</sup> plots. 

Similar to the absorption in amorphous semiconductors (see Figure 2a), non-perfect (poly-) crystalline semiconductors show an exponential decay of the absorption toward lower energy, which leads to absorption of light with an energy slightly smaller than the electronic bandgap _E_ g ( **Figure 5** a). This _Urbach tail_ follows the functional dependence (for _E < E_ g) 



<!-- Start of picture text -->
𝛼 ( E ) ∝ exp (7)<br>( E  − E U E g )<br><!-- End of picture text -->

where _E_ U is the so-called Urbach parameter, which is characteristic for the width of the absorption edge. The larger _E_ U, the stronger the absorption edge is influenced by the exponential tail. Analogous to the bandgap energy _E_ g, _E_ U is a function of temperature.<sup>[1]</sup> The cause of the _Urbach tail_ , which can be found in nearly every semiconductor, is still a matter of debate. In literature, phonons, impurities or excitons have been associated with the observed exponential tails.<sup>[34]</sup> In semiconductor systems with disorder and the presence of defects, the _Urbach tail_ is usually explained by defect states close to the band edges.<sup>[25,35,36]</sup> These defect states cause so called _band tails_ which can be a material property of an imperfect semiconductor or can been introduced into the material, for example, by doping. The exponential _Urbach tail_ at the absorption edge results from transitions between these band tails below the band edges (Figure 5b).<sup>[36]</sup> The Urbach tail in 

**2304523 (6 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 5.** a) Theoretical absorption edge of a direct crystalline and a direct “non-perfect” crystalline semiconductor owning band tails (Redrawn from ref. [36]). b) Energy diagram illustrating a sub-bandgap optical transition with band tails below the band edges. c) Optical absorption spectra for TlGaS2 as a function of temperature (left panel) and the related Urbach energy _E_ U as a function of temperature (right panel) (Reproduced with permission.<sup>[39]</sup> Copyright 2001, John Wiley & Sons, Inc.). 

crystalline semiconductors can shift the absorption onset by only a few tens of meV<sup>[37]</sup> or even by several hundred meV<sup>[38]</sup> to lower energies, depending on the material under consideration and its disorder. The absorption due to _band tails_ can become so strong that it overlaps partly with the fundamental band-to-band absorption. This is particularly challenging when studying a material at room temperature. As previously mentioned, the Urbach energy _E_ U depends on the temperature and increases with rising temperature, which causes the absorption edge to broaden (Figure 5c). This widening of the absorption edge can skew the determined values for the bandgap when using the ( _ahv_ )<sup>n</sup> _plots_ . 

A study by Viezbicke et al. dealt with this problem and investigated whether the ( _ahv_ )<sup>n</sup> _plots_ for crystalline semiconductors also apply to “non-perfect” polycrystalline metal oxides.<sup>[20]</sup> It was concluded that the ( _ahv_ )<sup>n</sup> _plots_ can be used to determine a bandgap even at room temperature provided that the influence of disorder on the absorption edge is not too strong. For this purpose, Viezbicke et al. have developed the NEAR factor (Near-Edge Absorptivity Ratio) to describe the influence of band tails on the absorption edge in a simple way.<sup>[20,40]</sup> The NEAR factor for a direct allowed transition is determined using the following formula. 



<!-- Start of picture text -->
⎧ ⎫1∕2<br>⎪ ( 𝛼hv ) 2| ||( hv  =  E g) ⎪ 𝛼 ( E g)<br>NEAR = 1 . 02⎨ ⎬ = (8)<br>𝛼<br>⎪⎩ ( 𝛼hv ) 2| ||( hv  = 1 . 02 E g) ⎪⎭ ( 1 . 02 E g )<br><!-- End of picture text -->

NEAR factor is intended to determine how steep the absorption edge is in the immediate vicinity of the bandgap.<sup>[40]</sup> To do so, the absorption at the energy of the bandgap is compared with the absorption at a photon energy enhanced by 2%, i.e., 1.02 _E_ g. When the _Urbach tail_ is significant, NEAR approaches 1, while when the absorption edge is little affected by the Urbach tail, NEAR is small, ideally approaching 0. According to Viezbicke et al., the ( _ahv_ )<sup>n</sup> _plot_ should only be used if a NEAR factor _<_ 0.5 can be achieved.<sup>[20,40]</sup> Note, however, that in this study both, excitons as well as band filling effects due to (non)-intentional doping are not considered. 

## **5. Quantization Effects** 

In addition to the presence of defects, the size of a semiconductor has a decisive influence on the electronic structure. As described in Sections 2 and 3, it is a prerequisite for the application of both the original _Tauc Plot_ for amorphous semiconductors and the ( _ahv_ )<sup>n</sup> plots for crystalline semiconductors that interband transitions between (approximately) parabolic bands are present. The parabolic band structure results in a density of states _N_ 3D( _E_ ) proportional to ~~√~~ _E_ . This necessary condition can only be met in _bulk_ ( _3D_ ) semiconductors. If, on the other hand, one considers a material that has a quantization in at least one spatial direction, the band structure and thus the density of states _N_ ( _E_ ) changes ( **Figure 6** a).<sup>[28]</sup> The density of states _N_ 2D( _E_ ) of quantum films ( _2D_ ) is described by a step function, _N_ 1D( _E_ ) of quantum wires ( _1D_ ) is proportional to ~~√~~ 1 _E_<sup>andincaseofquantumdots(</sup><sup>_0D_),discrete</sup> energy levels form. 

So, for example, it is possible to use the ( _ahv_ )<sup>2</sup> plot to identify the direct electronic bandgap of _bulk_ GaAs (see Figure 4a). If, however, GaAs is present in the form of quantum wells, quantization occurs and both the density of states and the optical absorption change (Figure 6b). Thus, once a material exhibits quantization, the use of the ( _ahv_ )<sup>n</sup> plots is no longer allowed. Quantization is expected to occur in semiconductors smaller than a few nanometers in size in at least one spatial direction. For example, ZnO has an exciton Bohr radius _a_ 0 of about 2.3 nm<sup>[42]</sup> and GaAs or CdSe of around 11.2<sup>[43]</sup> or 5.5 nm,<sup>[44]</sup> respectively. If quantum materials with a size smaller than _a_ 0 are considered, the band structure must no longer be investigated using the ( _ahv_ )<sup>n</sup> plots. This applies to all 2D sheets, platelets, or films such as transitionmetal dichalcogenide monolayers, graphene (-oxide), carbon nitrides or 2D perovskites, to 1D wires, rods or tubes like carbon nanotubes or AlxGa1−xAs/Si nanowires or generally to quantum dots and clusters that are sufficiently small for showing quantization effects. 

## **6. Spectral Overlap of Different Bands** 

In the previous sections individual interband transitions were considered which were either superimposed by band tails or 

**2304523 (7 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 6.** a) Schematic representation of the density of states _N_ ( _E_ ) of a _bulk_ ( _3D_ ), quantum film ( _2D_ ), quantum wire ( _1D_ ) and quantum dot ( _0D_ ) semiconductor. b) Optical absorption spectra for _bulk_ -GaAs and a 10 nm-thick quantum well at room temperature. The absorption of _bulk_ -GaAs is shown with an offset of 1.2 · 10<sup>4</sup> cm<sup>−1</sup> . In both cases GaAs is grown between AlxGa1–xAs layers. Note that in case of the GaAs quantum well the bandto-band absorption is superimposed by excitonic resonances (Adapted with permission.<sup>[41]</sup> Copyright 1974, AIP Publishing and Copyright 1985, Optica Publishing Group). 

changed due to quantization. In the following section it will now be examined how the absorption changes when no longer an isolated interband transition occurs. Cases can arise in which there is an overlap between interband transitions at virtually the same energy or in which transitions under the participation of localized defect states close to one band edge are involved. This is illustrated using the example of undoped and metal doped TiO2. 

### **6.1. Spectral Overlap of Multiple Interband Transitions** 

In mixed material systems, which may be tandem systems of different materials or one material with different phases, more than just one interband transition may occur. If these interband transitions are close in energy, both transitions can form a common absorption edge. This is shown schematically in **Figure 7** a. Imagine a mixed material consisting of two perfectly crystalline direct semiconductors _I_ and _II_ (assuming no excitons are formed), with one semiconductor having a slightly larger bandgap ( _E_ g,II _> E_ g,I). If the semiconductors are considered in isolation, both show an absorption behavior _𝛼_ I _h𝜈 and 𝛼_ II _h𝜈_ , (black, dotted lines) according to direct allowed band-to-band transitions (see _Formula_ (3)). The absorption onset is only shifted by Δ _E_ = _E_ g,II − _E_ g,I between 

the two semiconductors. The absorption of the mixed material _𝛼_ I + II _h𝜈_ (black, dashed line) can be formed by superimposing the band-to-band absorption of the isolated semiconductors. If the ( _𝛼h𝜈_ )<sup>2</sup> plot (blue, dashed line) is now applied to the superimposed absorption of the mixed system, i.e., ( _𝛼_ I + II _h𝜈_ )<sup>2</sup> , and the linear part is extrapolated to the energy axis ( _𝛼_ ( _E_ ) = 0) (red, solid line), a bandgap _E_ g,I + II results not reflecting the band-to-band transition of either semiconductor _I_ or _II_ . 

In real materials, it is sometimes difficult to identify this superposition of two band transitions, since other effects (e.g., _Urbach tail_ ) influence the absorption edge additionally. This can be shown using TiO2 as an example. Due to its outstanding importance in the field of, e.g., photocatalysis and dye sensitized solar cells, the absorption behavior of titania materials has been well researched. A characteristic absorption edge in the UV region caused by band-to-band transitions is known.<sup>[45,46]</sup> P25-TiO2 (Evonik) is probably the most important titania photocatalyst with a high level of activity and often cited as a benchmark to compare the performance of new catalysts.<sup>[47]</sup> The mixed-phase titanium oxide is made up of anatase and rutile crystallites in a mixing ratio of typically 4:1.<sup>[45,48]</sup> The P25-TiO2 particles presented in this work have a size of around 30 nm (estimated by scanning electron microscopy, SEM) meaning that quantum confinement 

**2304523 (8 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 7.** a) Theoretical absorption behavior and ( _𝛼h𝜈_ )<sup>_2_</sup> plot of a mixed material system consisting of two perfect crystalline semiconductors with direct bandgaps _E_ g,I and _E_ g,II and no excitons present. _𝛼_ I _h𝜈_ and _𝛼_ II _h𝜈_ (black, dotted) describe the band-to-band absorption of the isolated semiconductors I and II. _𝛼_ I+II _h𝜈_ (black, dashed) shows the absorption of the mixed material due to the superposition of the absorption of the isolated semiconductors. ( _𝛼_ I+II _h𝜈_ )<sup>2</sup> (blue, solid) describes the associated plot for determining the bandgap _E_ g,I+II of the mixed material from the superimposed absorption _𝛼_ I+II _h𝜈_ . The red dashed line describes the extrapolation of the linear part of ( _𝛼_ I+II _h𝜈_ )<sup>2</sup> . b) Optical behavior of P25-TiO2 particles: Optical absorption spectrum (left panel), the dependence of ~~√~~ _𝛼hv_ (middle), and ( _𝛼hv_ )<sup>2</sup> (right panel) on photon energy _hv_ . 

effects can be ruled out. As UV–vis measurements show, P25TiO2 displays an absorption edge starting to rise at around 3 eV and extends over several hundred meV (Figure 7b, left panel). However, the exact nature of this transition causing the absorption edge is discussed controversially. Values of the bandgap that can be found in literature are between 2.9 and 3.65 eV and assigned to both, indirect and direct interband transitions (see Figure 1b).<sup>[14,49]</sup> Typically, these bandgap values are obtained by applying the ( _ahv_ )<sup>n</sup> plots valid for crystalline semiconductors to P25-TiO2. If these two plots were used to determine bandgap values for the P25-TiO2 particles investigated in this work, an indirect bandgap of ≈2.9 eV as well as a direct bandgap of ≈3.3 eV would result (Figure 7b, middle and right panel). Thus, both a direct and an indirect interband transition with an energetic difference of ≈0.4 eV would be assigned to the same absorption edge simultaneously. 

However, as already explained, P25-TiO2 is a mixed material system consisting of rutile and anatase. Due to their different crystal structure, these two phases have a slightly different electronic structure. Anatase is usually assigned to a bandgap in the range of 3.2–3.7 eV by UV–vis measurements and density functional theory (DFT) simulations, while the bandgap of rutile is a few hundred meV smaller.<sup>[50,51]</sup> This behavior can be observed in the optical absorption when both TiO2 crystal phases are studied as separate particles ( **Figure 8** a). Both phases strongly absorb light in the UV range above 3 eV, with the absorption edge of rutile nanoparticles being shifted to lower energies by about 200 meV with respect to the anatase phase. For the mixed material system P25-TiO2 this means that it contains two phases, whose absorption due to band-to-band transitions starts at slightly different energies. Consequently, the absorption edge of P25-TiO2 forms from the superposition of the absorption of both isolated phases and neither the direct nor the indirect transition can be determined with the ( _ahv_ )<sup>n</sup> plots. 

There are studies to mathematically identify multiple bandgaps in mixed material systems by modifying the _Tauc plot_ using the _Lambert-Beer law_ and Taylor series expansion.<sup>[21]</sup> This, however, is only possible if the absorption edges of the different materials can be clearly separated from each other in the superimposed signal, i.e., the interband transitions are energetically far enough away from each other. This is not the case in P25-TiO2. Here the absorption bands from different crystal phases overlap and only a single absorption edge is observed. 

Besides the difficulties when considering a titania mixed system, it is not even trivial to characterize the optical absorption edge of the isolated phases in TiO2. This is due to their complex electronic structure. Different simulation methods are used to calculate the electronic structure and the size of the bandgap of anatase- and rutile-TiO2 (Figure 8b). When using DFT simulations, the well-known limitation of underestimating the bandgap occurs.<sup>[53]</sup> As a result, bandgap values are determined that are energetically significantly lower than the experimental absorption edge. However, using hybrid functional schemes, bandgap values of about ≈3.4 and ≈3.6 eV are estimated for the electronic bandgap of rutile (direct, Γ → Γ) and anatase (indirect, Σ → Γ).<sup>[51]</sup> Despite differences in the size of the calculated bandgaps—depending on the detailed methodology applied— these simulations have in common that the conduction band minimum at the Γ-point in rutile is almost degenerate with the local _R_ and _M_ minima being only a few ten meV higher in energy. A similar picture emerges for anatase, where the direct Γ → Γ transition is only slightly larger (≈13 meV) than the indirect Σ → Γ one. Given these small energetic differences between the calculated direct and indirect interband transitions in both TiO2 phases, it is doubtful whether the respective measured absorption edges can be clearly assigned specifically to one of the two transitions. This complex electronic structure is reflected in the widely varying number of direct and indirect bandgaps reported in literature (see Figure 1b). 

**2304523 (9 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.afm-journal.de** 



**Figure 8.** a) UV–vis diffuse reflectance spectra of phase pure anatase (A)–rutile (R)–and brookite (B) TiO2 nanoparticles (Reproduced with permission.<sup>[52]</sup> Copyright 2008, IOP Publishing). b) Electronic band structure of rutile- and anatase-TiO2 calculated by different models: DFT-HSE06 (solid lines), PBE-G0W0 (dots), and DFT-PBE (gray areas above the CBM and below the VBM) (Adapted with permission.<sup>[51]</sup> Copyright 2012, IOP Publishing). 

As the example of TiO2 shows, the existence of several interband transitions with nearly the same energy distorts the result of the ( _ahv_ )<sup>n</sup> plots. Even if both ( _ahv_ )<sup>n</sup> plots (direct or indirect gap) give a value for a bandgap, these values cannot reflect an accurate description of the respective interband transitions. This can be the case in mixed material systems such as P25-TiO2, but in single phases with a quasi-degeneracy of the direct and indirect bandgaps as well. This applies, for example, to semiconductor alloy systems such as AlxGa1−xAs.<sup>[33,54]</sup> In case that the Al content _x_ is 0 (GaAs) a material with a direct gap and a Γ _– L – X_ valley order is present. In case of the other extreme ( _x_ = 1), AlAs is an indirect material with exactly the reverse valley order. As the _x_ -content is increased from 0, the direct and indirect transitions approach each other energetically until, in a region around _x_ ≈ 0.4, the indirect transition is lower in energy. As absorption measurements show, this is a gradual process around _x_ ≈ 0.4. Both optical transitions occur for a certain _x_ -range simultaneously and influence the absorption edge.<sup>[55]</sup> 

### **6.2. Contribution of Optical Transitions Involving Localized Defect States** 

In addition to an overlap of optical transitions between several bands and at different positions in _k_ -space, it is challenging to use the ( _ahv_ )<sup>n</sup> to derive a bandgap if the materials are doped. Similar to the previously discussed _Urbach tail_ , which is present in almost every solid, defects can also be introduced on purpose into the bandgap by doping leading to the formation of “defect bands.” By introducing impurity atoms, mostly metals, it is intended to vary and control the absorption of the host material to suit a specific application. The shift of the lowest optical transi- 

tion from the UV to the visible region is of great importance for TiO2 materials, for example. Besides an increased photocatalytic activity, doped TiO2 finds a variety of applications in spintronics or photovoltaic components.<sup>[15,56]</sup> When, for example, a TiO2 nanopowder mix of anatase and rutile is doped with iron, additional optical transitions evolve within the bandgap of the previously undoped material ( **Figure 9** a). With increasing iron doping from initially 0.5–20%, these optical transitions become stronger and light in the visible range above 400 nm can be efficiently absorbed. However, one must carefully consider the physics behind this shift in the absorption edge in order to judge, whether the ( _ahv_ )<sup>n</sup> _plot method_ can be applied for deriving the bandgap. As outlined above, the ( _ahv_ )<sup>n</sup> _plot method_ relies on optical transitions between two parabolic bands. When a semiconductor material is heavily doped with impurity atoms, defect states in the vicinity of the conduction or valence band edge or even deep within the electronic bandgap are created. For the doping of TiO2 with iron, these defect levels can be caused, e.g., by oxygen vacancies _O_ v, Ti<sup>3+</sup> interstitials, or Fe<sup>3+</sup> sites.<sup>[53,57]</sup> As a result, the transition lowest in energy is no longer an optical transition between the valence and conduction band, but between defect states within the bandgap or between defect and band states (Figure 9b). As can be seen in Figure 9a, these transitions under the participation of defect states can reach absorption coefficients of ≈10<sup>3</sup> to 10<sup>4</sup> cm<sup>−1</sup> at very heavy doping levels, in this example resulting in a shift of the absorption onset of up to ≈1 eV to lower energies. Consequently, by doping TiO2, the absorption edge can be shifted into the visible range, but the character of the absorption edge changes. This change from interband transitions between (extended) states to transitions that involve (localized) defect states causes that the ( _ahv_ )<sup>n</sup> plots can no longer be used to assess the bandgap change due to doping. 

**2304523 (10 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 9.** a) UV–vis diffuse reflectance spectra of TiO2 nanopowders (rutile-anatase mixture) with different iron doping (Reproduced with permission.<sup>[58]</sup> Copyright 2005, American Chemical Society). b) Simple schematic diagram of the band structure of TiO2 and the appearance of defect levels due to doping with iron (Redrawn from refs. [53,57]). 

Thus, the application of the ( _ahv_ )<sup>n</sup> _plot method_ in TiO2 or doped TiO2 is not only limited by the overlap of different interband transitions but also by the overlap with optical transitions involving localized defect bands near the band edges. This limitation does not only apply to TiO2 but occurs in general when defect bands are formed near the band edges. As will be shown in the following section using (Al-doped) ZnO, further effects, so-called _manybody effects_ , can occur through doping, influencing the absorption edge additionally. 

## **7. Excitons and Many-Body Effects** 

The discussion of the suitability of the ( _ahv_ )<sup>n</sup> plots for determining _E_ g so far was based on the fundamental band-to-band absorption of a crystalline bulk semiconductor, neglecting electron– hole interactions and the formation of excitons. These are present in some crystalline bulk semiconductors even at room temperature and have a significant impact on the absorption behavior near the band edge. If a crystalline semiconductor is additionally doped, the charge carrier density can increase strongly and so-called _many-body effects_ may occur, which affect the near band edge absorption as well. This section aims to consider these effects. 

Due to electron–hole interactions, coupled electron–hole pairs, _excitons_ , can form in bulk semiconductors after optical excitation. The exciton forms a state similar to that of the hydrogen 

atom with several energetic levels ( _n_ =1, 2, 3, …) whereby the optical transitions of the exciton are always lower in energy than for the unbound case, i.e., for interband transitions ( **Figure 10** a, left panel).<sup>[1,28]</sup> 

The energy of the lowest excitonic state ( _n_ = 1) is called the excitonic bandgap _E_ gx and its energetic difference to the electronic bandgap _E_ g of the material is called the exciton binding energy _E_ x. As a result, excitons form discrete absorption lines in direct gap crystalline semiconductors, which lie below the electronic bandgap and merge into the absorption continuum (Figure 10a, right panel).<sup>[28]</sup> The absorption through excitons can have a strength in the order of _𝛼_ ≈ 10<sup>4</sup> –10<sup>5</sup> cm<sup>−1</sup> in direct semiconductors and thereby significantly influence the absorption edge.<sup>[1]</sup> These discrete optical transitions are broadened homogeneously, for example, due to phonon interactions. The resulting line shape of the exciton absorption resonance can thus be described with a Lorentzian function. If, on the other hand, the exciton resonance is broadened inhomogeneously, the shape of the absorption line corresponds to a Gaussian one.<sup>[60]</sup> Excitons are formed in indirect semiconductors as well, but the observed spectra have more of a step-like character due to the involvement of wave vector-conserving phonons. Nevertheless, these steps in the absorption spectrum lie also energetically below the fundamental band-to-band absorption.<sup>[28]</sup> The ( _𝛼h𝜈_ )<sup>n</sup> plots only apply if transitions between parabolic bands are considered. If the optical absorption edge is dominated by an exciton transition, the shape of the absorption edge changes and no longer follows the simple relationship for (in-)directly allowed interband transitions ( _Formula_ (3) _or_ (5a)). Using the ( _𝛼h𝜈_ )<sup>n</sup> plots is therefore no longer allowed. 

Stable excitons and the resulting exciton absorption peak only form if the exciton is sufficiently protected against collisions with phonons. For this reason, narrow and discrete absorption lines can primarily be observed for the respective excitonic states at cryogenic temperatures. This is the case for most crystalline semiconductors and consequently makes use of the ( _𝛼h𝜈_ )<sup>n</sup> plots at cryogenic temperatures unfeasible. However, the excitons in some materials have a sufficiently large binding energy _E_ x that a broadened exciton resonance is still observed at room temperature (Figure 10b).<sup>[31]</sup> This applies to “classical” bulk semiconductors such as the III–V semiconductor GaN with a wurtzite structure ( _E_ x,GaN ≈ 21 meV<sup>[61]</sup> ) or the II–VI semiconductors CdS ( _E_ x,CdS ≈ 30 meV<sup>[62]</sup> ) and wurtzite-ZnO ( _E_ x,ZnO ≈ 60 meV<sup>[28,63]</sup> ). Consequently, the presence of excitons can shift the absorption onset by a few tens of meV to lower energies compared to the band-to-band transition even in bulk materials. 

In addition to the temperature, the stability of the exciton also depends on the charge carrier density. High charge carrier densities can occur in a semiconductor, for example as a result of doping. This can be shown very nicely using the example of doped ZnO. In literature, ZnO is often doped with metals (typically Al, Ga, In, etc.).<sup>[64]</sup> Thus, it is of interest how the absorption changes with increasing doping. Undoped crystalline ZnO with a wurtzite structure is the metal oxide semiconductor which is, along with titania, best characterized in terms of its optical properties. The lowest conduction band of ZnO is formed by the antibonding level of Zn 4s orbitals and the highest valence band by the bonding level of O 2p orbitals. This results in a direct electronic bandgap of around 3.3–3.4 eV for undoped bulk ZnO at 

**2304523 (11 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 10.** a) Left panel: Schematic illustration of excitonic states in a crystalline semiconductor. _E_ g represents the electronic energy gap, _E_ gx the excitonic energy gap and _E_ x the exciton binding energy. The K-vector refers to the center-of-mass motion of the exciton. Right panel: Schematic absorption behavior of a direct semiconductor with exciton absorption lines at cryogenic temperatures. “Excitonic enhancement” occurs, i.e., an increased absorption in the continuum range, since electrons and holes are spatially correlated during the optical transition (Redrawn from ref. [28]). b) Optical absorption of _bulk_ - wurtzite GaN at room temperature. The inset shows an expanded view of the excitonic structure at 77 K (Reproduced with permission.<sup>[59]</sup> Copyright 1997, AIP Publishing). 

room temperature.<sup>[29,65]</sup> The ZnO particles discussed here have a polycrystalline wurtzite structure, a size in the μm-range (determined by SEM) and crystallite sizes _>_ 10 nm (estimated by Scherrer equation from PXRD patterns). Thus, it can be assumed that no quantum confinement effects affect the bulk-like band structure. As shown by UV–vis measurements, these ZnO particles have an absorption edge in the UV spectral range with a strong exciton absorption peak at 3.43 eV ( **Figure 11** a). It is usually discussed that this exciton absorption resonance at room temperature is partly formed by the _A_ -free exciton in combination with the _B_ -free exciton. The _B_ exciton is created under the participation of a hole from a lower level of the valence band.<sup>[66]</sup> As previously discussed, the presence of this exciton peak prevents that a bandgap can be simply determined using the ( _𝛼h𝜈_ )<sup>n</sup> plots. 

Doping these particles with aluminum (AZO) leads to a weakening of the exciton absorption peak until it is no longer observable at a doping level of 10% (Figure 11a). Unlike the previously discussed example of doped TiO2 (see Figure 9a), no absorption peak due to defect states below the bandgap occurs. If the ( _ahv_ )<sup>2</sup> plot for direct allowed transitions would be applied to AZO particles with a doping level of 10% (Figure 11b), a bandgap value of 3.27 eV would be obtained. Note, however, that the exciton resonance apparently vanishes with increasing doping level. 

After doping ZnO with aluminum, additional charge carriers are generated ( _n-_ doping) and the charge carrier density increases significantly. Due to this strong increase in the amount of charge carriers, _many-body effects_ occur.<sup>[1]</sup> The high charge carrier concentration in doped semiconductor systems results in a small distance between the charge carriers, which means that electrons can interact with each other via their _Coulomb potential_ .<sup>[1,67]</sup> This interaction between the charge carriers causes other charge carriers in the direct vicinity to redistribute spatially, thereby reducing the total energy of the electron system. Due to these carrier– carrier interactions, excitons in heavily doped semiconductors 

are no longer stable ( _exciton screening_ ).<sup>[67]</sup> Thus, with increasing doping, the exciton absorption peak broadens and finally vanishes (see Figure 11a). At even higher carrier densities, carrier– carrier interaction leads to a shift of the optical absorption edge to lower energy, which is referred to as _bandgap narrowing_ or _bandgap renormalization_ .<sup>[1]</sup> 

In case the conduction band is no longer empty,<sup>[1,68]</sup> and electrons populate states in the conduction band near the band edge (e.g., due to _n_ -doping), the _Fermi level_ can be shifted into the conduction band ( **Figure 12** a). Thus, optical transitions from the top of the valence band to states at the lower edge of the conduction band are no longer possible due to Pauli blocking. Only states lying energetically higher in the conduction band can be occupied upon optical excitation. This shift of the optical absorption edge to higher energies due to filled conduction band states (similarly if in case of _p_ -doping the valence band is filled with holes) is called _band-filling_ or _Burstein–Moss shift_ .<sup>[1]</sup> If ZnO is doped, the _Burstein–Moss effect_ is usually the dominant effect while _bandgap renormalization_ plays only a role at high doping concentrations (here _>_ 10<sup>20</sup> cm<sup>−3</sup> ) and weakens the increase of the absorption edge energy through the _Burstein–Moss effect_ (Figure 12b).<sup>[69]</sup> As can be shown using the example of Al-doped ZnO thin films, the energetic shift caused by the _Burstein–Moss effect_ (Δ _E_ BM) can be a few hundred meV in size and thus shifts the optical absorption edge by up to 0.3 eV to higher energies (Figure 12c). Note, however, that Al doping of course can in addition lead to a change of the gap between conduction and valence band, but it is highly challenging to entangle the change of the bandgap and the impact of many body effects upon doping by optical absorption experiments. 

Thus, a potential (real) change of the electronic bandgap due to doping can be covered by three effects: i) defect states near the band edges, ii) bandgap renormalization and excitonic effects, or iii) _Burstein–Moss_ effect. All these effects can influence the 

**2304523 (12 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 11.** a) Optical absorption spectrum of ZnO and Al-doped ZnO particles (AZO) with doping levels of 1% and 10%, respectively. b) Dependence of ( _𝛼hv_ )<sup>2</sup> on photon energy _hv_ for AZO (10%). 

position of the optical absorption edge making it impossible to use the ( _ahv_ )<sup>n</sup> plots to determine the bandgap in (highly) doped systems. 

## **8. Transitions via Localized Charge Transfers** 

In the undoped case, the (poly-) crystalline materials discussed so far could be described as “classical” semiconductors. In case the influence of defects is little, the well-known band model based on _Bloch functions_ with non-interacting and delocalized electrons can be applied. According to _Bloch’s band model_ , electrons can populate states in energy bands separated by an energetic gap with forbidden states. When the electronic bands (at zero temperature) are filled below the energy gap and empty above, one gets the “classical” _band insulators_ or _semiconductors_ . If some of the bands are filled above the energy gap, a _metal_ with high conductivity results.<sup>[1]</sup> However, there are a wide variety of transition metal oxides to which the _Tauc plot_ (or ( _ahv_ )<sup>n</sup> plot) method is often applied but for which this conventional classification can no longer be used. The different behavior is caused by the population of the _d-_ band, which is partially occupied with a high number of electrons.<sup>[5]</sup> Due to the partial occupation of the _d-_ band, transition metal oxides such as CoxFe3−xO4, CuO, LaTiO3, VO2, or NiO should actually be metallic conductors but instead show the behavior of electrical insulators. Thus, _Bloch’s band model_ with independent electrons fails to describe these materials, but the different electrical and optical behavior can be explained with models 

by Mott and Hubbard taking electron–electron interaction into account.<sup>[5,70]</sup> 

According to the _Mott–Hubbard model_ , the transition from a metal to an insulator, the so-called _Mott-transition_ , occurs due to the formation of an energy gap within the _d_ -band. This splitting occurs in narrow, heavily filled _3d_ -bands due to Coulomb repulsion and exchange interactions between electrons trying to occupy the same sites. As a result, the _d-_ band splits into an upper, empty, and a lower filled sub-band, also known as the _upper_ and _lower Hubbard-bands_ ( **Figure 13** a).<sup>[70]</sup> The two _Hubbardbands_ are separated by the energy _U_ , the _Hubbard-parameter_ . This gap in the electronic density of states causes a limitation of the mobility and thus a localization of the electrons reducing the conductivity.<sup>[71]</sup> Although the conductivity is lowered, it is not equal to zero since electrons can be transported through the transition metal oxide by a _hopping_ process. Here, an electron “hops” from one metal site _d_ to the next ( _d_ i<sup>n</sup><sup>_d_</sup> j<sup>n→</sup><sup>_d_</sup> i<sup>n−1</sup> _d_ j<sup>n+1</sup> ).<sup>[5]</sup> Transition metal oxides in which such a splitting of the _d_ -band occurs are referred to as _Mott–Hubbard insulators_ in contrast to band insulators, which can be described using the _Bloch theorem_ .<sup>[5]</sup> 

Despite the splitting of the _d_ -band due to electron–electron interactions, in _Mott–Hubbard insulators_ all states of the _d-_ band are higher in energy than the _p-_ band. However, there is the possibility as well that the splitting of the _d-_ band is strong enough that the lower _Hubbard band_ is energetically shifted below the oxygen _p_ - band (Figure 13b).<sup>[5,70]</sup> It follows that the lowest-energy transition between occupied and unoccupied states is no longer a _d–d_ transition but a _p–d_ charge transfer. This energy which is necessary 

**2304523 (13 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 12.** a) Principle of _Burstein–Moss shift_ , left panel: Schematic band structure with filled electron states shown in grey. _̂ k_ represents the _k_ - vector for the optical absorption process lowest in photon energy. Right panel: Electron distribution function for a degenerate electron gas with the Fermi level in the conduction band (Redrawn from ref. [1]). b) Apparent “bandgap” energy as a function of electron concentration in AZO. The inset shows the apparent “bandgap” shift as a function of electron concentration (Reproduced with permission.<sup>[69]</sup> Copyright 2007, AIP Publishing). c) Comparison of the absorption spectrum of Al-doped (AZO) and undoped ZnO thin films (Adapted with permission.<sup>[69]</sup> Copyright 2007, AIP Publishing). 

to excite an electron from the highest occupied oxygen _p_ -state to the lowest unoccupied metal _d-_ state is called the charge transfer term Δ. Depending on whether the _Hubbard term U_ or the charge transfer term Δ is larger, the transition metal oxide is classified as _Mott–Hubbard insulator_ or _charge transfer insulator_ .<sup>[5,70]</sup> In reality, however, this clear classification is much more difficult or sometimes hardly possible. As can be shown from photoemission spectra (Figure 13c), this is due to a strong hybridization between _p-_ and _d-_ states, which usually makes it impossible to clearly separate the density of states of both bands. Consequently, it is 

rarely possible to determine which optical transition is lowest in energy.<sup>[5]</sup> 

The effect of this complex electronic structure of _Mott– Hubbard_ and charge-transfer insulators on the optical absorption behavior can be exemplarily discussed for CoxFe3−xO4. In a first step, the simplest case is considered that there is only one metal cation, namely Co3O4 ( _x_ = 3). Co3O4 is a transition metal oxide with a normal spinel structure that has recently attracted a lot of attention due to its excellent catalytic performance in the oxygen evolution reaction (OER) or 2-propanol oxidation.<sup>[73]</sup> In the spinel crystal structure with a _face centered cubic_ ( _fcc_ ) lattice formed by oxygen anions, there are Co-ions with different oxidation states, Co<sup>2+</sup> and Co<sup>3+</sup> , on the tetrahedral and octahedral symmetry sites.<sup>[74,75]</sup> Simplified, this crystal structure with two different types of Co-ions allows six different optical transitions to occur ( **Figure 14** a, inset). First, _ligand-metal_ c _harge transfer_ processes (LMCT) from the O2p ligand orbitals of the oxygen anions to the two Co-metal ions are possible (O 2p → Co<sup>2 +</sup> , O 2p → Co<sup>3 +</sup> ). In addition, _metal–metal_ c _harge transfer_ processes (MMCT) can occur between the different cobalt ions (Co<sup>2 +</sup> → Co<sup>3 +</sup> , Co<sup>3 +</sup> → Co<sup>2 +</sup> ) as well as one _d_ − _d_ ligand field transition within each cobalt ion (Co<sup>2 +</sup> → Co<sup>2 +</sup> , Co<sup>3 +</sup> → Co<sup>3 +</sup> ). The spatial overlap between two _d-_ orbitals of separated Co-ions appears to be small, but a MMCT transition can still occur via an oxygen bridge. The prerequisite for this is that both _d-_ orbitals have a strong bond with the same O 2p orbital.<sup>[74]</sup> At the same time, four discrete optical transitions can be observed for Co3O4 in the absorption spectrum between 300 and 2000 nm causing maxima around 2.81, 1.64, 0.93, and 0.82 eV (Figure 14a).<sup>[74]</sup> These optical transitions in _Mott–Hubbard_ or charge transfer insulators can have absorption coefficients in the range of 10<sup>4</sup> cm<sup>−1</sup> .<sup>[76]</sup> 

Establishing an unambiguous connection between these four optical features and the possible six transfer and ligand field transitions is still challenging. In a study considering the optical absorption during the gradual substitution of Co<sup>2+</sup> by Zn<sup>2+</sup> , it is assumed that the broad peak at 2.81 eV is caused by LMCT processes between O<sup>2 −</sup> (2p) and Co<sup>2 +</sup> (t2) or Co<sup>3 +</sup> (eg) orbitals.<sup>[74,78]</sup> By measuring the dielectric function of Co3O4 with spectroscopic ellipsometry, it is suggested that the peak around 1.64 eV is due to a MMCT process between Co<sup>3 +</sup> (t2g) and Co<sup>2 +</sup> (t2).<sup>[78]</sup> But, to our knowledge, there is still no experimental study that provides a clear assignment of all four optical transitions to specific processes. There is in particular still lack of knowledge on the transitions at low energies ( _<_ 1 eV). Accordingly, it is hardly possible to say whether Co3O4 is a _Mott–Hubbard_ or a charge-transfer insulator. 

The application of the _Tauc plot method_ to extract a value for the bandgap requires extended states in _Bloch bands_ .<sup>[1]</sup> This is the case in “classical” band semiconductors or insulators, but not in _Mott–Hubbard_ or charge-transfer insulators since, as described above, _d–d_ transitions and charge transfer processes are highly localized.<sup>[70]</sup> Thus, instead of transitions between one valence and one conduction band, the absorption spectrum in _Mott– Hubbard_ or charge-transfer insulators is composed of a superposition of many different discrete transitions. The definition of an absorption edge, as is the case of “classical” band semiconductors, is not possible. Therefore, no value for the bandgap can be determined using the _Tauc plot method_ ; instead, each transition must be considered and analyzed individually. 

**2304523 (14 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 





**Figure 13.** Schematic illustration of the electronic structure of a) _Mott–Hubbard_ and b) charge-transfer insulators (Redrawn from ref. [70]). c) Simplified electron band diagram and valence band photoemission spectra of selected transition-metal oxides with a partially filled d-band and high occupancy (Adapted with permission.<sup>[72]</sup> Copyright 2012, Springer Nature Limited). 

**2304523 (15 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.afm-journal.de** 



**Figure 14.** a) Optical absorption spectrum of Co3O4 nanoparticles with a spinel oxide structure. The inset shows the possible charge transfer processes and _d–d_ transitions (Adapted with permission.<sup>[74]</sup> Copyright 2014, American Chemical Society). b) Influence of a change of the Co/Fe ratio on the optical absorption (left panel) and the crystal structure (middle and right panels) of CoxFe3−xO4 thin films with _x_ = 0.9 and 2.2 (Adapted with permission.<sup>[77]</sup> Copyright 2021, American Chemical Society). 

The study of optical transitions in insulators becomes even more complex when considering mixed systems containing more than just one metal cation. This is the case in CoxFe3−xO4 spinel oxides, which, in addition to Co cations, also have Fe<sup>2+</sup> and Fe<sup>3+</sup> cations on the tetrahedral and octahedral sites.<sup>[77]</sup> It follows that an even larger number of charge transfer or _d–d_ transitions is possible. Thus, there are usually hardly any maxima in the absorption spectrum, but instead a very broad increase of the absorption with photon energy over a few eV with several shoulders (Figure 14b, left panel).<sup>[77]</sup> Like Co3O4, mixed Co-Fe spinels are used in electro- and thermo-catalytic processes or in solar cells.<sup>[79]</sup> The special feature of CoxFe3−xO4 is that the electrical and optical material properties can be varied by changing the ratio between the Fe and Co cations (0 _< x <_ 3) and thus precisely adapted to a desired application.<sup>[80]</sup> One goal is, for example, to shift the bandgap of CoxFe3−xO4 over the visible spectral range by varying _x_ .<sup>[81]</sup> As already shown for Co3O4, the determination of a bandgap using the _Tauc plot method_ is not possible due to the localized character of the optical transitions. At the same time, this localized character also causes a very strong link between the crystal structure and the optical behavior.<sup>[77]</sup> An optical transition can only continue to take place if the partner ion required for a transfer process is still present. Localized optical transitions can thus become weaker (or stronger) when the crystal structure changes. 

This has strong impact on the interpretation of the optical absorption spectrum of _Mott–Hubbard_ and charge-transfer insulators like CoxFe3−xO4. While Co-rich thin films ( _x_ = 2.2) exhibit a strong absorption feature around 1.7 eV, there is a pronounced absorption resonance around 3.6 eV for Fe-rich ( _x_ = 0.9) samples (Figure 14b, left panel). As for Co3O4, it is suggested that the feature around 1.7 eV in Co-rich films is caused by both, a MMCT between Co<sup>3 +</sup> (t2g) and Co<sup>2 +</sup> (t2) and a _d–d_ crystal field transition of tetrahedrally coordinated Co<sup>2+</sup> .<sup>[77,78]</sup> Thus, prerequisites for this optical transition are, in particular, Co<sup>2+</sup> ions on tetrahedral sites. The feature around 3.6 eV in Fe-rich samples is assigned to a MMCT between Co<sup>2+</sup> and Fe<sup>3+</sup> , both on octahedral sites.<sup>[77]</sup> The change in the absorption spectrum can be explained by considering the occupation of the tetrahedral and octahedral sites. 

By Raman spectroscopy it was shown that in Co-rich CoxFe3−xO4 thin films ( _x_ = 2.2) the spinel structure is predominantly normal, with Co<sup>2+</sup> ions mostly occupying the tetrahedral sites and Co<sup>3+</sup> and Fe<sup>3+</sup> ions mostly on octahedral sites (Figure 14b, middle and right panel).<sup>[77]</sup> So the transition at 1.7 eV is dominant. When the Fe-content is increased ( _x_ = 0.9), the spinel phase changes to a mixed inverse one with more Co<sup>2+</sup> ions on octahedral and more Fe<sup>3+</sup> cations on tetrahedral sites. As a result, as the Fe content increases, Co<sup>2+</sup> ions are substituted with Fe<sup>3+</sup> ions at tetrahedral sites, the 1.7 eV feature vanishes and the resonance around 3.6 eV becomes stronger.<sup>[77]</sup> Thus, if the Co/Fe ratio in CoxFe3−xO4 is varied, the absorption spectrum changes because different optical transitions are dominant at high or low Co-content. This is an observation that applies to _Mott–Hubbard_ or charge transfer isolators in general. When metal cations are exchanged, no shift in interband transitions occurs but the strength of the respective localized transitions changes. 

The absorption spectra of _Mott–Hubbard_ and charge transfer isolators are dominated by localized _d–d_ transitions and charge transfers. This optical behavior prevents the use of the _Tauc plot method_ since that requires optical transitions between extended states in _Bloch bands_ . Instead, there is a strong link between the crystal structure and the optical transitions for these types of insulators. Changes in the crystal structure or the exchange of cations are therefore crucial for the optical absorption. 

## **9. Conclusion and Outlook** 

In this perspective, we offer a comprehensive review of the _Tauc plot method_ and its suitability for determining the bandgap of solids. The original _Tauc plot method_ was developed for _non-direct_ interband transitions in amorphous _bulk_ semiconductors and enables the _optical gap_ determination by UV–vis measurements and fitting the absorbance with a simple-power law ( ~~√~~ _𝛼_ ( _E_ ) _h𝜈_ ∝ _h𝜈_ − _E_ opt). Adapting the original _Tauc plot method_ by taking into account the purely band-to-band absorption, the bandgap of perfect crystalline _bulk_ solids can be derived using “( _ahv_ )<sup>n</sup> plots.” However, most materials have peculiarities in their electronic 

**2304523 (16 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



structure and various physical processes can occur that are not considered by the _Tauc plot_ (or ( _ahv_ )<sup>n</sup> _plot_ ) method. This strongly limits the application of this methodology. 

A prerequisite for the application of the _Tauc plot_ is that the absorption edge is formed by an interband transition between parabolic bands. Consequently, no materials can be studied that are quantized ( _2D_ , _1D_ , or _0D_ materials) or have strong band tails overlying the fundamental absorbance. Furthermore, we show that the _Tauc plot method_ can only be used if the absorption edge is clearly formed by a single interband transition. If direct and indirect band transitions overlap each other forming a common absorption edge, use is not permitted. This can be the case in mixed materials or semiconductor alloys (e.g., TiO2 or AlxGa1−xAs). Additionally, strong defect bands can form that superimpose the fundamental absorption edge (e.g., in Fe-doped TiO2). In general, it is of central importance to consider _electron–hole interactions_ and the formation of _excitons_ in (poly-) crystalline materials. Whenever the absorption edge is superimposed by an exciton absorption resonance, the use of the _Tauc plot_ is no longer possible. Strong doping can introduce so many charge carriers that _many-body effects_ like _bandgap renormalization_ occur and the exciton gets screened resulting in a shift of the absorption edge to lower energies. Simultaneously, as a result of this increase in the charge carrier density, the optical absorption edge can also be shifted to higher energies by the _Burstein–Moss_ effect. _Mott– Hubbard_ or _charge transfer insulators_ have the property that they cannot be described using the “classical” band model after _Bloch_ . Their optical transitions lowest in energy are no longer caused by band transitions between extended states but by localized _d–d_ transitions or charge transfer processes. Again, the bandgap cannot be derived by the _Tauc plot method_ (e.g., CoxFe3−xO4). 

So, if the _Tauc plot_ or “( _ahv_ )<sup>n</sup> plot” _method_ fails to derive the bandgap of solids, which alternative approaches exist? With the help of optical absorption spectroscopy, the electronic bandgap can be derived when crystalline bulk materials with a defined exciton signal are examined. If exciton resonances can be clearly separated (this is possible in some solids at room temperature, in others only at low temperatures), the electronic bandgap can be extracted by considering the exciton binding energy. In case of heavily doped crystalline solids, where the Fermi energy extends into the bands, complex calculations of _many-body_ effects at known carrier densities maybe used for getting the bandgap. 

In other (poly-) crystalline materials it is usually not appropriate to determine the electronic bandgap using optical spectroscopy. Instead, one may define an “ _optical gap_ ” by a welldefined procedure as often the onset of absorption is relevant for the intended application rather than the detailed nature of the underlying mechanism. We propose to provide the point of inflection together with values at which the absorption reaches 10% and 90%, respectively, for defining the “ _optical gap_ .” This allows the energetic position and the width of the absorption edge to be estimated. However, whichever definition is used, it is crucial that values of the “ _optical gap_ ” in different materials or in materials that are prepared with different methods are compared only if the “ _optical gap_ ” is defined in the same way. In case the absorption is formed by discrete optical transitions that results in several absorption peaks, an “ _optical gap_ ” should not be specified. Instead, each optical transition should be considered individually. 

Other non-optical methods, like photoelectron and inverse photoemission spectroscopy, as well as scanning tunneling microscopy, allow the band structure and the bandgap in solids to be determined or estimated. Note that the electronic bandgap as, e.g., measured by photoelectron spectroscopy is different to the “ _optical gap_ ” as derived from optical spectroscopy. However, the disadvantage of non-optical methods is that they are often more complex, e.g., due to the need for special environmental conditions, are surface-sensitive and cannot be implemented as quickly and easily as optical spectroscopy. 

## **Acknowledgements** 

This work was funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)—Project number 388390466-TRR 247— within the collaborative research center/transregio 247 “Heterogeneous Oxidation Catalysis in the Liquid Phase” (projects B3 and C1) and by the project BA 1422/24-1 “Interlinking catalysts, mechanisms and reactor concepts for the conversion of dinitrogen by electrocatalytic, photocatalytic and photo electrocatalytic methods” within the priority program SPP 2370. Open access funding enabled and organized by Projekt DEAL. 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Author Contributions** 

The concept and idea of this work were developed by J.K., LK., and G.B. Optical absorption measurements were performed by J.K. and L.K. J.S. contributed by her expertise in the field of photocatalysis to the discussion of the interaction of light with metal oxides. B.M. and M.B. contributed to the synthesis of AZO and ZnO particles and their characterization using XRD and SEM. The manuscript was written through contributions of all authors. All authors have given approval to the final version of the manuscript. 

## **Keywords** 

bandgap, metal oxide, semiconductor, Tauc plot, UV–vis spectroscopy 

Received: April 24, 2023 Revised: July 27, 2023 Published online: September 3, 2023 

- [1] M. Grundmann, _Semiconductor Physics. An Introduction Including Device and Nanophysics_ , Springer, Berlin, Germany **2005** . 

- [2] N. W. Ashcroft, N. D. Mermin, _Solid State Physics_ , Saunders College Publishing, New York, USA **1976** . 

- [3] J. Tauc, _Amorphous and Liquid Semiconductors_ , Springer International Publishing, London, UK **1974** . 

- [4] a) P. Apopei, C. Catrinescu, C. Teodosiu, S. Royer, _Appl. Catal., B_ **2014** , _160–161_ , 374; b) S. Lee, D. W. Shin, W. M. Kim, B. Cheong, T. S. Lee, K. S. Lee, S. Cho, _Thin Solid Films_ **2006** , _514_ , 296; c) I. Shaheen, K. S. Ahmad, C. Zequine, R. K. Gupta, A. G. Thomas, M. A. Malik, _RSC Adv._ **2021** , _11_ , 23374. 

- [5] M. T. Greiner, Z.-H. Lu, _NPG Asia Mater._ **2013** , _5_ , e55. 

- [6] a) Y. Dou, Y. Liang, H. Li, Y. Xue, H. Ye, Y. Han, _Chem. Commun._ **2022** , _58_ , 8548; b) A. M. El-Naggar, S. Y. El-Zaiat, S. M. Hassan, _Opt. Laser_ 

**2304523 (17 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

**www.afm-journal.de** 

**www.advancedsciencenews.com** 



_Technol._ **2009** , _41_ , 334; c) S. Dewan, M. Tomar, R. P. Tandon, V. Gupta, _Mater. Today Proc._ **2018** , _5_ , 15361; d) T. Maruyama, H. Miyake, _J. Vac. Sci. Technol., A_ **2006** , _24_ , 1096; e) R. Chen, W. Zhou, H. S Kwok, _Appl. Phys. Lett._ **2012** , _100_ , 22111; f) A. M. El-Naggar, _J. Appl. Phys._ **2011** , _109_ , 023508; g) A. M. El-Naggar, _J. Mater. Sci.: Mater. Electron._ **2012** , _23_ , 972; h) S. Özen, S. Pat, ¸S. Korkmaz, _J. Electron. Mater._ **2018** , _47_ , 3727. 

- [7] a) P. P. Sahay, R. K. Nath, S. Tewari, _Cryst. Res. Technol._ **2007** , _42_ , 275; b) R. Murugesan, S. Sivakumar, K. Karthik, P. Anandan, M. Haris, _Appl. Phys. A_ **2019** , _125_ , 281; c) D. Patidar, R. Sharma, N. Jain, T. P. Sharma, N. S. Saxena, _Bull. Mater. Sci._ **2006** , _29_ , 21; d) S. Kumar, S. Kumar, P. Sharma, V. Sharma, S. C. Katyal, _J. Appl. Phys._ **2012** , _112_ , 123512; e) V. Kumar, S. K. Sharma, T. Sharma, V. Singh, _Opt. Mater._ **1999** , _12_ , 115; f) W. Mahmood, J. Ali, I. Zahid, A. Thomas, A. ul Haq, _Optik_ **2018** , _158_ , 1558. 

- [8] a) G. Mannino, I. Deretzis, E. Smecca, A. La Magna, A. Alberti, D. Ceratti, D. Cahen, _J. Phys. Chem. Lett._ **2020** , _11_ , 2490; b) S. Chen, W. Liu, M. Xu, P. Shi, M. Zhu, _J. Mater. Chem. C_ **2023** , _11_ , 8431; c) J.-H. Cha, J. H. Han, W. Yin, C. Park, Y. Park, T. K. Ahn, J. H. Cho, D.-Y. Jung, _J. Phys. Chem. Lett._ **2017** , _8_ , 565; d) Y. Hua, F. Cui, P. Zhang, G. Zhang, Q. Zhang, X. Tao, _Z. Anorg. Allg. Chem._ **2022** , _648_ , e202200025; e) H. Zhang, X. Liu, J. Dong, H. Yu, C. Zhou, B. Zhang, Y. Xu, W. Jie, _Cryst. Growth Des._ **2017** , _17_ , 6426; f) X. Guo, H. Xie, R. Zhang, Z. Tang, K. Wang, C. Yang, _Cryst. Res. Technol._ **2023** , _58_ , 2300046; g) P. Zhang, G. Zhang, L. Liu, D. Ju, L. Zhang, K. Cheng, X. Tao, _J. Phys. Chem. Lett._ **2018** , _9_ , 5040. 

- [9] A. R. Zanatta, _Sci. Rep._ **2019** , _9_ , 11225. 

- [10] G. G. Macfarlane, T. P. McLean, J. E. Quarrington, V. Roberts, _Phys. Rev._ **1958** , _111_ , 1245. 

- [11] a) X. Chen, J. Huang, C. Chen, M. Chen, G. Hu, H. Wang, N. Dong, J. Wang, _Adv. Opt. Mater._ **2022** , _10_ , 2101963; b) L.-S. Lu, G.-H. Chen, H.-Y. Cheng, C.-P. Chuu, K.-C. Lu, C.-H. Chen, M.-Y. Lu, T.-H. Chuang, D.-H. Wei, W.-C. Chueh, W.-B. Jian, M.-Y. Li, Y.-M. Chang, L.-J. Li, W.-H. Chang, _ACS Nano_ **2020** , _14_ , 4963; c) A. D. Oyedele, S. Yang, L. Liang, A. A. Puretzky, K. Wang, J. Zhang, P. Yu, P. R. Pudasaini, A. W. Ghosh, Z. Liu, C. B. Jacobs, B. G. Sumpter, M. F. Chisholm, W. Zhou, P. D. Rack, D. B. Geohegan, K. Xiao, _J. Am. Chem. Soc._ **2017** , _139_ , 14090; d) M. Wei, J. Lian, Y. Zhang, C. Wang, Y. Wang, Z. Xu, _npj 2D Mater. Appl._ **2022** , _6_ , 1; e) L.-H. Zeng, Di Wu, S.-H. Lin, C. Xie, H.-Y. Yuan, W. Lu, S. P. Lau, Y. Chai, L.-B. Luo, Z.-J. Li, Y.-H. Tsang, _Adv. Funct. Mater._ **2019** , _29_ , 1806878. 

- [12] a) S. Paul, S. Ghosh, S. K. De, _Langmuir_ **2018** , _34_ , 4324; b) S. Agarwal, L. K. Jangir, K. S. Rathore, M. Kumar, K. Awasthi, _Appl. Phys. A_ **2019** , _125_ , 553; c) O. P. Egambaram, S. K. Pillai, M. Lategan, S. S. Ray, _J. Nanopart. Res._ **2019** , _21_ , 53; d) N. Kamarulzaman, M. F. Kasim, R. Rusdi, _Nanoscale Res. Lett._ **2015** , _10_ , 1034; e) K. W. Aga, M. T. Efa, T. T. Beyene, _ACS Omega_ **2022** , _7_ , 10796; f) S. Huber, C. C. Mardare, A. I. Mardare, C. Kleber, A. W. Hassel, _RSC Adv._ **2019** , _9_ , 35579. 

- [13] a) R. Zouzelka, J. Rathousky, _Appl. Catal., B_ **2017** , _217_ , 466; b) J. Y. Tai, K. H. Leong, P. Saravanan, A. A. Aziz, L. C. Sim, _J. Mater. Sci._ **2017** , _52_ , 11630; c) J. Melcher, S. Feroz, D. Bahnemann, _J. Mater. Sci._ **2017** , _52_ , 6341; d) P. Chawla, S. K. Sharma, A. P. Toor, _Environ. Dev. Sustain._ **2020** , _22_ , 231; e) M. Zouheir, O. Assila, K. Tanji, A. El Gaidoumi, J. Araña, J. M. Doña Rodríguez, J.-H. Smått, T.-P. Huynh, A. Kherbeche, _Nano Futures_ **2021** , _5_ , 025004. 

- [14] T. Lv, B. Xiao, S. Zhou, J. Zhao, T. Wu, J. Zhang, Y. Zhang, Q. Liu, _Chem. Commun._ **2021** , _57_ , 9704. 

- [15] R. V. Nair, V. S. Gummaluri, M. V. Matham, C. Vijayan, _J. Phys. D: Appl. Phys._ **2022** , _55_ , 313003. 

- [16] a) S. Agrawal, A. Parveen, A. Azam, _J. Lumin._ **2017** , _184_ , 250; b) A. A. Barzinjy, S. M. Hamad, S. Aydın, M. H. Ahmed, F. H. S. Hussain, _J. Mater. Sci.: Mater. Electron._ **2020** , _31_ , 11303; c) A. Diallo, K. Kaviyarasu, S. Ndiaye, B. M. Mothudi, A. Ishaq, V. Rajendran, M. Maaza, _Green Chem. Lett. Rev._ **2018** , _11_ , 166; d) M. M. Hussain, M. 

M. Rahman, A. M. Asiri, _J. Environ. Sci._ **2017** , _53_ , 27; e) R. Ramesh, V. Yamini, S. J. Sundaram, F. L. A. Khan, K. Kaviyarasu, _Mater. Today Proc._ **2021** , _36_ , 268; f) K. Varunkumar, R. Hussain, G. Hegde, A. S. Ethiraj, _Mater. Sci. Semicond. Process._ **2017** , _66_ , 149; g) H. Abbas, K. Nadeem, A. Hafeez, A. Hassan, N. Saeed, H. Krenn, _Ceram. Interfaces_ **2019** , _45_ , 17289. 

- [17] a) P. M. Anjana, M. R. Bindhu, M. Umadevi, R. B. Rakhi, _J. Mater. Sci.: Mater. Electron._ **2018** , _29_ , 6040; b) I. Khan, N. Zada, I. Khan, M. Sadiq, K. Saeed, _J. Environ. Health Sci. Eng._ **2020** , _18_ , 1473; c) Muzammil, A. T, D. Yuliantika, Y. A. Hariyanto, Sunaryono, A. H, S. Bahtiar, N. Mufti, N. Hidayat, _J. Phys.: Conf. Ser._ **2018** , _1093_ , 12020; d) M. M. Rahman, M. M. Hussain, A. M. Asiri, _PLoS One_ **2017** , _12_ , e0177817; e) T. Saragi, B. L. Depi, S. Butarbutar, B. Permana, Risdiana, _J. Phys.: Conf. Ser._ **2018** , _1013_ , 12190; f) V. M. Vinosel, S. Anand, M. A. Janifer, S. Pauline, S. Dhanavel, P. Praveena, A. Stephen, _J. Mater. Sci.: Mater. Electron._ **2019** , _30_ , 9663. 

- [18] a) M. Gilzad Kohan, R. Mazzaro, V. Morandi, S. You, I. Concina, A. Vomiero, _J. Mater. Chem. A_ **2019** , _7_ , 26302; b) S. Faisal, F. A. Jan, S. Saleem, R. Ullah, N. Wajidullah, S. Ullah, _Nanotechnol. Environ. Eng._ **2022** , _7_ , 675; c) R. S. Saravan, M. Muthukumaran, S. M. Mubashera, M. Abinaya, P. V. Prasath, R. Parthiban, F. Mohammad, W. C. Oh, S. Sagadevan, _Optik_ **2020** , _207_ , 164428; d) R. Drasovean, S. Condurache-Bota, J. Optoelectron, _Adv. Mater._ **2009** , _11_ , 2141; e) K. H. Mahmoud, _Polym. Compos._ **2016** , _37_ , 1881; f) S. Kandula, P. Jeevanandam, _RSC Adv._ **2015** , _5_ , 5295; g) R. Bhargava, S. Khan, N. Ahmad, M. M. N. Ansari, _AIP Conf. Proc._ **2018** , _1953_ , 30034. 

- [19] N. F. Mott, E. A. Davis, _Electronic Processes in Non-Crystalline Materials_ , Oxford University Press, Oxford, UK **1979** . 

- [20] B. D. Viezbicke, S. Patel, B. E. Davis, D. P. Birnie, _Phys. Status Solidi B_ **2015** , _252_ , 1700. 

- [21] P. Makuła, M. Pacia, W. Macyk, _J. Phys. Chem. Lett._ **2018** , _9_ , 6814. 

- [22] E. S. Welter, S. Garg, R. Gläser, M. Goepel, _ChemPhotoChem_ **2023** , _7_ , 202300001. 

- [23] A. Dolgonos, T. O. Mason, K. R. Poeppelmeier, _J. Solid State Chem._ **2016** , _240_ , 43. 

- [24] D. L. Wood, J. Tauc, _Phys. Rev. B_ **1972** , _5_ , 3144. 

- [25] K. Morigaki, S. Kugler, K. Shimakawa, _Amorphous Semiconductors. Structural, Optical, and Electronic Properties_ , John Wiley & Sons Ltd, Chichester West Sussex, UK **2017** . 

- [26] M. H. Cohen, H. Fritzsche, S. R. Ovshinsky, _Phys. Rev. Lett._ **1969** , _22_ , 1065. 

- [27] W. B. Jackson, S. M. Kelso, C. C. Tsai, J. W. Allen, S.-J. Oh, _Phys. Rev. B_ **1985** , _31_ , 5187. 

- [28] R. Sauer, _Halbleiterphysik. Lehrbuch für Physiker und Ingenieure_ , Oldenbourg Wissenschaftsverlag, Munich, Germany **2009** . 

- [29] Ed.: K. D. Sattler, _Handbook of Nanophysics. Functional Nanomaterials_ , CRC Press, Boca Raton, US **2010** . 

- [30] B. N. Brockhouse, _Phys. Rev. Lett._ **1959** , _2_ , 256. 

- [31] M. Fox, _Optical Properties of Solids_ , Oxford University Press, New York, USA **2010** . 

- [32] A. G. Cullis, L. T. Canham, P. D. J. Calcott, _J. Appl. Phys._ **1997** , _82_ , 909. 

- [33] I. Vurgaftman, J. R. Meyer, L. R. Ram-Mohan, _J. Appl. Phys._ **2001** , _89_ , 5815. 

- [34] a) J. D. Dow, D. Redfield, _Phys. Rev. B_ **1972** , _5_ , 594; b) F. Urbach, _Phys. Rev._ **1953** , _91_ , 1324; c) S. M. Wasim, G. Marı´n, C. Rincón, G. Sánchez Pérez, _J. Appl. Phys._ **1998** , _84_ , 5823. 

- [35] G. D. Cody, T. Tiedje, B. Abeles, B. Brooks, Y. Goldstein, _Phys. Rev. Lett._ **1981** , _47_ , 1480. 

- [36] J. I. Pankove, _Optical Processes in Semiconductors_ , Dover Publications, New York, US **2012** . 

- [37] B. Gürbulak, S. Duman, A. Ates, _Czech. J. Phys._ **2005** , _55_ , 93. 

- [38] H. Yaghoubi, Z. Li, Y. Chen, H. T. Ngo, V. R. Bhethanabotla, B. Joseph, S. Ma, R. Schlaf, A. Takshi, _ACS Catal._ **2015** , _5_ , 327. 

**2304523 (18 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

- [39] B. Abay, H. S. Güder, H. Efeo˘glu, Y. K. Yo˘gurtçu, _Phys. Status Solidi B_ **2001** , _227_ , 469. 

- [40] J. B. Coulter, D. P. Birnie, _Phys. Status Solidi B_ **2018** , _255_ , 1700393. 

- [41] a) D. S. Chemla, D. A. B. Miller, _J. Opt. Soc. Am. B_ **1985** , _2_ , 1155; b) D. D. Sell, H. C. Casey, _J. Appl. Phys._ **1974** , _45_ , 800. 

- [42] R. T. Senger, K. K. Bajaj, _Phys. Rev. B_ **2003** , _68_ , 45313. 

- [43] P. Y. Yu, M. Cardona, _Fundamentals of Semiconductors. Physics and Materials Properties_ , Springer, Berlin, Heidelberg, Germany **2010** . 

- [44] V. Babentsov, F. Sizov, _Opto-Electron. Rev._ **2008** , _16_ , 208. 

- [45] B. Ohtani, O. O. Prieto-Mahaney, D. Li, R. Abe, _J. Photochem. Photobiol._ **2010** , _216_ , 179. 

- [46] a) K. Nakata, A. Fujishima, _J. Photochem. Photobiol._ **2012** , _13_ , 169; b) A. Fujishima, T. N. Rao, D. Tryk, _J. Photochem. Photobiol., C_ **2000** , _1_ , 1; c) P. Roy, D. Kim, K. Lee, E. Spiecker, P. Schmuki, _Nanoscale_ **2010** , _2_ , 45; d) B. O’Regan, M. Grätzel, _Nature_ **1991** , _353_ , 737. 

- [47] a) D. Chen, Y. Cheng, N. Zhou, P. Chen, Y. Wang, K. Li, S. Huo, P. Cheng, P. Peng, R. Zhang, L. Wang, H. Liu, Y. Liu, R. Ruan, _J. Cleaner Prod._ **2020** , _268_ , 121725; b) D. C. Hurum, A. G. Agrios, K. A. Gray, T. Rajh, M. C. Thurnauer, _J. Phys. Chem. B_ **2003** , _107_ , 4545. 

- [48] a) T. Ohno, K. Sarukawa, K. Tokieda, M. Matsumura, _J. Catal._ **2001** , _203_ , 82; b) C. Wu, Y. Yue, X. Deng, W. Hua, Z. Gao, _Catal. Today_ **2004** , _93–95_ , 863. 

- [49] a) E. Galata, E. A. Georgakopoulou, M.-E. Kassalia, N. PapadopoulouFermeli, E. A. Pavlatou, _Materials_ **2019** , _12_ , 2589; b) R. López, R. Gómez, _J. Sol-Gel Sci. Technol._ **2012** , _61_ , 1. 

- [50] a) B. Su, V. Körstgens, Y. Yao, D. Magerl, L. Song, E. Metwalli, S. Bernstorff, P. Müller-Buschbaum, _J. Sol-Gel Sci. Technol._ **2017** , _81_ , 346; b) Y. Mi, Y. Weng, _Sci. Rep._ **2015** , _5_ , 11482. 

- [51] M. Landmann, E. Rauls, W. G. Schmidt, _J. Condens. Matter Phys._ **2012** , _24_ , 195503. 

- [52] D. Reyes-Coronado, G. Rodríguez-Gattorno, M. E. EspinosaPesqueira, C. Cab, R. de Coss, G. Oskam, _Nanotechnology_ **2008** , _19_ , 145605. 

- [53] C. Di Valentin, G. Pacchioni, A. Selloni, _J. Phys. Chem. C_ **2009** , _113_ , 20543. 

- [54] M. Jaros, _Rep. Prog. Phys._ **1985** , _48_ , 1091. 

- [55] B. Monemar, K. K. Shih, G. D. Pettit, _J. Appl. Phys._ **1976** , _47_ , 2604. 

- [56] a) A. Angeline Dorothy, P. Panigrahi, _IOP Conf. Ser.: Mater. Sci. Eng._ **2022** , _1219_ , 12041; b) M. u. Rahman, M. Saqib, K. Althubeiti, K. M. Abualnaja, S. u. Zaman, N. Rahman, R. Khan, _J. Mater. Sci.: Mater. Electron._ **2021** , _32_ , 28718. 

- [57] B. Bharti, S. Kumar, H.-N. Lee, R. Kumar, _Sci. Rep._ **2016** , _6_ , 32355. 

- [58] X. H. Wang, J.-G. Li, H. Kamiyama, M. Katada, N. Ohashi, Y. Moriyoshi, T. Ishigaki, _J. Am. Chem. Soc._ **2005** , _127_ , 10982. 

- [59] J. F. Muth, J. H. Lee, I. K. Shmagin, R. M. Kolbas, H. C. Casey, B. P. Keller, U. K. Mishra, S. P. DenBaars, _Appl. Phys. Lett._ **1997** , _71_ , 2572. 

### **www.afm-journal.de** 

- [60] Ed.: D. J. Lockwood, _Physics of Semiconductors. 22nd International Conference_ , World Scientific Publishing, Singapore **1995** . 

- [61] W. Shan, B. D. Little, A. J. Fischer, J. J. Song, B. Goldenberg, W. G. Perry, M. D. Bremser, R. F. Davis, _Phys. Rev. B_ **1996** , _54_ , 16369. 

- [62] J. Voigt, F. Spiegelberg, M. Senoner, _Phys. Status Solidi B_ **1979** , _91_ , 189. 

- [63] D. C. Look, _Mater. Sci. Eng., B_ **2001** , _80_ , 383. 

- [64] D. P. Norton, Y. W. Heo, M. P. Ivill, K. Ip, S. J. Pearton, M. F. Chisholm, T. Steiner, _Mater. Today_ **2004** , _7_ , 34. 

- [65] H. Morkoc, Ü. Özgür, _Zinc Oxide. Fundamentals, Materials and Device Technology_ , Wiley-VCH, Weinheim, Germany **2009** . 

- [66] J. F. Muth, R. M. Kolbas, A. K. Sharma, S. Oktyabrsky, J. Narayan, _J. Appl. Phys._ **1999** , _85_ , 7884. 

- [67] K. Y. Cheng, _III–V Compound Semiconductors and Devices_ , Springer International Publishing, Cham, Switzerland **2020** . 

- [68] P. A. Wolff, _Phys. Rev._ **1962** , _126_ , 405. 

- [69] J. G. Lu, S. Fujita, T. Kawaharamura, H. Nishinaka, Y. Kamada, T. Ohshima, Z. Z. Ye, Y. J. Zeng, Y. Z. Zhang, L. P. Zhu, H. p. He, B. H. Zhao, _J. Appl. Phys._ **2007** , _101_ , 83705. 

- [70] M. Imada, A. Fujimori, Y. Tokura, _Rev. Mod. Phys._ **1998** , _70_ , 1039. 

- [71] R. Tiwari, P. Majumdar, _Curr. Sci._ **2012** , _103_ , 518. 

- [72] M. T. Greiner, M. G. Helander, W.-M. Tang, Z.-B. Wang, J. Qiu, Z.-H. Lu, _Nat. Mater._ **2011** , _11_ , 76. 

- [73] a) E. Budiyanto, H. Tüysüz, _Eur. J. Inorg. Chem._ **2022** , 202200065; b) T. Falk, S. Anke, H. Hajiyani, S. Saddeler, S. Schulz, R. Pentcheva, B. Peng, M. Muhler, _Catal. Sci. Technol._ **2021** , _11_ , 7552; c) J. Klein, L. Kampermann, J. Korte, M. Dreyer, E. Budiyanto, H. Tüysüz, K. F. Ortega, M. Behrens, G. Bacher, _J. Phys. Chem. Lett._ **2022** , _13_ , 3217. 

- [74] C.-M. Jiang, L. R. Baker, J. M. Lucas, J. Vura-Weis, A. P. Alivisatos, S. R. Leone, _J. Phys. Chem. C_ **2014** , _118_ , 22774. 

- [75] R.-P. Wang, M.-J. Huang, A. Hariki, J. Okamoto, H.-Y. Huang, A. Singh, D.-J. Huang, P. Nagel, S. Schuppler, T. Haarman, B. Liu, F. M. F. de Groot, _J. Phys. Chem. C_ **2022** , _126_ , 8752. 

- [76] C. S. Pawar, A. T. Yadav, S. P. Salunkhe, _Macromol. Symp._ **2021** , _400_ , 2100125. 

- [77] L. Kampermann, J. Klein, J. Korte, O. Kowollik, O. Pfingsten, T. Smola, S. Saddeler, T. H. Piotrowiak, S. Salamon, J. Landers, H. Wende, A. Ludwig, S. Schulz, G. Bacher, _J. Phys. Chem. C_ **2021** , _125_ , 14356. 

- [78] K. J. Kim, Y. R. Park, _Solid State Commun._ **2003** , _127_ , 25. 

- [79] a) M. Li, Y. Xiong, X. Liu, X. Bo, Y. Zhang, C. Han, L. Guo, _Nanoscale_ **2015** , _7_ , 8920; b) Z. Yan, D. A. Keller, K. J. Rietwyk, H.-N. Barad, K. Majhi, A. Ginsburg, A. Y. Anderson, A. Zaban, _Energy Technol._ **2016** , _4_ , 809. 

- [80] T. H. Piotrowiak, X. Wang, L. Banko, S. Kumari, S. Sarker, A. Mehta, A. Ludwig, _ACS Comb. Sci._ **2020** , _22_ , 804. 

- [81] S. O. Estrada, C. A. Huerta-Aguilar, T. Pandiyan, M. Corea, I. A. ReyesDomínguez, G. Tavizon, _J. Alloys Compd._ **2017** , _695_ , 2706. 

**2304523 (19 of 19)** 

_Adv. Funct. Mater._ **2023** , _33_ , 2304523 

© 2023 The Authors. Advanced Functional Materials published by Wiley-VCH GmbH 

