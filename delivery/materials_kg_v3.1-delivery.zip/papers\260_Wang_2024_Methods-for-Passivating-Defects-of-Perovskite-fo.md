# Methods for Passivating Defects of Perovskite for Inverted Perovskite Solar Cells and Modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Advanced Energy Materials |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 204 |
| 作者 | Jia-Rong Wang, Le-Yu Bi, Qiang Fu, A. Jen |
| DOI | 10.1002/aenm.202401414 |
| 源文件 | 047_Wang_2024_Methods-for-Passivating-Defects-of-Perovskite-fo.pdf |

---
**REVIEW** 

**www.advenergymat.de** 



# **Methods for Passivating Defects of Perovskite for Inverted Perovskite Solar Cells and Modules** 

_Jiarong Wang, Leyu Bi, Qiang Fu,* and Alex K.-Y. Jen*_ 

interfaces.<sup>[3,4]</sup> These defects disrupt the band alignment of the absorber interfacing with the charge transport layer.<sup>[5,6]</sup> In contrast, the movement of ion defects can induce hysteresis during device operation and accelerate material degradation.<sup>[7,8]</sup> Consequently, mitigating or passivating these defects is paramount in realizing the high efficiency and stability of PSCs. 

**Inverted perovskite solar cells (PSCs) have attracted considerable attention due to their distinct advantages, including minimal hysteresis, cost-effectiveness, and suitability for tandem applications. Nevertheless, the solution processing and the low formation energy of perovskites inevitably lead to numerous defects formed at both the bulk and interfaces of the perovskite layer. These defects can act as non-radiative recombination centers, significantly impeding carrier transport and posing a substantial obstacle to stability and further enhancing power conversion efficiency (PCE). This review delves into a detailed discussion of the nature and origin of defects and the characterization techniques employed for defect identification. Furthermore, it systematically summarizes methods for defect detection and approaches for passivating interface and bulk defects within the perovskite film in inverted PSCs. Finally, this review offers a perspective on employing upscaling defect passivation engineering for perovskite modules. It is hoped this review provides insights into defect passivation in inverted PSCs and solar modules.** 

In recent times, defect passivation engineering has gained widespread adoption as a means to diminish trap states and bulk crystal defects.<sup>[9,10]</sup> It is pertinent to note that perovskite solar cells can be categorized into normal ( _n-ip_ ) and inverted _(p-i-n_ ) structures based on charge transfer direction. The former, originating from dye-sensitized solar cells (DSSCs), underwent extensive examination in its nascent stages.<sup>[11]</sup> Consequently, the efficiency of inverted PSCs lagged behind that of normal PSCs for an extended period.<sup>[12,13]</sup> However, with advancements in perovskite film preparation, the introduction of efficient charge transport materials, and the implementation of advanced optimization strategies, the efficiency of inverted PSCs has gradually closed the gap with normal PSCs, achieving a notable efficiency level of 26.1%.<sup>[14]</sup> This trend underscores the significant potential of inverted device structures. Moreover, inverted PSCs are preferred for tandem applications due to their superior compatibility with diverse high-performance bottom solar cells in terms of device structure.<sup>[15,16]</sup> This compatibility facilitates optimal light management, leading to enhanced efficiency levels. Consequently, the development of high-performance inverted devices holds promise as a viable pathway toward the commercialization of PSCs. 

## **1. Introduction** 

The solution processability inherent in perovskite solar cells (PSCs) streamlines the manufacturing process, rendering it more cost-effective and straightforward.<sup>[1,2]</sup> However, the low formation energy associated with perovskite materials gives rise to many defects within grains, grain boundaries (GBs), and 

J. Wang, L. Bi, Q. Fu, A. K.-Y. Jen Department of Materials Science and Engineering City University of Hong Kong Kowloon 999077, Hong Kong E-mail: qfu222@cityu.edu.hk; alexjen@cityu.edu.hk J.Wang, L.Bi, Q.Fu,A.K.-Y.Jen Department of Chemistry City University of Hong Kong Kowloon 999077,Hong Kong J.Wang, L.Bi, Q.Fu,A.K.-Y.Jen Hong Kong InstituteforClean Energy City University of Hong Kong Kowloon 999077,Hong Kong 

Due to the different device structures between inverted and normal PSCs, many passivation strategies are not universal. In inverted PSCs, C60 and PCBM are currently the most commonly used electron transport layer (ETL). With the deepening of research, researchers have found that high surface defect density and perovskite/ETL interface energy level mismatch are responsible for the loss of open-circuit voltage ( _V_ OC).<sup>[14]</sup> Passivating perovskite surface defects and improving interface energy level alignment through interface engineering have significantly reduced _V_ OC loss.<sup>[17]</sup> Based on the above problems, we should optimize the dipole of the modification materials, enhance the n-type characteristics of the perovskite surface, build the n-N interface, improve the perovskite/ETL interface energy level mismatch, 

The ORCID identification number(s) for the author(s) of this article can be found under https://doi.org/10.1002/aenm.202401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH. This is an open access article under the terms of the Creative Commons Attribution-NonCommercial-NoDerivs License, which permits use and distribution in any medium, provided the original work is properly cited, the use is non-commercial and no modifications or adaptations are made. 

### **DOI: 10.1002/aenm.202401414** 

**2401414 (1 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 



### **www.advenergymat.de** 



**Figure 1.** a) Various types of perovskite defects. b) Defect passivation for inverted perovskite solar cells. 

facilitate the extraction and transport of electrons, and introduce heteroatoms to enhance passivation ability. 

This review article will examine the nature and origins of defects in halide perovskite films. Subsequently, it will outline methodologies for detecting defects in perovskites. Additionally, it will detail defect passivation strategies targeting the buried interface, top surface, and perovskite bulk in inverted devices. Ultimately, the article will proffer insights into the progression of upscaling defect passivation engineering for inverted perovskite modules. 

## **2. Defects in Perovskite Film** 

### **2.1. Nature and Origin of Defects in Perovskite Films** 

intrinsic and extrinsic.<sup>[20</sup><sup>**]**</sup> Intrinsic defects, also named native point defects, involve vacancy defects (VA, VB, VX)-an ion is missing from a lattice site; interstitial defects (Ai, Bi, Xi)-an ion occupies an interstitial site; and substitutional defects (AB, AX, BA, BX, XA, XB)-an ion is replaced by another ion at a lattice site.<sup>[21]</sup> Combining point defects, charge-neutral defect pairs such as Frenkel defects (a vacancy and an interstitial pair) and Schottky defects (two vacancies of opposite charges) can be generated.<sup>[22]</sup> Extrinsic point defects are caused by the dangling bonds on the perovskite interfaces or the surrounding environment. They are typically classified as interface and GB defects. The passivation methods and key points for defects at different positions in inverted PSCs are summarized in Figure 1b, which will be discussed in detail later. 

### _2.1.1. Types of Perovskite Defects_ 

### _2.1.2. Origin of Defects_ 

Perovskites exhibit a periodic crystal lattice structure ABX3. However, due to their ionic character and generally low defect formation energies, halide perovskites exhibit various defects accommodated in the interfaces and GBs of the polycrystalline films.<sup>[18]</sup> Besides, ion migration within the perovskite film can lead to the formation of non-radiative recombination centers.<sup>**[**19]</sup> 

The primary defects in perovskite film are illustrated in **Figure 1** a. There are two main categories of perovskite defects: 

- 1) Processing process: The significant advantage of perovskites is their solution-processability due to their low formation energy. However, this low formation energy also leads to the formation of many defects at the GBs between the crystals, and the defect density of these films is significantly higher than that of single-crystal perovskite films.<sup>[23]</sup> Besides, prolonged or high-temperature thermal annealing during processing can cause the evaporation of organic cations and halides, 

**2401414 (2 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advancedsciencenews.com** 

**www.advenergymat.de** 



resulting in undercoordinated Pb<sup>2+</sup> ions on the surface or the formation of PbI2.<sup>[24]</sup> 

- 2) Ion migration: Ion migration can occur under certain conditions, such as heat, light, and electric fields.<sup>[25]</sup> During thermal annealing, ion migration can induce vacancy, interstitial, and substitutional defects.<sup>[25]</sup> Under an electric field, the charged point defects could migrate and accumulate at interfaces, resulting in unintentional doping effects.<sup>[25]</sup> The movement or redistribution of these defects can result in local band bending, _J_ - _V_ hysteresis, phase segregation, and degradation of perovskites or metal electrodes, significantly deteriorating the device performance.<sup>[26]</sup> 

- 3) Residual strain: Perovskite is mechanically soft and highly susceptible to strain. Residual strain refers to the internal stress in the materials after processing.<sup>[27]</sup> It can be divided into two types. One is tensile strain, which reduces the perovskite defect formation energy and the activation energy of ion migration. In other words, applying tensile strain to perovskite makes it more prone to defect generation, thus lowering device efficiency. The other one is compressive strain, which enhances the perovskite defect formation energy and the activation energy of ion migration. This suggests that compressive strain can be used to physically control the defects.<sup>[28]</sup> 

### **2.2. Characterization Techniques for Identifying Defects: Principle, Advantages and Limitations** 

Defects in the perfect crystal structure will break the periodic energy bands, producing a density of states (DOS) of defects in a Brillouin zone. The electrons near these defect DOS will respond to light, heat, and electric field. Therefore, the methods for studying defects involve directly observing defects within the physical structure and stimulating the defects using light, heat, and electric fields. 

Generally, defects are primarily observed through electron diffraction. In this review, indirect methods were categorized based on the type of stimulus and detected signals, as illustrated in **Figure 2** . Various characterizations can be obtained by combining different types of excitation and detection. From a sample perspective, it can be classified into film and device levels. At the film level, the main stimulation methods include photon excitation, leading to photoluminescence (PL) and time-resolved photoluminescence (TRPL) through the detection of emitted light, photothermal deflection spectroscopy (PDS) through the detection of heat released from non-radiative recombination and X-ray photoelectron spectroscopy (XPS) through the detection of the electron velocity. At the device level, electrodes are incorporated on both film surfaces, facilitating the application and detection of electric stimuli and signals. This setup allows us to measure sub-bandgap external quantum efficiency (s-EQE) by detecting the photogenerated carriers. Additionally, by altering the device temperature under alternating current and measuring capacity, we can conduct thermal admittance spectroscopy (TAS). Combining the alternating current (AC) and direct current (DC) bias, drive-level capacitance profiling (DLCP) can monitor the defect spatial distribution. Furthermore, by implementing a specific device structure with a slight band mismatch between the per- 

ovskite film and electrodes, we can observe space charge limited current (SCLC), as outlined in the schematic. 

### _2.2.1. Direct Observation of Perovskite Defects by Electron Microscopy_ 

Scanning electron microscopy (SEM) can observe the surface morphology of perovskite through the reflection and scattering of electrons, thereby observing nanometer-scale 3D defects on the surface. Therefore, SEM is often used to observe pin holes, cracks on the surface of perovskite, poor contacts on the back of the film, etc. However, it is powerless for smaller defects like 2D, 1D, and 0D defects.<sup>[29]</sup> 

To observe smaller-scale defects, high-resolution transmission electron microscopy (HR-TEM) is used to study perovskite defects. Neat, thin perovskite films ≈30 nm were grown by thermal evaporation. Under HR-TEM, a low dose of an electron beam (with ≈200 e Å<sup>−2</sup> ) was used to get atomic-resolution STEM images of FAPbI3. As shown in **Figure 3** a, grain boundary and 1D defects are captured in the HRTEM pictures.<sup>[30]</sup> However, this method was relatively difficult for solution-processed perovskite film. The main obstacle is making thin perovskite film samples. 

### _2.2.2. Photon-Photon: Photoluminescence (PL), Time-Resolved Photoluminescence (TRPL), and PL Imaging_ 

Steady PL uses monochromatic light of a fixed wavelength to excite electrons in the sample from VBM to CBM and detect the light emitted when the electrons transition back to VBM. The recombination can be separated into radiative recombination and non-radiative. Radiative recombination releasing photons could be detected by the PL, while in non-radiative recombination, charge carriers recombine, releasing phonons instead of photons, which cannot be detected by steady PL. Phonon detection will be discussed in the next section about PDS. Deep-level traps can serve as non-radiative recombination centers, impacting the luminescence properties of thin films. By studying the PL of the thin film, it is possible to investigate trap properties.<sup>[35]</sup> The TRPL measures the decay of the PL signal, which could separate the non-radiative and radiative recombination by fitting the decay spectrum to a biexponential equation: 



<!-- Start of picture text -->
Y =  A 1 exp ( − t ∕ 𝜏 1) +  A 2 exp  (− t ∕ 𝜏 2) (1)<br><!-- End of picture text -->

When applied to perovskite materials, a bi-exponential ( _n_ = 2) fit is commonly performed, with the two components typically attributed to trap-mediated recombination (shorter lifetime _𝜏_ 1) and radiative recombination (longer lifetime _𝜏_ 2).<sup>[36]</sup> Yang et al. introduced additional I<sup>−</sup> into the perovskite precursor to decrease deep-level defect concentration via an intramolecular exchanging process.<sup>[31]</sup> As shown in Figure 3b, the target layer exhibited an enhanced PL intensity compared to the control layer, indicating a decrease in the number of deep-level traps within the bulk perovskite layers. The longer lifetime of the PL transition in the target layer, as revealed by PL decay measurements, can be attributed to the reduced defect concentration and increased crystallinity. 

**2401414 (3 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 2.** Schematic diagram of indirect defect characterization methods. Combinations of excitations and detections corresponding to different characterization methods. 

Besides PL and TRPL, PL imaging was applied to observe the ion migration on a micrometer scale. As shown in Figure 3c, the ion migration results in the PL quenched region, causing the advancement of a dark edge in the perovskite observed under PL imaging microscopy. The process can then be slowly restored by reverse biasing the perovskite film or simply relaxing the system under dark conditions.<sup>[32]</sup> 

### _2.2.3. Photon-Phonon: Photothermal Deflection Spectroscopy (PDS)_ 

PL measures the photon released from the radiative recombination. In contrast, the PDS test measures the phonon released from the non-radiative recombination. During the PDS test, a beam of monochromatic light with tunable intensity is absorbed by the sample, causing electrons to transition into excited states. The system then relaxes through non-radiative tran- 

sitions, leading to time-dependent temperature changes in the studied material and the surrounding liquid. This change is also accompanied by changes in the index of refraction (IOR) of the material and surrounding liquid. In practice, we measure the change in IOR by observing the deflection of a laser beam using a position-sensitive 4-quadrant detector. The deflection amplitude is directly proportional to the optical absorption of the sample. 

Wolf et al. applied the PDS to the perovskite film to see a high absorption coefficient with a particularly sharp onset (Figure 3d).<sup>[33]</sup> They also suggested that the sub-bandgap absorption sensitivity of the PDS measurements of the as-prepared perovskite layer is fully limited by defects present in the glass substrate. 

Recently, Vlk et al. presented this measurement on halide perovskite single crystals.<sup>[37]</sup> By analyzing the frequency dependence of the PDS spectrum and the phase difference of the signals, deep 

**2401414 (4 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 3.** a) Atomic-resolution STEM images of FAPbI3, grain boundaries, intrinsic stacking fault (orange rectangle, left), and climb-dissociated dislocation (green rectangle, right). Scale bars, 5 nm. Reproduced with permission.<sup>[30]</sup> Copyright 2020, American Association for the Advancement of Science. b) Steady PL peak of control and after passivation (target) and TRPL spectra of control and target. Reproduced with permission.<sup>[31]</sup> Copyright 2017, American Association for the Advancement of Science. c) PL imaging showing the ion migration within 32 s. Reproduced with permission.<sup>[32]</sup> Copyright 2018, Springer Nature. d) PDS, FTPS, of CH3NH3PbI3 perovskite thin films as well as the PDS spectra of the glass substrate. Reproduced with permission.<sup>[33]</sup> Copyright 2014, American Chemical Society. e,f) XPS spectra of Pb 4f in the control and PDADI passivated film. Reproduced with permission.<sup>[34]</sup> Copyright 2023, Wiley. 

defects located on the surface and within the bulk of the sample can be effectively explicitly distinguished. 

### _2.2.4. Photon-Electron: X-Ray Photoelectron Spectroscopy (XPS)_ 

XPS uses a beam of X-rays to irradiate the top 1–10 nm of the material and then record the kinetic energy of emitted electrons. This characterization method reveals the changes in the binding energy of different elements before and after passivation to study the binding between passivation materials and surface defects of perovskite. It is gaining popularity in characterizing the role of passivation strategies.<sup>[38]</sup> Charging effect and calibration are needed to get the correct XPS data. Good grounding, space charge compensation, and peak position correction using adventitious C 1s or noble metals all contribute to accurate data acquisition. 

Zhong et al. compared the difference in the XPS spectrum of perovskite film before and after the passivation of 1,3diaminopropane dihydroiodide (PDADI). They found that two weak metallic Pb peaks (Pb<sup>0</sup> ) at 136.8 and 141.9 eV are observed (Figure 3e), suggesting the presence of uncoordinated Pb atoms, which are defects commonly observed in perovskite film. This could be due to the generation of iodide vacancy, accompanied by undercoordinated Pb<sup>2+</sup> , which will be further reduced to Pb<sup>0</sup> . For the perovskite film subjected to PDADI modification, the ratio of metallic Pb peaks decreased from 3.24% to 1.95% (Figure 3f). The fit of Pb 4f peaks of the PDADI-treated film shows that three pairs of peaks exist at ≈138.5/143.3, 137.6/142.4, and 136.8/141.9 eV. The appearance of the new energy peaks (137.6/142.4 eV) suggests the interaction between some Pb<sup>2+</sup> and other components on the surface, which is most likely 1,3diaminopropane (PDA).<sup>[34]</sup> 

**2401414 (5 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

**www.advenergymat.de** 



**Figure 4.** a) Absorption spectra at different temperatures with fitted Urbach region (straight lines). Reproduced with permission.<sup>[39]</sup> Copyright 1981, American Physical Society. b) Illustration of Urbach tail in an absorption model.<sup>[40]</sup> Copyright 2011, European Geosciences Union. c) Δs-EQE spectra (open circle) and Gaussian fitting results (lines) of Ag-contact and ITO-contact PSCs upon light soaking. Reproduced with permission.<sup>[41]</sup> Copyright 2020, Wiley. d) Band bending under alternating current in the TAS testing, _E𝜔(T,𝜔)_ move under different temperatures. Reproduced with permission.<sup>[42]</sup> Copyright 2018, American Chemical Society. e) Defect distribution spectra from TAS testing. Reproduced with permission.<sup>[43]</sup> Copyright 2019 Springer Nature. f,g) trap density distribution with the profiling distance by DLCP measurements of perovskite single crystal and thin film. Reproduced with permission.<sup>[44]</sup> Copyright 2020, American Association for the Advancement of Science. h) Schematic device structure of electron-only and hole-only SCLC tests. Reproduced with permission.<sup>[45]</sup> Copyright 2020, Springer Nature. 

### _2.2.5. Photon-Electron: Sub-Bandgap External Quantum Efficiency (s-EQE)_ 

S-EQE detects the photogenerated charge carrier to reflect the defect information. Band-to-band transition is the only transition in a defect-free, direct bandgap semiconductor. In this case, the relationship between the absorption coefficient and photon energy satisfies the bandgap model: 



<!-- Start of picture text -->
1<br>[ 𝛼 ( E, T )  E ] 2 = C [ E  − Eg  ( T ) ] (2)<br><!-- End of picture text -->

In this model, the absorption coefficient increases with photon energy. This is because, in 3D semiconductors, the DOS increases with distance from the bandgap, which causes the absorption coefficient to increase with photon energy, which exhibits approximately a quadratic function. However, due to defects and thermal effects of semiconductor materials, the actual absorption coefficient near the band edge is higher than the value of 

the bandgap model. The absorption coefficient is proportional to the index of incident photon energy ( **Figure 4** a).<sup>[39]</sup> In response to this situation, Franz Urbach gave the function between absorption coefficient and energy: 



<!-- Start of picture text -->
𝛼 ( E ) =  𝛼 0 exp (3)<br>( E  − E 0 E 1 )<br><!-- End of picture text -->

where _E_ is the photon energy, _𝛼_ 0 is the absorption coefficient corresponding to the intersection point obtained by epitaxy of the exponential segment at different temperatures, E1 is the energy corresponding to the intersection point after epitaxial extension, and E0 is defined as Urbach energy, which refers to the difference in energy between the beginning and the end of the exponential segment (Figure 4a). This exponential segment is called the Urbach tail, which begins at energy levels higher than the bandgap and extends to energy levels lower than the bandgap (Figure 4b).<sup>[40]</sup> The actual bandgap typically 

**2401414 (6 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

lies within the middle of the Urbach tail. While there are some unresolved details in the theory, it is widely accepted, especially for crystalline semiconductors, that the width of the exponential tail directly reflects temperature-induced disorder and represents the thermal occupancy of phonon states within the crystal.<sup>[40]</sup> 

In perovskite materials, the presence of defect states allows for additional photocurrent to be measured even at photon energies lower than those within the Urbach tail.<sup>[46]</sup> Assuming that the defect states have a Gaussian distributed DOS and considering only transitions between the band and the defect or vice versa, their contribution to the external quantum efficiency (EQE) follows a specific equation. 



<!-- Start of picture text -->
E  − Ed<br>Defect EQE ( E ) =  𝜅 Gd 1 + erf (4)<br>2<br>( ( 𝜎d √ 2 ))<br><!-- End of picture text -->

This equation takes into account the defect density (Gd), defect energy (Ed), standard deviation of the Gaussian defect DOS, and a proportionality constant ( _𝜅_ ). Valuable information regarding the energy and density of defect states can be obtained by fitting any s-EQE spectrum with a combination of an Urbach tail and a specific number of defect contributions. 

Cheng et al. have utilized highly sensitive s-EQE spectroscopy to monitor the ion dissociation process in PSCs based on MAPbI3 during degradation.<sup>[41]</sup> They performed s-EQE measurements at different time intervals and analyzed the changes in spectral characteristics using Gaussian fitting (Figure 4c). The results were compared with the defect state energy obtained through theoretical calculations. In another study, Janssen et al. combined s-EQE with optical modeling to investigate devices with the structure of PTAA/FA0.67MA0.33PbI2.85Br0.15/PCBM.<sup>[47]</sup> Their findings demonstrated that states near the perovskite/PCBM interface primarily contribute to the lower energy range of the photocurrent spectrum, indicating the presence of defects near this interface. These findings highlight the importance of considering optical interference effects when interpreting sub-bandgap spectra, particularly for perovskite devices, due to the localized effect caused by the abundance of defects at the interfaces. 

### **www.advenergymat.de** 

fecting the emission of defect states. By changing the temperature and frequency, the DOS in different energy band depths can be studied (Figure 4d).<sup>[42]</sup> In TAS, trap states’ center energy and energy distribution are determined by analyzing the capacitance (or admittance) spectrum obtained at different temperatures. As shown in Figure 4e, Zhou et al. found that the control device showed a relatively large density of defect states, especially around the deep defect level at 0.282 eV.<sup>[43]</sup> According to the previous density functional theory (DFT) calculation, they anticipate this defect-state level (0.282 eV) could potentially be ascribed to iodine interstitials (Ii). Meanwhile, the perovskite-FA (target) device exhibited a noticeable reduction of the deep-level defect state at 0.282 eV for two orders of magnitude. In conclusion, introducing a weak alkaline additive could suppress the incident I2 in the precursor solution and significantly reduce the Ii defect states. 

### _2.2.7. Electron-Electron: Drive-Level Capacitance Profiling (DLCP)_ 

DLCP is a type of capacitance-voltage-profiling characterization technique. DLCP can yield, like admittance spectroscopy, both the spatial and the energetic distribution of defects. The energetic distribution is obtained by varying the frequency of the AC signal, whereas the spatial distribution is sustained by modifications in the applied DC-bias.<sup>[48]</sup> 

Huang et al. conducted the DLCP method to map the spatial and energetic distributions of trap states in perovskite single crystals and polycrystalline thin films based on the device structure of ITO/PTAA/MAPbI3/C60/BCP/Cu. They found that the charge trap densities of all depths of the interfaces of the polycrystalline films were one to two orders of magnitude greater than that of the film interior (Figure 4g). The trap density at the film interior was still two to three orders of magnitude greater than that in high-quality single crystals (Figure 4f).<sup>[44]</sup> 

In principle, DLCP can have a high resolution because the depletion edge can be continuously tuned by the applied DC bias. However, the profiling distance within the real devices was affected by the non-flat depletion interfaces caused by either the roughness or the heterogeneity of the materials, which could compromise the resolution of the profiling distance. 

### _2.2.6. Phonon-Electron: Thermal Admittance Spectroscopy (TAS)_ 

### _2.2.8. Electron-Electron: Space Charge Limited Current (SCLC)_ 

TAS is a technique that utilizes electrical characterization to measure the admittance or impedance of a material as a function of both frequency and temperature. Unlike deep-level transient spectroscopy (DLTS), TAS is a steady-state measurement. 

As a diode, the solar cell exhibits capacitive characteristics in alternating current. When there is a defect state in the bandgap, the defect state may contribute to the capacitance. It takes some time for electrons to enter and leave the defect states. When the frequency of the AC is too fast, the defect state will not respond to the electric field. It will only react when the frequency is reduced. At a fixed temperature and frequency, a fixed deepest defect state responds to an AC. When the temperature increases, this defect state will move deeper. That is, deeper defect states will be excited at high temperatures. Therefore, temperature and frequency affect the capacitance of solar cells by af- 

SCLC was used in a vacuum diode. The current in a thin insulator is far over ohmic current behavior like the current in a vacuum diode.<sup>[49]</sup> When the applied voltage is low enough, the current is mainly driven by the mobile charge carriers being intrinsically present in the material. Currently, the current and voltage relationship satisfies Ohm’s law. When the voltage increases, the internal carriers of the insulator and intrinsic semiconductor are not enough to neutralize the injected charge, so a space charge is generated. The transmission speed of the space charge depends on the material’s mobility. When there are no defects, the charge drift follows the Mott-Gurney law. At this time, the current is proportional to the quadratic of the voltage. When the voltage and current follow this law, the device operates in the SCLC regime. Since the main limiting factor of current density under this 

**2401414 (7 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

working condition is the mobility of the material, the slope of _I_ – _V_<sup>2</sup> of SCLC reflects the mobility of the material. 



<!-- Start of picture text -->
J = 9 𝜀𝜈V 2 (5)<br>8 d 3<br><!-- End of picture text -->

where _𝜖_ is the absolute permittivity, d is the insulator’s thickness, and _𝜈_ is the mobility of the electrons. 

In the early stage of space charge generation, the injected electron density exceeds the characteristic carrier concentration, and the excess injected electrons will activate and occupy the defect state. At this time, the current density is composed of SCLC. The current is injected into the defect, so the current is proportional to the voltage higher than the quadratic, which was the trap-filling limited (TFL) region.<sup>[50]</sup> 

The trap density can be determined using the VTFL value according to the following equation: 



<!-- Start of picture text -->
Nt = 2 𝜀𝜀 0 VTFL (6)<br>e L 2<br><!-- End of picture text -->

where _𝜖_ is the dielectric constant of perovskite, _𝜖_ 0 is the vacuum dielectric constant, _L_ is the thickness of perovskite film, and _e_ is the elementary charge. 

However, due to its mixed electronic-ionic nature, the fundamental current-voltage behavior for electrons and holes in perovskite remains poorly understood. Alvar et al. demonstrated the crucial role of the frequency and temperature dependence of the apparent dielectric constant in understanding the magnitude, scan-rate dependence, and temperature dependence of SCLCs in perovskites. They developed a drift-diffusion model that incorporates experimentally validated ion dynamics, enabling consistent reproduction of the scan-rate dependence and temperature dependence of the _J–V_ curves in e<sup>−</sup> -only and h<sup>+</sup> -only devices (Figure 4h).<sup>[45]</sup> Lim et al. observed conspicuous hysteresis in the _J–V_ curves of SCLCs, obtained by scanning in different directions. They postulated that mobile ions are responsible for the hysteresis and developed a pulsed voltage SCLC method to effectively eliminate it. Furthermore, they discovered that the density of mobile ions can also be derived from the pulsed voltage SCLC data, in addition to the trap density.<sup>[51]</sup> 

### **2.3. How the Defects Influence Device Performance and Stability** 

During the operation of PSCs, sunlight is incident on the perovskite active layer through a transparent electrode, and the perovskite layer absorbs the incident photons to generate excitons. In ideal conditions, the perovskite film absorbs all incident photons, generating electrons and holes with the same efficiency. Under open-circuit conditions, the radiative recombination of free electrons and holes in the same layer in which they are produced is the only recombination channel.<sup>[52]</sup> However, defects at the interfaces and GBs of polycrystalline perovskite films will promote the non-radiative recombination of electrons and holes during the operation.<sup>[53]</sup> These will decrease the steady-state charge density, thereby reducing the quasi-Fermi level splitting (QFLS), which represents the energy difference between the quasi-Fermi levels of electrons and holes.<sup>[26]</sup> When the charge recombination rate coincides with the charge generation rate, this process is controlled by the charge density. 

### **www.advenergymat.de** 

In PSCs, there is a clear correlation between _V_ OC and QFLS.<sup>[54]</sup> 



<!-- Start of picture text -->
q VOC =  QFLS  + Δ E 1 + Δ E 2 −Φ n  −Φ p  − 𝛿n  −Δ VOC,NR (7)<br><!-- End of picture text -->

where Δ _E_ 1 = _E_ ( _F,h_ ) − _EHOMO_<sup>_HTL,_Δ</sup><sup>_E_2=</sup><sup>_E_</sup> _HOMO_<sup>_HTL_−</sup><sup>_EV,_Δ</sup><sup>_V_(</sup><sup>_OC,NR_)</sup> represents the non-radiative recombination loss (Δ _VOC,NR_ = −<sup>_kBT_</sup> _q_<sup>ln(</sup><sup>_PLQY_)),</sup><sup>_QFLS_=</sup><sup>_EF_,</sup><sup>_e_−</sup><sup>_EF_,</sup><sup>_h_(</sup><sup>_EF_,</sup><sup>_e_and</sup><sup>_EF_,</sup><sup>_h_representthe</sup> quasi-Fermi level of electron and hole, respectively). 

Furthermore, recombination at the interfaces and GBs affects the efficiency of charge extraction.<sup>[55]</sup> It could also affect the shortcircuit current ( _J_ SC) and fill factor ( _FF_ ) of devices due to increased series resistance.<sup>[56,57]</sup> Studies have shown a direct correlation between trap density, mobile ionic defects density, and the _J–V_ hysteresis degree.<sup>[58]</sup> The presence of defect states or mobile ions limits device performance and contributes to _J–V_ hysteresis.<sup>[26]</sup> Passivation of defects can alter the contact resistance at the interface between the perovskite and charge transport layers. Additionally, the addition of passivation agents in perovskite precursors can change the film morphology, reducing the presence of pinholes as shunt paths and thus affecting the _FF_ in PSCs.<sup>[59]</sup> 

Notably, defects at the interfaces and GBs of perovskite films significantly impact the performance of the devices. In addition, defects can also deteriorate device stability.<sup>[60]</sup> Eames et al. discovered that vacancies and interstitials, in particular, create ion migration pathways within perovskite films.<sup>[61]</sup> Meggiolaro et al. demonstrated that ion migration primarily occurs at interfaces and GBs due to the formation of migrating defects facilitated by the interfaces.<sup>[62]</sup> Ion mobility accelerates the degradation process by promoting the interface decomposition reaction. 

Furthermore, defects at interfaces and GBs play a crucial role in the degradation of perovskite films and the corresponding devices caused by moisture, oxygen, light, and thermal conditions.<sup>[60]</sup> Ahn et al. found that trapped charges induced by defects at GBs and interfaces of perovskite films under illumination provide charge accumulation sites and infiltration pathways, which trigger irreversible degradation under moisture exposure regardless of charge polarity.<sup>[63]</sup> Haque et al. demonstrated that VI defects are the preferred sites for the photo-induced formation of superoxide species (O<sup>2−</sup> ) from oxygen through theoretical calculation.<sup>[64]</sup> Aristidou et al. demonstrated that the exposure of MAPbI3 films to oxygen under illumination results in the formation of O<sup>2−</sup> through electron transfer from photoexcited perovskite to O2. Subsequently, the deprotonation reaction of O<sup>2−</sup> with MA<sup>+</sup> initiates degradation, resulting in the formation of products such as PbI2, MA, I2, and water.<sup>[65]</sup> 

## **3. Strategies for Defects Passivation in Perovskite Films** 

### **3.1. Defects Passivation at Perovskite Buried Interface** 

Due to the limitations of the layer-by-layer deposition process, directional passivation of defects at perovskite-buried interfaces remains challenging. The defects at the buried interface of perovskite films harm charge extraction and affect the nucleation and growth of the subsequently deposited perovskite layers.<sup>[66,67]</sup> 

**2401414 (8 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 5.** Defects passivation at perovskite buried interface. a) The structures of common HTMs in inverted PSCs. b) The structure of SAM molecules. c) Schematic diagram of interfacial interactions between ITO/SAM/perovskite. Reproduced with permission.<sup>[68]</sup> Copyright 2024, Wiley. d) Schematic of inverted device structure and the molecular design strategy of PPYs. Reproduced with permission.<sup>[69]</sup> Copyright 2020, Wiley. e) Design principle and molecular structures of synthesized HTMs: PTAA-P1 and PTAA-P2. Reproduced with permission.<sup>[70]</sup> Copyright 2023, Wiley. f) Schematic illustration of MeO-4PADBC anchoring on NiOx nanoparticle as the HSL in PSCs and the _J–V_ curves of corresponding devices. Reproduced with permission.<sup>[71]</sup> Copyright 2023, American Association for the Advancement of Science. 

### _3.1.1. Passivation by the Hole Transport Layer_ 

For inverted structures, the HTL directly contacts the TCO and perovskite. Thus, the properties of HTL and contact with perovskite are crucial for the overall device performance.<sup>[72]</sup> **Figure 5** a shows the common HTMs in inverted devices. Organic polymers, such as poly (3,4-ethylenedioxythiophene): poly(4styrenesulfonate) (PEDOT:PSS), poly[N,N’-bis(4-butylphenyl)-N, 

N’-bis(phenyl) benzidine] (polyTPD), poly(bis(4-phenyl) (2,4,6trimethylphenyl) amine (PTAA), metal oxide, such as NiOx, CuCrO2,<sup>[73]</sup> CuSCN, Cu2O, self-assembled monolayers (SAMs), such as [2-(3,6-dimethoxy9H-carbazol-9-yl) ethyl] phosphonic acid (MeO-2PACz), [2-(9Hcarbazol-9-yl)ethyl] phosphonic acid (2PACz), are extensively utilized.<sup>[74]</sup> 

Among them, SAMs stand out due to their crucial advantages of low-cost, simple synthesis, dopant-free and scalable. Moreover, 

**2401414 (9 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

they can realize conformal deposition, making them attractive for use in textured perovskite/silicon tandem solar cells. The structure of SAM molecules is shown in Figure 5b.<sup>[75–77]</sup> SAMs can simultaneously realize effective ITO work function adjustment and buried interface passivation by rational molecular design. Jen and co-workers reported two carbazole-based SAMs, CbzPh and CbzNaph, through asymmetric and helical _𝜋_ -expansion of carbazole, respectively.<sup>[78]</sup> Further, oxygen and sulfur atoms were introduced to tune the dipole of the CbzPh, obtaining CbzBF and CbzBT. The introduction can also effectively passivate defects at the buried interface.<sup>[79]</sup> Recently, they designed a novel SAM molecule based on 7-methoxybenzo[b]benzo[4,5]thieno[2,3d]thiophene (MeO-BTBT).<sup>[68]</sup> The tilt-packing mode of MeOBTBT enables interaction between the sulfur atom and the perovskite layer, thereby simultaneously passivating defects at the buried interface between the perovskite and the HSL (Figure 5c). Hong and co-workers developed Br-2EPT using phosphonic acid as the anchoring group, ethyl group as the linkage, and bromine atom as the functional phenothiazine group.<sup>[80]</sup> This design allows for efficient charge collection, electron blocking, and surface passivation of the perovskite. Wu and co-workers designed an amphiphilic hole transporter MPA-CPA, composed of a triphenylamine-based head group and a cyanovinyl phosphonic acid anchoring group.<sup>[81]</sup> This multifunctional transporter enables the formation of high-quality perovskite films with minimized interfacial defects by creating a super-wetting underlayer. 

Zhu and co-workers also reported a new pyridine-based polymer hole-transporting material (HTM) with suitable energy levels, high hole mobility, and efficient passivation effects (Figure 5d).<sup>[69]</sup> They also introduced pyridine units into the polyarylamine backbone to modulate the wettability and promote anchoring.<sup>[70]</sup> As shown in Figure 5e and 3,5-linked PTAA-P1 can form strong interaction with atop perovskite layer through the Pb─N bond, regulating the molecular conformation, leading to highly crystalline perovskite films with uniform back contact and reduced defect density. 

### _3.1.2. Passivation by the Modification Interlayer_ 

Modification molecules are also introduced to enhance the interaction between the HTL and perovskite layer and passivate the buried interface through the formation of a chemical bridge,<sup>[82]</sup> the construction of a 2D or heterogeneous intermediate layer and the induction of interface dipole.<sup>[83]</sup> For example, Zhang and co-workers introduced 3-(1-pyridinio)−1-propanesulfonate (PPS) molecules into the PTAA/perovskite interface.<sup>[84]</sup> The molecules have pyridine and sulfonate groups. The former can chemically bond with the phenyl group of PTAA via _𝜋_ – _𝜋_ stacking, and the latter can coordinate with the perovskite through S = O···Pb. The chemical bridge structure significantly suppresses interface recombination. Zang and co-workers incorporated 2-aminoindan hydrochloride into the perovskite precursor to form a bottomup 2D/3D heterojunction, which can modulate carrier recombination and extraction dynamics at the buried interface.<sup>[85]</sup> Chen and co-workers introduced different 2D spacers to the bottom interface in inverted devices. The modification of the 2D spacers induced the formation of 2D/3D heterojunction at the bottom interface, which can facilitate hole transfer and suppress inter- 

### **www.advenergymat.de** 

facial charge recombination.<sup>[86]</sup> Glyciniu-based additive was introduced to the perovskite precursor. GlyH cations can spontaneously accumulate in the bottom of the perovskite layer, thus inducing interface dipoles to enhance hole transport.<sup>[87]</sup> 

In addition, SAMs can also be utilized to enhance the adhesion between the HTL and perovskite layers as well as the passivate burred interface, facilitating charge transfer. Zhu and co-workers reported a new SAM, (4-(3,11-dimethoxy7H-dibenzo[c,g]carbazol-7-yl)butyl)phosphonic acid (MeO4PADBC), which is anchored to the NiOx film to improve and stabilize the interface (Figure 5f). Based on the modification, corresponding devices achieved a certified efficiency of 25.6%.<sup>[71]</sup> Yan and co-workers utilized a co-SAM layer to modify the buried interface of NiOx-based PSCs by simultaneously doping Me4PACz with phosphorylcholine chloride (PC).<sup>[88]</sup> The phosphate group and Cl<sup>−</sup> in PC can inhibit NiOx surface defects. In the meantime, the quaternary ammonium ions and Cl<sup>−</sup> in PC can fill organic cations and halogen vacancy defects at the bottom of the perovskite film. This strategy can promote the growth of perovskite crystals, collaboratively solve the problem of buried defects, suppress nonradiative recombination and accelerate carrier transmission. Tang and coworkers introduced an interfacial layer (KF) between HTL (NiOX/2PACz) and perovskite layers. Considering both the high electronegativity of F<sup>−</sup> and passivation interaction with halide vacancies via K<sup>+</sup> , the introduction of the KF interlayer not only enhances the SAM dipole moment but also passivates the bottom interface.<sup>[89]</sup> 

### **3.2. Defects Passivation at Perovskite Bulk** 

In addition to the buried interface, there are still various defects within the bulk of perovskite. The ionic nature of perovskite delivers an effective and straightforward approach to passivating defects through coordinated or ionic bonding.<sup>[90,91]</sup> Additive engineering can provide significant value for defect passivation in the fabrication process of perovskite film.<sup>[92–94]</sup> In this section, we will specifically concentrate on the passivation of defects within the bulk of perovskite. 

### _3.2.1. Excess Precursor Materials for Perovskite_ 

Typically, perovskite precursor solution preparation is based on the stoichiometry of precursors, 

However, the introduction of non-stoichiometric conditions, such as incorporating excess lead idoide (PbI2) or alkylammonium halogen salts into the precursor solution, has been found to effectively passivate defects. Chen et al. proposed a plausible passivation mechanism based on the I-type band alignment principle.<sup>[95]</sup> As shown in **Figure 6** a, the bandgap of PbI2 is 2.3 eV, which is larger than that of perovskite (1.5 eV). Its conduction band is located above the perovskite, and its valence band is located below the perovskite, causing carrier transport to be impeded at the GBs enriched with PbI2. Additionally, PbI2 alters the bending direction of the grain-to-grain boundary, reducing carrier recombination at the interface. However, an excessive amount of PbI2 can hinder the extraction of carriers due to its wide bandgap.<sup>[100]</sup> Besides, Son et al. showed that a small quantity of excess methylammonium iodide (MAI) can accumulate at 

**2401414 (10 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 6.** Defects passivation at perovskite bulk. a) Self-induced passivation of PbI2. Reproduced with permission.<sup>[95]</sup> Copyright 2014, American Chemical Society. b) _J_ – _V_ curves of (FAPbI3)0.875(CsPbBr3)0.125-based devices doped with different metal cations. Reproduced with permission.<sup>[96]</sup> Copyright 2018, American Chemical Society. c) The formation of quasi-3D FAxPEA1–xPbI3 crystal after introducing PEAI. Reproduced with permission.<sup>[97]</sup> Copyright 2017, Wiley. d) Schematic diagram of the interaction between the PPP polymer and perovskite. Reproduced with permission.<sup>[98]</sup> Copyright 2021, American Association for the Advancement of Science. e) The molecule structure of PTCoPF6 and its passivation effect for various perovskite defects calculated by DTF. Reproduced with permission.<sup>[99]</sup> Copyright 2024, Wiley. 

GBs, forming a thin layer that passivates defects and suppresses non-radiative recombination.<sup>[101]</sup> 

### _3.2.2. Metal Cations Doping_ 

During the annealing process, organic amine cations can exhibit high volatility, forming vacancy defects. To address this issue, ad- 

ditive engineering has introduced metal cations such as Cs and Rb into the perovskite lattice, occupying the A-site, per the Goldschmidt tolerance factors.<sup>[102]</sup> Other alkali metals like Na, K, and Li have also been well studied.<sup>[103–105]</sup> Son and co-workers systematically investigated the passivation effects of various alkali metal iodides (Figure 6b). They found that KI exhibited the most effective and universal passivation effect.<sup>[96]</sup> They demonstrated that K effectively decreased the formation of Frenkel defects by 

**2401414 (11 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

occupying interstitial sites. Moreover, other metal cations have also been explored for defect passivation.<sup>[106]</sup> Snaith and coworkers demonstrated that introducing a small amount of Al<sup>3+</sup> into the precursor enhanced crystallization, resulting in more orientated crystalline domains.<sup>[107]</sup> 

### _3.2.3. Large-Size Ammonium Salts_ 

Large-size ammonium salts have also been explored due to their ability to form 2D or 1D structures, which can improve device stability by protecting fragile 3D perovskite.<sup>[108–110]</sup> Jen and co-workers revealed that after introducing phenethylammonium iodide (PEAI) into FAPbI3 perovskite. As shown in Figure 6c, the larger PEA cation can assemble on both the lattice surface and GBs to form quasi-3D perovskite structures, acting as molecular locks to enhance the stability of FAPbI3 by tightening the domains and passivating surface defects.<sup>[97]</sup> Other short linear alkane amine functionalities, such as ethylammonium (EA), n-butylammonium (BA), and guanidinium (Gua), have also been well studied.<sup>[111]</sup> Wang et al. found that 2D layered perovskite formed by BA on the 3D perovskite has a wide bandgap. The 2D-3D heterojunction in the GBs can block the carriers, and they continue propagating in the grain without generating recombination.<sup>[112]</sup> In addition, 2D perovskites are also directly introduced in perovskite. Li et al. added the pre-prepared 2D C6H18N2O2PbI4 (EDBEPbI4) microcrystals into the precursor solution, wherein the 2D perovskite microcrystals could assemble at the GBs to passivate the defects and enhance the stability without sacrificing the charge-carrier extraction.<sup>[113]</sup> 

### _3.2.4. Anions Doping_ 

Anions doping is effective for Pb interstitial and halide vacancy defects.<sup>[114]</sup> It is commonly believed that an excess of iodide ions in the precursor solution or the addition of iodine separately can inhibit the formation of halogen vacancies. Besides, other smallradius halogen ions (Br<sup>−</sup> ,<sup>[115]</sup> Cl<sup>−</sup> ,<sup>[116,117]</sup> F<sup>−)[118]</sup> are also studied. Among them, F- has the smallest radius and highest electronegativity, allowing it to form strong chemical bonds with Pb. Li et al., through device modifications and DFT calculations, compared the effects of adding 0.1% NaX (X = I, Br, or Cl) and argued that F<sup>−</sup> exhibited a strong passivation effect by forming robust ionic bonds with Pb and hydrogen bonds (N-H···F) with MA/FA cations.<sup>[114]</sup> Other anions, apart from halogen anions, can also be passivators. It has been reported that halogenlike ions like SCN<sup>−</sup> can reduce recombination at GBs through reaction intermediates.<sup>[119]</sup> Yin et al. found that O<sup>2−</sup> significantly impacted defect passivation at GBs and enhanced charge transfer.<sup>[120]</sup> 

### _3.2.5. Lewis Acid and Lewis Base_ 

Lewis acids are molecules or ions that accept external electron pairs. In contrast, Lewis bases are molecules or ions that donate electron pairs. Such molecules could form acidbase complexes via covalent coordinate bonds without electron 

### **www.advenergymat.de** 

transfer.<sup>[121]</sup> Therefore, defects with lone pairs of electrons, such as free I<sup>−</sup> and Pb-I antisite defects, can be effectively passivated by Lewis acids.<sup>[121]</sup> In contrast, electron-deficient defects, such as Pb<sup>2+</sup> interstitials, can be firmly bonded by Lewis bases. Fullerene (C60) and its derivatives are the most representative Lewis acid passivators.<sup>[122]</sup> Liu and co-workers fabricated a heterojunction by introducing C60 into the precursor, resulting in reduced trap density and improved stability.<sup>[123]</sup> Wang and co-workers synthesized water/alcohol soluble A10C60 by attaching a carboxylic acid group to the head of C60. An excellent _FF_ of 86.7% was achieved based on the A10C60-modified devices.<sup>[124]</sup> 

Lewis bases are characterized by atoms that possess lone pairs of electrons, particularly N, S, O, and P atoms.<sup>[125]</sup> Liu and coworkers demonstrated that doping pyridine (typically N-doner) into a precursor could increase grain size and achieve high performance.<sup>[126]</sup> This is because the introduction of pyridine can slow down the crystallization process of perovskite and passivate the defects by interacting with uncoordinated Pb<sup>2+</sup> . The effects of the amine group (-NH2) have also been explored. For example, the introduction of aminovaleric acid greatly improves device efficiency and stability by accumulating at GBs or forming a 2D perovskite layer.<sup>[127]</sup> As for O-donor, commonly used solvents such as N,N-dimethylformamide, N,N-dimethylsulfoxide, N-methyl-2pyrrolidone, etc., all contain O-donors, which can strongly be coordinated with Pb<sup>2+</sup> , thus retarding the crystallization process of perovskite and resulting in high-quality film.<sup>[128]</sup> However, these solvents usually escape from the perovskite film under thermal annealing and do not participate in defect passivation. Huang and coworkers incorporated a series of carbamide molecules (urea, biuret, or triuret) consisting of both Lewis base (-NH2) and Lewis acid (─C═O) groups into the perovskite precursor to simultaneously eliminate the bulk and interface defects.<sup>[129]</sup> Thiourea, a representative S-donor, has also been demonstrated to suppress the defects and improve the film quality.<sup>[130]</sup> Moreover, combining N- and S-donor can significantly improve the passivation effect.<sup>[131]</sup> 

### _3.2.6. Others_ 

Ionic liquids (ILs), which consist entirely of ions, have been extensively investigated.<sup>[132]</sup> For example, Zhu et al. reported that the utilization of methylamine formate resulted in a more uniform and stronger compressive strain to suppress the transition of shared-corner PbI6 octahedron into shared-face _𝛿_ -FAPbI3. This, in turn, influenced the dynamic behavior of carriers and defects, leading to a remarkable efficiency of 24.08% for inverted FAPbI3-based PSCs.<sup>[133]</sup> Xia and co-workers employed 1,3-bis(4-vinylbenzyl)imidazolium chloride ([bvbim]Cl), which can undergo self-polymerization during the perovskite fabrication process and assemble at GBs to prevent the volatilization of MA and passivate defects. The resulting devices fabricated in humid environments exhibited an impressive efficiency of 19.92%.<sup>[134]</sup> 

Polymers with exceptional properties have also garnered significant attention.<sup>[135,136]</sup> Zuo and co-workers incorporated poly(4-vinyl pyridine) (PVP) into perovskite precursor, which can self-assemble at GBs, effectively passivating defects and protecting perovskite from moisture, thus significantly 

**2401414 (12 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

improving device stability.<sup>[137]</sup> Grätzel and co-workers designed a 3D star-shaped polymer that has multiple functional groups on each branch (polyhedral oligomeric silsesquioxanepoly(trifluoroethyl methacrylate)-b-poly(methyl methacrylate (PPP)). As shown in Figure 6d, PPP can strongly interact with perovskite via multiple chemical anchor sites to control the crystallization of perovskite film.<sup>[98]</sup> 

Besides, Li and co-workers introduced 1-propanol-2-(1,2,3triazol-4-yl) cobaltocenium hexafluorophosphate (PTCoPF6), an organometallic cobaltocenium salt additive, into the perovskite precursor solution to passivate holistic defects. As shown in Figure 6e, PTCoPF6 can act by passivating both the deep and shallow-level defects via coordination passivation and vacancy healing, which is also beneficial for stabilizing the components in perovskite.<sup>[99]</sup> 

### **3.3. Defects Passivation at Perovskite Upper Interface** 

In the previous sections, we have summarized the passivation method for the buried interface and the perovskite bulk. However, it is essential to note that the surface defects of perovskite films can be more pronounced due to the easy volatilization of organic molecules during the thermal annealing process.<sup>[138]</sup> Huang et al. have demonstrated that the charge trap densities of all depths of the interfaces of the polycrystalline perovskite films were one to two orders of magnitude greater than that of the film interior via DLCP.<sup>[44]</sup> Therefore, post-treatment of the perovskite films should effectively reduce the surface dangling bonds and enhance device performance. In this part, we will delve into the advancements made in passivating the surface defects of perovskite in inverted devices. 

### _3.3.1. Passivation by the Electron Transport Layer_ 

C60 and its derivatives are also suitable electron transport materials benefiting from their inherent electron attraction in fullerene spherical structures.<sup>[144]</sup> Huang and co-workers have demonstrated that the spun PC61BM layer can conformably cover perovskite with intimate contact and permeate along the perovskite GBs as the thermal annealing proceeds. They also demonstrated that the deposition of PC61BM/C60 double fullerene layers on perovskites can reduce trap state density and suppress the photocurrent hysteresis compared with the C60 single layer.<sup>[145]</sup> Jen and co-workers also demonstrated effective interfacial interaction between perovskite and fullerene exists under bias.<sup>[146,147]</sup> Peng and co-workers designed a novel n-self-doping conducive C60-PDI-I dimer ETL with high mobility by incorporating C60 and perylene diimide (PDI).<sup>[148]</sup> At the same time, the presence of abundant carbonyl groups with lone pair electrons affords coordination interactions with the under-coordinated Pb atoms at the perovskite interface, which boosts the device’s efficiency and stability. Wu and co-workers introduce electron-transporting carborane as an interlayer between perovskite and C60. Further introduction of functionalized aniline groups can adjust its energy level. As shown in **Figure 7** a, the HOMO of carborane is deeper than that of C60, which means better hole-blocking ability. Meanwhile, functionalized aniline groups can effec- 

### **www.advenergymat.de** 

tively passivate defects and suppress perovskite/C60 interfacial recombination.<sup>[139]</sup> 

### _3.3.2. Passivation by the Reactive Dipole Interlayer_ 

Perovskite surface defects differ significantly from those in the bulk, arising from various surface terminations and undercoordinated sites. Vacant terminations, which are more stable than PbI2 flat and MAI/FAI terminations, can induce vacancy defects (such as VI and VMA/VFA) on the surface due to differences in surface energy.<sup>[149]</sup> In FAPbI3 perovskite, FA-related intrinsic defects are more easily formed with lower formation energies, attributed to the weaker interaction between FA<sup>+</sup> and [PbI6]<sup>2−</sup> octahedral.<sup>[150]</sup> 

Numerous molecules have been developed to tailor the surface chemical environments and surface defects.<sup>[151,152]</sup> Huang and colleagues demonstrated the effective passivation of ionic defects in various types of hybrid perovskite using quaternary ammonium halides with their negatively and positively charged components.<sup>[153]</sup> Li and co-workers designed a fullerene electrolyte (PCBB-3N-3I) dipole interlayer to simultaneously passivate charged surface defects and reconfigure the energy band structure at the interface between the perovskite layer and ETL.<sup>[154]</sup> The iodide in PCBB-3N-3I can anchor the positive surface defects through electrostatic interaction, achieving effective passivation and the preferred orientation of PCBB-3N-3I assembly. Jen and co-workers reported a bifunctional molecule, piperazinium iodide (PI), with both R2NH and R2NH2+ groups on the same six-membered ring, which means it can act as an electron donor and an electron acceptor simultaneously to react with different surface terminations on perovskite films.<sup>[140]</sup> The tuning of surface termination with PI treatment also helps to achieve a more n-type characteristic film to facilitate charge transfer. As a result, an efficiency of 23.37% is obtained from PI-treated devices (Figure 7b). 

### _3.3.3. Passivation by the Organic Spacer Cations_ 

2D perovskite spacer cations (such as PEA, BA, and QA) can effectively passivate uncoordinated Pb<sup>2+</sup> or Pb clusters on the surface of perovskite films.<sup>[155,156]</sup> Among them, the lone pair of electrons of the N atom in the terminal group of spacer cation interacts with the metal Pb<sup>2+</sup> to form a quasi-2D perovskite capping layer.<sup>[141]</sup> Huang and co-workers revealed the chemical reaction mechanism between BA and 3D perovskite surface to construct 2D/3D heterostructure.<sup>[157]</sup> They explained the functionality of 2D layers in enhancing the thermal stability of the surface by preventing MA and I evaporation. Besides, they demonstrated the slow-down ion migration due to increased defect generation energy in the 2D perovskite layer.<sup>[158]</sup> Liu and colleagues designed morpholine hydroiodide (MORI) and thiomorpholine hydroiodide (SMORI) by introducing a Lewis base (O or S) to replace N in the PI molecule and applying them to passivate the perovskite surface. As shown in Figure 7c, the modified molecules can form a 2D perovskite capping layer on the perovskite surface instead of the 1D perovskite capping layer formed by PI treatment. After dimensional regulation, the SMORI treatment can realize robust surface passivation and stronger 2D/3D heterojunctions. Moreover, a power conversion efficiency (PCE) of 

**2401414 (13 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 7.** Defects passivation at perovskite upper interface. a) Device structure and molecule structures of CB and CB-NH2, as well as the corresponding energy levels. Reproduced with permission.<sup>[139]</sup> Copyright 2022, Springer Nature. b) The corresponding _J–V_ curves of devices based on regulating surface termination by PI. Reproduced with permission.<sup>[140]</sup> Copyright 2020, American Chemical Society. c) Schematic illustration of the post-treatment for perovskite film using MORI or SMORI and the corresponding _J_ – _V_ curves of perovskite solar modules. Reproduced with permission.<sup>[141]</sup> Copyright 2024, American Chemical Society. d) Device performance of 2D/3D perovskite heterojunction formed by OLAI post-treatment. Reproduced with permission.<sup>[142]</sup> Copyright 2022, American Association for the Advancement of Science. e) Illustration of the device structure with EDA<sup>2+</sup> and 4F-PEA post-treatment. Reproduced with permission.<sup>[143]</sup> Copyright 2024, Wiley. 

22.28% can be achieved based on SMORI-treated devices at an active-area of 14.4 cm<sup>2</sup> .<sup>[141]</sup> Besides, the dimension n of the 2D perovskite can also be customized by adjusting the annealing conditions. Wolf and co-workers post-treated the perovskite film with oleylammonium iodide molecules at room temperature to obtain 2D perovskite with _n_ ≥ 2. The device structure is shown in Figure 7d. Based on 2D layers prepared at room temperature, an efficiency of 24.3% was achieved.<sup>[142]</sup> 

Interestingly, Mahmud and co-workers demonstrated a 2D perovskite passivation scheme based on octylammonium chloride (OACl) and showed that it provides both bulk and surface passivation.<sup>[159]</sup> The Cl<sup>−</sup> diffuses into the perovskite bulk, passivating defects, while the OA ligands provide effective, localized surface passivation. Besides halide diffusing from the surface to passivate the perovskite bulk, the partial diffusion of organic bulky cations into the bulk is also possible if their ionic radii are comparable to the organic cations in the perovskite bulk.<sup>[160]</sup> Mahmud and co-workers adopted the cation-diffusionpassivation scheme and chose CH6N<sup>3+</sup> , which has an ionic radius comparable to FA<sup>+</sup> . This concurrent bulk-passivation 

and surface-passivation scheme is based on the partial diffusion of bulky organic cations from the surface layer into the bulkpassivating defects. In contrast, the surface-remaining cations passivate the perovskite surface.<sup>[161]</sup> 

### _3.3.4. Multi-Molecule Synergistic Passivation_ 

Inverted devices’ non-radiative recombination at the perovskite/C60 interface, including defects-induced surface recombination and contact-induced interface recombination, significantly affects device performance.<sup>[139]</sup> Sargent and coworkers adopt sulfur-modified methylthio and diammonium molecules for passivation of surface defect-induced and contactinduced interfacial recombination, respectively.<sup>[162]</sup> The former can interact with defects to form chemical bonds and reduce surface recombination. The latter can repel minority carriers (holes) to reduce interface recombination. The complex carrier recombination problem at the perovskite/C60 interface is alleviated by combination. Similarly, Tan and co-workers 

**2401414 (14 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 

developed a sequential post-treatment involving ethylenediamine diiodide and 4-Fluoro-Phenethylammonium chloride deposition (Figure 7e). The former works as a modifying layer to narrow the conduction band offset between the perovskite and C60 layers, while the latter acts as a positive dipole layer to further reduce recombination losses.<sup>[143]</sup> 

Capping 2D perovskite layers atop 3D perovskites, although they help achieve environmental stability, could hinder electron extraction and deteriorate device performances of inverted PSCs.<sup>[141]</sup> Liu and co-workers also reported a bi-molecular competitive adsorption strategy.<sup>[163]</sup> By introducing phenylmethylammonium iodide (PMAI) and octylammonium iodide (OAI) simultaneously, due to the greater molecular polarity and steric hindrance effect of OA, it preferentially adsorbs on the perovskite surface, thereby inhibiting PMA-induced surface layer transformation into a low-dimensional structural phase. Li and co-workers proposed constructing limited 2D/3D perovskite structures through interfacial ligand confinement to obtain efficient and stable inverted PSCs and modules.<sup>[164]</sup> As a masking reagent atop 3D perovskites, EDA interacts with ammonium via H-bonding interaction, regulating the cation exchange and distribution to form a finite and dense 2D passivation layer. Besides, a depth-dependent manipulation strategy was also developed to realize bulk and interfacial defects passivation.<sup>[165]</sup> Tan and co-workers adopt the mixture of methylammonium thiocyanate (MASCN) and PEAI to posttreat the perovskite.<sup>[166]</sup> The MASCN induces the regrowth of perovskite grains and simultaneously facilitates the penetration of PEAI into the HTL/perovskite bottom interface. PCEs of 21.9% and 19.9% for the 1.65-eV bandgap opaque and semitransparent perovskite solar cells, respectively, are obtained. 

### **3.4. Synergistic Passivation of Bulk and Interfaces of Perovskite** 

Recently, more and more researchers have tried to combine the passivation of bulk and interfaces of perovskite to further enhance device performance.<sup>[161,167]</sup> Liu and co-workers realized a total defect passivation by stereoscopically introducing the cysteamine hydrochloride (CSA-Cl) in bulk and surface of perovskites.<sup>[168]</sup> The DFT calculations reveal that the organic cation of CAS and its functional group (-SH, -NH2+) and the Cl<sup>−</sup> can occupy the organic vacancy and have apparent charge interaction with the undercoordinated Pb<sup>2+</sup> and Pb-I antisite defects. Vaynzof and co-workers presented a dual interfacial modification approach by integrating large organic cations at electron and HTL interfaces ( **Figure 8** a). They find that modification of the bottom interface leads to improved wettability, eliminating nanovoids forming at the HTL interface. Modifying the top perovskite surface leads to its efficient passivation and reduced non-radiative recombination losses. These two different mechanisms can be combined to simultaneously improve all photovoltaic parameters. Moreover, further incorporating ILs into the active perovskite layer leads to efficient and stable devices.<sup>[169]</sup> Xu and colleagues added functional nanographene (C78-AHM) into the PTAA HTL, resulting in an HTL with enhanced conductivity, reduced roughness, and frontier energy levels that match the perovskite absorber’s work function.<sup>[170]</sup> Thiosemicarbazide 

(TSC) was added to the perovskite precursor solution to modify the perovskite grain and interface, thus improving the crystalline morphology of the perovskite film. This co-doping strategy can simultaneously reduce interfaces, bulk defects, and the interface energy barrier in the perovskite film. Similarly, Chen and co-workers simultaneously introduced additives and surface passivators to realize dual-interface modification.<sup>[171]</sup> As shown in Figure 8b, this strategy can effectively reduce the surface potential of the perovskite film, facilitating electron transfer and reducing interface recombination. 

### **3.5. Passivation of Large-Area Perovskite** 

Upscaling defects passivation engineering for perovskite modules is a critical step toward commercializing and widespread adoption of perovskite-based photovoltaics. Notably, upscaling defects passivation engineering for perovskite solar cells and modules involve similar principles but differ in scale, complexity, and considerations due to their respective applications. 

In the past few years, a variety of scalable preparation processes, such as slot-die coating,<sup>[172]</sup> blade coating,<sup>[173]</sup> inkjet printing,<sup>[174]</sup> etc., have been reported. By combining various processing strategies such as anti-solvent casting,<sup>[128]</sup> hot casting,<sup>[175]</sup> air knife assistance,<sup>[176]</sup> and vacuum assistance,<sup>[177]</sup> etc., the preparation of dense perovskite layers has been successfully achieved. 

However, in addition to film defects, the uniformity of the perovskite film will also directly affect its interface contact with the charge transport layer as the device area increases. Poor interface contact and inadequate charge transport capability can lead to severe interface recombination, thereby reducing _FF_ and _V_ OC. 

To eliminate the severe interface recombination, researchers have done lots of work. Jen and co-workers have chosen SAM to replace PTAA with poor surface wettability.<sup>[178]</sup> As shown in **Figure 9** a, the SAM surface facilitates the nucleation and growth of perovskite film after the blade-coating process, forming a dense perovskite layer with strong adhesion to the substrate, thus passivating the interfacial defects. Moreover, the mini-module (an aperture area of 18.0 cm<sup>2</sup> .) based on SAM realized a PCE of 14.13%. Qiu and co-workers introduced Al2O3 nanoparticles into the HTL/perovskite interface to hamper the direct contact between perovskite and substrate. Besides, PEABr was employed to modify the buried and upper interfaces of perovskite film.<sup>[166]</sup> Due to the reduced interface recombination, the _V_ OC of corresponding devices is extensively improved from 1.02 to 1.14 V. The 1 cm<sup>2</sup> device efficiency reaches 22.4%. Li and co-workers introduced self-assembled dyad molecules to suppress the redox reaction between high-valence Ni<sup>3+</sup> of NiOx and ammonium iodide of perovskites via chemical passivation, which suppresses the interfacial degradation and enhances device efficiency and stability.<sup>[182]</sup> 

Wu and co-workers proposed that ultra-thin inorganic alkali metal fluorides interlayer passivate the interface defects at the perovskite/ETL interface.<sup>[183]</sup> Pang and co-workers introduced n- type polymer N2200 into the PCBM, the commonly used ETM in inverted structures, to enhance the electrical properties of 

**2401414 (15 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 8.** Synergistic passivation of bulk and surface interfaces of perovskite. a) Device structures with the different combinations of passivated interfaces. Reproduced with permission.<sup>[169]</sup> Copyright 2021, American Association for the Advancement of Science. b) AFM images and KPFM surface potential images of Control, AMP-modified and AMP-mF/P-modified perovskite films. Reproduced with permission.<sup>[171]</sup> Copyright 2024, Wiley. 

PCBM and passivate the defects distributed on the perovskite surface. An efficiency of 20.30% in an area of 11.19 cm<sup>2</sup> is obtained (Figure 9b).<sup>[179]</sup> Lu and co-workers designed a bulky fluorinated phenmethylammonium salt (2CF3-PMABr), which can passivate defects at the film’s buried and upper surface without forming 2D perovskite.<sup>[184]</sup> This treatment reduces perovskite defects, suppresses the recombination reaction at the interfaces, and enhances the charge extraction by charge transporting layers. Zhang and co-workers also reported a dual interface engineering strategy using ammonium salt, namely 2-thiopheneethylammonium chloride (TEACl) (Figure 9c).<sup>[180]</sup> These dual interface modifications passivate the deleterious defects, optimize the band alignment, and improve the interfacial contact. A PCE of 22.6% with a high FF of 82.4% was obtained on an active area of 3.63 cm<sup>2</sup> . 

Besides, the defects passivation strategies should be compatible with the fabrication processes involved in module production. For example, Song and co-workers proposed a CS2 vaporassisted passivation strategy for perovskite solar modules to passivate the VI defects and uncoordinated Pb<sup>2+</sup> caused by ion migration (Figure 9d). Significantly, this method can avoid the disadvantages of inhomogeneity film caused by spin-coating- 

assisted passivation and reconstruction of perovskite surface from solvent.<sup>[181]</sup> 

Moreover, the passivators easily show spatial inhomogeneity, greatly hindering the passivation effectivity, especially in upscaling perovskite modules. For surface passivation, especially for solvent-based passivators, the solubility of the passivator and the effect of the solvent on the underlying perovskite need to be considered. The additives that passivate perovskite films often co-precipitate during perovskite crystallization and aggregate at interfaces, contributing to defects and spatial inhomogeneity.<sup>[114,185]</sup> Therefore, not only the function but the properties of the passivator need to be considered. Sargent and co-workers demonstrated that thermotropic liquid crystals such as 3,4,5-trifluoro-4′-(trans-4-propylcyclohexyl)biphenyl enable large-area perovskite films that are uniform, low in defects and stable against environmental stress factors.<sup>[186]</sup> 

## **4. Summary and Outlook** 

In recent years, significant progress has been made in developing inverted PSCs, with a record PCE exceeding 26%. The continuous breakthroughs in tandem devices have highlighted the 

**2401414 (16 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 9.** Passivation of large-area perovskite. a) The proposed perovskite nucleation and growth mechanisms after blade-coating and during thermal annealing on PTAA-based and SAM-based substrates. Reproduced with permission.<sup>[178]</sup> Copyright 2022, Elsevier. b) _J–V_ curves of devices based on N-doped PCBM. Reproduced with permission.<sup>[179]</sup> Copyright 2023, Wiley. c) Dual interface passivation based on TEACl. Reproduced with permission.<sup>[180]</sup> Copyright 2023, American Chemical Society. d) Schematic illustration of CS2 vapor passivated perovskite film and the vapor passivation functions of CS2 with the corresponding defects in perovskite. Reproduced with permission.<sup>[181]</sup> Copyright 2023, Wiley. 

substantial commercial potential of inverted PSCs. This review article delves into the nature and origin of defects in organic halide perovskite films, exploring their impact on solar cell performance and stability. We provide an overview of characterization techniques for identifying defects at both film and device levels. Furthermore, we discuss defect passivation strategies in in- 

verted devices at the perovskite buried interface, perovskite bulk, and perovskite top surface, including typical examples of synergistic passivation of both bulk and surface defects. Nonetheless, there are still unresolved issues that warrant further consideration. The summary and outlook for defect passivation in inverted PSCs and modules are shown in **Figure 10** . 

**2401414 (17 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 



**Figure 10.** Summary and outlook for defect passivation in inverted perovskite solar cells and modules. 

### **4.1. Develop Streamlined Characterization Methods for Defect Detection and Quantification** 

The development of streamlined testing and characterization methods is essential for detecting and quantifying perovskite defects. These methods guide in optimizing passivation techniques and further enhancing device performance. Advanced characterization techniques such as scanning probe microscopy, XPS, and Raman spectroscopy can be employed to detect and analyze defects accurately. Furthermore, future testing and characterization methods for perovskite defects should prioritize convenience and efficiency, incorporating automated testing equipment, real-time monitoring technology, and fast analysis algorithms to enable swift defect detection and quantitative analysis. Integration of data analysis and machine learning techniques can establish a correlation model between defects and performance, thereby refining passivation strategies. 

### **4.2. Enhance the Universality of Passivation Materials and Methods** 

With the progression of PSC industrialization, the evolution of passivation materials and methods should embrace enhanced versatility and broad universality. Many passivation materials and methods may undergo validation in large-scale production and 

gradually gain traction in industrial applications. While numerous passivation systems have been developed, further research and refinement are warranted. Large-area experimental screening and material simulation calculations can facilitate universality by identifying the most suitable passivation materials and methods for industrial implementation. Additionally, exploring the synergistic application of diverse passivation materials and methods holds the potential for achieving improved passivation effects. 

### **4.3. Develop Highly Stable Passivation Strategies** 

Investigating highly stable passivation strategies or materials is poised to assume a central focus. The stability of compatibility with crystalline silicon is the key to the successful industrialization of perovskite photovoltaics. Thus, it is imperative to undertake extensive long-term stability testing and material durability research, along with the exploration of novel passivation materials such as organic passivation agents, inorganic protective layers, and passivation films, while assessing their impact on the stability of perovskite materials. Furthermore, established passivation strategies can be bolstered by optimizing material composition and structural design to ensure the enduring reliability of industrial-grade perovskite photovoltaic products. 

**2401414 (18 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 

### **4.4. Ensure Uniformity in Large-Area Passivation** 

In the realm of large-area passivation, the careful selection of passivation materials and methods holds paramount significance for ensuring the uniformity of passivation layers. Regrettably, academic research in this domain remains scarce. Hence, future endeavors necessitate more comprehensive and systematic investigations into selecting passivation materials and methods tailored for large-scale passivation processes. Through comparative assessments of various materials and methods on the thickness and uniformity of passivation layers, the passivation process can be fine-tuned, and appropriate control strategies can be devised to tackle the complexities associated with large-area passivation. 

In conclusion, the advancement and application of perovskite photovoltaic technology necessitate comprehensive exploration and implementation in crystal growth, defect detection, and passivation technology to enhance the performance and stability of PSCs incessantly. These deliberations and recommendations are intended to foster the progress and utilization of perovskite photovoltaic technology and contribute to the realization of clean energy and sustainable development. 

## **Acknowledgements** 

J.W. and L.B. contributed equally to this work. A.K.Y.J. thanks the sponsorship of the Lee Shau-Kee Chair Professor (Materials Science), and the support from the APRC Grants (9380086, 9610419, 9610492, 9610508) of the City University of Hong Kong, the TCFS Grant (GHP/018/20SZ) and MRP Grant (MRP/040/21X) from the Innovation and Technology Commission of Hong Kong, the Green Tech Fund (202020164) from the Environment and Ecology Bureau of Hong Kong, the GRF grants (11307621, 11316422) from the Research Grants Council of Hong Kong, the Shenzhen Science and Technology Program (SGDX20201103095412040), and the Guangdong Major Project of Basic and Applied Basic Research (2019B030302007). 

## **Conflict of Interest** 

The authors declare no conflict of interest. 

## **Keywords** 

defect passivation, interface passivation, inverted, perovskite solar cells, perovskite solar modules 

Received: March 28, 2024 Revised: May 8, 2024 Published online: June 27, 2024 

D. Menzel, F. Lang, S. Keßler, I. Levine, D. Mantione, A. Al-Ashouri, M. S. Härtel, K. Xu, A. Cruz, J. Kurpiers, P. Wagner, H. Köbler, J. Li, A. Magomedov, D. Mecerreyes, E. Unger, A. Abate, M. Stolterfoht, B. Stannowski, R. Schlatmann, et al., _Science_ **2023** , _381_ , 63. 

   - [6] X. Y. Chin, D. Turkay, J. A. Steele, S. Tabean, S. Eswara, M. Mensi, P. Fiala, C. M. Wolff, A. Paracchino, K. Artuk, D. Jacobs, Q. Guesnay, F. Sahli, G. Andreatta, M. Boccard, Q. Jeangros, C. Ballif, _Science_ **2023** , _381_ , 59. 

   - [7] N. Phung, A. Al-Ashouri, S. Meloni, A. Mattoni, S. Albrecht, E. L. Unger, A. Merdasa, A. Abate, _Adv. Energy Mater._ **2020** , _10_ , 1903735. 

   - [8] D. Moia, J. Maier, _ACS Energy Lett._ **2021** , _6_ , 1566. 

   - [9] Q. Fu, H. Liu, X. Tang, R. Wang, M. Chen, Y. Liu, _ACS Energy Lett._ **2022** , _7_ , 1128. 

   - [10] Q. Fu, X. Tang, Y. Gao, H. Liu, M. Chen, R. Wang, Z. Song, Y. Yang, J. Wang, Y. Liu, _Small_ **2023** , _19_ , 2301175. 

   - [11] Y. Ren, D. Zhang, J. Suo, Y. Cao, F. T. Eickemeyer, N. Vlachopoulos, S. M. Zakeeruddin, A. Hagfeldt, M. Grätzel, _Nature_ **2023** , _613_ , 60. 

   - [12] Q. Tan, Z. Li, G. Luo, X. Zhang, B. Che, G. Chen, H. Gao, D. He, G. Ma, J. Wang, J. Xiu, H. Yi, T. Chen, Z. He, _Nature_ **2023** , _620_ , 545. 

   - [13] S. M. Park, M. Wei, N. Lempesis, W. Yu, T. Hossain, L. Agosta, V. Carnevali, H. R. Atapattu, P. Serles, F. T. Eickemeyer, H. Shin, M. Vafaie, D. Choi, K. Darabi, E. D. Jung, Y. Yang, D. B. Kim, S. M. Zakeeruddin, B. Chen, A. Amassian, T. Filleter, M. G. Kanatzidis, K. R. Graham, L. Xiao, U. Rothlisberger, M. Grätzel, E. H. Sargent, _Nature_ **2023** , _624_ , 289. 

   - [14] H. Chen, C. Liu, J. Xu, A. Maxwell, W. Zhou, Y. Yang, Q. Zhou, A. S. R. Bati, H. Wan, Z. Wang, L. Zeng, J. Wang, P. Serles, Y. Liu, S. Teale, Y. Liu, M. I. Saidaminov, M. Li, N. Rolston, S. Hoogland, T. Filleter, M. G. Kanatzidis, B. Chen, Z. Ning, E. H. Sargent, _Science_ **2024** , _384_ , 189. 

   - [15] S. Wu, Y. Yan, J. Yin, K. Jiang, F. Li, Z. Zeng, S.-W. Tsang, A. K. Y. Jen, _Nat. Energy_ **2023** , _9_ , 411. 

   - [16] R. Lin, Y. Wang, Q. Lu, B. Tang, J. Li, H. Gao, Y. Gao, H. Li, C. Ding, J. Wen, P. Wu, C. Liu, S. Zhao, K. Xiao, Z. Liu, C. Ma, Y. Deng, L. Li, F. Fan, H. Tan, _Nature_ **2023** , _620_ , 994. 

   - [17] H. Chen, S. Teale, B. Chen, Y. Hou, L. Grater, T. Zhu, K. Bertens, S. M. Park, H. R. Atapattu, Y. Gao, M. Wei, A. K. Johnston, Q. Zhou, K. Xu, D. Yu, C. Han, T. Cui, E. H. Jung, C. Zhou, W. Zhou, A. H. Proppe, S. Hoogland, F. Laquai, T. Filleter, K. R. Graham, Z. Ning, E. H. Sargent, _Nat. Photonics_ **2022** , _16_ , 352. 

   - [18] Y. Chen, H. Zhou, _J. Appl. Phys._ **2020** , _128_ , 060903. 

   - [19] L. Wang, H. Zhou, J. Hu, B. Huang, M. Sun, B. Dong, G. Zheng, Y. Huang, Y. Chen, L. Li, Z. Xu, N. Li, Z. Liu, Q. Chen, L.-D. Sun, C.-H. Yan, _Science_ **2019** , _363_ , 265. 

   - [20] A. R. Mohd Yusoff, M. Vasilopoulou, D. G. Georgiadou, L. C. Palilis, A. Abate, M. K. Nazeeruddin, _Energy Environ. Sci._ **2021** , _14_ , 2906. 

   - [21] S. Bera, A. Saha, S. Mondal, A. Biswas, S. Mallick, R. Chatterjee, S. Roy, _Adv. Mater._ **2022** , _3_ , 5234. 

   - [22] J. Min, Y. Choi, D. Kim, T. Park, _Adv. Energy Mater._ **2024** , _14_ , 2302659. 

   - [23] H. Zhang, J. Cheng, D. Li, F. Lin, J. Mao, C. Liang, A. K. Y. Jen, M. Grätzel, W. C. H. Choy, _Adv. Mater._ **2017** , _29_ , 1604695. 

   - [24] Y. Lei, Y. Xu, M. Wang, G. Zhu, Z. Jin, _Small_ **2021** , _17_ , 2005495. 

   - [25] S. Reichert, Q. An, Y.-W. Woo, A. Walsh, Y. Vaynzof, C. Deibel, _Nat. Commun._ **2020** , _11_ , 6098. 

- [1] Q. Fu, A. K. Y. Jen, _Next Energy_ **2023** , _1_ , 100004. 

> [2] J. Park, J. Kim, H.-S. Yun, M. J. Paik, E. Noh, H. J. Mun, M. G. Kim, T. J. Shin, S. I. Seok, _Nature_ **2023** , _616_ , 724. 

- [3] W. Zhao, P. Guo, J. Su, Z. Fang, N. Jia, C. Liu, L. Ye, Q. Ye, J. Chang, H. Wang, _Adv. Funct. Mater._ **2022** , _32_ , 2200534. 

> [4] Y. Zhou, L. M. Herz, A. K. Y. Jen, M. Saliba, _Nat. Energy_ **2022** , _7_ , 794. [5] S. Mariotti, E. Köhnen, F. Scheler, K. Sveinbjörnsson, L. Zimmermann, M. Piot, F. Yang, B. Li, J. Warby, A. Musiienko, 

- [26] B. Chen, P. N. Rudd, S. Yang, Y. Yuan, J. Huang, _Chem. Soc. Rev._ **2019** , _48_ , 3842. 

- [27] F. Li, T. W. Lo, X. Deng, S. Li, Y. Fan, F. R. Lin, Y. Cheng, Z. Zhu, D. Lei, A. K. Y. Jen, _Adv. Energy Mater._ **2022** , _12_ , 2200186. 

- [28] D.-J. Xue, Y. Hou, S.-C. Liu, M. Wei, B. Chen, Z. Huang, Z. Li, B. Sun, A. H. Proppe, Y. Dong, M. I. Saidaminov, S. O. Kelley, J.-S. Hu, E. H. Sargent, _Nat. Commun._ **2020** , _11_ , 1514. 

- [29] N. Jiang, G. Ma, D. Song, B. Qiao, Z. Liang, Z. Xu, S. Wageh, A. Al-Ghamdi, S. Zhao, _Nanoscale_ **2024** , _16_ , 3838. 

**2401414 (19 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

- [30] M. U. Rothmann, J. S. Kim, J. Borchert, K. B. Lohmann, C. M. O’Leary, A. A. Sheader, L. Clark, H. J. Snaith, M. B. Johnston, P. D. Nellist, L. M. Herz, _Science_ **2020** , _370_ , abb5940. 

- [31] W. S. Yang, B.-W. Park, E. H. Jung, N. J. Jeon, Y. C. Kim, D. U. Lee, S. S. Shin, J. Seo, E. K. Kim, J. H. Noh, S. I. Seok, _Science_ **2017** , _356_ , 1376. 

- [32] C. Li, A. Guerrero, S. Huettner, J. Bisquert, _Nat. Commun._ **2018** , _9_ , 5113. 

- [33] S. De Wolf, J. Holovsky, S.-J. Moon, P. Löper, B. Niesen, M. Ledinsky, F.-J. Haug, J.-H. Yum, C. Ballif, _J. Phys. Chem. Lett._ **2014** , _5_ , 1035. 

- [34] Z.-R. Lan, Y.-D. Wang, J.-Y. Shao, D.-X. Ma, Z. Liu, D. Li, Y. Hou, J. Yao, Y.-W. Zhong, _Adv. Funct. Mater._ **2024** , _34_ , 2312426. 

- [35] C. Bao, F. Gao, _Rep. Prog. Phys._ **2022** , _85_ , 096501. 

- [36] E. V. Péan, S. Dimitrov, C. S. De Castro, M. L. Davies, _Phys. Chem. Chem. Phys._ **2020** , _22_ , 28345. 

- [37] A. Vlk, Z. Remes, L. Landova, K. Ridzonova, R. Hlavac, A. Fejfar, M. Ledinsky, _J. Phys. Chem. Lett._ **2024** , _15_ , 1273. 

- [38] G. Greczynski, L. Hultman, _J. Appl. Phys._ **2022** , _132_ , 01101. 

- [39] H. Moosmüller, R. K. Chakrabarty, K. M. Ehlers, W. P. Arnott, _Atmos. Chem. Phys._ **2011** , _11_ , 1217. 

- [40] G. D. Cody, T. Tiedje, B. Abeles, B. Brooks, Y. Goldstein, _Phys. Rev. Lett._ **1981** , _47_ , 1480. 

- [41] Y. Cheng, X. Liu, Z. Guan, M. Li, Z. Zeng, H.-W. Li, S.-W. Tsang, A. G. Aberle, F. Lin, _Adv. Mater._ **2021** , _33_ , 2006170. 

- [42] S. Wang, P. Kaienburg, B. Klingebiel, D. Schillings, T. Kirchartz, _J. Phys. Chem. C_ **2018** , _122_ , 9795. 

- [43] Y. Chen, N. Li, L. Wang, L. Li, Z. Xu, H. Jiao, P. Liu, C. Zhu, H. Zai, M. Sun, W. Zou, S. Zhang, G. Xing, X. Liu, J. Wang, D. Li, B. Huang, Q. Chen, H. Zhou, _Nat. Commun._ **2019** , _10_ , 1112. 

- [44] Z. Ni, C. Bao, Y. Liu, Q. Jiang, W.-Q. Wu, S. Chen, X. Dai, B. Chen, B. Hartweg, Z. Yu, Z. Holman, J. Huang, _Science_ **2020** , _367_ , 1352. 

- [45] M. Sajedi Alvar, P. W. M. Blom, G.-J. A. H. Wetzelaer, _Nat. Commun._ **2020** , _11_ , 4023. 

- [46] C. M. Sutter-Fella, D. W. Miller, Q. P. Ngo, E. T. Roe, F. M. Toma, I. D. Sharp, M. C. Lonergan, A. Javey, _ACS Energy Lett._ **2017** , _2_ , 709. 

- [47] B. T. van Gorkom, T. P. A. van der Pol, K. Datta, M. M. Wienk, R. A. J. Janssen, _Nat. Commun._ **2022** , _13_ , 349. 

- [48] Y. Xu, P. R. Berger, _J. Appl. Phys._ **2004** , _95_ , 1497. 

- [49] A. Rose, _Phys. Rev._ **1955** , _97_ , 1538. 

- [50] G. T. Wright, _Nature_ **1958** , _182_ , 1296. 

- [51] E. A. Duijnstee, J. M. Ball, V. M. Le Corre, L. J. A. Koster, H. J. Snaith, J. Lim, _ACS Energy Lett._ **2020** , _5_ , 376. 

- [52] P. Caprioglio, M. Stolterfoht, C. M. Wolff, T. Unold, B. Rech, S. Albrecht, D. Neher, _Adv. Energy Mater._ **2019** , _9_ , 1901631. 

- [53] A. Kumar, S. K. Gupta, B. P. Dhamaniya, S. K. Pathak, S. Karak, _Mater. Today Energy_ **2023** , _37_ , 101400. 

- [54] D. Ompong, K. S. Ram, D. D. Y. Setsoafia, H. Mehdizadeh Rad, J. Singh, _Adv. Mater. Interfaces_ **2023** , _10_ , 2201578. 

- [55] K. Park, J.-H. Lee, J.-W. Lee, _ACS Energy Lett._ **2022** , _7_ , 1230. 

- [56] F. Gao, Y. Zhao, X. Zhang, J. You, _Adv. Energy Mater._ **2020** , _10_ , 1902650. 

- [57] D. B. Khadka, Y. Shirai, M. Yanagida, J. W. Ryan, K. Miyano, _J. Mater. Chem. C_ **2017** , _5_ , 8819. 

- [58] T. S. Sherkar, C. Momblona, L. Gil-Escrig, J. Ávila, M. Sessolo, H. J. Bolink, L. J. A. Koster, _ACS Energy Lett._ **2017** , _2_ , 1214. 

- [59] G. Landi, H. C. Neitzert, C. Barone, C. Mauro, F. Lang, S. Albrecht, B. Rech, S. Pagano, _Adv. Sci._ **2017** , _4_ , 1700183. 

- [60] L. Duan, A. Uddin, _Mater. Chem. Front._ **2022** , _6_ , 400. 

- [61] C. Eames, J. M. Frost, P. R. F. Barnes, B. C. O’Regan, A. Walsh, M. S. Islam, _Nat. Commun._ **2015** , _6_ , 7497. 

- [62] D. Meggiolaro, E. Mosconi, F. De Angelis, _ACS Energy Lett._ **2019** , _4_ , 779. 

- [63] N. Ahn, K. Kwak, M. S. Jang, H. Yoon, B. Y. Lee, J.-K. Lee, P. V. Pikhitsa, J. Byun, M. Choi, _Nat. Commun._ **2016** , _7_ , 13422. 

**www.advenergymat.de** 

- [64] N. Aristidou, C. Eames, I. Sanchez-Molina, X. Bu, J. Kosco, M. S. Islam, S. A. Haque, _Nat. Commun._ **2017** , _8_ , 15218. 

- [65] N. Aristidou, I. Sanchez-Molina, T. Chotchuangchutchaval, M. Brown, L. Martinez, T. Rath, S. A. Haque, _Angew. Chem., Int. Ed._ **2015** , _54_ , 8208. 

- [66] F. Li, A. K. Y. Jen, _Acc. Mater. Res._ **2022** , _3_ , 272. 

- [67] X. Ji, L. Bi, Q. Fu, B. Li, J. Wang, S. Y. Jeong, K. Feng, S. Ma, Q. Liao, F. R. Lin, H. Y. Woo, L. Lu, A. K. Y. Jen, X. Guo, _Adv. Mater._ **2023** , _35_ , 2303665. 

- [68] M. Liu, M. Li, Y. Li, Y. An, Z. Yao, B. Fan, F. Qi, K. Liu, H.-L. Yip, F. R. Lin, A. K. Y. Jen, _Adv. Energy Mater._ **2024** , _14_ , 2303742. 

- [69] X. Sun, Z. Li, X. Yu, X. Wu, C. Zhong, D. Liu, D. Lei, A. K. Y. Jen, Z. Li, Z. Zhu, _Angew. Chem., Int. Ed._ **2021** , _60_ , 7227. 

- [70] X. Wu, D. Gao, X. Sun, S. Zhang, Q. Wang, B. Li, Z. Li, M. Qin, X. Jiang, C. Zhang, Z. Li, X. Lu, N. Li, S. Xiao, X. Zhong, S. Yang, Z. Li, Z. Zhu, _Adv. Mater._ **2023** , _35_ , 2208431. 

- [71] Z. Li, X. Sun, X. Zheng, B. Li, D. Gao, S. Zhang, X. Wu, S. Li, J. Gong, J. M. Luther, Z. Li, Z. Zhu, _Science_ **2023** , _382_ , 284. 

- [72] N. Yan, Z. Fang, Z. Dai, J. Feng, S. Liu, _Adv. Funct. Mater._ **2024** , _34_ , 2314039. 

- [73] H. Zhang, H. Wang, H. Zhu, C.-C. Chueh, W. Chen, S. Yang, A. K. Y. Jen, _Adv. Energy Mater._ **2018** , _8_ , 1702762. 

- [74] Y. Yao, C. Cheng, C. Zhang, H. Hu, K. Wang, S. De Wolf, _Adv. Mater._ **2022** , _34_ , 2203794. 

- [75] M. Li, M. Liu, F. Qi, F. R. Lin, A. K. Y. Jen, _Chem. Rev._ **2024** , _124_ , 2138. 

- [76] M. Liu, L. Bi, W. Jiang, Z. Zeng, S.-W. Tsang, F. R. Lin, A. K. Y. Jen, _Adv. Mater._ **2023** , _35_ , 2304415. 

- [77] X. Deng, F. Qi, F. Li, S. Wu, F. R. Lin, Z. Zhang, Z. Guan, Z. Yang, C.-S. Lee, A. K. Y. Jen, _Angew. Chem., Int. Ed._ **2022** , _61_ , 202203088. 

- [78] W. Jiang, F. Li, M. Li, F. Qi, F. R. Lin, A. K. Y. Jen, _Angew. Chem., Int. Ed._ **2022** , _134_ , 202213560. 

- [79] W. Jiang, M. Liu, Y. Li, F. R. Lin, A. K. Y. Jen, _Chem. Sci._ **2024** , _15_ , 2778. 

- [80] A. Ullah, K. H. Park, H. D. Nguyen, Y. Siddique, S. F. A. Shah, H. Tran, S. Park, S. I. Lee, K.-K. Lee, C.-H. Han, K. Kim, S. Ahn, I. Jeong, Y. S. Park, S. Hong, _Adv. Energy Mater._ **2022** , _12_ , 2103175. 

- [81] S. Zhang, F. Ye, X. Wang, R. Chen, H. Zhang, L. Zhan, X. Jiang, Y. Li, X. Ji, S. Liu, M. Yu, F. Yu, Y. Zhang, R. Wu, Z. Liu, Z. Ning, D. Neher, L. Han, Y. Lin, H. Tian, W. Chen, M. Stolterfoht, L. Zhang, W.-H. Zhu, Y. Wu, _Science_ **2023** , _380_ , 404. 

- [82] S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K. Y. Jen, _Joule_ **2020** , _4_ , 1248. 

- [83] Y. Ma, J. Gong, P. Zeng, M. Liu, _Nano-Micro Lett._ **2023** , _15_ , 173. 

- [84] Q. Zhou, J. Qiu, Y. Wang, M. Yu, J. Liu, X. Zhang, _ACS Energy Lett._ **2021** , _6_ , 1596. 

- [85] H. Li, C. Zhang, C. Gong, D. Zhang, H. Zhang, Q. Zhuang, X. Yu, S. Gong, X. Chen, J. Yang, X. Li, R. Li, J. Li, J. Zhou, H. Yang, Q. Lin, J. Chu, M. Grätzel, J. Chen, Z. Zang, _Nat. Energy_ **2023** , _8_ , 946. 

- [86] J. Li, L. Zuo, H. Wu, B. Niu, S. Shan, G. Wu, H. Chen, _Adv. Funct. Mater._ **2021** , _31_ , 2104036. 

- [87] S. Hu, K. Otsuka, R. Murdey, T. Nakamura, M. A. Truong, T. Yamada, T. Handa, K. Matsuda, K. Nakano, A. Sato, K. Marumoto, K. Tajima, Y. Kanemitsu, A. Wakamiya, _Energy Environ. Sci._ **2022** , _15_ , 2096. 

- [88] Q. Cao, T. Wang, X. Pu, X. He, M. Xiao, H. Chen, L. Zhuang, Q. Wei, H.-L. Loi, P. Guo, B. Kang, G. Feng, J. Zhuang, G. Feng, X. Li, F. Yan, _Adv. Mater._ **2024** , _36_ , 2311970. 

- [89] S. Wang, D. Khan, W. Zhou, Y. Sui, T. Zhang, G. Yu, Y. Huang, X. Yang, X. Chen, H. Yan, J. Tang, F. Yang, P. Han, Z. Zheng, Y. Zhang, Z. Tang, _Adv. Funct. Mater._ **2024** , 2316202. 

- [90] A. Hassan, Z. Wang, Y. H. Ahn, M. Azam, A. A. Khan, U. Farooq, M. Zubair, Y. Cao, _Nano Energy_ **2022** , _101_ , 107579. 

- [91] Y. Shen, G. Xu, J. Li, X. Lin, F. Yang, H. Yang, W. Chen, Y. Wu, X. Wu, Q. Cheng, J. Zhu, Y. Li, Y. Li, _Angew. Chem., Int. Ed._ **2023** , _62_ , 202300690. 

**2401414 (20 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

**www.advenergymat.de** 



**www.advancedsciencenews.com** 

- [92] F. Li, X. Deng, Z. Shi, S. Wu, Z. Zeng, D. Wang, Y. Li, F. Qi, Z. Zhang, Z. Yang, S.-H. Jang, F. R. Lin, S. W. Tsang, X.-K. Chen, A. K. Y. Jen, _Nat. Photonics_ **2023** , _17_ , 478. 

- [93] L. Bi, Q. Fu, Z. Zeng, Y. Wang, F. R. Lin, Y. Cheng, H.-L. Yip, S. W. Tsang, A. K. Y. Jen, _J. Am. Chem. Soc._ **2023** , _145_ , 5920. 

- [94] S. Wu, J. Zhang, M. Qin, F. Li, X. Deng, X. Lu, W.-J. Li, A. K. Y. Jen, _Small_ **2023** , _19_ , 2207189. 

- [95] Q. Chen, H. Zhou, T.-B. Song, S. Luo, Z. Hong, H.-S. Duan, L. Dou, Y. Liu, Y. Yang, _Nano Lett._ **2014** , _14_ , 4158. 

- [96] D.-Y. Son, S.-G. Kim, J.-Y. Seo, S.-H. Lee, H. Shin, D. Lee, N.-G. Park, _J. Am. Chem. Soc._ **2018** , _140_ , 1358. 

- [97] N. Li, Z. Zhu, C.-C. Chueh, H. Liu, B. Peng, A. Petrone, X. Li, L. Wang, A. K. Y. Jen, _Adv. Energy Mater._ **2017** , _7_ , 1601307. 

- [98] Q. Cao, Y. Li, H. Zhang, J. Yang, J. Han, T. Xu, S. Wang, Z. Wang, B. Gao, J. Zhao, X. Li, X. Ma, S. M. Zakeeruddin, W. E. I. Sha, X. Li, M. Grätzel, _Sci. Adv. 7_ , abg0633. 

- [99] X. Pu, Q. Cao, X. He, J. Su, W. Wang, X. Zhang, D. Wang, Y. Zhang, J. Yang, T. Wang, H. Chen, L. Jiang, Y. Yan, X. Chen, X. Li, _Adv. Energy Mater._ **2024** , _14_ , 2303972. 

- [100] Q. Jiang, Z. Chu, P. Wang, X. Yang, H. Liu, Y. Wang, Z. Yin, J. Wu, X. Zhang, J. You, _Adv. Mater._ **2017** , _29_ , 1703852. 

- [101] D.-Y. Son, J.-W. Lee, Y. J. Choi, I.-H. Jang, S. Lee, P. J. Yoo, H. Shin, N. Ahn, M. Choi, D. Kim, N.-G., Park, _Nat. Energy_ **2016** , _1_ , 16081. 

- [102] Y. Zhao, F. Ma, Z. Qu, S. Yu, T. Shen, H.-X. Deng, X. Chu, X. Peng, Y. Yuan, X. Zhang, J. You, _Science_ **2022** , _377_ , 531. 

- [103] C. Bi, X. Zheng, B. Chen, H. Wei, J. Huang, _ACS Energy Lett._ **2017** , _2_ , 1400. 

- [104] M. Abdi-Jalebi, Z. Andaji-Garmaroudi, S. Cacovich, C. Stavrakas, B. Philippe, J. M. Richter, M. Alsari, E. P. Booker, E. M. Hutter, A. J. Pearson, S. Lilliu, T. J. Savenije, H. Rensmo, G. Divitini, C. Ducati, R. H. Friend, S. D. Stranks, _Nature_ **2018** , _555_ , 497. 

- [105] T. Bu, X. Liu, Y. Zhou, J. Yi, X. Huang, L. Luo, J. Xiao, Z. Ku, Y. Peng, F. Huang, Y.-B. Cheng, J. Zhong, _Energy Environ. Sci._ **2017** , _10_ , 2509. 

- [106] X. Gong, L. Guan, H. Pan, Q. Sun, X. Zhao, H. Li, H. Pan, Y. Shen, Y. Shao, L. Sun, Z. Cui, L. Ding, M. Wang, _Adv. Funct. Mater._ **2018** , _28_ , 1804286. 

- [107] J. T.-W. Wang, Z. Wang, S. Pathak, W. Zhang, D. W. deQuilettes, F. Wisnivesky-Rocca-Rivarola, J. Huang, P. K. Nayak, J. B. Patel, H. A. Mohd Yusof, Y. Vaynzof, R. Zhu, I. Ramirez, J. Zhang, C. Ducati, C. Grovenor, M. B. Johnston, D. S. Ginger, R. J. Nicholas, H. J. Snaith, _Energy Environ. Sci._ **2016** , _9_ , 2892. 

- [108] J. W. Lee, Z. Dai, T. H. Han, C. Choi, S. Y. Chang, S. J. Lee, N. De Marco, H. Zhao, P. Sun, Y. Huang, Y. Yang, _Nat. Commun._ **2018** , _9_ , 3021. 

- [109] T. Liu, J. Guo, D. Lu, Z. Xu, Q. Fu, N. Zheng, Z. Xie, X. Wan, X. Zhang, Y. Liu, Y. Chen, _ACS Nano_ **2021** , _15_ , 7811. 

- [110] T. Zhou, Z. Xu, R. Wang, X. Dong, Q. Fu, Y. Liu, _Adv. Mater._ **2022** , _34_ , 2200705. 

- [111] Y. Zou, Y. Gao, Y. Liu, _Mater. Chem. Front._ **2024** , _8_ , 82. 

- [112] Z. Wang, Q. Lin, F. P. Chmiel, N. Sakai, L. M. Herz, H. J. Snaith, _Nat. Energy_ **2017** , _2_ , 17135. 

- [113] P. Li, Y. Zhang, C. Liang, G. Xing, X. Liu, F. Li, X. Liu, X. Hu, G. Shao, Y. Song, _Adv. Mater._ **2018** , _30_ , 1805323. 

- [114] N. Li, S. Tao, Y. Chen, X. Niu, C. K. Onwudinanti, C. Hu, Z. Qiu, Z. Xu, G. Zheng, L. Wang, Y. Zhang, L. Li, H. Liu, Y. Lun, J. Hong, X. Wang, Y. Liu, H. Xie, Y. Gao, Y. Bai, S. Yang, G. Brocks, Q. Chen, H. Zhou, _Nat. Energy_ **2019** , _4_ , 408. 

- [115] G. Y. Kim, S. H. Oh, B. P. Nguyen, W. Jo, B. J. Kim, D. G. Lee, H. S. Jung, _J. Phys. Chem. Lett._ **2015** , _6_ , 2355. 

- [116] F. X. Xie, C. C. Chen, Y. Z. Wu, X. Li, M. L. Cai, X. Liu, X. D. Yang, L. Y. Han, _Energy Environ. Sci._ **2017** , _10_ , 1942. 

- [117] M. M. Tavakoli, P. Yadav, D. Prochowicz, M. Sponseller, A. Osherov, V. Bulovi´c, J. Kong, _Adv. Energy Mater._ **2019** , _9_ , 1803587. 

- [118] A. Abate, M. Saliba, D. J. Hollman, S. D. Stranks, K. Wojciechowski, R. Avolio, G. Grancini, A. Petrozza, H. J. Snaith, _Nano Lett._ **2014** , _14_ , 3247. 

- [119] W. Ke, C. Xiao, C. Wang, B. Saparov, H.-S. Duan, D. Zhao, Z. Xiao, P. Schulz, S. P. Harvey, W. Liao, W. Meng, Y. Yu, A. J. Cimaroli, C.-S. Jiang, K. Zhu, M. Al-Jassim, G. Fang, D. B. Mitzi, Y. Yan, _Adv. Mater._ **2016** , _28_ , 5214. 

- [120] W.-J. Yin, H. Chen, T. Shi, S.-H. Wei, Y. Yan, _Adv. Electron. Mater._ **2015** , _1_ , 1500044. 

- [121] F. Gao, Y. Zhao, X. Zhang, J. You, _Adv. Energy Mater._ **2020** , _10_ , 1902650. 

- [122] L. Jia, M. Chen, S. Yang, _Mater. Chem. Front._ **2020** , _4_ , 2256. 

- [123] C. Liu, W. Li, H. Li, C. Zhang, J. Fan, Y. Mai, _Nanoscale_ **2017** , _9_ , 13967. 

- [124] K. Wang, C. Liu, P. Du, J. Zheng, X. Gong, _Energy Environ. Sci._ **2015** , _8_ , 1245. 

- [125] J. Guo, B. Wang, D. Lu, T. Wang, T. Liu, R. Wang, X. Dong, T. Zhou, N. Zheng, Q. Fu, Z. Xie, X. Wan, G. Xing, Y. Chen, Y. Liu, _Adv. Mater._ **2023** , _35_ , 2212126. 

- [126] X. Liu, J. Wu, Y. Yang, T. Wu, Q. Guo, _J. Power Sources_ **2018** , _399_ , 144. 

- [127] G. Grancini, C. Roldan-Carmona, I. Zimmermann, E. Mosconi, X. Lee, D. Martineau, S. Narbey, F. Oswald, F. De Angelis, M. Graetzel, M. K. Nazeeruddin, _Nat. Commun._ **2017** , _8_ , 15684. 

- [128] N. J. Jeon, J. H. Noh, Y. C. Kim, W. S. Yang, S. Ryu, S. I. Seok, _Nat. Mater._ **2014** , _13_ , 897. 

- [129] Y. Lv, H. Zhang, J. Wang, L. Chen, L. Bian, Z. An, Z. Qian, G. Ren, J. Wu, F. Nüesch, W. Huang, _Research_ **2020** , _2020_ , 2763409. 

- [130] Q. Sun, B. Tuo, Z. Ren, T. Xue, Y. Zhang, J. Ma, P. Li, Y. Song, _Adv. Funct. Mater._ **2022** , _32_ , 2208885. 

- [131] M. Sun, F. Zhang, H. Liu, X. Li, Y. Xiao, S. Wang, _J. Mater. Chem. A_ **2017** , _5_ , 13448. 

- [132] S. Bai, P. Da, C. Li, Z. Wang, Z. Yuan, F. Fu, M. Kawecki, X. Liu, N. Sakai, J. T.-W. Wang, S. Huettner, S. Buecheler, M. Fahlman, F. Gao, H. J. Snaith, _Nature_ **2019** , _571_ , 245. 

- [133] X. Jiang, X. Wang, X. Wu, S. Zhang, B. Liu, D. Zhang, B. Li, P. Xiao, F. Xu, H. Lu, T. Chen, A. K. Y. Jen, S. Yang, Z. Zhu, _Adv. Energy Mater._ **2023** , _13_ , 2300700. 

- [134] X. Rui, G. Xiao-Xin, Z. Yi, D. Nikita, I. E. Q. Valentin, T. Farzaneh Fadaei, S. Rosario, H. Zhangjun, F. Xiaodong, K. Sachin, F. Zhaofu, R.-C. Cristina, N. Mohammad Khaja, J. D. Paul, _Adv. Mater._ **2020** , _32_ , 2003801. 

- [135] H. Lai, X. Tang, L. Bi, B. Tian, H. Wang, X. Ji, Q. Fu, _Sol. RRL_ **2023** , _8_ , 2300961. 

- [136] Q. Fu, H. Liu, S. Li, T. Zhou, M. Chen, Y. Yang, J. Wang, R. Wang, Y. Chen, Y. Liu, _Angew. Chem., Int. Ed._ **2022** , _61_ , 202210356. 

- [137] L. Zuo, H. Guo, D. W. deQuilettes, S. Jariwala, N. De Marco, S. Dong, R. DeBlock, D. S. Ginger, B. Dunn, M. Wang, Y. Yang, _Sci. Adv._ **2017** , _3_ , 1700106. 

- [138] M. M. Byranvand, M. Saliba, _Sol. RRL_ **2021** , _5_ , 2100295. 

- [139] F. Ye, S. Zhang, J. Warby, J. Wu, E. Gutierrez-Partida, F. Lang, S. Shah, E. Saglamkaya, B. Sun, F. Zu, S. Shoaee, H. Wang, B. Stiller, D. Neher, W.-H. Zhu, M. Stolterfoht, Y. Wu, _Nat. Commun._ **2022** , _13_ , 7454. 

- [140] F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S.-H. Jang, J. Zhang, X. Lu, D. Lei, C.-S. Lee, Z. Zhu, A. K. Y. Jen, _J. Am. Chem. Soc._ **2020** , _142_ , 20134. 

- [141] T. Wang, L. Bi, L. Yang, Z. Zeng, X. Ji, Z. Hu, S.-W. Tsang, H.L. Yip, Q. Fu, A. K. Y. Jen, Y. Liu, _J. Am. Chem. Soc._ **2024** , _146_ , 7555. 

- [142] R. Azmi, E. Ugur, A. Seitkhan, F. Aljamaan, A. S. Subbiah, J. Liu, G. T. Harrison, M. I. Nugraha, M. K. Eswaran, M. Babics, Y. Chen, F. Xu, T. G. Allen, A. Rehman, C.-L. Wang, T. D. Anthopoulos, U. Schwingenschlögl, M. De Bastiani, E. Aydin, S. De Wolf, _Science_ **2022** , _376_ , 73. 

**2401414 (21 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

- [143] Z. Liu, H. Li, Z. Chu, R. Xia, J. Wen, Y. Mo, H. Zhu, H. Luo, X. Zheng, Z. Huang, X. Luo, B. Wang, X. Zhang, G. Yang, Z. Feng, Y. Chen, W. Kong, J. Gao, H. Tan, _Adv. Mater._ **2024** , _36_ , 2308370. 

- [144] X. Fang, J. Ding, N. Yuan, P. Sun, M. Lv, G. Ding, C. Zhu, _Phys. Chem. Chem. Phys._ **2017** , _19_ , 6057. 

- [145] Y. Shao, Z. Xiao, C. Bi, Y. Yuan, J. Huang, _Nat. Commun._ **2014** , _5_ , 5784. 

- [146] P.-W. Liang, C.-C. Chueh, S. T. Williams, A. K. Y. Jen, _Adv. Energy Mater._ **2015** , _5_ , 1402321. 

- [147] H. Zhang, F. Wang, B. Li, M. Sun, K. Li, H. Wang, K. Y. J. Alex, _ACS Energy Lett._ **2024** , _9_ , 176. 

- [148] T. Zheng, B. Fan, Y. Zhao, B. Jin, L. Fan, R. Peng, _Chem. Eng. J._ **2021** , _420_ , 129730. 

- [149] H. Uratani, K. Yamashita, _J. Phys. Chem. Lett._ **2017** , _8_ , 742. [150] N. Liu, C. Yam, _Phys. Chem. Chem. Phys._ **2018** , _20_ , 6800. 

- [151] B. Li, X. Wu, H. Zhang, S. Zhang, Z. Li, D. Gao, C. Zhang, M. Chen, S. Xiao, A. K. Y. Jen, S. Yang, Z. Zhu, _Adv. Funct. Mater._ **2022** , _32_ , 2205870. 

- [152] D. B. Khadka, Y. Shirai, M. Yanagida, H. Ota, A. Lyalin, T. Taketsugu, K. Miyano, _Nat. Commun._ **2024** , _15_ , 882. 

- [153] X. Zheng, B. Chen, J. Dai, Y. Fang, Y. Bai, Y. Lin, H. Wei, X. C. Zeng, J. Huang, _Nat. Energy_ **2017** , _2_ , 17102. 

- [154] M. Zhang, Q. Chen, R. Xue, Y. Zhan, C. Wang, J. Lai, J. Yang, H. Lin, J. Yao, Y. Li, L. Chen, Y. Li, _Nat. Commun._ **2019** , _10_ , 4593. 

- [155] Q. Fu, M. Chen, Q. Li, H. Liu, R. Wang, Y. Liu, _J. Am. Chem. Soc._ **2023** , _145_ , 21687. 

- [156] R. Wang, X. Dong, Q. Ling, Q. Fu, Z. Hu, Z. Xu, H. Zhang, Q. Li, Y. Liu, _ACS Energy Lett._ **2022** , _7_ , 3656. 

- [157] Y. Lin, Y. Bai, Y. Fang, Z. Chen, S. Yang, X. Zheng, S. Tang, Y. Liu, J. Zhao, J. Huang, _J. Phys. Chem. Lett._ **2018** , _9_ , 654. 

- [158] Y. Lin, Y. Bai, Y. Fang, Q. Wang, Y. Deng, J. Huang, _ACS Energy Lett._ **2017** , _2_ , 1571. 

- [159] M. A. Mahmud, H. T. Pham, T. Duong, Y. Yin, J. Peng, Y. Wu, W. Liang, L. Li, A. Kumar, H. Shen, D. Walter, H. T. Nguyen, N. Mozaffari, G. D. Tabi, G. Andersson, K. R. Catchpole, K. J. Weber, T. P. White, _Adv. Funct. Mater._ **2021** , _31_ , 2104251. 

- [160] Z. Huang, A. H. Proppe, H. Tan, M. I. Saidaminov, F. Tan, A. Mei, C.-S. Tan, M. Wei, Y. Hou, H. Han, S. O. Kelley, E. H. Sargent, _ACS Energy Lett._ **2019** , _4_ , 1521. 

- [161] M. A. Mahmud, J. Zheng, S. Tang, G. Wang, J. Bing, A. D. Bui, J. Qu, L. Yang, C. Liao, H. Chen, S. P. Bremner, H. T. Nguyen, J. Cairney, A. W. Y. Ho-Baillie, _Adv. Energy Mater._ **2022** , _12_ , 2201672. 

- [162] C. Liu, Y. Yang, H. Chen, J. Xu, A. Liu, A. S. R. Bati, H. Zhu, L. Grater, S. S. Hadke, C. Huang, V. K. Sangwan, T. Cai, D. Shin, L. X. Chen, M. C. Hersam, C. A. Mirkin, B. Chen, M. G. Kanatzidis, E. H. Sargent, _Science_ **2023** , _382_ , 810. 

- [163] Y. Ma, F. Li, J. Gong, L. Wang, X. Tang, P. Zeng, P. F. Chan, W. Zhu, C. Zhang, M. Liu, _Energy Environ. Sci._ **2024** , _17_ , 1570. 

- [164] Y. Huang, K. Yan, B. Niu, Z. Chen, E. Gu, H. Liu, B. Yan, J. Yao, H. Zhu, H. Chen, C.-Z. Li, _Energy Environ. Sci._ **2023** , _16_ , 557. 

- [165] Y. Zhang, Y. Wang, L. Zhao, X. Yang, C.-H. Hou, J. Wu, R. Su, S. Jia, J.-J. Shyue, D. Luo, P. Chen, M. Yu, Q. Li, L. Li, Q. Gong, R. Zhu, _Energy Environ. Sci._ **2021** , _14_ , 6526. 

### **www.advenergymat.de** 

- [166] H. Li, G. Xie, X. Wang, S. Li, D. Lin, J. Fang, D. Wang, W. Huang, L. Qiu, _Adv. Sci._ **2023** , _10_ , 2300586. 

- [167] S. Zhou, S. Fu, C. Wang, W. Meng, J. Zhou, Y. Zou, Q. Lin, L. Huang, W. Zhang, G. Zeng, D. Pu, H. Guan, C. Wang, K. Dong, H. Cui, S. Wang, T. Wang, G. Fang, W. Ke, _Nature_ **2023** , _624_ , 69. 

- [168] X. Liu, Z. Yu, T. Wang, K. L. Chiu, F. Lin, H. Gong, L. Ding, Y. Cheng, _Adv. Energy Mater._ **2020** , _10_ , 2001958. 

- [169] M. Degani, Q. An, M. Albaladejo-Siguan, Y. J. Hofstetter, C. Cho, F. Paulus, G. Grancini, Y. Vaynzof, _Sci. Adv._ **2021** , _7_ , abj7930. 

- [170] X. Zhou, X. Luan, L. Zhang, H. Hu, Z. Jiang, Y. Li, J. Wu, Y. Liu, J. Chen, D. Wang, C. Liu, S. Chen, Y. Zhang, M. Zhang, Y. Peng, P. A. Troshin, X. Wang, Y. Mai, B. Xu, _ACS Nano_ **2023** , _17_ , 3776. 

- [171] Y. Zheng, C. Tian, X. Wu, A. Sun, R. Zhuang, C. Tang, Y. Liu, Z. Li, B. Ouyang, J. Du, Z. Li, X. Wu, J. Chen, J. Cai, C.-C. Chen, _Adv. Energy Mater._ **2024** , _14_ , 2304486. 

- [172] J. B. Whitaker, D. H. Kim, B. W. Larson, F. Zhang, J. J. Berry, M. F. A. M. van Hest, K. Zhu, _Sustainable Energy Fuels_ **2018** , _2_ , 2442. 

- [173] J. Zhuang, C. Liu, B. Kang, H. Cheng, M. Xiao, L. Li, F. Yan, _Adv. Mater._ **2024** , _36_ , 2309869. 

- [174] Z. Li, P. Li, G. Chen, Y. Cheng, X. Pi, X. Yu, D. Yang, L. Han, Y. Zhang, Y. Song, _ACS Appl. Mater. Interfaces_ **2020** , _12_ , 39082. 

- [175] H. Min, J. Hu, Z. Xu, T. Liu, S.-U.-Z. Khan, K. Roh, Y.-L. Loo, B. P. Rand, _Adv. Mater._ **2022** , _34_ , 2205309. 

- [176] E. A. Ramírez, J. P. Velásquez, A. Flórez, J. F. Montoya, R. Betancur, F. Jaramillo, _Adv. Eng. Mater._ **2023** , _25_ , 2200964. 

- [177] L. Gu, F. Fei, Y. Xu, S. Wang, N. Yuan, J. Ding, _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 2949. 

- [178] J. Zeng, L. Bi, Y. Cheng, B. Xu, A. K. Y. Jen, _Nano Res. Energy_ **2022** , _1_ , 9120004. 

- [179] X. Sun, Y. Li, D. Liu, R. Liu, B. Zhang, Q. Tian, B. Fan, X. Wang, Z. Li, Z. Shao, X. Wang, G. Cui, S. Pang, _Adv. Energy Mater._ **2023** , _13_ , 2302191. 

- [180] X. Zhang, W. Qiu, S. Apergi, S. Singh, P. Marchezi, W. Song, C. Sternemann, K. Elkhouly, D. Zhang, A. Aguirre, T. Merckx, A. Krishna, Y. Shi, A. Bracesco, C. van Helvoirt, F. Bens, V. Zardetto, J. D’Haen, A. Yu, G. Brocks, T. Aernouts, E. Moons, S. Tao, Y. Zhan, Y. Kuang, J. Poortmans, _ACS Energy Lett._ **2023** , _8_ , 2532. 

- [181] K. Zhang, Y. Wang, M. Tao, L. Guo, Y. Yang, J. Shao, Y. Zhang, F. Wang, Y. Song, _Adv. Mater._ **2023** , _35_ , 2211593. 

- [182] H. Liu, K. Yan, J. Rao, Z. Chen, B. Niu, Y. Huang, H. Ju, B. Yan, J. Yao, H. Zhu, H. Chen, C.-Z. Li, _ACS Appl. Mater. Interfaces_ **2022** , _14_ , 6794. 

- [183] T. Lei, X. Jie, J. Chen, X. Zhu, B. Jiao, Z. Wu, _Org. Electron._ **2020** , _87_ , 105937. 

- [184] Y. Zhu, P. Lv, M. Hu, S. R. Raga, H. Yin, Y. Zhang, Z. An, Q. Zhu, G. Luo, W. Li, F. Huang, M. Lira-Cantu, Y.-B. Cheng, J. Lu, _Adv. Energy Mater._ **2023** , _13_ , 2203681. 

- [185] D. H. Kim, J. B. Whitaker, Z. Li, M. F. van Hest, K. Zhu, _Joule_ **2018** , _2_ , 1437. 

- [186] Y. Yang, C. Liu, Y. Ding, B. Ding, J. Xu, A. Liu, J. Yu, L. Grater, H. Zhu, S. S. Hadke, V. K. Sangwan, A. S. R. Bati, X. Hu, J. Li, S. M. Park, M. C. Hersam, B. Chen, M. K. Nazeeruddin, M. G. Kanatzidis, E. H. Sargent, _Nat. Energy_ **2024** , _9_ , 316. 

**2401414 (22 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 



**www.advancedsciencenews.com** 

### **www.advenergymat.de** 









|**JiarongWang**receivedherB.S.degreein2020fromJinanUniversityandherM.S.degreein2023<br>fromSouthChinaUniversityofTechnology.ShehasbeenaPh.D.studentunderthesupervisionof<br>Prof.AlexJenattheCityUniversityofHongKongsince2023.Herresearchismainlyfocusedonhigh-<br>performanceperovskitesolarcellsandmodules.|
|---|
|**LeyuBi**receivedhisB.S.degreein2016andM.S.degreein2019fromtheXi’anJiaotongUniversity.He<br>hasbeenaPh.D.studentunderthesupervisionofProf.AlexJenattheCityUniversityofHongKong<br>since2021.Hisresearchismainlyfocusedonnucleation,insitudetectionofperovskitefilm,and<br>materialdevelopmentforinterfacemodificationofperovskitesolarcellsandmodules.|
|**QiangFu**receivedhisB.S.in2016fromLanzhouUniversityandhisPh.D.in2021fromNankaiUni-<br>versity.HeworkedasapostdoctorinProfYongshengLiuandYongshengChen’sgroupsatNankai<br>Universityfrom2021to2022.HestartedhissecondpostdoctorinProfAlexJen’sgroupattheCityUni-<br>versityofHongKongin2022.Hisresearchismainlyfocusedonsolar-energyconversion,including<br>advancedenergymaterials,perovskitesolarcellsandmodules.|
|**AlexK.-Y.Jen**istheLeeShauKeeChairProfessorattheCityUniversityofHongKong.Healsoserved<br>astheProvostofCityUduring2016–2020.PriortoCityU,heservedastheBoeing-JohnsonChairPro-<br>fessorandChairoftheDepartmentofMaterialsScience&EngineeringattheUniversityofWashing-<br>ton,Seattle.Hehaspublishedover1000papers,with≈92,000citationsandanh-indexof155.Heis<br>alsoaco-inventorof65patentsandinventiondisclosures.Duetohissignificantcontributionstoor-<br>ganic/hybridfunctionalmaterialsanddevices,hewaselectedasafellowoftheEuropeanAcademy<br>ofSciencesandWashingtonStateAcademyofSciences.Heisalsoafellowofseveralprofessional<br>societies,includingAAAS,MRS,ACS,PMSE,OSA,andSPIE.|



**2401414 (23 of 23)** 

_Adv. Energy Mater._ **2024** , _14_ , 2401414 

© 2024 The Author(s). Advanced Energy Materials published by Wiley-VCH GmbH 

