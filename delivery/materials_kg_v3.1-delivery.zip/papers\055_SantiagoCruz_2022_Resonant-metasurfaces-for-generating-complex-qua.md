# Resonant metasurfaces for generating complex quantum states

| 字段 | 内容 |
|---|---|
| 期刊 | Science |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 318 |
| 作者 | T. Santiago-Cruz, Sylvain D. Gennaro, O. Mitrofanov, S. Addamane, J. Reno, I. Brener, M. Chekhova |
| DOI | 10.1126/science.abq8684 |
| 源文件 | 055_SantiagoCruz_2022_Resonant-metasurfaces-for-generating-complex-qua.pdf |

---
# **Resonant Semiconductor Metasurfaces for Generating Complex Quantum States** 

**Authors:** Tomás Santiago-Cruz<sup>1,2</sup> *, Sylvain D. Gennaro<sup>3,4</sup> , Oleg Mitrofanov<sup>3,5</sup> , Sadhvikas Addamane<sup>3,4</sup> , John Reno<sup>3,4</sup> , Igal Brener<sup>3,4</sup> , and Maria V. Chekhova<sup>1,2</sup> 

**Affiliations:** 

1Max Planck Institute for the Science of Light; Staudtstraße 2, 91058 Erlangen, Germany 2Friedrich-Alexander-Universität Erlangen-Nürnberg; Staudtstraße 7/B2, 91058 Erlangen, Germany. 

3Center for Integrated Nanotechnologies, Sandia National Laboratories; Albuquerque, New Mexico 87185, USA. 

4Sandia National Laboratories; Albuquerque, New Mexico 87185, USA. 

5University College London; WC1E 7JE, London, UK. 

*Corresponding author. Email: jose-tomas.santiago@mpl.mpg.de 

**Abstract:** Quantum state engineering, the cornerstone of quantum photonic technologies, mainly relies on spontaneous parametric down-conversion and four-wave mixing, where one or two pump photons decay into a photon pair. Both these nonlinear effects require momentum conservation (i.e., phase-matching) for the participating photons, which strongly limits the versatility of the resulting quantum states. Nonlinear metasurfaces, due to their subwavelength thickness, relax this constraint and extend the boundaries of quantum state engineering.  Here, we generate entangled photons via spontaneous parametric downconversion in semiconductor metasurfaces with high-quality resonances. By enhancing the quantum vacuum field, our metasurfaces boost the emission of photon pairs within narrow resonance bands at multiple selected wavelengths. Due to the relaxed momentum conservation, the same resonances support photon pair generation from pump photons of practically any energy. This enables the generation of complex frequency-multiplexed quantum states, in particular cluster states. Our results demonstrate the multifunctional use of metasurfaces for quantum state engineering. 

Quantum state engineering with photons mainly relies on nonlinear optical effects such as spontaneous parametric down-conversion (SPDC) or spontaneous four-wave mixing (SFWM). These effects create a vast variety of photonic quantum states, including single ( _1_ ) and entangled ( _2_ ) photons, squeezed ( _3_ ) and cluster ( _4_ – _6_ ) states. However, both SPDC and SFWM in conventional nonlinear crystals and waveguides require strict momentum conservation for the involved photons, which strongly limits the versatility of the states they produce.  The emergent concept of quantum optical metasurfaces helps to overcome this 

1 

constraint. Metasurfaces, i.e., arrays of nanoscale resonators, feature unique abilities to manipulate and control the amplitude, phase, and polarization of light in the nonlinear ( _7_ – _9_ ) and quantum regimes ( _10_ ) using a single ultrathin device. In particular, all-dielectric metasurfaces made of materials with high second-order nonlinearities have offered a potential route for on-chip quantum state generation ( _11_ – _13_ ) and manipulation. Due to the subwavelength thickness of metasurfaces, the momentum conservation (or phasematching) requirement is relaxed ( _14_ ), enabling multiple nonlinear processes to occur with comparable efficiencies ( _15_ ). In addition, optical resonances in metasurfaces enhance the vacuum field fluctuations at certain wavelengths, boosting the spontaneous emission of photons ( _16_ ). The same effect enhances the spontaneous emission of photon pairs via SPDC in optical antennas ( _17_ ) and metasurfaces ( _11_ , _13_ ). 

Vacuum field enhancement scales with the quality (Q) factor of the resonance. In metasurfaces, Q-factors are especially high for bound states in the continuum (BIC) resonances ( _18_ – _20_ ), which are discrete-energy modes whose energy levels overlap with a continuous spectrum of radiating modes ( _21_ ). In symmetry-protected BIC metasurfaces, the outcoupling of radiation in the normal direction is forbidden by symmetry ( _22_ ). As a consequence, the Q factors of these modes are infinite, and could in theory infinitely enhance the spontaneous emission of photons and photon pairs ( _23_ ). In practice, the enhancement is finite due to symmetry breaking (quasi-BICs) ( _22_ ) but can be still as high as 10<sup>2</sup> -10<sup>4</sup> . 

In this work, we report on the experimental generation of tunable photon pairs via spontaneous parametric down-conversion driven by high-Q BIC resonances in gallium arsenide (GaAs) quantum optical metasurfaces (QOMs). We show how our QOMs emit frequency-degenerate and non-degenerate narrowband photon pairs that can be tuned over more than a hundred nm by changing either the optical pump or the spectral location of the BIC without appreciable loss of efficiency. Moreover, by the appropriate choice of optical resonances and pump wavelengths, we can drive as many as necessary multiple SPDC processes simultaneously, leading to the emission of frequency multiplexed entangled photons.  Our work paves the way for building room-temperature nanoscale sources of complex tunable entangled states for quantum networks. 

2 

In SPDC, a pump photon of a higher frequency 𝜔! down-converts in a second-order nonlinear material into a pair of signal and idler photons of lower frequencies, 𝜔" and 𝜔#, following energy conservation (Fig. 1A).  Contrary to thick nonlinear crystals, SPDC in subwavelength sources does not require longitudinal momentum conservation leading to the broadband emission of photon pairs over a wide range of angles ( _24_ , _25_ ).  In optical nanoantennae and metasurfaces, however, the resonances select the range of wavelengths and wavevectors where the photon emission is enhanced ( _11_ , _13_ , _17_ ).  Therefore, under judicious choice and design of optical modes and resonances, metasurfaces can be used to generate tunable, unidirectional photons at the nanoscale. 

To demonstrate experimentally the SPDC enhancement with BICs, we fabricated various arrays of broken-symmetry resonators arranged in a square lattice of different periodicities and scaling, via standard electron beam lithography and chlorine-based dry etching. Subsequent fabrication steps include epoxy bonding and curing, substrate lapping and polishing, wet etching, and transferring the metasurface onto a transparent fused silica substrate. (See Supplementary Table 1 for various metasurface dimensions.) We choose GaAs as it possesses one of the highest second-order susceptibilities among traditional materials, between 𝜒<sup>(%)</sup> = 400 – 500 pm.V<sup>-1</sup> , for the range of pump wavelengths involved in this work; these susceptibilities exceed the nonlinear coefficients of ferroelectric nonlinear materials such as lithium niobate by more than one order of magnitude ( _26_ ). The structure of the metasurfaces, as well as the crystallographic axes orientation, is shown in Fig. 1B. 

The existence of symmetry-protected BICs can be explained through symmetry breaking and coupling between allowed and forbidden optical Mie modes ( _27_ ), or using group theory arguments ( _28_ ). A metasurface consisting of square meta-atoms obeys C2 and C4 rotational symmetry; photons at the BIC frequency are trapped inside the resonators and cannot escape into free space due to zero coupling to radiating modes. A small notch in the cube breaks the rotational symmetry (Fig. 1C) and transforms these symmetry-protected BICs into quasi-BICs, which can outcouple to the far field. Spectrally, they appear as narrow transmission peaks in the white-light far-field transmittance (Fig. 1D).  The modes, labelled electric dipole (ED)-BIC and magnetic dipole (MD)-BICs, reach quality factors of 𝑄'() (+,) ≈ 330 and 𝑄'() (-,) ≈1000, respectively. The MD-BIC and ED-BIC have different coupling 

3 

efficiencies with respect to the incident beam polarization as shown in Supplementary Figure S1.  For the lowest-order quasi-BICs, their simulated electric field profiles resemble those of out-of-plane dipole modes (see insets in Fig. 1D). Additional field distribution cross sections can be found in Supplementary Figure S2. 

By tuning the period of the array and the proportions of the resonators, the central wavelengths of the BICs can be tuned over a wide range of wavelengths (Supplementary Figure S3). For emission normal to the QOM, the Q factor is the highest since most of the system symmetry is preserved. However, off-normal emission breaks the symmetry and the Q factor of each BIC decreases, lowering the field enhancement.   Thus, we should also expect the emitted SPDC photon pairs to be radiated unidirectionally along the metasurface normal as observed in the past for emission from quantum dots embedded inside a symmetryprotected quasi BIC resonator ( _16_ ). 

To demonstrate multiplexed entangled photons generation via SPDC, we investigate three QOMs, labelled, respectively QOM-A, QOM-B and QOM-C, with different resonator sizes and resonance spectral spacings, such that the ED-BIC and MD-BIC optical modes are resonant at different wavelengths (Fig. 2A-C, upper panels). All metasurfaces are pumped with a linearly polarized continuous-wave tunable laser focused down to a spot size of 140 μm (1⁄𝑒<sup>%</sup> ).  Photon pairs are registered as joint detection events using two superconducting nanowire single-photon detectors placed at the two outputs of a fiber beam splitter (see Supplementary Figure S4). For all QOMs considered, we register a high number of simultaneous photon detections – coincidences (Fig. 1E) - which indicates the presence of photon pairs.  Further details of the experimental apparatus are given in the Supplementary Information. Supplementary Figure S5 also shows the results of the second-harmonic generation, which is mediated by the same nonlinear tensor as SPDC and is therefore helpful for investigating the SPDC polarization properties. 

We then perform two-photon fiber-assisted spectroscopy with 3 nm resolution to find the spectrum of the emitted photons. By placing a 3 km single-mode dispersive fiber into the path of the photons, we map the time delay between these photons to their wavelengths. The three corresponding SPDC spectra are shown in Fig. 2A-C (bottom panels), each one below its white-light transmission spectrum.  Thanks to the relaxed momentum conservation, the 

4 

pump wavelength 𝜆! can be arbitrary, and thus we use different pumps and different QOMs to demonstrate various types of photon pairs that can be generated in our system. 

For QOM-A, we use 𝜆! = 723 nm, such that the degenerate wavelength 2𝜆! overlaps with the ED-BIC resonance wavelength. In this case, both SPDC photons are emitted within a single narrow peak, centered at the resonance wavelength (2𝜆! = 1446 nm), see Fig. 2A.  The full width at half maximum (FWHM) of 4.3 nm matches the linewidth of the ED-BIC resonance. This corroborates previous observations on QOMs ( _11_ ) that the presence of an optical resonance enhances the quantum vacuum field within the resonance’s bandwidth. 

However, very different spectra are obtained when we pump QOM-B at 718 nm, such that the degenerate wavelength 2𝜆! is off-resonance from the ED-BIC modes.  Now, we find that the SPDC spectrum exhibits two narrow peaks, one centered at the ED-BIC peak wavelength (𝜆" = 1391 nm), and the other at a wavelength 𝜆# =1485 nm (Fig. 2B). This indicates the first-time observation of non-degenerate photon pairs emitted from QOMs.  Here, the EDBIC resonance enhances the vacuum field at the signal wavelength, forcing the QOM to emit a photon at this wavelength simultaneously with its partner at the idler wavelength, as 0. . . dictated by energy conservation: 𝜆# = ~~1~~ /! − /" ~~3~~ . 

The spectrum of the entangled photons gets richer when both ED-BIC and MD-BIC resonances are active in SPDC (Fig. 2C). We achieve this by pumping our third metasurface QOM-C at 725 nm, with the pump radiation polarized at 40 deg, so that the MD-BIC resonance at 1429 nm is activated (see the Supplementary Information). Now, we observe four peaks, two of them corresponding to signal photons emitted at the ED and MD resonances and the other two, to their idler partners. We find that, since the MD-BIC optical resonance has a higher Q-factor than the ED-BIC resonance, its emission FWHM is narrower, causing the signal and idler SPDC spectra to also be narrower. 

We also find that our QOMs can produce degenerate and non-degenerate photon pairs over a broad spectral range without considerable reduction of efficiency (Fig. 2D), and, due to the high-Q resonances, with an efficiency of at least three orders of magnitude higher than in an unpatterned GaAs film of the same thickness (see the Supplementary Information). 

5 

To verify the non-classicality of our photon pairs, we measure the pump-power dependence of the second-order cross-correlation function at zero time delay, defined as 𝑔"#(%)(0) = ⟨2<sup>3</sup> <u>"2</u><sup>3</sup> <u>#⟩</u> , where 𝑁<sup>6</sup> ",# are photon-number operators for the signal and idler modes. The cross⟨2<sup>3</sup> "⟩⟨2<sup>3</sup> #⟩ correlation function is measured as 𝑔"#(%)(0) = 6$ ~~,~~ where 𝑅8,",# are the rates of the signal6"6#7$ idler coincidences, signal photon detections, and idler photon detections, respectively, and 𝑇8 the coincidence resolution time ( _29_ ).  For SPDC, all three numbers 𝑅8,",# scale linearly with the pump power, which leads to the inverse dependence of 𝑔"#(%)(0) with power, as indeed observed in our measurement for QOM-A (Fig. 3A). While a strong correlation peak in 𝑔"#(%)(0) (Fig. 1D) is generally accepted as the evidence of nonclassical behavior, a formal proof requires the violation of the Cauchy-Schwarz (CS) inequality. Specifically, for classical fields the CS inequality holds ( _30_ ), 



<!-- Start of picture text -->
%<br>9𝑔"#(%)(0): ≤𝑔""(%)(0) ⋅𝑔##(%)(0),<br>( 1 )<br><!-- End of picture text -->

where 𝑔"",##(%) (0) is the second-order autocorrelation function for the signal and idler modes, 

<u>9: 2</u><sup>3</sup> "%∶< respectively, defined as 𝑔""(%)(0) = ,  with :: denoting normal ordering. Note that the CS ⟨2<sup>3</sup> "⟩<sup>%</sup> inequality (1) can be tested only when the modes _s_ and _i_ are distinguishable. Since QOM-B provides two distinguishable frequency modes, at 1391 nm and 1485 nm, we measure the autocorrelation functions of modes _s_ and _i_ after 50 nm FWHM bandpass filters centered at 1400 nm (s) and 1475 nm (i), respectively.  Figures 3B,C show the measured autocorrelation functions for the _s_ and _i_ modes, respectively. The single count graphs for each measurement are shown in the Supplementary Information. We get 𝑔""(%)(0) = 1.6 ± 0.3, and 𝑔""(%)(0) = 1.2 ± 0.2. The cross-correlation function is measured without bandpass filters (Fig. 3D), which gives 𝑔"#(%)(0) = 10.5 ± 1.1. Hence, the CS inequality is violated by >50 standard % deviations, 9𝑔"#(%)(0): = 110 ± 2, 𝑔""(%)(0) ⋅𝑔##(%)(0) = 1.9 ± 0.3,   revealing the nonclassical character of the photons generated in our QOMs. 

We emphasize that the presence of narrow optical resonances enables the creation of entangled states and more complicated graph quantum states from our metasurfaces, as 

6 

illustrated in figure 4A. In the current setup (see Supplementary Figure S4), the state preparation relies on the fiber beam splitter splitting the pairs between the two detectors; events where both photons arrive at the same detector are ignored. For a non-degenerate photon pair at wavelengths 𝜆.,%, after the beam splitter photon |𝜆.⟩ is path-entangled with photon |𝜆%⟩. If a second non-degenerate pair at wavelengths 𝜆.,=, arrives at the beam splitter, photon |𝜆.⟩ is also path-entangled with photon |𝜆=⟩ after it. Note that this photon pair needs another pump for its generation. If photons |𝜆.⟩ from each pair are indistinguishable, a linear graph state of three pairwise entangled qubits appears (Fig. 4A, top). This strategy of cluster state generation, called pairwise coupling ( _6_ ), can be implemented using two coherent pump beams, at wavelengths 725 nm and 718 nm, and a resonance at 1359 nm (Fig. 4B). In our experiment, the two pump beams are incoherent, but they still provide the desired spectrum. By adding a third pump, generating photon pairs at wavelengths 𝜆.,>, a more complicated graph state can be created, called a Greenberger-Horne-Zeilinger state ( _5_ ), shown in Fig. 4A (middle). 

The state becomes increasingly complex by adding multiple coherent pump beams at different wavelengths - for instance, using a frequency comb or a filtered supercontinuum as an excitation source. By appropriately matching the wavelength separation of the comb, and the optical resonances of the QOMs, photons at multiple wavelengths can be entangled via pairwise couplings. With this approach, one could implement a scalable cluster state, needed for one-way quantum computation ( _5_ ).  An example of such a state is shown in Fig. 4A (bottom). We stress that such methods of quantum state engineering are made possible by the use of our unique QOMs with the relaxed phase matching and engineered high-Q resonances, and are impossible to create using bulk crystal or waveguide SPDC sources. Moreover, QOMs provide a unique way to spatially multiplex multiple metasurfaces within the area of a single pump beam, by exciting resonances at different wavelengths (Fig. 4C), and entangling multiple photon pairs across separate wavelengths with a single pump. 

In summary, we have demonstrated, for the first time, SPDC driven by quasi-BIC optical resonances in QOMs. The metasurface design allows for the generation of photon pairs at multiple wavelengths, with either one or both photons of a pair created at the wavelength of the BIC resonance. Unlike in previously studied Mie-type QOMs, there is no considerable loss 

7 

or efficiency with passing from degenerate to non-degenerate SPDC. The resulting state features entanglement; in the case of pumping coherently at different wavelengths, scalable graph quantum states can be generated. In contrast to other on-chip sources of photon pairs, the QOM geometry offers additional degrees of freedom, such as transverse displacement of various structures within a single pump beam, opening up vast opportunities for on-chip quantum state engineering. 

## **Acknowledgments:** 

T.S.C. and M.V.C. are part of the Max Planck School of Photonics, supported by BMBF, Max Planck Society, and Fraunhofer Society. 

T.S.C. and M.V.C. acknowledge support by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) – Project ID 429529648 – TRR 306 QuCoLiMa (“Quantum Cooperativity of Light and Matter”). S.D.G., O.M. and I.B. were supported by the U.S. Department of Energy, Office of Basic Energy Sciences, Division of Materials Sciences and Engineering. The work was performed, in part, at the Center for Integrated Nanotechnologies, an Office of Science User Facility operated for the U.S. Department of Energy (DOE) Office of Science. Sandia National Laboratories is a multi-mission laboratory managed and operated by National Technology and Engineering Solutions of Sandia, LLC, a wholly owned subsidiary of Honeywell International, Inc., for the U.S. Department of Energy’s National Nuclear Security Administration under contract DE-NA0003525. This paper describes objective technical results and analysis. Any subjective views or opinions that might be expressed in the paper do not necessarily represent the views of the U.S. Department of Energy or the United States Government. 

We thank A. V. Rasputnyi, V. Sultanov, and M. Poloczek for their help at the initial stage of the experiment, and M. Lippl and N. Y. Joly for giving us access to the tunable continuous-wave laser. 

8 



**Fig. 1. SPDC using symmetry-protected quasi-BIC resonances in a semiconductor metasurface** . ( **A** ) Conceptual diagram of multiplexed entangled photon generation in a multi-resonance semiconductor metasurface. ( **B** ) Scanning electron micrograph of the metasurface at an intermediate step of nanofabrication (see SI).  ( **C** ) Structure of the broken-symmetry resonators. The parameters are: height 500nm, large square width 𝑎 = 320 nm, small rectangle width 𝑤 = 115 nm, length 𝑙 = 173 nm. The base periods of the array vary from 0.47 𝜇m to 0.55 𝜇m, which tunes and redshifts the BIC resonances.  The addition of a small rectangle (pink) breaks the symmetry of the metasurface, turning the BIC into a quasiBIC, which can outcouple to the far field. C2 and C4 denote rotational symmetries. ( **D** ) Simulated (top) and measured (bottom) white-light linear transmission spectra of one metasurface considered in this work, for two incident polarizations: along the [110] direction (blue) and orthogonal to it (pink). Grey areas highlight the locations of the quasi – BIC resonances:  the ED-BIC (𝜆=  1446 nm) and the MD-BIC (𝜆= 1512 nm). The inset shows the top view (xy) of the electric-field normalized distribution calculated at the center of the nanoresonator for both quasi-BIC resonances. Dark arrows indicate the direction of the electric field. ( **E** ) Typical distribution of the time difference between the photon arrivals at two detectors,  demonstrating photon pair generation. 

9 



**Fig. 2. SPDC spectra for the QOMs considered in this work.** ( **A – C** ) Measured white-light transmission spectra (top panels) and SPDC spectra measured via the fiber-assisted spectroscopy  (bottom panels) for QOMs A – C, respectively. The SPDC spectra show (A) the production of degenerate photon pairs at the wavelength 2𝜆& = 1446 nm (dark dashed line), which overlaps with the electric dipole (ED)-BIC resonance of QOM-A;  (B) the production of  non-degenerate photon pairs where only the signal photon is emitted at the ED-BIC mode wavelength 𝜆 = 1391 nm (purple vertical solid line) of QOM-B; (C) the production of two types of non-degenerate photon pairs, where signal photons are emitted at wavelengths 𝜆= 1359 nm of the ED-BIC resonance (orange vertical line) and 𝜆= 1429 nm of the magnetic dipole (MD)-BIC resonance (green vertical solid line) of QOM-C. Both ED- and MD-BIC modes are active in SPDC due to the choice of the pump polarization. ( **D** ) Coincidence rate as a function of the wavelength detuning 𝛥𝜆= 2𝜆& −𝜆'()*+, between the degenerate wavelength and the ED-BIC resonance, 𝜆'()*+, of five QOMs.  The pump power in this experiment was 9.6 mW. 

10 



**Fig. 3. Second-order cross- and auto-correlation functions.** ( **A** ) Pump power dependence of the secondorder auto-correlation function at zero-time delay measured for photon pairs emitted by QOM-A. The solid (/) (/) line is a fit of the expected dependence. ( **B,C** ) Second-order auto-correlation functions 𝑔 --<sup>and𝑔</sup> 22<sup>as</sup> measured for QOM-B at the signal wavelength (1391 nm) and idler wavelength  (1485 nm), respectively. ( **D** ) Second-order cross-correlation function 𝑔-2(/) as measured for QOM-B. 

11 



**Fig. 4. Cluster state generation with QOMs.** ( **A** ) Three examples of cluster states: a linear three-qubit graph state (top), a Greenberger-Horne-Zeilinger state (middle) and a more general graph state (bottom). ( **B** ) SPDC spectrum illustrating how a linear three-qubit graph state of photons |𝜆3〉, |𝜆/〉, |𝜆4〉 can be generated from QOM-C. ( **C** ) Spatial multiplexing of various (4 shown) metasurfaces for cluster state generation using a single pump beam. 

12 

## **References and Notes** 

1. B. Lounis, M. Orrit, Single-photon sources. _Reports on Progress in Physics_ . **68** , 1129–1179 (2005). 2. M. Chekhova, in _Progress in Optics_ (Elsevier, 2011), vol. 56 of _Progress in Optics_ , pp. 187–226. 3. R. Schnabel, Squeezed states of light and their applications in laser interferometers. _Physics Reports_ . **684** , 1–51 (2017). 

4. G. Vallone, E. Pomarico, P. Mataloni, F. De Martini, V. Berardi, Realization and characterization of a two-photon four-qubit linear cluster state. _Physical Review Letters_ . **98** , 1–4 (2007). 

5. H. J. Briegel, D. E. Browne, W. Dür, R. Raussendorf, M. Van den Nest, Measurement-based quantum computation. _Nature Physics_ . **5** , 19–26 (2009). 

6. N. C. Menicucci, S. T. Flammia, O. Pfister, One-Way Quantum Computing in the Optical Frequency Comb. _Physical Review Letters_ . **101** , 130501 (2008). 

7. G. Li, S. Zhang, T. Zentgraf, Nonlinear photonic metasurfaces. _Nature Reviews Materials_ . **2** , 17010 (2017). 

8. A. Krasnok, A. Alù, Low-Symmetry Nanophotonics. _ACS Photonics_ . **9** , 2–24 (2022). 9. M. Shcherbakov, S. Liu, I. Brener, A. Fedyanin, in _Dielectric Metamaterials_ (Elsevier, 2020), pp. 223– 248. 

10. A. S. Solntsev, G. S. Agarwal, Y. S. Kivshar, Metasurfaces for quantum photonics. _Nature Photonics_ . **15** , 327–336 (2021). 

11. T. Santiago-Cruz, A. Fedotova, V. Sultanov, M. A. Weissflog, D. Arslan, M. Younesi, T. Pertsch, I. Staude, F. Setzpfandt, M. Chekhova, Photon Pairs from Resonant Metasurfaces. _Nano Letters_ . **21** , 4423–4429 (2021). 

12. L. Li, Z. Liu, X. Ren, S. Wang, V. C. Su, M. K. Chen, C. H. Chu, H. Y. Kuo, B. Liu, W. Zang, G. Guo, L. Zhang, Z. Wang, S. Zhu, D. P. Tsai, Metalens-array-based high-dimensional and multiphoton quantum source. _Science (1979)_ . **368** , 1487–1490 (2020). 

13. J. Ma, J. Zhang, M. Parry, M. Cai, R. C. Morales, L. Xu, D. N. Neshev, A. A. Sukhorukov, Generation of spatial photon entanglement from lithium niobate nonlocal metasurfaces (2022), (available at https://arxiv.org/abs/2204.01890). 

14. C. Okoth, A. Cavanna, T. Santiago-Cruz, M. V. Chekhova, Microscale Generation of Entangled Photons without Momentum Conservation. _Physical Review Letters_ . **123** , 263602 (2019). 

15. S. Liu, P. P. Vabishchevich, A. Vaskin, J. L. Reno, G. A. Keeler, M. B. Sinclair, I. Staude, I. Brener, An alldielectric metasurface as a broadband optical frequency mixer. _Nature Communications_ . **9** , 2507 (2018). 

16. S. Liu, A. Vaskin, S. Addamane, B. Leung, M. C. Tsai, Y. Yang, P. P. Vabishchevich, G. A. Keeler, G. Wang, X. He, Y. Kim, N. F. Hartmann, H. Htoon, S. K. Doorn, M. Zilk, T. Pertsch, G. Balakrishnan, M. B. Sinclair, I. Staude, I. Brener, Light-Emitting Metasurfaces: Simultaneous Control of Spontaneous Emission and Far-Field Radiation. _Nano Letters_ . **18** , 6906–6914 (2018). 

17. G. Marino, A. S. Solntsev, L. Xu, V. F. Gili, L. Carletti, A. N. Poddubny, M. Rahmani, D. A. Smirnova, H. Chen, A. Lemaître, G. Zhang, A. V. Zayats, C. De Angelis, G. Leo, A. A. Sukhorukov, D. N. Neshev, Spontaneous photon-pair generation from a dielectric nanoantenna. _Optica_ . **6** , 1416 (2019). 

18. P. P. Vabishchevich, S. Liu, M. B. Sinclair, G. A. Keeler, G. M. Peake, I. Brener, Enhanced SecondHarmonic Generation Using Broken Symmetry III-V Semiconductor Fano Metasurfaces. _ACS Photonics_ . **5** , 1685–1690 (2018). 

19. A. C. Overvig, S. C. Malek, M. J. Carter, S. Shrestha, N. Yu, Selection rules for quasibound states in the continuum. _Physical Review B_ . **102** , 1–28 (2020). 

20. K. Koshelev, S. Lepeshov, M. Liu, A. Bogdanov, Y. Kivshar, Asymmetric Metasurfaces with High-Q Resonances Governed by Bound States in the Continuum. _Physical Review Letters_ . **121** , 193903 (2018). 

21. C. W. Hsu, B. Zhen, A. D. Stone, J. D. Joannopoulos, M. Soljacic, Bound states in the continuum. _Nature Reviews Materials_ . **1** (2016), p. 16048. 

22. K. Koshelev, S. Lepeshov, M. Liu, A. Bogdanov, Y. Kivshar, Asymmetric Metasurfaces with High- Q Resonances Governed by Bound States in the Continuum. _Physical Review Letters_ . **121** , 193903 (2018). 

13 

23. M. Parry, A. Mazzanti, A. Poddubny, G. della Valle, D. N. Neshev, A. A. Sukhorukov, Enhanced generation of nondegenerate photon pairs in nonlinear metasurfaces. _Advanced Photonics_ . **3** , 1–6 (2021). 

24. T. Santiago-Cruz, V. Sultanov, H. Zhang, L. A. Krivitsky, M. V. Chekhova, Entangled photons from subwavelength nonlinear films. _Optics Letters_ . **46** , 653 (2021). 

25. C. Okoth, E. Kovlakov, F. Bönsel, A. Cavanna, S. Straupe, S. P. Kulik, M. v. Chekhova, Idealized EinsteinPodolsky-Rosen states from non–phase-matched parametric down-conversion. _Physical Review A_ . **101** , 011801 (2020). 

26. S. D. Gennaro, C. F. Doiron, N. Karl, P. P. Iyer, D. K. Serkland, M. B. Sinclair, I. Brener, Cascaded Optical Nonlinearities in Dielectric Metasurfaces. _ACS Photonics_ . **9** , 1026–1032 (2022). 

27. S. Campione, S. Liu, L. I. Basilio, L. K. Warne, W. L. Langston, T. S. Luk, J. R. Wendt, J. L. Reno, G. A. Keeler, I. Brener, M. B. Sinclair, Broken Symmetry Dielectric Resonators for High Quality Factor Fano Metasurfaces. _ACS Photonics_ . **3** , 2362–2367 (2016). 

28. A. Cerjan, C. Jorg, S. Vaidya, S. Augustine, W. A. Benalcazar, C. W. Hsu, G. Von Freymann, M. C. Rechtsman, Observation of bound states in the continuum embedded in symmetry bandgaps. _Science Advances_ . **7** , 3–10 (2021). 

29. L. Mandel, E. Wolf, _Optical Coherence and Quantum Optics_ (Cambridge University Press, 1995). 

30. D. F. Walls, G. J. Milburn, _Quantum Optics_ (Springer Berlin Heidelberg, Berlin, Heidelberg, 2008). 

14 

