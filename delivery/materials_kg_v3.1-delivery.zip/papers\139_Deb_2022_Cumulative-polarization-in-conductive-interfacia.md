# Cumulative polarization in conductive interfacial ferroelectrics.

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 196 |
| 作者 | Swarup Deb, W. Cao, Noam Raab, K. Watanabe, T. Taniguchi, M. Goldstein, L. Kronik, M. Urbakh et al. |
| DOI | 10.1038/s41586-022-05341-5 |
| 源文件 | 039_Deb_2022_Cumulative-polarization-in-conductive-interfacia.pdf |

---
# **Cumulative Polarization Coexisting with Conductivity at Interfacial Ferroelectrics** 

<mark>Swarup Deb</mark><sup>1#</sup> <mark>, Wei Cao</mark><sup>2#</sup> <mark>, Noam Raab</mark><sup>1</sup> , Kenji Watanabe<sup>3</sup> , Takashi Taniguchi<sup>4</sup> , Moshe Goldstein<sup>1</sup> , <mark>Leeor Kronik</mark><sup>5</sup> <mark>, Michael Urbakh</mark><sup>2</sup> <mark>, Oded Hod</mark><sup>2</sup> <mark>, Moshe Ben Shalom</mark><sup>1*</sup> 

> 1 <mark>School of Physics and Astronomy, Tel Aviv University, Tel Aviv, Israel</mark> 

2 Department of Physical Chemistry, School of Chemistry, The Raymond and Beverly Sackler Faculty of Exact Sciences and The Sackler Center for Computational Molecular and Materials Science, Tel Aviv University, Tel Aviv, Israel. 

3 Research Center for Functional Materials, National Institute for Material Science, 1-1 Namiki, Tsukuba 3050044, Japan 

4 International Center for Materials Nanoarchitectonics, National Institute for Material Science, 1-1 Namiki, Tsukuba 305-0044, Japan 

5 Department of Molecular Chemistry and Materials Science, Weizmann Institute of Science, Rehovoth, Israel # These authors contributed equally 

* moshebs@tauex.tau.ac.il 

<mark>Ferroelectricity in atomically thin bilayer structures has been recently predicted</mark><sup>1</sup> <mark>and measured</mark><sup>2–4</sup> in <mark>two-dimensional (2D) materials with hexagonal non-centrosymmetric unit-cells. Interestingly, the crystal symmetry translates lateral shifts between parallel 2D layers to a change of sign in their outof-plane electric polarization, a mechanism referred to as "Slide-Tronics"</mark><sup>4</sup> <mark>. These observations, however, have been restricted to switching between only two polarization states under low charge carrier densities</mark><sup>5–12</sup> <mark>, strongly limiting the practical application of the revealed phenomena</mark><sup>13</sup> <mark>. To overcome these issues, one needs to explore the nature of the polarization that arises in multi-layered van der Waals (vdW) stacks, how it is governed by intra- and inter-layer charge redistribution, and to which extent it survives the introduction of mobile charge carriers, all of which are presently unknown</mark><sup>14</sup> <mark>. To explore these questions, we conduct surface potential measurements of parallel</mark> WSe2 and MoS2 <mark>multi-layers with aligned and anti-aligned configurations of the polar interfaces. We find evenly spaced, nearly decoupled potential steps, indicating highly confined interfacial electric fields, which provide means to design multi-state "ladder ferroelectrics". Furthermore, we find that the internal polarization remains significant upon electrostatic doping of a mobile charge carrier density as high as 10</mark><sup>13</sup> <mark>cm</mark><sup>-2</sup> <mark>, with substantial in-plane conductivity. Using first-principles calculations based on density functional theory (DFT), we trace the extra charge redistribution in real and momentum space and identify an eventual doping-induced depolarization mechanism.</mark> 

1 

Electronic devices based on 2D materials utilize electric fields that add or remove mobile charge carriers to control the material conductivity. If these materials also possess switchable electric dipoles, they could serve as the basis of future high-density memory technology<sup>13–16</sup> . Therefore, a visionary goal is to design 2D materials that simultaneously exhibit non-volatile memory and rapid logic response, where internal charge dipoles and free electrons coexist<sup>17,18</sup> . Such coexistence, however, is typically unfavored since free charge carriers tend to screen dipole formation and cooperative orientation<sup>19–23</sup> . In this respect, the recent discovery of interfacial ferroelectricity by interlayer vdW sliding suggests an approach to overcome the above difficulty by exploiting a partition between inand out-of-plane phenomena. Here, in-plane conductivity is afforded by a conducting 2D electron/hole gas, whereas out-of-plane switchable polarization emerges from intrinsic symmetry breaking at the interface that can be controlled by interlayer sliding. This inherent anisotropy of layered ferroelectrics should further distinguish them from thin ferroelectric films, which are highly susceptible to depolarizing fields at the surface or interface where the polarization terminates<sup>24</sup> . Specifically, at the 2D limit, the polarization magnitude rarely scales with the system thickness and can switch between two local states only<sup>25–27</sup> . 

To demonstrate and explore the potential of interfacial ferroelectrics, we study devices made of two or three layers of transition metal dichalcogenides (TMDs) that are artificially stacked in a parallel lattice orientation and encapsulated by thin flakes of non-polar hexagonal boron nitride ( _h_ -BN), placed atop a graphite or gold metallic electrode (Fig. 1a, inset). We measure the surface potential at room temperature, ~10 nm above the surface with an atomic force microscope operated in a sideband Kelvin probe mode (KPFM) (SI. S1)<sup>2,4</sup> . The obtained potential map is presented in Fig. 1a, showing a triangular domain landscape of various polarization values, separated by thin domain walls that naturally form due to a slight twist angle between the flakes. For a sufficiently small global twist, these domain walls accommodate a shear displacement of precisely one interatomic spacing, allowing for perfect high symmetry AB/BA stacking (zero twist) within the triangular domains<sup>28–30</sup> . Measuring the potential profile across domain walls, we find five distinct polarization values (Fig. 1b). The potential profile measured in the top-left triangular region in Fig. 1a (red line) exhibits two polarization states, consistent with previous reports on non-centrosymmetric bilayer TMDs incorporating a single polar interface<sup>1,9,11</sup> . This indicates regions of the WSe2 trilayer sample where only one of the two interfaces is active, namely exhibiting finite polarization due to noncentrosymmetric stacking and in-plane atomic relaxation. Notably, the corresponding profile measured at the central region (dashed blue line) shows three polarization states separated by potential steps of ΔVKP~110 mV (Fig. 1b). The potential of the intermediate step is the average of the two potential values corresponding to a single active-interface trilayer, suggesting two oppositely polarized (↑↓) interfaces within a trilayer WSe2 region, as in the case of mirror-symmetric Bernal stacking (ABA) of WSe2. This interpretation is further supported by the fact that the potential differences between the three polarization states equal those measured at the single-active interface regions, which translates to absolute polarization values twice as large as those measured for the bilayer system. This, in turn, can be achieved if the two interfaces have parallel polarizations (↑↑, ↓↓), which is the case for the rhombohedral ABC and CBA stacking configurations. 

2 



**Fig. 1| Multiple polarization states in artificially-stacked trilayers. a.** Surface potential map at the WSe2 tri-layer surface. The dashed white lines mark borders between regions consisting of single and two active interfaces. Arrows denote the out-of-plane polarization orientation in five domains with different stacking configurations. Inset, schematic illustration of the Kelvin probe force microscopy setup including a tri-layer TMDs structure (yellow), encapsulated between _h_ -BN layers (green) that are placed on a graphitic or gold (black) gate (Vg) electrode lying atop a silicon oxide substrate (blue). **b.** Typical line cuts of the lateral potential drop across walls separating large domains (extracted from the map in Fig. S1f) of single (solid red) and two (dashed blue) active interface regions. Line cuts crossing domain walls that separate smaller domains are illustrated by the red and dashed blue lines in panel **a** . The stacking configurations at the corresponding interfaces (shown schematically for the bilayer) are marked aside each potential step, with the corresponding interface polarizations marked by black arrows. **c.** Calculated laterally-averaged vertical potential profile along an ABC stacked trilayer with co-oriented (black arrows) interfacial polarization. 

The experimental evidence presented above indicates that the polarization should be localized at the interfaces between layers, suggesting that adjacent interfaces are only weakly coupled and, therefore, a cumulative polarization effect in layered stacks is obtained. This is further supported by the comparable coverage of the ABC and ABA domains in the map, demonstrating no significant energetic stability preference between the two stacking configurations<sup>29,30</sup> . The former domain, which have two aligned polar interfaces, thus exhibit a similar stacking energy to that of the latter domains, which include two anti-aligned polar interfaces. We note, however, that for larger domains small coverage differences are observed, indicating weak Ferro-like coupling that favors a co-aligned polar ABC configuration (as discussed in SI.S2). Fig. 1c presents DFT-computed potential profiles for the ABC stacked WSe2 trilayer. The potential drop, ∆𝜙, calculated between points far above and below 

3 

the layered system is in good agreement with the measured potential drop (ΔVKP =2∆𝜙) and its steplike shape<sup>31,32</sup> further emphasizes the interfacial confinement of the polarization, and hence the weak coupling between adjacent polarized interfaces. 



**Fig. 2| Multi-polarization states in naturally-grown 3R MoS2. a-d.** Topography (a,c) and surface potential (b,d) maps of two typical flakes composed of 2-7, and 7-13, respectively. The potential is measured relative to the value above an ABA stacked tri-layer region (Vavg in Fig.1b). **e.** Line cuts, as marked in a,b, showing the flake thickness (blue squares, left axis) and surface potential (red circles, right axis). The horizontal grids show evenly-spaced steps. **f.** Surface potential values and excess number of active interfaces (N `↑` - N `↓` ) above different positions (as marked in a-d) versus the number of layers at each point. The dashed black line connects points of the fully co-aligned polar interfaces, where the symbols correspond to those appearing in panels a, b and e. Other points (with symbols corresponding to those appearing in panels c and d) show fixed, evenly spaces values corresponding to multi-polarization configurations. For example, the four values measured above 7 layers with 6 active interfaces correspond to the 6 `↓` , 5 `↓` 1 `↑` , 3 `↓` 3 `↑` , and 2 `↓` 4 `↑` combinations. Calculated maximal polarization values are indicated by the full red squares. 

To demonstrate the emergence of multi-polarization states beyond tri-layered stacks, we measured the potential at the surface of MoS2 crystals, which are naturally grown in the 3R ABC stacking configuration. The addition of layers with aligned polarization results in an essentially linear increase of the total polarization with stack thickness (Fig. 2a,b,e), confirming the cumulative interfacial effect. Remarkably, some region of the flakes reveal various potential values indicative of multiple interfacial polarization configurations (Fig. 2c,d) of aligned and anti-aligned polarized interfaces. For a given number of layers, regions of different stacking and polarization are spatially separated by local domain walls, whose crossing results in evenly spaced potential steps. The specific value of the 

4 

measured potential above each region is determined by the difference between upward (N `↑` ) and downward (N `↓` ) polarization pointing active interfaces, which is dictated by the local stacking configuration and can be extracted from the measured local potential (Fig.2f). In case of 7 layers, for example, with N=6 interfaces the system can exhibit N+1 polarization values.<sup>33</sup> Therefore, by a relative shift of each pair of adjacent layers one could, in principle,<sup>4</sup> increase or decrease the surface potential in a sequential ladder of polarization values. 

The interface-localized nature of the polarization paves the way to an even more unusual effect, namely its coexistence with in-plane conductance through the individual layers. We set out to explore this intriguing possibility by introducing external gate electrodes to induce free charge carriers in polarized MoS2 or WSe2 bilayers. In Fig. 3a-c, we map the potential surface of the same spatial MoS2 region, while applying several fixed gate biases Vg. Already upon the application of a relatively small bias, one notices a conductance response (Fig. S1c), as well as an improvement in the map quality (Fig. 3a,b), indicating that, indeed, the gate bias affects the carrier density in the bilayers. The application of a larger gate bias leads to domain wall sliding and a reversible polarization orientation switching, as reported here and previously for bilayer systems4 (see Fig. S2 for additional examples). The results of Δ𝑉𝐾𝑃 measurements under different gate biases are presented in Fig. 3d for MoS2 (red stars) and WSe2 (blue triangles and circles) bilayers. The displacement field D and the carrier density n for each gate bias value are extracted from the change in the average surface potential, 𝑉𝑎𝑣𝑔, between the two domains (marked in Fig. 1b). This procedure (see SI.S3 for more details) is insensitive to effects such as quantum capacitance or Schottky barriers (the latter prevented us from attaining hole doping in MoS2). Notably, the polarization in both materials is sustained up to the highest experimentally accessible charge density of 𝑛≈10<sup>13</sup> cm<sup>−2</sup> . A reduction of 25-50% in the polarization, however, is observed at n ≈±3 × 10<sup>12</sup> cm<sup>−2</sup> . These findings are in qualitative agreement with DFT calculations, also shown in Fig. 3d (solid red and dashed blue lines for MoS2 and WSe2, respectively), in which doping is introduced by the inclusion of “pseudoatoms” with fractional nuclear charges, allowing the introduction of excess free charge carriers without violating sample neutrality and without distorting the underlying band-structure, see SI.S5)34. The experimental polarization is known to provide a lower bound to the true polarization35, owing to limitations of the local potential measurements under external bias and screening effects due to contaminants accumulating atop the surface at large carrier densities (see SI.S3). This explains the underestimation of the experimental measurements with respect to the calculated values. Notably, a qualitative difference between the calculated MoS2 and WSe2 polarization response to doping is 

5 

observed, where the former exhibits a weaker response to hole doping than to electron doping, whereas the latter exhibits an opposite trend. 



**Fig. 3| Effect of gate bias on the polarization. a-c.** Surface potential maps obtained for bilayer MoS2 under different gate biases. The center of the scale bar in each map is set to the corresponding average potential, Vavg, as indicated in the respective panel. **d.** Potential drop 𝛥𝑉𝐾𝑃 across domains of opposite polarization (see Fig. 1b), as a function of the external displacement field D and the corresponding 2D carrier density (lower/upper horizontal axis, see Methods section). Data from one MoS2 sample (red stars) and two different WSe2 samples (blue triangles and circles) are compared to the calculated 2∆∅  values (solid red, dashed blue lines, respectively). 

To rationalize these results, we further analyze the effect of doping on the charge density distribution and its relation to the observed depolarization. Fig. 4a,b present the calculated laterally averaged excess electron charge density profiles, 𝜌0𝑒𝑥(𝑧), for the undoped MoS2 (a) and WSe2 (b) bilayers, where 𝜌0𝑒𝑥(𝑧) is defined as the difference between the density of the bilayer and the superposition of the densities of the corresponding undoped infinitely separated layers (dashed black lines). The excess density features a similar prominent asymmetric contribution at the interface between the two layers for both the MoS2 and WSe2 bilayer systems, which is the origin of the interface dipole shown in Fig. 1c (see SI.S4 for more details). Doping-induced excess charge density variations, Δ𝜌<sup>𝑒𝑥</sup> (𝑧) , are represented by colored lines for different hole densities. With increasing doping density, excess charge accumulates primarily within the layers at the transition metal plane. To analyze the asymmetry of the doping induced excess charge, which is responsible for depolarization, we plot in Fig. 4c,d the antisymmetric part of Δ𝜌<sup>𝑒𝑥</sup> (𝑧), defined as Δ𝜌<sup>𝑒𝑥</sup> (𝑧) −Δ𝜌<sup>𝑒𝑥</sup> (−𝑧), where 𝑧= 0 is set at the interlayer region center. For both MoS2 and WSe2, the asymmetric part of the excess charge shows two contributions, one at the interface and the other within the layers. We find, however, two important differences in the doping response of Δ𝜌<sup>𝑒𝑥</sup> (𝑧) in the two materials: (i) At a given hole doping density the overall charge distribution asymmetry is larger for WSe2 (compare, for example, the red curves in panels c and d of fig. 4); (ii) When integrating over the layer region excluding the interface (𝑧≳ 0.15nm) the asymmetric contribution of MoS2 largely averages out, whereas that of WSe2 does not. Note that this contribution has a stronger depolarization effect due to its larger distance from the 

6 

interface. Due to both factors, depolarization is expected to commence at a much lower hole doping value in WSe2 than MoS2 (see Fig. S8 for comparison). 

**Fig. 4| Excess charge distribution calculations for polar bilayers of MoS2 (left panels) and WSe2 (right panels).** ( **a,b** ) Laterally averaged excess carrier density profiles of the undoped bilayers, 𝜌0𝑒𝑥(𝑧) (dashed black 

𝜌0𝑒𝑥(𝑧) (dashed black 0𝑒𝑥(𝑧) (dashed black 𝑒𝑥(𝑧) (dashed black (𝑧) (dashed black  (dashed black line), defined as the density of the bilayer stack after subtracting the superposition charge density of two isolated layers. Doping-induced variations in the excess carrier density, 𝛥𝜌<sup>𝑒𝑥</sup> (𝑧), for different hole densities are represented by the colored lines (see legends in panels c and d). All 𝛥𝜌<sup>𝑒𝑥</sup> (𝑧) values for MoS _2_ are divided by 10 for clarity of the representation. ( **c,d** ) Doping induced antisymmetric part of the charge carrier density variation profiles defined as 𝛥𝜌<sup>𝑒𝑥</sup> (𝑧) −𝛥𝜌<sup>𝑒𝑥</sup> (−𝑧) , where 𝑧= 0 is set at the bilayer center for several doping densities. ( **e,f** ) Band structures of the undoped bilayer systems, colored according to the projection of the corresponding crystal momentum state on the top (red) and bottom (blue) layers (see text). K momentum states split into layer-specific bands (prominent red\blue) that resemble the dashed black bands of a monolayer, only 𝑒𝛥𝑉𝐾𝑃 separated by ~ _~~.~~ ._ A larger 2 splitting due to strong interlayerdelocalization (designated by nearly white bands) appears for valence _._ 𝛤 and conduction _._ 𝑄 _._ states. 



Finally, to explain the computationally predicted asymmetry between the polarization response to electron and hole doping, we plot in Fig. 4e,f the band structures of the two interfaces, colored according to the relative contribution of the two layers to each 𝑘-dependent state, 𝜙𝑘(𝑥, 𝑦, 𝑧). To this ∞ ∞ ∞ end, we evaluate its projection on the top layer as 𝑃𝑘𝑇𝑜𝑝 = ∫−∞ d𝑥∫−∞ d𝑦∫0 d𝑧|𝜙𝑘(𝑥, 𝑦, 𝑧)|<sup>2</sup> , with the corresponding projection on the bottom layer given by 𝑃𝑘𝐵𝑜𝑡 = 1 −𝑃𝑘𝑇𝑜𝑝. This analysis clearly shows that the valence band states at the Γ point, ΓVB, which split considerably upon the formation of the bilayer structure, are delocalized over both layers. Similar behavior is found for the conduction band states at the Q point (positioned at the midpoint between the Γ and K points of the Brillouin zone), QCB, at the bottom of the conduction band<sup>31,32</sup> . Conversely, the corresponding 𝐾-point states are localized on either of the layers<sup>36</sup> and split to a much smaller extent (comparable to Δ𝑉𝐾𝑃/2), mainly due to the emergent interface dipole (more details in SI.S6). Therefore, changes in the 

7 

occupation of the latter states will have a significant effect on the polarization. Fig. 4e shows that for MoS2 the 𝐾𝐶𝐵 states are encountered earlier upon raising the Fermi level (electron doping), whereas Γ𝑉𝐵 states are encountered earlier upon lowering the Fermi level (hole doping). This explains the trend observed in Fig. 3d (solid red line), namely that depolarization commences at lower electron doping in MoS2. Fig. 4f predicts an opposite behavior for WSe2, owing to a much larger spin-orbit coupling induced upshift of the layer polarized 𝐾𝑉𝐵 states and downshift of the layer delocalized QCB states, which explains the trend shown by the dashed blue line in Fig. 3d. 

To conclude, we have demonstrated stacked 2D layers that support robust interfacial polarization which features three unique characteristics: (i) it supports polarization as high as ~0.5 pC/m per interface (S1.d); (ii) it exhibits distinct and switchable multiple polarization configurations; and (iii) it sustains charge carrier densities up to 10<sup>14</sup> cm<sup>-2</sup> , a computational prediction that is confirmed by our current experiments for charge carrier densities as high as 10<sup>13</sup> cm<sup>-2</sup> . The coexistence of polarization and conductivity is attributed to the interfacial localization of the polarization and the excess charge carriers delocalization on both layers, which inhibits strong depolarization fields. Notably, the measured polarization and density values are nearly ten times larger than those found for non-hexagonal TMDs to date<sup>5,7,8,10,37,12</sup> and may support rich correlated electronic phases<sup>38–40</sup> . The cumulative distinct multi-polar ladder of states reported here thus paves the way to bottom-up construction of 3D multi-ferroic structures out of well-defined 2D building blocks in a controllable, position- and orientation-specific manner. 

### **Acknowledgments** 

We thank A. Cerreta (Park Systems) for AFM support, and N. Ravid for laboratory support. K.W. and T.T. acknowledge support from JSPS KAKENHI (Grant Numbers 19H05790, 20H00354 and 21H05233). M.G. has been supported by the Israel Science Foundation (ISF) and the Directorate for Defense Research and Development (DDR&D) grant No. 3427/21 and by the US-Israel Binational Science Foundation (BSF) Grant No. 2020072. L.K. thanks the Aryeh and Mintzi Katzman Professorial Chair and the Helen and Martin Kimmel Award for Innovative Investigation. M.U. acknowledges the financial support of the Israel Science Foundation, Grant No. 1141/18 and the binational program of the National Science Foundation of China and Israel Science Foundation, Grant No. 3191/19. O.H. is grateful for the generous financial support of the Israel Science Foundation under grant no. 1586/17, the Heineman Chair in Physical Chemistry, and the Naomi Foundation for generous financial support via the 2017 Kadar Award. M.B.S. acknowledges funding by the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement no.852925), and the Israel Science Foundation under grants no. 1652/18, and 3623/21. O.H. and M.B.S. acknowledge the Center for Nanoscience and Nanotechnology of Tel Aviv University. 

8 

#### <mark>References</mark> 

1. Li, L. & Wu, M. Binary Compound Bilayer and Multilayer with Vertical Polarizations: TwoDimensional Ferroelectrics, Multiferroics, and Nanogenerators. _ACS.Nano_ **11,** 6382–6388 (2017). 

2. Woods, C. R., Ares, P., Nevison-Andrews, H., Holwill, M. J., Fabregas, R., Guinea, F., Geim, A. K., Novoselov, K. S., Walet, N. R. & Fumagalli, L. Charge-polarized interfacial superlattices in marginally twisted hexagonal boron nitride. _Nat .Commun_ **12,** 1–7 (2021). 

3. Yasuda, K., Wang, X., Watanabe, K., Taniguchi, T. & Jarillo-Herrero, P. Stacking-engineered ferroelectricity in bilayer boron nitride. _Science.(80- .)_ **372,** 1458–1462 (2021). 

4. Vizner Stern, M., Waschitz, Y., Cao, W., Nevo, I., Watanabe, K., Taniguchi, T., Sela, E., Urbakh, M., Hod, O. & Ben Shalom, M. Interfacial ferroelectricity by van der Waals sliding. _Science.(80- .)_ **372,** 142–1466 (2021). 

5. Fei, Z., Zhao, W., Palomaki, T. A., Sun, B., Miller, M. K., Zhao, Z., Yan, J., Xu, X. & Cobden, D. H. Ferroelectric switching of a two-dimensional metal. _Nature_ **560,** 336–339 (2018). 

6. Yuan, S., Luo, X., Chan, H. L., Xiao, C., Dai, Y., Xie, M. & Hao, J. Room-temperature ferroelectricity in MoTe2 down to the atomic monolayer limit. _Nat .Commun .2019.101_ **10,** 1–6 (2019). 

7. Sharma, P., Xiang, F. X., Shao, D. F., Zhang, D., Tsymbal, E. Y., Hamilton, A. R. & Seidel, J. A room-temperature ferroelectric semimetal. _Sci .Adv_ **5,** (2019). 

8. de la Barrera, S. C., Cao, Q., Gao, Y., Gao, Y., Bheemarasetty, V. S., Yan, J., Mandrus, D. G., Zhu, W., Xiao, D. & Hunt, B. M. Direct measurement of ferroelectric polarization in a tunable semimetal. _Nat .Commun .2021.121_ **12,** 1–9 (2021). 

9. Wang, X., Yasuda, K., Zhang, Y., Liu, S., Watanabe, K., Taniguchi, T., Hone, J., Fu, L. & Jarillo-Herrero, P. Interfacial ferroelectricity in rhombohedral-stacked bilayer transition metal dichalcogenides. _Nat .Nanotechnol_ (2022). doi:10.1038/s41565-021-01059-z 

10. Wan, Y., Hu, T., Mao, X., Fu, J., Yuan, K., Song, Y., Gan, X., Xu, X., Xue, M., Cheng, X., Huang, C., Yang, J., Dai, L., Zeng, H. & Kan, E.  Room-Temperature Ferroelectricity in   1 T   ′     -     ReS   2     Multilayers . _Phys .Rev .Lett_ **128,** 067601 (2022). 

11. Weston, A., Castanon, E. G., Enaldiev, V., Ferreira, F., Bhattacharjee, S., Xu, S., Corte-León, H., Wu, Z., Clark, N., Summerfield, A., Hashimoto, T., Gao, Y., Wang, W., Hamer, M., Read, H., Fumagalli, L., Kretinin, A. V., Haigh, S. J., Kazakova, O., Geim, A. K., Fal’ko, V. I. & Gorbachev, R. Interfacial ferroelectricity in marginally twisted 2D semiconductors. _Nat . Nanotechnol_ **17,** 390–395 (2022). 

12. Lipatov, A., Chaudhary, P., Guan, Z., Lu, H., Li, G., Crégut, O., Dorkenoo, K. D., Proksch, R., Cherifi-Hertel, S., Shao, D.-F., Tsymbal, E. Y., Íñiguez, J., Sinitskii, A. & Gruverman, A. Direct observation of ferroelectricity in two-dimensional MoS2. _npj.2D.Mater .Appl_ **6,** 18 (2022). 

13. Lines, M. & Glass, A. _Principles.and.applications.of.ferroelectrics.and.related.materials_ . (2001). at <https://www.google.com/books?hl=en&lr=&id=p6ruJH8C84kC&oi=fnd&pg=PA1&dq=Pri nciples+and+Applications+of+Ferroelectrics+and+Related+Materials+(Oxford+University.+ Press,+1977)&ots=3F7179vH7T&sig=nefFtl1fv8lkap4UyS1S3QrVUro> 

14. Wu, M. & Li, J. Sliding ferroelectricity in 2D van der Waals materials: Related physics and future opportunities. _Proc .Natl .Acad .Sci .U .S .A_ **118,** (2021). 

15. Eerenstein, W., Mathur, N. D. & Scott, J. F. Multiferroic and magnetoelectric materials. _Nat . 2006.4427104_ **442,** 759–765 (2006). 

16. Setter, N., Damjanovic, D., Eng, L., Fox, G., Gevorgian, S., Hong, S., Kingon, A., Kohlstedt, H., Park, N. Y., Stephenson, G. B., Stolitchnov, I., Taganstev, A. K., Taylor, D. V., Yamada, T. & Streiffer, S. Ferroelectric thin films: Review of materials, properties, and applications. _J ._ 

9 

- _Appl .Phys_ **100,** 051606 (2006). 

- 17. Anderson, P. W. & Blount, E. I. Symmetry Considerations on Martensitic Transformations: ‘Ferroelectric’ Metals? _Phys .Rev .Lett_ **14,** 217–219 (1965). 

18. Xue, F., He, J. H. & Zhang, X. Emerging van der Waals ferroelectrics: Unique properties and novel devices. _Appl .Phys .Rev_ **8,** 021316 (2021). 

19. Iwazaki, Y., Suzuki, T., Mizuno, Y. & Tsuneyuki, S. Doping-induced phase transitions in ferroelectric BaTiO3 from first-principles calculations. _Phys .Rev .B.-.Condens .Matter. Mater .Phys_ **86,** 214103 (2012). 

20. Wang, Y., Liu, X., Burton, J. D., Jaswal, S. S. & Tsymbal, E. Y. Ferroelectric Instability Under Screened Coulomb Interactions. (2012). doi:10.1103/PhysRevLett.109.247601 

21. Zhao, H. J., Filippetti, A., Escorihuela-Sayalero, C., Delugas, P., Canadell, E., Bellaiche, L., Fiorentini, V. & Íñiguez, J. Meta-screening and permanence of polar distortion in metallized ferroelectrics. _Phys .Rev .B_ **97,** 054107 (2018). 

22. Shi, Y., Guo, Y., Wang, X., Princep, A. J., Khalyavin, D., Manuel, P., Michiue, Y., Sato, A., Tsuda, K., Yu, S., Arai, M., Shirako, Y., Akaogi, M., Wang, N., Yamaura, K. & Boothroyd, A. T. A ferroelectric-like structural transition in a metal. _Nat .Mater .2013.1211_ **12,** 1024–1027 (2013). 

23. Zhou, W. X. & Ariando, A. Review on ferroelectric/polar metals. _Jpn .J .Appl .Phys_ **59,** SI0802 (2020). 

24. Dawber, M., Rabe, K. M. & Scott, J. F. Physics of thin-film ferroelectric oxides. _Rev .Mod . Phys_ **77,** 1083–1130 (2005). 

25. Jia, C. L., Nagarajan, V., He, J. Q., Houben, L., Zhao, T., Ramesh, R., Urban, K. & Waser, R. Unit-cell scale mapping of ferroelectricity and tetragonality in epitaxial ultrathin ferroelectric films. _Nat .Mater_ **6,** 64–69 (2007). 

26. Böscke, T. S., Müller, J., Bräuhaus, D., Schröder, U. & Böttger, U. Ferroelectricity in hafnium oxide thin films. _Appl .Phys .Lett_ **99,** 102903 (2011). 

27. Liu, F., You, L., Seyler, K. L., Li, X., Yu, P., Lin, J., Wang, X., Zhou, J., Wang, H., He, H., Pantelides, S. T., Zhou, W., Sharma, P., Xu, X., Ajayan, P. M., Wang, J. & Liu, Z. Roomtemperature ferroelectricity in CuInP2S6 ultrathin flakes. _Nat .Commun .2016.71_ **7,** 1–6 (2016). 

28. Alden, J. S., Tsen, A. W., Huang, P. Y., Hovden, R., Brown, L., Park, J., Muller, D. A. & McEuen, P. L. Strain solitons and topological defects in bilayer graphene. _Proc .Natl .Acad . Sci .U .S .A_ **110,** 11256–11260 (2013). 

29. Weston, A., Zou, Y., Enaldiev, V., Summerfield, A., Clark, N., Zólyomi, V., Graham, A., Yelgel, C., Magorrian, S., Zhou, M., Zultak, J., Hopkinson, D., Barinov, A., Bointon, T. H., Kretinin, A., Wilson, N. R., Beton, P. H., Fal’ko, V. I., Haigh, S. J. & Gorbachev, R. Atomic reconstruction in twisted bilayers of transition metal dichalcogenides. _Nat .Nanotechnol_ **15,** 592–597 (2020). 

30. Rosenberger, M. R., Chuang, H. J., Phillips, M., Oleshko, V. P., McCreary, K. M., Sivaram, S. V., Hellberg, C. S. & Jonker, B. T. Twist Angle-Dependent Atomic Reconstruction and Moiré Patterns in Transition Metal Dichalcogenide Heterostructures. _ACS.Nano_ **14,** 4550– 4558 (2020). 

31. Ferreira, F., Enaldiev, V. V, Fal’ko, V. I. & Magorrian, S. J. Weak ferroelectric charge transfer in layer-asymmetric bilayers of 2D semiconductors. _Sci .Rep_ **11,** 13422 (2021). 

32. Magorrian, S. J., Enaldiev, V. V., Zólyomi, V., Ferreira, F., Fal’ko, V. I. & Ruiz-Tijerina, D. A. Multifaceted moiré superlattice physics in twisted bilayers. _Phys .Rev .B_ **104,** (2021). 

33. We note that adding AA’ stacked layers does not affect the overall polarization due to mirror symmetry (as in h-BN). 

34. Sinai, O. & Kronik, L. Simulated doping of Si from first principles using pseudoatoms. _Phys . Rev .B.-.Condens .Matter.Mater .Phys_ **87,** 235305 (2013). 

10 

35. Collins, L., Kilpatrick, J. I., Kalinin, S. V. & Rodriguez, B. J. Towards nanoscale electrical measurements in liquid by advanced KPFM techniques: a review. _Reports.Prog .Phys_ **81,** 086101 (2018). 

36. Sung, J., Zhou, Y., Scuri, G., Zólyomi, V., Andersen, T. I., Yoo, H., Wild, D. S., Joe, A. Y., Gelly, R. J., Heo, H., Magorrian, S. J., Bérubé, D., Valdivia, A. M. M., Taniguchi, T., Watanabe, K., Lukin, M. D., Kim, P., Fal’ko, V. I. & Park, H. _Broken.mirror.symmetry.in. excitonic.response.of.reconstructed.domains.in.twisted.MoSe2/MoSe2.bilayers_ . _Nat . Nanotechnol_ **15,** (2020). 

37. Yuan, S., Luo, X., Chan, H. L., Xiao, C., Dai, Y., Xie, M. & Hao, J. Room-temperature ferroelectricity in MoTe2 down to the atomic monolayer limit. _Nat .Commun .2019.101_ **10,** 1–6 (2019). 

38. Chen, W., Sun, Z., Wang, Z., Gu, L., Xu, X., Wu, S. & Gao, C. Direct observation of van der Waals stacking–dependent interlayer magnetism. _Science.(80- .)_ **366,** 983–987 (2019). 

39. Vaňo, V., Amini, M., Ganguli, S. C., Chen, G., Lado, J. L., Kezilebieke, S. & Liljeroth, P. Artificial heavy fermions in a van der Waals heterostructure. _Nat .2021.5997886_ **599,** 582– 586 (2021). 

40. Liu, X., Pyatakov, A. P. & Ren, W. Magnetoelectric Coupling in Multiferroic Bilayer VS2. _Phys .Rev .Lett_ **125,** 247601 (2020). 

11 

# **Supplementary Information** 

## **S1. Materials and methods** 

#### **a)** **<u>Device fabrication</u>** 

_h_ -BN flakes of various thicknesses were exfoliated onto a Si/SiO2 substrate. MoS2 and WSe2, obtained from HQ Graphene, were exfoliated onto polydimethylsiloxane (PDMS). Large single-layer flakes (~20  m or more) of transition metal dichalcogenides (TMDs) were identified using optical contrast. _h-_ BN flakes were picked up from the substrate and placed on few-layered graphene or predesigned gold electrodes (Fig. S1a). Subsequently, parallel bilayers of TMDs were prepared on the _h-_ BN surface using the 'tear and stack' technique. In this process, a fragment of a chosen TMD flake is first stamped on _h_ -BN, followed by successive stacking of the remaining flake on it. The entire stack is then encapsulated with another _h_ -BN flake. The bottom graphene or gold substrate acts as a reference electrode for Kelvin probe force microscopy (KPFM) measurements and as a gate electrode. In the tri-layer measurements (without doping), the stack was placed directly on the conducting electrode without the bottom _h_ -BN. 

The samples studied in Fig. 2, with MoS2 multi-layered systems beyond tri-layer stacks, were obtained by exfoliating the 3R single crystal (purchased from HQ graphene) to a bare SiO2 surface and connecting the flakes to a metal electrode. 

|**Device Name**|**Electrode**|**_h_-BN spacer**<br>**thickness (nm)**|
|---|---|---|
|Dev 1: MoS2|Au|6.3|
|Dev 2: WSe2|Few layer graphene|12|
|Dev 3: WSe2|Au|5.1|



Table S1. Details of reported devices. 

12 

#### **b)** **<u>AFM measurements</u>** 

Topography and KPFM measurements were acquired simultaneously, using Park System NX10 AFM in non-contact scanning mode. The electrostatic signal was measured at a side-band frequency using a built-in lock-in amplifier. We used PointProbe Plus Electrostatic Force Microscopy (PPP-EFM) _n_ - doped tips with a conductive coating. The mechanical resonance frequency of the tips was ~75 kHz and the force constant was 3 N/m. The cantilever oscillated mechanically with an amplitude ranging from 20 to 5 nm. In several experiments, the average height above the surface, _h,_ was controlled via a two-pass measurement. The first pass records the topography, whereas in the second pass the tip follows the same scan line with a predefined lift (typically 4-5 nm) and measures the KPFM signal. The cantilever was excited with an AC voltage to perform KPFM measurements, with an amplitude of 1.5-4 V and a frequency of 2-4 kHz. In the closed-loop measurements, the DC voltage was controlled by a bias servo to obtain the surface potential. Images were acquired using the Park SmartScan software and the data analyzed with Gwyddion program. 

Obtaining a reliable quantitative assessment of the absolute surface potential is challenging and requires delicate calibration processes<sup>1–3</sup> , including the use of different tips, substrates, _h_ -BN thicknesses, height of the tip above the surface, and amplitude/frequency (side-band) operation mode (see Ref. 4 of the main text). We note that the surface potential was found to be independent of the h- BN stack thickness in the range of 1-10 nm, as long as the dimensions of the domain were > 300x300 nm2. Hence, we focus our analysis on large domains, where the potential away from the domain wall saturates. Importantly, the analyses and conclusions in the present work rely on the relative change of the surface potential between two adjacent and oppositely polarized domains (see Fig. 1b), or on the relative change in the gate voltage (Fig. 3d), rather than on absolute values. The relative changes are considerably less prone to calibration uncertainties. 

13 



_Figure.S1 .Further.device.characterization .(a,b).Optical.microscope.image.of.a.typical.device .Two. circuit.configurations.of.gating.and.KPFM.measurement.are.illustrated .(c).The.electric.current.along. the.MoS2.bilayers.is.measured.versus.the.source-drain.bias.(Vsd).and.plotted.for.several.fixed.gate. voltages.(Vg).at.room.temperature .(d,e).Simultaneous.measurement.of.topography.and.KPFM.maps. for. a. tri-layer. WSe2. structure. (also. shown. in. Fig 1. in. the. main. text) . The. dark. regions. in. the. topography.map.indicate.a.crack.in.one.of.the.layers,.separating.regions.of.trilayers.with.one.and. two.active.interfaces .(e,f).Examples.of.ferroelectric-like.coupling.between.the.two.active.interfaces. in.large-area.domains .The.↑↓.(ABA,.neutral.color,.0 2V).domains.cover.a.smaller.area.than.the.↓↓. (CBA,.dark,.0 02V).domains.(circumscribed.in.green) .The.same.is.found.for.↑↑.(ABC,.bright,.0 3V). regions.marked.in.black .The.solid.red.and.dashed.blue.lines.in.(f).mark.the.line.cut.position.of.the. data.shown.in.the.main-text,.Fig .1b_ 

#### **c)** **<u>Triangular Domain Formation</u>** 

The domain walls exhibit an intriguing geometrical structure that emerges due to the slight twist angle between the flakes and affects the entire atomically reconstructed triangular lattice. The shear boundary conditions of the artificial stacking experiments result in a shear deformation of precisely one planar interatomic spacing in each domain wall<sup>4</sup> (for WSe2, each domain contributes a shear of 3.3/√3 Å ). In fact, for a given global twist angle, there is a fixed number of crossing points between domain walls that is determined by the moiré superstructure topology. In our previous study (Ref. 4), we modeled the triangular superlattice structure using dedicated intra- and inter-layer force fields. 

14 

The relaxed geometry suggested that ~10 nm away from the domain wall and beyond, the stacking is perfect with zero inter-layer twists or strain, in agreement with experiment. The topological number of domain walls that end at domain wall crossings is directly related to the global twist angle in a given section by dividing the number of domain walls within the section and can be obtained by the number of interatomic spacings along the section side. For example, the scale bar in figure 1a is 0.5 µm long (~ 2,500 interatomic spacings), and it crosses ten domain walls (a total shear of 10 interatomic spacings), indicating an angle of 10/2,500 radians. 

#### **d)** **<u>2D polarization calculation</u>** 

The 2D polarization per interface is extracted directly from the measured Δ𝑉KP of a single active 𝜖0Δ𝑉KP interface via the relation 𝑃2𝐷 = . With 𝜖0 = 8.854 × 10<sup>−12</sup> Fm<sup>−1</sup> and Δ𝑉KP ≈120 mV , we 2 ∞ get 𝑃2D ≈0.53 pCm<sup>−1</sup> . This result is in agreement with the calculated value of 𝑃2𝐷 = ∫−∞ 𝜌0𝑒𝑥(𝑧)𝑧𝑑𝑧, with 𝜌0𝑒𝑥(𝑧) being represented by the dashed black line in Fig. 4a,b. 

15 

## **S2. Finite Ferroelectric-like coupling of two active interfaces** 

While the internal electric fields are mostly confined to the interfacial volume, as discussed in the main text, we find indications of finite coupling between adjacent regions of two active interfaces structures. This is achieved by comparing the average area coverage of co-aligned (ABC/CBA) and anti-aligned (ABA) domains (see Fig. S1e,f). The higher adhesion phase naturally expands on the expense of other stacking configurations<sup>5</sup> . Indeed, we find that regions in the map of large area domains (marked in black or green) show a clear preference for ABC or CBA stackings with ↑↑ or ↓↓ (bright or dark) polarization, respectively, at the expense of the anti-aligned ABA and BAB domains (with neutral-color) of **↑↓** or **↓↑** polarization, respectively. A close look at two active interface regions with smaller domains (outside the marks) also shows a reduced area of the neutral domains even away from the physical edge of the layers (although the area difference here is minor). Recently, we reported a similar behavior in a single active interface system of parallel _h_ -BN bilayers, where domain wall sliding in response to an externally applied electric field promoted larger domains that align with the external field at the expense of the anti-aligned configuration<sup>6</sup> (see also Fig. 3a-c). As previously discussed,<sup>6</sup> the dynamics of this phenomenon is governed by the loss of adhesion energy in the domain wall network and the pinning from the disorder at the interface. The internal out-ofplane coupling reported here (with no external field) reveals a more stable ferroelectric coupling (ABCABC…) in comparison to the antiferroelectric order in the Bernal (ABAB..) configuration. 

16 

## **S3. Doping and de-polarization measurements** 

A precise measurement of the out-of-plane polarization at the high doping limit is challenging due to the KPFM signal sensitivity to long-range coulomb forces. The latter interacts with the tip's cantilever and cone rather than its local apex only<sup>7</sup> . While the side-band measurement mode overcomes this challenge to provide quantitative information at zero gate bias, its reliability drops as the external potential on the gate electrode and, correspondingly, the doping charge density on the TMD increase. Crucially, this measurement limitation can only underestimate (by averaging out) the local potential drop, ΔVKP, between domains and its corresponding polarization magnitude. To minimize this underestimation, we used two complementary gating schemes, where either the sample potential is grounded and the gold electrode is biased or vice versa (Fig. S1b, a respectively). Data shown in the main text and in SI are recorded in the configuration of Fig. S1a. We also focused on domains located next to the electrode's edges (while placing the cantilever outside them) and controlled the potential on the global silicon substrate independently. Additional limitations arise from the motion of domain walls at high charge doping and displacement fields, surface chemical adsorption, and surface degradation (see Fig. S2a-c). The latter hinders our quantitative analysis even with a very thin gate dielectric (down to 5 nm thick), where the maximum doping level (at the _h_ -BN breakdown electric field) is reached at moderate gate potentials. 

Lastly, localized defect states at the host crystals may reduce the occupation of delocalized states by the gate bias. This may result in some overestimation of the precise doping if extracted from the geometric capacitance only. To eliminate this overestimation, we extracted the doping density in Fig. 3d from the change in the average potential (Vavg), measured on oppositely polarized domains (as marked in Fig. 1b), rather than directly from the applied Vg. Vavg grows with Vg beyond some threshold value, and in one direction only for each particular sample (Fig. S2d). We attribute this behavior to unpinning of the Fermi-level from gap states associated with native dopants in each sample. The latter seems to prevent achieving electron and hole doping in the same sample. Importantly, Vavg is only sensitive to the mobile charge density that accumulates to screen the bottom electrode, regardless of internal properties of the electrodes such as localized defect states, Schottky barriers, or quantum capacitance. The deviation from the ideal Vavg = -Vg (dashed black) slope at high |𝑉𝑎𝑣𝑔| is attributed to the underestimation of the local KPFM signal in case of large doping levels and spatially alternating potentials at the edges of the electrodes, as discussed above. Altogether, the measurements in Fig. 3d provide an underestimation of the polarization magnitude and the mobile charge density. 

17 



Figure S2. **Doping and depolarization measurements** . (a-c) Examples of surface potential maps obtained from a parallelly stacked WSe2 bilayer under several gate biases Vg (Device 3). Note the domain wall motion at high doping density (dashed green lines) that extends bright areas over dark domains<sup>6</sup> . (d) The average KP potential of the TMD bilayers, Vavg, as a function of the applied gate potential, Vg. 

18 

## **S4. Calculation of multi-layered WSe2 and MoS2 polarization** 

In Figs. 1c and 2f of the main text we present the electrostatic potential profile along the normal direction of an ABC stacked WSe2 trilayer and the thickness dependence of the polarization of parallelly stacked MoS2 multilayered systems, respectively. The potential profiels were calculated using the Perdew-Burke-Ernzerhof (PBE) generalized-gradient exchange-correlation density functional approximation,<sup>8</sup> augmented by the Grimme-D3 dispersion correction with Becke-Johnson (BJ) damping<sup>9</sup> as implemented in the Vienna Ab-initio Simulation Package (VASP).<sup>10</sup> The core electrons of the Mo, W, S, and Se atoms were treated via the projector augmented wave (PAW) approach. Spin-orbit interactions were included. This level of theory was recently successfully used to calculate the polarization of transition metal dichalcogenide (TMD) bilayers.<sup>11</sup> 

AB stacked WSe2 and MoS2 bilayers, constructed from two relaxed monolayers, were allowed to further relax, yielding lattice constants of 3.29 Å and 3.15 Å, respectively, and interlayer distances (defined as the normal distance between adjacent Se or S ions of the two layers) of 3.10 Å and 2.90 Å , respectively. Single-point electron density calculations were then performed on the relaxed structure with a plane wave energy cutoff of 600 eV and a k-point mesh of 12 × 12 × 1, setting a vertical vacuum size of 10 nm to avoid interactions between adjacent bilayer images. To evaluate the vertical polarization, a dipole moment correction was employed. The potential and charge density profiles along the vertical direction of the two bilayers are shown in Fig. S3. The resulting difference between the electrostatic potential values obtained far above the top and below the bottom surfaces of the WSe2 and MoS2 bilayers are 69 meV and 82 meV, respectively, defining the vertical polarization of the two systems. Multilayered MoS2 systems were constructed on the basis of the AB stacked bilayer by adding additional layers in the AB stacking configuration. Following further optimization, single point potential profile calculations were performed as detailed above. Convergence tests of the VASP calculations (see Fig. S4) with respect to the vacuum size, energy cutoff, and number of reciprocal space k-points indicate that our choice of parameters leads to WSe2 (MoS2) binding energies that are converged to within 0.006 (0.0001), 0.002 (0.01), and 0.007 (0.003) meV/atom, respectively. Correspondingly, the electrostatic potential difference converges to within 0.01 (0.5), 0.05 (0.001), and 0.04 (0.03) meV with respect to the vacuum size, energy cut-off, and number of reciprocal space k-points, respectively. 

19 



Figure S3. **Potential and charge density profiles of WSe2 and MoS2 bilayers.** Difference between bilayer and isolated monolayer plane-averaged potential (black) and charge density (red) for an AB stacked (a) WSe2 and (b) MoS2 bilayers. The dashed lines represent the vertical location of the ions. The origin of the horizontal axis is set to the midpoint between the layers. 



Figure S4. **Convergence tests.** Convergence tests of the binding energy (black curve, left vertical axis) and electrostatic potential difference (red curve, right vertical axis) of WSe2 (top panels) and MoS2 (bottom panels) bilayers (same structures as in Fig. S3) as a function of: (a) vacuum size; (b) energy cutoff, and (c) number of k-points. 

20 

## **S5. Calculation of doping-induced depolarization in WSe2 and MoS2** 

Doping calculations of bilayer WSe2 and MoS2 were performed using the fractional nuclear charge pseudoatom approach<sup>12</sup> , allowing for simulating doping densities in the experimentally relevant range. To this end, we use pseudopotentials (PPs) generated for atoms with fractional nuclear charge. These calculations were performed using the open source package Quantum Espresso<sup>13</sup> , instead of VASP that was used in section S4, allowing us to construct appropriate PPs. We first generated Rappe-RabeKaxiras-Joannopoulos (RRKJ)<sup>14</sup> PPs, including spin-orbit interactions, using the ld1.x program of the plane-wave pseudopotential Quantum Espresso package<sup>13,15</sup> . The nuclear charge of the pseudoatom was set to the original charge of the neutral element plus a small fractional charge 𝜀. For example, the nuclear charge of a doped pseudo W atom was set to 𝑍= 74 ± 𝜀. The valence electronic charge was changed accordingly to maintain neutrality of the unit-cell, with an electron configuration given by [Xe]4𝑓<sup>14</sup> 6𝑠<sup>2</sup> 6𝑝<sup>0</sup> 5𝑑<sup>4±𝜀</sup> . A set of PPs were generated by setting 𝜀= 10<sup>−9</sup> , 10<sup>−8</sup> , … , 10<sup>−2</sup> for all W atoms in the bilayer system, corresponding to doping densities of Δ𝑛2D = 2.1 × 10<sup>7</sup> , 2.1 × 10<sup>8</sup> , … , 2.1 × 10<sup>13</sup> cm<sup>−2</sup> , respectively. A similar procedure was used to generate MoS2 PPs with fractional nuclear charge and valence charge. For example, for a pseudo Mo nuclear charge of 𝑍= 42 ± 𝜀, the electron configuration was set to [Kr]5𝑠<sup>2</sup> 5𝑝<sup>0</sup> 4𝑑<sup>4±𝜀</sup> . 

Single point calculations were performed using the generated PPs to obtain the electron density and the corresponding electrostatic potential profiles. To this end, we employed the PBE generalizedgradient density functional approximation<sup>8</sup> and the Grimme-D3 dispersion correction with BJ damping,<sup>9</sup> as implemented in Quantum Espresso. A plane wave energy cutoff of 60 Ry (816.34 eV) was used with a k-mesh of 12 × 12 × 1 , and a vertical vacuum size of 10 nm was set to avoid interactions between adjacent bilayer images. Fermi-Dirac smearing was used to enhance the convergence of the self-consistent cycle. To obtain the electrostatic potential profiles, a dipole moment correction was used. 

As in the procedure discussed in section S4, AB-stacked WSe2 and MoS2 bilayers were first constructed and optimized, yielding lattice constants of 3.29 Å and 3.16 Å and interlayer distances of 3.05 Å and 2.95 Å, respectively. The resulting electrostatic potential drops were 71 meV and 76 meV for the undoped WSe2 and MoS2 bilayers, respectively. Note that little difference (2 and 6 meV for WSe2 and MoS2, respectively) was found between the potential drops calculated by VASP in section S4 and those obtained using Quantum Espresso. The potential and charge density profiles along the vertical direction for the two bilayers are shown in Fig. S5. 

Convergence tests for the Quantum Espresso calculations (see Fig. S6) with respect to the vacuum size, energy cut-off, and number of k-points indicate that our choice of parameters leads to WSe2 

21 

(MoS2) binding energies that are converged to within 0.0003 (0.0003), 0.004 (0.003), and 0.003 (0.0004) meV/atom, respectively. Correspondingly, the electrostatic potential difference converges to within 2.6 (0.9), 3.8 (1.1), and 3.6 (2.4) meV with respect to the vacuum size, energy cut-off, and number of reciprocal space k-points, respectively. 



Figure S5. **Potential and charge density profiles for WSe2 and MoS2 bilayer.** Difference between bilayer and isolated monolayer plane-averaged potential (black) and charge density (red) for AB stacked (a) WSe2 and (b) MoS2 bilayers. The dashed lines represent the vertical location of the ions. The origin of the horizontal axis is set to the midpoint between the layers. 



Figure S6. **Convergence tests.** Convergence tests of the binding energy (black curve, left vertical axis) and electrostatic potential difference (red curve, right vertical axis) of WSe2 (top panels) and 

22 

MoS2 (bottom panels) bilayers (same structures as in Fig. S5) as a function of (a, d) vacuum size; (b, e) energy cutoff, and (c,f) number of k-points. 

Doping of the WSe2 and MoS2 bilayers was performed by charging the metal nuclei. As discussed in the main text, up to a system dependent hole or electron charge density, the polarization remains mostly unaffected, following which a polarization drop is clearly seen (see Fig. S7). We note that the fractional nuclear charge pseudoatom doping approach<sup>14</sup> adopted in this study remains valid as long as variations in the calculated band-structure, induced by the nuclear pseudo charging, are negligible. To confirm that our calculations satisfy this condition, we compare the bandstructures of the undoped and doped WSe2 (Fig. S8a) and MoS2 (Fig. S8d) bilayers up to the highest doping density considered. Our results clearly demonstrate merely minor deviations of the band-structures of the doped systems from those of the undoped counterparts. The energy difference between the topmost K and Γ valence band points for the doped and undoped systems is presented in Fig. S8b and S8e for WSe2 and MoS2, respectively. Larger energy differences at higher doping levels result from the depolarization shown in Fig. S7. As an additional validity test, the doping-induced WSe2 and MoS2 Fermi level shifts are presented in Fig. S8c and S8f, respectively, exhibiting the expected logarithmic dependence<sup>16</sup> up to doping densities of 1 × 10<sup>13</sup> cm<sup>−2</sup> . 



<!-- Start of picture text -->
80<br>60<br>40<br> W Se2 n-dope<br>20  W Se2 p-dope<br> M oS2 n-dope<br> M oS2 p-dope<br>0<br>1E11 1E12 1E13 1E14<br>D n2D (cm-2)<br>(meV) Df<br><!-- End of picture text -->

Figure S7. **Effect of doping on the interlayer potential drop.** The potential drop as a function of electron ( _n_ , filled squares) and hole ( _p_ , empty circles) doping density for AB stacked bilayer WSe2 (red) and MoS2 (blue). The doping is introduced via the metal pseudo nuclei. 

23 



Figure S8. **Band structure and Fermi level variations with doping charge density.** (a, d) The band structures of undoped (black), _n_ -doped (red), and _p_ -doped (green) WSe2 (a) and MoS2 (d). For WSe2 (MoS2) the _n_ -doped and _p_ -doped band-structures are plotted for a charge density of Δ𝑛2D = ∓1.1 × 10<sup>13</sup> 𝑐𝑚<sup>−2</sup> (∓9.3 × 10<sup>13</sup> 𝑐𝑚<sup>−2</sup> ), respectively. The origins of the vertical axes are set to the topmost Γ-point valence band energy (EΓ−VBM). (b, e) The variation of the difference between the topmost K and Γ valence band energies as a function of doping density for (b) WSe2 and (e) MoS2. Results are presented with respect to the energy difference obtained for the undoped system: Δ𝐸= [EK−VBM −EΓ−VBM]𝑑𝑜𝑝𝑒𝑑 −[EK−VBM −EΓ−VBM]𝑢𝑛𝑑𝑜𝑝𝑒𝑑. (c, f) The Fermi level position of (c) WSe2 and (f) MoS2 as a function of _n_ -doping (red) and _p_ -doping (blue) charge densities. The origins of vertical axes are set to the conduction band minimum energy for _n_ -doping and the valence band maximum energy for _p_ -doping. The doping is introduced via the metal pseudo nuclei. 

To demonstrate that our conclusions are independent on the choice of doping only via the metal atoms, we repeated the calculations by doping only via the chalcogen nuclei or doping all nuclei (see Fig. S9). Consistent results are obtained regardless of the doping scheme. 

24 



Figure S9. **Comparison of different doping schemes.** The polarization as a function of _n_ -doping (red) and _p_ -doping (blue) charge density for (a) WSe2 and (b) MoS2. Different doping schemes are applied including: only metal ions (filled squares), only chalcogen ions (open circles), or all ion doping (open triangle). For WSe2, the W ion doping charge excess values were 𝜀= 10<sup>−4</sup> , 2 × 10<sup>−4</sup> , 5 × 10<sup>−4</sup> , 8 × 10<sup>−4</sup> , 10<sup>−3</sup> , 2 × 10<sup>−3</sup> , 5 × 10<sup>−3</sup> , 8 × 10<sup>−3</sup> , 0.01 ; the Se ion doping charge excess values were 𝜀= 5 × 10<sup>−5</sup> , 10<sup>−4</sup> , 2.5 × 10<sup>−4</sup> , 4 × 10<sup>−4</sup> , 5 × 10<sup>−4</sup> , 10<sup>−3</sup> , 2.5 × 10<sup>−3</sup> , 4 × 10<sup>−3</sup> , 0.005 ; and the all ion doping charge excess values used were 𝜀= 3.3 × 10<sup>−5</sup> , 6.6 × 10<sup>−5</sup> , 1.6 × 10<sup>−4</sup> , 2.6 × 10<sup>−4</sup> , 3.3 × 10<sup>−4</sup> , 6.6 × 10<sup>−4</sup> , 1.6 × 10<sup>−3</sup> , 2.6 × 10<sup>−3</sup> , 0.0033 . The electron configuration of Se was given by [Ar]3𝑑<sup>10</sup> 4𝑠<sup>2</sup> 4𝑝<sup>4±𝜀</sup> , and the corresponding nuclear charge was 𝑍= 34 ± 𝜀 . For MoS2, the Mo ion doping charge excess values were 𝜀= 10<sup>−4</sup> , 10<sup>−3</sup> , 2 × 10<sup>−3</sup> , 5 × 10<sup>−3</sup> , 8 × 10<sup>−3</sup> , 0.01, 0.02, 0.03, 0.04 ; the S ion doping charge excess values were 𝜀= 5 × 10<sup>−5</sup> , 5 × 10<sup>−4</sup> , 10<sup>−3</sup> , 2.5 × 10<sup>−3</sup> , 4 × 10<sup>−4</sup> , 0.005, 0.01, 0.015, 0.02 ; and the all ion doping charge excess values used were 𝜀= 3.3 × 10<sup>−5</sup> , 3.3 × 10<sup>−4</sup> , 6.6 × 10<sup>−4</sup> , 1.6 × 10<sup>−3</sup> , 2.6 × 10<sup>−3</sup> , 3.3 × 10<sup>−3</sup> , 6.6 × 10<sup>−3</sup> , 0.01, 0.013. The electron configuration of S was given by [Ne]3𝑠<sup>2</sup> 3𝑝<sup>4±𝜀</sup> , and the corresponding nuclear charge was 𝑍= 16 ± 𝜀. 

25 

## **S6. Effect of polarization on the band-structure** 

To evaluate the effect of the emerging polarization on the band structure, we compare in Fig. S10 the band structure of the anti-parallel AA' stacked undoped bilayers with those of the parallel AB stacked counterparts, all evaluated at the same level of theory as described in section S5. The results clearly demonstrate band splitting of both the conduction and the valence bands at the K point. Notably, this splitting is of the order of the calculated vertical potential drops (see SI section S5 above), indicating that the emerging polarization is indeed causing the splitting. 



Figure S10. **Effect of polarization on the band structure.** The band structures of (a) MoS2 and (b) WSe2 bilayers at their anti-parallel AA' (solid black curve) and parallel AB (dashed red curve) stacking modes. 

26 

References: 

1. Panchal, V., Pearce, R., Yakimova, R., Tzalenchuk, A. & Kazakova, O. Standardization of surface potential measurements of graphene domains. _Sci .Rep_ **3** , 2597 (2013). 

2. Liscio, A., Palermo, V. & Samorì, P. Nanoscale quantitative measurement of the potential of charged nanostructures by electrostatic and Kelvin probe force microscopy: Unraveling electronic processes in complex materials. _Acc .Chem .Res_ **43** , 541–550 (2010). 

3. Melios, C. _et.al_ Carrier type inversion in quasi-free standing graphene: Studies of local electronic and structural properties. _Sci .Rep_ **5** , 10505 (2015). 

4. Alden, J. S. _et.al_ Strain solitons and topological defects in bilayer graphene. _Proc .Natl . Acad .Sci .U .S .A_ **110** , 11256–11260 (2013). 

5. Weston, A. _et.al_ Atomic reconstruction in twisted bilayers of transition metal dichalcogenides. _Nat .Nanotechnol_ **15** , 592–597 (2020). 

6. Vizner Stern, M. _et.al_ Interfacial ferroelectricity by van der Waals sliding. _Science.(80- .)_ **372** , 142–1466 (2021). 

7. Collins, L., Kilpatrick, J. I., Kalinin, S. V. & Rodriguez, B. J. Towards nanoscale electrical measurements in liquid by advanced KPFM techniques: a review. _Reports.Prog .Phys_ **81** , 086101 (2018). 

8. Perdew, J. P., Burke, K. & Ernzerhof, M. Generalized gradient approximation made simple. _Phys .Rev .Lett_ **77** , 3865–3868 (1996). 

9. Grimme, S., Antony, J., Ehrlich, S. & Krieg, H. A consistent and accurate ab initio parametrization of density functional dispersion correction (DFT-D) for the 94 elements H- Pu. _J .Chem .Phys_ **132** , 154104 (2010). 

10. Kresse, G. & Furthmüller, J. Efficient iterative schemes for ab initio total-energy calculations using a plane-wave basis set. _Phys .Rev .B.-.Condens .Matter.Mater .Phys_ **54** , 11169–11186 (1996). 

11. Wang, X. _et.al_ Interfacial ferroelectricity in rhombohedral-stacked bilayer transition metal dichalcogenides. _Nat .Nanotechnol_ (2022) doi:10.1038/s41565-021-01059-z. 

12. Sinai, O. & Kronik, L. Simulated doping of Si from first principles using pseudoatoms. _Phys . Rev .B.-.Condens .Matter.Mater .Phys_ **87** , 235305 (2013). 

13. Giannozzi, P. _et.al_ QUANTUM ESPRESSO: a modular and open-source software project for quantumsimulations of materials. _J .Phys .Condens .Matter_ **21** , 395502 (2009). 

14. Rappe, A. M., Rabe, K. M., Kaxiras, E. & Joannopoulos, J. D. Optimized pseudopotentials. _Phys .Rev .B_ **41** , 15 (1990). 

15. Dal Corso, A. Pseudopotentials periodic table: From H to Pu. _Comput .Mater .Sci_ **95** , 337– 350 (2014). 

16. Colinge, J. P. & Colinge, C. A. _Physics.of.Semiconductor.Devices_ . (Kluwer Academic Publishers, 2002). doi:10.1007/b117561. 

27 

