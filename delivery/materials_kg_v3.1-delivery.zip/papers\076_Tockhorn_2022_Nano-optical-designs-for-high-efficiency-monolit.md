# Nano-optical designs for high-efficiency monolithic perovskite–silicon tandem solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Nature Nanotechnology |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 265 |
| 作者 | P. Tockhorn, J. Sutter, Alexandros Cruz, P. Wagner, K. Jäger, D. Yoo, F. Lang, Max Grischek et al. |
| DOI | 10.1038/s41565-022-01228-8 |
| 源文件 | 076_Tockhorn_2022_Nano-optical-designs-for-high-efficiency-monolit.pdf |

---
## **nature nanotechnology** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

# **Nano-optical designs for high-efficiency monolithic perovskite–silicon tandem solar cells** 

Received: 10 March 2022 **Philipp Tockhorn**<sup>**1,8**</sup> **, Johannes Sutter**<sup>**1,8**</sup> **, Alexandros Cruz**<sup>**1**</sup> **, Philipp Wagner**<sup>**1**</sup> **, Klaus Jäger**<sup>**1,2**</sup> **, Danbi Yoo**<sup>**1**</sup> **, Felix Lang**<sup>**3**</sup> **, Max Grischek**<sup>**1,3**</sup> **, Bor Li**<sup>**1**</sup> **,** Accepted: 5 September 2022 **Jinzhao Li**<sup>**1**</sup> **, Oleksandra Shargaieva**<sup>**1**</sup> **, Eva Unger**<sup>**1,4**</sup> **, Amran Al-Ashouri**<sup>**1**</sup> **,** Published online: 24 October 2022 **Eike Köhnen**<sup>**1**</sup> **, Martin Stolterfoht**<sup>**3**</sup> **, Dieter Neher**<sup>**3**</sup> **, Rutger Schlatmann**<sup>**1,5**</sup> **, Bernd Rech**<sup>**1,6**</sup> **, Bernd Stannowski**<sup>**1,7**</sup> **, Steve Albrecht**<sup>**1,6**</sup> **and** Check for updates **Christiane Becker**<sup>**1,5**</sup> 

Perovskite–silicon tandem solar cells offer the possibility of overcoming the power conversion efficiency limit of conventional silicon solar cells. Various textured tandem devices have been presented aiming at improved optical performance, but optimizing film growth on surface-textured wafers remains challenging. Here we present perovskite–silicon tandem solar cells with periodic nanotextures that offer various advantages without compromising the material quality of solution-processed perovskite layers. We show a reduction in reflection losses in comparison to planar tandems, with the new devices being less sensitive to deviations from optimum layer thicknesses. The nanotextures also enable a greatly increased fabrication yield from 50% to 95%. Moreover, the open-circuit voltage is improved by 15 mV due to the enhanced optoelectronic properties of the perovskite top cell. Our optically advanced rear reflector with a dielectric buffer layer results in reduced parasitic absorption at near-infrared wavelengths. As a result, we demonstrate a certified power conversion efficiency of 29.80%. 

Monolithic two-terminal perovskite–silicon tandem solar cells (PSTSCs) have recently achieved power conversion efficiencies (PCEs) exceeding 31%<sup>1</sup> , thus overcoming the physical limit of conventional crystalline-silicon single-junction solar cells<sup>2</sup> . Such high PCEs were reached by continuous improvements of the optical and electronic properties of PSTSCs. These improvements include, amongst others, switching the cell polarity for enhanced top-contact transmission<sup>3</sup> and fine-tuning of various layers to improve the optical performance<sup>4–6</sup> . In addition, various publications have addressed the improvement 

of the electronic properties by optimizing contact layers<sup>7</sup> , utilizing additives<sup>8,9</sup> and adjusting the perovskite composition<sup>10</sup> or deposition<sup>11</sup> . Numerical studies underline the importance of adequate light management by introducing textured device interfaces for high PCEs<sup>12,13</sup> . For silicon solar cells, potassium-hydroxide-etched random pyramidal textures with a size of several micrometres are commonly used for light management. However, they are not compatible without further adaptation with solution-processed perovskite absorbers, which result in the highest reported PCEs of perovskite single-junction solar 

> 1Division Solar Energy, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, Berlin, Germany. 2Computational Nanooptics Group, Zuse Institute Berlin, Berlin, Germany.<sup>3</sup> Soft Matter Physics, Universität Potsdam, Potsdam, Germany.<sup>4</sup> Department of Chemistry, Humboldt Universität zu Berlin, Berlin, Germany.<sup>5</sup> Faculty 1: School of Engineering – Energy and Information, Hochschule für Technik und Wirtschaft Berlin, Berlin, Germany.<sup>6</sup> Faculty of Electrical Engineering and Computer Science, Technische Universität Berlin, Berlin, Germany.<sup>7</sup> Berliner Hochschule für Technik, Berlin, Germany.<sup>8</sup> These authors contributed equally: Philipp Tockhorn, Johannes Sutter. e-mail: steve.albrecht@helmholtz-berlin.de; christiane.becker@helmholtz-berlin.de 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1214** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 



<!-- Start of picture text -->
a b c d<br>LiF 200<br>IZO<br>Perovskite- 150<br>doped InO<br>nc-SiO x :H(n) 100<br>c-Si<br>50<br>e 0<br>SiO2<br>Doped InO<br>Ag<br>1 µm<br>3 3<br>2 2<br>1 1<br>x  scan direction (µm) 0 0 y  scan direction (µm)<br>Scan height (nm)<br><!-- End of picture text -->

**Fig. 1 | Nanotextured PSTSC design. a** – **c** , SEM cross-section micrographs of the front and rear side of planar ( **a** ), nanotextured ( **b** ) and nanotextured + RDBL ( **c** ) PSTSCs. c-Si, crystalline silicon. **d** , AFM image of the nanostructured 

silicon bottom cell front side prior to the deposition of the contact layers. **e** , Photographs of the final PSTSC with a blue active area in between the front-side silver ring of approximately 1 cm<sup>2</sup> (left) and the RDBL on the rear side (right). 

cells so far<sup>14</sup> . In recent years, different approaches to implement light management textures in PSTSCs have been investigated, either by adapting the perovskite deposition technique but leaving the pyramidal texture unchanged<sup>15–18</sup> , or by adapting the textures such that perovskite solution-processing becomes feasible<sup>9,19–23</sup> (Supplementary Fig. 1). These studies demonstrated remarkable optical improvements in PSTSCs and provided insights into the morphology and optoelectronic properties of textured perovskite top cells. However, it remains a major challenge to develop an appropriate texture, which is able to balance the persistent trade-off between electronic and optical performance of textured PSTSCs with solution-processed perovskite top cells. In recent studies we already introduced gentle sinusoidal nanotextures with submicrometre feature size as promising candidate for PSTSCs: optical simulations indicated that the PCE can be substantially enhanced compared to planar reference tandem solar cells<sup>24</sup> . We further demonstrated experimentally that such nanotextures provide a feasible light-management approach in both solution-processed perovskite<sup>25</sup> and silicon<sup>26</sup> single-junction solar cells, without compromising the optoelectronic quality of the respective absorber. 

In this work, we present PSTSCs with a gentle sinusoidal nanotexture connecting the advantages of structuring the silicon surface while preserving the material quality of the solution-processed perovskite. We show that the nanotexturing causes a substantial reduction of reflection losses compared to their planar counterpart, strongly improves the fabrication yield enabled by the excellent film formation properties and increases the open-circuit voltage by 15 mV. To meet the challenge of parasitic absorption losses, we further implement a reflector with a dielectric buffer layer (RDBL) at the rear side of the silicon bottom cell. Combining both approaches, the gentle nanotexture at the front side and the reflector with dielectric buffer layer at the rear side of the silicon bottom cell, we demonstrate a monolithic PSTSC with an independently certified PCE of 29.80%. 

### **Tandem design** 

Figure 1a–c shows cross-sectional scanning electron microscopy (SEM) images of the investigated PSTSC device configurations: the reference PSTSC device (Fig. 1a) features a fully planar front side (upper half) and a standard random pyramid texture at the rear side of the silicon heterojunction (SHJ) subcell (lower half). The reference solar cell is similar to that presented in our previous publications<sup>7</sup> and consists of a SHJ solar cell with n-doped hydrogenated nanocrystalline 

silicon oxide (nc-SiO _x_ :H(n)), doped indium oxide as the transparent conducting oxide (TCO), a self-assembled monolayer (SAM) denoted Me-4PACz ([4-(3,6-dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid), a mixed-cation and mixed-halide perovskite absorber, lithium fluoride (LiF), C60, tin oxide and indium zinc oxide. The perovskite composition is either Cs0.05(FA0.79MA0.21)0.95Pb(I0.79Br0.21)3 or (Cs0.05(FA0.77MA0.23)0.95Pb (I0.77Br0.23)3 with bandgap energies of 1.66 eV or 1.68 eV, respectively. 

The sinusoidal nanostructure at the front surface of the silicon subcell (Fig. 1b,c) was manufactured by combining ultraviolet nanoimprint lithography, reactive ion etching and wet chemical etching<sup>26</sup> . The experimental procedure is detailed in Methods. The resulting nanotexture has a hexagonal lattice with a period of 750 nm and a peak-to-valley height of approximately 300 nm (Fig. 1d). This nanotexture can be completely covered by the perovskite film with a typical thickness of 500–600 nm (on planar surfaces) revealing a flat perovskite front surface on the C60 side. At the rear side of the silicon wafer we applied a reflector with an RDBL<sup>27</sup> (Fig. 1c). The RDBL comprises a SiO2 buffer layer between the TCO and the silver back-reflector, reducing parasitic absorption losses. A silver grid covering 4% of the active area is screen-printed on top of the TCO before SiO2 deposition to establish the electric contact between the TCO and Ag (Fig. 1e, right side). 

### **Perovskite film formation and morphology** 

Although Me-4PACz improves the electronic properties (for example, compared to 2PACz and poly(triaryl amine)), the suboptimal formation of perovskite films on planar bottom cells/Me-4PACz often leads to macroscopic holes (Fig. 2a). However, when the perovskite is spin-coated onto nanotextured silicon bottom cells covered with Me-4PACz (Fig. 2b), the occurrence of macroscopic holes is strongly reduced. After the perovskite was deposited, we visually inspected the samples and rejected any that exhibited macroscopic holes. As illustrated in Fig. 2c, out of 45 processed nanotextured tandem solar cells, only two had visible holes after perovskite spin-coating (∼95% yield). In contrast, out of 30 planar devices, which were processed in parallel to the nanotextured cells, 15 showed macroscopic holes (~50% yield). To obtain a more systematic understanding of this observation, we measured the static contact angle and the roll-off angle of the perovskite solution on the respective surfaces (Fig. 2d,e). We find decreased surface energy and reduced wettability on the nanostructured surfaces compared to the planar surface (see static contact angle measurement as insets). However, reduced wettability does not necessarily lead to a reduction in droplet 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1215** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 



<!-- Start of picture text -->
a Planar b Nanotexture c<br>Sample waste<br>4%<br>Sample yield<br>40<br>50% 96%<br>20<br>d e<br>θ CA = 30° θ CA = 40°<br>50%<br>0<br>θ RA = 18° θ RA = 25° Planar Nanotexture<br>f g<br>50 Planar<br>Nanotexture<br>40 Planar fit (Boltzmann)<br>Nanotexture fit (Boltzmann)<br>30<br>20<br>Planar<br>Nanotexture<br>10<br>0<br>0 0.1 0.2 0.3 0.4 0.5 0.6 0 20 60 80 100 120 160 180<br>Projected domain size area (µm 2 ) χ (Deg)<br>Number of samples (–)<br>Counts (–)<br>Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Perovskite film formation and morphology. a** , **b** , Representative spin-coated perovskite films on planar ( **a** ) and nanotextured ( **b** ) silicon bottom cells covered by Me-4PACz (approximate area, 25 × 25 mm<sup>2</sup> ). **c** , Fabrication yield of PCTSCs processed on planar and nanotextured silicon bottom cells. **d** , **e** , Side-view photographs of perovskite solution droplets on planar ( **d** ) and nanotextured ( **e** ) silicon substrate with roll-off angle (RA) and static contact 

angle (CA; inset) indicated. **f** , Projected area of domain sizes of perovskite layers deposited on planar and nanotextured substrates as determined from top-view SEM images (Supplementary Fig. 2). **g** , Azimuthal (χ) intensity profiles of the (100) reflection of perovskite averaged over 39 incidence angles from 0.1° to 2° as determined from GIWAXS measurements. 

retention: on the nanotextured sample, we observe a larger roll-off angle (25°), which is defined as the tilting angle at which a droplet of perovskite solution starts to roll off the surface<sup>28</sup> , than for the planar reference (18°). This indicates the improved ability of the nanotextured surface to retain the perovskite solution. This observation can be explained from the approach of de Gennes and co-workers, in which the resulting droplet retention force is enhanced by surface roughness pinning the three-phase contact line<sup>29,30</sup> . Such phenomena are a feature of pseudo-superhydrophobic surfaces, which exhibit very large contact angles, but on which the droplet is pinned by a particular combination of material and texture, resulting in an unusually large roll-off angle<sup>31</sup> . We hence regard increased droplet retention on nanotextured surfaces as an important factor for our improved fabrication yield. 

To further study the morphological properties of perovskite layers grown on sinusoidal nanotextures, we captured SEM top-view images (Supplementary Fig. 2), and analysed the projected domain size distribution as depicted in Fig. 2f. The domain size distribution is equal with a mean equivalent disk radius of 130 ± 60 nm and 120 ± 60 nm for planar and nanotextured silicon bottom cells, respectively. This is not surprising as it was reported that with the antisolvent method the crystallization is initiated at the top surface, which is not affected by the buried nanotextured interface<sup>32</sup> . 

To gain further understanding of the influence of nanotexture on the morphological properties of the perovskite layers, we performed depth-resolved grazing-incidence wide-angle X-ray scattering 

(GIWAXS) measurements: representative GIWAXS maps of planar and nanotextured samples are shown in Supplementary Fig. 3. Figure 2g displays the azimuthal intensity profiles of the (100) reflection of perovskite layers deposited onto planar and nanotextured silicon bottom cells, averaged over 39 incidence angles (0.1°–2.0°). The perovskite deposited onto the planar substrate shows less intense diffraction intensities at azimuthal scattering angles ( _χ_ ) of 70°–90°, resembling a previous report for a similar perovskite composition<sup>33</sup> . In contrast, a homogeneous intensity distribution is shown in the perovskite deposited on the nanotextured substrate, which indicates a random crystallite orientation of perovskite in the bulk and surface. Previous studies reported different mechanisms, which can lead to a variation of crystal orientation: it can be controlled by the chemical composition of precursors<sup>33,34</sup> , the underlying layer<sup>35</sup> or by crystal seeds<sup>36</sup> . It was also reported that nanotexturing of perovskite affects the crystal orientation<sup>37</sup> . We further could not detect a notable difference in the distribution of lead iodide in perovskite layers deposited on planar and nanotextured silicon cells (Supplementary Fig. 4), which could affect the optoelectronic properties<sup>38</sup> . 

### **Optical analysis** 

The optical performance of the planar and nanotextured PSTSCs was analysed by measuring the external quantum efficiency (EQE) and the reflectance ( _R_ ). Representative EQEs and 1 − _R_ spectra for planar and 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1216** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 



<!-- Start of picture text -->
a 100 b 4.0 c<br>R : 3.30<br>80 R : 2.82 40<br>3.5<br>60 Perovskite Silicon 39<br>3.0<br>40 Planar: 20.32 Planar: 19.69<br>Nanotexture: 20.46 Nanotexture: 19.76 2.5 25%–75%Range within 1.5 IQR 38<br>20 Median line<br>Numbers: Nanotexture Mean<br>J ph in mA cm –2 Planar Data<br>0 2.0 37<br>Planar Nanotexture Planar Nanotexture<br>Wavelength (nm)<br>d Air e f<br>Nanotexture<br>LiF<br>IZO 20.2 Planar 20.2<br>SnO2 Nanotexture<br>C60 Planar<br>↕ vskite Pero- 20.1 20.1<br>ITO<br>↕ nc-SiO x :H(n)<br>a-Si:H(i)<br>20.0 20.0<br>Si<br>525 550 575 600 625 75 100 125 150<br>Perovskite thickness (nm) nc-SiO x :H(n) thickness (nm)<br>300 450 600 750 900 1,050 1,200<br>EQE, 1– (%) R  –2(mA cm) J ph, R<br>–2 (mA cm) JJ  + ph,Siph,pero<br>–2 (mA cm) J ph<br><!-- End of picture text -->

**Fig. 3 | Optical analysis of nanotextures in PSTSCs. a** , Representative experimental EQE and 1 − _R_ spectra for a typical pair of planar (black lines: dotted 1 – _R_ ; dashed, perovskite EQE; solid, silicon EQE) and nanotextured (green lines: dotted, 1 - _R_ ; dashed, perovskite EQE; solid, silicon EQE) PSTSCs with standard rear reflector (no RDBL). Numbers are _J_ ph in mA cm<sup>−2</sup> . **b** , **c** , Box-plot diagrams of integrated current density from experimental reflection measurements ( _J_ ph, _R_ ) ( **b** ) and the sum of integrated current densities in the perovskite and silicon subcell from EQE measurements ( _J_ ph,pero + _J_ ph,Si) ( **c** ). IQR, interquartile range. **d** , Cross section through a meshed unit cell of a PSTSC with nanotextures 

between perovskite and silicon subcells, as used for FEM simulations. a-Si:H(i), intrinsic hydrogenated amorphous silicon. **e** , **f** , Sensitivity analysis for different layers, based on optical simulations: minimum of photogenerated current densities min[ _J_ ph(pero), _J_ Si(pero)] as a function of perovskite ( **e** ) and nc-SiO _x_ :H(n) ( **f** ) layer thickness for planar and nanotextured PSTSCs. In **e** , the perovskite thickness for the nanotextured device is defined as the thickness of a planar layer with the same overall volume. For clarity, in **f** only data for samples with a perovskite thickness within ±5 nm of the optimal perovskite thickness are shown. 

nanotextured PSTSCs are shown in Fig. 3a; no notable difference can be observed in the EQEs of the perovskite. In contrast, the EQEs of the silicon subcells differ from each other: the nanotexture diminishes the peaks and valleys caused by thin-film interference (green solid line), which occurs within the perovskite top cell. In addition, the integrated current densities ( _J_ ph,Si) of the silicon EQEs are similar. In contrast to the EQE measurements, nanotexturing reduces reflectance considerably from 3.30 to 2.82 mA cm<sup>−2</sup> current-density-equivalent. Results from a larger number of processed PSTSC devices confirm an average nanotexture-induced reduction of reflectance of around 0.5 mA cm<sup>−2</sup> current-density-equivalent ( _J_ ph, _R_ ) (Fig. 3b). Statistical analysis of the combined photogenerated current density ( _J_ ph,Pero + _J_ ph,Si) from EQE measurements yields the highest values for selected nanotextured devices, confirming their optical potential. The average values are 39.15 and 39.47 mA cm<sup>−2</sup> for planar and nanotextured devices, respectively, demonstrating that nanotextures enhance optical device performance (Fig. 3c). The partial compensation of optical gain as expected from reflectance might be attributed to collection losses under the low-light conditions of the EQE measurement for selected nanotextured silicon bottom cells (Supplementary Fig. 5). Nonetheless, the overall high level of optical performance was independently confirmed by the EQEs calculated from the relative spectral response measurements at Fraunhofer ISE CalLab (see Supplementary Fig. 6a,b for certificate and EQE spectra) with photogenerated current densities of 20.31 and 19.70 mA cm<sup>−2</sup> for perovskite and silicon subcells of a nanotextured PSTSC, respectively. Despite the current mismatch, which has little affect on the combined photogenerated current density (Supplementary Fig. 7), the combined photogenerated current density of 40.01 mA cm<sup>−2</sup> is among the highest values reported in the literature for two-terminal PSTSCs. Higher values have only been demonstrated with fully textured PSTSCs (Supplementary Fig. 8)<sup>15,16,18</sup> . 

In view of process robustness we performed a numerical sensitivity analysis to study the influence of layer thicknesses in the top cell on the photogenerated current density. We used data sets obtained during a Bayesian optimization based on the finite-element method (FEM), which rigorously solves Maxwell’s equations. Figure 3d shows a cross section through a meshed unit cell of a nanotextured PSTSC, as used in the simulations. A previous study showed no influence of the period of sinusoidal textures on the reflectivity of PSTSCs for periods ranging from 500 to 1,000 nm (ref.<sup>13</sup> ). This is in contrast to pyramidal textures, which reveal a strong dependence of antireflective effect on pyramid size<sup>20,21</sup> . During the Bayesian optimization, the overall current density of the monolithic tandem device was optimized by maximizing the minimum of the two subcell photocurrent densities. We assume perfect Lambertian light trapping at the rear side of the silicon bottom cell without any parasitic absorption such that the following results mainly concern the perovskite top-cell layer design. The results of the sensitivity analysis are shown in Fig. 3e,f as functions of the perovskite and nc-SiO _x_ :H(n) layer thickness, respectively. According to these simulations, the optimized nanotextured PSTSC performs almost the same as the optimized planar device with matched photogenerated current densities of 20.24 and 20.22 mA cm<sup>−2</sup> , respectively. As seen in Fig. 3e, the sensitivity to a changing perovskite thickness is also similar for the planar and nanotextured designs. However, texturing reduces the sensitivity to a changing nc-SiO _x_ :H(n) thickness, as seen in Fig. 3f: whereas for planar devices the photocurrent density peaks at around 100 nm nc-SiO _x_ :H(n) thickness, for the nanotextured design the photocurrent density reaches a plateau for nc-SiO _x_ :H(n) layers thicker than 100 nm. This means that nanotexturing of the PSTSC widens the process window for the optical nc-SiO _x_ :H(n) interlayer, which is an important aspect for industrialization of the tandem technology especially when processing on larger areas. 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1217** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 



<!-- Start of picture text -->
a b<br>25%–75%<br>20 1.92 Range within 1.5 IQR<br>Planar Nanotexture Median line<br>15 J SC (mA cm –2 ) 19.45 19.45 1.90 MeanData<br>V OC (V) 1.88 1.90<br>FF (%) 80.83 80.90<br>10 1.88<br>η 29.54 29.83<br>Planar forward scan<br>5 Planar reverse scan 1.86<br>Nanotexture forward scan<br>Nanotexture reverse scan<br>0 1.84<br>0 0.5 1.0 1.5 2.0 Planar Nanotexture<br>Voltage (V)<br>c<br>20<br>EL EL EL p V OC  = 1.91 V<br>p J – V p J – V p J – V<br>(c-Si) (Perovskite) (Tandem) p FF = 84.4%<br>15 p η  = 31.9%<br>0.27% p V OC  = 1.90 V<br>10 EQEEL p FF = 83.9%<br>( perovskite)<br>0.17% p η  = 31.2%<br>Planar<br>5 @ J inj =  J SC Nanotexture<br>1.1 1.6 +13 mV<br>Eph (eV)<br>0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0<br>Voltage (V)<br>Open circuit voltage (V)<br>–2Current density (mA cm)<br>EL (a.u.)<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 4 | Solar cell characteristics of nanotextured PSTSCs. a** , Representative current-density/voltage ( _J_ – _V_ ) characteristics of planar and nanotextured PSTSCs. **b** , Box plot of the open-circuit voltage for planar and nanotextured PSTSCs with 

a perovskite bandgap energy of 1.68 eV. **c** , Pseudo- _J_ – _V_ characteristics of planar and textured PSTSCs showing the individual crystalline silicon and perovskite subcells via subcell-selective EL measurements. Inset: EL spectra at _J_ inj = _J_ SC. 

### **Optoelectronic analysis** 

Figure 4a shows the current-density/voltage characteristics of representative nanotextured and planar PSTSCs. Both devices show PCEs (η) above 29% with a _J_ SC of 19.45 mA cm<sup>−2</sup> . In addition, the fill factor (FF) of the planar and nanotextured PSTSC shows similar values. Even when considering many devices and the influence of current density mismatch ( _J_ ph,Pero − _J_ ph,Si) on the FF (ref.<sup>6</sup> ), no clear difference can be observed between the planar and nanotextured configurations (Supplementary Fig. 9). Alongside the electronic characteristics, we tested the stability at maximum power point by subjecting both a planar and a nanotextured PSTSC to continuous illumination in a dedicated tandem ageing set-up. The observed degradation over time (Supplementary Fig. 10) resembles previous results<sup>7</sup> . We do not observe an effect of nanotextures on the stability of the tandem devices. In contrast, the open-circuit voltages ( _V_ OC) of planar and nanotextured PSTSC differ substantially. Figure 4b displays the _V_ OC of planar (black box) and nanotextured (green box) PSTSCs with a perovskite bandgap of 1.68 eV. The overall _V_ OC distribution shows higher maximum values and a statistical improvement of the median _V_ OC by around 15 mV for nanotextured compared with planar PSTSCs. To verify and understand this effect, we used a subcell-selective characterization approach based on electro- and photoluminescence (EL/PL), which makes it possible to assess the charge transport and recombination properties of the top and bottom cell and to determine their efficiency potential. First, we quantified the injection-dependent electroluminescence quantum yield (EQEEL) of both subcells by injecting a current into the tandem device and detecting the emitted EL of both subcells. From the emitted EL, we calculated the quasi-Fermi level splitting (QFLSEL). The injection-dependent QFLSEL equals a series-resistance-free dark _J_ – _V_ curve, from which we can generate a pseudo- _J_ – _V_ curve by adding the generation current<sup>39</sup> . Figure 4c shows the obtained characteristics of both subcells in the tandem configuration for planar 

and nanotextured PSTSCs. These results reveal an approximately ~60% enhanced EQEEL in the perovskite subcell for the nanostructured PSTSC (Supplementary Fig. 11), which explains the ~15 mV _V_ OC gain in the corresponding _J_ – _V_ measurements. We note that the pseudo-FF (pFF) of 84.5% and 84.1% for nanotextured and planar PSTSCs, respectively, clearly surpass the experimental values and thus point to a further optimization route for these solar cells (see also the results of intensity-dependent _J_ – _V_ measurements in Supplementary Fig. 12). Further, the EL emission of perovskite in the nanotextured devices is slightly skewed (Fig. 4c, inset), which might suggest enhanced photon recycling<sup>40</sup> . We note that the implied performance of both silicon subcells is identical and that the efficiency potential obtained with the nanostructured device is almost 32%. The exact mechanism that improves the EQEEL/ _V_ OC of the perovskite on the nanotextured silicon cell is not yet fully understood. The enhancement might stem from an improved optoelectronic quality of the absorber layer, possibly related to alterations in the crystal orientation (Fig. 2g). It is known that the impact of crystallite orientation on the carrier dynamics of layered perovskite is crucial; however, this relation has been the subject of controversy for three-dimensional perovskite<sup>41</sup> . There are both research reports claiming that the improved crystallite orientation contributes to improved optoelectronic properties<sup>33,42,43</sup> , and those claiming that there is no clear correlation<sup>44</sup> . In addition, slightly lower non-radiative recombination losses at the interfaces<sup>45</sup> , or an alteration of the optical coupling between the perovskite and the silicon<sup>46</sup> have also been discussed. In a study by Hou et al., a _V_ OC enhancement of the perovskite on textured silicon was related to an alteration of the electric fields in the perovskite with extended drift regions<sup>21</sup> . We observe no remarkable difference in the dark currents of nanotextured and planar solar cells, and almost no difference in the morphology (Fig. 2), hence the higher emission from EL (Fig. 4) indicates less non-radiative recombination in nanotextured devices. 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1218** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 



<!-- Start of picture text -->
a b c d<br>300 2.5<br>TCOPerovskite top cell 250 2:19.7 19.819.7 2.0 Constant 180 nm SiO2 0.8<br>nc-SiO X :H(n) 200 19.6 0.7<br>a-Si:H(i) 150 19.5 1.5 Optimized 0.6<br>c-Si absorber 19.4 RDBL: 0.29 0.5<br>a-Si:H(i) 1 2 3 100 3:19.0 1:19.4 19.319.2 1.0 0.4<br>a-Si:H(p)120 nm TCO 20 nm TCO 50 19.119.0 Standard: 0.61 0.3<br>SiO2 grid finger 0 18.9 0.5 0.2<br>Ag 50 100 150 200 50 100 150 200<br>TCO thickness (nm) TCO thickness (nm)<br>e 100 f<br>20<br>80 V OC→ J SC<br>15 J SC→ V OC<br>60 J ph,pero (mA cm–2) J ph,Si (mA cm–2) Steady-state MPP<br>Planar: 20.08 Planar: 19.56 10<br>40 n.t. + RDBL: 20.03 n.t. + RDBL: 19.88<br>20 PlanarNanotexture 5 (mA cm J SC –2) V (V)OC (%)FF PCE(%) MPP(%)<br>(n.t.) + RDBL J SC→ V OC 19.48 1.92 79.4 29.75 29.80<br>0 0<br>400 600 800 1,000 1,200 0 0.5 1.0 1.5 2.0<br>Wavelength (nm) Voltage (V)<br>SiO thickness (nm)2 ph,si (mA cm) J –2 loss (mW cm) P –2<br>Grid finger pitch (mm)<br>EQE (%)<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 5 | Implementing a rear RDBL for high-perfomance nanotextured PSTSCs. a** , **b** , Schematic of the PSTSC layer stack with standard reflector ( **a** ) and with an RDBL at the rear side ( **b** ). (i), (n) and (p) refer to intrinsic, n-doped and p-doped layers. The numbered black frames mark the standard rear side (1) and the SiO2 (2) and grid finger (3) regions of the RDBL. **c** , 2D map of _J_ ph,Si for different SiO2 ( _y_ axis) and TCO thicknesses ( _x_ axis). The configurations corresponding to the experimental layer stacks are marked with arrows and the corresponding _J_ ph,Si is indicated. **d** , 2D map of power losses in the silicon bottom cell for different 

grid finger pitches ( _y_ axis) with 40 µm finger width and TCO thickness ( _x_ axis). Power loss in mW cm<sup>−2</sup> is shown for the RDBL configuration and for the standard reflector. **e** , EQE spectra (dashed lines, perovskite EQE; solid lines, silicon EQE) of a planar PSTSC with a standard rear side (black) and a nanotextured (n.t.) PSTSC with an RDBL (red). The integrated photogenerated current densities of perovskite ( _J_ ph,pero) and silicon ( _J_ ph,Si) are shown. **f** , Current-density/voltage ( _J_ – _V_ ) characteristics of a nanotextured PSTSC with an RDBL certified by CalLab at Fraunhofer ISE. 

### **High-performance tandem solar cells with optically advanced rear reflector** 

To reduce parasitic absorption losses in the rear reflector, we additionally implemented an RDBL<sup>27,47,48</sup> . State-of-the-art monofacial silicon heterojunction solar cells use a TCO/silver system as reflector. By designing a thin TCO layer and at the same time increasing the distance between metal and silicon by means of an RDBL, parasitic absorption losses can be reduced. Bush et al. integrated such a reflector into a PSTSC, thereby increasing the _J_ SC and efficiency considerably<sup>49</sup> . Figure 5a,b illustrates PSTSC layer stacks with a standard reflector and with an RDBL. Three optically different regions can be distinguished: (1) standard reflector (120 nm TCO, no buffer layer), (2) RDBL (20 nm TCO, 180 nm SiO2 buffer layer) and (3) grid fingers of the RDBL (20 nm TCO, no buffer layer). SEM images of the corresponding regions are presented in Supplementary Fig. 13. The SiO2 layer thickness and the grid finger pitch were chosen according to optical and electrical simulations of the RDBL. To quantify the optical properties of these three regions, we performed simulations of the variation of the photogenerated current density in the silicon ( _J_ ph,Si) with TCO and SiO2 thickness (Fig. 5c). For the optimized layer thicknesses, the photocurrent density of the silicon bottom cell _J_ ph,Si increases from 19.4 to 19.7 mA cm<sup>−2</sup> when replacing the standard reflector design (region 1) with the RDBL (region 2), mostly due to reduced parasitic absorption in the TCO–silver contact. A full-area design as in the grid finger (region 3) would lead to a _J_ ph,Si of 19.0 mA cm<sup>−2</sup> . 

Finally, the local contact area has to be optoelectronically optimized not only regarding the optical properties, but also in terms of lateral transport and contact resistive losses. This means that the TCO thickness and the grid finger geometry have to be balanced. Figure 5d shows the simulation results (see Methods for details). We find decreased power loss with TCO thickness reduction, since the benefit from reduced parasitic absorption dominates. For a silver-grid finger 

width of 40 µm we find an optoelectrical optimum for a grid pitch of roughly 1.1 mm (Fig. 5d). Hence, a finger pitch of 1 mm was implemented, resulting in local contacts covering roughly 4% of the active area. The optoelectronic analysis further shows that overall the RDBL potentially increases the power output by 0.3 mW cm<sup>−2</sup> . The EQE spectra of experimentally realized PSTSCs with and without an RDBL are shown in Fig. 5e. In addition to the nanotexture-induced flattening of the silicon EQE, the RDBL features an increased absorption at the silicon band edge, as expected from the optical simulations. To account for the additional current density from the RDBL in the silicon subcell, we shifted the perovskite bandgap from 1.68 to 1.66 eV. As described by Peña-Camargo et al., the optoelectronic properties do not notably change when slightly adjusting the perovskite composition<sup>50</sup> ; only the _V_ OC changes according to the bandgap. One of the best PSTSCs, featuring both a nanotextured interface between the perovskite and silicon subcell and an RDBL was sent to Fraunhofer ISE CalLab for indepen dent certifica tion (Fig. 5f; see Supplementary Fig. 14 for certificate). The cell reached a PCE of 29.75% when measured from _J_ SC to _V_ OC (designated area, 1.0163 cm<sup>2</sup> ), with a _V_ OC of 1.92 V, an FF of 79.4% and a _J_ SC of 19.56 mA cm<sup>−2</sup> . The certified PCE, as determined from MPP tracking, is 29.80%. 

### **Conclusions** 

In this study, we integrated gentle submicrometre-periodic nanotextures and an improved back-reflector design into monolithic PSTSCs. The nanotextures enable greatly enhanced process yield of the solution-processed perovskite top cell from around 50% in case of planar to about 95% for nanotextured silicon bottom cells. We further observed a reduction of reflection losses amounting to around 0.5 mA cm<sup>−2</sup> current-density-equivalent. As a result, combined short-circuit current densities in the perovskite and silicon subcells of up to 40.0 mA cm<sup>−2</sup> are observed, which is one of the highest values 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1219** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

reported in the literature for two-terminal PSTSCs. A sensitivity analysis further indicates that the nanotextures substantially improve the performance robustness upon deviations from the optimal nanocrystalline silicon oxide layer thickness—an important aspect with regards to the industrialization of tandem technology and processing on larger areas. The main driver for improved PSTSC performance was an increase of the open-circuit voltage by around 15 mV that stems, according to our subcell-selective EL characterizations, solely from an improved perovskite-top-cell performance. In addition to the nanotextures at the silicon bottom-cell front side, we further implemented an RDBL at the rear side. This design further improves the current density in the silicon bottom cell by around 0.3 mA cm<sup>−2</sup> by reducing parasitic absorption losses. By combining nanotextures and RDBL in one PSTSC, we achieved a certified PCE of 29.80%. These results pave the way for the wide use of nano-optical designs in high-efficiency perovskite solar cells and other metal halide perovskite optoelectronic devices in the near future. 

### **Online content** 

Any methods, additional references, Nature Research reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41565-022-01228-8. 

### **References** 

1. EPFL. New world records: perovskite-on-silicon-tandem solar cells (2022); https://actu.epfl.ch/news/ new-world-records-perovskite-on-silicon-tandem-sol/ 

2. Richter, A., Hermle, M. & Glunz, S. W. Reassessment of the limiting efficiency for crystalline silicon solar cells. _IEEE J. Photovolt._ **3** , 1184–1191 (2013). 

3. Bush, K. A. et al. Compositional engineering for efficient wide band gap perovskites with improved stability to photoinduced phase segregation. _ACS Energy Lett._ **3** , 428–435 (2018). 

4. Bush, K. A. et al. Minimizing current and voltage losses to reach 25% efficient monolithic two-terminal perovskite–silicon tandem solar cells. _ACS Energy Lett._ **3** , 2173–2180 (2018). 

5. Mazzarella, L. et al. Infrared light management using a nanocrystalline silicon oxide interlayer in monolithic perovskite/ silicon heterojunction tandem solar cells with efficiency above 25%. _Adv. Energy Mater._ **9** , 1803241 (2019). 

6. Köhnen, E. et al. Highly efficient monolithic perovskite silicon tandem solar cells: analyzing the influence of current mismatch on device performance. _Sustain. Energy Fuels_ **3** , 1995–2005 (2019). 

7. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

8. Kim, D. et al. Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. _Science_ **368** , 155–160 (2020). 

9. Isikgor, F. H. et al. Concurrent cationic and anionic perovskite defect passivation enables 27.4% perovskite/silicon tandems with suppression of halide segregation. _Joule_ **5** , 1566–1586 (2021). 

10. Xu, J. et al. Triple-halide wide–band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097–1104 (2020). 

11. Schulze, P. S. C. et al. 25.1% high‐efficiency monolithic perovskite silicon tandem solar cell with a high bandgap perovskite absorber. _Sol. RRL_ **4** , 2000152 (2020). 

12. Santbergen, R. et al. Minimizing optical losses in monolithic perovskite/c-Si tandem solar cells with a flat top cell. _Opt. Express_ **24** , A1288 (2016). 

13. Jäger, K., Sutter, J., Hammerschmidt, M., Schneider, P.-I. & Becker, C. Prospects of light management in perovskite/silicon tandem solar cells. _Nanophotonics_ **10** , 1991–2000 (2020). 

14. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. _Nature_ **590** , 587–593 (2021). 

15. Sahli, F. et al. Fully textured monolithic perovskite/silicon tandem solar cells with 25.2% power conversion efficiency. _Nat. Mater._ **17** , 820–826 (2018). 

16. Tennyson, E. M. et al. Multimodal microscale imaging of textured perovskite–silicon tandem solar cells. _ACS Energy Lett._ **6** , 2293–2304 (2021). 

17. Roß, M. et al. Co-evaporated formamidinium lead iodide based perovskites with 1000 h constant stability for fully textured monolithic perovskite/silicon tandem solar cells. _Adv. Energy Mater._ **11** , 2101460 (2021). 

18. Li, Y. et al. Wide bandgap interface layer induced stabilized perovskite/silicon tandem solar cells with stability over ten thousand hours. _Adv. Energy Mater._ **11** , 2102046 (2021). 

19. Subbiah, A. S. et al. High-performance perovskite single-junction and textured perovskite/silicon tandem solar cells via slot-die-coating. _ACS Energy Lett._ **5** , 3034–3040 (2020). 

20. Chen, B. et al. Blade-coated perovskites on textured silicon for 26%-efficient monolithic perovskite/silicon tandem solar cells. _Joule_ **4** , 850–864 (2020). 

21. Hou, Y. et al. Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. _Science_ **367** , 1135–1140 (2020). 

22. Zhumagali, S. et al. Linked nickel oxide/perovskite interface passivation for high-performance textured monolithic tandem solar cells. _Adv. Energy Mater._ **11** , 2101662 (2021). 

23. Santbergen, R. et al. Ray-optics study of gentle non-conformal texture morphologies for perovskite/silicon tandems. _Opt. Express_ **30** , 5608 (2022). 

24. Chen, D. et al. Nanophotonic light management for perovskite– silicon tandem solar cells. _J. Photonics Energy_ **8** , 022601 (2018). 

25. Tockhorn, P. et al. Improved quantum efficiency by advanced light management in nanotextured solution-processed perovskite solar cells. _ACS Photonics_ **7** , 2589–2600 (2020). 

26. Sutter, J. et al. Tailored nanostructures for light management in silicon heterojunction solar cells. _Sol. RRL_ **4** , 2000484 (2020). 

27. Cruz, A. et al. Optoelectrical analysis of TCO + silicon oxide double layers at the front and rear side of silicon heterojunction solar cells. _Sol. Energy Mater. Sol. Cells_ **236** , 111493 (2022). 

28. Bhushan, B., Jung, Y. C. & Koch, K. Micro-, nano- and hierarchical structures for superhydrophobicity, self-cleaning and low adhesion. _Philos. Trans. R. Soc. A_ **367** , 1631–1672 (2009). 

29. Joanny, J. F. & de Gennes, P. G. A model for contact angle hysteresis. _J. Chem. Phys._ **81** , 552–562 (1984). 

30. Tadmor, R. Open problems in wetting phenomena: pinning retention forces. _Langmuir_ **37** , 6357–6372 (2021). 

31. Wu, J., Xia, J., Lei, W. & Wang, B. Advanced understanding of stickiness on superhydrophobic surfaces. _Sci. Rep._ **3** , 3268 (2013). 

32. Minemawari, H. et al. Inkjet printing of single-crystal films. _Nature_ **475** , 364–367 (2011). 

33. Zheng, G. et al. Manipulation of facet orientation in hybrid perovskite polycrystalline films by cation cascade. _Nat. Commun._ **9** , 2793 (2018). 

34. Chen, A. Z. et al. Crystallographic orientation propagation in metal halide perovskite thin films. _J. Mater. Chem. A_ **5** , 7796–7800 (2017). 

35. Xi, J. et al. Scalable, template driven formation of highly crystalline lead‐tin halide perovskite films. _Adv. Funct. Mater._ **31** , 2105734 (2021). 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1220** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

36. Luo, C. et al. Facet orientation tailoring via 2D-seed-induced growth enables highly efficient and stable perovskite solar cells. _Joule_ **6** , 240–257 (2022). 

37. Kim, W. et al. Oriented grains with preferred low-angle grain boundaries in halide perovskite films by pressure-induced crystallization. _Adv. Energy Mater._ **8** , 1702369 (2017). 

38. Chen, Q. et al. Controllable self-induced passivation of hybrid lead iodide perovskites toward high performance solar cells. _Nano Lett._ **14** , 4158–4163 (2014). 

39. Stolterfoht, M. et al. How to quantify the efficiency potential of neat perovskite films: perovskite semiconductors with an implied efficiency exceeding 28%. _Adv. Mater._ **32** , 2000080 (2020). 

40. Cho, C. et al. Effects of photon recycling and scattering in high-performance perovskite solar cells. _Sci. Adv._ **7** , eabj1363 (2021). 

41. Tan, W. L. & McNeill, C. R. X-ray diffraction of photovoltaic perovskites: principles and applications. _Appl. Phys. Rev._ **9** , 021310 (2022). 

42. Kim, D. H. et al. 300% enhancement of carrier mobility in uniaxial-oriented perovskite films formed by topotactic-oriented attachment. _Adv. Mater._ **29** , 1606831 (2017). 

43. Giesbrecht, N. et al. Synthesis of perfectly oriented and micrometer-sized MAPbBr3 perovskite crystals for thin-film photovoltaic applications. _ACS Energy Lett._ **1** , 150–154 (2016). 

44. Muscarella, L. A. et al. Crystal orientation and grain size: do they determine optoelectronic properties of MAPbI3 perovskite? _J. Phys. Chem. Lett._ **10** , 6010–6018 (2019). 

45. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

46. Kirchartz, T., Staub, F. & Rau, U. Impact of photon recycling on the open-circuit voltage of metal halide perovskite solar cells. _ACS Energy Lett._ **1** , 731–739 (2016). 

47. Holman, Z. C., Descoeudres, A., Wolf, S. D. & Ballif, C. Record infrared internal quantum efficiency in silicon heterojunction solar cells with dielectric/metal rear reflectors. _IEEE J. Photovolt._ **3** , 1243–1249 (2013). 

48. Boccard, M. et al. Low-refractive-index nanoparticle interlayers to reduce parasitic absorption in metallic rear reflectors of solar cells. _Phys. Status Solidi A_ **214** , 1700179 (2017). 

49. Bush, K. A. et al. 23.6%-efficient monolithic perovskite/silicon tandem solar cells with improved stability. _Nat. Energy_ **2** , 17009 (2017). 

50. Peña-Camargo, F. et al. Halide segregation versus interfacial recombination in bromide-rich wide-gap perovskite solar cells. _ACS Energy Lett._ **5** , 2728–2736 (2020). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

**Open Access** This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons. org/licenses/by/4.0/. 

© The Author(s) 2022 

Nature Nanotechnology | Volume 17 | November 2022 | 1214–1221 

**1221** 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

### **Methods** 

#### **Device fabrication** 

**Nanotextured silicon bottom cells.** A three-step process, developed by Sutter et al<sup>26</sup> ., was used to create nanotextures in silicon wafers for PSTSCs. Sinusoidal master structures, manufactured by laser interference lithography<sup>51</sup> , were replicated by nanoimprint lithography with a polydimethylsiloxane stamp in an ultraviolet-curable resist (mrNIL210–500; Microresist Technologies) on a double side polished (100) silicon n-type float-zone wafer (Topsil) with a nominal resistivity of 1–5 Ω·cm and an approximate thickness of 280 µm. For the nanoimprint lithography process, the 4 inch wafers were cleaned according to the standard RCA procedure<sup>52</sup> . In ambient conditions, 700 µl of resist was spin-coated for 30 s at 3,200 r.p.m. on the wafer, prebaked for 3 min at 60 °C and cured by ultraviolet light with the polydimethylsiloxane stamp comprising the inverted nanotexture from the master on top for 2 min. In a second step, the reproduced nanotexture was anisotropically etched into the silicon substrate by reactive-ion etching with the etching gases sulfur hexafluoride and fluoroform (CHF3) for 16 min at 90 W radiofrequency power and 20 mtorr pressure. In this step, the nanotextured resist served as a 3D etching mask and was able to replicate the texture into the underlying silicon. An additional reactive-ion etching oxygen plasma was applied to eliminate organic residues. Due to the diffusion of ions and silicon lattice distortion, a subsequent wet-chemical defect etch with nitric acid, phosphoric acid and fluoric acid (HNO3(65%)/H3PO4(85%)/HF(50%)/H2O, 30:10:1:15) was performed. Prior to the texturing of the rear side with random pyramids with (111) facets (potassium hydroxide etched, 8 min at 83 °C, CellTex Ultra (ICB) as additive), the nanotextured front side was protected with a 320-nm-thick SiO _2_ layer deposited by plasma-enhanced chemical vapour deposition (PECVD). After removal of the capping in HF, a final RCA clean and HF dip (1% dilution in water) were performed. Intrinsic and doped hydrogenated amorphous (a-Si:H(i)/a-Si:H(p)) and nc-SiO _x_ :H(n) layers were deposited by PECVD using an Applied Materials AKT1600 cluster tool. To account for the enhanced surface area, the process parameters for the front side of the nanotextured wafers were adjusted by a factor of 1.3 versus the planar case. A 20 nm layer of doped indium oxide as TCO was sputtered as the recombination contact. The rear-side contact of the silicon bottom cells is 120 nm for the standard design and 20 nm sputter-doped indium oxide for the RDBL. The RDBL has an additional silver grid printed on the rear side with a nominal finger width of 40 µm and a 1 mm pitch, and was cured for 10 min at 210 °C, followed by a PECVD deposition of 180 nm SiO2. For both standard and RDBL rear-side designs, 400 nm silver was sputtered as the back contact layer. In the standard design the silver forms a direct contact with the TCO. For the RDBL design the local contacts are fabricated at the finger grid printed area through the 180 nm SiO2 to the silver layer without additional processing steps being needed. All contacts of the silicon bottom cell were processed through a quadratic mask with an area of 1.1 cm<sup>2</sup> . After sputtering silver, the silicon wafers of the standard design were annealed for 10 min at 210 °C and wafers of both designs were additionally annealed for 5 min at 210 °C under 1 sun illumination. The wafers were then laser cut into 2.5 × 2.5 cm<sup>2</sup> pieces, with a 1.1 cm<sup>2</sup> contact area in the centre. 

For fabricating the perovskite top cells, we adapted a device stack reported earlier<sup>7</sup> . For cleaning, the 2.5 × 2.5 cm<sup>2</sup> silicon bottom cells were blown with nitrogen, and ethanol was spin-coated at 2,500 r.p.m. for 30 s, folllowed by ultraviolet/ozone treatment for 15 min. Further processes were carried out in a nitrogen-filled glovebox. First, 100 µl of a 3 mM solution of Me-4PACz (TCI) was dissolved in ethanol and spin-coated (3,000 r.p.m. for 30 s) onto the bottom cells, followed by a 10 min annealing at 100 °C. Then, either Cs0.05(FA0.79MA0.21)0.95P b(I0.79Br0.21)3 (1.66 eV bandgap) or Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3 (1.68 eV bandgap) perovskite was prepared, adapted from a recipe by Saliba et al<sup>53</sup> . For this, precursor solutions containing formamidinium iodide (Dyenamo) and lead iodide (TCI) were mixed in a ratio of 79:21 or 

77:23 with a precursor solution containing methylammonium bromide (Dyenamo) and lead bromide (TCI). Both precursor solutions contained 1 M of the corresponding organic and 1.1 M of the lead salts which were dissolved in a mixture of anhydrous dimethylformamide and dimethylsulfoxide (4:1 vol/vol; both purchased from Sigma Aldrich). Next, 5 vol% caesium iodide (abcr) from a 1.5 M stock solution in DMSO was added to the precursor solutions. The resulting perovskite solution was then spin-coated at 3,500 r.p.m. for 40 s; 15 s prior to the end of the programme, 500 µl ethyl acetate (Sigma Aldrich) was poured onto the spinning substrate. The films were annealed at 100 °C for 30 min. The front-side contact was deposited through subsequent thermal evaporation of 1 nm lithium fluoride (Sigma Aldrich) and 18 nm C60 (Sigma Aldrich). Then, 20 nm tin oxide was deposited by thermal atomic layer deposition in an Arradiance GEMStar reactor at 80 °C. A 100 nm layer of indium zinc oxide from a 4 inch target (90:10 wt% In3O2:ZnO) was deposited by sputtering at a power of 150 W under argon/oxygen. A 100 nm thick silver frame was thermally evaporated through a shadow mask. Finally, 100 nm LiF was thermally evaporated as an antireflective coating. The active area is defined by the metal frame and is slightly larger than 1 cm<sup>2</sup> . 

#### **Characterization** 

Roll-off measurements were conducted using a contact angle goniometer (DSA 25, Krüss). In all measurements, 10 µl droplets of perovskite solution (see above) were used. For the roll-off angle measurements the samples were placed on fixed, inclined stages before dispensing the solution. The methodology used here enables qualitative analysis of the droplet retention behaviour of both planar and textured surfaces<sup>54</sup> . 

Reflectance was measured under an angle of 8° in 5 nm steps from 300 to 1,200 nm with a PerkinElmer Lambda 1050+ ultraviolet/visible/ near-infrared spectrophotometer, which was calibrated with a Spectralon. For statistics on the reflectance of PSTSCs, perovskite absorbers with bandgaps varying from 1.66 to 1.68 eV were used. 

Atomic force microscopy (AFM) measurements were performed with a XE-70 (Park Systems). For accurate profile scans in the nanometre regime, high-aspect-ratio tips were used. SEM was performed with a Merlin field emission scanning electron microscope with a Gemini II optical column (Zeiss). 

Ex situ GIWAXS measurements were conducted at the mySpot beamline at the electron storage ring BESSY II. The samples were measured at room temperature in reflection mode with incidence angles from 0.1° to 2° (39 scans, 0.05° interval), using a radiation energy of 9 keV ( _λ_ = 1.378 Å). The size of the beam was around 100 µm (ref.<sup>55</sup> ). The 2D images were plotted and integrated with Dpdak and GIXSGUI software<sup>56,57</sup> . 

**EL measurements.** Absolute EL measurements were performed using a calibrated silicon photodetector and a Keithley 485 picoammeter. The detector (active area, ∼1 cm<sup>2</sup> ) was placed directly in front of the device, and the total photon flux was determined from the emission spectra of the perovskite and silicon subcell, and the EQE of the detector. To selectively pick up EL from the perovskite or crystalline silicon subcell, appropriate long-pass and short-pass filters were used. Underestimation of the EQEEL due to undetected photons that escaped to the side was compensated by additional measurements at different distances and with a larger detector (active area, ∼2 cm<sup>2</sup> ). During a typical EL measurement, a Keithley 2400 source meter was used to apply a forward bias to the cell, and the injected current was monitored. Measurements were conducted with a home-written LabVIEW routine. Relative EL spectra of the PSTSCs were measured with an Andor SR393i-B spectrometer equipped with an Andor iDus silicon charge-coupled device camera and an iDus InGaAs detector array. The spectral response of the system was calibrated by using a calibrated halogen lamp with specified spectral irradiance. The quasi-Fermi level splitting (QFLSEL) was calculated according to QFLSEL = _k_ B _T_ × ln(EQEEL × _J_ 0 _J_ ,Grad<sup>), where</sup><sup>_k_B</sup><sup>_T_</sup> 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

is the thermal energy at room temperature, and _J_ 0,rad and _J_ G are the radiative recombination current in the dark and the 1-sun-equivalent (AM1.5G) generation current, respectively. The quantification of the _J_ 0,rad of both subcells is shown in Supplementary Fig. 15 and Supplementary Table 1. 

**Solar cell characteristics.** The tandem solar cells were measured in air under AM1.5G (1 sun) equivalent illumination with a Wavelabs Sinus-70 light-emitting diode (LED) class AAA solar simulator as described in a previous publication by Al-Ashouri et al.<sup>7</sup> . The cells were not preconditioned. For calibration we used a slightly modified calibration routine as described in ref.<sup>58</sup> . We adjusted the spectrum such that it led to the photogenerated current densities obtained by EQE measurements for both subcells. Thus, for a perovskite-limited cell, we first increased the intensity of the blue light to get a silicon-limited cell. Subsequently, the near-infrared region was adjusted until the _J_ SC of the silicon-limited tandem solar cell was equal to the _J_ ph,Si (calculated from EQE and AM1.5G spectrum). Finally, the intensity of the blue light was decreased until the tandem solar cell was perovskite-limited again and the _J_ SC was equal to the _J_ ph,Pero. For a silicon-limited cell, the procedure is the opposite. The backside of the cell was contacted with a metal vacuum chuck at 25 °C, whereas the front side was contacted with two gold probes. A black laser-cut aperture mask covered the substrate outside of the active area. The _J_ – _V_ measurements and MPP tracks were recorded using ahome-built LabVIEW software. The EQE spectra were recorded with a home-built set-up using chopped (79 Hz) monochromatic light from a xenon and helium lamp,each covering a specific part of the spectrum. To measure the EQE of the perovskite subcell, the silicon subcell was saturated using an LED with 850 nm peak emission. To maintain short-circuit conditions, a bias voltage of 0.6 V was applied. The silicon subcell was measured by saturating the perovskite subcell with blue light from an LED (455 nm) and applying a bias voltage of 1.0 V. For statistics on totalized integrated subcell current densities of PSTSCs, perovskite absorbers with bandgaps varying from 1.66 to 1.68 eV were used. 

#### **Simulations** 

**3D optical simulations: JCMwave and Bayesian optimization.** The data used for the sensitivity analysis presented in Fig. 3 were generated during a layer-thickness optimization with a Bayesian optimization algorithm<sup>59</sup> , similar to an optimization we presented in previous work<sup>13</sup> . During the optimization the thicknesses of the perovskite and nc-SiO _x_ :H(n) layers were varied to maximize the function min( _J_ ph,pero, _J_ ph,Si), which is a well-suited optimization function for monolithic tandem solar cells, as it directly accounts for current matching<sup>60</sup> . The individual simulations were performed with the FEM solver JCMsuite<sup>61</sup> for a 300–1,190 nm wavelength range and produced absorption spectra for all the layers of the solar cell stack. To be able to do the FEM simulations, we had to restrict the simulation domain to the perovskite top cell and to assume the silicon to be infinitely thick. To compensate, we corrected the absorption of the silicon layer by assuming perfect light trapping for the silicon wafer according to Tiedje and Yablonovitch<sup>62</sup> . From the absorption spectra, the photocurrent densities were calculated<sup>60</sup> . For example, for reflection the equation is given as 



<!-- Start of picture text -->
1,190 nm<br>J ph, R = − e ∫ R  ( λ ) × ΦAM1.5G ( λ ) d λ<br>300 nm<br><!-- End of picture text -->

where _e_ is the elementary charge, _R_ is the spectral reflectance _R_ and _Φ_ is the spectral photon flux under the AM1.5G condition<sup>60</sup> . Hence, the current-density equivalents can be regarded as solar-spectrum-weighted reflectance values and their relevance for the solar cell device can immediately be seen. Details on the layer thicknesses, optical material data and optimization results are given in Supplementary Table 2. 

**1D optical simulations: GenPro4.** The optical simulations on the RDBL shown in Fig. 5c were performed with GenPro4 developed at TU Delft<sup>63</sup> , which uses the net-radiation method and ray tracing for scattering at the pyramidal back side of the solar cell. Details on the layer stack used for these simulations are given in Supplementary Table 3. 

**Optoelectrical simulations: Quokka.** For the RDBL with local contacts, the sheet resistance of the TCO ( _R_ sheet), which depends on its electrical properties and thickness, and the resistance of the grid fingers, which depends on their pitch, geometry and resistivity, have to be optimized. To calculate this balance, electrical simulations were carried out with the Quokka3 software<sup>64</sup> for which we assumed the wafer properties, finger geometry and resistivity, and Si/TCO/Ag contact resistivities to remain constant. Note also that _R_ sheet does not increase linearly with thickness reduction since we considered the variation of its electrical properties in real-solar-cell-like structures as studied in ref.<sup>27</sup> . The reference point from which the optical power loss ( _P_ loss) is calculated is _J_ SC = 19.73 mA cm<sup>−2</sup> at _t_ TCO = 10 nm and FP = 2.5 mm, decreasing to 19.44 mA cm<sup>−2</sup> at _t_ TCO = 200 nm and FP = 0.5 mm. For this _J_ SC range variation, _V_ OC = 1.9 V and FF = 79.52% are assumed to remain constant. For the electrical _P_ loss, the holes, vertical, lateral and metal finger transport losses are calculated assuming _J_ SC has a constant value of 19.4 mA cm<sup>−2</sup> . Other parameters used can be found in Supplementary Table 4. 

### **Data availability** 

All the data used to plot the figures are available via https://doi. org/10.5442/ND000009 (ref.<sup>65</sup> ). Source data are provided with this paper. 

### **References** 

51. Wolf, A. J. et al. Origination of nano- and microstructures on large areas by interference lithography. _Microelectron. Eng._ **98** , 293–296 (2012). 

52. Kern, W. The evolution of silicon wafer cleaning technology. _J. Electrochem. Soc._ **137** , 1887–1892 (1990). 

53. Saliba, M. et al. Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. _Energy Environ. Sci._ **9** , 1989–1997 (2016). 

54. Pierce, E., Carmona, F. J. & Amirfazli, A. Understanding of sliding and contact angle results in tilted plate experiments. _Colloids Surf. A_ **323** , 73–82 (2008). 

55. Zizak, I. The mySpot beamline at BESSY II. _J. Large-Scale Res. Facil._ **2** , A102 (2016). 

56. Benecke, G. et al. A customizable software for fast reduction and analysis of large X-ray scattering data sets: applications of the new DPDAK package to small-angle X-ray scattering and grazing-incidence small-angle X-ray scattering. _J. Appl. Crystallogr._ **47** , 1797–1803 (2014). 

57. Jiang, Z. GIXSGUI: a MATLAB toolbox for grazing-incidence X-ray scattering data visualization and reduction, and indexing of buried three-dimensional periodic nanostructured films. _J. Appl. Crystallogr._ **48** , 917–926 (2015). 

58. Meusel, M., Adelhelm, R., Dimroth, F., Bett, A. W. & Warta, W. Spectral mismatch correction and spectrometric characterization of monolithic III–V multi-junction solar cells. _Prog. Photovolt: Res. Appl._ **10** , 243–255 (2002). 

59. Schneider, P.-I., Garcia Santiago, X., Rockstuhl, C. & Burger, S. Global optimization of complex optical structures using Bayesian optimization based on Gaussian processes. In _Digital Optical Technology 2017_ (eds Kress B. C. et al.) 103350O (SPIE, 2017); https://doi.org/10.1117/12.2270609 

60. Jäger, K., Korte, L., Rech, B. & Albrecht, S. Numerical optical optimization of monolithic planar perovskite–silicon tandem solar cells with regular and inverted device architectures. _Opt. Express_ **25** , A473 (2017). 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-022-01228-8 

61. Pomplun, J., Burger, S., Zschiedrich, L. & Schmidt, F. Adaptive finite element method for simulation of optical nano structures. _Physica Status Solidi B Basic Solid State Phys._ **244** , 3419–3434 (2007). 

62. Tiedje, T., Yablonovitch, E., Cody, G. D. & Brooks, B. G. Limiting efficiency of silicon solar cells. _IEEE Trans. Electron Devices_ **31** , 711–716 (1984). 

63. Santbergen, R. et al. GenPro4 optical model for solar cell simulation and its application to multijunction solar cells. _IEEE J. Photovolt._ **7** , 919–926 (2017). 

64. Fell, A. A free and fast three-dimensional/two-dimensional solar cell simulator featuring conductive boundary and quasi-neutrality approximations. _IEEE Trans. Electron Devices_ **60** , 733–738 (2013). 

65. Tockhorn, P. et al. Supplement to: Nano-optical designs for high efficiency monolithic perovskite–silicon tandem solar cells (HZB Data Service, 2022); https://doi.org/10.5442/ND000009 

### **Acknowledgements** 

The authors thank J. Beckedahl, C. Ferber, M. Gabernig and H. Heinz for technical support in the HySPRINT lab and I. Rudolph for technical support in the BESSY cleanroom. C. Klimm and K. Sveinbjörnsson are acknowledged for SEM measurements. K. Jacob is acknowledged for RCA cleaning of silicon wafers and technical support. The authors thank F. Riesebeck for support during the poly-silicon etching. K. Mayer-Stillrich, M. Hartig and D. Debrassine are recognized for sputtering of TCO layers and F. Biegalke for potassium hydroxide etching. C. Trinh is acknowledged for PECVD deposition and J. Kleesiek for screen printing. Funding was provided by the German Federal Ministry for Education and Research (BMBF) through PeroWin Project (grant number 03SF0631, S.A.) and the SNaPSHoTs Project (grant number 01IO1806, J.S and C.B.), the German Federal Ministry for Economic Affairs (BMWi) through the ‘PersiST’ project (grant number 0324037C, S.A.) and the ‘PrEsto’ project (grant number 03EE1086C, S.A.), the HyperCells Graduate School, the HI-SCORE Research School, and the HySPRINT Helmholtz Innovation Lab. This work was also supported by the Helmholtz Association within the EU-Partnering project TAPAS (Tandem Perovskite and Silicon Solar Cells Advanced Optoelectrical Characterization, Modelling and Stability, S.A.) and the Helmholtz Excellence Network SolarMath, a strategic collaboration of MATH+ and Helmholtz-Zentrum Berlin (grant number ExNet0042-Phase-2-3, C.B.). We acknowledge funding by the Deutsche Forschungsgemeinschaft (DFG) under Germany’s Excellence Strategy (EXC-2046/1, project ID: 390685689, MATH+ AA4-6, B.R.). M.S. acknowledges the DFG (project number 423749265-SPP 

2196 (SURPRISE)) and financial support by the Federal Ministry for Economic Affairs and Energy (P3T-HOPE, 03EE1017C) for funding. 

### **Author contributions** 

P.T. and J.S. fabricated the perovskite top cell, finished the PSTSCs and characterized the PSTSC by sun simulator, EQE and reflection measurements. J.S. developed and prepared silicon substrates with nanotextures, and performed SEM and AFM measurements. J.S., P.W. and A.C. prepared the silicon bottom cells. A.C. developed the process for the RDBL and performed optical and electrical simulations concerning the RDBL. K.J. performed optical FEM simulations and Baysian optimizations. D.Y. carried out and analysed contact-angle and roll-off experiments. F.L., M.G. and M.S. performed EL/PL measurements and analysed the data. B.L. carried out stability measurements. O.S. and J.L. performed and analysed the GIWAXS measurements. A.A.-A., B.L. and E.K. developed and supported the PSTSC fabrication process. E.U. supervised the GIWAXS activities. D.N. supervised the EL/PL activities. R.S. and B.S. supervised the silicon bottom-cell activities. B.R. supported all activities and gave advice on the structure of the manuscript. S.A. supervised the PSTSC activities. C.B. supervised the optics and nanotexture activities. P.T., J.S., S.A. and C.B. coordinated the project. P.T., J.S. and C.B. wrote the manuscript, and all authors commented on the paper. 

### **Funding** 

Open access funding provided by Helmholtz-Zentrum Berlin für Materialien und Energie GmbH. 

### **Competing interests** 

The authors declare no competing interests. 

### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41565-022-01228-8. 

**Correspondence and requests for materials** should be addressed to Steve Albrecht or Christiane Becker. 

**Peer review information** _Nature Nanotechnology_ thanks Qi Chen and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Nanotechnology 

