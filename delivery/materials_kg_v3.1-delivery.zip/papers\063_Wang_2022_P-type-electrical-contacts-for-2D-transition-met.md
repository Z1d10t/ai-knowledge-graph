# P-type electrical contacts for 2D transition-metal dichalcogenides

| 字段 | 内容 |
|---|---|
| 期刊 | Nature |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 299 |
| 作者 | Yan Wang, Jong Chan Kim, Y. Li, K. Ma, Seokmo Hong, Minsu Kim, H. Shin, H. Jeong et al. |
| DOI | 10.1038/s41586-022-05134-w |
| 源文件 | 063_Wang_2022_P-type-electrical-contacts-for-2D-transition-met.pdf |

---
# P-type electrical contacts for two-dimensional transition metal dichalcogenides 

Yan Wang<sup>1+</sup> , Jong Chan Kim<sup>2+</sup> , Yang Li<sup>1</sup> , Kyung Yeol Ma<sup>3</sup> , Seokmo Hong<sup>3</sup> , Minsu Kim<sup>3</sup> , Hyeon Suk Shin<sup>3</sup> , Hu Young Jeong<sup>4</sup> , Manish Chhowalla<sup>1*</sup> 

**Affiliations:** 

_1Department of Materials Science and Metallurgy, University of Cambridge, 27 Charles Babbage Road, Cambridge CB3 0FS, UK_ 

_2UNIST Central Research Facilities (UCRF) and Department of Materials Science and Engineering, UNIST, Ulsan 44919, Republic of Korea_ 

_3Department of Chemistry & Low-Dimensional Carbon Materials Center, Ulsan National Institute of Science and Technology (UNIST), Ulsan 44919, Republic of Korea_ 

_4Graduate School of Semiconductor Materials and Devices Engineering, Ulsan National Institute of Science and Technology (UNIST), Ulsan, Republic of Korea_ 

_+These authors contributed equally to this work._ 

*Correspondence to: mc209@cam.ac.uk 

**Digital logic circuits are based on complementary pairs of n- and p-type field effect transistors (FETs) via complementary metal oxide semiconductor (CMOS) technology. In three dimensional (3D or bulk) semiconductors, substitutional doping of acceptor or donor impurities is used to achieve p- and n-type FETs. However, the controllable p-type doping of low-dimensional semiconductors such as two-dimensional transition metal dichalcogenides** 

**(2D TMDs) has proved to be challenging. Although it is possible to achieve high quality, low resistance n-type van der Waals (vdW) contacts on 2D TMDs**<sup>1–5</sup> **, obtaining p-type devices** 

**from evaporating high work function metals onto 2D TMDs has not been realised so far. Here we report high-performance p-type devices on single and few-layered molybdenum** 

**disulphide (MoS2) and tungsten diselenide (WSe2) based on industry-compatible electron beam evaporation of high work function metals such as Pd and Pt. Using atomic resolution imaging and spectroscopy, we demonstrate near ideal vdW interfaces without chemical interactions between the 2D TMDs and 3D metals. Electronic transport measurements reveal that the Fermi level is unpinned and p-type FETs based on vdW contacts exhibit low contact resistance of 3.3** **<mark>kΩ·µm,</mark> high mobility values of ~ 190 cm**<sup>**2**</sup> **-V**<sup>**-1**</sup> **s**<sup>**-1**</sup> **at room temperature with saturation currents in excess of > 10**<sup>**-5**</sup> **Amperes per micron (A-**  **m**<sup>**-1**</sup> **) and on/off ratio of 10**<sup>**7**</sup> **. We also demonstrate an ultra-thin photovoltaic cell based on n- and p-type vdW contacts with an open circuit voltage of 0.6 V and power conversion efficiency of 0.82%.** 

Two dimensional semiconductors based on TMD family of materials possess ideal attributes such as atomically thin body and absence of dangling bonds for next generation of electronics<sup>6,7</sup> . However, controllable and reliable substitutional doping of 2D TMDs is challenging – making it difficult to realise purely p- and n-type devices as well as achieving low resistance contacts<sup>8,9</sup> . When metal contacts are evaporated on 2D MoS2 and other TMDs, interface defects are created that pin the Fermi level near the conduction band and therefore n-type devices are most commonly obtained<sup>10,11</sup> . We<sup>2</sup> and others<sup>1,5,12,13</sup> have recently shown that low contact resistance vdW contacts can unpin the Fermi level so that high performance n-type and ambipolar devices on 2D TMDs can be realised. While p-type devices on multi-layered WSe2 have been demonstrated using mechanical transfer of metal contacts<sup>3,13</sup> , purely p-type FETs based on monolayers have yet to be achieved. P-type devices in monolayer MoS2 are even more challenging because the valence band energy is located > 6 eV below the vacuum level<sup>14</sup> . The fundamental challenge in achieving ultraclean p-type vdW contacts by electron beam evaporation – the most commonly used industrial method for deposition of contact metals – on single layer TMDs is that high work function metals 

require high energy for sublimation. The transfer of this energy to 2D TMD layers upon deposition of metal atoms leads to formation of defects<sup>15,16</sup> . 

We have found that clean vdW contacts by evaporation of Pt and Pd (as well as other metals such as Au) onto mono- and multi-layered 2D TMDs such as MoS2 and WSe2 can be achieved by minimizing damage at the interface by ensuring that temperature of the devices remains close to room temperature (see Methods). We have characterized the interfaces between the evaporated high work function metals and the 2D TMD semiconductors by annular dark field (ADF) imaging in a scanning transmission electron microscope (STEM), X-ray photoelectron spectroscopy (XPS) and electron energy loss spectroscopy (EELS). This work focuses on realizing p-type FETs with Pd or Pt contacts. We have also demonstrated devices with Au contacts and found that although Au forms clean contacts with MoS2 and WSe2, p-type behavior is limited by its relative low work function compared to Pd and Pt<sup>17</sup> (Extended Data Fig. 1). We find that Pd forms clean vdW contacts with few-layered MoS2 (Fig. 1a). The spacing between the sulfur and Pd atoms at the interface was found to be 2.3  0.1 Å [Fig. 1a (ii)] – slightly smaller than the vdW gap in indium alloy contacts<sup>2</sup> . The interface chemistry was analysed by taking several XPS and EELS spectra at multiple locations on the sample and on several samples to ensure good statistics. Chemical analysis of the Pd-MoS2 interface with XPS obtained from very thin (< 5 nm) Pd films on MoS2 revealed that the interface is clean with only pristine Pd 3d3/2 and Pd 3d5/2 peaks at ~ 340.3 eV and ~ 335 eV visible and no evidence of PdxSy or PdS2 was found – as indicated by typical results shown in Fig. 1b. The absence of chemical bonding at the interface is corroborated by EELS analysis (Fig. 1c) using a 0.9 Å electron beam probe focused on the sulfur atom adjacent to the deposited metal. The results show that the L2,3 edge of the S atom at the interface is the same as 

that of S atoms in the layers away from the interface – suggesting that the electronic structures of the S atoms are the same and no chemical interaction occurs between S and Pd at the interface. In contrast, for Pd deposition on WSe2 under the same conditions, ADF STEM imaging and XPS analysis indicates chemical interaction between the Pd and Se (Extended Data Fig. 2a and b). 

The results from deposition of Pt on multi-layered WSe2 are shown in Fig. 1d-f. The ADF STEM images of the interface are shown in Fig. 1d (i) and (ii). The spacing between the Pt and Se atoms is also ~ 2.3  0.1 Å [Fig. 1d (ii)]. Absence of chemical interaction between Pt and Se atoms at the interface was confirmed by several XPS scan on < 5 nm Pt films on WSe2 (Fig. 1e), which show only pristine Pt 4f5/2 at ~ 74 eV and Pt 4f7/2 at ~ 71 eV and no evidence for PtSe2 or PtxSey formation<sup>18</sup> . The EELS data taken from several regions at the interface shown in Fig. 1f also reveals that the electronic structure of the Se atoms at the interface is largely unperturbed. 

Electrical measurements on FETs fabricated using high work function metals as contacts and fewlayered 2D MoS2 and WSe2 as the semiconductor channels are shown in Fig. 2 . Remarkably, it can be seen from Fig. 2a, b that the deposition of Pd on few-layered MoS2 leads to primarily p- type FET transfer and output characteristics with the saturation hole current reaching ~ 4 µA/µm while the saturation electron current remains ~ 0.1 µA/µm. The hole mobility for MoS2 was found to be 45  5 cm<sup>2</sup> -V<sup>-1</sup> s<sup>-1</sup> . FET characteristics as a function of temperature (Extended Data Fig. 3a,b) were measured to extract the hole Schottky barrier<sup>19</sup> , which was found to be 500  50 meV (Extended Data Fig. 3c) for Pd contacts on few-layered MoS2. For the ambipolar devices, the Schottky barrier height can be extracted by comparing the hole and electron current branches<sup>20</sup> . The hole Schottky barrier extracted using this method was found to be 530  30 meV – consistent 

with the low temperature method. The fact p-type operation can be achieved with such a large Schottky barrier via modulation of Fermi level with gate voltage indicates that the Pd/2D MoS2 interface is clean and the Fermi level is unpinned<sup>21</sup> . 

We have found that purely p-type FETs with exceptionally high saturation hole currents of 3.07  10<sup>-4</sup> A (W= 12 µm, L= 4 µm.) and no measurable electron currents can be achieved with Pt contacts on few-layered WSe2, as observed in the transfer and output characteristics of devices in Fig. 2c and 2d. It can be seen in Extended Data Fig. 3d, e that the purely p-type behavior persists at temperatures down to 70 K. Mobility values of 190  10 cm<sup>2</sup> -V<sup>-1</sup> s<sup>-1</sup> were obtained with on/off ratios of 10<sup>7</sup> – comparable to those obtained for mechanically transferred Pt contacts<sup>4</sup> . Analysis of the hole Schottky barrier height reveals that it is 200  20 meV (Extended Data Fig. 3f), which leads to efficient injection of holes and acts as significant barrier for injection of electrons. Forward and reverse scans for multi-layer WSe2 FETs with Pt electrodes are shown in Extended Data Fig. 4. For comparison, damaged interface with ~ 3 nm intermixing layer is clearly seen in crosssectional STEM image of Pt-WSe2 interface without optimization of deposition parameters (Extended Data Fig. 5a). The transfer characteristics (Extended Data Fig. 5b) shows poor p-type performance with damaged interface. To demonstrate how the contacts affect the p-type characteristics, the results with Pt contacts on MoS2 and Pd contacts on WSe2 are shown in Extended Data Fig. 6. MoS2 FETs with Pt contacts exhibit lower hole currents compared to Pd contacts due to slightly lower work function of the thin Pt film deposited on TMD (Work function measurement results of Pt and Pd thin films grown on TMDs are shown in Extended Data Fig. 7). Poor p-type characteristics of WSe2 FETs with Pd contacts are due to chemical interactions between Pd metal and WSe2. In addition, the influence of substrates (SiO2, CVD grown hBN on 

SiO2, and PMMA on SiO2) on hole injection into MoS2 and WSe2 with high work function metal contacts is shown in Extended Data Fig. 8 and 9. We have also summarized the electron to hole current ratios of WSe2 and MoS2 FETs with different contacts on various substrates (Extended Data Fig. 10). The results show that contacts have dominant influence on the polarity of the devices while the substrates affect the hole current levels. The hole contact resistance of MoS2 FETs with Pd contacts and WSe2 FETs with Pt contacts were extracted by transfer length method (TLM) and shown in Fig. 2e,f. Hole contact resistance for multilayer MoS2 is around 430 kΩ·µm due to the large Schottky barrier. Contact resistance for multilayer WSe2 is ~ 3.3 kΩ·µm. Analysis of the literature reveals that our high work function metal contacts give comparable device performance 

to dry transferred metal contacts and are much lower than the reported evaporated contact resistances (Fig. 2g,h, also in Extended data Table 1-3). 

In addition to few-layered MoS2 and WSe2, we have also realised high work function vdW contacts on single layer TMDs grown by chemical vapor deposition (CVD) (Extended Data Fig. 11). Crosssectional ADF atomic resolution images of Pt on WSe2 and Pd on MoS2 are shown in Fig. 3a and 3e. Typical transfer curve of CVD grown monolayer WSe2 FETs with Pt electrodes is shown in Fig. 3b. It can be seen that the device shows purely p-type behavior with high saturation hole currents of ~ 7.6 µA/µm. The mobility of monolayer devices was found to range from 10 – 40 of cm<sup>2</sup> -V<sup>-1</sup> s<sup>-1</sup> . The output curves of CVD monolayer WSe2 FET are shown in Fig. 3c. The TLM results in Fig. 3d show that the contact resistance of monolayer WSe2 FET is around 229 kΩ·µm. The higher contact resistance compared to multilayer WSe2 is due to higher valance band edge for hole injection that leads to higher Schottky barrier height (Extended Data Fig. 12). The transfer characteristics of CVD grown monolayer MoS2 FETs are shown in Fig. 3f. We are able to obtain 

p-type behavior with ~ 0.008 µA/µm hole currents. This is consistent with the fact that hole injection into monolayer MoS2 is exceptionally difficult even with clean contacts of high work function metals because the valence band is located > 6 eV below the vacuum level, which means that there is a significant barrier for hole injection. The fact that we are able to obtain hole currents in monolayer MoS2 FETs is consistent with realisation of clean vdW contacts and absence of Fermi level pinning. These results suggest that it is possible to fabricate clean vdW contacts using high work function metals on CVD grown monolayers of MoS2 and WSe2 to achieve p-type FETs. 

We now demonstrate the integration of n- and p-type vdW contacts onto 2D TMDs in ultra-thin photovoltaics and photodiodes. The schematic of the device is shown in Fig. 4a where we utilise our previously reported<sup>2</sup> indium alloy vdW contacts for electron injection (n-type) and high work function vdW contacts based on Pt and Pd reported here for hole injection (p-type). This way, we are able to realize metal-semiconductor-metal (MSM) diode on the same 2D TMD. The FET output curves for In/Au-MoS2-Pd devices shown in Fig. 4b exhibit diode characteristics at all gate voltages, with a rectification ratio of up to 10<sup>6</sup> . The diode properties in dark and under illumination are shown in Fig. 4c. A significant photocurrent is generated under illumination and open circuit voltage of ~ 0.5  0.03 V is obtained. The corresponding power conversion efficiency is calculated to be ~ 0.40  0.02% and the power output of 267 nW is obtained at Vm= 0.3 V (maximum power output point). A similar device consisting of In/Au-WSe2-Pt also exhibited diode-like behavior at different gate voltages (Fig. 4d) with a rectification ratio of up to 10<sup>7</sup> . The current-voltage characteristics under dark and illumination for the In/Au-WSe2-Pt devices are shown in Fig. 4e. The open circuit voltage measured in these devices is larger (0.6  0.03 V), which results in higher conversion efficiency of 0.82  0.05% with a maximum power output of 572 nW at Vm= 0.35 V. 

The responsivity of the photodiodes was found to be 17.6 mA W<sup>−1</sup> and 33.1 mA W<sup>−1</sup> with external quantum efficiencies of 4.1% and 7.7% for the In-MoS2-Pd and In-WSe2-Pt devices, respectively. The photodiode properties (power output, power conversion efficiency, responsivity and external quantum efficiencies) for MoS2 and WSe2 devices are among the highest reported<sup>1,35–37</sup> . We have also measured diode properties at three different laser powers as shown in Fig. 4f. It can be seen that the photocurrent increases with power but the open circuit voltage (defined by the contacts) remains constant. 

We have demonstrated clean vdW contacts of high work function metals such as Pd, Pt and Au on few- and single-layered MoS2 and WSe2. These contacts lead to p-type characteristics on single layer MoS2 and purely p-type on WSe2. The results also suggest that the Fermi level is unpinned and can be modulated with gate voltage. P-N diodes have been achieved with n- and p-type contacts. Our discovery will allow realization of next generation of electronics based on 2D materials under the current complementary p-n FET paradigm. 

## **Reference:** 

1. Liu, Y. _et al._ Approaching the Schottky-Mott limit in van der Waals metal-semiconductor junctions, _Nature_ **557** , 696–700 (2018). 

2. Wang, Y. _et al._ Van der Waals contacts between three-dimensional metals and twodimensional semiconductors. _Nature_ **568** , 70–74 (2019). 

3. Wang, J. _et al._ Steep Slope p-type 2D WSe2 Field-Effect Transistors with Van der Waals Contact and Negative Capacitance. 2018 IEEE International Electron Devices Meeting (IEDM). IEEE, (2018). 

4. Jung, Y. _et al._ Transferred via contacts as a platform for ideal two-dimensional transistors. _Nat. Electron._ **2** , 187–194 (2019). 

5. Kim, B. K. _et al._ Origins of genuine Ohmic van der Waals contact between indium and MoS2. _npj 2D Mater. Appl._ **5** , 1–10 (2021). 

6. Novoselov, K. S., Mishchenko, A., Carvalho, A. & Castro Neto, A. H. 2D materials and van der Waals heterostructures. _Science_ 353 (2016). 

7. Chhowalla, M., Jena, D. & Zhang, H. Two-dimensional semiconductors for transistors. _Nature Reviews Materials_ 1, 1–15 (2016). 

8. Gao, H. _et al._ Tuning Electrical Conductance of MoS2 Monolayers through Substitutional Doping. _Nano Lett._ **20** , 4095–4101 (2020). 

9. Suh, J. _et al._ Doping against the native propensity of MoS2: Degenerate hole doping by cation substitution. _Nano Lett._ **14** , 6976–6982 (2014). 

10. Kim, C. _et al._ Fermi Level Pinning at Electrical Metal Contacts of Monolayer Molybdenum Dichalcogenides. _ACS Nano_ **11** , 1588–1596 (2017). 

11. Das, S., Chen, H. Y., Penumatcha, A. V. & Appenzeller, J. High performance multilayer MoS2 transistors with scandium contacts. _Nano Lett._ **13** , 100–105 (2013). 

12. Telford, E. J. _et al._ Via Method for Lithography Free Contact and Preservation of 2D Materials. _Nano Lett._ **18** , 1416–1420 (2018). 

13. Kong, L. _et al._ Doping-free complementary WSe2 circuit via van der Waals metal integration. _Nat. Commun._ **11** , 1–7 (2020). 

14. Rasmussen, F. A. & Thygesen, K. S. Computational 2D Materials Database: Electronic Structure of Transition-Metal Dichalcogenides and Oxides. _J. Phys. Chem. C_ **119** , 13169– 13183 (2015). 

15. Bonifas, A. P. & McCreery, R. L. Soft Au, Pt and Cu contacts for molecular junctions through surface-diffusion-mediated deposition. _Nat. Nanotechnol._ **5** , 612–617 (2010). 

16. Wu, R. J. _et al._ Visualizing the metal-MoS2 contacts in two-dimensional field-effect transistors with atomic resolution. _Phys. Rev. Mater._ **3** , 111001 (2019). 

17. Derry, G. N., Kern, M. E. & Worth, E. H. Recommended values of clean metal surface work functions. _J. Vac. Sci. Technol. A Vacuum, Surfaces, Film._ **33** , 060801 (2015). 

18. Mirabelli, G. _et al._ Effects of Annealing Temperature and Ambient on Metal/PtSe2 Contact Alloy Formation. _ACS Omega_ **4** , 17487–17493 (2019). 

19. Allain, A., Kang, J., Banerjee, K. & Kis, A. Electrical contacts to two-dimensional semiconductors. _Nature Materials_ , 14, 1195–1205 (2015). 

20. Das, S. & Appenzeller, J. WSe2 field effect transistors with enhanced ambipolar characteristics. _Appl. Phys. Lett._ **103** , 103501 (2013). 

21. Liu, Y., Stradins, P. & Wei, S. H. Van der Waals metal-semiconductor junction: Weak Fermi level pinning enables effective tuning of Schottky barrier. _Sci. Adv._ **2** , e1600069 (2016). 

22. Zhang, X. _et al._ Molecule-Upgraded van der Waals Contacts for Schottky-Barrier-Free Electronics. _Advanced Materials_ 33, 2104935, (2021). 

23.     Xu, S. _et al._ Universal low-temperature Ohmic contacts for quantum transport in transition metal dichalcogenides. _2D Mater._ **3** , 021007 (2016). 

24.     Movva, H. C. P. _et al._ High-Mobility Holes in Dual-Gated WSe2 Field-Effect Transistors. _ACS Nano_ **9** , 10402–10410 (2015). 

25. Zhou, C. _et al._ Carrier Type Control of WSe2 Field-Effect Transistors by Thickness Modulation and MoO3 Layer Doping. _Adv. Funct. Mater._ **26** , 4223–4230 (2016). 

26. Li, W. _et al._ Uniform and ultrathin high-κ gate dielectrics for two-dimensional electronic devices. _Nat. Electron._ **2** , 563–571 (2019). 

27. Zhang, L. _et al._ High-performance multilayer WSe2 p-type field effect transistors with Pd contacts for circuit applications. _J. Mater. Sci. Mater. Electron._ **32** , 17427–17435 (2021). 

28. Yang, S., Lee, G. & Kim, J. Selective p-Doping of 2D WSe2 via UV/Ozone Treatments and Its Application in Field-Effect Transistors. _ACS Appl. Mater. Interfaces_ **13** , 955–961 (2020). 

29. Allain, A. & Kis, A. Electron and Hole Mobilities in Single-Layer WSe2. _ACS Nano_ **8** , 7180–7185 (2014). 

30. Yeh, C.-H. _et al._ Graphene–Transition Metal Dichalcogenide Heterojunctions for Scalable and Low-Power Complementary Integrated Circuits. _ACS Nano_ **14** , 985–992 (2020). 

31. Li, J. _et al._ General synthesis of two-dimensional van der Waals heterostructure arrays. _Nature,_ **579** , 368–374 (2020). 

32. Zhang, R., Drysdale, D., Koutsos, V. & Cheung, R. Controlled Layer Thinning and p-Type Doping of WSe2 by Vapor XeF2. _Adv. Funct. Mater._ **27** , 1702455 (2017). 

33. Yamamoto, M., Nakaharai, S., Ueno, K. & Tsukagoshi, K. Self-Limiting Oxides on WSe2 as Controlled Surface Acceptors and Low-Resistance Hole Contacts. _Nano Lett._ **16** , 2720– 2727 (2016). 

34. Zhao, P. _et al._ Air Stable p-Doping of WSe2 by Covalent Functionalization. _ACS Nano_ **8** , 10808–10814 (2014). 

35. Pospischil, A., Furchi, M. M. & Mueller, T. Solar-energy conversion and light emission in an atomic monolayer p-n diode. _Nat. Nanotechnol._ **9** , 257–261 (2014). 

36. Went, C. M. _et al._ A new metal transfer process for van der Waals contacts to vertical 

Schottky-junction transition metal dichalcogenide photovoltaics. _Sci. Adv._ **5** , eaax6061 (2019). 

37. Zhang, Y. et al.  An Ultrafast WSe2 Photodiode Based on a Lateral p-i-n Homojunction. _ACS Nano_ **15** , 4405-4415 (2021). 

**Acknowledgements** MC, YW received funding from the European Research Council (ERC) Advanced Grant under the European Union ’ s Horizon 2020 research and innovation programme 

(grant agreement GA 101019828-2D- LOTTO]), Leverhulme Trust (RPG-2019-227), EPSRC (EP/ T026200/1, EP/T001038/1), and Royal Society Wolfson Merit Award (WRM\FT\180009). H.Y.J. acknowledges support from the National R&D Program through the National Research Foundation of Korea funded by the Ministry of Science and ICT (2022M3H4A1A01013228). 

**Author Contributions** MC conceived the idea, supervised the project and wrote the paper with YW. YW synthesized all the samples, measured all devices and analysed the results. JCK, HYJ performed and analysed the STEM and EELS measurements with YW and MC. YL assisted in photoresponse measurements. KYM and SH, HSS performed hBN growth. MK assisted in Raman and PL characterization. 

**Competing Interests** The authors declare no competing interests. 



**Figure 1 | Atomic resolution imaging and chemical analyses of the metal-semiconductor** 

**interface. a,** Aomic resolution images of Pd on multilayer MoS2. (i) Annular dark field (ADF) STEM image showing clean interface between Pd and MoS2. Scale bar = 1 nm.  (ii) Enlarged dashed rectangle region from (i) showing ADF STEM image where Mo, S and Pd atoms are visible. The distacne between Pd and S is 2.3  0.1 Å. Scale bar = 5 Å. **b,** X-ray photoelectron spectrocopy (XPS) of Pd-MoS2 interface showing only pristine Pd metal peaks with no evidence of PdS2 or other chemical reactions. **c,** Electron energy loss spectroscopy (EELS) showing that the sulfur atoms at the interface are completely unaffected by the deposition of metal on top. The sulfur peaks of the topmost and the fourth layer are the same within the measurement precision. **d,** Aomic resolution images of Pt on multilayer WSe2. (i) ADF STEM image of the interface and (ii) enlarged dashed rectangle region from (i). The distacne between Pt and Se is 2.3  0.1 Å. Scale bars = 1 nm in (i) and 5 Å in (ii). **e,** XPS of Pt-WSe2 interface showing pristine Pt metal peaks. **f,** EELS showing that the electronic structure of the Se atoms in all layers is similar. 



**Figure 2 | Multilayer MoS2 and WSe2  devices with Pd and Pt contacts. a,** Transfer curves of 

multilayer MoS2 with Pd contacts showing ambipolar device characteristics with higher hole current branch compared to electron current. W= 5.5 µm, L= 2 µm. **b,** Output curves of multilayer MoS2 with Pd contacts showing linear current-voltage curves for holes. **c,** Transfer curves of multilayer WSe2 with Pt contacts showing pure p-type device characteristics. W= 12 µm, L= 4 µm. **d,** Linear output characteristics of multilayer WSe2 with Pt electrodes. **e,** TLM results of multilayer MoS2 with Pd electrodes. **f,** TLM results of multilayer WSe2 with Pt contacts. **g, h,** Comparison of drain current and contact resistance of WSe2 FETs with values reported in the literature using different methods<sup>2,4,13,22–34</sup> . 



**Figure 3 | CVD grown monolayer MoS2 and WSe2 with high work function metal contacts.** 

**a,** ADF STEM image showing clean interface between Pt and monolayer WSe2. Scale bar = 1 nm. **b,** Transfer curve of monolayer WSe2 with Pt contact showing pure p-type characteristics. W= 4 µm, L= 1.5 µm. **c,** Output curve of monolayer WSe2 FET with Pt contacts. **d,** TLM result of WSe2 FET showing contact resistance value around 229 kΩ·µm. **e,** ADF STEM image showing clean interface between Pd and monolayer MoS2. Scale bar = 1 nm. **f,** Transfer curve of monolayer MoS2 with Pd contacts showing ambipolar device characteristic with higher hole current branch. W= 5 µm, L= 1 µm. The electron current values are << 1 nA. 



**Figure 4 | Metal-semiconductor-metal photodiode with asymmetric electrodes for MoS2 and** 

**WSe2. a,** Schematic illustration of the assymetric contact diode. **b,** Output curves of MoS2 device with In/Au and Pd contacts showing good rectification behavior. **c,** I-V curves of the diode under dark and illumination (532 nm, 70  W), demonstrating open circuit voltage of 0.48 V and output power of 267 nW. The red dashed lines show the corresponding power area for maximum power conversion. **d,** Output curves of WSe2 device with In/Au and Pt contacts showing good rectification behavior. **e,** I-V curves of the diode under dark and illumination (532 nm, 70  W), demonstrating an open circuit voltage of 0.6 V and output power of 572 nW. **d,** I-V curves under different illumination power showing increasing current and stable open voltage. 

## **Methods:** 

**High work function metal deposition on 2D TMDs for achieving vdW contacts:** It has been widely reported that deposition of high work function metals with high melting temperature cause damage to the atomically thin 2D semiconductors<sup>1,13</sup> . We have carefully investigated the influence of a wide range of electron beam evaporation parameters (deposition rate, base vacuum pressure, power, and temperature) on the metal/2D TMD interface. We have found that radiative heating of the 2D materials from the crucible during metal evaporation is a crucial parameter for creation of vdW contacts with high work function metals (See Extended Data Fig. 13). To minimize the damage to the TMDs, we conducted the metal evaporation at a base pressure of < 10<sup>-8</sup> torr and long working distance of 70 cm. <mark>Furthermore, during heating of the crucible to metal sublimation temperature, the crucible and substrate shutters were kept closed to avoid radiative heating of the device. Once the crucible was sufficiently hot for metal sublimation to occur, the deposition was carried out in steps to ensure the device/ sample holder remained at or close to room temperature. For example, a typical process involved multiple steps of 10 nm Pd or Pt depositions at a rate of 2 Å/s. After this initial 50s step, the deposition was paused for one hour to allow the vacuum chamber and substrate holder to cool to room temperature before starting the next deposition step. Extended Data Fig. 13 shows the temperature versus time sketches for deposition of 300 Å Pt in a single step and with multiple steps. The temperature versus time plot on the left (without steps) shows that during deposition the temperature of the holder gradually increases with time. Usually, the substrate temperature increased from 18 °C to 36 °C during 300 Å Pt deposition and the chamber pressure increased from 5  10</mark><sup>-8</sup> <mark>torr to 8  10</mark><sup>-7</sup> <mark>torr. In contrast, the sketch on the right shows the temperature variation during deposition with three steps (100 Å Pt for each step). After each 100 Å of Pt deposition, the chamber and substrate holder were allowed to cool to room temperature</mark> 

<mark>and the chamber pressure returned to the base pressure before running another deposition (red curve region in the plot). As a result, the temperature of the sample holder remained quite low (~24 °C) compared to the deposition without steps. These temperatures were recorded from the thermocouple connected at the bottom of the sample holder (a massive copper block). The real device temperature is likely to be much higher than the temperature of the Cu block. The temperature of the Cu block surface exposed to irradiation where the device is placed is likely to be higher than the back thermocouple reading. This supported by the fact that the PMMA crosslinks (Extended Data Fig. 12) at low deposition rates. We use the values from the thermocouple to compare relative heating of the device during contact evaporation. Typically, 20 nm of Pd capped with 20 nm of Au was used for Pd contacts (all deposited at 2 Å/s in 100 Å steps). For Pt contacts, 10 nm of Pt capped with 30 nm of Au was used.</mark> The voltage supplied to the crucible was 10 kV and the current used for the Pd deposition was 60 mA. For Pt deposition, the voltage was 10 kV and the current was 110 mA. For Au deposition, the voltage was 10 kV and the current was 75 mA. Typically, we used 20 nm of Pd and 20 nm of Au for Pd contacts. For Pt contacts, we deposited 10 nm of Pt first then 30 nm Au. 

The method and results are reproducible. We have fabricated hundreds of devices with more than 50% showing dominant p-type behavior This is because we did not take any special precautions during device fabrication. For example, all materials and devices were processed in air and the 2D TMDs were transferred via wet chemical processes which can introduce residues. Despite this, we were able to reproduce our results from batch to batch. We fabricated devices at two institutions using completely different electron beam evaporation systems and found similar results. The devices used in this study were fabricated at the University of Cambridge and Ulsan Institute of Science and Technology. 

**2D TMD materials synthesis:** <mark>Few-layered (3 - 20 layers, unless otherwise specified) MoS</mark> 2 <mark>and WSe</mark> 2 <mark>samples were obtained by mechanical exfoliation of bulk MoS</mark> 2 <mark>and WSe</mark> 2 <mark>crystals onto 300 nm or 100 nm of thermally grown SiO</mark> 2 <mark>on degenerately doped silicon substrates</mark> . The silicon substrate was cleaned in the usual way<sup>2</sup> prior to mechanical transfer. This involved washing with acetone, isopropanol and deionized water. After exfoliation, the flakes are identified and devices are patterned by electron beam lithography. 

Single-layer MoS2 and WSe2 were grown by chemical vapor deposition (CVD). Detailed description of the methods is provided in references<sup>38</sup> and<sup>39</sup> .  The as-deposited single layers were confirmed by PL and Raman spectroscopies shown in Extended Data Fig. 11. After growth, the samples were transferred to target substrates by wet transfer. 

**Role of substrates in devices** : To achieve p-type devices, the electron doping from SiO2 must be suppressed. To this end, it is important to passivate the SiO2 substrate with self-assembled monolayers (SAMs), or by placing the 2D TMDs on hBN or polymethyl methacrylate (PMMA) substrates. The results in the main paper are based on 2D TMDs on SiO2 passivated by SAMs. The FET characteristics of Pd and Pt contacts on few-layered MoS2 and WSe2 on different substrates <mark>(pure SiO</mark> 2 <mark>, hBN/SiO</mark> 2 <mark>, PMMA/SiO</mark> 2) are shown in Extended Data Fig. 8 and 9. 

SAM treated SiO2 was obtained by immersing in FOTS (trichloro-(1H,1H,2H,2H-perfluorooctyl) silane, silane/n-hexadecane (1:1000 v:v), purchased from Sigma-Aldrich ) for 1 hour to passivate the surface -OH groups. After passivation, the substrate was rinsed with acetone and isopropanol multiple times. The hBN in this work is few-layer hBN grown by CVD. The PMMA substrate was 

obtained by spin coating (MicroChem, A6) at 3000 rpm for 1 minute and heating at 180<sup>o</sup> C for 5 minutes. Since the PMMA substrate is not compatible with the ebeam lithography process. TEM grid was used as shadow mask to achieve channel length of around 10  m. 

**Measurements:** Electrical measurements at room and low temperature were carried using the Keithley 4200 current voltage system. Capacitances of the dielectrics used in this study were measured with Keithley 4200 capacitance-voltage unit. The low temperature measurements were performed in Lakeshore probe station. X-ray photoelectron spectroscopy (XPS) was measured by the Thermo Scientific K-Alpha system. PL and Raman data was collected using a 514-nm laser excitation focused through a × 100 objective lens. The spectra were taken at an incident laser power of 50 μW, which was sufficiently low to avoid any damage to the sample. Photoresponse current-voltage measurements were done using a 532-nm laser excitation focused through a 50× objective lens. 

XPS measurements of the metal/semiconductor interface was carried out by depositing 20 nm of the metal on the 2D TMD and then incrementally etching the metal while simultaneously obtaining the spectra. The XPS spectra presented in the main paper were collected when the metal was thin enough (< 5 nm) for the x-rays to penetrate the metal and observe signal from both the contact metal and the TMDs (that is XPS peaks from the chalcogen and transition metal). The interface chemistry was double confirmed by XPS measurements of ~3 nm thin metal deposited on 2D TMDs without any depth profiling. UPS measurements are performed in ultrahigh vacuum using a He discharge UV lamp (He I line at 21.2 eV) to test work function of the thin metal films deposited on TMDs. 

**Schottky barrier extraction** : Schottky barrier height of the contact was extracted using exactly the same methodology as in our previous work<sup>2</sup> by measuring the activation energy in the thermionic emission region. The current density of thermal emission through a metalsemiconductor contact is given by: 



<!-- Start of picture text -->
𝑞 Ф 𝐵0 𝑞𝑉<br>)]<br>𝐽= 𝐴 ∗ 𝑇 𝛼 exp [−  𝑘𝐵𝑇 ]  [1 −exp (− 𝑘𝐵𝑇<br><!-- End of picture text -->

Where A* is the Richardson constant, V is the applied voltage, T is the temperature, α is an exponent equal to 2 for bulk semiconductors and 3/2 for 2D semiconductors, and kB is the Boltzmann’s constant. Using this equation, the slope of the Richardson plot, ln(I/T<sup>3/2</sup> ) ~ 1/T, yields ФB0 as a function of gate voltage. The gate voltage at which the Schottky barrier height tends to curve away from the linear dependence is where the flat band condition occurs because after the gate voltage reaches this condition carriers are transferred through tunneling as well. To extract Schottky barrier height, we identify the voltage at which ФB0 stops linearly depending on Vg, as shown in Extended Fig. 3c and 3f. 

For ambipolar FETs, the Schottky barrier height can also be estimated by comparing the electron and hole branches. Electron and hole currents can be written as: 



<!-- Start of picture text -->
kT<br>In = A ∗ T α e −q∅b_n<br>kT<br>Ip = A ∗ T α e −q∅b_p<br><!-- End of picture text -->

Combining with Eg = q∅b_n + q∅b_p , both electron and hole barriers can be extracted by comparing the electron and hole current branches. 

**STEM specimen preparation and acquisition parameters:** The cross-sectional TEM specimens were fabricated using the same method described in reference<sup>2</sup> . Briefly, samples were prepared 

using a focused ion beam (FEI Helios NanoLab 450).  The cross-sectional STEM images were taken at 200 keV using a FEI Titan<sup>3</sup> G2 60-300 with a double-side spherical aberration (Cs) corrector. The probe convergence semi-angle was set to be ~ 26 mrad. ADF STEM images were acquired from 50-200 mrad range. All EELS measurements were collected in dual-mode to enable simultaneous collection of a zero-loss and a core-loss spectrum to compensate for energy drift during specimen acquisition. 

**References:** 

38. Wang, P. _et al._ Mechanism of Alkali Metal Compound-Promoted Growth of Monolayer MoS2 : Eutectic Intermediates. _Chem. Mater._ **31** , 873–880 (2019). 

39. Sahoo, P. K., Memaran, S., Xin, Y., Balicas, L. & Gutiérrez, H. R. One-pot growth of twodimensional lateral heterostructures via sequential edge-epitaxy. _Nature_ **553** , 63–67 (2018). 

40. Fang, H. _et al._ High-performance single layered WSe2 p-FETs with chemically doped contacts. _Nano Lett._ **12** , 3788–3792 (2012). 

41. Ji, H. G. _et al._ Chemically Tuned p- and n-Type WSe2 Monolayers with High Carrier Mobility for Advanced Electronics. _Adv. Mater._ **31** , 1903613 (2019). 

42. Liu, B. _et al._ Chemical Vapor Deposition Growth of Monolayer WSe2 with Tunable Device Characteristics and Growth Mechanism Study. _ACS Nano_ **9** , 6119–6127 (2015). 

43. Ma, Y. _et al._ Reversible Semiconducting-to-Metallic Phase Transition in Chemical Vapor Deposition Grown Monolayer WSe2 and Applications for Devices. _ACS Nano_ **9** , 7383–7391 (2015). 

44. Zhang, X. _et al._ Defect-Controlled Nucleation and Orientation of WSe2 on hBN: A Route to Single-Crystal Epitaxial Monolayers. _ACS Nano_ **13** , 3341–3352 (2019). 

45. Vu, V. T. _et al._ One-Step Synthesis of NbSe2/Nb-Doped-WSe2Metal/Doped- 

   - Semiconductor van der Waals Heterostructures for Doping Controlled Ohmic Contact. _ACS Nano_ **15** , 13031–13040 (2021). 

46. Fan, S. _et al._ Tailoring Quantum Tunneling in a Vanadium-Doped WSe2/SnSe2 Heterostructure. _Adv. Sci._ **7** , 1902751 (2020). 

47. Sata, Y. _et al._ N- and p-type carrier injections into WSe2 with van der Waals contacts of two-dimensional materials. _Jpn. J. Appl. Phys._ **56** , 04CK09 (2017). 

48. Si, M. _et al._ Steep-Slope WSe2 Negative Capacitance Field-Effect Transistor. _Nano Lett._ **18** , 3682–3687 (2018). 

49. Smyth, C. M. _et al._ Engineering the Palladium–WSe2 Interface Chemistry for Field Effect Transistors with High-Performance Hole Contacts. _ACS Appl. Nano Mater._ **2** , 75–88 (2018). 

50. Abuzaid, H., Cheng, Z., Li, G., Cao, L. & Franklin, A. D. Unanticipated Polarity Shift in Edge-contacted Tungsten-based 2D Transition Metal Dichalcogenide Transistors. _IEEE Electron Device Letters_ **_42_** _, 1563-1566, (2021)._ 

51. Pang, C.-S. _et al._ Atomically Controlled Tunable Doping in High-Performance WSe2 Devices. _Adv. Electron. Mater._ **6** , 1901304 (2020). 

52. Chuang, S. _et al._ MoS2 P-type transistors and diodes enabled by high work function MoOx contacts. _Nano Lett._ **14** , 1337–1342 (2014). 

53. Liu, X. _et al._ P-Type Polar Transition of Chemically Doped Multilayer MoS2 Transistor. _Adv. Mater._ **28** , 2345–2351 (2016). 

54. Chen, M. _et al._ Stable few-layer MoS2 rectifying diodes formed by plasma-assisted doping. _Appl. Phys. Lett._ **103** , 142110 (2013). 

55. Das, S., Demarteau, M. & Roelofs, A. Nb-doped single crystalline MoS2 field effect transistor. _Appl. Phys. Lett._ **106** , 173506 (2015). 

56. Suh, J. _et al._ Doping against the native propensity of MoS2: Degenerate hole doping by cation substitution. _Nano Lett._ **14** , 6976–6982 (2014). 

57. Lin, C. Y. _et al._ Polarity-controllable MoS2 transistor for adjustable complementary logic inverter applications. _Nanoscale Horizons_ **5** , 163–170 (2019). 

58. Lan, Y. W. _et al._ Scalable fabrication of a complementary logic inverter based on MoS2 finshaped field effect transistors. _Nanoscale Horizons_ **4** , 683–688 (2019). 

## **Data availability** 

The data that support the findings of this study are available from the corresponding author upon reasonable request. 



**Extended Data Figure 1 | Au contacts on MoS2 and WSe2. a** , Cross-sectional STEM image of 

a Au-WSe2 device showing cleaning van der Waals interface. Scale bar = 5 nm. **b** , Transfer curves of WSe2 device with Au contact showing p-type results. W= 4 µm, L= 1.5 µm. **c,** Output curves of WSe2 device with Au contacts. The non-linear I-V curves indicate high Schottky barrier with Au contacts for WSe2. **d,** Transfer curves of MoS2 device with Au contacts on PMMA/SiO2 substrate showing ambipolar behavior with dominant electron current. W= 8 µm, L= 10 µm. **e,** Output curves of MoS2 device with Au contacts. 



**Extended Data Figure 2 | Pd contacts on WSe2. a (i and ii)** , Cross-sectional STEM of the Pd- 

WSe2 interface. Scale bar = 1 nm. **b** , XPS of Pd-WSe2 interface showing the presence of PdSe2 

peaks, indicating reaction between the deposited metal and the Se atoms. 



**Extended Data Figure 3 | Low temperature measurements. a,** Transfer curves of MoS2 device with Pd contacts on PMMA/SiO2 substrate at different temperatures. The hole transport part showed a more obvious temperature dependence compared to the electron branch, indicating thermally activated transport for holes and tunnel dominant transport for electrons due to higher Schottky barrier for electrons. **b,** Transfer curves from a plotted linearly. **c,** Schottky barrier extraction for holes in multilayer MoS2 with Pd contacts. **d,** Transfer curves of WSe2 device with Pt contacts at different temperatures. **e,** Transfer curves from **d** plotted linearly. **f,** Schottky barrier 

extraction for holes in multilayer WSe2 with Pt contacts. 



**Extended Data Figure 4 | Hysteresis in WSe2 FETs.** Forward (red) and reverse (black) scans for multi-layer ( **a** ) and monolayer ( **b** ) WSe2 FETs with Pt electrodes on SAM treated SiO2. **c,** Transfer characteristics of the same monolayer WSe2 FET measured in air and vacuum. <mark>It can be clearly seen that the hysteresis decreases in vacuum suggesting it is caused by adsorbates and not any defects at the contacts.</mark> 



**Extended Data Figure 5 | Pt on WSe2 without optimized deposition parameters. a,** Cross- 

sectional STEM of Pt/WSe2 interface without optimization of the deposition conditions. **b,** Transfer curve of WSe2 FET with damaged interface showing very poor p-type characteristics. 



**Extended Data Figure 6 | Device performance of MoS2 with Pt contacts and WSe2 with Pd** 

**contacts. a** , Transfer curves for MoS2 device with Pt contacts showing ambipolar characteristics with higher electron branch. W= 4 µm, L= 10 µm. **b** , Output curves of MoS2 device with Pt contacts. **c** , Transfer curves of WSe2 device with Pd contacts showing ambipolar characteristics with higher hole branch. W= 38 µm, L= 10 µm. **d** , Output curves of WSe2 device with Pd contacts showing non-ideal characteristics. 



**Extended Data Figure 7 | Work function measurements of Pd and Pt thin films on TMDs** . **a,** 

AFM image of ~3 nm Pt deposited on cleaved MoS2 crystal. **b,** Height profile of the blue line in the AFM image showing uniform growth of Pt on MoS2. **c** , UPS result of Pd thin film on MoS2 showing work function ~5.2 eV. **d** , UPS result of Pt thin film on WSe2 showing work function ~5.0 eV. 



**Extended Data Figure 8 | Properties of MoS2 FETs with Pd (a-f) and Pt (g-l) contacts on** 

**different substrates. a,b,** Transfer and output curves of MoS2 FET with Pd contacts on SiO2. W= 

4 µm, L= 1 µm. **c,d,** Transfer curves of MoS2 FET with Pd contacts on hBN. W= 3 µm, L= 1.5 µm. **e,f,** Transfer and output curves of MoS2 FETs with Pd contacts on PMMA. W= 16 µm, L= 10 

µm. **g,h,** Transfer and output curves of MoS2 FET with Pt contacts on SiO2. W= 6 µm, L= 0.8 µm. **i,j,** Transfer and output curves of MoS2 FET with Pt contacts on hBN. W= 2.5 µm, L= 1 µm. **k,l,** Transfer and output curves of MoS2 FET with Pt contacts on PMMA. W= 25 µm, L= 10 µm. It can be seen that Pd contacts lead to higher hole current for MoS2 FETs compared to Pt contacts 

and the substrates have some influence on the hole injection level. 



**Extended Data Figure 9 | Properties of WSe2 FETs with Pd (a-f) and Pt (g-l) contacts on** 

**different substrates. a,b,** Transfer and output curves of WSe2 FET with Pd contacts on SiO2. W= 

6.5 µm, L= 1 µm. **c,d,** Transfer and output curves of WSe2 FET with Pd contacts on hBN. W= 6.5 µm, L= 0.8 µm. **e,f,** Transfer and output curves of WSe2 FET with Pd contacts on PMMA. W= 25 

µm, L= 10 µm. **g,h,** Transfer and output curves of WSe2 FET with Pt contacts on SiO2. W= 4 µm, L= 0.8 µm. **i,j,** Transfer and output curves of WSe2 FET with Pt contacts on hBN. W= 1.8 µm, L= 2.5 µm **k,l,** Transfer and output curves of WSe2 FET with Pt contacts on PMMA. W= 5 µm, L= 10 µm. The results show poor p-type performance of WSe2 FETs with Pd contacts on all different substrates. 



**Extended Data Figure 10 | WSe2 FETs with differnt contacts on different substrates.** The scatter plots show the ratio of electron to hole current (Ielectron/Ihole) of WSe2 FETs fabricated on different substrates (SiO2, hBN, PMMA and SAM treated SiO2 substrate ) using different contacts (In, Au, Pd and Pt). The results excluded the p-type characteristics originate from SAM doping as the trend shows the polarity clearly varies with different contacts. 



**Extended Data Figure 11 | CVD grown WSe2 and MoS2. a** , Optical image of CVD grown WSe2 

on SiO2. Scale bar = 10  m. **b** , Raman of WSe2 showing pristine WSe2. **c** , PL of monolayer WSe2 

showing a peak at ~ 1.65 eV. **d** , Optical image of CVD grown MoS2 on SiO2. Scale bar = 20  m. 

**e** , Raman of MoS2 showing pristine MoS2. **f** , PL of MoS2 with a peak at ~1.83 eV. 



**Extended Data Figure 12 | Schottky barrier height for monolayer WSe2. a,** Transfer curves of 

monolayer WSe2 FET device with Pt contacts on SAM treated SiO2 substrate measured at different temperatures. **b,** Transfer curves from **a** plotted linearly. **c,** The extracted Schottky barrier height for the monolayer WSe2 is ~400 meV, which is 200 meV higher than multilayer WSe2 FETs due to higher valence band edge of monolayer WSe2. 



**Extended Data Figure 13 | The influence of deposition rate on metal/2D TMD interface** . **a,** 

Optical microscope image of a device where the metal (Au in this case) was deposited at a deposition rate of 0.1 Å/s. To achieve 50 Å, the deposition was conducted for just over eight minutes. The radiative heat emitted from the evaporation crucible causes significant damage to the device. **b,** Cross-sectional atomic resolution ADF STEM image shows that the interface is damaged in this case (arrow indicating mixing of Au atoms with the S atoms of MoS2. **c, d,** In 

contrast, when the deposition is done quickly (deposition rate = 2 Å/s) and in multiple steps, the device is undamaged and the interface shown in panel **d** is ultra-clean. 



**Extended Data Figure 14 | Evaporation procedures for clean high work function contacts. a,** 

Summary of e-beam evaporation current and voltage applied to deposit Au, Pd and Pt at 0.1 Å/s 

and 2 Å/s. The irradiation energy supplied to the device for high rate deposition is much lower than for low rate deposition. **b,** Comparison of substrate temperature versus time for 300 Å Pt depositions done in single and multiple steps. The left figure (single step deposition) shows that during deposition, the temperature of the holder gradually increases with time. For deposition with steps, the chamber and substrate holder were allowed to cool to room temperature before running the next deposition. Thus, the temperature of the sample remained lower than deposition without steps. 



**Extended Data Table 1 | P-type characteristics of monolayer WSe2 FETs** 



**Extended Data Table 2 | P-type characteristics of multilayer WSe2 FETs** 



**Extended Data Table 3 | P-type characteristics of multilayer MoS2 FETs** 

