# Understanding Transient Photoluminescence in Halide Perovskite Layer Stacks and Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Advanced Energy Materials |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 214 |
| 作者 | Lisa Krückemeier, Benedikt Krogmeier, Zhifa Liu, U. Rau, T. Kirchartz |
| DOI | 10.1002/aenm.202003489 |
| 源文件 | 014_Krückemeier_2021_Understanding-Transient-Photoluminescence-in-Hal.pdf |

---
# **Understanding Transient Photoluminescence in Halide Perovskite Layer Stacks and Solar Cells** 

_Lisa Krückemeier_<sup>_*_</sup> _, Benedikt Krogmeier, Zhifa Liu, Uwe Rau and Thomas Kirchartz_<sup>_*_</sup> 

## **Affiliations** 

L. Krückemeier, B. Krogmeier, Z. Liu, Prof. U. Rau, Prof. T. Kirchartz IEK5-Photovoltaik Forschungszentrum Jülich 52425 Jülich, Germany E-mail: l.krueckemeier@fz-juelich.de E-mail: t.kirchartz@fz-juelich.de L. Krückemeier, Prof. U. Rau Faculty of Electrical Engineering and Information Technology, RWTH Aachen University, Mies-van-der-Rohe-Straße 15, 52074 Aachen, Germany Prof. T. Kirchartz Faculty of Engineering and CENIDE University of Duisburg-Essen Carl-Benz-Str. 199, 47057 Duisburg, Germany 

## **Keywords** 

decay time, time-resolved photoluminescence, interfacial recombination, interface charging, charge transfer, charge-carrier lifetime, non-radiative voltage losses, photovoltaics 

### **Abstract** 

While transient photoluminescence measurements are a very popular tool to monitor the chargecarrier dynamics in the field of halide perovskite photovoltaics, interpretation of data obtained on multilayer samples is highly challenging due to the superposition of various effects that modulate the charge-carrier concentration in the perovskite layer and thereby the measured PL. These effects include bulk and interfacial recombination, charge transfer to electron or hole transport layers and capacitive charging or discharging. Here, numerical simulations with Sentauraus TCAD, analytical solutions and experimental data with a dynamic range of  ~7 orders of magnitude on a variety of different sample geometries from perovskite films on glass to full devices are combined to present an improved understanding of this method. A presentation of the decay time of the TPL decay that follows from taking the derivative of the photoluminescence at every time is proposed. Plotting this decay time as a function of the time-dependent quasi-Fermi level splitting enables distinguishing between the different contributions of radiative and non-radiative recombination as well as charge extraction and capacitive effects to the decay. 

1 

### **1. Introduction** 

Technological development of halide-perovskite solar cells towards even higher efficiencies requires ways of understanding and quantitatively analyzing the main loss processes.<sup>[1-3]</sup> Non-radiative recombination is one of the main loss processes in basically any solar-cell technology<sup>[4, 5]</sup> including perovskites that leads to reduced open-circuit voltages at a given illumination condition.<sup>[6-9]</sup> Transient photoluminescence (TPL) is a frequently used tool to monitor the charge-carrier dynamics and investigate these recombination losses.<sup>[10-12]</sup> While TPL measured on bare perovskite films on glass is a well-understood and frequently-used method to derive charge-carrier lifetimes and recombination coefficients,<sup>[13, 14]</sup> it is typically the recombination at interfaces between the absorber and charge transfer layers that is the dominant sources of recombination in a complete device.<sup>[15-21]</sup> 

However, adding contact layers to the perovskite film not only adds additional recombination paths but also leads to effects like charge-carrier separation or interface-charging effects<sup>[21-23]</sup> that may change the recombination kinetics fundamentally. Thus, the information on recombination may be totally obscured by interfacial effects such that, e.g., a faster photoluminescence (PL) decay cannot anymore be interpreted simply as an increased recombination coefficient. Hence, misinterpretation of experimental data becomes likely, especially if the information contained in the decay curve is reduced to a single value – the characteristic decay time of a mono-exponential decay. The present paper introduces a method to analyse the differential PL decay that uses the derivative of the photoluminescence at every time during the transient.<sup>[22]</sup> We propose to plot this decay time as a function of the corresponding quasi-Fermi level splitting allowing us to better understand the complex interplay between charge extraction and interface or contact charging with radiative and non-radiative recombination. We use a combination of numerical simulations with Sentauraus TCAD, analytical models and experimental data to illustrate how the different effects influence the PL transients and the resulting decay times. 

In the following, we investigate transient photoluminescence measurements on the different sample geometries shown in the overview in **Figure 1** that start with films on glass and continue via layer stacks to full devices and discuss their respective peculiarities. We show how the addition of further layers and interfaces modifies the transients and adds physical effects that must be considered. With this step-bystep description we aim to create an understanding of which processes dominate and are important for these different sample types and how they affect the transient PL decay and the extracted decay time. This step-by-step approach is conceptually similar to the already well-understood analysis of steady state PL (SSPL) as a function of sample type that allows screening contact layers for minimum recombination losses<sup>[15, 24]</sup> and to also analyze and quantify changes in ideality factor<sup>[20, 24]</sup> and resistive effects.<sup>[25]</sup> In SSPL any change in absolute intensity between different samples suggests that the difference between the samples (e.g. an additional interface and layer) must be the cause of the loss in PL which is linked to a loss in quasi-Femi level splitting. In contrast, a clear correlation between the 

2 

decay of a transient PL signal and the amount of recombination is not necessarily present, because in a transient experiment currents can temporarily flow even at open circuit. 



**Figure 1:** Overview over the different halide perovskite sample types that are investigated with transient photoluminescence. Depending on the sample type (i.e., absorber layer on glass or absorber layer with one or two contact layers attached), the complexity of the interpretation of data increases from left to right. The second row illustrates typical mechanisms that affect the PL decay in different sample geometries. While the film on glass is only affected by bulk and surface recombination, samples with interfaces to charge extraction layers are affected by charge accumulation and recombination at the interfaces between absorber and charge-extraction layer. On fully contacted devices, charging and discharging of the electrodes finally affects the global band diagram and therefore the transients measured on full devices. 

### **2. Perovskite film on glass** 

The simplest sample geometry is that of a perovskite film on glass. Therefore, we want to use this device geometry as a starting point to recapitulate the basic theory of TPL measurements and data interpretation that is already quite well understood and briefly introduce the terminology and the physical parameters that we will use during the discussion. Furthermore, we introduce the representation of the decay time _τ_ TPL, which results from the derivative of the photoluminescence with respect to time that we plot as a function of the corresponding time-dependent quasi-Fermi level splitting _∆E_ F. 

3 

### **2.1. Perovskite film on glass with a passivated surface** 

At first, we consider charge-carrier recombination only in the bulk and leave out the effect of surface recombination, which is discussed separately in section 2.2. A perovskite film on glass whose surface is passivated, e.g. by an organic passivation layer,<sup>[26, 27]</sup> is suitable as a corresponding test structure, because the interface between perovskite layers and glass substrates is typically quite inert and not particularly recombination active.<sup>[13, 28]</sup> When the semiconducting perovskite film is photoexcited by a laser pulse, free excess-electrons  _n_ and equal density of holes  _p =_  _n_ are generated. The initial generation profile of these excess-charge carriers depends on the optical properties of the perovskite, its thickness, and the excitation wavelength. The initially inhomogeneous distribution of the charge-carrier concentration is flattened by diffusion. Since the perovskite film is typically only a few hundred nanometers thick and the charge-carrier mobility is typically > 1 cm²/Vs,<sup>[29]</sup> this carrier equilibration occurs in the first hundreds of pico- to several nanoseconds after the laser pulse. For simplicity, we therefore assume that the system has no spatial gradients of electron or hole concentrations or the electrostatic potential. This assumption leads us to the convenient situation that diffusion and drift currents can be neglected and that the photogenerated charge carriers  _n_ vanish over time only through different recombination processes. The rate equation 



<!-- Start of picture text -->
 n = − k rad ( np − n i2 ) − np − n i2 − C n n ( np − n i2 ) − C p p ( np − n i2 ) (1)<br> t  p n + n p<br><!-- End of picture text -->

accounts for the rates of these different competing processes and describes the change of excess-charge carrier concentration as a function of time. Here, _n_ i is the intrinsic charge-carrier density _, n_ is the total electron and _p_ the total hole concentrations, being defined as _n_ = _n_ 0+ _∆n_ and _p_ = _p_ 0+ _∆n_ , respectively, with the corresponding equilibrium concentrations _n_ 0 and _p_ 0. For the moment, we keep the condition  _p =_  _n_ and therefore do not distinguish between the rate equations for electrons and holes. For a perovskite film on glass three different bulk-recombination mechanisms need to be considered, which are radiative band-to-band recombination<sup>[30, 31]</sup> and non-radiative recombination via Auger<sup>[32]</sup> or firstorder Shockley-Read Hall (SRH).<sup>[33, 34]</sup> The radiative recombination coefficient is given by _k_ rad, _τ_ n and _τ_ p are the non-radiative SRH lifetime for electrons and holes, respectively. For the Auger recombination rates, _C_ n represents the Auger coefficient for electrons and _C_ p is the Auger coefficient for holes. Note that the effect of photon recycling<sup>[35]</sup> is not explicitly considered in this paper, so the radiative coefficient _k_ rad is the corresponding external quantity. Photoluminescence is based on measuring the emitted photons that have been created by radiative recombination with a rate proportional to _np_ . Accordingly, the PL intensity  TPL depends on the product _np_ of electron and hole concentrations. The time-resolved photoluminescence itself contains information about these entire recombination processes because the decrease in _n_ and _p_ results from the sum of all recombination processes. 

While the radiative recombination coefficient and the Auger coefficients are important material properties, the SRH lifetimes can vary substantially from sample to sample within a material system. This is because SRH lifetime depend on defect concentrations which may vary e.g. with processing 

4 

conditions. Hence, while the determination of all recombination coefficients is important for a material system, the SRH lifetimes are the key sample dependent property that might vary in a series of samples of the same material. Hence, TPL measurements on semiconducting materials would very often be done to extract the SRH lifetimes of individual samples. Given that the PL transient is affected by a several recombination mechanisms, it is necessary to briefly discuss how to extract the SRH lifetimes from the PL transients and to establish a common terminology that we use for the remainder of the article. 

The term charge-carrier lifetime in general describes the dependence of the electron or hole concentration as a function of time after the generation of electrons and holes (e.g. by a laser pulse) has stopped. Often, the characteristic decay time constant  mono of an exponential fit of the form  TPL = TPL ( 0 ) exp( − _t_  mono ) to TPL data is also called a ‘lifetime’. This lifetime concept is meaningful and suitable for a doped semiconductor film, crystal or wafer that is operated in low-level injection (less injected minority carriers than pre-existing majority carriers). In this case all recombination mechanisms stated in Equation 1 become linear in minority carrier concentration and a lifetime (often specifically called effective lifetime  eff ) could easily be defined as the decay time of minority carrier decay. I.e. if electrons are minority carriers their decay would be mono-exponential and follow =  _n n_ ( 0 ) exp( − _t_  eff ) no matter what recombination mechanism dominates<sup>[36]</sup> and its effective lifetime  eff is a constant, carrier concentration independent value (Supporting Information Table  II). 

Lead-halide perovskite films, however, are typically intrinsic enough that during a TPL experiment both types of carriers are present in roughly equal concentrations. In this situation, called high-level injection (HLI), both types of carriers have a finite lifetime. Let us assume for simplicity that electron and hole concentrations are exactly equal, i.e. _n_ = _p_ , to illustrate the difference between the timedependent decay time and a lifetime. In this case, the rate equation (Equation 1) can be simplified to 



<!-- Start of picture text -->
dn ( t ) = −( C n + C p ) n ( t ) 3 − k rad n ( t ) 2 − n ( t ) = − C Auger n ( t ) 3 − k rad n ( t ) 2 − n bulk ( t ) ,  (2)<br>dt ( n + p )  SRH<br><!-- End of picture text -->

which can be solved analytically. The respective result and solutions for further problems are listed in Table S1 in the Supporting Information. Here, we only want to have a look at the illustrated solutions being shown in **Figure 2** a. In high level injection, different recombination mechanisms will lead to differently shaped transient decays. Among the three typically studied bulk-recombination mechanisms (SRH, radiative and Auger) only SRH would lead to a mono-exponential decay. Hence, the situation where only SRH recombination occurs can be described by a single lifetime value that is given for _n_ = _p_ bulk by the sum  SRH = n +  p . The dotted lines in Figure 2a represent this case for three different SRH lifetimes, namely 100 ns (yellow), 500 ns (red) and 2 µs (blue). Both, Auger, and radiative recombination lead to faster initial decay, with a higher radiative recombination coefficient _k_ rad and higher Auger coefficients _C_ n and _C_ p enhancing the effect. As an example, the _k_ rad is varied in Figure 2b for the SRH lifetime of 2 µs. At longer times, the slope approaches the one from SRH- only scenario. 

5 



<!-- Start of picture text -->
 excess-charge carrier concentration  n  (cm-3)<br>1014 1015 1016 1017<br>100<br>(a) 2 µs (c) 2 µs (e)<br>10-1 10-6 time<br>500 ns<br>dotted: SRH only<br>10-2 solid: SRH+ radiative<br>dashed: SRH+ radiative + Auger<br>100 ns 100 ns<br>10-7<br>10-3<br>10-4<br>10-8<br>with Auger with Auger<br>100<br>solid: SRH+ radiative  2 µs (b) (d) 2 µs (f)<br>2 µs<br>10-1 10-6<br>vary  k rad<br>10-2 vary  k rad<br>10-7<br>10-3 vary  k rad<br>10-4<br>10-8<br>10-5<br>0.0 0.2 0.4 0.6 0.8 1.0 10-9 10-8 10-7 10-6 1.0 1.1 1.2 1.3 1.4 1.5<br>time  t  (µs) time  t  (s) Fermi-level splitting  E F (eV)<br>500 ns<br>2 µs<br>500 ns<br>10-10 cm/s3<br>5×10-11 cm/s3<br>5×10-10 cm/s3<br>5×10-11 cm/s3<br>100 ns<br>10-10 cm/s3<br>5×10-10 cm/s3<br>normalized TPL TPL<br>decay time  (s)TPL,HLI<br>normalized TPL TPL<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 2:** Illustration of the analytical solutions of the differential equations for high-level injection describing an undoped perovskite film on glass with passivated surface. (a-b) Normalized transient photoluminescence decays  TPL , starting from similar initial charge-carrier concentration, for (a) varying bulk SRH lifetimes with  SRH = n +  p equals 100 ns, 500 ns or 2 µs, and (b) varying radiative coefficients − 11 3 -1 − 10 3 -1 − 10 3 -1 _k_ rad = 5  10 cm s , 5  10 cm s or 10 cm s . Different scenarios are selected to differentiate the influence of the respective recombination mechanisms on the decay. (c-d) presents the decay time  TPL,HLI in HLI as a function of time _t_ or in (e-f) plotted versus quasi-Fermi-level splitting _∆E_ F which is 4 -3 linked to the excess-charge carrier concentration via Equation 4 using _n_ i = 8.05  10 cm .<sup>[13]</sup> 

Consequently, if any other recombination mechanism plays a role, the decay is no longer monoexponential and cannot be described by a single lifetime. Thus, we promote the use of a carrier-densitydependent decay time defined by 



<!-- Start of picture text -->
− 1<br> 1 d ln(  TPL ) <br> TPL =  −   (3)<br> m dt <br><!-- End of picture text -->

to interpret TPL decays, with the factor _m_ relating to the injection level ( _m_ = 1 for low-level injection (LLI), _m_ = 2 for high-level injection (HLI)). Figure 2c-d display  TPL,HLI , resulting from the analytical solution of the TPL decays in Figure 2a-b, versus time. Figure 2e-f presents these decay times as a function of the quasi-Fermi-level splitting _∆E_ F 



<!-- Start of picture text -->
  n 2 <br> E F = kT ln  2  .   (4)<br> n i <br><!-- End of picture text -->

Plotting the decay time  TPL versus _∆E_ F allows more easily distinguishing the influences of the individual processes because they typically differ in their dependence on carrier density (the different recombination mechanisms) or external voltage (electrode discharging), while they do not have a 

6 

fundamental time dependence. A similar method of representation – i.e. time constant vs. voltage – is also typically used for the analysis of transient photovoltage (TPV)<sup>[37-39]</sup> and open-circuit voltage decay (OCVD)<sup>[40-42]</sup> measurements. These measurements also allow deriving differential time decay that are however frequently denoted as “lifetimes” in the literature.<sup>[39, 41, 43, 44]</sup> Radiative and Auger recombination define the shape of the decay time at high Fermi-level splitting, i.e. directly after the laser pulse. The comparison of the analytical solution with and without Auger recombination illustrates that Auger recombination steepens the increase of  TPL . In all cases, the saturation of the decay time on the value of the SRH lifetime is clearly visible (Figure 2a, c-d). The choice of _m_ = 2 for _n_ = _p_ ensures that the decay time given by Equation 3 will saturate towards  TPL,HLI = n +  p for long times or low _∆E_ F. 



<!-- Start of picture text -->
100<br>(a) 1 nJ/cm2 (b) 1 nJ/cm2 100 nJ/cm2 (c)<br>10-6<br>10-1 1 nJ/cm2 1 µJ/cm2<br>100 nJ/cm2<br>100 nJ/cm2<br>10-2 1 µJ/cm2<br>1 µJ/cm2 10-7<br>10-3 n+p=1 µs<br>10 µJ/cm2 k rad=5×10-11 cm3/s<br>10-4 10-8 10 µJ/cm2<br>C Auger=4.4×10-29 cm6/s<br>0.5 1.0 1.5 2.0 10-9 10-8 10-7 10-6 10-5 0.8 1.0 1.2 1.4<br>time  t  (µs) time  t  (s) Fermi-level splitting  E F (eV)<br>10-5<br>100 (d) (e) (f)<br>770 nJ/cm²<br>85 nJ/cm²<br>10-1<br>10-6<br>85 nJ/cm²<br>10-2<br>770 nJ/cm² 770 nJ/cm²<br>10-3 10-7<br>85 nJ/cm²<br>10-4<br>11 µJ/cm² 11 µJ/cm² 11 µJ/cm²<br>10-8<br>0.0 0.5 1.0 1.5 2.0 10-9 10-8 10-7 10-6 1.2 1.3 1.4 1.5<br>time  t  (µs) time  t  (s) Fermi-level-splitting  E F (eV)<br>Figure 3:  (a-c) Simulated data (Sentaurus TCAD) of transient photoluminescence measurements of a<br>− 11 3 -1<br>CH3NH3PbI3 perovskite film with   n =  p = 500 ns  (  SRH,bulk = n +  p = 1 µs) ,  k rad = 5  10 cm s<br>− 29 6 -1<br>and  C n = C p = 4.4  10 cm s  for different laser excitation fluences (1 nJ/cm2, 100 nJ/cm2, 1 µJ/cm2,<br>10 µJ/cm2). (a) Normalized photoluminescence decays over time Sentaurus TCAD simulations on a<br>semi-logarithmic scale. For low laser fluences or later times the exponential decay caused by SRH<br>recombination ( R SRH ∝ Δ n ) dominates the decay. At higher laser fluences higher order recombination<br>mechanisms like radiative or Auger recombination dominate the decay. (b) Carrier-density-dependent<br>decay time   TPL,HLI  assuming high-level injection ( m =2) determined via Equation 3 versus time and (c)<br>versus Fermi-Level splitting. (d-f) Experimental data reused from ref. [13]  of transient photoluminescence<br>measurements of a CH3NH3PbI3 perovskite film on glass for different laser excitation fluences<br>(85 nJ/cm2, 770 nJ/cm2, 11 µJ/cm2). (d) shows the normalized photoluminescence decays over time<br>from measurements (open symbols). Solid lines represent global fits including radiative and trap-<br>assisted SRH and Auger recombination. (e) Decay time   TPL,HLI assuming HLI ( m =2) versus time and<br>(f) versus quasi Fermi-level splitting.<br>10 µJ/cm2<br>normalized TPL TPL decay time  (s)TPL,HLI<br>normalized TPL TPL decay time  (s)TPL,HLI<br>laser pulse<br><!-- End of picture text -->

7 

This new method of representation (  TPL vs. _∆E_ F) becomes even more important if TPL measurements at different excitation fluences are compared, because the photoexcited charge-carrier density critically influences which recombination type dominates the TPL decay. **Figure 3** presents a comparison of the simulated situation (a-c) and experimental data (d-f) of a perovskite film on glass but now for varying laser fluences. Again, the results are shown as normalized TPL decays and their decay times over time or Fermi-level-splitting. Figure 2b and e reveal that using the time as x-axis is not very informative, because  TPL,HLI at a specific delay time after the pulse can have very different values depending on the excitation energy. Only when one plots the  TPL,HLI versus Fermi level splitting, which depends on the charge-carrier concentration, the information merges and the curves complement each other. Finally, it should be noted that both the Sentaurus simulation and the analytical solution reflect the trend of the experimental data and are therefore well suited to describe a pure, passivated perovskite film on glass. 

### **2.2. Layer with surface recombination** 

TPL measurements on unpassivated perovskite films on glass are often used to characterize not only the bulk but also the surface. If the bulk properties of the perovskite are already known, this sample type can be used to extract the corresponding surface properties from the TPL measurement. In general, the rate of surface recombination may be limited either by the transport of charge carriers to the surface or by the surface recombination velocities _S_ n and _S_ p of electrons and holes at the interface itself. Due to the relatively low thickness of halide perovskite thin films (typically < 1µm) and the typically high mobilities ( _µ_ > 1cm²/Vs), the transport of electrons and holes to the surface can be considered fast compared to the rate of recombination at the surface,<sup>[13]</sup> which can be quite low relative to many other semiconductors. Therefore, we do not have to distinguish between the average carrier concentration in the bulk of the perovskite-thin film and the carrier concentrations at either of the surface. This finding implies that the rates of bulk and surface recombination can just be added up and it is not necessary to calculate the concentration of electrons and holes at the film surface. The surface recombination rate per unit area is given by 



<!-- Start of picture text -->
R surf = n Sn p p +− pn i2 S n  1 S p + n 1 S n (5)<br><!-- End of picture text -->

whereby the approximation sign is valid for _n_ = _p_ and _np_ >> _n_ i<sup>2</sup> . Equation 5 is essentially a modified SRH recombination rate, where all instances of lifetime are replaced by inverse surface recombination velocities _S_ n and _S_ p of electrons and holes. This implies that _R_ s is a rate per unit area and time rather than per unit volume and time as the SRH recombination rate in the bulk. If we additionally assume _S_ n = _S_ p = _S_ for simplicity, we have _R_ surf = _Sn_ /2. If we want to combine the surface recombination rate per unit area with the bulk recombination rates per volume and time, we have to either multiply all volume recombination rates with the thickness _d_ pero of the film or divide the surface recombination rate 

8 

_R_ surf by the thickness. Doing the latter, we could write the rate equation including surface recombination at one surface (the other being perfectly passivated) as 



<!-- Start of picture text -->
dn ( t ) = − k rad n ( t ) 2 − n bulk ( t ) − Sn ( t ) .   (6)<br>dt  SRH 2 d pero<br><!-- End of picture text -->

We note that in Equation 6, the bulk SRH term and the surface recombination term are both linear in electron concentration which suggests that we could use the concept of surface lifetime _τ_ surf and an effective SRH lifetime 



<!-- Start of picture text -->
eff  1 1 − 1  1 S − 1<br> SRH =  bulk + surf  =  bulk +  ,  (7)<br>  SRH  SRH    SRH 2 d pero <br><!-- End of picture text -->

which would allow us to rewrite Equation 7 to obtain 



<!-- Start of picture text -->
dn ( t ) = − k rad n ( t ) 2 − n bulk ( t ) − n surf ( t ) = − k rad n ( t ) 2 − n eff ( t ) (8)<br>dt  SRH  SRH  SRH<br><!-- End of picture text -->

Equation 8 has an analytical solution being listed in Table S1 in the Supporting Information. 



<!-- Start of picture text -->
100<br>(a) 10-6 0.01 cm/s (b) (c)<br>10 cm/s<br>10-1 vary  S 100 cm/s<br>10-7<br>10-2<br>1000 cm/s<br>vary  S<br>10-3<br>10-8<br>10000 cm/s<br>10-4  (1/bulkSRH+ S /2 d pero)-1<br>10-9 100000 cm/s TPL,HLI(1.1 eV)<br>10-5<br>10-9 10-8 10-7 10-6 0.8 1.0 1.2 1.4 10-1 101 103 105<br>time  t  (s) Fermi-level-splitting  E F (eV) surface recombination<br>velocity  S  (cm/s)<br>0.01 cm/s<br>100 cm/s<br>100000 cm/s 10000 cm/s 1000 cm/s 10 cm/s<br>normalized TPL TPL<br>decay time  (s)TPL,HLI<br>laser pulse<br><!-- End of picture text -->

**Figure 4:** (a) Simulated normalized photoluminescence decays  TPL versus time of a CH3NH3PbI3 perovskite film with a constant bulk SRH lifetime of  n =  p = 500 ns (  n +  p = 1 µs) and a varying surface recombination velocity _S_ (Sentaurus TCAD). A laser excitation fluences of 10 µJ/cm2 was used. Further simulation parameters are listed in Table S3. The higher the surface recombination velocities the faster is the TPL decay. (b) Decay time  TPL,HLI over Fermi-Level splitting  _E_ F calculated form the normalized TPL decays via Equation 3. Figure 4c represents the correlation of the effective decay time on the surface recombination velocity _S_ . The dotted line results from the analytical solution. The colored data points belonged to the saturated plateau values of  TPL,HLI at  _E_ F = 1.1 eV from the numerical simulation. 

To check whether the analytical description in Equation 7 is adequate, we have also simulated the corresponding structure of a perovskite film with one recombination-active surface numerically. The resulting PL transients and their decay times  TPL,HLI as a function of the quasi-Fermi-level splitting for various surface recombination velocities _S_ are summarized in **Figure 4** a and b. Faster surface recombination velocities _S_ lead to faster TPL decays and the saturation value of the decay time at low 

9 

Fermi-level-splitting decrease. These saturation values of  TPL,HLI match with the respective effective SRH lifetime _τ_ SRH,eff. How well numerical and analytical solutions match is confirmed by Figure 4c, in which the corresponding plateau values of  TPL,HLI are compared with the calculated values using Equation 7. We conclude that the numerical results from Sentaurus TCAD and the analytical description fit well and only deviate for particularly large _S_ . Therefore, the analytical model is suitable to analyse experimental TPL data of a perovskite film on glass with an unpassivated surface. The surface recombination velocity _S_ can then be extracted from the plateau value of the decay time if the SRH bulk lifetime is already known from a measurement of a passivated sample. 

### **3. Perovskite layer with charge extraction layer** 

Surface recombination is an important loss mechanism but usually the surface to ambient air is not of special interest. We are rather interested in the analysis of interfaces between the perovskite film and charge-extracting layers to evaluate and compare the quality of contact materials and assign recombination losses in the actual solar cell. There are a range of additional effects - not related to recombination - that will affect the shape of the TPL decay and that we will illustrate in the following using the example of a perovskite/PCBM bilayer. **Figure 5** a - d show band diagrams of a simulated TPL experiment on such a bilayer while Figures 5e - g show the TPL data at different fluences and the differential lifetime vs. time and vs. quasi-Fermi level splitting. 

After the laser pulse has hit the sample, the equilibrium Fermi level _E_ F splits up into quasi-Fermilevels _E_ Fp for holes and _E_ Fn for electrons (see Figure 5b) and charge is transferred to the PCBM, which is visible by the increase of the Fermi-level split inside the PCBM. Due to the reasonably low mobility of the PCBM ( _µ_ PCBM = 5×10<sup>-2</sup> cm²/Vs),<sup>[45]</sup> this increase is slower than in the perovskite and position dependent (compare Figure 5b with 5c). The injection of electrons into the PCBM leads to a reduction of the _np_ -product in the perovskite and thereby to a reduction in the PL at early times that is not caused by recombination. In Figure 5c) (35 ns after the pulse), the quasi-Fermi levels are flat throughout the sample, while the bands are bend close to the interface. This bending implies that high densities of electrons accumulate in the PCBM close to the interface. This accumulation requires high fluences and low interfacial recombination velocities to happen and it implies that quantitatively describing interfacial recombination is only possible by including the effect of Poisson’s equation in addition to the continuity equations for electrons and holes.<sup>[22]</sup> After the quasi-Fermi levels have equilibrated, recombination leads to a further reduction in PL. Depending on the properties of the bilayer, recombination may preferentially proceed (i) via interfacial recombination of electrons in the PCBM with holes in the perovskite, (ii) via re-injection of electrons from the PCBM into the perovskite and subsequent recombination in the perovskite. The first scenario is more likely if the interfacial recombination velocities are high and the conduction band offsets are large and the second scenario in the opposite case 

10 

(low recombination velocities and small offsets). In both cases, additional aspects like the thickness _d_ PCBM of the PCBM layer will affect the TPL decay. 



<!-- Start of picture text -->
100<br>perovskite    PCBM (e )<br>(a ) 10-1<br>0  ns E C<br>E F 10-2<br>0<br>10-3<br>E V<br>- 1 10-4<br>0.0 0.5 1.0 1.5 2.0<br>(b )<br>2  ns E Fn time  t  (µs)<br>0 0.1 nJ/cm2 (f )<br>E Fp 10-6<br>- 1<br>(c ) 10-7 1 µJ/cm2<br>3 5 ns<br>10 µJ/cm2<br>0 10-8<br>10-9 10-8 10-7 10-6 10-5<br>time  t  (s)<br>- 1 10-5<br>(g )<br>(d ) 10 µs<br>10-6<br>1 0 µs<br>0 n+p<br>10-7<br>35 ns<br>- 1 1 0 µJ/cm2<br>10-8<br>0 100 200 300<br>0.6 0.9 1.2 1.5<br>position  x  (nm)<br>Fermi-level splitting  E F (eV)<br>0.1 nJ/cm2<br>100 nJ/cm2<br>1 µJ/cm2<br>10 µJ/cm2<br>100 nJ/cm2<br>normalized TPL TPL<br>E  (eV)energy<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 5:** (a-d) Band diagrams of a perovskite film on glass with a charge-extracting PCBM layer on top before and at different time delays after the laser pulse excitation simulated with Sentaurus TCAD. (a) Equilibrium band diagram before the sample gets photoexcited. (b) shows the situations directly after the end of the laser pulse, when the quasi Fermi-level splitting in the perovskite is the highest but a negligible density of electrons has been transferred to the PCBM. In (c) substantial transfer of electrons to the PCBM has happened resulting in electron accumulation and band bending in the PCBM close to the perovskite/PCBM interface (35 ns). (d) after 10 µs this band bending has vanished again, and the Fermi-level splitting has visibly decreased. (e) normalized PL and (f) decay time over time for different laser fluences. In (g) the decay time  TPL,HLI for the highest fluence is shown again but here as a function of the average quasi-Fermi-level-splitting in the perovskite layer. The respective time steps for which the band diagrams are shown are highlighted. The SRH bulk lifetimes were set to  n +  p = 1 µs with  n =  p . The perovskite/PCBM junction is a type II heterojunction, the difference in electron affinity is 70 meV and the interface recombination velocity is set to _S_ = 0.01 cms-1 . Additional simulation parameters and are listed in Table S3 and a detailed description of the simulation implementation can be found in the Supporting Information. 

11 



<!-- Start of picture text -->
10-4<br>S PCBM = 50 cm/s (a ) 170 meV S PCBM = 0.01 cm/s<br>n + p = 1 µs  140 meV n + p = 1 µs<br>10-5<br>120 meV<br>220 meV<br>70 meV<br>40 meV<br>10-6<br>40 meV R<br>R vary energy offset<br>140 meV<br>c<br>10-7<br>vary energy offset c<br>220 meV (b)<br>10-5<br>(c ) S PCBM = 50 cm/s 150 nm S PCBM = 0.01 cm/s<br>100 nm<br>n + p = 1 µs 50 nm n + p = 1 µs<br>150 nm c = 150 meV 10 nm30 nm c = 70 meV<br>10-6<br>R R<br>30 nm 100 nm vary thickness<br>10 nm d PCBM<br>10-7<br>vary thickness<br>d PCBM<br>(d)<br>0.8 1.0 1.2 1.4 0.8 1.0 1.2 1.4<br>Fermi-level-splitting  E F (eV) Fermi-level-splitting  E F (eV)<br>120 meV<br>170 meV<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 6:** Decay time _τ_ diff,HLI versus Fermi-level splitting  _E_ F for the two scenarios, of (a, c) a high interfacial recombination velocity of _S_ PCBM = 50 cm/s at the perovskite/PCBM interface and (b, d) a negligible interfacial recombination velocity of _S_ PCBM = 0.01 cm/s. (a-b) shows a variation of the energy offset c of the conduction bands and its impact on the decay time for each scenario and (c-d) a variation of the PCBM layer thickness _d_ PCBM. The dotted, grey lines show the simulation result of the pure perovskite film where only the combination of the different recombination processes define the course of the decay time, named recombination lifetime _τ_ R (details see SI). A comparison allows us to distinguish between pure recombination processes and the impact of additional effects e.g. interfacial charging, reinjection, or diffusion limitation. Additional simulation parameter can be found in Table S3 in the Supporting Information. 

Based on **Figure 6** a and b we explain the impact of the conduction band offset c (40 meV220 meV), which is defined by the difference in electron affinity c PCBM of the PCBM and the perovskite c pero , for the two scenarios. In this example the thickness _d_ PCBM of the PCBM is set to 50 nm like in Figure 5. In Figure 6c-d the impact of a thickness change of the PCBM layer is illustrated. First, we discuss scenario (i) by showing decay times calculated for a non-negligible interface recombination velocity of _S_ = 50 cm/s. We observe for all the different band offsets c differently pronounced S- shaped curves. After the fast decay times at high  _E_ F due to charge transfer to the PCBM as well as the 

12 

normal radiative and Auger recombination in the bulk, we observe an initial plateau of  TPL,HLI between around 1.2 and 1.4 eV quasi-Fermi level splitting. For even lower  _E_ F,  TPL,HLI saturates at a second plateau. We observe that the first plateau nearly disappears for small offsets and is particularly pronounced in the opposite case. At an offset of 40 meV (grey line) the shape of the decay time approaches the simple case of an unpassivated perovskite film, when no additional effects besides recombination define the decay time (recombination lifetime _τ_ R). The explanation for the first plateau is the effect of charge accumulation in the PCBM close to the interface. This effect reduces  TPL,HLI relative to longer times, where charge accumulation has been reduced to a point where all bands and Fermi levels are flat (see Figure 5d). The effect of charge accumulation gets more severe for higher band offsets, because the misalignment of the conduction bands leads to larger electron densities in the PCBM and reduces the rate of re-injection into the perovskite. 

In addition, the thickness of the PCBM layer is varied between 10 – 150 nm for a medium-large energy offset of 150 meV. The respective decay times  TPL,HLI , being presented in Figure 6c in different shades of purple with lighter colors representing thinner layers, point out that the first plateau gets more pronounced for thicker PCBM layers. Higher PCBM thickness also allows more impact of band bending, because of electrostatic arguments. For a given charge-carrier density, any change in electrostatic potential of _k_ B _T_ / _q_ will occur over one Debye length, where _k_ B is the Boltzmann constant, _T_ the temperature and _q_ the elementary charge. Hence, thicker layers will allow a larger change in electrostatic potential over the PCBM and therefore stronger band bending. The saturation value of  TPL,HLI (second plateau) at long times and small  _E_ F is also strongly affected by PCBM thickness. At longer times, recombination will be limited by the time the electrons take to diffuse through part of the PCBM layer before they can recombine at the interface. This effect leads to longer  TPL,HLI at small  _E_ F. 

Figure 6b shows the case, where interfacial recombination is negligibly small and the decay at longer times must be due to re-injection of electrons into the perovskite absorber layer (scenario (ii)). Now,  TPL,HLI at longer times or small  _E_ F can substantially exceed the bulk SRH lifetime of 1 µs. This is because electrons are injected into the PCBM and cannot escape from there other than by re-injection over a barrier of a certain height. This re-injection process is the rate limiting step at longer times and therefore leads to prolonged decay times at small  _E_ F. Again, PCBM thickness has the same effect as before for the saturation value of the decay time. Larger thicknesses lead to longer  TPL,HLI due to the diffusion time through the PCBM (Figure 6d). 

The effect of band bending, and thus charge-carrier dynamics in a perovskite layer in contact with a charge extraction layer cannot easily be described by an analytical solution anymore. Just for thin charge-extracting layers with small energy offset, it is still reasonable to use the saturation value of the decay time  TPL,HLI at small ∆ _E_ F as effective lifetime and use Equation 7 (section 2.2) for estimating interface recombination velocities and bulk SRH lifetimes. Only then does the decay time roughly 

13 

correspond to the pure recombination lifetime  R . When interpreting data from TPL measurements on samples with thick transport layers or those with high band offsets, the presented effects, and their impact on the decay time  TPL,HLI cannot be ignored. Otherwise one assigns interface and the bulk lifetimes, which can differ by orders of magnitude from the actual one. 

### **4. Perovskite layer with charge extraction layer and electrode** 

In the previous section, we have discussed the relevant case of a type II heterojunction between the perovskite and a charge-transport layer – in this case the ETL. Similar simulations could of course be done for hole transport layers that form a type II interface with the perovskite. Two aspects are however missing in section 3 that may appear in practice. One is the case where type I heterojunction is formed, and the second aspect is that an electrode (anode or cathode) may be present in addition to the ETL or HTL. In this section we are combining these two issues and simulate the layer stack glass/ITO/PTAA/perovskite. UPS measurements suggest that PTAA may have a negligible valence band offset to MAPI at least for the samples prepared with the recipe presented in ref.<sup>[46]</sup> . As in the previous section, we first have a look at the corresponding band diagram in equilibrium and at different delay times after laser pulse excitation being represented in **Figure 7** a-d. When comparing the equilibrium-band diagrams of Figure 5a and 7a, it is directly apparent that the equilibrium Fermi-level _E_ F is no longer roughly in the middle of the perovskite band gap but is rather pinned by the ITO contact. When different layers are brought into contact charge-carrier injection from layers with higher electron (or hole concentration) into layers with lower concentrations occurs. Because ITO is much more conductive than PTAA and perovskite, the work function of the ITO sets the position of the Fermi level in the layer stack and holes are transferred into the PTAA and the perovskite. Therefore, the Fermi-level in the perovskite is much closer to the valence band edge _E_ V than to the conduction band edge _E_ C, which implies that the equilibrium hole concentration _p_ 0 is substantially higher than _n_ i. Thus, the situation is comparable to the one in a doped semiconductor even though the perovskite itself is assumed to be perfectly intrinsic. 

This behavior caused by the ITO contact leads to a transition between high- and low- level injection during the TPL measurement. Directly after (Figure 7b) up to 3.93 µs after the laser pulse excitation (Figure 7c) roughly equal densities of electrons and holes are present in the perovskite ( _n_ = _p_ , HLI), whereas for later times the density of electrons becomes much smaller compared to the one of holes ( _p_ >> _n_ , LLI) (see Figure 7d and Supporting Figure S10). Then the position _E_ Fp relative to the valence band _E_ V is approximately constant and the quasi-Fermi level splitting is reduced by a _E_ Fn moving towards _E_ Fp. This change of injection level also has an impact on the recombination rates. Since the ratio of electrons and holes is not constant and also not explicitly known, it is no longer possible to simplify the differential equation in Equation 1 for high- or low-level injection (e.g.: _n_ = _p_ or _p_ >> _n_ ). 

14 



<!-- Start of picture text -->
 ITO   PTAA   perovskite 10 0<br>(e )<br>(a )<br>0  ns E C 10 -1<br>1 10 -2<br>10 -3<br>E F E V<br>0 10 -4<br>10 -5<br>2 ns E C (b ) 0.0 0.5 1.0 1.5 2.0<br>time  t  (µs)<br>E Fn<br>1<br>(f )<br>0.1 nJ/cm 2<br>10 -6<br>0 E Fp E V<br>3. 93 µs E C (c ) 10 -7<br>1 E Fn<br>10 -8<br>10 -9 10 -8 10 -7 10 -6 10 -5<br>0 E Fp time  t  (s)<br>E V (g )<br>9. 92 µs E C (d ) 10 -6 9.92 µs 3.93 µs<br>1<br>E Fn<br>10 -7<br>E Fp E V<br>0 1 0 µJ/cm 2<br>10 -8<br>0 100 200 300 400 1.0 1.2 1.4<br>position  x  (nm) Fermi-level splitting  E F (eV)<br>100 nJ/cm2<br>1 µJ/cm2<br>1 µJ/cm2<br>10 µJ/cm2<br>100 nJ/cm2<br>0.1 nJ/cm2<br>10 µJ/cm2<br>normalized TPL TPL<br>laser pulse<br>E  (eV) energy<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 7:** (a-d) Simulated band diagrams of a glass/ITO/PTAA/perovskite layer stack at different time delays before and after the laser pulses. These times are (a) before the laser pulse, (b) directly after the end of the laser pulse, (c) at a delay of 3.93 µs when substantial transfer of holes to the PTAA has happened, the quasi-Fermi-level for holes _E_ Fp is flat and the perovskite is still in high-level injection and finally (d) after 9.92 µs. Then, the position _E_ Fp relative to the valence band _E_ V is approximately constant and the Fermi level splitting is reduced by a change of _E_ Fn. The concentration of electrons in the perovskite is much lower than the one for holes, corresponding to low-level injection. (e) Normalized PL transients and (f) decay time over time for different laser fluences. In (g) the decay time _τ_ diff,HLI for the highest fluence is shown again but here as a function of the average quasi-Fermi-level-splitting in the perovskite layer. The respective time steps for which the band diagrams are shown are highlighted. The perovskite/PTAA junction is a type I heterojunction and the interface recombination velocity are -1 set to _S_ n = _S_ p = 0.01 cms . The SRH bulk lifetimes were set asymmetric to = n 500 ns and = p 2 µs enabling us to see the transition for HLI to LLI. Additional simulation parameters are listed in Table S3 in the Supporting Information. 

15 

This lack of information complicates the interpretation of the decay time in terms of bulk or surface lifetimes. In order to better see the transition from HLI to LLI, we use asymmetric SRH lifetimes in Figure 7 which are set to  n = 500 ns and = p 2 µs . In high-level injection ( _n_ ≈ _p_ ) the lifetime from SRH recombination is given by  n +  p=2.5 µs. At lower Fermi-level splitting (LLI), the situation in this example can be described in a simplified manner by the rate equation 



<!-- Start of picture text -->
dn ( t ) n ( t )<br>= − (9)<br>dt  n<br><!-- End of picture text -->

with the solution =  _n n_ ( 0 ) exp( − _t_  n ) . With _p_ being approximately constant and fixed by the ITO work function, the photoluminescence flux will be proportional only to the minority carrier density, i.e.  TPL  _n_ . Thus, the decay time given by Equation 3 will give 2  n = 1 µs , with the factor 2 originating from the choice _m_ = 2 in Equation 3 that we use throughout the paper. We observe this transition from ~  n +  p to ~2  n when looking at the decay time curve vs. Fermi-level splitting (Figure 7g). A deviation from the value  TPL,HLI =  n +  p occurs because the transition from higher order recombination (radiative and Auger) to SRH recombination is not yet complete when the transition to LLI begins (indicated by the gray lines). In **Figure 8a** these findings are summarized by comparing the decay times for different ratios of electron and hole bulk lifetimes to highlight the transition from HLI to LLI. The dotted lines are a guide to the eye and mark the respective lifetime values of ~  n +  p (red) and 2  n (blue). The dotted white lines show the simulations scenarios where only SRH or only radiative recombination is active. Note that these transitions from high- to low level injection that may occur due to doping of the absorber or Fermi-level pinning due to the (low or high) work function of a contact layer, create a dilemma for the definition of the decay time. We can either chose _m_ = 1 or _m_ = 2. No matter what we chose, it will affect the translation between decay time and lifetime in either of the two regimes. 

Figure 8b shows the corresponding situation for the case, where interface recombination at the perovskite/PTAA becomes relevant. Here, we fix the bulk SRH lifetime at  n =500 ns  and  p = 1 µs as well as the interface recombination velocity for electrons at _S_ n =10<sup>3</sup> cm/s and vary the interface recombination velocity _S_ p for holes. Here, we also see a change of the decay time  TPL,HLI at a Fermilevel splitting of  _E_ F of around 1.2 eV due to the transition from high- to low-level injection. In HLI both interface recombination velocities _S_ n and _S_ p are relevant for the recombination rate, whereas in LLI only _S_ n plays are role. Thus, at very low Fermi-level energies, the three curves converge to the same decay time value. Since the bulk lifetimes are high the interface recombination is the dominant nonradiative process and  diff,HLI should saturate to ~ 2dpero/ _S_ n=56 ns but the actual value is almost twice as high. In addition, we would not expect to see any transition for the case of symmetrically chosen lifetimes  n =  p and surface recombination velocities _S_ n = _S_ p. The reason why this decay time at very low Fermi-level splitting differs, is the influence of space charge. In low-level injection, the high work 

16 

function of the ITO leads to the creation of positive charge due to free holes inside the PTAA and the perovskite that is counterbalanced by negative charge at the ITO surface. This positive charge in the perovskite leads to band bending and therefore a slightly higher concentration of holes and thereby lower concentration of electrons at the PTAA/perovskite interface as compared to the bulk of the perovskite. At the PTAA/perovskite interface, electrons are the minority carriers in low-level injection and hence the reduction of electron concentration leads to a slight increase in the decay time in low-level injection relative to high-level injection (see Supporting Figure S10). 



<!-- Start of picture text -->
(a ) LLI  p =2 µs  HLI<br>p=1 µs<br> n =500 ns<br>10-6<br> p =500 ns<br>p=100 ns<br>vary p<br>~2n<br>~n+p<br>10-7<br>S n= S p=0.01 cm/s<br>(b ) LLI HLI<br>S p=102 cm/s<br>S n=103 cm/s<br>10-7<br>S p=103 cm/s<br>vary  S p S p=104 cm/s<br>10-8<br>0.9 1.0 1.1 1.2 1.3 1.4 1.5<br>Fermi-level-splitting  E F (eV)<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 8:** Decay times vs. Fermi-level splitting resulting from drift-diffusion simulation with Sentaurus TCAD of transient PL of glass/ITO/PTAA/perovskite stack. (a) Variation of the SRH bulk lifetime for holes _τ_ p from 100 ns (red) to 2 µs (green) at a constant electron lifetime _τ_ n=500 ns, while the interface recombination velocity is negligibly slow ( _S_ n = _S_ p= 0.01 cm/s). (b) Variation of the interface recombination velocity _S_ p for holes at a constant bulk lifetime and recombination velocity for electrons of _S_ n=1000 cm/s. Both changes translate into observable changes in the decay time and illustrate the transition for high- to low level injection. Additional simulation parameters are listed in Table S3 in the Supporting Information. 

17 

### **5. Complete device stack** 

In case of the TPL of complete perovskite solar cells, the charging and discharging of the device electrodes adds an additional effect modifying the shape of the TPL decay. The mathematical problem can still be approximately described by an ordinary differential equation in time without any spatial dependences. This differential equation (neglecting Auger recombination for simplicity) could be written as 



<!-- Start of picture text -->
dn ( t ) = − k rad n ( t ) 2 − n eff ( t ) − C area dV ( t ) ,   (10)<br>dt  SRH qd pero dt<br><!-- End of picture text -->

where _C_ area is the area-related capacitance in F/cm² and _V_ the voltage between the electrodes. If we assume that the electron and hole densities scale with voltage as _n_ ( _t_ ) = _p_ ( _t_ ) = _n_ i exp ( _qV_ ( _t_ ) 2 _k_ B _T_ ) , we can solve Equation 10 analytically. The effect of the last term in Equation 10 is to take into account that electrons will diffuse from the perovskite through the ETL to the cathode (Ag) and holes through the HTL to the anode (ITO) and change the surface-charge density on cathode and anode until the external voltage _V_ ext =  _E_ F,ext _q_ and the internal quasi-Fermi splitting  _E_ F,int = _qV_ int have equilibrated and no further current is flowing. At longer times, the electrons and holes may flow back from the electrodes through the ETL and HTL to the perovskite leading to long  TPL,HLI limited by the electrode capacitance and the differential resistance of the solar cell. The decay time  TPL,HLI at low  _E_ F is an _RC_ time constant with the _C_ being formed by the electrode capacitance and the _R_ being determined by the recombination resistance of the solar cell that increases exponentially towards smaller voltages as predicted by the diode equation. Hence,  TPL,HLI is also increasing exponentially towards smaller  _E_ F as previously observed for large and small signal _V_ oc decays.<sup>[40, 41, 43, 44]</sup> 

To illustrate the effects occurring in complete devices, **Figure 9** a - f presents the band diagrams simulated, using the full differential equations which include charge transport, at different delay times during a TPL measurement. Figure 9b depicts the band diagram directly after the pulse has hit the sample showing a substantial internal quasi-Fermi level splitting in the perovskite layer while the external voltage is still zero (see the Fermi levels in the ITO relative to the one in the Ag in Figure 9b). Figure 9c pictures the situation 5 ns after the pulse. At this stage, the quasi-Fermi levels are substantially split in the perovskite and also an external voltage has now been built up. However, there is still a substantial difference between the quasi-Fermi level splitting inside the perovskite absorber and the external quasiFermi splitting  _E_ F,ext = _qV_ ext . Furthermore, there are large gradients _dE_ Fn _dx_ and _dE_ Fp _dx_ in the quasi-Fermi levels inside the electron and hole transport materials. These gradients are necessary to drive the electron- _J_ n = _n_  n _dE_ Fn _dx_ and hole-current density _J_ p = _n_  p _dE_ Fp _dx_ that have to flow from the absorber to the contacts to change the amount of charge stored on the electrodes. Hence, the average internal voltage is still substantially higher than the external voltage. 

18 



<!-- Start of picture text -->
 ITO   PTAA   perovskite  PCBM  Ag 100<br>a) 0 ns ( g)<br>1 10-1 laser fluence<br>E C<br>0 10-2 10 nJ/cm2<br>E F<br>-1 E V 10-3<br>(b)<br>1 ns E C 10-4<br>1<br>E Fn<br>V int 10-5<br>0 E Fp 10-9 10-8 10-7 10-6 10-5 10-4<br>1.06 V<br>time  t  (s)<br>-1 E V<br>internal voltage V int ( h)<br>1.5<br>(c) 5 ns<br>1 5  ns 1  ns 234 ns 4.1 µs<br>E C 1.0<br>external<br>0 V ext E Fn<br>V int voltage V ext<br>0.82 V<br>0.5<br>1.46 V<br>-1 E Fp<br>E V 10 µJ/c m 2<br>-2 0.0<br>(d) 1 2 34 ns 10-5 10 µJ/cm2 ( i)<br>E C external decay time<br>0  V ext<br>V ext E Fn V int 10-6 4.1 µs<br>-1 1 .42 V 1.42 V<br>E Fp 234 ns<br>10-7<br>-2 E V 5 ns tr-PL differential<br>(e) decay time diff,TPL<br>1 4 .1 µs 10-8<br>E C 10-9 10-8 10-7 10-6 10-5 10-4<br>0 time  t  (s)<br>E Fn<br>10-4<br>-1 E Fp ( j)<br>E V 10-5<br>-2  V ext<br>(f)<br>1 1 0 ms 4.1 µs  n +  p<br>E C 10-6<br>0<br>E Fn 234 ns<br>E Fp 10-7<br>-1 diff,HLI<br>E V 1 0 µJ/cm2 5 ns<br>-2 10-8<br>1.0 1.1 1.2 1.3 1.4 1.5<br>0 200 400 600<br>position  x  (nm) Fermi-level splitting  E F (eV)<br>100 nJ/cm2<br>10 µJ/cm2 1 µJ/cm2<br>laser pulse<br>laser pulse<br>normalized transient PL TPL<br>voltage  V  (V)<br>E  (eV) energy<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 9:** Numerical simulations results of a TPL experiment on a complete solar cell stack. (a-f) band diagrams of the glass/ITO/PTAA/perovskite/PCBM/Ag stack for different time delays. (g) normalized TPL transients for different laser fluences. (h) illustrates how the externally measurable voltage _V_ ext between the contacts needs time to build up while the Fermi-level-splitting  _E_ F,int = _qV_ int inside the cell is already present. (i) shows the decay time  TPL,HLI as a function of time and (j) versus the Fermi-level splitting for the highest excitation fluence of 10 µJ/cm<sup>2</sup> . As an illustration, we picked a cell that has good interface properties and a long bulk life. The entire simulation parameters can be found in Table S3 in the Supporting Information. 

19 

Figure 9d shows the situation, where the quasi-Fermi levels have equilibrated. Now the gradients _dE_ Fn _dx_ and _dE_ Fp _dx_ are nearly zero indicating that there is very little current flow to or from the electrodes. The internal and external voltage are equal, and both will decay over time in the same way. If we simulate the photoluminescence transients for the device geometry presented in Figure 9a-f, we observe a strong dependence of the decay curve on the pulse fluence of the laser. Figure 9g shows the decays normalized to their maximum. For the low pulse fluence of 10 nJ/cm<sup>2</sup> , the PL decays quickly directly after the laser pulse has hit sample. In this case, nearly all electrons and holes generated by the laser pulse are necessary to change the amount of charge on the device electrodes for a sufficient external voltage to build up. If, however, the pulse energy is higher, no abrupt fast decay at early times is visible because only a small fraction of photogenerated electrons and holes are needed to build up the external voltage. However, the initial decay is still not monoexponential because Auger- and radiative recombination in the absorber will now matter at early times. The combination of these effects leads to a difficult to interpret situation, where fast decays at early times are visible for very low and very high pulse energies, however, for completely different reasons. Figure 9h summarizes the charging and discharging of the capacitance of the solar cell by showing how external and internal voltage change with time, which we explained before using the band diagrams. In Figure 9i-j we present the decay time versus time or Fermi-level splitting. For the complete solar cell device stack, the decay time  TPL,HLI vs. ∆ _E_ F consists of three regions, which will be discussed in the following. 

It is still possible to derive an analytical relation describing the transient if we assume high-level injection, include radiative recombination, SRH recombination and discharging of a constant capacitance. In this case, the solution of Equation 10 has to be expressed as time as a function of the Fermi-level splitting via 



<!-- Start of picture text -->
eff<br>t =  1 − mk B T C area k rad  SRHeff  SRHeff ln  n ( 0 ) + n ( t ) n ( 0 ) k rad  SRHeff <br> q qd   n ( t ) + n ( t ) n ( 0 ) k rad  SRH <br>(11)<br>+ mk B T C area  exp  −  E F ( t )  − exp  −  E F ( 0 ) <br>q J 0   mk B T   mk B T <br><!-- End of picture text -->

eff where _J_ 0 = _qd_ pero _n_ i  SRH , _n_ ( _t_ ) = _n_ i exp ( _E_ F ( _t_ ) _mk_ B _T_ ) and _n_ ( 0 ) equals the initial charge-carrier density due to the generation of the laser pulse excitation. While we are not aware that Equation 11 has been previously presented in the literature, similar equations neglecting radiative recombination have been derived and used in the context of analysing OCVD decays, where the equation was used to derive a time dependent open-circuit voltage and subsequently a differential time constant of a large signal _V_ oc decay.<sup>[40, 41, 43]</sup> 

20 



<!-- Start of picture text -->
100<br>(a) (b) (c)<br>10-1 vary  k rad 10-5<br>10-2<br>10-6<br>10-3<br>10-7<br>10-4 100 ns<br>vary  C area<br>vary  k rad<br>10-5 10-8<br>0.0 0.2 0.4 0.6 0.8 1.0 1.0 1.1 1.2 1.3 1.4 1.5 1.0 1.1 1.2 1.3 1.4 1.5<br>time  t  (µs) Fermi-level splitting  E F (eV) Fermi-level splitting  E F (eV)<br>Figure 10:  Illustration of (a) transient photoluminescence decays and (b-c) the decay time over Fermi-<br>level splitting calculated from the analytical solution of the simplified differential equation in<br>Equation 11 for the case of high-level injection and neglected Auger recombination, which can be used<br>to demonstrate the charge-carrier dynamics in a perovskite solar cell. (a-b) Results for varying SRH bulk<br>bulk<br>lifetimes   SRH = n + p , namely 100 ns (yellow), 500 ns (red) and 2 µs (blue) are shown, as well as the<br>− 10 3 -1 − 10 3 -1 − 11 3 -1<br>effect due to changes of the radiative coefficients (1  10 cm s , 5  10 cm s , 5  10 cm s ). (c)<br>variation and the capacitance (5 nF/cm 2 , 50 nF/cm2, 200 nF/cm 2 ) and its impact on the shape of the<br>decay time at low ∆ E F. The discharging of the capacitances prolongs the decay time.<br>100 ns<br>2 µs<br>500 ns<br>500 ns 5 nF/cm2<br>5×10-11 cm3/s 2 µs<br>10-10 cm3/s 50 nF/cm2<br>200 nF/cm2<br>10-10 cm/s3<br>5×10-11 cm/s3<br>100 ns 5×10-10 cm/s3<br>5×10-10 cm/s3<br>decay time  (s)TPL,HLI<br>normalized transient PL TPL<br><!-- End of picture text -->

**Figure 10** illustrates Equation 11, whereby panel (a) shows the normalized TPL decays and bulk panel (b) their decay times  TPL,HLI for three different SRH bulk lifetimes  SRH = n + p , respectively 100 ns (yellow), 500 ns (red) and 2 µs (blue). Furthermore, the external radiative recombination coefficient _k_ rad is varied for the SRH lifetime of 2 µs and the capacitance _C_ area in calculations with bulk  SRH = 100 ns . With shorter SRH lifetimes and higher radiative coefficients, the PL transients show a faster decay, however, one can hardly note any systematic differences compared to the case of perovskite on glass (Figure 2a)). This picture changes when considering the decay times  TPL,HLI as a function of quasi-Fermi-level splitting in Figures 10b and c. In this case, three different regions appear in the decay time curve as was the case in Figure 9j. At early times and high Fermi-level-splitting, we observe a charge-carrier dependent lifetime that is indicative of radiative recombination, which is already familiar to us. At slightly longer times and lower Fermi-level-splitting  TPL,HLI reaches a plateau and becomes bulk approximately constant at a value  SRH = n + p . But instead of staying on or near this plateau as usual, the decay times for even smaller Fermi level splitting increase even further. This SRH dominated regime transitions into the exponentially voltage-dependent regime controlled by the ratio _C_ area/ _J_ 0. Here, chargecarrier recombination is limited by discharging of the electrodes. Thus, the decay time  TPL,HLI at small ∆ _E_ F is higher for higher capacitances, demonstrated by the yellow curves. The purpose of transient photoluminescence measurements is to determine recombination parameters in finished devices. Thus, the region at low times and medium to high ∆ _E_ F is the relevant region that one would like to assess and use for extraction of bulk lifetimes, surface recombination velocities and radiative recombination coefficients. This implies that the initial value ∆ _E_ F(0) of the Fermi-level splitting and hence also the 

21 

charge-carrier concentration _n_ (0) has to be high enough to observe the relevant range. Moreover, the different regimes can also merge into one another, so that a clear separation is no longer possible. This overlap occurs e.g. for a combination of high radiative recombination coefficients and high bulk lifetimes. Then the decay time  TPL,HLI is radiatively limited. The corresponding case is illustrated by the − 10 3 -1 blue curves belonging to a SRH bulk lifetime of 2 µs. For _k_ rad = 10 cm s the plateau of  TPL,HLI is fully gone, and the decay time runs almost straight. At this point, it is no longer possible to determine whether there is a limitation due to capacitive effects or due to fast radiative recombination. This means that the determination of the recombination processes becomes particularly difficult for very good devices with long SRH lifetimes. 



<!-- Start of picture text -->
(a) 40 µs<br>10-6<br>1 µs<br>400 ns<br>200 ns<br>10-7<br>100 ns<br>vary n + p<br>S PTAA =  S PCBM = 0.01 cm/s<br>10-8<br>1.1 1.2 1.3 1.4 1.5<br>Fermi-level splitting  E F (eV)<br>(b ) 0.01 cm/s<br>1 cm/s n + p= 20 µs<br>10-6 10 cm/s<br>100 cm/s<br>10-7<br>vary  S PCBM 200 cm/s<br>1000 cm/s<br>10-8<br>1.1 1.2 1.3 1.4 1.5<br>Fermi-level splitting  E F (eV)<br>4 µs<br>2 µs<br>20 µs<br>decay time  (s)TPL,HLI<br> (s)decay time TPL,HLI<br><!-- End of picture text -->

**Figure 11:** Decay times  TPL,HLI vs. Fermi-level splitting resulting from numerical simulations of a transient PL of solar cell stack using Sentaurus TCAD. (a) Simulation series where the SRH bulk lifetime is varied from 100 ns (yellow) to 40 µs (grey), while the interface recombination velocities are low ( _S_ = 0.01 cm/s) for both absorber-transport layer interfaces. In b) the opposite case is presented, where _τ_ n + _τ_ p = 20 µs is kept constant and the interface recombination velocity _S_ PCBM of perovskite/PCBM is varied. Both changes translate into observable changes in the decay time. Additional simulation parameters are listed in Table S3 in the Supporting Information. 

22 

With **Figure 11** we confirm that the trend of the analytical relation can also be obtained in numerical simulations of a solar cell. In Figure 11a a variation of the SRH bulk lifetime (100 ns-40 µs) is illustrated. In this example, the interfaces between the perovskite absorber and the charge-extracting layers are nearly ideal (low _S_ , no or small band offsets) and similar to the simulation parameters used in Figure 9 (see Table S3 in the Supporting Information). Here again, the SRH bulk lifetime correlates with the value of the decay time  TPL,HLI near the inflection point of the curve and also the radiative limitation for high _τ_ n + _τ_ p becomes apparent. A direct comparison of the analytical and numerical solution can be found in Figure S14 in the Supporting Information. Figure 11b deals with the case of varying interfacerecombination velocities _S_ PCBM on the perovskite/PCBM side, while the SRH bulk lifetime is high, namely _τ_ n + _τ_ p = 20 µs. For higher _S_ PCBM the decay time in the middle region around 1.2 to 1.4 eV drops. 



<!-- Start of picture text -->
10-5<br>solar cell<br>unpassivated MAPI<br>S PCBM=0.01cm/s<br>10-6 S =50 cm/s<br>passivated MAPI<br>MAPI/PCBM<br>S PCBM=50 cm/s<br>10-7<br>1.0 1.1 1.2 1.3 1.4 1.5<br>Fermi-level splitting  E F (eV)<br>decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 12:** Summary of the fundamentally different effects that modify the decay time in different sample geometries. Bulk recombination (radiative and SRH) is the sole factor influencing the decay in a passivated perovskite layer (solid gray line)– the simplest possible sample geometry discussed here. In the presence of surface recombination (dot-dashed dark grey line) the decay time  TPL,HLI at low  _E_ F is reduced. In case of a perovskite/ETL bilayer (blue curves), the shape of the decay time is fundamentally changed due to effects such as interface charging (dash-dotted blue line) and electron reinjection (solid blue line) from the ETL into the perovskite. In addition to interfacial charging, we also observe electrode charging and discharging if we analyze complete devices (red line). In this case, we observe an exponential increase of  TPL,HLI towards lower values of  _E_ F. 

Finally, **Figure 12** shows a summary of some exemplary effects observed so far in the simulations and how they affect the charge-density-dependent decay time. The simplest case of a passivated perovskite film on glass (solid grey curve) shows fast radiative recombination at high  _E_ F and the bulk 

23 

lifetime of SRH recombination at low  _E_ F. For less well passivated surfaces, the  TPL,HLI -curve is essentially only shifted to lower decay times at lower values of  _E_ F (dot-dashed grey curve). An additional dip is observed for absorber-charge transfer layer combinations (dot-dashed blue curve). Here, interface charging and Coulomb induced charge accumulation at the MAPI/PCBM interface lead to increased interface recombination and decay times  TPL,HLI that are reduced relative to the case of a MAPI layer with the same surface recombination velocity but without the PCBM layer attached. For perovskite/ETL bilayers with substantial conduction-band offset but recombination inactive interface, we would observe additional effects due to electron re-injection into the perovskite. This re-injection depends on the energetic barrier at the perovskite/ETL interface and leads to  TPL,HLI that can substantially exceed the bulk SRH lifetimes of the perovskite itself (solid blue line). Finally, we can also charge and discharge the electrode capacitance of a complete perovskite solar cell (solid red line). At open circuit, the capacitor can only discharge via recombination in the absorber layer or at its interfaces. Since the recombination resistance of the solar cell increases exponentially towards lower voltages, the decay time associated with electrode discharging also increases exponentially. 

### **6. Comparison to experimental data** 

Finally, we want to apply and transfer our findings from the simulations to experimental data. **Figure 13** shows experimental data obtained from photoluminescence measurements for two sample series each featuring different multilayer stacks from the film on glass to the complete device. One sample series is based on solution-processed MAPI (left side), while the second sample series uses coevaporated MAPI (CH3NH3PbI3) as absorber material (right side). The used stacks for the full devices are glass/ITO/PTAA/MAPI/ETL/BCP/Ag, where ETL is PCBM for the cell with solution-processed MAPI and C60 for the cell with coevaporated MAPI. Note that the open-circuit voltages of the two solar cells are substantially different despite the fact that the stack and the materials are nearly identical. The coevaporated, inverted, planar MAPI solar cell has an open-circuit voltage _V_ oc of only 1.05 V while the solution-processed MAPI solar cell has a very high open-circuit voltage of 1.25 V (see Supporting Figure S18). The sample series, we show, always include a sample (glass/MAPI/TOPO) that should be well passivated. The molecule n-trioctylphosphine oxide (TOPO) has been shown to strongly reduce surface recombination velocities.<sup>[26, 27]</sup> In addition, the sample series include one sample with the hole transport layer PTAA (glass/PTAA/MAPI/TOPO) that serves to characterize recombination losses at the PTAA/MAPI interface. Finally, the complete cells are included which feature in addition the MAPI/ETL interface as an additional source of recombination. Figure 13a and b compare the normalized transient PL intensities _ϕ_ TPL and (c-d) the respective decay times  TPL,HLI vs. ∆ _E_ F for the two sample series described above. Each data set results from stitching several measurements recorded with a gated CCD camera starting at different delay times after the laser pulse and using different gains and integration times. This approach enables a very high dynamic range of up to 7 orders of magnitude that 

24 

is necessary to observe the wide range of physical phenomena discussed in the simulation sections of this paper. Typical combined measurement times were several hours. Given the differences in _V_ oc of the two cells, we expect that the two sample series should differ in the recombination losses that occur either in the bulk or at interfaces and that these differences should be reflected in differences in the decay times  TPL,HLI . This qualitative expectation is confirmed already by studying the PL transients for the two sample series (Figure 13a and b) which show substantially faster TPL decays for the samples based on coevaporated perovskite layers. 

In order to obtain additional insights, we first determine the decay times shown in Figure 13c and d. While taking the derivative defined by Equation 3 is a simple task for smooth, simulated data, it is quite challenging to extract meaningful derivatives from noisy experimental data. Therefore, it is advisable to not or not only take the derivative of the background corrected raw data but to first fit the data with a function and then differentiate the fit. We note that given the multitude of non-exponential features affecting the transients, we opted to identify functions for which the fit algorithm converges easily and leads to a good agreement with the experimental transients even though the functional form of the fit functions bears no physical meaning. We observed that good candidates for fit functions are high order polynomials that can be fitted to the logarithm of the PL. Alternatives are rational functions, i.e. ratios of higher order polynomials. In Figure 13c and d, we therefore see symbols and lines, where the symbols represent the derivative of the background-corrected and stitched raw data while the lines are the derivative of the fits to the data. Both agree within the accuracy of the method, which is – at least partly – a consequence of the raw data being fairly high quality (low noise level) due to long integration and high measurement times. The  _E_ F axis for the experimental data was determined from the knowledge of the laser fluences used in the measurement (provides the initial  _E_ F at time zero after the pulse with Equation 4) and the knowledge that the PL intensity scales with exp(  _E_ F/ _k_ B _T_ ).<sup>[47]</sup> This proportionality implies that any order of magnitude decrease in PL leads to a 58 mV decrease in  _E_ F. From comparing the glass/MAPI/TOPO (grey) samples of the coevaporated and the solution-processed perovskite sample series in Figure 13c and d, it is directly apparent that the quality of the bulk differs substantially. In addition, the coevaporated cell suffers from increased interface recombination relative to the solutionprocessed cell, which we conclude from the substantial reduction in  TPL,HLI for the samples with interfaces (green and red) relative to the passivated layer on glass (grey). Furthermore, the comparison in Figure 13 demonstrates that the representation of the decay time  TPL,HLI via Fermi-level-splitting  _E_ F is advantageous compared to the usual representation of the decay itself. This new type of graph highlights differences and similarities between the samples more clearly and allows estimating recombination parameters. 

25 



<!-- Start of picture text -->
100 100<br>PTAA/MAPI/TOPO ( a) ( b)<br>10-1 10-1<br>ITO/PTAA/MAPI/TOPO MAPI/TOPO<br>10-2 10-2<br>MAPI/TOPO<br>10-3 10-3 PTAA/MAPI/TOPO<br>10-4 10-4<br>solar cell solar cell<br>10-5 solution-processed  10-5 coevaporated<br>V oc=1.25 V V oc=1.05 V<br>10-6 10-6<br>10-7  rational fit 10-7  rational fit<br> experimental data  experimental data<br>10-8 10-8<br>10-9 10-8 10-7 10-6 10-5 10-9 10-8 10-7 10-6 10-5<br>time  t  (s) time  t  (s)<br>excess-charge carrier density  n  (cm-3) excess-charge carrier density  n  (cm-3)<br>1014 1015 1016 1017 1014 1015 1016 1017<br>ITO/PTAA/MAPI/TOPO ( c)  rational fit ( d)<br>10-5 MAPI/TOPO 10-5  experimental data<br>PTAA/MAPI/TOPO<br>10-6 10-6<br>solution-processed<br>solar cell<br>10-7 10-7<br> rational fit coevaporated<br>10-8  experimental data 10-8 solar cell<br>1.1 1.2 1.3 1.4 1.5 1.1 1.2 1.3 1.4 1.5<br>Fermi-level-splitting  E F (eV) Fermi-level-splitting  E F (eV)<br>PTAA/MAPI/TOPO<br>glass/MAPI/TOPO<br>normalized TPL TPL normalized TPL TPL<br>decay time  (s)TPL,HLI decay time  (s)TPL,HLI<br><!-- End of picture text -->

**Figure 13:** Experimental data of transient photoluminescence measurements on two different a sample series comparing coevaporated and solution-processed, starting with the passivated perovskite film (grey), going further to MAPI with charge-extracting layer (PTAA (green), C60 (blue)) and finally showing the complete coevaporated cell (red). A laser excitation fluences of 7.2 µJ/cm<sup>2</sup> with a spot diameter of 3.8 mm was used for the measurements. A gated CCD camera is used to detect the timeresolved PL. Stitching several measurements recorded at different delay times after the laser pulse with different gains and integration times enables a higher dynamic range. More details can be found in the method section in the Supporting Information. (a-b) Normalized photoluminescence decays over time. (c-d) Decay time _τ_ TPL,HLI assuming HLI ( _m_ =2) versus Fermi-level splitting  _E_ F. Solid lines represent the derivative from TPL fits using a fifth-degree rational function and are intended to be as a guide to the eye. 

To quantify and extract these material and device parameters, the TPL datasets were fitted with transient simulations performed with Sentaurus TCAD. **Figure 14** presents the experimental data for _τ_ TPL,HLI of the two sample series compared with the simulations that best reproduce the experimental data. First, we simulated the glass/perovskite/TOPO stacks (grey) to determine the recombination coefficients of the perovskite bulk material. The decay time  TPL,HLI of experimental data is dominated by radiative recombination over the complete range of quasi Fermi-level splitting, which were 

26 

experimentally accessible, and increases constantly for smaller ∆ _E_ F. This behaviour implies that SRH lifetimes have to be extremely long. The simulations are done with a SRH bulk lifetime of _τ_ n + _τ_ p = 80 µs and in Figure S21, we show how the simulations with lower SRH lifetimes look like. From Figure S21, we conclude for lifetimes _τ_ n + _τ_ p < 40 µs, the agreement between simulation and experiment deteriorates substantially. SRH bulk lifetimes as high as 80 µs would allow an open-circuit voltage of 1.31 V under AM1.5g illumination, i.e. a value very close to the radiative limit of 1.32 V.<sup>[13]</sup> The solution-processed samples with PTAA (green, yellow) do not suffer from additional losses. The decay times are similar to the passivated sample with the glass/perovskite interface. The band offset between perovskite and PTAA and the surface recombination velocity must therefore be negligibly small. In the Supporting Figure S21 we demonstrate that a surface recombination velocity must be around SPTAA=1 cm/s. Also, the band offset and surface recombination at the PCBM/perovskite interface must be quite small to explain the data. Nevertheless, the PCBM/perovskite interface is the only interface that causes visible deviations of the PL transients from the behaviour expected in the radiative limit. We find that a surface recombination velocity _S_ PCBM=17 cm/s and an offset of 70 meV lead to the best agreement with the experimental data. Note that the decay time curve for the solution-processed cell (red line, Figure 12c) reproduces the typical S-shape predicted by Equation 11. It should also be noted that the simulated _JV_ -curve of a simulated cell with the stated parameters agrees well with the measured _JV_ -characteristic (Supporting Figure S19). Another implication from the data shown in Figure 14a is that for perovskite films and layer stacks with small recombination losses, the measured differential time constants may assume nearly any value (from tens of ns to tens of ms), depending on the range of carrier concentrations and Fermi-level splitting that are set by the laser fluence. 



<!-- Start of picture text -->
excess-charge carrier density  n  (cm -3 ) excess-charge carrier density  n  (cm -3 )<br>10 14 10 15 10 16 10 17 10 14 10 15 10 16 10 17<br>(a) (b)<br>MAPI/TOPO 10 -6<br>ITO/PTAA/MAPI/TOPO<br>10 -5<br>PTAA/MAPI/TOPO<br>S PTAA=0.01 cm/s<br>10 -7<br>10 -6 no offset<br>solution-processed<br>solar cell<br>10 -7<br>S PCBM=17 cm/s<br>n+p=80 µs 10 -8 n+p=0.7 µs<br>c=70 meV coevaporated<br>k rad=7×10 -11 cm 3 /s k rad=2×10 -10 cm 3 /s solar cell<br>10 -8<br>1.1 1.2 1.3 1.4 1.5 1.1 1.2 1.3 1.4 1.5<br>Fermi-level-splitting  E F (eV) Fermi-level splitting  E F (eV)<br>PTAA/MAPI/TOPO<br>decay time  (s)TPL,HLI decay time  (s)TPL,HLI MAPI/TOPO<br><!-- End of picture text -->

**Figure 14:** Experimental data of transient photoluminescence measurements of the solution-processed sample series and fits from Sentaurus TCAD, which allow us to state the material parameters that describe the sample behavior best. All simulation parameters are listed in Table S4 and S5 in the Supporting Information. 

27 

Without the additional information on the laser fluence and without high dynamic range data as shown here, the information obtained from TPL data on many high-quality layers or layer stacks would be either difficult to compare or entirely meaningless. 

In the following we want to discuss the fitting of the coevaporated sample series, representing an example of samples with a higher degree of non-radiative recombination. A SRH bulk lifetime of about _τ_ n + _τ_ p = 750 ns best describes the experimental TPL data of coevaporated bulk passivated with TOPO in the glass/perovskite/TOPO stack (grey). This SRH bulk lifetime would allow much higher opencircuit voltages than 1.05 V. Combined with an effective radiative recombination coefficient _k_ rad = 2×10<sup>-</sup> 10 cm3s-1, a _V_ oc of about 1.23 V would still be possible for the coevaporated bulk if no additional recombination losses would occur in the stack. The simulations suggest that for the coevaporated cell, these additional recombination losses are caused by misaligned energy levels and increased recombination at both interfaces (see Figure 6). Interface recombination at the PTAA/MAPI interface (coevaporated sample) leads to slightly shorter decay times  TPL,HLI at small Fermi-level splitting (green) as opposed to the samples without charge-extracting layers attached (grey). Note that these two decay time curves nicely overlap at high ∆ _E_ F, where radiative and Auger recombination dominate the _τ_ TPL,HLI. The trend of PTAA/perovskite interface can be best explained by a band offset of ∆ _χ_ = 100 meV and a surface recombination velocity of _S_ n = _S_ p = 100 cm/s. Since the PTAA layer is very thin we would expect that  TPL,HLI saturates for small ∆ _E_ F around ~400 ns (discussion section 3). However, the decay time at small ∆ _E_ F is much higher and increases beyond the bulk lifetime. We observe this behaviour in our simulations if we assume shallow, neutral defects. Thus, in the simulation that best fits the data the defects are shallow and positioned only 150 meV away from the VB band edge (Supporting Figure S22). These parameters would still allow a Fermi-level splitting of 1.18 V in simulated PTAA/perovskite stack. Also, the properties of the perovskite/C60 interface in the solar cell (red) are quite complex. In this case, the decay time is roughly two orders of magnitudes lower suggesting the additional interfacial losses in _V_ oc must be higher. Only for small ∆ _E_ F the decay time increases again indicating that the loss is caused by a huge conduction band offset e.g. ∆ _χ_ = 200 meV. To explain the shape of _τ_ TPL,HLI vs. ∆ _E_ F that deviates from the typical S-shape we introduced in the discussion of the TPL on solar cells, we had to assume at least two different defect state. A deep level defect is responsible for the loss in _V_ oc and another shallow defect must be introduced to match the shape of the differential decay curve. While we note here that various defect properties such as its charge, concentration and energetic and spatial position affect the TPL, it is beyond the scope of this work to present a systematic investigation on the influence of these parameters on the decay time  TPL,HLI . 

28 

### **7. Conclusions** 

Transient photoluminescence experiments are abundantly used in the field of halide perovskite photovoltaics to study charge-carrier recombination in the bulk and at interfaces. While the interpretation of TPL on thin films on glass has been thoroughly discussed and used in the literature,<sup>[12,</sup> 13, 48] the most important recombination losses are often occurring at the interfaces between the absorber and the charge-transfer layers.<sup>[15]</sup> In addition, the presence of charge-transfer layers can also have an impact on how the perovskite films grow and hence affect the bulk and surface quality of the perovskite layer. Thus, there is a clear need to extend our theoretical understanding to TPL measurements done on a variety of sample geometries including zero, one or two charge-transfer layers in contact to the perovskite absorber. In addition, it is important to also understand how contact layers such as ITO or Ag affect the TPL decay and to be able to understand measurements done on complete devices. The present paper provides an extensive account based on a combination of experimental data, numerical simulations with Sentaurus TCAD and analytical solutions to differential equations that allows the reader to understand the mechanisms affecting a TPL decay in a variety of sample geometries. As a key tool to analyze the data, we introduce the concept of a decay time  TPL,HLI displayed as a function of the timedependent quasi-Fermi level splitting. This plot allows us to combine data obtained with different laser fluences in one figure and improves the comparability of different data sets. The charge-carrier-density dependent decay time  TPL,HLI is affected by various different _recombination mechanisms_ (radiative, Auger and SRH recombination), also by charge transfer between the absorber and the charge-transport layers and, finally, by capacitive charging and discharging of the electrodes in case of a full device. The different mechanisms can partly be distinguished by their appearance at different values of the quasiFermi level splitting and by their characteristic slope the decay time vs. quasi-Fermi level splitting diagram. Along with this paper, the reader finds a video collection of the band diagram during the TPL simulation for the different layer stacks. After introducing the general concepts using numerical simulations, we show experimental data sets on different sample geometries and absorber deposition methods (solution-processed vs. coevaporated). We determine the TPL decays over seven orders of magnitude in dynamic range and show that our previously presented recipe for MAPI layers allows bulk lifetimes of several tens of µs (best fits are obtained for 80 µs the sum of electron and hole lifetimes). In addition, the TPL transients clearly indicate negligible losses at the MAPI/PTAA interface and only moderate losses with surface recombination velocities of 17 cm/s for the MAPI/PCBM interface. 

29 

### **Data availability** 

The data that support the findings of this study are available from the corresponding author on request. 

### **Code availability** 

The code and data sets generated and analyzed during this study are available from the corresponding author on reasonable request. 

### **Author Information** 

Corresponding Author: 

*To whom correspondence should be addressed. E-Mail: t.kirchartz@fz-juelich.de, l.krueckemeier@fzjuelich.de 

### **Acknowledgements** 

The authors acknowledge support from PEROSEED. We thank Steffen Krause and Jonathan Werner for the process development and fabrication of the coevaporated MAPI samples. 

### **Author contributions** 

LK and TK prepared the manuscript. LK performed the simulations. BK developed the basis of the Sentaurus TCAD code, which was modified by LK. ZL fabricated the solar cell devices and thin films. LK performed the TPL measurements. All authors contributed to the planning and the interpretation of simulations and experiments. All authors discussed the results and commented on the manuscript. 

30 

### **References** 

- [1] W. E. I. Sha, H. Zhang, Z. S. Wang, H. L. Zhu, X. Ren, F. Lin, A. K.-Y. Jen, W. C. H. Choy, _Advanced Energy Materials_ **2018,** 8, 1701586. 

- [2] S. Draguta, J. A. Christians, Y. V. Morozov, A. Mucunzi, J. S. Manser, P. V. Kamat, J. M. Luther, M. Kuno, _Energy & Environmental Science_ **2018,** 11, 960. 

- [3] L. Krückemeier, U. Rau, M. Stolterfoht, T. Kirchartz, _Advanced Energy Materials_ **2020,** 10, 1902573. 

- [4] P. K. Nayak, S. Mahesh, H. J. Snaith, D. Cahen, _Nature Reviews Materials_ **2019,** 4, 269. [5] M. A. Green, A. W. Ho-Baillie, _ACS Energy Letters_ **2019,** 4, 1639. [6] J. Yao, T. Kirchartz, M. S. Vezie, M. A. Faist, W. Gong, Z. He, H. Wu, J. Troughton, T. Watson, D. Bryant, J. Nelson, _Physical Review Applied_ **2015,** 4, 014020. 

- [7] K. Tvingstedt, O. Malinkiewicz, A. Baumann, C. Deibel, H. J. Snaith, V. Dyakonov, H. J. Bolink, _Scientific Reports_ **2014,** 4, 6071. 

- [8] G.-J. A. H. Wetzelaer, M. Scheepers, A. M. Sempere, C. Momblona, J. Ávila, H. J. Bolink, _Advanced Materials_ **2015,** 27, 1837. 

- [9] D. Luo, R. Su, W. Zhang, Q. Gong, R. Zhu, _Nature Reviews Materials_ **2020,** 5, 44. [10] T. Kirchartz, J. A. Márquez, M. Stolterfoht, T. Unold, _Advanced Energy Materials_ **2020,** 10, 1904134. 

- [11] K. P. Goetz, A. D. Taylor, F. Paulus, Y. Vaynzof, _Advanced Functional Materials_ **2020,** 30, 1910004. 

- [12] S. D. Stranks, V. M. Burlakov, T. Leijtens, J. M. Ball, A. Goriely, H. J. Snaith, _Physical Review Applied_ **2014,** 2, 034007. 

- [13] F. Staub, H. Hempel, J. C. Hebig, J. Mock, U. W. Paetzold, U. Rau, T. Unold, T. Kirchartz, _Physical Review Applied_ **2016,** 6, 044017. 

- [14] J. M. Richter, M. Abdi-Jalebi, A. Sadhanala, M. Tabachnyk, J. P. H. Rivett, L. M. Pazos-Outon, K. C. Gödel, M. Price, F. Deschler, R. H. Friend, _Nature Communications_ **2016,** 7, 13941. 

- [15] M. Stolterfoht, P. Caprioglio, C. M. Wolff, J. A. Marquez, J. Nordmann, S. Zhang, D. Rothhardt, U. Hörmann, Y. Amir, A. Redinger, L. Kegelmann, F. Zu, S. Albrecht, N. Koch, T. Kirchartz, M. Saliba, T. Unold, D. Neher, _Energy & Environmental Science_ **2019,** 12, 2778. 

- [16] M. Stolterfoht, C. M. Wolff, J. A. Marquez, S. Zhang, C. J. Hages, D. Rothhardt, S. Albrecht, P. L. Burn, P. Meredith, T. Unold, D. Neher, _Nature Energy_ **2018,** 3, 847. 

- [17] P. Schulz, D. Cahen, A. Kahn, _Chemical Reviews_ **2019,** 119, 3349. [18] C. M. Wolff, P. Caprioglio, M. Stolterfoht, D. Neher, _Advanced Materials_ **2019,** 31, 1902762. [19] J. Chen, N.-G. Park, _Advanced Materials_ **2019,** 31, 1803019. [20] M. Stolterfoht, M. Grischek, P. Caprioglio, C. M. Wolff, E. Gutierrez-Partida, F. Peña-Camargo, D. Rothhardt, S. Zhang, M. Raoufi, J. Wolansky, M. Abdi-Jalebi, S. D. Stranks, S. Albrecht, T. Kirchartz, D. Neher, _Advanced Materials_ **2020,** 32, 2000080. 

- [21] J. Haddad, B. Krogmeier, B. Klingebiel, L. Krückemeier, S. Melhem, Z. Liu, J. Hüpkes, S. Mathur, T. Kirchartz, _Advanced Materials Interfaces_ **2020,** 7, 2000366. 

- [22] B. Krogmeier, F. Staub, D. Grabowski, U. Rau, T. Kirchartz, _Sustainable Energy & Fuels_ **2018,** 2, 1027. [23] E. M. Hutter, T. Kirchartz, B. Ehrler, D. Cahen, E. v. Hauff, _Applied Physics Letters_ **2020,** 116, 100501. 

- [24] V. Sarritzu, N. Sestu, D. Marongiu, X. Chang, S. Masi, A. Rizzo, S. Colella, F. Quochi, M. Saba, A. Mura, _Scientific reports_ **2017,** 7, 44629. 

- [25] M. Stolterfoht, V. M. Le Corre, M. Feuerstein, P. Caprioglio, L. J. A. Koster, D. Neher, _ACS Energy Letters_ **2019,** 4, 2887. 

- [26] D. W. DeQuilettes, S. Koch, S. Burke, R. K. Paranji, A. J. Shropshire, M. E. Ziffer, D. S. Ginger, _ACS Energy Letters_ **2016,** 1, 438. 

- [27] I. L. Braly, D. W. deQuilettes, L. M. Pazos-Outón, S. Burke, M. E. Ziffer, D. S. Ginger, H. W. Hillhouse, _Nature Photonics_ **2018,** 12, 355. 

- [28] Y. Yang, M. Yang, D. T. Moore, Y. Yan, E. M. Miller, K. Zhu, M. C. Beard, _Nature Energy_ **2017,** 2, 1. 

- [29] L. M. Herz, _ACS Energy Letters_ **2017,** 2, 1539. 

- [30] X. Zhang, J.-X. Shen, W. Wang, C. G. Van de Walle, _ACS Energy Letters_ **2018,** 3, 2329. 

31 

- [31] C. L. Davies, M. R. Filip, J. B. Patel, T. W. Crothers, C. Verdi, A. D. Wright, R. L. Milot, F. 

   - Giustino, M. B. Johnston, L. M. Herz, _Nature Communications_ **2018,** 9, 293. 

- [32] J.-X. Shen, X. Zhang, S. Das, E. Kioupakis, C. G. Van de Walle, _Advanced Energy Materials_ **2018,** 8, 1801027. 

- [33] B. Das, I. Aguilera, U. Rau, T. Kirchartz, _Physical Review Materials_ **2020,** 4, 024602. 

- [34] X. Zhang, M. E. Turiansky, J.-X. Shen, C. G. Van de Walle, _Physical Review B_ **2020,** 101, 140101. 

- [35] T. Kirchartz, F. Staub, U. Rau, _ACS Energy Letters_ **2016,** 1, 731. 

- [36] T. Kirchartz, _Philosophical Transactions of the Royal Society A: Mathematical, Physical and Engineering Sciences_ **2019,** 377, 20180286. 

- [37] C. G. Shuttle, B. O’Regan, A. M. Ballantyne, J. Nelson, D. D. C. Bradley, J. d. Mello, J. R. Durrant, _Applied Physics Letters_ **2008,** 92, 093311. 

- [38] S. Wheeler, D. Bryant, J. Troughton, T. Kirchartz, T. Watson, J. Nelson, J. R. Durrant, _The Journal of Physical Chemistry C_ **2017,** 121, 13496. 

- [39] P. R. F. Barnes, K. Miettunen, X. Li, A. Y. Anderson, T. Bessho, M. Gratzel, B. C. O'Regan, _Advanced Materials_ **2013,** 25, 1881. 

- [40] L. Castaner, E. Vilamajo, J. Llaberia, J. Garrido, _Journal of Physics D: Applied Physics_ **1981,** 14, 1867. 

- [41] D. Kiermasch, A. Baumann, M. Fischer, V. Dyakonov, K. Tvingstedt, _Energy & Environmental Science_ **2018,** 11, 629. 

- [42] F. A. Lindholm, J. J. Liou, A. Neugroschel, T. W. Jung, _IEEE Transactions on Electron Devices_ **1987,** 34, 277. 

- [43] O. J. Sandberg, K. Tvingstedt, P. Meredith, A. Armin, _The Journal of Physical Chemistry C_ **2019,** 123, 14261. 

- [44] Z. S. Wang, F. Ebadi, B. Carlsen, W. C. H. Choy, W. Tress, _Small Methods_ **2020,** 4, 2000290. 

- [45] F. Steiner, S. Foster, A. Losquin, J. Labram, T. D. Anthopoulos, J. M. Frost, J. Nelson, _Materials Horizons_ **2015,** 2, 113. 

- [46] Z. Liu, L. Krückemeier, B. Krogmeier, B. Klingebiel, J. A. Márquez, S. Levcenko, S. Öz, S. Mathur, U. Rau, T. Unold, T. Kirchartz, _ACS Energy Letters_ **2019,** 4, 110. 

- [47] P. Würfel, _Journal of Physics C: Solid State Physics_ **1982,** 15, 3967. 

- [48] M. J. Trimpl, A. D. Wright, K. Schutt, L. R. V. Buizza, Z. Wang, M. B. Johnston, H. J. Snaith, 

   - P. Müller-Buschbaum, L. M. Herz, _Advanced Functional Materials_ **2020,** 30, 2004312. 

32 

