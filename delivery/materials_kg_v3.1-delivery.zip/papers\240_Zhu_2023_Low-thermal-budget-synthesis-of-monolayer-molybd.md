# Low-thermal-budget synthesis of monolayer molybdenum disulfide for silicon back-end-of-line integration on a 200 mm platform

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Nanotechnology |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 248 |
| 作者 | J. Zhu, Ji-Hoon Park, S. Vitale, Wen-Jun Ge, G. Jung, Jiangtao Wang, M. Mohamed, Tianyi Zhang et al. |
| DOI | 10.1038/s41565-023-01375-6 |
| 源文件 | 040_Zhu_2023_Low-thermal-budget-synthesis-of-monolayer-molybd.pdf |

---
## **nature nanotechnology** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

# **Low-thermal-budget synthesis of monolayer molybdenum disulfide for silicon back-endof-line integration on a 200 mm platform** 

Received: 3 August 2022 **Jiadi Zhu**<sup>**1,5**</sup> **, Ji-Hoon Park**<sup>**1,5**</sup> **, Steven A. Vitale**<sup>**2**</sup> **, Wenjun Ge**<sup>**3**</sup> **, Gang Seob Jung**<sup>**3**</sup> **, Jiangtao Wang**<sup>**1**</sup> **, Mohamed Mohamed**<sup>**2**</sup> **, Tianyi Zhang**<sup>**1**</sup> **,** Accepted: 11 March 2023 **Maitreyi Ashok**<sup>**1**</sup> **, Mantian Xue**<sup>**1**</sup> **, Xudong Zheng**<sup>**1**</sup> **, Zhien Wang**<sup>**1**</sup> **, Jonas Hansryd**<sup>**4**</sup> **,** Published online: 27 April 2023 **Anantha P. Chandrakasan**<sup>**1**</sup> **, Jing Kong**<sup>**1**</sup> **& Tomás Palacios**<sup>**1**</sup> Check for updates Two-dimensional (2D) materials are promising candidates for future electronics due to their excellent electrical and photonic properties. Although promising results on the wafer-scale synthesis (≤150 mm diameter) of monolayer molybdenum disulfide (MoS2) have already been reported, the high-quality synthesis of 2D materials on wafers of 200 mm or larger, which are typically used in commercial silicon foundries, remains difficult. The back-end-of-line (BEOL) integration of directly grown 2D materials on silicon complementary metal–oxide–semiconductor (CMOS) circuits is also unavailable due to the high thermal budget required, which far exceeds the limits of silicon BEOL integration (<400 °C). This high temperature forces the use of challenging transfer processes, which tend to introduce defects and contamination to both the 2D materials and the BEOL circuits. Here we report a low-thermal-budget synthesis method (growth temperature < 300 °C, growth time ≤ 60 min) for monolayer MoS2 films, which enables the 2D material to be synthesized at a temperature below the precursor decomposition temperature and grown directly on silicon CMOS circuits without requiring any transfer process. We designed a metal–organic chemical vapour deposition reactor to separate the low-temperature growth region from the high-temperature chalcogenide-precursor-decomposition region. We obtain monolayer MoS2 with electrical uniformity on 200 mm wafers, as well as a high material quality with an electron mobility of ~35.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . Finally, we demonstrate a silicon-CMOS-compatible BEOL fabrication process flow for MoS2 transistors; the performance of these silicon devices shows negligible degradation (current variation < 0.5%, threshold voltage shift < 20 mV). We believe that this is an important step towards monolithic 3D integration for future electronics. 

The scaling and integration of silicon devices are quickly reaching a limit due to interconnect-distance, mobility-degradation and lithographic challenges<sup>1,2</sup> . New material systems and new integration technologies are needed to enable a further increase in the transistor density and 

novel functionalities in integrated circuits<sup>3–5</sup> . For these applications, two-dimensional (2D) materials (for example, molybdenum disulfide (MoS2)) have attracted great attention in the past decade due to their high carrier mobility, relatively large bandgap, atomic-level thickness 

A full list of affiliations appears at the end of the paper. e-mail: jingkong@mit.edu; tpalacios@mit.edu 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**456** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

and rich electronic and photonic properties<sup>6,7</sup> . In addition, 2D materials offer great potential in their integration with silicon circuits as they can boost integration density, provide lower leakage than silicon transistors for memory selector applications, and enrich the set of functions available in future heterogeneously integrated circuits, for example, energy harvesting<sup>8</sup> and sensing<sup>9</sup> . Wafer-scale syntheses of monolayer 2D materials have been demonstrated in recent years<sup>10–12</sup> . However, the growth of 2D materials on wafers of ~200 mm diameter or larger, with good uniformity and quality, has been difficult<sup>13,14</sup> . The high thermal budget that is typical in 2D material synthesis also hinders its direct integration with silicon circuits during back-end-of-line (BEOL) fabrication<sup>15–17</sup> . 

### **Low-thermal-budget synthesis of monolayer MoS2** 

Here we demonstrate a low-thermal-budget synthesis method for monolayer MoS2 at the 200 mm wafer scale. Figure 1a shows a schematic of the custom-made low-temperature metal–organic chemical vapour deposition (MOCVD) system used in this work. Extended Data Figure 1 shows photographs of the system (Extended Data Fig. 1a) and how the wafers are mounted vertically to the quartz wafer boat (Extended Data Fig. 1b,c). The reactor is a 250-mm-diameter hot-wall tube furnace, with molybdenum hexacarbonyl (Mo(CO)6) and diethyl sulfide ((C2H5)2S) being the molybdenum and sulfur precursors, respectively. To realize low-temperature growth, the system is separated into two temperature regions: a low-temperature growth region (Region I) for MoS2 synthesis on the left (upstream), and a high-temperature sulfur-precursor-decomposition region (Region II) on the right (downstream) where (C2H5)2S is decomposed to provide the sulfur species needed for the growth. In this system, the growth region (Region I) is not heated directly by the heating element. Instead, it reaches a temperature gradient in the axial direction and a uniform temperature profile in the radial direction through heat transfer from the decomposition region (Region II) to the surrounding environment. The left and right boundaries of Region I are defined, respectively, by the decomposition temperature of Mo(CO)6 (~250 °C)<sup>11</sup> and the safe temperature for the silicon process (400 °C)<sup>17</sup> . This temperature range enables the decomposition of the molybdenum precursor, which provides the molybdenum oxide species needed for MoS2 synthesis. Contrary to traditional high-temperature growth methods<sup>10,11</sup> , where the target wafer is placed horizontally in the high-temperature growth region, in our low-temperature synthesis, the target wafer is placed vertically inside the growth tube to realize a uniform temperature distribution over the 200 mm wafer. Region II functions as a sulfur reservoir, the left boundary of which is defined by the decomposition temperature of (C2H5)2S (550 °C)<sup>11</sup> . Computational fluid dynamics (CFD) simulations (Supplementary Notes 1–3) predict that the flow speed at the edge of the wafer is close to zero. This low flow speed enables exchange of the decomposed sulfur precursors from the right side (downstream) of the wafer to the left side (upstream) of the wafer. The low growth pressure (~255 mtorr) increases the mean free path of the decomposed precursor with respect to the higher-pressure cases<sup>11</sup> , which helps the decomposed sulfur precursors to diffuse longer. The localized higher pressure behind the wafer caused by decomposition of the sulfur precursor leads to an increase in the partial pressure of the decomposed sulfur precursor, which also helps to decrease the flow speed at the edge of the wafer and force the decomposed sulfur precursor to flow back to the front (upstream) side of the wafer (Supplementary Note 4). All these three factors enhance the flow back of the decomposed sulfur precursors from Region II to Region I. Hence, the decomposed molybdenum and sulfur species react in the low-temperature growth region (Region I). The monolayer film is then deposited on both sides of the growth substrate, which enables MoS2 synthesis below the decomposition temperature of the sulfur precursor. However, owing to the limited supply of the molybdenum precursor and its predominant 

consumption during the growth on the left side (upstream) of the substrate, the film on the left side (upstream) of the wafer has a higher quality and better uniformity. To enhance precursor use, a thermal block is placed on the right (downstream) side of Region II. In doing so, the gas flow from the reaction chamber to the vacuum pump is limited, which helps the decomposed sulfur precursor flow back to Region I. A large temperature gradient is also created between Regions I and II via natural air cooling to minimize the distance between the two regions, which increases the amount of decomposed sulfur that flows back into Region I. In this way, we are able to realize a high concentration of the decomposed sulfur atoms in the growth region. 

To improve the uniformity of the MoS2 growth over 200 mm wafers (Fig. 1b), a 100-mm-diameter gas diffuser (a silicon wafer with designed holes) is used at the gas inlet (Fig. 1a). This helps to stabilize and uniformly distribute the precursor flow in the chamber (Supplementary Note 2). The total gas flow inside the chamber is set to 1,100 sccm during the growth to ensure that the molybdenum precursors can reach the left surface (upstream) of the target wafer with good uniformity in the radial direction whilst not being so strong as to hinder the flow back of the decomposed sulfur precursor (Supplementary Notes 3 and 4). The total gas flow includes the evaporated molybdenum, the sulfur precursors and the argon carrier gas. Owing to the low chamber pressure, the sulfur precursor evaporates spontaneously in the reaction chamber at a rate that can be controlled using a needle valve. This helps to minimize the total flow rate and greatly increases the sulfur precursor density inside the chamber, since no carrier gas is used for the sulfur precursor. Importantly, the excess sulfur precursor creates a sulfur-rich environment that enhances the flow back for the decomposed sulfur precursor, which provides enough sulfur atoms to ensure effective MoS2 growth. In this sulfur-rich environment, the flow rate of the molybdenum precursor ( _Q_ Mo), which is controlled using a mass flow controller, determines the nucleation density of the monolayer MoS2, and thus the grain size and total growth time, to realize a full monolayer MoS2 film coverage (Fig. 1c). A total growth time below 60 min can be realized by increasing the Mo(CO)6 flow rate above 120 sccm, which also further reduces the total thermal budget. Sodium chloride (NaCl) is used as the seeding promoter to ensure seeding and accelerate the lateral growth of MoS2 (Methods and Supplementary Note 5). 

A low thermal budget for MoS2 growth is critical for integration at the BEOL of silicon complementary metal–oxide–semiconductor (CMOS) circuits, as temperatures above 400 °C will damage the dopant distribution in silicon, the gate dielectric layer and the interconnect quality<sup>17</sup> . Conventional chemical vapour deposition (CVD) methods require synthesis temperatures above 500 °C, or even up to 1,000 °C, to enable the reaction of solid-state molybdenum oxide and sulfur<sup>10,18</sup> . Thermally assisted conversion can ensure a low growth temperature, although it is less controllable, generates nanometre-scale domains and is limited to certain types of transition metal dichalcogenide materials, for example, PtSe2 (ref. 19). MOCVD growth typically also requires growth temperatures higher than 550 °C to fully decompose the sulfur precursors<sup>11,16</sup> . Moreover, the slow lateral growth rate in MOCVD growth requires a long growth time for full film coalescence, which is not practical for commercial products<sup>20,21</sup> . In this work, we are able to realize a low growth temperature of 275 °C through (1) decoupling the region used for precursor decomposition from the region where the substrate is located and (2) increasing the sulfur partial pressure to enhance sulfur flow back from the decomposition region to the growth region. This not only enables the growth of MoS2 at a low temperature but also ensures that the concentration of decomposed sulfur is no longer a limiting factor. In addition, the growth time for a full monolayer is less than 60 min due to using a high flow rate for Mo(CO)6, which slightly increases the nucleation density and balances grain size and growth time. The combination of a low growth temperature and a short growth time is ideal for BEOL integration with silicon CMOS wafers (Fig. 1d). 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**457** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



<!-- Start of picture text -->
a<br>Region I Region II<br>Mo(CO)6 (C2H5)2S decomposition<br>decomposition<br>Pump out<br>Flow back<br>Gas inlet<br>Diffuser<br>Thermal<br>block<br>Mo<br>C<br>O<br>S<br>Target wafer<br>Heating element<br>b 200 mm c 90 d<br>30 (11)<br>MOCVD<br>500 60 (16)<br>20<br>(20)<br>250 30 10 (21)<br>CVD<br>This<br>work (18) (10)<br>300 nm Monolayer  0<br>SiO2/Si MoS2 0 0<br>60 90 120 150 400 800 1,200<br>Q Mo (sccm) Growth temperature (°C)<br>250 °C 400 °C 550 °C<br>Grain size (nm) Growth time (h)<br>Growth time (min)<br>Thermal limit<br><!-- End of picture text -->

**Fig. 1 | Low-temperature MOCVD of MoS2. a** , Schematic illustration of the MOCVD system and the deposition process. Precursors are injected from the left side of the reaction chamber. The molybdenum precursor starts to decompose on reaching the left side of Region I (250 °C). The sulfur precursor decomposes in Region II (>550 °C) and flows back into Region I where it reacts with the decomposed molybdenum precursor to deposit MoS2 on the target wafer. The residue gases are pumped out on the right side of the reaction chamber. A thermal block is placed in Region II to limit the gas flow. **b** , Optical image of 

MoS2 synthesized on top of a 300-nm-thick silica/silicon (SiO2/Si) substrate. The left half shows the bare 300 nm SiO2/Si substrate for comparison. **c** , Dependence of the growth time and grain size on the Mo(CO)6 flow rate ( _Q_ Mo) when the total flow rate is fixed at ~1,100 sccm. **d** , Benchmarking of thermal budgets for different synthesis methods of monolayer MoS2 growth. The purple rectangle indicates the desired region, and the number in parentheses indicates the reference number of the synthesis method. 

Careful material characterization further illustrates the quality of the synthesized MoS2. Figure 2a shows the MoS2 grown after a growth time of only 30 min (half of the time for full coalescence) under a 120 sccm Mo(CO)6 flow rate. Triangular MoS2 flakes can clearly be observed, with an average flake size of around 200 nm. By increasing the growth time, these isolated flakes will merge into a continuous monolayer thin film, as shown in Extended Data Fig. 2a–c. The monolayer MoS2 film appears to be polycrystalline, as highlighted by the selected-area electron diffraction measurements in Extended Data Fig. 2d. Excellent stitching between two different grains is observed (Extended Data Fig. 2e–i), with no overlapped regions in between. X-ray photoelectron spectroscopy (XPS) data exhibit strong characteristic peaks of MoS2 at 232.3 eV (Mo 3 _d_<sup>3/2</sup> ), 229.3 eV (Mo 3 _d_<sup>5/2</sup> ) and 226.4 eV (S 2 _s_ ), which highlights full consumption of the molybdenum precursors and intermediate reactants (Fig. 2b,c). This is further confirmed via high-resolution scanning transmission electron microscopy (HR-STEM) 

(Fig. 2d). No sulfur defect is observed in the HR-STEM image. A low interface trap density ( _D_ it) of 3.5 × 10<sup>12</sup> cm<sup>−2</sup> was estimated (Supplementary Note 6). The Raman and photoluminescence (PL) spectra of the synthesized MoS2 (Fig. 2e,f, respectively) also show sharp and high-intensity peaks, matching very well with those reported from high-temperature growth<sup>3</sup> . Since the sulfur precursor will first decompose into volatile ethyl radicals at around 550 °C, and requires much higher temperatures to decompose further into ethylene and less volatile amorphous carbon<sup>22,23</sup> , the low substrate temperature (~275 °C) of our MOCVD process is likely to reduce carbon contamination in MoS2. Indeed, no amorphous carbon peak can be observed in the Raman spectrum (Extended Data Fig. 2j), indicating that carbon contamination is negligible in the low-temperature synthesis process. 

To discuss the device-to-device uniformity further, we fabricated back-gated MoS2 transistors (Extended Data Fig. 3a) with a channel length of 200 nm in a 5 × 5 mm region at the centre of a 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**458** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



<!-- Start of picture text -->
a b c g<br>Mo 4+ S 2– 10 –5<br>Mo 4+<br>S 2–<br>10 –6<br>S 2–<br>Mo 6+<br>10 –7<br>240 235 230 225 170 165 160<br>Binding energy (eV) Binding energy (eV)<br>10 –8<br>d e f<br>A1g<br>10 –9<br>E12g<br>10 –10<br>300 350 400 450 500 1.6 1.8 2.0 –2 0 2 4 6<br>Raman shift (cm –1 ) Photon energy (eV) V GS (V)<br>Intensity (a.u.) Intensity (a.u.)<br>–1) (A  I µmD<br>Intensity (a.u.) Intensity (a.u.)<br><!-- End of picture text -->

**Fig. 2 | Material characterization. a** , Scanning electronic microscope image of the synthesized MoS2 after 30 min of growth, which is half of the typical time for full coalescence. Scale bar, 1 µm. **b** , **c** , XPS data of the synthesized monolayer MoS2 thin film, showing molybdenum peaks ( **b** ) and sulfur peaks ( **c** ), and a very weak molybdenum oxide peak (Mo<sup>6+</sup> ) can be observed in **b** , which highlights full consumption of the molybdenum precursors and intermediate reactants. **d** , Typical HR-STEM image of the synthesized MoS2, which shows no defect sites. 

Scale bar, 2 nm. **e** , Raman spectrum of the synthesized monolayer MoS2 film. **f** , PL spectrum of the synthesized monolayer MoS2 film. **g** , Measured transfer characteristics of 100 back-gated MoS2 transistors fabricated in a 5 × 5 mm region at the centre of a 200-mm-diameter, 20-nm-thick alumina/silicon (Al2O3/Si) wafer ( _V_ DS = 0.7 V, _L_ CH = 200 nm). _I_ D, drain current; _V_ GS, gate–source voltage; _V_ DS, drain–source voltage; _L_ CH, channel length. 

200-mm-diameter MoS2 wafer. With good poly(methyl methacrylate) (PMMA) passivation (Methods), the hysteresis in the transfer curves of back-gated transistors can be greatly reduced and has limited impact on the device performance (Extended Data Fig. 3b). Moreover, even when the channel material is polycrystalline with many grain boundaries and few-nanometre-scale bilayer islands (Extended Data Fig. 2c), we still observed excellent device-to-device uniformity among these 100 back-gated MoS2 transistors (Fig. 2g), which is even comparable to silicon metal–oxide–semiconductor field-effect transistors (MOSFETs) fabricated using a standard silicon CMOS procedure<sup>24</sup> . This shows that excellent device-to-device uniformity can be achieved, in spite of the small grain size, as long as the material has a uniform grain size (for example, all around 200 nm in this work), good stitching between the grains and a limited defect density. With further device scaling, the device performance and uniformity may be more sensitive to the material quality, for example, variations caused by localized doping and defects, which will require further exploration. 

### **Wafer-scale uniformity** 

We mapped the Raman spectrum of the as-grown MoS2 samples over the 200 mm wafer with a resolution of 1 cm. The intensity mapping of the Raman A1g peak is shown in Fig. 3a. This 200 mm wafer-scale uniformity is further confirmed by full-width at half-maximum (FWHM) mapping of the E<sup>1</sup> 2g<sup>peak in the Raman spectrum (Fig. 3b) and FWHM</sup> mapping of the PL spectrum (Fig. 3c) as well as mapping of the PL peak position and integrated intensity (Extended Data Fig. 3c,d, respectively). 

Because of the minimum damage to the substrate during the low-temperature growth process, we are able to fabricate back-gated transistors (Extended Data Fig. 3a,e) on the as-grown MoS2 sample. These devices used 20 nm Al2O3 as the global back-gate dielectric and had a channel length of 200 nm. Using the ‘Y function’ method<sup>25,26</sup> 

(Supplementary Note 7), we extracted field-effect mobility ( _µ_ Y function) values in the linear region of these transistors (Supplementary Fig. 8); these are mapped in Fig. 3d with a resolution of 1 cm, demonstrating an average mobility and standard deviation of 26.3 ± 5.7 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> and a highest mobility value of ~35.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . These results are in good agreement with the two-terminal field-effect mobility ( _µ_ FE) data we extracted using the transmission line model (or TLM) method (Supplementary Note 7). With a relatively small grain size (~200 nm), the low-temperature-synthesized MoS2 can still have comparable, or even higher, mobility levels than MoS2 synthesized at much higher temperatures<sup>11,16</sup> . It should be noted that dielectric/interface charges<sup>27,28</sup> and remote optical phonon scattering<sup>29</sup> may also limit the carrier mobility to some extent, which requires study and optimization. Threshold voltage values were extracted from these devices and are mapped in Fig. 3e. An average threshold voltage and standard deviation of −1.93 ± 0.50 V can be observed over the 200 mm wafer. The on-state resistance ( _R_ ON) and subthreshold swing are also mapped in Extended Data Fig. 3f and Fig. 3f, respectively, showing similar wafer-scale uniformity. The distribution functions of all the aforementioned mappings are shown in Extended Data Fig. 4. The transfer characteristics of 510 back-gated transistors with a 200 nm channel length are demons trated in Fig. 3g. Small device-to-device variation can be observed. The batch-to-batch uniformity was also studied, as shown in Extended Data Fig. 3g, where we grew four batches of 200 mm monolayer MoS2 thin films, fabricated devices in the centre region of the wafer and measured the transfer characteristics of the MoS2 transistors. The transfer curves of these four batches of devices overlap well, demonstrating that the reproducibility of the synthesis process is good. These electrical measurements and mappings confirm that the low-temperature MoS2 samples possess a very high electrical performance uniformity over the 200 mm wafer. Moreover, we also benchmarked the mobility of our 200 mm MoS2 sample 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**459** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



<!-- Start of picture text -->
a b c g<br>Intensity (%) FWHM (cm –1 ) FWHM (meV)<br>100 10 100 10 –5<br>80 8 80<br>60 6 60 10 –7<br>40 4 40<br>10 –9<br>20 2 20<br>0 0 0 10 –11<br>–4 –2 0 2 4<br>V GS (V)<br>d µ Y function (cm 2  V −1  s −1 ) e V th (V) f SS (mV dec −1 ) h 10 3<br>50 1 500 Theoretical limit (30)<br>40 0 400 10 2 (31) (10) (32)CVD This<br>( 20) (33) work<br>30 –1 300 10 1 (11) (12)<br>(34)<br>20 –2 200 10 0<br>MOCVD<br>10 –3 100 (35)<br>10 –1<br>0 –4 0 0 50 100 150 200 250 300<br>Approximate substrate<br>size (mm)<br>–1) (A  I µmD<br>2–1–1)Mobility (cm V s<br><!-- End of picture text -->

**Fig. 3 | Uniformity characterization of the 200 mm monolayer MoS2 synthesized at low temperature. a** , Mapping of the Raman A1g peak over the 200 mm wafer, where the colour represents the intensity of the A1g peak. **b** , Mapping of the Raman E<sup>1</sup> 2g<sup>peak over the 200 mm wafer, where the colour</sup> represents the FWHM of the E<sup>1</sup> 2g<sup>peak.</sup><sup>**c**, PL mapping over the 200 mm wafer,</sup> where the colour denotes the FWHM of the PL peaks. **d** , Field-effect mobility ( _µ_ Y function) mapping over a 200 mm MoS2 wafer based on the measurement of back-gated transistors with a 200 nm channel length. **e** , Threshold voltage ( _V_ th) mapping over a 200 mm MoS2 wafer based on the measurement of back-gated 

transistors with a 200 nm channel length. **f** , Subthreshold swing (SS) mapping of back-gated MoS2 transistors over a 200 mm wafer. The minimum SS value in the subthreshold region is used for the plot. **g** , Transfer characteristics of 510 transistors with _V_ DS = 0.7 V and _L_ CH = 200 nm. **h** , Benchmarking of the state-of-theart electron mobility and as-grown substrate size of MoS2, regardless of the growth temperature. The purple region represents the desired region for wafer-scale MoS2 synthesis, and the number in parentheses indicates the reference number of the synthesis method. The green and red symbol colours indicate a growth temperature lower than 400 °C. 

with values reported using other state-of-the-art MoS2 synthesis methods<sup>10–12,20,30–35</sup> , regardless of the growth temperature and the wafer diameter (Fig. 3h). The mobility of MoS2, even at a high growth temperature (>400 °C), tends to be lower as the wafer diameter increases due to trade-offs related to the growth uniformity, wafer-scale coverage and transport properties. The low growth temperature and the high sulfur precursor concentration used in our work enable a low defect density and good mobility. In addition, the use of gas-phase precursors and a low chamber pressure enable better material uniformity at the 200 mm wafer scale (Fig. 3). The high electron mobility and the large substrate that we used is closer to the desired region (purple) compared with other reports, and shows a promising path to bring this material system and BEOL devices into mainstream silicon semiconductor fabrication plants. 

### **Heterogeneous integration with silicon transistors** 

In addition to developing a low-thermal-budget MOCVD MoS2 synthesis, we have also demonstrated a BEOL-compatible fabrication flow. A key challenge for this is that when we expose the fully fabricated silicon CMOS circuits to the MoS2 growth environment, the exposed top metal layers, for example, copper or aluminium, will be sulfurized during the synthesis of MoS2 (Extended Data Fig. 5a) and become more resistive. This sulfurization of the metal lines was prevented through passivation using a thin oxide layer (for example, 20 nm Al2O3 or SiO2) before the MoS2 growth. This ensured good metal conductivity and prevented potential shortages resulting from the fabrication of BEOL MoS2 transistors (Extended Data Fig. 5b–g). Figure 4a–d shows 

the fabrication process flow for BEOL integration of MoS2 transistors and the circuits on top of the silicon CMOS wafers. The process starts from the as-fabricated silicon CMOS wafers (Fig. 4a), followed by deposition of the passivation oxide layers and the direct growth of monolayer MoS2 (Fig. 4b). After the BEOL MoS2 transistors are fabricated (Fig. 4c), interconnects between the MoS2 transistors and silicon devices are formed to realize wafer-scale heterogeneous integration (Fig. 4d). 

Figure 4e,f demonstrates the transfer and output characteristics, respectively, of p-type and n-type silicon transistors fabricated at the MIT Lincoln Laboratory<sup>36</sup> before (blue curves) and after (red curves) the two elevated-temperature processes in BEOL MoS2 fabrication: MOCVD MoS2 growth and atomic layer deposition (ALD) for oxides. Only a slight shift in the threshold voltage can be observed: ~7 mV for the silicon p-type MOSFET (pMOSFET) and ~17 mV for the silicon n-type MOSFET (nMOSFET). In addition, the on-current density changes only slightly: a 0.15% increase for the pMOSFET and a 0.32% decrease for the nMOSFET. A major portion of these small changes may be due to variability during the device measurement rather than to the BEOL-integration process itself. Extended Data Figure 6a–f plots the typical measurement variability, from which a 20 mV shift in the threshold voltage and a 3% on-current variability can be observed within the same silicon transistor, even before the ALD process and the MoS2 growth. We also performed the direct growth of a monolayer MoS2 film on top of silicon CMOS circuits fabricated by a commercial foundry (Taiwan Semiconductor Manufacturing Company (TSMC)). Extended Data Figure 7 shows the performance of an 8-bit analogue–digital converter (ADC) circuit before (grey) and after (green) the MOCVD growth. A full-scale 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**460** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



<!-- Start of picture text -->
a Silicon BEOL circuit b Direct MOCVD growth c 2D transistor fabrication d Forming interconnects<br>e f 240 g 10 –3 h 400<br>10 –4 +0.15% –0.32%<br>120<br>10 –6 160 10 –5<br>80<br>10 –8 7 mV 17 mV 200<br>40 80 10 –7<br>10 –10<br>0 0 10 –9 0<br>–1.0 –0.5 0 0.5 1.0 –1.0 –0.5 0 0.5 1.0 –1 0 1 2 3 0 0.2 0.4 0.6<br>V GS (V) V DS (V) V GS (V) V DS (V)<br>i WL k l<br>V DD 0.5 1 0.6<br>0 –0.6<br>1 0.6<br>Q<br>MoS2 Q 0 0 –0.6<br>BL BL 1 0.6<br>0 –0.6<br>GND Silicon<br>j 1 3.0<br>GND Q V DD Q Q –0.5 0 –1.0<br>–0.5 0 0.5 0 2 4 6 8 10<br>BL WL BL VQ  (V) Time (s)<br> (A) I D A) ( I µD  (A) I D A) ( I µD<br>Q<br>Q<br> (V) VQ<br>BL Voltage (V)<br>WL<br><!-- End of picture text -->

**Fig. 4 | BEOL integration of MoS2 transistors with silicon transistors. a** – **d** , Schematics of the heterogeneous integration process, starting from the as-fabricated silicon CMOS sample ( **a** ), with passivation of the silicon sample by the deposition of Al2O3 (20 nm thick) and direct synthesis of the monolayer MoS2 film on top ( **b** ), the fabrication of MoS2 transistors and circuits ( **c** ) and connecting the MoS2 circuits to the silicon transistors and circuits ( **d** ). **e** , Transfer characteristics of the p- and n-type metal–oxide–semiconductor (p-MOS and n-MOS) silicon transistors before (blue curves) and after (red curves) the MOCVD growth, where the inset arrows show that the threshold voltage shift is around 7 mV for the pMOSFET and 17 mV for the nMOSFET after the MOCVD process. **f** , Output characteristics of the p-MOS and n-MOS silicon transistors before (blue curves) and after (red curves) the MOCVD process. The on-current of the pMOSFET changes by around 0.15%, and the on-current of the nMOSFET changes 

by around 0.32%. **g** , **h** , Transfer ( **g** ) and output ( **h** ) characteristics of the MoS2 transistor on top of the silicon CMOS sample for BEOL integration. For the transfer curves, _V_ DS = 1.2 V. For the output curves (shown in different colours), _V_ GS increases from 0 to 3 V with a step size of 0.5 V. **i** , Circuit schematics of the MoS2–silicon SRAM cell. The FEOL silicon devices and interconnects are marked in black. The BEOL MoS2 devices and interconnects are marked in yellow. WL, word line; BL, bit line; GND, ground; _V_ DD, operating voltage; _Q_ , value stored in the SRAM cell; Overbars, logic ‘NOT’ function. **j** , Optical microscopy image of the heterogeneously integrated MoS2–silicon SRAM circuit. Scale bar, 50 µm. **k** , Butterfly curves (fully overlapping on top of each other) of the silicon transistors inside the SRAM cell before (blue curve) and after (red curve) the MOCVD process and after BEOL fabrication (green curve). _V_ Q, voltage on node ‘Q’; _V_ Q̄ , voltage on node ‘̄Q’. **l** , The input and output waveforms of the MoS2–silicon SRAM. 

input sine wave of 15 kHz frequency was used in the measurements to ensure that the digital output can reach a maximum digital output code range. Other than the typical variability due to the multiple measurements, minimum change can be observed between the two samples, which highlights the minimal damage caused by our MoS2 growth method on fully fabricated commercial silicon chips. 

Finally, to demonstrate the BEOL integration further, we fabricated top-gate MoS2 transistors with a channel width of 342 µm and a channel length of 200 nm (Extended Data Fig. 6g) on top of the silicon CMOS circuits. These top-gated devices have a 10-nm-thick Al2O3 gate dielectric and gold (Au) source/drain contacts. The transfer and output curves of the BEOL MoS2 transistors are shown in Fig. 4g,h, respectively. A high on/off current ratio of up to 10<sup>6</sup> and a current density of around 3 µA µm<sup>−1</sup> is demonstrated. Using a large enough channel width, the total on-state current can reach 874 µA, which is comparable to the total current in the silicon transistors 

shown in Fig. 4e,f, making the static random access memory (SRAM) cell functional. We used this technology to demonstrate a MoS2– silicon BEOL integrated circuit. An SRAM-like silicon front-end-ofline (FEOL) circuit with two silicon nMOSFETs and two silicon pMOSFETs (black parts in Fig. 4i) was combined with two additional BEOL MoS2 transistors fabricated on top of the silicon FEOL circuit (yellow parts in Fig. 4i). Figure 4j shows an optical microscope image of the MoS2–silicon SRAM cell. Electrical measurements were carried out on the same silicon pMOSFET and silicon nMOSFET after the BEOL steps to ensure that there is no degradation of the FEOL circuit (Extended Data Fig. 6h,i). The butterfly curves of the SRAM-like silicon circuit before MoS2 growth (blue), after growth (red) and after fabrication (green) are shown in Fig. 4k. These fully overlapping curves demonstrate negligible changes. Figure 4l plots the input and output waveforms of the MoS2–silicon SRAM cell, confirming that the heterogeneous integration is successful. 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**461** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

### **Conclusions** 

In summary, we report here a silicon-CMOS-compatible, low-thermalbudget, 200-mm-platform MOCVD synthesis method for monolayer MoS2 films. This MOCVD system separates the low-temperature molybdenum-precursor-decomposition region from the hightemperature sulfur-precursor-decomposition region and enables the MoS2 to be grown in the low-temperature region. The synthesized MoS2 film shows a high material quality with few defect sites, a high field-effect mobility (~35.9 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ) and a good electrical performance. Outstanding material and electrical uniformity are demonstrated over 200-mm-diameter wafers. We also developed a silicon-CMOS-compatible BEOL-integration technology by growing a monolayer MoS2 film directly on silicon CMOS circuits, fabricating MoS2 transistors and connecting FEOL silicon circuits with BEOL MoS2 devices to realize a functional heterogeneously integrated MoS2–silicon SRAM circuit. This represents an alternative approach for material transfer. The seamless heterogeneous integration of state-of-the-art silicon CMOS circuits and BEOL MoS2 devices paves the way for future electronics with a higher integration density, more functionality and a vast new array of future applications. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41565-023-01375-6. 

### **References** 

1. Khan, H. N. et al. Science and research policy at the end of Moore’s law. _Nat. Electron._ **1** , 14–21 (2018). 

2. Li, M.-Y. et al. How 2D semiconductors could extend Moore’s law. _Nature_ **567** , 169–170 (2019). 

3. Hills, G. et al. Modern microprocessor built from complementary carbon nanotube transistors. _Nature_ **572** , 595–602 (2019). 

4. Wang, H. et al. Integrated circuits based on bilayer MoS2 transistors. _Nano Lett._ **12** , 4674–4680 (2012). 

5. Si, M. et al. Scaled indium oxide transistors fabricated using atomic layer deposition. _Nat. Electron._ **5** , 164–170 (2022). 

6. Manzeli, S. et al. 2D transition metal dichalcogenides. _Nat. Rev. Mater._ **2** , 17033 (2017). 

7. Lemme, M. C. et al. 2D material for future heterogeneous electronics. _Nat. Commun._ **13** , 1392 (2022). 

8. Zhang, X. et al. Two-dimensional MoS2-enabled flexible rectenna for Wi-Fi-band wireless energy harvesting. _Nature_ **566** , 368–372 (2019). 

9. Xue, M. et al. Integrated biosensor platform based on graphene transistor arrays for real-time high-accuracy ion sensing. _Nat. Commun._ **13** , 5064 (2022). 

10. Li, T. et al. Epitaxial growth of wafer-scale molybdenum disulfide semiconductor single crystals on sapphire. _Nat. Nanotechnol._ **16** , 1201–1207 (2021). 

11. Kang, K. et al. High-mobility three-atom-thick semiconducting films with wafer-scale homogeneity. _Nature_ **520** , 656–660 (2015). 

12. Yang, P. et al. Batch production of 6-inch uniform monolayer molybdenum disulfide catalyzed by sodium in glass. _Nat. Commun._ **9** , 979 (2018). 

13. Asselberghs, I. et al. Wafer-scale integration of double gated WS2-transistors in 300 mm Si CMOS fab. In _Proc. 2020 IEEE International Electron Devices Meeting (IEDM)_ 40.2.1–40.2.4 (IEEE, 2020); https://doi.org/10.1109/IEDM13553.2020.9371926 

14. O’Brien, K. P. et al. Advancing 2D monolayer CMOS through contact, channel and interface engineering. In _Proc. 2021 IEEE International Electron Devices Meeting (IEDM)_ 7.1.1–7.1.4 (IEEE, 2021); https://doi.org/10.1109/IEDM19574.2021.9720651 

15. Meng, W. et al. Three-dimensional monolithic micro-LED display driven by atomically thin transistor matrix. _Nat. Nanotechnol._ **16** , 1231–1236 (2021). 

16. Hwangbo, S. et al. Wafer-scale monolithic integration of full-colour micro-LED display using MoS2 transistor. _Nat. Nanotechnol._ **17** , 500–506 (2022). 

17. Koike, J., Hosseini, M., Hai, H. T., Ando, D. & Sutou, Y. Material innovation for MOL, BEOL, and 3D integration. In _Proc. 2017 IEEE International Electron Devices Meeting (IEDM)_ 32.3.1–32.3.4 (IEEE, 2017); https://doi.org/10.1109/ IEDM.2017.8268485 

18. Zhang, W. et al. High-gain phototransistors based on a CVD MoS2 monolayer. _Adv. Mater._ **25** , 3456–3461 (2013). 

19. Yim, C. et al. High-performance hybrid electronic devices from layered PtSe2 films grown at low Temperature. _ACS Nano_ **10** , 9550–9558 (2016). 

20. Park, J.-H. et al. Synthesis of high-performance monolayer molybdenum disulfide at low temperature. _Small Methods_ **5** , 2000720 (2021). 

21. Mun, J. et al. High-mobility MoS2 directly grown on polymer substrate with kinetics-controlled metal–organic chemical vapor deposition. _ACS Appl. Electron. Mater._ **1** , 608–616 (2019). 

22. Schaefer, C. M. et al. Carbon Incorporation in MOCVD of MoS2 thin films grown from an organosulfide precursor. _Chem. Mater._ **33** , 4474–4487 (2021). 

23. Cole-Hamilton, D. J. & Williams, J. O. (eds) _Mechanisms of Reactions of Organometallic Compounds with Surfaces_ (Plenum, 2014). 

24. Nam, H. & Shin, C. Impact of current flow shape in tapered (versus rectangular) FinFET on threshold voltage variation induced by work-function variation. _IEEE Trans. Electron. Devices_ **61** , 2007–2011 (2014). 

25. Zhang, C. et al. An accurate method to extract and separate interface and gate oxide traps by the MOSFET subthreshold current. In _Technical Proc. 2011 NSTI Nanotechnology Conference and Expo_ Vol. 2 (eds Laudon, M. & Romanowicz, B.) 180–183 (Nano Science and Technology Institute, CRC, 2011). 

26. Cheng, Z. et al. How to report and benchmark emerging field-effect transistors. _Nat. Electron._ **5** , 416–423 (2022). 

27. Bao, W. et al. High mobility ambipolar MoS2 field-effect transistors: substrate and dielectric effects. _Appl. Phys. Lett._ **102** , 042104 (2013). 

28. Illarionov, Y. Y. U. et al. Insulators for 2D nanoelectronics: the gap to bridge. _Nat. Commun._ **11** , 3385 (2020). 

29. Ma, N. & Jena, D. Charge scattering and mobility in atomically thin semiconductors. _Phys. Rev. X_ **4** , 011043 (2014). 

30. Yu, Z. et al. Realization of room-temperature phonon-limited carrier transport in monolayer MoS2 by dielectric and carrier screening. _Adv. Mater._ **28** , 547–552 (2016). 

31. Liu, X. et al. A modified wrinkle-free MoS2 film transfer method for large area high mobility field-effect transistor. _Nanotechnology_ **24** , 055707 (2020). 

32. Li, N. et al. Large-scale flexible and transparent electronics based on monolayer molybdenum disulfide field-effect transistors. _Nat. Electron._ **3** , 177–717 (2020). 

33. Sebastian, A. et al. Benchmarking monolayer MoS2 and WS2 field-effect transistors. _Nat. Commun._ **12** , 693 (2021). 

34. Seol, M. et al. High-throughput growth of wafer-scale monolayer transition metal dichalcogenide via vertical Ostwald ripening. _Adv. Mater._ **32** , 2003542 (2020). 

35. Kim, T. et al. Wafer-scale production of highly uniform two-dimensional MoS2 by metal–organic chemical vapor deposition. _Nanotechnology_ **28** , 18LT01 (2017). 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**462** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

36. Roy, A., Grossmann, P. J., Vitale, S. A. & Calhoun, B. H. A 1.3 µW, 5 pJ/cycle sub-threshold MSP430 processor in 90 nm xLP FDSOI for energy-efficient IoT applications. In _Proc. 2016 17th International Symposium on Quality Electronic Design (ISQED)_ 158–162 (IEEE, 2016); https://doi.org/10.1109/ISQED.2016.7479193 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

1Department of Electrical Engineering and Computer Science, Massachusetts Institute of Technology, Cambridge, MA, USA. 2Lincoln Laboratory, Massachusetts Institute of Technology, Lexington, MA, USA.<sup>3</sup> Computational Sciences and Engineering Division, Oak Ridge National Laboratory, Oak Ridge, TN, USA.<sup>4</sup> Ericsson Research, Ericsson AB, Gothenburg, Sweden.<sup>5</sup> These authors contributed equally: Jiadi Zhu, Ji-Hoon Park. e-mail: jingkong@mit.edu; tpalacios@mit.edu 

Nature Nanotechnology | Volume 18 | May 2023 | 456–463 

**463** 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

### **Methods** 

#### **Growth of monolayer MoS2 via the MOCVD method** 

The target substrate was placed vertically inside a 250 mm hot-wall tube furnace. Mo(CO)6 (98%, Sigma Aldrich) and (C2H5)2S (98%, Sigma Aldrich) are used as the precursors for molybdenum and sulfur, respectively. NaCl (Sigma Aldrich) was used as the seeding promoter to accelerate the lateral growth of the MoS2. NaCl (0.15 wt%) was dissolved in methanol and mixed with isopropyl alcohol (IPA) (3:7) at room temperature to make a saturated solution. NaCl/methanol–IPA solution (12.5 ml) was spin-coated onto the surface of the targeted 200 mm wafers at 3,000 revolutions per min. The flow rate of Mo(CO)6 was 120 sccm, which was regulated using individual mass flow controllers. A needle valve was used to control the partial pressure of (C2H5)2S to be around 25 mtorr. Argon (~900 sccm) was used as the carrier gas for a total flow rate of around 1,100 sccm. The chamber pressure was kept at ~255 mtorr during the growth process, with a base pressure ~40 mtorr. The centre temperature of the decomposition region (Region II) was set to be 800 °C to ensure full decomposition of the sulfur precursor, with the growth region (Region I) kept below 300 °C. The whole system was cooled to slightly above room temperature (~40 °C for Region I; and ~80 °C for Region II) before venting. The growth time is defined from the time the chamber temperature reaches the set point to the time the chamber temperature begins to decrease, and does not include the ramp-up and -down processes. We used 20 min for the ramp-up process and around 30 min for the ramp-down process. 

#### **Growth-temperature measurement** 

The growth temperature was measured using several type-K thermocouples (Perfect Prime). These type-K thermocouples were positioned at different places (in both axial and radial directions, with the support of quartz wafer boats and silicon wafers) inside the reaction chamber. Owing to the difficulty in sealing and pumping down the reaction chamber with the thermocouples inside, the furnace was heated under ambient conditions, while the temperatures in different regions were measured over time. The peak temperature in Region I was around 280 °C (with any overshoot for less than 5 min). The stabilized temperature in Region I was 275 °C. Good uniformity of the radial temperature distribution was confirmed, with a small temperature variation (±10 °C). The temperature of the outer surface of the 250 mm quartz tube in Region I was also measured using a type-K thermocouple (220 °C) and was double-checked using a portable infrared thermometer (230 °C). The substrate temperature during the growth was not measured directly, but can be expected to be lower than 275 °C since the stabilized outer surface temperature of the quartz tube during the actual growth process (vacuum chamber and with gas flow) was measured to be 210 °C (type-K thermocouple) and 215 °C (infrared thermometer). This is because (1) the cold precursor gas flow will take away heat from the growth region and (2) there will be only a minor contribution from heat-releasing oxidation processes (for example, oxidation of the carbon and organic residues) in the reaction chamber once it has been pumped down to a vacuum. 

#### **MoS2 transistor fabrication and electrical characterization** 

For back-gated MoS2 field-effect transistors, Al2O3 (20 nm) deposited via ALD on a heavily doped silicon substrate was used as the gate dielectric, while the substrate was used as the gate electrode. After growing a monolayer MoS2 film on top of the substrate, electron-beam lithography (EBL) and electron-beam (e-beam) evaporation (~3 × 10<sup>−6</sup> torr) followed by a lift-off process were used to pattern and deposit Au (50 nm thick) as the alignment markers. EBL and reactive-ion etching (RIE) using oxygen plasma were used to define the device area of interest. EBL and e-beam evaporation (~3 × 10<sup>−6</sup> torr) followed by a lift-off process were used to pattern and deposit Au (40 nm) as the source/ drain contacts. PMMA A2 (molecular weight 950,000) was spin-coated on top of the 200 mm wafer at 3,000 revolutions per min and 60 s as 

the passivation layer of the back-gated MoS2 transistors. The sample was heated at 180 °C for 3 min before the electrical measurements. 

For heterogeneous integration with silicon CMOS circuits, Al2O3 (20 nm) was deposited onto the silicon CMOS sample via ALD for passivation. A monolayer MoS2 film was deposited via MOCVD. EBL and RIE with oxygen plasma were used to define the device area of interest by removing the non-desired MoS2 from the substrate. EBL and e-beam evaporation (~3 × 10<sup>−6</sup> torr) followed by a lift-off process were used to pattern and deposit Au (25 nm) as the source/drain contacts and Au (60 nm) as the probing pads. An Al2O3 (10 nm) dielectric layer was then deposited at 250 °C as the top-gate dielectric using the ALD method. Subsequently, EBL, e-beam evaporation and a lift-off process were used to pattern and deposit a Au (60 nm) stack as the top-gate electrode. EBL and RIE with BCl4 and Cl2 were used to etch away the Al2O3 in the interconnect areas followed by oxygen-plasma cleaning and wet cleaning (acetone and IPA). EBL, e-beam evaporation (150 nm Au) and a lift-off process were used to connect the MoS2 transistors to the top-layer metal of the silicon circuits. 

All electrical measurements were carried out in air at room temperature using a semiconductor parameter analyzer (Agilent 4155C) and signal generators. A better electrical performance is expected if the vacuum level of the metal evaporation chamber can be improved. 

#### **Fabrication of silicon devices and circuits and their electrical characterization** 

The silicon transistors and SRAM-like circuits were fabricated by the MIT Lincoln Laboratory, with the top-layer metal being aluminium. The electrical measurements were carried out in air at room temperature using the semiconductor parameter analyzer (Agilent 4155C). The 8-bit silicon ADC was fabricated by TSMC using the standard 65 nm node silicon fabrication process. Al2O3 (20 nm) was deposited onto the CMOS chips via ALD for passivation. A monolayer MoS2 film was deposited via MOCVD. EBL and RIE with BCl4 and Cl2 were used to etch away the MoS2 and Al2O3 on the metal pads followed by oxygen-plasma cleaning and wet cleaning (acetone and IPA). The ADC was then wire-bonded to a QFN80 package. The electrical measurements were carried out under ambient conditions using a customized printed circuit board and measurement system. 

#### **Characterization of the morphology and structure** 

The morphology and structure of the as-grown MoS2 layers were characterized using a scanning electronic microscope (ZEISS GeminiSEM; 3 kV), a multipurpose transmission electron microscope (FEI Tecnai G2 Spirit TWIN; 120 kV) and a scanning transmission electron microscope (Titan Themis Z G3 Cs-Corrected S/TEM; 60 kV). 

Raman and PL spectra of the MOCVD-grown monolayer MoS2 films were collected using a confocal Raman microscope system (HORIBA LabRAM HR800) with an excitation wavelength of 532 nm. The Raman spectra were obtained at a laser power of 0.9 mW and an accumulation time of 5 s (using a grating of 1,800 grooves per mm). The PL spectra were obtained at a laser power of 0.9 mW and an accumulation time of 1 s (using a grating of 600 grooves per mm). To acquire the Raman and PL intensity maps, individual Raman and PL spectra (~330 data points) were first collected from the as-grown MoS2 film on an 200 mm wafer with a step size of 1 cm along both the _x_ and _y_ directions. Then the intensities of the A1g vibrational mode and the PL emission were extracted and mapped based on the respective collected Raman and PL datasets. 

The XPS spectra were obtained using an XPS instrument (PHI Versaprobe II) with a monochromatic Al Kα source (1,486.6 eV) and a spot size of 200 µm. A gun power of 50 W and an operation voltage of 15 kV were used during spectrum acquisition. During the measurements, the sample was flooded using electron and argon-ion guns to neutralize the charge on the surface. All the XPS spectra were calibrated using the C 1 _s_ peak at 284.8 eV. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

#### **Computational fluid dynamics simulations** 

The CFD simulations were performed using the OpenFOAM software<sup>37</sup> . During the modelling, an axis-symmetric cylindrical coordinate was used to model the MOCVD chamber. We followed the dimensions of the chamber used in the experiment. Only argon gas was considered in the CFD modelling because it is the main gas component (>80%). No chemical reaction was considered for this simplified simulation. 

The Peng–Robinson model<sup>38</sup> was used as the equation of state for the gas using previously derived parameters for argon<sup>39</sup> . We derived other parameters from the values of the NIST database<sup>40,41</sup> . Since the low-density flow is sensitive to the temperature ( _T_ ), the viscosity ( _µ_ ) and thermal conductivity ( _k_ ) are included as a linear function of temperature: 



<!-- Start of picture text -->
μ  = 4.7 × 10 −8 T  + 10 −5 (Pa s) (1)<br><!-- End of picture text -->



<!-- Start of picture text -->
k  = 3.7 × 10 −5 T  + 0.0076 (W m −1 K −1 ) . (2)<br><!-- End of picture text -->

The coefficients were fitted based on values from the temperature range of 300–1,000 K from the reference data. The specific heat capacity ( _C_ p) was set as 520.33 (J kg<sup>−1</sup> K<sup>−1</sup> ), and it does not depend on the temperature at the chamber pressure used. 

Instead of defining the parameters for the quartz and the air cooling of the cylinder, the experimentally measured temperature was used as the boundary conditions (Supplementary Note 1). Since we utilized the flow with an axis-symmetric coordinate, the diffuser was modelled with a three-ring structure. The SIMPLE (semi-implicit method for pressure-linked equations) algorithm<sup>42</sup> was used as the solution method for the Navier–Stokes equations, which is implemented as ‘rhoSimpleFoam’ in OpenFOAM to model the compressible flow in the simulations. The momentum, energy and pressure equations are iterated until a converged solution is reached, with the residuals of all equations reaching the order of 10<sup>−5</sup> (~5,000 steps). The density is updated after each iteration through its relation to the equation of state. It was challenging to obtain convergence for the simulations at low pressure. The pressure field tends to oscillate more between iterations for low-pressure simulations. Therefore, we gradually decreased the pressure in the simulation from one of high pressure (~3 kPa) to the experimental pressure (~31 Pa), using the solution from a higher-pressure simulation as the initial condition for the lower-pressure simulation. 

To understand the gas flow inside the CVD chamber, we first estimated the Reynolds number, Re. This provides insight into the fluid pattern and whether the gas flow is turbulent or laminar. The Reynolds number is defined as 



<!-- Start of picture text -->
Re = ρuL (3)<br>μ ,<br><!-- End of picture text -->

where _ρ_ is the density, _u_ is the flow speed, _L_ is the hole dimension and _µ_ is the dynamic viscosity. Owing to the low chamber pressure, the density of argon is very low (~10<sup>−4</sup> kg m<sup>−3</sup> ) and the hole has a short characteristic length (~10<sup>−3</sup> m). The estimated flow speed at the inlet hole is about 10<sup>0</sup> m s<sup>−1</sup> . We obtained a Reynolds number of ~10<sup>−2</sup> with a viscosity of ~10<sup>−5</sup> Pa s. This value is very small (≪1), so the argon flow is more likely to be laminar than turbulent. 

### **Data availability** 

All data are available in the paper and Supplementary Information. All materials are available on figshare at https://doi.org/10.6084/ m9.figshare.21761057 or upon request from T.P. 

38. Peng, D.-Y. & Robinson, D. B. A new two-constant equation of state. _Ind. Eng. Chem. Fundam._ **15** , 59–64 (1976). 

39. Tkaczuk, J. et al. Equations of state for the thermodynamic properties of binary mixtures for helium-4, neon, and argon. _J. Phys. Chem. Ref. Data_ **49** , 023101 (2020). 

40. Tegeler, C. et al. A new equation of state for argon covering the fluid region for temperatures from the melting line to 700 K at pressures up to 1000 MPa. _J. Phys. Chem. Ref. Data_ **28** , 779–850 (1999). 

41. Lemmon, E. W. & Jacobsen, R. T. Viscosity and thermal conductivity equations for nitrogen, oxygen, argon, and air. _Int. J. Thermophys._ **25** , 21–69 (2004). 

42. Darwish, M. & Moukalled, F. _The Finite Volume Method in Computational Fluid Dynamics: An Advanced Introduction with OpenFOAM_<sup>_®_</sup> _and Matlab_<sup>_®_</sup> (Springer, 2021). 

### **Acknowledgements** 

We thank C. Lin and A. Zubair for helpful discussions. We are also grateful for the assistance from Y. Shao, J.-H. Hsia, A. Yao, Y. Yang, A. Penn, D. Morales, Y. Hou, J. Moodera, J. Baylon, P. Kingsview, M. Hempel, G. Riggott and K. Broderick. This work was carried out in part through the use of MIT.nano’s facilities and with the support of the TSMC University Shuttle Program. J.Z., M.X. and T.P. are supported by the MIT-Army Institute for Soldier Nanotechnologies (W911NF13-D-0001), the NSF Center for Integrated Quantum Materials (grant DMR-1231319) and Ericsson AB. J.-H.P., J.W., Z.W. and J.K. acknowledge the support from the US Army Research Office MURI project under grant number W911NF-18-1-04320432 and the US Army Research Office through the Institute for Soldier Nanotechnologies at MIT, under cooperative agreement number W911NF-18-2-0048. T.Z. and X.Z. acknowledge the support from the US Department of Energy (DOE), Office of Science, Basic Energy Sciences under award DE-SC0020042. For authors from the MIT Lincoln Laboratory (S.A.V. and M.M.), this work is approved for public release. Distribution is unlimited. This material is based upon work supported by the Under Secretary of Defense for Research and Engineering under Air Force contract number FA8702-15-D-0001. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the Under Secretary of Defense for Research and Engineering. W.G. and G.S.J. acknowledge support by the Laboratory Directed Research and Development Program of Oak Ridge National Laboratory, managed by UT–Battelle, LLC, for the US DOE under contract DE-AC05-00OR22725 (Eugene P. Wigner Fellowship). This research used resources from the Compute and Data Environment for Science at the Oak Ridge National Laboratory, which is supported by the Office of Science of the US DOE under contract number DE-AC05-00OR22725. This manuscript has been authored by UT–Battelle, LLC, under contract number DE-AC05-00OR22725 with the US DOE. The United States Government retains and the publisher, by accepting the article for publication, acknowledges that the United States Government retains a non-exclusive, paid-up, irrevocable, world-wide license to publish or reproduce the published form of this manuscript, or allow others to do so, for United States Government purposes. The US DOE will provide public access to these results of federally sponsored research in accordance with the DOE Public Access Plan (http://energy.gov/ downloads/doe-public-access-plan). M.A. acknowledges the support from the MITRE Innovation Program, the NSF Graduate Research Fellowship Program (grant 1745302) and the MathWorks Engineering Fellowship. J.H. is supported by Ericsson AB. A.C. acknowledges the support from the MITRE Innovation Program and Ericsson AB. 

### **References** 

37. Weller, H. G. et al. A tensorial approach to computational continuum mechanics using object-oriented techniques. _Comput. Phys._ **12** , 620–631 (1998). 

### **Author contributions** 

T.P. and J.K. supervised the project. J.Z., T.P. and J.-H.P. conceived the experiments. J.Z. and J.-H.P. performed the material synthesis. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 

J.-H.P., T.Z. and Z.W. performed the material characterizations. J.Z. and J.-H.P. fabricated the MoS2 transistors. J.-H.P., J.Z. and J.W. designed the MOCVD system. J.Z., J.-H.P. and M.X. carried out the device measurements. S.A.V. and M.M. fabricated the silicon transistors and circuits. W.G. and G.S.J. designed the CFD models and contributed equally to the simulations. J.W. helped with the initial fluid dynamics simulations. M.A. carried out the ADC design and measurements. M.X., X.Z., J.H., A.C. and J.K. participated in data analysis. J.Z. wrote the paper. All authors read and revised the paper. 

### **Competing interests** 

J.Z., J.-H.P., J.W., J.K. and T.P. have applied for a provisional patent (application number, 63/398,331; filing date, 16 August 2022) related to the results presented in Figs. 1–4 and Extended Data Figs. 2,3,5–7. Formal patent pending. The other authors declare no competing interests. 

### **Additional information** 

**Extended data** is available for this paper at https://doi.org/10.1038/s41565-023-01375-6. 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41565-023-01375-6. 

**Correspondence and requests for materials** should be addressed to Jing Kong or Tomás Palacios. 

**Peer review information** _Nature Nanotechnology_ thanks Taesung Kim, Max Lemme and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 1 | Detailed Photographs of the custom MOCVD system. a** , Overview of the MOCVD system. From left to right are: 1) Controlling computer, 2) Mass flow controllers, precursors and gas inlet, 3) Reaction chamber, 4) Dry pump and vacuum gauge, 5) Stainless steel enclosure. **b** , 8-inch quartz wafer boat. To avoid potential blocking of the gas flow by the quartz 

wafer boat, we cut away the parts in the red rectangle. **c** , Picture of an 8” wafer vertically mounted to the adapted 8-inch quartz wafer boat. There is no blocking on the front side to ensure uniform MoS2 growth on the wafer. The dark color on the quartz wafer boat comes from the MoS2 accumulated during the deposition process. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 2 | MOCVD synthesis process of monolayer MoS2 film. a** , SEM image of MoS2 synthesized after 40 mins. **b** , SEM image of MoS2 synthesized after 55 mins. **c** , SEM image of MoS2 synthesized after 60 mins. The discrete flakes gradually merge into a continuous film with grain size around 200 nm. scale bar: 1 µm. **d** , Selective area electron diffraction (SAED) pattern of the synthesized monolayer MoS2 thin film, a polycrystalline structure can be observed. **e** , HR-STEM image of a region where two grains with different crystal orientation are merged. Good stitching between the grains can be observed. 

**f** , Fast Fourier transform (FFT) of ( **e** ). Two different set of single crystal MoS2 patterns are overlaid together. **g** , FFT of the region in the orange rectangle in ( **e** ), where two grains merged together. Two sets of single crystal MoS2 patterns can be observed. **h** , FFT of the region in the red rectangle in ( **e** ). Single crystal MoS2 pattern can be observed. **i** , FFT of the region in the green rectangle in ( **e** ). Single crystal MoS2 pattern can be observed. **j** , Raman spectrum of MOCVD-grown MoS2 under low growth temperature (~275 °C). 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 3 | Supplementary data for wafer scale uniformity. a** , Optical image of one back-gate MoS2 transistor on Al2O3/Si substrate. **b** , Hysteresis measurement of one of the MoS2 transistors with PMMA passivation. The gate voltage was swept from −2 V to 7 V (blue curve), and from 7 V to −2 V (red curve). The sweep speed is around 55 mV/sec with VDS = 0.7 V. The measurement was carried out in dark and ambient condition. **c** , Peak position mapping of the photoluminescence (PL) data over the 8-inch wafer. **d** , Integrated intensity mapping of the PL data over the 8-inch wafer. The color 

represents the integrated intensity of the peak from 1.82 eV to 1.90 eV photon energy. 100% refers to the highest integrated intensity of the monolayer MoS2 thin film measured over the 8-inch wafer. **e** , Optical image of the 8-inch wafer with fabricated MoS2 transistors. 300 nm SiO2/Si substrate was used as the global back gate structure. **f** , On-state resistance mapping of back-gated MoS2 transistors over 8-inch wafer. **g** , 4 MoS2 transistors which can represent the typical performance of transistors in the center region on 4 different 8” wafers. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 4 | Probability distribution functions (device counts) associated with the mapping data in Fig. 3 and Extended Data Fig. 3.** The red lines demonstrate the fitted Gaussian function based on the probability distribution. **a** , Peak position of photoluminescence (PL) measurement, **b** , Full width at half maximum (FWHM) of PL measurement, **c** , Integrated PL intensity. The gaussian fitting does not apply to this figure. **d** , Intensity of Raman A1g peak. 

**e** , FWHM of Raman E<sup>1</sup> 2g<sup>peak.</sup><sup>**f**, mobility extracted from “Y-function” method.</sup> **g** , Threshold voltage. **h** , minimum subthreshold swing extracted from transfer characteristics. **i** , On-state resistance. The Gaussian fitting does not apply to this figure as it is impacted by multiple factors, for example contact resistance, channel resistance, fabrication variations, etc. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 5 | Feasibility of BEOL integration with MoS2 on top of silicon. a** , Sulfurization of aluminum wires inside MOCVD chamber during the MoS2 growth process. Even at temperatures as low as 190<sup>°</sup> C, the sulfurization of aluminum wires still takes place, generating insulating aluminum sulfides which degrade the conductivity of the aluminum wire. **b** , SEM image of the as-fabricated silicon transistors (top-layer metal). **c** , SEM image of the silicon transistor after atomic layer deposition (ALD) passivation of 20 nm Al2O3. **d** , SEM image of the 

silicon transistor after MOCVD MoS2 growth. **e** , SEM image of the MoS2 flakes grown on the silicon CMOS sample (with 20 nm Al2O3 passivation) after 40 mins. The dark triangle-like flakes are monolayer MoS2 before coalescence. The squares are dummy top layer metals for the FEOL silicon circuits. **f** , resistance change of aluminum wires with and without Al2O3 passivation. **g** , resistance change of aluminum wires with SiO2 passivation (different thickness) and without passivation. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 6 | BEOL integration of MoS2 transistors with silicon transistors. a** , Transfer and **b** , output characteristics of the as-fabricated silicon devices (black curves) and after: ALD passivation of 20 nm Al2O3 (blue curves), MOCVD growth of monolayer MoS2 (red curves), and BEOL integration (green curves). **c** , MoS2 transistors with finger source/drain structures on silicon CMOS circuits before the top gate dielectric and gate terminal is formed. **d-i** , repeated measurements on one pMOSFET and one nMOSFET without the ALD and the MOCVD process to show the cycle-to-cycle variation caused by device 

measurements. **d** , Transfer characteristics of one silicon pMOSFET and one silicon nMOSFET during 10 consecutive measurements. **e** , Output characteristics of one silicon pMOSFET and one silicon nMOSFET during 10 consecutive measurements. **f** , Threshold voltage distribution of the silicon pMOSFET during the 10 measurements. **g** , Threshold voltage distribution of the silicon nMOSFET during the 10 measurements. **h** , On-current distribution of the silicon pMOSFET during the 10 measurements. **i** , On-current distribution of the silicon nMOSFET during the 10 measurements. 

Nature Nanotechnology 

**Article** 

https://doi.org/10.1038/s41565-023-01375-6 



**Extended Data Fig. 7 | MoS2 growth on top of a foundry fabricated 8-bit analog-digital converter (ADC). a** , 8-bit ADC performance before MOCVD growth. Sine wave with 1.07 V amplitude, 15 kHz frequency was used as the input signal. 10 digital output waveforms are collected and plotted. **b** , 8-bit ADC performance after the MOCVD growth. Same input signal is used. The output 

digital signals demonstrate same performance as the pre-grown samples. **c-e** , Comparison of the ( **c** ) lowest digital output, ( **d** ) highest digital output, and ( **e** ) total digital output range before (grey bars) and after (green bars) the MOCVD growth. 

Nature Nanotechnology 

