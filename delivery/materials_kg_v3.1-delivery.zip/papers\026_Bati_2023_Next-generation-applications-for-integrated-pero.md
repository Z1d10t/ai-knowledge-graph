# Next-generation applications for integrated perovskite solar cells

| 字段 | 内容 |
|---|---|
| 期刊 | Communications Materials |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 417 |
| 作者 | Abdulaziz S. R. Bati, Yu-Lin Zhong, P. Burn, M. Nazeeruddin, P. Shaw, Munkhbayar Batmunkh |
| DOI | 10.1038/s43246-022-00325-4 |
| 源文件 | 026_Bati_2023_Next-generation-applications-for-integrated-pero.pdf |

---


## REVIEW ARTICLE 



> https://doi.org/10.1038/s43246-022-00325-4 **OPEN** 

# Next-generation applications for integrated perovskite solar cells 

Abdulaziz S. R. Bati 1, Yu Lin Zhong 2, Paul L. Burn1, Mohammad Khaja Nazeeruddin<sup>3</sup> , Paul E. Shaw 1✉ & Munkhbayar Batmunkh 2✉ 

Organic/inorganic metal halide perovskites attract substantial attention as key materials for next-generation photovoltaic technologies due to their potential for low cost, high performance, and solution processability. The unique properties of perovskites and the rapid advances that have been made in solar cell performance have facilitated their integration into a broad range of practical applications, including tandem solar cells, building-integrated photovoltaics, space applications, integration with batteries and supercapacitors for energy storage systems, and photovoltaic-driven catalysis. In this Review, we outline notable achievements that have been made in these photovoltaic-integrated technologies. Outstanding challenges and future perspectives for the development of these fields and potential next-generation applications are discussed. 

ver the past decade, metal halide perovskites with the chemical structure ABX3 (A = methylammonium (MA), formamidinium (FA), or cesium (Cs); B = Pb, Sn; and OX = I<sup>−</sup> , Br<sup>−</sup> , or Cl<sup>−</sup> , or combinations thereof) have emerged as promising photovoltaic (PV) materials due to their extraordinary optical and electrical properties such as high absorption coefficients, low exciton binding energy, bandgap tunability, ambipolar transport characteristics, excellent charge-carrier mobilities, long charge-carrier lifetimes, long carrier diffusion lengths and high defect tolerance<sup>1–3</sup> . These remarkable properties have underpinned the rapid development of PV devices based on perovskite absorbers, which is illustrated by the improvement in power conversion efficiencies (PCEs) from 3.8% to 25.7%<sup>4</sup> . This significant advance in PV performance has placed perovskite solar cells (PSCs) in the front-of-line for realizing next-generation low-cost PV and integrated technologies. PSCs are slated to hold several advantages over established and emerging PV technologies. For instance, silicon solar cells require pure silicon, produced by heating sand at elevated temperatures (>1000 °C), have complicated manufacturing processes (e.g., texturing, anti-reflective coatings) that are usually carried out using special facilities, and greenhouse gases in their fabrication, all of which add to the fabrication cost. In contrast, perovskite materials can be solution processed, enabling low-embedded energy manufacturing using commercial coating technologies. Compared to silicon solar cells, some emerging solar cells, such as organic solar cells (OSCs), tend to be more cost-effective and wet-processable. However, efficient OSCs need to overcome some intrinsic properties such as low relative dielectric constants (2–4, meaning free charge carriers are not directly formed upon photoexcitation), low effective carrier mobility (10<sup>−5</sup> to 10<sup>−4</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> ), and low chargecarrier diffusion length at open circuit (≈20 nm)<sup>5</sup> . In contrast, PSCs exhibit a larger relative 

> 1 Centre for Organic Photonics & Electronics, School of Chemistry and Molecular Biosciences, The University of Queensland, St Lucia, Brisbane, QLD 4072, Australia.<sup>2</sup> Queensland Micro- and Nanotechnology Centre, School of Environment and Science, Griffith University Nathan, Brisbane, QLD 4111, Australia. 3 Group for Molecular Engineering of Functional Materials, Institute of Chemical Sciences and Engineering, École Polytechnique Fédérale de Lausanne (EPFL), CH-1951 Sion, Switzerland.<sup>✉</sup> email: p.shaw3@uq.edu.au; m.batmunkh@griffith.edu.au 

1 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

dielectric constant in the range of 20–50, more effective chargecarrier mobility of 0.1–10 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , and large charge-carrier diffusion length at open circuit (>500 nm)<sup>5</sup> . 

In general, PSCs are fabricated with a layered device structure that consists of a transparent conductive oxide (TCO), electron transporting layer (ETL), perovskite absorption layer, hole transporting layer (HTL), and a counter electrode. However, in common with cadmium-telluride thin-film solar cells, plans will need to be put in place to recover the heavy metals in perovskite solar cells. Furthermore, it is important to note that all solar types require encapsulation. Depending on the position of the charge-selective layer, PSCs can be classified as standard (n–i–p) or inverted (p–i–n) configurations<sup>6</sup> . The operational mechanism of PSCs can be described briefly as follows: upon light absorption, electron-hole pairs are generated in the perovskite layer, which are then extracted through the chargeselective HTL and ETL materials to the corresponding conductive electrodes<sup>7</sup> . 

Motivated by the unprecedented advancement in the PCEs of PSCs over the past few years, a relatively new and growing area of research has been recently explored where PSCs are utilized as an energy source for integrated systems such as energy conversion and storage devices. Although these research areas are still in their infancy, early activities in integrating PSCs into a wide range of applications have already shown significant promise. 

In this review, we explore the integration of state-of-the-art PSCs into a comprehensive range of next-generation applications, including tandem solar cells, building-integrated PVs (BIPVs), space applications, PV-powered batteries, supercapacitors, and energy sources for catalytic synthesis of high-value chemicals (Fig. 1). Finally, we present a brief outlook highlighting the challenges and future perspectives in this vibrant research field. 

### Tandem solar cells 

The PCEs of single-junction PSCs are approaching the maximum of 25.7% under one sun illumination. Further enhancing the PCE to the theoretical Shockley–Queisser limit (~33%), requires the thermalization of high-energy carriers and photon transmission losses to be reduced<sup>8</sup> . In order to minimize these energy losses and overcome the Shockley–Queisser limit for a single junction device, designing multiple junctions 

(tandem or greater solar cells) composed of a wide-bandgap absorber (top layer) and a low-bandgap absorber (bottom layer) have been proposed and implemented<sup>9</sup> . Such a device configuration allows absorption of the fraction of incident photons with energy higher than the wide-bandgap absorber, while the low energy photons pass through to the bottom subcell where they are harvested by the low-bandgap active layer<sup>10</sup> . There are two general structures for tandem devices—two-terminal (2 T, also called monolithic) and four-terminal (4 T) tandem solar cells (see Fig. 2). In the former, a single substrate is used to construct both subcells (stacked together with an interconnection layer) with a transparent front electrode and a nontransparent back electrode. In the latter case (4 T), two separate cells are fabricated individually and then physically connected together to form a full device. Due to the lower fabrication cost of the 2 T architecture (i.e., only two electrodes are involved and no extra external circuit is required) and the absence of a physical gap between the two connected subcells, which in turn reduces the optical loss, the 2T device configuration is more appealing for practical applications than the 4 T tandem structure<sup>10</sup> . Theoretical analysis has predicted that stacked cell configurations fabricated from two-junction (tandem) and three-junction architectures could achieve power conversion efficiencies as high as 42% and 49%, respectively. Furthermore, if an infinite number of solar cells could be stacked, then the upper limit efficiency can be further increased to reach 68% and 86% under unconcentrated and concentrated sunlight, respectively<sup>11</sup> . However, from a manufacturing perspective, the cost of fabricating multi-junction stacked devices increases significantly, which can outweigh the efficiency gains. It should be noted that there are several different classes of multijunction (tandem) solar cells including III–V semiconductor based devices<sup>12</sup> , but their commercialization pathways are limited due to their high production cost and complicated fabrication process. 

With their lower fabrication cost, low-temperature solution processability, roll-to-roll manufacturing, and wide-bandgap tunability, PSCs have the potential to become the candidate of choice for high-efficiency tandem solar cells<sup>13</sup> . Importantly, the ability to tailor the optical properties of the perovskite materials by tuning their chemical composition provides a means to optimize the light absorption for different device architectures, and 



Fig. 1 Schematic overview of the topics covered in this Review. The figure outlines the development of halide perovskite materials-based applications. 

2 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 2 Structures of the two most common tandem architectures. The figure shows two-terminal and four-terminal device configurations. It should be noted that in the literature, the positions of the top and bottom subcells are defined differently. In this Review, we define the top subcell as the cell in which the light initially passes through to the bottom subcell. 

hence perovskite materials can be potentially used to form either/ or the top and/or bottom subcells in a tandem device<sup>14</sup> . In addition to the tandem device structures made of perovskiteorganic or perovskite–perovskite subcells, the integration of a wide-bandgap perovskite with well-established low-bandgap materials such as Si and CIGS to build tandem solar cells is an attractive proposition and has received considerable attention from the PV community. In the following sub-sections, the major advancements that have been made in perovskite-based tandem solar cells will be discussed in detail. 

Perovskite/organic tandem solar cells. Organic solar cells (OSCs) are an attractive option for next-generation photovoltaics due to their low-cost, tunable optical properties, solution processability, mechanical flexibility and lightweight formfactors<sup>15</sup> . The best OSCs have now been reported to have PCEs of over 18%. Despite achieving high efficiencies, OSCs generally feature low Voc values (<1 V). To overcome this limiting factor, tandem devices comprising a wide-bandgap perovskite cell and a small optical gap organic cell have promise. In addition to improving the device performance, the hydrophobic nature of the organic layers can potentially play a role in stabilizing the perovskite subcell, which is particularly sensitive to moisture. Another distinct advantage of perovskite/organic tandem solar cells is that the absorbing layers can be deposited from orthogonal solvents, which ensures that the coating of the organic layer on top of the perovskite layer does not cause the underlying layer to dissolve. Thus, these types of tandem devices can in principle be fabricated as all-solution-processed tandem devices, which are compatible with large-scale roll-to-roll production coating techniques. 

Yang and colleagues pioneered 2 T perovskite/organic tandem devices, which were found to have a PCE of 10.2% and an Voc of 1.52 V. The tandem device used CH3NH3PbI3 (MAPbI3) as the perovskite absorber and an IR-sensitive block copolymer PBSeDTEG8:fullerene blend as the organic semiconductor absorber<sup>16</sup> . Although this work was the first demonstration of integrating perovskite and organic semiconductor polymer subcells into a tandem structure, a number of challenges remain. To avoid damaging the polymer subcell underneath during the fabrication of the upper perovskite subcell (i.e., during thermal 

annealing and chemical treatment), Liu et al.<sup>17</sup> inverted the order of the layers in the tandem device structure by employing a very thin MAPbI3 layer (~90 nm) as the top subcell and an organic layer as the bottom subcell. The resulting tandem devices exhibited a PCE of 16% and an Voc of 1.63 V, with the PCE being higher than a single-junction perovskite device assembled with an identical perovskite layer thickness (9.1%) and the single-junction organic device (9.7%). By adopting the FA0.8MA0.02Cs0.18PbI1.8Br1.2 perovskite with a wide-bandgap of 1.77 eV as the top subcell and a PBDBT-2F:Y6:PC71BM blend with a small optical gap of 1.41 eV as the bottom subcell, Yang and co-workers were able to fabricate 2 T perovskite/organic tandem solar cells that delivered a PCE of 20.6% and an Voc of 1.90 V (Fig. 3a, b)<sup>18</sup> . It was also shown that the perovskite subcell acted as a UV filter eliminating the UV sensitivity of the organic subcell, leading to enhanced photostability of the tandem device. Based on the semi-empirical device model developed in this study, perovskite/organic tandem solar cells were predicted to be able to achieve PCEs exceeding 30%, although at this time these have yet to be realized. 

The inorganic large-bandgap CsPbI2Br perovskite has also been demonstrated to be an excellent candidate for integration with organic subcells due to its superior UV and high thermal stability<sup>19,20</sup> . Wang et al.<sup>10</sup> demonstrated that a hole transporting material (HTM) in the interconnecting layers was essential for monolithic perovskite/ organic tandem solar cells to reduce the charge accumulation at the interface, and therefore minimize the voltage loss. By employing the wide-bandgap CsPbI2Br as the top subcell, the narrow-optical gap PM6:Y6-BO blend as the bottom subcell, and a 4-butyl-N,Ndiphenylaniline homopolymer (polyTPD) as the HTL in the interconnecting layer, a tandem device was found to achieve a PCE of 21.1% and a Voc of 1.96 V. Notably, the full name of the PM6 polymer is poly[(4,8-bis{5-[2-ethylhexyl]-4-fluoro-2-thienyl}] benzo[1,2-b:4,5-b′]dithiophene-2,6-diyl)-2,5-thiophenediyl(5,7bis{2-ethylhexyl}-4,8-dioxo-4H,8H-benzo[1,2-c:4,5-c′]dithiophene1,3-diyl)-2,5-thiophenediyl], while that of Y6-BO is defined as 2,2′[(2Z,2′Z)-({12,13-bis[2-butyloctyl]-3,9-diundecyl-12,13-dihydro[1,2,5]thiadiazolo[3,4-e]thieno[2″,3′:4′,5′]thieno[2′,3′:4,5]pyrrolo[3,2g]thieno[2′,3′:4,5]thieno[3,2-b]indole-2,10-diyl}bis{methanylylidene})bis(5,6-difluoro-3-oxo-2,3-dihydro-1H-indene-2,1-diylidene)] dimalononitrile. The energy diagram of the tandem device is depicted 

3 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 3 Device engineering of perovskite-based tandem solar cells. a Tandem cell structure highlighting the interconnection layer (ICL) design. b Simulated distribution of photon absorption in tandem cells using the transfer matrix method. a, b adapted with permission from ref.<sup>18</sup> , Copyright 2020 Elsevier Inc. c Energy-level diagram of an inorganic perovskite/organic tandem solar cell (TSCs). c adapted with permission from ref.<sup>10</sup> , Copyright 2021 American Chemical Society. d Schematic illustration of the trimethylammonium chloride (TACl) and IPA synergistically induced surface reconstruction (SR) processes. d adapted with permission from ref.<sup>21</sup> , Copyright 2021 Wiley-VCH. e EQE spectra of a NiOx/PTAA tandem device measured for the individual subcells and the total reflection ® spectra depicted as 1-R. Perovskite, CIGSe, and 1-R spectra are denoted with red, blue, and gray lines and areas. Integrated photocurrents and reflection losses from the EQE and 1-R spectra values are also shown. e adapted with permission from ref.<sup>30</sup> , Copyright 2019 American Chemical Society. f J–V curve of a monolithic CIGSe/perovskite-tandem solar cell (active area of 1.034 cm<sup>2</sup> ), with MeO-2PACz2PACz as a holeselective contact (HSC) that is used to conformally cover the rough CIGSe bottom cell. The orange circle indicates the MPP at a PCE of 23.3% PCE. Inset: SEM image of the cross-section of a representative tandem device. f adapted with permission from ref.<sup>31</sup> , Copyright 2019 Royal Society of Chemistry. g Cross-sectional scanning electron micrograph of an all-perovskite tandem. g adapted with permission from ref.<sup>35</sup> , Copyright 2019 Elsevier Inc. h J–V curves of the current champion all-perovskite-tandem solar cells (all-PTSCs) fabricated with a formamidine sulfinic acid additive scanned in the reverse and forward directions. i Continuous MPP tracking of encapsulated all-PTSCs over a period of 500 h under 1 Sun (100 mW cm<sup>−2</sup> ) light illumination without an ultraviolet filter in ambient air with a humidity of 30–50%. (h, i) adapted with permission from ref.<sup>36</sup> Copyright 2020 Springer Nature. j, k SEM images of perovskite films prepared (j) without and (k) with 7% of a GuaSCN additive. j, k adapted with permission from ref.<sup>37</sup> , Copyright 2019 American Association for the Advancement of Science. 

in Fig. 3c. At around the same time, Li and co-workers reported a PCE of 21.0% using a 2 T perovskite/organic tandem solar cell with a Voc of 2.05 V<sup>21</sup> . Their strategy relied on passivating the defects of CsPbI1.8Br1.2 perovskite surface using trimethylammonium chloride (Fig. 3d), which resulted in the growth of high-quality pinhole-free perovskite films and the suppression of surface nonradiative charge recombination. Importantly, those devices showed enhanced operational and UV stability relative to the individual subcells. Despite the progress made over the past several years, the PV performance of perovskite/organic tandem solar cells is still far from the maximum potential efficiency. The main limitations in this class of tandem devices are thought to be the Voc loss from wide-bandgap perovskite subcells and the non-ideal interconnecting layers. Chen et al.<sup>22</sup> employed a nickel oxide (NiOx) based HTL in combination with benzylphosphonic acid to suppress the interfacial recombination within the devices, and achieved a Voc of 1.26 V for the 1.79-eV- 

bandgap perovskite subcell. The authors also developed an interconnecting layer structure comprising a 4-nm-thick sputtered indium zinc oxide layer, which provided enhanced electrical properties and transmittance in the near-infrared region (NIR). These improvements resulted in perovskite/organic tandem solar cells with maximum and certified PCEs of 23.6% and 22.95%, respectively. This work demonstrates that there are further opportunities to enhance the PV performance of perovskite/organic based systems. 

Recently, the emergence of non-fullerene acceptors (NFAs) with their facile synthetic routes and wide energy-level adjustment enabled the fabrication of OSCs with a significant reduction in Voc loss<sup>23,24</sup> . With the recent advances in developing novel NFAs, single-junction OSCs with a certified PCE of 19.2% have been reported. This large performance enhancement is beneficial for more efficient perovskite/organic devices. In a recent study, 

4 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

Brinkmann et al.<sup>25</sup> demonstrated perovskite–organic tandem solar cells with a certified PCE of 23.1% and a high Voc of 2.15 V based on a Y6-containing ternary system for the OSC component. We anticipate that with the continuous significant advances in OSCs subcells, more efficient tandem devices will be achieved. Future studies on perovskite/organic tandem solar cells should focus on developing narrow-optical gap organic semiconductors with excellent environmental stability and suppressing phase segregation in wide-bandgap perovskites. 

Perovskite/CIGS tandem solar cells. Polycrystalline thin-film copper indium gallium selenide (CIGS) based solar cells are wellestablished and commercially available. The record efficiency of single-junction CIGS solar cells has reached 23.4%, which makes this class of solar cells very attractive for integration into perovskite containing tandem solar cells<sup>26</sup> . CIGS-based absorbers have an adjustable direct bandgap that can be tuned to 1 eV<sup>27</sup> , and high absorption coefficient of around 10<sup>5</sup> cm<sup>−1</sup> . The latter property means that it is possible to significantly reduce the absorber thicknesses required, and hence the costs associated with fabricating tandem devices<sup>28</sup> . 

The first 2 T perovskite/CIGS tandem solar cells were reported by Todorov et al.<sup>29</sup> in 2015, and these device had a maximum PCE of 10.9% and an Voc of 1.45 V, although it should be noted that the PCE was lower than the efficiencies of the individual subcells. This reduced efficiency was ascribed to the optical losses resulting from the top Al electrode and the high series resistance in the device. Furthermore, the high surface roughness of CIGS layers represents a major obstacle for obtaining high-quality and uniform perovskite films when they are deposited on top of the CIGS layer. In addition, the high surface roughness can significantly increase the probability of device shunting. Various strategies have been developed to fabricate a smoother CIGSbased bottom subcell surface. For instance, Albrecht and coworkers found that the deposition of dual p-type HTLs consisting of atomic layer deposited NiOx and spin-coated PTAA on a rough CIGS bottom subcell not only prevented device shunting, but also improved the performance of the monolithic perovskite/ CIGSe tandem solar cells<sup>30</sup> . Using this approach, a device with an active area of 0.78 cm<sup>2</sup> yielded a PCE of 21.6%. Despite the good PCE, the recorded photocurrent showed a large mismatch between the two subcells, which was attributed to the parasitic absorption and the rough interfaces of the device (Fig. 3e). In 2019, the same group demonstrated how employing a selfassembled monolayer (SAM) that binds to the oxide layer of the CIGS rough surface could boost the PCE of monolithic perovskite/CIGS tandem solar cells. The devices had a larger active area of 1.03 cm<sup>2</sup> and a PCE of 23.3% (Fig. 3f)<sup>31</sup> . It was proposed that the SAM forms an energetically favorable interface with the perovskite, acting as an efficient hole-selective contact without introducing nonradiative losses. Considering the negligible amount of SAMs required for device fabrication, SAMs and other surface passivators may be a realistic and cost-effective strategy to realize high efficiency and low-cost PV technologies. It should be noted that MiaSolé Hi-Tech and the European Solliance Solar Research (Solliance) have announced the development of perovskite/CIGS tandem solar cells with a record efficiency of 26.5%. However, the exact details of their discovery are still unknown<sup>32</sup> . 

Very recently, Jošt et al.<sup>33</sup> reported monolithic perovskite/CIGS tandem solar cells with a certified PCE of 24.2% utilizing a large bandgap perovskite (1.68 eV) containing a PEAI additive, Me4PACz monolayer as the HTM, and a LiF interlayer. This work demonstrates the high potential of perovskite/CIGS tandem solar cells. 

Perovskite/perovskite-tandem solar cells. All-perovskite-tandem solar cells (all-PTSCs) are also attractive although there are challenges that need to be addressed. In an all-PTSC, a widebandgap perovskite (~1.7 eV) and a narrow-bandgap (~1 eV) perovskite are required as the top and bottom subcells, respectively. In a single-junction configuration, PSCs are typically fabricated with a bandgap of 1.5–1.7 eV (e.g., MAPbI3), which meets the requirement for the wide-bandgap subcell. However, obtaining a narrow-bandgap perovskite is challenging and usually requires the partial replacement of Pb<sup>2+</sup> with Sn<sup>2+</sup> . This substitution creates several undesirable issues, which include the tendency of Sn<sup>2+</sup> to oxidize to Sn<sup>4+</sup> resulting in pinholes and/or a non-uniform perovskite surface with high defect density, both of which are detrimental to device performance. When compared with pure Pb-based perovskites, Sn-containing perovskites suffer from a shorter carrier lifetime and diffusion length, and small near-infrared absorption coefficient, which means that the perovskite film thickness needs to be increased to ensure that the long wavelength light is sufficiently absorbed<sup>34</sup> . 

Despite the aforementioned obstacles, advances in efficiency of all-PTSCs have been achieved. It is worth mentioning at this stage that the solution-processed fabrication of 2 T all-PTSCs represents a challenge as the deposition of the top subcell can easily dissolve/damage the bottom subcell given the materials are often soluble in the same processing solvents. Hence, an interconnecting layer with orthogonal solubility between the subcells can play and important role in protecting the bottom perovskite layer. In 2019, Palmstrom et al.<sup>35</sup> reported an effective surface treatment of a C60 interconnecting layer using a 1 nm thick poly(ethylenimine) ethoxylated (PEIE) layer and an atomic layer deposited aluminum zinc oxide (AZO) film (Fig. 3g). The incorporation of the PEIE improved the nucleation of the AZO and also protected the modified layer from damage by water or N,N-dimethylformamide (DMF). Using this strategy, 2 T all-PTSCs with PCEs of 23.1% and 21.3% on rigid and flexible substrates, respectively, were obtained. This work not only demonstrates that efficient allPTSCs can be formed, but that they can be lightweight and have a flexible form factor. 

To inhibit the oxidation of Sn<sup>2+</sup> and passivate the defects on the mixed Pb–Sn perovskite surface, Xiao et al.<sup>36</sup> incorporated zwitterionic antioxidant additives, achieving an excellent PCE of 25.6% for a 2 T all-PTSC with an active area of 0.049 cm<sup>2</sup> (Fig. 3h). The encapsulated devices showed good operational stability at the maximum power point (MPP), preserving 88% of their initial PCEs after 500 h of continuous illumination at a temperature of 54-60 °C under ambient atmosphere (Fig. 3i). Although this all-PTSC fabricated with antioxidant additives exhibited promising operational stabilities, the longer-term stability of these devices is yet to be determined. Tong et al.<sup>37</sup> integrated guanidinium thiocyanate (GuaSCN) into the perovskite films in order to reduce the density of defects and improve the carrier lifetime and diffusion lengths. The SEM images of the perovskite films with and without GuaSCN additive shown in Fig. 3j, k reveal the structural changes in the perovskite film. The use of GuaSCN has led to the current record PCE of 25.4% for a 4 T all-PTSC configuration, as well as an efficiency of 23.1% for a 2 T all-PTSC. Lin et al.<sup>38</sup> were able to fabricate a thick Pb–Sn mixed perovskite subcell (1.2 μm) with the aim of increasing the photocurrent in monolithic all-perovskitetandem solar cells. In order to reduce losses associated with the short carrier diffusion length relative to the perovskite film thickness, the Pb–Sn perovskites were passivated using 4-trifluoromethylphenylammonium (CF3-PA), resulting in a significant increase in the carrier diffusion length which exceeded 5 μm. Using this strategy, the authors fabricated all-perovskitetandem solar cells with a certified PCE of 26.4% that maintained over 90% of the initial PCE after 600 h under illumination at the 

5 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

maximum power point in an ambient environment. It is worth mentioning that a monolithic perovskite–perovskite–silicon based triple-junction tandem solar cell with an efficiency of over 20%, a Voc of 2.74 V, and a FF of 86% was recently demonstrated<sup>39</sup> . However, to compensate for the increased cost of such a complicated device structure, the PCEs would need to increase further. 

Perovskite/silicon tandem solar cells. With a large market share of more than 90%, low fabrication cost, suitable bandgap, exceptional performance, and life span of over 20 years, Si solar cells are the most mature candidate to combine with PSCs in a tandem device. Indeed, the integration of PSCs with silicon cells to form tandem devices has provided a great opportunity to realize highefficiency PV systems<sup>40,41</sup> . One of the challenges in the development of perovskite/silicon tandem solar cells (PSTSCs) is the requirement for transparent and conductive electrodes to allow for the transmittance of the near-infrared (NIR) part of the incident light through the semitransparent perovskite top subcell to the bottom Si subcell. Typically, transparent conducting oxides (TCOs) such as indium tin oxide (ITO) are employed as the electrode of the semitransparent perovskite cell. This is problematic as the electrode material needs to be deposited directly onto the perovskite, for example, via magnetron sputtering in the case of ITO, which can degrade the quality of the underlying perovskite layer. To address this issue, a buffer layer can be inserted to protect the perovskite, although this adds complexity to the fabrication process. As such, a wide range of semitransparent electrodes made from different materials have been explored, such as silver nanowires, for their suitability for PSTSCs<sup>42</sup> . Recently, Wang et al.<sup>43</sup> employed a thermally evaporated semitransparent electrode composed of a MoO3/Au/MoO3 multilayer for the perovskite subcell. The champion 4 T perovskite/Si tandem device using this transparent conducting electrode exhibited a PCE of 27%, which was higher than that of the individual subcells. 

The interconnection layer (ICL) within the 2 T tandem configuration plays an important role in optically and electrically connecting the top and bottom subcells and facilitates the balanced recombination of photogenerated carriers to ensure the flow of current throughout the entire tandem device. Under operation, the overall photocurrent of the 2 T tandem structure relies on matching the photocurrent of both subcells and is limited by the subcell with the lower current. In this regard, the ICL acts as a recombination site to facilitate the current flow and inhibit the formation of a p–n junction. Moreover, the quality of the ICL directly impacts the Voc, as the incorporation of a poorly performing ICL can lead to the accumulation of charge carriers at both ICL interfaces, introducing a reverse electric field that reduces the overall output voltage. Therefore, optimizing the properties of the ICL such as transmittance, thickness, resistivity, and refractive index is very important<sup>44</sup> . In 2015, Mailoa et al.<sup>45</sup> were the first to report 2 T PSTSCs employing a n<sup>++</sup> /p<sup>++</sup> Si tunnel junction between the Si bottom subcell and the perovskite top subcell, delivering a PCE of 13.7%. Since this study, the development of efficient ICLs has become the focus of many research groups leading to the creation of several effective ICLs materials, including ITO<sup>46</sup> . Recently, Mazzarella et al.<sup>47</sup> described an interlayer consisting of nanocrystalline silicon oxide between the perovskite and Si subcells to reduce the infrared reflection losses. After optimizing the thickness and refractive index of the interlayer by varying the oxygen content, 2 T PSTSCs with a certified PCE of 25.2% were obtained. Despite this promising PCE, the performance of this tandem device was limited by the bottom Si cell, which had a slightly lower current density (Jsc) 

(18.8 mA cm<sup>−2</sup> ) than the top perovskite cell (19.9 mA cm<sup>−2</sup> ), as determined from the EQE spectrum. Therefore, it is reasonable to expect further enhancements in the PV performance of this class of tandem device by matching the Jsc values for both the bottom and top subcells. 

Enhancing the hole extraction process and minimizing nonradiative recombination at the HTL interface with the perovskite is also important for improving the performance of PSTSCs. AlAshouri et al.<sup>48</sup> showed that a HTL composed of the SAM with methyl group substitution [4-(3,6-dimethyl-9H-carbazol-9-yl) butyl]phosphonic acid Me-4PACz in conjunction with a p–i–n perovskite subcell can significantly enhance the hole extraction and transporting efficiency. This strategy has led to the current world record certified PCE of 29.15% for a 2 T PSTSC (Fig. 4a, b). In addition to the p–i–n configuration for the perovskite subcell, improving the charge-selective layers for the n–i–p architecture is also of great interest<sup>49</sup> . The strategy of incorporating 2D with a 3D perovskite to improve stability has attracted a lot of interest. Duong et al.<sup>50</sup> designed a 2D/3D mixed perovskite system by coating n- butylammonium bromide onto the surface of a 3D perovskite, which improved the charge-carrier lifetime and PV performance (PCE of 27.7%) and lifetime. It is worth noting that the surface passivation of the perovskite film has also been reported for the p–i–n PCSs device structure by Isikgor et al.<sup>51</sup> , who showed that incorporating phenformin hydrochloride (PhenHCl) into the perovskite solution can passivate the perovskite surface and suppress light-induced phase segregation (Fig. 4c). The authors of this work were able to increase the Voc of the perovskite cells by 100 mV as compared to the control device and achieved a maximum PCE of 27.4% for their 2 T PSTSCs. Importantly, the fabricated devices showed no Voc losses after thermal aging at 85 °C for 3000 h in a nitrogen atmosphere. This stability is promising for the development of high efficiency and stable tandem cells, which is currently the key challenge for their commercialization. In a separate study, a thermally evaporated CsBr thin-layer was used between the perovskite and HTL, which led to the development of fully-textured PSTSCs with a PCE of 27.48%. The unencapsulated CsBr based device stored in the dark inside a N2-filled glove box showed excellent stability for over 10,000 h maintaining about 95% of its initial PCE as compared to only 74% for the control device without the CsBr (Fig. 4d, e)<sup>52</sup> . 

Depositing a perovskite layer onto fully-textured Si bottom cells provides a strategy to improve light trapping and reduce the cost of single-side textured Si wafers (i.e., the cost associated with polishing the front side of the Si wafers and the additional requirement for antireflection foils), which is the commonly used configuration with 2 T PSTSCs<sup>53</sup> . However, obtaining high-quality perovskite films with full coverage on a rough surface while avoiding electrical shunting is challenging. In order to achieve compact micrometer-thick perovskite films with full coverage on the Si pyramids, Hou et al.<sup>53</sup> proposed spin-coating a concentrated perovskite precursor solution followed by passivation of the perovskite surface using 1-butanethiol (Fig. 4f). The corresponding monolithic 2 T PSTSCs achieved a certified PCE of 25.7%, and had excellent thermal and operational stability under MPP tracking over 400 h of testing. In addition to this strategy, deposition of perovskite films on textured Si with full coverage by blade coating has been demonstrated<sup>54</sup> , which paves the way for highthroughput commercial-scale production of PSTSCs. Very recently, an exceptional PCE of 29.2% for a 4 T PSTSCs was reported in the popular literature<sup>55</sup> . However, while the exact device structure and the full experimental details were not described, it demonstrates that it may be possible to reach the 30% PCE milestone, which would catalyze the potential commercialization of tandem devices. 

6 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 4 The development of perovskite/silicon tandem solar cells and other emerging perovskite-based tandem devices. a Schematic illustration for the layered structure of a monolithic perovskite/silicon tandem solar cell. b Certified J–V curve measured at the Fraunhofer ISE, including the MPP value and the device parameters (red), in comparison to a tandem cell with PTAA (gray) as the HTL measured in-house. a, b adapted with permission from ref.<sup>48</sup> , Copyright 2020 American Association for the Advancement of Science. c Illustration of the p–i–n device structure, grain boundary passivation (GBP) and top surface passivation (TSP) strategies, and the molecular structure of the PhenHCl passivation molecule used in the study. c adapted with permission from ref.<sup>51</sup> , Copyright 2021 Elsevier Inc. d, e Comparison of the original efficiency of the PSTSC device stored in a nitrogen atmosphere (d) without CsBr after 8760 h and (e) with CsBr after 10488 h. d, e adapted with permission from ref.<sup>52</sup> , Copyright 2021 Wiley-VCH. f Cross-sectional SEM images of a textured c-Si with an average pyramid size of 2 μm (top) and corresponding substrates covered by solution-processed perovskite crystals (bottom). f adapted with permission from ref.<sup>53</sup> , Copyright 2020 American Association for the Advancement of Science. g Device architecture of a perovskite/ CZTSSe tandem solar cell. h J–V curves of various types of the sub- and tandem cells based on a perovskite and CZTSSe. g, h adapted with permission from ref.<sup>59</sup> , Copyright 2022 Wiley-VCH. 

Other emerging perovskite-based tandem solar cells. In addition to the above-mentioned perovskite-based tandem solar cells, there have been other approaches to perovskite-tandem cells employing emerging photovoltaic materials. These include combinations such as perovskite/CZTSSe, perovskite/colloidal quantum dots (QDs), and perovskite/CdTe. The application of Cu2ZnSn(S,Se)4 (CZTSSe) as the bottom subcell in perovskite-based tandem solar cells holds specific promise relative to the use of CIGS due to its low-cost, high abundancy of the chemical components, excellent absorption coefficient across the visible wavelengths, solution processibility, and the fact that it has a tunable bandgap<sup>56</sup> . Despite the lower reported efficiencies of earlier perovskite/CZTSSe tandem devices (<17%)<sup>57,58</sup> , significant progress in their PV performances continues to be made. For example, Wang et al.<sup>59</sup> showed that a 1.66 eV semitransparent perovskite top subcell and a 1.1 eV CZTSSe bottom subcell can form a 4 T tandem device with a PCE of 22.27% (Fig. 4g). It should be noted that in these devices the light absorption of the bottom cell is limited as it is filtered by the semitransparent perovskite film. As shown in Fig. 4h, the Jsc of the CZTSSe bottom subcell decreased from 35.24 mA cm<sup>−2</sup> (single-junction) to 15.43 mA cm<sup>−2</sup> , while the perovskite top subcell had a much higher Jsc (18.82 mA cm<sup>−2</sup> ). 

The absorption properties of colloidal quantum dots (CQDs) can be manipulated through control of their size, and this alongside their low-cost and solution processibility makes them excellent candidates for bottom subcells of tandem applications. Although the efficiency of perovskite/CQDs tandem devices is far from the theoretically estimated value of 43%<sup>60</sup> , recent studies 

have already demonstrated their feasibility. Chen et al.<sup>61</sup> reported that integrating PbS CQDs with non-fullerene acceptors (NFA) to complement the CQD absorption and connecting this bottom hybrid subcell with a semitransparent perovskite top subcell could give 4 T tandem devices with a PCE of 24%. Recently, Tavakoli et al.<sup>62</sup> employed surface passivation to reduce the surface defects of PbS QDs and ZnO nanowires (used in the ETL) with CdCl2 and SnO2, respectively. After optimizing the thickness and matching the current density of both subcells, 2 T and 4 T tandem perovskite/PbS QDs devices with PCEs of 17.1% and 21.1%, respectively were obtained. The 2 T tandem device showed excellent stability when tested at MPP under continuous light illumination in a nitrogen environment maintaining 94% of its initial PCE. Furthermore, no changes in the PCE were observed when exposing the device to a high RH of 65% over 72 days as compared to 37% efficiency loss observed with the single junction PSC device, which further highlights the important role of PbS QDs in protecting the perovskite from degradation under high humidity conditions. 

Cadmium-telluride (CdTe) solar cells are currently among the most successful low-cost thin-film technology in the PV market with an installed capacity of over 25 GW<sup>63</sup> . The certified record PCE of a CdTe cell is 22.1%<sup>4</sup> . The bandgap of CdTe is ~1.5 eV, which makes them unsuitable to be used with the conventional wide-bandgap perovskites. However, the bandgap of CdTe can be reduced to 1.36 eV when doped with selenium<sup>64</sup> . Nevertheless, this bandgap is too wide to be used as the bottom subcell—the optimum being 1 eV. In the scenario where CdTe is used as the 

7 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

Table 1 The best-performing perovskite-based tandem solar cells. 

|Subcells|Type|Perovskite composition|Jsc (mA cm<sup>−2</sup>)|Voc (V)|FF|PCE (%)|Ref.|
|---|---|---|---|---|---|---|---|
|PSC/Organic|2 T|FA0.8Cs0.2Pb(I0.5Br0.5)3|14|2.15|80|24.0<sup>b</sup>|25|
||4 T|CsPbBr3|6.15|1.38|70.51|14.03<sup>c</sup>|131|
||||12.18|0.88|75.16|||
|PSC/CIGS|2 T|Cs5(MA17FA83)95Pb(I83Br17)3|19.17|1.68|71.9|23.26<sup>a</sup>|31|
||4 T|(FA0.65MA0.20Cs0.15)Pb(I0.8Br0.2)3|19.6|1.137|76.8|25.9<sup>c</sup>|170|
||||15.6|0.715|79.2|||
|PSC/PSK|2 T|FA0.7MA0.3Pb0.5Sn0.5I3<br>FA0.8Cs0.2Pb(I0.62Br0.38)3|16.54|2.048|77.9|26.4<sup>a</sup>|38|
||4 T|(FASnI3)0.6(MAPbI3)0.4|10.5|0.806|80.6|25.4<sup>c</sup>|37|
|||Cs0.05FA0.8MA0.15PbI2.55Br0.45|20.8|1.124|79.3|||
|PSC/Si|2 T|Cs0.05(FA0.77MA0.23)0.95Pb(I0.77Br0.23)3|19.23|1.90|79.40|29.15<sup>a</sup>|48|
||4 T|Cs0.05FA0.81MA0.14PbI2.55Br0.45|22.3|1.12|77.7|28.2<sup>b</sup>|61|
||||17.2|0.70|76.6|||
|PSC/CZTSSe|2 T|(FA0.7MA0.15Cs0.15)Pb(I0.85Br0.15)3|17.67|1.46|68|17.5<sup>c</sup>|171|
||4 T|Cs0.2FA0.8Pb(I0.82Br0.15Cl0.03)3|18.82|1.23|77.3|22.27<sup>c</sup>|59|
||||15.43|0.43|66.54|||
|PSC/QDs|2 T|Cs0.05FA0.8MA0.15PbI2.55Br0.45|16.3|1.55|69|17.1<sup>b</sup>|62|
||4 T|Cs0.05FA0.81MA0.14PbI2.55Br0.45|22.3|1.12|77.7|24<sup>b</sup>|61|
||||12.2|0.62|66|||



> aCertified PCE. 

> bStabilized PCE. 

> cBest-performing cell. 

top subcell, perovskites with wider bandgaps (>2 eV) are needed. However, wide-bandgap perovskites usually suffer from low efficiencies and poor stability. For instance, Siegler et al.<sup>65</sup> reported the use of MAPbBr3 (bandgap of 2.3 eV) to fabricate 4 T perovskite/CdTe tandem cells, but these were found to have a very poor PCE of 3.5%. This was attributed to the optical haze in the perovskite film causing a significant optical loss. Therefore, optimizing the bandgaps of both subcells is needed before this tandem device configuration is viable. 

The above-mentioned results demonstrate the exciting rapid improvement in the efficiency and stability of perovskite-based tandem solar cells, which have now surpassed those of singlejunction perovskite devices. Table 1 shows a summary of the best-performing perovskite-based tandem solar cells. It is anticipated that further efficiency and stability enhancement will compensate for the additional costs derived from constructing tandem structures. A recent cost estimation analysis of several tandem devices was conducted by Li et al.<sup>66</sup> using the levelized cost of electricity (LCOE). Based on their calculations and assumptions, an LCOE of 4.34 US cents kWh<sup>−1</sup> for a single-junction planar PSCs was obtained, which was found to be 21% lower than that of a silicon solar cell. Their findings also revealed that the LCOE increases to 5.22 US cents kWh<sup>−1</sup> with silicon/perovskite-tandem cells, which is still about 5% lower than that of a conventional silicon solar cell. Surprisingly, the LCOE was found to be considerably reduced to 4.22 US cents kWh<sup>−1</sup> with perovskite/perovskitetandem devices. The lower LCOE was attributed to the high efficiency and reduced cost of perovskite devices. It was also predicted that the LCOE values could be further decreased by improving the PCE and stability of the devices presented in the study. These studies clearly demonstrate the appeal of perovskite-tandem devices for commercialization. 

### Challenges for perovskite-based subcells 

Stability of perovskite solar cells. The long-term stability of PSCs represents a key obstacle for their commercial deployment. Perovskite materials typically used in solar cells have been shown to be unstable when exposed to oxygen, water, heat, and light. In addition to these external factors, some studies have also shown 

that the inherent properties of perovskite materials, such as ion migration and low defect formation energy, play a significant role in the rapid decomposition of perovskite films. With 25 years of an outdoor operational lifetime required by the marketplace, PSCs currently lag behind this target. To overcome the stability issues, many strategies have been developed, such as compositional engineering, interface engineering, and surface/bulk defect passivation<sup>67–72</sup> . For instance, by fully or partially substituting the highly volatile A site MA cation with formamidinium (FA) and/ or cesium (Cs) in the perovskite, the device stability was found to be enhanced<sup>73</sup> . Another strategy involves the incorporation of various materials, such as 1D and 2D materials<sup>1,74</sup> , polymers<sup>75</sup> , and fullerene derivatives<sup>76</sup> into the perovskite film to passivate its defects and hence improve the overall device stability. The replacement of doped HTMs with undoped ones is also a promising route to prevent ion migration and interaction between the dopants and perovskite, but their PV performance remains questionable<sup>77</sup> . The migration of ionic species in halide perovskite films can also be largely suppressed by the formation of 2D/3D multidimensional perovskite structures, leading to greater device stability<sup>78</sup> . It is worth mentioning that in common with all PV technologies, encapsulating PSCs can prolong their lifetime by protecting them against external environmental factors<sup>79</sup> . 

Toxicity of lead. To date, state-of-the-art PSCs are constructed of lead-based halide perovskites due to their excellent optical and optoelectronic properties. However, the potential hazard of lead leaking into the environment and potential human health risks means that encapsulation and end of life recycling needs to be considered. The European Commission (EU) has restricted the maximum amount of lead that can be used in electrical and electronic equipment to 0.1 wt%, which is significantly lower than the amount of lead currently needed to fabricate PSCs (5–10 wt%)<sup>80</sup> . As such, tremendous efforts have been made to design low-toxic/lead-free metal halide perovskites for PV applications. The complete replacement of Pb using other metal halides such as tin (Sn), germanium (Ge), bismuth (Bi), and antimony (Sb) have been attempted. However, PSCs based on these alternative metal-based perovskites show inferior performance to their Pb-based counterparts. For instance, while the 

8 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

PCE of Pb-based PSCs exceeded 25%, the highest PCE of Snbased PSCs has only recently achieved slightly over 14%<sup>81,82</sup> . These poor PCEs are currently below that required for singlejunction and tandem solar cell applications. Another practical approach to reducing the content of Pb while maintaining the high performance of PSCs is to partially substitute a portion of the Pb with less-toxic metal cations. Indeed, Pb–Sn mixed perovskite absorbers with their close-to-ideal bandgap of ~1.2–1.3 eV enabled the fabrication of efficient devices with PCEs exceeding 21%<sup>83</sup> . This narrow bandgap, coupled with the high PCEs, makes Pb–Sn mixed PSCs desirable candidates as the bottom subcell in all-perovskite-tandem solar cells. For instance, Xiao et al.<sup>36</sup> demonstrated excellent performance of a single-junction Pb–Sn mixed PSCs with a certified PCE of 20.7%. By employing a wide-bandgap perovskite of 1.77 eV (Cs0.2FA0.8PbI1.8Br1.2) and a narrow-bandgap perovskite of 1.22 eV (FA0.7MA0.3Pb0.5Sn0.5I3), the group was able to fabricate monolithic all-perovskite-tandem cells with a certified PCE of 24.2% and an aperture area of 1.041 cm<sup>2</sup> . It is anticipated that with further tuning the optoelectronic properties of Pb–Sn mixed perovskites and developing a novel method to passivate the surface of Pb–Sn mixed perovskite films, exciting opportunity lies ahead in realizing more efficient allperovskite-tandem devices. However, the trade-off is that at this stage Sn-containing perovskites are less stable. 

### Building-integrated photovoltaic 

Electricity-generating solar panels are generally mounted on the building rooftops. However, PV systems can be buildingintegrated (BIPV) and are increasingly employed in new ways during the construction of buildings. BIPV includes inclusion of panels on or as parts of the building envelope such as the windows, skylights, exterior walls, or facades. The requirements for BIPV are therefore different for rooftop-mounted systems with a greater emphasis on the optical properties, such as color and transparency, weight and form factor. In addition to color tunability, PSCs can be fabricated on transparent, conductive and flexible substrates, making them attractive for BIPV applications. In the context of perovskite-based BIPV, three major categories have been developed and explored. The first category is semitransparent PSCs, which have been explored for use in building windows and glass roofs. The second category of perovskite-based BIPVs are colorful PSCs, which can be applied in building fences, walls and car park roofs. The third category is smart PV windows (SPWs), which are dual-functional BIPVs created by combining the solar harvesting function with electrochromic/thermochromic functionalities. SPWs are interesting in that they can harvest sunlight to produce electricity while blocking sunlight entering the building on a hot summer day (Fig. 5a). However, before BIPV becomes widespread there are manufacturing and performance related challenges to be addressed<sup>84–87</sup> . In the following sub-sections, we outline and discuss some of the recent advances that have been made in these three categories of BIPV that use PSCs. 

Smart PV windows. A smart window is a glass whose optical transmission is altered when an external stimuli (e.g., heat, voltage, or light) is applied. In general, smart windows are constructed using switchable films such as thermochromic, photochromic and electrochromic layers. Integration of smart windows with PV devices has the promise to reduce cooling/ heating costs and ventilation loads, improve privacy, and harvest excess solar energy as electricity, thus maximizing the overall energy efficiency of the building. In this regard, emerging PV systems, including organic solar cells, dye-sensitized solar cells 

(DSSCs), and PSCs have been considered as candidates for SPWs due to the high degree of tunability of their properties. Both organic molecules and dye sensitizers can exhibit photochromic properties, allowing them to be integrated into photochromic solar windows, but they typically exhibit poor PCEs<sup>88–90</sup> . Interestingly, the temperature required to crystallize perovskite light absorbers opens new avenues for research in SPWs as the temperature can adjust the color of perovskite films. Overall, considerable progress has been made in the development of integrated SPW systems involving PV device and an electrochromic layer using each type of emerging PV cell, including organic solar cells, DSSCs and PSCs. Since the output voltage plays a vital role in operating the electrochromic windows, PSCs with their high voltage are particularly attractive. Perovskitebased SPWs can be categorized into dual-function thermochromic solar cells and photovoltachromic cells (PVCCs) depending on their functionality. It is still early days for these two categories of SPWs and while there are many challenges remaining to be addressed the technology is ripe for further research and development. Interestingly, a group of researchers led by Bakr demonstrated the temperature-dependent thermochromic properties of hybrid halide perovskites<sup>91</sup> . The authors prepared perovskite inks based on MAPb(I1−xBrx)3 with varying x. At room temperature, the ink was yellow in color, but it changed to orange upon heating to 60 °C, bright red at 90 °C, and finally black at 120 °C (Fig. 5b). They found that this temperature-induced thermochromic variation was reversible in the presence of solvent. It should be highlighted that the halogen components in the perovskite plays the key role in this unusual crystallization behavior. Wheeler et al.<sup>92</sup> reported the practical use of the thermochromic properties of perovskites in switchable photovoltaic windows. In this work, the thermochromic layer was made of a halide perovskite with differing amounts of methylamine (CH3NH3PbI3•xCH3NH2). The working principle of this SPW device can be described as follows. Upon illumination (solar photothermal heating), the thermochromic film switches from a transparent state (68% visible transmittance) to an opaque colored state (<3% visible transmittance) due to the dissociation of CH3NH2 from the perovskite-CH3NH2 complex (Fig. 5c). After cooling, the CH3NH2 complex is re-formed in the absorber layer, making the device transparent (bleached state) to visible light. This switchable PSC device exhibited a PCE of 11.3% in the colored state, while the control cell, which did not show switching behavior, had an average efficiency of 16.3% (Fig. 5d). Despite the promising PCE, the PV device performance decreased over time due to the loss of CH3NH2 and disruption of the film morphology during the cycling process. In a separate study, the structural phase transitions of an all-inorganic perovskite, CsPbI3−xBrx, were used to obtain a thermochromic smart solar window with improved stability<sup>93</sup> . Thermal annealing at a temperature of 105 °C and exposure to moisture were used to control the reversible transition between the transparent (81.7% transmittance) and colored (35.4% transmittance) phases (Fig. 5e). Importantly, no significant color fading and efficiency reduction were observed for this all-inorganic perovskite-based SPW during the phase transition cycles, showing the potential of perovskitebased smart solar windows. However, the efficiencies of this switchable device during the phase transition cycles were only around 4–6%, suggesting further improvements in the PV performance are required for this class of SPWs. In addition to the low efficiency, the 105 °C heating requirement to generate the colored phase means that the strategy was not practical, as the temperature is much higher than the temperature expected as a result of solar illumination. Indeed, it is important to design photoactive perovskites that can switch colors at low 

9 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 5 Perovskite-based smart PV windows. a Schematic illustration of the key components of a self-powered smart photovoltaic window in hot and cold conditions. b Colors of MAPb(I1−xBrx)3 perovskite inks at temperatures of 25 °C, 60 °C, 90 °C and 120 °C. b Adapted with permission from ref.<sup>91</sup> Copyright 2017 American Chemical Society. c Optical transmittance of CH3NH3PbI3•xCH3NH2 complex based PSCs in the bleached and colored states. d J–V curves of switchable PV devices in the dark and under illumination. c, d Adapted with permission from ref.<sup>92</sup> , Copyright 2017 Springer Nature. e Schematic illustration of the phase transitions of CsPbI3−xBrx perovskite caused by thermal heating and exposure to moisture. e Adapted with permission from ref.<sup>93</sup> Copyright 2018 Springer Nature. f A schematic illustration of the first PVCC device using a PSC as an external electrical supply. f Adapted with permission from ref.<sup>95</sup> , Copyright 2015 Royal Society of Chemistry. g Repeatability of PVCC fabricated from a transparent PSC and ion-gel based electrochromic components. g Adapted with permission from ref.<sup>97</sup> , Copyright 2021 Springer Nature. 

temperatures. Recently, highly robust and stable SPWs with rapid reversibility were constructed using a 2D perovskite ((C6H4(CH2NH3)2)(CH3NH3)[Pb2I7]), but their PV efficiencies were less than 1%<sup>94</sup> . Currently, the key challenges in thermochromic perovskite-based smart solar windows include low device efficiency, poor reversibility and stability. Moreover, studying the thermochromic properties of lead-free perovskites for SPWs would be an interesting research direction. 

The final category of perovskite-based SPWs is PVCC, which combines a PV cell as the power supply and an electrochromic coated glass as the smart window. The first work integrating PSCs 

and electrochromic layers was reported by Cannavale et al.<sup>95</sup> who used two separate glass sheets for the PV device and electrochromic layer. A schematic of this device architecture is illustrated in Fig. 5f. The PV device was made of a semitransparent perovskite layer coated on the top TCO substrate, while the electrochromic layer was made of WO3 deposited on the bottom TCO glass. This semitransparent system exhibited an AVT of 15.9% when bleached, which changed to 5.5% upon darkening. However, the PCE of the device was only 5.5% when colored, suggesting that considerable enhancement in the PV performance should be made for this class of SPWs. Moreover, 

10 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

the transparency of the device in the neutral state was still low at 15.9%, which is undesirable. One possible strategy to overcome this issue for this class of SPWs would be to integrate the PV cells onto the frame of the electrochromic windows. 

Current SPWs have at least one of the following limitations: low PV efficiency, poor operational stability, and/or long response time. Efforts have been made to address some of these issues, but usually at a cost to the others. Xia et al.<sup>96</sup> aimed to overcome these challenges by coupling multiresponsive liquid crystal/ polymer composite (LCPC) films and semitransparent PSCs. The strategy involved using the PSCs as a power source, with the LCPC films used to adjust the transparency of the windows. The semitransparent PSCs had an AVT higher than 10%, with the PV device having a PCE of >16%. Thus the SPW exhibited excellent power output, energy saving, and privacy protection. Recently, Liu et al.<sup>97</sup> developed a PVCC integrating a transparent PSC with ion-gel based electrochromic components. The device was constructed in a vertical tandem architecture without an intermediate electrode. The authors were able to adjust the halide-exchange period precisely and achieved a high transmittance of up to 76% for the PVCC module (Fig. 5g). Further impressive parameters such as a color-rendering index of up to 96, a wide contrast ratio of >30%, and a self-adaptable transmittance adjustment were also obtained for their PVCC. Due to the simple architecture and scalable manufacturing, this particular PVCC device architecture shows great promise in the development of future energy-saving smart technologies. In addition to combining PV devices with electrochromic films, there have been efforts on integrating PSCs with both energy storage systems and electrochromic layers<sup>98,99</sup> . These types of integrated systems are expected to provide novel green technologies that can not only produce and store power, but also automatically control their optical transparencies. These initial results show significant technological promise, and are a fruitful area for further research and development. 

Semitransparent PSCs. Among perovskite-based BIPVs, semitransparent PSCs are the most widely studied because of the tunability of the perovskite film transparency. Efficient semitransparent solar cells should have high PV performance at the highest possible optical transmittance. Important optical factors include color-rendering index, average visible transmittance (AVT), and average near-infrared (NIR) transmittance. It should be noted that the theoretical Shockley–Queisser (SQ) limit for a single-junction wavelength-selective transparent solar cell with an AVT of 100% is around 20.6%<sup>100</sup> , although this has yet to be realized. Promisingly, the state-of-the-art semitransparent devices with organic layers have achieved PCEs of around 13% with AVT values of ⁓20%<sup>101–104</sup> . Semitransparent DSSCs tend to exhibit lower efficiencies as compared to organic solar cells due to the device architecture<sup>105</sup> . On the other hand, researchers have been making rapid developments in the area of semitransparent PSCs with improved performance and design<sup>106</sup> . Recently, a PCE of over 13% with an AVT of 27% was achieved using plasmonic gold nanorod integrated perovskite-based PSCs<sup>107</sup> , suggesting a bright future for transparent PV devices using perovskite light absorbers. A typical PSC (high-efficiency device) has an average thickness of 500-600 nm, which is too thick for semitransparent devices. In 2014, two independent research groups reduced the thickness of the perovskite layers to obtain semitransparent films for solar cells<sup>108,109</sup> . Devices fabricated by Bolink et al.<sup>108</sup> with a 180 nm thick perovskite film delivered a PCE of 7.31% and an AVT of 22%, whereas a semitransparent PSC with a 135 nm perovskite film prepared by Qi et al.<sup>109</sup> exhibited a PCE of 9.9%. However, no AVT value was reported for the latter semitransparent cell. An 

ideal semitransparent device should exhibit a high PCE while also maintaining a high AVT (25% is the current benchmark)<sup>84</sup> . Therefore, it is critical to investigate both the PV efficiency and AVT to determine the overall performance of semitransparent solar cells. Since these two pioneering studies, researchers have further improved both the efficiency and AVT of the devices using various strategies. For instance, Jen’s group used transparent CuSCN as a HTM in an inverted (p–i–n) device with different perovskite film thicknesses ranging from 60 nm to 300 nm (Fig. 6a)<sup>110</sup> . They found that a device with a 180 nm thick perovskite film displayed a PCE of over 10% and an AVT of 25%. 

Meanwhile, a novel strategy (dewetting) was introduced by Eperon et al.<sup>111</sup> to fabricate neutral colored semitransparent PSCs (Fig. 6b). The key attraction of this strategy was to create microstructured arrays of perovskite “islands” to enable unattenuated transmission of light between the islands (Fig. 6c). The fabricated semitransparent device showed a good AVT of 30%, but its efficiency was only 3.5% due to the lower geometric fill factor of the active perovskite sections of the film. These authors further improved both PCE and AVT of color neutral semitransparent devices to 5.2% and 28%, respectively, using FAPbI3<sup>112</sup> . Despite these improvements, it can be observed from Fig. 6c that the direct contact of the ETL and HTL in the perovskite-free region leads to poor device performance. Therefore, depositing an extra layer as a shunt-blocking layer on the uncovered surface could be used to improve the performance. 

Improving/modifying the microstructure of the perovskite film is another method for obtaining semitransparent PSCs. Snaith and his colleagues used a highly ordered metal oxide honeycomb structure to control the size and structure of the perovskite (Fig. 6d)<sup>113</sup> . The honeycomb structure allowed them to control the growth of the perovskite crystal. In this device design, the honeycomb region was transparent, which allowed them to fabricate semitransparent PSCs with an efficiency of 9.5% and an AVT of 37%. Fan’s group recently reported a PCE of 10.5% with an AVT of 32.5% for semitransparent PSCs using a moth-eyeinspired structure (MEIS) (Fig. 6e)<sup>114</sup> . The incorporation of MEIS into the devices resulted in light manipulation, which improved the performance and visual appearance of the devices. Figure 6f compares photographs of the planar (control) and MEIS based PSCs. These studies clearly show that controlling the structure of perovskite films is a promising approach for the development of efficient semitransparent PSCs. However, there is still room for the development of techniques that can be used to accurately control the growth of the perovskite film, which can then be used for the construction of semitransparent PV cells. 

In addition to optimization of the properties of the perovskite films, the choice and structure of the metal electrodes acting as the charge collectors, such as Au and Ag, are of great importance for semitransparent devices. A dielectric–metal–dielectric (DMD) electrode is one strategy for ultrathin metal-electrode based semitransparent PSCs<sup>115</sup> due to their excellent electrical conductivity and suitable energy band alignment. Carbon-based electrode materials such as carbon nanotubes (CNTs) and graphene are also promising candidates for PSCs<sup>116</sup> . You et al.<sup>117</sup> have used stacked multilayer graphene as the top electrode of semitransparent PSCs. With a transmittance of around 26%, the semitransparent device exhibited a PCE of 6.6% when illuminated from the graphene side. This work was one of the first examples that showed graphene electrodes are candidates for use in semitransparent PSCs. Recently, a collaborative research team led by Shi and Grätzel introduced an innovative strategy to construct semitransparent PSCs using carbon materials<sup>118,119</sup> . The key innovation was assembling a semi-cell (thin carbon layer coated perovskite film) with a charge collector (carbon electrode). Using this approach, a steady-state PCE of 

11 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 6 Semitransparent perovskite solar cells. a Photographs of CH3NH3PbI3 films with different thicknesses on CuSCN treated ITO-coated glass substrates. a Adapted with permission from ref.<sup>110</sup> , Copyright 2015 Wiley-VCH. b A layered structure of the dewetting strategy applied to a PSC. c Crosssectional SEM image of a neutral colored semitransparent device. b, c Adapted with permission from ref.<sup>111</sup> , Copyright 2014 American Chemical Society. d SEM images of perovskite film formations within (i) TiO2 and (ii) SiO2 honeycomb scaffolds. d Adapted with permission from ref.<sup>113</sup> , Copyright 2015 Royal Society of Chemistry. e (i) Tilted-view and (ii) top-view SEM images of MEIS-ITO. f Photographs of planar (reference) and MEIS based semitransparent PSCs. e, f adapted with permission from ref.<sup>114</sup> , Copyright 2021 Wiley-VCH. 

over 20% was achieved for carbon-based semitransparent PSCs, while maintaining excellent operational stability under 1 sun illumination at 25 °C and 60 °C<sup>119</sup> . The semitransparent PSC fabricated using this strategy was also used to construct a tandem solar cell with a CuInSe2 based bottom subcell, delivering an efficiency of 27.1%<sup>120</sup> . Devices fabricated using carbon electrodes have the potential benefit of low production costs, but their hydrophobic nature could also provide enhancement of the stability of PSCs through reducing the ingress of moisture. Future work should aim to improve the hole selectivity and/or enhance p-type conductivity of the carbon electrodes. The same group has recently reported the use of CNT based electrodes as an alternative to the top metal electrode to fabricate semitransparent PSCs. When multi-walled CNTs (MWCNTs) were used, they were able to achieve a PCE of more than 22% for the semitransparent PSC. Other carbonaceous materials such as MXene (Ti3C2Tx) are also expected to be promising electrode candidates as they show high conductivity and excellent transparency. Until now, progress in semitransparent PSCs has mainly focused on devices with lead-based perovskites, leaving the development of semitransparent lead-free PSCs as a fruitful area to explore. 

Colorful PSCs. Colorful PV devices including PSCs have drawn considerable attention for various applications where esthetics are important. The color of PSCs and their esthetic properties can be tuned by controlling the light absorption properties or using external layers. A wide range of colors can be achieved in PSCs by adjusting the elemental components of the perovskites to change their bandgap. A great example of tunable device colors is demonstrated by changing the content of iodine and 

bromine in the perovskite, which is depicted in Fig. 7a that shows the appearance in reflected light<sup>121</sup> . Noh et al.<sup>122</sup> studied the chemical tunability of inorganic-organic hybrid perovskites with the basic composition of MAPb(I1–xBrx)3 and showed that the onset of the absorption band of the MAPb(I1–xBrx)3 perovskite could be tuned from 786 nm (1.58 eV) to 544 nm (2.28 eV) (Fig. 7b). The authors were able to observe the direct changes in the perovskite bandgap as a function of bromide composition (x) – the higher the bromide content the higher the gap (Fig. 7c). The devices fabricated with the perovskite containing a small amount of bromide (x = 0.2) were found to have an average PCE of over 10% with the best-performing device exhibiting a PCE of 12.3%. It should be noted that a PCE of 12.3% was a remarkable PV performance for PSCs in 2013. Interestingly, the cells with higher Br content exhibited greatly improved stability under humid conditions. In 2015, Snaith and colleagues fabricated PSCs with tunable structural colors across the visible spectrum (from red to blue) using a porous photonic crystal scaffold within the photoactive layer<sup>123</sup> . Inspired by this pioneering work, Huang’s group designed vividly colorful PSCs using a doctor blade coating technique<sup>124</sup> . In this work, the photonic structures on the perovskite film form instantly by Rayleigh-Bénard convection and the “coffee-ring effect”, resulting in a tunable domain pattern and concentric rings in each domain with near equal ring spacing (Fig. 7d). These structures were responsible for the appearance of vivid colors. However, this type of architecture leads to an increased number of grain boundaries within the film, which can be clearly observed, and these lead to increased charge recombination and reduced performance. Therefore, reducing the number of grain 

12 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 7 Colorful perovskite solar cells. a A photo of the fabricated PSCs, with Spiro-MeOTAD as the HTM and gold as the current collector, showing the appearance in reflected light. a adapted with permission from ref.<sup>121</sup> , Copyright 2016 Royal Society of Chemistry. b Changes in the UV-vis absorption spectra and (c) the corresponding bandgap of perovskites (MAPb(I1–xBrx)3) as a function of Br composition (x). b, c Adapted with permission from ref.<sup>122</sup> , Copyright 2013 American Chemical Society. d The precursor solution concentration dependent perovskite film morphologies for vividly colorful PSCs. d adapted with permission from ref.<sup>124</sup> , Copyright 2015 Royal Society of Chemistry. e Different pigment materials spin-coated on semitransparent perovskites. e adapted with permission from ref.<sup>125</sup> , Copyright 2016 Wiley-VCH. f A photo of PSCs with different thicknesses (40–160 nm) of PEDOT:PSS. f adapted with permission from ref.<sup>126</sup> Copyright 2016 American Chemical Society. 

boundaries while maintaining the photonic structure is important for obtaining high PV efficiency using this strategy. 

In addition to the compositional engineering of perovskites, simple pigment materials with different colors can be coated on fabricated devices to obtain colorful PSCs. Guo et al.<sup>125</sup> have created semitransparent PSCs with a PCE of 5.36% and an AVT 

of 34% using polyvinylpyrrolidone (PVP) as a dopant material in the perovskite. Then the authors spin-coated different pigments (yellow, red and green) on top of fully fabricated devices to obtain colorful PSCs that were also semitransparent (Fig. 7e). However, while devices with any color of choice can be formed, this class of solar cells suffer from low cell efficiencies due to the parasitic 

13 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

absorption of the pigment filters. Colorful PSCs with PV efficiencies of up to 16% were successfully fabricated by Zhou’s group using the transparent conducting polymer, poly(3,4ethylenedioxythiophene):poly(styrenesulfonate) (PEDOT:PSS), as both the top electrode and as a spectrally selective antireflection coating<sup>126</sup> . By adjusting the thickness of the PEDOT:PSS layer, they were able to effectively tune the reflectance of the devices (Fig. 7f) and thus the perceived color. These initial studies provide the foundations for approaches to methods and modifications that can be made to produce PCEs that are colorful. 

### Space applications 

PSCs are promising candidates for space applications due to their distinctive features such as their superior gamma-ray radiation resistance and high power-to-weight (also known as specific power)<sup>127–129</sup> . In addition, the instability issues of PSCs that arise from the exposure to oxygen and moisture in the atmosphere on earth do not exist in the space environment, which further enhances the potential of PSCs for space applications. A reasonable basis on which to evaluate the performance of solar cells for space applications is to consider the AIAA-S111 standard for the qualification of space solar cells. A solar cell system must satisfy the requirements associated with the performance and stability before being considered for space applications<sup>130</sup> . For instance, solar cells need to withstand 1 MeV electrons with a fluence of 1 × 10<sup>16</sup> electrons per square centimeter and 3 MeV protons with a fluence of 1 × 10<sup>13</sup> protons per square centimeter. In addition, solar cells should be characterized over a temperature range from −150 °C to 150 °C. Currently, the highest PCE of 47.1% was achieved using six-junction inverted metamorphic solar cells under 143 suns<sup>12</sup> . Although this PCE is higher than the state-of-the-art single-junction PSCs, two-junction perovskitebased tandem devices, such as perovskite-Si, have already approached ~30% and are more cost-effective. However, the feasibility of using perovskite-based tandem devices for space applications has not been practically determined yet. Investigations are needed to assess the impact of exposing PSCs to the vacuum of space, different temperatures, and UV radiation. It is worth mentioning that according to the IEC-61345 industrial standard, a solar cell system needs to preserve over 95% of its initial PCE after 15 kWh m<sup>−2</sup> of UV exposure<sup>131</sup> . For space applications, the UV level is even more important, considering that it is much higher than under AM0 conditions. Therefore, testing PSCs under high UV irradiance is important. Although UV-light stable PSCs (CsPbBr3) for 120 h have been reported<sup>131</sup> , extending the time measurement window and varying the perovskite compositions to maximize the device efficiency is critical for future space applications. 

Given the difficulty and complexity of undertaking PSCs performance testing under real space conditions, simulated space environments are generally used. The capability of the solar cells to survive different space conditions such as high-energy particle irradiation (e.g., protons, electrons, and gamma-rays), high vacuum, and elevated temperatures is of great importance. There have been some promising test results on single-junction PSCs<sup>132,133</sup> . For example, Lang et al.<sup>134</sup> were the first to study the operational stabilities of two types of perovskite-based tandem solar cells under the harsh radiation conditions of 68 MeV proton irradiation at a dose of 2 × 10<sup>12</sup> p<sup>+</sup> /cm<sup>2</sup> (see Fig. 8a for the device structures). They found that monolithic perovskite/Si solar cells became severely degraded, maintaining only 1% of their initial PCE, which compared poorly to perovskite/CIGS tandem solar cells that retained 85% of the initial PCE under space solar illumination conditions (AM0). The poor device stability of monolithic perovskite/Si solar cells was ascribed to the radiation- 

induced formation of recombination centers in the Si. It was also found that the primary reason for the PCE loss in perovskite/ CIGS tandem solar cells was due to increased recombination in the CIGS subcell. Following this pioneering work, the same group recently reported the hardness of all-perovskite-tandem devices when exposed to high-energy proton irradiation (68 MeV at an accumulated dose of 1 × 10<sup>13</sup> p<sup>+</sup> /cm<sup>2</sup> )<sup>135</sup> . Remarkably, over 94% of the initial PCE was maintained, clearly indicating that perovskite materials are resilient to high irradiation exposure and thus suitable candidates for the space industry. It is worth noting that an accumulated dose of 1 × 10<sup>13</sup> p<sup>+</sup> /cm<sup>2</sup> is equivalent to the accumulated dose after >100 years in near-earth and >10 years in geostationary orbit. 

Although the development of PSCs for space applications is still in its infancy, there have also been a few studies carried out under real space conditions. To the best of our knowledge, Cardinaletti et al.<sup>136</sup> were the first to track the changes in PSC performance attached to stratospheric balloons that reached an altitude of 32 km (Fig. 8b). The output of the MAPbI3 based devices in a near-space environment were recorded over the 3 h of stratospheric flight. Although this work was a great demonstration, longer testing times are required in a space environment. In subsequent work, Reb et al.<sup>137</sup> fabricated both mesoporous (TiO2) and SnO2 based standard PSCs that were mounted on a suborbital rocket. The device performance was evaluated after the rocket attained the apogee of 239 km under temperatures ranging from 30 °C to 60 °C for a 6 min period (Fig. 8c). Despite this short tracking time, the devices showed satisfactory performance (power densities exceeded 14 mW cm<sup>−2</sup> ) under strong solar irradiation. Furthermore, Tu et al.<sup>138</sup> used a high-altitude balloon to carry an FA0.81MA0.10Cs0.04PbI2.55Br0.40 based large-area PSC (1.00 cm<sup>2</sup> ) to an altitude of 35 km for 2 h (Fig. 8d, f). The TiO2based PSC maintained 95% of its initial PCE during the test. The authors also found that using an ultraviolet (UV) filter could further improve the stability of the devices. These findings have laid the foundation for additional research to promote the applications of PSCs in space. However, these advances in exploring the feasibility of perovskite-based devices under real space environments have only been made using single-junction PSCs. Comparable efforts on the exploration of perovskite-based tandem solar cells for practical space applications have not yet been reported. 

### PV-integrated energy storage systems 

Solar energy will continue to be a leading source of renewable energy. However, conventional solar cells are instantaneous photoelectric conversion devices and the electrical output has to be consumed immediately or stored<sup>139</sup> . To address the need of uninterrupted energy availability it is therefore important to develop integrated energy conversion-storage systems. In this regard, integrating solar cells as an energy conversion unit with energy storage units has become a promising solution for developing renewable and clean technologies. Supercapacitors (SCs), lithium-ion batteries (LIBs) and other rechargeable batteries are the most promising energy storage units owing to their high energy and power density and long lifetime. It should be noted that considerable attention has been given to integrated systems based on energy storage devices (batteries and supercapacitors) and a range of solar cells technologies, such as DSSCs and organic photovoltaic devices (OPVs)<sup>140,141</sup> , but the overall performance of these integrated systems are still unsatisfactory mainly due to the limited PCEs of the solar cells. This has led to recent advances being focused on employing PSCs in integrated systems. When integrating energy conversion and storage units, voltage matching is of great importance. In this context, PSCs with their high Voc 

14 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 8 Perovskite solar cells for space applications. a Device architecture for two different types of perovskite-based tandem solar cells. These two devices were tested against harsh radiation conditions (68 MeV high proton irradiation). a Adapted with permission from ref.<sup>134</sup> , Copyright 2020 Elsevier Inc. b Solar cell mounting structure, and schematics of the flight altitude. b Adapted with permission from ref.<sup>136</sup> , Copyright 2018 Elsevier. c Schematic Overview of the MAPHEUS-8 Sounding Rocket Flight. c Adapted with permission from ref.<sup>137</sup> , Copyright 2020 Elsevier Inc. d Representative schematic showing the relative position of the Sun, the high-altitude balloon, and the Earth (courtesy of National Aeronautics and Space Administration). e The photograph of launch site. f The photograph of the high-altitude balloon with a pod in near space. d–f adapted with permission from ref.<sup>138</sup> , Copyright 2019 Springer Nature. 

values are expected to be a lead candidate for energy conversion/ storage capability. Furthermore, their maximum power point can be close to the charge/reaction voltage plateau, which is vital for avoiding metal plating in battery technologies. In PV-integrated energy storage systems, the cost-benefit has been regarded as one of the key factors for the investment. For the analysis of costeffectiveness, factors that should be accounted for include system architecture, size of the components (e.g., energy storage devices, PV modules, electric cables, inverters, etc.), operation and maintenance costs, and replacements. Importantly, the cost benefits of integrated systems must outweigh the costs of the technology to deliver their advantages. In this regard, the manufacturing cost and PCE of individual PV cells will play critical roles in determining the final cost benefits of PV-integrated energy technologies. 

For a broad perspective of the field, Fig. 9 shows a schematic illustration of PV-integrated energy storage devices and PV-celldriven catalysis reactions, highlighting the advantages of integrated systems. The average voltage outputs required to drive supercapacitors, water splitting, CO2 reduction, and batteries are also provided. The following sub-sections outline and evaluate the recent progress on integrated systems based on PSCs and energy storage devices such as supercapacitors and batteries. 

PSCs–supercapacitors. Of the different types of energy storage devices, supercapacitors exhibit unique advantages including ultralong cycling stabilities, rapid charging/discharging, and high power densities. Importantly, the voltage demands for supercapacitors are relatively low compared to other energy storage devices, making them attractive for integration with solar cells. Xu et al.<sup>142</sup> fabricated the first integrated system using a CH3NH3PbI3-based PSC connected with a supercapacitor 



Fig. 9 Schematic illustration of PV-integrated energy storage systems and PV-cell-driven catalysis. Integrated PV and energy storage devices or catalysis systems. The overpotential windows required to drive different solar energy conversion and storage, particularly supercapacitors, water splitting, CO2 reduction, are provided. It should be noted that the voltage outputs required to drive these systems vary depending on the performance of the electrode materials and catalysts. 

15 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 10 Perovskite solar cells for energy storage devices. a J–V curves of an integrated system using a CH3NH3PbI3 based PSC and a polypyrrole-based supercapacitor (supercapacitor was charged at 0.6 V). Inset: Connection of the integrated system. a Adapted with permission from ref.<sup>142</sup> , Copyright 2015 American Chemical Society. b Schematic diagram of a self-powered wearable electronic sensing device (PSC-LIC integrated system). b Adapted with permission from ref.<sup>143</sup> , Copyright 2019 Elsevier Ltd. c Schematic illustration of energy harvesting and storage ribbon consisting of a PSC and a symmetric supercapacitor with a shared copper electrode. c Adapted with permission from ref.<sup>146</sup> , Copyright 2016 Springer Nature. d Schematic diagram of the first PSC–LIB integrated system. e J–V curves of the connected PSCs before and after various cycles. f Discharge capacity of of the PSC-LIB integrated device. d–f adapted with permission from ref.<sup>152</sup> , Copyright 2015 Springer Nature. g Schematic diagram of the integrated PSC–Li-S battery. g adapted with permission from ref.<sup>153</sup> Copyright 2015 Wiley-VCH. h A layered structure of the PSTSC designed for an aqueous solar flow battery. h Adapted with permission from ref.<sup>157</sup> , Copyright 2020 Springer Nature. 

assembled from a cellulose membrane/polypyrrole (PPy) nanofibers/MWCNTs combination. The integrated device displayed an energy storage efficiency of 10% and high output voltage of 1.45 V under AM 1.5 G illumination (Fig. 10a). The overall efficiency was calculated considering the light density, the device active area and the charging time. Notably, this performance was much higher than that of other integrated systems constructed from other types of solar cells. However, active area mismatch between the PSCs and supercapacitors was the key limitation in this work, causing a relatively long charging time of 300 s. A device with a large active area is expected to shorten the charging time of the capacitor. Later, Liu’s group designed a self-powered wearable sensing device by integrating a flexible PSC, a flexible lithium-ion capacitor (LIC) module, and a graphene-based strain sensor (Fig. 10b)<sup>143</sup> . For the flexible PSC module, the authors connected four individual PSCs in series to achieve a voltage output of 3.95 V for LIC charging. The flexible module was able to display an overall efficiency of 8.41% and an output voltage of 3 V at a discharge current density of 0.1 A g<sup>−1</sup> . In a slightly different approach from the above configurations, a flexible all-solid-state wire-connected integrated system based on self-stacked solvated graphene films was also developed by Du et al.<sup>144</sup> , which achieved 

a gravimetric specific capacitance of 245 F g<sup>−1</sup> and stability over 10,000 cycles. By avoiding the use of aqueous electrolytes, the solid electrolyte significantly improved the stability of the device, suggesting that this strategy has great potential to satisfy the technical requirements for integrated energy systems. 

Besides these wire-connected integrating strategies, the design of the shared electrode has drawn much interest due to its lower integration cost and better technological features. An integrated energy conversion and storage device was constructed using a PSC with a PEDOT-carbon-based shared electrode<sup>145</sup> . In this design, the carbon electrodes played dual roles in collecting holes from the perovskite layer and that could be used by the redox supercapacitors. The hybrid device showed an overall energy conversion and storage efficiency of 4.7% and 74%, respectively. A highly conductive metal electrode has been used by Li et al.<sup>146</sup> for an all-solid-state, energy harvesting and storage ribbon that integrates a PSC with a symmetric supercapacitor via a copper (Cu) ribbon, which acts as a shared electrode (Fig. 10c). Upon illumination, the PSC achieved a PCE of >10% and the supercapacitor exhibited an energy density of 1.15 mWh cm<sup>−3</sup> and a power density of 243 mW cm<sup>−3</sup> . However, it is worth mentioning that the supercapacitors in integrated systems are 

16 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

typically constructed with carbon-based electrodes such as CNTs, graphene, and composites due to the need to achieve low-cost and highly conductive electrodes<sup>147</sup> . Carbon-based materials have also shown promise for use in stable PSCs owing to their hydrophobic characteristics and chemical stability<sup>148</sup> . Therefore, developing high-efficiency PSCs with carbon back-electrodes for integrated energy storage devices is a promising research direction. A novel integrated system based on a PSC with a MoO3/Au/MoO3 transparent electrode and electrochromic supercapacitor has also been reported<sup>98</sup> . Despite the functionality of smart coloring, the PCEs of these perovskite photovoltachromic supercapacitor cells was less than 4% with the colored electrodes. 

Devices consisting of a PSC and a supercapacitor are known as photo-supercapacitors and have attracted attention over the past few years due to their potential for being green portable power supply technologies. This class of integrated device does not need an external wire connection, but the challenge is the requirement for high operating and output voltages. Liu et al.<sup>149</sup> developed a system using four individual photo-supercapacitors assembled in series, and was able to obtain a stable output voltage of ∼3.8 V. This power pack was able to drive light-emitting diodes (LEDs) after being photo-charged, demonstrating the potential of this innovative technology. Given that supercapacitors require high voltages, their combination with PSCs to form high-efficiency PTSCs are expected to be promising candidates for solar rechargeable supercapacitors. 

PSCs–batteries. Smart electronic devices, electric vehicles and smart grids have received a lot of attention and seem set to become an integral part of our day-to-day life. Currently, these advanced technologies depend on rechargeable batteries as the key energy storage device. Due to their high-energy density and excellent chemical stabilities, metal-ion batteries (e.g., lithium-ion batteries (LIBs)) are expected to be energy storage units for solar rechargeable batteries. Indeed, LIBs have been integrated with Sibased multi-junction solar cells in early reports and with DSSCs<sup>150,151</sup> . However, the output voltages of individual energy conversion units (solar cells) are often less than 0.8 V, which is insufficient to drive power storage devices. To provide sufficient output voltages, multiple PV units need to be connected in series, but this strategy is undesirable for the development of compact integrated systems. In this regard, PSCs with their high voltages are promising candidates for solar rechargeable batteries. An early study on integrating PSCs with LIBs was by Dai’s group<sup>152</sup> , where LIBs with a voltage range of 1.0-2.6 V were constructed, with four CH3NH3PbI3 based solar cells connected in series to allow for direct photo-charging (Fig. 10d). The connected PSCs delivered a Voc value (3.84 V) for photo-charging the LIBs (Fig. 10e). Although promising cycling stability was demonstrated (∼2.05% decay per cycle) (Fig. 10f), these PSCs-LIB integrated systems still require significant improvements in their operational stabilities and more testing conditions need to be applied, including thermal, long-term, repeated cycling and humidity tests. 

Lithium–sulfur (Li-S) batteries are expected to be one of the leading technologies due to their high-energy density and weight, and with a cut-off charge voltage of 2.8 V, they are well suited for integration with a serially connected PSC pack for solar-driven batteries. Chen et al.<sup>153</sup> designed an integrated solar-driven rechargeable Li-S battery using three CH3NH3PbI3 based PSCs connected in series. The connected PSC unit had a PCE of 12.4% and Voc of 2.79 V, which were sufficient to photo-charge the Li-S battery. As a result, an overall energy conversion efficiency of 5.1% was achieved for the integrated battery with a specific capacity of 750 mAh g<sup>−1</sup> . Notably, in this integrated system, the sulfur-based electrode was connected with the joint carbon 

electrode of the three PSC units (Fig. 10g). The use of carbon materials can be beneficial for integrated systems due to their low-cost, high stability and simple structure. In addition to the state-of-the-art Li-based batteries, emerging metal-based batteries such as Al-ion<sup>154</sup> , Na-ion<sup>155</sup> and aqueous zinc batteries<sup>156</sup> have been integrated with PSCs as demonstrators for solar rechargeable battery systems. 

It should be emphasized that voltage matching between the solar cell and the battery device is critical for integrated systems. In this context, PTSCs show particular promise as they not only exhibit high PCEs, but also suitable photovoltage outputs due to the bandgap tunability of the perovskite top layer. In 2020, Li et al.<sup>157</sup> developed a tandem solar cell constructed using a (FAPbI3)0.83(MAPbBr3)0.17 based PSC as the top subcell and Si as the bottom subcell (Fig. 10h) with a suitable photovoltage for an aqueous solar flow battery. During the operation of the solar flow battery system, more than 90% of the PCE of the PSTSC was effectively utilized, suggesting that good photovoltage matching was achieved in this integrated device. Despite this advance, more effort should still be made to develop high-efficiency integrated systems using PTSCs. Noticeably, the majority of studies on integrated PSC-battery systems have employed simple perovskites such as MAPbI3. However, as discussed earlier there are many different perovskite materials developed that could be used in conjunction with batteries. Considering the technical requirements for commercialization of the integrated systems, a comprehensive range of lifetime tests including thermal, moisture and light stabilities under harsh testing conditions over extended durations should be conducted. Furthermore, although excellent progress has been made on integrated PSC-battery systems, the wire connection should be minimized in future work to reduce energy losses and device fabrication costs. 

### PV cell-driven catalysis 

Solar-driven catalytic reactions are regarded as an emerging sustainable chemical production route. Advanced catalytic reactions such as water splitting and carbon dioxide (CO2) reduction have the potential for green, sustainable and cost-effective routes for energy and feedstocks for industry. There are several categories of solar-driven catalysis, including photocatalytic, photoelectrochemical catalytic, photothermal catalytic and photosynthetic processes. For a broad perspective of the field, there are several reviews on these solar-driven catalysis processes available<sup>158–160</sup> , and in this review we will focus on the foundational processes of water splitting and carbon dioxide reduction. Of particular interest in this section is PSC cell-driven catalysis of water splitting and CO2 reduction. 

PSCs–driven water splitting. Hydrogen (H2) energy (known also as H2 fuel) needs no introduction as a zero-carbon fuel that can be used in internal combustion engines and fuel cells. H2 energy can be stored as a gas under high pressure and can even be delivered through natural gas pipelines. H2 production from water (H2O) has been considered as a promising green strategy. By applying an electric current to a suitable electrode, splitting of H2O into H2 and oxygen (O2) is achieved. Of particular importance in water electrolysis is the selection of an efficient electrocatalyst and the use of a high voltage PV-electrolyzer. Theoretically, a thermodynamic equilibrium potential of 1.23 V is required as minimum energy for water-splitting, but the practical operating potential can be varied between 1.5 and 2.0 V<sup>161</sup> . Due to the demand of such high operating voltages, several junctions and/or individual cells need to be connected in series for the electrolyzer<sup>126</sup> . Since PSCs typically display Voc values of more than 1.0 V, connecting only two individual PSC units is expected 

17 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 11 Perovskite solar cell driven water splitting. a Schematic diagram of the water-splitting device powered by CH3NH3PbI3 based PSCs (two cells connected in series). b J–V curves of the connected PSCs measured under dark and simulated illumination of 100 mW cm<sup>−2</sup> , and the NiFe/Ni foam electrodes in a two-electrode configuration. a, b Adapted with permission from ref.<sup>162</sup> , Copyright 2014 American Association for the Advancement of Science. c The stability test of the integrated PSC-driven water splitting system with CoP and NiFe/Ni foam catalysts. c adapted with permission from ref.<sup>163</sup> , Copyright 2016 Wiley-VCH. d Energy diagram of the PSTSC-driven water-splitting system, and (e) the corresponding performance evaluation. d, e Adapted with permission from ref.<sup>165</sup> , Copyright 2019 Elsevier Inc. 

to meet the electrochemical potential required for water splitting. In 2014, Grätzel’s group reported the use of PSCs as an electrolyzer for water splitting for the first time (Fig. 11a)<sup>162</sup> . They connected two individual CH3NH3PbI3 based PSCs that each had a PCE of 17.3% and an Voc of 1.06 V. When the two cells were connected in series, the module deliver a Voc of 2.00 V, which was sufficient for efficient water splitting. Importantly, these authors designed a novel bifunctional catalyst (efficient for both H2 and O2 evolution) by directly growing a NiFe layered double hydroxide on a Ni foam. By integrating the connected PSCs and NiFe/ Ni foam electrode, a solar-to-hydrogen (STH) efficiency of 12.3% was achieved (Fig. 11b), which even at this early stage approached the theoretical limit (17.8%) of H2 generation for this type of 

system, as defined by a 1.5 eV bandgap and the solar flux. Further improvements in the STH efficiency should be achievable by applying a shared electrode strategy to form an integrated system and/or by employing other efficient perovskite light absorbers. However, the stability issues associated with the PSCs at the time impacted the viability of this approach. The same authors made considerable improvements in both STH efficiency and stability of PSC-driven water-splitting system by employing (FAPbI3)1−x(MAPbBr3)x based PSCs, while using a cobalt phosphide (CoP) catalyst for the H2 evolution and NiFe/Ni foam for the O2 evolution<sup>163</sup> . In that work, two individual PSC units were also connected in series to provide a potential of over 2.0 V, and the authors were able to achieve an STH efficiency of 12.7%. The 

18 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

system was found to retain more than 70% of its initial STH efficiency after 16 h of operation (Fig. 11c), which was significantly better than their first integrated device reported in 2014. Despite this, further improvements in both STH performance and stability are required to make this approach economically viable since the power (electricity) consumed is currently more valuable than the H2 produced. 

One of the key strategies to construct an efficient and costeffective PV cell-driven water-splitting system is to use high voltage solar cells. In this regard, single-junction all-inorganic PSCs and bromine (Br) based cells are good candidates. Building perovskite-based tandem PV devices (in particular 2 T) would also be appealing for use in integrated systems. Indeed, the first hybrid PTSC-driven water-splitting was reported by Bin et al.<sup>164</sup> who used graphene-based materials as the catalysts for both H2 and O2 evolution. Their tandem cell was able to deliver an Voc value of 1.86 V, which was sufficient for water splitting, but the obtained STH efficiency was <10%. Recently, Luo and colleagues constructed a 2 T PSTSC with an Voc of 1.76 V as a low-cost alternative to III–V multi-junction solar cells to drive water splitting<sup>165</sup> . The authors used TiC/Pt as the H2 evolution catalyst and a NiFe/Ni foam for O2 evolution, and powered the water splitting process using a mixed halide-based perovskite (Cs0.19FA0.81Pb(Br0.13I0.87)3) and monocrystalline-Si tandem solar cell (Fig. 11d). The integrated system showed a peak STH efficiency of 18.7% (Fig. 11e). This performance is the highest reported value to date among halide perovskite-based PV celldriven and non-III–V-class light absorber-based water-splitting systems. Remarkably, after operating for over 2 h, the STH conversion efficiency dropped to only 18.02%, demonstrating promising stability of the system. Despite this significant milestone, further improvements are still expected in this class of integrated systems by maximizing the PV performance of the tandem solar cells and by designing efficient bifunctional electrocatalysts. 

PSC-driven CO2 reduction. The conversion of CO2 into valuable chemical feedstocks and fuels has been the focus of catalysis research for many years. This approach is not only important for producing high-value chemicals, but has the potential to reduce the global greenhouse effect caused by CO2. The CO2 reduction reaction (CO2RR) powered by renewable electricity generated from solar energy is an ideal approach to effectively utilize these abundant resources to produce high-value chemicals. However, CO2RR demands driving voltages that are considerably higher than supplied by single-junction solar cells. In particular, the power supply unit (PV cell) should provide an output voltage of >2.0 V<sup>161</sup> , which again requires that single-junction PV cells are connected in series. Schreier et al.<sup>166</sup> used three single-junction PSCs connected in series to achieve a Voc of 3.10 V for the reduction of CO2 to carbon monoxide (CO). In this work, iridium oxide (IrO2) was used as the oxygen-evolution catalyst, while gold (Au) was for the cathodic CO evolution. The integrated system delivered a solar-to-CO (STC) efficiency of over 6.5% with excellent stabilities (Fig. 12a). When the system was operated without any external bias under constant illumination, no significant changes in the current density, Faradaic yield (CO%) and STC efficiency was observed over at least 18 h (Fig. 12b), highlighting the stable operation of both the catalyst and the PV cells. A schematic illustration of the energy diagram for converting CO2 into CO using this series of three PSCs is shown in Fig. 12c. Although this work is an excellent demonstration of integrating PSCs with CO2RR, further work is required to achieve efficiency improvements. Similarly, two series of three individual triple cation PSCs connected in parallel were used to convert CO2 to 

hydrocarbons<sup>167</sup> . More recently, for the purpose of light-driven CO2 conversion to methane (CH4), four series-connected PSCs (delivering an Voc of 4.20 V) were electrically coupled to an electrochemical cell that had copper (Cu) and RuO2 electrodes, providing a 5% solar-to-fuel conversion efficiency<sup>168</sup> . 

Considering the need of high driving voltages for CO2RR, it is reasonable to expect that achieving high-efficiency CO2 conversion at low-cost will utilize multi-junction (notably triple) PSCs. As far as we are aware, until now, there has been no effort in designing perovskite multi-junction (tandem) solar cells for CO2RR despite many groups having reported high-efficiency perovskite triple-junction solar cells. For example, Tan’s group fabricated monolithic all-perovskite triple-junction solar cells with an efficiency of 20.1% and an Voc value of 2.80 V (Fig. 12d)<sup>169</sup> . This triple-junction device was constructed using three perovskites with different bandgaps (1.22 eV, 1.60 eV and 1.99 eV) and is a good example of how the characteristics of a single perovskite device might be tuned towards an application with very specific requirements, such as CO2RR. 

### Outlook 

Metal halide perovskites are exciting PV materials with fascinating properties including high absorption coefficients, bandgap tunability, excellent charge-carrier mobilities and solution processability. PV devices fabricated using these materials have demonstrated the steepest growth in terms of PCE of any PV technology in history. Considering the rapid progress in PV performance, PSCs have been considered to be ideal candidates for integrating with other systems to realize new innovative technologies. The next-generation applications of perovskitebased solar cells include tandem PV cells, space applications, PVintegrated energy storage systems, PV cell-driven catalysis and BIPVs. Herein, we have discussed the major advances towards integrating PSCs with these innovative technologies, highlighting the key advantages and challenges with some potential ways forward. We now summarize the perspectives and provide potential ways forward for the development of these exciting research areas. 

(i) The integration of PSCs with other PV cells to form tandem solar cells has provided an opportunity to realize high-efficiency PV systems and leverage existing PV technologies. Although excellent progress has been made, there are several critical issues that need urgent attention. When integrating with wide-bandgap semiconductors based cells, perovskites with low-bandgap should be employed. However, the preparation of low-bandgap perovskites is not an easy task and generally requires the partial replacement of Pb<sup>2+</sup> with Sn<sup>2+</sup> . This process not only causes detrimental issues associated with the perovskite films such as large defect density, pinholes and non-uniform surfaces, Sn-based perovskites also exhibit lower carrier lifetime, diffusion length and poorer stability. Therefore, alternative strategies to design lowbandgap perovskites should be explored including the replacement of Sn with other stable metals and surface passivation techniques. In contrast, wide-bandgap perovskites are needed when lowbandgap materials such as CdTe are employed as the top subcell. However, wide-bandgap perovskites generally suffer from poor efficiencies, which should also be addressed to obtain high PV efficiencies. 

One of the major requirements for high-efficiency tandem solar cells is highly conductive transparent electrodes, which play important roles not only in electrically conducting the charge carriers, but controlling the transmittance of the incident light through the top subcell to the bottom subcell. Carbon materials such as graphene, CNTs and MXene, with their high electrical conductivity and excellent optical transparencies are expected to be ideal electrode 

19 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 



Fig. 12 Perovskite solar cell driven CO2 reduction. a J–V curves of three series-connected PSCs, overlaid with the matched J–V characteristics of the CO2RR and oxygen-evolution electrodes. b Current density, CO% and STC efficiency of the integrated system during a stability test without any external bias under constant illumination for 18 h. c Schematic diagram of the CO2RR system powered by CH3NH3PbI3 based PSCs (three cells connected in series). a–c adapted with permission from ref.<sup>166</sup> , Copyright 2015 Springer Nature. d J–V curve of monolithic all-perovskite triple-junction cells with the structure illustrated in the inset. d adapted with permission from ref.<sup>169</sup> , Copyright 2020 American Chemical Society. 

materials for semitransparent top subcells. The advantages of employing carbon electrodes in solar cells include low-cost, high efficiencies and enhanced device stabilities due to their hydrophobic nature. However, very limited efforts have been made on fabricating semitransparent PSCs using carbon electrodes for tandem solar cells. Carbon electrodes with improved hole selectivity and conductivity should be explored for HTM-free and metal-free PSCs. 

It is well understood that the photocurrent matching of top and bottom subcells plays a critical role in achieving high PV performance for 2-T tandem solar cells. Therefore, particular attention should be paid to obtain strongly matched Jsc values for the two subcells when designing tandem devices. Although there are many reports demonstrating the excellent operational stabilities of tandem solar cells, testing conditions and duration should be extended to harsher environments for longer times, respectively, to better reflect the real-world and improve the prospects for commercialization. 

(ii) The high output voltage values of PSCs open a new technology avenue for integrated energy storage systems. A single integrated device made up of a PSC and a battery (or a supercapacitor) is known as a solar rechargeable power system. Although these types of integrated systems are highly attractive, high operating and output voltages are required. Therefore, voltage matching between the energy conversion unit (solar cell) and the battery device is critical. However, the output voltage of single-junction PV cells including PSCs is insufficient to drive energy storage devices. In this regard, perovskite-based multijunction tandem solar cells would be excellent candidates to power integrated energy storage systems. For example, the Voc value can exceed 2.2 V for two series connected PSCs with higher voltages obtained by adding more series-connected cells. 

It is well known that carbon-based materials such as CNTs, graphene and carbon particles can play significant roles in the 

construction of energy storage devices due to their low-cost and high conductivity. Therefore, designing integrated systems using carbon electrode based PSCs and energy storage devices would be of great value. Furthermore, on the basis of current literature, it is noticeable that the majority of available reports on PSCsintegrated energy storage systems have used the conventional perovskite type (CH3NH3PbI3), whereas there are a comprehensive range of other perovskite structures available for use. 

(iii) PV-driven conversion of CO2 and water splitting have gained increasing attention as emerging sustainable routes to produce high-value chemicals. Electrolysis of water theoretically requires a minimum potential of 1.23 V, but in practice the requirement can be up to 2.0 V, which can be achieved by connecting two single-junction PSC units in series. However, instead of connecting two individual cells, employing perovskite-based tandem devices as an electrolyzer for water splitting can be a better approach. Currently, a STH efficiency of 18.7% is the best reported value among halide perovskite-based PV cell-driven water-splitting systems. Other important factors for achieving high-efficiency PV-integrated catalysis systems include the activity of the electrocatalysts. It is important to utilize catalyst materials that are readily available for use and exhibit outstanding catalytic activity for the proposed reactions. Therefore, it is reasonable to expect a STH efficiency of 20% by employing highefficiency tandem solar cells and designing catalysts with outstanding activities for both H2 and O2 evolution. Considering the demand of much higher driving voltages for CO2RR (>2.0 V) as compared to water electrolysis, the use of multi-junctions PSCs and serially connected tandem solar cells is a powerful strategy. However, based on current performance, the power consumed would be more valuable than the converted CO2 using PV cells. (iv) Among the different types of perovskites based BIPVs, major progress has been made on semitransparent PSCs. However, the 

20 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

energy benefits of BIPVs must outweigh the costs of the technology to deliver the advantage of integrating semitransparent PSCs into buildings. As such, significant improvements are needed in the PCE of semitransparent PSCs while enhancing their optical transparencies. Typically, the benchmark AVT value is considered to be 25% for solar windows. However, it is difficult to generate a high photocurrent if 25% of the incident light is transmitted through the window. Therefore, future studies on semitransparent and colorful PSCs should aim to achieve high photovoltage values to compensate for the low photocurrent. This can be achieved through multiple strategies such as compositional engineering and bandgap engineering of the perovskites. 

There is no doubt that PSCs have appealing characteristics for the development of BIPVs. However, the key challenge lies in realizing all of the following features in a single system: high PCE, excellent device stability and rapid response characteristics. Some of these features can be achieved, but at a cost to the others. For the potential commercialization of BIPVs, the devices should be scaled up with window-like dimensions. Moreover, lead-free perovskites should be explored for different types of BIPVs. Perovskite-based SPWs are innovative technologies that show many attractive features. Despite their great promise, thermochromic perovskitebased smart solar windows suffer from several issues including fast decay in the PCE during cycling and response delays in switching between bleached and colored states. The key issue for temperature based photochromics is the temperature requirement (>100 °C) to crystallize perovskite, which is well above the temperature reached from solar radiation (<100 °C). Therefore, designing perovskites that can be crystallized at low temperature while showing rapid response characteristics would be a valuable research direction for perovskite photochromic windows. 

Received: 24 June 2022; Accepted: 10 December 2022; 



15. Pan, Y. et al. A new end group on nonfullerene acceptors endows efficient organic solar cells with low energy losses. Adv. Funct. Mater. 32, 2108614 (2022). 

16. Chen, C.-C. et al. Perovskite/polymer monolithic hybrid tandem solar cells utilizing a low-temperature, full solution process. Mater. Horiz. 2, 203–211 (2015). 

17. Liu, Y. et al. High efficiency tandem thin-perovskite/polymer solar cells with a graded recombination layer. ACS Appl. Mater. Interfaces 8, 7070–7076 (2016). 

18. Chen, X. et al. Efficient and reproducible monolithic perovskite/organic tandem solar cells with low-oss interconnecting layers. Joule 4, 1594–1606 (2020). 

19. Xie, S. et al. Efficient monolithic perovskite/organic tandem solar cells and their efficiency potential. Nano Energy 78, 105238 (2020). 

20. Wu, X. et al. Improved stability and efficiency of perovskite/organic tandem solar cells with an all-inorganic perovskite layer. J. Mater. Chem. A 9, 19778–19787 (2021). 

21. Chen, W. et al. Surface reconstruction for stable monolithic all-inorganic perovskite/organic tandem solar cells with over 21% Efficiency. Adv. Funct. Mater. 32, 2109321 (2022). 

22. Chen, W. et al. Monolithic perovskite/organic tandem solar cells with 23.6% efficiency enabled by reduced voltage losses and optimized interconnecting layer. Nat. Energy 7, 229–237 (2022). 

23. He, C. et al. Asymmetric electron acceptor enables highly luminescent organic solar cells with certified efficiency over 18%. Nat. Commun. 13, 2598 (2022). 

24. Wang, L. et al. Alkyl chain tuning of non-fullerene electron acceptors toward 18.2% efficiency binary organic solar cells. Chem. Mater. 33, 8854–8862 (2021). 

25. Brinkmann, K. O. et al. Perovskite–organic tandem solar cells with indium oxide interconnect. Nature 604, 280–286 (2022). 

26. Green, M. A. et al. Solar cell efficiency tables (Version 58). Prog. Photovolt Res. Appl. 29, 657–667 (2021). 

27. Contreras, M. A. et al. Wide bandgap Cu(In,Ga)Se2 solar cells with improved energy conversion efficiency. Prog. Photovolt: Res. Appl. 20, 843–850 (2012). 

28. Yakushev, M. V. et al. Influence of growth conditions on the structural quality of Cu(InGa)Se2 and CuInSe2 thin films. Thin Solid Films 451-452, 133–136 (2004). 

29. Todorov, T. et al. Monolithic perovskite-CIGS tandem solar cells via in situ band gap engineering. Adv. Energy Mater. 5, 1500799 (2015). 

30. Jošt, M. et al. 21.6%-Efficient monolithic perovskite/Cu(In,Ga)Se2 tandem solar cells with thin conformal hole transport layers for integration on rough bottom cell surfaces. ACS Energy Lett 4, 583–590 (2019). 

31. Al-Ashouri, A. et al. Conformal monolayer contacts with lossless interfaces for perovskite single junction and monolithic tandem solar cells. Energy Environ. Sci. 12, 3356–3369 (2019). 

### References 

1. Bati, A. S. R. et al. Cesium-doped Ti3C2Tx MXene for efficient and thermally stable perovskite solar cells. Cell Rep. Phys. Sci. 2, 100598 (2021). 

2. Zhang, Y. et al. Ambient fabrication of organic–inorganic hybrid perovskite solar cells. Small Methods 5, 2000744 (2021). 

3. Bati, A. S. R. et al. Electrically sorted single-walled carbon nanotubes-based electron transporting layers for perovskite solar cells. iScience 14, 100–112 (2019). 

4. National renewable energy laboratory. Best research-cell efficiencies., (https:// www.nrel.gov/pv/assets/pdfs/best-research-cell-efficiencies-rev220630.pdf) (Accessed November 2022). 

5. Wu, J. et al. A Comparison of charge carrier dynamics in organic and perovskite solar cells. Adv. Mater. 34, 2101833 (2022). 

6. Bati, A. S. R. et al. 1D-2D Synergistic MXene-nanotubes hybrids for efficient perovskite solar cells. Small 17, 2101925 (2021). 

7. Bati, A. S. R., Batmunkh, M. & Shapter, J. G. Emerging 2D layered materials for perovskite solar cells. Adv. Energy Mater. 10, 1902253 (2020). 

8. Nelson, C. A., Monahan, N. R. & Zhu, X. Y. Exceeding the Shockley–Queisser limit in solar energy conversion. Energy Environ. Sci. 6, 3508–3519 (2013). 

9. Leijtens, T., Bush, K. A., Prasanna, R. & McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. Nat. Energy 3, 828–838 (2018). 

10. Wang, P. et al. Tuning of the interconnecting layer for monolithic perovskite/ organic tandem solar cells with record efficiency exceeding 21%. Nano Letters 21, 7845–7854 (2021). 

11. Vos, A. D. Detailed balance limit of the efficiency of tandem solar cells. J. Phys. D: Appl. Phys. 13, 839–846 (1980). 

12. Geisz, J. F. et al. Six-junction III–V solar cells with 47.1% conversion efficiency under 143 Suns concentration. Nature Energy 5, 326–335 (2020). 

13. Li, H. & Zhang, W. Perovskite tandem solar cells: from fundamentals to commercial deployment. Chem. Rev. 120, 9835–9950 (2020). 

14. Ho-Baillie, A. W. Y. et al. Recent progress and future prospects of perovskite tandem solar cells. Appl. Phys. Rev. 8, 041307 (2021). 

32. pv magazine. Solliance, MiaSolé hit 26.5% efficiency on tandem CIGS/ perovskite solar cell., (https://www.pv-magazine.com/2021/02/15/solliancemiasole-hit-26-5-efficiency-on-tandem-cigs-perovskite-solar-cell/) (Accessed November 2022). 

33. Jošt, M. et al. Perovskite/CIGS tandem solar cells: from certified 24.2% toward 30% and beyond. ACS Energy Lett 7, 1298–1307 (2022). 

34. Yang, Z. et al. Enhancing electron diffusion length in narrow-bandgap perovskites for efficient monolithic perovskite tandem solar cells. Nat. Commun. 10, 4498 (2019). 

35. Palmstrom, A. F. et al. Enabling flexible all-perovskite tandem solar cells. Joule 3, 2193–2204 (2019). 

36. Xiao, K. et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. Nature Energy 5, 870–880 (2020). 

37. Tong, J. et al. Carrier lifetimes of >1 μs in Sn-Pb perovskites enable efficient all-perovskite tandem solar cells. Science 364, 475–479 (2019). 

38. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. Nature 603, 73–78 (2022). (This paper reported a certified efficiency of 26.4% in all-perovskite tandem solar cells.). 

39. Zheng, J. et al. Monolithic perovskite–perovskite–silicon triple-junction tandem solar cell with an efficiency of over 20%. ACS Energy Lett. 7, 3003–3005 (2022). 

40. Shen, H. et al. Monolithic perovskite/Si tandem solar cells: pathways to over 30% efficiency. Adv. Energy Mater. 10, 1902840 (2020). 

41. Mao, L. et al. Fully textured, production-line compatible monolithic perovskite/silicon tandem solar cells approaching 29% efficiency. 34, 2206193 (2022). 

42. Ramírez Quiroz, C. O. et al. Balancing electrical and optical losses for efficient 4-terminal Si–perovskite solar cells with solution processed percolation electrodes. J. Mater. Chem. A 6, 3583–3592 (2018). 

43. Wang, Z. et al. 27%-Efficiency four-terminal perovskite/silicon tandem solar cells by sandwiched gold nanomesh. Adv. Funct. Mater. 30, 1908298 (2020). 

44. Yu, Z. et al. Simplified interconnection structure based on C60/SnO2-x for allperovskite tandem solar cells. Nat. Energy 5, 657–665 (2020). 

21 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

45. Mailoa, J. P. et al. A 2-terminal perovskite/silicon multijunction solar cell enabled by a silicon tunnel junction. Appl. Phys. Lett. 106, 121105 (2015). 

46. Albrecht, S. et al. Monolithic perovskite/silicon-heterojunction tandem solar cells processed at low temperature. Energy Environ. Sci. 9, 81–88 (2016). 

47. Mazzarella, L. et al. Infrared light management using a nanocrystalline silicon oxide interlayer in monolithic perovskite/silicon heterojunction tandem solar cells with efficiency above 25%. Adv. Energy Mater. 9, 1803241 (2019). 

48. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300–1309 (2020). 

49. Aydin, E. et al. Ligand-bridged charge extraction and enhanced quantum efficiency enable efficient n–i–p perovskite/silicon tandem solar cells. Energy Environ. Sci. 14, 4377–4390 (2021). 

50. Duong, T. et al. High efficiency perovskite-silicon tandem solar cells: effect of surface coating versus bulk incorporation of 2D perovskite. Adv. Energy Mater. 10, 1903553 (2020). 

51. Isikgor, F. H. et al. Concurrent cationic and anionic perovskite defect passivation enables 27.4% perovskite/silicon tandems with suppression of halide segregation. Joule 5, 1566–1586 (2021). 

52. Li, Y. et al. Wide bandgap interface layer induced stabilized perovskite/silicon tandem solar cells with stability over ten thousand hours. Adv. Energy Mater. 11, 2102046 (2021). 

53. Hou, Y. et al. Efficient tandem solar cells with solution-processed perovskite on textured crystalline silicon. Science 367, 1135–1140 (2020). (This study made an important advance in the field of perovskite/silicon tandem solar cells.). 

54. Chen, B. et al. Blade-coated perovskites on textured silicon for 26%-efficient monolithic perovskite/silicon tandem solar cells. Joule 4, 850–864 (2020). 

55. pv magazine. Solliance hits 29.2% efficiency on perovskite/silicon tandem solar cell., (https://www.pv-magazine.com/2021/11/01/solliance-hits-29-2efficiency-on-perovskite-silicon-tandem-solar-cell/) (Accessed November 2022). 

56. Giraldo, S. et al. Progress and perspectives of thin film Kesterite photovoltaic technology: a critical review. Adv. Mater. 31, 1806692 (2019). 

57. Todorov, T., Gershon, T., Gunawan, O., Sturdevant, C. & Guha, S. Perovskitekesterite monolithic tandem solar cells with high open-circuit voltage. Appl. Phys. Lett. 105, 173902 (2014). 

58. Li, Y. et al. Solution-processed perovskite-kesterite reflective tandem solar cells. Sol Energy 155, 35–38 (2017). 

59. Wang, D. et al. Interfacial engineering of wide-bandgap perovskites for efficient perovskite/CZTSSe tandem solar cells. Adv. Funct. Mater. 2, 2107359 (2022). 

60. Karani, A. et al. Perovskite/colloidal quantum dot tandem solar cells: theoretical modelling and monolithic structure. ACS Energy Lett. 3, 869–874 (2018). 

61. Chen, B. et al. Enhanced optical path and electron diffusion length enable high-efficiency perovskite tandems. Nat. Commun. 11, 1257 (2020). 

62. Tavakoli, M. M. et al. Ambient stable and efficient monolithic tandem perovskite/PbS quantum dots solar cells via surface passivation and light management strategies. Adv. Funct. Mater. 31, 2010623 (2021). 

63. Hatton, P. et al. Chlorine activated stacking fault removal mechanism in thin film CdTe solar cells: the missing piece. Nat. Commun. 12, 4938 (2021). 

64. Fiducia, T. A. M. et al. Understanding the role of selenium in defect passivation for highly efficient selenium-alloyed cadmium telluride solar cells. Nat. Energy 4, 504–511 (2019). 

65. Siegler, T. D., Shimpi, T. M., Sampath, W. S. & Korgel, B. A. Development of wide bandgap perovskites for next-generation low-cost CdTe tandem solar cells. Chem. Eng. Sci. 199, 388–397 (2019). 

66. Li, Z. et al. Cost Analysis of perovskite tandem photovoltaics. Joule 2, 1559–1572 (2018). 

67. Saliba, M. et al. Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 206–209 (2016). 

68. Saidaminov, M. I. et al. Suppression of atomic vacancies via incorporation of isovalent small ions to increase the stability of halide perovskite solar cells in ambient air. Nat. Energy 3, 648–654 (2018). 

69. Jeon, N. J. et al. Compositional engineering of perovskite materials for highperformance solar cells. Nature 517, 476–480 (2015). 

70. Chen, J. & Park, N.-G. Materials and methods for interface engineering toward stable and efficient perovskite solar cells. ACS Energy Lett. 5, 2742–2786 (2020). 

71. Gao, F., Zhao, Y., Zhang, X. & You, J. Recent progresses on defect passivation toward efficient perovskite solar cells. Adv. Funct. Mater. 10, 1902650 (2020). 

72. Zhao, Y. et al. Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. Science 377, 531–534 (2022). 

73. Saliba, M. et al. Cesium-containing triple cation perovskite solar cells: improved stability, reproducibility and high efficiency. Energy Environ. Sci. 9, 1989–1997 (2016). 

74. Bati, A. S. R., Yu, L., Batmunkh, M. & Shapter, J. G. Recent advances in applications of sorted single-walled carbon nanotubes. Adv. Funct. Mater. 29, 1902273 (2019). 

75. Wang, S. et al. Polymer strategies for high-efficiency and stable perovskite solar cells. Nano Energy 82, 105712 (2021). 

76. Deng, L.-L., Xie, S.-Y. & Gao, F. Fullerene-based materials for photovoltaic applications: toward efficient, hysteresis-free, and stable perovskite solar cells. Adv. Electron. Mater. 4, 1700435 (2018). 

77. Yan, P., Yang, D., Wang, H., Yang, S. & Ge, Z. Recent advances in dopant-free organic hole-transporting materials for efficient, stable and low-cost perovskite solar cells. Energy Environ. Sci. 15, 3630–3669 (2022). 

78. Proppe, A. H. et al. Multication perovskite 2D/3D interfaces form via progressive dimensional reduction. Nat. Commun. 12, 3472 (2021). 

79. Matteocci, F. et al. Encapsulation for long-term stability enhancement of perovskite solar cells. Nano Energy 30, 162–172 (2016). 

80. European Commission. Restriction of Hazardous Substances in Electrical and Electronic Equipment (RoHS), (https://environment.ec.europa.eu/system/ files/2021-01/FAQ%20key%20guidance%20document%20-%20RoHS.pdf) (Accessed October 2022). 

81. Jiang, X. et al. One-Step Synthesis of SnI2·(DMSO)x Adducts for highperformance tin perovskite solar cells. J. Am. Chem. Soc. 143, 10970–10976 (2021). 

82. Yu, B.-B. et al. Heterogeneous 2D/3D tin-halides perovskite solar cells with certified conversion efficiency breaking 14%. Adv. Mater. 33, 2102055 (2021). 

83. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(ii) oxidation in precursor ink. Nat. Energy 4, 864–873 (2019). 

84. Batmunkh, M., Zhong, Y. L. & Zhao, H. Recent advances in perovskite-based building-integrated photovoltaics. Adv. Mater. 32, 2000631 (2020). 

85. Tai, Q. & Yan, F. Emerging semitransparent solar cells: materials and device design. Adv. Mater. 29, 1700192 (2017). 

86. Shi, B., Duan, L., Zhao, Y., Luo, J. & Zhang, X. Semitransparent perovskite solar cells: from materials and devices to applications. Adv. Mater. 32, 1806474 (2020). 

87. Xue, Q., Xia, R., Brabec, C. J. & Yip, H.-L. Recent advances in semitransparent polymer and perovskite solar cells for power generating window applications. Energy Environ. Sci. 11, 1688–1709 (2018). 

88. Huaulmé, Q. et al. Photochromic dye-sensitized solar cells with light-driven adjustable optical transmission and power conversion efficiency. Nat. Energy 5, 468–477 (2020). 

89. Ma, S. et al. Smart photovoltaics based on dye-sensitized solar cells using photochromic spiropyran derivatives as photosensitizers. AIP Adv. 5, 057154 (2015). 

90. Wang, Y. et al. Acidochromic organic photovoltaic integrated device. Chem. Eng. J. 452, 139479 (2023). 

91. De Bastiani, M. et al. Thermochromic perovskite inks for reversible smart window applications. Chem. Mater. 29, 3367–3370 (2017). 

92. Wheeler, L. M. et al. Switchable photovoltaic windows enabled by reversible photothermal complex dissociation from methylammonium lead iodide. Nat. Commun. 8, 1722 (2017). 

93. Lin, J. et al. Thermochromic halide perovskite solar cells. Nat. Mater. 17, 261–267 (2018). (This work revealed that smart photovoltaic windows can be fabricated using thermochromic perovskite.). 

94. Zhang, Y. et al. Robust and swiftly reversible thermochromic behavior of a 2D perovskite of (C6H4(CH2NH3)2)(CH3NH3)[Pb2I7] for smart window and photovoltaic smart window applications. ACS Appl. Mater. Interfaces 13, 12042–12048 (2021). 

95. Cannavale, A. et al. Perovskite photovoltachromic cells for building integration. Energy Environ. Sci. 8, 1578–1584 (2015). (A combination of photovoltaic and electrochromic behaviours is reported in this work to enable adjustable solar windows.). 

96. Xia, Y. et al. High-efficiency and reliable smart photovoltaic windows enabled by multiresponsive liquid crystal composite films and semi-transparent perovskite solar cells. Adv. Energy Mater. 9, 1900720 (2019). 

97. Liu, Y. et al. Full-frame and high-contrast smart windows from halideexchanged perovskites. Nat. Commun. 12, 3360 (2021). 

98. Zhou, F. et al. Perovskite photovoltachromic supercapacitor with alltransparent electrodes. ACS Nano 10, 5900–5908 (2016). 

99. Xia, X. et al. Perovskite solar cell powered electrochromic batteries for smart windows. Mater. Horiz. 3, 588–595 (2016). 

100. Yang, C., Liu, D., Bates, M., Barr, M. C. & Lunt, R. R. How to accurately report transparent solar cells. Joule 3, 1803–1809 (2019). 

101. Wang, D. et al. High-performance semitransparent organic solar cells with excellent infrared reflection and see-through functions. Adv. Mater. 32, 2001621 (2020). 

102. Yin, P., Yin, Z., Ma, Y. & Zheng, Q. Improving the charge transport of the ternary blend active layer for efficient semitransparent organic solar cells. Energy Environ. Sci. 13, 5177–5185 (2020). 

22 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

103. Hu, Z. et al. Semitransparent organic solar cells exhibiting 13.02% efficiency and 20.2% average visible transmittance. J. Mater. Chem. A 9, 6797–6804 (2021). 

104. Xu, T. et al. High-performance semitransparent organic solar cells: from competing indexes of transparency and efficiency perspectives. Adv. Sci. 9, 2202150 (2022). 

105. Grifoni, F. et al. Toward sustainable, colorless, and transparent photovoltaics: state of the art and perspectives for the development of selective near-infrared dye-sensitized solar cells. Adv. Energy Mater. 11, 2101598 (2021). 

106. Mujahid, M., Chen, C., Zhang, J., Li, C. & Duan, Y. Recent advances in semitransparent perovskite solar cells. InfoMat 3, 101–124 (2021). 

107. Lie, S., Bruno, A., Wong, L. H. & Etgar, L. Semitransparent perovskite solar cells with >13% efficiency and 27% transparency using plasmonic Au nanorods. ACS Appl. Mater. Interfaces 14, 11339–11349 (2022). 

108. Roldán-Carmona, C. et al. High efficiency single-junction semitransparent perovskite solar cells. Energy Environ. Sci. 7, 2968–2973 (2014). 

109. Ono, L. K., Wang, S., Kato, Y., Raga, S. R. & Qi, Y. Fabrication of semitransparent perovskite films with centimeter-scale superior uniformity by the hybrid deposition method. Energy Environ. Sci. 7, 3989–3993 (2014). 

110. Jung, J. W., Chueh, C.-C. & Jen, A. K.-Y. High-performance semitransparent perovskite solar cells with 10% power conversion efficiency and 25% average visible transmittance based on transparent CuSCN as the hole-transporting material. Adv. Energy Mater. 5, 1500486 (2015). 

111. Eperon, G. E., Burlakov, V. M., Goriely, A. & Snaith, H. J. Neutral color semitransparent microstructured perovskite solar cells. ACS Nano 8, 591–598 (2014). 

112. Eperon, G. E. et al. Efficient, Semitransparent neutral-colored solar cells based on microstructured formamidinium lead trihalide perovskite. J. Phys. Chem. Lett. 6, 129–138 (2015). 

113. Hörantner, M. T., Zhang, W., Saliba, M., Wojciechowski, K. & Snaith, H. J. Templated microstructural growth of perovskite thin films via colloidal monolayer lithography. Energy Environ. Sci. 8, 2041–2047 (2015). 

114. Zhu, Y. et al. Moth eye-inspired highly efficient, robust, and neutral-colored semitransparent perovskite solar cells for building-integrated photovoltaics. EcoMat 3, e12117 (2021). 

115. Della Gaspera, E. et al. Ultra-thin high efficiency semitransparent perovskite solar cells. Nano Energy 13, 249–257 (2015). 

116. Batmunkh, M., Shearer, C. J., Biggs, M. J. & Shapter, J. G. Nanocarbons for mesoscopic perovskite solar cells. J. Mater. Chem. A 3, 9020–9031 (2015). 

117. You, P., Liu, Z., Tai, Q., Liu, S. & Yan, F. Efficient semitransparent perovskite solar cells with graphene electrodes. Adv. Mater. 27, 3632–3638 (2015). 

118. Zhang, C. et al. Efficient stable graphene-based perovskite solar cells with high flexibility in device assembling via modular architecture design. Energy Environ. Sci. 12, 3585–3594 (2019). 

119. Zhang, C. et al. Ti1–graphene single-atom material for improved energy level alignment in perovskite solar cells. Nat. Energy 6, 1154–1163 (2021). 

120. Zhang, C. et al. CNT-based bifacial perovskite solar cells toward highly efficient 4-terminal tandem photovoltaics. Energy Environ. Sci. 15, 1536–1544 (2022). 

121. Jesper Jacobsson, T. et al. Exploration of the compositional space for mixed lead halogen perovskites for high efficiency solar cells. Energy Environ. Sci. 9, 1706–1724 (2016). 

122. Noh, J. H., Im, S. H., Heo, J. H., Mandal, T. N. & Seok, S. I. Chemical management for colorful, efficient, and stable inorganic–organic hybrid nanostructured solar cells. Nano Lett. 13, 1764–1769 (2013). 

123. Zhang, W. et al. Highly efficient perovskite solar cells with tunable structural color. Nano Lett. 15, 1698–1702 (2015). 

124. Deng, Y., Wang, Q., Yuan, Y. & Huang, J. Vividly colorful hybrid perovskite solar cells by doctor-blade coating with perovskite photonic nanostructures. Mater. Horiz. 2, 578–583 (2015). 

125. Guo, Y., Shoyama, K., Sato, W. & Nakamura, E. Polymer stabilization of lead(II) perovskite cubic nanocrystals for semitransparent solar cells. Adv. Energy Mater. 6, 1502317 (2016). 

126. Jiang, Y. et al. Efficient colorful perovskite solar cells using a top polymer electrode simultaneously as spectrally selective antireflection coating. Nano Lett. 16, 7829–7835 (2016). 

127. Yang, S. et al. Organohalide lead perovskites: more stable than glass under Gamma-Ray radiation. Adv. Mater. 31, 1805547 (2019). 

128. Kaltenbrunner, M. et al. Flexible high power-per-weight perovskite solar cells with chromium oxide–metal contacts for improved stability in air. Nat. Mater. 14, 1032–1039 (2015). 

129. Tu, Y. et al. Perovskite solar cells for space applications: progress and challenges. Adv. Mater. 33, 2006545 (2021). 

130. The American Institute of Aeronautics and Astronautics (AIAA). Standard: qualification and quality requirements for space solar cells (AIAA S-111A2014) (2014). 

131. Chen, W. et al. A Semitransparent inorganic perovskite film for overcoming ultraviolet light instability of organic solar cells and achieving 14.03% efficiency. Adv. Mater. 30, 1800855 (2018). 

132. Lang, F. et al. Efficient minority carrier detrapping mediating the radiation hardness of triple-cation perovskite solar cells under proton irradiation. Energy Environ. Sci. 12, 1634–1647 (2019). 

133. Miyazawa, Y. et al. Tolerance of perovskite solar cell to high-energy particle irradiations in space environment. iScience 2, 148–155 (2018). 

134. Lang, F. et al. Proton radiation hardness of perovskite tandem photovoltaics. Joule 4, 1054–1069 (2020). 

135. Lang, F. et al. Proton-radiation tolerant all-perovskite multijunction solar cells. Adv. Energy Mater. 11, 2102246 (2021). 

136. Cardinaletti, I. et al. Organic and perovskite solar cells for space applications. Sol. Energy Mater. Sol. Cells 182, 121–127 (2018). 

137. Reb, L. K. et al. Perovskite and organic solar cells on a rocket flight. Joule 4, 1880–1892 (2020). 

138. Tu, Y. et al. Mixed-cation perovskite solar cells in space. Sci. China: Phys. Mech. Astron. 62, 1–4 (2019). 

139. Lan, Y. et al. Smart solar–metal–air batteries based on BiOCl photocorrosion for monolithic solar energy conversion and storage. Small 18, 2105668 (2022). 

140. Zeng, Q. et al. Integrated photorechargeable energy storage system: nextgeneration power source driving the future. Adv. Energy Mater. 10, 1903930 (2020). 

141. Vega-Garita, V., Ramirez-Elizondo, L., Narayan, N. & Bauer, P. Integrating a photovoltaic storage system in one device: A critical review. Prog. Photovolt: Res. Appl. 27, 346–370 (2019). 

142. Xu, X. et al. A power pack based on organometallic perovskite solar cell and supercapacitor. ACS Nano 9, 1782–1787 (2015). 

143. Li, C. et al. Flexible perovskite solar cell-driven photo-rechargeable lithiumion capacitor for self-powered wearable strain sensors. Nano Energy 60, 247–256 (2019). 

144. Du, P. et al. Self-powered electronics by integration of flexible solid-state graphene-based supercapacitors with high performance perovskite hybrid solar cells. Adv. Funct. Mater. 25, 2420–2427 (2015). 

145. Xu, J., Ku, Z., Zhang, Y., Chao, D. & Fan, H. J. Integrated photosupercapacitor based on PEDOT modified printable perovskite solar cell. Adv. Mater. Technol. 1, 1600074 (2016). 

146. Li, C. et al. Wearable energy-smart ribbons for synchronous energy harvest and storage. Nat. Commun. 7, 13319 (2016). 

147. Sun, H. et al. Energy harvesting and storage devices fused into various patterns. J. Mater. Chem. A 3, 14977–14984 (2015). 

148. Mei, A. et al. A hole-conductor-free, fully printable mesoscopic perovskite solar cell with high stability. Science 345, 295–298 (2014). 

149. Liu, Z. et al. Novel integration of perovskite solar cell and supercapacitor based on carbon electrode for hybridizing energy conversion and storage. ACS Appl. Mater. Interfaces 9, 22361–22368 (2017). 

150. Chakrapani, V., Rusli, F., Filler, M. A. & Kohl, P. A. A combined photovoltaic and Li ion battery device for continuous energy harvesting and storage. J. Power Sources 216, 84–88 (2012). 

151. Mahmoudzadeh, M. A. et al. A high energy density solar rechargeable redox battery. J. Mater. Chem. A 4, 3446–3452 (2016). 

152. Xu, J., Chen, Y. & Dai, L. Efficiently photo-charging lithium-ion battery by perovskite solar cell. Nat. Commun. 6, 8103 (2015). 

153. Chen, P., Li, G.-R., Li, T.-T. & Gao, X.-P. Solar-driven rechargeable lithium–sulfur battery. Adv. Sci. 6, 1900620 (2019). 

154. Hu, Y. et al. A Portable and efficient solar-rechargeable battery with ultrafast photo-charge/discharge rate. Adv. Energy Mater. 9, 1900872 (2019). 

155. Wang, L., Zhao, X., Dai, S., Shen, Y. & Wang, M. High-rate and stable iron phosphide nanorods anode for sodium-ion battery. Electrochim. Acta 314, 142–150 (2019). 

156. Chen, P., Li, T.-T., Yang, Y.-B., Li, G.-R. & Gao, X.-P. Coupling aqueous zinc batteries and perovskite solar cells for simultaneous energy harvest, conversion and storage. Nat. Commun. 13, 64 (2022). 

157. Li, W. et al. High-performance solar flow battery powered by a perovskite/ silicon tandem solar cell. Nat. Mater. 19, 1326–1331 (2020). (High performance and stable flow battery system is realized by combining highefficiency perovskite/silicon tandem solar cells and redox flow batteries.). 

158. Zhao, Y. et al. Solar- versus thermal-driven catalysis for energy conversion. Joule 3, 920–937 (2019). 

159. Huang, H., Pradhan, B., Hofkens, J., Roeffaers, M. B. J. & Steele, J. A. Solardriven metal halide perovskite photocatalysis: design, stability, and performance. ACS Energy Lett. 5, 1107–1123 (2020). 

160. He, J. & Janáky, C. Recent advances in solar-driven carbon dioxide conversion: expectations versus reality. ACS Energy Lett. 5, 1996–2014 (2020). 

161. Li, T.-T., Yang, Y.-B., Li, G.-R., Chen, P. & Gao, X.-P. Two-terminal perovskite-based tandem solar cells for energy conversion and storage. Small 17, 2006145 (2021). 

162. Luo, J. et al. Water photolysis at 12.3% efficiency via perovskite photovoltaics and Earth-abundant catalysts. Science 345, 1593–1596 (2014). (This work employed perovskite solar cells to electrochemically split water into hydrogen and oxygen.). 

23 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

<u>REVIEW ARTICLE</u> 

COMMUNICATIONS MATERIALS <u>|</u> https://doi.org/10.1038/s43246-022-00325-4 

163. Luo, J. et al. Bipolar membrane-assisted solar water splitting in optimal pH. Adv. Energy Mater. 6, 1600100 (2016). 

164. Bin, A. R., Yusoff, M. & Jang, J. Highly efficient photoelectrochemical water splitting by a hybrid tandem perovskite solar cell. Chem. Commun. 52, 5824–5827 (2016). 

165. Gao, J. et al. Solar water splitting with perovskite/silicon tandem cell and TiCsupported Pt nanocluster electrocatalyst. Joule 3, 2930–2941 (2019). 

166. Schreier, M. et al. Efficient photosynthesis of carbon monoxide from CO2 using perovskite photovoltaics. Nat. Commun. 6, 7326 (2015). 

167. Huan, T. N. et al. Low-cost high-efficiency system for solar-driven conversion of CO2 to hydrocarbons. Proc. Natl. Acad. Sci. U.S.A. 116, 9735–9740 (2019). 

168. Esiner, S., Wang, J. & Janssen, R. A. J. Light-driven electrochemical carbon dioxide reduction to carbon monoxide and methane using perovskite photovoltaics. Cell Rep. Phys. Sci. 1, 100058 (2020). 

169. Xiao, K. et al. Solution-processed monolithic all-perovskite triple-junction solar cells with efficiency exceeding 20%. ACS Energy Lett. 5, 2819–2826 (2020). 

170. Kim, D. H. et al. Bimolecular additives improve wide-band-gap perovskites for efficient tandem solar cells with CIGS. Joule 3, 1734–1745 (2019). 

171. Hwang, S. K. et al. Electrochemically deposited CZTSSe thin films for monolithic perovskite tandem solar cells with efficiencies over 17%. Energy Environ. Mater. https://doi.org/10.1002/eem2.12489 (2022). 

### Acknowledgements 

This work was financially supported by the Australian Research Council (DE220100521). A. S. R. B acknowledges support from King Abdullah University of Science and Technology (KAUST) through the Ibn Rushd Postdoctoral Fellowship Award. M.B. acknowledges the support of Griffith University internal grants. P.L.B. is a University of Queensland Laureate Fellow. 

### Author contributions 

M.B. proposed the idea. A.S.R.B. and M.B. conceptualized the proposal. A.S.R.B. wrote the first draft of the review under the supervision of M.B. and P.E.S. The review received critical feedback from Y.L.Z., P.L.B. and M.K.N. 

### Competing interests 

The authors declare no competing interests. 

### Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s43246-022-00325-4. 

Correspondence and requests for materials should be addressed to Paul E. Shaw or Munkhbayar Batmunkh. 

Peer review information Communications Materials thanks Zhaoning Song, Rui Zhu and the other, anonymous, reviewer for their contribution to the peer review of this work. Primary handling editor: John Plummer. Peer reviewer reports are available. 

Reprints and permission information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons license, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons license, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons license and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this license, visit http://creativecommons.org/ licenses/by/4.0/. 

© The Author(s) 2023 

24 

COMMUNICATIONS MATERIALS | (2023) 4:2 | https://doi.org/10.1038/s43246-022-00325-4 | www.nature.com/commsmat 

