# Enhanced charge carrier transport and defects mitigation of passivation layer for efficient perovskite solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 188 |
| 作者 | Zi-Han Qu, Yang Zhao, Fei Ma, Le Mei, Xian-Kai Chen, Hai-Tao Zhou, Xin-Bo Chu, Ying-Guo Yang et al. |
| DOI | 10.1038/s41467-024-52925-y |
| 源文件 | 050_Qu_2024_Enhanced-charge-carrier-transport-and-defects-mi.pdf |

---


Article 

https://doi.org/10.1038/s41467-024-52925-y 

# Enhanced charge carrier transport and defects mitigation of passivation layer for efficient perovskite solar cells 

|Received: 29 April 2024<br>Accepted: 23 September 2024|Zihan Qu<sup>1,2</sup>, Yang Zhao<sup>1,2,3</sup>, Fei Ma<sup>1,2</sup>, Le Mei<sup>4,5,6</sup>, Xian-Kai Chen<br>5,6,<br>Haitao Zhou<br>1,2, Xinbo Chu1,2, Yingguo Yang<br>7,8, Qi Jiang1,2,<br>Xingwang Zhang<br>1,2& Jingbi You<br>1,2|
|---|---|
|Check for updates|Surface passivation has been developed as an effective strategy to reduce trap-<br>state density and suppress non-radiation recombination process in perovskite<br>solar cells. However, passivation agents usually own poor conductivity and<br>hold negative impact on the charge carrier transport in device. Here, we report<br>a binary and synergistical post-treatment method by blending 4-tert-butyl-<br>benzylammonium iodide with phenylpropylammonium iodide and spin-<br>coating on perovskite surface to form passivation layer. The binary and<br>synergistical post-treatedfilms show enhanced crystallinity and improved<br>molecular packing as well as better energy band alignment, benefiting for the<br>hole extraction and transfer. Moreover, the surface defects are further passi-<br>vated compared with unary passivation. Based on the strategy, a record-<br>certified quasi-steady power conversion efficiency of 26.0% perovskite solar<br>cells is achieved. The devices could maintain 81% of initial efficiency after 450 h<br>maximum power point tracking.|



The last decade has seen the incredible development of perovskite solar cells (PSCs)<sup>1–8</sup> , with the reported highest certified power conversion efficiency (PCE) approaching 26%<sup>9</sup> based on composition engineering<sup>8,10–13</sup> , crystal growth modulation<sup>14,15</sup> and surface passivation<sup>5,16,17</sup> , which demonstrates nearly the same level as commercial crystalline silicon solar cells<sup>18</sup> . Among these strategies, surface passivation is becoming the last but crucial for fabricating PSCs with excellent performances<sup>19</sup> . 

In our previous work, phenethylammonium iodide (PEAI) was applied onto the surface of perovskite film to reduce the defect density and suppress the nonradiative recombination of holes and electrons<sup>5</sup> . Two-dimensional (2D) perovskite<sup>20,21</sup> , inorganic compound<sup>22,23</sup> and polymer<sup>24</sup> were reported as passivation agents as well. Those materials 

usually show low conductivity, which could impede the charge transfer in devices, even though the passivation layers were normally ultrathin. This should be one of the reasons why fill factor (FF) increased at a very slow rate in the PCE development process compared with short-circuit current density (JSC) and open-circuit voltage (VOC) and lags behind the Shockley-Queisser (S-Q) limit value<sup>25,26</sup> . 

Considering the trade-off between defect passivation and charge transport, a passivation material holding ability to extract and transmit charge carriers efficiently should be developed. Sargent et al. reported a series of semiconducting polymer to replace the conventional insulator-based passivation agent and the flat-band alignment enabled a better charge transport ability with a FF as high as 83% achieved on PSC<sup>27</sup> . White et al. modified the passivation layer distribution and built 

> 1Laboratory of Semiconductor Physics, Institute of Semiconductors, Chinese Academy of Sciences, 100083 Beijing, P. R. China. 2Center of Materials Science and Optoelectronics Engineering, University of Chinese Academy of Sciences, 100049 Beijing, P. R. China.<sup>3</sup> School of Physics, Liaoning University, 110036 Shenyang, Liaoning, P. R. China.<sup>4</sup> Department of Chemistry, City University of Hong Kong, 999077 Kowloon, Hong Kong, P. R. China.<sup>5</sup> Institute of Functional Nano & Soft Materials (FUNSOM), Soochow University, 215123 Suzhou, Jiangsu, P. R. China.<sup>6</sup> Jiangsu Key Laboratory of Advanced Negative Carbon Technologies, Soochow University, 215123 Suzhou, Jiangsu, P. R. China.<sup>7</sup> Shanghai Synchrotron Radiation Facility (SSRF), Zhangjiang Lab, Shanghai Advanced Research Institute, Chinese Academy of Sciences, 201210 Shanghai, P. R. China.<sup>8</sup> School of Microelectronics, Fudan University, 200433 Shanghai, P. R. China. e-mail: jyou@semi.ac.cn 

Nature Communications |  (2024) 15:8620 

1 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

charge transport pathways inside the passivation layer by introducing the nanopatterned electron transport layer, thus a FF reaching 83.9% could be realized thanks to the improved charge transport process<sup>28</sup> . 

In this work, we propose a mixed organic halide salt system for binary and synergistical post-treatment (BSPT) of RbCl-doped FAPbI3 (FA: HC(NH2)2). Specifically, we blended 4-tert-butylphenylmethylammonium iodide (tBBAI)<sup>29</sup> with phenylpropylammonium iodide (PPAI)<sup>30</sup> in isopropanol (IPA), and the solution was spin-coated onto the perovskite surface for BSPT. Previously, some groups have reported similar combined passivants strategy and mainly focused on the nonradiative recombination loss reduction effect referring to the decreased defect state density<sup>31–33</sup> . We observed that surface defects were further suppressed in our BSPT films compared with PPAI unary passivation as well. More importantly, the crystallinity of passivation layer was prominently strengthened, and the molecular configuration with more ordered packing was achieved through BSPT method, which benefitted the hole transfer from perovskite to HTL. An accelerating electrical field was formed from perovskite to passivation layer, and 

the energy level of perovskite was more suitable for HTL after BSPT, facilitating the hole extraction. As a result, we achieved a certified 26.0% PCE on normal (n-i-p) planar PSCs. The devices could maintain 81% of the original PCE after 450 h maximum power point (MPP) tracking. 

## Results 

### Crystallization quality and molecular packing 

The perovskite film was deposited through a modified two-step method according to our previous report<sup>8</sup> . PPAI, tBBAI or the mixed were dissolved directly in IPA, and the precursor solution was spin-coated on perovskite film without further annealing. The device structure employed in our research and the molecular configuration of PPAI and tBBAI are schematically illustrated in Fig. 1a. The complete device fabrication process is diagrammed in Supplementary Fig. 1. 

We first implemented grazing incident X-ray diffraction (GIXRD) characterization to detect the surface crystallization condition (Fig. 1b 



Fig. 1 | Device structure, film crystallization characterization and all-atom molecular dynamics simulation. a Diagram of PSC structure used in this study with molecular structure of PPAI and tBBAI. b GIXRD patterns at small angle region for pristine perovskite film, perovskite with PPAI, tBBAI and PPAI/tBBAI BSPT posttreatment. c Conventional XRD patterns at small angle region for pristine perovskite film, perovskite with PPAI, tBBAI and PPAI/tBBAI BSPT post-treatment, respectively. a.u. arbitrary units. d–f 2D GIWAXS patterns of pristine perovskite 

film, perovskite with PPAI unary post-treatment and perovskite with BSPT. g The radial distribution function (RDF) in the PPAI unary and PPAI-tBBAI blended film based on AA-MD simulation results. h The interaction energy in the PPAI unary and PPAI-tBBAI blended film according to AA-MD simulation results. Sum (Blend) refers to the total interaction energy between all molecules in the BSPT film. i Possible energy band structure and hole transfer mechanism of perovskite with BSPT. The HOMO level of Spiro-OMeTAD is drawn from our previous report<sup>75</sup> . 

Nature Communications |  (2024) 15:8620 

2 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

and Supplementary Fig. 2). The post-treatment of perovskite film was mainly reflected on the new diffraction peaks in the small angle region, while diffraction peaks corresponding to perovskite lattice planes remained virtually the same, implying that the surface treatment held little effect on perovskite. For PPAI unary treatment, a new peak located at 4.76° was observed. A tiny peak of 4.42° emerged on tBBAI unary treated film, coherent with previous report<sup>34</sup> . When we mixed tBBAI with PPAI and applied BSPT strategy on perovskite film, a new peak located at 4.55° appeared, which fell into the region between 4.42° and 4.76°. We believed that the phenomenon could be explained on the basis of Vegard law, referring to a linear variation of crystal lattice constant when molecular with different size dissolved together. When depositing a single BSPT layer on glass substrate, the diffraction peak at approximately 4.55° could still be observed (Supplementary Fig. 3), indicating that the BSPT layer generally exists in the intrinsic mode when deposited on perovskite surface rather than reacting with perovskite. We further compared the GIXRD peak positions of BSPT perovskite films with different weight ratios between tBBAI and PPAI (Supplementary Fig. 4). We could see from the graph that when tBBAI occupied a larger concentration part, the low-angle diffraction peak was smaller and when PPAI occupied a larger concentration part, the low-angle diffraction peak turned to be larger, which fitted well with the Vegard law. Thus, the new peak after BSPT could indicate a full fusion of the two organic halide salt rather than physical blend. We also noticed that the diffraction intensity at 4.55° significantly enhanced compared with the diffraction intensity at 4.76° in PPAI unary passivation condition. Since the diffraction intensity at 4.42° was weak on tBBAI unary post-treatment film, it could be safe to conclude that the strong intensity signal at 4.55° was indeed due to the improved crystallinity of passivation layer when tBBAI was added into PPAI rather than simply concentration increase, which should be conducive to charge carrier transport process. The I-V measurements of the passivation layers confirmed the better charge transport property of BSPT layer (Supplementary Fig. 5). Conventional X-ray diffraction (C-XRD) results (Fig. 1c and Supplementary Fig. 6) also confirm this finding. 

To investigate the crystallization orientation of passivation layer, we further performed grazing-incidence wide-angle X-ray scattering (GIWAXS) measurements<sup>35</sup> (Fig. 1d–f). We could calculate that the scattering wave vector q was 3.39 nm<sup>−1</sup> and 3.24 nm<sup>−1</sup> for the characteristic diffraction peaks in PPAI unary and BSPT conditions, respectively. The corresponding Bragg scattering spots are pointed out using the red arrows in Fig. 1e, f. The Bragg spot along qz is indicative of a parallel orientation relative to the substrate<sup>36,37</sup> . We inferred that the passivation agents could grow in a layer-by-layer structure mode on the perovskite film and the π-π bonding (large π bond) in the phenyl functional group of the passivation agents could facilitate the charge transfer along the vertical orientation. For BSPT condition, the stronger Bragg spot signal intensity could imply a more parallel molecular orientation relative to the substrate and the more ordered packing situation would be beneficial for charge transport process<sup>38</sup> . The X-ray photoelectron spectroscopy (XPS) was applied to detect the surface state of perovskite before and after post-treatment (Supplementary Fig. 7). In the C 1s core-level energy spectra, the much more intense peak corresponding to C-C bonds after BSPT could be attributed to the large total concentration of passivators, which manifested that both tBBAI and PPAI remained on the surface of perovskite in the BSPT case. The C=O bonds were mostly eliminated after post-treatment, consistent with previous report<sup>5</sup> . The π-π bonding signal was from the phenyl functional group in passivation agent and the stronger signal intensity in BSPT film may imply an improved charge carrier transport process, which proved the GIWAXS results. From Pb 4f and I 3d core-level energy spectra, we could calculate the Pb:I ratio of each condition. The highest Pb:I ratio in BSPT sample could indicate the full filling of 

iodine vacancies at perovskite surface, which should bring the best defect passivation function<sup>5</sup> . 

To uncover the interaction between tBBAI and PPAI as well as the final molecular packing configuration of BSPT, all-atom molecular dynamics (AA-MD) simulation was performed<sup>39–41</sup> . Calculation details can be found in the “Methods” part. For a quantitative analysis, the radial distribution function (RDF, g(r)) of partial centroids between the center of mass (COM) was plotted, which measures the probability of finding a particle at a certain distance from a reference particle. A higher g(r) peak signifies a greater packing density at a specific distance. As shown in Fig. 1g, the intensity of the first peak of g(r) for PPAI in the PPAI unary film localized at the distance of 3.0 Å was significantly lower than that between PPAI and tBBAI in the blended film, thus the packing patterns between PPAI and tBBAI in the mixed film were more dominant than between PPAI and PPAI in the PPAI unary film. This could indicate that a more structured molecular packing system emerged between PPAI and tBBAI in the blended film than in the PPAI unary film, in accordance with the stronger diffraction peak signal from XRD measurement and the stronger Bragg spot signal along qz from GIWAXS measurement shown in BSPT condition than PPAI unary post-treatment condition. Additionally, the peak intensity of g(r) for PPAI in the blended film was less pronounced than in the pure PPAI film, as the peak distance expanded to 3.6 Å in the mixed film. This suggested that the packing patterns of PPAI in the unary film were superseded by those between PPAI and tBBAI in the blended film. The result could explain the XRD diffraction peak angle shift after adding tBBAI into PPAI when applying BSPT strategy. The interaction energy data was also gathered in the unary and blended film. Interestingly, after adding the tBBAI molecules, the interaction energy between PPAI molecules reduced in the mixed film compared with that in the PPAI unary film. Most importantly, the interaction between PPAI and tBBAI was stronger than that between PPAI and PPAI in the mixed film, suggesting that PPAI may prefer to interact with tBBAI to create an ordered pattern in the blended situation (Fig. 1h), which further proved aforementioned outcomes. The molecular conformation in the film containing both PPAI and tBBAI was extracted from the AA-MD trajectories, showing that PPAI molecules could pack well with tBBAI (Supplementary Fig. 8a). Besides, we calculated the distribution of angles between the PPAI benzene plane and tail (Supplementary Fig. 8b) and fitted the data with a Gaussian function. It is worth noting that the peak angle slightly increased to 75.4<sup>o</sup> after adding tBBAI, which was slightly lower when the tBBAI was not present, implying that the PPAI molecules mixed with tBBAI became denser and may be beneficial for the charge transport process (Supplementary Fig. 8c, d). The above theoretical and experimental results suggest that the improved charge transport process could be thanks to the enhanced crystallization quality, ordered molecular orientation and improved molecular packing in BSPT layer, which is a novel interesting insight compared with other combined passivants literatures<sup>31–33</sup> . 

### Energy level alignment and surface morphology 

Ultraviolet photoelectron spectroscopy (UPS) was utilized to confirm the energy band structure of perovskite with and without posttreatment (Supplementary Fig. 9a, b). After PPAI unary post-treatment, the work function (WF) of perovskite surface was uplifted from −4.67 eV to −4.23 eV (minus sign represents relative to vacuum energy level), while BSPT elevated the WF to an even higher value of −3.45 eV. The upshifted WF after post-treatment offered a more negative charged surface, which could induce a dipole with a built-in electrical field oriented from perovskite to passivation layer, accelerating the hole transport and blocking electron<sup>42</sup> . Besides, both PPAI unary posttreatment and BSPT provided an intermediate HOMO energy level between active layer and HTL, revealing a gradient alteration property favorable for hole extraction<sup>43</sup> . Moreover, BSPT perovskite surface held a much smaller HOMO level gap to Spiro-OMeTAD (0.13 eV) than 

Nature Communications |  (2024) 15:8620 

3 

Article 

https://doi.org/10.1038/s41467-024-52925-y 



Fig. 2 | Surface morphology and photoluminescence properties of perovskite with different treatments. a–c 3D AFM mapping images of a pristine perovskite, b perovskite with PPAI unary post-treatment and c perovskite with BSPT, respectively. d Steady-state photoluminescence characterization of pristine perovskite, perovskite with PPAI unary post-treatment and perovskite with BSPT. e TRPL characterization of pristine perovskite, perovskite with PPAI unary post-treatment and perovskite with BSPT. f Transient reflection spectroscopy measurements of 

pristine perovskite, perovskite with PPAI unary post-treatment and perovskite with BSPT, respectively, using 700 nm pump light to excite the films. ΔR means change in reflection. g–i PL mapping patterns of g pristine perovskite film, h perovskite with PPAI unary post-treatment and i perovskite with BSPT. ssPL, TRPL, TRS and PL mapping characterization were carried out on glass/perovskite/passivation layer structure. a.u. arbitrary units. 

PPAI unary post-treated perovskite (0.65 eV), which could ameliorate hole extraction to HTL and avoid hole accumulation at the interface<sup>44</sup> (Fig. 1i and Supplementary Fig. 9c, d). We also employed Kelvin probe force microscopy (KPFM) to detect the surface potential distribution of perovskite films with distinct post-treatments (Supplementary Fig. 10a–c). BSPT sample owned a rather flat CPD distribution, while neat and PPAI unary post-treated sample possessed a rougher distribution with a clearer grain boundary. The evenly distributed CPD (Supplementary Fig. 10d) could probably induce a better physical contact and energy band alignment between perovskite and HTL, conducive for hole transfer and extraction. The higher average CPD values for BSPT and PPAI-treated perovskite film than pristine perovskite film were consistent with the upshifted work function revealed by UPS results<sup>45</sup> . 

We carried out top-view scanning electron microscopy (SEM) and atomic force microscopy (AFM) to depict the surface morphology of neat perovskite film or perovskite film with PPAI unary post-treatment or perovskite film with BSPT. From SEM results (Supplementary Fig. 11), we found out that PPAI unary post-treatment could not entirely 

cover the perovskite surface, leaving some white dots and pinholes. The white dots may be attributed to the accumulation of PPAI at some local part, and the pinholes could be the lack of coverage at some local part due to the accumulation distribution mode of PPAI. Pinholes could be commonly found in unary organic halide salt post-treatment situations<sup>5</sup> . The pinholes could act as tunneling channels for charge carriers. In contrast, BSPT strategy led to a well-covered and uniform surface, which should provide a better post-treatment effect. Since the charge carrier transport ability has been effectively improved, the charge carriers could be transferred even without those pinholes observed in PPAI unary condition as tunneling channels. AFM results further depicted surface height fluctuation of samples and were mapped in a three-dimensional (3D) model (Fig. 2a–c). Although both showed smaller roughness than pristine perovskite (Ra = 22.7 nm), BSPT perovskite film could be even smoother (Ra = 9.76 nm) than PPAI unary post-treated perovskite film (Ra = 17.8 nm). We inferred that the BSPT layer should grow in a similar way as PEAI we reported before<sup>5</sup> , which could fill into the valleys of rough perovskite surface. The higher total concentration of BSPT layer than unary PPAI and tBBAI could lead 

Nature Communications |  (2024) 15:8620 

4 

Article 

https://doi.org/10.1038/s41467-024-52925-y 



Fig. 3 | Device performances and stability testing. a Statistical distributions of VOC, JSC, FF and PCE values in a batch of 25 control devices and 25 target devices, respectively. b J-V curves of the champion target device under 1 Sun condition (100 mW/cm<sup>2</sup> ). Reverse and forward sweep are plotted together. c Steady power output of the champion target device for 600 s with a bias of 1.04 V. d EQE and 

integrated JSC of the champion target device. e The ratio of our certified results to S-Q limit values<sup>51</sup> . VOC, JSC, FF and PCE are listed respectively. f MPP tracking of unencapsulated control and target devices under continuous 1 Sun illumination in a N2 atmosphere at a temperature of 50 ± 5 °C without active cooling. The initial PCE for control and target devices were 25.1% and 25.6% respectively. 

to a more adequate filling to the valleys, which should be the reasons behind the substantial alteration in roughness following our BSPT method. We supposed that the tert-butyl group in tBBAI may also act as a framework to disperse the passivator more homogeneously. A more uniform and smoother surface could avoid the direct contact between perovskite film and electrode, generating less leakage current. 

### Surface defect density characterization 

Surface defects are prone to trap charge carriers, playing the role of nonradiative recombination center and holding negative impact on the charge transport process<sup>19</sup> . We used a 520 nm wavelength light to excite the film and observed a twofold steady-state photoluminescence (ssPL) intensity on the BSPT sample to PPAI unary posttreated sample, both showing obviously stronger signal than pristine perovskite (Fig. 2d). We also conducted the photoluminescence quantum yield (PLQY) tests and the variation trends of PLQY values were in accordance with the ssPL results (Supplementary Fig. 12). The results could provide evidence for the lowest surface defect density after BSPT and the non-radiation recombination loss was effectively reduced. The wavelength corresponding to the maximum PL intensity (λmax) showed negligible variation for all three samples, identical to the ignorable change on cutoff edges of ultraviolet-visible (UV-Vis) absorption spectra and Tauc plots (Supplementary Fig. 13), which was reasonable since the perovskite composition kept the same. For timeresolved PL (TRPL) testing, we operated a 375 nm laser to excite the samples and detected the PL intensity at λmax as a function of time after removing the laser.The TRPL lifetime of BSPT samplewas calculated as 6.36 μs, nearly doubled the PPAI unary treated sample (3.46 μs) and even eight times longer than pristine perovskite film (0.81 μs) (Fig. 2e), which could be explained by fewer recombination centers after BSPT, demonstrating a better passivation function of the binary agents system than unary agent<sup>46–48</sup> . We further measured transient reflection 

spectroscopy (TRS) of perovskite films with different post-treatment (Fig. 2f). When using a pump light with a long wavelength (i.e., low photon energy, 700 nm) to excite the film, the BSPT perovskite film possessed an obviously slower surface carrier decay. Since the pump light of long wavelength creates small carrier concentration gradient and mainly reflects surface condition, it could be safely concluded that BSPT decreases the surface recombination rate of perovskite film<sup>49,50</sup> . BSPT strategy offered the passivation layer a better charge transport property, which allowed a higher total solution concentration than the unary passivation conditions, inducing a better passivation effect. To study the distribution of surface defects, we also mapped the PL intensity of the samples in a 15 × 15 μm area (Fig. 2g–i). The BSPT perovskite film possessed obviously more uniform and larger PL intensity, implying that the surface defects could be homogenously suppressed over the film. This could be attributed to the better coverage of passivation agents on perovskite through BSPT, which was in accordance with the AFM results. 

### Device performance and characterizations 

Encouraged by the better crystallization quality, enhanced hole extraction ability and more effective passivation through BSPT of perovskite surface, we fabricated PSCs based on a device structure of FTO/SnO2/perovskite/passivation layer/Spiro-OMeTAD/Au (FTO, fluorine-doped tin oxide; Spiro-OMeTAD, 2,2′,7,7′-Tetrakis[N,N-di (4-methoxyphenyl)amino]-9,9′-spirobifluorene; Au, gold) (Fig. 1a and Supplementary Fig. 14). We set devices passivated by unary PPAI (10 mg/mL) as our control samples and devices with BSPT as target samples. To optimize the best tBBAI mixing concentration, we compared performances of devices with BSPT layers containing 10 mg/mL PPAI and different tBBAI concentrations (Supplementary Fig. 15 and Supplementary Table 1); 10 mg/mL tBBAI mixed with 10 mg/mL PPAI was confirmed to be the optimal BSPT concentration condition and all target samples were treated under such concentration. 

Nature Communications |  (2024) 15:8620 

5 

Article 

https://doi.org/10.1038/s41467-024-52925-y 



Fig. 4 | Device optoelectronic characterizations. a The VOC-light intensity relationship for control and target device. The ideal factors are presented beside the fitting curves. b Mott-Schottky curves of C-V measurement for control and target devices. The built-in voltages are presented beside the fitting curves. c TAS results 

for control and target devices. d I-V curves of control and target devices under dark environment. e TPC curves and fitting curves for control and target devices. The fitted lifetimes are presented beside the fitting curves. a.u. arbitrary units. f OCVD curves of control and target devices. 

To demonstrate the reproductivity of the devices, we each prepared 25 samples for control and target condition and plotted the PCE distributions as well as the parameters (VOC, JSC and FF) distributions for the two device categories (Fig. 3a). The PCE advancement after BSPT was primarily owe to the dramatic improvement of FF, which should be ascribed to the better hole extraction and transfer ability. An obvious decreased series resistance was also observed, implying a more fluent charge carrier transport channel after applying BSPT strategy (Supplementary Fig. 16), which is in accordance with previous result (Supplementary Fig. 5). The VOC was increased as well, which should be the result of suppressed charge recombination process at perovskite surface. Note that the VOC of control devices was already extremely high (~1.18 V) and fairly close to S-Q limit, the tiny growth on VOC of target devices (~0.01 V) was still inspiring. The JSC was virtually the same since the surface layer was unable to penetrate deep inside the perovskite bulk phase and influence the composition. The best target device we have fabricated showed a PCE of 26.75% tested in our own laboratory (Supplementary Fig. 17 and Supplementary Table 2). Such device showed negligible hysteresis between reverse and forward sweep (Fig. 3b and Supplementary Table 3) and exhibited steady power output of 26.1% under a bias of 1.04 V for 600 s (Fig. 3c). Compared with a typical control device (Supplementary Fig. 18 and Supplementary Table 4), VOC and FF of target device in both reverse and forward sweep were enhanced (Supplementary Table 3). The integrated current density calculated from the external quantum efficiency (EQE) data was in agreement with the JSC collected from the J-V measurement under solar simulator (Fig. 3d). 

We sent our best device to Japan Electrical Safety & Environment Technology Laboratories (JET) for accredited certification. A certified quasi-stabilized PCE of 26.0% with a VOC of 1.19 V, JSC of 26.00 mA cm<sup>−2</sup> and FF of 84% was obtained (Supplementary Fig. 19a), corresponding 

to 83.4%, 95%, 94.1% and 93.2% of S-Q limit respectively<sup>51</sup> (Fig. 3e). When comparing with other high-efficiency normal structure PSCs reported (certified PCE > 25%)<sup>6–9,13,52</sup> , we found that our device possessing the highest PCE/PCESQ value (Supplementary Fig. 20 and Supplementary Table 5), suggesting an extremely ideal charge carrier management during device operation process. Our result was collected both in the best research-cell efficiencies chart published by the National Renewable Energy Laboratory (NREL) in USA<sup>53</sup> (Supplementary Fig. 19b) and solar cell efficiency tables published by Green et al.<sup>54</sup> as the world record. 

Operational stability is a crucial issue for the future commercialization of PSCs. We tracked the MPP output of the unencapsulated devices under continuous 1 Sun illumination (AM 1.5G, 100 mW cm<sup>−2</sup> ) in a nitrogen-filled atmosphere at 50 ± 5 °C without active cooling (Fig. 3f). The target device could maintain 81% of its initial PCE after 450 h continuous output, at the same level with the high-efficient normal structure PSCs<sup>6,13</sup> , while the control device degraded to 78% of its initial PCE. We realize that our operational stability still lags behind commercial demand, which is still a challenge for normal structure with Spiro-OMeTAD as the hole transport layer. Developing a more stable HTL material to replace SpiroOMeTAD could be a route to further promote device stability<sup>55,56</sup> . Besides, constructing interlayer to suppress ion migration process should also benefit the improvement of device stability. Replacing organic functional layer with more stable inorganic material could also be an effective method to enhance device stability. We also conducted thermal stability tests for target device (Supplementary Fig. 21). From the results, we could see that at the first 50 h, the PCE already degraded rapidly, which could be attributed to the formation of low-dimensional perovskite on the 3D perovskite surface<sup>5</sup> (Supplementary Fig. 22). Therefore, a more thermally stable passivation agent should be explored in our future work. Humidity and ultraviolet irradiation stability tests for target device were also included 

Nature Communications |  (2024) 15:8620 

6 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

(Supplementary Figs. 23, 24). Developing better encapsulation and effective ultraviolet filter technologies could further improve device stability. 

We further conducted a series of characterizations based on the complete devices to understand the charge carrier dynamics and recombination mechanism more comprehensively. We first tested the device performances under different light intensity and plotted the VOC variation trends to calculate the ideal factors from the fitting curves<sup>57</sup> . BSPT device showed an ideal factor of 1.09 which was extraordinarily close to 1 and among the smallest as we know, indicating a considerably suppressed Shockley-Read-Hall (SRH) recombination process, while the control device showed a larger value of 1.26 (Fig. 4a). The JSC versus light intensity curves were also plotted under double logarithmic coordinate (Supplementary Fig. 25) and the linear relationship illustrated no obvious charge transport barrier in device<sup>13</sup> . We then applied Mott-Schottky method to measure the built-in voltage (Vbi) in device, which could reflect the charge separation and collection ability<sup>58</sup> . The capacitance-voltage (C-V) measurement was implemented and Vbi was acquired from the intercept with x-axis in C<sup>−2</sup> -V graph. The Vbi of target device was 1.04 V, larger than 1.00 V of control device, implying BSPT could be beneficial for charge separation and collection (Fig. 4b). To evaluate the trap density of states (tDOS), we measured the thermal admittance spectroscopy (TAS)<sup>44,59</sup> , and the results showed that the defect density was obviously reduced in the deep-trap region (above 0.4 eV)<sup>60</sup> after BSPT, with the peak value decreasing from 1.84 × 10<sup>17</sup> cm<sup>−3</sup> eV<sup>−1</sup> to 7.3 × 10<sup>16</sup> cm<sup>−3</sup> eV<sup>−1</sup> , which could be helpful for the charge carrier dynamics (Fig. 4c). The tDOS result offered quantitative evidence for the conclusion induced by PL result. Electrical impedance spectroscopy (EIS) results (Supplementary Fig. 26) also confirmed the reduction of SRH recombination rate after BSPT with a larger recombination resistance fitted by the equivalent circuit (inset graph)<sup>61</sup> . 

We also carried out the I-V measurements under dark environment (Fig. 4d), target device owned a reduced dark current compared with control device near zero voltage point, suggesting decreased electrical leakage channels. For target device, the lowest dark current was nearly located at the zero voltage point, declaring limited charge accumulation at the interfaces<sup>62</sup> . When applying higher forward voltage, the dark current of target device ascended more quickly, signifying better charge transport<sup>63</sup> . In order to study the device transient charge carrier dynamics, we conducted transient photocurrent (TPC) test and open-circuit voltage decay (OCVD) test. For TPC result, a faster photocurrent decay was observed on the target device, with a lifetime of merely 0.94 μs (Fig. 4e), which further proved the quick charge extraction process due to superior charge transfer capacity after BSPT<sup>64</sup> . In OCVD test, a slower VOC decay process indicated a more balanced charge carrier transport through BSPT strategy (Fig. 4f)<sup>65</sup> . A photogenerated charge extraction by linearly increasing voltage (Photo-CELIV) measurement was executed to evaluate the global charge carrier mobilities of device (Supplementary Fig. 27). A mobility value of 2.05 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> was obtained from the target device, which was larger than the control device with 1.90 × 10<sup>−3</sup> cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> , indicating thatthe BSPT indeed facilitated the charge carrier transport in device<sup>66</sup> . Those device characterization results offered adequate evidence for a suppressed charge carrier recombination process as well as a more efficient charge carrier transport process after BSPT, which should be the main reasons for the improvement on both VOC and FF. 

In general, we have proposed a BSPT strategy to improve the charge carrier transport property and defect suppression function of passivation layer. Specifically, a better crystallization quality and a more ordered molecular packing pattern of passivation layer were achieved with a more suitable energy band alignment, inducing a better hole extraction and transfer ability. Moreover, BSPT strategy further diminished surface trap-state density on the basis of PPAI unary 

passivation. As a result, a certified PCE as high as 26.0% was realized on our PSCs. The device could also maintain 81% of its original PCE after 450 h MPP tracking. Our work provides an effective method to passivate surface defects without sacrificing charge carrier transport ability, which should also be enlightening in the fields of other perovskite semiconductor optoelectronic devices<sup>67</sup> . 

## Methods 

### Materials 

SnO2 colloid precursor (tin (IV) oxide, 15% in H2O colloidal dispersion) was purchased from Alfa Aesar. Dimethylformamide (DMF), dimethyl sulfoxide (DMSO), chlorobenzene (CB), isopropanol (IPA), lead iodide (PbI2), rubidium chloride (RbCl), bis(trifluoromethane)sulfonimide lithium salt (Li-TFSI), acetonitrile and 4-tert-butylpyridine (tBP) were all purchased from Sigma Aldrich. Formamidinium iodide (FAI), methylammonium chloride (MACl), 4-tert-butylphenylmethylammonium iodide (tBuPMAI/tBBAI), phenylpropylammonium iodide (PPAI), Tris(2(1H-pyrazol-1-yl)-4-tert-butylpyridine)cobalt(III)Tris(bis(trifluorome thylsulfonyl)imide) (FK209), 2,2′,7,7′-Tetrakis[N,N-di(4-methoxyphenyl) amino]-9,9′-spirobifluorene (Spiro-OMeTAD) and poly[bis(4-phenyl) (2,4,6-trimethylphenyl)amine] (PTAA) were all purchased from Xi’an Yuri Solar Co., Ltd in China. 4-Isopropyl-4’-methyldiphenyliodonium Tetrakis(pentafluorophenyl) borate (TPFB) was purchased from TCI. Except for SnO2 colloid precursor stored in ambient air, all the materials are stored in the nitrogen-filled glove box to avoid the water and oxygen in air. 

### Perovskite solar cells fabrication 

FTO glass was cleaned by sequentially washing with detergent, deionized water (DI), acetone and isopropanol (IPA). Before use, the FTO glass substrate was cleaned with ultraviolet ozone for 10 min. Then the substrate was spin-coated with a thin layer of SnO2 nanoparticle film (2.67%, diluted by DI) at 4000 r.p.m. for 30 s, and annealed in ambient air at 150 °C for 30 min. It is better to clean the SnO2 substrate with ultraviolet ozone for 10 min to improve the surface wetting. After that, the substrate was transferred into a nitrogen-filled glove box to finish the device fabrication process. A two-step method was applied to deposit the perovskite film. First, 1.5 M PbI2 doped with 5 mol% RbCl in DMF:DMSO (9:1) solvent was spin-coated onto SnO2 at 1500 r.p.m for 30 s, annealed at 70 °C for 1 min, and then cooled to room temperature. Second, a solution of FAI: MACl (90 mg: 9–18 mg in 1 ml IPA) was spin-coated onto the PbI2 film at 1800 r.p.m. for 30 s to form perovskite precursor film. Afterward, the perovskite precursor film was taken out from the nitrogen-filled glove box to ambient air for thermal annealing at 150 °C for 15 min in humidity conditions (30–40% relative humidity (RH)) to finally become α-phase FAPbI3 perovskite. It must be noted that humidity is very critical for achieving high crystallinity of perovskite films and high performance of devices. From our previous results, the RH should be controlled at around 30–40%, lower humidity will not promote the perovskite growth and high humidity could lead to perovskite decomposition. Humidifier or dehumidifier is usually used for keeping the RH ataround 30–40% in the open ambient air environment. After perovskite formation, the samples were transferred back to the nitrogen-filled glove box for further processing. For control samples, 10 mg/mL PPAI was dissolved in IPA and spin-coated onto the perovskite surface at a spin rate of 5000 r.p.m. without any further annealing process. For target samples, 10 mg/mL PPAI added with 10 mg/mL tBBAI were dissolved in IPA together and spin-coated onto the perovskite surface at a spin rate of 5000 r.p.m. without any further annealing process to form BSPT layer. To optimize the tBBAI concentration, 5, 7.5, 15 mg/mL tBBAI was also tried within the solution. When depositing the HTL, 72.3 mg/mL Spiro-OMeTAD solution, which consisted of 35 μL Li-TFSI stock solution (260 mg Li-TFSI in 1 mL acetonitrile), 30 μL tBP and 3.59 μL FK209 stock solution (759.81 mg FK209 in 1 mL acetonitrile) in 1 mL chlorobenzene was spin-coated at 

Nature Communications |  (2024) 15:8620 

7 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

1500 r.p.m. for 30 s. The devices without electrode were put in a drying cabinet (25 °C, 1% RH) for overnight oxidation of Spiro-OMeTAD to enhance the conductivity. For the device thermal stability test, PTAA doped with TPFB was used to replace spiro-OMeTAD as the hole transport layer. The concentration of PTAA was 40 mg/mL and the weight ratio of PTAA/TPFB was 10:1.5. The PTAA was deposited on top of the perovskite layer at a spin rate of 2000 r.p.m. for 30 s. Finally, 80 nm of Au film was thermally evaporated as a counter electrode using a shadow mask. The device size areas were 0.108 cm<sup>2</sup> . When measuring J-V and EQE, a 0.07461 cm<sup>2</sup> non-reflective mask was used to define the accurate active cell area. 

### Material characterization 

The XRD patterns of the perovskite films were characterized on a D8 ADVANCE system (Bruker Nano Inc.) using Cu Kα radiation (λ = 1.5405 Å) as the X-ray source. For conventional XRD, a θ−2θ model was used. For the GIXRD measurement, the incident angle was 2.0°. The GIWAXS was performed at BL17B1 beamline of SSRF using the X-ray energy of 10 KeV. Two-dimensional patterns were acquired by a PLATUS 2M detector mounted vertically at a distance ~240 mm from the sample with a grazing-incidence angle of 0.2° or 0.4° and an exposure time of 20 s. XPS was performed on a Thermo Scientific ESCALab 250Xi using 200 W monochromated Al Kα (1486.6 eV) radiation. A 500 μm X-ray spot was used for XPS analysis. The base pressure in the analysis chamber was about 3 × 10<sup>−10</sup> mbar. UPS was also carried out on a Thermo Scientific ESCALab 250Xi, with the HeI (21.22 eV) emission line employed for excitation. AFM and KPFM were performed using a Bruker Dimension Icon (Bruker Nano Inc.) and the scan rate was 0.5 Hz. KPFM measurements were performed in a tapping-contact mode in dark conditions. The SEM images were acquired using a field-emission scanning electron microscope (FEI NanoSEM650), in which an electron beam was accelerated at 500 V to 30 kV, enabling operation at a variety of currents. Absorption spectra were obtained using an ultraviolet-visible spectrometer (Cary 5000). Steady-state PL and TRPL spectra were measured by an FLS1000 spectrometer. During the steady-state PL intensity tests, we kept the slit bandwidth of the incident 520 nm light at 1.20 nm for all three conditions. In this way, we could excite the film sample at the same light power and make the steady-state PL intensity comparable between the samples. The incident 520 nm wavelength light was acquired from a 450 W xenon lamp and the light power density illuminated at the samples was around 3.5 mW/cm<sup>2</sup> . With a 0.05 cm<sup>2</sup> area of light irradiation spot, we could calculate the light power of the 520 nm wavelength light is about 175 μW. For TRPL test, the samples were excited by a diode laser of 375 nm wavelength. For PLQY test, the samples were excited by a 368 nm light from a light-emitting diode and the PLQYs were recorded by a commercialized PLQY measurement system (LQE-50-PL) fromEnlitech. For the PL mapping, a laser scanning confocal microscope equipped with a 532 nm pulse laser was used. The mapping area was set to be 15 × 15 μm. The laser source was set to 10 nW range on the sample for measurement. TRS measurements were conducted in a similar way with literature<sup>49</sup> . A Ti:sapphire laser amplifier (PHAROS-20W) can generate 1028 nm pulse. A branch of fundamentalbeam was transferred into an optical parametric amplifier (TP-OR-ORPHEUS-HP) to produce monochromatic pump pulses with different wavelengths. Another branch of beam was attenuated and focused into sapphire crystals to generate the broadband probe pulses in the visible regions. The time delay between the pump and probe pulses was controlled by a motorized translation stage. The reflected probe pulses were sent into the visible spectrometers. 

### Device characterization 

The I-V characteristics of PPAI and BSPT layer were obtained using a Keithley 2400 Source Meter based on ITO/passivation layer/Au structure with the voltage step as 0.1 V. The J-V characteristics of the 

photovoltaic cells were obtained using a Keithley 2400 Source Meter under simulated 1 Sun AM 1.5G illumination (100 mW cm<sup>−2</sup> ) with a solar simulator (Enlitech, SS-F5-3A) and the light intensity was calibrated by means of a KG-5 Si photodiode. The J-V measurements were carried out in ambient air at 25 °C. The devices were measured both in reverse scan (1.2 V → 0 V, step 0.02 V) and forward scan (0 V → 1.2 V, step 0.02 V). We sent the best devices to an accredited laboratory (JET, Japan) for certification. The operational stability tracking tests were conducted under a 1 Sun white light-emitting diode lamp illumination continuously in a nitrogen-filled glove box at 50 ± 5 °C without active cooling while the unencapsulated PSCs were masked and placed on a homemade sample holder. During measurements, a fixed bias voltage was applied on the devices to retain the PSCs working at MPP and reverse scanned J-V curves were recorded every 60 min by Keithley 2635B Source Meter. The dark I-V measurements were carried out in a black box and tested by Keithley 6482 Source Meter to detect the dark current more precisely. The EQE was measured using an Enlitech EQE measurement system (QE-R3018). TPC measurements were conducted on a commercial apparatus (Arkeo, Cicci Research) based on a highspeed waveform generator that drives high-speed light-emitting diodes (5000 K). EIS, C-V, photo-CELIV and OCVD tests were measured by an all-in-one characterization platform (Paios Fluxim AG) in air conditions without encapsulation. The device structures are the same as the J-V test. For EIS tests, the measurement frequency ranged from 10 Hz to 10 MHz at open-circuit condition under dark environment. C-V measurements were carried out at fixed frequency of 100 kHz under dark environment. The depletion widths W were calculated as 80.0 nm and 84.3 nm for control and target device, respectively, based on the slopes of the Mott-Schottky curves and were applied in the TAS analysis further together with the Vbi obtained from the intercepts. For photo-CELIV test, the delay time was set to 0 s, the light intensity was 100%, the light-pulse length was 5 ms and the sweep ramp rate was 100 V/ms. The mobility value μ could be calculated according to the <u>2d</u><sup>2</sup> <u>1</u> following equation μ = 3Atmax 2<sup>×</sup> 1 + 0:36 4j , in which d represents the jdisp 

perovskite film thickness, A refers to the ramp rate, tmax is the time required to reach the current density peak, jdisp stands for the displacement current density and Δj is the difference between the peak current density and the displacement current density<sup>68</sup> . The TAS measurements were performed on an Agilent E4980A precision LenzCapacitor-Resistance (LCR) meter in the dark at 300 K. The d.c. bias was fixed at 0 V and the amplitude of the a.c. bias was 20 mV. The scanning range of the a.c. frequency (f) was 1–2000 kHz. The tDOS (Nt(Eω)) was calculated through the equation Nt�Eω� = � qk1BT <u>ωddCω</u> VW bi<sup>~~,~~</sup> where q, kB, T, ω, C, W, Vbi, Nt and Eω are elementary charge, Boltzmann constant, temperature under Kelvin thermodynamic scale, angular frequency, specific capacitance, depletion width, build-in voltage, trap density of states and demarcation energy respectively<sup>59</sup> . The demarcation energy is defined based on the equation Eω = kBTln ~~ð~~ 2βρωNV<sup>~~Þ~~,</sup> where βρ is capture coefficient of hole, NV is the effective density of states in the valence band. For FAPbI3 perovskite, βρ and NV are 10<sup>−8</sup> cm<sup>3</sup> /s and 2.524 × 10<sup>19</sup> cm<sup>−3</sup> , respectively, according to literature<sup>69</sup> . Before each measurement, the system was self-calibrated under opencircuit and short-circuit conditions to compensate for any undesired signal from the instrument. 

### All-atom molecular dynamics simulation 

To uncover the impact of halide-based organic salts on the packing, allatom molecular dynamics (AA-MD) was performed using the GROMACS2021.2 package with the optimized potentials for liquid simulations-all atom (OPLS-AA) force field. The concentration used in the simulation (50 mg/mL) was higher than the concentration used in the experiment (10 mg/mL), due to the computational limitations of AA-MD. The first model was built by randomly inserting 200 PPAI and 

Nature Communications |  (2024) 15:8620 

8 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

plenty of IPA molecules in cubic cells. For the BSPT condition, another model containing 200 PPAI, 182 tBBAI, and plenty of IPA molecules in 30 × 30 × 30 nm<sup>3</sup> cells was also built. In both cases, we periodically removed 100 IPA solvent molecules per 300 ps to investigate the impact of the introduction of tBBAI molecules on the kinetic of the PPAI-tBBAI blended film formation. The LINCS algorithm was applied to constrain the covalent bonds with H-atoms<sup>70</sup> . The time step of the simulations was 1.0 fs. All the simulations were performed in periodic boundary conditions. The pressure and temperature were controlled with the Parrinello-Rahman barostat coupled in 1 atm and the V-rescale thermostat<sup>71,72</sup> . The cutoff of the nonbonded interactions was set to 12 Å. The particle mesh Ewald (PME) method was used to calculate the long-range electrostatic interactions<sup>73</sup> . The graphics and visualization analyses were processed by the Visual Molecular Dynamics (VMD) program<sup>74</sup> . 

### Reporting summary 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

## Data availability 

All data generated or analyzed during this study are included in the published article and its Supplementary Information. Additional data are available from the corresponding author upon request. 

## References 

1. Kojima, A., Teshima, K., Shirai, Y. & Miyasaka, T. Organometal halide perovskites as visible-light sensitizers for photovoltaic cells. J. Am. Chem. Soc. 131, 6050–6051 (2009). 

2. Kim, H. S. et al. Lead iodide perovskite sensitized all-solid-state submicron thin film mesoscopic solar cell with efficiency exceeding 9%. Sci. Rep. 2, 7 (2012). 

3. Lee, M. M., Teuscher, J., Miyasaka, T., Murakami, T. N. & Snaith, H. J. Efficient hybrid solar cells based on meso-superstructured organometal halide perovskites. Science 338, 643–647 (2012). 

4. Yang, W. S. et al. High-performance photovoltaic perovskite layers fabricated through intramolecular exchange. Science 348, 1234–1237 (2015). 

5. Jiang, Q. et al. Surface passivation of perovskite film for efficient solar cells. Nat. Photonics 13, 460–466 (2019). 

6. Yoo, J. J. et al. Efficient perovskite solar cells via improved carrier management. Nature 590, 587–593 (2021). 

7. Min, H. et al. Perovskite solar cells with atomically coherent interlayers on SnO2 electrodes. Nature 598, 444–450 (2021). 

8. Zhao, Y. et al. Inactive (PbI2)2RbCl stabilizes perovskite films for efficient solar cells. Science 377, 531–534 (2022). 

9. Park, J. et al. Controlled growth of perovskite layers with volatile alkylammonium chlorides. Nature 616, 724–730 (2023). 

10. Eperon, G. E. et al. Formamidinium lead trihalide: a broadly tunable perovskite for efficient planar heterojunction solar cells. Energy Environ. Sci. 7, 982–988 (2014). 

11. Jeon, N. J. et al. Compositional engineering of perovskite materials for high-performance solar cells. Nature 517, 476–480 (2015). 

12. Saliba, M. et al. Incorporation of rubidium cations into perovskite solar cells improves photovoltaic performance. Science 354, 206–209 (2016). 

13. Jeong, J. et al. Pseudo-halide anion engineering for alpha-FAPbI3 perovskite solar cells. Nature 592, 381–385 (2021). 

14. Bi, D. et al. Polymer-templated nucleation and crystal growth of perovskite films for solar cells with efficiency greater than 21%. Nat. Energy 1, 16142 (2016). 

15. Hui, W. et al. Stabilizing black-phase formamidinium perovskite formation at room temperature and high humidity. Science 371, 1359–1364 (2021). 

16. Zhou, H. P. et al. Interface engineering of highly efficient perovskite solar cells. Science 345, 542–546 (2014). 

17. Zheng, X. et al. Defect passivation in hybrid perovskite solar cells using quaternary ammonium halide anions and cations. Nat. Energy 2, 17102 (2017). 

18. Lin, H. et al. Silicon heterojunction solar cells with up to 26.81% efficiency achieved by electrically optimized nanocrystalline-silicon hole contact layers. Nat. Energy 8, 789–799 (2023). 

19. Gao, F., Zhao, Y., Zhang, X. W. & You, J. B. Recent progresses on defect passivation toward efficient perovskite solar cells. Adv. Energy Mater. 10, 1902650 (2019). 

20. Wang, Z. et al. Efficient ambient-air-stable solar cells with 2D-3D heterostructured butylammonium-caesium-formamidinium lead halide perovskites. Nat. Energy 2, 17135 (2017). 

21. Chen, P. et al. In situ growth of 2D perovskite capping layer for stable and efficient perovskite solar cells. Adv. Funct. Mater. 28, 1706923 (2018). 

22. Yang, S. et al. Stabilizing halide perovskite surfaces for solar cell operation with wide-bandgap lead oxysalts. Science 365, 473–478 (2019). 

23. Li, X. D. et al. Constructing heterojunctions by surface sulfidation for efficient inverted perovskite solar cells. Science 375, 434–437 (2022). 

24. Zuo, L. J. et al. Polymer-modified halide perovskite films for efficient and stable planar heterojunction solar cells. Sci. Adv. 3, 1700106 (2017). 

25. Shockley, W. & Queisser, H. J. Detailed balance limit of efficiency of p-n junction solar cells. J. Appl. Phys. 32, 510–519 (1961). 

26. Ma, C. & Park, N.-G. A realistic methodology for 30% efficient perovskite solar cells. Chem 6, 1254–1264 (2020). 

27. Tan, F. R. et al. In situ back-contact passivation improves photovoltage and fill factor in perovskite solar cells. Adv. Mater. 31, 1807435 (2019). 

28. Peng, J. et al. Nanoscale localized contacts for high fill factors in polymer-passivated perovskite solar cells. Science 371, 390–395 (2021). 

29. Zhu, H. et al. Tailored amphiphilic molecular mitigators for stable perovskite solar cells with 23.5% efficiency. Adv. Mater. 32, 1907757 (2020). 

30. Ren, G. et al. Organic iodides in efficient and stable perovskite solar cells: strong surface passivation and interaction. Energy Environ. Sci. 16, 565–573 (2023). 

31. Liu, Z. et al. Grain regrowth and bifacial passivation for highefficiency wide-bandgap perovskite solar cells. Adv. Energy Mater. 13, 2203230 (2022). 

32. Liu, Z. et al. Reducing perovskite/C60 interface losses via sequential interface engineering for efficient perovskite/silicon tandem solar cell. Adv. Mater. 36, e2308370 (2024). 

33. Liu, C. et al. Bimolecularly passivated interface enables efficient and stable inverted perovskite solar cells. Science 382, 810–815 (2023). 

34. Ling, X. et al. Combined precursor engineering and grain anchoring leading to MA-free, phase-pure, and stable alpha-formamidinium lead iodide perovskites for efficient solar cells. Angew. Chem. Int. Ed. Engl. 60, 27299–27306 (2021). 

35. Qin, M., Chan, P. F. & Lu, X. A systematic review of metal halide perovskite crystallization and film formation mechanism unveiled by in situ GIWAXS. Adv. Mater. 33, 2105290 (2021). 

36. Tsai, H. et al. High-efficiency two-dimensional Ruddlesden-Popper perovskite solar cells. Nature 536, 312–316 (2016). 

37. Zhou, N. et al. Exploration of crystallization kinetics in quasi twodimensional perovskite and high performance solar cells. J. Am. Chem. Soc. 140, 459–465 (2017). 

Nature Communications |  (2024) 15:8620 

9 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

38. Choi, Y. et al. A vertically oriented two-dimensional Ruddlesden-Popper phase perovskite passivation layer for efficient and stable inverted perovskite solar cells. Energy Environ. Sci. 15, 3369–3378 (2022). 

39. Jorgensen, W. L. & Tiradorives, J. The OPLS potential functions for proteins. Energy minimizations for crystals of cyclic peptides and crambin. J. Am. Chem. Soc. 110, 1657–1666 (1988). 

40. Abraham, M. J. et al. GROMACS: high performance molecular simulations through multi-level parallelism from laptops to supercomputers. SoftwareX 1–2, 19–25 (2015). 

41. Dahlgren, M. K., Schyman, P., Tirado-Rives, J. & Jorgensen, W. L. Characterization of biaryl torsional energetics and its treatment in OPLS all-atom force fields. J. Chem. Inf. Model. 53, 1191–1199 (2013). 

42. Liang, L., Luo, H., Hu, J., Li, H. & Gao, P. Efficient perovskite solar cells by reducing interface‐mediated recombination: a bulky amine approach. Adv. Energy Mater. 10, 2000197 (2020). 

43. Chu, X. et al. Surface in situ reconstruction of inorganic perovskite films enabling long carrier lifetimes and solar cells with 21% efficiency. Nat. Energy 8, 372–380 (2023). 

44. Shen, L. et al. Ion diffusion management enables all-interface defect passivation of perovskite solar cells. Adv. Mater. 35, e2301624 (2023). 

45. You, S. et al. Bifunctional hole-shuttle molecule for improved interfacial energy level alignment and defect passivation in perovskite solar cells. Nat. Energy 8, 515–525 (2023). 

46. Zhang, Y. et al. Depth-dependent defect manipulation in perovskites for high-performance solar cells. Energy Environ. Sci. 14, 6526–6535 (2021). 

47. Wu, P. et al. Mixed cations enabled combined bulk and interfacial passivation for efficient and stable perovskite solar cells. Nanomicro. Lett. 15, 114 (2023). 

48. Suo, J. et al. Surface reconstruction engineering with synergistic effect of mixed‐salt passivation treatment toward efficient and stable perovskite solar cells. Adv. Funct. Mater. 31, 2102902 (2021). 

49. Deng, J. et al. Molecular bridge assisted bifacial defect healing enables low energy loss for efficient and stable perovskite solar cells. Adv. Funct. Mater. 32, 2209516 (2022). 

50. Jiang, Q. et al. Surface reaction for efficient and stable inverted perovskite solar cells. Nature 611, 278–283 (2022). 

51. Rühle, S. Tabulated values of the Shockley-Queisser limit for single junction solar cells. Sol. Energy 130, 139–147 (2016). 

52. Kim, M. et al. Conformal quantum dot-SnO2 layers as electron transporters for efficient perovskite solar cells. Science 375, 302–306 (2022). 

53. National Renewable Energy Laboratory, U.S. Department of Energy. Interactive Best Research-Cell Efficiency Chart. https://www.nrel. gov/pv/interactive-cell-efficiency.html (USA, 2023). 

54. Green, M. A. et al. Solar cell efficiency tables (version 62). Prog. Photovoltaics 31, 651–663 (2023). 

55. Wang, T. et al. Transporting holes stably under iodide invasion in efficient perovskite solar cells. Science 377, 1227–1231 (2022). 

56. Jeong, M. J., Yeom, K. M., Kim, S. J., Jung, E. H. & Noh, J. H. Spontaneous interface engineering for dopant-free poly(3-hexylthiophene) perovskite solar cells with efficiency over 24%. Energy Environ. Sci. 14, 2419–2428 (2021). 

57. Yang, D. et al. Surface optimization to eliminate hysteresis for record efficiency planar perovskite solar cells. Energy Environ. Sci. 9, 3071–3078 (2016). 

58. Almora, O., Aranda, C., Mas-Marzá, E. & Garcia-Belmonte, G. On Mott-Schottky analysis interpretation of capacitance measurements in organometal perovskite solar cells. Appl. Phys. Lett. 109, 173903 (2016). 

59. Ni, Z. Y. et al. Resolving spatial and energetic distributions of trap states in metal halide perovskite solar cells. Science 367, 1352–1358 (2020). 

60. Luo, Y. et al. Dissolved-Cl2 triggered redox reaction enables highperformance perovskite solar cells. Nat. Commun. 14, 3738 (2023). 

61. Wu, J. et al. Regioselective multisite atomic-chlorine passivation enables efficient and stable perovskite solar cells. J. Am. Chem. Soc. 145, 5872–5879 (2023). 

62. Sadollahkhani, A. et al. Energetic barriers to interfacial charge transfer and ion movement in perovskite solar cells. ChemPhysChem 18, 3047–3055 (2017). 

63. Jiang, Q. et al. Enhanced electron extraction using SnO2 for highefficiency planar-structure HC(NH2)2PbI3-based perovskite solar cells. Nat. Energy 2, 1–7 (2017). 

64. Wang, S. et al. Over 24% efficient MA-free CsxFA1−xPbX3 perovskite solar cells. Joule 6, 1344–1356 (2022). 

65. Zhang, Y. et al. 24.11% high performance perovskite solar cells by dual interfacial carrier mobility enhancement and charge-carrier transport balance. Adv. Energy Mater. 12, 2201269 (2022). 

66. Im, J. H., Jang, I. H., Pellet, N., Grätzel, M. & Park, N. G. Growth of CH3NH3PbI3 cuboids with controlled size for high-efficiency perovskite solar cells. Nat. Nanotechnol. 9, 927–932 (2014). 

67. Khan, R., Shi, G., Chen, W., Xiao, Z. & Ding, L. Interface engineering yields efficient perovskite light-emitting diodes. J. Semicond. 44, 120501 (2023). 

68. Stephen, M., Genevičius, K., Juška, G., Arlauskas, K. & Hiorns, R. C. Charge transport and its characterization using photo-CELIV in bulk heterojunction solar cells. Polym. Int. 66, 13–25 (2017). 

69. Wang, M. H. et al. Synergetic co-modulation of crystallization and co-passivation of defects for FAPbI3 perovskite solar cells. Adv. Funct. Mater. 32, 2108567 (2022). 

70. Hess, B., Bekker, H., Berendsen, H. J. C. & Fraaije, J. LINCS: a linear constraint solver for molecular simulations. J. Comput. Chem. 18, 1463–1472 (1997). 

71. Parrinello, M. & Rahman, A. Polymorphic transitions in single crystals: a new molecular dynamics method. J. Appl. Phys. 52, 7182–7190 (1981). 

72. Bussi, G., Donadio, D. & Parrinello, M. Canonical sampling through velocity rescaling. J. Chem. Phys. 126, 014101 (2007). 

73. Essmann, U. et al. A smooth particle mesh Ewald method. J. Chem. Phys. 103, 8577–8593 (1995). 

74. Humphrey, W., Dalke, A. & Schulten, K. VMD: visual molecular dynamics. J. Mol. Graphics 14, 33–38 (1996). 

75. Ma, F. et al. Efficient perovskite solar cells with iodine-doped spiroOMeTAD hole transport layer via fast oxidation. Sol. RRL 7, 2300042 (2023). 

## Acknowledgements 

This work was supported by the National Key Research and Development Program of China (grant number: 2020YFB1506400) and the National Natural Science Foundation of China (grant number: 61925405). We thank Y. Li from Soochow University for helping with TAS measurements, C. Yi from Tsinghua University for helping with TPC characterization and L. Meng from the Institute of Chemistry, Chinese Academy of Sciences for helping with Photo-CELIV measurement. 

## Author contributions 

J.Y. directed and supervised the project. J.Y. and Z.Q. conceived the idea and designed the experiment. Y.Z. contributed to device fabrication, characterization and certification. L.M. and X.-K.C. conducted the allatom molecular dynamics simulation. Y.Y. conducted the GIWAXS characterizations. F.M., H.Z., X.C., Q.J. and X.Z. were involved in data analysis. Z.Q. and J.Y. co-wrote the manuscript. All authors contributed to the discussions and finalization of the manuscript. 

## Competing interests 

The authors declare no competing interests. 

Nature Communications |  (2024) 15:8620 

10 

Article 

https://doi.org/10.1038/s41467-024-52925-y 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-024-52925-y. 

Correspondence and requests for materials should be addressed to Jingbi You. 

Peer review information Nature Communications thanks Jingjing Xue and the other anonymous reviewer(s) for their contribution to the peer review of this work. A peer review file is available. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do not have permission under this licence toshare adapted material derived from this article or parts of it. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http:// creativecommons.org/licenses/by-nc-nd/4.0/. 

© The Author(s) 2024 

Nature Communications |  (2024) 15:8620 

11 

