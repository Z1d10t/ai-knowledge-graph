# All-perovskite tandem solar cells achieving >29% efficiency with improved (100) orientation in wide-bandgap perovskites

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature Materials |
| 年份 | 2025 |
| 引用量（Semantic Scholar） | 353 |
| 作者 | Zhouyang Liu, Ren-Xing Lin, Mingyang Wei, Mengran Yin, Pu Wu, Man-Ya Li, Lu-Dong Li, Yu-Rui Wang et al. |
| DOI | 10.1038/s41563-024-02073-x |
| 源文件 | 018_Liu_2025_All-perovskite-tandem-solar-cells-achieving-29-e.pdf |

---
## **nature materials** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

# **All-perovskite tandem solar cells achieving >29% efficiency with improved (100) orientation in wide-bandgap perovskites** 

|Received: 12 November 2023<br>Accepted: 3 November 2024|**Zhou Liu**<sup>**1,6**</sup>**, Renxing Lin**<br> <sup>**1,6**</sup><br>**, Mingyang Wei**<br> <sup>**2,6**</sup>**, Mengran Yin**<sup>**1,6**</sup>**, Pu Wu**<sup>**1**</sup>**,**<br>**Manya Li**<sup>**1**</sup>**, Ludong Li**<sup>**1**</sup>**, Yurui Wang**<sup>**1**</sup>**, Gang Chen**<br> <sup>**3**</sup>**, Virginia Carnevali**<br> <sup>**4**</sup>**,**<br>**Lorenzo Agosta**<br> <sup>**4**</sup>**, Vladislav Slama**<br> <sup>**4**</sup>**, Nikolaos Lempesis**<br> <sup>**4**</sup>**, Zhichao Wang**<sup>**1**</sup>**,**|
|---|---|
|Published online: 10 January 2025<br>Check for updates|**Meiyu Wang**<sup>**1**</sup>**, Yu Deng**<br> <sup>**1**</sup>**, Haowen Luo**<sup>**1**</sup>**, Han Gao**<sup>**1**</sup>**, Ursula Rothlisberger**<br> <sup>**4**</sup>**,**<br>**Shaik M. Zakeeruddin**<br> <sup>**2**</sup>**, Xin Luo**<sup>**5**</sup>**, Ye Liu**<sup>**5**</sup>**, Michael Grätzel**<br> <sup>**2**</sup><br>**&**<br>**Hairen Tan**<br> <sup>**1,5**</sup>|
||Monolithic all-perovskite tandem solar cells present a promising approach<br>for exceeding the efficiency limit of single-junction solar cells. However,<br>the substantial open-circuit voltage loss in the wide-bandgap perovskite<br>subcell hinders further improvements in power-conversion efficiency. Here<br>we develop wide-bandgap perovskite films with improved (100) crystal<br>orientation that suppress non-radiative recombination. We show that using<br>two-dimensional perovskite as an intermediate phase on the film surface<br>promotes heterogeneous nucleation along the (100) three-dimensional<br>perovskite facets during crystallization. Preferred (100) orientations can be<br>realized by augmenting the quantity of two-dimensional phases through<br>surface composition engineering, without the need for excessive two-<br>dimensional ligands that otherwise impede carrier transport. We demonstrate<br>an open-circuit voltage of 1.373 V for 1.78 eV wide-bandgap perovskite solar<br>cells, along with a high fill factor of 84.7%. This yields an open-circuit voltage<br>of 2.21 V and a certified power-conversion efficiency of 29.1% for all-perovskite<br>tandem solar cells, measured under the maximum power-point conditions.|



All-perovskite tandem solar cells comprise wide-bandgap (WBG, ~1.8 eV) lead (Pb) halide perovskite top cells paired with narrow-bandgap (NBG, ~1.2 eV) mixed lead–tin (Pb–Sn) bottom cells<sup>1–3</sup> . Compared to their single-junction counterparts, this configuration reduces carrier thermalization and captures a broader band of the solar spectrum, promising power-conversion efficiencies (PCEs) of up to 44% (refs. 4,5). In recent years, the performance of all-perovskite tandems has seen rapid evolution, surpassing that of single-junction perovskite solar cells 

(PSCs)<sup>2,3,6–8</sup> . This progress is attributed to advancements in both WBG and NBG subcells. Particularly, the PCEs of NBG PSCs have exceeded 23% with an open-circuit voltage ( _V_ OC) of over 0.9 V (refs. 1,9–12). The factor limiting further efficiency gains is the below-average performance of WBG PSCs. 

WBG PSCs often experience significant _V_ OC and fill factor (FF) losses (Supplementary Fig. 1). These losses stem from pronounced non-radiative recombination, both within the neat perovskite film and 

> 1National Laboratory of Solid State Microstructures, Collaborative Innovation Center of Advanced Microstructures, College of Engineering and Applied Sciences, Frontiers Science Center for Critical Earth Material Cycling, Nanjing University, Nanjing, China.<sup>2</sup> Laboratory of Photonics and Interfaces, Ecole Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>3</sup> School of Physical Science and Technology, ShanghaiTech University, Shanghai, China.<sup>4</sup> Laboratory of Computational Chemistry and Biochemistry, Ecole Polytechnique Fédérale de Lausanne, Lausanne, Switzerland.<sup>5</sup> Research and Development Center, Renshine Solar (Suzhou) Co., Ltd, Changshu, China.<sup>6</sup> These authors contributed equally: Zhou Liu, Renxing Lin, Mingyang Wei, Mengran Yin. e-mail: rxlin@nju.edu.cn; michael.graetzel@epfl.ch; hairentan@nju.edu.cn 

Nature Materials | Volume 24 | February 2025 | 252–259 

**252** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 



<!-- Start of picture text -->
a b c<br>Before annealing M-SPA After annealing (100) M-SPA<br>SPA SPA 50 4<br>DA DA<br>n  = 1 Control Control 40 3<br>(200)<br>2<br>(110) 30<br>1<br>20<br>0<br>10 12 16 20<br>2 θ  (°)<br>0<br>5 10 15 20 25 30 5 10 15 20 25 30<br>2 θ  (°) 2 θ  (°)<br>d<br>Precursor solution Before annealing film After annealing film<br>2D<br>layer<br>MAI/PEAI Annealing<br>(100)<br>Anti-solvent plane<br>Substrate Substrate Substrate<br>Control DA SPAM-SPA<br>Intensity (a.u.)<br>Intensity (a.u.) Intensity (a.u.)<br>(100)/(110) peak area ratio (a.u.)<br><!-- End of picture text -->

**Fig. 1 | Formation process of DA, SPA and M-SPA perovskite films. a** , XRD of DA, SPA and M-SPA perovskite precursor films. **b** , **c** , XRD ( **b** ) and (100)/(110) peak ratio ( **c** ) of annealed DA, SPA and M-SPA perovskite films. The inset shows the normalized XRD pattern of the annealed films. **d** , Schematic diagram of the M-SPA perovskite film formation process. 

at the interface between the absorber and the charge transport layers (Supplementary Table 1)<sup>13</sup> . Recent progress indicates that interfacial energy losses can be curtailed through interface engineering and optimizing charge transport materials, elevating the PCEs of 1.8 eV WBG PSCs to ~20% (refs. 2,14,15). However, mitigating the non-radiative recombination inherent to WBG perovskite films remains elusive. Whereas incorporating molecular additives (for example ionic liquids and ammonium ligands) shows promise<sup>14,16–18</sup> , the _V_ OC losses relevant to neat perovskites persist in WBG PSCs, typically exceeding 120 mV, which is far higher than those in ~1.5 eV-bandgap PSCs. 

Controlling crystallographic orientation represents a promising approach for enchancing the optoelectronic properties of WBG perovskite films<sup>18–20</sup> . Both theoretical and experimental studies suggest that cubic perovskite crystals with a preferred (100) orientation exhibit superior carrier mobility and fewer trap densities than those with primary (110) or (111) orientations<sup>21–24</sup> . These findings apply to different perovskites with diverse A- and X-site compositions, where A can be methylammonium (MA), formamidinium (FA) or caesium (Cs) and X usually denotes bromide (Br) or iodide (I)<sup>25,26</sup> . Unfortunately, the ionic nature of metal-halide perovskites, combined with their rapid crystallization, often leads to films with randomly oriented crystalline domains<sup>27–29</sup> . 

Several strategies have been developed to manipulate the crystal orientation of perovskite films. For instance, Xu et al. reported that in FAMA perovskites, increasing the MA content could reduce the surface energy of the (100) crystal facet<sup>30</sup> , thermodynamically favouring its formation. They also demonstrated that cascade doping with alkali cations could kinetically drive the (100) orientation during crystallization<sup>31</sup> . Meanwhile, various molecular additives have been employed to control nucleation, crystal growth and the surface energy of crystal facets in order to create highly oriented perovskites<sup>32,33</sup> . Notable examples include alkylamine ligands that restrict the tilt of crystal grains for a dominant (100) orientation<sup>22,34</sup> and organic spacers<sup>35</sup> , such as phenylethylammonium iodide (PEAI), that directly intercalate into 

perovskite lattices to form two-dimensional (2D) layered structures, inducing anisotropic crystal growth. 

Despite the progress, achieving the (100)-oriented WBG perovskite films remains a formidable challenge. State-of-the-art all-perovskite tandem solar cells utilize an MA-free, mixed-cation/mixed-halide WBG perovskite formulation, namely, FA _x_ Cs1- _x_ Pb(I _y_ Br1- _y_ )3, to improve thermal and phase stability<sup>14,36</sup> . However, these compositions often favour the growth of the (110) crystal facet. Furthermore, the WBG perovskites suffer from having inhomogeneous film structures due to the competing crystallization of varying compositions<sup>21,37–39</sup> . These factors necessitate excessive incorporation of molecular additives (for example 4-fluorophenylethylammonium iodide) to improve the (100) orientation. However, this undermines carrier transport due to the insulating nature of typical additives<sup>32</sup> . 

In this Article, we sought to improve the efficacy of crystallization control in WBG perovskite films using molecular additives. We found that, with the standard organic spacer PEAI, premixing with the precursor solution enhanced crystal growth along the [100] direction, but this did not modify the nucleation process. Introducing PEAI at the liquid/air interface generated intermediate 2D templates, which promoted heterogeneous nucleation and enhanced the vertical stacking of (100)-oriented crystals. We then manipulated the formation of 2D templates through surface composition engineering, achieving WBG perovskites with improved (100) orientation. This led to suppressed non-radiative recombination for WBG PSCs, yielding a _V_ OC of 1.373 V for a 1.78 eV bandgap. The corresponding tandem devices exhibited a _V_ OC of 2.211 V and a certified quasi-steady-state PCE of 29.1%. 

### **Crystallographic orientation control in WBG perovskite films** 

FA0.8Cs0.2Pb(I0.6Br0.4)3 perovskite, with a cubic phase (Supplementary Fig. 2), exhibiting a suitable bandgap of 1.78 eV for all-perovskite tandem applications<sup>5</sup> , has previously demonstrated excellent phase stability for long-term device operation. However, a preferred (110) 

Nature Materials | Volume 24 | February 2025 | 252–259 

**253** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

orientation has also been observed<sup>14,40–42</sup> . We noted that increasing the (100) orientation could also modify the bulk properties of perovskite films (Supplementary Fig. 3)<sup>43</sup> . Two common approaches were investigated (Supplementary Fig. 4): (1) adding PEAI into the precursor solution as a direct additive (DA) and (2) introducing PEAI into the anti-solvent as a solution-process additive (SPA). 

We evaluated the efficacy of these methods using X-ray diffraction (XRD). To monitor the progression of film formation, we analysed the one-step processed films both pre- and post-thermal annealing (Fig. 1a,b). In films without additives (control), both the (100) and (110) diffraction peaks were observed for WBG perovskites. We calculated the ratio of the (100) to (110) diffraction peak intensities (that is _I_ (100)/(110)) to assess the degree of preferential crystal orientation. This value remained similar for the unannealed control and DA films, suggesting that the direct addition of PEAI has a minimal effect on nucleation or initial crystal growth. However, after thermal annealing, the fully crystallized DA film showed an _I_ (100)/(110) 1.8 times higher than that of the control (Fig. 1c). This is likely to be due to the preferential surface anchoring of PEAI on the (100) facet, since replacing FA with PEA cations resulted in a more pronounced reduction in surface energy for the (100) compared to the (110) or (111) surface (1.8 versus 0.98 eV nm<sup>–2</sup> , Supplementary Fig. 5 and Methods)<sup>23</sup> . For the SPA method, an enhanced (100) orientation was evident even before thermal annealing and the _I_ (100)/(110) of the final film was notably higher than that of the DA film (7.8 versus 1.7 eV nm<sup>–2</sup> ) (Fig. 1c). 

XRD results indicate that the SPA method outperforms the DA approach in the control of facet orientation, as it promoted greater (100) orientation during perovskite nucleation, whereas DA primarily influences crystal growth. Time-of-flight secondary ion mass spectrometry (TOF-SIMS) showed that the SPA method introduced PEAI on the surface of wet films, while PEAI was distributed throughout the bulk of the DA film (Supplementary Fig. 6). The photoluminescence (PL) spectra prove the existence of _n_ = 1 perovskite phases on the surface of unannealed SPA films (Supplementary Figs. 7 and 8). Despite their trace amounts relative to three-dimensional (3D) perovskites and their absence in the XRD patterns (Fig. 1a), surficial 2D perovskites induce more effective tuning in crystallographic orientation than the direct PEAI additive. From cross-sectional scanning electron microscopy (SEM) images of control films at various stages of thermal annealing (Supplementary Fig. 9), we observed that perovskite nucleation occurs at the liquid/air interface, followed by downward crystal growth<sup>44</sup> . We reasoned that introducing 2D perovskites on the film surface provided heterogeneous nucleation sites, enhancing the formation of (100) 3D perovskites in the out-of-plane direction, given the low interfacial energy of 2D/3D heterostructures (Supplementary Fig. 5). The subsequent downward growth resulted in vertically aligned crystals and thus a higher degree of (100) orientation compared to both the control and the DA method. 

Increasing the concentration of PEAI can enhance the efficacy of the SPA approach by providing more 2D templates. However, this could compromise charge transport<sup>32</sup> . Given that the formation of 2D/3D heterostructures occurs more readily on the surface of MA perovskites than on FACs perovskites<sup>45</sup> , we incorporated a mixture of MAI and PEAI with a weight ratio of 1:2 as the mixed solution-process additive (M-SPA) to create a local MA-rich environment and thus improve the presence of 2D templates. In the XRD patterns of the unannealed M-SPA films, we identified _n_ = 1 (layer number of the perovskite; n, number of inorganic lead halide sheets) layered perovskite at 5.2°. The corresponding 2D/3D PL peak intensity ratio was 3.2 times higher than that of the SPA counterparts (Supplementary Fig. 7), suggesting increased amounts of 2D templates. Consequently, compared to the control, the M-SPA method led to a 52-fold increase in _I_ (100)/(110) for the annealed films (Supplementary Table 2). We noted that this enhancement was achieved without adding more insulating ammonium ligands. The 2D phases formed during solution processing also disappeared in the final films (Fig. 1b). This is likely to be due to the 

dynamic interactions at 2D/3D interfaces under high temperatures<sup>46</sup> . For comparison, introducing a mixture of MAI and PEAI in the DA method (that is the mixed DA (M-DA) approach) proved less effective, as no 2D template was found on the film surface (Supplementary Fig. 10). This is possibly due to their ultrathin nature or higher _n_ values that cannot be distinguished from 3D perovskites<sup>47</sup> . 

To gain deeper insights into the role of the M-SPA method, we varied the weight ratios of MAI and PEAI in the anti-solvent (Supplementary Figs. 11 and 12). Therefore, the optimal ratio of MAI to PEAI strikes a balance between 2D template formation and relative uniform 3D structures. For comparison, other processing parameters such as the type of anti-solvent, dripping time and annealing temperature were found to be less effective in controlling the (100) orientation without the inclusion of additives (Supplementary Fig. 13). The M-SPA approach is also effective for blade-coated perovskite films (Supplementary Figs. 14 and 15). 

### **Characterization of WBG perovskite films** 

We utilized SEM (Fig. 2a) to investigate the perovskite surface morphology and grazing incidence wide-angle X-ray scattering (GIWAXS) (Fig. 2b), in combination with high-resolution scanning transmission electron microscopy (HR-STEM) (Fig. 2c), for the bulk structure. From SEM (Fig. 2a), the control film exhibited an average grain size of 265 nm, which decreased to 204 nm in the DA film. The SPA and M-SPA methods resulted in average grain sizes of 262 and 322 nm (Supplementary Fig. 16), respectively. These findings suggest that the DA method leads to smaller crystal sizes, possibly due to retarded coalescence of tiny crystals<sup>48</sup> . Meanwhile, the SPA and M-SPA methods, which introduce PEAI on the film surface, have limited impact on the final crystal sizes. Nevertheless, excess MAI content in the non-optimized M-SPA method led to smaller grain sizes due to inhomogeneous film formation (Supplementary Fig. 11). 

To accurately determine the crystal orientations in different samples, we performed GIWAXS measurements. All samples showed a Debye–Scherrer ring at _q_ = 1.0 Å<sup>−1</sup> for the (100) plane of WBG perovskites, with no signals for layered-perovskite-related patterns (Fig. 2b). We integrated the diffraction intensity azimuthally over this Debye–Scherrer ring and observed the (100) peak at 45 and 135° azimuthal angles for both the control and DA films (Supplementary Fig. 17), respectively. This suggests a tilt of the (100) plane preferentially along these directions, representing the corner-up orientation of the cubic crystals<sup>33</sup> . For the SPA approach, which demonstrated improved orientation control compared to the DA method, the resultant film exhibited both corner-up and face-up orientations, with (100) peaks appearing at 0, 45, 90, 135 and 180° (Supplementary Fig. 17). The use of M-SPA further reduced the (100) peaks linked to the corner-up orientation, producing (100)-oriented perovskite films along the out-of-plane direction. The percentage of (100)-oriented domains was calculated by comparing the total integrated intensity from 80 to 110° azimuthal angles to the overall (100) azimuthal profiles (Supplementary Figs. 18 and 19). The M-SPA method enhanced the (100) orientation 2.1-fold compared to the control sample near the film surface (at an incident angle of 0.1°) and maintained over 25% (100)-oriented domains across various incident angles. Both the SPA and M-SPA methods improve the (100) crystal orientation near the film surface, while the DA method primarily affects the crystal orientation within the bulk. 

Cross-sectional high-resolution transmission electron microscope images of the M-SPA film showed predominant (100) planes of WBG perovskites with an interplanar spacing of 3.2 Å, evident both near the film surface (Fig. 2d) and at the buried interface (Fig. 2e). This is consistent with the enhanced (100) orientation observed in XRD and GIWAXS. The fast Fourier transform (FFT) patterns further confirmed the characteristic Fourier spots corresponding to the (100) crystalline facet. In addition, we detected an interplanar spacing of 6.4 Å in the region near the surface, which we ascribed to the residual 2D templates after post annealing (Fig. 2d)<sup>49</sup> . 

Nature Materials | Volume 24 | February 2025 | 252–259 

**254** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 



<!-- Start of picture text -->
a<br>500 nm 500 nm 500 nm 500 nm<br>b<br>Control DA SPA M-SPA<br>2.0<br>1.5<br>1.0<br>0.5<br>0<br>–1.5 –1.0 –0.5 0 0.5 1.0 1.5 –1.5 –1.0 –0.5 0 0.5 1.0 1.5 –1.5 –1.0 –0.5 0 0.5 1.0 1.5 –1.5 –1.0 –0.5 0 0.5 1.0 1.5<br>q r (Å –1 ) q r (Å –1 ) q r (Å –1 ) q r (Å –1 )<br>c d e<br>Region 1 Region 2 Region 3  Region 3<br>Region 1<br>Scale 1<br>Scale 2 6.4 Å<br>Region 2<br>5 nm 5 nm<br>200 nm<br>–1Å) ( q z<br><!-- End of picture text -->

**Fig. 2 | Characterization of WBG perovskite films. a** , **b** , SEM ( **a** ) and GIWAXS ( **b** ) images of perovskite films prepared using the control, DA, SPA and M-SPA methods. **c** , TEM images of the M-SPA film. Scale 1 and Scale 2 are the upper and lower regions of the cross-section, which correspond to **d** and **e** respectively 

when magnified. **d** , **e** , Cross-sectional HR-STEM images from Scale 1 ( **d** ) and Scale 2 ( **e** ). The insets show the corresponding FFT patterns of Region 1, Region 2 and Region 3. The red arrows in **d** indicate the magnitude of the interplanar spacing. 

### **Performance of WBG perovskite solar cells** 

We carried out photoluminescence quantum yield measurements to evaluate the non-radiative recombination losses in both the neat perovskite absorber layers and the multilayer device stacks (Fig. 3a and Supplementary Note 1). The schematic measurement diagram and the corresponding quasi-Fermi level splitting (QFLS) are shown in Fig. 3a,b, respectively. For the neat perovskites, the QFLS values are 1,324, 1,364, 1,407 and 1,415 mV for the control, DA, SPA and M-SPA methods, respectively. This indicates that the M-SPA samples exhibit the lowest non-radiative recombination loss, consistent with their highest degree of (100) orientations. When accounting for the interfacial recombination in the full device stack, the QFLS values decreased to 1,278, 1,322, 1,367 and 1,385 mV, respectively. Nevertheless, the M-SPA samples maintain the highest QFLS. 

We fabricated WBG PSCs with interfacial passivation (Methods)<sup>50</sup> . The pseudo- _J_ – _V_ curves, derived from light-intensity-based _V_ OC curves (Supplementary Note 2), along with the actual measured _J_ – _V_ curves from the devices, are presented in Supplementary Fig. 20. Figure 3c quantifies the contribution of reducing non-radiative recombination to the boost in device _V_ OC. Using the M-SPA method, the _V_ OC increase is dominantly attributed to the reduction of bulk recombination rather than interfacial recombination. We further analysed the various contributions to FF losses across different WBG PSCs (Fig. 3d) and found that both non-radiative and transport losses were reduced with the M-SPA method, leading to an enhanced FF for WBG PSCs. 

To further assess the non-radiative recombination of different WBG perovskites, we conducted time-resolved photoluminescence measurements on control, DA, SPA and M-SPA perovskite films (Fig. 3e). The PL decay lifetime for the M-SPA sample is 182 ns, surpassing SPA (88 ns), DA (67 ns) and control (21 ns) samples. The carrier dynamics of the perovskite films can be modelled with balanced trapping rates<sup>14</sup> , showing reduced carrier trapping for the M-SPA process (Supplementary Fig. 21). We further analysed the transient reflection (TR) spectra of the perovskite films (Supplementary Fig. 22). These show a single bleaching peak around 690 nm for both SPA and M-SPA samples, characteristic of 3D WBG perovskites<sup>51</sup> , confirming the absence of 2D perovskite phases in the final films. The decay rate of the TR signal for the SPA sample is considerably higher than that for the M-SPA sample. This decrease in non-radiative recombination loss is further evidenced by the improved electroluminescence (EL) external quantum efficiency (EQE) observed in M-SPA WBG PSCs (Fig. 3f). In addition, the terahertz transient analysis showed that the effective mobility (that is the combined mobility of both holes and electrons) is 31.7 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for M-SPA samples, compared to 25.1 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> for SPA samples (Supplementary Fig. 23). We optimized the additive concentration in the anti-solvent during the M-SPA process (Supplementary Figs. 24 and 25). The _J_ – _V_ curves of the optimal device are shown in Fig. 3g. This device achieved a PCE of 21.1%, with a high _V_ OC of 1.373 V, a short-circuit current density ( _J_ SC) of 18.1 mA cm<sup>–2</sup> and an FF of 84.7%, without noticeable hysteresis. The integrated _J_ SC from the EQE measurement (18.1 mA cm<sup>–2</sup> ) 

Nature Materials | Volume 24 | February 2025 | 252–259 

**255** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 



<!-- Start of picture text -->
a b c<br>Neat PVK<br>1.55 120<br>Bulk loss          Device loss Bulk improvement<br>1.50 Interfacial loss V OC 100 Interfacial improvement<br>WBG PVK V OC improvement<br>Glass 1.45 80<br>PVK cell 1.40 60<br>1.35 40<br>C60<br>Passivation 1.30 20<br>WBG PVK 1.25 0<br>ITO-NiO x -SAM 1.20 –20<br>Control DA SPA M-SPA DA SPA M-SPA<br>d 100 e 104 f 2.0<br>M-SPA Control<br>Non-radiative loss<br>SPA DA<br>Transport loss<br>95 Device FF 103 DA 1.6 SPA<br>Control M-SPA<br>90 1.2<br>102<br>85 0.8<br>101<br>80 0.4<br>100<br>75 0<br>Control DA SPA M-SPA 0 0.4 0.8 1.2 1.6 10 50<br>Time (µs) Current density (mA cm −2 )<br>g 20 h 100 i 22<br>Reverse 20<br>80<br>15 Forward<br>18<br>60<br>Reverse Forward<br>10 Integrated  J SC<br>V OC 1.371 V 1.373 V SPO = 21.1%<br>40 18.1 mA cm −2<br>PCE 21.1% 21.1% 4<br>FF 84.8% 84.7%<br>5<br>J SC 18.1  18.1  20 2<br>mA cm −2 mA cm −2<br>0 0 0<br>0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 300 400 500 600 700 800 0 100 200 300 400 500<br>Voltage (V) Wavelength (nm) Time (s)<br>Fig. 3 | Performance of WBG PSCs. a , Schematic of the perovskite films and  balance limit, comparing different cells.  e , Time-resolved photoluminescence<br>device structures for photoluminescence quantum yield measurement. PVK,  decay curves for the neat control, DA, SPA and M-SPA perovskite films when<br>perovskite; ITO, indium tin oxide; SAM, self-assembled monolayer.  b , QFLS   excited from the perovskite side.  f , ELEQE for devices with different processes.<br>and  V OC values extracted from the PL spectra for perovskite films and devices.   values extracted from the PL spectra for perovskite films and devices.   g ,  J – V  curves of the optimal M-SPA device.  h , i , EQE ( h ) and the stabilized power<br>c , QFLS and  V OC for different WBG perovskites compared to the control sample.  for different WBG perovskites compared to the control sample.  output (SPO) efficiency ( i ) for the best-performing M-SPA PSCs.<br> (eV)QFLS,  Vq OC<br> increasement (meV)QFLS,  Vq OC<br>FF (%)<br>ELEQE (%)<br>Intensity (a.u.)<br>EOE (%) PCE (%)<br>−2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 3 | Performance of WBG PSCs. a** , Schematic of the perovskite films and device structures for photoluminescence quantum yield measurement. PVK, perovskite; ITO, indium tin oxide; SAM, self-assembled monolayer. **b** , QFLS and _V_ OC values extracted from the PL spectra for perovskite films and devices.   values extracted from the PL spectra for perovskite films and devices. **c** , QFLS and _V_ OC for different WBG perovskites compared to the control sample.  for different WBG perovskites compared to the control sample. **d** , Repartition of loss mechanisms lowering the FF of the cell below the detailed 

matches that from the _J_ – _V_ curve (Fig. 3h). We also calculated a bandgap of 1.78 eV for WBG perovskites films using the EQE spectra (Supplementary Fig. 26). The _V_ OC reported in this Article is high for WBG PSCs (Supplementary Table 3). The maximum power-point (MPP) tracking remained stable at 21.1% over 600 seconds (Fig. 3i). We have shown that the M-SPA method retained effectiveness for 1.60 and 1.68 eV PSCs (Supplementary Fig. 27). 

The M-SPA process is adaptable and can be used with various 2D ligands to enable the formation of different low-dimensional phases. The improvement in device _V_ oc was universal, attributed to the enhanced (100) orientation (Supplementary Figs. 28 and 29). Meanwhile, blade-coated PSCs demonstrated improved device performance with the M-SPA approach, associated with a higher degree of (100) orientation (Supplementary Fig. 30). 

Nature Materials | Volume 24 | February 2025 | 252–259 

**256** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 



<!-- Start of picture text -->
a b<br>84 16.8 30<br>2.20<br>82 29<br>16.4<br>NBG perovskite 2.16 80 28<br>78 16.0 27<br>WBG perovskite 2.12<br>76 26<br>Glass 1 µm 15.6<br>2.08 74 25<br>Control M-SPA Control M-SPA Control M-SPA Control M-SPA<br>c d<br>20 NBG WBG Tandem 100 WBG<br>J – V  forward J – V  reverse Pseudo  J – V pFF 85.7% NBG<br>15 Real JV pPCE 31.5% 80<br>FF 83.3%<br>PCE 29.7% 60<br>10<br>(pseudo NBG J – V ) (pseudo WBG J – V ) 40 WBG:16.34mA cm −2 NBG:16.53mA cm −2<br>5<br>20<br>0 0<br>0 0.5 1.0 1.5 2.0 2.5 400 600 800 1,000<br>Voltage (V) Wavelength (nm)<br>e<br>32 1.2<br>28<br>1.0<br>24<br>20 T90 0.8<br>16 0.6<br>MPP tracking under 100 mW cm −2  illumination<br>12<br>0.4<br>8<br>0.2<br>4<br>0 0<br>0 100 200 300 400 500 600 700 800<br>Time (h)<br> (V) V OC FF (%) PCE (%)<br>−2) (mA cmJSC<br>EQE (%)<br>−2)Current density (mA cm<br>0.88 V 1.34 V 2.18 V 2.21 V<br>PCE (%)<br>Normalized PCE (a.u.)<br><!-- End of picture text -->

**Fig. 4 | Photovoltaic performance of all-perovskite tandem solar cells. a** , Cross-sectional SEM images of the perovskite/perovskite tandem solar cells. **b** , Photovoltaic parameters of the tandem perovskite solar cells, including PCE, _V_ OC, FF and _J_ SC. The statistical experiments were repeated 10 times and they were carried out in the same laboratory (the National Laboratory of Solid State Microstructures of Nanjing University). The middle line in a box plot shows the median, indicating the central tendency of the data. The box length reflects data spread, while the ‘whiskers’ mark the maximum and minimum values of the 

normal range. Points outside this range are outliers. **c** , _J_ – _V_ curves and pseudo- _J_ – _V_ derived from ELEQE curves. **d** , EQE curves for the best-performing tandem PSC. **e** , Continuous MPP tracking of an encapsulated tandem solar cell for 800 hours under simulated AM1.5 G illumination (100 mW cm<sup>–2</sup> , multi-colour LED simulator) in ambient air, with a relative humidity of 30–50% at a device temperature of 40–45 °C. The black dashed line is the 90% original efficiency baseline, and the red line is the MPP tracking efficiency of the tandem solar cells. 

The photostabilities of WBG PSCs with a different fabrication process were evaluated by subjecting different devices to continuous 100 mW cm<sup>–2</sup> AM1.5 G light illumination under open-circuit conditions (Supplementary Figs. 31–34). Both SPA and M-SPA devices proved more stable than DA devices, retaining over 85% of their initial efficiency for 500 hours. However, M-SPA exhibited slightly lower photostability due to the inclusion of MA cations. We suggest that future efforts should focus on non-MA additives that enhance the formation of 2D templates. 

### **All-perovskite tandem solar cells** 

Figure 4a shows cross-sectional SEM images of all-perovskite tandem solar cells. The thickness of the WBG perovskite layer is approximately 380 nm, while that of the NBG perovskite layer is about 1 μm. Statistical photovoltaic parameters of the tandem devices are presented in 

Fig. 4b. We found that the average PCE of the M-SPA-based tandem devices increased from 27.5% in the control to 28.5%, primarily due to an improvement in _V_ OC (from 2.12 to 2.18 V). The highest _V_ OC of the M-SPA devices reached an impressive ~2.22 V and the fill factor (FF) achieved 83.5%. Both metrics are among the best reported results for all-perovskite tandem solar cells. The _J_ – _V_ curves for representative NBG PSCs and the highest _V_ OC tandem cell can be found in Supplementary Figs. 35 and 36, respectively. 

Figure 4c shows the forward and reverse _J_ – _V_ scans of the optimal tandem device, complemented by the ELEQE-calculated pseudo- _J_ – _V_ of both WBG and NBG subcells. The corresponding ELEQE curve for the tandem solar cell is shown in Supplementary Fig. 37. We obtained a pseudo- _V_ OC of 2.21 V, marking an increase of 30 mV over the standard _J_ – _V-_ measured _V_ OC of 2.18 V. Additionally, a pseudo-FF of 85.7% and a 

Nature Materials | Volume 24 | February 2025 | 252–259 

**257** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

pseudo-PCE of 31.5% were discerned, indicating an approximate 2% absolute PCE loss due to series resistance. The device achieved a PCE of 29.7%, with a _V_ OC of 2.175 V, a _J_ SC of 16.4 mA cm<sup>–2</sup> and an FF of 83.3%. 

The EQE spectra (Fig. 4d) unveiled a well-matched photocurrent of 16.3 mA cm<sup>–2</sup> for the WBG top-cell, mirroring the _J_ – _V_ curve results. Supplementary Fig. 38 shows the steady-state PCE of the device, which attained 29.3% over a measurement span of 180 s. We sent one tandem cell to the accredited independent photovoltaic calibration laboratory, Japan Electrical Safety & Environment Technology Laboratories (JET). This device delivered a certified steady-state PCE of 29.1% (29.5% PCE under reserve _J_ – _V_ scan from reverse sweep test) and a _V_ OC of 2.157 V (Supplementary Fig. 39). The results have been included in a recent version of the solar cell efficiency table (version 62)<sup>52</sup> . To assess operating stability, we tracked the MPP of an encapsulated tandem device under ambient conditions (Fig. 4e). Under light-emitting dioide (LED) illumination with near-infrared components, the device retained 90% of its initial PCE after 750 hours of continuous operation. This promising operating stability, coupled with high _V_ OC and PCE enabled by the M-SPA method, represents an important step towards the application of all-perovskite tandem solar cells. 

### **Outlook** 

We report a facile strategy to produce WBG perovskites with an improved (100) orientation by using a mixture of MAI and PEAI in the anti-solvent. This promoted the formation of _n_ = 1 layered perovskite on the film surface during crystallization, inducing oriented nucleation and downward crystal growth. Utilizing this approach, the WBG perovskite films exhibited reduced non-radiative recombination, with a QFLS approaching 1.415 eV and enhanced carrier mobilities of 31.7 cm<sup>2</sup> V<sup>−1</sup> s<sup>−1</sup> . We obtained efficient WBG PSCs with a _V_ OC exceeding 1.37 V and a PCE of 29.1%. This study offers an effective technique to control the crystal orientation of WBG perovskites without compromising charge transport, overcoming the efficiency barrier of all-perovskite tandems stemming from photovoltage losses. 

### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41563-024-02073-x. 

### **References** 

1. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73–78 (2022). 

2. Chen, H. et al. Regulating surface potential maximizes voltage in all-perovskite tandems. _Nature_ **613** , 676–681 (2023). 

3. Lin, R. et al. All-perovskite tandem solar cells with 3D/3D bilayer perovskite heterojunction. _Nature_ **620** , 994–1000 (2023). 

4. Hörantner, M. T. et al. The potential of multijunction perovskite solar cells. _ACS Energy Lett._ **2** , 2506–2513 (2017). 

5. Leijtens, T., Bush, K. A., Prasanna, R. & McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. _Nat. Energy_ **3** , 828–838 (2018). 

6. Lin, R. et al. Monolithic all-perovskite tandem solar cells with 24.8% efficiency exploiting comproportionation to suppress Sn(II) oxidation in precursor ink. _Nat. Energy_ **4** , 864–873 (2019). 

7. Xiao, K. et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. _Nat. Energy_ **5** , 870–880 (2020). 

8. Jiang, Q. et al. Compositional texture engineering for highly stable wide-bandgap perovskite solar cells. _Science_ **378** , 1295–1300 (2022). 

9. Tong, J. et al. Carrier control in Sn–Pb perovskites via 2D cation engineering for all-perovskite tandem solar cells with improved efficiency and stability. _Nat. Energy_ **7** , 642–651 (2022). 

10. Prasanna, R. et al. Design of low bandgap tin–lead halide perovskite solar cells to achieve thermal, atmospheric and operational stability. _Nat. Energy_ **4** , 939–947 (2019). 

11. Cao, J. et al. High-performance tin–lead mixed-perovskite solar cells with vertical compositional gradient. _Adv. Mater._ **34** , 2107729 (2022). 

12. Zhou, J. et al. Mixed tin-lead perovskites with balanced crystallization and oxidation barrier for all-perovskite tandem solar cells. _Nat. Commun._ **15** , 2324 (2024). 

13. Penã-Camargo, F. et al. Halide segregation versus interfacial recombination in bromide-rich wide-gap perovskite solar cells. _ACS Energy Lett._ **5** , 2728–2736 (2020). 

14. Brinkmann, K. O. et al. Perovskite–organic tandem solar cells with indium oxide interconnect. _Nature_ **604** , 280–286 (2022). 

15. He, R. et al. Improving interface quality for 1-cm<sup>2</sup> all-perovskite tandem solar cells. _Nature_ **618** , 80–86 (2023). 

16. Chen, C. et al. Arylammonium-assisted reduction of the open-circuit voltage deficit in wide-bandgap perovskite solar cells: the role of suppressed ion migration. _ACS Energy Lett._ **5** , 2560–2568 (2020). 

17. Kim, D. et al. Efficient, stable silicon tandem cells enabled by anion-engineered wide-bandgap perovskites. _Science_ **368** , 155–160 (2020). 

18. Caprioglio, P. et al. Open-circuit and short-circuit loss management in wide-gap perovskite p-i-n solar cells. _Nat. Commun._ **14** , 932 (2023). 

19. McMeekin, D. P. et al. Intermediate-phase engineering via dimethylammonium cation additive for stable perovskite solar cells. _Nat. Mater._ **22** , 73–83 (2023). 

20. Susic, I., Gil-Escrig, L., Palazon, F., Sessolo, M. & Bolink, H. J. Quadruple-cation wide-bandgap perovskite solar cells with enhanced thermal stability enabled by vacuum deposition. _ACS Energy Lett._ **7** , 1355–1363 (2022). 

21. Zheng, X., Alsalloum, A. Y., Hou, Y., Sargent, E. H. & Bakr, O. M. All-perovskite tandem solar cells: a roadmap to uniting high efficiency with high stability. _Acc. Mater. Res._ **1** , 63–76 (2020). 

22. Ma, C. et al. Unveiling facet-dependent degradation and facet engineering for stable perovskite solar cells. _Science_ **379** , 173–178 (2023). 

23. Ma, C., Grätzel, M. & Park, N. G. Facet engineering for stable, efficient perovskite solar cells. _ACS Energy Lett._ **7** , 3120–3128 (2022). 

24. Ma, C. et al. Photovoltaically top-performing perovskite crystal facets. _Joule_ **6** , 2626–2643 (2022). 

25. He, R. et al. Wide-bandgap organic–inorganic hybrid and all-inorganic perovskite solar cells and their application in all-perovskite tandem solar cells. _Energy Environ. Sci._ **14** , 5723–5759 (2021). 

26. Li, H. & Zhang, W. Perovskite tandem solar cells: from fundamentals to commercial deployment. _Chem. Rev._ **120** , 9835–9950 (2020). 

27. Nie, T., Fang, Z., Ren, X., Duan, Y. & Liu, S. Recent advances in wide-bandgap organic–inorganic halide perovskite solar cells and tandem application. _Nanomicro Lett._ **15** , 70 (2023). 

28. An, Y. et al. Optimizing crystallization in wide-bandgap mixed halide perovskites for high‐efficiency solar cells. _Adv. Mater._ **36** , 2306568 (2023). 

29. Xu, F., Zhang, M., Li, Z., Yang, X. & Zhu, R. Challenges and perspectives toward future wide-bandgap mixed-halide perovskite photovoltaics. _Adv. Energy Mater._ **13** , 2203911 (2023). 

30. Xu, Z. et al. A thermodynamically favored crystal orientation in mixed formamidinium/methylammonium perovskite for efficient solar cells. _Adv. Mater._ **31** , 1900390 (2019). 

31. Zheng, G. et al. Manipulation of facet orientation in hybrid perovskite polycrystalline films by cation cascade. _Nat. Commun._ **9** , 2793 (2018). 

Nature Materials | Volume 24 | February 2025 | 252–259 

**258** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

32. Yu, Y. et al. Synergetic regulation of oriented crystallization and interfacial passivation enables 19.1% efficient wide-bandgap perovskite solar cells. _Adv. Energy Mater._ **12** , 2201509 (2022). 

33. Xiang, W. et al. Intermediate phase engineering of halide perovskites for photovoltaics. _Joule_ **6** , 315–339 (2022). 

34. Wang, M., Gao, W., Cao, F. & Li, L. Ethylamine iodide additive enables solid-to-solid transformed highly oriented perovskite for excellent photodetectors. _Adv. Mater._ **34** , 2108569 (2022). 

35. Zheng, Y. et al. Downward homogenized crystallization for inverted wide-bandgap mixed-halide perovskite solar cells with 21% efficiency and suppressed photo-induced halide segregation. _Adv. Funct. Mater._ **32** , 2200431 (2022). 

36. McMeekin, D. P. et al. A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151–155 (2016). 

37. Xu, J. et al. Triple-halide wide-band gap perovskites with suppressed phase segregation for efficient tandems. _Science_ **367** , 1097–1104 (2020). 

38. Jaysankar, M. et al. Crystallisation dynamics in wide-bandgap perovskite films. _J. Mater. Chem. A_ **4** , 10524–10531 (2016). 

39. Abdollahi Nejand, B. et al. Scalable two-terminal all-perovskite tandem solar modules with a 19.1% efficiency. _Nat. Energy_ **7** , 620–630 (2022). 

40. Wen, J. et al. Steric engineering enables efficient and photostable wide-bandgap perovskites for all-perovskite tandem solar cells. _Adv. Mater._ **34** , 2110356 (2022). 

41. Bu, T. et al. Structure engineering of hierarchical layered perovskite interface for efficient and stable wide bandgap photovoltaics. _Nano Energy_ **75** , 104917 (2020). 

42. Li, L. et al. Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708–717 (2022). 

43. Chen, J. et al. Oriented halide perovskite nanostructures and thin films for optoelectronics. _Chem. Rev._ **121** , 12112–12180 (2021). 

44. Chen, S. et al. Crystallization in one-step solution deposition of perovskite films: upward or downward? _Sci. Adv._ **7** , eabb2412 (2021). 

45. Wen, J. et al. Heterojunction formed via 3D-to-2D perovskite conversion for photostable wide-bandgap perovskite solar cells. _Nat. Commun._ **14** , 7118 (2023). 

46. Perini, C. A. R. et al. Interface reconstruction from Ruddlesden– Popper structures impacts stability in lead halide perovskite solar cells. _Adv. Mater._ **34** , 2204726 (2022). 

47. Wei, M. et al. Combining efficiency and stability in mixed tin–lead perovskite solar cells by capping grains with an ultrathin 2D layer. _Adv. Mater._ **32** , 1907058 (2020). 

48. Li, N. et al. Mixed cation FA _x_ PEA1– _x_ PbI3 with enhanced phase and ambient stability toward high‐performance perovskite solar cells. _Adv. Energy Mater._ **7** , 1601307 (2017). 

49. Luo, C. et al. Facet orientation tailoring via 2D-seed-induced growth enables highly efficient and stable perovskite solar cells. _Joule_ **6** , 240–257 (2022). 

50. Liu, Z. et al. Reducing perovskite/C60 interface losses via sequential interface engineering for efficient perovskite/silicon tandem solar cell. _Adv. Mater._ **36** , 2308370 (2024). 

51. Xiao, K. et al. Scalable processing for realizing 21.7%-efficient all-perovskite tandem solar modules. _Science_ **376** , 762–767 (2022). 

52. Green, M. A. et al. Solar cell efficiency tables (version 62). _Prog. Photovolt.: Res. Appl._ **31** , 651–663 (2023). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2025 

Nature Materials | Volume 24 | February 2025 | 252–259 

**259** 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

### **Methods** 

#### **Materials** 

All materials were used as received without further purification. The ammonium salts (FAI, MAI, PEAI, barium iodide (BAI), PEACl, PEABr, PEASCN, guanidinium bromide (GUABr) and 4-(aminomethyl)piperidinium iodide (4-AMPI) and 4-trifluoromethylphenylammonium chloride (CF3-PACl) with purity of >99%) were purchased from Greatcell Solar Materials. [4-(3,6-Dimethyl-9H-carbazol-9-yl)butyl]phosphonic acid (Me-4PACZ), [2-(3,6-dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid (MeO-2PACZ) (> 98% purity), PbI2 (99.999%), CsI (99.9%) and PbBr2 were purchased from TCI. _N_ , _N_ -Dimethylformamide (DMF) (99.8% anhydrous), dimethyl sulfoxide (DMSO) (99.9% anhydrous), chlorobenzene (99.8% anhydrous) and formamidine sulfinic acid (>98%) were purchased from Sigma Aldrich. C60 was purchased from Nano-C. Ethanediamine dihydroiodide (EDAI2), 4F-PEACl and 2,9-dimethyl-4,7diphenyl-1,10-phenanthroline (BCP) (> 99% sublimed) were purchased from Xi’an Polymer Light Technology. 

#### **WBG perovskite film fabrication** 

Spin coating: 1.15 M FA0.8Cs0.2Pb(I0.6Br0.4)3 perovskite solution was formulated by mixing CsI, FAI, PbBr2 and PbI2 with the corresponding stoichiometry ratio dissolved in a mixed solvent of DMF and DMSO with a volume ratio of 4:1. The 150 μl perovskite solution was dropped onto the substrate and this was followed by a two-step spin-coating procedure: 2,000 r.p.m. for 10 s with an acceleration of 200 r.p.m. s<sup>–1</sup> and 6,000 r.p.m for 30 s with an acceleration of 2,000 r.p.m. s<sup>–1</sup> . Then 200 μl anisole was dropped into a solution containing a 5% volume ratio of 2 mg ml<sup>–1</sup> PEAI and 1 mg ml<sup>–1</sup> MAI in isopropyl alcohol (IPA) for 10 s before the end of the procedure. Then the as-deposited film was annealed at 100 °C for 15 min. 

Blade coating: 1.4 M Cs0.35FA0.65PbI1.8Br1.2 solution was prepared with FAI, CsI, PbI2 and PbBr2 in a mixed solvent of DMF and DMSO with a volume ratio of 4:1. The WBG perovskite (Cs0.35FA0.65PbI1.8Br1.2) precursor solution was blade-coated onto the substrate with a gap of 200 μm at a movement speed of 5 mm s<sup>−1</sup> without blowing N2. A mixed MAI (1 mg ml<sup>−1</sup> )/PEAI (2 mg ml<sup>−1</sup> ) solution in IPA/anisole (volume ratio 1:9) was then deposited with a movement speed of 15 mm s<sup>−1</sup> onto the wet film. Then the as-deposited film was annealed at 100 °C for 15 min. 

#### **WBG perovskite solar cell fabrication** 

NiO _x_ nanocrystal (15 mg ml<sup>−1</sup> in water) layers were first spin-coated onto indium tin oxide substrates at 3,000 r.p.m. for 30 s and annealed on a hotplate at 130 °C for 30 min in air. NiO nanocrystals were synthesized as reported previously<sup>53</sup> . After cooling, the substrates were immediately transferred to the nitrogen-filled glovebox. Then 100 μl of a 1 mmol 2PACZ and MEO-2PACZ mixed solution with a molar ratio of 3:1 was dropped onto an indium tin oxide substrate spinning at 4,000 r.p.m. with an acceleration of 4,000 r.p.m. s<sup>–1</sup> for 20 s and this was post-annealed at 100 °C for 5 min. Then, 100 μl IPA solution was dropped onto the annealed film to wash out unbound molecules on the substrate with a dynamic spin-casting process at 4,000 r.p.m. for 10 s. The washed film was transferred to a 100 °C hot plate and dried for 3 min. The WBG perovskite solution was deposited on the self-assembled monolayer-modified substrate as detailed above. For the WBG perovskite post treatment, EDAI2 (1 mg ml<sup>–1</sup> ) in mixed IPA:toluene (1:1 volume ratio) and 4F-PEACl (1 mg ml<sup>–1</sup> ) in IPA were prepared and deposited sequentially. The spin speed was set to 5,000 r.p.m. for 20 s. Then, 50 μl of the treatment solution was dropped onto the perovskite film once the spin speed reached its maximum. The perovskite films were then annealed at 100 °C for 5 min following the spin-coating of each post treatment solution<sup>50</sup> . After cooling down to room temperature, the substrates were transferred to the evaporation system and a 20 nm-thick C60 film was subsequently deposited on top by thermal evaporation at a rate of 0.2 Å s<sup>–1</sup> . The substrates were then transferred to the atomic layer deposition (ALD) system (Veeco Savannah S200) to deposit 

20 nm SnO2 at low temperature (typically 100 °C) using precursors of tetrakis(dimethylamino)tin(IV) (99.9999%, Nanjing Ai Mou Yuan Scientific Equipment Co., Ltd) and deionized water. After ALD deposition, 120 nm Ag was deposited by the thermal evaporation method. 

#### **NBG perovskite film fabrication** 

The precursor solution was prepared in a mixed solvent of DMF and DMSO with a volume ratio of 2:1. The molar ratios for FAI/MAI and PbI2/SnI2 were 0.7:0.3 and 0.5:0.5, respectively. The molar ratio of (FAI + MAI)/(PbI2 + SnI2) was 1:1. SnF2 (10 mol% relative to SnI2) was added to the precursor solution. The precursor solution was then stirred at room temperature for 2 h. Tin powders (5 mg ml<sup>−1</sup> ) and formamidine sulfinic acid (0.3 mol%) were added to the precursor to reduce Sn<sup>4+</sup> in the precursor solution and to improve film uniformity. CF3-PACl (0.4 mol%) was added to the precursor solution. The surfaces of the NBG perovskites were passivated by a 3D/3D bilayer perovskite heterojunction as reported previously<sup>3</sup> . 

#### **Tandem solar cell fabrication** 

The WBG perovskite subcell was first fabricated using the same procedure as the single-junction solar cell but without the evaporation of the Ag electrode. The half devices were then transferred back to the thermal evaporation system to deposit an ultra-thin layer of Au clusters (approximately 1 nm) on ALD-SnO2. Poly(3,4-ethylenedioxythiophene)poly(styrenesulfonate) layers were spin-cast on top of the front cells and annealed in air at 120 °C for 20 min. After the substrates cooled down, they were immediately transferred to a nitrogen-filled glovebox for the deposition of NBG perovskite films with identical procedures to those used for the single-junction devices. Finally, 20 nm C60, 7 nm BCP and 150 nm Cu films were sequentially deposited by thermal evaporation (Beijing Technol Science). Details of the deposition of ALD-SnO2 layers can be found in our previous work<sup>3</sup> . 

#### **Characterization of solar cells** 

For single-junction solar cells, the _J_ – _V_ characteristics were measured using a Keithley 2400 sourcemeter under the illumination of a solar simulator (EnliTech, Class AAA) at a light intensity of 100 mW cm<sup>−2</sup> as checked with National Renewable Energy Laboratory-calibrated reference solar cells (KG-5 and KG-0 reference cells were used for the measurements of the WBG and NBG solar cells, respectively). Unless otherwise stated, the _J_ – _V_ curves were all measured in a nitrogen-filled glovebox with a scanning rate of 100 mV s<sup>−1</sup> (with voltage steps of 20 mV and a delay time of 100 ms). The active area was determined by the aperture shade masks (0.049 cm<sup>2</sup> ) placed in front of the solar cells. EQE measurements were performed in ambient air using a QE system (EnliTech) with monochromatic light focused on the device pixel and a chopper frequency of 20 Hz. For tandem solar cells, the measurements of the _J_ – _V_ characteristics were performed under the illumination of a two-lamp high spectral match solar simulator (SAN-EI ELECTRIC, XHS-50S1). The spectrum from the simulator was finely tuned to ensure that spectral mismatch was in the region of 100 ± 3% for each 50 nm interval in the wavelength range 400–1,000 nm. The solar simulator was set at a light intensity of 100 mW cm<sup>−2</sup> as checked with a calibrated crystalline silicon reference solar cell with a quartz window (KG-0). We note that a dual-lamp solar simulator, rather than a single Xe lamp, is preferred for the characterization of tandem solar cells, due to the better spectral match with AM1.5 G solar irradiance. EQE measurements were performed in ambient air and the bias illumination from bright LEDs with emission peaks of 850 and 460 nm was used for the measurements of the front and back subcells, respectively. No bias voltage was applied during the EQE measurements of the tandem solar cells. 

#### **Stability tests of solar cells** 

The operating stability tests were carried out under full AM1.5 G illumination (Class AAA, multicolour LED solar simulator, Guangzhou 

Nature Materials 

**Article** 

https://doi.org/10.1038/s41563-024-02073-x 

Crysco Equipment Co. Ltd) with an intensity of 100 mW cm<sup>−2</sup> using a home-made LabVIEW-based MPP tracking system and a perturb and observe method in ambient conditions. The solar cells were encapsulated with a cover glass and UV epoxy (Three Bond), which was cured under a UV-LED lamp (peak emission at 365 nm) for 3 min. No UV filter was applied during operation. The environmental temperature was kept at around 25 °C. The solar cell temperature increased to approximately 35 °C under illumination as no active cooling was implemented at the measurement stage. The illumination intensity was regularly calibrated to check the degradation of the LED lamp. 

#### **Femtosecond-resolved optical-pump-terahertz probe spectroscopy** 

A commercial Ti:Sapphire amplified laser (Libra, Coherent) with a pulse duration of 90 fs, centre wavelength of 800 nm and repetition rate of 1 kHz was used to generate terahertz radiation by optical rectification in a 0.5 mm-thick ZnTe (110) non-linear single crystal. The radiation was detected using free-space electro-optic sampling in a 0.5 mm-thick ZnTe (110) crystal. Perovskite thin films deposited on _z_ -cut quartz substrates were photoexcited at 800 nm with fluences in the range 1.5–50 μJ cm<sup>−2</sup> . The change in terahertz amplitude was monitored as a function of the time delay between the 800 nm optical pump pulse and the terahertz probe pulse using a translation stage. All measurements were carried out in a nitrogen-purged environment to avoid potential degradation of the perovskite films in ambient air. 

#### **Other characterizations** 

The SEM images were obtained using a Hitachi S8100 microscope with an accelerating voltage of 2 kV. X-ray photoelectron spectroscopy (XPS) analysis was carried out using the Thermo Scientific Al K-alpha XPS system with energy steps of 0.1 eV. The powder XRD spectra ( _θ_ −2 _θ_ scans) were obtained on a D8 powder X-ray diffraction system (PANalytical Inc.) with Cu Kα ( _λ_ = 1.5418 Å) as the X-ray source. The photoluminescence (PL) signal was analysed on a Horiba Jobin Yvon system. Absorption spectra were recorded using an Agilent Technologies Cary Series UV–vis–NIR Spectrophotometer. 

### **Acknowledgements** 

This work was financially supported by the National Key R&D Program of China (2022YFB4200304 and 2021YFB3200303), the National Natural Science Foundation of China (T2325016, U21A2076, 61974063), the Natural Science Foundation of Jiangsu Province (BE2022021, BE2022026, BK20202008, BK20190315), the Fundamental Research Funds for the Central Universities (0213/14380206, 0205/14380252), the Frontiers Science Center for Critical Earth Material Cycling Fund (DLTD2109), the Program for Innovative Talents and Entrepreneurs in Jiangsu, and the Guangdong Major Project of Basic and Applied Basic Research (2021B0301030002). U.R. acknowledges funding from the Swiss National Science Foundation Grant No. 200020_219440 and computational resources from the Swiss National Computing Centre (CSCS). We also thank the C. Zhang group, Nanjing University, for technical support. 

### **Author contributions** 

H.T. conceived the idea and directed the overall project. Z.L., R.L. and M.Y. fabricated all the devices and conducted the characterization. P.W. packaged the devices and performed long-term stability testing. M.L. and H.G. performed the SEM measurements. L.L. performed the photoluminescence quantum yield measurement. Y.W. and H.L. performed the PL and time-resolved photoluminescence measurements. G.C. performed the GIWAXS characterization. Z.W., M. Wang and Y.D. performed the HR-STEM measurements. V.C., L.A, V.S., N.L. and U.R. performed and analysed the density functional theory calculations. X.L. and Y.L. added the data for blade coating. Z.L., M. Wei, M.G. and H.T. wrote the manuscript. All authors discussed the results and commented on the paper. 

### **Competing interests** 

H.T. is the founder, chief scientific officer and chairman of Renshine (Suzhou) Solar Co., Ltd, a company that is commercializing perovskite photovoltaic cells. The other authors declare no competing interests. 

### **Additional information** 

#### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

### **Data availability** 

All data generated or analysed during this study are included in the published article and its Supplementary Information. Further data are available from the corresponding author (H.T.) on reasonable request. 

### **References** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41563-024-02073-x. 

**Correspondence and requests for materials** should be addressed to Renxing Lin, Michael Grätzel or Hairen Tan. 

**Peer review information** _Nature Materials_ thanks Henry Snaith and the other, anonymous, reviewer(s) for their contribution to the peer review of this work. 

53. Yin, X. et al. Highly efficient flexible perovskite solar cells using 

- solution-derived NiO _x_ hole contacts. _ACS Nano_ **10** , 3630–3636 (2016). 

**Reprints and permissions information** is available at www.nature.com/reprints. 

Nature Materials 





