# Poly(carbazole phosphonic acid) as a versatile hole-transporting material for p-i-n perovskite solar cells and modules

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Joule |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 172 |
| 作者 | Zhi-Jun Ren, Zewei Cui, Xiaoyu Shi, Ling-Yuan Wang, Yunjie Dou, Fei-Fei Wang, Haoran Lin, He Yan et al. |
| DOI | 10.1016/j.joule.2023.10.014 |
| 源文件 | 064_Ren_2023_Polycarbazole-phosphonic-acid-as-a-versatile-hol.pdf |

---
**ll** 

## Article 

Poly(carbazole phosphonic acid) as a versatile hole-transporting material for p-i-n perovskite solar cells and modules 



Zhijun Ren, Zewei Cui, Xiaoyu Shi, ..., Haoran Lin, He Yan, Shangshang Chen 

hyan@ust.hk (H.Y.) schen@nju.edu.cn (S.C.) 

Highlights 

A hole-transporting material named Poly-4PACz is developed for perovskite solar cells 

Poly-4PACz exhibits excellent hole-extraction capacity and passivation effects 

Poly-4PACz is compatible with the scaling up of perovskite modules 

Ren and co-workers report a new type of polymeric hole-transporting material named Poly-4PACz for high-performance p-i-n perovskite solar devices. Compared with its small-molecular counterparts, Poly-4PACz shows higher conductance and better wettability on conductive substrates. In addition, Poly4PACz can further passivate interfacial traps and stabilize the cells. Consequently, blade-coated perovskite solar cells based on Poly-4PACz realize a high efficiency of 24.4% with good operational stability, and a 20.7%-efficiency perovskite solar module is also achieved at an aperture area of 25.0 cm<sup>2</sup> . 

Ren et al., Joule 7, 2894–2904 December 20, 2023 ª 2023 Elsevier Inc. https://doi.org/10.1016/j.joule.2023.10.014 



**ll** 

#### Article 

# Poly(carbazole phosphonic acid) as a versatile hole-transporting material for p-i-n perovskite solar cells and modules 

Zhijun Ren,<sup>1,4</sup> Zewei Cui,<sup>1,2,4</sup> Xiaoyu Shi,<sup>1</sup> Lingyuan Wang,<sup>1</sup> Yunjie Dou,<sup>1</sup> Feifei Wang,<sup>1</sup> Haoran Lin,<sup>3</sup> He Yan,<sup>2,</sup> * and Shangshang Chen<sup>1,5,</sup> * 

##### SUMMARY 

Commonly used poly(triaryl amine) and carbazole phosphonic acid (PACz) hole-transporting materials (HTMs) typically suffer from poor wettability for perovskite solutions and sensitiveness to layer thickness/substrate roughness, respectively, thus limiting their applications in the real-world manufacturing of perovskite modules. To address these issues, in this work, we report a new type of HTM by polymerizing PACz into a versatile polymeric material. The resultant polymeric HTM (named Poly-4PACz) exhibits excellent hole-extraction capacity and can further suppress the interfacial recombination and stabilize perovskite/HTM interfaces. Most importantly, Poly-4PACz exhibits high conductance and is insensitive to layer thickness on both indium-doped tin oxide and fluorine-doped tin oxide substrates, which are highly desirable for the scalable coating of perovskite films. As a result, the blade-coated p-i-n perovskite solar cells and modules realize impressive power conversion efficiencies of 24.4% and 20.7% at 6.84 mm<sup>2</sup> and 25.0 cm<sup>2</sup> aperture areas, respectively. 

##### INTRODUCTION 

Metal halide perovskite solar cells (PSCs) have been considered a next-generation photovoltaic technology that can compete with mainstreaming crystalline Si cells due to their solution processibility, mechanical flexibility, and excellent optoelectronic properties.<sup>1–7</sup> Among different types of PSC structures, p-i-n type (or inverted) PSCs are more promising for commercialization because of their low-temperature processing, low material cost, and better device stability.<sup>8–11</sup> In the scalable manufacturing of p-i-n perovskite modules, the key step is to coat perovskite precursor solutions onto hole-transporting material (HTM)-covered transparent conductive oxide (TCO) substrates via a blade or slot-die coatings.<sup>12</sup> In this process, the wettability, compactness, and uniformity of HTMs on TCO have critical effects on the quality of perovskite films and the performance of devices.<sup>13,14</sup> Poly(triaryl amine) (PTAA) is a widely used HTM in p-i-n perovskite solar devices, and its efficient hole collection capacity and chemical inertness to perovskites have enabled multiple cases of highperformance p-i-n perovskite solar devices.<sup>15–17</sup> However, its hydrophobic nature makes large-area and conformal coating of perovskite films challenging.<sup>18</sup> Recently, carbazole phosphonic acid (PACz), such as Me-2PACz, Me-4PACz, and MeO-2PACz, have emerged as small-molecular type HTMs.<sup>19–21</sup> Different from PTAA, PACz-type small molecular HTMs rely on forming self-assembled monomer (SAM) layers on TCO to extract holes, and their hole-transporting performance is particularly sensitive to layer thickness and coverage. During spin-coating process of small-area substrates, PACz-type HTM solutions generally dry fast due to the centrifugal force and 

##### CONTEXT & SCALE 

In the fabrication of p-i-n perovskite solar devices, the wettability, compactness, and uniformity of hole-transporting materials (HTMs) on conductive substrates have critical effects on the quality of perovskite films and the performance of devices. Here, we develop a new type of versatile polymeric HTM named Poly4PACz via a low-cost synthetic route. Compared with prevailing HTMs, such as poly(triaryl amine) and carbazole phosphonic acid, Poly-4PACz exhibits excellent hole-extraction capacity, high conductance, and good wettability. Poly-4PACz can also passivate the interfacial traps and stabilize the perovskite solar cells. The blade-coated perovskite solar cells based on Poly-4PACz realize an impressive efficiency of over 24% with good stability. It has also shown the universality in other commonly used perovskite compositions and the compatibility with the scaling up of perovskite photovoltaics. 



2894 Joule 7, 2894–2904, December 20, 2023 ª 2023 Elsevier Inc. 

**ll** 

#### Article 

are relatively easier to spread into a thin layer with good coverage. However, when it comes to blade or slot-die coatings of large-area perovskite films on TCO, PACz solutions tend to fill the nano-size valley of TCO first, resulting in multiple-layer PACz stackings with poor coverage.<sup>22</sup> On the one hand, multiple-layer stackings of PACz increase the hole-extraction resistance due to their intrinsic insulation properties; on the other hand, SAM-uncovered regions cause charge recombination and induce decomposition at perovskite/substrate interfaces.<sup>23</sup> Moreover, in the actual manufacturing of perovskite solar devices, fluorine-doped tin oxide (FTO) substrates are employed instead of expensive indium-doped tin oxide (ITO) to reduce production costs.<sup>24</sup> FTO substrates are much rougher than ITO,<sup>25</sup> and forming a compact SAM layer on them is more challenging,<sup>12</sup> thus limiting the real applications of PACz SAM layers in the scalable fabrication of perovskite solar devices. Therefore, developing high-performance HTMs that are insensitive to layer thickness and substrate roughness is critical for scalable coating and the commercialization of perovskite photovoltaics. 

In this work, we design and synthesize a novel type of HTM by polymerizing carbazole phosphonic acid small molecules, and the resultant Poly-4PACz possesses several key advantages over current prevailing small-molecular PACz HTMs. First, unlike small-molecular PACz HTM that rely on forming compact ultra-thin SAM layers, Poly-4PACz exhibits good conductance and thus is less sensitive to layer thickness and TCO surface roughness, which significantly broadens the processing windows of HTMs. Second, the phosphonic acid groups of Poly-4PACz not only form chemical bonds to TCO but also are able to passivate the perovskite films and suppress the charge recombination at the buried perovskite/HTM interface. Based on these beneficial effects of Poly-4PACz, the p-i-n type PSCs based on Poly-4PACz achieve impressive power conversion efficiencies (PCEs) of 24.4% and 22.7% on ITO and FTO substrates, respectively. Meanwhile, the compact coating of Poly-4PACz on large ITO substrates enables the perovskite solar modules to realize a high PCE of 20.7% at an aperture area of 25.0 cm<sup>2</sup> . 

##### RESULTS AND DISCUSSION 

The synthetic route of Poly-4PACz is shown in Figure 1A. We started with the low-cost and accessible dibromocarbazole as the raw material, and bromobutane was then grafted to its amino group. After substituting the remaining bromide groups with phosphate, the carbazole phosphate monomers were polymerized, and further hydrolysis gave the target Poly-4PACz HTM. All reactions proceed under a moderate condition, and the synthesis cost of Poly-4PACz is estimated to be as cheap as �$60/g (Table S1). The synthesis of Poly-4PACz has very good reproducibility, and the five batches of Poly-4PACz we synthesized were found to show very small batch-to-batch variation in molecular weight (Table S2). Poly-4PACz is well soluble in methanol/chloroform mixture solvents, allowing its solution processibility via scalable coating methods. The Poly-4PACz-coated ITO substrate shows a smaller water contact angle of 71.0<sup>�</sup> (Figure S1) and a higher surface energy of 33.2 mJ m<sup>�2</sup> than Me-4PACz (74.9<sup>�</sup> and 32.0 mJ m<sup>�2</sup> ). The Poly-4PACz thin film exhibits a higher highest occupied molecular orbital (HOMO) level of �5.28 eV (Figure S2) and a red-shifted absorption compared with Me-4PACz (Figure 1B). The routine atomic force microscopy (AFM) measurements (Figure S3) show that the surface of Poly-4PACz-coated ITO substrate is much smoother with a smaller root mean square (RMS) roughness of 2.05 nm than that of Me-4PACz (3.95 nm). To investigate the chemical interaction between Poly4PACz and ITO substrate, we first measured X-ray photoelectron spectroscopy (XPS) of bare ITO, Me-4PACz-, and Poly-4PACz-coated ITO substrates, and we found 

> 1State Key Laboratory of Coordination Chemistry, MOE Key Laboratory of High Performance Polymer Materials & Technology, School of Chemistry and Chemical Engineering, Nanjing University, Nanjing 210023, Jiangsu, China 

2Department of Chemistry and Hong Kong Branch of Chinese National Engineering Research Center for Tissue Restoration and Reconstruction, Hong Kong University of Science and Technology, Clear Water Bay, Kowloon, Hong Kong 999077, China 

3Hoffmann Institute of Advanced Materials, Shenzhen Polytechnic, 7098 Liuxian Blvd, Nanshan District, Shenzhen 518055, China 4These authors contributed equally 5Lead contact *Correspondence: hyan@ust.hk (H.Y.), schen@nju.edu.cn (S.C.) https://doi.org/10.1016/j.joule.2023.10.014 

Joule 7, 2894–2904, December 20, 2023 2895 





<!-- Start of picture text -->
ll<br><!-- End of picture text -->

Article 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->





Figure 1. Synthesis and characterizations of Poly-4PACz (A) Synthesis route of Poly-4PACz. 

(B) UV-vis spectra of Me-4PACz and Poly-4PACz thin films. Inset shows the chemical structure of Me4PACz. 

(C) XPS In 3d spectra of bare ITO, Me-4PACz-, and Poly-4PACz-covered ITO substrates. (D) Routine IR and IR-PiFM spectra of Poly-4PACz powder (bottom) and thin layer on ITO substrate (top). 

an obvious shift of In 3d peaks (Figure 1C) after the deposition of Me-4PACz or Poly4PACz on ITO. Such a shift was not observed for N 1s peaks between Poly-4PACz powder and Poly-4PACz thin layer on ITO (Figure S4). Meanwhile, we performed the infrared photo-induced force microscopy (IR-PiFM) measurement of the ITO glass substrate covered by Poly-4PACz thin layer and compared it with the routine IR spectrum of Poly-4PACz powder. As shown in Figure 1D, compared with Poly-4PACz powder, we observed the shift of the vibration peaks of P–O–H groups after coating Poly4PACz on ITO glass substrate, whereas no notable shift was observed for the vibration peak of P=O group, indicating the bidentate bonding interaction between P–O–H moieties with ITO.<sup>26</sup> 

For the PACz-type small-molecular HTMs such as Me-4PACz, their hole-transporting performance is highly sensitive to layer numbers and coverages on TCO, and ideally, they should spread into a compact SAM layer to block electrons and extract holes. However, the scalable large-area coatings make the formation of such a compact SAM layer on TCO pretty challenging, particularly on rougher FTO substrates that are low-cost and widely used in the real manufacturing of perovskite modules. We show that this issue can be well addressed by polymerizing PACz small molecules to Poly-4PACz that exhibits high conductance and can conformally cover TCO layer at a large thickness without increasing hole-transporting resistance. As shown in the conductive AFM (cAFM) images of Me-4PACz- and Poly-4PACz-coated ITO substrates (Figures 2A and 2B), the mean current (1.65 nA) of the Poly-4PACz ITO substrate is five times higher than that (0.32 nA) of Me-4PACz (the distribution of current values can be found in Figure S5), which indicates the conductance of Poly-4PACz is much higher than that of Me4PACz counterpart. The hole mobilities of Me-4PACz and Poly-4PACz films via the space-charge-limited current (SCLC) method with a hole-only device structure of 

2896 Joule 7, 2894–2904, December 20, 2023 

**ll** 

#### Article 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->













Figure 2. Optoelectrical characterizations of Poly-4PACz layers (A and B) c-AFM current images of (A) Me-4PACz and (B) Poly-4PACz-coated ITO substrates. (C and D) (C) Steady-state PL and (D) TRPL spectra of the perovskite films on Me-4PACz and Poly4PACz-coated ITO substrates excited from the glass side. 

glass/ITO/Poly(3,4-ethylenedioxythiophene)-poly(styrenesulfonate) (PEDOT:PSS)/ HTM/MoO3/Ag. The results (Figure S6) show that Poly-4PACz exhibits a much higher hole mobility of 4.4 3 10<sup>�5</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> than that of Me-4PACz (9.6 3 10<sup>�6</sup> cm<sup>2</sup> V<sup>�1</sup> s<sup>�1</sup> ). This is attributed to the delocalization of electrons along the polymer backbone of Poly4PACz that facilitates the intra- and inter-chain charge transport. Such good conductance allows Poly-4PACz to efficiently extract holes even forming a thick layer that fully covers the TCO surface instead of a SAM layer such as Me-4PACz-type small molecules. Meanwhile, the phosphonic acid groups of Poly-4PACz, on the one hand, can bond to TCO; on the other hand, the excess phosphonic acid groups can also bond to perovskite phase and passivate the interfacial defects, which will be discussed in the following device performance characterization section. 

X-ray diffraction (XRD) patterns of the perovskite films show negligible differences in crystallinity when blade-coated on Me-4PACz and Poly-4PACz-covered ITO glass substrates (Figure S7). Subsequently, both steady-state and time-resolved photoluminescence (TRPL) characterizations were carried out to investigate the effects of Poly-4PACz on film PL behaviors compared with Me-4PACz counterpart, in which the films were excited through the substrate/HTM side. Compared with the film coated on ITO/Me-4PACz substrate, Poly-4PACz is able to enhance the PL intensity by �40% (Figure 2C). Meanwhile, the PL lifetime of the film on Me-4PACz is 512 ns, whereas it is further increased to 633 ns after replacing Me-4PACz with Poly-4PACz (Figures 2D and S8). The enhanced PL intensity and prolonged PL lifetime can be attributed to both more compact coating of Poly-4PACz and its passivation effects from richer phosphonic acid groups that suppress the non-radiative interfacial recombination. Later, p-i-n-structured PSCs were fabricated with a planar heterojunction architecture of glass/ITO/HTM/MA0.7FA0.3PbI3 (�1,000 nm thick)/C60/bathocuproine (BCP)/copper (Cu). Both HTMs and perovskite layers were processed via blade-coating method at ambient conditions. The champion PSC based on Poly4PACz delivered an impressive PCE of 24.4%, along with an open-circuit voltage 

Joule 7, 2894–2904, December 20, 2023 2897 





<!-- Start of picture text -->
ll<br><!-- End of picture text -->

Article 



<!-- Start of picture text -->
A B<br>C D<br><!-- End of picture text -->





Figure 3. Solar cell characterizations (A) J-V curves, (B) EQE, (C) TPV, and (D) tDOS spectra of the blade-coated PSCs based on Me4PACz and Poly-4PACz. Inset in (A) shows the stabilized power output curve of the champion Poly4PACz cell at a fixed bias of 1.03 V for 500 s. 

(VOC) of 1.17 V, a short-circuit current density (JSC) of 24.8 mA cm<sup>�2</sup> , and a fill factor (FF) of 0.839 (Figure 3A), outperforming the reference cells based on Me-4PACz (21.9%, VOC: 1.14 V, JSC: 24.3 mA cm<sup>�2</sup> , FF: 0.789). The champion cell based on Poly-4PACz was further held at a fixed bias of 1.03 V, or maximum power point (MPP), and a stabilized power output for 500 s was recorded as depicted in the inset of Figure 3A. The current density was stabilized at 23.5 mA cm<sup>�2</sup> , thus corresponding to a stabilized PCE of 24.2%, which is the highest stabilized PCE for blade-coated PSCs. The improved VOC of Poly-4PACz-based cells is attributed to the both better passivation effects of Poly-4PACz and the compact coating of Poly-4PACz that can reduce the leakage current. The champion cell based on Poly-4PACz also show negligible hysteresis (Figure S9A), and the average PCE of 23.6% G 0.5% was obtained (Figure S9B; Tables S3 and S4). The external quantum efficiency (EQE) spectra show that Poly-4PACz-based cell exhibits more efficient photon-to-current conversion efficiency in the range of 400–800 nm than Me-4PACz counterpart (Figure 3B). We also measured the transient photovoltage (TPV), transient photocurrent (TPC), electrochemical impedance spectroscopy (EIS), and trap density of state (tDOS) of two types of PSCs. As shown in Figure 3C, we observed a much longer photovoltage recombination lifetime (3.6 ms) when replacing Me-4PACz with Poly-4PACz (2.0 ms), which is consistent with the trend observed by TRPL characterizations. Meanwhile, TPC measurement results showed that replacing Me-4PACz with Poly-4PACz was able to reduce the carrier transit time from 42.1 to 31.2 ns (Figure S10), indicating the better carrier extraction capability of Poly-4PACz. EIS characterizations (Figure S11) show that Poly-4PACz-based PSC exhibits a smaller series resistance of 47 U than that based on Me-4PACz (65 U). In addition, the Poly-4PACz-based PSC exhibited a lower trap density in the shallow trap depth region from 0.25 to 0.35 eV characterized by thermal admittance spectroscopy (TAS, Figure 3D). These results clearly confirm the passivation effects of Poly-4PACz to the HTM/perovskite interface. 

2898 Joule 7, 2894–2904, December 20, 2023 

**ll** 

#### Article 

Table 1. Photovoltaic parameters of the champion PSCs based on Me-4PACz and Poly-4PACz at different concentrations 

|HTMs on ITO|Concentration (mg mL<sup>�1</sup>)|VOC(V)|JSC<br>(mA cm<sup>�2</sup>)|FF|PCE (%)|
|---|---|---|---|---|---|
|Me-4PACz|0.5|1.12|23.8|0.717|19.1|
||1|1.14|24.3|0.789|21.9|
||3|1.08|20.5|0.522|11.6|
|Poly-4PACz|0.5|1.16|24.7|0.810|23.2|
||1|1.17|24.8|0.839|24.4|
||3|1.16|24.8|0.817|23.5|



We also investigated the impacts of HTM thickness on cell PCEs by changing the concentrations of HTM precursor solutions. As shown in Table 1, even the concentration of Poly-4PACz solution increased by three times to 3 mg mL<sup>�1</sup> , which corresponds to a layer thickness of �25–30 nm as determined by AFM characterization (Figure S12), and the resultant cells can still realize a decent PCE of 23.5%. On the contrary, the PCEs of Me-4PACz-based cells were significantly reduced to 19.1% and 11.6% at Me-4PACz concentrations of 0.5 and 3 mg mL<sup>�1</sup> , which are ascribed to the incomplete coverage of Me-4PACz and high electrical resistance from multiple-layer stacking of Me-4PACz, respectively. To testify the versatility of Poly-4PACz, we tried Poly-4PACz HTM in spin-coated Cs0.05(FA0.98MA0.02)0.95Pb(I0.98Br0.02)3 PSCs. The perovskite films showed much better coverage on Poly-4PACz layer (Figure S13A), and the corresponding cell realized a higher PCE of 21.0% than that (9.3%) of the Me-4PACz counterpart (Figure S13B). In addition, we also explored the application of Poly-4PACz in FTO substrates that are much thicker and have a much rougher surface (roughness: 8–15 nm, Figure S14) than ITO (RMS: 1–3 nm). Similarly, Poly-4PACz-based cells show a much higher PCE of 22.7% (Figure S15) than that based on Me-4PACz (15.9%). To the best of our knowledge, this is also the record PCE for the p-i-n PSCs on FTO substrates. Besides blade-coating, dip-coating by immersing TCO substrates in SAM solution is also a feasible method for large-area deposition of SAM HTMs, but subsequent rinsing step is generally required to wash away excess and unassembled HTM molecules. We also tried such a dip-coating method for Poly-4PACz deposition by immersing ITO substrates into a 0.5 mg mL<sup>�1</sup> Poly-4PACz solution for 30 min, and no rinsing step was involved. The resultant unoptimized cell delivered a decent PCE of 21.8% (Figure S16). The high conductance of Poly-4PACz enables it to achieve good PCEs without the rinsing step, which is beneficial for simplifying the fabrication procedures. These results verify that Poly-4PACz has a much wider processing window that is highly desirable in the scalable manufacturing of perovskite photovoltaics. To investigate the stabilization effects of Poly-4PACz on substrate/perovskite interface and solar devices, we connected two types of cells to an automatic MPP tracker that enabled our cells to keep working at MPP conditions under simulated AM 1.5G 1 sun illumination (100 mW cm<sup>�2</sup> ). As plotted in Figure 4A, the Poly-4PACz-based cell exhibited much better operational stability that 94% of the initial PCE was retained after over 1,500h light soaking, whereas the control cell lost 50% of efficiency after 1,000-h MPP tracking. This clearly verifies the effectiveness of Poly-4PACz in stabilizing p-i-n PSCs. 

Based on the successful application of Poly-4PACz in small-area cells, we further transferred to large perovskite modules with the aforementioned room-temperature bladecoating method. As expected, Poly-4PACz can be coated onto large ITO substrates uniformly, and the large perovskite films show mirror-like surfaces when coated onto Poly-4PACz-covered ITO module substrate (inset in Figure 4B). The Poly-4PACz-based perovskite module was able to realize an impressive PCE of 20.7% at an aperture area of 25.0 cm<sup>2</sup> , with a VOC of 8.11 V (1.16 V for each sub-cell), a short-circuit current (ISC) of 

Joule 7, 2894–2904, December 20, 2023 2899 

**ll** 

Article 



<!-- Start of picture text -->
A B<br><!-- End of picture text -->

Figure 4. Cell stability and module fabrication (A) MPP tracking stability test results of the encapsulated PSCs based on Me-4PACz- and Poly4PACz-covered ITO substrates. 

(B) J-V characteristics of the Poly-4PACz-based perovskite mini-module with an aperture area of 25.0 cm<sup>2</sup> . Inset shows a picture of Poly-4PACz-based perovskite module. 

82.5 mA, and a FF of 0.773. Considering the geometrical FF (GFF) of 92%, the aperturearea efficiency corresponds to an active-area PCE of 22.5% (Figure 4B), respectively. Overall, these results suggest that such a polymeric material is totally compatible with the scalable fabrication of perovskite modules, and Poly-4PACz has very promising applications in the real-world manufacturing of perovskite photovoltaics. 

###### Conclusions 

In summary, we develop a versatile HTM by polymerizing small-molecular carbazole phosphonic acid, and the resulting Poly-4PACz exhibits excellent hole-transporting capacity while maintaining good solution processibility. Most importantly, not like Me-4PACz-type HTMs that are highly sensitive to layer thickness, Poly-4PACz shows high conductance and good tolerance to layer thickness. Consequently, the p-i-n type cells and modules based on Poly-4PACz realized impressive PCEs of 24.4% and 20.7%, respectively. The target cell was able to stably operate for 1,500 h with only 6% efficiency loss. Overall, taking into consideration of its low cost, thickness insensitiveness, good conductance, excellent scalability, and stability, we believe that Poly-4PACz will have very promising applications in the real-world manufacturing of perovskite modules. 

##### EXPERIMENTAL PROCEDURES 

###### Resource availability 

Lead contact 

Further information and requests for resources should be directed to and will be fulfilled by the lead contact, Shangshang Chen (schen@nju.edu.cn). 

###### Materials availability 

Poly-4PACz generated in this study will be made available on request, but we may require a payment and/or a completed materials transfer agreement if there is potential for commercial application. 

###### Data and code availability 

This study did not generate any datasets or code. 

###### Materials 

All chemicals without any notes were commercially available and used without further purification. Me-4PACz was purchased from TCI chemical. BCP, lead iodide 

2900 Joule 7, 2894–2904, December 20, 2023 

**ll** 

#### Article 

(PbI2, 99.999% trace metals), dimethyl sulfoxide (DMSO), L-a-phosphatidylcholine (LP), benzylhydrazine dihydrochloride, 2-methoxyethanol (2-ME), and toluene were purchased from Sigma-Aldrich and used without further purification. C60 was purchased from eFlexPV Limited. Methylammonium iodide (MAI), formamidinium iodide (FAI), 4-fluoro-phenethylammonium iodide (p-F-PEAI), and n-dodecylammonium iodide were purchased from GreatCell Solar. The other chemicals involved in the synthesis of Poly-4PACz were purchased from Anhui energy-chemical. 

###### Device fabrication 

Patterned TCO glass substrates (1.5 cm 3 1.5 cm ITO/FTO for solar cells, and 13.0 cm 3 8.5 cm ITO for solar modules) were first cleaned by ultrasonication with soap, deionized water, and isopropyl alcohol, and then, they were UV-ozone-treated for 15 min before use. HTMs (Me-4PACz and Poly-4PACz) were dissolved in a solvent mixture of methanol:chloroform (1:1, v/v) at different concentrations. All perovskite solar devices were prepared by blade-coating at room temperature inside a fume hood with a relative humidity of 40% G 10%. The configuration of our blade-coater for perovskite film deposition can be found in Figure S17. Before coating perovskite films, the HTMs were bladecoated onto TCO glass substrates at a speed of 20 mm s<sup>�1</sup> , followed by a thermal annealing process at 100<sup>�</sup> C for 10 min in air. The gap between blade-coater and TCO substrates was 200 mm. 1.30 M MA0.7FA0.3PbI3 precursor solution was prepared by dissolving corresponding organic halide salts and PbI2 into 2-ME in a N2-filled glovebox with an O2 level < 10 ppm. 0.83 mg mL<sup>�1</sup> n-dodecylammonium iodide, 0.27 mg mL<sup>�1</sup> LP, 0.14% v/v MAH2PO2, 1.40 mg mL<sup>�1</sup> p-F-PEAI, 0.15 mg mL<sup>�1</sup> benzylhydrazine dihydrochloride, and 2.8% v/v DMSO were added as additives before blade-coating. Subsequently, the precursor solution was blade-coated onto the HTM-covered TCO glass substrates with a gap of 230 mm at a movement speed of 20 mm s<sup>�1</sup> . The N2 knife worked at 20 psi during blade-coating. After that, the perovskite films were annealed at 120<sup>�</sup> C for 10 min in air to remove the residual solvents. The solar cells were completed by thermally evaporatingC60 (30nm,0.3A<sup>˚</sup> s<sup>�1</sup> ),BCP(6nm,0.1A<sup>˚</sup> s<sup>�1</sup> ),and100nmCu(1A<sup>˚</sup> s<sup>�1</sup> ).AMgF2 layer (100 nm for ITO substrates and 130 nm for FTO substrates) was thermally evaporated to the front surface of solar cells as the antireflection coating. The active areas of solar cells are 8 mm<sup>2</sup> (4 mm 3 2 mm determined by a metal shadow mask). For mini-modules based on ITO, the laser scribing was performed twice with a Keyence laser marker (MD-U1000C,355 nm).The laserpowerforP2andP3scribingare �0.375W,andthe final widths of P2 and P3 were measured to be about 140 and 70 mm, respectively. The total scribing line width was �0.5 mm, giving a GFF of 92%. The champion module has 7 subcells, and each sub-cell has a total area of 3.575 cm<sup>2</sup> (0.65 cm by 5.5 cm). A polydimethylsiloxane(PDMS) layer preparedbyasoftlithography methodwasapplied tothe front surface of glass substrate as antireflection coating during the measurement of the target perovskite solar modules. The PDMS antireflection layer was prepared according to our previous work.<sup>15</sup> Specifically, the PDMS antireflection layer was prepared by a soft lithography method, and a textured silicon wafer with pyramid size of �10 mm was used as a template. First, the PDMS pre-polymer/curing agent mixture (SYLGARD 184 SILICONE ELASTOMER, 10:1 w/w) was dropped onto the silicon wafer and let rest for 0.5 h to allow the PDMS to fill the cavities. After cured on a hot plate kept at 150<sup>�</sup> C for 15 min, the PDMS layer was peeled off silicon wafer with caution and then mounted onto the surface of module substrate with adhesive tapes. 

###### Device and material characterization 

The J-V characteristics of solar devices were measured using a light-emitting diode (LED) solar simulator (BG-LED3A-100S, Class AAA Solar Simulator, solar spectrum can be found in Figure S18), and the power of the simulated light was calibrated to 100 mW cm<sup>�2</sup> by a silicon reference cell (Newport 91150V-KG5). The silicon reference 

Joule 7, 2894–2904, December 20, 2023 2901 

**ll** 

Article 

cell was certified on February 18, 2022, and the next calibration due date is December 06, 2023 according to the Newport certificate (Figure S19). The spectral mismatch was calculated to be 0.4% between reference cell and testing cells. All devices were measured using a Keithley 2400 source meter with a backward scan rate of 0.1 V s<sup>�1</sup> in air at room temperature, and the delay time was 10 ms. There was no preconditioning before measurement. A metal mask with an aperture (6.84 mm<sup>2</sup> ) aligned with the solar cell area was used for measurements. The PSCs were encapsulated with cover glass sealed by epoxy encapsulant (Gorilla 2-part epoxy 4200130) on the back. After curing, the stability of encapsulated cells was monitored with a 91 PVKSOLAR MSCLT-1 automatic MPP tracker. A Me-4PACz-based cell and a Poly-4PACz-based cell were connected to the MPP tracker, and two cells kept working at MPP conditions under simulated AM 1.5G 1 sun illumination (100 mW cm<sup>�2</sup> , light source: 91PVKAT500M) in air (relative humidity: �30%–40%). The stabilized PCEs were recorded every 10 s. No fan or cooler was used to control the cell temperature, and the temperature of the cells was measured to be �40<sup>�</sup> C. The XRD patterns were acquired with a Bruker D8 ADVANCE X-ray diffractometer. XPS was performed using a Thermo SCIENTIFIC ESCALAB Xi+ with Al Ka anode source (1,486.6 eV) operated at 15 kV and 10<sup>�9</sup> mbar chamber pressure. Routine AFM images were obtained with a Bruker Icon atomic force microscope. c-AFM experiments were performed with an Asylum ORCA cantilever holder with a gain of 1 3 10<sup>�9</sup> V/A. The bias voltage was applied to the sample and the tip was virtually grounded for all measurements. IR-PiFM measurement was taken on a Vista75 microscope of Molecular Vista, which is coupled to a QCL laser system from Block Engineering with a wavenumber resolution of 1 cm<sup>�1</sup> and a tuning range from 770 to 1,860 cm<sup>�1</sup> . The IR beam is focused on the sample with an angle of 30 degrees using a parabolic mirror. The set point is set as 75% with an oscillation amplitude of �1 nm. The microscope is operated in dynamic mode with NCHR-Pt/Ir-PiFM non-contact cantilevers from Molecular Vista. The cantilever was excited at its second resonance around 1.70 MHz. The measurements were carried out in a dry air environment to minimize the water background from environment. The collection time for each spectrum is around 30 s, and the spectrum is normalized with the background laser power profile spectrum. Routine IR spectrum of Poly-4PACz powder was acquired with Bruker FT-IR Tensor II Spectrometer. I-V data were collected with a triangular voltage shape (ramp of 3 V/s; 2,000 points/s). Molecular weights of Poly-4PACz were determined by gel permeation chromatograph (GPC) equipped with a Water 2414 refractive index detector. UV-vis absorption spectra were obtained with a Shimadzu UV3600 Spectrophotometer. Cyclic voltammetry was carried out on a Shanghai CHI660E electrochemical workstation with three-electrode configuration, using Ag/AgCl as the reference electrode, a Pt plate as the counter electrode, and a glassy carbon as the working electrode. The HTM solutions were drop-cast onto the electrodes to form thin films. 0.1 mol L<sup>�1</sup> tetrabutylammonium hexafluorophosphate in anhydrous acetonitrile was used as the supporting electrolyte. Potentials were referenced to the ferrocenium/ferrocene couple by using ferrocene as external standards in acetonitrile solutions. The scan rate is 0.1 V s<sup>�1</sup> . EQE spectra were obtained with a Zolix SCS600 solar cell quantum efficiency measurement system equipped with a standard Si cell. EIS characterization was carried out on a Shanghai CHI660E electrochemical workstation, and the Nyquist plots of the EIS spectra were measured at the frequency range of 100 MHz to 1 Hz with a bias of 0.9 V in dark. TPV and TPC spectra were measured with an oscilloscope (Tektronix DPO 4104B-L) and a laser pulse (Quantel Q-smart 450 laser) as a small perturbation to the cells. The cells were connected to the oscilloscope at an open-circuit condition and illuminated by a simulated solar simulator (100 mW cm<sup>�2</sup> ). The laser pulse width was 3 ns, and the laser intensity was adjusted to make sure the photovoltage variation was less than 5% of VOC, and then, TPV spectra were obtained. After that, the background 

2902 Joule 7, 2894–2904, December 20, 2023 

**ll** 

#### Article 

illumination was removed, and the internal impedance was set to 50 U to form a shortcircuit condition to obtain TPC spectra while the laser intensity remained unchanged. tDOS spectra were obtained with an Agilent E4980A precision LC meter. Both steadystate PL and TRPL spectra were acquired on a HORIBA FL-3 fluorescence spectrophotometer at room temperature. The excitation wavelengths were 480 and 405 nm for PL and TRPL measurements, respectively. The TRPL curves were fitted with a bi-exponential formula of y = y0 + A1exp(�(x � x0)/t1) + A2exp(�(x � x0)/t2) (t2 > t1). The exponential decay fittings of TRPL curves were shown in Figure S8. The t1 values of two cases were found to be comparable, and here, we used t2 to represent the lifetimes of the films.<sup>1</sup> H NMR and<sup>13</sup> C NMR spectra were obtained on a 500 MHz Bruker AVANCE III-500 spectrometer. High-resolution mass spectrometry (HR-MS) was performed on a Thermo Fisher Q Exactive LC/MS. 

##### SUPPLEMENTAL INFORMATION 

Supplemental information can be found online at https://doi.org/10.1016/j.joule. 2023.10.014. 

##### ACKNOWLEDGMENTS 

S.C. acknowledges support from the National Natural Science Foundation of China (no. 52372196). We thank Lu Han and Prof. Jia Zhu at Nanjing University for c-AFM measurements. 

##### AUTHOR CONTRIBUTIONS 

S.C. conceived the idea, designed the experiments, and supervised the project. Z.R. synthesized Poly-4PACz. Z.C. fabricated the solar devices. X.S., L.W., Y.D., and F.W. assisted with the material and device characterizations. H.L. carried out IR-PiFM measurement. S.C. and Z.R. wrote the paper. All authors reviewed this paper. 

##### DECLARATION OF INTERESTS 

The authors declare no competing interests. 

Received: June 27, 2023 Revised: September 5, 2023 Accepted: October 19, 2023 Published: November 10, 2023 

##### REFERENCES 

7. Zhang, B., Oh, J., Sun, Z., Cho, Y., Jeong, S., Chen, X., Sun, K., Li, F., Yang, C., and Chen, S. (2023). Buried guanidinium passivator with favorable binding energy for perovskite solar cells. ACS Energy Lett. 8, 1848–1856. https://doi.org/10.1021/ acsenergylett.2c02881. 

hole transport material. Nat. Photonics 16,, 119–125. https://doi.org/10.1038/s41566021-00931-7.. 

1. Correa-Baena, J.P., Saliba, M., Buonassisi, T., hole transport material. Nat. Photonics 16,, Gra¨tzel, M., Abate, A., Tress, W., and Hagfeldt, 119–125. https://doi.org/10.1038/s41566A. (2017). Promises and challenges of 021-00931-7.. perovskite solar cells. Science 358, 739–744. https://doi.org/10.1126/science.aam6323. 5. Chen, X., Guo, B., Zhang, Z., Zhang, B., Zu, X., Ouedraogo, N.A.N., Oh, J., Cho, 

2. Rong, Y., Hu, Y., Mei, A., Tan, H., Saidaminov, Y., Odunmbaku, G.O., Chen, K., et al. M.I., Seok, S.I., McGehee, M.D., Sargent, E.H., (2023). Binary hole transport layer enables and Han, H. (2018). Challenges for stable perovskite solar cells with PCE commercializing perovskite solar cells. Science exceeding 24%. DeCarbon 1,, 100004. 361, eaat8235. https://doi.org/10.1126/, eaat8235. https://doi.org/10.1126/ https://doi.org/10.1126/ https://doi.org/10.1016/j.decarb.2023. science.aat8235.. 100004.. 

2. Rong, Y., Hu, Y., Mei, A., Tan, H., Saidaminov, M.I., Seok, S.I., McGehee, M.D., Sargent, E.H., and Han, H. (2018). Challenges for commercializing perovskite solar cells. Science 361, eaat8235. https://doi.org/10.1126/, eaat8235. https://doi.org/10.1126/ https://doi.org/10.1126/ science.aat8235.. 

   - stable perovskite solar cells with PCE 8. Jeng, J.Y., Chiang, Y.F., Lee, M.H., Peng, S.R., exceeding 24%. DeCarbon 1,, 100004. Guo, T.F., Chen, P., and Wen, T.C. (2013). https://doi.org/10.1016/j.decarb.2023. CH3NH3PbI3 perovskite/fullerene planar100004.. heterojunction hybrid solar cells. Adv. Mater. 25, 3727–3732. https://doi.org/10.1002/adma. 

   - 6. Xiong, Z., Chen, X., Zhang, B., 201301327. Odunmbaku, G.O., Ou, Z., Guo, B., Yang, K., Kan, Z., Lu, S., Chen, S., et al. (2022). 9. Zhu, R. (2020). Inverted devices are catching Simultaneous interfacial modification and up. Nat. Energy 5, 123–124. https://doi.org/10. 5, 123–124. https://doi.org/10., 123–124. https://doi.org/10. https://doi.org/10. crystallization control by biguanide 1038/s41560-020-0559-z.. hydrochloride for stable perovskite solar cells with PCE of 24.4%. Adv. Mater. 34, 10. Liu, T., Chen, K., Hu, Q., Zhu, R., and Gong, Q. e2106118. https://doi.org/10.1002/adma. (2016). Inverted perovskite solar cells: 202106118. progresses and perspectives. Adv. Energy 

3. Service, R.F. (2016). Perovskite solar cells gear up to go commercial. Science 354, 1214–1215. https://doi.org/10.1126/science.354. 6317.1214. 

   9. Zhu, R. (2020). Inverted devices are catching up. Nat. Energy 5, 123–124. https://doi.org/10. 5, 123–124. https://doi.org/10., 123–124. https://doi.org/10. https://doi.org/10. 1038/s41560-020-0559-z.. 

4. Jeong, M., Choi, I.W., Yim, K., Jeong, S., Kim, M., Choi, S.J., Cho, Y., An, J.-H., Kim, H.-B., Jo, Y., et al. (2022). Large-area perovskite solar cells employing spiro-Naph 

10. Liu, T., Chen, K., Hu, Q., Zhu, R., and Gong, Q. (2016). Inverted perovskite solar cells: progresses and perspectives. Adv. Energy 

Joule 7, 2894–2904, December 20, 2023 2903 

### **ll** 

#### Article 

17. Li, Z., Li, B., Wu, X., Sheppard, S.A., Zhang, S., Gao, D., Long, N.J., and Zhu, Z. (2022). Organometallic-functionalized interfaces for highly efficient inverted perovskite solar cells. Science 376, 416–420. https://doi.org/10.1126/ science.abm8566. 

Mater. 6, 1600457. https://doi.org/10.1002/ aenm.201600457. 

11. Li, B., Li, Z., Wu, X., and Zhu, Z. (2022). Interface functionalization in inverted perovskite solar cells: from material perspective. Nano Res. Energy 1, e9120011. https://doi.org/10.26599/ NRE.2022.9120011. 

   18. Degani, M., An, Q., Albaladejo-Siguan, M., Hofstetter, Y.J., Cho, C., Paulus, F., Grancini, G., and Vaynzof, Y. (2021). 23.7% efficient inverted perovskite solar cells by dual interfacial modification. Sci. Adv. 7, eabj7930. https://doi.org/10.1126/sciadv.abj7930. 

12. Li, Z., Klein, T.R., Kim, D.H., Yang, M., Berry, J.J., van Hest, M.F.A.M., and Zhu, K. (2018). Scalable fabrication of perovskite solar cells. Nat. Rev. Mater. 3, 18017. https://doi.org/10. 1038/natrevmats.2018.17. 

   19. Al-Ashouri, A., Ko¨ hnen, E., Li, B., Magomedov, A., Hempel, H., Caprioglio, P., Ma´rquez, J.A., Morales Vilches, A.B., Kasparavicius, E., Smith, J.A., et al. (2020). Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. Science 370, 1300– 1309. https://doi.org/10.1126/science. abd4016. 

13. Howard, I.A., Abzieher, T., Hossain, I.M., Eggers, H., Schackmar, F., Ternes, S., Richards, B.S., Lemmer, U., and Paetzold, U.W. (2019). Coated and printed perovskites for photovoltaic applications. Adv. Mater. 31, e1806702. https://doi.org/10.1002/adma. 201806702. 

14. Bi, C., Wang, Q., Shao, Y., Yuan, Y., Xiao, Z., and Huang, J. (2015). Non-wetting surface-driven high-aspect-ratio crystalline grain growth for efficient hybrid perovskite solar cells. Nat. Commun. 6, 7747. https://doi.org/10.1038/ ncomms8747. 

   20. He, R., Wang, W., Yi, Z., Lang, F., Chen, C., Luo, J., Zhu, J., Thiesbrummel, J., Shah, S., Wei, K., et al. (2023). Improving interface quality for 1-cm<sup>2</sup> all-perovskite tandem solar cells. Nature 618, 80–86. https://doi.org/10.1038/s41586023-05992-y. 

15. Chen, S., Xiao, X., Gu, H., and Huang, J. (2021). Iodine reduction for reproducible and highperformance perovskite solar cells and modules. Sci. Sci. Adv. 7, eabe8130. https:// doi.org/10.1126/sciadv.abe8130. 

   21. Zeng, J., Bi, L., Cheng, Y., Xu, B., and Jen, A.K.-Y. (2022). Self-assembled monolayer enabling improved buried interfaces in bladecoated perovskite solar cells for high efficiency and stability. Nano Res. Energy 1, e9120004. https://doi.org/10.26599/NRE. 2022.9120004.. 

16. Chen, S., Dai, X., Xu, S., Jiao, H., Zhao, L., and e9120004. https://doi.org/10.26599/NRE. Huang, J. (2021). Stabilizing perovskite2022.9120004.. substrate interfaces for high-performance perovskite modules. Science 373, 902–907. 22. Phung, N., Verheijen, M., Todinova, A., Datta, https://doi.org/10.1126/science.abi6323. K., Verhage, M., Al-Ashouri, A., Ko¨ bler, H., Li, 

   - X., Abate, A., Albrecht, S., et al. (2022). Enhanced self-assembled monolayer surface coverage by ALD NiO in p-i-n perovskite solar cells. ACS Appl. Mater. Interfaces 14, 2166– 2176. https://doi.org/10.1021/acsami.1c15860. 

23. Zheng, X.P., Li, Z., Zhang, Y., Chen, M., Liu, T., Xiao, C.X., Gao, D.P., Patel, J.B., Kuciauskas, D., Magomedov, A., et al. (2023). Co-deposition of hole-selective contact and absorber for improving the processability of perovskite solar cells. Nat. Energy 8, 462–472. https://doi.org/10.1038/s41560023-01227-6. 

24. Latif, H., Liu, J., Mo, D., Wang, R., Zeng, J., Zhai, P.F., and Sattar, A. (2021). Effect of target morphology on morphological, optical and electrical properties of FTO thin film deposited by pulsed laser deposition for MAPbBr3 perovskite solar cell. Surf. Interfaces 24, 101117. https://doi.org/10.1016/j.surfin.2021. 101117. 

25. Holzhey, P., Prettl, M., Collavini, S., Mortan, C., and Saliba, M. (2023). Understanding the impact of surface roughness: changing from FTO to ITO to PEN/ITO for flexible perovskite solar cells. Sci. Rep. 13, 6375. https://doi.org/ 10.1038/s41598-023-33147-6. 

26. Truong, M.A., Funasaki, T., Ueberricke, L., Nojo, W., Murdey, R., Yamada, T., Hu, S., Akatsuka, A., Sekiguchi, N., Hira, S., et al. (2023). Tripodal triazatruxene derivative as a face-on oriented hole-collecting monolayer for efficient and stable inverted perovskite solar cells. J. Am. Chem. Soc. 145, 7528–7539. https://doi.org/10.1021/jacs.3c00805. 

2904 Joule 7, 2894–2904, December 20, 2023 

