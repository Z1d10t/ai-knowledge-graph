# Improving interface quality for 1-cm^2 all-perovskite tandem solar cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Nature |
| 年份 | 2023 |
| 引用量（Semantic Scholar） | 570 |
| 作者 | Rui He, Wan-Hai Wang, Zong-Jin Yi, F. Lang, Cong Chen, Jin-Cheng Luo, Jing-Wei Zhu, J. Thiesbrummel et al. |
| DOI | 10.1038/s41586-023-05992-y |
| 源文件 | 008_He_2023_Improving-interface-quality-for-1-cm2-all-perovs.pdf |

---
Article 

# **Improving interface quality for 1-cm**<sup>**2**</sup> **all-perovskite tandem solar cells** 

|https://doi.org/10.1038/s41586-023-05992-y<br>Received: 2 October 2022|**Rui He**<sup>**1,11**</sup>**, Wanhai Wang**<sup>**2,3,11**</sup>**, Zongjin Yi**<sup>**1,11**</sup>**, Felix Lang**<sup>**4,11**</sup>**, Cong Chen**<sup>**1** ✉</sup>**, Jincheng Luo**<sup>**1**</sup>**,**<br>**Jingwei Zhu**<sup>**1**</sup>**, Jarla Thiesbrummel**<sup>**4,5**</sup>**, Sahil Shah**<sup>**4**</sup>**, Kun Wei**<sup>**6**</sup>**, Yi Luo**<sup>**1**</sup>**, Changlei Wang**<sup>**7**</sup>**,**<br>**Huagui Lai**<sup>**8**</sup>**, Hao Huang**<sup>**9**</sup>**, Jie Zhou**<sup>**3**</sup>**, Bingsuo Zou**<sup>**9**</sup>**, Xinxing Yin**<sup>**10**</sup>**, Shengqiang Ren**<sup>**1**</sup>**, Xia Hao**<sup>**1**</sup>**,**|
|---|---|
|Accepted: 21 March 2023<br>Published online: 29 March 2023|**Lili Wu**<sup>**1**</sup>**, Jingquan Zhang**<sup>**1**</sup>**, Jinbao Zhang**<sup>**6**</sup>**, Martin Stolterfoht**<sup>**4**</sup>**, Fan Fu**<sup>**8** ✉</sup>**, Weihua Tang**<sup>**2,3** ✉</sup>**&**<br>**Dewei Zhao**<sup>**1** ✉</sup>|
|Check for updates|All-perovskite tandem solar cells provide high power conversion efficiency at a low<br>cost<sup>1–4</sup>. Rapid efficiency improvement in small-area (<0.1 cm<sup>2</sup>) tandem solar cells<br>has been primarily driven by advances in low-bandgap (approximately 1.25 eV)<br>perovskite bottom subcells<sup>5–7</sup>. However, unsolved issues remain for wide-bandgap<br>(> 1.75 eV) perovskite top subcells<sup>8</sup>, which at present have large voltage and fill factor<br>losses, particularly for large-area (>1 cm<sup>2</sup>) tandem solar cells. Here we develop a<br>self-assembled monolayer of (4-(7_H_-dibenzo[_c,g_]carbazol-7-yl)butyl)phosphonic<br>acid as a hole-selective layer for wide-bandgap perovskite solar cells, which facilitates<br>subsequent growth of high-quality wide-bandgap perovskite over a large area<br>with suppressed interfacial non-radiative recombination, enabling efficient hole<br>extraction. By integrating (4-(7_H_-dibenzo[_c,g_]carbazol-7-yl)butyl)phosphonic acid<br>in devices, we demonstrate a high open-circuit voltage (_V_OC) of 1.31 V in a 1.77-eV<br>perovskite solar cell, corresponding to a very low_V_OCdeficit of 0.46 V (with respect<br>to the bandgap). With these wide-bandgap perovskite subcells, we report 27.0%<br>(26.4% certified stabilized) monolithic all-perovskite tandem solar cells with an<br>aperture area of 1.044 cm<sup>2</sup>. The certified tandem cell shows an outstanding<br>combination of a high_V_OCof 2.12 V and a fill factor of 82.6%. Our demonstration of<br>the large-area tandem solar cells with high certified efficiency is a key step towards<br>scaling up all-perovskite tandem photovoltaic technology.|



All-perovskite (all-PVSK) tandem solar cells (TSCs) can surpass the Shockley–Queisser efficiency limit of single-junction solar cells<sup>9–13</sup> . The certified power conversion efficiency (PCE) of small-area (0.049 cm<sup>2</sup> ) monolithic all-PVSK TSCs has reached 28%, exceeding that of the best single-junction solar cells known so far (25.7%)<sup>14</sup> . The rapid increase in PCE of all-PVSK TSCs is because of the advances in low-bandgap (LBG; 1.2–1.3 eV) PVSK subcells; however, relatively large voltage losses limit the wide-bandgap (WBG; approximately 1.8 eV) PVSK subcells, which are equally important for achieving high-efficiency TSCs<sup>15</sup> . Besides the non-radiative voltage losses, WBG perovskite solar cells (PSCs) suffer from relatively low fill factors (FFs), especially for those with areas larger than 1 cm<sup>2</sup> . 

The considerable _V_ OC deficit (defined as _E_ g/ _q_ − _V_ OC) in WBG PSCs is mainly because of the high trap density in the WBG PVSK absorber and poor band alignment with charge-selective contacts<sup>16–20</sup> . It is very 

challenging to reduce the _V_ OC deficit in PVSKs with a wider bandgap (>1.75 eV) for all-PVSK TSCs<sup>7</sup> . 

The performance of WBG PSCs and all-PVSK TSCs is also limited by the relatively low FF<sup>21–23</sup> , typically below 80%. The low FF is mainly attributed to poor film uniformity, non-ideal charge transport and non-radiative recombination between the PVSK and the charge-selective layer. This limitation is more pronounced for devices with a large active area (>1 cm<sup>2</sup> ). For instance, the certified PCE of all-PVSK TSCs with a centimetre-scale active area is only 24.2% with a _V_ OC of 1.986 V and an FF of 76.6%, which is much lower than that of small-area devices and could be mainly due to poor uniformity of WBG PVSK subcell and resistive losses<sup>24,25</sup> . Recently, it was found that replacing conventional hole-transport layer (HTL) poly(bis(4-phenyl)(2,4,6-trimethylphenyl) amine) (PTAA) with a self-assembled monolayer (SAM) suppresses the interfacial non-radiative recombination and enables fast hole 

> 1College of Materials Science and Engineering & Institute of New Energy and Low-Carbon Technology & Engineering Research Center of Alternative Energy Materials and Devices, Ministry of Education, Sichuan University, Chengdu, China.<sup>2</sup> Institute of Flexible Electronics (IFE, Future Technologies), Innovation Laboratory for Sciences and Technologies of Energy Materials of Fujian Province (IKKEM), Xiamen University, Xiamen, China.<sup>3</sup> School of Chemistry and Chemical Engineering, Nanjing University of Science and Technology, Nanjing, China.<sup>4</sup> Institute of Physics and Astronomy, University of Potsdam, Potsdam, Germany.<sup>5</sup> Clarendon Laboratory, University of Oxford, Oxford, UK.<sup>6</sup> College of Materials, Fujian Key Laboratory of Advanced Materials, Xiamen Key Laboratory of Electronic Ceramic Materials and Devices, Xiamen University, Xiamen, China.<sup>7</sup> School of Optoelectronic Science and Engineering, Collaborative Innovation Center of Suzhou Nano Science and Technology, Key Lab of Advanced Optical Manufacturing Technologies of Jiangsu Province, Key Lab of Modern Optical Technologies of Education Ministry of China, Soochow University, Suzhou, China.<sup>8</sup> Laboratory for Thin Films and Photovoltaics, Empa, Swiss Federal Laboratories for Materials Science and Technology, Dübendorf, Switzerland. 

> 9State Key Laboratory of Featured Metal Materials and Life-cycle Safety for Composite Structures, School of Resources, Environment and Materials, Guangxi University, Nanning, China. 

> 10China-Australia Institute for Advanced Materials and Manufacturing (IAMM), Jiaxing University, Jiaxing, China. 11These authors contributed equally: Rui He, Wanhai Wang, Zongjin Yi, Felix Lang. ✉ e-mail: chen.cong@scu.edu.cn; fan.fu@empa.ch; whtang@xmu.edu.cn; dewei.zhao@scu.edu.cn 

**80** | Nature | Vol 618 | 1 June 2023 



<!-- Start of picture text -->
a b c d<br>–0.03<br>N<br>n 0.03 ITO<br>PTAA Side view �  = 0.84 D<br>e f g h<br>–0.03<br>N<br>HO P OH<br>O<br>4PACz Side view �  = 1.93 D 0.03 ITO<br>i j k l<br>–0.03<br>N<br>HO P OH<br>O<br>0.03 ITO<br>4PADCB Side view �  = 2.63 D<br><!-- End of picture text -->

**Fig. 1 | Material properties and schematic of interconnection between ITO, HTLs and PVSK. a** , **e** , **i** , Molecular structure of PTAA ( **a** ), 4PACz ( **e** ) and 4PADCB ( **i** ). **b** , **f** , **j** , Side view of PTAA ( **b** ), 4PACz ( **f** ) and 4PADCB ( **j** ). **c** , **g** , **k** , Calculated ESP 

of PTAA ( **c** ), 4PACz ( **g** ) and 4PADCB ( **k** ). **d** , **h** , **l** , Schematic of the interconnection between ITO, HTL and PVSK for PTAA ( **d** ), 4PACz ( **h** ) and 4PADCB ( **l** ). 

extraction, enabling improved _V_ OC and FF in the record-efficiency PVSK–Si TSCs<sup>26</sup> . Since then, SAMs such as Me-[4-(9 _H_ -carbazol-9-yl) butyl]phosphonic acid (Me-4PACz), 2PACz and MeO-2PACz have been widely adopted in efficient PVSK-based TSCs<sup>26–28</sup> . These results indicate that judicious carrier management at the interface of the PVSK and hole-selective layers as well as matched energy band levels enable simultaneous increase in FF and _V_ OC and therefore the performance of large-area single-junction and TSC devices. However, achieving a perfect coverage of the SAM on the transparent conductive oxide (TCO) or the wetting of the PVSK on top can be challenging for some SAMs<sup>26</sup> , for example, 4PACz. Rational molecular design is highly desired to optimize the trade-off between energy level matching, film formation and charge transport and collection abilities to enable new prospects for large-scale WBG PSCs and all-PVSK TSCs. 

Here we designed a SAM—(4-(7 _H_ -dibenzo[ _c,g_ ]carbazol-7-yl)butyl) phosphonic acid (4PADCB)—with improved film coverage and surface wettability by constructing a new terminal group of 7 _H_ -dibenzocarbazole (DCB). These advantages enable fast hole extraction and suppress the interfacial non-radiative recombination. We report an efficiency of 27.0% for the monolithic all-PVSK TSCs (1.044 cm<sup>2</sup> ) and a high certified value (26.4%) for centimetre-scale all-PVSK TSCs<sup>14</sup> . 

##### **Characterizations of HTLs and WBG PVSK** 

The conventional HTL PTAA may not be suitable for scaling up high-performance PVSK devices because of hydrophobicity and poor 

conductivity<sup>25,29</sup> . State-of-the-art SAMs could address these issues to some extent and enhance hole extraction. However, they still suffer from relatively poor solubility in alcohol because of excessive molecular aggregation caused by planar conjugated terminal groups and tend to rapidly precipitate during the volatilization of the solution<sup>26,30,31</sup> . This drawback usually leads to non-uniform coating of the SAM and subsequently the PVSK film, resulting in notable interfacial recombination losses and poor reproducibility<sup>26</sup> . Furthermore, the deficient surface wettability of these SAMs also makes large-scale PVSK deposition challenging. Our previous study has shown that incorporating a partial distortion into the molecular backbone can modulate the self-aggregation of the unfused-ring electron acceptor, which leads to improved solubility and ultimately more homogeneous films<sup>32</sup> . Moreover, the larger conjugation range of the building block is beneficial for enhancing the charge transport capacity of the molecule, especially when it is parallel to the substrate<sup>33</sup> . Taking these ideas into consideration, we introduced two benzene rings into the carbazole group of commercial 4PACz to simultaneously improve the film formation and charge transport and collection of the SAM (Fig. 1e,f). The constructed DCB moiety has a non-coplanar screw-shaped configuration because of the steric repulsive interaction between the terminal aromatic rings, which can hinder molecular aggregation and improve the solubility of the SAM<sup>34</sup> (Supplementary Fig. 1). Moreover, the contorted DCB also possesses more ordered packing in the solid state as shown by the single-crystal data (Supplementary Fig. 2). These properties facilitate more-uniform and more-compact 4PADCB films. The synthesis 

Nature | Vol 618 | 1 June 2023 | **81** 



<!-- Start of picture text -->
Article<br><!-- End of picture text -->



<!-- Start of picture text -->
a b c<br>1,446 cm –1 475 1,480 cm –1 429 1,646 cm –1 196<br>38  42 31<br>d e f<br>1,472 2.5 × 10 4 2.8 × 10 4<br>372 1.2 × 10 4 1.5 × 10 4<br>g h i<br>PTAA4PACz 10 0  PTAA 4PACz 1.4 Bare absorber potential 1.380<br>4PADCB  4PADCB 1.349<br>1.328<br>Glass  Glass<br>1.300<br>10 –1 1.3<br>10 –2 1.2<br>10 –3 1.1<br>600 650 700 750 800 0 500 1,000 1,500 Glass ITO/ ITO/ ITO/<br>Wavelength (nm) Time (ns) PTAA 4PACz 4PADCB<br> WBG PVSK on glass or HTL<br>Fig. 2 | Characterizations of HTLs on ITO and PVSK films deposited on  PTAA ( d ), 4PACz ( e ) and 4PADCB ( f ).  g – i , Steady-state photoluminescence<br>different HTLs. a – c , Photo-induced surface potential mapping at different  spectra ( g ), TRPL decays ( h ) and QFLS (i V OC) values ( i ) of PVSK on glass and<br>wavenumbers for PTAA ( a ), 4PACz ( b ) and 4PADCB ( c ).  d – f , Confocal  varying HTLs. Scale bars, 500 nm ( a – c ) and 10 μm ( d – f ).<br>Counts Counts Counts<br>Counts Counts Counts<br>PL intensity (a.u.) Normalized PL<br>QFLS (eV) or implied  (V) V OC<br><!-- End of picture text -->

**Fig. 2 | Characterizations of HTLs on ITO and PVSK films deposited on different HTLs. a** – **c** , Photo-induced surface potential mapping at different wavenumbers for PTAA ( **a** ), 4PACz ( **b** ) and 4PADCB ( **c** ). **d** – **f** , Confocal photoluminescence (PL) mapping (50 × 50 μm<sup>2</sup> ) of PVSK films deposited on 

of 4PADCB is described in Supplementary Fig. 3 and Supplementary Note 1, with the molecular structure confirmed by nuclear magnetic resonance (NMR) spectroscopy (Supplementary Fig. 4). Supplementary Fig. 5 shows the absorbance spectra of the SAMs, from which we can determine the optical bandgaps for 4PACz and 4PADCB as 3.43 eV and 3.19 eV, respectively. The calculated electrostatic surface potential (ESP) of the HTLs is shown in Fig. 1, in which 4PADCB shows a higher electron density on DCB, especially on the benzene rings near the interface (Fig. 1k). This may enhance the interactions with the upper PVSK to facilitate interfacial charge transport<sup>35</sup> . The dipole moment for PTAA, 4PACz, and 4PADCB is 0.84 D, 1.93 D, and 2.63 D, respectively. The molecular dynamics simulations show that 4PADCB has a dominant orientation of the conjugation backbone parallel to the substrate when deposited on indium tin oxide (ITO), which is beneficial for hole transport from the WBG PVSK to 4PADCB and ITO, whereas 4PACz does not have this feature<sup>33,36</sup> (Supplementary Fig. 6). 

To examine the uniformity of various HTLs deposited on ITO, we conducted photo-induced force microscopy (PiFM) measurements (Fig. 2). The 4PADCB sample shows the smallest amplitude of potential 

change among the three HTLs (Fig. 2a–c), indicating that 4PADCB has a more homogeneous anchoring on ITO than 4PACz because of the special steric hindrance of DCB terminal group (Fig. 1l), whereas PTAA and 4PACz show inhomogeneous potential distribution. We compared the wettability of the three HTLs using contact angle measurements using _N_ , _N_ -dimethylformamide (DMF) solvent. 4PADCB (76.5°) shows a significantly reduced contact angle, compared with PTAA (89.6°) and 4PACz (83.3°) (Supplementary Fig. 7), indicating that the wettability of 4PADCB is improved. These features benefit the uniformity and enable a complete coverage of the SAM and the PVSK film, especially on large areas. 

We further performed confocal photoluminescence mapping with high spatial resolution to examine the uniformity of WBG PVSK deposited on different HTLs on ITO. Enhanced homogeneity of photoluminescence emission has been observed for SAM-based HTLs (Fig. 2d–f), in which the 4PADCB film shows the highest photoluminescence intensity and the narrowest distribution, indicating that both uniformity and optoelectronic quality of WBG PVSK grown on 4PADCB are notably improved. By contrast, the WBG PVSK films grown on these HTLs do not 

**82** | Nature | Vol 618 | 1 June 2023 

show notable morphological and structural changes in the top-view and cross-sectional scanning electron microscopy (SEM) images (Supplementary Fig. 8) and X-ray diffraction patterns (Supplementary Fig. 9). 

To study the improvement of the HTL–PVSK interface directly, we exfoliated the PVSK from the substrate with different HTLs, characterized the morphology with SEM and mapped the photoluminescence of the buried interface (Supplementary Fig. 10). The PTAA-based samples show several clustered pinholes and an inhomogeneous photoluminescence, indicating a considerable non-radiative recombination loss at the buried interface. By contrast, the SAM-based PVSK films show notably improved uniformities as well as enhanced photoluminescence intensity. The 4PADCB film, in particular, shows no pinholes at the buried interface in combination with an enhanced photoluminescence intensity, indicating improved homogeneity of the PVSK on 4PADCB, which contributes to the suppressed interfacial non-radiative recombination. We further examined the charge transfer and recombination kinetics of PVSK films by conducting steady-state photoluminescence and time-resolved photoluminescence (TRPL) measurements using a structure of ITO/HTL/PVSK (Fig. 2g,h, Supplementary Table 1 and Supplementary Fig. 11). The PVSK film on 4PADCB shows a higher photoluminescence intensity and longer _τ_ 2 (441.2 ns) than those on PTAA (38.2 ns) and 4PACz (372 ns), in which the longer _τ_ 2 is probably related to suppressed interfacial non-radiative recombination<sup>37,38</sup> . To quantify the non-radiative recombination losses at the HTL–PVSK interface, we measured the photoluminescence quantum yield (PLQY) to estimate quasi-Fermi level splitting (QFLS) or implied _V_ OC (i _V_ OC)<sup>39</sup> (Supplementary Note 2). Figure 2i and Supplementary Fig. 12 show highly increased PLQY and QFLS values for PVSKs on SAMs compared with those on PTAA. The 4PADCB sample shows the maximum PLQY value of 0.23% and QFLS value of 1.349 eV, consistent with the TRPL results. This suggests that 4PADCB effectively suppresses the interfacial non-radiative recombination loss. 

##### **Performance of WBG PSCs** 

Encouraged by the enhanced film homogeneity and the reduced interfacial recombination by the 4PADCB HTL, we fabricated WBG PSCs with a device structure of glass/ITO/HTL/WBG PVSK/C60/SnO2/Cu, in which the HTL varies between PTAA, 4PACz and 4PADCB. Small-area (around 0.05 cm<sup>2</sup> ) WBG devices with 4PACz and 4PADCB HTLs show a notable improvement in _V_ OC and a much narrower spread in FF and _V_ OC statistics compared with PTAA (Supplementary Fig. 13). When the active area is scaled up to centimetre-scale (around 1 cm<sup>2</sup> ) (Fig. 3a), the 4PADCB devices retain a high _V_ OC of 1.30 V and a high FF of 78.7%, whereas the PTAA and 4PACz devices show a deterioration in FF, which we attributed to the improved homogeneity of PVSK deposited on 4PADCB HTL. The statistics of photovoltaic parameters of large-area PSCs with different HTLs (Supplementary Table 2 and Supplementary Fig. 14) indicate comprehensively improved performance of the SAM-based devices, of which 4PADCB shows the best performance, especially in _V_ OC and FF. 

Because of the ultra-thin SAM layer, the short-circuit current density ( _J_ SC) of 4PACz and 4PADCB devices slightly increases compared with that of PTAA because of the increased spectral response in the range of 350–480 nm in the external quantum efficiency (EQE) spectra (Fig. 3b). As a result, centimetre-scale 1.77-eV WBG PSCs provide the best PCE of 18.46% of the champion device, with a _V_ OC of 1.31 V, an FF of 79.18% and a _J_ SC of 17.80 mA cm<sup>−2</sup> (Fig. 3c). We note that the _V_ OC deficit of 0.46 V with respect to the bandgap (and 0.18 V with respect to the radiative limit) as obtained here is to our knowledge the lowest value reported for WBG (approximately 1.75–1.8 eV) PSCs used in all-PVSK TSCs<sup>40</sup> (Supplementary Table 3 and Supplementary Fig. 15). We then monitored the stability of the devices and the results are shown in Fig. 3c (inset). The 4PADCB device shows better operational stability than the PTAA and 4PACz ones, retaining 90% of its original efficiency after 501 h of continuous operation. 

To elucidate the underlying reasons of the improvements in both efficiency and stability of the large-area WBG PSCs with 4PADCB, we first examined the homogeneity of the complete devices with an active area of 1.27 cm<sup>2</sup> using electroluminescence mapping. As shown in Fig. 3d–f, dark regions were observed in the PTAA device, implying inhomogeneous electroluminescence intensity. This issue has been improved in the 4PACz device but some dark spots could still be observed. By contrast, the 4PADCB device shows the highest overall intensity and the uniform electroluminescence emission intensity across the whole cell area (Supplementary Fig. 16). This result is consistent with our photoluminescence mapping results, indicating significantly suppressed non-radiative recombination at the HTL–PVSK interface, which could account for enhanced _V_ OC and FF as well as improved stability because of less interfacial defects<sup>41</sup> . 

We also used ultraviolet photoelectron spectroscopy (UPS), which revealed an improved interfacial energy alignment of 4PADCB over the other HTLs. To qualitatively understand the impact of the band alignment on the device performance, we performed drift-diffusion simulations (Supplementary Discussion 1, Supplementary Table 4 and Supplementary Figs. 17 and 18), which highlight that the better energy alignment is probably an important factor for the improved performance. 

To investigate the dynamics of charge extraction in the operational cells, we further performed resistance-dependent photovoltage (RPV) measurements, which have been used to study the dynamics of charge extraction in complete devices<sup>29,42</sup> . The transient photovoltage (TPV) signal of 4PADCB samples presents the fastest saturation time (approximately 125 ns) compared with 4PACz (approximately 168 ns) and PTAA (approximately 215 ns) (Fig. 3g), demonstrating the faster hole extraction using the 4PADCB HTL<sup>29</sup> . Moreover, TPV and electrochemical impedance spectroscopy (EIS) results indicate enhanced charge extraction of 4PADCB (Supplementary Discussion 2 and Supplementary Fig. 19). 

To better understand the improved FF with the use of the 4PADCB SAM, we reconstructed the pseudo- _JV_ (p- _JV_ ) curves in the absence of transport losses (Fig. 3h, Supplementary Discussion 3, Supplementary Figs. 20 and 21 and Supplementary Note 2). Comparing these pseudo-FF (p-FF) values with the theoretical maximum FF from the Shockley– Queisser limit<sup>40</sup> , we observed that the solar cells with SAM HTLs showed lower FF losses than those with PTAA because of non-radiative recombination. The differences between p-FF and the FF extracted from _JV_ scans are 8.9%abs and 10.65%abs for 4PADCB and 4PACz devices, respectively (Supplementary Table 5). This suggests that the improved FF in 4PADCB is mainly because of the reduced transport loss compared with 4PACz (Fig. 3i), probably owing to the faster hole extraction as substantiated by the RPV measurement. 

##### **Performance of all-PVSK TSCs** 

To demonstrate the potential of the WBG PSC that we developed, we integrated the optimized WBG PSCs into centimetre-scale monolithic all-PVSK TSCs (Methods). We used a 1.25-eV LBG FA0.6MA0.3 Cs0.1Sn0.5Pb0.5I3 PVSK subcell, which shows a PCE of 21.27%, with a _V_ OC of 0.85 V, an FF of 78.14% and a _J_ SC of 31.58 mA cm<sup>−2</sup> (Supplementary Fig. 22). The monolithic TSC device architecture is glass/ ITO/HTL/WBG PVSK/C60/SnO2/indium zinc oxide (IZO)/poly (3,4-ethylenedioxythiophene) polystyrene sulphonate (PEDOT:PSS)/ LBG PVSK/C60/SnO2/Cu, where SnO2/IZO/PEDOT:PSS works as a robust interconnection layer (ICL) (Fig. 4a). 

Figure 4b shows the _JV_ curves of TSCs with varying HTLs, showing little difference in _J_ SC. However, notable improvements in both _V_ OC and FF are observed for SAM-based TSCs—that is, the 4PADCB TSC delivers an improved _V_ OC of 2.09 V and an FF of 82.20%. As a result, a large-area efficiency of 27.01% (26.82%) was achieved for our best-performing all-PVSK TSC under reverse (forward) scan (Fig. 4c), with a high _V_ OC 

Nature | Vol 618 | 1 June 2023 | **83** 

### Article 



<!-- Start of picture text -->
a b c<br>Forward PCE = 18.34%<br>20 100 20 Reverse PCE = 18.46%<br>15 PTAA 80 15<br>4PACz 1.2<br>4PADCB 60 1.0<br>10 10 0.8<br>V OC FF J SC PCE 40 0.6<br>(V) (%) (mA cm –2 ) (%) 0.4  PTAA  T 90 = 26 h<br>5 PTAA4PACz 1.201.26 74.7675.49 17.5117.80 15.7116.93 20 PTAA4PACz 17.37 mA cm17.13 mA cm –2–2 5 0.20  4PACz  4PADCB  TT 90 90 = 147 h= 501 h<br>4PADCB 1.30 78.70 17.84 18.28 4PADCB  17.38 mA cm –2 0 100 200 300 400 500 600<br>0 0 0 Time (h)<br>0 0.2 0.4 0.6 0.8 1.0 1.2 300 400 500 600 700 0 0.2 0.4 0.6 0.8 1.0 1.2 1.4<br>Voltage (V) Wavelength (nm) Voltage (V)<br>d 1 e 1 f 1<br>0 0 0<br>g Carrier arrival at electrodes h i<br>1.0<br>15 90 Non-radiative recombination loss<br>0.8<br>85<br>10<br>0.6<br>Transport loss<br>0.4 80<br>5 p- JV  bare absorber<br> PTAA p- JV  PVSK/C60<br>0.2  4PACz p-p- JVJV  PTAA complete device 4PACz complete device 75  SQ limit p-FF (complete stack)<br> 4PADCB 0 p- JV  4PADCB complete device  Real cell FF<br>0<br>10 –8 10 –7 10 –6 10 –5 10 –4 0.6 0.8 1.0 1.2 1.4 PTAA 4PACz 4PADCB<br>Time (s) Voltage (V)<br>HTL losses<br>ETL losses<br>EQE (%)<br>Normalized PCE<br>–2Current density (mA cm) –2Current density (mA cm)<br>FF (%)<br>Normalized voltage (V) –2)Current density (mA cm<br><!-- End of picture text -->

**Fig. 3 | Photovoltaic performance and characterizations of complete WBG devices with different HTLs. a** , **b** , _JV_ curves ( **a** ) and EQE ( **b** ) of WBG PSCs with PTAA, 4PACz and 4PADCB with an aperture area of 1.044 cm<sup>2</sup> . **c** , _JV_ curve of the best-performing WBG device with 4PADCB. Inset, steady-state efficiency by tracking MPP. **d** – **f** , Electroluminescence mapping for complete WBG devices with PTAA ( **d** ), 4PACz ( **e** ) and 4PADCB ( **f** ). **g** , Resistance-dependent photovoltage (RPV) transient signals measured on large-area WBG PSCs with different HTLs. 

The saturation of the transients shows that all photogenerated charges have reached the contacts. **h** , p- _JV_ curves on the basis of bare PVSK absorber, PVSK with C60 and PSCs with different HTLs as obtained from intensity-dependent PLQY and QFLS measurements. **i** , Schematic of FF loss mechanisms. The Shockley–Queisser limit is obtained from the radiative efficiency limit, whereas p-FF and real-cell FF are obtained experimentally. Scale bar = 0.5 cm. 

of 2.11 V (2.11 V), an FF of 83.13% (82.31%) and a _J_ SC of 15.37 mA cm<sup>−2</sup> (15.46 mA cm<sup>−2</sup> ). A photo of the large-area TSC cell is shown in Fig. 4d (inset). The EQE-integrated _J_ SC values for WBG and LBG subcells measured from a TSC device are 15.31 mA cm<sup>−2</sup> and 14.94 mA cm<sup>−2</sup> , respectively (Fig. 4d). The _V_ OC of 2.11 V and FF of around 83% represent notable enhancements over previously reported values among the best all-PVSK TSCs with a 1-cm<sup>2</sup> area. We fabricated more than 80 4PADCB-based TSCs; a histogram of PCE values is shown in Supplementary Fig. 23. The devices show an average PCE of 25.70 ± 0.75%, demonstrating the high reproducibility of 4PADCB-based TSCs. 

We sent a TSC device with 4PADCB to the Japan Electrical Safety and Environment Technology Laboratories for an independent accredited certification. The device shows a certified PCE of 26.6% with a _V_ OC of 2.12 V and FF of 82.6% and a stabilized PCE of 26.4% after 300 s maximum power point (MPP) tracking (Supplementary Fig. 24). The certified stabilized efficiency of 26.4% has been included in the latest version of Solar Cell Efficiency Tables (v.60)<sup>14</sup> . This stabilized efficiency is greater than all certified PCEs for single-junction PSCs and all-PVSK TSCs with 

a centimetre-scale area reported until now, and the PCE of 25.7% of small-area single-junction PSC (Fig. 4e and Supplementary Table 6). 

We also performed MPP tracking of encapsulated TSCs with different HTLs in ambient air (Fig. 4f). The 4PADCB TSC maintained 80% of its initial efficiency after 415 h of continuous operation under 1 sun illumination at the MPP, whereas the PTAA and 4PACz TSC devices had much shorter lifetimes. This suggests that 4PADCB as HTL enhances the operational stability of large-area all-PVSK TSCs. We attribute this to the improved homogeneity and suppressed non-radiative interfacial losses. Fast hysteresis measurements on slightly aged devices (Supplementary Fig. 25) further show a much smaller impact of mobile ions on the PCE and FF in the 4PADCB-based WBG devices compared with 4PACz because of the improved interface, thereby minimizing ion-induced performance losses, for example, upon ageing or degradation<sup>43</sup> . To achieve longer operational stability, strategies such as reducing the methylamine content and preventing the oxidation of LBG PSCs, suppressing the phase segregation in WBG PSCs and advanced encapsulation technology will be pursued in the future. 

**84** | Nature | Vol 618 | 1 June 2023 



<!-- Start of picture text -->
a b c<br>15 15<br>PTAA Forward, PCE = 26.82%<br>4PACz Reverse, PCE = 27.01%<br>4PADCB<br>10 10<br>LBG PVSK<br>V OC FF J SC PCE<br>(V) (%) (mA cm –2 ) (%)<br>C60/SnO2/IZO/PEDOT:PSS 5 PTAA 2.00 77.91 15.25 23.76 5<br>WBG PVSK  4PACz 2.06 79.29 15.34 25.06<br>4PADCB 2.09 82.20 15.41 26.47<br>0 0<br>0 0.5 1.0 1.5 2.0 0 0.5 1.0 1.5 2.0<br>d WBG subcell LBG subcell 1-R f Voltage (V) Voltage (V)<br>100<br>1.0<br>80<br>0.8<br>60<br>0.6<br>Integrated  J SC Integrated  J SC<br>40 15.31 mA cm –2 14.94 mA cm –2 0.4<br>PTAA        T 80 = 55 h<br>20 0.2 4PACz T 80 = 252 h<br>4PADCB T 80 = 415 h<br>0 0<br>400 600 800 1,000 0 50 100 150 200 250 300 350 400 450 500<br>Wavelength (nm)<br>e g Time (h)<br>26 All-perovskite TSCs This work26.4% 15<br>24 24.2%<br>Single-junction PSCs 23.7%<br>10<br>22 22.6%<br>21.6%<br>20 20.9%  4PADCB<br>19.7%  5 Bare<br>18 LBG p- JV<br>WBG p- JV<br>16 Tandem p- JV<br>15.6%<br>0<br>2014 2016 2018 2020 2022 0 0.5 1.0 1.5 2.0<br>Year Voltage (V)<br>–2Current density (mA cm) –2Current density (mA cm)<br>EQE (%)<br>Normalized PCE<br>PCE (%)<br>–2Current density (mA cm)<br><!-- End of picture text -->

**Fig. 4 | Photovoltaic performance and characterizations of complete allPVSK TSCs with different HTLs. a** , Cross-sectional SEM image of an all-PVSK TSC. **b,** _JV_ curves of TSCs with different HTLs with an aperture area of 1.044 cm<sup>2</sup> under forward voltage scan. **c,** _JV_ curve of the best-performing TSC device (1.044 cm<sup>2</sup> ). Inset, a large-area TSC. **d** , EQE spectra and reflectance spectrum of the best-performing TSC device with 4PADCB. **e** , Summary of the reported, independently certified PCEs of centimetre-scale single-junction PSCs and 

all-PVSK TSCs. **f** , Continuous MPP tracking of encapsulated TSC devices with different HTLs. **g** , p _-JV_ curves of an 4PADCB-based TSC, including the individual WBG and LBG subcells, derived from their selectively measured intensitydependent PLQY. Solid lines show a comparison with bare WBG and LBG absorbers reaching an efficiency, _V_ OC and an FF potential of about 30%, 2.27 V and 86.07%, respectively. Scale bar, 500 nm. 

##### **Subcell analysis in all-PVSK TSCs** 

To gain insight into the limitations and practical efficiency potential of our all-PVSK TSCs based on the actual optoelectronic quality of the absorbers, we performed a detailed PLQY analysis on individual PVSK cells deposited on glass and PVSK subcells in monolithic TSC devices. Similar QFLS (i _V_ OC) results were obtained for the WBG subcell in a full TSC stack and the single-junction WBG device, suggesting no extra losses—for example, owing to the recombination layer—when integrating these WBG subcells into monolithic TSCs (Supplementary Fig. 26a). The LBG PVSK subcells in the TSC stack exhibit an almost identical QFLS (i _V_ OC) to the corresponding single junction. Overall this confirms that the _V_ OC improvement in monolithic TSC devices is mainly because of the improved WBG PVSK subcells (Supplementary Fig. 26b). 

The p- _JV_ curves of the WBG subcell, LBG subcell and TSCs drawn on the basis of the bare absorber and complete device stack (Fig. 4g and 

Supplementary Fig. 27) show that a PCE of about 30% can be achieved with an i _V_ OC of 2.27 V and a p-FF of 86.07%, indicating a promising future for our PVSK absorber composition. To achieve this, TSC-cell FF limitations because of insufficient charge transport in the absorber and the transport layers as well as _V_ OC limitations because of interfacial recombination need to be solved. The 4PADCB-incorporated TSC device delivers the highest i _V_ OC of 2.09 V and a p-FF of 84.21%, yielding a p-PCE of 26.90%, which has been essentially achieved in our best TSCs (Supplementary Table 7), which implies small transport losses in the full-TSC cell stack. Despite this achievement, a lot more needs to be done to further improve the efficiency of our large-area TSCs. Comparing the QFLS (i _V_ OC) values of bare PVSK, PVSK/C60 and HTL/PVSK/ C60 for cm<sup>2</sup> -sized films, we found that the C60 ETL used in our devices with 4PADCB notably reduces the QFLS and thus i _V_ OC from 1.380 V for the bare PVSK to 1.306 V for PVSK/C60 and 1.325 V for 4PADCB/PVSK/ C60 (Supplementary Fig. 28) although the use of 4PADCB improves the 

Nature | Vol 618 | 1 June 2023 | **85** 

### Article 

QFLS (i _V_ OC) by 19 mV. Thus, future research should focus on managing the energy alignment and recombination losses at the PVSK–C60 interface. Moreover, the _J_ SC of the TSC can be further improved using optical management such as coating an antireflection film on the glass side of the device, reducing the thickness of the TCO ICL to decrease the parasitic absorption, slightly reducing the bandgap of WBG PVSK absorber and increasing the thickness of LBG PVSK absorber. Furthermore, substrate texturing for near-infrared light trapping can be exploited to increase the optical path length instead of the LBG absorber thickness. Combining these optical management strategies (for the highest _J_ SC) with minimized interfacial recombination (for the highest _V_ OC) and minimized transport losses (for the highest FF) (see p- _JV_ analysis and discussion in this paragraph), an efficiency potential almost 32.8% is shown (Supplementary Fig. 29). This might enable the realization of large-area all-PVSK TSCs and even modules with an efficiency of ≥30% in future. 

##### **Online content** 

Any methods, additional references, Nature Portfolio reporting summaries, source data, extended data, supplementary information, acknowledgements, peer review information; details of author contributions and competing interests; and statements of data and code availability are available at https://doi.org/10.1038/s41586-023-05992-y. 

1. Eperon, G. E., Hörantner, M. T. & Snaith, H. J. Metal halide perovskite tandem and multiple-junction photovoltaics. _Nat. Rev. Chem._ **1** , 0095 (2017). 

2. Rajagopal, A. et al. Highly efficient perovskite–perovskite tandem solar cells reaching 80% of the theoretical limit in photovoltage. _Adv. Mater._ **29** , 1702140 (2017). 

3. Leijtens, T., Bush, K. A., Prasanna, R. & McGehee, M. D. Opportunities and challenges for tandem solar cells using metal halide perovskite semiconductors. _Nat. Energy_ **3** , 828–838 (2018). 

4. Forgács, D. et al. Efficient monolithic perovskite/perovskite tandem solar cells. _Adv. Energy Mater._ **7** , 1602121 (2017). 

5. Tong, J. et al. Carrier lifetimes of >1 μs in Sn-Pb perovskites enable efficient all-perovskite tandem solar cells. _Science_ **364** , 475–479 (2019). 

6. Zhao, D. et al. Efficient two-terminal all-perovskite tandem solar cells enabled by highquality low-bandgap absorber layers. _Nat. Energy_ **3** , 1093–1100 (2018). 

7. Lin, R. et al. All-perovskite tandem solar cells with improved grain surface passivation. _Nature_ **603** , 73–78 (2022). 

8. Thiesbrummel, J. et al. Understanding and minimizing _V_ OC losses in all-perovskite tandem photovoltaics. _Adv. Energy Mater._ **13** , 2202674 (2022). 

9. Eperon, G. E. et al. Perovskite-perovskite tandem photovoltaics with optimized band gaps. _Science_ **354** , 861–865 (2016). 

10. Jiang, F. et al. A two-terminal perovskite/perovskite tandem solar cell. _J. Mater. Chem. A_ **4** , 1208–1213 (2016). 

11. He, R. et al. Wide-bandgap organic-inorganic hybrid and all-inorganic perovskite solar cells and their application in all-perovskite tandem solar cells. _Energy Environ. Sci._ **14** , 5723–5759 (2021). 

12. Shockley, W. & Queisser, H. J. Detailed balance limit of efficiency of _p_ - _n_ junction solar cells. _J. Appl. Phys._ **32** , 510–519 (1961). 

13. Zhao, D. & Ding, L. All-perovskite tandem structures shed light on thin-film photovoltaics. _Sci. Bull._ **65** , 1144–1146 (2020). 

14. Green, M. A. et al. Solar cell efficiency tables (version 60). _Prog. Photovolt._ **30** , 687–701 (2022). 

15. Brinkmann, K. O. et al. Perovskite–organic tandem solar cells with indium oxide interconnect. _Nature_ **604** , 280–286 (2022). 

16. Mahesh, S. et al. Revealing the origin of voltage loss in mixed-halide perovskite solar cells. _Energy Environ. Sci._ **13** , 258–267 (2020). 

17. Tan, H. et al. Dipolar cations confer defect tolerance in wide-bandgap metal halide perovskites. _Nat. Commun._ **9** , 3100 (2018). 

18. McMeekin, D. P. et al. A mixed-cation lead mixed-halide perovskite absorber for tandem solar cells. _Science_ **351** , 151–155 (2016). 

19. Fu, F. et al. High-efficiency inverted semi-transparent planar perovskite solar cells in substrate configuration. _Nat. Energy_ **2** , 16190 (2016). 

20. Liu, Y., Dong, B., Hagfeldt, A., Luo, J. & Graetzel, M. Chemically tailored molecular surface modifiers for efficient and stable perovskite photovoltaics. _SmartMat_ **2** , 33–37 (2021). 

21. Yu, Z. et al. Simplified interconnection structure based on C60/SnO2- _x_ for all-perovskite tandem solar cells. _Nat. Energy_ **5** , 657–665 (2020). 

22. Li, C. et al. Low-bandgap mixed tin–lead iodide perovskites with reduced methylammonium for simultaneous enhancement of solar cell efficiency and stability. _Nat. Energy_ **5** , 768–776 (2020). 

23. Xiao, K. et al. All-perovskite tandem solar cells with 24.2% certified efficiency and area over 1 cm<sup>2</sup> using surface-anchoring zwitterionic antioxidant. _Nat. Energy_ **5** , 870–880 (2020). 

24. Bi, C., Yuan, Y., Fang, Y. & Huang, J. Low-temperature fabrication of efficient wide-bandgap organolead trihalide perovskite solar cells. _Adv. Energy Mater._ **5** , 1401616 (2015). 

25. Hu, M., Bi, C., Yuan, Y., Bai, Y. & Huang, J. Stabilized wide bandgap MAPbBr _x_ I3- _x_ perovskite by enhanced grain size and improved crystallinity. _Adv. Sci._ **3** , 1500301 (2016). 

26. Al-Ashouri, A. et al. Monolithic perovskite/silicon tandem solar cell with >29% efficiency by enhanced hole extraction. _Science_ **370** , 1300–1309 (2020). 

27. Li, L. et al. Flexible all-perovskite tandem solar cells approaching 25% efficiency with molecule-bridged hole-selective contact. _Nat. Energy_ **7** , 708–717 (2022). 

28. Lai, H. et al. High-performance flexible all-perovskite tandem solar cells with reduced VOC-deficit in wide-bandgap subcell. _Adv. Energy Mater._ **12** , 2202438 (2022). 

29. Stolterfoht, M. et al. Approaching the fill factor Shockley–Queisser limit in stable, dopant-free triple cation perovskite solar cells. _Energy Environ. Sci._ **10** , 1530–1539 (2017). 

30. Ullah, A. et al. Novel phenothiazine-based self-assembled monolayer as a hole selective contact for highly efficient and stable p-i-n perovskite solar cells. _Adv. Energy Mater._ **12** , 2103175 (2022). 

31. Kapil, G. et al. Tin–lead perovskite solar cells fabricated on hole selective monolayers. _ACS Energy Lett._ **7** , 966–974 (2022). 

32. Du, F. et al. An unfused-ring acceptor with high side-chain economy enabling 11.17% as-cast organic solar cells. _Mater. Horiz._ **8** , 1008–1016 (2021). 

33. Zhao, S. et al. Cross-plane transport in a single-molecule two-dimensional van der Waals heterojunction. _Sci. Adv._ **6** , eaba6714 (2020). 

34. Wang, J. et al. Aza[5]helicene rivals _N_ -annulated perylene as π-linker of D−π−D typed hole-transporters for perovskite solar cells. _Adv. Funct. Mater._ **30** , 2002114 (2020). 

35. Chen, B., Rudd, P. N., Yang, S., Yuan, Y. & Huang, J. Imperfections and their passivation in halide perovskite solar cells. _Chem. Soc. Rev._ **48** , 3842–3867 (2019). 

36. Lin, H.-C. et al. Influence of molecular orientation on charge-transfer processes at phthalocyanine/metal oxide interfaces and relationship to organic photovoltaic performance. _J. Phys. Chem. C_ **119** , 10304–10313 (2015). 

37. Levine, I. et al. Charge transfer rates and electron trapping at buried interfaces of perovskite solar cells. _Joule_ **5** , 2915–2933 (2021). 

38. Stolterfoht, M. et al. Visualization and suppression of interfacial recombination for high-efficiency large-area pin perovskite solar cells. _Nat. Energy_ **3** , 847–854 (2018). 

39. Caprioglio, P. et al. On the relation between the open-circuit voltage and quasi‐fermi level splitting in efficient perovskite solar cells. _Adv. Energy Mater._ **9** , 1901631 (2019). 

40. Nayak, P. K., Mahesh, S., Snaith, H. J. & Cahen, D. Photovoltaic solar cell technologies: analysing the state of the art. _Nat. Rev. Mater._ **4** , 269–285 (2019). 

41. Jiang, Y. et al. Mitigation of vacuum and illumination-induced degradation in perovskite solar cells by structure engineering. _Joule_ **4** , 1087–1103 (2020). 

42. Philippa, B. et al. The impact of hot charge carrier mobility on photocurrent losses in polymer-based solar cells. _Sci. Rep._ **4** , 5695 (2014). 

43. Le Corre, V. M. et al. Quantification of efficiency losses due to mobile ions in perovskite solar cells via fast hysteresis measurements. _Sol. RRL_ **6** , 2100772 (2022). 

**Publisher’s note** Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law. 

© The Author(s), under exclusive licence to Springer Nature Limited 2023 

**86** | Nature | Vol 618 | 1 June 2023 

#### **Methods** 

###### **Materials** 

DMF, DMSO, chlorobenzene, isopropanol (IPA), SnI2, SnF2 and Pb(SCN)2 were purchased from Sigma-Aldrich. Diethyl ether was purchased from Chengdu Chron Chemical. PbI2, 4PAC and PbBr2 were purchased from TCI. Formamidinium iodide (FAI) and methylammonium iodide were purchased from Greatcell Solar Materials. CsI was purchased from Alfa Aesar. PTAA was purchased from Xi’an Polymer Light Technology. PEDOT:PSS (CLEVIOS P VP AI 4083) was purchased from Heraeus. Tetrakis(dimethylamino)tin(IV) (99.9999%) for atomic-layer-deposited (ALD) SnO2 was bought from Nanjing Ai Mou Yuan Scientific Equipment. The 2-inch (0.0508 m)  indium zinc oxide (IZO) ceramic target was purchased from Shijiazhuang Huake Chemical. C60 was purchased from Nano-C. Cu was purchased from ZhongNuo Advanced Material (Beijing) Technology Co., Ltd. The synthesis of 4PADCB is described in the synthesis section of Supplementary Note 1 and the synthesis of 2-thiopheneethylammonium chloride has been reported in a previous work<sup>44</sup> . 

###### **PVSK precursor preparation** 

**WBG PVSK FA0.8Cs0.2Pb(I0.6Br0.4)3.** The precursor was prepared by dissolving 0.96 mmol FAI, 0.24 mmol CsI, 0.48 mmol PbI2, 0.72 mmol PbBr2 and 0.015 mmol Pb(SCN)2 in 1 ml DMF:DMSO (3:1/v:v) and stirred at 60 °C overnight. 

**LBG PVSK FA0.6MA0.3Cs0.1Sn0.5Pb0.5I3.** The precursor was prepared by mixing 0.18 mmol CsI, 1.08 mmol FAI, 0.54 mmol methylamine iodide, 0.90 mmol SnI2, 0.90 mmol PbI2, 0.09 mmol SnF2, 0.036 mmol NH4SCN and 0.036 mmol of glycine hydrochloride in mixed solvents of 250 μl DMSO and 750 μl DMF and stirred at 60 °C overnight. 

###### **Device fabrication** 

**LBG PSCs.** Glass substrates coated with pre-patterned ITO (10 Ω per square) were ultrasonically cleaned consecutively with detergent, deionized water and ethanol for 15 min. The ITO glass substrates were dried with nitrogen flow and a treatment with ozone generated by UV light for 15 min was done before the deposition of HTL. PEDOT:PSS films were coated on the cleaned ITO substrate at 4,000 rpm for 50 s and then dried at 150 °C for 45 min. The LBG PVSK precursor was spin-coated onto ITO/PEDOT:PSS at 1,000 rpm for 10 s with an acceleration of 200 rpm s<sup>−1</sup> in the first step and at 4,000 rpm for 40 s with an acceleration of 1,000 rpm s<sup>−1</sup> . Then, 400 μl chlorobenzene was dripped onto the surface of the spinning substrate during the second spin coating step. All PVSK films were annealed at on a 100 °C hotplate for 10 min. Next, the PVSK thin films were transferred into a vacuum chamber for thermal evaporation and 20 nm C60 was evaporated at a vacuum of 5 × 10<sup>−4</sup> Pa. Then, the samples were transferred to the ALD chamber to deposit 20 nm SnO2. Finally, 100 nm Cu was thermally evaporated as an electrode. The area of solar cells is defined by the overlap of the metal electrode and patterned ITO. 

**WBG PSCs and TSCs.** PTAA dissolved in chlorobenzene (2 mg ml<sup>−1</sup> ) was spin-coated onto the ITO substrate at 4,000 rpm for 30 s, followed by annealing at 100 °C for 10 min. For the SAM HTLs, 4PACz and 4PADCB dissolved in ethanol (0.5 mg ml<sup>−1</sup> ) were filtered before the deposition and then 80 μl of the solution was dropped onto the ITO substrate and spin-coated at 3,000 rpm for 30 s, followed by annealing at 100 °C for 10 min. Then 70 μl precursor was dropped on HTLs and quickly spin-coated through a two-step process—that is, 500 rpm for 2 s and 4,000 rpm for 60 s—and the antisolvent of 700 μl diethyl ether was dripped at 25 s of the second step. Then the as-prepared PVSK film was annealed at 60 °C for 2 min and 100 °C for 10 min. For post-treatment passivation, 2-thiopheneethylammonium chloride dissolved in IPA (2 mg ml<sup>−1</sup> ) was spin-coated onto the PVSK surface at 3,000 rpm for 

30 s after the as-prepared PVSK films were cooled down to room temperature, followed by annealing at 100 °C for 5 min. For single-junction WBG PSCs, all the samples were transferred to the evaporation chamber and the same processes were done as for LBG PSCs. 

For the TSCs, 100 nm IZO was sputtered at 70 W power under an Ar pressure of 0.3 Pa after ALD-SnO2 deposition. PEDOT:PSS diluted with IPA (volume ratio 1:1) was spin-coated onto the sputtered IZO layer, followed by annealing for 5 min on a 100 °C hotplate. Then, the film was transferred to a glovebox for the fabrication of an LBG subcell as described above. 

**Characterization of HTLs.** The<sup>1</sup> H NMR and<sup>13</sup> C NMR spectra were measured using a Bruker Avance 500 MHz spectrometer with deuterated chloroform (CDCl3) or dimethyl sulphoxide (DMSO-d6) as the solvent and trimethylsilane as the internal reference. Mass spectra were measured using gas chromatography-mass spectrometry (GC-MS) via electron ionization (EI) and a Bruker Daltonics Biflex III matrix-assisted laser desorption/ionization time-of-flight (MALDI-TOF) analyser in the MALDI mode. Absorption spectra were taken on a UV–visible light (UV–vis) instrument Evolution 220 (Thermo Fisher). 

The VMD software was used to map the molecular surface electrostatic potential. The electron density level of the van der Waals (vdW) surface was defined as 0.001 e Bohr<sup>−3</sup> , and all molecular size information was calculated by Multiwfn. 

**Simulation details and methodology.** Molecular dynamics simulations were carried out to investigate the microstructures of 4PACz and 4PADCB near the confined ITO substrate at the atomic level. The initial configuration systems were constructed using the PACKMOL software<sup>45</sup> . After the confined systems were tentatively constructed, 6 nm vacuum above and below the solid substrates were added to the simulation box in the _z_ dimension, which was sufficiently long to remove any artefacts caused by periodicity. The substrates were set as rigid to ensure that the atoms of the ITO were fixed during the simulation. The OPLS-AA force field was used to describe the behaviour of the SAMs<sup>46,47</sup> . The ITO potential parameters were obtained from a previous study<sup>47</sup> . The molecular force field consisted of non-bonded and bonded interactions. The non-bonded interaction contains vdW and electrostatic interactions, which is described by equations (1) and (2), respectively. 



<!-- Start of picture text -->
ELJ ( rij ) = 4 εij  εrijij 12 −  εrijij 6 (1)<br> <br><!-- End of picture text -->



<!-- Start of picture text -->
qqi j<br>Ec ( rij ) = 4 πεoεrrij (2)<br><!-- End of picture text -->

For different kinds of atom, the Lorentz–Berthelot mix rules were adopted for vdW interactions, which follows equation (3). The cutoff distance of vdW and electronic interactions was set to 1.2 nm, and the particle mesh Ewald method was used to calculate long-range electrostatic interactions. 



<!-- Start of picture text -->
σij = 2 1 ( σii + σjj ); εij = ( εii * εjj )1/2 (3)<br><!-- End of picture text -->

For the simulation, an energy minimization was first used to relax the simulation box. Then, a canonical (NVT) ensemble with a 1.0-fs time step was used to optimize the simulation box, in which the temperature was set to 298.15 K. The temperature was maintained using a Nosé–Hoover thermostat. The optimization time was set to 10.0 ns, which was long enough to obtain a stable system. Following the optimization simulation, another canonical (NVT) ensemble with 2.0 ns was used to further investigate the behaviour of soft molecules. In all molecular dynamics simulations, the motion of atoms was described 

### Article 

by conventional Newton’s equation, which was solved using the velocity-Verlet algorithm. All simulations were performed using the Lammps 2022.3 package<sup>48</sup> and the results are shown in Supplementary Fig. 6. 4PACz and 4PADCB show a similar angle of about 50° between phosphorus (P)–nitrogen (N) and _z_ axis, but they show large differences in plane angles. The domination of the plane angle of 4PADCB is about 110°, which means the DCB moiety in 4PADCB is almost parallel to ITO. However, 4PACz shows no obvious dominant orientation. This could be one of the reasons why the charge transfer ability of 4PADCB is better. Therefore, because of the complex nature of the inter- and intra-molecular interactions, the used force fields in our molecular dynamics simulations will only approximate the reality. However, they qualitatively illustrate the difference between the two SAMs and draw the attention of material chemists and designers to the importance of molecular orientation. 

**Details of the PVSK exfoliation.** The details of the PVSK exfoliation from the substrates can be found in a previous publication<sup>49</sup> . Specifically, PMMA (Sigma-Aldrich) layer was deposited on the PVSK film by blade-coating the PMMA solution (0.4 g ml<sup>−1</sup> in chlorobenzene). An epoxy layer was then blade-coated on top of the PMMA film by using an epoxy precursor composed of diglycidyl ether bisphenol A type (Sigma-Aldrich), _n_ -octylamine (Sigma-Aldrich) and _m_ -xylylenediamine (Sigma-Aldrich) with a molar ratio of 4:2:1. The coated substrate was annealed at 70 °C for 10 min. After 12 h, the epoxy layer was completely solidified at room temperature. Finally, the PVSK film was exfoliated from the glass/ITO substrate by a glass nipping plier. The micromorphology of the bottom PVSK surface was characterized by SEM (SU-70, Hitachi Nake High-Tech). Photoluminescence mapping measurements (at 700 nm) were conducted by the instrument Vis–NIR–XU (Nanophoton) with excitation at 532 nm. 

###### **Characterizations of films and devices** 

**Absolute photoluminescence measurements.** For single-junction WBG and subcells in TSCs, absolute photoluminescence measurements were made by selective excitation using a 520-nm continuous-wave laser (for WBG single junctions and WBG subcells in TSC) or a 808-nm continuous-wave laser (for LBG PVSK subcells), which were coupled through an optical fibre into an integrating sphere. Both laser intensities were set to an intensity equivalent to 1 sun, matching the current density generated in each single-junction device or TSC subcell. For intensity-dependence measurements, the intensity was varied between 2 and 0.001 sun using a grey filter wheel. The photoluminescence was then detected using a second optical fibre that coupled the output of the integrating sphere to an Andor SR393i-B spectrometer equipped with an Andor iDus silicon CCD camera, spectrally calibrated using a calibrated halogen lamp. The accuracy of the derived PLQY values was within 5% corroborated by measuring three fluorescent test samples with high specified PLQY (approximately 70%) supplied by Hamamatsu Photonics. 

**Electroluminescence imaging.** For electroluminescence measurements, we injected a current equal to the generation current under 1 sun illumination ( _J_ inj = _J_ gen = _J_ SC) into the cell. Electroluminescence images were then recorded using a scientific CCD camera (Hamamatsu Orca) with a variable zoom microscope. 

**Resistance-dependent photovoltage.** Resistant-dependent photovoltage measurements were obtained for WBG cells with different HTLs by applying a short (5-ns) laser pulse (532 nm wavelength) to the device with a 5-Hz repetition rate, after which the transient photo voltage was recorded across a large (1-MΩ) resistance. This large resistance is used to create a large resistance-capacitance (RC) time, which enables visualization of the transit time of the carriers through the device. In this experiment, the transient photovoltage is recorded across a large load resistance using an oscilloscope (1 MΩ). In this case, the transient corresponds to the motion of photogenerated charge to the electrodes whereas the saturation marks the extraction of the charges. The measurements were repeated for different laser fluences to check whether the observed trends in carrier transit times changed with changing carrier concentrations. 

**Fast-hysteresis measurements.** Fast _JV_ measurements were obtained by applying a triangular voltage pulse to the cells being tested starting from an approximately open circuit to 0 V and back to open-circuit voltage. The scan speed time was thereby varied over many orders of magnitude and the voltage response of the cell was measured with an Agilent DSO9054H High-Definition Oscilloscope, using an external load resistance of 10 Ω. The voltage pulse was supplied by an Agilent 33220A function generator in combination with a custombuilt amplifier (4×). 

**Other characterizations.** WBG PVSKs deposited on various HTLs were characterized by X-ray diffraction (Bruker D2 Phaser) with Cu-Kα ( _λ_ = 0.154 nm) radiation at 30 kV and 10 mA excitation. SEM images were taken with field emission scanning electron microscopy (Regulus-8230, Hitachi). Absorbance spectra of PVSK films were measured using UV–vis spectrophotometer (LAMBDA 950, PerkinElmer). PiFM was characterized by Vista Scope (Molecular Vista) illuminated by a quantum cascade laser with a wavenumber in the range of 770–1,800 cm<sup>−1</sup> . The potential distribution of different substrates was obtained by the infrared absorption of the characteristic peak of the materials. Photoluminescence and TRPL were performed by FLS980 (Edinburgh). Photoluminescence was measured using a 532-nm Xeon lamp with a monochromator and TRPL was measured using a supercontinuum pulsed laser (Wuhan Yangtze Soton Laser) with a wavelength of 532 nm. Confocal photoluminescence mapping was done using a Raman atomic force system (Alpha300RA, Witec) under a 532-nm diode laser in continuous-wave mode. UPS measurements were taken using a photoelectron spectrometer (ESCALAB 250Xi, Thermo Fisher Scientific). According to Einstein’s photo-emission law and calculating from the formula _E_ F = _hν_ − _E_ cutoff, where _hν_ is the photon energy (21.22 eV here) and _E_ cutoff is the secondary electron cutoff edge. 

_JV_ curves were measured using Keysight B2901A source metre under AM1.5G (100 mW cm<sup>−2</sup> ) illumination using a solar simulator (Enlitech, SS-F5) in a N2-filled glovebox. The light source is calibrated by a reference silicon solar cell. All _JV_ measurements were performed using an aperture area of 0.0576 cm<sup>2</sup> for devices with a small active area and 1.044 cm<sup>2</sup> for devices with a centimetre-scale active area. Unless otherwise stated, the _JV_ curves were measured at a scanning rate of 130 mV s<sup>−1</sup> (with voltage steps of 10 mV and a delay time of 80 ms). The spectral response was recorded by a solar-cell quantum efficiency measurement system (QE-R, Enlitech). For TSCs, the bias illumination from a 150 W halogen lamp with optical filters of 850 nm and 550 nm was employed to measure the spectral response of the WBG and LBG subcells, respectively. No bias voltage was applied during the EQE measurements of the TSCs. TPV and EIS were measured by an all-in-one characterization system (PAIOS, FLUXiM). The MPP tracking was done using a multicolour LED solar simulator (Guangzhou Crysco Equipment) equivalent to AM1.5G, 100 mW cm<sup>−2</sup> . 

##### **Reporting summary** 

Further information on research design is available in the Nature Portfolio Reporting Summary linked to this article. 

##### **Data availability** 

All data are available in the paper or Supplementary Information. The data that support the findings of this study are available from the corresponding authors on reasonable request. 

##### **Code availability** 

The codes that support the findings of this study are available from the corresponding authors on reasonable request. 

44. Chen, C. et al. Interfacial engineering of a thiophene-based 2D/3D perovskite heterojunction for efficient and stable inverted wide-bandgap perovskite solar cells. _Nano Energy_ **90** , 106608 (2021). 

45. Martínez, L., Andrade, R., Birgin, E. G. & Martínez, J. M. PACKMOL: a package for building initial configurations for molecular dynamics simulations. _J. Comput. Chem._ **30** , 2157–2164 (2009). 

46. Jorgensen, W. L., Maxwell, D. S. & Tirado-Rives, J. Development and testing of the OPLS all-atom force field on conformational energetics and properties of organic liquids. _J. Am. Chem. Soc._ **118** , 11225–11236 (1996). 

47. Lorenzoni, A., Mosca Conte, A., Pecchia, A. & Mercuri, F. Nanoscale morphology and electronic coupling at the interface between indium tin oxide and organic molecular materials. _Nanoscale_ **10** , 9376–9385 (2018). 

48. Plimpton, S. Fast parallel algorithms for short-range molecular dynamics. _J. Comput. Phys._ **117** , 1–19 (1995). 

49. Wei, K. et al. Facile exfoliation of the perovskite thin film for visualizing the buried interfaces in perovskite solar cells. _ACS Appl. Energy Mater._ **5** , 7458–7465 (2022). 

**Acknowledgements** This work was financially supported by the National Key Research and Development Program of China (no. 2019YFE0120000), the National Natural Science Foundation of China (nos. 62174112, 62005188 and 21875111), the Fundamental Research Funds for the Central Universities (nos. YJ201955 and YJ2021157), the Science and Technology Program of Sichuan Province (no. 2020JDJQ0030), the Engineering Featured Team Fund of Sichuan University (2020SCUNG102), the Research Funds from Tan Kah Kee Innovation Laboratory (HRTP-[2022]-45), the Key R&D Program of Natural Science Foundation of Jiangsu Province (BE2019733), the Natural Science Foundation of Jiangsu Province (BK20190825), open foundation of State Key Laboratory of Featured Metal Materials and Life-Cycle Safety for Composite Structures, Guangxi University (grant no. 2022GXYSOF05) and Key Lab of Advanced Optical Manufacturing Technologies of Jiangsu Province and Key 

Lab of Modern Optical Technologies of Education Ministry of China, Soochow University (no. KJS1909). F.F. acknowledges funding from the Swiss National Science Foundation (no. 200021_213073/1) and European Union’s Horizon Europe research and innovation programme under grant agreement no. 101075605. We acknowledge funding from the Deutsche Forschungsgemeinschaft in the SPP 2196 (HIPSTER 424709669 and SURPRISE 423749265). M.S. further acknowledges the Heisenberg programme from the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) for funding (project no. 498155101). F.L. acknowledges funding by the Volkswagen Foundation through the Freigeist Program. We also acknowledge Jihua Zou for measuring confocal PL mapping of WBG perovskites. 

**Author contributions** D.Z., F.F., W.T. and C.C. conceived and designed the research. R.H. carried out the fabrication and main characterizations of WBG PVSK films and devices. W.W., J. Zhou. and W.T. synthesized the SAMs and provided the relevant characterizations of SAMs. R.H., Z.Y., Y.L., J.L. and J. Zhu fabricated all-PVSK tandem devices. J.L. and J. Zhu helped to optimize the LBG devices. F.L., J.T., S.S. and M.S. performed the RPV measurements, the fast hysteresis measurements, the PLQY and electroluminescence-related characterizations and constructed the p- _JV_ of WBG PSCs and TSCs. C.W. performed EQE measurements. H.L. and F.F. carried out TPV and EIS measurements. H.H. and B.Z. performed PiFM measurements. X.Y. synthesized the molecule 2-thiopheneethylammonium chloride. M.S. performed numerical simulations of WBG PVSKs and helped to analyse the results. K.W. and Jinbao Zhang performed the exfoliation of WBG PVSK and characterized the photoluminescence mapping and SEM of the buried interface. R.H., C.C., F.F. and D.Z. wrote the manuscript with inputs from all co-authors. All authors discussed the results and reviewed the manuscript. D.Z. directed this project. 

**Competing interests** The authors declare no competing interests. 

###### **Additional information** 

**Supplementary information** The online version contains supplementary material available at https://doi.org/10.1038/s41586-023-05992-y. 

**Correspondence and requests for materials** should be addressed to Cong Chen, Fan Fu, Weihua Tang or Dewei Zhao. 

**Peer review information** _Nature_ thanks Anita Ho-Baillie, Lijun Zhang and the other, 

anonymous, reviewer(s) for their contribution to the peer review of this work. 

**Reprints and permissions information** is available at http://www.nature.com/reprints. 

Corresponding author(s): Cong Chen, Fan Fu, Weihua Tang, Dewei Zhao 



## <u>Solar Cells Reporting Summary</u> 

Nature Research wishes to improve the reproducibility of the work that we publish. This form is intended for publication with all accepted papers reporting the characterization of photovoltaic devices and provides structure for consistency and transparency in reporting. Some list items might not apply to an individual manuscript, but all fields must be completed for clarity. 

For further information on Nature Research policies, including our data availability policy, see Authors & Referees. 

### � Experimental design 

##### **Please check: are the following details reported in the manuscript?** 

1.   Dimensions 

|f h d l ll|Yes|The active area of the tested solar cells are 0.0975 cm2 and 1.27 cm2 .|
|---|---|---|
|Area o te teste soar ces|No|_Explain why this information is not reported/not relevant._|
|Method used to determine the device area<br>Current-voltage characterization|Yes<br>No|Metal shadow masks of 0.0975 cm2 and 1.27 cm2 were used during metal electrode<br>deposition.<br>_Explain why this information is not reported/not relevant._|
|Current density-voltage (J-V) plots in both forward|Yes|Provided in this manuscript.|
|and backward direction|No|_Explain why this information is not reported/not relevant._|
|Voltage scan conditions|Yes|Provided in Method section.|
|_For instance: scan direction, speed, dwell times_|No|_Explain why this information is not reported/not relevant._|
|Test environment|Yes|Provided in Method section.|
|_For instance: characterization temperature, in air or in glove box_|No|_Explain why this information is not reported/not relevant._|
|Protocol for preconditioning of the device before its|Yes|_State where this information can be found in the text._|
|characterization|No|No preconditioning was used in this work.|
|Stability of the J-V characteristic|Yes|Stabilized efficiencies of wide-bandgap perovskite solar cells and tandem solar cells|
|_Verified with time evolution of the maximum power point or with_|No|were provided.|
|_the photocurrent at maximum power point; seeref. 7 for details._||_Explain why this information is not reported/not relevant._|
|Hysteresis or any other unusual behaviour<br>Description of the unusual behaviour observed during|Yes|Very minor hysteresis was observed for devices.|
|the characterization|No|_Explain why this information is not reported/not relevant._|
||Yes|J-V curves under reverse and forward voltage scans were provided.|
|Related experimental data|No|_Explain why this information is not reported/not relevant._|
|Efficiency<br>External quantum efficiency (EQE) or incident|Yes|EQE spectra were provided.|
|photons to current efficiency (IPCE)|No|_Explain why this information is not reported/not relevant._|
|A comparison between the integrated response under<br>the standard reference spectrum and the response|Yes<br>No|The integrated Jsc values from EQE responses were consistent with the Jsc values<br>from J-V measurements.|
|measure under the simulator||_Explain why this information is not reported/not relevant._|
|For tandem solar cells, the bias illumination and bias|Yes|Stated in Method section.|
|voltage used for each subcell<br>Calibration|No|_Explain why this information is not reported/not relevant._|
|Light source and reference cell or sensor used for the|Yes|Stated in Method section.|
|characterization|No|_Explain why this information is not reported/not relevant._|



2.   Current-voltage characterization 

##### 3.   Hysteresis or any other unusual behaviour 

4.   Efficiency 

5.   Calibration 

1 

|Confirmation that the reference cell was calibrated|Yes|The reference cells were calibrated by NREL and provided in Method section.|
|---|---|---|
|and certified|No|_Explain why this information is not reported/not relevant._|
|Calculation of spectral mismatch between the|Yes|_State where this information can be found in the text._|
|reference cell and the devices under test|No|The light spectral response used for measurements matches well with the Si<br>reference cell, and so we did not calculate the spectral mismatch between the<br>reference cell and the devices under test.|
|6.   Mask/aperture|||
|Size of the mask/aperture used during testing|Yes<br>No|Metal aperture masks with areas of 0.0576 and 1.044 cm2 were used for testing.<br>_Explain why this information is not reported/not relevant._|
|Variation of the measured short-circuit current|Yes|_State where this information can be found in the text._|
|density with the mask/aperture area|No|All J-V curves were measured with a metal aperture mask.|
|7.   Performance certification|||
|Identity of the independent certification laboratory|Yes|Tandem solar cell was certified by JET.|
|that confirmed the photovoltaic performance|No|_Explain why this information is not reported/not relevant._|
|A copy of any certificate(s)|Yes|Provided in the supplementary information.|
|_Provide in Supplementary Information_|No|_Explain why this information is not reported/not relevant._|
|8.   Statistics|||
|Nb f l ll ttd|Yes|Stated in the manuscript.|
|umer o soar ces ese|No|_Explain why this information is not reported/not relevant._|
|Siil li f h di f|Yes|Stated in the manuscript.|
|tatstca anayss o te evce perormance|No|_Explain why this information is not reported/not relevant._|
|9.   Long-term stability analysis|||
|Type of analysis, bias conditions and environmental|Yes|Stated in the manuscript.|
|conditions|No|_Explain why this information is not reported/not relevant_|
|_For instance: illumination type, temperature, atmosphere_||_._|
|_humidity, encapsulation method, preconditioning temperature_|||



2 

