# Enhanced Self-Assembled Monolayer Surface Coverage by ALD NiO in p-i-n Perovskite Solar Cells

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | ACS Applied Materials and Interfaces |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 232 |
| 作者 | N. Phung, M. Verheijen, A. Todinova, K. Datta, M. Verhage, A. Al-Ashouri, H. Köbler, Xin Li et al. |
| DOI | 10.1021/acsami.1c15860 |
| 源文件 | 036_Phung_2021_Enhanced-Self-Assembled-Monolayer-Surface-Covera.pdf |

---
<mark>Research Article</mark> 

www.acsami.org 



## Enhanced Self-Assembled Monolayer Surface Coverage by ALD NiO in p‑i‑n Perovskite Solar Cells 

Nga Phung,* Marcel Verheijen, Anna Todinova, Kunal Datta, Michael Verhage, Amran Al-Ashouri, Hans Köbler, Xin Li, Antonio Abate, Steve Albrecht, and Mariadriana Creatore* 

Cite This: ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

Read Online 

### ACCESS Metrics & More Article Recommendations 



<!-- Start of picture text -->
*sı Supporting Information<br><!-- End of picture text -->

ABSTRACT: Metal halide perovskites have attracted tremendous attention due to their excellent electronic properties. Recent advancements in device performance and stability of perovskite solar cells (PSCs) have been achieved with the application of self-assembled monolayers (SAMs), serving as stand-alone hole transport layers in the p-i-n architecture. Specifically, phosphonic acid SAMs, directly functionalizing indium−tin oxide (ITO), are presently adopted for highly efficient devices. Despite their successes, so far, little is known about the surface coverage of SAMs on ITO used in PSCs application, which can affect the device performance, as non-covered areas can result in shunting or low open-circuit voltage. In this study, we investigate the surface coverage of SAMs on ITO and observe that the SAM of MeO-2PACz ([2-(3,6-dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid) inhomogeneously covers the ITO substrate. Instead, when adopting an intermediate layer of NiO between ITO and the SAM, the homogeneity, and hence the surface coverage of the SAM, improve. In this work, NiO is processed by plasma-assisted atomic layer deposition (ALD) with Ni(MeCp)2 as the precursor and O2 plasma as the co-reactant. Specifically, the presence of ALD NiO leads to a homogeneous distribution of SAM molecules on the metal oxide area, accompanied by a high shunt resistance in the devices with respect to those with SAM directly processed on ITO. At the same time, the SAM is key to the improvement of the open-circuit voltage of NiO + MeO-2PACz devices compared to those with NiO alone. Thus, the combination of NiO and SAM results in a narrower distribution of device performance reaching a more than 20% efficient champion device. The enhancement of SAM coverage in the presence of NiO is corroborated by several characterization techniques including advanced imaging by transmission electron microscopy (TEM), elemental composition quantification by Rutherford backscattering spectrometry (RBS), and conductive atomic force microscopy (c-AFM) mapping. We believe this finding will further promote the usage of phosphonic acid based SAM molecules in perovskite PV. 

KEYWORDS: perovskite solar cells, atomic layer deposition, nickel oxide, indium tin oxide, self-assembled monolayer, surface coverage 

# <mark>■</mark><sup>INTRODUCTION</sup> 

Solar cells based on metal halide perovskites are an attractive emerging photovoltaic (PV) technology. Their intriguing material properties offer extraordinary flexibility to tune the band gap, therefore making this class of absorbers suitable for both single-junction and multijunction cells.<sup>1</sup> The progress in the field of halide perovskites for PV application in the last 10 years is to be attributed to improvements in the absorber’s opto-electrical properties, as well as to the engineering of appropriate contact layers (hole/electron transport layer, HTL and ETL, respectively). Most notably, the recent development of self-assembled monolayer (SAM) as a stand-alone HTL helped in achieving more than 21% efficient single-junction devices at an absorber band gap of 1.63 eV.<sup>2,3</sup> These results have surpassed the paradigmatic polymer HTLs, such as poly[bis(4-phenyl)(2,4,6-trimethylphenyl)amine] (PTAA).<sup>2−4</sup> The use of a SAM HTL has also resulted in record tandem cells both with crystalline silicon (c-Si) and copper−gallium− indium−selenide (CIGS) bottom cells.<sup>2,5</sup> Therefore, materials 

based on molecular self-assembly form a promising class of HTLs for the next generation of p-i-n perovskite solar cells. 

Despite its success in perovskite PV, so far, limited investigation has been carried out on the surface coverage of SAMs on indium tin oxide (ITO). Surface coverage is important because noncovered areas can result in low opencircuit voltage and electrical shunts, thus reducing the device’s efficiency. In fact, since the early 2000s, there have been several reports raising concerns around the quality of SAMs grown on transparent ITO electrodes. The properties of these layers are said to heavily depend on the intrinsic properties of the ITO surface, as well as on the pretreatment of the ITO surface prior to SAM deposition. A recent work on tandem perovskite/c-Si 



Received: August 19, 2021 Accepted: December 6, 2021 Published: December 22, 2021 

© 2021 The Authors. Published by American Chemical Society 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

2166 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

with front textured silicon employing a phosphonic acid based SAM ([2-(9H-carbazol-9-yl)ethyl]phosphonic acid, 2PACz) hypothesized that this SAM might not cover the peaks of the pyramids completely, thereby reducing shunt resistance and VOC in tandem devices when compared to the summation of two single-junction cells.<sup>6</sup> Similarly, it has been shown that the different facets of crystalline ITO and surface roughness of ITO affected SAM formation causing defects in the layer.<sup>7,8</sup> In addition, it has been shown that the pretreatment of ITO affects the properties of the assembled layers. Al-Ashouri et al. reported that UV−O3 was essential for surface activation of ITO for SAM formation in perovskite solar cells.<sup>2</sup> However, the work function of SAM-functionalized ITO has also been found to be sensitive to the UV−O3 treatment time.<sup>9</sup> A report using 2PACz SAM also demonstrated that the performance of organic solar cells depended on the duration of O2-plasma treatment preceding SAM deposition.<sup>10</sup> Since the hydroxyl group concentration on any surface is a key element for promoting SAM formation via covalent bonds,<sup>11,12</sup> hydroxyl group rich NiO processed by atomic layer deposition (ALD) is expected to promote controlled and homogeneous SAM formation. ALD is an attractive deposition method due to its excellent conformality, reproducibility, and industrial viability.<sup>13</sup> Moreover, ALD as a deposition method has been used extensively in the field of perovskite PV, alone or in combination with buffer layers.<sup>14−17</sup> ALD metal oxides not only serve as charge transport layers but also can be used as protective layers to prevent perovskite degradation especially from oxygen and humidity. Thus, ALD NiO layer can create a universal surface chemistry for SAM formation, which is independent of the pretreatment of ITO surface and ITO’s intrinsic properties. 

NiO is a wide-band-gap p-type semiconductor due to the presence of nickel vacancies, which is widely used in perovskite solar cells and has enabled good device performance in both single-junction<sup>18−20</sup> and tandem devices.<sup>21,22</sup> More importantly, its tolerance to thermal stress delivers high operational stability to perovskite solar cells.<sup>21,23</sup> Previous work on plasmaassisted ALD NiO using Ni(MeCp)2 precursor and O2 plasma as co-reactant resulted in more than 17% efficient singlejunction devices on account of high optical transparency and good electrical properties of the NiO layer.<sup>24</sup> Further implementation of ALD NiO in the recombination junction of perovskite/CIGS tandem devices led to 21.6% power conversion efficiency (PCE).<sup>22</sup> In this case, NiO exhibited suitable optical and electrical properties in the tunnel recombination junction and conformably grew on the rough surface of CIGS, preventing electrical shunts.<sup>22</sup> Nonetheless, it has been shown that the quality of the NiO/perovskite interface remains a key challenge to achieve high open-circuit voltage (VOC) values in NiO-based perovskite solar cells, which is commonly attributed to the presence of surface defects of NiO.<sup>25</sup> Several reports suggested the presence of a nonphotoactive (“dead”) layer between NiO and perovskite, which reduces the VOC.<sup>26−28</sup> For instance, nickel defects (especially Ni<sup>3+</sup> ) have been proposed to react with organic cations in the perovskite precursors, resulting in a lead-rich layer at the interface.<sup>28</sup> Another hypothesis is that the nickel defects could act as hole-trapping centers, negatively affecting device performance.<sup>29−31</sup> This motivates research to improve the NiO/perovskite interface, for example by using SAMs for surface passivation.<sup>32−36</sup> 

In this manuscript, we report on MeO-2PACz ([2-(3,6dimethoxy-9H-carbazol-9-yl)ethyl]phosphonic acid SAM) and its surface coverage on ITO and ITO/NiO. The choice of this specific SAM with phosphonic acid anchoring chemistry is due to its proven implementation in high-efficiency single-junction perovskite solar cells devices, delivering a more than 21% efficiency champion device with a 1.55 eV band gap perovskite.<sup>2</sup> In our study, we conclude that ALD NiO provides a suitable surface for the homogeneous growth of SAM, compared to direct growth on ITO. This result leads to a narrow distribution of device efficiency values, specifically in terms of fill factor (FF). The presence of MeO-2PACz on metal oxides is evidenced from X-ray photoelectron spectroscopy (XPS) and Rutherford backscattering spectrometry (RBS). Transmission electron microscopy (TEM) imaging complemented by spectroscopic ellipsometry (SE) indicate a higher density of molecules on the surface of NiO. The difference in the spatial distribution of the SAM molecular density on ITO and NiO is further supported by conductive atomic force microscopy (c-AFM) measurements. We attribute the increase of shunt resistance seen in ITO/NiO/MeO2PACz-based devices compared to ITO/MeO-2PACz-based devices to the homogeneous coverage of the SAM on NiO. Simultaneously, the formation of a MeO-2PACz SAM is key to improve the NiO/perovskite interface resulting in a VOC gain of more than 50 mV and 7% absolute FF. At the same time, the presence of the NiO layer in combination with this SAM reduces the spread in device efficiency compared to ITO/ MeO-2PACz devices reaching an overall higher average device efficiency. Thus, the homogeneous packing of MeO-2PACz on ALD NiO and a well-performing interface enable a champion device with 20% PCE and a narrow efficiency distribution. 

# ■<sup>RESULTANDDISCUSSION</sup> 

In this study, we adopt the following p-i-n structure of perovskite cells: ITO/NiO/MeO-2PACz/CsFAMA/C60/ BCP/Cu (where CsFAMA stands for Cs0.05FA0.92MA0.03Pb(I0.83Br0.17)3 with FA as formamidinium, MA as methylammonium, and BCP as bathocuproine). The employed NiO is fabricated by plasma-assisted ALD following the procedure in previous reports.<sup>22,24</sup> To process MeO-2PACz, we utilize the dip-coating method,<sup>2</sup> which can be suitable for upscaling (details in the Method Section). Here, the MeO-2PACz molecule with the phosphonic acid anchoring group can bind with the hydroxyl surface groups of the metal oxide by a condensation reaction:<sup>37,38</sup> 



where R is 3,6-dimethoxy carbazole and M is the metal of the metal oxide, in this case, it is either In (in the case of ITO) or Ni (in the case of NiO). 

Figure 1a shows that NiO only based devices achieve 16% PCE on average, in agreement with previously reported values of NiO-based devices with postannealing treatment.<sup>24</sup> It has been shown that post-annealing treatment improved the perovskite solution wettability and the conductivity of the NiO layer, which overall results in higher device performance.<sup>24</sup> Meanwhile, solar cells using MeO-2PACz as the HTL can reach a higher PCE value, with the champion device 

2167 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

Table 1. Average PV Parameters and Standard Deviation of Different Devices Based on Different HTLs<sup>a</sup> 

||PCE (%)|VOC (mV)|JSC (mA/cm<sup>2</sup>)|FF (%)|
|---|---|---|---|---|
|NiO|16.0 ± 0.8|1071 ± 14|21.7 ± 0.4|70.7 ± 3.7|
|MeO-2PACz|19.0 ± 1.1|1123 ± 13|21.7 ± 0.4|77.5 ± 3.3|
|NiO + MeO-2PACz|19.0 ± 0.4|1124 ± 13|22.1 ± 0.2|77.3 ± 1.1|



aStandard deviation obtained from 36 different devices. 



Figure 1. Box charts of PV parameters of devices using ALD NiO with postannealing at 300 °C for 20 min in air, MeO-2PACz, and ALD NiO (without post-treatment) + MeO-2PACz: (a) PCE, (b) open-circuit voltage (VOC), (c) fill factor (FF), (d) short-circuit current (JSC). The data are collected from reverse second J−V scan with 100 mV/s scan rate. Box charts represent 25−75%. Whiskers are 5−95%, and the rest are outliers. Data are collected from 36 devices (active area of 0.16 cm<sup>2</sup> ), with each condition reported from several different batches. 

surpassing 20% (Figure S1), in agreement with previous literature work with the same SAM.<sup>2</sup> NiO-only devices lag behind MeO-2PACz-only devices both in FF and VOC, which suggests inefficient charge extraction by NiO and higher recombination at the NiO/perovskite interface compared to that of MeO-2PACz/perovskite. It has been reported that the energetic alignment of NiO with perovskite could be unfavorable, leading to a lower FF and VOC.<sup>19</sup> Nevertheless, in our case, the work functions of NiO and MeO-2PACz are quite similar at approximately 4.6−4.7 eV.<sup>2,24</sup> Moreover, the valence band maximum of NiO is 5.3 eV, deeper compared to that of MeO-2PACz having a value of 5.1 eV. This means that NiO exhibits a better band alignment to the perovskite (VBM of 5.6 eV) compared to MeO-2PACz. Hence, the difference in efficiency cannot be explained by band alignment between the HTL and the perovskite layer. Instead, it is likely that lower FF and VOC values are due to the presence of NiO surface defects. Such defects can react with the perovskite forming undesirable interlayers between NiO and perovskite<sup>27,28</sup> and/or act as hole traps.<sup>31,39</sup> The presence of SAM improves the NiO/perovskite interface, which is evidenced by higher FF and VOC of NiO/ SAM compared to NiO alone devices. In particular, the VOC of 

NiO + MeO-2PACz-based devices reaches 1.12 V on average compared to 1.07 V for NiO-based devices as can be seen in Table 1. Thus, it is likely that MeO-2PACz improves the interface between NiO and the perovskite absorber, though further work needs to be done to understand the underlying reason behind this improvement. 

Despite having a significantly higher PCE compared to NiObased devices, MeO-2PACz-based devices suffer from a larger distribution of device efficiency. This spread of efficiencies is the result of the large spread in FF (Figure 1b and Table 1). Instead, when we use ALD NiO in combination with MeO2PACz, the devices perform uniformly across the batch with an average efficiency of 19.0%. We argue that this improvement is due to the higher surface coverage of SAM on the metal oxide (on which we will elaborate later). Thus, the advantage of using the combination of ALD NiO and MeO-2PACz is clear thanks to the narrower distribution of NiO + MeO-2PACz devices’ efficiency compared to ITO + MeO-2PACz counterparts and higher performance of the NiO + MeO-2PACz compared to that of NiO-alone based devices. Moreover, the NiO + MeO-2PACz devices exhibit higher stability compared 

2168 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 



Figure 2. High-angle annular dark-field images of a cross section of the (a) ITO/MeO-2PACz device and (b) ITO/NiO + MeO-2PACz device. O 1s spectra of (c) ITO and ITO + SAM and (d) NiO and NiO + SAM samples. 

to MeO-2PACz-alone devices in an accelerated aging test at 85 °C (Figure S2). 

Before addressing the earlier formulated hypothesis on the difference in MeO-2PACz surface coverage directly on ITO and on ITO/NiO, we investigate the crystallinity and morphology of the perovskite layer deposited on the two different stacks by X-ray diffraction (XRD) and scanning electron microscopy (SEM). We observe negligible changes in the perovskite layer in XRD patterns (Figure S3) or in the apparent grain size in SEM micrographs between perovskite layers grown on different substrates. Moreover, steady-state photoluminescence (PL) curves of the perovskite layers on ITO + MeO-2PACz and NiO + MeO-2PACz in Figure S4 show negligible differences between the two PL spectra in terms of peak position and peak shape. Since PL peak position and peak shape can correlate to the defect chemistry of the perovskite layers,<sup>40,41</sup> the similar steady-state PL curves can indicate identical perovskite layers on different HTLs. Hence, we conclude that the difference in device performance can be attributed primarily to the layers (ITO or NiO) underneath MeO-2PACz. 

We now examine the surface coverage of MeO-2PACz on ITO and on ALD NiO. Figure 2a,b presents high-angle annular dark-field (HAADF) scanning TEM images of cross-sectional samples of a MeO-2PACz device and a NiO + MeO-2PACz device. In the HAADF images, the brightness is roughly 

proportional to Z<sup>2</sup> , where Z is the atomic number of the elements constituting the layer. 

In the HAADF images, a darker layer is recognizable, sandwiched by the metal oxide and perovskite layers. This layer corresponds to the MeO-2PACz layer, based on the expected low brightness because of the lower atomic number of the organic molecules. We note that there is evidence of carbon signal in the XPS spectrum of NiO (Figure S5c). Nonetheless, this presence of carbon signal is only because of surface contamination, since gentle Ar ion sputtering of the top layer totally suppresses the C 1s signal as can be seen in Figure S7. Hence, there are no unreacted organic ligands in our ALD NiO films, which can influence TEM analysis. However, from these images, it cannot be excluded that the apparent dark area is a void caused by mechanical delamination between the layers. Identification of the composition of this layer by energydispersive X-ray spectroscopy (EDX) appeared unsuccessful, as the phosphorus concentration in the SAM is below the detection limit of STEM-EDX, and the carbon profile in the dark layer is dominated by the signal from the adjacent perovskite. Therefore, several other techniques were used to corroborate the TEM images and confirm the presence of the MeO-2PACz layer. In the following session, we verify the presence of MeO-2PACz on ITO and NiO by analyzing the layers using XPS and RBS. 

First, XPS is used to analyze the surface chemistry of the ITO/MeO-2PACz and ITO/NiO/MeO-2PACz. As shown in 

2169 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 



Figure 3. (a) Schematic of c-AFM where the layers are biased at 100 mV and a metal-coated AFM tip is used to collect the current signal from the surface. (b) Height and current map of ITO + MeO-2PACz layer and (c) corresponding line profile along the dashed line. (d) c-AFM height and current maps of NiO + MeO-2PACz layer with line profile plotted in (e). 

Figures S5 and S6, the presence of MeO-2PACz is confirmed by the P 2p peak at binding energy of 133 eV (assigned to P in phosphate) and N 1s at binding energy of 399.5 eV (assigned to C−N bonds) for both ITO and NiO as substrates.<sup>42</sup> In addition, we detect the C−O contribution in the O 1s spectrum (Figure 2c,d), which belongs to the methoxy groups of MeO-2PACz in agreement with a previous report.<sup>2</sup> We also observe a shift of approximately 0.3 eV for the Ni 2p spectrum toward higher binding energies in the presence of the SAM (Figure S5a). This shift is also visible in the O 1s XPS signal of NiO + MeO-2PACz compared to only NiO as can be seen in Figure 2d. Similarly, there is a 0.2 eV shift in the In 3d and O 1s spectra when comparing ITO + MeO-2PACz and UV−O3treated ITO alone as can be seen in Figures S6a and 2c. The homogeneous shift in the binding energy of the core level peaks can indicate a change in the work function due to the presence of a dipole introduced by MeO-2PACz. It has been reported that the molecule has an intrinsic dipole moment of 0.2D,<sup>2</sup> which can explain the shift when MeO-2PACz chemisorbs on the surface of the metal oxides. Furthermore, from XPS analysis, we observe a higher ratio between hydroxyl group (−OH) and metal oxide (O<sup>2−</sup> ) calculated from the O 1s spectra for NiO compared to ITO, which are presented in Figure 2c,d (0.59 ± 0.06 and 0.41 ± 0.04 for NiO and ITO after UV−O3 surface treatment, respectively). Here, the detected hydroxyl group is likely to concentrate on the surface of the metal oxides, as evidenced in our previous work using angle-resolved XPS showing a higher hydroxyl group on the surface than in the bulk of NiO.<sup>24</sup> Because surface hydroxyl groups are key to the chemisorption of SAM on the metal oxide, we propose that the difference in MeO-2PACz coverage can be related to a higher hydroxyl concentration on ALD NiO surface, compared to ITO. These surface hydroxyl groups are 

also thought to promote the chemisorption of MeO-2PACz on sputtered NiO in another work published during the preparation of this work.<sup>43</sup> It is reported that the absorption of MeO-2PACz is stronger on NiO due to tridentate binding resulting in more compact MeO-2PACz layer on NiO than on ITO,<sup>43</sup> which is well-aligned with our conclusion. Notably, the good coverage of SAM on NiO is achievable without any postannealing of ALD NiO, which makes it compatible to lowtemperature requirements in other application such as with flexible substrates. 

Next to the qualitative analysis of the interface by XPS, RBS is employed to quantify the molecular areal densities of phosphorus (atoms/cm<sup>2</sup> ), which represents the number of MeO-2PACz molecules. As can be seen in Figure S8, the spectra show a peak associated with phosphorus for both ITO/ MeO-2PACz and ITO/NiO/MeO-2PACz, thereby confirming the finding of XPS. Simulated spectra indicate that there are 0.3 ± 0.1 × 10<sup>15</sup> atoms/cm<sup>2</sup> of phosphorus for both ITO/ MeO-2PACz and ITO/NiO/MeO-2PACz. Since there is one phosphorus in every MeO-2PACz molecule, this number also represents the areal density of MeO-2PACz. The relatively high uncertainty of RBS data roots from the fact that the signal is close to the detection limit of the measurement. Although we can quantify the areal density of MeO-2PACz layer, it was not possible to conclude about any difference between the areal density of P in case of ITO/MeO-2PACz and ITO/NiO/ MeO-2PACz. However, we can conclude that the XPS and RBS analyses strongly suggest that the dark layer in the TEM images (Figure 2a,b) corresponds to MeO-2PACz. 

Furthermore, we note that the MeO-2PACz layer is characterized by a variation in local thicknesses on ITO as can be seen in Figure 2a. In particular, the MeO-2PACz thickness varies from 1.5 to 4.5 nm when considering ITO 

2170 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 



Figure 4. (a) Dark current density−voltage curves of low- and high-efficiency MeO-2PACz devices and a NiO + MeO-2PACz device. (b) Distribution of shunt resistance of MeO-2PACz devices and NiO + MeO-2PACz devices obtained from the data set in Figure 1. 

peaks and valleys, respectively. This thickness variation effectively smoothens the ITO surface. In contrast, the thickness of the MeO-2PACz layer is homogeneous on the NiO layer with approximately 3 nm as inferred from the TEM image in Figure 2b. Finally, we note that the thickness of MeO2PACz detected by TEM is larger than the estimated 1 nm of SAM molecular length. This value originates by considering the bond lengths from the C atom of the methoxy group to the O atom of the phosphonic group, not accounting for the Coulomb force, or the rotation of methoxy group, or the tilting of the molecule on the surface. This difference between estimated and detected SAM thickness implies that MeO2PACz might form multiple layers of molecules, which can bond with each other via hydrogen bonds.<sup>44−46</sup> 

We acknowledge that the acronym of SAM (self-assembled monolayer) may not be applicable in this study as more than one monolayer of MeO-2PACz may be present. Therefore, we refer here to SAM as self-assembled monolayer or multilayers following the suggestion in literature.<sup>47</sup> This is also because MeO-2PACz layer formation still results from self-assembling of the molecules, which by nature can still be defined as a SAM.<sup>37,48</sup> The self-assembly process has a distinct self-limiting behavior. To demonstrate this self-limiting nature of MeO2PACz layer formation, we fabricated layers with different concentrations of MeO-2PACz and quantify the P-to-In (in case of MeO-2PACz deposited on ITO) and P-to-Ni (in case of MeO-2PACz deposited on NiO) ratios from the XPS core level peaks (P 2p3/2, In 3d5/2, and Ni 2p3/2). The calculated ratios reach a saturation value confirming the self-limiting behavior of the MeO-2PACz layer as can be seen in Figure S9. Therefore, this self-limiting characteristic can warrant MeO2PACz to be referred to as SAM. 

As can be seen from TEM images in Figure 2 (also evidenced in lower magnification images in Figure S10), we found an area where the molecular density of MeO-2PACz appears to be lower than the rest of the layer, as indicated by the circle in Figure 2a. In contrast, MeO-2PACz forms a homogeneous layer on NiO, as highlighted in Figure 2b. Multiple images of different areas of a cross section made on an ITO/NiO/MeO-2PACz device are shown in Figure S11, confirming the homogeneity of MeO-2PACz on NiO. To support the increased homogeneity of MeO-2PACz on NiO/ ITO layer with respect to MeO-2PACz on ITO observed in TEM images, we use c-AFM on the two layers. Figure 3a represents the schematic of the setup where a bias is applied to the layer and a metal-coated highly doped n-Si-based AFM tip is used to record the current from the surface of the layers. A bias of 100 mV was applied to the samples using a tunnelling 

AFM setup (TUNA), which is extremely sensitive to low current (detailed in Method section). As can be seen from Figure 3b, ITO/MeO-2PACz layer shows a crater feature visible in the height map of the layer. Corresponding to the valley of the layer, the current map shows a cluster of high current regions. To clarify this, we overlay the current and height line profiles obtained along the white dash line. It can be seen in Figure 3c that the high current position coincides well with the valley of the ITO layer. Considering that ITO has higher conductivity than MeO-2PACz itself, it is plausible that the high current is due to exposed ITO or low molecular density of SAM area allowing current to tunnel through. On the contrary, as shown in Figure 3d, the current map of the ITO/NiO/MeO-2PACz sample is comparatively homogeneous despite having similar isolated valley features. We also focus on a valley on ITO/NiO/MeO-2PACz and plot corresponding current and height line profiles. Figure 3e shows that MeO-2PACz layer on NiO exhibits a relatively constant and low current. These current maps support that the MeO-2PACz molecules forms a homogeneous layer on NiO in agreement with TEM analysis. We acknowledge that the ITO/ NiO/MeO-2PACz layer is less rough, as observed in the TEM cross-sectional image (Figure 2), thereby contributing to the homogeneity of the SAM. This is also evidenced by the slightly decrease in surface roughness of ITO/NiO/MeO-2PACz (RMS = 2.0 nm) compared to ITO/MeO-2PACz (RMS = 2.2 nm). These surface roughness values are calculated from 10 × 10 μm<sup>2</sup> AFM images in Figure S13 (ESI). This change in roughness is quite small, which is expected to play a minor role in the observed trend. 

Finally, we employ variable angle SE to determine the optical thickness of the MeO-2PACz layers and confirm the above-reported findings. SE measurements were carried out with a range of angles from 40° to 85° with a 5° step to enhance the sensitivity of the measurement to the thin semiabsorbing layer. We model the MeO-2PACz layer with the Cauchy dispersion formula<sup>49</sup> in the transparent range (1.0−3.0 eV).<sup>2,50</sup> Since it is challenging to accurately determine both optical constant and thickness of such an ultrathin layer,<sup>51,52</sup> we derive the optical thickness of MeO-2PACz layer that is the product of refractive index (n) and thickness (d). For MeO2PACz on ITO, the optical thickness is 3.4 ± 0.1 nm (n = 1.8 at 1.95 eV, d = 1.9 ± 0.1 nm) whereas a value of 7.2 ± 0.1 nm (n = 1.8 at 1.95 eV, d = 4.0 ± 0.1 nm) is obtained for MeO2PACz on NiO. Because the optical thickness relates to the density of the material, this comparison strengthens the conclusion derived by TEM analysis that the MeO-2PACz layer on NiO is denser than the MeO-2PACz layer on ITO. 

2171 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

The details of the fit procedure can be found in the discussion related to Figures S14−S17 (ESI). 

On the basis of the opto-chemical and morphological characterization carried out so far, we argue that the lower molecular density associated with MeO-2PACz on ITO in combination with its inhomogeneity in film thickness is responsible for the spread in device efficiency (Figure 1). Low molecular density of MeO-2PACz may lead to possible shunt paths due to direct contact between perovskite and ITO. To support this conclusion, we report dark J−V characteristics to analyze the difference in shunt resistance of ITO/MeO-2PACz and ITO/NiO/MeO-2PACz-based devices. Figure 4a shows that a low-PCE MeO-2PACz device is characterized by a high leakage current, which correlates with additional recombination pathways<sup>53</sup> due to charge recombination at poorly covered ITO surfaces. This is also reflected in the distribution of shunt resistances presented in Figure 4b. The ITO/NiO/MeO2PACz devices have an overall higher shunt resistance on average (3.2 kOhm·cm<sup>2</sup> ) compared to that of ITO/MeO2PACz devices (2.3 kOhm·cm<sup>2</sup> ), and more importantly, the spread of shunt resistance is narrower than that of ITO/MeO2PACz devices. This is attributed to the denser MeO-2PACz layer on NiO compared to ITO. We note that it is possible to obtain higher shunt resistance in NiO + SAM due to the low lateral conductivity of NiO (sheet resistance of a thin NiO film (ca. 8 nm) is on order of 10<sup>8</sup> Ohm/sq, as determined by fourpoint probe measurement, see details in the Method Section). Low lateral conductivity reduces the chance for charge carriers to transport from electrical shunts to recombine and contribute to the leakage current. This can improve the shunt resistance of the device.<sup>54</sup> However, the shunt resistance of NiO alone devices, despite having a narrower distribution, has an average value lower than the average found for MeO-2PACz devices (Figure S18). Hence, we believe that the higher shunt resistance seen in NiO + MeO-2PACz devices compared to ITO + MeO-2PACz devices can mainly be attributed to the higher coverage of the SAM on NiO. 

We conclude that MeO-2PACz forms a more homogeneous layer on ALD NiO compared to direct processing on ITO, which leads to a narrow distribution of device efficiency. Although this study focuses only on MeO-2PACz, we believe that the finding can be applied to other phosphonic acid SAMs as well and can be extended to carboxylic acid SAMs because of their similar chemisorption mechanism. We also expect that ALD NiO can be applied to ITO with different properties, thereby delivering a universal surface that is suitable for the formation of a homogeneous and uniform SAM. We trust that our finding can further promote the use of SAMs in combination with NiO in single and tandem junction PV. 

# ■<sup>CONCLUSION</sup> 

It is undeniable that SAMs as hole-selective materials are attractive for state-of-the-art perovskite solar cells, providing record efficiencies in single-junction and tandem devices.<sup>2−5</sup> In this work, we have shown that ALD NiO provides a more suitable surface for homogeneous SAM formation compared to ITO. We adopted TEM, in combination with XPS and RBS to detect MeO-2PACz layers on NiO and ITO surfaces. The TEM images, supported by c-AFM and SE optical modeling, point to a denser and more homogeneous SAM layer on ALD NiO, with respect to the ITO case. In the latter case, we detect low-molecular-density areas of MeO-2PACz on ITO, responsible for higher dark current and lower shunt resistance as 

observed in some MeO-2PACz/ITO based devices. Instead, the homogeneous MeO-2PACz layer on NiO leads to a narrow distribution of device efficiency across different batches of devices. We trust that our finding can further promote the use of SAMs in combination with NiO in single-junction and tandem junction PV. 

# ■<sup>METHODSSECTION</sup> 

Solar Cell Fabrication. The perovskite solutions started from stock solutions using 1.5 M PbI2 and PbBr2 (Tokyo Chemical Industry, 99.99% purity) in dimethylformamide/dimethyl sulfoxide (DMF/DMSO) mixed solvent (4:1 by volume, Sigma Adrich, anhydrous). Then formamidinium iodide (Dyenamo) and methylammonium bromide (Dyenamo) powders were mixed into the lead stock solutions to obtain 1.24 M FAPbI3 and MAPbBr3. The Cs source was from CsI (abcr GmbH) 1.5 M in DMSO. The final perovskite solution consists of 92% FA and 3% MA and 5% Cs. Details of the perovskite solution can be found elsewhere.<sup>55,56</sup> 

Indium tin oxide (ITO) substrates (Automatic Research, 15 Ω cm<sup>−2</sup> ) were cleaned by soap (2% Mucasol in DI water), water, acetone, and isopropanol in subsequential steps in an ultrasonic bath at 40 °C for 15 min each. After drying the substrates, they were treated with UV−O3 or O2 plasma prior to SAM deposition or ALD NiO deposition, respectively. 

The solution for SAM deposition consisted of 0.1 mmol/L MeO2PACz (Tokyo Chemical Industry). Before dissolving in anhydrous ethanol (Alfa Aesar), the material was exposed to air for 5 min. The solution was mixed in a thermal shaker at 60 °C for 5 min, followed by 15 min of sonication in an ultrasonic bath to ensure full dispersion of MeO-2PACz in the solution. The cleaned substrates were immediately transferred to N2 glovebox and put in a glass beaker for full submergence of the substrate in the MeO-2PACz solution. The substrates were left in this solution for 8−12 h. In literature, it has been shown that this range of dipping time can ensure a highquality, fully saturated coverage of SAM;<sup>48</sup> however, longer than 12 h might lead to ITO damage.<sup>8</sup> For the spin-coating method, 100 μL of SAM solution (with different concentration in ethanol from 0.01 to 10 mM) was dropped to the substrates followed by 3000 rpm for 30 s of spin-coating. Then, the layers were annealed at 100 °C for 15 min before washing twice with 200 μL of anhydrous ethanol during a 3000 rpm spin coating step. The MeO-2PACz molecular length was estimated by Avogadro molecule editing and drawing software. 

The ALD NiO process detail can be found in the previous report.<sup>24</sup> In short, the ITO substrates were cleaned with O2 plasma for 15 min to remove contaminants prior to the process. The process consisted of 3 s of plasma dosing and 4 s of precursor dosing with 5 s of purging in between steps. The precursor used was bis-methylcyclopentadienylnickel (Ni(MeCp)2). The table temperature was set at 150 °C, and the substrate’s temperature was estimated to be around 100−110 °C. The growth per cycle of the ALD NiO is 0.03 nm/cycle in agreement with the previous study.<sup>24</sup> Afterward, the ALD NiO layers were annealed for 300 °C in air for 20 min before perovskite deposition in the case of ALD NiO-only devices. The postannealing treatment was to ensure good wetting of the perovskite solution on ALD NiO as previously reported.<sup>24</sup> For the bilayer NiO + MeO-2PACz, there was no thermal annealing posttreatment, but the ALD NiO layers were directly coated with the SAM (as described above). We would like to point out that although we will refer throughout the manuscript to ALD NiO thin films both Ni<sup>2+</sup> and Ni<sup>3+</sup> oxidation states are present in the film. 

The perovskite layer was fabricated as followed: First, 100 μL of perovskite solution was spun on a room-temperature substrate by spin-coating (4000 rpm for 30 s, ramping for 5 s). After 25 s of spincoating, a quenching step using 250 μL of anisole was used to form a smooth and compact film. The perovskite films were immediately annealed at 100 °C for 60 min. Finally, C60 (23 nm, Sigma-Aldrich), BCP (bathocuproine or 2,9-dimethyl-4,7-diphenyl-1, 8 nm, SigmaAldrich), and Cu (100 nm, Alfa Aesar, 99.95% purity) were thermally evaporated onto the perovskite layer to complete the devices. The 

2172 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

data presented in Figure 1 are from several batches of devices. The devices were fabricated as such all the processes except HTL were kept identical, e.g., the same perovskite solution was used to spin-coat onto the HTL. All of these fabrication steps were done in an inert atmosphere with minimal air exposure. All chemicals were used as received. 

Current Density−Voltage Measurement. The devices were measured using ABB Xenon solar simulator in N2-filled atmosphere with 100 ms/V scan rate. The device’s holder was actively cooled using a copper block and cooling water setting at 23 °C so that the device reached approximately 25 °C at 1 sun illumination. The solar simulator was calibrated using a Si diode certified by Fraunhofer ISE. During the measurement, the reverse scan was performed first. The data were reported from the second current density−voltage measurement. The area of the cell was defined as the overlapping between ITO patterned with the metal electrode which is 0.16 cm<sup>2</sup> . 

External Quantum Efficiency. The device’s EQE was measured with a Newport 300 W xenon arc lamp in an Oriel Instruments QEPVSI-b system. A Newport Cornerstone 260 monochromator was used to create monochromatic light chopped at a frequency of 78 Hz. Prior to the measurement, the system was calibrated with a silicon reference cell with a known spectral response. The electrical response of the device was recorded with a Stanford Research SR830 Lock-In amplifier. The commercial TracQ software was used to collect and evaluate the signal. 

X-ray Diffraction. XRD patterns were collected using PANalytical thin-film analysis system equipped with Cu Kα X-ray source. The integration time was 1 s per 0.02° step. Because the measurements were done in an ambient atmosphere, the perovskite layers were capped with 20 nm of PMMA (Sigma-Aldrich, 20 mg/mL chlorobenzene) to avoid rapid degradation. 

Photoluminescence. Steady-state PL measurements were done with a lab-built setup utilizing a 520 nm CW laser (Insaneware). The excitation intensity was calibrated to be equivalent to 1 sun illumination calibrated using a known absorption spectrum Si diode. 

Transmission Electron Microscopy. The TEM studies were performed using a probe-corrected JEOL ARM 200F TEM. Here, the images were collected at 200 kV. Cross-sectional TEM sample preparation was performed using a Focused Ion Beam (FIB) using a standard lift-out process. 

Spectroscopic Ellipsometry. The ellipsometry measurements were carried out using UV−vis Ellipsometer M2000, J. A. Woollam Co. using the commercial software CompleteEASE to collect and analyze the data. Prior to the measurement, a system check was performed using a known optical constant 10 nm of SiO2 on Si substrate. Then, the measurements were performed with angles from 40 to 85° (in a step of 5°) for a wavelength range of 200−1000 nm. The glass substrates were covered with Scotch magic tape on the back side to avoid back reflection. The SE measurements were done prior to every layer deposition step to ensure a correct fitting of the individual thicknesses. This meant that SE data were collected for ITO alone, ITO + NiO, ITO + SAM, and ITO + NiO + SAM and were modeled accordingly. 

X-ray Photoelectron Spectroscopy. XPS studies in this work used Thermo Scientific KA1066 spectrometer. The excitation source was a monochromatic Al Kα X-rays having an energy of 1486.6 eV. The measurements were done without any presputtering procedure, and the layers were in contact with air for 1 h prior to the measurement. A gold clamp and an electron flood gun were used to reduce sample charging during the measurement. The data were analyzed using commercial software Avantage with Shirley background subtraction. To avoid possible peak shifts due to charging, the binding energies of the XPS spectra were corrected by setting the maximum of the adventitious carbon peak in the C 1s spectra to 284.4 eV. The assignment of the peaks relied on several literatures.<sup>42,57,58</sup> We acknowledge that the assignment of different chemical states of nickel oxide is quite complex in XPS; however, in this case, there was no detectable change in the shape of Ni 2p spectra with or without MeO-2PACz but rather a peak shift. Hence, we believed that the 

assignment sufficed for the purpose of elemental identification of our thin layers. 

Conductive Atomic Force Microscopy. AFM images were collected with a Veeco Dimension MultiMode microscope connected to a Nanoscope III controller in tapping mode at the scan rate of 1 Hz using PPP-NCH probes (Nanosensors). The probes were sputtered with 3 nm tantalum seed layer and 30 nm of platinum. For c-AFM, a TUNA head was used to apply bias and record currents from the layer with contact mode configuration at a scan rate of 0.5 Hz. For imaging analysis, the commercial software NanoScope and the freely available software package ImageJ were used. 

Rutherfold Backscattering Spectrometry. RBS measurement was performed with 1000 keV He<sup>+</sup> beam with perpendicular incidence. 

Four-Point Probe Measurement. The four-point probe measurement was done to determine the sheet resistance of the NiO layer deposited on a Si substrate coupon with 450 nm SiO2 to ensure electrical insulation between the layer of interest and the substrate. The setup consisted of a Signatron probe connecting to a Keithley 2400 SourceMeter which was controlled by lab-built software in LabView environment. 

Operational Stability Test. A custom-built high-throughput aging rig was used for the stability test of solar cells in this study,<sup>59</sup> in which each cell’s maximum power point (MPP) was individually tracked by the use of special electronics. MPP tracking used a perturb and observe algorithm<sup>60</sup> with a voltage step-width of 0.01 V and a delay time of 1 s. PCEMPP values were automatically recorded for all cells every 2 min and normalized to the maximum value. J−V measurements were taken every 24 h that might cause spikes in the MPP tracking curves and/or the perturbance of the system. During the aging test, the active area touched a heat pad in order to ensure direct thermal coupling and Peltier elements were used to keep the cells at 85 °C. MPP tracking of devices was performed without encapsulation and under a continuous flow of nitrogen in a closed box. A metal−halide lamp with a H2 filter was used as a light source with 100 mW/cm<sup>2</sup> intensity, of which the spectrum is shown elsewhere.<sup>3</sup> The light source intensity was actively controlled using a silicon irradiation-sensor which was calibrated using a Silicon reference from Fraunhofer ISE. 

# ■<sup>ASSOCIATEDCONTENT</sup> 

#### *sı Supporting Information 

The Supporting Information is available free of charge at https://pubs.acs.org/doi/10.1021/acsami.1c15860. 

- Further details of champion devices, additional devices data, additional TEM and AFM images, additional XPS data, details of ellipsometry fitting (PDF) 

# ■<sup>AUTHORINFORMATION</sup> 

##### Corresponding Authors 

- Nga Phung − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands; orcid.org/0000-0002-0328-6791; Email: t.t.n.phung@tue.nl 

- Mariadriana Creatore − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands; Solliance, 5656 AE Eindhoven, The Netherlands; Eindhoven Institute of Renewable Energy Systems (EIRES), 5600 MB Eindhoven, The Netherlands; Email: M.Creatore@tue.nl 

##### Authors 

- Marcel Verheijen − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands; orcid.org/0000-0002-8749-7755 

2173 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

- Anna Todinova − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands; Present Address: Solar Technologies and Applications, TNO/Solliance, High tech campus 21, 5656AE Eindhoven, The Netherlands. Email: anna. todinova@tno.nl 

- Kunal Datta − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands 

- Michael Verhage − Department of Applied Physics, Eindhoven University of Technology, 5600 MB Eindhoven, The Netherlands 

- Amran Al-Ashouri − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; orcid.org/0000-0001-5512-8034 

- Hans Köbler − Young Investigator Group Active Materials and Interfaces for Stable Perovskite Solar Cells, HelmholtzZentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; Present Address: Department Novel Materials and Interfaces for Photovoltaic Solar Cells, Helmholtz-Zentrum Berlin, 12489 Berlin, Germany. 

- Xin Li − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; Present Address: Solar Energy Research Institute of Singapore (SERIS), National University of Singapore, Singapore 117574, Singapore. Email: Xin.li@nus.edu.sg 

- Antonio Abate − Young Investigator Group Active Materials and Interfaces for Stable Perovskite Solar Cells, HelmholtzZentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; Department of Chemical, Materials and Production Engineering, University of Naples Federico II, 80125 Fuorigrotta, Italy; Present Address: Department Novel Materials and Interfaces for Photovoltaic Solar Cells, Helmholtz-Zentrum Berlin, 12489 Berlin, Germany; orcid.org/0000-0002-3012-3541 

- Steve Albrecht − Young Investigator Group Perovskite Tandem Solar Cells, Helmholtz-Zentrum Berlin für Materialien und Energie GmbH, 12489 Berlin, Germany; Faculty of Electrical Engineering and Computer Science, Technical University Berlin, 10587 Berlin, Germany; orcid.org/0000-0001-9962-9535 

Complete contact information is available at: https://pubs.acs.org/10.1021/acsami.1c15860 

##### Author Contributions 

M.C. conceived the idea of this study and supervised the research. N.P. fabricated devices with the assistance of A.T. and performed AFM, SE, and XPS measurements. M. Verheijen acquired and analyzed EDX-TEM data. K.D. fabricated layers for XPS measurements. M. Verhage performed c-AFM measurements and provided support in data interpretation. N.P. and H.K. performed device stability measurements. A.A.A. fabricated devices and optimized SAM fabrication with support from X.L. A.A. and S.A. provided suggestions on data interpretation. N.P. wrote the first draft of the manuscript under the supervision of M.C. M.C., S.A., A.A. secured the funding for the collaboration. All authors discussed the results and commented on the manuscript. 

##### Notes 

The authors declare no competing financial interest. 

# <u>■</u><sup>ACKNOWLEDGMENTS</sup> 

The authors acknowledge the technical support of Thomas Lußky, Hagen Heinz, Monika Gabernig, and Carola Ferber at HZB, Cristian van Helvoirt, Caspar van Bommel, Joris Meulendijks and Janneke Zeebregts at TU/e. The authors thank Wim Arnold-Bik at DIFFER for performing RBS measurement, Carola Klimm (HZB) for acquiring SEM images, and Dr. Beatriz Barcones Campo (TU/e) for preparing FIB for TEM measurement. N.P. thanks Dr. Ece Aktas (ICIQ), Dr. Artiom Magomedov (KTU), Dr. Gerben van Straaten (TU/e), Dr. Stephan Prunte (TU/e), and Kousumi Mukherjeë (TU/e) for fruitful discussion. The authors are grateful to Prof. dr. René Janssen (TU/e) for the valuable discussions. N.P. and M. Verhage thank Ömür Gökçinar (TU/e) for his support during c-AFM measurements. Solliance and the Dutch province of Noord-Brabant are acknowledged for funding the TEM facility. A.A.A. and S. A. acknowledge the BMBF for funding of the Young Investigator Group (grant no. 03SF0540) within the project “Materialforschung fur die Energiewende.” A.T. and M.C. acknowledge the TKI Urban Energy (PVPress TEUE 118010). M.C. acknowledges the NWO Aspasia program. 

# ■<sup>REFERENCES</sup> 

(1) Snaith, H. J. Present Status and Future Prospects of Perovskite Photovoltaics. Nat. Mater. 2018, 17 (5), 372−376. 

(2) Al-Ashouri, A.; Magomedov, A.; Roß, M.; Jošt, M.; Talaikis, M.; Chistiakova, G.; Bertram, T.; Márquez, J. A.; Köhnen, E.; Kasparavičius, E.; Levcenco, S.; Gil-Escrig, L.; Hages, C. J.; Schlatmann, R.; Rech, B.; Malinauskas, T.; Unold, T.; Kaufmann, C. A.; Korte, L.; Niaura, G.; Getautis, V.; Albrecht, S. Conformal Monolayer Contacts with Lossless Interfaces for Perovskite Single Junction and Monolithic Tandem Solar Cells. Energy Environ. Sci. 2019, 12 (11), 3356−3369. 

(3) Aktas, E.; Phung, N.; Köbler, H.; González, D. A.; Méndez, M.; Kafedjiska, I.; Turren-Cruz, S.-H.; Wenisch, R.; Lauermann, I.; Abate, A.; Palomares, E. Understanding the Perovskite/Self-Assembled Selective Contact Interface for Ultra-Stable and Highly Efficient p− i−n Perovskite Solar Cells. Energy Environ. Sci. 2021, 14 (7), 3976− 3985. 

(4) Yalcin, E.; Can, M.; Rodriguez-Seco, C.; Aktas, E.; Pudi, R.; Cambarau, W.; Demic, S.; Palomares, E. Semiconductor SelfAssembled Monolayers as Selective Contacts for Efficient PiN Perovskite Solar Cells. Energy Environ. Sci. 2019, 12 (1), 230−237. (5) Al-Ashouri, A.; Köhnen, E.; Li, B.; Magomedov, A.; Hempel, H.; Caprioglio, P.; Márquez, J. A.; Morales Vilches, A. B.; Kasparavicius, E.; Smith, J. A.; et al. Monolithic Perovskite/Silicon Tandem Solar Cell with >29% Efficiency by Enhanced Hole Extraction. Science (Washington, DC, U. S.) 2020, 370 (6522), 1300−1309. 

(6) Isikgor, F. H.; Furlan, F.; Liu, J.; Ugur, E.; Eswaran, M. K.; Subbiah, A. S.; Yengel, E.; De Bastiani, M.; Harrison, G. T.; Zhumagali, S.; Howells, C. T.; Aydin, E.; Wang, M.; Gasparini, N.; Allen, T. G.; Rehman, A. ur; Van Kerschaver, E.; Baran, D.; McCulloch, I.; Anthopoulos, T. D.; Schwingenschlögl, U.; Laquai, F.; De Wolf, S. Concurrent Cationic and Anionic Perovskite Defect Passivation Enables 27.4% Perovskite/Silicon Tandems with Suppression of Halide Segregation. Joule 2021, 5 (6), 1566−1586. 

(7) Chockalingam, M.; Darwish, N.; Le Saux, G.; Gooding, J. J. Importance of the Indium Tin Oxide Substrate on the Quality of SelfAssembled Monolayers Formed from Organophosphonic Acids. Langmuir 2011, 27 (6), 2545−2552. 

(8) Losego, M. D.; Guske, J. T.; Efremenko, A.; Maria, J.-P.; Franzen, S. Characterizing the Molecular Order of Phosphonic Acid Self-Assembled Monolayers on Indium Tin Oxide Surfaces. Langmuir 2011, 27 (19), 11883−11888. 

2174 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

(9) Hubmann, A.; Dietz, D.; Brötz, J.; Klein, A. Interface Behaviour and Work Function Modification of Self-Assembled Monolayers on Sn-Doped In2O3. Surfaces 2019, 2 (2), 241−256. 

(10) Lin, Y.; Firdaus, Y.; Isikgor, F. H.; Nugraha, M. I.; Yengel, E.; Harrison, G. T.; Hallani, R.; El-Labban, A.; Faber, H.; Ma, C.; et al. Self-Assembled Monolayer Enables Hole Transport Layer-Free Organic Solar Cells with 18% Efficiency and Improved Operational Stability. ACS Energy Lett. 2020, 5 (9), 2935−2944. 

(11) Hotchkiss, P. J.; Jones, S. C.; Paniagua, S. A.; Sharma, A.; Kippelen, B.; Armstrong, N. R.; Marder, S. R. The Modification of Indium Tin Oxide with Phosphonic Acids: Mechanism of Binding, Tuning of Surface Properties, and Potential for Use in Organic Electronic Applications. Acc. Chem. Res. 2012, 45 (3), 337−346. 

(12) Rozlosnik, N.; Gerstenberg, M. C.; Larsen, N. B. Effect of Solvents and Concentration on the Formation of a Self-Assembled Monolayer of Octadecylsiloxane on Silicon (001). Langmuir 2003, 19 (4), 1182−1188. 

(13) Johnson, R. W.; Hultqvist, A.; Bent, S. F. A Brief Review of Atomic Layer Deposition: From Fundamentals to Applications. Mater. Today 2014, 17 (5), 236−246. 

(14) Zardetto, V.; Williams, B. L.; Perrotta, A.; Di Giacomo, F.; Verheijen, M. A.; Andriessen, R.; Kessels, W. M. M. M.; Creatore, M. Atomic Layer Deposition for Perovskite Solar Cells: Research Status, Opportunities and Challenges. Sustain. Energy Fuels 2017, 1 (1), 30− 55. 

(15) Brinkmann, K. O.; Gahlmann, T.; Riedl, T. Atomic Layer Deposition of Functional Layers in Planar Perovskite Solar Cells. Sol. RRL 2020, 4 (1), 1900332. 

(16) Xing, Z.; Xiao, J.; Hu, T.; Meng, X.; Li, D.; Hu, X.; Chen, Y. Atomic Layer Deposition of Metal Oxides in Perovskite Solar Cells: Present and Future. Small Methods 2020, 4 (12), 2000588. 

(17) Raiford, J. A.; Oyakhire, S. T.; Bent, S. F. Applications of Atomic Layer Deposition and Chemical Vapor Deposition for Perovskite Solar Cells. Energy Environ. Sci. 2020, 13 (7), 1997−2023. 

(18) Chen, W.; Wu, Y.; Fan, J.; Djurisič , A. B.; Liu, F.; Tam, H. W.;́ Ng, A.; Surya, C.; Chan, W. K.; Wang, D.; He, Z. B. Understanding the Doping Effect on NiO: Toward High-Performance Inverted Perovskite Solar Cells. Adv. Energy Mater. 2018, 8 (19), 1703519. 

(19) Chen, W.; Zhou, Y.; Wang, L.; Wu, Y.; Tu, B.; Yu, B.; Liu, F.; Tam, H. W.; Wang, G.; Djurišic,́ A. B.; Huang, L.; He, Z. MoleculeDoped Nickel Oxide: Verified Charge Transfer and Planar Inverted Mixed Cation Perovskite Solar Cell. Adv. Mater. 2018, 30 (20), 1800515. 

(20) Nie, W.; Tsai, H.; Blancon, J.-C. C.; Liu, F.; Stoumpos, C. C.; Traore, B.; Kepenekian, M.; Durand, O.; Katan, C.; Tretiak, S.; et al. Critical Role of Interface and Crystallinity on the Performance and Photostability of Perovskite Solar Cell on Nickel Oxide. Adv. Mater. 2018, 30 (5), 1703879. 

(21) Bush, K. A.; Palmstrom, A. F.; Yu, Z. J.; Boccard, M.; Cheacharoen, R.; Mailoa, J. P.; McMeekin, D. P.; Hoye, R. L. Z.; Bailie, C. D.; Leijtens, T.; Peters, I. M.; Minichetti, M. C.; Rolston, N.; Prasanna, R.; Sofia, S.; Harwood, D.; Ma, W.; Moghadam, F.; Snaith, H. J.; Buonassisi, T.; Holman, Z. C.; Bent, S. F.; McGehee, M. D. 23.6%-Efficient Monolithic Perovskite/Silicon Tandem Solar Cells With Improved Stability. Nat. Energy 2017, 2 (4), 1−7. 

(22) Jošt, M.; Bertram, T.; Koushik, D.; Marquez, J. A.; Verheijen, M. A.; Heinemann, M. D.; Köhnen, E.; Al-Ashouri, A.; Braunger, S.; Lang, F.; Rech, B.; Unold, T.; Creatore, M.; Lauermann, I.; Kaufmann, C. A.; Schlatmann, R.; Albrecht, S. 21.6%-Efficient Monolithic Perovskite/Cu(In,Ga)Se2 Tandem Solar Cells with Thin Conformal Hole Transport Layers for Integration on Rough Bottom Cell Surfaces. ACS Energy Lett. 2019, 4 (2), 583−590. 

(23) Chen, W.; Wu, Y.; Yue, Y.; Liu, J.; Zhang, W.; Yang, X.; Chen, H.; Bi, E.; Ashraful, I.; Grätzel, M.; Han, L. Efficient and Stable LargeArea Perovskite Solar Cells with Inorganic Charge Extraction Layers. Science (Washington, DC, U. S.) 2015, 350 (6263), 944−948. 

(24) Koushik, D.; Jošt, M.; Ducinskas, A.; Burgess, C.; Zardetto, V.;̌ Weijtens, C.; Verheijen, M. A.; Kessels, W. M. M.; Albrecht, S.; Creatore, M. Plasma-Assisted Atomic Layer Deposition of Nickel 

Oxide as Hole Transport Layer for Hybrid Perovskite Solar Cells. J. Mater. Chem. C 2019, 7 (40), 12532−12543. 

(25) Di Girolamo, D.; Di Giacomo, F.; Matteocci, F.; Marrani, A. G.; Dini, D.; Abate, A. Progress, Highlights and Perspectives on NiO in Perovskite Photovoltaics. Chem. Sci. 2020, 11 (30), 7746−7759. 

(26) Głowienka, D.; Zhang, D.; Di Giacomo, F.; Najafi, M.; Veenstra, S.; Szmytkowski, J.; Galagan, Y. Role of Surface Recombination in Perovskite Solar Cells at the Interface of HTL/ CH3NH3PbI3. Nano Energy 2020, 67, 104186. 

(27) Di Girolamo, D.; Matteocci, F.; Kosasih, F. U.; Chistiakova, G.; Zuo, W.; Divitini, G.; Korte, L.; Ducati, C.; Di Carlo, A.; Dini, D.; Abate, A. Stability and Dark Hysteresis Correlate in NiO-Based Perovskite Solar Cells. Adv. Energy Mater. 2019, 9 (31), 1901642. 

(28) Boyd, C. C.; Shallcross, R. C.; Moot, T.; Kerner, R.; Bertoluzzi, L.; Onno, A.; Kavadiya, S.; Chosy, C.; Wolf, E. J.; Werner, J.; et al. Overcoming Redox Reactions at Perovskite-Nickel Oxide Interfaces to Boost Voltages in Perovskite Solar Cells. Joule 2020, 4, 1759−1775. (29) D’Amario, L.; Föhlinger, J.; Boschloo, G.; Hammarström, L. Unveiling Hole Trapping and Surface Dynamics of NiO Nanoparticles. Chem. Sci. 2018, 9 (1), 223−230. 

(30) Yue, S.; Liu, K.; Xu, R.; Li, M.; Azam, M.; Ren, K.; Liu, J.; Sun, Y.; Wang, Z.; Cao, D.; Yan, X.; Qu, S.; Lei, Y.; Wang, Z. Efficacious Engineering on Charge Extraction for Realizing Highly Efficient Perovskite Solar Cells. Energy Environ. Sci. 2017, 10 (12), 2570−2578. 

(31) Di Girolamo, D.; Phung, N.; Jošt, M.; Al-Ashouri, A.; Chistiakova, G.; Li, J.; Márquez, J. A.; Unold, T.; Korte, L.; Albrecht, S.; Di Carlo, A.; Dini, D.; Abate, A. From Bulk to Surface: Sodium Treatment Reduces Recombination at the Nickel Oxide/ Perovskite Interface. Adv. Mater. Interfaces 2019, 6 (17), 1900789. 

(32) Wang, Q.; Chueh, C.-C.; Zhao, T.; Cheng, J.; Eslamian, M.; Choy, W. C. H.; Jen, A. K. Y. Effects of Self-Assembled Monolayer Modification of Nickel Oxide Nanoparticles Layer on the Performance and Application of Inverted Perovskite Solar Cells. ChemSusChem 2017, 10 (19), 3794−3803. 

(33) Zhang, J.; Luo, H.; Xie, W.; Lin, X.; Hou, X.; Zhou, J.; Huang, S.; Ou-Yang, W.; Sun, Z.; Chen, X. Efficient and Ultraviolet Durable Planar Perovskite Solar Cells: Via a Ferrocenecarboxylic Acid Modified Nickel Oxide Hole Transport Layer. Nanoscale 2018, 10 (12), 5617−5625. 

(34) Bai, Y.; Chen, H.; Xiao, S.; Xue, Q.; Zhang, T.; Zhu, Z.; Li, Q.; Hu, C.; Yang, Y.; Hu, Z.; Huang, F.; Wong, K. S.; Yip, H. L.; Yang, S. Effects of a Molecular Monolayer Modification of NiO Nanocrystal Layer Surfaces on Perovskite Crystallization and Interface Contact toward Faster Hole Extraction and Higher Photovoltaic Performance. Adv. Funct. Mater. 2016, 26 (17), 2950−2958. 

(35) Chen, W.; Zhou, Y.; Chen, G.; Wu, Y.; Tu, B.; Liu, F. Z.; Huang, L.; Ng, A. M. C.; Djurišic,́ A. B.; He, Z. Alkali Chlorides for the Suppression of the Interfacial Recombination in Inverted Planar Perovskite Solar Cells. Adv. Energy Mater. 2019, 9 (19), 1803872. 

(36) Mann, D. S.; Patil, P.; Kwon, S.-N.; Na, S.-I. Enhanced Performance of P-i-n Perovskite Solar Cell via Defect Passivation of Nickel Oxide/Perovskite Interface with Self-Assembled Monolayer. Appl. Surf. Sci. 2021, 560, 149973. 

(37) Ulman, A. Formation and Structure of Self-Assembled Monolayers. Chem. Rev. 1996, 96 (4), 1533−1554. 

(38) Bardecker, J. A.; Ma, H.; Kim, T.; Huang, F.; Liu, M. S.; Cheng, Y. J.; Ting, G.; Jen, A. K. Y. Self-Assembled Electroactive Phosphonic Acids on ITO: Maximizing Hole-Injection in Polymer Light-Emitting Diodes. Adv. Funct. Mater. 2008, 18 (24), 3964−3971. 

(39) Yang, H.; Park, H.; Kim, B.; Park, C.; Jeong, S.; Chae, W.; Kim, W.; Jeong, M.; Ahn, T. K.; Shin, H. Unusual Hole Transfer Dynamics of the NiO Layer in Methylammonium Lead Tri-Iodide Absorber Solar Cells. J. Phys. Chem. Lett. 2021, 12, 2770−2779. 

(40) Shao, Y.; Xiao, Z.; Bi, C.; Yuan, Y.; Huang, J. Origin and Elimination of Photocurrent Hysteresis by Fullerene Passivation in CH3NH3PbI3 planar Heterojunction Solar Cells. Nat. Commun. 2014, 5, 1−7. 

(41) Xu, J.; Boyd, C. C.; Yu, Z. J.; Palmstrom, A. F.; Witter, D. J.; Larson, B. W.; France, R. M.; Werner, J.; Harvey, S. P.; Wolf, E. J.; 

2175 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

<u>ACS Applied Materials & Interfaces</u> 

<mark>Research Article</mark> 

<mark>www.acsami.org</mark> 

Weigand, W.; Manzoor, S.; van Hest, M. F. A. M.; Berry, J. J.; Luther, J. M.; Holman, Z. C.; McGehee, M. D. Triple-Halide Wide−Band Gap Perovskites with Suppressed Phase Segregation for Efficient Tandems. Science (Washington, DC, U. S.) 2020, 367 (6482), 1097− 1104. 

(42) Moulder, J. F.; Stickle, W. F.; P.E, S.; Bomben, K. D. Handbook of X-Tay Photoelectron Spectroscopy; Perkin-Elmer Corp., 1992. 

(43) Sun, J.; Shou, C.; Sun, J.; Wang, X.; Yang, Z.; Chen, Y.; Wu, J.; Yang, W.; Long, H.; Ying, Z.; Yang, X.; Sheng, J.; Yan, B.; Ye, J. NiOXseeded Self-assembled Monolayers as Highly Hole-selective Passivating Contacts for Efficient Inverted Perovskite Solar Cells. Sol. RRL 2021, 5, 2100663. 

Spectroscopy Study of Indium Tin Mixed Oxides on the Surface of Silicate Glass. Inorg. Mater. 2020, 56 (5), 482−493. 

(59) Wang, Q.; Smith, J. A.; Skroblin, D.; Steele, J. A.; Wolff, C. M.; Caprioglio, P.; Stolterfoht, M.; Köbler, H.; Li, M.; Turren-Cruz, S.-H.; Gollwitzer, C.; Neher, D.; Abate, A. Managing Phase Purities and Crystal Orientation for High-Performance and Photostable Cesium Lead Halide Perovskite Solar Cells. Sol. RRL 2020, 4 (9), 2000213. 

(60) Rakocevic, L.; Ernst, F.; Yimga, N. T.; Vashishtha, S.; Aernouts, T.; Heumueller, T.; Brabec, C. J.; Gehlhaar, R.; Poortmans, J. Reliable Performance Comparison of Perovskite Solar Cells Using Optimized Maximum Power Point Tracking. Sol. RRL 2019, 3 (2), 1800287. 

(44) Pawsey, S.; McCormick, M.; De Paul, S.; Graf, R.; Lee, Y. S.; Reven, L.; Spiess, H. W. 1 H Fast MAS NMR Studies of HydrogenBonding Interactions in Self-Assembled Monolayers. J. Am. Chem. Soc. 2003, 125 (14), 4174−4184. 

(45) Brodard-Severac, F.; Guerrero, G.; Maquet, J.; Florian, P.; Gervais, C.; Mutin, P. H. High-Field<sup>17</sup> O MAS NMR Investigation of Phosphonic Acid Monolayers on Titania. Chem. Mater. 2008, 20 (16), 5191−5196. 

(46) Timpel, M.; Li, H.; Nardi, M. V.; Wegner, B.; Frisch, J.; Hotchkiss, P. J.; Marder, S. R.; Barlow, S.; Brédas, J.; Koch, N. Electrode Work Function Engineering with Phosphonic Acid Monolayers and Molecular Acceptors: Charge Redistribution Mechanisms. Adv. Funct. Mater. 2018, 28 (8), 1704438. 

(47) Greene, J. E. Tracing the 4000 Year History of Organic Thin Films: From Monolayers on Liquids to Multilayers on Solids. Appl. Phys. Rev. 2015, 2 (1), 011101. 

(48) Love, J. C.; Estroff, L. A.; Kriebel, J. K.; Nuzzo, R. G.; Whitesides, G. M. Self-Assembled Monolayers of Thiolates on Metals as a Form of Nanotechnology. Chem. Rev. 2005, 105 (4), 1103−1170. 

(49) Prato, M.; Moroni, R.; Bisio, F.; Rolandi, R.; Mattera, L.; Cavalleri, O.; Canepa, M. Optical Characterization of Thiolate SelfAssembled Monolayers on Au(111). J. Phys. Chem. C 2008, 112 (10), 3899−3906. 

(50) Magomedov, A.; Al-Ashouri, A.; Kasparavičius, E.; Strazdaite, S.; Niaura, G.; Jošt, M.; Malinauskas, T.; Albrecht, S.; Getautis, V. Self-Assembled Hole Transporting Monolayer for Highly Efficient Perovskite Solar Cells. Adv. Energy Mater. 2018, 8 (32), 1801892. 

(51) Tompkins, H. G.; Hilfiker, J. N. Spectroscopic Ellipsometry: Practical Application to Thin Film Characterization; Momentum Press, 2015. 

(52) Arwin, H.; Aspnes, D. E. Determination of Optical Properties of Thin Organic Films by Spectroellipsometry. Thin Solid Films 1986, 138 (2), 195−207. 

(53) Williams, B. L.; Smit, S.; Kniknie, B. J.; Bakkers, N. J.; Kessels, W. M. M.; Schropp, R. E. I.; Creatore, M. Identifying Parasitic Current Pathways in CIGS Solar Cells by Modelling Dark JV Response. IEEE Photovoltaic Spec. Conf., 40th 2014, 23, 1729−1734. (54) Blaga, C.; Christmann, G.; Boccard, M.; Ballif, C.; Nicolay, S.; Kamino, B. A. Palliating the Efficiency Loss Due to Shunting in Perovskite/Silicon Tandem Solar Cells through Modifying the Resistive Properties of the Recombination Junction. Sustain. Energy Fuels 2021, 5 (7), 2036−2045. 

(55) Saliba, M.; Matsui, T.; Seo, J.-Y. Y.; Domanski, K.; CorreaBaena, J.-P. P.; Nazeeruddin, M. K.; Zakeeruddin, S. M.; Tress, W.; Abate, A.; Hagfeldt, A.; Grätzel, M. Cesium-Containing Triple Cation Perovskite Solar Cells: Improved Stability, Reproducibility and High Efficiency. Energy Environ. Sci. 2016, 9 (6), 1989−1997. 

(56) Saliba, M.; Correa-Baena, J.-P.; Wolff, C. M.; Stolterfoht, M.; Phung, N.; Albrecht, S.; Neher, D.; Abate, A. How to Make over 20% Efficient Perovskite Solar Cells in Regular (n−i−p) and Inverted (p− i−n) Architectures. Chem. Mater. 2018, 30 (13), 4193−4201. 

(57) Biesinger, M. C.; Payne, B. P.; Lau, L. W. M.; Gerson, A.; Smart, R. S. C. X-Ray Photoelectron Spectroscopic Chemical State Quantification of Mixed Nickel Metal, Oxide and Hydroxide Systems. Surf. Interface Anal. 2009, 41 (4), 324−332. 

(58) Teterin, Y. A.; Maslakov, K. I.; Murav’ev, E. N.; Teterin, A. Y.; Bulychev, N. A.; Meshkov, B. B.; Stepnov, D. S. X-Ray Photoelectron 

2176 

https://doi.org/10.1021/acsami.1c15860 ACS Appl. Mater. Interfaces 2022, 14, 2166−2176 

