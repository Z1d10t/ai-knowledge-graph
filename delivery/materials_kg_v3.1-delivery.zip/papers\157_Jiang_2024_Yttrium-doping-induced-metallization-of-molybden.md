# Yttrium-doping-induced metallization of molybdenum disulfide for ohmic contacts in two-dimensional transistors

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Electronics |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 186 |
| 作者 | Jianfeng Jiang, Lin Xu, Luo-Jun Du, Lu Li, Guang-Yu Zhang, Chen-Guang Qiu, Lian-Mao Peng |
| DOI | 10.1038/s41928-024-01176-2 |
| 源文件 | 057_Jiang_2024_Yttrium-doping-induced-metallization-of-molybden.pdf |

---




<!-- Start of picture text -->
Yttrium -i nduced phase -t ransition technology for<br>forming perfect ohmic contact in two -d imensional<br>MoS  transistors<br>2<br><!-- End of picture text -->

Peking University 

Hong Kong Polytechnic University 

Institute of Physics, Chinese Academy of Sciences 

Institute of physics, Chinese Academy of Sciences 

Beijing National Laboratory for Condensed Matter Physics, Institute of Physics, Chinese Academy of Sciences https://orcid.org/0000-0002-1242-4391 

Peking University https://orcid.org/0000-0001-6390-593X 



Peking University https://orcid.org/0000-0003-0754-074X 

Posted Date: February 8th, 2023 

DOI: https://doi.org/10.21203/rs.3.rs-2508636/v1 

License:   This work is licensed under a Creative Commons Attribution 4.0 International License. Read Full License 

Additional Declarations: There is NO Competing Interest. 

Page 1/24 

Version of Record: A version of this preprint was published at Nature Electronics on May 27th, 2024. See the published version at https://doi.org/10.1038/s41928-024-01176-2. 

Page 2/24 

The van der Waals (vdW) strategy is promising for overcoming the Fermi pinning challenge in twodimensional (2D) transistors. However, the lack of advanced-node lithography-compatible methods hinders wafer-scale integrated manufacturing of vdW contacts. We report a yttrium-doping-induced phase-transition technology for converting semiconducting trigonal prismatic (2H) into heavily doped metallic octahedral (1T) MoS2 to achieve suitable vdW band alignment and ideal ohmic contacts. This Y- doped 1T-MoS2 is a vdW metallic buffer, and it improves carrier transfer e�ciency from the metal electrode to 2H MoS2. We developed a solid-state-source three-step doping method (plasma-depositionannealing) and achieved Å-thickness surface doping with yttrium atoms replacing sulfur atoms in the top surface of MoS2, thus forming self-aligned Y-doped 1T-MoS2 vdW ohmic contacts lithographically patterned in the source and drain regions. We fabricated 10-nm MoS2 FETs with Y-doped 1T-MoS2 vdW contacts in 2-inch wafers exhibiting nearly ideal ohmic contact with an ignorable Schottky barrier, achieved the smallest contact-resistance Rc in all 2D TMD FETs (less than 117-ohm micrometers) and a total-resistance (235-ohm micrometers) more than three times smaller than those of the best-reported 2D n-type FETs (greater than 800-ohm micrometers), showing high performance with an excellent oncurrent density of 1.22 milliamperes per micrometer at a small drain voltage of 0.7 V, a high ballistic ratio of 80%, and a record transconductance of 3.2 millisiemens per micrometer. 

Solid-state-source yttrium-doping-induced phase-transition technology enables wafer-scale 10-nm ballistic MoS2 FETs to approach the ideal ohmic contact and performance limits. 

Silicon technology is quickly approaching its fundamental limits at the sub-10 nanometer node predicted by the International Roadmap for Devices and Systems (IRDS)<sup>1</sup> . Further scaling of �eld-effect transistors (FETs) requires new channel materials<sup>2-12</sup> . Two-dimensional (2D) semiconductors have two intrinsic electronic advantages, ultrathin bodies, and high carrier mobilities<sup>13-18</sup> , which allow better electrostatic control and on-state performance in short-channel FETs<sup>19-24</sup> . However, the high contact resistance resulting from the Fermi-pinning effect introduced by nonideal interfaces through conventional metal physical vapor deposition, is one of the main obstacks limiting the on-state performance of 2D transistors<sup>25-30</sup> . Van der Waals contact can in principle effectively avoid Fermi pinning, and many attempts have been made to improve the contact, such as using mechanical transfer of metal �lms<sup>31,32</sup> , low-thermal deposition (indium, semimetal bismuth, etc.)<sup>33-35</sup> , and contact phase transition through laser-induced or chemical treatments<sup>36,37</sup> . But, the total-resistances of all 2D transistors are still greater than 800 ohms per micrometer, and this does not meet the standard for commercial advanced-node silicon transistors (250-ohm micrometers by IRDS)<sup>1</sup> , and wafer-scale advanced-nodes lithographypatterned van der Waals contacts is desired. 

Page 3/24 

We �rst examine the mature structure of commercial silicon transistors, aiming to �nd a method with which to realize wafer-scale ohmic contact engineering in 2D electronics. In a commercial silicon transistor, the contact structure is sophistically designed to decrease the contact resistance, which includes the metal electrode, heavily doped source and drain extension regions, and a crucial metal silicide thin layer, such as TiSi or CoSi, which acts as a buffer between the metal electrode and heavily doped silicon, as shown in Fig. 1a<sup>1,38</sup> , thus improving the carrier transfer e�ciency and decreasing the series contact resistance. The silicides are formed by alloying a surface silicon layer through the deposition of an ultrathin metal layer and annealing. This classical structure and the corresponding standard silicide process have always accompanied the scaling of silicon transistors, which have followed Moore’s law from the micrometer nodes in the 1970s to the state-of-the-art sub-10 nm nodes today. In this work, we explore a suitable metallic 2D buffer layer sandwiched between the metal electrode and the 2D semiconductor, which plays a role similar to that of the “silicide” structure in silicon transistors to improve the carrier transfer e�ciency, as illustrated in Fig. 1b. This metallic 2D buffer is formed with a mechanism that we named “yttrium-doping-induced phase-transition technology” and is fabricated through a phase transition in homogenous 2D materials in locally lithography-patterned source and drain regions. The van der Waals interface between this metallic 2D buffer and 2D semiconductor avoids lattice degradation and does not introduce additional Fermi pinning. During the preparation of this contact, we developed a wafer-scale three-step Y-doping integrated process named “plasma-deposition-annealing” as a potential way to achieve Å-thickness ultrathin doping and Y-dopinginduced 1T phase transition in the local source and drain regions de�ned through lithography patterning (note: conventional ion implantation gives doping depths of not less than 5 nm, which is inapplicable to surface doping in low-dimensional semiconductors)<sup>39,40</sup> . Then, we adopted this Y-doping-induced phasetransition van der Waals ohmic contact engineering to fabricate 10-nm gate length MoS2 transistors in 2- inch CVD wafers. The scaled MoS2 FETs exhibit the smallest contact-resistance RC of less than 117-ohm micrometers in all 2D TMD FETs, a total-resistance of 235-ohm micrometers, which is more than three times smaller than the best-reported 2D n-type FETs (over 800-ohm micrometers), a large on-current density of 1.22 milliamperes per micrometer at a small drain voltage of 0.7 V, and more importantly, a record transconductance of 3.2 millisiemens per micrometer. 

In some previous reports, the 2H-to-1T phase transitions of transition metal dichalcogenides (TMDs) in source and drain regions seemed to be the closest 2D metallic buffer strategy, including laser-induced, plasma-induced or chemical lithium ion-induced<sup>36,37,41</sup> ; unfortunately, however, the Fermi levels of all the 1T metallic phase TMDs (MX2, M=Mo, W; X= S, Se, Te) lie in the middle of the bandgaps of their corresponding homologous 2H semiconducting phase TMDs, which inherently causes a large Schottky barrier between the 2H phase and 1T phase TMDs (Fig. 1c)<sup>42-47</sup> . This occurs because the total number of conduction and valence electrons is conserved during the phase-transition process, so the Fermi level shifts only slightly before or after the phase transition. Therefore, introducing suitable dopants into 1T phase 2D semimetals is required to provide adequate excess electrons or holes and thus move the Fermi level of the 1T phase 2D semimetals to become higher than the conduction band minimum (CBM) or lower than the valence band maximum (VBM) of 2H phase 2D semiconductors to form the appropriate 

Page 4/24 

band alignment and thus the ideal ohmic contact. Here, we choose the rare-earth element yttrium (Y) as the dopant for 2D MoS2, and density functional theory (DFT) results show that the con�guration of Y atoms replacing S atoms requires less formation energy (1.42 eV) and was more stable than that of Y atoms replacing Mo atoms (1.67 eV). Fig. 1d shows the band structure of the Y-doped 1T-MoS2 obtained by DFT, which con�rms the zero-bandgap semimetal characteristic with the CBM and VBM coinciding in the Brillouin zone. The band structures of intrinsic 2H-MoS2 and 1T-MoS2 are shown in Extended Data Fig. 1. Our DFT calculations show that when increasing the Y atom doping density to nearly 8%, adequate excess electrons are added to elevate the Fermi level of 1T phase 2D MoS2, causing the work function of Y-doped 1T-MoS2 (4.0 eV) to be smaller than the electron a�nity of intrinsic 2H-MoS2 (4.3 eV); thus, an ideal ohmic contact at the junction of Y-doped 1T-MoS2 and 2H-MoS2 is predicted theoretically. In comparison, the work function of the intrinsic metallic 1T-MoS2 is 5.1 eV, and the Fermi level is located in the middle of the band gap of semiconducting 2H-MoS2, causing a larger Schottky barrier (Fig. 1c). In addition, compared to conventional metal contacts (such as Ti, etc.), which induce signi�cant metalinduced gap states (MIGS), semimetallic Y-doped 1T-MoS2 in contact with 2H-MoS2 has negligible MIGS and thus almost no additional Fermi pinning; it bene�ts from the native ideal van der Waals interface and much smaller density of states (DOS) for the semimetal at the Fermi energy level (Fig. 1e). Furthermore, to understand how Y-doping affects the dynamic mechanism of the phase transition, the nudged elastic band (NEB) method was adopted to calculate the energy barrier for the phase transition from the 2H to the 1T structure of MoS2, as shown in Figs. 1f and 1g. The result shows that the barrier from 2H-MoS2 to 1T-MoS2 is 1.57 eV. By comparison, the barrier from 2H-MoS2 to Y-doping-induced 1T-MoS2 (Y-T-MoS2) is reduced to 0.34 eV when some S atoms are substituted by Yatoms. This indicates that Y atom doping favorably induces the phase-transition process since the smaller energy barrier in the Y-doped system means that the 2H-to-1T phase transition would occur more easily. On the other hand, there is a large energy difference between intrinsic 1T-MoS2 and Y-T-MoS2. Note that 1T-MoS2 is a metastable metallic phase, and its structural energy is 0.83 eV higher than that of the original stable-phase 2H-MoS2, meaning possible reversion into 2H when undergoing the following device fabrication process. After Y- doping, the structural energy of Y-T-MoS2 decreases to approximately 0.8 eV lower than that of intrinsic 1T-MoS2 and thus forms stable-metallic-phase Y-T-MoS2. Therefore, Y-doping is an effective strategy for achieving reliable ohmic contact, not only inducing the phase transition and stabilizing the 1T-metallicphase but also elevating the Fermi level of 1T-MoS2. 

Next, we consider to �nd a fabrication process to achieve Y-doping into the MoS2 structure. Note that local doping in 2D materials in the source and drain regions through lithography patterning is extremely di�cult and has not been reported thus far. This is because the atomic 2D materials are too thin to use the normal ion-implantation and dopant-activation process, and sub-5 nm-thick ion-implantation engineering is not yet achieved in Foundries<sup>39,40</sup> . Here, we have developed a three-step process called plasma-deposition-annealing (PDA) method to achieve yttrium doping in the surface layer of MoS2 (Fig. 2a). First, the patterned local contact areas were treated with low-power (9 watts, 15 seconds) argon soft plasma to modify the contact interface and generate active sites. This low-power soft plasma �ltering of 

Page 5/24 

energetic particles induces trace amounts of sulfur vacancies on the surface of the top-layer MoS2 without damaging the overall lattice of the 2D MoS2. Next, a 1/5/7 nm-thick Y/Ti/Au stacked metal was deposited by electron beam evaporation in high vacuum (<1×10<sup>-8</sup> Torr), and the 1 nm-thick active metal Y was used as a solid-state doping source. Finally, Y atoms diffused toward active sites of the plasmainduced sulfur vacancies and were activated in the top layer of MoS2 using high-temperature annealing (250 ℃ for 30 min) in an inert gas environment. Due to the utilization of hyper�ne patterned structures, great thermal stability after annealing, and all-solid-state nature, this PDA doping process is compatible with advanced-node wafer-scale integration. 

Fig. 2b shows optical images of wafer-scale 2D MoS2 �lms used to fabricate our transistors grown by layer-by-layer epitaxy on sapphire substrates<sup>48</sup> . High-angle annular dark �eld (HAADF) scanning transmission electron microscopy (STEM) imaging show a clear lattice structure and atomically clean and sharp interfaces, con�rming the high quality of the MoS2 �lms (Fig. 2 and Extended Data Fig. 2). Compared to monolayer MoS2, trilayer MoS2 has a smaller bandgap, a smaller effective mass, and higher thermal velocity and mobility, making it more suitable for use as a channel material in high-performance electronics<sup>20,48</sup> . Therefore, the devices focused on in this work are mainly based on high-quality trilayer MoS2 channels. We conducted yttrium doping into MoS2, and the STEM image and electron energy-loss spectroscopy (EELS) maps in Figs. 2c-e demonstrates the cross-sectional atomic structure and elemental composition of Y-doped 1T-MoS2. Each layer of intrinsic MoS2 is composed of a layer of Mo atoms and two layers of S atoms above and below, and the Mo atoms appear brighter than the S atoms in the STEM image due to the different atomic numbers (Z-contrast). After the yttrium-PDA process, the uppermost S atoms of MoS2 were partially replaced by bright Y atoms (Fig. 2c, right), and this was further con�rmed by elemental analysis, which showed a signi�cant Y element signal in the top layer of MoS2 (Fig. 2d, e), which provides strong evidence for Y-doping and partial replacement of top surface S atoms. After the selective removal of excess Y metal by a wet process, Raman spectroscopy and X-ray photoelectron spectroscopy (XPS) were used to exhibit the following signi�cant differences between the Y-doped 1T-MoS2 and intrinsic 2H-MoS2: i) The Y-doped MoS2 showed a signi�cant Y XPS signal (different from the pure Y metal binding energy) after removal of the excess Y metal from the surface (Fig. 2f, left), which further proved that yttrium atoms were doped and activated in MoS2; ii) The XPS peaks for both Mo and S were shifted in the direction of lower energies after Y doping, which again provided strong evidence for the Y-doping-induced metallic 1T phase transition (Fig. 2f, middle)<sup>37,41,49-52</sup> . In addition, the XPS spectra obtained for the surface of the Y, MoS2, and Y-doped MoS2 samples all had C 1s peaks corrected to 284.8 eV (Fig. 2f, right); iii) The Y-doped MoS2 had three more new peaks, J1 (167 cm<sup>-1</sup> ), J2 (227 cm<sup>-1</sup> ), and J3 (334 cm<sup>-1</sup> ), in the Raman spectrum, demonstrating the characteristics of the 1T semimetal phase (Fig. 2g)<sup>37,41,49-52</sup> . Fig. 2h shows four typical output characteristics of ballistic MoS2 FETs after annealing activation at different temperatures, which corresponds to no activation (at room temperature, RT), partial activation (at 150 ℃ and 200 ℃), and full activation (at 250 ℃) of the yttrium dopants. The unannealed MoS2 FET exhibited an extremely high Schottky barrier (total resistance of 

Page 6/24 

~1×10<sup>5</sup> Ω·μm, bottom blue curve), while the MoS2 FET with full dopant activation achieved the desired ohmic contact (total-resistance of ~235 Ω·μm, top red curve) for ballistic transistors. The electrical transport measurement provides the most direct evidence, and it also showed that the device containing Y-doped 1T-MoS2 as the channel exhibited semimetallic modulation with an on/off current ratio of less than 10, while the device with an intrinsic semiconducting 2H MoS2 channel exhibited an on/off current ratio of greater than 10<sup>8</sup> (Fig. 2i). 

Fig. 3a shows a schematic drawing of the 2D MoS2 FET structure used in this work. A cross-sectional STEM image and the corresponding EELS map of our ballistic MoS2 transistor are shown in Figs. 3b and 3c, and these results con�rm the location of the 2-nm-thick trilayer MoS2 channel, the 10-nm channel length (10-nm back-gate length and 5 nm top-gate length), 2.6-nm-thick HfO2 dielectrics for both the top and bottom gates formed by atomic layer deposition (ALD), the source/drain/gate electrodes, and a thin layer of yttrium in the contact area. The dual-gate leakage currents are shown in Extended Data Fig. 3. 

Our ohmic-contact ballistic 10-nm MoS2 FET exhibited a constant on-state current over a wide temperature range from 300 K to 100 K (Fig. 3d) in the transfer characteristics, which is the �rst time that this has been observed in short-channel MoS2 transistors, providing strong evidence of the near-zero Schottky barrier in our devices<sup>53</sup> . Moreover, the Schottky barrier height (SBH) was extracted via Arrhenius plots from the temperature-variable transfer characteristics of our ballistic FET and showed to approach the theoretical limit (Extended Data Fig. 4). In a typical ballistic unoptimized Schottky-barrier MoS2 FET using a conventional Ti/Au metal contact, there exist two slopes below the threshold in the FET transfer characteristics determined at a low temperature of 100 K (Fig. 3e and Extended Data Fig. 5). The lower part consists only of thermal emission (TE) current determined by the channel potential, and it exhibits a smaller subthreshold swing (SS)<sup>54</sup> . The upper part consists of the thermal �eld emission (TFE) current and shows poor SS due to gate-modulated Schottky barrier tunneling<sup>26</sup> . Furthermore, the case of the intrinsically undoped 1T-MoS2 contact using only the argon plasma-induced phase transition, as reported in the literature (after 40 s treatment), also exhibits a large Schottky barrier as shown for comparison in Fig. 3e (gray hollow dot) and Extended Data Fig. 5<sup>41,55</sup> . Although the ideal van der Waals interface without Fermi pinning makes the undoped 1T-MoS2 contact better than the conventional Ti/Au contact in MoS2 FETs (purple hollow dot, Fig. 3e), the large Schottky barrier between undoped 1T-MoS2 and 2H-MoS2 still reduces the current to a much lower level than that in the case of the Y-doped 1T-MoS2 (blue solid dot, Fig. 3e). 

Typical saturation output characteristics (with maximum VGS) of our ballistic MoS2 transistors, compared with those of other reported sub-50 nm short-channel 2D TMD transistors, are shown in Fig. 3f<sup>19,20,34,35,56-61</sup> , and more details of our ballistic FETs are shown in Extended Data Figs. 6 and 7. The total resistance of our ballistic MoS2 transistors is more than three times smaller than those of the reported optimum sub-50 nm 2D n-type FETs, which allows a standard high current density of 1 mA/μm at much lower drain voltages below 0.5 V. Previous reports have consistently proven that the 

Page 7/24 

transmission line method (TLM) is not always accurate for extracting the contact resistance of a 2D transistor because of �uctuations in the large-channel resistances<sup>4,62</sup> . Since the total contact-resistance 2RC is approximately equal to the total-resistance Rtotal in a ballistic transistor, extracting the totalresistance in ballistic 2D FETs is thus a more reliable method than TLM for evaluating the contact resistance, as we have shown here<sup>28,31-34,56,63-65</sup> . 

The process �ow for wafer-scale 2D MoS2 FETs is depicted in Fig. 4a, and SEM images of an array of FETs based on the CVD trilayer MoS2 �lm and a typical 10-nm gate length dual-gate transistor are shown in Fig. 4b. Our ballistic MoS2 transistors exhibit advances in main electronic merits and are superior to the best-performance 2D TMD transistors previously reported (Fig. 4c)<sup>20,34,56</sup> . Fig. 4d shows the total resistances of �fty representative ballistic FETs, and the corresponding saturation output characteristics are shown in Extended Data Fig. 8; these demonstrate that our FETs have three times smaller totalresistance values than other 2D transistors, and the lowest total-resistance Rtotal can reach 235 Ω·μm (Fig. 4d), corresponding to a contact-resistance Rc less than 117 Ω·μm (Rtotal = RCH + 2RC). Fig. 4e shows typical transfer characteristics for our ballistic MoS2 FETs (LG=10 nm for the left, and LG=20 nm for the right) exhibiting ideal switching characteristics, including a SS of 63 mV/decade near the Boltzmann limit, a negligible drain-induced barrier lowering (DIBL) of 14 mV/V, and a large on/off current ratio of >10<sup>8</sup> , which satisfy the requirements for commercial standard-performance (SP) integrated circuits<sup>1</sup> . In addition, more typical electric data for ballistic transistors are shown in Extended Data Figs. 6 and 7, and the typical hysteresis of our ballistic FET is shown in Extended Data Fig. 9. To benchmark the overall switching behaviors of 2D FETs, we plotted the SS-IDS of our ballistic MoS2 FETs as well as those of other reported 2D sub-50 nm short-channel FETs<sup>19,56-61</sup> . Our 20 nm ballistic MoS2 transistors show an ideal SS close to the Boltzmann limit of 60 mV/decade across over four orders of magnitude for IDS, which is more than two orders of magnitude larger than that for other sub-50 nm short-channel 2D transistors. The transconductance determines the intrinsic gain and switching speed of a FET and is a more practical parameter for evaluating performance than the saturation current. In our MoS2 FETs, a scattering-free ballistic channel is combined with an ideal ohmic contact and an ultrathin 2.6 nm-HfO2 dual-gate structure to provide record transconductance (3.2 mS/μm) and transconductance rates (13 mS/μm·V), which are nearly an order of magnitude larger than those of other reported short-channel 2D TMD FETs (Figs. 4g and 4h)<sup>19,20,34,56-61</sup> . Fig. 4i shows the output characteristics of a typical 10 nm MoS2 FET and its corresponding standard virtual source model �tting, and the extracted room-temperature ballistic rate of our typical 10-nm MoS2 FET is close to 80%, which is signi�cantly higher than those of all previously reported silicon-based and other 2D transistors (Fig. 4j)<sup>66-68</sup> . The excellent overall electrical characteristics of our ballistic FETs are attributed to the low contact resistance that results from the van der Waals Y-doped 1T-MoS2 ohmic contact strategy. 

In summary, we propose a solid-state-source doping-induced 2D phase-transition technology that is compatible with advanced Å-nodes; it achieves reliable vdW ohmic contact for wafer-scale n-type MoS2 

Page 8/24 

transistors, and this strategy can in principle be extended to other 2D material systems. There remain, however, important challenges hindering the transfer of 2D semiconductor transistors from the laboratory to industry, these include CVD growth of wafer-scale single-crystal 2D materials, higher-quality gate stack structures, and complementary transistors fabricated with monolithic integration. Nevertheless, this work provides the �rst step toward pushing the switching and on-performance of wafer-scale ballistic 2D semiconductor transistors to the theoretical limit under ohmic contact, which con�rms the practical potential of 2D semiconductors in large-scale integrated circuits of future nodes. 



<!-- Start of picture text -->
Declarations<br>Acknowledgments:<br><!-- End of picture text -->

Funding: Supported by the National Key Research & Development Program of China (grant No. 2021YFA0717400) and the National Science Foundation of China (grants 61888102, 61971009 and 62122006). 

Author contributions: C.Q. and L.-M.P. proposed and supervised the project; C.Q., J.J., and L.-M.P. designed the experiment; J.J. performed Y-T-MoS2 material STEM, Raman and XPS characterization, device fabrication and device characterization and analysis; L.L., L.D, and G.Z. provided the 2-inch waferscale MoS2 materials; L.X. provided the �rst principles calculation and model �tting; J.J., C.Q., L.X., and L.-M.P. analyzed the experimental results and modeling results; J.J., C.Q. and L.-M.P. co-wrote the manuscript. All authors commented on and discussed this work. 

Competing interests: Authors declare that they have no competing interests. 

Data and materials availability: All data are available in the main text or the supplementary materials. 

1. IEEE International Roadmap for Devices and Systems<sup>TM</sup> . https://irds.ieee.org/editions 

2. Chhowalla, M., Jena, D., H. Zhang, Two-dimensional semiconductors for transistors. Nat. Rev. Mater. 1, 16052 (2016). 

3. Novoselov, K., Geim, A. K. et al. Electric �eld effect in atomically thin carbon �lms. Science 306, 666669 (2004). 

4. Liu, Y., Duan, X., Shin, H., Park, S., Huang, Y. & Duan, X. Promises and prospects of two-dimensional transistors. Nature 591, 43-53 (2021). 

5. Franklin, A. D. Nanomaterials in transistors: From high-performance to thin-�lm applications. Science 349, aab2750 (2015). 

- �. Akinwande, D., Huyghebaert, C., Wang, C.-H., Serna, M.I., Goossens, S., Li, L.-J., Wong, H.-S.P., Koppens, F.H.L. Graphene and two-dimensional materials for silicon technology. Nature 573, 507518 (2019). 

Page 9/24 

7. Peng, L.-M., Zhang, Z., Qiu, C. Carbon nanotube digital electronics. Nat. Electron. 2, 499-505 (2019). 

- �. Qiu, C., Peng, L.-M. et al., Scaling carbon nanotube complementary transistors to 5-nm gate lengths. Science 355, 271 (2017). 

9. Franklin, A. D., Chen, Z., Length scaling of carbon nanotube transistors. Nat. Nanotech. 5, 858 (2010). 

10. Qiu, C., Peng, L.-M. et al., Dirac-source �eld-effect transistors as energy-e�cient, high-performance electronic switches. Science 361, 387-392 (2018). 

11. Das, S., Sebastian, A., Pop, E., McClellan, C.J., Franklin, A.D., Grasser, T., Knobloch, T., Illarionov, Y., Penumatcha, A.V., Appenzeller, J., Chen, Z., Zhu, W., Asselberghs., I., Li, L.-J., Avci, U.E., Bhat, N., Anthopoulos, T.D., Singh, R. Transistors based on two-dimensional materials for future integrated circuits. Nat. Electron. 4, 786-799 (2021). 

12. Cao, Q., Tersoff, J., Farmer, D. B., Zhu, Y., Han, S. J. Carbon nanotube transistors scaled to a 40nanometer footprint. Science 356, 1369-1372 (2017). 

13. Radisavljevic, B., Radenovic, A., Brivio, I., Kis, A. Single-layer MoS2 transistors. Nat. Nanotech. 6, 147150 (2011). 

14. Su, S. K., Chuu, C.-P., Li, M., Cheng, C., Wong, H. -S. P., Li, L.J. Layered Semiconducting 2D Materials for Future Transistor Applications. Small Struct. 2000103 (2021). 

15. Yoon, Y., Ganapathi, K., Salahuddin, S. How good can monolayer MoS2 transistors be? Nano Lett. 11, 3768-3773 (2011). 

- 1�. Sarkar, D., Ajayan, P.M., Banerjee, K. et al., A subthermionic tunnel �eld-effect transistor with an atomically thin channel. Nature 526, 91-95 (2015). 

17. Liu, Y., Weiss, N.O., Duan, X., Cheng, H.-C., Huang, Y. & Duan, X. Van der Waals heterostructures and devices. Nat. Rev. Mater. 1, 16042 (2016). 

- 1�. Chhowalla, M., Liu, Z., Zhang, H. Two-dimensional transition metal dichalcogenide (TMD) nanosheets. Chem. Soc. Rev. 44, 2584-2586 (2015). 

19. Desai, S. B., Javey, A. et al., MoS2 transistors with 1-nanometer gate length. Science 354, 99 (2016). 

20. Liu, L., Li, T., Ma, L., Wang, J., Wang, X. et al. Uniform nucleation and epitaxy of bilayer molybdenum disul�de on sapphire. Nature 605, 69–75 (2022). 

21. Liu, Y., Duan, X., Huang, Y. & Duan, X. Two-dimensional transistors beyond graphene and TMDCs. Chem. Soc. Rev. 47, 6388-6409 (2018). 

22. Liu, L., Yang, L., Guo, J. On Monolayer MoS2 Field-Effect Transistors at the Scaling Limit. IEEE Trans. Electron Dev. 60, 4133-4139 (2013). 

23. Brien, K.P.O’, Metz, M., Avci, V. et al. Advancing 2D Monolayer CMOS Through Contact, Channel and Interface Engineering. IEDM Tech. Digest, 7.1.1-7.1.4 (2021). 

24. Li, M.-Y., Su, S.-K., Wong, H.S.P. & Li, L.-J. How 2D semiconductors could extend Moore’s law. Nature 567, 169-170 (2019). 

Page 10/24 

25. Allain, A., Kang, J., Banerjee, K., Kis, A. Electrical contacts to two-dimensional semiconductors. Nat. Mater. 14, 1195-1205 (2015). 

- 2�. Schulman, D. S., Arnold, A. J., Das, S. Contact engineering for 2D materials and devices. Chem. Soc. Rev. 47, 3037-3058 (2018). 

27. Kim, C., Shin, H.-J., Park, S., Yoo, W.J. et al. Fermi level pinning at electrical metal contacts of monolayer molybdenum dichalcogenides. ACS Nano 11, 1588–1596 (2017). 

- 2�. Das, S., Chen, H.-Y., Penumatcha, A. V., Appenzeller, J. High performance multilayer MoS2 transistors with scandium contacts. Nano Lett. 13, 100-105 (2013). 

29. McDonnell, S., Hinkle, C. L. et al., Defect-dominated doping and contact resistance in MoS2. ACS Nano 8, 2880-2888 (2014). 

30. Liu, W., Kang, Sarkar, D., Khatami, Y., J., Jena, D., Banerjee, K. Role of metal contacts in designing high-performance monolayer n-type WSe2 �eld effect transistors. Nano Lett. 13, 1983-1990 (2013) 

31. Y. Liu, J. Guo, E. Zhu, L. Liao, S. Lee, M. Ding, I. Shakir, V. Gambin, Y. Huang & X. Duan Nature 557, 696-700 (2018). 

32. Jung, Y., Choi, M.S., Yoo, W.J., Hone, J., Teherani, J. Y. et al., Transferred via contacts as a platform for ideal two-dimensional transistors. Nat. Electron. 2, 187-194 (2019). 

33. Wang, Y., Chhowalla, M. et al., Van der Waals contacts between three-dimensional metals and twodimensional semiconductors. Nature 568, 70-74 (2019). 

34. Shen, P. C., Li, L.-J., Kong, J. et al., Ultralow contact resistance between semimetal and monolayer semiconductors. Nature 593, 211-217 (2021). 

35. Chou, A., Wong, H.-S.P., Wang, H. et al., Antimony Semimetal Contact with Enhanced Thermal Stability for High Performance 2D Electronics IEDM Tech. Digest, 7.2.1-7.2.4 (2021). 

- 3�. Cho, S., Kim, Kim, S.W., S., Lee, Y., Yang, H. et al., Phase patterning for ohmic homojunction contact in MoTe2. Science 349, 625-628 (2015). 

37. Kappera, R., Mohite, A.D., Chhowalla, M. et al., Phase-engineered low-resistance contacts for ultrathin MoS2 transistors. Nat. Mater. 13, 1128-1134 (2014). 

- 3�. Gambina, J. P., Collgan, E. G. (IBM Microelectronics Division), Silicides and ohmic contacts. Mater. Chem. Phys. 52, 99-146 (1998). 

39. Zhao, Q. et al., Strained Si and SiGe nanowire tunnel FETs for logic and analog applications. IEEE J. Electron. Dev. Soc. 3, 103-114 (2015). 

40. Alzanki, T. et al., Nanotechnology Investigation of Ultra-shallow Junctions of Antimony (Sb) Implants in Conventional Silicon (Si). SOJ Mater. Sci. Eng. 2, 1-6 (2014). 

41. Zhu, J., Zhang, G. et al., Argon plasma induced phase transition in monolayer MoS2. J. Am. Chem. Soc. 139, 10216-10219 (2017). 

42. Liu, Y., Stradins, P., Wei, S. -H. Van der Waals metal-semiconductor junction: Weak Fermi level pinning enables effective tuning of Schottky barrier. Sci. Adv. 2, e1600069 (2016). 

Page 11/24 

43. Paz, W., Palacios, J. A theoretical study of the electrical contact between metallic and semiconducting phases in monolayer MoS2. 2D Mater. 4, 015014 (2017). 

44. Chaves, A., Wang, X., Low, T. et al., Bandgap engineering of two-dimensional semiconductor materials. npj 2D Mater. Appl. 4, 29 (2020). 

45. Tan, J., Li, S., Liu, B., Cheng, H. -M. Structure, Preparation, and Applications of 2D Material-Based Metal-Semiconductor Heterostructures. Small Struct. 2, 2000093 (2021). 

- 4�. Zhang, Z., Gu, L., Zhang, Y. Epitaxial Growth of Two-Dimensional Metal–Semiconductor TransitionMetal Dichalcogenide Vertical Stacks (VSe2/MX2) and Their Band Alignments. ACS nano 13, 885893 (2019). 

47. Wang, N. Ohmic contacts for atomically-thin transition metal dichalcogenide semiconductors. J. Semicond. 41, 070401 (2020). 

- 4�. Wang, Q., Tang, J., Zhang, G. et al. Layer-by-Layer Epitaxy of Multilayer MoS2 Wafers. Natl. Sci. Rev. 9, nwac077 (2022). 

49. Yu, Y., Zhang, H. et al., High phase-purity 1T’-MoS2- and 1T’-MoSe2-layered crystals. Nat. Chem. 10, 638-643 (2018). 

50. Cai, L. et al., Vacancy-induced ferromagnetism of MoS2 nanosheets. J. Am. Chem. Soc. 137, 26222627 (2015). 

51. Acerce, M., Voiry, D., Chhowalla, M. Metallic 1T phase MoS2 nanosheets as supercapacitor electrode materials. Nat. Nanotech. 10, 313-318 (2015). 

52. Voiry, D., Acerce, A., Chhowalla, M. Phase engineering of transition metal dichalcogenides. Chem. Soc. Rev. 44, 2702-2712 (2015). 

53. Javey, A., Guo, J., Wang, Q., Lundstrom, M., Dai, H. Ballistic carbon nanotube �eld-effect transistors. Nature 424, 654-657 (2003). 

54. Knoch, J., Appenzeller, J. Impact of the channel thickness on the performance of Schottky barrier metal–oxide–semiconductor �eld-effect transistors. Appl. Phys. Lett. 81, 3082 (2002). 

55. Zhu, J., Yang, R., Zhang, L., Jiang, Y., Zhang, G. et al. Boundary activated hydrogen evolution reaction on monolayer MoS2. Nat. Commun. 10, 1348 (2019). 

- 5�. Pang, C. S., Wu, P., Appenzeller, J., Chen, Z. Sub-1nm EOT WS2-FET with IDS > 600μA/μm at VDS=1V and SS < 70mV/dec at LG=40nm. IEDM Tech. Digest, 3.4.1-3.4.4 (2020). 

57. Yang, L., Lee, R., Rao, S., Tsai, W., Ye, P.D. 10 nm Nominal Channel Length MoS2 FETs with EOT 2.5 nm and 0.52 mA/um Drain Current. 73rd Annual Device Research Conference (DRC), 237-238 (2015). 

- 5�. Zhu, Y., Hone, J.C. et al., Monolayer Molybdenum Disul�de Transistors with Single-Atom-Thick Gates. Nano Lett. 18, 3807-3813 (2018). 

59. Nourbakhsh, A., Kong, J., Palacios, T. et al., MoS2 Field-Effect Transistor with Sub-10 nm Channel Length. Nano Lett. 16, 7798-7806 (2016). 

Page 12/24 

- �0. Xie, L., Zhang, G. et al., Graphene‐contacted ultrashort channel monolayer MoS2 transistors. Adv. Mater. 29, 1702522 (2017). 

- �1. Li, W., Wang, X. et al. Uniform and ultrathin high-κ gate dielectrics for two-dimensional electronic devices. Nat. Electron. 2, 563-571 (2019). 

- �2. Chen, Z., Pang, C.-S, Wang, P., Le, S.T., Wu, Y., Shahrjerdi, D., Radu, I., Lemme, M. C., Peng, L.-M., Duan, X., Chen, Z., Appenzeller, J., Koester, S. J., Pop, E., Franklin, A. D., Richter, C. A. How to report and benchmark emerging �eld-effect transistors. Nat. Electron. 5, 416-423 (2022). 

- �3. Mleczko, M. J., Wallace, R.M., Pop, E. et al., Contact engineering high-performance n-type MoTe2 transistors. Nano Lett. 19, 6352-6362 (2019). 

- �4. English, C., Pop, E. et al., Improved contacts to MoS2 transistors by ultra-high vacuum metal deposition. Nano Lett. 16, 3824-3830 (2016). 

- �5. J. Wang, L. Liao et al, High Mobility MoS2 transistor with low Schottky barrier contact by using atomic thick h-BN as a tunneling layer. Adv. Mater. 28, 8302-8308 (2016). 

- ��. Jeon, J. et al. The �rst observation of shot noise characteristics in 10-nm scale MOSFETs. VLSI Tech. Digest, pp. 48-49. (2009). 

- �7. Liow, T. et al. Carrier Transport Characteristics of Sub-30 nm Strained N-Channel FinFETs Featuring Silicon-Carbon Source/Drain Regions and Methods for Further Performance Enhancement. IEDM Tech. Digest, pp. 1-4. (2016). 

- ��. Barral, V. et al. Experimental determination of the channel backscattering coe�cient on 10–70 nmmetal-gate double-gate transistors. Solid-State Electron. 51, 537-542. (2007). 



<!-- Start of picture text -->
Materials And Methods<br>1. Layer -b y -l ayer epitaxy of wafer -s cale MoS2<br><!-- End of picture text -->

A multisource chemical vapor deposition (CVD) system with three temperature zones, referred to as zones I, II, and III, was used for all MoS2 growths. A typical growth process involved loading one highpurity (99.9%) sulfur source (15 g) into zone I and carrying it with Ar (40 sccm), while loading six MoO3 sources (99.999%, 30 mg) into zone II and carrying it with Ar/O2 (40/1.7 sccm) and loading single side polished 2-inch sapphire substrates with c-plane (0001) into zone III. For heterogeneous epitaxy (�rst MoS2 layer growth, sapphire-MoS2) of MoS2 on 2-inch sapphire, the temperatures in zones I, II, and III were maintained at 120, 540, and 910 ℃, respectively, while for homogeneous epitaxy (top two layers growth, sapphire-MoS2-MoS2-MoS2) of MoS2, the temperatures in zones II and III were increased to 570 and 940 ℃, respectively. More details of the growth can be found in our previous work<sup>48</sup> . 

Transfer of MoS2 �lms was performed by using polydimethylsiloxane (PDMS, Dow Corning), which was made by mixing a ten-to-one weight ratio of prepolymer and crosslinker in a mold and curing at 100 °C 

Page 13/24 

for four hours. During the transfer process, a customized mechanical transfer platform was used to press the prepared PDMS onto the sapphire grown with MoS2, and the PDMS was stripped using a deionized water-assisted approach, thus transferring the MoS2 �lm from the sapphire to the PDMS. Furthermore, the PDMS with the MoS2 �lm was pressed onto the plasma-modi�ed substrate (HfO2/Si) using a mechanical transfer platform and stripped off. After transfer, the MoS2 �lms were placed in a vacuum drying system for 6 hours to avoid moisture adsorption. 

To prepare dielectric/Si substrates, highly doped bare silicon wafers were cleaned using a standard buffered oxide etch (BOE) process to remove polymer and oxide layers on the surface, then rinsed with deionized water. The cleaned substrates were quickly placed in the vacuum chamber of the atomic layer deposition (ALD, BeneQ TFS 200) for HfO2 dielectric growth. The 2.6 nm thickness of the back-gated HfO2 dielectric was grown using a high temperature of 230 ℃. In addition, the standard electron-beam lithography (EBL)/electron-beam evaporation (EBE)/lift-off processes were used in this work. Spin coating of electron beam resists, such as polymethyl methacrylate (PMMA) and hydrogen silsesquioxane polymers (HSQ), was followed by pattern preparation through an EBL system (Raith Voyager), metal deposition by EBE after development, and �nally metal lift-off. Then, the MoS2 �lms were transferred to the premade metal-mark substrate (2.6 nm HfO2 dielectric/Si), and the substrate was modi�ed with a low-power oxygen plasma for 120 seconds before transfer. An inductively coupled plasma (ICP) system was then used to dry etch the MoS2 �lm into a banded structure using a hard mask. The source/drain electrodes were prepared by using double overlay exposure (more details can be found in our previous work<sup>8</sup> ), and 10 nm source/drain electrode gaps were generated to de�ne the channel length (i.e., back-gated length) of the ballistic MoS2 FETs. As contacts for ballistic MoS2 FETs, a Y/Ti/Au metal �lm stack of 1/5/7 nm thickness was used. To make injecting the solid-dopant source of the reactive metal Y easier, the contact area de�ned by the EBL system was treated with a low-power argon soft plasma (for 15 s) before contact metal evaporation. After annealing at 250 °C for 30 minutes under an inert gas atmosphere, the solid-dopant source Y diffused toward the upper layer of the MoS2, resulting in Y-doping at the active sites induced by the pre-plasma. Under all metal lines and pads (Ti/Au of 5/120 nm) except the contact area, 60 nm-thick SiO2 from HSQ (2%) was used to de�ne the pattern through electron beam lithography (EBL) and to reduce leakage from the back gate. A few layers of Al atoms oxidized into 0.3 nm Al2O3 were used as the seed layer for the growth of the top-gated 2.6 nm HfO2 dielectric with a growth temperature of 150 ℃, followed by growth of Ti/Au as the top-gated electrode de�ned by EBL. Finally, the PMMA de�ned by EBL was used as a mask to etch the thin-layer HfO2 on top of the pad through the ICP system. 

Optical images were taken using an optical microscope from Nikon, and the thickness of the layer-bylayer epitaxy of MoS2 was determined by atomic force microscopy (AFM, Veeco Instruments Inc. 

Page 14/24 

Dimension lcon) using tapping mode (Extended Data Fig. 2). Raman spectroscopy was performed using a spectrometer (Renishaw) with a laser wavelength of 532 nm at a laser power of 2.5 mW, and XPS (Thermo Fisher) was used in the binding energy analyses of our samples. For cross-sectional analyses of materials and devices, the sample was cut out from our chip using a double-beam focused ion beam (FIB, Zeiss Auriga Compact) system and transferred into the TEM grid with OmniProbe 200 nanomanipulators. Then, a high-resolution spherical aberration correction TEM (JEM-ARM200F) was used to obtain the cross-section scanning transmission electron microscopy (STEM) images and EELS maps of our samples. A Zeiss Sigma 300 SEM with inLens probes was used to obtain SEM images of our FETs. Electrical characterizations of the FETs were performed using parameter analyzers (Keithley B4200A and Agilent B1500), and the low-temperature transport of our ballistic FETs was measured using a Lakershare vacuum low-temperature probe station under a vacuum of 1.3×10<sup>-3</sup> mbar. 

A thermionic-emission model was used to extract the Schottky barrier heights (SBHs) of 2D transistors in near-threshold or subthreshold regions. In this case, carriers inject to the 2D semiconductors occurred mainly through thermal emission below the �at-band voltage (VFB), as shown by the following equation<sup>31,69-71</sup> : 



where IDS is the source-to-drain current in the FET, A is the junction area, A<sup>*</sup> is the Richardson constant, ΦSB is the Schottky barrier, k is the Boltzmann constant, and T is the temperature. As a result, the formula for extracting the Schottky barrier from an Arrhenius diagram was<sup>31,69-71</sup> : 



where c is a constant and ΦSB is the slope within the Arrhenius plots. Based on Equations (1) and (2), the SBHs of the 2D FETs were extracted under various gate voltages. For an n-type 2D transistor, when the gate voltage is below the �at-band voltage (VGS<VFB), the device is in the subthreshold region (thermionic emission current), where the 2D channel resistance dominates devices and produces a signi�cantly larger Schottky barrier height. In contrast, when the gate voltage is higher than the �at-band voltage (VGS>VFB), the superimposed tunneling current greatly affects the height of the extracted Schottky barrier<sup>26</sup> , which exhibits a smaller SBH. Therefore, the SBHs at gate voltages equal to the �atband voltage were extracted for accurate contact evaluation. 

Page 15/24 

DFT calculations were performed using the projector augmented wave approach implemented with the VASP package. The electron exchange-correlation energy was described by the generalized gradient approximation (GGA) in the scheme of the Perdew-Burke-Ernzerhof (PBE) functional. The cutoff energy of the plane-wave basis was 500 eV. Optimization of atomic positions was performed until the forces were smaller than 0.02 eV/A, and the electronic self-consistent interaction was converged until the energy difference was less than 10<sup>-5</sup> eV between two interaction steps. A vacuum space larger than 15 Å was added to the z directions of all 2D materials to prevent interactions between periodic images. The phase transition occurring between the 2H and 1T phases was calculated using the Nudge Elastic Band method with a force convergence of 0.03 eV/A. 

69. Yang, H., Kim, P., Yoo, I., Chung, H., Kim, K. et al., Graphene barristor, a triode device with a gatecontrolled Schottky barrier. Science 336, 1140-1143 (2012). 

70. Lee, S., Tang, A., Aloni, S., Wong, H.-S.P. Statistical study on the Schottky barrier reduction of tunneling contacts to CVD synthesized MoS2. Nano Lett. 16, 276-281 (2016). 

71. Liu, Y., Huang, Y. & Duan, X. et al., Toward Barrier Free Contact to Molybdenum Disul�de Using Graphene Electrodes. Nano Lett. 15, 3030-3034 (2015). 

72. Li, W., Wang, X. et al., High-Performance CVD MoS2 Transistors with Self-Aligned Top-Gate and Bi Contact. IEDM Tech. Digest, 37.3.1-37.3.4 (2021). 

73. Maxey, K., Avci, U., Metz, M. et al., 300 mm MOCVD 2D CMOS Materials for More (Than) Moore Scaling. VLSI Tech. Digest, 419-420 (2022). 

74. Jena, D., Bannerjee, K., Xing, G.H. 2D crystal semiconductors: intimate contacts. Nat. Mater. 13, 10761078 (2014). 

Page 16/24 



Illustration and theoretical calculations of phase transition and semimetal ~~Y-T-M~~ oS2 ohmic contact. a, Schematic diagram showing an advanced-node commercial silicon-based transistor contact, with metal silicide introduced between the metal and silicon semiconductor to reduce the contact resistance. b, Ideal 2D transistor contact diagram, with a 2D semimetal inserted between the metal and the 2D semiconductor for Fermi-level depinning. c, Band alignment between 2D semimetals and 2D 

Page 17/24 

semiconductors<sup>42</sup> . The red and blue squares represent the conduction and valence bands of the 2HTMDs, respectively, and the gray planes represent the Fermi levels of the corresponding semimetal 1TTMDs. d, Calculated band structure for Y-doping-induced phase-transition MoS2 (Y atoms are substitutionally doped into the top layer of MoS2). e, Projected local density of states (PLDOS) of MoS2 before (upper panel) and after contact with metal Ti (lower panel) and semimetal Y-T-MoS2 (middle panel). The light blue part represents the valence band, and the red part represents the conduction band. The Fermi level moves from inside the gap (before contact) to above the minimum value of the conduction band (after Y-T-MoS2 contact). f, Illustration of the phase transition from the 2H to 1T structure of MoS2, intrinsic (up) and Y-doping (low), and g, the corresponding required barrier energy calculated by the nudged elastic band (NEB) method. 

Page 18/24 



Characterization of doping ~~-i~~ nduced phase ~~-t~~ ransition technology. a, Schematic diagram of the plasma deposition-annealing (PDA) method for doping-induced phase transition. b, Photograph of 2-inch sapphire wafers covered with few layer MoS2, including monolayer and trilayer MoS2. c, Cross-sectional STEM image of the Y-doping-induced Y-T-MoS2. The brighter atoms are Mo and Y, and the darker atoms are S (scale bar, 1 nm). Corresponding atomic structure is shown on the left. d, EELS maps showing the 

Page 19/24 

presence and spatial distributions of Mo, S, and Y elements. The green, yellow, and red maps represent Mo, S, and Y elements. The spatial elemental maps show that Y atoms were clearly diffused into the MoS2. Scale bar, 0.5 nm. e, Cross-sectional STEM images and EELS maps of Y-doping-induced phasetransition in trilayer MoS2. EELS maps show the presence and spatial distribution of Mo, S, and Y elements in the trilayer structure. The green, yellow, and red maps represent Mo, S, and Y elements respectively. The spatial elemental maps show that Y was only doped into the uppermost layer of the trilayer MoS2. Scale bar, 0.5 nm. f, XPS spectra showing the Mo, S, Y, and C (baseline) peaks and the shifts of the Y �lm (orange curves), intrinsic MoS2 (red curves), and Y-doping-induced Y-T- MoS2 (purple curves); a.u., arbitrary units. g, Comparison of Raman spectra of trilayer MoS2 wafers before (red lines) and after (blue lines) Y doping. New peaks (J1, J2, and J3) can be observed in the Y-doped trilayer MoS2, con�rming the occurrence of the phase transition. h, Typical output characteristics with the maximum gate voltage of ballistic MoS2 FETs at different annealing activation temperatures, from bottom to top, room temperature (RT), 150 ℃, 200 ℃, and 250 ℃. This corresponds to states of no activation, partial activation, and full activation of the doped impurities. i, Transfer characteristics of ballistic FETs with the intrinsic MoS2 channel (red curves) and the Y-doping-induced Y-T-MoS2 (purple curves) channel. The weak gate modulation of the Y-T-MoS2 channel FET is direct evidence of the semimetal mature of Y-TMoS2. 

Page 20/24 



Structural and electric characteristics of ballistic MoS2 FETs. a, Schematic diagram of a double-gate MoS2 transistor with a semimetal Y-T-MoS2 contact. The black, yellow, and purple balls represent Mo, S, and Y atoms, respectively. b, Cross-sectional STEM image of a ballistic 3-layer MoS2 FET with a dual-gate and 2.6 nm HfO2 dielectirc layers, showing a channel length of ~10 nm, top-gate length of 5 nm, and 

Page 21/24 

back-gate length of 10 nm. c, EELS map showing the spatial distributions of yttrium, molybdenum, sulfur, titanium, gold, and hafnium elements, con�rming the locations of the MoS2 channel, Y-MoS2 semimetal buffer, electrodes, and HfO2 dielectric layers. d, Variable temperature transfer characteristics of a typical 10 nm gate length ballistic MoS2 FET at temperatures from 300 K to 100 K. e, Transfer characteristics of ballistic MoS2 FETs with three types of contacts measured at low temperatures of 100 K, including Y-TMoS2 vdW contact, argon plasma-induced undoped 1T-MoS2 vdW contact, and conventional Ti/Au metal contact. f, Comparison of the saturation output characteristics and the total-resistances of our ballistic MoS2 transistors and other reported n-type 2D sub-50 nm TMD transistors<sup>19,20,34,35,56-61</sup> . 

Page 22/24 



Wafer scale fabrication and comparison of MoS2 FETs. a, Process �ow diagram for preparing waferscale ballistic MoS2 FETs with doping-induced Y-T-MoS2 contacts. b, SEM images of a fabricated dualgate ballistic MoS2 FET array (scale bar, 250 nm) and a typical 10 nm gate length MoS2 FET (scale bar, 100 nm). Among the false colors, gold is the contact electrode, cyan is the gate electrode, and purple is 

Page 23/24 

the MoS2 channel. The inset shows a schematic diagram and an SEM image of the MoS2 FET (scale bar, 40 μm). c, Radar plot of the electric performance of our ballistic MoS2 FETs versus other reported shortchannel TMD FETs<sup>20,34,56</sup> . Red stars indicate our FETs, and light blue, light yellow, and light green areas indicate other reported advanced TMD FETs. d, The total-resistances extracted from output characteristics of 50 representative ballistic MoS2 FETs. The colored solid dots in the upper area represent the total resistance of all other n-type sub-50 nm TMD FETs. e, Transfer characteristics of our typical ballistic MoS2 FETs with 10 nm (left) and 20 nm (right) gate lengths at VDS= 0.1, 0.3, 0.5, and 0.7 V. f, Comparison of IDS-SS plots of our three typical ballistic MoS2 FETs (solid dots) with other published sub-50 nm short-channel 2D FETs (hollow dots)<sup>19,56-61</sup> . g, Transconductances and transconductance rates of six typical ballistic MoS2 FETs. The colored dots represent our FETs, and the blue area represents other 2D TMD FETs<sup>19,20,34,56-61</sup> . h, Peak transconductance comparison of our ballistic MoS2 FETs at VDS=0.7 V and other sub-50 nm 2D TMD FETs at VDS= 1 V. The light red, light blue, and light yellow areas represent our ballistic MoS2 FETs, other reported MoS2 FETs, and reported WS2 FETs<sup>19,20,34,56-61</sup> . i, Comparison of the virtual source model �tting (hollow circles) and measured data (lines) for output characteristics from a typical 10-nm gate-length MoS2 FET. j, Benchmarking the roomtemperature ballistic ratios of our MoS2 FETs with those of short-channel FETs, including bulk silicon FETs, silicon FinFETs, dual-gated silicon FETs, and other 2D FETs<sup>66-68</sup> . 

This is a list of supplementary �les associated with this preprint. Click to download. 

ExtendedDataFigs.docx 

Page 24/24 

