# Ultra-fast switching memristors based on two-dimensional materials

| 字段 | 内容 |
|---|---|
| 批次 | 第 2 批 |
| 期刊 | Nature Communications |
| 年份 | 2024 |
| 引用量（Semantic Scholar） | 220 |
| 作者 | S. S. Teja Nibhanupudi, Anupam Roy, D. Veksler, Matthew J Coupin, Kevin C. Matthews, Matthew N. Disiena, Ansh, J. Singh et al. |
| DOI | 10.1038/s41467-024-46372-y |
| 源文件 | 009_Nibhanupudi_2024_Ultra-fast-switching-memristors-based-on-two-dim.pdf |

---


Article 

https://doi.org/10.1038/s41467-024-46372-y 

# Ultra-fast switching memristors based on two-dimensional materials 

|Received: 9 March 2023<br>Accepted: 26 February 2024|S. S. Teja Nibhanupudi<br>1<br>, Anupam Roy<br>1,2<br>, Dmitry Veksler<sup>3</sup>,<br>Matthew Coupin<br>4, Kevin C. Matthews<br>4, Matthew Disiena1, Ansh1,<br>Jatin V. Singh<br>1, Ioana R. Gearba-Dolocan4, Jamie Warner<br>4,<br>Jaydeep P. Kulkarni<sup>1</sup>, Gennadi Bersuker<sup>5 </sup>& Sanjay K. Banerjee<sup>1</sup>|
|---|---|
|Check for updates||



The ability to scale two-dimensional (2D) material thickness down to a single monolayer presents a promising opportunity to realize high-speed energyefficient memristors. Here, we report an ultra-fast memristor fabricated using atomically thin sheets of 2D hexagonal Boron Nitride, exhibiting the shortest observed switching speed (120 ps) among 2D memristors and low switching energy (2pJ). Furthermore, we study the switching dynamics of these memristors using ultra-short (120ps-3ns) voltage pulses, a frequency range that is highly relevant in the context of modern complementary metal oxide semiconductor (CMOS) circuits. We employ statistical analysis of transient characteristics to gain insights into the memristor switching mechanism. Cycling endurance data confirms the ultra-fast switching capability of these memristors, making them attractive for next generation computing, storage, and Radio-Frequency (RF) circuit applications. 

In today’s digital era, the role of memory technology has become integral, particularly in the context of artificial intelligence (AI) applications. Several AI tasks, such as classification, recognition, natural language processing, prediction etc., heavily rely on large-scale memory storage and processing capability of the underlying hardware<sup>1–3</sup> . Conventional memory technologies like Static Random Access Memory (SRAM) or Dynamic Random Access Memory (DRAM) are energy-inefficient for implementing these data-intensive applications due to their volatile nature, resulting in dynamic as well as static power dissipation. These energy requirements are even more stringent for battery-operated mobile, wearable electronics, and Internet of Things (IoT) edge devices<sup>4,5</sup> . Although flash memory is non-volatile, the slow programming speed (>10us) makes it impractical for these applications<sup>6,7</sup> . To effectively harness and maximize the potential of AI and other emerging applications, an ultra-fast non-volatile memory is necessary. 

Memristors are promising devices in the emerging non-volatile memory landscape that have shown great potential owing to their small footprint (4F<sup>2</sup> ), fast operation, and low power consumption<sup>8–13</sup> . 

Several studies explored the use case of memristors for storage, memory-centric computing<sup>14–17</sup> , and high-frequency RF applications<sup>18–20</sup> . In the past decade, memristors fabricated using a variety of materials such as Transition Metal Oxides (TMO)<sup>21–24</sup> , chalcogenides<sup>25,26</sup> , and organic materials<sup>27–29</sup> have been extensively studied. TEM studies have conclusively established that the resistive switching in memristors can be attributed to the presence of conductive nanofilaments<sup>30,31</sup> . Based on the experimental observations, the switching dynamics in memristors have been captured using different modeling techniques<sup>32–34</sup> . The commercially available memristors typically switch in ~50 ns–100 μs range, making them slower than state-of-the-art DRAM<sup>35–37</sup> . Although a few studies have reported fasterswitching memristors (TSWITCH < 5 ns)<sup>38–47</sup> , the fast-switching dynamics have not been thoroughly studied. 

Here, we present an ultra-fast memristor fabricated using a twodimensional (2D) material, i.e., hexagonal Boron Nitride (hBN) as the switching layer<sup>48–50</sup> . The atomically thin nature of the 2D material facilitates rapid filament dynamics enabling an ultra-fast and energyefficient memristor. We study these memristors using ultra-short 

> 1Microelectronics Research Center, The University of Texas at Austin, Austin, TX 78758, USA. 2Birla Institute of Technology, Mesra, Ranchi 835215, India. 3HRL Laboratories, Malibu, CA 90265, USA.<sup>4</sup> Texas Materials Institute, The University of Texas at Austin, Austin, TX 78712, USA.<sup>5</sup> M2D solutions, Austin, TX 78758, USA. e-mail: subrahmanya_teja@utexas.edu; royanupam@bitmesra.ac.in; banerjee@ece.utexas.edu 

Nature Communications |  (2024) 15:2334 

1 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

pulses (TPULSE < 2.7 ns) in a custom-built RF test setup. Moreover, since the filament formation/dissolution in memristors is a stochastic process<sup>51–53</sup> , we employ statistical analysis of the transient switching characteristics to study these memristors. Statistical data provided critical insights into the switching mechanism and the inherent stochasticity of the filament dynamics. To the best of our knowledge, this is the first study of this kind not just in 2D memristors but among the plethora of scientific reports based on TMO memristors. In addition, by leveraging cues from statistical data, we model the fast-switching dynamics using a combination of finite element-based physics solver, empirical, and analytical equations. 

## Results 

Device fabrication and DC electrical performance 

Structural features of the fabricated memristor with few-layer hBN sandwiched between active (Ti) and inert (Au) electrodes are shown in Fig. 1a, b. The switching hBN layers were synthesized using chemical vapor deposition (CVD) on copper foil and transferred onto Si/SiO2 substrate for device fabrication (see Supplementary Fig. 1 and Methods section for details). The final device structure was confirmed using scanning electron microscopy (SEM) (Fig. 1c) and cross-sectional transmission electron microscopy (TEM) (Fig. 1d) images. Synthesized hBN films are 7-8 layers thick with an inter-layer spacing of 0.33 nm, as evident from the TEM images (Supplementary Fig. 2,3). These CVDgrown films contain single atom and few atom-wide intrinsic defects, as seen in Fig. 1e. These defects facilitate the formation of conductive filaments, which, in turn, enable the desired resistive switching behavior. Notably, previous studies have reported the absence of a resistive switching phenomenon in exfoliated flakes that lack intrinsic defects<sup>54,55</sup> . The crystal structure and chemical composition of the synthesized hBN films were corroborated using Raman and X-ray photoelectron spectroscopy (XPS) techniques (Supplementary Fig. 4). In addition, memristors fabricated with thinner (3-4 layers) hBN films (Supplementary Fig. 5), synthesized by tuning the growth parameters were studied for comparison. 

Devices with different cross-sectional areas varying from 500 × 500 nm<sup>2</sup> to 2 × 2 μm<sup>2</sup> were fabricated (Supplementary Fig. 6) and characterized. The majority of as-fabricated (virgin) devices (92%) exhibit high resistance (>1MΩ), which indicates the excellent quality of the synthesized hBN films (Supplementary Fig. 7.1). The remaining 

devices with low initial resistance likely contain grain boundaries or multi-atom wide defects which were probably introduced during the fabrication processes. These leaky devices were discarded and not considered for further analysis. The high voltage sweep applied to the Ti electrode during the forming process generates the conductive filament inside the memristor. Supplementary Fig. 7.2 shows that the magnitude of the forming voltage is directly correlated to the initial resistance of the memristor. Consequently, devices with higher initial resistance, characterized by fewer defects, require a higher voltage to establish the conductive filament. Apparently, this trend holds true for all devices, irrespective of the device cross-section. To ensure that the measured initial resistance and subsequent resistive switching were not influenced by an unintentional TiOx layer at the interface (Ti layer susceptible to oxidation), devices fabricated without the hBN layer were measured (Supplementary Fig. 8). These devices exhibit ohmic conduction with low resistance (50Ω−180Ω), confirming the absence of any substantial TiOx layer. 

After the forming operation, memristors exhibit bipolar resistive switching characteristics with positive voltage and negative voltage applied to the top Ti electrode for SET (transition to lower resistance) and RESET (transition to higher resistance) operations, respectively. Figure 2a shows the representative DC current–voltage (I–V) sweeps of the memristor device with a current compliance limit of 100 μA. Additional I–V sweeps measured from multiple devices are presented in Supplementary Fig. 9. Data collected from 200 such I–V traces were analyzed to quantify the variation in the device characteristics. Statistical analysis shows that the minimum separation between the highresistance state (HRS) and low-resistance state (LRS), is ~50x (Fig. 2b), considering variations. Similarly, the variations in the SET and RESET voltages are characterized by Gaussian distributions with mean values (μ) of 1.73 V and −0.85 V, respectively (Fig. 2c). The SET voltage distribution displays higher dispersion (standard deviation (σ) of 0.5 V) mainly attributable to the device-to-device variations (see Supplementary Fig. 10 for discussion). In comparison, the RESET voltage distribution is rather tight with σ of 0.27 V. This variation in switching voltage can be further reduced by ensuring high crystalline quality of the synthesized 2D material and by employing superior device fabrication methods that can reduce electrode surface roughness. 

To study the transport mechanisms responsible for the switching process, SET I–V sweep was plotted on a log-log scale 



<!-- Start of picture text -->
Au<br>Ti<br>a b<br>TE<br>BE<br>1μm<br>Au Ti Au<br>      hBN<br>(~ 8 layers) Au<br>6nm<br>c d e<br><!-- End of picture text -->

Fig. 1 | Device structure of the fabricated 2D hBN memristor. a Schematic drawing of the memristor device. b Cross-section schematic showing the metal contact used for top (titanium) and bottom electrodes (gold). c SEM image of the device after fabrication (inset) zoomed image where top and bottom electrodes 

cross. d Phase contrast TEM image of the device cross-section showing 8 layer thick hBN sandwiched between metal electrodes. e Magnified TEM cross-section showing the layered structure of hBN with single-atom defects (arrows) and few atom wide amorphous regions (dashed circles). 

Nature Communications |  (2024) 15:2334 

2 

Article 

https://doi.org/10.1038/s41467-024-46372-y 



Fig. 2 | DC characterization of the 2D hBN memristor. a DC I–V sweeps of the hBN memristors shown for 20 consecutive cycles (SET curves shown in red traces and RESET curves shown in blue traces). b Cumulative probability distribution of the resistance in HRS and LRS states extracted from DC sweeps at VREAD = 0.1 V collected from 200 I–V traces. c SET/RESET voltage distribution using 100uA compliance current. d SET I–V curve plotted on log-log scale shows regions with varying slope in HRS and linear slope in LRS. e I–V sweep of the device in LRS measured at various operating temperatures (225 K (pink curve), 250 K (black curve), 275 K (blue curve), 300 K (red curve)); (inset) resistance extracted at VREAD = 0.5 V plotted vs. 

(Fig. 2d). Device transitioning to LRS during SET traverses through conductance regions with varying slopes, indicating that the dominant charge transport mechanism varies: ohmic conduction with slope ~1, space-charge limited conduction (SCLC) in regions with slope ~2 and trap-fill limited SCLC in regions with slope >2<sup>56,57</sup> . Bidirectional voltage sweeps confirm that the change in slope is reversible and, therefore, not related to the filament formation (Supplementary Fig. 11). Further voltage increase results in an abrupt current jump (slope >10) suggesting the formation of an ohmic conductive filament (slope ~1). The current compliance prevents further expansion of the filament and protects the device from thermal breakdown. To corroborate the filamentary conduction mechanism, conductive atomic force microscopy (CAFM) measurements were conducted on a stressed device. The CAFM maps reveal isolated regions exhibiting high current, clearly indicating the formation of conductive filaments across the hBN layer (details in Supplementary Fig. 12). Likewise, the RESET I–V sweep also exhibits ohmic conduction in LRS and SCLC in the HRS, as seen in Supplementary Fig. 11. To understand the fundamental nature of the filament, I–V sweeps were measured at different operating temperatures. The resistance of the device in LRS increases with temperature suggesting the metallic nature of the filament (Fig. 2e). On the other hand, HRS resistance decreases with temperature indicating energy-activated conduction (Fig. 2f). In addition, Electron Energy Loss Spectroscopy (EELS) was employed to investigate the elemental composition of the filament. The EELS profiles gathered from four distinct points (A, B, C, D) on the TEM cross-section are plotted in Fig. 2g. A prominent Ti peak was observed at point C (located inside the Ti layer) while a faint peak was observed at point B (located within hBN layers). The presence of Ti peak at location B suggests titanium ion migration into the hBN layer, which contributes to the filament formation. Similar observations of titanium ion-constituted filaments have been reported in previous studies<sup>55,58</sup> . Overall, the temperature measurements and the EELS analysis collectively reinforce the existence of metallic filaments (composed of Ti atoms) in the 2D hBN memristor. 



temperature. The memristor in LRS has a positive temperature coefficient of resistance indicating the formation of metallic filaments (f) I–V sweeps of the device in HRS measured at various operating temperatures (225–300 K); (inset) resistance extracted at VREAD = 0.5 V (black curve),0.75 V (blue curve),1 V (red curve) plotted vs. temperature. Reducing resistance with increasing temperature suggests conduction through insulating medium. g TEM cross-section illustrating the locations where electron energy loss spectroscopy (EELS) profile was collected. Points A (red curve), D (black curve) are located inside Au electrode, point B (blue curve) is located inside hBN layer, and point C (green curve) inside Ti electrode. 

### Pulse voltage stress operations 

The switching dynamics of the memristors were studied by applying a sequence of ultra-short voltage pulses (TPULSE ~ 2.7 ns) with a rise/fall time of ~ 350 ps. In our test setup, the voltage pulses were delivered to the device through an impedance (Z = 50 Ω) matched network, as schematically illustrated in Fig. 3a (additional details provided in the Methods section). A 50 Ω termination resistor was soldered onto the probe-tip (Fig. 3a), which minimized reflections and ensured maximum power transfer to the device (Supplementary Fig. 13). The resistance state of the device was measured by applying a constant DC offset (VREAD = 0.1 V) to the pulse. This DC component of the current signal was amplified and measured on the oscilloscope. 

Figure 3b shows the oscilloscope waveforms of the applied voltage pulse and the measured current during a SET operation. The induced current rises slowly compared to the voltage pulse and saturates at ~700 ps which can be characterized as the SET switching time of the memristor. The I–V characteristics extracted from the transient waveforms in Fig. 3b clearly demonstrate the resistive switching behavior (Fig. 3c). To verify that the memory window observed in Fig. 3c originates from memristor resistive switching and not from system parasitics, we apply similar voltage pulses to discrete resistors (Supplementary Fig. 14). Further, the successful SET operation was also confirmed through the DC read signal (Supplementary Fig. 15). Figure 3d shows the transient waveforms of the voltage and current pulses for the RESET operation. Initially, since the device is in LRS, the current increases, reaches a maximum, and gradually decreases as the filament dissolution proceeds. This initial current surge should not be confused with parasitic displacement current since the 50Ω shunt resistor placed on the probe tip provides an effective path to dissipate parasitic charges. The successful resistive switching during the RESET operation is confirmed by the I–V plot (Fig. 3e) and the DC read signal (Supplementary Fig. 15). 

### Statistical analysis of switching dynamics 

The filament formation and dissolution are stochastic processes determined by several factors apart from the electric field, such as 

Nature Communications |  (2024) 15:2334 

3 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

energy generation/dissipation, defects in the 2D film, and the interface with the electrodes. Hence, statistical analysis of the switching dynamics was employed to gain insights into the resistive switching mechanism. This study was conducted by applying identical voltage pulses (VPULSE ~ 2.75 V, TPULSE ~ 2.7 ns) and analyzing changes in the switching behavior across different devices/cycles. Data from the measured current pulses display a wide range of intrinsic switching 

times (600 ps to 2.5 ns—see Supplementary Fig. 16 for details) as seen from Fig. 4a (voltage pulses traces omitted for clarity). The distribution of switching times (extracted from each current trace) has a mean value of 1.32 ns and a standard deviation of 670 ps (Fig. 4b). Notably, ~46% of the devices exhibit sub-nanosecond switching. 

Further, to understand the effect of filament morphology on switching dynamics, we studied the correlation between switching 



<!-- Start of picture text -->
a<br>3.5 12 8 1.0 2 1<br>3.0 700ps SET pulse 10 7 SET pulse 0.5 RESET pulse 0 0 RESET pulse<br>2.5 8 6 0.0 -2 -1-2<br>5 -0.5<br>2.01.5 Pulse-width2.7ns 6 4 -1.0 Pulse-width2.7ns -4 -3-4<br>4 3 -1.5 -6 -5<br>1.0 2 2 -2.0 -6<br>0.50.0 0 10 -2.5-3.0 1ns -8-10 -7-8<br>0 1 2 3 4 5 6 7 8 9 10 0.0 0.5 1.0 1.5 2.0 2.5 3.0 3.5 0 1 2 3 4 5 6 7 8 9 10 -2.5 -2.0 -1.5 -1.0 -0.5 0.0 0.5<br>b Time (ns) c Voltage (V) d Time (ns) e Voltage (V)<br>Voltage (V) Current (mA) Current (mA) Voltage (V) Current (mA) Current (mA)<br><!-- End of picture text -->

Fig. 3 | Ultra-fast pulse characterization setup and waveforms. a Schematic drawing of the high-frequency pulse test setup; (right) zoomed schematic of the probe tips with 50 Ω termination for maximum power transfer .b Applied voltage pulse (black trace) and measured current (red trace) waveform for SET operation. The applied pulse has a pulse-width of 2.7 ns and the device switches in about 

700 ps, c I–V plot of the data in (b) shows change in resistance during the applied pulse. d Applied voltage pulse (black trace) and measured current (blue trace) waveform for RESET operation (e) I–V plot of the data in (d) shows change in resistance during the applied pulse. 



<!-- Start of picture text -->
18 70 3.0 1200<br>1614 T~ 600ps SWITCH SET transition V PULSE : 2.75V, 2.7ns 60 SET switching time 2.5 SET switching data200 data points 1000 hBNTiAu Interface<br>1210 5040 0.67ns1.32ns 2.0 800 Au<br>1.5<br>8 30<br>6 T SWITCH 20 1.0 600<br>4 ~ 2ns<br>2 10 0.5 400 HfOx (t = 5nm)<br>hBN (t = 2.5nm)<br>0 0 0.0<br>0 1 2 3 4 5 6 7 8 0.0 0.5 1.0 1.5 2.0 2.5 3.0 1 10 100 0 10 20 30 40 50<br>a Time (ns) b SET switching time (ns) c RINIT/RFIN after SET pulse d Time (ps)<br>0 60 3.0<br>RESET switching time RESET switching data Read LRS<br>-2-4 T ~SWITCH 1.2ns 50 2.5 175 data points SET RESET HRS<br>-6 40 1.43ns 2.0 10 4<br>-10-8 T~ 2ns SWITCH 3020 0.4ns 1.5 ~2x<br>-12 1.0 10 3<br>-14-16 RESET transition V PULSE : -2.25V, 2.7ns 100 0.5 RESET -2.25V2.75V, 2.7ns, 2.7ns<br>0 1 2 3 4 5 6 7 8 0.0 0.5 1.0 1.5 2.0 2.5 3.0 1 10 100 0 100 200 300 400 500 600<br>e Time (ns) f RESET switching time (ns) g RFIN/RINIT after RESET pulse h Cycle Number<br>Current (mA) Frequency<br>Switching time (ns)<br>Avg. interface temperature (K)<br>Current (mA) Frequency Resistance<br>Reset switching time (ns)<br><!-- End of picture text -->

Fig. 4 | Statistical analysis of transient switching characteristics using ultra-fast pulses. a Measured current waveforms on 30 different devices under identical applied voltage pulses (VPULSE → 2.75 V, 2.7 ns) during SET operation. b SET switching time distribution created from 200 measurements with a mean value of 1.32 ns. c Correlation between SET switching time and resulting relative change in resistance values. Large resistance change requires a longer switching time. d Transient response of average interface temperature for 2.5 nm thick hBN and 5 nm thick HfOx, obtained through COMSOL simulation (inset) snapshot of 

temperature heatmap. e Measured current waveforms on 30 devices under identical applied voltage pulses (VPULSE→ −2.25 V, 2.7 ns) during RESET operation. f RESET switching time distribution created from 175 measurements with a mean value of 1.43 ns. g Correlation between RESET switching and resulting relative change in resistance after the RESET pulse. h Switching endurance measurement of single device demonstrates 600 cycles with 2.7 ns pulses (SET data points shown in red and RESET data points shown in blue). 

Nature Communications |  (2024) 15:2334 

4 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

time and resistance change induced by the SET pulse (RINIT/RFIN where RINIT is the initial state resistance and RFIN is the final state resistance) (Fig. 4c). Here, the resistance values (RINIT, RFIN) were obtained by DC measurements before and after the SET pulse. For this study, devices were programmed (by leveraging the gradual RESET characteristics shown in Fig. 2a) such that the initial resistances were in the 10<sup>4</sup> –10<sup>5</sup> Ω range and the set pulse results in RFIN < 10<sup>4</sup> Ω. The switching time varies among devices even with the same RINIT and RFIN, highlighting the stochastic nature of filament growth. However, a clear upward trend indicates that larger resistance change (which entails more structural modifications) requires longer switching times. 

The switching mechanism in 2D memristors is typically based on the formation and dissolution of conductive filaments<sup>55,58</sup> . Although a recent study<sup>59</sup> reports non-filamentary conduction in hBN memristors, our devices exhibit filamentary switching, as confirmed by the ohmic behavior in LRS and positive TCR in LRS. The filament growth in memristors proceeds through vertical propagation (around defects or weak spots), followed by lateral expansion<sup>60–62</sup> . The current flowing through the initially formed narrow filament (single atom or few atoms wide) raises the temperature inside the memristor through the Joule heating phenomenon. The generated temperature helps the Ti ions surmount the energy barrier (Arrhenius dependence) and migrate into the hBN layer, further propelling the filament growth<sup>61–63</sup> . To understand the fundamental factors responsible for the ultra-fast switching in 2D memristors, we conducted transient thermal analysis using a finite element method-based physics solver (COMSOL). The ultra-thin 2D hBN layer increases the electric field as well as the temperature in the memristor, both of which promote rapid filament growth. Moreover, the high in-plane thermal conductivity of the hBN layer<sup>64,65</sup> (~ 35x higher than transition metal oxides<sup>66–68</sup> ) rapidly spreads the heat generated in the filament (joule heating) to the Ti/hBN interface (detailed analysis presented in Supplementary Fig. 17). The high 

temperature at the Ti/hBN interface facilitates Ti ion release from the electrode into the hBN switching layer. Figure 4d compares the average interface temperature for our devices and HfOx memristors with 5 nm thickness (typical thickness for oxide memristors). Evidently, the interface temperature rises rapidly in our devices compared to thicker oxide memristors, consequently resulting in faster resistive switching. 

Similar to SET operation, RESET also displays a range of intrinsic switching times (Fig. 4e). The RESET operation is slower than the SET operation (distribution μ = 1.43 ns, σ = 400 ps) with only ~8% of the devices exhibiting sub-ns switching (Fig. 4f). As in SET, a larger resistance increase is associated with a longer switching time (Fig. 4g). Here, the devices have RINIT ~ 10<sup>3</sup> –10<sup>4</sup> Ω, and the RESET pulse results in RFIN > 10<sup>4</sup> Ω. Further, the switching endurance test demonstrates one of the highest reported values (600 cycles) with the shortest applied pulses (~2.7 ns) in 2D memristors (Fig. 4h). Consistent switching between resistance states is very promising since it demonstrates the potential of 2D memristors for ultra-fast switching memory applications. 

### Role of Joule heating on filament stability 

Several studies have reported that Joule heating promotes filament dissolution in TMO memristors<sup>69–71</sup> as well as in 2D memristors<sup>72,73</sup> . Especially in devices with metallic filaments, large LRS current generates considerable heat (600–1200K) that accelerates the outdiffusion of metal ions<sup>74,75</sup> . The joule heating can be estimated by the energy generated inside the memristor, which can be calculated by integrating the product of transient voltage and current pulses (obtained from Fig. 4a, e) over time (E = R t0<sup>VðtÞIðtÞdt)(seeSupple-</sup> mentary Fig. 18 for details). This energy can be roughly segregated into switching energy and excess energy, as shown by the schematic in Fig. 5a. Switching energy contributes to the resistive switching process while excess energy continues to dissipate throughout the device after the switching process is complete. The switching energy driving the 



<!-- Start of picture text -->
50 SET switching energy 10 7 3.02.5 RPUL 1614<br>40 Energy SWITCH V(t)I(t) dt 2.0 12 10<br>10 6 1.5 8<br>1.0 6<br>30 = 16.2pJ25.1pJ 10 5 0.5 0.0 1 R2 INIT3 4 5 6 7 8 R9 FIN10 4 20<br>20 10 4 Time (ns)<br>10 10 3<br>0 10 2<br>0 10 20 30 40 50 60 70 80 RINIT RPUL RFIN<br>SET switching Energy (pJ) Res before Min Res Res after<br>a b c pulse during pulse pulse<br>50<br>SET switching data RESET switching energy RESET switching data<br>40 Energy SWITCH V(t)I(t) dt<br>100<br>100<br>30<br>22.9pJ 10<br>20 =10.8pJ<br>10<br>10<br>RINIT > 1 RINIT <<br>0<br>0 10 20 30 40 50 60 70 80 0 10 20 30 40 50 60 0 10 20 30 40 50 60<br>SET excess energy (pJ) RESET Switching energy (pJ) RESET switching energy (pJ)<br>d e f<br>Voltage (V) Current (mA)<br>Frequency<br>Resistance<br>Frequency<br> after SET pulse/RRINITFIN<br> after RESET pulse/RRFININIT<br><!-- End of picture text -->

Fig. 5 | Statistical analysis of memristor switching energy. a Schematic representation of the partition between switching energy and excess energy. b SET switching energy distribution created from 200 measurements with a mean of 25.1 pJ. c Resistance distribution of RINIT (red box plot), RPUL (blue box plot), and RFIN (green boxplot) (inset) waveform illustrating the time instance at which the resistances were measured. The distribution clearly indicates the filament 

resistance increases after pulse termination. d Relative resistance change after SET pulse variation vs excess energy expended in the device. Since excess energy is proportional to the Joule heating in the device, higher excess energy results in narrowing of the filament. e RESET switching energy distribution created from 175 measurements with a mean of 22.9 pJ. f Relative resistance change after RESET pulse vs switching energy. 

Nature Communications |  (2024) 15:2334 

5 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

SET operation has a mean of 25.1 pJ and a standard deviation of 16.2 pJ (Fig. 5b). On the other hand, the mean excess energy (μ ~ 39.3 pJ) is higher than the switching energy attributable to the large LRS current flowing through the device. 

For the SET transition, the memristor resistance distribution measured after the pulse was observed to be higher than the resistance during the pulse (Fig. 5c). Ideally, the resistance should have remained unchanged as the memristor in LRS exhibits linear ohmic conduction (based on Fig. 2d). Identical pulses applied to discrete resistors displayed no change in resistance during and after the pulse (Supplementary Fig. 19), confirming that the test setup parasitics do not contribute to the resistance change. We hypothesize that the joule heating-assisted filament narrowing is responsible for the observed resistance increase. To understand how this phenomenon affects the final resistance state (RFIN), the correlation between excess energy dissipated in the device (proportional to filament temperature) and the resistance change (RINIT/ RFIN) was studied (Fig. 5d). For this study, devices with similar initial resistance (RINIT > 10<sup>5</sup> Ω) were chosen to eliminate the impact of initial filament morphology. Evidently, higher excess energy results in lower resistance change, indicating significant filament narrowing caused by enhanced joule heating. Supplementary Fig. 20 presents a further analysis of resistance change induced by Joule heating. 

The phenomenological model based on the Arrhenius relationship is a widely accepted model which satisfactorily captures the filament growth dynamics in TMO memristors<sup>59–62</sup> . Therefore, in this study, we employ a modified version of this model to capture the growth dynamics as well as the Joule heating-induced filament narrowing in our 2D memristors. In the classic model, time dependency of the filament growth is described by the Arrhenius relationship �ddΦt<sup>= A1 exp</sup> �<sup>�</sup> Ea0kT�αqV��59–62, where Φ is the filament diameter and Ea is the activation energy and αqV accounts for the barrier lowering due to the applied voltage. This simple relationship cannot capture the filament narrowing observed in our devices. Therefore, an additional term �ddΦt<sup>=�A2 exp</sup> �<sup>�</sup> kTEa�� was included that accounts for Joule heating-induced filament dissolution (see Supplementary Fig. 21 for detailed analysis). Based on this model, the following observations can be deduced: During the switching energy phase, when the Joule heating is insignificant (low current in the memristor), the filament growth rate dominates, resulting in filament expansion. On the other hand, during the excess energy phase when Joule heating is significant (high current in the memristor), the filament growth rate balances the filament dissolution rate resulting in current saturation. Finally, during the voltage pulse falling transition, the filament growth rate (determined by V, TCF) decreases faster than filament dissolution rate (determined only by TCF), thereby resulting in narrowing of the filament. A self-consistent electro-thermal solver using the proposed model clearly captures the filament narrowing phenomenon (see Supplementary Fig. 21) which closely matches with the experimental data presented in Fig. 5c. In addition to the proposed electro-thermal model, the resistance evolution of the memristor can be adequately captured through a simple empirical model. The ArrheniusdΦ relation-expð�EakT0 ~~<u>Þ</u>~~ ship with an added filament enlargement factor Φ<sup>n</sup> ~~(~~ dt<sup>= A</sup> Φ<sup><u>n</u></sup> ) produces a good fit to measured data (Supplementary Fig. 22). In this model, the temperature is considered constant, which significantly reduces the computational cost. Such models are particularly beneficial for implementing large circuits using the SPICE simulator. 

Mean RESET switching energy (μ ~ 22.9 pJ) is slightly lower than the SET switching energy, as seen from Fig. 5e. Unlike SET operation, Joule heating in the RESET operation is dominant during the switching energy phase (wider filaments supporting higher currents). The resistance change (RFIN/RINIT) after the RESET pulse clearly increases with increasing switching energy, as seen in Fig. 5f. A similar trend of increasing resistance change can be observed from the total energy plots presented in Supplementary Fig. 23. Further, to confirm the role of heat on filament stability, we conducted retention studies at 

elevated temperature (350–700K). The experiments show that memristors in LRS or HRS display resistance increase with time, validating the thermally-driven filament dissolution (Supplementary Fig. 24). Further, the LRS retention time shows an exponential dependence on the temperature, characterized by an activation energy of 0.668 eV. Extrapolating the graph shows that the memristors in LRS would exhibit a retention time of 10 years at room temperature (Supplementary Fig. 24). 

### Ultra-fast (120 ps) switching memristors 

The memristive devices fabricated using thick hBN (7–8 layers) exhibited varying ranges of intrinsic switching times, with the tail-bits reaching as low as 600 ps. To evaluate the lowest possible switching time, we tested the devices using ultra-short pulses (TPULSE ~ 120 ps). These ultra-short pulses were generated through a step-recovery diode-based comb generators. Although thick hBN devices exhibit resistive switching under ultra-short pulses, the switching was inconsistent. The devices generally fail to switch in multiple cycles, especially in the RESET operations (Supplementary Fig. 25). To understand the impact of hBN layer thickness on switching, devices with thin hBN films (3-4 layers) were fabricated. These devices have lower initial resistance due to reduced thickness and do not require initial forming operation. Supplementary Fig. 26 shows repeatable switching using DC voltage sweeps in these devices. These devices exhibited resistive switching with ultra-short voltage pulses of 120 ps FWHM (full width at half maximum) (Fig. 6a, b). This is the fastest ever reported switching time observed in 2D memristors surpassing the previous best report of 700 ps in MoS2 memristors<sup>47</sup> . Note that higher amplitude voltage pulses (~4 V) were required for successful SET and RESET operation compared to ~2.75 V of longer nanosecond pulses (Fig. 3b, d). The devices consumed <2pJ for SET/RESET transitions (see Supplementary Fig. 27 for details) that is among the lowest reported switching energies in 2D material-based memristors. Repeated cycling using 120 ps pulses shows consistent switching (100 cycles) with a memory window of ~1.7x (Fig. 6c). This is the highest reported endurance using sub-ns pulses, exceeding the best-reported value of 20 cycles observed in the TMO memristor<sup>38</sup> (see Fig. 6d and Supplementary Table. 1 for details). Supplementary Table 2 compares the endurance performance of our devices with other 2D memristors. 

## Discussion 

In summary, we fabricated Ti/hBN/Au memristors that exhibit ultrafast switching characteristics when characterized using short voltage pulses (TPULSE < 3 ns). Unlike other ultra-fast memristors, our devices with thicker hBN (7–8 layers) exhibit high cycling endurance (~600 cycles) using short 2.7 ns voltage pulses with a mean switching time of 1.43 ns. On the other hand, thin hBN (3–4 layers) devices switch under ultra-short pulses of 120 ps, which is the fastest reported switching speed among 2D material-based memristors. Finite-element-analysisbased thermal simulations provided key insights which help explain the fundamental reason responsible for the observed ultra-fast switching in 2D memristors. 

Statistical data collected from several devices revealed useful correlations between switching time-resistance ratio and switching energy-resistance ratio, providing a practical knob to tune device characteristics. Furthermore, the unique experimental methodology employed in this work allowed us to study the dynamic evolution of resistance (during the pulse) as well as the change in resistance (before and after the pulse). To the best of our knowledge, this is the first instance where such an approach has been adopted. Correlating these data points revealed a significant presence of joule heating-induced filament narrowing in our devices. The impact of Joule heating on filament stability was studied using a combination of statistical analysis, retention testing, and electrothermal simulations. Moreover, an electro-thermal model was developed which accurately captures the 

Nature Communications |  (2024) 15:2334 

6 

Article 

https://doi.org/10.1038/s41467-024-46372-y 



<!-- Start of picture text -->
4.5 8 0.0 0<br>4.0 SET pulse 7 -0.5 -1<br>3.5 6 -1.0 -2<br>3.0 -1.5<br>5 -3<br>2.5 FWHM 4 -2.0 FWHM ~ 120ps -4<br>2.0 -2.5<br>~ 120ps 3 -5<br>1.5 -3.0<br>1.0 2 -3.5 -6<br>0.5 1 -4.0 -7<br>RESET pulse<br>0.0 0 -4.5 -8<br>0.0 0.5 1.0 1.5 2.0 2.5 0.0 0.5 1.0 1.5 2.0 2.5<br>(a) Time (ns) (b) Time (ns)<br>Read LRS 1000<br>SET RESET HRS This work<br>(3-4 layer hBN)<br>This work<br>10 4 100 (7-8 layer hBN)<br>~2x 38<br>43<br>10<br>10 3<br>2.75V, 2.7ns<br>RESET -2.25V, 2.7ns 1 41 44  45 42 39 47<br>0 100 200 300 400 500 600 0 200 400 600 800 1000 1200 1400<br>Cycle Number Switching time (ps)<br>(c) (d)<br>Voltage (V) Voltage (V)<br>Current (mA) Current (mA)<br>Resistance<br>Reported number of cycles<br><!-- End of picture text -->

Fig. 6 | Demonstration of highest switching speed in 2D memristors. a Applied SET voltage pulse (gray trace) and measured current (red trace) for thin hBN (3–4 layers) memristor. The pulse-width of the voltage pulse is about 120 ps. b Applied RESET voltage pulse (gray trace) and measured current (blue trace) using 120 ps pulse. c Endurance cycling between LRS and HRS of the memristor with ultra-short 

pulses. The device shows 100 consecutive cycles of consistent switching, which is the highest ever reported endurance using ultra-short pulses. d Plot benchmarking the performance of the devices presented in this article with other TMO and 2D material memristors. 

transient switching characteristics including secondary effects such as Joule heating. Overall, this study unveils the true potential of 2D material memristors for future high-speed computing, storage, and RF applications. 

## Methods 

### Hexagonal boron nitride synthesis 

Few layer hBN stacks were grown by Chemical Vapor deposition (CVD) on commercially available copper foils (25um thick, 99.8% purity, annealed, uncoated – Alfa Aesar Corporation). The foils were electropolished using phosphoric acid-based solution to reduce the surface roughness and eliminate the striations typical of commercially produced copper foils. The copper foil was folded into an enclosure and placed in the center of the quartz tube. The furnace temperature was ramped-up and the substrates were annealed at 1030 C for 25 min in H2 environment (30sccm flow rate). After annealing the substrates, the ammonia-borane precursor (placed in a separate heating zone – see Supplementary Fig. 1) was heated to 92C-95C in a water bath. At this temperature, ammonia-borane decomposes to borazine, monomeric aminoborane and hydrogen that are introduced into the chamber through H2/Ar carrier gas. The chemical species adsorbed onto the copper surface synthesize the desired few-layer hBN stacks. During the growth, H2/Ar flow rate was 80sccm/14sccm and the overall chamber pressure reached ~700mT. The duration of the growth varied ranging from 10 to 12 min Following the growth, the chamber was rapidly cooled (~30 min) through a natural cooling process and the gas flow was maintained throughout the cooling process. The layered structure of the grown hBN films was confirmed using TEM imaging (Fig. 1 and Supplementary Figs. 2, 3). 

### hBN film transfer 

The grown hBN films were transferred from copper foil onto Si/ SiO2 (285 nm) substrate for device fabrication. For enabling the 

transfer process, the copper foils with hBN films were spin-coated with PMMA (polymethyl methacrylate) at 3000 rpm for 1 min followed by baking at 180 C for 1 min. The PMMA layer provides support and protection to the hBN films during the transfer process. The hBN films were transferred using H2 bubbling transfer method using NaOH solution as the electrolyte. The spincoated copper foil was used as the cathode and nickel substrate was used as the anode for the electrolysis process. Applying 1.8 V to the anode generates H2 gas bubbles at the cathode which leads to the delamination of hBN from the copper foil. The separated hBN/PMMA stack was rinsed several times to remove residues introduced during the transfer process and scooped up onto the target substrate with patterned bottom electrode. The sample with hBN/PMMA stack was stored in a vacuum chamber overnight to remove any water bubbles trapped between the hBN film and the substrate. Then the PMMA was stripped by leaving the sample in acetone for 2 hours. To further remove any PMMA residues, the sample was annealed at 200 C for 4 hours in a high vacuum chamber (1e-6 Torr). Successful transfer of the hBN film onto target substrate was confirmed by Raman and XPS spectroscopy, SEM and TEM imaging (Supplementary Figs. 2,3,4). 

### Memristor device fabrication 

The memristor device fabrication involves patterning the Bottom Electrode (BE) using e-beam lithography on Si/SiO2 (285 nm) substrates, followed by e-beam evaporation of metal contacts (Au(70 nm)). The grown hBN film was transferred onto the BE using PMMA-assisted bubbling transfer method. The device fabrication was completed by patterning and depositing Top electrode (TE) metal (Ti(5 nm)/Au(70 nm)) such that titanium metal is directly in contact with hBN. The fabricated devices have varying cross-sectional area between 500 x 500nm<sup>2</sup> and 2 x 2 um<sup>2</sup> . The final device structure was confirmed using optical and SEM imaging (Supplementary Fig. 6). 

Nature Communications |  (2024) 15:2334 

7 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

### Electrical DC characterization 

DC characterization (Fig. 2a-d) of the fabricated memristors was conducted using a probe station (Cascade Microtech) and a semiconductor parameter analyzer (Agilent 4156 C). In all the measurements, the bias was applied to the TE with the BE grounded and the current compliance was typically set to 100uA. The temperature measurements (Fig. 2e, f) were conducted in a cryogenic probe station (Lakeshore FWP6) connected to an Agilent B1500 semiconductor parameter analyzer. 

### Electrical pulse characterization 

Pulse characterization (Figs. 3, 4, 5, 6) of the memristors was conducted in a custom in-house RF measurement setup. The nanosecond pulses (t ~ 2.7 ns used in Figs. 3, 4) were generated using a Picosecond Pulse Labs 10070A pulse generator. These ultra-short pulses were delivered to the memristors via an impedance (50 Ω) matched network to eliminate the reflections (see Supplementary Fig. 12). A 50Ω termination resistor was soldered onto the probe-tip to ensure maximum power transfer to the device as well as provide a quick path for dissipating parasitic charges. The voltage pulse delivered to the device was monitored through a pick-off tee that samples the signal with a 20 dB attenuation. The voltage pulse induces a current pulse that traverses downstream to the oscilloscope. Here the signal was split into AC and DC components using a bias-tee. The AC component of the signal was captured using a highperformance oscilloscope (Agilent DSA91304A—13 GHz, 40GSa/s). Since the input impedance of the oscilloscope is 50Ω, only current signals with amplitude > 200uA can be reliably captured. However, the memristors typically conduct 1uA-100uA current under read voltages (VREAD ~ 100mV-500mV). Therefore, to study memristor switching, the DC component of the signal was amplified using a current-to-voltage converter (Femto DHCPA-100) with a maximum operational frequency of 200 MHz. The switching in memristor was monitored by sampling the DC data before (500 ns) and after (4us) the pulse. The splitting of the signal allows us to study the dynamics of the memristor during switching (Figs. 3, 4a, b, e, f, 5b, e) as well as after the switching was complete (Figs. 4c, g, h, 5d, f, 6c). The ultrafast pulse (TPULSE ~ 120 ps) was generated by sending nano-second pulses through a step-recovery diode-based comb generator. 

### Physical characterization 

The quality of the synthesized hBN films was confirmed by Raman spectroscopy (532 nm laser—Renishaw InVia Raman spectrometer) and X-ray Photo-electron spectroscopy (XPS). The surface topography of the transferred hBN layers was characterized by Atomic Force Microscopy (Bruker Icon AFM). The final device structure was imaged using Optical Microscopy, SEM (Zeiss Neon 40 SEM) and TEM (Jeol neoARM Scanning TEM). The sample cross-section for TEM was prepared using focused ion beam (Thermo Scientific Scios 2 HiVac). 

## Data availability 

The authors declare that the data that support the findings of this study are available within the article and its Supplementary Information files. All other relevant data are available from the corresponding author upon request. 

## References 

1. Talib, M. A., Majzoub, S., Nasir, Q. & Jamal, D. A systematic literature review on hardware implementation of artificial intelligence algorithms. J. Supercomput. 77, 1897–1938 (2021). 

2. Capra, M. et al. An updated survey of efficient hardware architectures for accelerating deep convolutional neural networks. Future Internet 12, 113 (2020). 

3. Stoica, I. et al. A Berkeley view of systems challenges for Preprint at https://arxiv.org/abs/1712.05855 (2017). 

4. Pereira, F., Correia, R., Pinho, P., Lopes, S. I. & Carvalho, N. B. Challenges in resource-constrained IoT devices: energy and communication as critical success factors for future IoT deployment. Sensors 20, 6420 (2020). 

5. Fan, X. et al. Flexible and wearable power sources for next‐generation wearable electronics. Batteries Supercaps 3, 1262–1274 (2020). 

6. Compagnoni, C. M. et al. Reviewing the evolution of the NAND flash technology. Proc. IEEE 105, 1609–1633 (2017). 

7. Hemink, G. & Goda, A. (eds) in Semiconductor Memories and Systems 119–158 (Woodhead publishing, 2022). 

8. Chua, L. Memristor-the missing circuit element. IEEE Trans. Circuit Theory 18, 507–519 (1971). 

9. Strukov, D. B., Snider, G. S., Stewart, D. R. & Williams, R. S. The missing memristor found. Nature 453, 80–83 (2008). 

10. Yang, J. J. et al. Memristive switching mechanism for metal/oxide/ metal nanodevices. Nat. Nanotechnol. 3, 429–433 (2008). 

11. Luo, Q. et al. 8-Layers 3D vertical RRAM with excellent scalability towards storage class memory applications. In: 2017 IEEE International Electron Devices Meeting (IEDM) (ed Gendt, S. D.) 2–7 (IEEE, 2017). 

12. Luo, Q. et al. Demonstration of 3D vertical RRAM with ultra lowleakage, high-selectivity and self-compliance memory cells. In: 2015 IEEE International Electron Devices Meeting (IEDM) (ed Suehle, J.) 10–12 (IEEE, 2015). 

13. Xu, X. et al. Fully CMOS compatible 3D vertical RRAM with selfaligned self-selective cell enabling sub-5nm scaling. In: 2016 IEEE Symposium on VLSI Technology (ed Philip Wong, H. S.) 1–2 (IEEE, 2016). 

14. Ielmini, D. & Wong, H. S. P. In-memory computing with resistive switching devices. Nat. Electron. 1, 333–343 (2018). 

15. Yin, S., Sun, X., Yu, S. & Seo, J. S. High-throughput in-memory computing for binary deep neural networks with monolithically integrated RRAM and 90-nm CMOS. IEEE Trans. Electron Devices 67, 4185–4192 (2020). 

16. Pedretti, G. & Ielmini, D. In-memory computing with resistive memory circuits: status and outlook. Electronics 10, 1063 (2021). 

17. Yin, S. et al. Monolithically integrated RRAM-and CMOS-based inmemory computing optimizations for efficient deep learning. IEEE Micro 39, 54–63 (2019). 

18. Kim, M. et al. Zero-static power radio-frequency switches based on MoS2 atomristors. Nat. Commun. 9, 1–7 (2018). 

19. Kim, M. et al. Non-volatile RF and mm-wave switches based on monolayer hBN. In: 2019 IEEE International Electron Devices Meeting (IEDM) (ed Datta, S.) 5–9 (IEEE, 2019). 

20. Kim, M., Pallecchi, E., Happy, H. & Akinwande, D. Single-PoleDouble-Throw RF switches based on monolayer MoS2. In: 2021 Device Research Conference (DRC) (ed Chen, Z.) 1–2 (IEEE, 2021). 

21. Wong, H. S. P. et al. Metal–oxide RRAM. Proc. IEEE 100, 1951–1970 (2012). 

22. Sawa, A. Resistive switching in transition metal oxides. Mater. Today 11, 28–36 (2008). 

23. Khan, R. et al. Oxide-based resistive switching-based devices: fabrication, influence parameters and applications. J. Mater. Chem. C 9, 15755–15788 (2021). 

24. Carlos, E., Branquinho, R., Martins, R., Kiazadeh, A. & Fortunato, E. Recent progress in solution‐based metal oxide resistive switching devices. Adv. Mater. 33, 2004328 (2021). 

25. Jang, J., Pan, F., Braam, K. & Subramanian, V. Resistance switching characteristics of solid electrolyte chalcogenide Ag2Se nanoparticles for flexible nonvolatile memory applications. Adv. Mater. 24, 3573–3576 (2012). 

26. Pradel, A., Frolet, N., Ramonda, M., Piarristeguy, A. & Ribes, M. Bipolar resistance switching in chalcogenide materials. Phys. Status Solidi (a) 208, 2303–2308 (2011). 

Nature Communications |  (2024) 15:2334 

8 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

27. Gao, S., Yi, X., Shang, J., Liu, G. & Li, R. W. Organic and hybrid resistive switching materials and devices. Chem. Soc. Rev. 48, 1531–1565 (2019). 

28. Yuan, L., Liu, S., Chen, W., Fan, F. & Liu, G. Organic memory and memristors: from mechanisms, materials to devices. Adv. Electron. Mater. 7, 2100432 (2021). 

29. Park, S. P. et al. Analysis of the bipolar resistive switching behavior of a biocompatible glucose film for resistive random access memory. Adv. Mater. 30, 1800722 (2018). 

30. Yang, Y. et al. Electrochemical dynamics of nanoscale metallic inclusions in dielectrics. Nat. Commun. 5, 4232 (2014). 

31. Yang, Y. et al. Observation of conducting filament growth in nanoscale resistive memories. Nat. Commun. 3, 732 (2012). 

32. Qian, F. et al. A leaky integrate-and-fire neuron based on hexagonal boron nitride (h-BN) monocrystalline memristor. IEEE Trans. Electron Devices 69, 6049–6056 (2022). 

33. Clima, S. et al. First-principles thermodynamics and defect kinetics guidelines for engineering a tailored RRAM device. J. Appl. Phys. 119 (2016). 

34. Yu, S., Guan, X. & Wong, H.S.P. On the stochastic nature of resistive switching in metal oxide RRAM: physical modeling, Monte Carlo simulation, and experimental characterization. In: 2011 International Electron Devices Meeting (ed Ishimaru, K.) 17–3 (IEEE, 2011). 

35. Jain, P. et al. 13.2 A 3.6 Mb 10.1 Mb/mm 2 embedded non-volatile ReRAM macro in 22nm FinFET technology with adaptive forming/ set/reset schemes yielding down to 0.5 V with sensing time of 5ns at 0.7 V. In: 2019 IEEE International Solid-State Circuits Conference(ISSCC) (ed Spiegel, J. V. D.) 212–214 (IEEE, 2019). 

36. Liu, T.Y. et al. A 130.7 mm 2 2-layer 32Gb ReRAM memory device in 24nm technology. In: 2013 IEEE International Solid-State Circuits Conference Digest of Technical Papers (ed Nauta, B.) (San Francisco, CA, 2013). 

37. Chang, M. F. et al. 19.4 embedded 1Mb ReRAM in 28nm CMOS with 0.27-to-1V read using swing-sample-and-couple sense amplifier and self-boost-write-termination scheme. In: 2014 IEEE International Solid-State Circuits Conference Digest of Technical Papers (ISSCC) (ed Stetzler, T.) 332–333 (IEEE, 2014). 

38. Chen, Z. et al. Ultrafast multilevel switching in Au/YIG/n‐Si RRAM. Adv. Electron. Mater. 5, 1800418 (2019). 

39. Wang, C. et al. Ultrafast RESET analysis of HfOx‐based RRAM by sub‐nanosecond pulses. Adv. Electron. Mater. 3, 1700263 (2017). 

40. Shrestha, P. R. et al. Energy control paradigm for compliance-free reliable operation of RRAM. In: 2014 IEEE International Reliability Physics Symposium MY-10 (IEEE, 2014). 

41. Choi, B. J. et al. High‐speed and low‐energy nitride memristors. Adv. Funct. Mater. 26, 5290–5296 (2016). 

42. Lee, H. Y. et al. Evidence and solution of over-RESET problem for HfO x based resistive memory with sub-ns switching speed and high endurance. In: 2010 International Electron Devices Meeting (ed Ieong, M.) 19–7 (IEEE, 2010). 

43. Choi, B. J. et al. Electrical performance and scalability of Pt dispersed SiO2 nanometallic resistance switch. Nano letters 13, 3213–3217 (2013). 

44. Torrezan, A. C., Strachan, J. P., Medeiros-Ribeiro, G. & Williams, R. S. Sub-nanosecond switching of a tantalum oxide memristor. Nanotechnology 22, 485203 (2011). 

45. Böttger, U. et al. Picosecond multilevel resistive switching in tantalum oxide thin films. Sci. Rep. 10, 1–9 (2020). 

46. Zhang, F. et al. An ultra-fast multi-level MoTe 2-based RRAM. In: 2018 IEEE International Electron Devices Meeting (IEDM) (ed Takayanagi, M.) 22–27 (IEEE, 2018). 

47. Kim, M. et al. Monolayer molybdenum disulfide switches for 6G communication systems. Nat. Electron. 5, 1–7 (2022). 

48. Chen, S. et al. Wafer-scale integration of two-dimensional materials in high-density memristive crossbar arrays for artificial neural networks. Nat. Electron. 3, 638–645 (2020). 

49. Zhu, K. et al. Graphene–boron nitride–graphene cross-point memristors with three stable resistive states. ACS Appl. Mater. Interfaces 11, 37999–38005 (2019). 

50. Zhuang, P. et al. Nonpolar resistive switching of multilayer‐hBN‐ based memories. Adv. Electron. Mater. 6, 1900979 (2020). 

51. Fantini, A. et al. Intrinsic switching variability in HfO 2 RRAM. In: 2013 5th IEEE International Memory Workshop 30–33 (IEEE, 2013). 

52. Ambrogio, S. et al. Understanding switching variability and random telegraph noise in resistive RAM. In: 2013 IEEE International Electron Devices Meeting (ed Ghani, T.) 31–35 (IEEE, 2013) 

53. Guan, X., Yu, S. & Wong, H.S.P. On the switching parameter variation of metal-oxide RRAM—Part I: Physical modeling and simulation methodology. IEEE Trans. Electron Devices 59, 172–1182 (2012). 

54. Shen, Y. et al. Variability and yield in h‐BN‐based memristive circuits: the role of each type of defect. Adv. Mater. 33, 2103656 (2021). 

55. Shi, Y. et al. Electronic synapses made of layered two-dimensional materials. Nat. Electron. 1, 458–465 (2018). 

56. Lim, E. W. & Ismail, R. Conduction mechanism of valence change resistive switching memory: a survey. Electronics 4, 586–613 (2015). 

57. Chakraborty, I., Panwar, N., Khanna, A. & Ganguly, U. Space Charge Limited Current with Self-heating in Pr0.7Ca0.3MnO3 based RRAM. Preprint at https://arxiv.org/abs/1605.08755 (2016). 

58. Puglisi, F. M. et al. 2D h-BN based RRAM devices. In: 2016 IEEE International Electron Devices Meeting (IEDM) (ed Fay, P.) 34–38 (IEEE, 2016). 

59. Zhu, K. et al. Hybrid 2D–CMOS microchips for memristive applications. Nature 618, 57–62 (2023). 

60. Yu, S. & Wong, H. S. P. Compact modeling of conducting-bridge random-access memory (CBRAM). IEEE Trans. Electron Devices 58, 1352–1360 (2011). 

61. Ielmini, D. Modeling the universal set/reset characteristics of bipolar RRAM by field-and temperature-driven filament growth. IEEE Trans. Electron Devices 58, 4309–4317 (2011). 

62. Huang, P. et al. A physics-based compact model of metal-oxidebased RRAM DC and AC operations. IEEE Trans. Electron Devices 60, 4090–4097 (2013). 

63. Ielmini, D., Nardi, F. & Cagli, C. Physical models of size-dependent nanofilament formation and rupture in NiO resistive switching memories. Nanotechnology 22, 254022 (2011). 

64. Jo, I. et al. Thermal conductivity and phonon transport in suspended few-layer hexagonal boron nitride. Nano Lett. 13, 550–554 (2013). 

65. Alam, M. T., Bresnehan, M. S., Robinson, J. A. & Haque, M. A. Thermal conductivity of ultra-thin chemical vapor deposited hexagonal boron nitride films. Appl. Phys. Lett. 104 (2014). 

66. Panzer, M. A. et al. Thermal properties of ultrathin hafnium oxide gate dielectric films. IEEE Electron Device Lett. 30, 1269–1271 (2009). 

67. Cappella, A. et al. High temperature thermal conductivity of amorphous Al2O3 thin films grown by low temperature ALD. Adv. Eng. Mater. 15, 1046–1050 (2013). 

68. Landon, C. D. et al. Thermal transport in tantalum oxide films for memristive applications. Appl. Phys. Lett. 107 (2015). 

69. Kwon, D. H. et al. Atomic structure of conducting nanofilaments in TiO2 resistive switching memory. Nat. Nanotechnol. 5, 148–153 (2010). 

70. Tsuruoka, T., Hasegawa, T., Terabe, K. & Aono, M. Conductance quantization and synaptic behavior in a Ta2O5-based atomic switch. Nanotechnology 23, 435705 (2012). 

71. Lee, S., Sohn, J., Jiang, Z., Chen, H. Y. & Philip Wong, H. S. Metal oxide-resistive memory using graphene-edge electrodes. Nat. Commun. 6, 1–7 (2015). 

Nature Communications |  (2024) 15:2334 

9 

Article 

https://doi.org/10.1038/s41467-024-46372-y 

72. Zhuang, P., Ma, W., Liu, J., Cai, W. & Lin, W. Progressive RESET induced by Joule heating in hBN RRAMs. Appl. Phys. Lett. 118, 143101 (2021). 

73. Lanza, M. et al. Temperature of conductive nanofilaments in hexagonal boron nitride based memristors showing threshold resistive switching. Adv. Electron. Mater. 8, 2100580 (2022). 

74. Li, S. et al. Fully coupled multiphysics simulation of crosstalk effect in bipolar resistive random access memory. IEEE Trans. Electron Devices 64, 3647–3653 (2017). 

75. Hsieh, C. C., Roy, A., Chang, Y. F., Shahrjerdi, D. & Banerjee, S. K. A sub-1-volt analog metal oxide memristive-based synaptic device with large conductance change for energy-efficient spike-based computing systems. Appl. Phys. Lett. 109, 223501 (2016). 

## Competing interests 

The authors declare no competing interests. 

## Additional information 

Supplementary information The online version contains supplementary material available at https://doi.org/10.1038/s41467-024-46372-y. 

Correspondence and requests for materials should be addressed to S. S. Teja Nibhanupudi, Anupam Roy or Sanjay K. Banerjee. 

Peer review information Nature Communications thanks Mario Lanza, Majid Mohseni and the other anonymous reviewers for their contribution to the peer review of this work. A peer review file is available. 

## Acknowledgements 

This work was performed in part at the University of Texas Microelectronics Research Center, a member of the National Nanotechnology Coordinated Infrastructure (NNCI), which is supported by the National Science Foundation (grant ECCS-2025227). A.R. acknowledges support from the Science and Engineering Research Board, Govt. of India, Grant #SRG/2022/000788. It was supported in part by the Semiconductor Research Corporation grant LMD 3009.001. 

## Author contributions 

S.S.T.N., A.R. and S.K.B. conceived this work and prepared the manuscript. S.S.T.N. synthesized the 2D material, fabricated the memristor and performed electrical characterization. A.R. conducted the X-ray photoelectron spectroscopy measurement. S.S.T.N., D.V. and G.B. set up the ultra-fast pulse measurement setup and helped with analyzing the measurement data. M.C., K.C.M. and J.W. performed the Transmission Electron Microscopyimaging of the fabricated devices. S.S.T.N. and M.D. conducted the temperature based resistance measurement of the fabricated devices. S.S.T.N., A.R., A., J.V.S and J.P.K. were involved in analyzing the measurement results through electro-thermal model, phenomenological model and thermal simulations. I.R.G.D. performed the conductive AFM experiment and analyzed the result. All authors discussed and contributed to the analysis presented in the manuscript. S.K.B. supervised the study. 

Reprints and permissions information is available at http://www.nature.com/reprints 

Publisher’s note Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations. 

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/ licenses/by/4.0/. 

#### © The Author(s) 2024 

Nature Communications |  (2024) 15:2334 

10 

