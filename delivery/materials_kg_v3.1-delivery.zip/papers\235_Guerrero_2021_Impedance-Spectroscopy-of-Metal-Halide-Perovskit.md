# Impedance Spectroscopy of Metal Halide Perovskite Solar Cells from the Perspective of Equivalent Circuits.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Chemical Reviews |
| 年份 | 2021 |
| 引用量（Semantic Scholar） | 272 |
| 作者 | Antonio Guerrero, J. Bisquert, G. Garcia-Belmonte |
| DOI | 10.1021/acs.chemrev.1c00214 |
| 源文件 | 026_Guerrero_2021_Impedance-Spectroscopy-of-Metal-Halide-Perovskit.pdf |

---
pubs.acs.org/CR 

<mark>Review</mark> 





# Impedance Spectroscopy of Metal Halide Perovskite Solar Cells from the Perspective of Equivalent Circuits 

Antonio Guerrero, Juan Bisquert,* and Germà Garcia-Belmonte 

Cite This: Chem. Rev. 2021, 121, 14430−14484 

Read Online 

## ACCESS 

Metrics & More 

##### Article Recommendations 

ABSTRACT: Impedance spectroscopy (IS) provides a detailed understanding of the dynamic phenomena underlying the operation of photovoltaic and optoelectronic devices. Here we provide a broad summary of the application of IS to metal halide perovskite materials, solar cells, electrooptic and memory devices. IS has been widely used to characterize perovskite solar cells, but the variability of samples and the presence of coupled ionic-electronic effects form a complex problem that has not been fully solved yet. We summarize the understanding that has been obtained so far, the basic methods and models, as well as the challenging points still present in this research field. Our approach emphasizes the importance of the equivalent circuit for monitoring the parameters that describe the response and providing a physical interpretation. We discuss the possibilities of models from the general perspective of solar cell behavior, and we describe the specific aspects and properties of the metal halide perovskites. We analyze the impact of the ionic effects and the memory effects, and we describe the combination of light-modulated techniques such as intensity modulated photocurrent spectroscopy (IMPS) for obtaining more detailed information in complex cases. The transformation of the frequency to time domain is discussed for the consistent interpretation of time transient techniques and the prediction of features of current−voltage hysteresis. We discuss in detail the stability issues and the occurrence of transformations of the sample coupled to the measurements. 

### CONTENTS 

|1. Introduction|14431|
|---|---|
|2. Overview of the Impedance Spectroscopy||
|Method|14432|
|3. A Guideline for Presentation of Results of IS of<br>MHP|14433|
|3.1. Basic Elements of Reliable Measurement<br>and Interpretation|14433|
|3.2. Fundamental Equivalent Circuit of a Solar<br>Cell|14435|
|3.3. Why Use Equivalent Circuits to Describe IS<br>Data|14435|
|4. Capacitances of MHP Devices|14437|
|4.1. Dielectric Relaxation and Conductivity|14438|
|4.2. Chemical Capacitance|14439|
|4.3. Contact Polarization Effects|14440|
|4.4. Characteristic Features of Capacitance of<br>MHP|14440|
|4.5. Determination of Doping Densities by the<br>Mott−Schottky Method|14442|
|4.6. Capacitive Response of Defect Levels|14443|
|5. Equivalent Circuit of MHP Solar Cells and Their<br>Interpretation|14445|
|5.1. Search for a General Equivalent Circuit and<br>Need of Simplification|14445|



- 5.1. Search for a General Equivalent Circuit and Need of Simplification 

   - 5.2. Response of Optimized Perovskite Solar Cells 

- Cells 14446 

- 5.3. Series or Parallel Connection and Physical Interpretation 14447 

- 5.3.1. Importance in the Arrangement of Elements 14447 

- 5.3.2. Interpretation of the Impedance Models That Include Dielectric Relaxationlike Subcircuits 14448 

- 5.4. Simplified Equivalent Circuits that Account for Inefficient Contacts 14452 

- 6. Resistance and Recombination Mechanisms 14454 6.1. Recombination Parameters 14454 6.1.1. Recombination Lifetime 14454 6.1.2. Ideality Factor 14454 6.1.3. Recombination Resistance 14454 

   - 6.2. Recombination and Correlation of Resistances 14455 



Received: March 12, 2021 Published: November 30, 2021 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

© 2021 American Chemical Society 

14430 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

|6.3. Resistances in the Dark<br>f|14456|
|---|---|
|7. Ionic Diffusion and Transmission Line Observa-||
|tion|14456|
|8. Negative Capacitance Phenomena|14458|
|8.1. Frequently Observed Negative Capacitance<br>|14458|
|8.2. Interpretation of the Inductor Element and<br>the Negative Capacitor<br>|14459|
|8.2.1. Kinetic Origin of the Inductive Loop<br>|14459|
|8.2.2. Inductive Impedance Spectra|14460|
|8.2.3. Inductor or Negative Capacitance?|14461|
|8.2.4. Nonequilibrium Intrinsic Negative Ca-<br>pacitance<br>|14461|
|8.3. Interpretation of Negative Capacitance by<br>||
|Modulation Currents|14462|
|9. Light-Modulated Small Perturbation Techniques||
|(IMPS and IMVS)<br>|14462|
|9.1. Methods of IMPS and IMVS<br>f|14462|
|9.2. Correlation of the Different Techniques<br>f|14463|
|9.3. Observation of Diffusion−Recombination of<br>Electrons by IMPS<br>|14464|
|10. Time Domain Methods and Time Constants<br>|14465|
|10.1. Interpretation of Time Constants<br>|14465|
|10.2. Transformation between Frequency and<br>Time Domain Methods<br>|14467|
|10.2.1. Small Perturbation Time Transient<br>Techniques<br>|14468|
|10.2.2. Large Perturbation Time Transient<br>f||
|Techniques: Hysteresis Effects<br>f|14468|
|11. Memory Effect Devices|14470|
|12. Stability, Reproducibility, and Noise<br>|14471|
|12.1. Evolution of the Perovskite Material|14472|
|12.2. Evolution of Perovskite/External Layers<br>Interfaces<br>|14472|
|12.3. Degradation of External Contacts|14474|
|12.4. Stability of Response and Kramers−Kronig<br>Test<br>|14474|
|12.5. Reduction of Noisy IS Response|14474|
|13. Summary|14475|
|Author Information|14475|
|Corresponding Author|14475|
|Authors|14475|
|Notes|14475|
|Biographies<br>|14475|
|Acknowledgments|14476|
|References|14476|



### 1. INTRODUCTION 

Semiconductor materials based on metal halide perovskite (MHP) have been the object of extensive investigations owing to their exceptional optoelectronic properties that may lead to applications in areas such as solar cells, light emission diodes, X-ray detectors, etc. The chemical formula of the perovskite can be described as ABX3 where A = monovalent cations such as methylammonium (MA), formamidinium (FA), cesium (Cs), B = divalent cations such as lead (Pb), tin (Sn), and X = halide anions including chloride (Cl), bromide (Br), and iodide (I). MAPbX3 was first synthesized by Weber in 1978.<sup>1</sup> The first attempt of applying methylammonium lead halide (bromide, iodide) (MAPbBr3, MAPbI3) in solar cells was reported by Kojima et al. in 2009.<sup>2</sup> The first reported power conversion efficiency (PCE) was very discrete with only 3.81%, and degradation was very severe. In the subsequent years, 

extraordinary fast progress has been obtained thanks to the advancement in material engineering and interface optimization. In the device configuration, a layer of the absorber perovskite material of about 500 nm is sandwiched between two charge selective layers of varied structures and compositions. In 2015, a PCE of over 20% was obtained by the replacement of most of the MA cation by FA cation that reduces the bandgap of the semiconductor and increases the photocurrent.<sup>3</sup> The reproducibility and stability of the cells were improved using a combination of two or three cations (MA, FA, Cs, and Rb) in the perovskite formulation.<sup>4−6</sup> At the same time, Br was used in addition to I to tune the band gap energy and to increase the tolerance to oxidation.<sup>5,7</sup> More recently, efforts have been focused to optimize the perovskite compositions to control the trade-off between photon absorption of the low bandgap perovskites and thermalization losses.<sup>8</sup> For lead halide perovskites, this was achieved by increasing the molar concentration of formamidinium lead iodide in the perovskite formulation. Passivation of the external interfaces and improvement of the charge extraction layers have enhanced the external charge collection and stability of the devices.<sup>9,10</sup> For example, the introduction of large cations like phenyl ethylammonium (PEA) have enabled the formation of quasi-2D perovskites capping layers that benefit from reduced ion migration and adequate charge extraction.<sup>11</sup> In parallel, understanding the degradation pathways has been key to improving the solar cell stability while maintaining high performances.<sup>12</sup> Stability has been improved over the years by properly controlling extrinsic (i.e., ingress of water or oxygen) and intrinsic factors (i.e., ion migration or phase stability), but further work is still required. The current certified record power conversion efficiency (PCE) of the perovskite solar cell (PSC) is 25.5% for single junction solar cells.<sup>13</sup> Further improvements are expected in the future in terms of efficiency and stability by a proper understanding of the operation and degradation mechanisms. 

The operation of solar cells depends on a wide range of physical phenomena such as the extent of recombination, large carrier mobilities, and the suitability of contacts for extracting the generated charge.<sup>14,15</sup> The main goal of the characterization of solar cells is to explain the steady-state behavior, defined by the current density−voltage curve (j−V). This curve is ultimately responsible for the PCE from light to electricity. However, the steady-state characteristic alone is not sufficient for extracting information about the dynamic phenomena that determine the physical behavior. To obtain such information, it is necessary to perturb the system by an imposed external signal and record the response. 

There is an ample set of light and voltage perturbation methods in the time domain that measure the recovery toward the equilibrium state. On the other hand, one can use frequency domain small perturbation methods. Here the perturbation is a sinusoidal function, and the response becomes a stable sinusoidal as well. If the input and output signals are of the same physical kind, their quotient becomes an impedance. More generally, if one uses, e.g., the ratio of photon flux to electrical photocurrent (as in intensity modulated photocurrent spectroscopy, IMPS), the quotient is a transfer function.<sup>16</sup> The main advantage of using characterization methods by a small perturbation in the frequency domain is that the impedance or transfer function provides spectroscopy from which one can infer separated physical properties that govern the response of the device. 

14431 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 1. J−V curve of a perovskite solar cell with a diagram that explains the impedance spectroscopy measurement and representative complex impedance plots measured at different VDC values. 

However, when investigating new systems, this apparently simple statement becomes in practice a difficult task, involving extensive experimental measurements, experience, and skillful interpretation in some cases. 

In this paper, we will explain the current understanding of the application of the method of impedance spectroscopy (IS) to PSC. The excellent books by Lasia,<sup>17</sup> Orazem and Tribollet<sup>18</sup> provide all the basic resources of the method applied to electrochemical systems. An introduction to the main concepts and methods of IS applied to solar cells, i.e., the capacitance, resistance, equivalent circuit, etc., can be found in the textbook.<sup>19</sup> A summary of solar cells characterization by IS may be found in refs 20 and 21. There has been extensive work on device characterization for PSC and related devices,<sup>14,22,23</sup> but a picture is not yet complete, and many questions remain open. The purpose of this review article is to present the basic methods, the main results, and the dominant equivalent circuits (EC) that form the basis for a physical interpretation of the physical and material properties of perovskite photovoltaic and electrooptic devices. We will also point out the assessment of stability of the solar cell operation as well as peculiar behavior concerning negative capacitance and memory effects. 

### 2. OVERVIEW OF THE IMPEDANCE SPECTROSCOPY METHOD 

In the small perturbation technique of IS, a small oscillating voltage indicated by a tilde is applied in addition to a DC voltage signal, V(ω) = VDC + Ṽ(ω) where ω is the angular frequency and f = ω/2π. The differential current output I(̃ ω) is measured to form the complex impedance, defined as 



<!-- Start of picture text -->
V ( ω )<br>Z ( ω ) =̃̃<br>I ( ω ) (1)<br><!-- End of picture text -->

The impedance function is represented in terms of the real and imaginary parts 



<!-- Start of picture text -->
Z ( ω ) = Z ′( ω ) + iZ ″( ω ) (2)<br><!-- End of picture text -->

The complex impedance plot representation shown in Figure 1 is a useful way to visualize the electrical response of the device. In this type of representation, the x-axis is connected to the resistive contributions, which correspond to the real part of the impedance (Z′). On the other hand, since the AC phase of a capacitor is 90°, the imaginary y-axis (-Z′′) relates to the capacitive contributions. 

Data points over many decades are taken to cover the whole range between 1 MHz and 10 mHz, in order to scan a substantial range of the dynamic phenomena that govern the response. The frequency of the perturbation will determine the type of physical parameter which is monitored at each stage. The measurement usually starts at high frequencies of about 1 MHz. In this range of frequencies, the impedance is small, as at high-frequency capacitances act as short circuits. The data points correspond to values close to the origin of the complex plane plot (see inset in Figure 1 at VDC = 0 V). Typically, at intermediate to high frequencies (HF) (1 Hz−1 MHz) the AC perturbation promotes electronic displacement and dipolar relaxation. At low frequencies (<1 Hz), the effect of ionic contact phenomena and electrochemical reactions may be observed. An elementary process consisting of a parallel combination of resistance and capacitance (RC element) produces a semiarc in the complex plane.<sup>19</sup> A characteristic time constant can be attributed to such an arc with the value 



<!-- Start of picture text -->
τ = RC (3)<br><!-- End of picture text -->

By representing all the measured points in the complex plane, the spectral picture shows well-resolved arcs when different processes are separated with respect to frequency. 

14432 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> <u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

Table 1. Criteria for Measuring and Reporting IS of MHP Devices 

|criteria|how|
|---|---|
|describe the experimental conditions accurately|report atmosphere (% relative humidity, dry air, N2, O2...) in which the experiment is carried out, light conditions<br>(intensity and type of light source), storage conditions of the device, overall time measurement, biasing history,<br>or waiting times|
|ensure reproducibility|repeat the measurement using exactly the same conditions on a statistically meaningful number of independent<br>devices (>5 devices)|
|test regularly the efficiency of the device|record a j−V curve before and after a frequency scan during the IS measurements|
|use of EC|use models to fit the spectral data to be able to quantify the different parameters|
|plot the evolution of fitting parameters|thefitted resistances and capacitances can be monitored as a function of external control parameters, e.g., the DC<br>voltage or current, to analyze the meaning of the observed elements.|
|make modifications of samples|compare the IS results of samples that vary one aspect: a change of a contact, a passivation layer, a modification of<br>layer thickness, etc., to determine the origin of spectral features|
|when possible, correlate with other techniques|combine IS data with analytical, microscopy, optical, and electrooptical techniques to support general claims|



Measurements can be carried out under different illumination conditions (i.e., from dark up to 1 sun) to seek specific contributions to the measured current. The device may be probed at different positions on the j−V curve, positions in which the operation mechanism may be totally different. At each point of voltage, the impedance spectrum provides the information about the system response as a function of frequency. 

The examples shown in Figure 1 correspond to a perovskite device in the configuration FTO/TiO2-compact/TiO2-mesoporous/MAPI/spiro/Au. The device shows PCE in the range of ∼17% and has been measured at 1 sun at different DC voltages sweeping from 0 V to open-circuit voltage value, Voc. We observe in Figure 1 the evolution of spectra along the different points of the j−V curve. Let us anticipate some interpretations that will be further discussed later. At 0 V, two arcs are observed that provide information on the recombination kinetics of the device in the bulk of the perovskite semiconductor and at the contacts. Also, the effects of shunt resistances are observed at zero bias. The arcs decrease their size as we increase the applied DC bias, and a new feature appears at low frequencies (LF) below <0.1 Hz. This feature is related to accumulation of ions followed by electrochemical reactions at the external interfaces that reduce the measured resistance with time by decreasing the extraction barriers. This low-frequency feature can turn into an inductive element that crosses the Z′ axis (1.0 or 1.1 V). 

Beyond the visual observation of the spectral features, a quantitative analysis requires the identification of the different equivalent electrical elements that cause the observed response and ultimately to obtain a physical interpretation. The individual resistive and capacitive contributions will be described in the following sections. The elements are distributed in a particular topology that accounts for serial and parallel carrier phenomena. These features of the physical response are conveniently conveyed by an EC representation, combined with the dependence of resistances and capacitors with the external variables such as bias voltage and light intensity. Therefore, the standard procedure for the analysis of the IS requires fitting the experimental results with an EC model in which each element from the circuit corresponds to a physical process in the operating device. A major task of the research for the characterization of a family of photovoltaic and electronic devices is to establish an adequate framework of interpretation, preferably in the form of an EC that may have different versions according to specific system properties. Once a consolidated tool of interpretation is accepted, it is extremely useful for assessing the quality of devices, identifying their 

possible weaknesses, and for investigating new phenomena and configurations. 

### 3. A GUIDELINE FOR PRESENTATION OF RESULTS OF IS OF MHP 

#### 3.1. Basic Elements of Reliable Measurement and Interpretation 

The main advantage of the impedance spectroscopy technique is that it is a very simple nondestructive method to characterize a device which contains contacts and can be operated electrically as in the real application. This advantage is sometimes a weakness if a well-established model for the interpretation of experimental results is not available. Unfortunately, this technique is not analyzed properly in many published papers related to PSCs. It is common to observe a graph with a complex plane plot of two different devices and an ad hoc model developed to justify the hypothesis of the authors without any contrasted base. The direct comparison of a couple of impedance spectra instead of the study of the trends at different voltage or illumination conditions cannot provide an accurate analysis of the samples. 

The number of possible research situations is endless, and there may be a variety of uses for the technique. Here we adopt a series of criteria based on our experience to indicate which should be the minimal precautions when performing and presenting IS results. Following these guidelines should avoid unwanted situations in which presented data provide scarce knowledge and only contribute to a multiplication of scientific papers with limited addition to significant understanding. 

We treat a number of issues and provide a summary guide in Table 1. Many of the aspects will be discussed in detail in later sections of this review, but we think it is useful to start with a general landscape of the experimental requirements criteria to have trust in the data and to obtain acceptable scientific explanations. 

PSCs are well-known to be sensitive to the experimental conditions in which common external stimuli such as humidity, light or applied voltage, or previous biasing totally modify the electrical response.<sup>24</sup> For this reason, a precise description of the experimental details is needed to extract meaningful electrical properties of PSCs. In addition, only one parameter must be probed at the time for the purpose of extracting general information of PSCs operation mechanisms. In this respect, impedance measurements carried out in ambient conditions are problematic since they combine light/voltage with the reactivity of the water present in the ambient with the perovskite material. The use of highly controlled conditions should always be the choice, provided the experimental set up 

14433 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

provides the opportunity; otherwise, the precise conditions need to be reported as described in Table 1. 

Testing the reproducibility of the electrical response is always required since a large variability is often observed in devices fabricated within one batch. Statistical data of at least 20 devices are normally needed to properly report the j−V performance parameters. Here we propose the characterization of at least five independent devices when reporting IS results. The measurement time of a single applied DC voltage takes 5− 15 min; therefore, this number of repetitions is reasonable. The IS measurement may be a relatively fast or slow measurement depending on the frequency range under study. For example, it takes either 0.1 or 100 s to record a single data point with lowfrequency limits of 10 Hz or 10 mHz, respectively. The total time of the measurement is predominantly determined by the information that we wish to extract in the very low frequency regime. This must be balanced against other factors such as reproducibility of several samples. Devices will be reproducible when resistances and capacitances are not too dispersed (within 20%) and when tendencies with time are maintained. For example, if the evolution of parameters is being analyzed, the same tendency needs to be recorded for the five devices. 

Activated reactivity of the perovskite materials and the dynamic nature of ions motion that modifies the extraction properties of the contacts are responsible for hysteresis observed during the electrical characterization.<sup>23</sup> Therefore, the evolution of the performance parameters, often observed during the IS measurements, needs to be monitored. We propose to record a j−V curve before and after each frequency scan in IS or use another method to evaluate the performance evolution such as chronoamperometry (CA) or maximum power point (MPP) tracking measurements. Here, we need to remind the reader that the IS measurement reflects the efficiency of the device in the same way as the j−V, but more complex information may be extracted. Therefore, if the device shows unsatisfactory performance, then both the j−V and IS will similarly exhibit the typical signatures for poorly performing devices; i.e., a device fabricated with a poor contact which does not enable the extraction of carriers will show a low fill factor and high contact resistance. 

The best practice to report IS results is to show the fitting parameters of an accepted EC model and to show the complex impedance plot or capacitance−frequency graphs depending on the type of discussion. By using the fitting results, it is possible to quantify the different parameters and show their evolution with the control variables of the measurements. The main controversy here is to decide which EC is best suited for a given device configuration. An excellent resource is to study samples in which geometric or materials characteristics are varied one by one, in order to identify the origin of specific aspects of the spectral response. For example, attributing a feature to the bulk response requires showing that it scales with sample thickness. Contrarily, features associated with the contact interface should be independent of the distance between the electrodes, as shown for the thickness dependence of the capacitances measured in PSCs; see Figure 2.<sup>25</sup> These topics will be covered in different sections of the present review. 

Once an adequate EC is chosen, reporting the evolution of resistances and capacitances with voltage will provide very useful information for establishing the physical origin of the elements and design improved device materials and configurations. For example, new resistances associated with 



Figure 2. Capacitance as a function of the perovskite layer thickness at different temperatures extracted from (a) low-frequency plateau corresponding to the electrode polarization and (b) intermediate frequency plateau caused by dipolar polarization. Reproduced with permission from ref 25. Copyright 2015 American Chemical Society. 

physical/chemical processes may appear which are not visible by other techniques such as the j−V curve. When an EC is widely consolidated for a class of devices, it can be used as a rapid tool for assessing the quality and behavior of devices. On the other hand, if unexpected features occur in the impedance spectra, their origin needs to be investigated. 

It is important to remark on the connection between AC and steady-state DC measurements in eq 4. The total resistance (the impedance at zero frequency) can be obtained by the very low frequency value of the spectra in the real axis. It is a differential quantity defined as a function of current and voltage as 



<!-- Start of picture text -->
i ∂ j y−1<br>R tot = jjjk∂ V zzz{ (4)<br><!-- End of picture text -->

This statement acts as a practical tool for checking that IS results are meaningful and that the measurement is reproducible. As an example, Figure 3a shows the impedance measurement of a 2D Ruddlesden−Popper perovskite-based memristor device at different bias voltages.<sup>26</sup> The spectra show a characteristic double arc with formation of a negative capacitance (inductive) feature when the threshold voltage for transition to the high conduction state has been reached as shown in Figure 3c. From this quasi-static j−V curve, the lowfrequency resistance can be established by differentiation as in eq 4. In Figure 3d, it is confirmed that the low-frequency resistance measured by IS coincides from that obtained from j−V curves, indicating that there is no further structure to the low-frequency arcs. It is satisfactory that even in a highly nonlinear system with a strong memory effect the sample provides the same electrical characteristics on independent measurements made at different times. Figure 3b shows the IS spectra of a sample that differs from the former just by the addition of a spiro-OMETAD layer. It can be observed that IS is extraordinarily sensitive to the addition of just one layer, as it modifies the operational characteristics of the device. 

Finally, we remark that IS is an indirect measurement subject to much freedom of interpretation. For this reason, it is very important to correlate the data and interpretation with other techniques that help to support the IS results, as just 

14434 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> <u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 3. (a) IS spectra evolution of a FTO/PEDOT:PSS/2D Ruddlesden−Popper perovskite/Ag (15 nm)/Au (85 nm) memristor device at representative voltages. (b) IS spectra evolution of device with an additional spiro-OMETAD layer. (c) j−V curves (d) RDC‑jV, RDC‑IS, Z′0.1 Hz and Zint′ (intercept) voltage dependence of the Ag ReRAM device. Reproduced with permission from ref 26. Copyright 2021 AIP Publishing. 

suggested about the correlated results at low frequency. The application of different frequency modulated methods as IMPS will be explained in section 9. The use of direct analytical techniques such as XPS or TOF-SIMMS, microscopy methods like SEM or additional optical techniques like absorption/ emission experiments provides complementary information to interpret the observed behavior. When these analytical techniques are not available or beyond the expertise of the researchers, it is preferable to use validated ECs. 

#### 3.2. Fundamental Equivalent Circuit of a Solar Cell 

The investigation of an emerging solar cell must start at the fundamental model that is described in Figure 4, namely, a semiconductor with good transport characteristics endowed with selective contacts.<sup>19</sup> By linearization of conservation equations,<sup>27</sup> the circuit of Figure 4b is readily constructed, which contains the central elements associated with photovoltaic operations: the chemical capacitance Cμ and the recombination resistance Rrec as in eq 6. The chemical capacitance relates the increase of carriers to the change of Fermi levels, and it is explained later in eq 19. There is a necessary amount of recombination in the solar cell (in the most favorable situation, this is purely radiative recombination); therefore, Rrec is a necessary element: it should be as large as possible indicating a low internal recombination rate. 

An additional factor that often poses an important effect is the transport of carriers along the thickness needed to absorb the full spectral light intensity, as indicated in Figure 4c.<sup>27</sup> Then, the point impedance of Figure 4b is converted into a transmission line model shown in Figure 4d.<sup>28,29</sup> The recombination resistance is connected in parallel to the chemical capacitance, and moving along the distance appears the transport resistance (rd, reciprocal to the carrier conductivity). This model has been widely used in the analysis of several types of emerging solar cells.<sup>20,28,30</sup> The diffusion− recombination transmission line model produces the impedance patterns shown in Figure 5. If the transport resistance is small (with respect to the recombination resistance), then it is visible as a Warburg impedance at high frequency, indicative of the diffusion process, with a characteristic inclination of 45°, Figure 5a,b. Otherwise, if the transport feature is large, then the diffusion length is shorter than the sample size, and one obtains the Gerischer impedance of Figure 5c.<sup>29</sup> Additionally, solar cells show the contact impedances in a parallel or series connection to the central RC circuit. 

#### 3.3. Why Use Equivalent Circuits to Describe IS Data 

The IS technique is a rather transversal method widely used in electrochemistry and material science and engineering. The different possibilities for applying ECs in emerging solar cells 

14435 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 4. (a) Fundamental model of a solar cell consisting of a twolevel semiconductor absorber with selective contacts, indicating the processes of charge generation, recombination, injection, and extraction. (b) The EC corresponding to (a) consists of a recombination resistance and chemical capacitance. (c) The solar cell model for a spatially extended absorber includes the transport process along the conduction and valence band levels. (d) The EC corresponding to (c) is a repetition of the model of (b) connected by the diffusion resistances. (e) The fundamental EC for IMPS including a current generator that accounts for carrier generation. 



Figure 5. Diffusion−recombination impedance spectra with reflecting boundary condition corresponding to Figure 4d. Simulation of the impedance with parameters Rrec = 10<sup>3</sup> Ω, Cμ = 5 × 10<sup>−6</sup> F (a) low transport resistance Rt = 10<sup>4</sup> Ω, (b) expanded view of near origin region, and (c) Gerischer impedance with high transport resistance Rt = 10<sup>4</sup> Ω. Shown are the frequencies in Hz at selected points, the characteristic frequency of the low-frequency arc (square point), related to the angular frequency ωrec = τ−n 1, and the low-frequency resistance. The frequency (Hz) of the turnover from Warburg behavior to low-frequency recombination arc (square point), related to the characteristic frequency of diffusion ωd is also shown. Reproduced with permission from ref 29. Copyright 2013 John Wiley and Sons. 

have been recently well summarized.<sup>21</sup> The use of EC is not the only way to interpret the data, but we would like to argue its significance from a fundamental point of view. 

As explained in Figure 1, IS methods operate by small perturbation over a steady state that can be at fixed voltage (potentiostatic) or fixed current (galvanostatic). In general, the system is described by a set of physicochemical equations that involve voltage, current, and different internal variables, such as carrier densities of the different entities in the system. This model may be rather complex and highly nonlinear. However, according to the method of IS response, by the small perturbation criterion, the underlying equations are linearized around a certain point of operation. After this procedure, the resulting system of equations must necessarily be linear. In the end, the small perturbation current is proportional to the small perturbation voltage, and their relationship, eq 1, is independent of any amplitude. It only depends on the external parameters of the steady-state point and the frequency. Since the system of equations that describes the impedance function is linear, it can be represented as an EC of resistors, capacitors, and inductors that may take positive or negative values. 

The linear system of equations and the corresponding circuit representation may be quite complex. Therefore, the representation of electronic processes in a semiconductor provides a transmission line model as in Figure 4d, based on a linear system of equations, first formulated by Shockley.<sup>31</sup> Electrochemical systems may become oscillatory at unstable points; however, the stability criteria can be based on linear systems of equations concerning the impedance.<sup>32,33</sup> A numberless variety of complex systems have been treated in the literature, based on ECs. 

While it is not strictly necessary to establish an EC for the physical analysis, by constructing a model as an EC, we ensure that it obeys the linear response criterion and that it is a valid IS model. In addition, the EC is an excellent tool to compare different experiments reported in the literature in a unified framework since it is very easy to view the interpretation of the spectral features adopted by the experimenters. 

There are some additional aspects that are worth taking into account: 

(1) An EC model is not unique. A specific model can be described by different combinations of elements that produce the same impedance. Traditionally, this causes uncertainty about the physical significance of this tool. This point is discussed in section 5.2, and a full account is given in ref 34. This fact is not an impediment to use EC models; rather, it is a call to establish meaningful EC models that capture the physical properties of the system. 

(2) Models that include nonlinear elements are not appropriate to deal with IS data. For example, you cannot include diodes or transistors, since these do not represent a small perturbation response and hence do not belong to the IS method. Figure 6 shows a standard model to describe a solar cell including a diode element. This is a valid circuit to describe the j−V curve of the solar cell but not the IS response at one point of it. We can write the current−voltage characteristic of the diode element as 



<!-- Start of picture text -->
= qV / mk B T −<br>j j 0( e 1) (5)<br><!-- End of picture text -->

where V is the forward voltage, q is elementary charge, kBT is the thermal energy, j0 is the saturation current, and m is the ideality factor. By taking the derivative in eq 5, we get the 

14436 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 6. Standard EC for DC response of a solar cell, with a diode element, a current source that represents illumination, a shunt, and a series resistance. 

recombination resistance that decreases as the forward voltage increases as follows: 



<!-- Start of picture text -->
R rec = mkqj B0 T e− qV / mk B T (6)<br><!-- End of picture text -->

This is the voltage-dependent differential resistance of the diode. It is the resistance in the fundamental model in Figure 4b. Equation 6 is the response of the diode when we perform a small perturbation, while eq 5 describes the behavior of the diode under a large variation of the voltage. In Figure 1, Rrec relates to the gradient of the tangent of the curved diode characteristic at the selected point. The correlation between the DC and AC model of a solar cell has been described in general.<sup>35</sup> As deduced by examining Figure 6, shunt resistance is connected in parallel with Rrec and, consequently, will dominate the resistive response as Rrec ≫ close to short-circuit conditions (see later section 6.2). 

(3) For a system composed of a multilayer device involving different carriers and interfaces, we can guess that the underlying physical model and the correspondent linearization may become a fabulous problem involving a very large system of equations. Do we need to formulate such a model before analyzing the data? The answer is no since we are ready to use a rather simplified model that contains the experimental characteristics of the IS response. In this sense, the EC that we use does not need to consider all potential aspects of the system; it rather has to account for the experimentally significant features. Either starting from a general theory, or by constructing heuristic models, of which many are possible,<sup>36</sup> one should try to find a minimal EC in accord with the measured response of the system. The IS response usually corresponds to the least resistive pathways, and, usually, a reduced number of elements are present in the spectra. For this reason, simplified circuits are selected. One needs to be aware that the electrical response in general will depend to the measuring conditions: the range of DC bias, light conditions, and frequency. A complete EC that considers all the potential elements and effects composing the multilayer device is useful for understanding the device working mechanism in theory. However, the use of this complete EC very often is useless from the practical point of view since the system will be overparameterized, and the resulting fitted parameters are not reliable. More than one set of parameters would fit the same experimental data. One example of the process of simplification of an EC is shown in Figure 7. When the diffusion resistance is neglected in a high mobility semiconductor, there is no need to use a transmission line model since the transport features can be eliminated from the outset: they will not be observed in measurements due to a very low total resistance. This is how a general transmission line in Figure 7a reduces to 



Figure 7. (a) A transmission line model for diffusion and recombination. (b) The same model when the transport resistance is negligible. (c) Case (b) can be written as two elements in parallel; the transmission line is not needed. 

the lumped circuit in Figure 7c, the parallel connection of chemical capacitance, and recombination resistance. 

(4) An alternative approach to the use of ECs is to apply numerical simulations to describe the small perturbation frequency techniques. This method is very powerful to generate the expected shapes of spectra in complex situations involving multiple carriers and inhomogeneous distributions. However, the method has some drawback when applied in practice to PSC and related systems. These tools emphasize the drift-diffusion transport equations and concentrate on the transport region. But PSCs have distinct features on the surface, of the thickness of a Debye layer<sup>37,38</sup> (see Figure 9) and specific interfacial energetics<sup>39,40</sup> that are often excluded from the modeling in small perturbation conditions. This problem has been clearly explained in ref 41 as shown in Figure 10. Without the inclusion of proper interface resistances and capacitances, the simulated features correspond predominantly to the electrons and holes transport evolution, and the only visible capacitances are the chemical capacitance and the dielectric capacitance.<sup>42,43</sup> This is a major problem as discussed in section 5.2 since the model lacks essential elements, and the results are highly artificial, in the sense that spectra are similar to those observed in experiments, but the physical origin is totally different so that there is no addition to the understanding of the system. Equivalent circuits and simulation methods should be viewed as complementary instead of competing approaches since each has its own strengths and weaknesses, and the best methodology should be to combine the use of both. While the use of simulations is powerful and can provide important insights, it would be useful that authors of simulation work would sketch at least the EC structure of the linearized set of equations they are using, in particular, to explain very clearly the critical issue of how they have treated the contact impedances, that often produce a dominant effect at low frequencies, and identify the origin of the associated time constants in terms of RC elements, as in Figure 30 and Figure 60. 

### 4. CAPACITANCES OF MHP DEVICES 

Much work has been carried out in the last few years to understand the origin of the capacitances in MHP. In this section, we start with the description of the different types of 

14437 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

#### <u>Chemical Reviews</u> 

capacitances that can be monitored by IS in general, and later we focus on the experimental conditions to reveal each of them. 

#### 4.1. Dielectric Relaxation and Conductivity 

The charge distribution of ionic/electronic systems can be probed by the IS technique by analyzing the capacitances of the system.<sup>19</sup> The complex capacitance C(ω) is defined from the impedance as 



<!-- Start of picture text -->
1<br>C ( ω ) =<br>iωZ ( ω ) (7)<br><!-- End of picture text -->

The complex capacitance can be separated into real and imaginary parts as 



<!-- Start of picture text -->
C ( ω ) = C ′( ω ) − iC ″( ω ) (8)<br><!-- End of picture text -->

As indicated in the previous definitions, the capacitance is a function of the frequency. It is useful to represent the function C′( f) that shows increments of the capacitance as the frequency decreases. A number of distinct capacitive phenomena can be expected that we describe generally in the following paragraphs. 

The complex dielectric constant is obtained from the complex capacitance and the area A and thickness d of the sample 



<!-- Start of picture text -->
ε ( ω ) = dC ( ω )<br>Aε 0 (9)<br><!-- End of picture text -->

#### We can write 



<!-- Start of picture text -->
ε ( ω ) = ε ′( ω ) − iε ″( ω ) (10)<br><!-- End of picture text -->

The real part of the dielectric constant indicates the increase of charge accumulated by polarization, while ε″ is denoted as “dielectric loss” as it determines the dissipation of energy in excess of the dc dissipation. A dielectric capacitance associated with the dielectric relaxation relates to charge separation and polarization under an electrical field. The frequency dependence of the real part of the permittivity and the dielectric loss are closely related. In general, a peak in the dielectric loss that corresponds to a specific dielectric relaxation mechanism produces an increase of the real part of the permittivity, as dictated by the Kramers−Kronig relationship.<sup>44−46</sup> This pattern is shown in Figure 8 for Debye and Cole−Cole relaxation models further explained in section 5.2. For one given mechanism, the increment of the complex permittivity from its high-frequency value can be expressed. 



<!-- Start of picture text -->
Δ ε = ε s − ε ∞ (11)<br><!-- End of picture text -->

Here εs is the “static” value of the real part of the dielectric constant, while ε∞ is the high-frequency limit. The latter can be associated with an “instantaneous” relaxation due to the displacement of the electrons with respect to the nuclei and of ions with respect to their normal equilibrium positions, and it gives the geometrical capacitance per unit area. 



<!-- Start of picture text -->
ε 0 ε ∞<br>C =<br>g d (12)<br><!-- End of picture text -->

The conduction properties are generally described by the ac conductivity (σ(ω) = d/Z(ω)A) that can be separated into a real and imaginary part as 



<!-- Start of picture text -->
σ ( ω ) = σ ′( ω ) + iσ ″( ω ) (13)<br><!-- End of picture text -->



<!-- Start of picture text -->
pubs.acs.org/CR Review<br><!-- End of picture text -->



Figure 8. Real (ε′) and imaginary part (ε″) of the complex permittivity for an elementary relaxation with increment Δε = 10. (a) Debye relaxation. (b) Cole−Cole relaxation with parameter α = 0.4; see eq 31. The bottom line is the corresponding ECs including the capacitance Cg related to ε∞, the additional branch Rdr and Cdr that describes the dielectric relaxation toward low frequencies, and the constant phase element (CPE) that replaces the resistance in the case of a broad Cole−Cole relaxation. 

We have the relationships between conductivity and dielectric constant 



<!-- Start of picture text -->
σ ′( ω ) = ωε 0 ε ″( ω ) (14)<br>σ ″( ω ) = ωε 0 ε ′( ω ) (15)<br><!-- End of picture text -->

The ac conductivity produces features in the permittivity representation and vice versa. 

Often in ionic or electronically conducting solids, the real part of the conductivity, taken over a frequency range from mHz to GHz, presents a constant domain at low frequencies σ0 and thereafter increases rapidly at high frequencies, as described by the expression<sup>47,48</sup> 



<!-- Start of picture text -->
σ ′( ω ) = σ 0[1 + ( ω / ωm ) n ] (16)<br><!-- End of picture text -->

where the frequency ωm marks the onset of the dispersion that takes the form of a power law σ′ ∝ ω<sup>n</sup> , with the exponent 0 < n ≤ 1 lying usually in the range 0.6−0.8. This dependence is shown in Figure 9,<sup>49</sup> in the high-frequency part. The origin of the universal behavior of the conductivity has been broadly 



Figure 9. Representation of ac conductivity and real part of the permittivity for a lithium-phosphate glass, indicating the step Δε, the electrode polarization, and the nearly constant loss (NCL) approximation. Reproduced with permission from ref 49. Copyright 2009 IOP Publishing Ltd. 

14438 

https://doi.org/10.1021/acs.chemrev.1c00214 

Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> <u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 10. Simulation of a forward-bias voltage step from 0 to 1.5 V. (a) Transient current. (b, c) Charge carrier density profiles of electrons, holes, anions, and cations at two different time steps as marked in a. The HTM/perovskite and perovskite/ETM interfaces are located at 50 and 550 nm, respectively. Reproduced from ref 41. Copyright 2019 American Chemical Society. (d) Schematic of the electric potential ϕ in the perovskite. ϕ is linear across most of the perovskite film but varies rapidly across narrow Debye layers at its edges, jumping by an amount V− across the left-hand layer and V+ across the right-hand layer. Reproduced from ref 37 with permission from the Royal Society of Chemistry. (e) CPD distribution of a MAPI cell under open-circuit conditions obtained Kelvin probe force microscopy (KPFM) measurements. (f) Calculated charge densities (y axis) from the potential distribution. Reproduced from ref 56. Copyright 2016 American Chemical Society. 

discussed.<sup>50,51</sup> Equation 16 indicates that short-range motion at high frequency allows for displacement pathways of the carrier that are not allowed in the long-range excursions that give rise to dc conduction. The power-law raising conductivity is often termed a “nearly constant loss” NCL. In addition to eq 16, Jonscher<sup>45,47</sup> pointed out the existence of two types of “universal relaxation” that have been observed for a wide variety of materials in the complex permittivity. 

#### 4.2. Chemical Capacitance 

Another capacitive mechanism occurs in semiconductor devices. We find here a substantially different type of capacitance, the chemical capacitance, cμ, that relates the change of electron carrier density n, to the displacement of EFn, as follows (similarly for holes):<sup>19,52</sup> 

14439 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 11. Schematic representation of the frequency-dependent capacitance and relative permittivity (real part) of a MAPbI3 material measured by IS and comparison with the relative permittivity measured using complementary techniques at room temperature. 



<!-- Start of picture text -->
2 ∂ n<br>c μ = q<br>∂ EFn (17)<br><!-- End of picture text -->

If the carrier density obeys the Boltzmann statistics 

|=<br>−<br>_n_<br>_n e _<sup>_E_</sup><br>_E_<br>_k T_<br>0<br>(<br>)/<br>_Fn_<br>_F_0<br>B<br>(18)|
|---|



then the chemical capacitance per unit volume is 



<!-- Start of picture text -->
2<br>q n<br>c μ =<br>k B T (19)<br><!-- End of picture text -->

In disordered semiconductors, the Fermi levels explore a disorder-induced density of states (DOS), gn. In this case, the chemical capacitance is a replica of the DOS, in a good approximation, in such a way that<sup>52</sup> 



<!-- Start of picture text -->
2<br>=<br>c μ q gn ( EFn ) (20)<br><!-- End of picture text -->

This last identification is strictly valid at zero temperature when the Fermi−Dirac function converges to the step function. 

The total chemical capacitance is directly proportional to film thickness<sup>52</sup> 



<!-- Start of picture text -->
C = c d<br>μ μ (21)<br><!-- End of picture text -->

This is in contrast to the dielectric capacitance that depends reciprocally on d, as indicated above in eq 12. The chemical capacitance is not experimentally observable in two circumstances: 

- (1) The semiconductor works within the relaxation regime, which entails shorter recombination times than relaxation times τdie = εε0/σ, τrec < τdie.<sup>53</sup> 

- (2) A low effective DOS of the conduction band impedes observation. 

#### 4.3. Contact Polarization Effects 

In ionic conducting systems, one encounters the phenomenon of electrode polarization, which is related to the fact that ions cannot penetrate the metal collector contact so that conductivity is blocked at low frequency. The accumulation of ions at the contact interface produces a capacitance due to surface space charge.<sup>54,55</sup> This capacitance is located within a 

short distance from the contact, and it is independent of film thickness d, provided that the film is thick enough. 

As MHPs are considered to be mixed ionic-electronic conductors, it is plausible that strong charge accumulation occurs at the outer contacts, as indicated by simulations in Figure 10c. This is confirmed by a variety of experimental methods such as Kelvin probe force microscopy (KPFM) carried out on a cross section of devices that show strong ionic−electronic accumulation at the perovskite/contact interfaces; see Figure 10f.<sup>56</sup> 

Electrode polarization gives rise to very large values of the apparent permittivity in the ε(ω) plot. The large rise of the ε′ is a typical feature of many types of ionic systems,<sup>57</sup> as shown for an ionically conducting glass in Figure 9. The capacitances of order 10 μF cm<sup>−2</sup> related to ionic accumulation can be modeled following the classical Gouy−Chapman diffuse double-layer model. At equilibrium (zero bias), excess ion carriers build up within a space charge region zone equivalent to the ion Debye length, λD 



<!-- Start of picture text -->
εε 0 k B T<br>λ D = q 2 N (22)<br><!-- End of picture text -->

Here N accounts for the concentration of ionic charges; see Figure 10d. The resulting electrode capacitance is 



<!-- Start of picture text -->
εε 0<br>C sc =<br>λ D (23)<br><!-- End of picture text -->

#### 4.4. Characteristic Features of Capacitance of MHP 

An overview of the different capacitive processes over a range of 18 orders of magnitude in frequencies is shown in Figure 11, and relevant experiments to IS will be described next. The dielectric response of the bulk MHP material determines the most significative capacitive mechanism at high frequencies, and the effects of electrode polarization and chemical reactivity are observed at low frequencies. The graph has been adapted from ref 58 and derives from average values over a number of MAPbI3 literature reports.<sup>58−65</sup> At high frequencies, several techniques have been used to characterize MHP materials, i.e., absorbance or emission spectroscopies, time-resolved terahertz spectroscopy, far-infrared spectroscopy, ellipsometry, Raman 

14440 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 

spectroscopy, or Millimeter-Wave spectroscopy. At low frequencies the information is extracted from IS measurements. The units in the x-axis are only expressed in Hz, but depending on the technique other units such as eV, λ, or cm<sup>−1</sup> are more commonly used. Features around 5 × 10<sup>14</sup> Hz are associated with electronic interband transitions, and strong resonances near 1 and 2 THz derive from optical phonon resonances of the lead iodide lattice. An increase in the dielectric response near 100 GHz is associated with collective reorientation of MA cations to obtain values of static permittivity of about 60 up to the kHz range.<sup>58</sup> The dielectric relaxation is also detected by IS, and at frequencies <10 kHz the effect of ion migration toward the electrodes becomes dominant. An excess capacitance due to electrode charge accumulation is associated with the surface polarization. In dark conditions, the charge corresponds to the typical ionic double layer capacitance according to eq 23, and under illumination electronic and ionic accumulation leads to still higher capacitance values. Depending on the materials present at the electrode interfacial, chemical reactions may be promoted and detected by IS. 

That general capacitive dark response is corroborated using ultrasonic and Raman spectroscopy for different halide perovskites as observed in Figure 12, which allows observing 



Figure 12. Dielectric constant of the three MA-Pb-halides across a wide frequency spectrum. Sections denote the dominant micromechanism contributing to the dielectric response: (A) ionic motion/ drift, (B) MA-dipole relaxation, (C) anionic lattice dynamics (phonons), and (D) internal vibrations of the MA molecule. Reproduced with permission from ref 63. Copyright 2017 John Wiley and Sons. 

very high values of dielectric constant (>27) for frequencies below 1 THz in all three halides.<sup>63</sup> Also, the LF electrode polarization mechanism is always observed. 

The dielectric constant is dependent on temperature since MAPbX3 (X = Cl, I, or Br) crystals undergo a phase transformation at ∼160 K between orthorhombic (γ-phase with ε ≈ 30) and tetragonal (β -phase with ε ≈ 60 at 300 K) structures, as observed in Figure 13 for samples contacted using metal electrodes.<sup>63,66</sup> 

When contacts are made of semiconducting charge selective compounds, additional features appear because of the dielectric 



Figure 13. Temperature dependencies of the real part of the dielectric permittivity of CH3NH3PbI3 and CH3NH3PbBr3 single crystals and CH3NH3PbCl3 polycrystal measured at a frequency of 1 MHz in the range of the low-temperature phase transitions. The inset shows measurements of CH3NH3PbI3 above room temperature at a frequency of 50 MHz. Reproduced with permission from ref 63. Copyright 2017 John Wiley and Sons. 

contribution of contacts layers as spiro-OMeTAD and TiO2.<sup>67</sup> Accordingly, the high-frequency plateau observed in Figure 14b at lower temperatures (C = 10<sup>−7</sup> F cm<sup>−2</sup> ) can be related to the perovskite permittivity of the orthorhombic phase in series with that of the contacts. It is also noticeable that the polycrystalline structure (porosity) of perovskite layers for photovoltaic purposes may alter the experimental permittivity extracted at 300 K for the β-phase (C = 10<sup>−6</sup> F cm<sup>−2</sup> ) in Figure 14c.<sup>68,69</sup> 

As commented on previously, the LF capacitance (<10 Hz) at 300 K reaches values exceeding 10 μF cm<sup>−2</sup> as shown in Figure 14c. It was reported that the capacitance values are practically independent of the MAPbI3 film thickness, Figure 2.<sup>25</sup> It is also noticeable that the LF contribution is largely suppressed when contacts include fullerene and polymer interlayers,<sup>39,65,70</sup> as shown in Figure 15 for PSC with different contacts, in which the LF large capacitance correlates with the hysteresis in j−V curves. These observations<sup>70−73</sup> led to the idea that the large LF capacitance relates to the interactions of ions and the interface.<sup>74</sup> The chemical capacitance is not observed, may be due to a low DOS<sup>75</sup> so that this feature is obscured by other effects, as discussed in section 4.6. 

The capacitance spectra under illumination reveal additional phenomena. A significant increase of the capacitance is observed, Figure 16, that depends on the light intensity,<sup>76</sup> which reaches values as high as 10<sup>−2</sup> F cm<sup>−2</sup> for 1 sun light intensity. There are different possible origins to such large capacitance. A first explanation is the formation of a majority electronic carrier accumulation zone in the vicinity of the contacts. It produces upward band bending with width equaling the electronic Debye length of the background majority density p0. For a typical background of majorities in polycrystalline perovskite layers p0 ≈ 10<sup>17</sup> cm<sup>−3</sup> , one expects λD ≈ 10 nm. A variation of Cs with voltage is predicted as<sup>64</sup> 



<!-- Start of picture text -->
C s = εε 2 λ 0D e (2 qkV B T ) (24)<br><!-- End of picture text -->

In addition, it was suggested that under illumination conditions a chemical reaction between selective contacts 

14441 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 



<!-- Start of picture text -->
Chemical Reviews pubs.acs.org/CR Review<br><!-- End of picture text -->



Figure 14. Capacitance vs frequency at different temperatures (dark) of a perovskite solar cell formed by planar TiO2 electron contact, with 400 nm CH3NH3PbI3 film as the light-absorber layer and 150 nm spiro-OMeTAD as the hole selective layer. Reprinted from ref 25. Copyright 2015 American Chemical Society. 

and iodide can modify the capacitive response of the interface and enhance the electrode polarization at lower frequencies, as shown in Figure 17.<sup>65,70</sup> Consequently, the large capacitance can be originated by interaction of ionic and electronic carriers, involving slow charge binding at the interface.<sup>65,77</sup> A variety of explanations of the low-frequency capacitance based on the modulation of currents<sup>78</sup> are later discussed in section 8.3. 4.5. Determination of Doping Densities by the Mott−Schottky Method 

The work function offset between a semiconductor and the contacting material produces the formation of a Schottky barrier. A bending of the transport bands toward the bulk absorbing layer appears as a consequence of the presence of immobilized charged defects. The contact barrier height determines the flat-band voltage as qVfb = EF0 − Φc79 where EF0 is the equilibrium Fermi level of an n-type semiconductor, 



Figure 15. (a) j−V hysteresis of the cp-TiO2/MAPbI3/spiroMeOTAD (normal) structure and (b) the PEDOT:PSS/MAPbI3/ PCBM (inverted) structure. During a j−V scan, the current was acquired for 100 ms after applying a given voltage. (c) Normalized time-dependent jsc of the normal and the inverted structures. Opencircuit condition under one sun illumination was maintained before measuring jsc. Capacitance−frequency C−f curves (d) in the dark and (e) under one sun illumination at short-circuit conditions (bias voltage = 0 V). Reproduced with permission from ref 70. Copyright 2015 American Chemical Society. 



Figure 16. Capacitance spectra measured in open-circuit conditions for different illumination intensities of 300 nm thick CH(NH2)2PbI3−xClx-based solar cells between 100 mHz and 1 MHz. Dark response at zero bias is also shown. Reproduced with permission from ref 64. Copyright 2016 American Chemical Society. 

and the work function of the metal is Φc. At the semiconductor−metal interface, these depletion zones produce capacitive responses. The depletion-layer width, w, controls the capacitance value as 

14442 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 17. Impedance spectroscopy results devices FTO/c-TiO2/mTiO2/MAPbBr3/Au measured in the dark and at 1 sun under different conditions. A device with a spiro-OMeTAD hole transport layer is analyzed for reference. Capacitance vs frequency plot showing different vertical scales (a) logarithmic and (b) linear plot around the value of the Helmholtz capacitance, indicated with a straight baseline. Reproduced from ref 65 with the permission. Copyright 2019 AIP Publishing. 



<!-- Start of picture text -->
εε 0<br>C dl =<br>w (25)<br><!-- End of picture text -->

For a uniform distribution of dopants with density N in the space charge region (corresponding to carrier density in the neutral region n = N), _w_ ∝ _V_ fb − _V_ , and hence 



<!-- Start of picture text -->
C dl−2 = 2 ( fb − V )<br>qεε 0 N V (26)<br><!-- End of picture text -->

The representation C−dl2 versus V shows a linear behavior that indicates the presence of a depletion zone. This representation is commonly known as a Mott−Schottky (MS) plot that allows one to determine the flat-band voltage from the intercept on the voltage axis and the doping density from the slope of the linear portion of the response. 

The determination of electronic doping densities using capacitive techniques has to be carefully analyzed, as it can give inconsistent results in MHP due to two main reasons: 

- (1) The capacitance due to the modulation of space charge in the depletion region Cdl can be masked by another large capacitance such as the ionic surface capacitance Cs. 

- (2) The biasing condition can modify doping densities by the displacement of ionic defects. 

The complexity of applying MS analysis is shown in Figure 18 corresponding to ref 80. The electronic depletion-layer capacitance Cdl at the contact is readily distinguishable at the small forward voltage region, while the ion-related surface capacitance Cs dominates at much larger bias in Figure 18a. The defect density calculated from the linear response C<sup>−2</sup> ∝V as in eq 17 is N ≈ 10<sup>17</sup> cm<sup>−3</sup> , which establishes the limit of applicability of the MS technique in PSCs.<sup>80,81</sup> It is very likely that the extraction of any lower defect densities becomes masked by additional LF capacitive mechanisms.<sup>22,80</sup> As an example, in the case of Figure 18b, the MS analysis may not be reliable<sup>80</sup> because Cdl cannot be unambiguously separated from 



Figure 18. Capacitance−voltage and MS plots of PSCs comprising (a) CH3NH3PbI3−xClx and (b) CH3NH3PbI3 illustrating different capacitive regimens. Adapted from ref 80 with permission. Copyright 2016 American Institute of Physics. (c) MS plots for (▲) formamidinium- and (●) CH3NH3PbI3-based PSCs when different prebias durations are applied. Reproduced with permission from 82. Copyright 2018 American Chemical Society. 

Cs that masks lower contributions. A transition between these two limiting cases (clear observation of Cdl or a masking effect produced by Cs) is even observable through MS analysis for formamidinium-based PSCs upon poling (Figure 18c).<sup>82</sup> In this case, the application of prebias before capacitance measurement modifies the ionic distribution and electronic doping profile within the active layer. 

Related techniques, widely used for semiconductor characterization, are profiling methods such as capacitance−voltage (C−V) and drive-level capacitance profiling (DLCP) measurements (Figure 19). A trap or density profile within the semiconducting layer is inferred by manipulating capacitance data. Very recently, a bulk trap density as low as ∼10<sup>11</sup> cm<sup>−3</sup> has been reported<sup>83</sup> for halide perovskite solar cells, which seems to be below the limit of resolution for IS measurements. By using electrostatic arguments, it is concluded that the geometrical capacitance and charge injection into the perovskite layer suffice to generate the observed capacitance signal level.<sup>84</sup> A limiting density value is here established below which trap or doping density are not experimentally accessible as shown in Figure 19c. 

#### 4.6. Capacitive Response of Defect Levels 

The thermal admittance spectroscopy (TAS), based on the electron occupancy variation of defect levels by applying an alternating electrical perturbation,<sup>85</sup> is the most commonly employed procedure for the analysis of trap levels within the band gap of active semiconductors. An excess capacitance is 

14443 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 19. Universal rise in apparent interfacial charge densities due to charge injection. Some reported spatial trap profiles shown with (A) linear and (B) logarithmic horizontal axis obtained from DLCP and CV measurements for different solar cell technologies and an 8 μm thick p-i-n (doping and trap-free) perovskite solar cell simulated using SCAPS. Also plotted is the analytical prediction derived by considering a geometric capacitance in parallel with an exponential injection capacitance. The capacitance related to injection of charge at forward bias causes an apparent rise in the interfacial charge densities at the lowest profiling distances (left side of “U”-shaped profile in A) that can erroneously be interpreted as trap densities. (C) Minimum charge densities (dopant or trap) that will be observed in a capacitance−voltage measurement for different thicknesses and permittivities typical of perovskite (olive) and silicon or organic (cyan) solar cells. The green region represents charge densities that are experimentally accessible for the perovskite solar cell. Reproduced with permission from ref 84. Copyright 2021 American Association of the Advancement of Science. 

observed, with respect to the high-frequency geometrical capacitance, as a consequence of the Fermi level modulation within the bulk of the semiconductor layer. 

In classical TAS analysis, the electronic DOS can be easily determined from the derivative of the capacitance spectrum C(ω) according to<sup>86</sup> 



<!-- Start of picture text -->
V bi ω d C ( ω )<br>g ( Eω ) = −<br>qdk B T d ω (27)<br><!-- End of picture text -->

Here Eω corresponds to the defect demarcation energy, Vbi is the built-in voltage, and d is the sample thickness. Again, due to the interference of significant capacitive effect of the LF ionic polarization, straightforward application of TAS and related methods in perovskite-based devices may produce unphysical results.<sup>87</sup> An illustration of the misleading application of TAS in the dark is shown in Figure 20. The HF (>10<sup>4</sup> Hz) feature is simply an artifact produced by the series resistance effect on the capacitance spectra. Also, the hypothetical DOS corresponding to the LF peak reaches unphysical values as high as 10<sup>21</sup> eV<sup>−1</sup> cm<sup>−3</sup> . When the frequency axis is rescaled in terms of energy (Figure 20c), a collapse in a unique peak that should occur in the case of deep 



Figure 20. (a) Capacitance spectra for varying temperatures of a CH3NH3PbI3-based solar cell with TiO2 as an electron selective contact. (b) Hypothetical DOS after application of the capacitance derivative TAS method in eq 17. In the inset: calculation of the activation energy corresponding to the LF (high energy) feature. (c) Same data represented as a function of the demarcation energy. Reproduced with permission from ref 88. Copyright 2016 AIP Publishing. 

level electronic bands does not happen (see Figure 21b). Therefore, at least of PSCs comprising oxide selective contacts, the large LF capacitance dominates and masks additional capacitive contributions produced by electronic transitions of defects within the band gap. 

In other cases, less pronounced excess capacitance steps are reported when fullerene-based contacts are used (Figure 21).<sup>89</sup> 

14444 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 21. Defect analysis of a perovskite PV device. (a) Capacitance spectra at different temperatures (legends in °C). (b) DOS extracted using eq 27. Reproduced with permission from ref 89. Copyright 2020 Wiley-VCH. 

The masking LF ionic capacitance has a minor effect here, and trap bands may be observable. 

### 5. EQUIVALENT CIRCUIT OF MHP SOLAR CELLS AND THEIR INTERPRETATION 

As explained previously, one of the main goals when developing useful IS methods for a class of systems is to establish a general EC with unambiguous physical interpretation of each of the elements. In this section, we will summarize the main characteristics of the ECs and resistances in PSC. The resistances will be further discussed in the following section in relation to the ECs as they provide important information on the recombination kinetics. 

First, it is important to highlight that in a multilayer device the IS interpretation is complex as each layer and interface may contribute to the transport, accumulation, and recombination of electronic carriers and transport of ions. A complete understanding of the operation processes has not been obtained to date. While many of the capacitive contributions to the impedance are currently well understood as described previously, the resistive contributions still require further work to reveal their origin. In particular, discerning between bulk and interfacial effects on the impedance needs a careful analysis of the particularities of each system. 

Earlier in Figure 16, we commented on the drastic variation of the low-frequency capacitance under illumination. It is a widely observed characteristic behavior of halide perovskite that major changes occur when the samples are under light intensity in comparison with the response in the dark. It is therefore necessary to distinguish the ECs and impedance analysis in both situations. This is due to complex interactions occurring between photocarriers and the perovskite lattice that would suggest light-induced changes of the IS response. We can mention a number of concrete effects. First, because of the excellent electronic transport properties, halide perovskites exhibit ionic conductivity with values several orders of magnitude lower than those observed for the electronic conductivity.<sup>23</sup> However, it has been argued that light can facilitate ion conductivity by increasing mobile ion concentration in parallel to electronic transport enhancement.<sup>90</sup> The photoinduced ion conductivity is assumed to be the consequence of hole localization that locally neutralizes iodide; 

the so-formed neutral iodine atoms can occupy interstitial sites where they are further stabilized by the polarizable environment in MAPbI3.<sup>91</sup> That mechanism would be in line with previously reported photoeffects on the capacitance. For instance, photogenerated hot carriers are believed to interact with the inorganic lattice inducing rotational disordering and broadening of iodine−iodine correlation at the picosecond time scale.<sup>92</sup> It is also observed that mixed halide perovskites undergo reversible phase segregation upon illumination.<sup>93</sup> Another related effect is that the time constant of decay of the photovoltage is strongly modified by a short preceding illumination.<sup>94</sup> 

The reader also needs to be aware that due to the recent development of the technology there are several early reported ECs that do not accurately represent the operational processes as we understand them currently as indicated in Table 1.<sup>95</sup> For example, samples in the initial papers showed low efficiency and poor stability, which produced some drift in the data that was difficult to eliminate. In addition, initial reports did not consider that perovskites are mixed electronic/ionic conductors which has an important effect on the current interpretation of capacitances. A series of competing models and the implications will be discussed in Section 5.2. 

#### 5.1. Search for a General Equivalent Circuit and Need of Simplification 

The principal strategy to study a new type of solar cell is to identify the core elements, namely, the chemical capacitance and recombination resistance, as presented in section 3.2, and then to infer any other elements typically present in the system, which can be a multitude of possible contributions in the bulk, at internal interfaces, or in the selective contacts. Several ECs have been proposed in the literature depending on the dominant factors that determine the measured spectra.<sup>65,96−98</sup> The formulation of a general EC model for transport and recombination depends on certain basic characteristics of the particular solar cell, regarding the mobilities of carriers, amount of shielding, etc.<sup>22,99</sup> For the PSC, it is widely observed that electron diffusion length is much larger than the typical sample thickness. Hence, diffusion should be the dominant mechanism for charge extraction in a first approximation. Therefore, the impedance model can be derived from a general EC shown in Figure 22a that is an 

14445 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 

#### <u>Chemical Reviews</u> 



Figure 22. (a) Transmission line circuit for diffusion−recombination including the transport resistances of the two carriers, impedances at contacts, and series resistance. (b−d) The transmission line circuit for diffusion of a single carrier with different boundary conditions (b) blocking, (c) absorbing (or infinite recombination), (d) surface polarization capacitor. 

extension of Figure 4d. In this general EC, we describe specifically the impedance of the contacts and a transmission line for diffusion and recombination in which the transport resistances of both electrons and holes are assumed significant. As MHP are considered to be mixed ionic-electronic conductors, they show important effects of charge accumulation and recombination at the contacts, as indicated in Figure 10. The boundary conditions represented by specific impedances Zc induce very large changes of the impedance spectra.<sup>100</sup> For example, Figure 22b is a blocking boundary condition, Figure 22c is an absorbing boundary condition also known as infinite recombination condition, and Figure 22d is a boundary capacitor. Further insight to these models is described in Figure 45 when we discuss the observations of ionic transport. In many cases, the chemical capacitance can be directly related to the density of states (DOS) of the lightabsorber phase, eq 20.<sup>101</sup> However, the chemical capacitance may be also overwhelmed by other contributions, as the depletion capacitance.<sup>102</sup> 

However, the use of very complex EC is not justified since the typical response of perovskite solar cells shows only two arcs, and a Warburg-like response is only observed under specific conditions. Therefore, there is a need to use a simplified EC that captures the essential information for a given set of experimental conditions. Our aim is to provide the guidelines for a useful selection of EC in experimental work on PSC and the interpretation of each of the elements. Since there are so many diverse proposals, we are not able to cover all the published work, and we apologize to those authors who may have not been given the attention that their work deserves. 

5.2. Response of Optimized Perovskite Solar Cells 

We show in Figure 23 one of the ECs that has been used to fit the impedance data under illumination successfully in many cases. This EC is a simplification of more complex and general circuits as those described above in the process indicated in Figure 7. 



Figure 23. Equivalent circuit and (a) complex plane impedance spectrum (impedances in Ω). The arrow indicates the direction of increasing frequency. The point indicates the angular frequency 1/τ1 = 1/R1 C1 (b). Real part of the capacitance vs frequency. Parameters R1 = 5 Ω, R3 = 3 Ω, C1 = 10 F, Cg = 10<sup>−3</sup> F. 

Figure 24 shows impedance spectra of MAPI devices measured under different illumination conditions with efficiencies in the range of 18% at 1 sun illumination, a clear sign that they contain adequate extraction layers for this perovskite formulation. Under these conditions, the capacitance frequency plot (Figure 24b) shows one plateau at high frequencies (HF) and increases the capacitance toward the low frequencies (LF) as it was discussed in section 4.4. These features of the capacitance correspond, respectively, to Cg, the geometrical capacitance, and C1, the low-frequency capacitance, in the circuit of Figure 23, as shown in detail in Figure 24a. 

The complex plane impedance plots (Figure 24c,d) show two arcs, which is a pattern often found in good quality PSC devices. The resistance associated with the wires and charge collectors is the series resistance (Rseries) of the device and may be read directly from the plot as the distance between the origin of coordinates and the intercept of the HF arc with the x-axis (Figure 24c). The two arcs are associated with two resistances. According to a previous convention,<sup>96</sup> subscript numbering of resistances are ordered from the lowest frequency resistance to the highest, starting from 1. We denote the LF arc resistance as R1 and the HF arc as R3. The use of additional resistance R2 (not present in Figure 24) is applied for an additional intermediate process, as discussed later in this review; see Figure 35. 

The meaning of the resistance depends on the illumination conditions. In the dark, the HF arc contains information on the bulk conductivity of the perovskite film and shunt resistance, and the LF one relates to the perovskite/contacts interface (ion migration and accumulation),<sup>103</sup> which justifies the parallel connection of R1 to C1. Under illumination conditions, photoconductivity rises progressively, and the contribution from the conductivity of the perovskite to the impedance response is reduced until it totally vanishes at high illumination conditions. Under these conditions, the resistances are related to the recombination kinetics, and they can be analyzed as a function of the applied DC bias or illumination conditions. In 

14446 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 24. (a) Representative EC used to fit the data for MHP devices containing adequate extraction layers from the (b) capacitance frequency plots (c) and (d) complex impedance plot. 

devices of a reasonable photovoltaic performance, the HF resistance is associated with a recombination resistance<sup>97,103</sup> as will be discussed<sup>97,104</sup> in section 6. It is found that total recombination resistance Rrec is obtained by the addition of R1 and R3. Figure 25 shows that the application of the model at different stabilized steady states provides the voltage depend- 



ence of EC parameters. The calculation of the corresponding time constants is presented in Figure 64. 

Other ECs have been described in the literature, and we next discuss the implications of using different alternatives for describing the operational mechanism. 

5.3. Series or Parallel Connection and Physical Interpretation 

5.3.1. Importance in the Arrangement of Elements. In the analysis of IS data, there is often a latent question that any moderately complex data can be represented by several different ECs that are equally valid. This is just because the impedance represents a linear system of equations, and the internal state variables can be modified by linear transformation.<sup>34,105</sup> As a relevant example, let us consider the circuits A and B of Figure 26. These two circuits are just two equivalent representations of a two-arc spectrum as that in Figure 24d. The equivalence implies that the impedance functions of both circuits are the same, and circuit parameters are related by the transformation 



<!-- Start of picture text -->
R 3<br>P 1 = ( R 1 + R 3)<br>R 1 (28)<br><!-- End of picture text -->



<!-- Start of picture text -->
P 3 = R 1 + R 3 (29)<br><!-- End of picture text -->

Figure 25. Impedance spectroscopy results of a planar structure FTO/TiO2/MAPbI3/spiro-OMeTAD/Au solar cell. (a) Example of complex plane impedance plots measured under short-circuit conditions at different irradiation intensities. (b) Example of capacitance spectra corresponding to the conditions in panel (a). Solid lines correspond to fits using the EC of Figure 24. (c) Capacitances and (d) resistances under open-circuit conditions. Solid lines (low-frequency arc) and dashed lines (high-frequency arc) correspond to linear fits with m approaching 2. In panel c, m = 1.90 ± 0.17, and in panel d, m = 1.94 ± 0.08. Reproduced with permission from ref 97. Copyright 2016 American Chemical Society. 



<!-- Start of picture text -->
R 12<br>K 1 = ( R 1 + R 3)2 C 1 (30)<br><!-- End of picture text -->

Consequently, if a set of data can be fitted with one model, it can also be fitted with the other one, as shown in Figure 27, where representative PSC experimental IS data are fitted using both ECs. The geometric capacitance Cg is connected equally in both models, and, therefore, fitting results will be the same. However, as observed in the transformation equations, the values of the other parameters are in general quite different 

14447 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 26. Equivalent circuits models with the low-frequency subcircuit (A) in parallel and (B) in series. Top rows are the corresponding circuits at low frequency (with the capacitors in an open circuit) and intermediate frequency (when the relaxation of lowfrequency capacitors has ended and they become shorts). 



Figure 27. (a, b) Representative experimental data of a PSC measured under illumination and fitting results using ECs A and B from Figure 24. 

(Table 2), and hence the physical interpretation of both circuits cannot be the same. 

As we have mentioned in the general criteria, when applying IS, we should attempt to provide a valid and coherent physical 

Table 2. Fitting Results of Experimental Data shown in Figure 27 

||eq circuit|A||
|---|---|---|---|
|R3 (Ω)|Cg (nF)|R1 (Ω)|C1 (mF)|
|56|51|14.7|13.7|
||eq circuit|B||
|P3 (Ω)|Cg (nF)|P1 (Ω)|K1 (mF)|
|70|51|265|0.60|



picture of the processes associated with circuit elements. In fact, we can discuss some salient differences of the circuits in Figure 26 just by studying the meaning of the connections for a solar cell model. Circuit A is the standard circuit that we have described above, see Figure 23, in which R1 and C1 correspond to the LF resistance and capacitance of the perovskite, respectively. The LF limiting subcircuit (with capacitors in an open circuit) shows that the dc pathway includes both resistances R1 and R3, and hence both clearly have electronic (or mixed ionic−electronic) character since the current can be injected to the electrode through R1. In contrast to this, in the LF pathway in circuit B, the transport through P1 is blocked at low frequency by the capacitor K1, and thus P1 is better interpreted as a pure ionic transport. Therefore, as commented on previously, even though the two circuits A and B are a valid representation of the spectral data, it is necessary to clarify which circuit is correct in terms of the physical interpretation of the given experimental case. 

5.3.2. Interpretation of the Impedance Models That Include Dielectric Relaxation-like Subcircuits. In addition, we remark that the circuit B opens a different possibility than an ionic transport branch. So far, we have only considered the inclusion of the HF polarization through a geometric dielectric constant, ε∞, that represents orientational polarization, in the description of capacitance of eq 12. However, as described in classic textbooks<sup>44,45</sup> the process of orientational polarization can be frequency dependent. This is called a dielectric relaxation process, as discussed in section 4.1, in which the complex dielectric constant varies from LF (static) value εs to HF (geometric) value ε∞ causing the step of the dielectric constant mentioned in eq 11. The simplest type of relaxation is given by the Cole−Cole relaxation peak that takes the form: 



<!-- Start of picture text -->
ε s − ε ∞<br>ε ( ω ) = 1 + ( iωτ dr)1− α + ε ∞ (31)<br><!-- End of picture text -->

where τdr is a constant relaxation time and α is a parameter that takes into account the dispersion of relaxation times. For α = 0, eq 31 reduces to the case of the Debye relaxation peak for a single relaxation time, represented in Figure 8a, and more generally the broadened peak for α > 0 is shown in Figure 8b. By comparing the lower branches of Circuit B (Figure 26) with Figure 8a, we can conclude that Circuit B can be viewed as a dielectric relaxation process with a parallel conduction pathway P3. In this case, P1 does not involve the meaning of ionic motion. Instead, P1 relates to the dielectric loss in the relaxation process, which is an orientational rotation without long-range displacement. 

To clarify the situation, we can observe the dielectric relaxation and ac conductivity data of a purely ionic conducting glass already presented in Figure 9. In this set of data, the dielectric function makes a clear step Δε = ε′(0) − ε′(∞). The conductivity is nearly constant at intermediate frequency. On the other hand, at low frequency, there is another capacitive contribution associated with the blocking of ionic carriers at the external electrodes, as described in section 4.3. Such blocking is manifested in the vanishing of the real part of the conductivity. This formalism has been recently adopted for analyzing the IS response of perovskite single crystals,<sup>106</sup> Figure 28, also concluding that the LF capacitive excess is originated by ion accumulation at the Ag interface. 

The initial analysis of perovskite solar cells showed a large capacitance that opened questions about the operation mode, 

14448 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 28. Dielectric constant and ac conductivity in CH3NH3PbI3 Single crystal as a function of frequency at the temperatures (a) 193 K and (b) 283 K. Reproduced from ref 106. Copyright 2020 American Chemical Society. 

whether it was dominated by a nanostructure related to the contacts, or consisted of a thin film.<sup>107</sup> Then, a very important result was obtained by Mora-Seró and his co-workers.<sup>76</sup> The capacitance of the PSC showed a high-frequency plateau and a large feature toward low frequencies. Furthermore, the size of the low-frequency capacitance increased orders of magnitude with increasing illumination intensity, as shown in Figure 29. This result has been confirmed in many later reports as explained previously; see Figure 14 and Figure 16. 



Figure 29. Plot of the real permittivity as a function of frequency for different incident light intensities (Φ0) from dark to 1 sun, for MAPbI3‑xClx perovskite (compact TiO2/MAPbI3‑xClx perovskite in Al2O3 scaffold/spiro-OMeTAD). Measurements have been carried out at room temperature and 0 V applied bias. Inset: linear regression of dielectric constant vs illumination intensity at f = 50 mHz, observing a close to linear dependence between ε0 and intensity illumination. Reprinted with permission from ref 76. Copyright 2014 American Chemical Society. 

The interpretation of such a dramatic dependence and the previously unseen shape of the capacitance versus frequency is not obvious at first sight. Two different options were examined in the initial years of investigation, both related to the general framework of Figure 29. 

- (1) A photoinduced dielectric relaxation. Figure 29 shows at high frequency a plateau of the geometrical capacitance that can be associated with ε∞. Therefore, it can be thought that the LF peak is associated with a dielectric relaxation that goes to a static value εs as in the examples of Figure 6. In fact, Figure 29 adopted this interpretation since the capacitance is reported in terms of the 

   - dielectric constant (a bulk value due to the nature of the MHP), as also shown in Figure 28. 

- (2) Another option provided by Figure 29 is that the large LF jump of capacitance is due to electrode polarization, an interfacial effect rather than a large bulk dielectric constant. This possibility requires that the solar cell absorber, the MHP, behaves as a solid electrolyte with plenty of mobile ions that become blocked at the contact. 

In 2014, it was hard to believe that such an excellent semiconductor as the MHP would be full of mobile defects as lattice imperfections. Nevertheless, shortly after, the existence of mobile ions in MHP was suggested.<sup>71,108</sup> Then, the interpretation (2) of the LF jump due to the intervention of mobile ions was rapidly developed, as described and adopted in the present paper. A main piece of evidence was the sensitivity of the LF plateau to the nature of the contacts, shown in Figure 15,<sup>70</sup> in close relationship to the hysteresis of current−potential curves, and this interpretation was confirmed by a variety of techniques.<sup>74</sup> It was also noted that the large surface capacitance is independent of film thickness, indicating a surface origin as discussed earlier in this paper.<sup>25</sup> In a few years, the ionic motion and its influence in the PSC operation were widely adopted by the scientific community, and the EC A (Figure 26) was associated with the ionic/ electronic effects typical of the MHP. 

Nevertheless, it is important to complete the exploration of option (1) since according to this view a circuit of the type of EC B (Figure 26) is preferred. This approach can be seen in the early interpretation of Pascoe et al. (Figure 30)<sup>109</sup> and in the recent work of Yoo et al. (Figure 31).<sup>98</sup> 

Assuming that the electrical response in Figure 29 is a dielectric relaxation process, it can be observed that the static value of the dielectric constant is very large even in the dark, about 1000, well above the high-frequency value of the perovskite, which is of the order ε∞ ≈ 50. Then, under 1 sun illumination, the value still increases further by a factor of 1000. 

Such large values of the dielectric constant cannot be explained by an ordinary relaxation process, and hence it must be assumed that the MHP exhibits it due to a special phenomenon such as ferroelectric polarization. The enormous increases of the dielectric response under light should be related to a photoinduced increase of polarization, a possibility that has been explored over the years.<sup>110−112</sup> 

14449 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 30. (a) Equivalent circuit used to fit the impedance response. Typical complex plane impedance plots are shown for (b) PIN, (c) PI, and (d) IN devices measured under open-circuit conditions, and the resistance and capacitance values for the contact (blue triangles) and dielectric response (red circles). (e) IS-derived time constants for the high-frequency (filled markers) and low-frequency (open markers) impedance features for the PIN (blue squares), PI (red circles), and IN (black triangles) cell structures. Reproduced with permission from ref 109. Copyright 2015 American Chemical Society. 

Including the ferroelectric effect in the picture of the solar cell opens a new problem of inserting the electrical field into a model of transport. In general, solar cells with high conductivity operate by diffusion, while those that have poor transport characteristics need a drift component of migration in the electrical field.<sup>99</sup> Incidentally, we note that ferroelectric semiconductors are usually strong insulators and require a large electrical field for assisted charge separation.<sup>113</sup> However, the MHP has excellent charge conduction properties. Therefore, the picture of Figure 8 and Figure 9 cannot be applied to the MHP solar cell. In fact, in the measurements of frequencydependent conductivity as that in Figure 23, it is observed that the dc conductivity does not vanish at low frequency, in contrast to the electronically insulating material of Figure 9, obviously because the PSC has a dc electronic conduction. 

Accordingly, the dielectric relaxation feature of Figure 8 needs to be supplemented at least with a parallel line for electronic transport and recombination, which leads to the eq Circuit B (Figure 26). However, since the electrical field is affecting electronic transport at each point of the device, the question that appears is how the electrical field associated with the dielectric relaxation influences the diffusion model that has been shown in Figure 3c and how it modifies the corresponding transmission line. 

Since this is a general problem related to the description of drift-diffusion models in ac conditions, the solution is known. Dielectric polarization introduces a new capacitance in the transmission line model that is distinct to the chemical capacitance. This feature has been described many years ago in ac circuits in solid-state electronics<sup>114</sup> as well as in electrochemistry models.<sup>115−117</sup> Both types of approaches have led to 

14450 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 31. (A−C) Complex plane impedance plots at 0.6 V forward applied bias under 0.1 sun illumination of MAPbI3 solar cells prepared with 0.1 M MAI and a PbI2 concentration of (A) 0.2 M, (B) 0.6 M, and (C) 0.9 M. (D−F) Simulated plots using the (G) transmission line EC with transport resistance for both electrons and holes as developed for all solids. (E) Simulated plots using the EC (H) including the transmission line (in G) with a dielectric relaxation-like branch characterized by a dielectric relaxation resistance, Rdr, and a dielectric relaxation capacitance, Cdr. (F) Simulated Nyquist plots using (I) a simplified EC with respect to the one depicted in (H), considering the case Cg, Cdr ≫ Cμ. Reproduced with permission from ref 98. Copyright 2019 Elsevier. 

the same conclusion that high-frequency dielectric polarization is described through a transmission line EC that includes an additional middle rail containing dielectric capacitors, associated with the geometric capacitance of the material, as suggested in Figure 32. The inclusion of the electrical field has been explained by Barker.<sup>115</sup> A line of “Poisson” condensers occurs between the two transport rails of the normal transmission line. Figure 30a shows the standard circuit for diffusion (without recombination) that we have discussed above in Figure 3d. Figure 32b shows the addition of bulk polarization with the central rail of the Poisson condensers (a distributed geometrical capacitance). The denomination of “Poisson condensers” is because the transmission line is obtained from drift-diffusion model, and the central rail of condensers stems directly from the Poisson equation that links the local charge density to the electrical field.<sup>115</sup> Figure 32c considers several species, ionic and electronic, that may be necessary in a PSC, as shown in Figure 10, and discussed later in section 7 in more detail. Figure 32c shows that the central Poisson rail is unique and affects all the transport channel, just because all the separate species feel the same local electrical field. 

According to the previous discussion, we are interested in including the whole dielectric relaxation circuit of Figure 8 into the general framework of the transmission line. This extension of the classical results, namely, obtaining drift-diffusion with recombination and a background of dielectric relaxation that affects the electrical field, is solved in ref 46. The main results are summarized in Figure 33. Figure 33a,b shows the energy levels of the two carriers and the vacuum level in relation to the different processes represented in the transmission line model. Figure 33c shows the general structure of the extended transmission line, a system of great complexity. Figure 33d 

shows a strategic (and arbitrary) simplification by connecting in series all the “Poisson” relaxation elements. Then, the full circuit is decoupled to an electronic impedance (possibly a transmission line with two rails) and the dielectric relaxation elements, Figure 33e. This simplified Figure 33e is the one that appears as eq Circuit B (Figure 26) that was used for fitting the data in Figure 30<sup>109</sup> and Figure 31.<sup>98</sup> 

Now that we have provided a full physical picture of ECs A and B in Figure 26, we can ask, what is the evidence for dielectric relaxation in the perovskite? To the best of our knowledge, the geometric capacitance does not change significantly as a function of frequency or light intensity. This fact was discussed in ref 112. Therefore, it is hard to imagine a light-induced dielectric polarization mechanism able to affect the static permittivity εs but simultaneously giving unaltered ε∞. This problem is indicated in ref 41 as shown in Figure 34. A simulation based on electrons and holes driftdiffusion describes well the j−V curve. However, the model for IS only includes the geometric capacitance and not the large low -frequency capacitance, and it cannot be correct. 

We conclude the interpretation of the two competing models in Figure 26. Successful fitting is no warrant of its physical validity. A suitable physical interpretation has to be given, or at least attempted, for an acceptable interpretation of the information that IS can provide. The discussion of basic ECs A and B establishes that the low-frequency capacitance should not be regarded as a dielectric capacitance. However, in more complex situations, the use of a series or parallel approach will also depend on the cell configuration. The series connection implies successive processes, each one with its respective voltage drop, while a parallel connection implies that both processes experience the same voltage drop. Hence, the effect of different layers can be easily viewed as a series process, 

14451 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 



<!-- Start of picture text -->
Chemical Reviews pubs.acs.org/CR Review<br><!-- End of picture text -->



Figure 32. Transmission line model corresponding to Nernst−Planck equations. This circuit describes the two element impedances: membrane (or thin cell) bulk, geometric impedance semicircle, and Warburg impedance, for symmetric and asymmetric cells, membranes with total salt penetration, and equivalent liquid junctions. (a) Without and (b) with the central line of “Poisson” capacitors. (c) The structure of the circuit is a tube of ion or electron-conducting strings coupled by “Poisson” capacitors. Reproduced with permission from ref 118. Copyright 1999 Elsevier. 

but this is not the case for processes involving electrons and ions that cannot be in series. 

In summary, Circuit B may still be useful in the framework of advanced models. In fact, the series RC line is used later in the contexts of Figure 60 and Figure 62. Since the MHP shows a very broad range of phenomena, we must state that a large variety of models have been considered in the literature.<sup>89,119</sup> Still, we regard the two-arc model EC A (Figures 24 and 26a) as the initial try of impedance studies of ordinary MHP cells that may require completion by additional factors if they are observed in the spectra. 

5.4. Simplified Equivalent Circuits that Account for Inefficient Contacts 

In general, two arcs are observed for PSCs, but an additional arc has also been reported when extraction layers are not well matched to the perovskite materials. ECs need to be adapted 



Figure 33. (a) Semiconductor energy levels and Fermi levels and (b) correspondent general transmission line model with three rails for two carriers and dielectric relaxation (extension of Figure 22a). (c) General TL without the current sources showing the boundary conditions. (d) In this simplified circuit, the dielectric relaxation subcircuit has been decoupled from the rest of the transmission line of (c). The central dielectric line of elements Zdr is disconnected from the vertical processes. The dielectric relaxation becomes a parallel process. (e) A representation of the parallel connection of an electronic impedance Z0 and the bulk dielectric relaxation Zdr. Adapted from ref 46. Copyright 2014 American Chemical Society. 

for this additional feature. It is also important to note that during the lifetime of the devices, contacts degradation usually occurs. Therefore, interpretation of these ECs will be key to understand degradation experiments where impeded charge collection is observed. Some of the most commonly used ECs are described next. 

An EC that accounts for this additional arc is shown in Figure 35a representative for the inadequate electron extraction layer Nb2O3 as deposited by atomic layer deposition (Figure 35b).<sup>96</sup> This material hinders efficient charge extraction as revealed by the minimal performance when the j−V curves are recorded (Figure 35b). The additional arc 

14452 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 34. Example of simulation mismatch. Measurement (black) and simulation (green) of a planar perovskite solar cell. (a) j−V curve with a ramp rate of 89 V/s. (b) Impedance spectroscopy in the dark. (c) Transient current as a response to a voltage step from 0 to 1.5 V at t = 0. Despite the agreement of simulation and measurement in the j−V curve, they do not match impedance and voltage step experiments. Parameters extracted from j−V curve fitting (a) are thus likely to be inaccurate. Reproduced with permission from ref 41. Copyright 2019 American Chemical Society. 



Figure 35. (a) j−V curves, (b) complex impedance plots, and (c) capacitance−frequency plots for perovskite devices measured at 1 sun illumination conditions. Impedance data have been recorded at 0 V. Adapted with permission from ref 96. Copyright 2016 American Chemical Society. 

appears at intermediate frequencies in the complex impedance plot. The resistance R2 may be associated with an interfacial charge transfer resistance or to low conductivity of the Nb2O3 layer and the capacitance C2 to the charge accumulated at the interface with the perovskite or inside the Nb2O3 layer. In this 

EC, all the remaining parameters maintain the physical origin as in the previous EC from Figure 23. 

Alternatively, the response of the external contacts can be present at very high frequencies as reported by Pauporté et al.<sup>120</sup> to account for the obstructed charge extraction by using an undoped spiro-OMeTAD layer as shown in Figure 36a. In 



Figure 36. (a) Simplified EC that accounts for impeded charge extraction due to inadequate contact. (b) Complex impedance plot that shows three arcs for the undoped spiro-OMeTAD layer. (c) Expansion of the high-frequency region of (b). Adapted from ref 120 with permission. Copyright 2018 the Royal Society of Chemistry. 

this case, three arcs are clearly observed in Figure 36b, and the arc at very HF is attributed to the inadequate extraction of carriers. Similar results have more recently been obtained by Raga, Bach, and collaborators where they studied the photooxidation of the undoped spiro-OMeTAD layer observing an increase of the conductivity of the contacting layer with a reduction of the very HF feature.<sup>121</sup> 

Still more exotic features like negative capacitance and loops have been observed in PSCs.<sup>96,23,77,120,122,123</sup> The origin of these features seems to be related to the dynamic interaction of migrating ions with external interfaces and will be discussed in section 8. At intermediate and low frequencies, the effect of ion migration and attachment to the interface becomes important, 

14453 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

and the electronic and ionic contributions to the impedance response are mixed, as previously indicated in Figure 17 for a solar cell with Au contact. In any case, this is an area that still requires more work to fully understand the physical process behind the response, and, therefore, a preferred EC that describes the working mechanism has not been established so far. 

### 6. RESISTANCE AND RECOMBINATION MECHANISMS 

6.1. Recombination Parameters 

6.1.1. Recombination Lifetime. The determination of the electron lifetime from IS can be obtained as a time constant of the type of eq 3, as 



<!-- Start of picture text -->
τ rec = R rec Cμ (32)<br><!-- End of picture text -->

where Rrec is the recombination resistance, and Cμ is the chemical capacitance.<sup>124</sup> If the chemical capacitance is obstructed by other capacitances, or if the shunt resistance is lower than the recombination resistance (Figure 42), then the product of the measured quantities R and C is not a recombination lifetime.<sup>102,125</sup> A different procedure to measure τrec in a PSC is explained in section 9.3, based on IMPS measurements.<sup>126</sup> 

6.1.2. Ideality Factor. The ideality factor m in eq 5 is closely related to the recombination mechanism.<sup>127−129</sup> The number m can be obtained: 

- (1) Directly from the j−V curve. 

- (2) From the analysis of the Voc dependence with light intensity, Figure 37, or alternatively 



Figure 37. (a) j−V curves of a representative pristine device and a device polarized under illumination conditions for 30 min at 0 V. (b) Complex impedance plot of a device measured under 1 sun illumination sweeping the voltage from 0 to 1.0 V. (c, d) Comparison of Voc dependence with light intensity for photovoltaic devices with different perovskite thicknesses measured when pristine and after polarization. md is the diode ideality factor. Reproduced with permission from ref 130. Copyright 2017 American Chemical Society. 

(3) From IS measurements by the voltage dependence of the recombination resistance.<sup>130</sup> 

Different properties of the ideality factor are commented on in section 10.2 in connection with hysteresis effects. 

6.1.3. Recombination Resistance. Recalling eq 5 and 6, one realizes that the recombination resistance Rrec mimics the dependence on voltage of the recombination current, exhibiting an exponential dependence. As a consequence, the recombination resistance reproduces the slope in the log Rrec ∝ V plot caused by specific values of the ideality factor as Rrec ∝ e<sup>−qV/mkBT</sup> . This is indeed the case of Si solar cells where Rrec exhibits a transition between two regimes of exponents m = 1 and m = 2 for low and large Voc, respectively.<sup>131</sup> That change in slope is a consequence of the appearance of bimolecular-like recombination processes as photogenerated carrier density exceeds the majority carrier background. Then, recombination resistances can be viewed as a critical element for diagnostic and elucidation of solar cell operating mechanisms. 

Despite the potential of adopting resistance as a relevant checking parameter, only a few works have shown a systematic analysis. Indeed, the variation of the EC resistances (connected to recombination mechanisms) upon specific solar cell processing routes<sup>132−135</sup> and contact layers<sup>136,137</sup> was addressed in early IS studies. This is illustrated in Figure 38 



Figure 38. (a) Recombination resistance for two different types of cells measured at an open circuit under different illumination intensities. Slopes of the lines shown correspond to ideality factor values of 4.8 (FS43-1) and 2.7 (FB-06), respectively. Reproduced with permission from ref 132. (b) Recombination resistance Rrec as a function of voltage for planar perovskite solar cell based on the mixed halide CH3NH3PbI3−xClx prepared from the precursor containing MAI and PbCl2 (3:1 molar ratio). The Rrec values for the planar CH3NH3PbI3 cells prepared from the CH3NH3PbI3 precursor with two MACl additives are also plotted for comparison. Reproduced with permission from ref 133. Copyright 2014 American Chemical Society. 

in which very dissimilar voltage dependencies can be observed for similarly processed samples (a), while in other cases changes in processing induces observable and reproducible trends in the recombination resistance (b). 

More recently, several works focused on the relative impact of specific recombination paths on the overall solar cell functioning through IS analysis.<sup>38,97,130,138</sup> One example of the crucial effect of passivating HTL recombination paths is shown in Figure 39.<sup>139</sup> Here, Zn-TFSI2 is used instead of Li-TFSI as a dopant for spiro-MeOTAD. The device with Zn-TFSI2 showed over 80 mV higher built-in voltage and a bigger Rrec than the one with Li-TFSI, which was responsible for the striking increase in both the open-circuit voltage and fill factor, leading to a stabilized PCE of 22.0% for the best cells. 

14454 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 



<!-- Start of picture text -->
pubs.acs.org/CR Review<br><!-- End of picture text -->



Figure 39. Recombination resistance of the devices employing LiTFSI (black) and Zn-TFSI2 (red) as a function of the applied voltage. Reproduced from ref 139 with permission from the Royal Society of Chemistry. 

Other studies have attributed variations in Rrec to improvements in perovskite layer crystallinity.<sup>140</sup> When poly(3,4ethylenedio-xythiophene):poly(styrenesulfonate) (PEDOT:PSS) is replaced by the π-conjugated organic small molecule 4,4′-cyclohexylidenebis[N,N-bis(4-methylphenyl) benzenamine] (TAPC) as an efficient hole transport material, the perovskite photoactive layer cast onto thermally annealed TAPC displays large grains and low residual PbI2, leading to a high value of Rrec, as shown in Figure 40. 



Figure 40. IS data of TAPC-RT, TAPC-120, and TAPC-160-based devices measured under AM 1.5G illumination with 0.6 V bias. Reproduced with permission from ref 140. Copyright 2017 John Wiley and Sons. 

#### 6.2. Recombination and Correlation of Resistances 

As explained in Figure 23, in the simplest and most common MHP impedance response, two resistances are observed which dominate the HF (R3) and LF (R1) ranges, respectively. In some cases, these two resistances, that apparently represent different physical phenomena, display a similar dependence on illumination and voltage,<sup>97,141</sup> signaling some kind of physical correlation, Figure 41. This is particularly observed for 3D perovskite in the simplest formulations. However, for multicomponent perovskite absorbing layers, the LF and HF 



Figure 41. (a) Intensity dependence of the resistances extracted from the high-frequency and low-frequency semicircles measured by IS on a PSC. (b) Intensity dependence of the resistance values extracted from the HF and MF semicircles observed in IMVS (scaled to give the same value of Cg). (c) Temperature dependence of the midfrequency time constant measured from IMVS. (d) Temperature dependence of the low-frequency time constant measured by IS. Reproduced from ref 141 with permission. Copyright 2017 the Royal Society of Chemistry. 

#### resistances behave differently, suggesting a variety of recombination mechanisms.<sup>142</sup> 

More specifically, the resistances for MAPbI3-based planar solar cells with four different contacting layers are shown in Figure 42a. It is observed that both resistances exhibit voltage dependencies of the type Rrec ∝ e<sup>−qV/2kBT</sup> at high forward potentials. Nevertheless, this reported simple behavior is not universal. As shown in Figure 42b, in the case of mixed cation and anion absorber perovskites, HF and LF resistance behave differently with exponents m = 2 and m = 1.5, indicating a much more complex situation associated with decoupling of recombination mechanisms.<sup>142</sup> It is also noticed in Figure 42 that components of the shunt resistance dominate at lower voltages. 

Because of the common trend of HF and LF resistances, one can assume that the total recombination resistance Rrec can be regarded as the addition of R3 and R1. In addition, the voltage dependence with exponent −1/2kBT is a clear indication that similar densities of electrons and holes participate in the carrier recombination mechanism. 

This would lead us to compare exponents of the Rrec versus voltage plot, with the ideality factor of the current−voltage characteristics,<sup>123,130,142−144</sup> as mentioned earlier. Some models have proposed from resistive analysis that recombination events mainly occur at the outer interfaces (surface recombination). Photovoltage losses were then linked to the decrease in surface hole density, producing 0.3 V reduction with respect to the ideal radiative limit.<sup>97</sup> However, bulk recombination cannot be ruled out, principally when simple −1/2kBT exponents are encountered.<sup>145</sup> As previously commented on, much more systematic analysis of the resistive 

14455 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 42. High- and low-frequency resistance as a function of voltage for a variety of solar cells containing different perovskite absorbers 3D layers based on (a) CH 3 NH 3 PbI 3 or (b) mixed Cs0.1FA0.74MA0.13PbI2.48Br0.39 and a variety of interlayers (2D perovskite thin capping). Adapted with permission from ref 142. Copyright 2018 Elsevier. 

response is necessary to make further progress in the elucidation of recombination mechanisms. 

#### 6.3. Resistances in the Dark 

The IS response in the dark normally shows two arcs in optimized devices (Figure 43a), as also observed under 



Figure 43. (a) Complex impedance plot of a typical photovoltaic devices measured in the dark at 0 V based on (a) MAPbI3 and (c, d) MAPbBr3. (b) Correlation between the HF resistance and the thickness in MAPbI3 devices. Adapted with permission from ref 65. Copyright 2019 AIP Publishing. 

illumination. The perovskite material is highly resistive in the dark, and the response of the intrinsic conductivity of the perovskite layer is manifested in the HF region.<sup>96,146</sup> The resistance scales with the thickness for the perovskite layer for thick pellets (hundreds of microns) as shown in Figure 43b.<sup>96</sup> Alternatively, at a lower thickness of 200−400 nm, the contribution of the contacts becomes dominant at HF. 

Figure 44b shows the HF response of an interdigitated electrode with a channel length of 150 μm that is polarized by applying an electrical field.<sup>130</sup> The HF arc increases the resistance as the applied voltage induces a reduction in the doping density in the perovskite material. 

On the other hand, the origin of the LF arc is connected to ion migration and formation of an ionic double layer. Observation of the ionic double layer depends very much on the type of extraction layers used as discussed in the next section. At LF, the effect of ion migration and attachment to the interface becomes important, and the electronic and ionic contributions to the impedance response are mixed.<sup>77</sup> 

When extraction layers are prone to give chemical reactions with migrating ions, the chemical reactivity and passivation of defects are also observed in the LF arc. In experiments where the perovskite is in direct contact with a thin Ag contact, the mobile ions can react with the silver as confirmed by XPS analysis.<sup>148</sup> In devices subjected to polarization experiments while measuring the IS, the evolution of the spectra was monitored as the chemical reaction proceeds to form AgI. The LF arc was the only changing feature during the chemical reaction. 

Measurements in the dark also offer the possibility to detect nonoptimized conditions. This is the case when inefficient external layers respond at time scales neatly decoupled from bulk electronic processes showing a separate arc. For example, in experiments using MAPbBr3 (Figure 43c,d), it was shown that the presence of spiro-OMeTAD was clearly connected with the appearance of a third arc at intermediate frequencies that was coupled with an increase in capacitance.<sup>65</sup> The offset in energy levels between the conduction band of MAPbBr3 and the HOMO level of spiro-OMeTAD could account for this additional resistance,<sup>39</sup> but a modification in the characteristic time constant for the process could also be responsible for the appearance of this new arc. Similarly, the use of undoped spiroOMeTAD in combination MAPbI3 shows an additional arc at very high frequencies as discussed in section 5.4. 

### 7. IONIC DIFFUSION AND TRANSMISSION LINE OBSERVATION 

The method of impedance spectroscopy has a well-defined spectral shape for identification of diffusion in a thin layer.<sup>28,149</sup> This model has been widely used in electrochemical analysis of ion-intercalation systems and batteries.<sup>150,151</sup> Diffusion− recombination impedances for electronic systems have been described here in Figure 7. For the diffusion of ions in a thin film, a different pattern is expected since the ions do not recombine, and they are blocked at the arrival electrode. According to the transmission line model,<sup>28,149</sup> for an ionblocking boundary, there is a transition of two features, from a 45° Warburg feature at high frequency, to a vertical feature associated with capacitive charging, indicated in Figure 45c. The diffusion coefficient can be determined from the characteristic frequency of the transition and the thickness of the sample<sup>152</sup> 

14456 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 44. (a) Evolution of PL in interdigitated electrodes with film under an external electric field (∼2 × 10<sup>4</sup> V/m). The “+” and “−” signs indicate the polarity of the electrodes. (b) Complex impedance plot of an interdigitated electrode measured in the dark as a function of the applied DC bias. (c) PL decay in the intensity of the device measured in (b). Adapted with permission from ref 147. Copyright 2018 Springer Nature. 



Figure 45. Impedance of ion diffusion in a finite layer is a transmission line composed of a distributed transport resistance and chemical capacitance. The process of termination at the boundary, represented by the boundary impedance, ZB, dramatically changes the impedance spectra at low frequency. For a blocking boundary shown in (a) the impedance rises vertically (c). For a boundary that allows charge transfer (b) the impedance forms an arc at low frequency that decreases when the charge transfer rate at the contact increases (d). This arc will be eventually exhausted when the ionic reservoir becomes full. Reproduced with permission from ref 103. Copyright 2018 American Chemical Society. 



<!-- Start of picture text -->
D<br>μ<br>ω d = d 2 (33)<br><!-- End of picture text -->

For a permeable boundary, the low-frequency property is not vertical but rather an arc depending on the charge transfer rate at the boundary,<sup>100</sup> as shown in Figure 45d. This pattern is similar to the Gerischer impedance in Figure 5c, but the interpretation is quite different. In Figure 45c, the lowfrequency feature closes to the real axis due to the absorbing boundary condition, but yet another feature will be formed if the organic layer is thin and becomes full of injected ions. 

In MHP, there are both electronic and ionic conduction by several carriers at the same time. Therefore, it is necessary to consider the transmission line of a multiple ionic-electronic carrier system, the model of Figure 32c. Since the impedance measurement will show the least resistive pathway, the existence of a significant electronic component in the MHP makes the measurement of ionic conductivity difficult under most conditions. The electronic transport will provide the electrical pathway, and the ionic resistance will most likely not be observed. 

There have been many reports over the years indicating transmission line behavior associated with either electronic or ionic transport,<sup>72,98,153−155</sup> but very few of them are conclusive about ionic diffusion. For example, Venkataraman and coworkers<sup>72,156,157</sup> presented the observation of Warburg-like features as indication of ion transport. A generalization of the EC was proposed that includes ion diffusive elements along with capacitive ones as seen in Figure 46. 

For a deeper insight into the analysis of ionic diffusion, it is recommended to prolong the measurement to very low frequency in order to obtain the information about the patterns of Figure 45. If the turnover frequency is observed, then it is straightforward to derive the diffusion coefficient by eq 33.<sup>152</sup> 

The full diffusion impedance associated with ionic transport has been in fact observed for low doped monocrystalline MAPbBr3 samples in the dark, contacted with gold electrodes, 

14457 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 46. (a) IS plot of a MAPbI3 sample at 45 °C at 100 mW·cm<sup>−2</sup> light intensity and 0 V applied bias. (b) Equivalent circuit diagram of perovskite solar cells showing combined charge and ion transport impedance. Reproduced from ref 72. Copyright 2015 American Chemical Society. 

as shown in Figure 47.<sup>103</sup> The method aims at minimizing the electronic conductivity using dark conditions and Vdc = 0 V. A 



Figure 47. Different configurations used for devices containing MAPbBr3: (a) monocrystalline, (c, e) polycrystalline. (b, d, f) Complex plane impedance plots extracted from impedance measures in the dark at 0 V for configurations shown on their left. Solid lines correspond to fitting results using EC shown in Figure 32. Ionic processes are highlighted with different colors: ionic transport (red), charge accumulation (gray), and diffusion into absorptive contacts (brown). Reproduced with permission from ref 103. Copyright 2018 American Chemical Society. 

distortion of the impedance pattern is observed by including an organic layer, as expected for a partially absorptive boundary, as indicated in Figure 47e,f. The chemical diffusion coefficient of Dμ = 1.8 × 10<sup>−8</sup> cm<sup>2</sup> /s has been calculated for Br<sup>−</sup> from the correlation of the frequency of the ankle to the thickness of the 

perovskite layer. This result is in agreement with the measurements obtained by other independent methods.<sup>147,158</sup> 

The diffusion of ions has been probed by alternative methods related to IS. The kinetic coefficients of MHP have been investigated using transient capacitance techniques.<sup>159</sup> An analysis of frequency modulated transmittance data<sup>160</sup> (Figure 48) shows that the bulk mobile ion density is modulated by the light illumination. The spectral transient response of the ion density is very similar to that of a finite Warburg element. The consequent determination of the diffusion coefficient is 10<sup>−11</sup> to 10<sup>−10</sup> cm<sup>2</sup> s<sup>−1</sup> , indicating a slower response than with the voltage modulated method of IS. 

The coupling of ion diffusion and photoluminescence provides interesting observations in a planar sample with lateral contacts.<sup>161−163</sup> Ion migration leads to PL quenching in the form of a dark front that advances with time (Figure 44a).<sup>147</sup> By combining optical and electrical measurements, it is possible to observe the evolution of the HF resistance in the dark (Figure 44b) related to the intrinsic conductivity of the perovskite. As the DC bias is increased, the HF resistance increases in line with the reduction in PL intensity and decreased doping density in the perovskite. This effect is partially reversible since ions can go back to an equilibrium position with partial recovery of the PL, and resistance reduces its magnitude with time. 

The connection of ion distribution and electronic doping density has been recently corroborated using long-time impedance relaxation.<sup>164</sup> Zero-bias HF resistive features slowly recover steady-state values after poling, indicating that the overall ion concentration establishes the effective electronic conductivity through a dynamic doping mechanism. That approach allows for an indirect determination of the ionic diffusion coefficient, which also results in the range of 10<sup>−8</sup> cm<sup>2</sup> s<sup>−1</sup> . 

### 8. NEGATIVE CAPACITANCE PHENOMENA 

#### 8.1. Frequently Observed Negative Capacitance 

In addition to the typical arcs in the complex impedance plane of the standard model in Figure 23, MHP devices very frequently exhibit inductive loops and negative capacitances, as also found in other types of solar cells in the past.<sup>165</sup> In some cases, the distortion of spectra is an unstable feature due to the time drift of the sample,<sup>166</sup> as discussed in section 12.4, but in others the negative capacitance is a stable and physically robust response; see Figure 3. In terms of materials properties, it has been observed that negative capacitance effects in MHPs are rather sensitive to the surface conditions.<sup>77</sup> 

In MHP, there are two main types of characteristic spectral behaviors according to the reported observations. The first is a final semicircle with the shape of a hook entering the fourth quadrant (+Z′′) at very low frequencies; see Figure 1, Figure 3, and Figure 49.<sup>77</sup> The hook feature has been observed already in very early measurements<sup>153,167</sup> and is reported in many papers on the halide perovskite solar cells.<sup>123,168,169</sup> It becomes very prominent in perovskite memristors as shown in Figure 3a.<sup>26</sup> 

In other cases, the impedance spectra show the formation of an intermediate frequency loop between the LF and HF arcs, Figure 35c.<sup>96,170−173</sup> This has been observed for systems where charge extraction contact is not efficient (i.e., Nb2O5)<sup>96</sup> and in samples with composite contacts.<sup>174,175</sup> Similar results are observed for TiO2 prepared by spray pyrolysis.<sup>176</sup> The TiO2 

14458 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 48. Cole−Cole plots of ΔT/T at various probe wavelengths under a modulated light power of 77.7 mW cm<sup>−2</sup> (520 nm). X(Re(ΔT/T)) and Y(Im(ΔT/T)) axes are the real part and imaginary part of ΔT/T, respectively. (b) Photoinduced absorption spectrum ([ΔT(0) − ΔT(∞)]/T), of which ΔT(0)/T and ΔT(∞)/T are ΔT/T at angular frequency 0 and ∞. Reproduced from ref 160 with permission. Copyright 2020 from the Royal Society of Chemistry. 



Figure 49. (A) Complex plane impedance plot of CH3NH3PbI3 films measured in a mild vacuum (10<sup>−3</sup> mbar) environment. Data are presented for the top (black) and bottom (red) electrode configurations for different residence times in the vacuum. (B) Mild vacuum data for top contact with residence time of 40 min and fit to the EC presented above in the plot. Reproduced with permission from ref 77. Copyright 2016 American Chemical Society. 



Figure 50. (a) Reverse j−V curves, scanning from positive to zero potential, showing the stability of sample behavior before and after impedance measurement. (b) Representative Impedance spectra of samples 1 and 2 taken at a fixed voltage of 0.7 V and under 1 sun illumination. A prominent arc below the x-axis appears at low frequencies for sample 2. Reproduced with permission from ref 123. Copyright 2017 American Chemical Society. 

layer has an influence on the impedance spectroscopy response of the cells over the whole frequency range. In the case of the most poorly performing devices, the inductive loop is more pronounced, and it is observed over a larger potential range. Since there is a practical limit to the measurement of impedance data at low frequency, in some cases it is unclear whether the hook feature could be continued to a full loop, followed by another arc at lower frequencies. 

The negative capacitance can be associated with a decreased performance of the solar cell. Figure 50 shows the measurement for two representative different PSCs (labeled as samples 1 and 2) with CsPbBr3 as the active layer and TiO2 and polytriaryl amine (PTAA) as electron and hole selective layers.<sup>123</sup> For one sample, the impedance only shows the typical two arcs with positive capacitances. For the other sample, the j−V curve is less stable, and there is a decrease of performance, associated with the formation of an arc in the fourth quadrant with an inductor element that decreases the resistance as in Figure 49. The inductive feature has an important deleterious impact on the solar cell, decreasing Voc and to an even higher extent the fill factor. Negative capacitance and inductive features have also been correlated to the amount of inverted hysteresis,<sup>168,177</sup> as discussed in section 10.2.2. 

The most common procedure in the literature to describe the data in the presence of negative capacitance is to include 

inductor elements in the EC, as shown in Figure 49b.<sup>165</sup> Such inductor elements do not correspond to a magnetic induction effect but to a dynamic behavior that may have diverse origins such as the relaxation impedance that has been previously applied in electrochemistry<sup>178</sup> or a variable series resistance.<sup>179</sup> These approaches are discussed in detail in the next section. 

Several ECs have been proposed for MHP that lead to inductive loops and negative capacitance; some of them are shown in Figure 51.<sup>96,175,180</sup> In common with the usual indeterminacy of an EC,<sup>34</sup> different alternatives can be applied to include the inductor. The main types are either a parallel RLC as in Figure 36 and Figure 51a or the RL series connection as in Figure 51b. 

8.2. Interpretation of the Inductor Element and the Negative Capacitor 

8.2.1. Kinetic Origin of the Inductive Loop. Let us analyze the physical origin of the inductor element in ECs for solar cells. The EC in Figure 51b is derived from a physical surface polarization model<sup>175</sup> that describes the autonomous relaxation of the internal voltage at the contact surface in a MHP, Vs, based on a relaxation equation of the type<sup>181</sup> 



<!-- Start of picture text -->
d V s V s − ( V − V bi)<br>= −<br>d t τ kin (34)<br><!-- End of picture text -->

14459 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> <mark>Review</mark> 



Figure 51. (a) Equivalent circuit used for three arcs spectra and intermediate frequency loops; here, resistances appear in series. Reproduced with permission from ref 97. Copyright 2016 American Chemical Society. (b) Equivalent circuit used for spectra with two arcs and inductive intermediate loop, with the branches in parallel. Reproduced with permission from refs 96 and 175. Copyright 2016 and 2017 American Chemical Society. 

Here V is the total voltage between the contacts, Vbi is the built-in voltage, and the relaxation kinetic constant τkin is determined by the rapidity of ion displacement when the surface is polarized and depolarized by external bias or photovoltage.<sup>94</sup> 

Later it has been found that eq 34 is a particular instance of a more general formalism. From a general standpoint, the inductive behavior observed in MHP emerges from a type of kinetic equations in which an internal slow state variable undergoes a relaxation process, forced by the external “fast” variable. This mechanism has been applied in electrochemistry,<sup>178,182,183</sup> and recently this framework has been formulated in a generalization that encompasses the impedance of memristors as well as the impedance of biological neurons.<sup>184</sup> The model is expressed for the external voltage V and current I across the device, and an internal current w that describes the slow transient effects (such as ionic effects) that occur when the external variables are displaced to a different steady-state level. The kinetic equations have the form 



<!-- Start of picture text -->
d V<br>τ m = f ( V ) + R I(− w + I)<br>d t (35)<br><!-- End of picture text -->



<!-- Start of picture text -->
d w 1<br>τ k = − w<br>d t R a V (36)<br><!-- End of picture text -->

The independent parameters in the model are the voltage response time , the recovery current response time τk, channel resistor RI, and recovery current resistor Ra. f(V) is a conductivity function of the main channel. As w is subjected to a slow relaxation process in eq 36, it is expected τk ≫ τm. This type of model forms part of the general framework of fastslow dynamical models,<sup>185</sup> which includes famous dynamical models like the van der Pol oscillator or the FitzHugh− Nagumo neuron model.<sup>186</sup> A series of derived parameters are useful for the physical interpretation: capacitance, a resistance, and internal variable inductor: 



<!-- Start of picture text -->
τ m<br>C m = R I (37)<br><!-- End of picture text -->



<!-- Start of picture text -->
R b = −′ R I<br>f (38)<br>L a = τ k R a (39)<br>impedance obtained from eqs 35 and 36 has the<br>expression<br>Z ( ω ) = [ R b−1 + C m s + ( R a + L s a )−1]−1 (40)<br><!-- End of picture text -->

The impedance obtained from eqs 35 and 36 has the expression 

This impedance function can be represented as the EC model of Figure 52 that was proposed to accommodate a negative capacitance in solar cells.<sup>165</sup> The kinetic eqs 35−36 have been used for the interpretation of hysteresis in MHP devices;<sup>177</sup> see section 10.2.2. 



Figure 52. Equivalent circuit including an inductive branch and the associated complex plane impedance spectra. (a) Ra = 2, Rb = 10, Cm = 10, La = 200, (c) Ra = 10, Rb = 10, Cm = 10, La = 1000, (d) Ra = 2, Rb = 10, Cm = 100, La = 100. The arrow indicates the direction of increasing frequency. Panel (b) is the real part of the capacitance of the system parameters in (a). The point in (a) is at the angular frequency 1/τk = Ra/La. 

Therefore, in recent work, the series RL branching has been favored in the analysis of MHP<sup>168,180</sup> since this EC can be obtained rigorously from basic physical considerations that relate to the structure of the impedance of a fast-slow dynamical system. However, it must be recalled that the series or parallel connection of the inductor are equivalent via related ECs in a transformation similar to that of eqs 28−30 in Figure 26. The issue of the fundamental kinetic equations is therefore open to more investigations. 

8.2.2. Inductive Impedance Spectra. We discuss the spectral hook feature in Figure 52a. At high frequency, the model shows a regular relaxation (arc) with a resistance Rb and 

14460 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

time constant τm = RbCm. The total resistance at dc conditions, however, must be less, due to the parallel component Ra. The contribution of the lower branch depends on the frequency. The impedance of the inductor Z = iωLa is large at high frequency, and Ra has no effect. When the frequency is reduced, this branch becomes active and reduces the overall resistance of the system. In general, the resistance associated with the inductor becomes active in slow time scales, forming a memory effect. In PSC, it can be interpreted as the onset of surface recombination that reduces the efficiency of the solar cell, as shown in Figure 50.<sup>123</sup> 

The EC of Figure 52 has different possible types of spectra as shown in Figure 52a,c,d. Let us define the characteristic frequency of an LC circuit as ωLC = (LaCm)<sup>−1/2</sup> . Then the frequency of the intercept in Figure 52a is 



<!-- Start of picture text -->
Ä 2É 1/2<br>ω 1 = ÅÅÅÅÅÅÅÅÅÅÇ ω LC2 − ijjjjjk RL aa yzzzzz{ ÑÑÑÑÑÑÑÑÑÑÑÑÖ (41)<br><!-- End of picture text -->

The negative arc occurs only if ωLC > Ra/La. This negative arc phenomenon is fairly general and has been observed in a wide variety of materials systems. For PSC, the model was already shown in Figure 49,<sup>77</sup> and the model describes well the data in Figure 3. Figure 53 shows two different examples of the general EC with the inductor line associated with interfacial electronic phenomena for the measurements of an OLED device<sup>187</sup> and a CdS/CdTe solar cell.<sup>165</sup> 

8.2.3. Inductor or Negative Capacitance? The denomination of “negative capacitance” requires clarification; we can 



Figure 53. Left column. Results of the measurement of an ITO/ PEDOT/superyellow/Ba/Al organic LED device. (a) Impedance plots for different bias voltages. Panels (b) and (c) show a magnification of the observed inductive behavior at 2.9 and 2.7 V, respectively. (d) Capacitance versus frequency for various bias voltages indicating a region of negative capacitance. Reproduced from ref 187. Copyright 2016 Elsevier. Right column. Impedance spectra for a CdS/CdTe solar cell. (a−c) Complex plane plot of the impedance at two different forward biases in dark conditions. The frequency range employed in the measurement was 1 MHz to 0.1 Hz. (d) Absolute value of capacitance vs frequency at forward bias. Reproduced with permission from ref 165. Copyright 2006 American Chemical Society. 

further analyze this issue. In the EC of Figure 52, all elements are defined positive, and there is not a negative capacitor. But in the representation of the impedance, it is quite common to calculate the real part of the capacitance via eq 7. As the RL feature enters the fourth quadrant of the complex plane, the associated real part of the capacitance C′ is negative, Figure 52b, which leads one to the denomination of negative capacitance, even though this feature has been described with positive elements, that is, using positive resistances, capacitors, and inductors. 

On the other hand, we can introduce a negative capacitance using the following approximation.<sup>165</sup> The low-frequency limit of the admittance related to eq 40 is 



<!-- Start of picture text -->
Y ( ω ) = R 1a + R 1b − s ijjjjjk R L aa2 − C myzzzzz{ (42)<br><!-- End of picture text -->

Therefore, the final part of the negative arc can be viewed as the composition of the total dc resistance and a negative capacitance, provided that the following condition is satisfied 



<!-- Start of picture text -->
RL aa > R a C m (43)<br><!-- End of picture text -->

This is the condition for the appearance of inductor feature in the impedance diagram, obtained from eq 41. We remark that eq 40 and eq 42 are not equivalent, and hence there are two alternatives to describe the negative imaginary features in impedance spectra, namely, the positive inductor and a negative capacitor. On the other hand, it is not possible to transform eq 40 into an equivalent model with negative capacitance alone. As shown by Klotz,<sup>188</sup> the equivalent transformation requires both a negative capacitance and a negative resistance. 

Different from the usual negative capacitance features is the presence of a negative differential resistance (NDR), in which the j−V decreases as the voltage increases.<sup>189</sup> The NDR is a necessary condition in oscillatory electrochemical systems,<sup>190</sup> and the impedance goes into the second and third quadrant of the complex plane.<sup>33</sup> The NDR is so far not reported in MHP to our knowledge. 

8.2.4. Nonequilibrium Intrinsic Negative Capacitance. The meaning of the counterintuitive intrinsic negative capacitor has been broadly discussed in the literature. It can be associated with a certain electronic state that is discharged when the associated chemical potential is increased. One example is an intermediate electronic state that is emptied by a large applied voltage, due to the modification of the rate constants for the exchange of the electronic state with the environment, as indicated in Figure 54a.<sup>187,188</sup> The negative capacitance is often found in electrochemical measurements of electrocatalysis, electrodeposition, and electrodissolution.<sup>190−192</sup> Similar to the previous mechanism, it occurs when the concentration of the adsorbed species decreases, while the potential increases, contrary to the equilibrium isotherm, as a result of a significant charge−transfer current. Another related mechanism occurs in double-barrier resonant tunneling diodes as shown in Figure 54b. The quantum capacitance (equivalent to the chemical capacitance) becomes negative in the region of NDR due to the decrease of electron charges in the quantum well at increasing forward bias.<sup>193,194</sup> 

The intrinsic negative capacitance is an effect that occurs when a reactive system or charge transfer electronic system is maintained far away from thermodynamic equilibrium by 

14461 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 54. Mechanisms for intrinsic negative capacitance. (a) A surface state becomes empty when the potential V is increased. (b) The same for a quantum well in a resonant tunnel diode. 

intense dc current. The detailed balance condition, that the rates far from equilibrium can be extrapolated from those at equilibrium,<sup>195,196</sup> is broadly used to elaborate a dynamical model. By using rates that obey detailed balance, a normal chemical capacitance is obtained. However, if the kinetic constant across injection barrier depends on the voltage, then we are out of detailed balance (the rates far from equilibrium are essentially different from those at equilibrium), and a departure from the normal thermodynamic concept of the chemical capacitance follows.<sup>197</sup> It is likely that we find a violation of the normal definition of rates by detailed balance behind many varied mechanisms suggested in the literature for negative capacitances. The issue requires further investigation. If the kinetic rates have such properties, a variety of kinetic phenomena that break the usual meaning of a chemical capacitance become feasible, including the discharge at high forward bias. The main problem with this type of explanation is that it is relatively easy to generate exotic nonequilibrium behavior such as negative capacitance. One can get the desired simulations of the experimental characteristics, but it is difficult to verify the nonequilibrium kinetic physical assumptions, and very often the models remain ambiguous and arbitrary. 

8.3. Interpretation of Negative Capacitance by Modulation Currents 

There are different hypotheses about the physical origin of the intermediate loops and negative arcs in the fourth quadrant. Several papers have indicated the connection of ionic− electronic accumulation at the surface, and its possible influence on electron transfer and recombination rates, in order to explain large capacitance and inductive behavior.<sup>81,175,198,199</sup> In the same spirit, it was previously suggested that recombination at the interfaces is affected by the changing environment of ions when their occupation at the double layer is modified by the photovoltage or polarization.<sup>141,200</sup> Some recent studies have proposed that LF capacitive or inductive features come from the electronic conduction or recombination currents modulation rather than by charge accumulation.<sup>81,173,198,199</sup> These kinds of models introduce a dependence of electronic conductive or recombination properties on additional mechanisms which also vary under perturbation, which is the basic toolkit to generate exotic dependence in impedance characteristics as mentioned before. Ultimately, 

these couplings produce an alteration in the LF part of the impedance response.<sup>201</sup> Their use is well-known in electronics, as observed in the conductivity modulation of p−n junction diodes at forward bias that produces inductive loops<sup>202</sup> or the thermal diffusivity of thermoelectric modules giving rise to large positive LF capacitances.<sup>203</sup> 

The suggestions<sup>200</sup> that carrier recombination in PSCs depends on the ionic environment proposed that, under operation, vacancies move to increase the recombination resistance from the millisecond to the second time scale.<sup>204</sup> This view has been further elaborated,<sup>199</sup> assuming that the electronic−ionic coupling directly influences LF, when the carrier recombination current becomes phase-delayed with respect to the voltage perturbation because of the ion displacement. Ultimately, LF capacitance is caused by out-ofphase carrier recombination instead of electronic charge accumulation. Figure 55 confronts experimental capacitance spectra with simulated phase-delayed carrier recombinationionic displacement coupled contributions at LF. 

Similarly, sophisticated ECs (an ionically gated transistor interface) have been proposed<sup>81</sup> accounting for the ionic− electronic coupling governing charge injection and recombination. Also, very recently, analogous arguments have been developed, but in this case ionic effects were disregarded, and instead delayed electronic injection currents were proposed as the sole cause of the LF capacitive phenomena, even in the dark.<sup>198</sup> Obviously, that explanation should be evaluated with additional experiments, not only IS responses. Recent findings reveal, however, that real steady-state charge is indeed induced by the applied voltage in the dark, easily interpreted by means of charged real capacitors with values much larger than the film geometrical capacitance.<sup>205</sup> 

### 9. LIGHT-MODULATED SMALL PERTURBATION TECHNIQUES (IMPS AND IMVS) 

#### 9.1. Methods of IMPS and IMVS 

The complexity associated with the interpretation of IS in PSC may be related to the limited amount of information that IS alone can supply so that the measured characteristics are due to a mixture of complicated phenomena. In fact, IS measures a current in response to a voltage, where both quantities are measured at the external contact. The ECs found in the spectral responses reflect the least resistance pathway and associated capacitances. It is therefore not surprising that the technique cannot resolve all the internal processes that govern the physical response. 

In order to overcome this limitation, it is possible to expand the range of techniques using also light-modulated stimulus, which leads us to the methods of intensity modulated photocurrent spectroscopy (IMPS) and intensity modulated photovoltage spectroscopy (IMVS). These methods have been widely applied in emerging solar cells especially in connection with the determination of diffusion parameters.<sup>206−211</sup> The different applications of IMPS with a view to characterization of MHP<sup>132,141,212,213</sup> have been recently reviewed.<sup>214</sup> 

IMPS involves the measurement of a modulated extracted current density Jê upon the application of a small perturbation of modulated photon flux Φ̂ over a wide range of frequencies, generally between 10<sup>−2</sup> and 10<sup>6</sup> Hz. We express the spectral flux in the units of electrical current as follows 

> <sup>_j_</sup> Φ = _q_ Φ̂ (44) 

14462 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 55. (a) Experimental C−f measurements of a “standard” fluorine doped tin oxide (FTO)/cp-TiO2/mp-TiO2/MAPbI3/spiroOMeTAD/Au cell in darkness (gray) and under illumination (yellow). The dashed line indicates an extrapolation of the ionic contribution toward high frequencies. (a, inset) Complex plane impedance plot at 0 V under illumination, zoomed in on the highfrequency region (circled data correspond to frequencies in the indicated portion of the C−f spectrum). (b) Cumulative area plot of a simulated C−f spectrum under illumination showing the relative contributions of phase-delayed recombination (AR, yellow) and the more familiar charge-storage capacitance (CQ, blue). Here, two ionic species with diffusion constants 10<sup>−10</sup> cm<sup>2</sup> s<sup>−1</sup> and 10<sup>−13</sup> cm<sup>2</sup> s<sup>−1</sup> were used to emulate the broad spectrum observed experimentally. Reproduced with permission from ref 199. Copyright 2018 AIP Publishing. 

#### The IMPS transfer function QΦ is then calculated as 



<!-- Start of picture text -->
Q Φ( ω ) =̂̂ J e ( ω )<br>J Φ( ω ) (45)<br><!-- End of picture text -->

In the same manner as IS, IMPS can be measured under any given DC bias voltage or light intensity. The data are represented in the form of a Q-plane plot, which is a plot of the real part of the IMPS transfer function Q′(ω) versus the negative imaginary part - Q′′(ω) as indicated in Figure 56. Similarly, a IMVS transfer function is obtained from the modulated voltage<sup>215</sup> 



<!-- Start of picture text -->
V ( ω )<br>W ( ω ) = −̃̂<br>j Φ ( ω ) (46)<br><!-- End of picture text -->

QΦ is a current-to-current ratio and hence is dimensionless. Just as the derivative in eq 4 relates to the impedance at frequency zero, the low-frequency limit of the IMPS transfer 



Figure 56. IMPS response for a PSC showing the RC time constant at high frequency and a low-frequency semicircle. Reproduced with permission from ref 132. Copyright 2015 American Chemical Society. 

function QΦ coincides with the external quantum efficiency EQEPV obtained from the differential spectral response method, when the chopper frequency tends to zero.<sup>132,213,216</sup> Pockett et al. first found a correlation of the EQE to the quality of different PSCs.<sup>132</sup> 

#### 9.2. Correlation of the Different Techniques 

A general connection exists between the three transfer functions, first suggested by Halme<sup>215</sup> for dye-sensitized solar cells: 



<!-- Start of picture text -->
W Φ( ω )<br>Z ( ω ) =<br>Q Φ( ω ) (47)<br><!-- End of picture text -->

The general proof that shows the structure of eq 47 is based on the master equation of Bertolucci et al.<sup>16</sup> that connects the different possibilities of small current perturbation corresponding to voltage, electrical current, and light flux: 



<!-- Start of picture text -->
j e =̂ Q Φ( ω ) j Φ +̂ Z −1( ω ) V (48)<br><!-- End of picture text -->

The connection between the techniques is explained in ref 217; see Figure 57 for the different measurement conditions 



Figure 57. Different connections to measure IS, IMPS, and IMVS in a simple circuit. Note that the current source and parallel resistance can be transformed to a voltage source and series resistance. Reproduced from ref 217. Copyright 2020 American Chemical Society. 

applied to a simple EC. Impedance Z(ω) is defined in the absence of modulated illumination, JΦ̂ = 0. With IMPS, we impose V̂ = 0, and the resulting photocurrent modulation Jê (ω) is measured to provide QΦ (ω). IMVS transfer function WΦ (ω) consists of maintaining the photocurrent perturbation at zero (Jê = 0). The three connections are linked by eq 48 such that for a given steady state the impedance of the system can be directly expressed in terms of the IMVS and IMPS transfer functions as shown in eq 47. 

14463 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

Furthermore, eq 48 indicates that, using a combination of different voltage and light-modulated methods, the underlying EC of a system must be able to describe the different small perturbation techniques,<sup>16</sup> provided the solar cell has been stabilized and the steady-state conditions are the same in the different methods (i.e., Voc conditions). Thus, from a single EC, one can obtain the spectral response of IS, IMPS, and IMVS,<sup>218</sup> as indicated in Figure 57. Even though the EC is the same for the different stimulations, the connection of the AC generators inside the EC is quite different for voltage and illumination. In Figure 57, the current source is connected in parallel to the recombination resistance, while the voltage source is connected on the outer terminals. Correspondingly, for a structured EC the spectral shapes are different, as shown in Figure 58, which allows one to obtain additional information using a combination of the different methods. 



Figure 58. (a) Standard EC shown in Figure 23 with the addition of the generator in parallel with R3. The EC is accompanied by IS (b), IMPS (c), and IMVS (d) spectra for the following values of the circuit elements: RS = 10 Ω, Cg = 0.2 μF, R3 = 60 Ω, and R1 = 50 Ω, C1 = 1 mF. Reproduced with permission from ref 180. Copyright 2020 American Chemical Society. 

The fundamental model for the EC of a solar cell, Figure 4b, in the measurement of IMPS is represented in Figure 4e. In Figure 58, we note the current generator connected in parallel to the recombination resistance R3 pertaining to the standard circuit of the PSC (Figure 23). The generator represents bandto-band generation of carriers by the photon flux. The EQE has the expression 



<!-- Start of picture text -->
i R s + R 1 y−1<br>EQEPV = jjjjjk1 + R 3 zzzzz{ (49)<br><!-- End of picture text -->

The loss through R3 reduces the current from the generator measured through Rs in the outer circuit. EQE decreases when R3 decreases as shown by a LF arc in the fourth quadrant in Figure 58c. The IMPS negative arc is obtained without inductors of negative capacitances.<sup>214</sup> 

IMPS measurements on three types of CH3NH3PbBr3 cells shown in Figure 59 present additional features<sup>218</sup> with respect to the basic model of Figure 58. In order to account for an extra intermediate frequency process, the basic IMPS model of the PSC is expanded by the addition of a capacitor C2 with a corresponding resistor R2. The simulated IMPS spectra in Figure 60b reproduce well the experimental spectral features of 

Figure 59a−c. The additional IMPS feature is well described by drift-diffusion simulations as shown in Figure 61.<sup>43</sup> 

It is important to remark that the arcs observed in the different types of measurement correspond to different features, as indicated in Figure 60 that shows the origin of each time constant. In IMPS, the HF time constant is due to the coupling by the series resistance and the geometric capacitance of the cell,<sup>132</sup> while in IS it is due to the HF RC elements. 

As it is possible to compare the three measurements, IS, IMPS, and IMVS, the combination of the different methods via eq 47 has been recently developed.<sup>180,219,220</sup> We comment on the correlated measurements for carbon-contact perovskite solar cells.<sup>180,221</sup> These cells have shown very slow dynamic phenomena in voltage decay methods<sup>222</sup> and tunable hysteresis.<sup>223</sup> The capacitance versus frequency in Figure 62b indicates three different capacitive processes, and therefore the EC to describe the data starts from the model of Figure 60 including the RL series line as in Figure 51b to account for the low-frequency loops. The extended EC of Figure 62a is able to fit adequately the three types of spectra at the same time. The combination of spectra allows one to test the correlation of the techniques in eq 47, by calculating IMPS transfer function from the other two in Figure 62f. It is found that experimental and calculated spectra have the same number of features with similar shapes. Advanced methods to obtain physical parameters from the correlation of techniques are explained by Fabregat-Santiago et al.<sup>220</sup> 

9.3. Observation of Diffusion−Recombination of Electrons by IMPS 

Recently, it has been remarked that the IMPS of MHP shows negative features in the real part of Q as it is inferred from Figures 56 and 62d.<sup>126,212</sup> The same result is obtained from drift-diffusion simulations as shown in Figure 61. These features can be well described by the following model of the IMPS transfer function<sup>126,217</sup> that is based on the standard generation−diffusion−recombination approach<sup>209,215</sup> 



<!-- Start of picture text -->
Q ( ω )<br>1 − e − αd lm oo e ( p / ω d)1/2 + Ä p 1/2 − 1É sinhÄ p 1/2É|} oo<br>oon ÅÅÅÅÅÅÅÅÅÇ( ωα ) ÑÑÑÑÑÑÑÑÑÖ ÅÅÅÅÅÅÅÅ Å Ç( ωd ) ÑÑÑÑÑÑÑÑ Ñ Öoo~<br>= Ä É<br>Ä É 1/2<br>1 − p cosh p<br>ÅÅÅÅÅÅÅÇ ωα ÑÑÑÑÑÑÑÖ Å ÅÅÅÅÅÅÅ Å Ç( ω d) Ñ ÑÑÑÑÑÑÑ Ñ Ö<br>(50)<br>p ( ω ) = ω rec + iω (51)<br><!-- End of picture text -->

In eq 50, ωrec = τrec−1 is a recombination frequency, ωd = Dn/d2 is a frequency of diffusion over the cell thickness d, and ωα = Dnα<sup>2</sup> is a frequency of diffusion over light absorption distance, α being the optical absorption coefficient. 

As shown in Figure 63, the model provides a rich variety of behaviors and reveals the negative Q′ in the conditions in which the light absorption distance is short and the diffusion length is long, producing a spectral feature that spirals from low frequency to the origin at high frequency. This is very different from the diffusion impedance in Figure 4 where the diffusion appears in a high-frequency resistance that is well observed in dye-sensitized solar cells<sup>30,224</sup> but not observed in PSCs due to the very large electron diffusion coefficient that produces a very small resistance. Therefore, the IMPS model provides the opportunity to capture the electron lifetime and 

14464 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 



<!-- Start of picture text -->
pubs.acs.org/CR<br><!-- End of picture text -->



<!-- Start of picture text -->
Review<br><!-- End of picture text -->



Figure 59. IMPS spectra (frequency range 10 mHz−20 kHz) of CH3NH3PbBr3 cells with spiro-OmeTAD as the HTL measured at open-circuit conditions under DC 90 mW·cm<sup>−2</sup> blue (470 nm) illumination and different ETLs - (a) meso-(m-TiO2), (b) PCBM − ([6,6]-phenyl-C61-butyric acid methyl ester), and (c) flat (no ETL) samples. (d) IMPS measurements at a short circuit. (e) IS spectra at open-circuit conditions of the same samples measured under DC 90 mW·cm<sup>2</sup> white light illumination and (f) corresponding evolution of capacitance versus frequency. Reproduced with permission from ref 218. Copyright 2019 American Chemical Society. 



Figure 60. (a) Modified PSC EC for an IMPS. (b) Simulated IMPS Q-plane plot and (c) IS Z-plane plot and their corresponding time constants at OC conditions using the EC in (a). Parameters used were Rs = 120 and 20 Ω·cm<sup>2</sup> for (b) and (c) respectively, RHF = 30 Ω·cm<sup>2</sup> , RLF = 20 Ω·cm<sup>2</sup> , RIF = 300 Ω·cm<sup>2</sup> , Cg = 10<sup>−7</sup> F·cm<sup>−2</sup> , CIF = 10<sup>−4</sup> F· cm<sup>−2</sup> , CLF = 10<sup>−2</sup> F·cm<sup>−2</sup> . Reproduced with permission from ref 218. Copyright 2019 American Chemical Society. 

diffusion coefficient using small perturbation techniques over a steady state, and this in fact has been shown for different PSC types that provide a long pathway for the electrons generated in one contact to travel to the other one.<sup>126</sup> The results of the fit of the spiralling spectra gave excellent results for Dn and τrec, in agreement with other methods. But in contrast to contactless methods or the SCLC technique, the IMPS method enables the in situ characterization of a PSC at the required steady state since the diffusional features occur at high 



Figure 61. Simulated IMPS response for varying light intensity. Reproduced with permission from ref 43. Copyright 2019 American Chemical Society. 

frequency without the influence of ionic polarization that takes place in the LF range. 

### 10. TIME DOMAIN METHODS AND TIME CONSTANTS 

#### 10.1. Interpretation of Time Constants 

In the interpretation of IS, the EC is a valuable tool that gives a summary vision of the elements that control the physical response to a small perturbation over a steady state. Sometimes R and C elements can be directly interpreted in terms of conduction and polarization as discussed in previous sections. In other cases, it is simpler to give an interpretation to the product RC as indicated in eq 3, in terms of a time constant. There is not a general rule about which view is better. In some cases, the results are discussed in terms of characteristic time constants, and in others as separate R and C elements with unrelated physical interpretation. For example, R and C can be intimately linked in the case of a recombination process: a recombination resistance and the associated chemical capacitance (section 4.2), in which case the product is the recombination lifetime τrec in eq 31 that can be obtained from 

14465 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> <u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 62. (a) EC for the data fitting of IS of carbon-based perovskite solar cells. (b) Capacitance−frequency plot showing three capacitances at different frequencies. Complex plane plots of the IS (c), IMPS (d), and IMVS (e) transfer functions (Z, Q, and W, respectively) measured under 0.1 sun illumination at an open circuit. (f) IMPS Q function calculated from W and Z. Reproduced with permission from ref 180. Copyright 2020 American Chemical Society. 



Figure 63. Complex plane plots of the IMPS transfer function for several relative values of light absorption distance and diffusion length Ln = (Dnτrec)<sup>1/2</sup> . Rows are for equal absorption length, and columns for equal diffusion length. Red points indicate the characteristic time constant for diffusion, ωg = (π<sup>2</sup> /2)Dn/d<sup>2</sup> , and the black ones are the characteristic time for recombination, ωrec = 1/τn. Reproduced with permission from ref 126. Copyright 2021 American Chemical Society. 

14466 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

#### <u>Chemical Reviews</u> 

first principles.<sup>19,124</sup> Similarly, an RC product for a trapping process yields the trapping kinetic constant.<sup>225,226</sup> However, if R and C have a different origin, their product cannot be interpreted as a lifetime.<sup>102,125</sup> 

The typical behavior of the impedance spectra of PSC and the correspondent resistances and capacitances as a function of the open-circuit voltage are shown in Figure 25.<sup>97</sup> From their product, the time constants are obtained as shown in Figure 64. A study of three types of devices with different contacts is 



Figure 64. Characteristic response time calculated from the RC product for the low-frequency arc (solid line) and high-frequency arc (dashed line), respectively, from Figure 25. (a) Short-circuit and (b) open-circuit conditions for MAPbI3-based planar solar cells and (c) short-circuit and (d) open-circuit conditions for FAPbI3−xClx-based planar solar cells. Reproduced with permission from ref 97. Copyright 2016 American Chemical Society. 

shown in Figure 30.<sup>109</sup> As in other studies, there are two apparent time constants, a rapid time constant due to the RC combination corresponding to the HF, on the order of 10<sup>−3</sup> s, and a slow tie constant on the order of 1 s.<sup>23,167</sup> The slow time value is basically constant, while the fast process value decreases at increasing voltage.<sup>38</sup> The two relaxation processes have also been found by measurements of IMVS.<sup>227</sup> 

In principle, one would ascribe the fast time constant to a recombination process and the slow time constant to an interfacial process related to ionic interaction with the surface. In order to investigate this question, detailed measurements have been presented,<sup>97</sup> as shown in Figure 64, comparing cells with different thicknesses. The results confirm the exponential dependence on voltage for the rapid time constant, which is entirely due to the voltage dependence of the resistance since the HF capacitance is constant. The analysis also shows a striking voltage-independent behavior for the slow time constant. The reason why the LF capacitance and resistance are correlated reciprocally is still unknown. If the slow time constant is associated with a simple interfacial process, then it should be independent of the thickness, which is clearly not the case in the experimental data of Figure 48. It is concluded that the process presents a mixture of interfacial and bulk characteristics. This indicates that charging the double layer involves a transport for ions. Garcia-Belmonte et al. suggested<sup>88</sup> that the ion charging dynamics is composed of 

an average time for bulk transport in the thickness d and double layer charging, as is well established for liquid electrolytes and colloids.<sup>228</sup> A more detailed analysis indicates that τ time at LF is not explained simply by electrostatics and diffusion.<sup>23</sup> The slow time constant contains these features, but in addition, a significant component of surface binding, related to ionic relaxation that slows down the system, sets the value in the 1 s and longer domain and eventually produces out-ofphase components leading to inductive behavior in the frequency domain and a resistance that decreases at low frequency. 

We summarize in Figure 65 a range of kinetic phenomena concerning the LF behavior, with the following features: 



Figure 65. Classification of kinetic phenomena in PSC. (a) Ion transport along a distance of 100 nm occurs with a characteristic time constant of 10<sup>−2</sup> s. (b) Interfacial polarization is due to the ions blocked at the interface. It shows a capacitance without a resistive part. The low-frequency resistance needs to be interpreted in terms of recombination of interfacial charge transfer. (c) By specific ionic absorption at the interface, the ionic blocking obtains a resistive part. The ionic absorption can be extended to a more or less intense ionic reaction at the interface. The time constant is variable in the range 1− 20 s. These phenomena produce a very large capacitance, instability, and negative capacitance in some cases. 

- (1) The ionic migration in a sample of 100 nm occurs in a relatively fast time of 10<sup>−2</sup> s. 

- (2) The surface polarization provides a large capacitance at LF. However, polarization itself does not explain that the capacitance step occurs at a very low frequency. 

- (3) The low-frequency process shows in many cases a constant kinetic time, independent of current and voltage. Since the constant is a product RC, it occurs that the LF capacitance and resistance are correlated. The low-frequency features have combined properties of electronic and ionic processes. The low-frequency time constant should be associated with the surface charging with a resistive component associated with surface attachment and probably also to the ionic dynamics toward the interface. In extreme cases, these features can be fully controlled in a reproducible memory effect, as in the case of perovskite memristors. 

10.2. Transformation between Frequency and Time Domain Methods 

In this paper, we have reviewed extensively the application of small perturbation frequency domain techniques as IS, IMPS, and IMVS to MHP. The use of time transient decay techniques 

14467 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 

is a very popular alternative approach, aiming at the same goal of understanding the dynamic processes that determine the device response. There is a general connection between the two types of methods, corresponding to the transformation between time and frequency domain by the use of Laplace transform methods. In principle, by having sufficient information about the system characteristics in the frequency domain, for example, an exhaustive knowledge of the EC as a function of the applied voltage, one may be able to predict the behavior of time domain methods and vice versa. In practice, it is not so straightforward. The problem can be separated in two types, a soft problem and a hard problem. 

10.2.1. Small Perturbation Time Transient Techniques. The “soft” problem is the transformation between small perturbation methods in time and frequency domains. In both domains, the respective techniques operate by a small modification of a steady state; therefore, the steady-state parameters are fixed, and the Laplace techniques can be applied without a technical impediment. It does not mean that the transformation is simple; however, the operational pathway is well-defined. 

Small perturbation time-domain measurements of the transient photocurrent (TPC) and transient photovoltage (TPV) in response to a short light pulse have been widely reported in PSCs and applied to derive their fundamental parameters.<sup>200,212,229−236</sup> These techniques are closely related to time-resolved optical techniques as transient absorption spectroscopy (TAS)<sup>237−239</sup> and time-resolved-photoluminescence (TRPL),<sup>240,241</sup> which are contactless techniques not considered here. The connection of frequency and time domain methods was established for dye-sensitized solar cells,<sup>242</sup> and recently the framework to solve the frequency to time transformation has been elaborated for a number of models of perovskite solar cells.<sup>217</sup> Starting from models of the transfer function of IMPS, the associated impulse response function, the TPC in response to a short light pulse, is derived. Similarly, the transient photovoltage (TPV) is determined starting from the IMVS transfer function. An example of the derivation of TPC and TPV from an EC is shown in Figure 66 for the model of Figure 58. 

While the theoretical connection has been established, there are many uncertainties for the interpretation of experimental data. A number of unexpected phenomena like negative spikes in TPC and TPV<sup>200,212,229−232</sup> have been observed. Very probably many of these features can be attributed to the sample not being in an equilibrated steady state. It is suggested that the appearance of a photovoltage creates an electrical field in the film that opposes the built-in field and modifies the amount and sign of charge in the double layer, producing internal currents that oppose the ordinary charge or discharge effect.<sup>141</sup> In Figure 66d, the negative spike is a real feature pertaining to the steady state due to the hook in the fourth quadrant of the IMPS spectrum in b. 

Another problem of the transformation of small perturbation methods is the interpretation of the TPV decays in terms of recombination. In principle, TPV is closely connected to the contactless TRPL. The latter measures the radiative recombination in the sample, and the time constant is clearly a lifetime. However, in TPV, the decay time constant corresponds to the transformation of IMVS, as shown in Figure 66. Hence, the time constant depends on the product of the EC elements, previously described in Figure 64. As explained in eq 32, the interpretation of the TPV decay as a lifetime is related to the 



Figure 66. Frequency spectra and time transient analysis of the EC of Figure 58 (a). (b) IMPS, (c) IMVS, (d) TPC, (e) TPV, for the circuit with parameters Rs = 1 Ω, R1 = 10 Ω, R3 = 10, C1 = 0.1 F, Cg = 0.01 F. Reproduced with permission from ref 217. Copyright 2020 American Chemical Society. 

presence of the chemical capacitance of eq 17. We note that the chemical capacitance is not normally observed in the experimental ECs of MHPs. If the measured decay corresponds to surface capacitance C1 coupled with a resistor, it cannot be interpreted as a recombination lifetime, as commented on before.<sup>102,125</sup> In summary, even though the methods can be clearly formulated, the situation is far from being well understood. More experimental work is needed that relates the frequency domain methods in stabilized conditions to the correspondent small perturbation time transient decays, in order to obtain a consolidated interpretation of the observed processes by independent routes of measurement. 

10.2.2. Large Perturbation Time Transient Techni- 

ques: Hysteresis Effects. We describe the “hard” problem of the connection between frequency and time domain for a large perturbation. Suppose that we make a step voltage of 300 mV in a PSC such as those in Figure 25 or Figure 41. Clearly, the resistance and the capacitances change by several orders of magnitude, in the instantaneous change, from the initial to the final voltage. Therefore, it is not clear what parameter controls the transformation. In many cases, the time constant may be independent of voltage, but in others there are significant variations.<sup>177</sup> One can combine a number of small steps as shown in Figure 67. However, because of the slow evolution, the instantaneous parameters cannot simply be read from the voltage. There is a memory effect that makes them dependent on the previous history of the sample. 

14468 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

<u>Chemical Reviews</u> 

<u><mark>pubs.acs.org/CR</mark></u> 

<mark>Review</mark> 



Figure 67. Time-dependent photocurrent response of a planar perovskite solar cell on compact TiO2 (cp-TiO2) with a 500 nm CH3NH3PbI3 film as the light-absorber layer and 150 nm spiro-OMeTAD as the HTM layer under reverse and forward stepwise scans with (a) 1 s step time and (b) 0.1 s step time. (c) j−V response for PSCs with different CV scan rates. Reproduced with permission from 243. 



Figure 68. Catalogue of measured electrical responses observed in our laboratories as a function of the perovskite formulation and measurement conditions. Normal hysteresis with a capacitive response: MAPI and triple cation (TC) formulations. Inverted hysteresis with an inductive response: MAPBr measured at R.H. = 60%<sup>168</sup> or in inert atmosphere (R.H. = 0%). Reproduced from ref 177. 

These complex points regarding the elaboration of predictive models affect important characterization techniques. The open-circuit voltage decay (OCVD) experiment<sup>125,244,245</sup> is a large amplitude method wherein the decay of the photovoltage 

is measured upon switching off the light.<sup>242</sup> An example of an anomalous response due to a memory effect is the bounce-back of the photovoltage at intermediate times.<sup>141</sup> But the most famous and relevant phenomenon of large perturbation is the 

14469 

https://doi.org/10.1021/acs.chemrev.1c00214 Chem. Rev. 2021, 121, 14430−14484 

