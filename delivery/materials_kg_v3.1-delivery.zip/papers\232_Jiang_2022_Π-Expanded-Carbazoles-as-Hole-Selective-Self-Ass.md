# Π-Expanded Carbazoles as Hole-Selective Self-Assembled Monolayers for High-Performance Perovskite Solar Cells.

| 字段 | 内容 |
|---|---|
| 批次 | 第 3 批（机构权限补漏） |
| 期刊 | Angewandte Chemie |
| 年份 | 2022 |
| 引用量（Semantic Scholar） | 284 |
| 作者 | Wenlin Jiang, Fengzhu Li, Ming-Liang Li, Feng-Xiao Qi, Francis R. Lin, A. Jen |
| DOI | 10.1002/anie.202213560 |
| 源文件 | 023_Jiang_2022_Π-Expanded-Carbazoles-as-Hole-Selective-Self-Ass.pdf |

---
**_Angewandte Chemie_** 

**_Communications_** 

www.angewandte.org 







## **_Solar Cells Hot Paper_** 

How to cite: _Angew. Chem. Int. Ed._ **2022,** _61,_ e202213560 International Edition: doi.org/10.1002/anie.202213560 German Edition: doi.org/10.1002/ange.202213560 

# **π-Expanded Carbazoles as Hole-Selective Self-Assembled Monolayers for High-Performance Perovskite Solar Cells** 

_Wenlin Jiang_<sup>_+_</sup> _, Fengzhu Li_<sup>_+_</sup> _, Mingliang Li_<sup>_+_</sup> _, Feng Qi, Francis R. Lin, and Alex K.-Y. Jen*_ 

**Abstract:** Carbazole-derived self-assembled monolayers (SAMs) are promising hole-selective materials for inverted perovskite solar cells (PSCs). However, they often possess small dipoles which prohibit them from effectively modulating the workfunction of ITO substrate, limiting the PSC photovoltage. Moreover, their properties can be drastically affected by even subtle structural modifications, undermining the final PSC performance. Here, we designed two carbazole-derived SAMs, CbzPh and CbzNaph through asymmetric or helical π-expansion for improved molecular dipole moment and strengthened π-π interaction. The helical π- expanded CbzNaph has the largest dipole, forming densely packed and ordered monolayer, facilitated by the highly ordered assembly observed in its π-scaffold’s single crystal. These synergistically modulate the perovskite crystallization atop and tune the ITO workfunction. Consequently, the champion PSC employing CbzNaph showed an excellent 24.1% efficiency and improved stability. 

**_A_** lthough inverted (p-i-n junction) perovskite solar cells (PSCs) have attracted great attention<sup>[1]</sup> due to their lowtemperature processability and better compatibility with flexible substrates<sup>[2]</sup> and tandem device fabrication,<sup>[3]</sup> they usually show lower power conversion efficiencies (PCEs) than their conventional (n-i-p) counterparts due to larger energy losses. A key to mitigating this issue is to reduce the recombination losses at the interfaces between perovskite and charge-selective layers. Particularly, the hole-selective layer (HSL) plays a critical role in affecting the performance of inverted PSCs<sup>[4]</sup> by contributing to: i) extraction and transport of holes from perovskite to anode; ii) formation of an energetic barrier to block electrons from reaching anode 

[*] Dr. W. Jiang,<sup>+</sup> F. Li,<sup>+</sup> Dr. M. Li,<sup>+</sup> Prof. A. K.-Y. Jen Department of Materials Science and Engineering, City University of Hong Kong Kowloon 999077 (Hong Kong) 

E-mail: alexjen@cityu.edu.hk 

Dr. W. Jiang,<sup>+</sup> F. Li,<sup>+</sup> Dr. M. Li,<sup>+</sup> F. Qi, Dr. F. R. Lin, Prof. A. K.-Y. Jen Department of Chemistry, City University of Hong Kong, Kowloon 999077 (Hong Kong) 

Dr. W. Jiang,<sup>+</sup> F. Li,<sup>+</sup> Dr. M. Li,<sup>+</sup> F. Qi, Dr. F. R. Lin, Prof. A. K.-Y. Jen Hong Kong Institute for Clean Energy, City University of Hong Kong, Kowloon 999077 (Hong Kong) 

[<sup>+</sup> ] These authors contributed equally to this work. 

to avoid recombination; and iii) serving as a template to facilitate the crystallization of perovskite absorber on top.<sup>[5]</sup> Therefore, it is desirable to develop better materials to improve the quality of HSLs for serving the abovementioned functions to further improve PSC performance.<sup>[6]</sup> 

Self-assembled monolayers (SAMs) are ordered organic molecular assemblies grown from chemical adsorption on substrates.<sup>[7]</sup> Unlike traditional hole-transporting polymers such as PTAA and PEDOT, which work through a transport mechanism and often require additional dopants,<sup>[8]</sup> the ultrathin SAM layer can serve as an efficient HSL to extract holes from perovskite to anode in inverted PSCs.<sup>[9]</sup> The usage of SAM not only significantly reduces material consumption and parasitic absorption, but also offers the combined diverse substrate compatibility, simpler dopantfree processing protocols, and green-solvent processability.<sup>[10]</sup> Moreover, the better packed SAMs can help minimize current leakage and tune the substrate workfunction (WF) through its dipole<sup>[11]</sup> to improve the photovoltage of solar cells. 

Carbazole-based SAMs possess an electron-rich nature which is suitable for application as SAM HSLs. In earlier studies, a pristine carbazole SAM with a linear alkyl chain and phosphonic acid anchoring group was used as a HSL to achieve a respectable PCE of 20.9% in inverted PSCs.<sup>[9b,12]</sup> Thereafter, significant efforts have been devoted to developing SAMs based on carbazole scaffold.<sup>[13]</sup> In particular, the energetic alignment between SAM and perovskite and the molecular dipole orientation of SAM versus the substrate are two important topics that were systematically investigated from the molecular design perspective.<sup>[9b,13]</sup> While SAMs based on pristine carbazole show reasonably matched highest occupied molecular orbital (HOMO) energy level with the valence band maximum (VBM) of perovskites, it is quite challenging to introduce proper dipole pointing toward the ITO substrate in this class of molecules. 

Modulating the WF of substrate stems from the intrinsic molecular dipole orientation of the SAM, synergized by the density and order of molecular assembly. However, the highly symmetric and planar structure of carbazole leads to intrinsically weak molecular dipole, whereas the introduction of electron-donating groups to strengthen the dipole often induces steric hindrance and shifting of HOMO energy levels,<sup>[9b,13,14]</sup> undermining their capabilities in forming ordered and compact SAM and hole extraction. This is detrimental to the performance and stability of PSCs, which often needs to be remedied with a co-SAM<sup>[13b,14]</sup> to help alleviate leakage current and suppress interfacial charge recombination. Yet, even the subtle modification of 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (1 of 6) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Communications_** 



carbazole may drastically affect its assembly pattern, stacking, and energy levels to affect the final device performance. Therefore, a new molecular design strategy to introduce larger molecular dipole into carbazole-based SAMs without compromising the dense packing of monolayer is highly desirable. 

Herein, we report the design and synthesis of two carbazole-based SAMs, CbzPh and CbzNaph, through asymmetric<sup>[15]</sup> and helical π-expansion<sup>[16]</sup> of carbazole, respectively. Both strategies are capable of increasing the dipole moment and π-π interactions simultaneously. The structure-property-performance relationships of applying these SAMs as HSL for inverted PSCs were also investigated, with the inclusion of a commonly employed 4PACZ for thorough comparison (Figure 1). Among them, CbzNaph possesses the largest molecular dipole (2.41 D), suitable HOMO energy level (� 5.39 eV) for aligning with perovskite absorber, and compact π-π stacking (π-π distance = 3.34 Å) that can facilitate the formation of the densest assembly. Consequently, a champion PCE of 24.1% with improved device stability could be achieved by applying CbzNaph as an HSL in an inverted PSC. 

The intrinsic photostability and thermal stability of SAM molecules were first evaluated by 1H NMR spectra and thermogravimetric analysis (TGA) according to previously reported methods.<sup>[17]</sup> The 1H NMR spectra of the three SAM molecules were measured before and after continuous illumination under 1 sun light intensity for 24 h in powder form, where no material degradation signals could be observed (Figure S1, S2), demonstrating 4PACZ, CbzPh, and CbzNaph all have good photostability. From the TGA heating curve (Figure S3), the 5% weight loss temperature of 4PACZ, CbzPh and CbzNaph were 331 °C, 366 °C and 378 °C, respectively, which all have high enough thermal stability for practical optoelectronic applications. 

Cyclic voltammetry (CV) was employed to determine the energy levels for the π-scaffold of 4PACZ, CbzPh, and CbzNaph (Figure S5). The HOMO energy levels of CbzPh and CbzNaph were estimated to be � 5.47 eV and � 5.39 eV, respectively, which are both up-shifted compared to 4PACZ (� 5.52 eV). The lowest unoccupied molecular orbital 



**_Figure 1._** Molecular structures, calculated HOMO orbital distributions, dipole moments and HOMO energy levels of 4PACZ, CbzPh, and CbzNaph. 

(LUMO) energy levels of 4PACZ, CbzPh, and CbzNaph were estimated to be � 2.08 eV, � 2.31 eV and � 2.28 eV, respectively, based on their optical band gaps (Figure S4, Table S1). These results were further corroborated by density functional theory (DFT) computation (Figure S6) to afford the calculated HOMO energy levels of � 5.61 eV, � 5.49 eV and � 5.35 eV, respectively, for 4PACZ, CbzPh, and CbzNaph, which agree well with those obtained from the CV measurements. The energy levels of SAM-modified substrates were also characterized with ultraviolet photoelectron spectrometry (UPS). The HOMO energy levels of 4PACZ-, CbzPh- and CbzNaph-modified ITO surface were measured to be � 5.43 eV, � 5.36 eV, and � 5.24 eV (Figure S8, Table S1), respectively, showing the same trend as the those obtained from CV measurements and DFT calculations. The energetic alignment between these SAMs and perovskite absorber are within the proper range to enable efficient hole extraction from perovskite to SAMs, as well as to block electrons from reaching anode. 

The gas-phase molecular dipole moments were also calculated by DFT (Figure S7), among which CbzPh (2.04 D) and CbzNaph (2.41 D) both show larger dipole moments than 4PACZ (1.68 D). It is notable that a larger molecular dipole pointing toward ITO is favorable for down-shifting its WF.<sup>[11a,13b]</sup> Moreover, as shown by UPS measurements (Figure S8), the WF of CbzPhand CbzNaph-modified ITO substrates are � 5.00 eV and � 5.15 eV, deeper than that modified with 4PACZ (� 4.89 eV). This should facilitate more efficient holeextraction at the interface by minimizing the energy offset to achieve higher fill factor (FF) and open-circuit voltage ( _V_ oc) of the corresponding PSCs.<sup>[9e,13b]</sup> 

Annulate π-expansion is an effective molecular design strategy to strengthen π-π interactions,<sup>[18]</sup> which can be used to synergize with the van der Waals interactions between alkyl linkers in SAM to promote the molecular ordering during assembly.<sup>[19]</sup> To gain a deeper understanding about how our strategy affects the π-π interactions in these π- expanded carbazole SAMs, the single-crystal structures of their π-scaffolds retrieved from the CCDC database<sup>[20]</sup> were carefully analyzed. These structures are free of anchoring group which allows us to solely focus on the comparison of intrinsic intermolecular interactions between different π- expanded carbazoles, therefore can exclude the interruption of strong intermolecular interactions from anchoring groups, such as hydrogen bonding. The molecular packing of pristine carbazole in single crystal is a nearly parallel or antiparallel mode,<sup>[20b]</sup> and the vertical distance and longitudinal slip between parallel-neighboring carbazole molecules are as large as 3.37 Å and 5.73 Å, respectively (Figure 2a), resulting in no overlap between the carbazoles π-plane, which may lead to poor π-π interaction during the growth of 4PACZ. The direct fusion of one phenyl group on carbazole (3,4-positions) yields the asymmetric π-scaffold of CbzPh (7 _H_ -benzo[ _c_ ]carbazole), which has a small twisting angle of 4.27° (between the expanded phenyl ring and carbazole core) (Figure S9).<sup>[20c]</sup> The high planarity and absence of substituting pendants allow the 7 _H_ -benzo[ _c_ ]carbazole molecules to show a distance of 3.14 Å between neighboring 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (2 of 6) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Communications_** 





**_Figure 2._** The molecular packing patterns in single crystals corresponding to the π-scaffolds of a) 4PACZ (pristine carbazole), b) CbzPh (7 _H_ - benzo[ _c_ ]carbazole), and c) CbzNaph (7 _H_ -dibenzo[ _c_ , _g_ ]carbazole). The dihedral angles were measured through the plane defined by the central pyrrole ring and the outermost benzene ring. 

molecular π-planes, however, the large longitudinal slip of 5.48 Å doesn’t provide sufficient π-π overlap for interactions (Figure 2b). This also limits CbzPh’s capability in forming ordered assembly on the substrates. 

A helical π-expansion of carbazole through the symmetric fusion of two phenyls onto carbazole (3,4- and 5,6positions, respectively) gives the π-scaffold of CbzNaph (7 _H_ - dibenzo[ _c,g_ ]carbazole).<sup>[20d]</sup> The structure is slightly twisted, where dihedral angles of 14.01° can be observed between the central pyrrole ring and the lateral naphthyl on both sides (Figure 2c), resulting in a helical structure. 7 _H_ - dibenzo[ _c,g_ ]carbazole adopts a slipped π-stacked packing motif with strong C� H···π (2.82 Å) and π-π (3.34 Å) interactions. The strong π-π interaction induces a highly ordered one-dimensional linear assembly extending along the _c_ -axis. Such well-established π-π interactions and ordered packing of 7 _H_ -dibenzo[ _c,g_ ]carbazole may help promote the formation of a dense, highly ordered CbzNaph monolayer on substrates, alleviating the variations or cancelling of dipoles as in gas-phase molecules when they are incorporated into a condensed matter system,<sup>[21]</sup> synergizing with its larger dipole moment to more effectively tune the WF of substrates. 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (3 of 6) 

The SAMs were grown on ITO substrates by facile spincoating (Figure 3a) and then annealed at 100 °C on a hotplate for 15 min. Simply after the condensation reactions between phosphonic acid and hydroxyl group on the ITO surface, SAM molecules anchor onto the ITO substrates predominantly through bidentate and a small fraction of tridentate binding modes.<sup>[22]</sup> The annealed sample was rinsed with isopropanol to remove any unbounded SAM molecules. To confirm the formation of SAMs and assess their coverage on ITO surface, High resolution X-ray photoelectron spectroscopy (HR-XPS) and energy-dispersive X-ray spectroscopy (EDS) measurements were performed. The characteristic signals of C 1s and P 2p electrons are consistent with the atomic compositions of 4PACZ, CbzPh, and CbzNaph, demonstrating the successful anchoring of SAMs on the ITO surface (Figure S10 and S11). Furthermore, the EDS mapping revealed that all SAMs were uniformly functionalized on the ITO surface without severe phase segregation (Figure S14 and Figure 3b). In the literature, HR-XPS measurements can be used to help reveal the content information of both SAM and substrate within the penetration depth of approximately 5 nm.<sup>[23]</sup> Therefore, a semi-quantitative analysis on the elemental contents by HR-XPS was conducted to identify the molecular density and regularity in SAMs. The molecular concentration of SAMs can be reflected by the ratio of P in SAMs to In in ITO.<sup>[24]</sup> Furthermore, the coverage factor was calculated according to previous reports,<sup>[25]</sup> a coverage factor of 7.4×10<sup>�3</sup> , 8.2×10<sup>�3</sup> and 8.6×10<sup>�3</sup> was found for 4PACZ-, CbzPh-, and CbzNaph-modified ITO (Table S3), respectively. The CbzNaph-modified substrate was found to have the lowest In 3d content, the highest P/In ratio (Table S2) and the largest coverage factor, indicating the lowest ITO surface exposure and demonstrating the formation of a denser CbzNaph monolayer. This can be attributed to the more pronounced π-π interactions between CbzNaph molecules, as revealed from the single crystal of its π-scaffold. 

Since all 4PACZ, CbzPh, and CbzNaph possess similar carbazole-derived π-scaffolds without introducing other hydrophobic/hydrophilic heteroatoms, they should show 



**_Figure 3._** a) Schematic diagram for SAMs deposition; b) elemental mapping of P for 4PACZ-, CbzPh-, and CbzNaph-modified ITO; c) water contact angles of bare ITO, 4PACZ-, CbzPh-, and CbzNaphmodified ITO. 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Communications_** 



similar chemical environment of being more hydrophobic than the ITO substrate. Therefore, a SAM-modified ITO substrate with larger water contact angle should correspond to its denser growth and assembly.<sup>[26]</sup> The water contact angles of UV-ozone-treated ITO substrate and those modified with 4PACZ, CbzPh, and CbzNaph were measured, showing a contact angle of 15.1°, 73.4°, 75.8° and 86.6°, respectively (Figure 3c). This trend validates that CbzNaph is capable of forming a denser assembly and also can serve as a suitable non-wetting surface for perovskite crystallization.<sup>[27]</sup> 

From our experimental results, the π-expanded SAMs have been proven to form denser monolayers, which can synergize with their larger molecular dipoles to effectively tune the ITO WF.<sup>[11,13b]</sup> Moreover, it is noted that the SAM density on the substrate may affect the quality of perovskite absorber grown atop by modulating its crystallization dynamics. Therefore, X-ray diffraction (XRD) measurements were further conducted to investigate the quality of perovskite films formed on different SAM-modified substrates (Figure S16). When the perovskite is grown on a CbzNaph-modified substrate, it shows a stronger (110) crystal face diffraction than those grown on 4PACZ and CbzPh, indicating better perovskite film quality. This could benefit cell performance by improving FF through more efficient carrier extraction and minimized interfacial recombination.<sup>[27]</sup> 

Based on these encouraging findings, 4PACZ, CbzPh and CbzNaph SAMs were applied to evaluate their effectiveness as HSLs for fabricating inverted PSCs with a device configuration of ITO/SAM/perovskite/C60/BCP/Ag (Figure 4a). The reference device based on 4PACZ showed an average PCE of 14.5% with a _V_ oc of 1.07 V, a shortcircuit current density ( _J_ sc) of 23.20 mAcm<sup>�2</sup> , and a FF of 

58.43% under 1 sun illumination (AM 1.5G, 100 mWcm<sup>�2</sup> ). The average PCE of the devices based on CbzPh and CbzNaph were significantly improved to 19.2% and 21.4%, respectively, due to the enhanced FFs to 73.06% and 80.51%, and _J_ SCs to 23.43 mAcm<sup>�2</sup> and 23.57 mAcm<sup>�2</sup> , respectively (Figure 4b, 4c and Figure S20). Although the deepest-lying HOMO energy level of 4PACZ (� 5.52 eV) could form more favorable energy alignment with the perovskite VBM (� 5.9 eV), the CbzPh- and CbzNaph-based devices also deliver comparable _V_ OCs. This could be due to ITO WF adjusted by the larger dipoles of CbzPh and CbzNaph. The greatly enhanced FFs from CbzPh- and CbzNaph-based devices can also be attributed to the denser, more ordered assemblies resulting from enhanced π-π interactions, as observed in the single crystals of corresponding SAM π-scaffolds. Moreover, the dark current and light intensity-dependent _V_ oc of PSCs based on 4PACZ-, CbzPh-, and CbzNaph-modified substrates were measured (Figure S22). The CbzNaph-based device shows the smallest dark current and the highest ideality factor, both of which indicate a densely packed CbzNaph monolayer could effectively reduce current leakage and interfacial recombination<sup>[28]</sup> to improve the _V_ oc and FF of the corresponding PSCs. 

To study the charge carrier dynamics at the SAM/ perovskite interface, steady-state photoluminescence (PL) and time-resolved PL (TRPL) spectra of perovskite on top of SAM-modified substrates were measured to evaluate the hole extraction ability of SAMs. Notably, CbzNaph exhibits more efficient hole extraction than 4PACZ and CbzPh, as indicated by its weakest PL peak intensity (Figure S17). Moreover, lifetimes and weight fractions derived from TRPL spectra (Table S4, Figure S17) demonstrate CbzNaph has fastest carrier extraction capability among different 



**_Figure 4._** a) Device architecture of the inverted PSCs; b) current density–voltage ( _J_ – _V_ ) characteristics; c) box plots of PCEs of the PSCs employing SAM-modified substrates of 4PACZ, CbzPh and CbzNaph; d)–f) device characteristics of d) _J_ – _V_ sweeps, e) EQE and f) stabilized power output of the champion device employing CbzNaph HSL. 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (4 of 6) 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Communications_** 



SAMs. This could be attributed to the enhanced π-π interaction that enables CbzNaph to extract holes more efficiently in a more ordered ensemble. 

To fully exploit the potential of the CbzNaph HSL, top surface passivation<sup>[29]</sup> and light management through antireflection coating were also applied. The champion CbzNaph-based device achieved a PCE of 24.1% ( _V_ oc = 1.17 V, _J_ sc = 24.69 mAcm<sup>�2</sup> , and FF = 83.39%) (Figure 4d), which is the highest among SAM HSL-based inverted PSCs reported (Table S5), demonstrating the great potential of CbzNaph HSL for inverted PSCs. To ensure the data reliability, external quantum efficiency (EQE) of the device was also measured to calibrate the cell _J_ sc (Figure 4e). The integrated photocurrent (24.64 mAcm<sup>�2</sup> ) of the champion device matches well with the value obtained from the _J_ – _V_ measurement. The stability of champion cell was further assessed by tracking the stabilized power output at bias corresponding to the maximum power point (MPP) under continuous AM 1.5G illumination (Figure 4f). A stabilized PCE of 23.74% was retrieved, also agreeing well with the PCE from the _J_ – _V_ sweeps. 

To further evaluate the photostability and thermal stability of 4PACZ-, CbzPh-, and CbzNaph-based PSCs, the performance of unencapsulated devices under continuous AM 1.5G illumination in an N2-filled glove box (Figure S23) were tracked. The device with CbzNaph HSL exhibited the best photostability, retaining 97% of its initial efficiency after 120 h of continuous illumination, which was higher than those employing CbzPh (91%) and 4PACZ (88%). Then, the high-temperature (85 °C) stability of these cells was evaluated. The one with CbzNaph still showed the best thermal stability, retaining 70% of its initial efficiency after being continuously heated for 168 h, which is much higher than those with CbzPh (54%) and 4PACZ (25%). This demonstrates that more ordered and denser assembly of CbzNaph contributes to better stability of PSCs under external stresses. 

In conclusion, we report a novel molecular design strategy for carbazole-derived SAMs to facilitate their dense assembly and use for tuning ITO workfunction. Through asymmetric or helical π-expansion, CbzPh and CbzNaph were obtained as efficient HSLs for inverted PSCs. The larger molecular dipole of CbzPh and CbzNaph can tune the ITO WF effectively, while the stronger π-π interactions ensure more ordered and denser SAM assemblies. As a result, the champion device of inverted PSCs employing CbzNaph as HSL could achieve a very high PCE of 24.1% and improved device stability, which is the best performance among PSCs using SAM HSL. This work presents a novel molecular engineering strategy for functionalizing SAMs to control the energy levels, molecular dipoles, packing patterns, and self-assembly for achieving optimal electronic performance. Moreover, we also demonstrate how to correlate the single-crystal structure of SAM π-scaffolds with their assemblies and the corresponding PSC performance. The insights obtained from this molecular engineering approach will help accelerate the development of new SAM HSLs for more efficient PSCs. 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (5 of 6) 

### **_Acknowledgements_** 

A.K.Y.J. thanks the sponsorship of the Lee Shau-Kee Chair Professor (Materials Science), and the support from the APRC Grant of the City University of Hong Kong (9380086), the TCFS Grant (GHP/018/20SZ) and MRP Grant (MRP/040/21X) from the Innovation and Technology Commission of Hong Kong, the Green Tech Fund (202020164) from the Environment and Ecology Bureau of Hong Kong, the GRF grants (11307621, 11316422) from the Research Grants Council of Hong Kong, Guangdong Major Project of Basic and Applied Basic Research (2019B030302007), Guangdong-Hong Kong-Macao Joint Laboratory of Optoelectronic and Magnetic Functional Materials (2019B121205002). 

### **_Conflict of Interest_** 

The authors declare no conflict of interest. 

### **_Data Availability Statement_** 

The data that support the findings of this study are available in the Supporting Information of this article. 

**Keywords:** Carbazole **·** Hole-Selective Layer **·** Perovskite **·** Self-Assembled Monolayer **·** Solar Cells 

- [1] a) A. Rajagopal, K. Yao, A. K. Jen, _Adv. Mater._ **2018** , _30_ , 1800455; b) S. Yang, J. Dai, Z. Yu, Y. Shao, Y. Zhou, X. Xiao, X. C. Zeng, J. Huang, _J. Am. Chem. Soc._ **2019** , _141_ , 5781–5787; c) X. Zheng, B. Chen, J. Dai, Y. Fang, Y. Bai, Y. Lin, H. Wei, X. C. Zeng, J. Huang, _Nat. Energy_ **2017** , _2_ , 17102; d) D. Luo, W. Yang, Z. Wang, A. Sadhanala, Q. Hu, R. Su, R. Shivanna, G. F. Trindade, J. F. Watts, Z. Xu, T. Liu, K. Chen, F. Ye, P. Wu, L. Zhao, J. Wu, Y. Tu, Y. Zhang, X. Yang, W. Zhang, R. H. Friend, Q. Gong, H. J. Snaith, R. Zhu, _Science_ **2018** , _360_ , 1442–1446. 

- [2] a) P. Docampo, J. M. Ball, M. Darwich, G. E. Eperon, H. J. Snaith, _Nat. Commun._ **2013** , _4_ , 2761; b) Y. Li, L. Meng, Y. M. Yang, G. Xu, Z. Hong, Q. Chen, J. You, G. Li, Y. Yang, Y. Li, _Nat. Commun._ **2016** , _7_ , 10214. 

- [3] a) J. Xu, C. C. Boyd, Z. J. Yu, A. F. Palmstrom, D. J. Witter, B. W. Larson, R. M. France, J. Werner, S. P. Harvey, E. J. Wolf, W. Weigand, S. Manzoor, M. van Hest, J. J. Berry, J. M. Luther, Z. C. Holman, M. D. McGehee, _Science_ **2020** , _367_ , 1097–1104; b) Y. Hou, E. Aydin, M. De Bastiani, C. Xiao, F. H. Isikgor, D. J. Xue, B. Chen, H. Chen, B. Bahrami, A. H. Chowdhury, A. Johnston, S. W. Baek, Z. Huang, M. Wei, Y. Dong, J. Troughton, R. Jalmood, A. J. Mirabelli, T. G. Allen, E. Van Kerschaver, M. I. Saidaminov, D. Baran, Q. Qiao, K. Zhu, S. De Wolf, E. H. Sargent, _Science_ **2020** , _367_ , 1135–1140; c) M. Jošt, L. Kegelmann, L. Korte, S. Albrecht, _Adv. Energy Mater._ **2020** , _10_ , 1904102; d) G. Yang, Z. Ni, Z. J. Yu, B. W. Larson, Z. Yu, B. Chen, A. Alasfour, X. Xiao, J. M. Luther, Z. C. Holman, J. Huang, _Nat. Photonics_ **2022** , _16_ , 588–594. 

- [4] a) N. Cai, F. Li, Y. Chen, R. Luo, T. Hu, F. Lin, S. M. Yiu, D. Liu, D. Lei, Z. Zhu, A. K. Jen, _Angew. Chem. Int. Ed._ **2021** , _60_ , 20437–20442; _Angew. Chem._ **2021** , _133_ , 20600–20605; b) Y. 

© 2022 Wiley-VCH GmbH 

**_Angewandte Chemie_** 

**_Communications_** 



   - Yao, C. Cheng, C. Zhang, H. Hu, K. Wang, S. De Wolf, _Adv. Mater._ **2022** , _34_ , 2203794. 

- [5] X. Sun, X. Deng, Z. Li, B. Xiong, C. Zhong, Z. Zhu, Z. Li, A. K. Jen, _Adv. Sci._ **2020** , _7_ , 1903331. 

- [6] a) S. Wu, J. Zhang, Z. Li, D. Liu, M. Qin, S. H. Cheung, X. Lu, D. Lei, S. K. So, Z. Zhu, A. K. Y. Jen, _Joule_ **2020** , _4_ , 1248– 1262; b) X. Sun, Z. Li, X. Yu, X. Wu, C. Zhong, D. Liu, D. Lei, A. K. Jen, Z. Li, Z. Zhu, _Angew. Chem. Int. Ed._ **2021** , _60_ , 7227–7233; _Angew. Chem._ **2021** , _133_ , 7303–7309. 

- [7] a) M. Kim, J. N. Hohman, Y. Cao, K. N. Houk, H. Ma, A. K. Jen, P. S. Weiss, _Science_ **2011** , _331_ , 1312–1315; b) O. Acton, D. Hutchins, L. Arnadottir, T. Weidner, N. Cernetic, G. G. Ting, T. W. Kim, D. G. Castner, H. Ma, A. K. Jen, _Adv. Mater._ **2011** , _23_ , 1899–1902; c) J. Y. Lee, S. Y. Kim, H. J. Yoon, _Adv. Opt. Mater._ **2022** , _10_ , 2101361. 

- [8] K. Rakstys, C. Igci, M. K. Nazeeruddin, _Chem. Sci._ **2019** , _10_ , 6748–6769. 

- [9] a) A. Al-Ashouri, A. Magomedov, M. Roß, M. Jošt, M. Talaikis, G. Chistiakova, T. Bertram, J. A. Márquez, E. Köhnen, E. Kasparavičius, S. Levcenco, L. Gil-Escrig, C. J. Hages, R. Schlatmann, B. Rech, T. Malinauskas, T. Unold, C. A. Kaufmann, L. Korte, G. Niaura, V. Getautis, S. Albrecht, _Energy Environ. Sci._ **2019** , _12_ , 3356–3369; b) A. Al-Ashouri, E. Kohnen, B. Li, A. Magomedov, H. Hempel, P. Caprioglio, J. A. Marquez, A. B. Morales Vilches, E. Kasparavicius, J. A. Smith, N. Phung, D. Menzel, M. Grischek, L. Kegelmann, D. Skroblin, C. Gollwitzer, T. Malinauskas, M. Jost, G. Matic, B. Rech, R. Schlatmann, M. Topic, L. Korte, A. Abate, B. Stannowski, D. Neher, M. Stolterfoht, T. Unold, V. Getautis, S. Albrecht, _Science_ **2020** , _370_ , 1300–1309; c) S. Y. Kim, S. J. Cho, S. E. Byeon, X. He, H. J. Yoon, _Adv. Energy Mater._ **2020** , _10_ , 2002606; d) Z. Dai, S. K. Yadavalli, M. Chen, A. Abbaspourtamijani, Y. Qi, N. P. Padture, _Science_ **2021** , _372_ , 618–622; e) A. Ullah, K. H. Park, H. D. Nguyen, Y. Siddique, S. F. A. Shah, H. Tran, S. Park, S. I. Lee, K. K. Lee, C. H. Han, K. Kim, S. Ahn, I. Jeong, Y. S. Park, S. Hong, _Adv. Energy Mater._ **2022** , _12_ , 2103175. 

- [10] a) E. Li, E. Bi, Y. Wu, W. Zhang, L. Li, H. Chen, L. Han, H. Tian, W. H. Zhu, _Adv. Funct. Mater._ **2020** , _30_ , 1909509; b) E. Li, C. Liu, H. Lin, X. Xu, S. Liu, S. Zhang, M. Yu, X. M. Cao, Y. Wu, W. H. Zhu, _Adv. Funct. Mater._ **2021** , _31_ , 2103847; c) R. Azmi, E. Ugur, A. Seitkhan, F. Aljamaan, A. S. Subbiah, J. Liu, G. T. Harrison, M. I. Nugraha, M. K. Eswaran, M. Babics, Y. Chen, F. Xu, T. G. Allen, A. U. Rehman, C. L. Wang, T. D. Anthopoulos, U. Schwingenschlogl, M. De Bastiani, E. Aydin, S. De Wolf, _Science_ **2022** , _376_ , 73–77. 

- [11] a) H.-L. Yip, S. K. Hau, N. S. Baek, H. Ma, A. K. Y. Jen, _Adv. Mater._ **2008** , _20_ , 2376–2382; b) I. Lange, S. Reiter, M. Pätzel, A. Zykov, A. Nefedov, J. Hildebrandt, S. Hecht, S. Kowarik, C. Wöll, G. Heimel, D. Neher, _Adv. Funct. Mater._ **2014** , _24_ , 7014– 7024. 

- [12] E. J. Cassella, E. L. K. Spooner, T. Thornber, M. E. O’Kane, T. E. Catley, J. E. Bishop, J. A. Smith, O. S. Game, D. G. Lidzey, _Adv. Sci._ **2022** , _9_ , 2104848. 

- [13] a) E. Aktas, N. Phung, H. Köbler, D. A. González, M. Méndez, I. Kafedjiska, S.-H. Turren-Cruz, R. Wenisch, I. Lauermann, A. Abate, E. Palomares, _Energy Environ. Sci._ **2021** , _14_ , 3976– 3985; b) X. Deng, F. Qi, F. Li, S. Wu, F. R. Lin, Z. Zhang, Z. Guan, Z. Yang, C. S. Lee, A. K. Jen, _Angew. Chem. Int. Ed._ **2022** , _61_ , e202203088; _Angew. Chem._ **2022** , _134_ , e202203088. 

   - [16] B. Liu, M. Bockmann, W. Jiang, N. L. Doltsinis, Z. Wang, _J. Am. Chem. Soc._ **2020** , _142_ , 7092–7099. 

   - [17] S. Zhang, R. Wu, C. Mu, Y. Wang, L. Han, Y. Wu, W.-H. Zhu, _ACS Mater. Lett._ **2022** , _4_ , 1976–1983. 

   - [18] a) W. Wu, Y. Liu, D. Zhu, _Chem. Soc. Rev._ **2010** , _39_ , 1489– 1502; b) W. Jiang, Z. Liu, D. Zhu, W. Zheng, L. Chen, X. Zhang, G. Zhang, Y. Yi, L. Jiang, D. Zhang, _Angew. Chem. Int. Ed._ **2021** , _60_ , 10700–10708; _Angew. Chem._ **2021** , _133_ , 10795–10803. 

   - [19] a) S. Casalini, C. A. Bortolotti, F. Leonardi, F. Biscarini, _Chem. Soc. Rev._ **2017** , _46_ , 40–71; b) M. Halik, A. Hirsch, _Adv. Mater._ **2011** , _23_ , 2689–2695. 

   - [20] a) C. R. Groom, I. J. Bruno, M. P. Lightfoot, S. C. Ward, _Acta Crystallogr. Sect. B_ **2016** , _72_ , 171–179; b) Z. Zhang, L. Tang, X. Fan, Y. Wang, K. Zhang, Q. Sun, H. Zhang, S. Xue, W. Yang, CCDC 1845385: _Experimental Crystal Structure Determination_ , **2018** ; c) W. Clegg, CCDC 1412957: _Experimental Crystal Structure Determination_ , **2015** ; d) Y. Zhang, Y. Su, H. Wu, Z. Wang, C. Wang, Y. Zheng, X. Zheng, L. Gao, Q. Zhou, Y. Yang, X. Chen, C. Yang, Y. Zhao CCDC 2098803: _Experimental Crystal Structure Determination_ , **2021** . 

   - [21] a) H. J. Yoon, N. D. Shapiro, K. M. Park, M. M. Thuo, S. Soh, G. M. Whitesides, _Angew. Chem. Int. Ed._ **2012** , _51_ , 4658–4661; _Angew. Chem._ **2012** , _124_ , 4736–4739; b) H. J. Yoon, C. M. Bowers, M. Baghbanzadeh, G. M. Whitesides, _J. Am. Chem. Soc._ **2014** , _136_ , 16–19. 

   - [22] a) P. B. Paramonov, S. A. Paniagua, P. J. Hotchkiss, S. C. Jones, N. R. Armstrong, S. R. Marder, J.-L. Brédas, _Chem. Mater._ **2008** , _20_ , 5131–5133; b) S. A. Paniagua, A. J. Giordano, O. L. Smith, S. Barlow, H. Li, N. R. Armstrong, J. E. Pemberton, J. L. Bredas, D. Ginger, S. R. Marder, _Chem. Rev._ **2016** , _116_ , 7117–7158. 

   - [23] H. Alhummiany, S. Rafique, K. Sulaiman, _J. Phys. Chem. C_ **2017** , _121_ , 7649–7658. 

   - [24] a) O. Acton, M. Dubey, T. Weidner, K. M. O’Malley, T.-W. Kim, G. G. Ting, D. Hutchins, J. E. Baio, T. C. Lovejoy, A. H. Gage, D. G. Castner, H. Ma, A. K. Y. Jen, _Adv. Funct. Mater._ **2011** , _21_ , 1476–1488; b) S. Y. Lee, Y. Choi, E. Ito, M. Hara, H. Lee, J. Noh, _Phys. Chem. Chem. Phys._ **2013** , _15_ , 3609–3617. 

   - [25] I. Levine, A. Al-Ashouri, A. Musiienko, H. Hempel, A. Magomedov, A. Drevilkauskaite, V. Getautis, D. Menzel, K. Hinrichs, T. Unold, S. Albrecht, T. Dittrich, _Joule_ **2021** , _5_ , 2915–2933. 

   - [26] J. A. Bardecker, H. Ma, T. Kim, F. Huang, M. S. Liu, Y.-J. Cheng, G. Ting, A. K. Y. Jen, _Adv. Funct. Mater._ **2008** , _18_ , 3964–3971. 

   - [27] a) C.-H. Chen, Y.-T. Hsu, B.-C. Wang, C.-L. Chung, C.-P. Chen, _J. Phys. Chem. C_ **2019** , _123_ , 1602–1609; b) C. Bi, Q. Wang, Y. Shao, Y. Yuan, Z. Xiao, J. Huang, _Nat. Commun._ **2015** , _6_ , 7747; c) S. Y. Kim, H. Kang, K. Chang, H. J. Yoon, _ACS Appl. Mater. Interfaces_ **2021** , _13_ , 31236–31247. 

   - [28] a) V. Sarritzu, N. Sestu, D. Marongiu, X. Chang, S. Masi, A. Rizzo, S. Colella, F. Quochi, M. Saba, A. Mura, G. Bongiovanni, _Sci. Rep._ **2017** , _7_ , 44629; b) C. M. Wolff, P. Caprioglio, M. Stolterfoht, D. Neher, _Adv. Mater._ **2019** , _31_ , 1902762. 

   - [29] F. Li, X. Deng, F. Qi, Z. Li, D. Liu, D. Shen, M. Qin, S. Wu, F. Lin, S. H. Jang, J. Zhang, X. Lu, D. Lei, C. S. Lee, Z. Zhu, A. K. Jen, _J. Am. Chem. Soc._ **2020** , _142_ , 20134–20142. 

- [14] A. Magomedov, A. Al-Ashouri, E. Kasparavičius, S. Strazdaite, G. Niaura, M. Jošt, T. Malinauskas, S. Albrecht, V. Getautis, _Adv. Energy Mater._ **2018** , _8_ , 1801892. 

- [15] W. Gao, B. Fan, F. Qi, F. Lin, R. Sun, X. Xia, J. Gao, C. Zhong, X. Lu, J. Min, F. Zhang, Z. Zhu, J. Luo, A. K. Y. Jen, _Adv. Funct. Mater._ **2021** , _31_ , 2104369. 

Manuscript received: September 14, 2022 Accepted manuscript online: October 27, 2022 Version of record online: November 22, 2022 

_Angew. Chem. Int. Ed._ **2022** , _61_ , e202213560 (6 of 6) 

© 2022 Wiley-VCH GmbH 

