# 材料专业术语知识图谱 · 进度汇报包

生成时间：2026-11-26 18:03　数据版本：v3.0　包版本：v3.1-delivery

## 一、包内清单

| 目录 | 文件 | 内容 |
|---|---|---|
| `图/` | `01_知识图谱总览.png` | 汇报用总图（2600×1600，标题 + 统计 + 图例） |
| | `02_交互界面_全库大图.png` | 实际页面截图（12 类型区域 + 社区斑块） |
| | `03_类型汇总.png` | 12 个类型的汇总环图 |
| | `04_英文界面.png` | 中英文切换后的界面 |
| `三元组/` | `triples_full.csv` | 全量三元组，39,400 行，18 列，UTF-8 BOM（Excel 直接打开） |
| | `triples_full.jsonl` | 同一批三元组，39,400 行 JSON，字段更全 |
| | `样例_200条.csv` | 从全量中均匀抽样 200 条，用于快速浏览 |
| `统计/` | `概览.json` | 规模、覆盖、质量口径汇总 |
| | `谓词族分布.csv` | 各类关系的数量与占比 |
| | `类型对Top30.csv` | 最常见的「主语类型 → 宾语类型」组合 |
| | `论文关系量.csv` | 285 篇论文各自的关系数 |

## 二、规模与质量口径

| 指标 | 数值 |
|---|---|
| 论文 | 285 篇 |
| 概念 | 51,464 个（12 类） |
| 论文内实例 | 920 个 |
| 规范关系 | 39,400 条（唯一 `relation_id` 39,400 个） |
| 涉及节点 | 41,124 个有关系连接 + 11,260 个仅检索 |
| 证据行号覆盖 | 37,925 / 39,400（96.3%） |
| 方向待复核 | 159 条（0.4%） |
| 每篇关系数 | 最少 14，中位 105，最多 720，平均 138.2 |

关系最多的论文：

- 259 · Synergy of 3D and 2D Perovskites for Durable, Efficient Solar Cells and Beyond.：720 条
- 226 · Recent Advances in 2D Material Theory, Synthesis, Properties, and Applications：649 条
- 164 · Narrow Bandgap Metal Halide Perovskites for All-Perovskite Tandem Photovoltaics：574 条
- 253 · Porous materials as effective chemiresistive gas sensors.：531 条
- 228 · Confinement of Luminescent Guests in Metal–Organic Frameworks: Understanding Pathways from Synthesis and Multimodal Characterization to Potential Applications of LG@MOF Systems：519 条
- 209 · Biomass-Based Carbon Dots: Current Development and Future Perspectives.：503 条
- 038 · Recent Progress on Flexible Room-Temperature Gas Sensors Based on Metal Oxide Semiconductor：487 条
- 173 · Strategy and Future Prospects to Develop Room-Temperature-Recoverable NO2 Gas Sensor Based on Two-Dimensional Molybdenum Disulfide：472 条

计数口径：CSV 行数 = JSONL 行数 = 唯一 `relation_id` 数。关系用 `relation_id` 去重，同一规范关系在不同论文中的出现各自保留。

## 三、图怎么用

- `01_知识图谱总览.png`：适合直接放进汇报 PPT。12 个类型区域，区域内的彩色斑块是关系聚类社区；底部是社区图例。
- `02_交互界面_全库大图.png`：展示实际产品的侧栏、筛选和统计条；页面可缩放、悬停高亮、点节点看证据。
- `03_类型汇总.png`：适合讲“知识库覆盖哪些类型、类型之间怎么连”。
- `04_英文界面.png`：展示中英文一键切换。

## 四、三元组怎么读

一行是一条规范关系，核心是 `主语 → 谓词 → 宾语`，并带出处：

| 字段 | 含义 |
|---|---|
| `relation_id` | 关系唯一 ID（计数以此为准） |
| `subject_id` / `object_id` | 概念或实例 ID |
| `subject` / `object` | 术语文本 |
| `predicate` | 规范谓词 |
| `subject_type` / `object_type` | 12 类实体类型 |
| `family` | 谓词族（effect / process / dependency / …） |
| `paper_id` | 来源论文（前 3 位是论文序号） |
| `evidence_line` / `evidence` | 原文行号与引文；行号为空表示“定位缺失” |
| `direction_ok` | 方向是否符合谓词约束；`false` 为待复核 |
| `polarity` / `modality` / `review_status` / `source` | 极性、模态、复核状态、抽取来源 |

Excel：双击 `triples_full.csv` 即可（带 BOM，中文不乱码）。
Python：

```python
import pandas as pd
df = pd.read_csv("三元组/triples_full.csv", encoding="utf-8-sig")
print(len(df), df["family"].value_counts().head())
```

```python
import json
rows = [json.loads(line) for line in open("三元组/triples_full.jsonl", encoding="utf-8")]
```

## 五、汇报要点（可直接照读）

1. 已从 285 篇材料论文抽出 39,400 条带出处的规范关系，覆盖 51,464 个专业概念和 920 个论文内样品/器件实例。
2. 关系按 12 类实体和 9 类谓词族组织，可以从“材料—工艺—结构—性能—器件”链条上检索和追溯。
3. 96.3% 的关系能定位到原文行号和引文；其余明确标注“定位缺失”，不伪装成可核对证据。
4. 页面支持全库大图、类型汇总、术语邻域三种看法，支持按类型/谓词族/论文筛选、悬停高亮、点选看证据，以及中英文切换。
5. 质量口径是“全量守恒、端点完整、可核对、可移交”；语义准确率与召回率尚未做独立抽样评估。

## 六、已知边界

- 这是术语与关系知识库，不是问答系统或性能预测模型；观测数值只放在样品/属性信息里，不做跨论文性能排名。
- 7,135 条类型冲突、159 条方向待复核、1,475 条证据无行号仍以“复核队列”形式存在，页面会标注但不自动改写。
- 数据版本 v3.0，抽取侧的改进（摘要误删、失败块补抽、跨学科本体扩展）留待下一轮。

## 七、原始交付物

本包只放汇报用的图、三元组和统计，体积控制在 18 MB 左右，方便邮件/微信传输。
完整可交互页面（含 285 篇论文原文、证据分片，约 28 MB）不在本包内；需要演示时从项目交付目录取
`materials_kg_v3.1-delivery.zip`，解压后用本地 HTTP 服务打开：
`python -m http.server 8766 --bind 127.0.0.1 --directory materials_kg_final`，浏览器访问 `http://127.0.0.1:8766/`。
